"""Owner setup recipes for builders and external settlement rails.

    python -m covenant_agent.owner_config builder --directory /OWNER_DIR \\
        --publisher PUBLISHER_ACCOUNT_HEX=PUBLISHER_KEY_HEX \\
        --trusted-account ACCOUNT_HEX=KEY_HEX
    python -m covenant_agent.owner_config rail --directory /OWNER_DIR \\
        --rail x402 --network base-sepolia --credential-env OWNER_X402_TOKEN
    python -m covenant_agent.owner_config inspect --directory /OWNER_DIR

Every file written here is key-free. Publisher and account entries are public
verification keys. A rail credential is named by an environment variable; its
value is never read into, written to or printed from any file.

``load_builder`` turns the builder file into the owner-side registries that
``covenant_chain.runtime_host.RuntimeHost`` accepts as ``applications`` and
``builders``. Application backends remain Python handlers the owner registers;
no code is loaded from configuration.

An external rail declaration records the owner's intent. This package has no
executable external x402 or AP2 settlement; the bilateral host still settles
only through its owner-installed reference provider. Inspection reports a
declared rail as ``DECLARED_NOT_EXECUTABLE`` and never as ready to pay.
"""
import argparse
import json
import os
from pathlib import Path
import re
import stat
import sys

from covenant_language.safe_io import atomic_write

from .errors import NativeError, need, refusal

BUILDER_VERSION = 'covenant-builder-owner/0.1'
RAIL_VERSION = 'covenant-rail-owner/0.1'
RAILS = ('x402', 'ap2')
HEX = re.compile(r'[0-9a-f]{64}\Z')
ENV_NAME = re.compile(r'[A-Z][A-Z0-9_]{1,63}\Z')
NETWORK = re.compile(r'[a-z0-9][a-z0-9:._-]{0,79}\Z')
SECRET_WORDS = ('seed', 'secret', 'private', 'password', 'token_value', 'api_key')
IMPLEMENTED = [
    {'rail': 'REFERENCE_SQLITE', 'implementation': 'covenant_agent.settlement_ledger_v2.SharedSettlementLedger',
     'setup': 'python -m covenant_agent.demo_setup --directory /OWNER_SELECTED_NEW_DIRECTORY',
     'money': 'SYNTHETIC_ONLY', 'executable': True},
    {'rail': 'x402/ap2 labels on covenant-bilateral', 'implementation': 'covenant_agent.settlement.X402Adapter, AP2Adapter',
     'setup': 'In-process StablecoinLedger balances in an owner host config',
     'money': 'SIMULATED_STABLECOIN_LEDGER_NOT_EXTERNAL_PAYMENT', 'executable': True},
    {'rail': 'PAYMENT_DEMO', 'implementation': 'covenant_chain.payment_rails.DemoPaymentRail',
     'setup': 'runtime host workflow.adapters kind PAYMENT_DEMO', 'money': 'DISPOSABLE_TEST_CREDITS', 'executable': True},
]


def _directory(directory, *, create):
    need(isinstance(directory, (str, Path)) and str(directory).strip(), 'OWNER_DIRECTORY')
    path = Path(directory).expanduser().absolute()
    need('..' not in path.parts and path.name not in ('', '.'), 'OWNER_DIRECTORY')
    if create and not os.path.lexists(path):
        need(path.parent.is_dir(), 'OWNER_DIRECTORY')
        path.mkdir(mode=0o700)
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        raise NativeError('OWNER_DIRECTORY') from None
    need(stat.S_ISDIR(info.st_mode), 'OWNER_DIRECTORY')
    need(info.st_uid == os.getuid() and info.st_mode & 0o077 == 0, 'OWNER_DIRECTORY_PERMISSIONS')
    return path


def _write(path, name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode('ascii')
    try:
        atomic_write(path / name, raw, mode=0o600, exclusive=True, follow_symlinks=False)
    except FileExistsError:
        raise NativeError('OWNER_CONFIG_EXISTS') from None
    return str(path / name)


def _read(path, name):
    try:
        fd = os.open(path / name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_mode & 0o077 == 0 and
             info.st_size <= 65536, 'OWNER_FILE_PERMISSIONS')
        raw = stream.read(65537)
    try:
        value = json.loads(raw.decode('ascii'))
    except (ValueError, UnicodeError):
        raise NativeError('OWNER_JSON') from None
    need(type(value) is dict, 'OWNER_JSON')
    return value


def _no_secrets(value, depth=0):
    """Configuration may name secrets, never hold them."""
    need(depth <= 8, 'OWNER_JSON')
    if type(value) is dict:
        for key, item in value.items():
            need(type(key) is str and not any(word in key.lower() for word in SECRET_WORDS), 'OWNER_SECRET_IN_CONFIG')
            _no_secrets(item, depth + 1)
    elif type(value) is list:
        for item in value:
            _no_secrets(item, depth + 1)


def _pairs(values, code):
    need(type(values) is dict and len(values) <= 64, code)
    for account, key in values.items():
        need(type(account) is str and bool(HEX.fullmatch(account)), code)
        need(type(key) is str and bool(HEX.fullmatch(key)), code)
        from .codec import valid_ed25519_key
        need(valid_ed25519_key(key), 'PUBLIC_KEY')
    return dict(sorted(values.items()))


def builder_document(publishers, trusted_accounts, policies=()):
    """The exact key-free builder owner document, validated before writing."""
    need(publishers, 'BUILDER_PUBLISHERS')
    need(type(policies) in (list, tuple) and len(policies) <= 32 and all(type(p) is dict for p in policies),
         'BUILDER_POLICIES')
    document = {'version': BUILDER_VERSION, 'trusted_publishers': _pairs(publishers, 'BUILDER_PUBLISHERS'),
                'trusted_accounts': _pairs(trusted_accounts, 'BUILDER_TRUST'),
                'economics_policies': list(policies),
                'backends': 'OWNER_REGISTERS_PYTHON_HANDLERS; NONE_LOADED_FROM_CONFIG'}
    _no_secrets(document)
    return document


def write_builder(directory, publishers, trusted_accounts, policies=()):
    path = _directory(directory, create=True)
    document = builder_document(publishers, trusted_accounts, policies)
    load_builder_document(document)
    written = _write(path, 'builder-owner.json', document)
    return {'format': BUILDER_VERSION, 'path': written, 'publishers': sorted(document['trusted_publishers']),
            'trusted_accounts': sorted(document['trusted_accounts']), 'policies': len(document['economics_policies']),
            'private_keys_in_output': False, 'applications_installed': 0, 'execution_authorized': False,
            'next': ('In the owner process: regs = load_builder(path, mechanisms=<owner MechanismRegistry with handlers>); '
                     'RuntimeHost(config, applications=regs["applications"], builders=regs["builders"]). '
                     'Install each signed release explicitly; publisher trust is not installation.')}


def load_builder_document(document, *, mechanisms=None):
    """Owner-side registries from a validated builder document; nothing is installed."""
    need(type(document) is dict and set(document) == {'version', 'trusted_publishers', 'trusted_accounts',
                                                      'economics_policies', 'backends'}, 'BUILDER_CONFIG')
    need(document['version'] == BUILDER_VERSION, 'BUILDER_CONFIG')
    _no_secrets(document)
    from covenant_chain.builder_programme_runtime import BuilderProgrammeRegistry
    from covenant_chain.developer_runtime import ApplicationRegistry
    from covenant_chain.mechanism_runtime import MechanismRegistry
    if mechanisms is None:
        mechanisms = MechanismRegistry()
    need(isinstance(mechanisms, MechanismRegistry), 'BUILDER_MECHANISMS')
    applications = ApplicationRegistry(mechanisms, _pairs(document['trusted_publishers'], 'BUILDER_PUBLISHERS'),
                                       document['economics_policies'])
    builders = BuilderProgrammeRegistry(applications, _pairs(document['trusted_accounts'], 'BUILDER_TRUST'))
    return {'mechanisms': mechanisms, 'applications': applications, 'builders': builders}


def load_builder(path, *, mechanisms=None):
    """Read ``builder-owner.json`` from an owner-private directory."""
    directory = _directory(Path(path).parent if Path(path).name == 'builder-owner.json' else path, create=False)
    document = _read(directory, 'builder-owner.json')
    need(document is not None, 'BUILDER_CONFIG_MISSING')
    return load_builder_document(document, mechanisms=mechanisms)


def rail_document(rail, network, credential_env, *, endpoint=None, provider_pin=None):
    need(rail in RAILS, 'RAIL')
    need(type(network) is str and bool(NETWORK.fullmatch(network)), 'RAIL_NETWORK')
    need(type(credential_env) is str and bool(ENV_NAME.fullmatch(credential_env)), 'RAIL_CREDENTIAL_ENV')
    need(endpoint is None or (type(endpoint) is str and endpoint.startswith('https://') and
                              8 < len(endpoint) <= 256 and '@' not in endpoint and '?' not in endpoint), 'RAIL_ENDPOINT')
    need(provider_pin is None or (type(provider_pin) is str and bool(HEX.fullmatch(provider_pin))), 'RAIL_PROVIDER_PIN')
    document = {'version': RAIL_VERSION, 'rail': rail, 'network': network,
                'credential_env': credential_env, 'endpoint': endpoint, 'provider_pin': provider_pin,
                'status': 'DECLARED_NOT_EXECUTABLE'}
    _no_secrets(document)
    return document


def write_rail(directory, rail, network, credential_env, *, endpoint=None, provider_pin=None):
    path = _directory(directory, create=True)
    document = rail_document(rail, network, credential_env, endpoint=endpoint, provider_pin=provider_pin)
    written = _write(path, 'rail-' + rail + '.json', document)
    return {'format': RAIL_VERSION, 'path': written, 'rail': rail, 'network': network,
            'credential_env': credential_env, 'credential_value_read': False,
            'status': 'DECLARED_NOT_EXECUTABLE', 'payment_rail_touched': False, 'execution_authorized': False,
            'next': ('This package does not execute external ' + rail + ' payments. A real rail needs an owner-installed '
                     'provider implementing the SharedSettlementLedger interface and its own review before any host uses it.')}


def inspect(directory):
    """Key-free status of the builder and rail files; credential values are never read."""
    path = _directory(directory, create=False)
    result = {'format': 'covenant-owner-config-status/0.1', 'directory': str(path), 'builder': None, 'rails': [],
              'implemented_rails': [dict(row) for row in IMPLEMENTED], 'private_keys_in_output': False,
              'credential_values_read': False, 'payment_rail_touched': False, 'execution_authorized': False}
    try:
        document = _read(path, 'builder-owner.json')
        if document is None:
            result['builder'] = {'status': 'NOT_CONFIGURED'}
        else:
            load_builder_document(document)
            result['builder'] = {'status': 'LOADABLE', 'publishers': sorted(document['trusted_publishers']),
                                 'trusted_accounts': sorted(document['trusted_accounts']),
                                 'policies': len(document['economics_policies']),
                                 'applications_installed': 0,
                                 'note': 'Registries load with publisher trust only; install signed releases separately.'}
    except (NativeError, ValueError, TypeError, KeyError) as exc:
        result['builder'] = {'status': 'BLOCKED', 'code': _code(exc, 'BUILDER_CONFIG')}
    for rail in RAILS:
        try:
            document = _read(path, 'rail-' + rail + '.json')
            if document is None:
                continue
            need(set(document) == {'version', 'rail', 'network', 'credential_env', 'endpoint', 'provider_pin', 'status'}, 'RAIL_CONFIG')
            need(document == rail_document(document['rail'], document['network'], document['credential_env'],
                                           endpoint=document['endpoint'], provider_pin=document['provider_pin']) and
                 document['rail'] == rail, 'RAIL_CONFIG')
            result['rails'].append({'rail': rail, 'network': document['network'], 'status': 'DECLARED_NOT_EXECUTABLE',
                                    'credential_env': document['credential_env'],
                                    'credential_present': bool(os.environ.get(document['credential_env'])),
                                    'executable_in_this_package': False})
        except (NativeError, ValueError, TypeError, KeyError) as exc:
            result['rails'].append({'rail': rail, 'status': 'BLOCKED', 'code': _code(exc, 'RAIL_CONFIG')})
    return result


def _code(exc, fallback):
    if isinstance(exc, NativeError):
        return exc.code
    text = str(exc)
    return text if re.fullmatch(r'[A-Z][A-Z0-9_]{0,100}', text) else fallback


def _pair_args(values, code):
    pairs = {}
    for value in values or ():
        need(value.count('=') == 1, code)
        account, key = value.split('=')
        need(account not in pairs, code)
        pairs[account] = key
    return pairs


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_agent.owner_config',
        description='Write or inspect key-free owner setup for builder registries and declared external rails.')
    commands = parser.add_subparsers(dest='command', required=True)
    builder = commands.add_parser('builder', help='Write builder-owner.json with trusted publisher and account public keys.')
    builder.add_argument('--directory', required=True)
    builder.add_argument('--publisher', action='append', required=True, help='ACCOUNT_HEX=PUBLIC_KEY_HEX; repeatable.')
    builder.add_argument('--trusted-account', action='append', help='ACCOUNT_HEX=PUBLIC_KEY_HEX; repeatable.')
    railed = commands.add_parser('rail', help='Declare an external rail by network and credential variable name.')
    railed.add_argument('--directory', required=True)
    railed.add_argument('--rail', required=True, choices=RAILS)
    railed.add_argument('--network', required=True)
    railed.add_argument('--credential-env', required=True, help='Environment variable NAME only; never its value.')
    railed.add_argument('--endpoint')
    railed.add_argument('--provider-pin')
    looked = commands.add_parser('inspect', help='Print key-free builder and rail status.')
    looked.add_argument('--directory', required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'builder':
            result = write_builder(args.directory, _pair_args(args.publisher, 'BUILDER_PUBLISHERS'),
                                   _pair_args(args.trusted_account, 'BUILDER_TRUST'))
        elif args.command == 'rail':
            result = write_rail(args.directory, args.rail, args.network, args.credential_env,
                                endpoint=args.endpoint, provider_pin=args.provider_pin)
        else:
            result = inspect(args.directory)
    except (NativeError, ValueError, OSError) as exc:
        code = _code(exc, 'OWNER_CONFIG_FAILED')
        print(json.dumps({'error': code, **refusal(code, getattr(exc, 'remediation', None)),
                          'execution_authorized': False}), file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
