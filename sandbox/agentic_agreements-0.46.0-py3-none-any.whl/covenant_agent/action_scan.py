"""Find protocol actions by reading the implementation, not a second list.

Chain operations are the ``op`` names ``apply_transaction`` and the extension
modules dispatch. Language verbs are the Common Language kinds, domain event
operations, and maintenance kinds. Network verbs are the agent-network kinds.
The work-order verbs are the five names in ``envelope.VERBS``.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OP_EQ = re.compile(r"op\s*==\s*'([A-Z][A-Z0-9_]*)'")
OP_IN = re.compile(r"op\s*in\s*\{([^}]*)\}")
KIND_EQ = re.compile(r"kind['\"]?\]?\s*==\s*'([A-Z][A-Z0-9_]*)'")
EXACT_LITERAL = re.compile(r"exact\(\s*(?:p|payload)\s*,\s*'([^']+)'\s*\)")
NAME = re.compile(r"'([A-Z][A-Z0-9_]*)'")


def _names(blob):
    return NAME.findall(blob)


def chain_operations():
    """Every transaction op the chain source compares against."""
    found = {}
    for path in sorted((ROOT / 'covenant_chain').glob('*.py')):
        text = path.read_text()
        for match in OP_EQ.finditer(text):
            found.setdefault(match.group(1), path.name)
        for match in OP_IN.finditer(text):
            for name in _names(match.group(1)):
                found.setdefault(name, path.name)
    return found


def _ops_on(line):
    guarded = re.match(r'\s*(elif|if)\b', line) or re.search(r'need\(\s*op\s+in\s*\{', line)
    if not guarded:
        return set()
    ops = set(OP_EQ.findall(line))
    for blob in OP_IN.findall(line):
        ops.update(_names(blob))
    return ops


def chain_fields_from_source():
    """Required payload fields from the ``exact`` call that guards each op."""
    required = {}
    sources = {}
    for path in sorted((ROOT / 'covenant_chain').glob('*.py')):
        text = path.read_text()
        lines = text.splitlines()
        for name in OP_EQ.findall(text):
            sources.setdefault(name, path.name)
        for blob in OP_IN.findall(text):
            for name in _names(blob):
                sources.setdefault(name, path.name)
        starts = [(index, _ops_on(line)) for index, line in enumerate(lines) if _ops_on(line)]
        for position, (index, ops) in enumerate(starts):
            end = starts[position + 1][0] if position + 1 < len(starts) else min(len(lines), index + 16)
            window_lines = lines[index:end]
            # The first exact belongs to this test. A later exact belongs to a nested op.
            first_exact = next((n for n, row in enumerate(window_lines) if 'exact(' in row), None)
            if first_exact is not None:
                window_lines = window_lines[:first_exact + 1]
            assigned = _fields_in_window('\n'.join(window_lines), ops)
            for name, fields in assigned.items():
                if fields and name not in required:
                    required[name] = fields
        for match in re.finditer(r'^([A-Z][A-Z0-9_]*)\s*=\s*\{([^}]*)\}', text, re.M):
            members = _names(match.group(2))
            if not members:
                continue
            # A shared exact immediately after ``op in OPERATIONS``.
            for exact in EXACT_LITERAL.finditer(text):
                before = text[max(0, exact.start() - 180):exact.start()]
                if f'op in {match.group(1)}' not in before:
                    continue
                fields = exact.group(1).split()
                for name in members:
                    if name not in required:
                        required[name] = fields
    for name, source in chain_operations().items():
        required.setdefault(name, [])
        sources.setdefault(name, source)
    return required, sources


def _fields_in_window(window, ops):
    found = {}
    # Shared dict: fields={'OP':'a b','OP2':'c'}
    dict_match = re.search(r"fields\s*=\s*\{([^}]*)\}", window)
    per_op = {}
    if dict_match:
        for name, fields in re.findall(r"'([A-Z][A-Z0-9_]*)'\s*:\s*'([^']*)'", dict_match.group(1)):
            per_op[name] = fields.split()
    prefix = None
    joined = re.search(r"exact\(\s*p\s*,\s*'([^']*)'\s*\+\s*fields\[op\]\s*\)", window)
    if joined:
        prefix = joined.group(1).split()
    ternary = re.search(
        r"exact\(\s*p\s*,\s*'([^']+)'\s+if\s+op\s*==\s*'([A-Z][A-Z0-9_]*)'\s+else\s+'([^']+)'\s*\)",
        window)
    renew = re.search(
        r"(?:fields\s*=\s*)?'([^']+)'\s*\+\s*\(\s*'([^']*)'\s+if\s+op\.endswith\('([A-Z0-9_]*)'\)\s+else\s+'([^']*)'",
        window)
    endswith_exact = re.search(
        r"exact\(\s*p\s*,\s*'([^']+)'\s+if\s+op\.endswith\('([A-Z0-9_]*)'\)\s+else\s+'([^']+)'\s*\)",
        window)
    optional_extra = re.search(r"exact\(\s*p\s*,\s*'([^']+)'\s*\+\s*\(\s*'[^']+'\s+if\b", window)
    literals = EXACT_LITERAL.findall(window)
    for name in ops:
        if name in per_op or prefix:
            found[name] = prefix + per_op.get(name, []) if prefix else list(per_op.get(name, []))
            continue
        if ternary and name == ternary.group(2):
            found[name] = ternary.group(1).split()
            continue
        if ternary and name in ops and name != ternary.group(2) and len(ops) > 1:
            found[name] = ternary.group(3).split()
            continue
        if endswith_exact:
            found[name] = (endswith_exact.group(1) if name.endswith(endswith_exact.group(2)) else endswith_exact.group(3)).split()
            continue
        if renew:
            fields = renew.group(1).split()
            extra = renew.group(2) if name.endswith(renew.group(3)) else renew.group(4)
            found[name] = fields + extra.split()
            continue
        if optional_extra and len(ops) == 1:
            found[name] = optional_extra.group(1).split()
            continue
        if len(literals) == 1 and len(ops) == 1:
            found[name] = literals[0].split()
        elif len(literals) == 1 and len(ops) > 1 and not per_op and not ternary:
            found[name] = literals[0].split()
    return found


def language_kinds():
    from covenant_language.core import KINDS
    from covenant_language.domains import EVENT_OPS
    from covenant_language.maintenance import KINDS as MAINTENANCE
    sdk = (ROOT / 'covenant_language' / 'sdk.py').read_text()
    match = re.search(r"fields = \{\n(?P<body>.*?)\n    \}", sdk, re.S)
    body = match.group('body') if match else ''
    lang_fields = {}
    for name, fields in re.findall(r'"([A-Z]+)"\s*:\s*"([^"]+)"', body):
        lang_fields[name] = fields.split()
    return {
        'language': {name: lang_fields.get(name, []) for name in sorted(KINDS)},
        'domain': {name: [] for name in sorted(EVENT_OPS)},
        'maintenance': {name: [] for name in sorted(MAINTENANCE)},
    }


def network_kinds():
    from covenant_chain.agent_network import KINDS
    text = (ROOT / 'covenant_chain' / 'agent_network.py').read_text()
    fields = {}
    # kind=='NAME' ... exact(p,'fields') within the next 6 lines, plus PROPOSAL via validate_poll.
    lines = text.splitlines()
    hits = [(index, KIND_EQ.search(line).group(1)) for index, line in enumerate(lines) if KIND_EQ.search(line)]
    for position, (index, name) in enumerate(hits):
        end = hits[position + 1][0] if position + 1 < len(hits) else min(len(lines), index + 8)
        literals = EXACT_LITERAL.findall('\n'.join(lines[index:end]))
        if literals and name not in fields:
            fields[name] = literals[0].split()
    poll = (ROOT / 'covenant_chain' / 'voting.py').read_text()
    poll_fields = EXACT_LITERAL.search(poll)
    if poll_fields:
        fields['PROPOSAL'] = poll_fields.group(1).split()
    for name in KINDS:
        fields.setdefault(name, [])
    return fields


def agent_tool_schemas():
    from covenant_chain.agent_tools import TOOLS
    out = {}
    for tool in TOOLS:
        schema = tool['inputSchema']
        required = list(schema.get('required') or [])
        properties = list((schema.get('properties') or {}))
        optional = [name for name in properties if name not in required]
        out[tool['name']] = {
            'required': required,
            'optional': optional,
            'purpose': tool['description'].split('.')[0].rstrip() + '.',
        }
    # The four-tool front door stays discover/prepare/check/compare.
    # covenant_surface lives on the workflow host and still has a catalogue row.
    out['covenant_surface'] = {
        'required': ['action', 'parameters'],
        'optional': [],
        'purpose': 'Describe a module, adapter, crate, or host file.',
    }
    return out


def work_verbs():
    from .envelope import VERBS
    homes = {
        'make': 'verbs.py',
        'dispute': 'verbs.py',
        'decide': 'envelope.py',
        'light_verify': 'light.py',
    }
    extras = []
    for name, filename in homes.items():
        text = Path(__file__).with_name(filename).read_text()
        if re.search(rf'^def {name}\(', text, re.M):
            extras.append('covenant_' + name)
    return list(VERBS) + extras


def observed_actions():
    """Every protocol action the current source defines."""
    rows = []
    fields, sources = chain_fields_from_source()
    for name in sorted(fields):
        optional = ['resource_proof'] if name == 'BRIDGE_IMPORT' else []
        rows.append(_row('chain', name, fields[name], optional, f'covenant_chain/{sources[name]}'))
    families = language_kinds()
    for name, required in families['language'].items():
        nullable = [field for field in ('condition', 'authority', 'parent') if field in required]
        rows.append(_row('language', name, required, [], 'covenant_language/sdk.py', nullable=nullable))
    domain_required = ['domain', 'collection', 'author', 'key']
    domain_optional = ['payload', 'detached_commitment', 'predecessor', 'parents', 'evidence_refs', 'descriptions']
    for name in families['domain']:
        optional = list(domain_optional)
        required = list(domain_required)
        if name == 'TOMBSTONE':
            optional = [field for field in optional if field not in ('payload', 'detached_commitment')]
        rows.append(_row('domain', name, required, optional, 'covenant_language/domains.py'))
    maintenance = ['policy', 'target', 'signer', 'root', 'challenge', 'issued', 'expires', 'due_start', 'result', 'evidence']
    for name in families['maintenance']:
        rows.append(_row('maintenance', name, maintenance, [], 'covenant_language/maintenance.py'))
    for name, required in sorted(network_kinds().items()):
        rows.append(_row('network', name, required, [], 'covenant_chain/agent_network.py'))
    for name, schema in agent_tool_schemas().items():
        rows.append(_row('agent', name, schema['required'], schema['optional'], 'covenant_chain/agent_tools.py',
                         hint=schema['purpose']))
    work_fields = {
        'covenant_propose': (['counterparty', 'resolver', 'appeal_resolver', 'quantity', 'pay_to', 'deadline'],
                             ['document', 'task_hash', 'unit', 'rail', 'challenge_window', 'timeout', 'effect', 'network', 'executor',
                              'approval']),
        'covenant_accept': (['envelope'], ['approval']),
        'covenant_deliver': (['envelope'], ['content', 'content_base64']),
        'covenant_verify': ([], ['envelope', 'cid']),
        'covenant_settle': (['envelope'], ['decision', 'evidence_hash', 'rail', 'paid_amount']),
        'covenant_make': (['counterparty', 'resolver', 'appeal_resolver', 'quantity', 'pay_to', 'deadline'],
                          ['document', 'task_hash', 'unit', 'rail', 'challenge_window', 'timeout', 'effect', 'network', 'executor',
                           'approval']),
        'covenant_light_verify': (['cid'], []),
        'covenant_dispute': (['envelope', 'reason', 'evidence_hash'], []),
        'covenant_decide': (['envelope', 'result', 'evidence_hash'], ['paid_amount']),
    }
    for name in work_verbs():
        required, optional = work_fields[name]
        rows.append(_row('work', name, required, optional, 'covenant_agent/envelope.py'))
    rows.extend(exchange_actions())
    return rows


def _sentence(text):
    piece = text.split('.')[0].strip()
    if piece and not piece.endswith('.'):
        piece += '.'
    return piece[:400]


class _ListedNetwork:
    """Truth value only. tools() lists network actions without opening a replica."""


def exchange_actions():
    """Every action on the existing exchange-tool catalog, qualified as tool:.

    Network-gated tools such as covenant_reputation are part of that catalog.
    The sentinel is not a replica; it only makes tools() include their schemas.
    """
    from covenant_chain.agent_exchange_tools import ExchangeTools
    from covenant_chain.host_flags import DEFAULTS, HostPlugins
    rows = []
    # Catalogue optional schemas without adopting a mandate or supplying signing keys.
    plugins = HostPlugins({name: True for name in DEFAULTS})
    listed = ExchangeTools(network=_ListedNetwork(), plugins=plugins).tools()
    # Offline catalogue only: no owner desk or private journal is constructed.
    from covenant_chain.crawl_licensing_tools import spec as crawl_spec
    from covenant_chain.agent_exchange_tools import action_schema, _with_read
    name, description, readonly, actions = crawl_spec()
    listed.append({'name':name,'description':description,'inputSchema':action_schema(_with_read(actions))})
    for tool in listed:
        hint = _sentence(tool['description'])
        branches = tool['inputSchema'].get('oneOf') or []
        names = []
        for branch in branches:
            action = ((branch.get('properties') or {}).get('action') or {}).get('const')
            if action:
                names.append(action)
        if not names:
            rows.append(_row('tool', tool['name'], [], [], 'covenant_chain/agent_exchange_tools.py', hint=hint))
            continue
        for action in names:
            rows.append(_row('tool', tool['name'] + '.' + action, ['parameters'], [],
                             'covenant_chain/agent_exchange_tools.py', hint=hint))
    return rows


def _row(family, name, required, optional, source, nullable=(), hint=''):
    return {
        'id': f'{family}:{name}',
        'name': name,
        'family': family,
        'required': list(required),
        'optional': list(optional),
        'nullable': list(nullable),
        'source': source,
        'hint': hint,
    }
