"""x402 v2 ``exact`` payments on the simulated stablecoin ledger. Maturity: experimental.

Recourse stays first. PR 87's pay-with-recourse scheme (``covenant_x402``,
scheme ``covenant``: escrow, a named judge and appeal judge, RELEASE on
silence) is the default x402 rail. This module is an option for parties who
agreed a direct x402 v2 ``exact`` payment on the same ledger, with the
agreement hash attached. ``install`` registers it only when the host owner
turned the ``x402`` settlement flag on, and registers the recourse adapter
beside it.

Wire shapes follow the x402 v2 specification. PaymentRequired carries
``x402Version``, ``resource``, ``accepts`` and ``extensions``. Each
PaymentRequirements carries ``scheme``, ``network``, ``amount``, ``asset``,
``payTo``, ``maxTimeoutSeconds`` and ``extra``. PaymentPayload carries
``x402Version``, ``resource``, ``accepted``, ``payload`` and ``extensions``.
SettleResponse carries ``success``, ``payer``, ``transaction``, ``network`` and
``amount``. Over HTTP each travels as base64 JSON in the PAYMENT-REQUIRED,
PAYMENT-SIGNATURE and PAYMENT-RESPONSE headers.

``extensions.legalContext`` uses the v2 extension shape ``{info, schema}``.
``info.atrHash`` is the agreement hash: SHA-256 of the exact agreement-terms
bytes (``atr_hash``). It is an AAP extension, not a published x402 one, and a
facilitator that does not know it ignores it.

The scheme ``payload`` is a COVENANT-X402-V2-PAYMENT-0.1 Ed25519 signature by
the payer over the accepted requirements, the agreement hash and an
EIP-3009-shaped ``authorization`` (from, to, value, validAfter, validBefore,
nonce). ``settle`` checks the hash, the exact terms, the time window, that
signature and the nonce before any balance moves. Escrow is optional: with
``extra.escrow`` true the payment passes through an escrow row on the same
ledger, held and paid in one step; it is not a dispute window. Nothing here
reaches a chain, a facilitator or a bank.
"""
import base64
import binascii
import secrets
from copy import deepcopy

from .codec import HEX, canonical, digest, loads, public_key, sha256_hex, sign, verify
from .errors import NativeError, need
from .settlement import (DEFAULT_X402_NETWORK, RAIL_VERSION, STABLECOINS, X402Adapter, register_on,
                         require_stablecoin)

X402_VERSION = 2
SCHEME = 'exact'
LABEL = 'COVENANT-X402-V2-PAYMENT-0.1'
REQUEST_LABEL = 'COVENANT-X402-V2-REQUEST-0.1'
LEGAL_CONTEXT = 'legalContext'
ATR_HASH = 'atrHash'
MAX_ATR_BYTES = 262144
MAX_HEADER = 16384
MAX_TIMEOUT = 86400
DEFAULT_TIMEOUT = 600
MAX_INTEGER = 2**53 - 1
REQUIREMENT_FIELDS = frozenset({'scheme', 'network', 'amount', 'asset', 'payTo', 'maxTimeoutSeconds'})
AUTHORIZATION_FIELDS = frozenset({'from', 'to', 'value', 'validAfter', 'validBefore', 'nonce'})
PAYMENT_FIELDS = frozenset({'x402Version', 'accepted', 'payload', 'extensions'})
_ATR_SCHEMA = {'type': 'object', 'properties': {ATR_HASH: {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}},
               'required': [ATR_HASH], 'additionalProperties': False}


def atr_hash(raw):
    """SHA-256 hex of the exact agreement-terms bytes. The same rule as an LCP atrHash."""
    need(isinstance(raw, (bytes, bytearray)) and 0 < len(raw) <= MAX_ATR_BYTES, 'X402_ATR_BYTES')
    return sha256_hex(raw)


def _hex(value, code):
    need(type(value) is str and HEX.fullmatch(value) is not None, code)
    return value


def legal_context(atr):
    """The ``extensions`` map entry in the v2 ``{info, schema}`` shape."""
    return {LEGAL_CONTEXT: {'info': {ATR_HASH: _hex(atr, 'X402_ATR')}, 'schema': deepcopy(_ATR_SCHEMA)}}


def challenge(atr, *, pay_to, amount, unit, network=DEFAULT_X402_NETWORK, escrow=False, resource=None,
              timeout=DEFAULT_TIMEOUT):
    """PaymentRequired for one exact payment bound to agreement hash ``atr``."""
    require_stablecoin(unit)
    _hex(atr, 'X402_ATR')
    need(type(pay_to) is str and 1 <= len(pay_to) <= 256, 'PAY_TO')
    need(type(amount) is int and 0 < amount <= MAX_INTEGER, 'QUANTITY')
    need(type(network) is str and 1 <= len(network) <= 80, 'NETWORK')
    need(type(escrow) is bool, 'ARGUMENTS')
    need(type(timeout) is int and 1 <= timeout <= MAX_TIMEOUT, 'X402_TIMEOUT')
    resource = 'urn:covenant:' + atr if resource is None else resource
    need(type(resource) is str and 1 <= len(resource) <= 200, 'FIELDS')
    body = {
        'x402Version': X402_VERSION,
        'resource': {'url': resource, 'description': 'AAP agreement payment', 'mimeType': 'application/json'},
        'accepts': [{
            'scheme': SCHEME,
            'network': network,
            'amount': str(amount),
            'asset': unit,
            'payTo': pay_to,
            'maxTimeoutSeconds': timeout,
            'extra': {
                'escrow': escrow,
                'assurance': 'COVENANT_BINDING_NOT_A_CHAIN_PAYMENT',
                'recourse': 'NONE_IN_EXACT_USE_SCHEME_covenant_FOR_JUDGE_APPEAL_AND_RELEASE',
            },
        }],
        'extensions': legal_context(atr),
    }
    canonical(body)
    return body


def _bound_atr(document):
    """``extensions.legalContext.info.atrHash`` and nothing else in that entry."""
    extensions = document.get('extensions') if type(document) is dict else None
    entry = extensions.get(LEGAL_CONTEXT) if type(extensions) is dict else None
    need(type(entry) is dict and 'info' in entry and set(entry) <= {'info', 'schema'}, 'X402_ATR_MISMATCH')
    info = entry['info']
    need(type(info) is dict and set(info) == {ATR_HASH}, 'X402_ATR_MISMATCH')
    return _hex(info[ATR_HASH], 'X402_ATR_MISMATCH')


def _requirements(accepted):
    """One exact PaymentRequirements: (amount, unit, payTo, escrow)."""
    need(type(accepted) is dict and accepted.get('scheme') == SCHEME, 'X402_ATR_MISMATCH')
    need(REQUIREMENT_FIELDS <= set(accepted) <= REQUIREMENT_FIELDS | {'extra'}, 'X402_TERMS')
    amount = accepted['amount']
    need(type(amount) is str and 1 <= len(amount) <= 16 and amount.isascii() and amount.isdigit()
         and amount == str(int(amount)) and 0 < int(amount) <= MAX_INTEGER, 'X402_TERMS')
    require_stablecoin(accepted['asset'])
    need(type(accepted['payTo']) is str and 1 <= len(accepted['payTo']) <= 256, 'X402_TERMS')
    need(type(accepted['network']) is str and 1 <= len(accepted['network']) <= 80, 'X402_TERMS')
    need(type(accepted['maxTimeoutSeconds']) is int and 1 <= accepted['maxTimeoutSeconds'] <= MAX_TIMEOUT,
         'X402_TIMEOUT')
    extra = accepted.get('extra', {})
    need(type(extra) is dict and type(extra.get('escrow', False)) is bool, 'X402_TERMS')
    return int(amount), accepted['asset'], accepted['payTo'], extra.get('escrow', False)


def _offered(body):
    """The offered requirements and agreement hash of a v2 exact PaymentRequired."""
    need(type(body) is dict and body.get('x402Version') == X402_VERSION, 'X402_ATR_MISMATCH')
    accepts = body.get('accepts')
    need(type(accepts) is list and 1 <= len(accepts) <= 8, 'X402_TERMS')
    for accepted in accepts:
        _requirements(accepted)
    return accepts, _bound_atr(body)


def _authorization(authorization):
    need(type(authorization) is dict and set(authorization) == AUTHORIZATION_FIELDS, 'X402_AUTHORIZATION')
    _hex(authorization['from'], 'X402_AUTHORIZATION')
    _hex(authorization['nonce'], 'X402_AUTHORIZATION')
    after, before = authorization['validAfter'], authorization['validBefore']
    need(type(after) is int and type(before) is int and 0 <= after < before <= MAX_INTEGER, 'X402_AUTHORIZATION')
    need(type(authorization['to']) is str and type(authorization['value']) is str, 'X402_AUTHORIZATION')
    return authorization


def _signed(payment):
    """What the payer signs: the whole PaymentPayload except the signature itself."""
    return {'x402Version': payment['x402Version'], 'resource': payment.get('resource'),
            'accepted': payment['accepted'], 'authorization': payment['payload']['authorization'],
            'extensions': payment['extensions']}


def pay(body, payer, *, valid_after, valid_before, nonce=None, index=0):
    """PaymentPayload for ``accepts[index]``, signed by the payer's key. Nothing moves here."""
    accepts, atr = _offered(body)
    need(type(index) is int and 0 <= index < len(accepts), 'X402_TERMS')
    accepted = deepcopy(accepts[index])
    authorization = _authorization({
        'from': public_key(payer), 'to': accepted['payTo'], 'value': accepted['amount'],
        'validAfter': valid_after, 'validBefore': valid_before,
        'nonce': secrets.token_hex(32) if nonce is None else nonce,
    })
    payment = {'x402Version': X402_VERSION, 'resource': deepcopy(body.get('resource')), 'accepted': accepted,
               'payload': {'authorization': authorization}, 'extensions': legal_context(atr)}
    payment['payload']['signature'] = sign(payer, LABEL, _signed(payment))
    canonical(payment)
    return payment


def _spent(ledger, payer, nonce):
    return any(type(row) is dict and row.get('label') == LABEL and row.get('payer') == payer
               and row.get('nonce') == nonce for row in ledger.receipts.values())


def settle(ledger, effect_id, request):
    """Pay one signed exact payment on the shared ledger.

    ``request`` is ``{atr, challenge, payment, as_of}``. ``atr`` is the agreement
    hash the payee expects and ``as_of`` the caller's asserted time. Every check
    runs before a balance moves. Repeating the same request returns the recorded
    receipt and moves nothing.
    """
    need(type(request) is dict and set(request) == {'atr', 'challenge', 'payment', 'as_of'}, 'ARGUMENTS')
    need(type(effect_id) is str and 1 <= len(effect_id) <= 128, 'ARGUMENTS')
    atr = _hex(request['atr'], 'X402_ATR')
    request_hash = digest(REQUEST_LABEL, {name: request[name] for name in ('atr', 'challenge', 'payment')})
    prior = ledger.receipts.get(effect_id)
    if prior is not None:
        need(prior.get('request_hash') == request_hash, 'SETTLEMENT_CONFLICT')
        return deepcopy(prior)
    offered, challenge_atr = _offered(request['challenge'])
    payment = request['payment']
    need(type(payment) is dict and PAYMENT_FIELDS <= set(payment) <= PAYMENT_FIELDS | {'resource'}, 'X402_TERMS')
    need(payment['x402Version'] == X402_VERSION, 'X402_ATR_MISMATCH')
    need(challenge_atr == atr and _bound_atr(payment) == atr, 'X402_ATR_MISMATCH')
    accepted = payment['accepted']
    amount, unit, payee, escrow = _requirements(accepted)
    need(any(canonical(accepted) == canonical(offer) for offer in offered), 'X402_TERMS')
    need('resource' not in payment or payment['resource'] == request['challenge'].get('resource'), 'X402_TERMS')
    signed = payment['payload']
    need(type(signed) is dict and set(signed) == {'authorization', 'signature'}, 'X402_AUTHORIZATION')
    authorization = _authorization(signed['authorization'])
    need(authorization['to'] == payee and authorization['value'] == accepted['amount'], 'X402_TERMS')
    as_of = request['as_of']
    need(type(as_of) is int and authorization['validAfter'] <= as_of < authorization['validBefore'],
         'X402_AUTHORIZATION_WINDOW')
    payer = authorization['from']
    verify(payer, LABEL, _signed(payment), signed['signature'])
    need(not _spent(ledger, payer, authorization['nonce']), 'X402_REPLAY')
    # An escrow row under this id belongs to another payment. Never pay it out here.
    need(effect_id not in ledger.escrow, 'ESCROW_CONFLICT')
    if escrow:
        ledger.move_to_escrow(effect_id, payer, unit, amount)
        moved = ledger.pay(effect_id, payee)
    else:
        moved = ledger.transfer(payer, payee, unit, amount)
    receipt = {
        'x402Version': X402_VERSION,
        'scheme': SCHEME,
        'label': LABEL,
        'success': True,
        'payer': payer,
        'transaction': '',
        'network': accepted['network'],
        'amount': accepted['amount'],
        ATR_HASH: atr,
        'status': 'PAID',
        'escrow': escrow,
        'unit': unit,
        'payee': payee,
        'nonce': authorization['nonce'],
        'request_hash': request_hash,
        'moved': moved['status'],
        'fee_accountant': 'covenant_chain.economics',
        'protocol_fee': 0,
        'external_verification': 'NOT_PERFORMED',
        'assurance': 'SIMULATED_STABLECOIN_LEDGER_NOT_A_CHAIN_PAYMENT',
        'execution_authorized': False,
    }
    return ledger.remember(effect_id, receipt)


def settle_response(receipt):
    """The SettleResponse for PAYMENT-RESPONSE. ``transaction`` is empty: no chain was touched."""
    need(type(receipt) is dict and receipt.get('label') == LABEL, 'ARGUMENTS')
    return {'success': receipt['success'], 'payer': receipt['payer'], 'transaction': receipt['transaction'],
            'network': receipt['network'], 'amount': receipt['amount'],
            'extensions': legal_context(receipt[ATR_HASH])}


def encode_header(value):
    """Base64 of the canonical JSON, as the v2 HTTP headers carry it."""
    need(type(value) is dict, 'X402_HEADER')
    text = base64.b64encode(canonical(value)).decode('ascii')
    need(len(text) <= MAX_HEADER, 'X402_HEADER')
    return text


def decode_header(text):
    """One bounded base64 JSON object. Duplicate keys, floats and oversize values are refused."""
    need(type(text) is str and 0 < len(text) <= MAX_HEADER and text.isascii(), 'X402_HEADER')
    try:
        raw = base64.b64decode(text, validate=True)
        value = loads(raw)
    except (binascii.Error, ValueError):
        raise NativeError('X402_HEADER') from None
    need(type(value) is dict, 'X402_HEADER')
    return value


class X402ExactRail:
    """x402 v2 exact rail on RailRegistry. An option beside the recourse X402Adapter, never the default."""

    def __init__(self, ledger, directory_label='local'):
        need(type(directory_label) is str and 1 <= len(directory_label) <= 80, 'ARGUMENTS')
        self.ledger = ledger
        self.manifest = {
            'version': RAIL_VERSION,
            'rail': 'x402',
            'x402Version': X402_VERSION,
            'scheme': SCHEME,
            'unit_kind': 'STABLECOIN',
            'native_token': False,
            'assets': sorted(STABLECOINS),
            'instance': directory_label,
            'external_broadcast': False,
            'escrow': 'OPTIONAL',
            'payer_signature': LABEL,
            'legal_context': 'extensions.legalContext.info.atrHash',
            'default_rail': False,
            'default_scheme': 'covenant',
            'maturity': 'experimental',
            'fee_schedule': 'DEFERRED_TO_ECONOMICS_MODULE',
            'fee_accountant': 'covenant_chain.economics',
            'protocol_fee': 0,
            'actions': ['CHALLENGE', 'SETTLE'],
            'assurance': 'SIMULATED_STABLECOIN_LEDGER_NOT_CUSTODY_NOT_A_BANK',
        }
        canonical(self.manifest)

    def execute(self, effect_id, request):
        need(type(request) is dict and request.get('action') in ('CHALLENGE', 'SETTLE'), 'ARGUMENTS')
        fields = {name: value for name, value in request.items() if name != 'action'}
        if request['action'] == 'CHALLENGE':
            need({'atr', 'pay_to', 'amount', 'unit'} <= set(fields)
                 <= {'atr', 'pay_to', 'amount', 'unit', 'network', 'escrow', 'resource', 'timeout'}, 'ARGUMENTS')
            body = challenge(fields.pop('atr'), **fields)
            return {'status': 'CHALLENGE', 'body': body, 'header': encode_header(body),
                    'default_scheme': 'covenant', 'execution_authorized': False}
        settle(self.ledger, effect_id, fields)
        return self.observe(effect_id)

    def observe(self, effect_id):
        return self.ledger.observe(effect_id)


def install(registry, ledger, flags=None, *, directory_label='local'):
    """Owner installation behind the ``x402`` flag: recourse stays the default, exact v2 sits beside it."""
    if flags is None:
        raise NativeError('PLUGIN_DISABLED')
    flags.require('x402')
    recourse = X402Adapter(ledger, directory_label=directory_label)
    exact = X402ExactRail(ledger, directory_label=directory_label)
    return {
        'recourse': register_on(registry, recourse),
        'exact': register_on(registry, exact),
        'default_scheme': 'covenant',
        'ledger': 'SHARED_STABLECOIN_LEDGER',
        'escrow': 'OPTIONAL',
        'execution_authorized': False,
    }
