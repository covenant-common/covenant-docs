"""Explicit /0.3 open-rail work orders. No historical profile is reinterpreted.

Signatures bind instructions, not the truth or performance of an external rail.
Owner Python callbacks are installed authority; supplied JSON cannot install one.
"""
from copy import deepcopy
import re

from .codec import canonical, digest, exact, public_key, sign, verify as verify_signature
from .errors import need

PROFILE = 'covenant-bilateral/0.3'
TERMS = 'covenant-work-order/0.3'
LABEL = 'COVENANT-OPEN-WORK-0.3'


def _text(value, maximum=256):
    need(type(value) is str and 0 < len(value) <= maximum, 'OPEN_WORK_TEXT')
    canonical(value)


def _hash(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'OPEN_WORK_HASH')


def _key(value):
    from .codec import valid_ed25519_key
    need(valid_ed25519_key(value), 'OPEN_WORK_KEY')


def _int(value):
    need(type(value) is int and 0 <= value <= 2**53-1, 'OPEN_WORK_INTEGER')


def rail(identifier, network, asset, unit, payee, adapter=None, instructions=None):
    """A named payment mechanism, including none/manual/future owner adapters."""
    for value in (identifier, network, asset, unit, payee):
        _text(value)
    need(identifier.startswith(('urn:', 'https:')) or identifier in ('NONE', 'MANUAL'), 'OPEN_WORK_RAIL')
    if adapter is not None:
        _hash(adapter)
    canonical(instructions)
    return {'identifier': identifier, 'network': network, 'asset': asset, 'unit': unit,
            'payee': payee, 'adapter': adapter, 'instructions': deepcopy(instructions)}


def draft(task, customer, provider, quantity, payment, nonce, deadline, *, context=None):
    _text(task, 16000); _key(customer); _key(provider); _int(quantity); _int(deadline); _hash(nonce)
    need(customer != provider, 'OPEN_WORK_DISTINCT_PARTIES')
    exact(payment, 'identifier network asset unit payee adapter instructions')
    need(canonical(rail(**payment)) == canonical(payment), 'OPEN_WORK_RAIL')
    body = {'profile': PROFILE, 'terms': {'version': TERMS, 'task': task, 'quantity': quantity,
            'payment': deepcopy(payment), 'nonce': nonce, 'deadline': deadline,
            'clock': 'OWNER_ADOPTED_UNIX_SECONDS', 'context': deepcopy(context)},
            'customer': customer, 'provider': provider}
    ref = digest(LABEL, body)
    return {'body': body, 'id': ref, 'assents': [], 'events': [],
            'execution_authorized': False, 'funds_reserved': False}


def _validate(order, expected_id):
    exact(order, 'body id assents events execution_authorized funds_reserved')
    body = order['body']; exact(body, 'profile terms customer provider')
    terms = body['terms']; exact(terms, 'version task quantity payment nonce deadline clock context')
    rebuilt = draft(terms['task'], body['customer'], body['provider'], terms['quantity'],
                    terms['payment'], terms['nonce'], terms['deadline'], context=terms['context'])
    need(canonical(body) == canonical(rebuilt['body']) and order['id'] == rebuilt['id'] == expected_id,
         'OPEN_WORK_CHANGED')
    need(order['execution_authorized'] is False and order['funds_reserved'] is False, 'OPEN_WORK_CLAIMS')
    need(type(order['assents']) is list and len(order['assents']) <= 2 and
         type(order['events']) is list and len(order['events']) <= 128, 'OPEN_WORK_RECORDS')


def inspect(order, expected_id):
    _validate(order, expected_id)
    approved = set()
    for assent in order['assents']:
        exact(assent, 'signer signature')
        need(assent['signer'] in (order['body']['customer'], order['body']['provider']) and
             assent['signer'] not in approved, 'OPEN_WORK_ASSENT')
        verify_signature(assent['signer'], LABEL+'-ASSENT', {'agreement': expected_id}, assent['signature'])
        approved.add(assent['signer'])
    prior = expected_id; last = 0
    for event in order['events']:
        need(len(approved) == 2, 'OPEN_WORK_NOT_BOUND')
        exact(event, 'body signer signature')
        value = event['body']; exact(value, 'agreement previous action evidence at')
        need(value['agreement'] == expected_id and value['previous'] == prior, 'OPEN_WORK_EVENT_CHAIN')
        _int(value['at']); need(value['at'] >= last, 'OPEN_WORK_CLOCK_ORDER'); last = value['at']
        need(value['action'] in ('DELIVERY_CLAIM', 'PAYMENT_CLAIM', 'DISPUTE', 'RECEIPT'), 'OPEN_WORK_ACTION')
        expected = order['body']['provider'] if value['action'] == 'DELIVERY_CLAIM' else order['body']['customer']
        need(event['signer'] in (order['body']['customer'], order['body']['provider']) and
             (value['action'] in ('DISPUTE', 'RECEIPT') or event['signer'] == expected), 'OPEN_WORK_EVENT_AUTHORITY')
        _hash(value['evidence'])
        verify_signature(event['signer'], LABEL+'-EVENT', value, event['signature'])
        prior = digest(LABEL+'-EVENT', event)
    return {'id': expected_id, 'status': 'BOUND' if len(approved) == 2 else 'PROPOSED',
            'head': prior, 'approved': sorted(approved), 'events': len(order['events']),
            'payment_verified': False, 'delivery_verified': False, 'funds_reserved': False,
            'execution_authorized': False, 'chain_required': False}


def assent(order, signer, expected_id):
    info = inspect(order, expected_id); who = public_key(signer)
    need(who in (order['body']['customer'], order['body']['provider']) and who not in info['approved'], 'OPEN_WORK_ASSENT')
    out = deepcopy(order)
    out['assents'].append({'signer': who, 'signature': sign(signer, LABEL+'-ASSENT', {'agreement': expected_id})})
    inspect(out, expected_id)
    return out


def event(order, signer, action, evidence, at, expected_id):
    info = inspect(order, expected_id); need(info['status'] == 'BOUND', 'OPEN_WORK_NOT_BOUND')
    out = deepcopy(order)
    value = {'agreement': expected_id, 'previous': info['head'], 'action': action, 'evidence': evidence, 'at': at}
    out['events'].append({'body': value, 'signer': public_key(signer), 'signature': sign(signer, LABEL+'-EVENT', value)})
    inspect(out, expected_id)
    return out


def payment_link(order, expected_id, mechanism, external_body):
    """Bind an exact AP2/x402/other proposed leg; does not sign that protocol."""
    info = inspect(order, expected_id)
    need(info['status'] == 'BOUND', 'OPEN_WORK_NOT_BOUND'); _text(mechanism)
    return {'profile': 'covenant-payment-leg-link/0.1', 'agreement': expected_id,
            'mechanism': mechanism, 'external_body_hash': digest(LABEL+'-PAYMENT-BODY', external_body),
            'quantity': order['body']['terms']['quantity'],
            'payment': deepcopy(order['body']['terms']['payment']), 'payment_verified': False,
            'external_mandate_authorized': False, 'execution_authorized': False}


def observe_payment(order, expected_id, evidence, *, owner_observer):
    """Explicit owner callback must attest the complete agreement-bound payment."""
    inspect(order, expected_id); need(callable(owner_observer), 'OPEN_WORK_OBSERVER')
    terms = order['body']['terms']
    expected = {'agreement': expected_id, 'payment': deepcopy(terms['payment']), 'quantity': terms['quantity']}
    result = owner_observer(deepcopy(expected), deepcopy(evidence))
    need(type(result) is dict and canonical(result.get('payment')) == canonical(expected)
         and result.get('status') in ('OBSERVED', 'UNKNOWN', 'NOT_OBSERVED'), 'OPEN_WORK_OBSERVATION')
    return {'agreement': expected_id, 'status': result['status'], 'observation': deepcopy(result),
            'assurance': 'OWNER_INSTALLED_OBSERVER_ONLY', 'execution_authorized': False}
