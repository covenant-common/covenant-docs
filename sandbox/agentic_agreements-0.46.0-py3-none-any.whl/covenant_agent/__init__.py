"""Agent-native Covenant work orders.

Five verbs sit on top of the existing agent actions: propose, accept, deliver,
verify and settle. make() is the one-call proposer primitive. light_verify()
checks a content id from local bytes. Settlement adapters speak x402 and AP2
in stablecoins. The chain is used only when a dispute builds an anchor.
"""
from .envelope import VERSION
from .interop import (agent_card, erc8004_pointer, erc8004_pointer_bound, erc8004_validation, langchain_tool_specs,
                      offer_task, openai_function_tools)
from .kits import framework_kits, spend_guard
from .biomimicry import adoption
from .evidence import check as check_evidence
from .evidence import pin as pin_evidence
from .score import covenant_score, erc8004_reputation, score_credential, verify_score
from .mcp import Host
from .settlement import AP2Adapter, StablecoinLedger, X402Adapter
from .store import ContentStore
from .drafting import accept_draft, compose, counter, draft, library, lint, simulate, template
from .feedback import feedback_report
from .navigate import covenant, explain, find, next_actions
from .verbs import (
    accept, advanced, decide, deliver, discover, dispute, light_verify, make, once, propose, settle, verify,
)

__all__ = [
    'VERSION', 'Host', 'ContentStore', 'StablecoinLedger', 'X402Adapter', 'AP2Adapter',
    'discover', 'make', 'propose', 'accept', 'deliver', 'verify', 'settle', 'once',
    'light_verify', 'dispute', 'decide', 'advanced',
    'agent_card', 'erc8004_validation', 'erc8004_pointer', 'erc8004_pointer_bound',
    'openai_function_tools', 'langchain_tool_specs',
    'framework_kits', 'spend_guard', 'offer_task',
    'covenant_score', 'verify_score', 'erc8004_reputation', 'score_credential', 'adoption',
    'check_evidence', 'pin_evidence',
    'covenant', 'find', 'explain', 'next_actions',
    'library', 'template', 'draft', 'lint', 'simulate', 'counter', 'accept_draft', 'compose',
    'feedback_report',
]
