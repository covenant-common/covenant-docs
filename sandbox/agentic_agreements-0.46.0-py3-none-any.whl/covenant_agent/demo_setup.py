"""Owner-invoked local reference setup; every balance and actor is synthetic.

Creates a new private directory, four separate one-key host configurations and
one funded SQLite reference authority. It is never called by an agent tool.
The owner of this test directory can read all four test keys. Real parties
must install their own custody and independently adopt their payment provider.
"""
import argparse
import json
import os
from pathlib import Path
import secrets
import sys

from covenant_language.safe_io import atomic_write

from .codec import key_from_seed, public_key
from .errors import NativeError, need, refusal
from .mcp import HOST_VERSION
from .settlement_ledger_v2 import SharedSettlementLedger

ROLES = ('buyer', 'seller', 'resolver', 'appeal')


def _private_json(directory_fd, name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode('utf-8')
    atomic_write(name, raw, mode=0o600, exclusive=True, dir_fd=directory_fd)
    os.chmod(name, 0o600, dir_fd=directory_fd)


def create(directory, *, balance=1000, clock_time=None):
    """Explicit synthetic-owner setup, never enrollment or production funding."""
    need(type(directory) in (str, Path) or isinstance(directory, Path), 'DEMO_DIRECTORY')
    need(type(balance) is int and 1 <= balance <= 2**53 - 1, 'DEMO_BALANCE')
    need(clock_time is None or (type(clock_time) is int and 0 <= clock_time <= 2**53 - 1),
         'DEMO_CLOCK')
    given = Path(directory).expanduser()
    need(str(directory) and given.name not in ('', '.', '..'), 'DEMO_DIRECTORY')
    target = given.parent.resolve(strict=True) / given.name
    try:
        target.mkdir(mode=0o700)
    except FileExistsError:
        raise NativeError('DEMO_DIRECTORY_EXISTS') from None
    directory_fd = os.open(target, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fchmod(directory_fd, 0o700)
        info = os.fstat(directory_fd)
        need(info.st_uid == os.getuid() and info.st_mode & 0o077 == 0, 'DEMO_DIRECTORY')
        seeds = {role: secrets.token_hex(32) for role in ROLES}
        identities = {role: public_key(key_from_seed(seed)) for role, seed in seeds.items()}
        need(len(set(identities.values())) == len(ROLES), 'DEMO_IDENTITIES')
        balances = {identities['buyer']: {'USDC': balance}, identities['seller']: {'USDC': 0}}
        ledger_path = target / 'reference.sqlite'
        ledger = SharedSettlementLedger(ledger_path, balances)
        hosts = {}
        for role in ROLES:
            config = {'version': HOST_VERSION, 'seed': seeds[role], 'sandbox': True,
                      'work_order_profile': 'covenant-bilateral/0.2',
                      'settlement_db': str(ledger_path)}
            if clock_time is not None:
                config['clock_time'] = clock_time
            filename = role + '.json'
            _private_json(directory_fd, filename, config)
            hosts[role] = {'identity': identities[role], 'config_path': str(target / filename),
                'command': sys.executable, 'args': ['-m', 'covenant_agent.server', '--config', str(target / filename)]}
        result = {'format': 'covenant-reference-demo/0.1', 'synthetic_only': True,
            'profile': 'covenant-bilateral/0.2', 'directory': str(target),
            'hosts': hosts, 'settlement_authority': ledger.instance,
            'opening_balance': {'actor': 'buyer', 'amount': balance, 'unit': 'USDC', 'real_money': False},
            'clock': {'mode': 'REAL_LOCAL_TIME' if clock_time is None else 'SANDBOX_FIXED', 'at': clock_time},
            'private_keys_in_output': False, 'agreement_signed': False,
            'provider': 'SINGLE_LOCAL_SQLITE_REFERENCE_AUTHORITY',
            'custody': 'UNENCRYPTED_OWNER_PRIVATE_TEST_FILES; OWNER_CONTROLS_ALL_TEST_ACTORS',
            'next': 'Launch each selected host separately; discover its exact tool schema before make, accept, deliver and settle. Preserve original envelopes on retries.'}
        # Publish the key-free manifest only when every private config exists.
        _private_json(directory_fd, 'manifest.json', result)
        os.fsync(directory_fd)
        return result
    finally:
        os.close(directory_fd)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Create or read-only inspect an owner-private synthetic /0.2 work-order demo. Never production keys or money.')
    parser.add_argument('--directory', required=True, help='New directory for creation, existing directory for --inspect. Existing paths are never overwritten.')
    parser.add_argument('--inspect', action='store_true', help='Read-only setup snapshot after restart; print only key-free status. Does not launch hosts or check payment.')
    parser.add_argument('--expected-authority', help='Optional separately retained 64-character authority pin; valid only with --inspect.')
    parser.add_argument('--balance', type=int, help='Synthetic opening USDC-labelled units (default 1000), not actual USDC. Creation only.')
    parser.add_argument('--clock-time', type=int, help='Optional fixed sandbox clock; omitted uses local time.')
    args = parser.parse_args(argv)
    if args.inspect:
        if args.balance is not None or args.clock_time is not None:
            parser.error('--balance and --clock-time are creation-only options')
        from .owner_setup import inspect_demo
        result = inspect_demo(args.directory, expected_authority=args.expected_authority)
        print(json.dumps(result, sort_keys=True))
        return 0 if result['status'] == 'READY_FOR_SYNTHETIC_HOST_LAUNCH' else 1
    if args.expected_authority is not None:
        parser.error('--expected-authority requires --inspect')
    try:
        result = create(args.directory, balance=1000 if args.balance is None else args.balance,
                        clock_time=args.clock_time)
    except (NativeError, ValueError, OSError) as exc:
        code = exc.code if isinstance(exc, NativeError) else 'DEMO_SETUP_FAILED'
        print(json.dumps({'error': code, **refusal(code, getattr(exc, 'remediation', None)), 'synthetic_only': True,
            'next': 'Use a new directory under an existing trusted parent; retain any partial private files for owner inspection.'}), file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
