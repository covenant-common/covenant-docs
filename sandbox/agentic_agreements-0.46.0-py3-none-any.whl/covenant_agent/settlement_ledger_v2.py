"""Owner-adopted, persistent reference settlement; synthetic balances only.

Independent clients can observe the same atomic receipt without trusting a
receipt supplied by their counterparty. This is one local SQLite authority,
not bank money, a public blockchain, a portable payment proof or a connector
installed by agreement text. A different provider must implement this interface
and be independently installed by the owner.

Private SQLite storage keeps each agreement history independently bounded;
network canonical-byte limits still apply to each signed message. Existing
single-blob databases migrate atomically on opening. Stop old provider binaries
before upgrading: the migrated marker deliberately makes their reads fail closed
instead of letting them operate an obsolete second balance snapshot.

Time authority. Every party signs its own claimed ``at`` from its own host
clock, so a signed time is a claim, not a fact. By default this authority
judges every new settlement against its own owner-installed clock (``clock``;
the default is the operating-system clock of the process that opens the
database). It refuses a receipt whose claimed time is ahead of that clock
(SETTLEMENT_CLOCK_AHEAD), a primary decision settled before its appeal window
closed by authority time (APPEAL_WINDOW_OPEN) and a silent refund before the
deadline by authority time (SILENCE_NOT_DUE). The clock is owner configuration
of the provider, never a tool argument or a party's host clock: every process
that opens the same database must run under the same owner-administered clock.

Time evidence (opt-in). An owner may instead install a covenant-time-evidence/0.1
policy when initializing a new authority (``time_policy``). It then replaces
the clock: a new silent refund needs evidence that the deadline has passed, and
a primary decision without an appeal needs evidence that its window has closed;
NOT_YET refuses with the same codes and UNDETERMINED or UNKNOWN with
TIME_UNDETERMINED. Only lower bounds decide acceptance, and those need no
freshness, so a party who supplies old or selected evidence can only cause
refusals. The policy is stored with the records, so every opener applies it.

Either way, an exact retry of an already stored receipt is history and is not
re-judged. A resolver can still back-date or post-date its own signed decision
time; that remains a resolver-trust assumption, as does any record that is not
registered here.

Storage formats. covenant-reference-settlement-sqlite/0.2 has no optional
feature and keeps its exact meaning. A store with any optional feature is
covenant-reference-settlement-sqlite/0.4: its metadata lists ``features`` and
carries one member per listed feature, so an older binary refuses it instead of
ignoring a rule. /0.3 is never accepted: two unmerged drafts used it for
different features.
Witnessing is off by default. With an owner-adopted witness policy the store
uses feature-declared format 0.4: every committed change appends one journal entry in the
same transaction, the authority signs C2SP checkpoints over the entries, and
writes or reads that rely on earlier records proceed only when a fresh quorum
of witnesses cosigned the whole journal. Otherwise they refuse; an unverified
receipt is UNKNOWN, never observed. Counterparties verify receipt_proof bundles
offline with verify_receipt_proof.
"""
from collections.abc import MutableMapping
from copy import deepcopy
from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import secrets
import sqlite3
import stat
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from covenant_language.safe_io import durable_sqlite
from .codec import canonical, digest, loads, public_key
from .errors import NativeError, need
from .settlement import StablecoinLedger


def _snapshot(value, code='SETTLEMENT_PROOF_INVALID'):
    need(value is not None, 'SETTLEMENT_PROOF_REQUIRED')
    need(type(value) is dict, code)
    try:
        raw = canonical(value)
        need(len(raw) <= 2_000_000, code)
        return loads(raw)
    except (ValueError, TypeError, RecursionError, OverflowError, UnicodeError):
        raise NativeError(code) from None


def _bind_request(effect, payer, payee, unit, total, paid, receipt):
    need(type(total) is int and type(paid) is int and 0 <= paid <= total <= 2**53-1,
         'QUANTITY')
    need(type(receipt) is dict and type(receipt.get('body')) is dict, 'SETTLEMENT_BINDING')
    expected = {'agreement': effect, 'payer': payer, 'payee': payee, 'unit': unit,
                'amount': total, 'paid_amount': paid, 'refunded_amount': total-paid}
    need(all(key in receipt['body'] and canonical(receipt['body'][key]) == canonical(value)
             for key, value in expected.items()), 'SETTLEMENT_BINDING')


def _prefix(earlier, later):
    """Exact signed lineage, excluding the separately committed final receipt."""
    fields = set(earlier) - {'assents', 'deliveries', 'dispute', 'settlement'}
    if any(canonical(earlier[k]) != canonical(later[k]) for k in fields):
        return False
    for field in ('assents', 'deliveries'):
        if len(earlier[field]) > len(later[field]) or any(
                canonical(a) != canonical(b) for a, b in zip(earlier[field], later[field])):
            return False
    old, new = earlier['dispute'], later['dispute']
    if old is not None:
        if new is None or any(canonical(old[k]) != canonical(new[k]) for k in ('opening', 'evidence_hash')):
            return False
        for field in ('decision', 'appeal'):
            if old[field] is not None and canonical(old[field]) != canonical(new[field]):
                return False
    return True


def _proof(envelope, instance):
    from . import bilateral_v2 as b
    need(type(envelope) is dict, 'SETTLEMENT_PROOF_REQUIRED')
    checked = b.verify(envelope)
    need(checked['ok'], checked['code'])
    need(envelope['terms']['settlement_authority'] == instance, 'SETTLEMENT_AUTHORITY')
    progress = deepcopy(envelope)
    progress['settlement'] = None
    return b.identifier(envelope), progress


def _known_progress(ledger, state, effect, candidate):
    known = state.get('progress', {}).get(effect)
    if known is not None:
        need(_prefix(candidate, known) or _prefix(known, candidate), 'PROGRESS_CONFLICT')
        candidate = known if _prefix(candidate, known) else candidate
    result = deepcopy(candidate)
    receipt = ledger.receipts.get(effect)
    if receipt is not None:
        from . import bilateral_v2 as b
        result['settlement'] = deepcopy(receipt)
        checked = b.verify(result)
        need(checked['ok'], 'SETTLEMENT_CONFLICT')
    return result


_STORAGE_FORMAT = 'covenant-reference-settlement-sqlite/0.2'
# Optional features change what every opener must check, so a store with any of
# them declares them under /0.4: older provider binaries refuse it instead of
# settling without the owner's rule. /0.3 is never accepted (see the module doc).
_FEATURED_STORAGE_FORMAT = 'covenant-reference-settlement-sqlite/0.4'
# Each declared feature and the metadata member that carries its configuration.
_FEATURE_MEMBERS = {'time-policy': 'time_policy', 'witness-journal': 'journal'}
_RECORD_KINDS = ('accounts', 'escrow', 'receipts', 'progress', 'initial_balances')
JOURNAL_ENTRY_VERSION = 'covenant-reference-settlement-journal/0.1'
RECEIPT_PROOF_VERSION = 'covenant-reference-settlement-receipt-proof/0.1'
_JOURNAL_LABEL = 'COVENANT-REFERENCE-SETTLEMENT-JOURNAL-0.1'
_RECEIPT_LABEL = 'COVENANT-SETTLEMENT-RECEIPT-0.1'
_JOURNAL = 'reference_journal'
_ENTRY_FIELDS = {'version', 'instance', 'sequence', 'previous', 'operation', 'effect', 'receipt', 'changes', 'snapshot'}


class _Records(MutableMapping):
    """Transaction-local dictionary backed by individually bounded records.

    Nested dictionary mutations remain visible until flush. In particular, a
    balance or escrow update must commit in the same transaction as its signed
    progress and receipt. Unrelated agreement histories are never decoded.
    """

    def __init__(self, db, kind):
        self.db, self.kind = db, kind
        self.cache, self.original, self.deleted = {}, {}, set()

    def __getitem__(self, key):
        if key in self.deleted:
            raise KeyError(key)
        if key not in self.cache:
            row = self.db.execute(
                'SELECT value FROM reference_records WHERE kind=? AND key=?',
                (self.kind, key)).fetchone()
            if row is None:
                raise KeyError(key)
            self.cache[key], self.original[key] = loads(row[0]), row[0]
        return self.cache[key]

    def __setitem__(self, key, value):
        need(type(key) is str, 'SETTLEMENT_STORAGE')
        canonical({key: None})
        self.cache[key] = value
        self.deleted.discard(key)

    def __delitem__(self, key):
        self[key]
        self.deleted.add(key)
        self.cache.pop(key, None)

    def __iter__(self):
        keys = dict.fromkeys(row[0] for row in self.db.execute(
            'SELECT key FROM reference_records WHERE kind=?', (self.kind,)))
        keys.update(dict.fromkeys(self.cache))
        return iter(key for key in keys if key not in self.deleted)

    def __len__(self):
        return sum(1 for _ in self)

    def __deepcopy__(self, memo):
        result = {}
        memo[id(self)] = result
        for key in self:
            result[deepcopy(key, memo)] = deepcopy(self[key], memo)
        return result

    def flush(self):
        """Write changed records; return [kind, key, sha256 of the new bytes or None] for each."""
        changes = []
        for key in self.deleted:
            self.db.execute('DELETE FROM reference_records WHERE kind=? AND key=?',
                            (self.kind, key))
            changes.append([self.kind, key, None])
        for key, value in self.cache.items():
            raw = canonical(value)
            if raw != self.original.get(key):
                self.db.execute(
                    'INSERT INTO reference_records(kind, key, value) VALUES (?, ?, ?) '
                    'ON CONFLICT(kind, key) DO UPDATE SET value=excluded.value',
                    (self.kind, key, raw))
                changes.append([self.kind, key, hashlib.sha256(raw).hexdigest()])
        return changes


def _time_evidence():
    # Imported only when a policy is involved: the SDK-only wheel has no chain package.
    try:
        from covenant_chain import time_evidence
    except ImportError:
        raise NativeError('TIME_EVIDENCE_UNAVAILABLE') from None
    return time_evidence


def _time_policy(value):
    try:
        return _time_evidence().check_policy(value)
    except NativeError:
        raise
    except ValueError:
        raise NativeError('SETTLEMENT_TIME_POLICY') from None


def _features(value):
    """The declared optional features of a metadata record: [] for /0.2."""
    need(type(value) is dict and value.get('storage_format') in (_STORAGE_FORMAT, _FEATURED_STORAGE_FORMAT),
         'SETTLEMENT_STORAGE')
    if value['storage_format'] == _STORAGE_FORMAT:
        return []
    features = value.get('features')
    need(type(features) is list and features and all(type(name) is str for name in features) and
         features == sorted(set(features)) and set(features) <= set(_FEATURE_MEMBERS), 'SETTLEMENT_STORAGE')
    return features


def _metadata(value):
    features = _features(value)
    members = {_FEATURE_MEMBERS[name] for name in features}
    need(set(value) == {'storage_format', 'instance', 'opened'} | ({'features'} | members if features else set()) and
         type(value['instance']) is str and
         len(value['instance']) == 64 and all(c in '0123456789abcdef' for c in value['instance']) and
         type(value['opened']) is dict, 'SETTLEMENT_STORAGE')
    witnessed = 'witness-journal' in features
    need(not witnessed or (type(value['journal']) is dict and set(value['journal']) == {'origin', 'log'} and
                           all(type(item) is str for item in value['journal'].values())), 'SETTLEMENT_STORAGE')
    # Validate units and exact integer types as for the original reference ledger.
    check = StablecoinLedger({'opening': value['opened']})
    need(check.total_map() == value['opened'], 'SETTLEMENT_STORAGE')
    if 'time-policy' in features:
        _time_policy(value['time_policy'])
    return value


def _with_features(metadata, **members):
    """The same store declaring additional features; existing members are unchanged."""
    names = {name for name, member in _FEATURE_MEMBERS.items() if member in members}
    features = sorted(set(_features(metadata)) | names)
    return _metadata({**metadata, **members, 'storage_format': _FEATURED_STORAGE_FORMAT, 'features': features})


def _store_records(db, value, time_policy=None):
    """Create or atomically migrate the original bounded single-blob storage."""
    required = {'instance', 'accounts', 'escrow', 'receipts', 'opened', 'initial_balances'}
    need(type(value) is dict and required <= set(value) <= required | {'progress'},
         'SETTLEMENT_STORAGE')
    metadata = _metadata({'storage_format': _STORAGE_FORMAT,
                          'instance': value['instance'], 'opened': value['opened']})
    if time_policy is not None:
        metadata = _with_features(metadata, time_policy=time_policy)
    need(db.execute('SELECT 1 FROM reference_records LIMIT 1').fetchone() is None,
         'SETTLEMENT_STORAGE')
    for kind in _RECORD_KINDS:
        entries = value.get(kind, {})
        need(type(entries) is dict, 'SETTLEMENT_STORAGE')
        records = _Records(db, kind)
        for key, entry in entries.items():
            records[key] = entry
        records.flush()
    # Replacing, rather than retaining, the old snapshot ensures an old binary
    # cannot silently operate a stale second set of balances after migration.
    db.execute('INSERT INTO reference_state(id, value) VALUES (1, ?) '
               'ON CONFLICT(id) DO UPDATE SET value=excluded.value', (canonical(metadata),))
    return metadata


def _clock_now(clock):
    try:
        value = clock()
    except Exception:
        raise NativeError('SETTLEMENT_CLOCK') from None
    need(type(value) in (int, float) and value == value and 0 <= value <= 2**53-1, 'SETTLEMENT_CLOCK')
    return int(value)


def _judge_clock(envelope, receipt, now):
    body, terms = receipt['body'], envelope['terms']
    need(type(body.get('at')) is int and body['at'] <= now, 'SETTLEMENT_CLOCK_AHEAD')
    dispute = envelope.get('dispute') or {}
    decision = dispute.get('appeal') or dispute.get('decision')
    if body.get('authorized_by') == 'resolver_decision' and dispute.get('appeal') is None:
        need(now >= decision['body']['at'] + terms['challenge_window'], 'APPEAL_WINDOW_OPEN')
    elif body.get('authorized_by') == 'silent_refund':
        need(now > terms['deadline'], 'SILENCE_NOT_DUE')


def _judge_evidence(effect, envelope, receipt, policy, evidence):
    body, terms = receipt['body'], envelope['terms']
    dispute = envelope.get('dispute') or {}
    if body.get('authorized_by') == 'resolver_decision' and dispute.get('appeal') is None:
        limit, code = dispute['decision']['body']['at'] + terms['challenge_window'] - 1, 'APPEAL_WINDOW_OPEN'
    elif body.get('authorized_by') == 'silent_refund':
        limit, code = terms['deadline'], 'SILENCE_NOT_DUE'
    else:
        return
    need(evidence is not None, 'TIME_EVIDENCE_REQUIRED')
    need(evidence.get('subject') == effect, 'TIME_EVIDENCE_SUBJECT')
    time_evidence = _time_evidence()
    try:
        checked = time_evidence.deadline(time_evidence.assess(evidence, policy), limit)
    except ValueError as exc:
        raise NativeError(str(exc) if str(exc).startswith(('TIME_', 'ROUGHTIME_', 'TRUST_', 'GEO_')) else 'TIME_EVIDENCE_INVALID') from None
    need(checked['status'] != 'NOT_YET', code)
    need(checked['status'] == 'PASSED', 'TIME_UNDETERMINED')
    need(checked['not_after'] is None or body['at'] <= checked['not_after'], 'SETTLEMENT_CLOCK_AHEAD')


def _witness_options(value):
    from covenant_chain import witness_journal
    need(type(value) is dict and {'policy', 'log_key'} <= set(value) <= {'policy', 'log_key', 'witnesses', 'retained', 'clock', 'gate'}, 'SETTLEMENT_WITNESS')
    rules = witness_journal.validate_policy(value['policy'])
    need(isinstance(value['log_key'], Ed25519PrivateKey) and public_key(value['log_key']) == rules['log']['public'].hex(), 'SETTLEMENT_WITNESS')
    witnesses = value.get('witnesses') or {}
    clock = value.get('clock') or (lambda: int(time.time()))
    need(type(witnesses) is dict and callable(clock), 'SETTLEMENT_WITNESS')
    # Optional owner-chosen Gate factory, e.g. chain_witness.gate_factory for chain witnesses (witness policy /0.2).
    gate = value.get('gate') or witness_journal.Gate
    need(callable(gate), 'SETTLEMENT_WITNESS')
    return {'policy': deepcopy(value['policy']), 'rules': rules, 'log_key': value['log_key'], 'witnesses': dict(witnesses),
            'retained': value.get('retained'), 'clock': clock, 'gate': gate}


def _journal_entry(journal, instance, operation, effect, receipt, changes, snapshot=None):
    size = journal.size()
    entry = {'version': JOURNAL_ENTRY_VERSION, 'instance': instance, 'sequence': size,
             'previous': journal.entry(size - 1) if size else None, 'operation': operation,
             'effect': effect, 'receipt': receipt, 'changes': sorted(changes), 'snapshot': snapshot}
    journal.append(digest(_JOURNAL_LABEL, entry), canonical(entry), effect)
    return entry


class SharedSettlementLedger:
    def __init__(self, path, balances=None, *, clock=None, time_policy=None, witness=None):
        need(clock is None or callable(clock), 'SETTLEMENT_CLOCK')
        self._clock = time.time if clock is None else clock
        adopted = None if time_policy is None else _time_policy(time_policy)
        self.path = Path(path).absolute()
        self.witness = None if witness is None else _witness_options(witness)
        need(self.path.parent.is_dir() and not self.path.is_symlink(), 'SETTLEMENT_STORAGE')
        if balances is None:
            need(self.path.exists(), 'SETTLEMENT_NOT_INITIALIZED')
        else:
            try:
                fd = os.open(self.path, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            except FileExistsError:
                pass
            else:
                os.close(fd)
        info = self.path.lstat()
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
             info.st_uid == os.getuid() and info.st_mode & 0o077 == 0, 'SETTLEMENT_STORAGE')
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('CREATE TABLE IF NOT EXISTS reference_state (id INTEGER PRIMARY KEY CHECK(id=1), value BLOB NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS reference_records ('
                       'kind TEXT NOT NULL, key TEXT NOT NULL, value BLOB NOT NULL, '
                       'PRIMARY KEY(kind, key)) WITHOUT ROWID')
            row = db.execute('SELECT value FROM reference_state WHERE id=1').fetchone()
            if row is None:
                need(balances is not None, 'SETTLEMENT_NOT_INITIALIZED')
                ledger = StablecoinLedger(balances)
                _store_records(db, {'instance': secrets.token_hex(32), 'accounts': ledger.accounts,
                                    'escrow': {}, 'receipts': {}, 'opened': ledger.total_map(),
                                    'initial_balances': balances}, adopted)
            else:
                value = loads(row[0])
                if type(value) is dict and 'storage_format' in value:
                    metadata = _metadata(value)
                else:
                    metadata = _store_records(db, value)
                # A policy is installed only at initialization and cannot be
                # added to, changed on or removed from an existing authority.
                need(adopted is None or canonical(metadata.get('time_policy')) == canonical(adopted),
                     'SETTLEMENT_TIME_POLICY')
                if balances is not None:
                    initial = _Records(db, 'initial_balances')
                    need(type(balances) is dict and len(initial) == len(balances) and all(
                        type(key) is str and key in initial and canonical(initial[key]) == canonical(units)
                        for key, units in balances.items()), 'SETTLEMENT_ALREADY_INITIALIZED')
            metadata = _metadata(loads(db.execute('SELECT value FROM reference_state WHERE id=1').fetchone()[0]))
            if self.witness is None:
                need('witness-journal' not in _features(metadata), 'SETTLEMENT_WITNESS_REQUIRED')
            else:
                self._adopt_journal(db, metadata)

    def _adopt_journal(self, db, metadata):
        """Feature-declared format 0.4: the journal opens with a digest of every existing record, atomically."""
        from covenant_chain import witness_journal
        rules = self.witness['rules']
        pin = {'origin': rules['origin'], 'log': rules['log']['vkey']}
        journal = witness_journal.Journal(db, _JOURNAL, create=True)
        if 'witness-journal' in _features(metadata):
            need(metadata['journal'] == pin, 'SETTLEMENT_WITNESS_CONFIG')
            return
        need(journal.size() == 0, 'SETTLEMENT_STORAGE')
        snapshot = hashlib.sha256()
        for kind, key, raw in db.execute('SELECT kind, key, value FROM reference_records ORDER BY kind, key'):
            snapshot.update(canonical([kind, key, hashlib.sha256(raw).hexdigest()]) + b'\n')
        _journal_entry(journal, metadata['instance'], 'OPEN', None, None, [], snapshot.hexdigest())
        upgraded = _with_features(metadata, journal=pin)
        db.execute('UPDATE reference_state SET value=? WHERE id=1', (canonical(upgraded),))

    @contextmanager
    def _gate(self):
        """The authority's witness gate on its own connection, outside any settlement transaction."""
        from covenant_chain import witness_journal
        options, retained = self.witness, None
        db = sqlite3.connect(self.path.as_uri() + '?mode=rw', uri=True, timeout=15, isolation_level=None)
        try:
            db.execute('PRAGMA busy_timeout=15000')
            db.execute('PRAGMA synchronous=FULL')
            if options['retained'] is not None:
                retained = witness_journal.RetainedHead(options['retained'], options['rules']['origin'])
            gate = options['gate'](witness_journal.Journal(db, _JOURNAL), options['policy'],
                                   log_key=options['log_key'], clock=options['clock'],
                                   witnesses=options['witnesses'], retained=retained)
            need(isinstance(gate, witness_journal.Gate), 'SETTLEMENT_WITNESS')
            yield gate
        finally:
            if retained is not None:
                retained.close()
            db.close()

    def _witnessed(self):
        """A fresh quorum over the whole journal before reliance; UNKNOWN or REFUSED refuse."""
        try:
            with self._gate() as gate:
                verdict = gate.check()
        except ValueError as error:  # a journal that cannot even be judged is not relied on
            raise NativeError('SETTLEMENT_WITNESS_REFUSED') from error
        need(verdict['status'] == 'VERIFIED', 'SETTLEMENT_WITNESS_' + verdict['status'])
        return verdict

    def _publish(self):
        """After a commit: sign the new head and ask the witnesses. Failure is retried at the next reliance."""
        try:
            with self._gate() as gate:
                gate.publish()
                gate.check()
        except (ValueError, sqlite3.Error):
            pass

    def witness_verdict(self):
        need(self.witness is not None, 'SETTLEMENT_WITNESS_REQUIRED')
        with self._gate() as gate:
            return gate.check()

    def journal_checkpoint(self):
        """The authority's C2SP checkpoint over every journal entry so far."""
        need(self.witness is not None, 'SETTLEMENT_WITNESS_REQUIRED')
        with self._gate() as gate:
            return gate.publish()

    def journal_extension(self, old):
        """A consistency proof from a checkpoint size a counterparty retained to the newest one."""
        need(self.witness is not None, 'SETTLEMENT_WITNESS_REQUIRED')
        with self._gate() as gate:
            gate.check()
            return gate.extension(old)

    def witness_evidence(self):
        need(self.witness is not None, 'SETTLEMENT_WITNESS_REQUIRED')
        with self._gate() as gate:
            return gate.journal.evidence()

    def receipt_proof(self, effect):
        """The receipt, its journal entry and inclusion under the newest witnessed checkpoint."""
        need(self.witness is not None, 'SETTLEMENT_WITNESS_REQUIRED')
        observed = self._run(lambda ledger, instance: ledger.observe(effect))
        need(observed['status'] == 'OBSERVED', 'SETTLEMENT_NOT_OBSERVED')
        with self._gate() as gate:
            found = [index for index in gate.journal.tagged(effect)
                     if loads(gate.journal.body(index))['receipt'] == observed['output_hash']]
            need(found, 'SETTLEMENT_JOURNAL_ENTRY')
            entry = loads(gate.journal.body(found[-1]))
            proof = gate.proof(found[-1])
        return {'version': RECEIPT_PROOF_VERSION, 'effect': effect, 'receipt': observed['value'],
                'entry': entry, 'proof': proof}

    @contextmanager
    def _connect(self):
        # Creation belongs exclusively to explicit initialization above. A
        # missing/replaced store during restart or a later operation must never
        # silently become a new empty database.
        db = sqlite3.connect(self.path.as_uri() + '?mode=rw', uri=True, timeout=15)
        try:
            db.execute('PRAGMA busy_timeout=15000')
            # A rollback journal: owner_setup snapshots this one file and treats
            # any journal beside it as an active writer.
            durable_sqlite(db, journal='DELETE')
            with db:
                yield db
        finally:
            db.close()

    def _transact(self, action, *, write=False, relies=False, timed=False):
        for attempt in range(3):
            verdict = self._witnessed() if self.witness is not None and (write or relies) else None
            try:
                result = self._attempt(action, write, verdict, timed)
            except NativeError as error:
                if error.code == 'SETTLEMENT_WITNESS_RACE' and attempt < 2:
                    continue
                raise
            if write and self.witness is not None:
                self._publish()
            return result

    def _attempt(self, action, write, verdict, timed=False):
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE' if write else 'BEGIN')
            row = db.execute('SELECT value FROM reference_state WHERE id=1').fetchone()
            need(row is not None, 'SETTLEMENT_STORAGE')
            metadata = _metadata(loads(row[0]))
            journal = None
            if self.witness is None:
                need('witness-journal' not in _features(metadata), 'SETTLEMENT_WITNESS_REQUIRED')
            else:
                from covenant_chain import witness_journal
                need('witness-journal' in _features(metadata), 'SETTLEMENT_STORAGE')
                journal = witness_journal.Journal(db, _JOURNAL)
                # Another writer may have appended since the witnessed head; rely only on what was witnessed.
                need(verdict is None or journal.size() == verdict['size'], 'SETTLEMENT_WITNESS_RACE')
            records = {kind: _Records(db, kind) for kind in _RECORD_KINDS}
            value = dict(records, instance=metadata['instance'], opened=metadata['opened'])
            ledger = StablecoinLedger()
            ledger.accounts, ledger.escrow = records['accounts'], records['escrow']
            ledger.receipts, ledger._opened = records['receipts'], metadata['opened']
            # A timed action also receives the installed time policy, read in
            # the same transaction as the balances it may move.
            result = (action(ledger, value['instance'], value, metadata.get('time_policy')) if timed else
                      action(ledger, value['instance'], value))
            if write:
                need(ledger.total_map() == ledger._opened, 'PAYMENT_FUNDS')
                changes = [change for records_for_kind in records.values()
                           for change in records_for_kind.flush()]
                if journal is not None and changes:
                    keys = {kind: key for kind, key, _ in changes if kind in ('receipts', 'progress', 'escrow')}
                    effect = keys.get('receipts') or keys.get('progress') or keys.get('escrow')
                    receipt = (digest(_RECEIPT_LABEL, records['receipts'][keys['receipts']])
                               if 'receipts' in keys else None)
                    operation = 'SETTLE' if receipt else 'PROGRESS' if 'progress' in keys else 'CHANGE'
                    _journal_entry(journal, metadata['instance'], operation, effect, receipt, changes)
            return deepcopy(result)

    def _run(self, action, *, write=False):
        return self._transact(lambda ledger, instance, state: action(ledger, instance), write=write)

    @property
    def instance(self):
        return self._run(lambda ledger, instance: instance)

    @property
    def time_policy(self):
        """The owner-installed covenant-time-evidence/0.1 policy, or None."""
        return self._transact(lambda ledger, instance, state, policy: policy, timed=True)

    def balance(self, account, unit):
        return self._run(lambda ledger, instance: ledger.balance(account, unit))

    def total_map(self):
        return self._run(lambda ledger, instance: ledger.total_map())

    def observe(self, effect):
        if self.witness is None:
            return self._run(lambda ledger, instance: ledger.observe(effect))
        try:
            verdict = self._witnessed()
        except NativeError as error:
            return {'status': 'UNKNOWN', 'output_hash': None, 'code': error.code,
                    'assurance': 'WITNESSED_JOURNAL_NOT_VERIFIED_NOT_OBSERVED'}
        def read(ledger, instance, state):
            from covenant_chain import witness_journal
            seen = ledger.observe(effect)
            if seen['status'] == 'OBSERVED':
                journal = witness_journal.Journal(state['receipts'].db, _JOURNAL)
                covered = [index for index in journal.tagged(effect) if index < verdict['size'] and
                           loads(journal.body(index))['receipt'] == seen['output_hash']]
                if not covered:
                    return {'status': 'UNKNOWN', 'output_hash': None, 'code': 'SETTLEMENT_WITNESS_UNKNOWN',
                            'assurance': 'RECEIPT_NOT_YET_WITNESSED_NOT_OBSERVED'}
                seen['witness'] = {'status': 'VERIFIED', 'size': verdict['size'], 'root': verdict['root']}
            return seen
        return self._transact(read)

    def move_to_escrow(self, effect, payer, unit, amount, *, envelope=None):
        # This public provider entry is not an unsigned debit capability.
        envelope = _snapshot(envelope)
        proof_effect, candidate = _proof(envelope, self.instance)
        need(proof_effect == effect and canonical(candidate['parties']['principal']) == canonical(payer) and
             canonical(candidate['terms']['unit']) == canonical(unit) and
             canonical(candidate['terms']['quantity']) == canonical(amount), 'SETTLEMENT_BINDING')
        self.register_progress(candidate, fund=True)
        return self._run(lambda ledger, instance: ledger.escrow[effect])

    def progress(self, envelope):
        """Observe compatible registered history without adopting caller authority."""
        envelope = _snapshot(envelope)
        def read(ledger, instance, state):
            effect, candidate = _proof(envelope, instance)
            if envelope['settlement'] is not None:
                need(canonical(ledger.receipts.get(effect)) == canonical(envelope['settlement']),
                     'SETTLEMENT_NOT_OBSERVED')
            return _known_progress(ledger, state, effect, candidate)
        return self._transact(read, relies=True)

    def registered_progress(self, envelope):
        """Read the adopted journal; None means no progress has been registered."""
        envelope = _snapshot(envelope)
        def read(ledger, instance, state):
            effect, candidate = _proof(envelope, instance)
            if effect not in state.get('progress', {}):
                return None
            return _known_progress(ledger, state, effect, candidate)
        return self._transact(read, relies=True)

    def records_for(self, account, *, limit=256):
        """Read-only: registered agreements naming ``account`` in any role.

        Returns the provider's own journal, escrow row and receipt for each
        match, newest key order not implied. Nothing is registered, funded or
        released; callers label these rows as provider observations.
        """
        need(type(account) is str and len(account) == 64 and
             all(c in '0123456789abcdef' for c in account), 'PUBLIC_KEY')
        need(type(limit) is int and 1 <= limit <= 4096, 'SETTLEMENT_LIMIT')
        def read(ledger, instance, state):
            rows = []
            truncated = False
            for effect in sorted(state['progress']):
                envelope = state['progress'][effect]
                parties = envelope.get('parties') if type(envelope) is dict else None
                if type(parties) is not dict or account not in parties.values():
                    continue
                if len(rows) == limit:
                    truncated = True
                    break
                receipt = ledger.receipts.get(effect)
                escrow = ledger.escrow.get(effect)
                progress = deepcopy(envelope)
                if receipt is not None:
                    progress['settlement'] = deepcopy(receipt)
                rows.append({'agreement': effect, 'progress': progress,
                             'escrow': None if escrow is None else deepcopy(escrow),
                             'receipt': None if receipt is None else deepcopy(receipt)})
            return {'instance': instance, 'rows': rows, 'truncated': truncated}
        return self._transact(read)

    def register_progress(self, envelope, *, fund=False):
        """Verify and persist a monotone signed update, atomically with funding."""
        envelope = _snapshot(envelope)
        def apply(ledger, instance, state):
            effect, candidate = _proof(envelope, instance)
            if envelope['settlement'] is not None:
                need(canonical(ledger.receipts.get(effect)) == canonical(envelope['settlement']),
                     'SETTLEMENT_NOT_OBSERVED')
            known = state.get('progress', {}).get(effect)
            result = _known_progress(ledger, state, effect, candidate)
            if ledger.receipts.get(effect) is not None:
                # A finalized order accepts only historical prefix retries.
                need(known is None or _prefix(candidate, known), 'ORDER_FINAL')
                return result
            if fund:
                need(len(candidate['assents']) == 2, 'COUNTERPARTY_ASSENT')
                ledger.move_to_escrow(effect, candidate['parties']['principal'],
                                      candidate['terms']['unit'], candidate['terms']['quantity'])
            stored = deepcopy(result); stored['settlement'] = None
            state.setdefault('progress', {})[effect] = stored
            return result
        return self._transact(apply, write=True)

    def settle_split(self, effect, payer, payee, unit, total, paid, receipt, *, envelope=None, time_evidence=None):
        receipt, envelope = _snapshot(receipt, 'SETTLEMENT_BINDING'), _snapshot(envelope)
        if time_evidence is not None:
            time_evidence = _snapshot(time_evidence, 'TIME_EVIDENCE_INVALID')
        _bind_request(effect, payer, payee, unit, total, paid, receipt)
        def apply(ledger, instance, state, policy):
            proof_effect, candidate = _proof(envelope, instance)
            need(proof_effect == effect and canonical(envelope['settlement']) == canonical(receipt),
                 'SETTLEMENT_BINDING')
            need(receipt.get('body', {}).get('settlement_authority') == instance, 'SETTLEMENT_AUTHORITY')
            previous = ledger.receipts.get(effect)
            if previous is not None:
                need(canonical(previous) == canonical(receipt), 'SETTLEMENT_CONFLICT')
                return previous
            known = state.get('progress', {}).get(effect)
            if known is not None:
                need(_prefix(known, candidate), 'STALE_PROGRESS' if _prefix(candidate, known) else 'PROGRESS_CONFLICT')
            if policy is None:
                # Default: this authority's own clock, not the signer's host
                # clock, decides whether the claimed time has arrived and the
                # agreed window has closed.
                need(time_evidence is None, 'TIME_POLICY_NOT_INSTALLED')
                _judge_clock(envelope, receipt, _clock_now(self._clock))
            else:
                # Opt-in: independent time sources replace the clock.
                _judge_evidence(effect, envelope, receipt, policy, time_evidence)
            ledger.move_to_escrow(effect, payer, unit, total)
            row = ledger.escrow[effect]
            need(row['status'] == 'HELD', 'ESCROW_STATE')
            ledger._add(payee, unit, paid)
            ledger._add(payer, unit, total-paid)
            row.update(status='SPLIT', payee=payee, paid_amount=paid, refunded_amount=total-paid)
            ledger.remember(effect, receipt)
            state.setdefault('progress', {})[effect] = candidate
            return receipt
        return self._transact(apply, write=True, timed=True)


def verify_receipt_proof(bundle, policy, now):
    """Verify authority-recorded receipt evidence, never external funds."""
    from covenant_chain import witness_journal
    return _verify_receipt_proof(bundle, policy, now, witness_journal.verify_proof)


def _verify_receipt_proof(bundle, policy, now, verify_proof):
    """verify_proof(proof, policy, now, entry=...) is witness_journal's, or chain_witness's under witness policy /0.2."""
    need(type(bundle) is dict and set(bundle) == {'version', 'effect', 'receipt', 'entry', 'proof'} and bundle['version'] == RECEIPT_PROOF_VERSION, 'SETTLEMENT_PROOF_INVALID')
    entry, receipt = bundle['entry'], bundle['receipt']
    need(type(entry) is dict and set(entry) == _ENTRY_FIELDS and entry['version'] == JOURNAL_ENTRY_VERSION and entry['operation'] == 'SETTLE' and entry['effect'] == bundle['effect'] and entry['receipt'] == digest(_RECEIPT_LABEL, receipt), 'SETTLEMENT_PROOF_INVALID')
    need(type(receipt) is dict and type(receipt.get('body')) is dict and receipt['body'].get('agreement') == bundle['effect'] and receipt['body'].get('settlement_authority') == entry['instance'], 'SETTLEMENT_PROOF_INVALID')
    reference = digest(_JOURNAL_LABEL, entry)
    need(type(bundle['proof']) is dict and bundle['proof'].get('entry') == reference, 'SETTLEMENT_PROOF_INVALID')
    checked = verify_proof(bundle['proof'], policy, now, entry=reference)
    return {**checked, 'effect': bundle['effect'], 'receipt_hash': entry['receipt'], 'instance': entry['instance'], 'assurance': 'AUTHORITY_RECORDED_RECEIPT_NOT_EXTERNAL_PAYMENT'}


def settle_split(ledger, effect, payer, payee, unit, total, paid, receipt, *, envelope=None, time_evidence=None):
    """The in-process test ledger implements the same conservation boundary."""
    _bind_request(effect, payer, payee, unit, total, paid, receipt)
    if hasattr(ledger, 'settle_split'):
        extra = {} if time_evidence is None else {'time_evidence': time_evidence}
        return ledger.settle_split(effect, payer, payee, unit, total, paid, receipt, envelope=envelope, **extra)
    need(isinstance(ledger, StablecoinLedger), 'SETTLEMENT_ADAPTER')
    need(time_evidence is None, 'TIME_POLICY_NOT_INSTALLED')
    before = deepcopy((ledger.accounts, ledger.escrow, ledger.receipts))
    try:
        previous = ledger.receipts.get(effect)
        if previous is not None:
            need(canonical(previous) == canonical(receipt), 'SETTLEMENT_CONFLICT')
            return deepcopy(previous)
        ledger.move_to_escrow(effect, payer, unit, total)
        need(ledger.escrow[effect]['status'] == 'HELD', 'ESCROW_STATE')
        ledger._add(payee, unit, paid)
        ledger._add(payer, unit, total-paid)
        ledger.escrow[effect].update(status='SPLIT', paid_amount=paid, refunded_amount=total-paid)
        ledger.remember(effect, receipt)
        need(ledger.total_map() == ledger._opened, 'PAYMENT_FUNDS')
        return deepcopy(receipt)
    except BaseException:
        ledger.accounts, ledger.escrow, ledger.receipts = before
        raise
