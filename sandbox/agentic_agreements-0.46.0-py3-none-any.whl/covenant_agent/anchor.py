"""Build chain transactions for a dispute. Nothing here is submitted.

The happy path never calls this module. A caller may pass submit() to broadcast
the transactions; until that returns, the chain ledger is untouched.
"""
from .errors import NativeError, need


def build_anchor(envelope, anchor):
    need(type(anchor) is dict, 'ANCHOR_FIELDS')
    for field in ('genesis', 'resource', 'profile', 'deadline_height', 'keys'):
        need(field in anchor, 'ANCHOR_FIELDS')
    keys = anchor['keys']
    need(type(keys) is dict and 'agent' in keys and 'counterparty' in keys, 'ANCHOR_FIELDS')
    from covenant_chain import app
    from covenant_chain.crypto import genesis_id
    genesis = anchor['genesis']
    fee_profiles = {app.ECONOMIC_VERSION, app.CONFIDENTIAL_VERSION, app.CONTINUITY_VERSION,
                    app.MARKET_VERSION, app.REVIEW_VERSION, app.PREDICTION_VERSION, app.MIGRATION_VERSION}
    if genesis.get('protocol') in fee_profiles:
        raise NativeError('ANCHOR_FIELDS',
                          'This genesis charges a fee envelope. Build the anchor on a pre-fee profile, or let the economics module supply the fee.')
    chain = genesis_id(genesis)
    parties = envelope['parties']
    terms = envelope['terms']
    mandate_id = anchor.get('mandate_id')
    if parties['principal'] != parties['agent']:
        need(type(mandate_id) is str and len(mandate_id) == 64, 'ANCHOR_REQUIRES_CHAIN_MANDATE')
    else:
        need(mandate_id is None, 'ANCHOR_MANDATE')
    blocks = anchor.get('challenge_blocks', terms['challenge_window'])
    need(type(blocks) is int and 1 <= blocks <= 10000, 'ANCHOR_CHALLENGE_BLOCKS')
    deadline = anchor['deadline_height']
    need(type(deadline) is int and 1 <= deadline <= 2**53 - 1, 'DEADLINE')
    need(type(terms['pay_to']) is str and len(terms['pay_to']) <= 256, 'PAY_TO')
    native = {
        'chain': chain,
        'principal': parties['principal'],
        'agent': parties['agent'],
        'counterparty': parties['counterparty'],
        'mandate': mandate_id,
        'profile': anchor['profile'],
        'resource': anchor['resource'],
        'quantity': terms['quantity'],
        'effect': terms['effect'],
        'destination': terms['pay_to'],
        'executor': parties['executor'],
        'resolver': parties['resolver'],
        'appeal_resolver': parties['appeal_resolver'],
        'deadline': deadline,
        'challenge_blocks': blocks,
        'timeout': terms['timeout'],
        'terms_hash': terms['task_hash'],
    }
    assents = [app.assent(keys['agent'], native), app.assent(keys['counterparty'], native)]
    nonces = anchor.get('nonces') or {}
    agent_pub_nonce = nonces.get('agent', 0)
    submitter = keys.get('submitter', keys['agent'])
    protocol = genesis['protocol']
    bind = app.make_transaction(submitter, chain, agent_pub_nonce, 'BIND',
                                {'terms': native, 'assents': assents}, protocol=protocol)
    transactions = [bind]
    agreement = app.agreement_id(native)
    if envelope.get('deliveries'):
        content_hash = envelope['deliveries'][0]['content_hash']
        show = app.make_transaction(
            keys['counterparty'], chain, nonces.get('counterparty', 0), 'SHOW',
            {'agreement': agreement, 'content_hash': content_hash, 'description': content_hash},
            protocol=protocol)
        transactions.append(show)
    return {
        'status': 'READY_NOT_SUBMITTED',
        'chain': chain,
        'agreement_id': agreement,
        'native_terms': native,
        'transactions': transactions,
        'chain_ledger_touched': False,
        'ledger_touched': False,
    }
