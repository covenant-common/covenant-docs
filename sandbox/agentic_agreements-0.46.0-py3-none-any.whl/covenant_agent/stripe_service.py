"""The owner's Stripe gateway as one separate process: loopback HTTP for agents and Stripe events.

    python -m covenant_agent.stripe_service serve --directory OWNER_DIR --port 8473 [--ops-port 9473] [--log-json]
    python -m covenant_agent.stripe_service approve --directory OWNER_DIR --occurrence HEX [--key-file F --confirm SHA256]
    python -m covenant_agent.stripe_service status --directory OWNER_DIR [--prometheus]
    python -m covenant_agent.stripe_service export --directory OWNER_DIR --agreement HEX
    python -m covenant_agent.stripe_service verify --record FILE --principal HEX --agreement HEX
    python -m covenant_agent.stripe_service backup --directory OWNER_DIR --out FILE
    python -m covenant_agent.stripe_service describe

OWNER_DIR (mode 0700) holds stripe-owner.json (mode 0600, key-free): the
Checkout policy of covenant_agent.stripe_gateway, the owner-signed payment
policy, the owner-signed approval policies, the names of the environment
variables holding the restricted key and the webhook signing secret, and the
provider origin. Credential values are read from the environment at the moment
of use, never written, logged or returned. Custody lives in OWNER_DIR/custody.

The listener binds 127.0.0.1 only. Agents post signed actions; Stripe's webhook
reaches it through the owner's own TLS front end or `stripe listen
--forward-to`. Routes and their bounds are listed by `describe`.
"""
import argparse
from http.server import BaseHTTPRequestHandler
import json
import os
from pathlib import Path
import re
import signal
import sys
import threading
import time
from urllib.parse import urlsplit

from covenant_chain.crypto import loads, need
from covenant_chain.http_limits import BoundedHTTPServer
from covenant_chain.observability import Instrumented, Ops, add_arguments, start, writable_directory

from . import owner_config, stripe_action as action, stripe_disputes as disputes, stripe_payments as payments
# Fix text for the codes raised here: the service's own, the gateway's and the owner configuration's.
from .errors import REMEDIATION as OWNER_REMEDIATION
from .stripe_action import REMEDIATION as ACTION_REMEDIATION
from .stripe_gateway import REMEDIATION as GATEWAY_REMEDIATION
from .stripe_gateway import StripeGateway, _parse

CONFIG_VERSION = 'covenant-stripe-owner/0.1'
CONFIG = 'stripe-owner.json'
ENV_NAME = re.compile(r'[A-Z][A-Z0-9_]{1,63}\Z')
CREDENTIAL_PREFIXES = ('rk_', 'sk_', 'pk_', 'rkcs_', 'whsec_')
MAX_JSON = 65536
MAX_EVENT = 1048576
OPERATION_PATH = '/v1/payment-operations/'
EVENTS_PATH = '/v1/stripe-events'
ROUTES = {('GET', '/v1/gateway'): 'gateway', ('POST', '/v1/payment-actions'): 'submit',
          ('POST', '/v1/approvals'): 'approval', ('POST', '/v1/sources'): 'source', ('POST', EVENTS_PATH): 'event'}
STATUS = {'STRIPE_PAYMENT_APPROVAL_REQUIRED': 403, 'STRIPE_PAYMENT_APPROVAL_REFUSED': 403,
          'STRIPE_PAYMENT_GRANT_REFUSED': 403, 'STRIPE_PAYMENT_OBSERVER_REFUSED': 403,
          'STRIPE_PAYMENT_UNRESOLVED': 409, 'STRIPE_PAYMENT_UNKNOWN_BLOCKS': 409, 'STRIPE_PAYMENT_ALREADY_PAID': 409,
          'STRIPE_PAYMENT_CHECKOUT_OPEN': 409, 'STRIPE_PAYMENT_OPERATION_REUSED': 409,
          'STRIPE_PAYMENT_OPERATION_UNKNOWN': 404}


def _code(error, fallback='STRIPE_SERVICE_FAILED'):
    text = getattr(error, 'code', None) or (str(error) if error.args else '')
    return text if type(text) is str and re.fullmatch(r'[A-Z][A-Z0-9_]{1,100}', text) else fallback


def _plain(value, depth=0):
    """Configuration may name credentials, never hold them."""
    need(depth <= 12, 'OWNER_JSON')
    if type(value) is str:
        need(not value.startswith(CREDENTIAL_PREFIXES), 'OWNER_SECRET_IN_CONFIG')
    elif type(value) is dict:
        for item in value.values():
            _plain(item, depth + 1)
    elif type(value) is list:
        for item in value:
            _plain(item, depth + 1)


def check_config(config):
    """Validate stripe-owner.json; returns it unchanged. No credential value is read."""
    need(type(config) is dict and set(config) == {'version', 'checkout_policy', 'payment_policy', 'approval_policies',
                                                  'key_env', 'webhook_env', 'origin', 'harness', 'allow_live',
                                                  'timeout'} and config['version'] == CONFIG_VERSION, 'OWNER_JSON')
    owner_config._no_secrets(config)
    _plain(config)
    need(type(config['key_env']) is str and ENV_NAME.fullmatch(config['key_env']) is not None and
         type(config['webhook_env']) is str and ENV_NAME.fullmatch(config['webhook_env']) is not None,
         'RAIL_CREDENTIAL_ENV')
    # Two provider calls (a token read, then the charge) must fit inside one 60-second connection.
    need(type(config['harness']) is bool and type(config['allow_live']) is bool and type(config['timeout']) is int and
         1 <= config['timeout'] <= 25 and type(config['approval_policies']) is list and
         len(config['approval_policies']) <= 16, 'OWNER_JSON')
    origin = config['origin']
    if config['harness']:
        u = urlsplit(origin) if type(origin) is str else None
        need(u is not None and u.scheme == 'http' and u.hostname == '127.0.0.1' and u.port is not None,
             'STRIPE_HARNESS_ORIGIN')
    else:
        need(origin == 'https://api.stripe.com', 'STRIPE_ORIGIN')
    return config


def load_config(directory):
    path = owner_config._directory(directory, create=False)
    config = owner_config._read(path, CONFIG)
    need(config is not None, 'OWNER_CONFIG_MISSING')
    return path, check_config(config)


def write_config(directory, config):
    """Write a validated, key-free stripe-owner.json (0600, never overwritten)."""
    path = owner_config._directory(directory, create=True)
    check_config(config)
    return owner_config._write(path, CONFIG, config)


def open_owner(directory, *, environ=None, live=False, clock=None):
    """Owner custody: Codex's Checkout gateway, the payment extension and the chargeback mapper."""
    environ = os.environ if environ is None else environ
    path, config = load_config(directory)
    checkout = config['checkout_policy']
    need(not checkout.get('livemode') or (config['allow_live'] and live), 'STRIPE_LIVE_NOT_ADOPTED')
    transport = payments.StripePaymentTransport(lambda: environ[config['key_env']], livemode=checkout.get('livemode'),
                                                allow_live=config['allow_live'] and live, origin=config['origin'],
                                                loopback_harness=config['harness'], timeout=config['timeout'])
    gateway = StripeGateway(path / 'custody', checkout, transport, clock=clock,
                            webhook_secret=lambda: environ[config['webhook_env']])
    try:
        owner = payments.StripePayments(gateway, config['payment_policy'],
                                        approval_policies=config['approval_policies'], clock=clock)
        owner.observe_evidence(disputes.Chargebacks(owner))
    except BaseException:
        gateway.close()
        raise
    return config, gateway, owner


def refusal(error):
    code = _code(error)
    body = {'error': action.explain(code), 'execution_authorized': False}
    if isinstance(error, payments.Refusal) and error.details:
        body['details'] = error.details
    return STATUS.get(code, 400), body


class Service:
    """One owner process: request handling, a reconciliation loop and operator observability."""

    def __init__(self, directory, *, environ=None, live=False, clock=None, reconcile_every=60):
        self.config, self.gateway, self.payments = open_owner(directory, environ=environ, live=live, clock=clock)
        self.environ = os.environ if environ is None else environ
        self.recovered = self.payments.recover()
        self.ops = Ops('stripe-gateway', routes=[*sorted({path for _, path in ROUTES}), OPERATION_PATH + '{id}'])
        self.ops.health.add('custody', writable_directory(str(Path(directory) / 'custody')))
        self.ops.health.add('credentials', lambda: True if self.config['key_env'] in self.environ and
                            self.config['webhook_env'] in self.environ else 'CREDENTIAL_NOT_CONFIGURED')
        self.ops.storage('custody', [Path(directory) / 'custody'])

        def snapshot(name):
            return lambda: {(key,): value for key, value in self.payments.snapshot()[name].items()}
        self.ops.metrics.gauge('aap_stripe_payment_operations', 'Payment actions in owner custody, by state.',
                               ('state',), fn=snapshot('states'))
        self.ops.metrics.gauge('aap_stripe_payment_approvals', 'Owner approval requests not yet used, by status.',
                               ('status',), fn=snapshot('approvals'))
        self.ops.metrics.gauge('aap_stripe_payment_reserved_minor_units', 'Amounts held by reservations.',
                               ('operation',), fn=snapshot('reserved'))
        self.ops.metrics.gauge('aap_stripe_payment_open_disputes', 'Provider disputes not yet closed.',
                               fn=lambda: self.payments.snapshot()['open_disputes'])
        self.every = reconcile_every
        self.stopping = threading.Event()
        self.server = None

    def handle(self, method, target, headers, raw):
        path = urlsplit(target).path
        name = ROUTES.get((method, path))
        if name is None and method == 'GET' and path[:len(OPERATION_PATH)] == OPERATION_PATH:
            name = 'inspect'
        if name is None:
            return 404, {'error': action.explain('STRIPE_SERVICE_ROUTE'), 'execution_authorized': False}
        try:
            if name == 'inspect':
                return 200, self.payments.inspect(path[len(OPERATION_PATH):])
            if name == 'gateway':
                return 200, self.payments.describe()
            if name == 'event':
                return 200, self.event(raw, headers.get('Stripe-Signature', ''))
            value = loads(raw)
            if name == 'submit':
                need(type(value) is dict and set(value) <= {'record', 'chain', 'authorization', 'approval'} and
                     'record' in value, 'STRIPE_PAYMENT_RECORD')
                result = self.payments.submit(value['record'], chain=value.get('chain', []),
                                              authorization=value.get('authorization'), approval=value.get('approval'))
                self.ops.log.event('stripe_operation', state=result['state'], operation=result['operation'],
                                   code=result['code'])
                return 200, result
            if name == 'approval':
                return 200, self.payments.store_approval(value)
            need(type(value) is dict and set(value) == {'kind', 'value'}, 'STRIPE_PAYMENT_SOURCE')
            return 200, {'reference': self.payments.add_source(value['kind'], value['value']),
                         'credential_returned': False, 'execution_authorized': False}
        except (ValueError, TypeError, KeyError, OSError) as error:
            status, body = refusal(error)
            self.ops.refusal(body['error']['code'])
            return status, body
        except Exception:  # Durable state is already written; the caller may resend the same signed action.
            self.ops.log.event('request_failed', 'error', route=name)
            self.ops.refusal('STRIPE_SERVICE_FAILED')
            return 500, {'error': action.explain('STRIPE_SERVICE_FAILED'), 'execution_authorized': False}

    def event(self, raw, header):
        """Payment, refund and dispute events go to the extension; Checkout events to Codex's gateway."""
        try:
            return self.payments.ingest_event(raw, header)
        except ValueError as error:
            if str(error) != 'STRIPE_PAYMENT_EVENT_SCOPE':
                raise
        event = _parse(raw)
        value = (event.get('data') or {}).get('object') if type(event.get('data')) is dict else None
        need(type(event.get('type')) is str and event['type'][:17] == 'checkout.session.' and type(value) is dict,
             'STRIPE_PAYMENT_EVENT_SCOPE')
        metadata = value.get('metadata') if type(value.get('metadata')) is dict else {}
        effect = metadata.get('aap_intent')
        need(type(effect) is str and action.HEX.fullmatch(effect) is not None, 'STRIPE_PAYMENT_EVENT_SCOPE')
        observed = self.gateway.ingest_event(effect, raw, header)
        return {'event': event.get('id'), 'route': 'checkout', 'reference': effect, 'phase': observed['phase'],
                'execution_authorized': False}

    def loop(self):
        while not self.stopping.wait(self.every):
            try:
                self.payments.reconcile_due()
            except Exception as error:  # A failed pass is logged and retried; it never changes a state by itself.
                self.ops.log.event('reconcile_failed', 'warning', code=_code(error))

    def serve(self, port):
        service = self

        class Handler(Instrumented, BaseHTTPRequestHandler):
            server_version = 'aap-stripe-gateway'
            sys_version = ''
            ops = service.ops

            def log_message(self, *args):
                pass

            def respond(self, status, body):
                raw = json.dumps(body, sort_keys=True, separators=(',', ':')).encode('ascii')
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(raw)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                self.respond(*service.handle('GET', self.path, self.headers, b''))

            def do_POST(self):
                limit = MAX_EVENT if urlsplit(self.path).path == EVENTS_PATH else MAX_JSON
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                except ValueError:
                    length = -1
                if not 0 <= length <= limit:
                    return self.respond(413, {'error': action.explain('STRIPE_SERVICE_SIZE'),
                                              'execution_authorized': False})
                self.respond(*service.handle('POST', self.path, self.headers, self.rfile.read(length)))
        self.server = BoundedHTTPServer(('127.0.0.1', port), Handler, max_connections=16, connection_seconds=60)
        self.server.ops = self.ops
        worker = threading.Thread(target=self.loop, name='stripe-reconcile', daemon=True)
        worker.start()
        return self.server.server_address[1]

    def close(self):
        self.stopping.set()
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
        self.ops.close()
        self.gateway.close()


def describe():
    return {'service': 'stripe-gateway', 'profile': CONFIG_VERSION, 'listener': '127.0.0.1 only',
            'routes': {**{'%s %s' % key: name for key, name in sorted(ROUTES.items())},
                       'GET ' + OPERATION_PATH + '{operation_id}': 'inspect', 'GET /healthz': 'liveness',
                       'GET /readyz': 'readiness'},
            'bounds': {'json_bytes': MAX_JSON, 'event_bytes': MAX_EVENT, 'connections': 16, 'connection_seconds': 60},
            'agent_may': ['read what it needs to draft an action', 'submit a signed covenant-stripe-payment-action/0.1 '
                          'with its grant chain and the payer authorisation', 'read one operation'],
            'agent_may_not': ['read or set credentials', 'approve its own action', 'change policy or budget',
                              'resolve an UNKNOWN outcome'],
            'action': action.describe(), 'payments': payments.describe(), 'disputes': disputes.describe(),
            'credentials_in_output': False, 'execution_authorized': False}


def _read_json(path, limit=4 * 1024 * 1024):
    with open(path, 'rb') as stream:
        raw = stream.read(limit + 1)
    need(len(raw) <= limit, 'STRIPE_PAYMENT_RECORD_PROFILE')
    return json.loads(raw)


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_agent.stripe_service',
        description='Owner Stripe gateway: a separate loopback service and owner commands. No credential is printed.')
    commands = parser.add_subparsers(dest='command', required=True)
    served = commands.add_parser('serve', help='Run the gateway service on 127.0.0.1.')
    served.add_argument('--directory', required=True)
    served.add_argument('--port', type=int, required=True)
    served.add_argument('--reconcile-every', type=int, default=60)
    served.add_argument('--live', action='store_true', help='Allow live mode when the owner config also adopts it.')
    add_arguments(served)
    approving = commands.add_parser('approve', help='Show a pending approval; with --confirm, sign and store it.')
    approving.add_argument('--directory', required=True)
    approving.add_argument('--occurrence', required=True)
    approving.add_argument('--key-file', help='Owner approval Ed25519 seed hex file, mode 0600. Never printed.')
    approving.add_argument('--confirm', help='The rendering SHA-256 you read.')
    approving.add_argument('--decision', choices=('approve', 'refuse'), default='approve')
    status = commands.add_parser('status', help='Counts and readiness; --prometheus for metrics text.')
    status.add_argument('--directory', required=True)
    status.add_argument('--prometheus', action='store_true')
    exported = commands.add_parser('export', help='Print the portable record of one agreement.')
    exported.add_argument('--directory', required=True)
    exported.add_argument('--agreement', required=True)
    checked = commands.add_parser('verify', help='Verify a portable record offline.')
    checked.add_argument('--record', required=True)
    checked.add_argument('--principal', required=True)
    checked.add_argument('--agreement', required=True)
    backed = commands.add_parser('backup', help='Copy the custody database into a new 0600 file.')
    backed.add_argument('--directory', required=True)
    backed.add_argument('--out', required=True)
    commands.add_parser('describe', help='What agents and owners can do here.')
    args = parser.parse_args(argv)
    try:
        if args.command == 'describe':
            result = describe()
        elif args.command == 'verify':
            result = payments.verify_record(_read_json(args.record), expected_principal=args.principal,
                                            expected_agreement=args.agreement)
        elif args.command == 'serve':
            service = Service(args.directory, live=args.live, reconcile_every=max(1, args.reconcile_every))
            start(service.ops, args)
            port = service.serve(args.port)
            print(json.dumps({'listening': '127.0.0.1', 'port': port, 'recovered': len(service.recovered)}),
                  flush=True)
            stop = threading.Event()
            for name in ('SIGTERM', 'SIGINT'):
                signal.signal(getattr(signal, name), lambda *_: stop.set())
            threading.Thread(target=service.server.serve_forever, kwargs={'poll_interval': 0.2}, daemon=True).start()
            stop.wait()
            service.close()
            return 0
        else:
            config, gateway, owner = open_owner(args.directory)
            try:
                if args.command == 'approve':
                    shown = owner.approval_rendering(args.occurrence)
                    if args.confirm is None:
                        sys.stdout.write(shown['text'] + 'Rendering SHA-256: ' + shown['sha256'] + '\n')
                        return 0
                    need(args.confirm == shown['sha256'], 'STRIPE_PAYMENT_APPROVAL_CHANGED')
                    need(args.key_file is not None, 'ASSENT_KEY_FILE')
                    from .assent_gate import _key_file
                    record = payments.sign_approval(shown['request'], _key_file(args.key_file),
                                                    'APPROVE' if args.decision == 'approve' else 'REFUSE')
                    try:
                        result = owner.store_approval(record)
                    except ValueError as error:
                        if str(error) != 'STRIPE_PAYMENT_APPROVAL_REFUSED' or args.decision != 'refuse':
                            raise
                        result = {'occurrence': args.occurrence, 'status': 'REFUSED', 'stored': True}
                    result = {**result, 'private_keys_in_output': False}
                elif args.command == 'status':
                    snapshot = owner.snapshot()
                    if args.prometheus:
                        sys.stdout.write(payments.prometheus(snapshot))
                        return 0
                    result = {'format': CONFIG_VERSION, **snapshot, 'policy': owner.id,
                              'credential_present': config['key_env'] in os.environ,
                              'webhook_secret_present': config['webhook_env'] in os.environ,
                              'credential_values_read': False, 'execution_authorized': False}
                elif args.command == 'export':
                    result = owner.portable_record(args.agreement)
                else:
                    result = {'backup': owner.backup(args.out), 'execution_authorized': False}
            finally:
                gateway.close()
    except (ValueError, TypeError, KeyError, OSError) as error:
        code = _code(error, 'STRIPE_SERVICE_FAILED')
        print(json.dumps({'error': action.explain(code), 'execution_authorized': False}, sort_keys=True),
              file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
