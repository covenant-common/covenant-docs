"""Thin framework kits over the same five tools.

Each kit is data. Nothing here imports a framework SDK or calls a model.
The spend guardrail suggests a covenant above a threshold and does not move funds.
"""
from .errors import need
from .mcp import tool_descriptors
from .settlement import require_stablecoin

PROFILE = 'covenant-framework-kit/0.1'
GUARD_PROFILE = 'covenant-spend-guardrail/0.1'
FIVE = (
    'covenant_propose', 'covenant_accept', 'covenant_deliver', 'covenant_verify', 'covenant_settle',
)
KIT_IDS = (
    'openai-agents', 'langchain', 'crewai', 'autogen', 'google-adk', 'vercel-ai', 'claude-mcp',
)


def five_tools():
    """The five verbs from the MCP descriptor list. ``covenant_once`` stays off."""
    found = [tool for tool in tool_descriptors(include_once=False) if tool['name'] in FIVE]
    need(tuple(tool['name'] for tool in found) == FIVE, 'FIELDS')
    return found


def spend_guard(*, amount, threshold, unit='USDC'):
    """Suggest ``covenant_propose`` when the amount is above the threshold.

    Equal to the threshold does not suggest. This function does not spend.
    """
    require_stablecoin(unit)
    need(type(amount) is int and type(threshold) is int and amount >= 0 and threshold >= 0, 'QUANTITY')
    over = amount > threshold
    call = None
    if over:
        call = {'name': 'covenant_propose', 'arguments': {'quantity': amount, 'unit': unit, 'rail': 'x402'}}
    return {
        'profile': GUARD_PROFILE,
        'over_threshold': over,
        'suggest': 'covenant_propose' if over else None,
        'tool_call': call,
        'amount': amount,
        'threshold': threshold,
        'unit': unit,
        'spent': False,
        'funds_moved': False,
        'submitted': False,
        'execution_authorized': False,
    }


def _survival():
    return {
        'improves': 'FRAMEWORK_REACH',
        'dependency': 'HOST_BINDS_CALLBACKS',
        'retire': 'DROP_THE_KIT_FIVE_TOOLS_REMAIN',
    }


def _base(kit_id, tools):
    return {
        'profile': PROFILE,
        'id': kit_id,
        'tools': tools,
        'tool_names': [tool['name'] for tool in five_tools()],
        'spend_guardrail': GUARD_PROFILE,
        'imports_framework': False,
        'models_called': False,
        'survival': _survival(),
    }


def _openai(descriptors):
    tools = [{'type': 'function', 'name': tool['name'], 'description': tool['description'],
              'parameters': tool['inputSchema'], 'strict': False} for tool in descriptors]
    return {**_base('openai-agents', tools), 'sdk': 'OpenAI Agents SDK',
            'note': 'Host binds the callbacks. This kit does not import openai.'}


def _langchain(descriptors):
    tools = [{'name': tool['name'], 'description': tool['description'], 'args_schema': tool['inputSchema']}
             for tool in descriptors]
    graph = {'nodes': [tool['name'] for tool in descriptors], 'compiled': False, 'checkpointer': None}
    return {**_base('langchain', tools), 'sdk': 'LangChain', 'langgraph': graph,
            'note': 'LangGraph uses the same schemas. This kit does not import langchain or langgraph.'}


def _crewai(descriptors):
    tools = [{'name': tool['name'], 'description': tool['description'], 'args_schema': tool['inputSchema']}
             for tool in descriptors]
    return {**_base('crewai', tools), 'sdk': 'CrewAI',
            'note': 'Host binds the callbacks. This kit does not import crewai.'}


def _autogen(descriptors):
    tools = [{'type': 'function', 'function': {'name': tool['name'], 'description': tool['description'],
              'parameters': tool['inputSchema']}} for tool in descriptors]
    return {**_base('autogen', tools), 'sdk': 'AutoGen/AG2',
            'note': 'AG2 function tools. This kit does not import autogen.'}


def _adk(descriptors):
    tools = [{'name': tool['name'], 'description': tool['description'], 'parameters': tool['inputSchema']}
             for tool in descriptors]
    return {**_base('google-adk', tools), 'sdk': 'Google ADK',
            'note': 'Function declarations. This kit does not import google.adk.'}


def _vercel(descriptors):
    tools = {tool['name']: {'description': tool['description'], 'inputSchema': tool['inputSchema']}
             for tool in descriptors}
    return {**_base('vercel-ai', tools), 'sdk': 'Vercel AI SDK',
            'note': 'JSON form of tool(). This kit does not import the Vercel AI SDK.'}


def _claude(descriptors):
    tools = [{'name': tool['name'], 'description': tool['description'], 'inputSchema': tool['inputSchema']}
             for tool in descriptors]
    return {**_base('claude-mcp', tools), 'sdk': 'Claude MCP',
            'server': 'python3 -m covenant_agent.server', 'transport': 'stdio', 'protocol': 'MCP',
            'new_server': False,
            'note': 'Use the existing MCP tool list. This kit does not start a second protocol.'}


_BUILDERS = {
    'openai-agents': _openai,
    'langchain': _langchain,
    'crewai': _crewai,
    'autogen': _autogen,
    'google-adk': _adk,
    'vercel-ai': _vercel,
    'claude-mcp': _claude,
}


def framework_kit(name):
    need(name in _BUILDERS, 'FIELDS')
    return _BUILDERS[name](five_tools())


def framework_kits():
    return {name: framework_kit(name) for name in KIT_IDS}
