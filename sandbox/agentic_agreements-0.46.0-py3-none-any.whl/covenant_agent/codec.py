"""Canonical JSON and Ed25519, matching covenant_chain.crypto for this subset.

The SDK wheel does not import the chain package. The same labels and the same
byte encoding are what make a Python signature verify in the TypeScript SDK.
"""
import hashlib
import json
import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .errors import NativeError, need

MAX_BYTES = 4_000_000
HEX = re.compile(r'[0-9a-f]{64}\Z')
SIG = re.compile(r'[0-9a-f]{128}\Z')
P = 2**255 - 19
D = -121665 * pow(121666, P - 2, P) % P
I = pow(2, (P - 1) // 4, P)


def valid_ed25519_key(encoded):
    """Same admission rule as covenant_language.key_validation."""
    if type(encoded) is not str or len(encoded) != 64:
        return False
    try:
        raw = bytes.fromhex(encoded)
    except ValueError:
        return False
    if len(raw) != 32 or raw.hex() != encoded:
        return False
    n = int.from_bytes(raw, 'little')
    sign = n >> 255
    y = n & ((1 << 255) - 1)
    if y >= P:
        return False
    yy = y * y % P
    denominator = (D * yy + 1) % P
    if denominator == 0:
        return False
    xx = (yy - 1) * pow(denominator, P - 2, P) % P
    x = pow(xx, (P + 3) // 8, P)
    if x * x % P != xx:
        x = x * I % P
    if x * x % P != xx or (x == 0 and sign):
        return False
    if x & 1 != sign:
        x = P - x
    for _ in range(3):
        product = D * x * x * y * y % P
        dx, dy = (1 + product) % P, (1 - product) % P
        if dx == 0 or dy == 0:
            return False
        x, y = (2 * x * y * pow(dx, P - 2, P) % P, (y * y + x * x) * pow(dy, P - 2, P) % P)
    return (x, y) != (0, 1)


def check(value, depth=0):
    need(depth <= 40, 'DEPTH_LIMIT')
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        need(abs(value) <= 2**53 - 1, 'INTEGER_RANGE')
    elif type(value) is str:
        need(len(value) <= 100000 and all(32 <= ord(c) <= 126 for c in value), 'ASCII_PROFILE')
    elif type(value) is list:
        need(len(value) <= 20000, 'ARRAY_LIMIT')
        for item in value:
            check(item, depth + 1)
    elif type(value) is dict:
        need(len(value) <= 20000, 'MAP_LIMIT')
        for key, item in value.items():
            need(type(key) is str and len(key) <= 256 and all(32 <= ord(c) <= 126 for c in key), 'MAP_KEY')
            check(item, depth + 1)
    else:
        raise NativeError('TYPE')


def canonical(obj):
    check(obj)
    raw = json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')
    need(len(raw) <= MAX_BYTES, 'SIZE_LIMIT')
    return raw


def loads(raw):
    need(isinstance(raw, (str, bytes)) and len(raw) <= MAX_BYTES, 'SIZE_LIMIT')

    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, 'DUPLICATE_KEY')
            out[key] = value
        return out

    def bad(_value):
        raise NativeError('NONINTEGER_NUMBER')

    try:
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        need(not raw.startswith('\ufeff'), 'JSON_BOM')
        obj = json.loads(raw, object_pairs_hook=pairs, parse_float=bad, parse_constant=bad)
    except NativeError:
        raise
    except (RecursionError, UnicodeError, json.JSONDecodeError) as exc:
        raise NativeError('INVALID_JSON') from exc
    canonical(obj)
    return obj


def digest(label, obj):
    return hashlib.sha256(label.encode('ascii') + b'\0' + canonical(obj)).hexdigest()


def sha256_hex(raw):
    need(isinstance(raw, (bytes, bytearray)), 'CONTENT_SIZE')
    return hashlib.sha256(bytes(raw)).hexdigest()


def public_key(private):
    return private.public_key().public_bytes_raw().hex()


def key_from_seed(seed_hex):
    need(type(seed_hex) is str and bool(HEX.fullmatch(seed_hex)), 'PUBLIC_KEY')
    return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(seed_hex))


def sign(private, label, body):
    return private.sign(label.encode('ascii') + b'\0' + canonical(body)).hex()


def verify(public, label, body, signature):
    need(type(public) is str and bool(HEX.fullmatch(public)) and valid_ed25519_key(public), 'PUBLIC_KEY')
    need(type(signature) is str and bool(SIG.fullmatch(signature)), 'SIGNATURE_ENCODING')
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(
            bytes.fromhex(signature), label.encode('ascii') + b'\0' + canonical(body))
    except (ValueError, InvalidSignature) as exc:
        raise NativeError('SIGNATURE') from exc
    return True


def exact(obj, fields):
    need(type(obj) is dict and set(obj) == set(fields.split()), 'FIELDS')


def signature_ok(public, label, body, signature):
    try:
        return verify(public, label, body, signature)
    except NativeError:
        return False
