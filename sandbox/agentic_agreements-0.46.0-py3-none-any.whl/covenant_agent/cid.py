"""CIDv1 for raw SHA-256 bytes. Multibase base32, prefix ``b``.

This is codec 0x55 (raw), not dag-pb. A gateway that hashes the same bytes as
dag-pb will produce a different CID. ``sha256:<hex>`` is accepted as an alias
for lookup. The id this package returns is always the CIDv1.

Every identifier names its hash scheme. A CIDv1 already carries it in the
multihash prefix (0x12 = ``sha2-256``) and the multicodec (0x55 = ``raw``);
``HASH_SCHEME`` and ``describe_cid`` spell those names out, so a later
``sha3-256`` or ``blake3`` id is a new scheme name, not a silent change. The
bytes of every CID this module has issued are unchanged.
"""
import base64
import hashlib

from .errors import NativeError, need

RAW = 0x55
SHA2_256 = 0x12
HASH_SCHEME = 'sha2-256'
CODEC = 'raw'
MULTIBASE = 'base32'
CID_SCHEME = 'cidv1-raw-sha2-256-base32'
ALIAS_PREFIX = 'sha256:'
# Multihash and multicodec names this module can parse. Unknown codes are refused.
MULTIHASH_NAMES = {SHA2_256: HASH_SCHEME}
MULTICODEC_NAMES = {RAW: CODEC}


def cid_from_bytes(data):
    need(isinstance(data, (bytes, bytearray)) and len(data) > 0, 'CONTENT_SIZE')
    digest = hashlib.sha256(bytes(data)).digest()
    multihash = bytes([SHA2_256, 32]) + digest
    packed = bytes([1, RAW]) + multihash
    text = base64.b32encode(packed).decode('ascii').lower().rstrip('=')
    return 'b' + text


def parse_cid(value):
    """Return the 32-byte SHA-256 named by a CID or a sha256: alias."""
    need(type(value) is str and 0 < len(value) <= 128, 'CID')
    if value.startswith('sha256:'):
        hex_digest = value[7:]
        need(len(hex_digest) == 64 and all(c in '0123456789abcdef' for c in hex_digest), 'CID')
        return bytes.fromhex(hex_digest)
    need(value.startswith('b') and len(value) > 1, 'CID')
    body = value[1:].upper()
    pad = '=' * ((8 - len(body) % 8) % 8)
    try:
        decoded = base64.b32decode(body + pad, casefold=False)
    except Exception as exc:
        raise NativeError('CID') from exc
    need(len(decoded) == 36 and decoded[0] == 1 and decoded[1] == RAW, 'CID')
    multihash = decoded[2:]
    need(multihash[0] == SHA2_256 and multihash[1] == 32, 'CID')
    return multihash[2:]


def cid_matches(cid, blob):
    return parse_cid(cid) == hashlib.sha256(bytes(blob)).digest()


def describe_cid(value):
    """Name the scheme of a CID or ``sha256:`` alias. The id is not changed or re-encoded."""
    digest = parse_cid(value)
    alias = value.startswith(ALIAS_PREFIX)
    return {
        'id': value,
        'form': 'SHA256_ALIAS' if alias else 'CIDV1',
        'cid_version': None if alias else 1,
        'multibase': None if alias else MULTIBASE,
        'codec': None if alias else MULTICODEC_NAMES[RAW],
        'hash': MULTIHASH_NAMES[SHA2_256],
        'multihash_code': SHA2_256,
        'digest_bytes': len(digest),
        'scheme': ALIAS_PREFIX[:-1] if alias else CID_SCHEME,
        'canonical_cid': cid_from_digest(digest),
    }


def cid_from_digest(digest):
    """CIDv1 for an existing SHA-256 digest. Same bytes as ``cid_from_bytes`` would give."""
    need(isinstance(digest, (bytes, bytearray)) and len(digest) == 32, 'CID')
    packed = bytes([1, RAW]) + bytes([SHA2_256, 32]) + bytes(digest)
    return 'b' + base64.b32encode(packed).decode('ascii').lower().rstrip('=')
