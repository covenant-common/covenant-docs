"""Hosting-independent identifiers for new adoptions; historical bytes stay exact.

Aliases are this registry's explicit statements of intended equivalence. They
never rewrite an old signature, activate an extension or dereference a URL.
"""
from copy import deepcopy
from .codec import digest
from .errors import need

PROFILE = 'covenant-protocol-identifiers/0.1'
ENTRIES = (
    {'urn': 'urn:aap:protocol:required-a2a-agreement:0.1', 'profile': 'covenant-required-a2a-agreement/0.1',
     'aliases': ['https://github.com/malik-degen/covenant/blob/main/docs/REQUIRED_A2A_AGREEMENTS.html#covenant-required-a2a-agreement-0.1'],
     'rule': 'NEW_ADOPTION_MUST_PIN_EXACT_WIRE_EXTENSION_URI; OLD_SIGNATURES_ARE_NOT_REWRITTEN'},
    {'urn': 'urn:aap:protocol:work-order:0.3', 'profile': 'covenant-work-order/0.3', 'aliases': [],
     'rule': 'EXPLICIT_NEW_PROFILE; NO_HISTORICAL_REINTERPRETATION'},
    {'urn': 'urn:aap:protocol:portable-trust:0.1', 'profile': 'covenant-portable-trust/0.1', 'aliases': [],
     'rule': 'EXPERIMENTAL_OWNER_ADOPTION_REQUIRED'},
    {'urn': 'urn:aap:protocol:commerce-agreement:0.1', 'profile': 'urn:aap:commerce-agreement:0.1',
     'aliases': ['io.github.covenant-common.shopping.agreement@2026-10-25'],
     'rule': 'OPTIONAL_ACP_AND_UCP_CHECKOUT_EXTENSION; CHECKOUT_ORDER_AND_PAYMENT_MESSAGES_ARE_EVIDENCE_NOT_AUTHORITY'},
    {'urn': 'urn:aap:protocol:delivery-receipt:0.1', 'profile': 'urn:aap:delivery-receipt:0.1', 'aliases': [],
     'rule': 'BUYER_SIGNED_OBSERVATIONS; VERDICT_RECOMPUTED_AGAINST_TYPED_CRITERIA'},
    {'urn': 'urn:aap:rail:mpp:1', 'profile': 'urn:aap:mpp-pricing:0.1', 'aliases': [],
     'rule': 'HTTP_402_PAYMENT_AUTHENTICATION_RAIL; AGREED_TYPED_PRICING; RECEIPT_IS_EVIDENCE_NEVER_RELEASE'},
    {'urn': 'urn:aap:protocol:ap2-release-condition:0.2', 'profile': 'urn:aap:ap2-release-condition:0.2', 'aliases': [],
     'rule': 'ADOPTED_VERIFIER_REQUIRED_FOR_EXACT_MANDATE_AND_AGREEMENT; VERIFIED_DELIVERY; NEVER_PAYS'},
    {'urn': 'urn:aap:protocol:ap2-release-condition:0.1', 'profile': 'urn:aap:ap2-release-condition:0.1', 'aliases': [],
     'rule': 'RELEASE_ONLY_ON_VERIFIED_AAP_DELIVERY_RECEIPT; DECISION_RECORD_NEVER_PAYS'},
)


def catalog():
    return {'profile': PROFILE, 'entries': deepcopy(list(ENTRIES)),
            'registry_hash': digest(PROFILE, list(ENTRIES)), 'network_accessed': False,
            'authority_granted': False, 'execution_authorized': False}


def resolve(identifier, expected_registry):
    need(type(identifier) is str and expected_registry == catalog()['registry_hash'], 'IDENTIFIER_REGISTRY_PIN')
    for row in ENTRIES:
        if identifier in [row['urn'], row['profile']] + row['aliases']:
            return {**deepcopy(row), 'input': identifier, 'rewrite_signed_bytes': False,
                    'adoption_required': True, 'execution_authorized': False}
    raise ValueError('IDENTIFIER_UNKNOWN_EXPLICIT_ADOPTION_REQUIRED')
