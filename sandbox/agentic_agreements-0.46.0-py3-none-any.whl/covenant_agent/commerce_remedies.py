"""Post-purchase remedies for AAP commerce agreements: escrow release or refund, or the dispute ladder.

A remedy plan starts from a delivery receipt this module verifies itself (the
buyer's signature, the recomputed verdict and, when supplied, the agreement's
exact assent). It prepares exact requests; it never executes them:

* AAP_ESCROW: the PAYOUT request for the agreed escrow policy
  (covenant_chain.escrow_desk), which still needs the escrow's controller quorum.
* DISPUTE_LADDER: the signed OPEN event payload for the agreed escalation policy
  (covenant_language.agreement_procedures) with the receipt as the claim, and
  later the payout implied by the ladder's final attested outcome.
* RECORD_ONLY: the refund owed under the agreement, compared with refunds the
  merchant itself reported in ACP or UCP order evidence.

Silence, an incomplete receipt or an unverified agreement is UNKNOWN, never a
release or a refund.
"""
from copy import deepcopy

from covenant_language import agreement_application as application_profile
from covenant_language import agreement_procedures as procedures

from . import commerce
from .errors import NativeError

PLAN = 'urn:aap:commerce-remedy:0.1'

HINTS = {
    'REMEDY_ESCROW_POLICY': 'Pass the exact escrow policy record the agreement pins: same id, amount, currency unit, payer (buyer) and payee (seller).',
    'REMEDY_LADDER': 'Pass {policy, adoptions, events} for the escalation policy the agreement pins.',
    'REMEDY_LADDER_POLICY': 'The ladder must be an ESCALATION whose disputants are the agreement buyer and seller keys.',
    'REMEDY_LADDER_OUTCOMES': 'Every ladder outcome needs a refund MONEY term in the agreement currency between 0 and the price.',
    'REMEDY_LADDER_FULL_REFUND': 'The ladder offers no outcome refunding the full price; pass the refund outcome to claim.',
    'REMEDY_LADDER_BOND': 'The first ladder stage requires a bond: pass bond_receipt, the 64-hex reference of the bond payment.',
    'REMEDY_EVIDENCE': 'Pass merchant order evidence exactly as returned by the ACP or UCP adapter for this agreement.',
    'REMEDY_NOT_APPLICABLE': 'This remedy kind does not take that input.',
}


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS.get(code) or commerce.HINTS[code])


def _escrow(t, policy):
    from covenant_language import marketplace
    need(type(policy) is dict, 'REMEDY_ESCROW_POLICY')
    try:
        ref = marketplace.identifier(policy)
    except ValueError:
        raise NativeError('REMEDY_ESCROW_POLICY', HINTS['REMEDY_ESCROW_POLICY']) from None
    data = policy['data']
    need(policy['kind'] == 'ESCROW_POLICY' and ref == t['remedy_reference'] and data['amount'] == t['amount'] and
         data['payer'] == t['parties']['buyer'] and data['payee'] == t['parties']['seller'] and
         str(data['asset']['unit']).lower() == t['currency'].lower(), 'REMEDY_ESCROW_POLICY')
    return ref, data


def payout(t, policy, refund):
    """Exact escrow PAYOUT allocation: refund to the buyer, the rest to the seller."""
    ref, data = _escrow(t, policy)
    need(type(refund) is int and 0 <= refund <= t['amount'], 'REMEDY_ESCROW_POLICY')
    payouts = {key: amount for key, amount in ((data['payer'], refund), (data['payee'], t['amount'] - refund)) if amount}
    if not payouts:
        payouts = {data['payee']: 0}
    return {'request': {'action': 'PAYOUT', 'escrow': ref, 'payouts': payouts},
            'quorum': {'controllers': deepcopy(data['controllers']), 'threshold': data['threshold']},
            'next': 'covenant_escrow.assent_payload with the owner-installed escrow adapter; the controller quorum signs; '
                    'the adapter executes. This plan signs and moves nothing.'}


def ladder_roles(t, policy):
    """Map the ladder's disputant roles to the agreement's buyer and seller keys; check refund outcomes."""
    try:
        ref = procedures.identifier(policy)
    except ValueError:
        raise NativeError('REMEDY_LADDER_POLICY', HINTS['REMEDY_LADDER_POLICY']) from None
    need(policy['kind'] == 'ESCALATION' and ref == t['remedy_reference'], 'REMEDY_LADDER_POLICY')
    c = policy['configuration']
    keys = {application_profile.canonical(policy['parties'][role]): role for role in c['disputants']}
    buyer = keys.get(application_profile.canonical(t['parties']['buyer']))
    seller = keys.get(application_profile.canonical(t['parties']['seller']))
    need(buyer is not None and seller is not None and buyer != seller, 'REMEDY_LADDER_POLICY')
    for outcome in c['outcomes']:
        refund = outcome.get('refund')
        need(type(refund) is dict and refund.get('kind') == 'MONEY' and refund.get('unit') == t['currency'] and
             0 <= refund.get('amount', -1) <= t['amount'], 'REMEDY_LADDER_OUTCOMES')
    return ref, buyer, seller


def _refunds_reported(t, rows):
    """Merchant-reported completed refunds in ACP or UCP order evidence for this agreement."""
    need(type(rows) is list and len(rows) <= 32, 'REMEDY_EVIDENCE')
    latest = 0
    for row in rows:
        need(type(row) is dict and type(row.get('record')) is dict, 'REMEDY_EVIDENCE')
        record = row['record']
        need(row.get('id') == application_profile.content_id('AAP-COMMERCE-EVIDENCE-0.1', record) and
             record.get('version') == commerce.EVIDENCE and record.get('agreement') == t['application'] and
             record.get('protocol') in ('ACP', 'UCP') and record.get('kind') == 'ORDER_EVENT' and
             type(record.get('summary')) is dict, 'REMEDY_EVIDENCE')
        total = 0
        for adjustment in commerce.items(record['summary'].get('adjustments')):
            if type(adjustment) is not dict:
                continue
            if adjustment.get('type') == 'refund' and adjustment.get('status') == 'completed':
                if record['protocol'] == 'ACP' and type(adjustment.get('amount')) is int and \
                        str(adjustment.get('currency')).lower() == t['currency'].lower():
                    total += adjustment['amount']
                elif record['protocol'] == 'UCP' and type(adjustment.get('total')) is int:
                    total += -adjustment['total'] if adjustment['total'] < 0 else 0
        # Orders are full snapshots; the largest reported cumulative refund is the latest claim.
        latest = max(latest, total)
    return latest


def plan(application, agreement, receipt, adoption, *, escrow_policy=None, ladder=None, at=None, refund_outcome=None,
         bond_receipt=None, merchant_evidence=None):
    """The next remedy step after a delivery receipt. Prepares requests; executes nothing."""
    t = commerce.terms(application)
    checked = commerce.verify_receipt(application, agreement, receipt, adoption)
    base = {'version': PLAN, 'agreement': agreement, 'application': t['application'], 'remedy': t['remedy'],
            'receipt': checked['receipt'], 'verdict': checked['verdict'], 'agreement_adoption': checked['agreement_adoption']}
    if checked['agreement_adoption'] != 'VERIFIED' or checked['verdict'] == 'INCOMPLETE':
        return {**base, 'decision': 'UNKNOWN', 'reason': 'RECEIPT_INCOMPLETE_OR_AGREEMENT_ASSENT_NOT_VERIFIED', **commerce.FLAGS}
    decision = 'RELEASE' if checked['verdict'] == 'MEETS' else 'REFUND'
    out = {**base, 'decision': decision, 'amount': t['amount'], 'currency': t['currency'], 'action': None}
    if t['remedy'] == 'AAP_ESCROW':
        need(ladder is None and merchant_evidence is None, 'REMEDY_NOT_APPLICABLE')
        out['action'] = payout(t, escrow_policy, 0 if decision == 'RELEASE' else t['amount']) if escrow_policy is not None else \
            {'request': None, 'missing': 'ESCROW_POLICY_RECORD', 'escrow': t['remedy_reference']}
    elif t['remedy'] == 'DISPUTE_LADDER' and decision == 'REFUND':
        need(escrow_policy is None and merchant_evidence is None, 'REMEDY_NOT_APPLICABLE')
        out['action'] = {'request': None, 'missing': 'LADDER_POLICY_ADOPTIONS_AND_EVENTS', 'ladder': t['remedy_reference']}
        if ladder is not None:
            out['action'] = open_dispute(t, ladder, checked['receipt'], at, refund_outcome, bond_receipt)
    elif t['remedy'] == 'RECORD_ONLY' and decision == 'REFUND':
        need(escrow_policy is None and ladder is None, 'REMEDY_NOT_APPLICABLE')
        reported = _refunds_reported(t, merchant_evidence or [])
        out['action'] = {'refund_owed': t['amount'], 'refund_reported_by_merchant': reported,
                         'outstanding': max(0, t['amount'] - reported),
                         'basis': 'MERCHANT_REPORTED_ADJUSTMENTS_ARE_CLAIMS_NOT_OBSERVED_PAYMENTS'}
    return {**out, **commerce.FLAGS}


def open_dispute(t, ladder, receipt_ref, at, refund_outcome=None, bond_receipt=None):
    """The buyer's signed OPEN event payload on the agreed ladder, claiming with the verified receipt."""
    need(type(ladder) is dict and set(ladder) == {'policy', 'adoptions', 'events'}, 'REMEDY_LADDER')
    policy = ladder['policy']
    ref, buyer, _seller = ladder_roles(t, policy)
    outcomes = policy['configuration']['outcomes']
    if refund_outcome is None:
        full = [o for o in outcomes if o['refund']['amount'] == t['amount']]
        need(len(full) == 1, 'REMEDY_LADDER_FULL_REFUND')
        refund_outcome = full[0]
    stage = policy['configuration']['stages'][0]
    need(bool(stage['bond']) == (bond_receipt is not None), 'REMEDY_LADDER_BOND')
    if bond_receipt is not None:
        commerce._hex(bond_receipt)
    need(type(at) is int and 0 <= at <= commerce.MAX, 'COMMERCE_CLOCK')
    payload = procedures.event_payload(policy, ladder['adoptions'], ladder['events'], buyer, 'OPEN',
                                       {'claim': receipt_ref, 'result': deepcopy(refund_outcome), 'bond_receipt': bond_receipt}, at)
    return {'ladder': ref, 'actor': buyer, 'event_payload': payload,
            'next': 'The buyer signs event_payload.body with its own key; the ladder decides. Bonds stay claims until observed.'}


def ladder_outcome(application, ladder, *, expected_head=None):
    """Turn the ladder's final attested outcome into the refund and release the agreement owes."""
    t = commerce.terms(application)
    need(t['remedy'] == 'DISPUTE_LADDER', 'REMEDY_NOT_APPLICABLE')
    need(type(ladder) is dict and set(ladder) == {'policy', 'adoptions', 'events'}, 'REMEDY_LADDER')
    ref, _buyer, _seller = ladder_roles(t, ladder['policy'])
    state = procedures.replay(ladder['policy'], ladder['adoptions'], ladder['events'], expected_head)
    base = {'version': PLAN, 'application': t['application'], 'ladder': ref, 'head': state['head'], 'status': state['status']}
    if state['status'] == 'CLOSED_UNRESOLVED':
        return {**base, 'decision': 'UNRESOLVED', 'action': None, **commerce.FLAGS}
    if state['status'] != 'FINAL_ATTESTED_OUTCOME':
        return {**base, 'decision': 'PENDING', 'action': None, **commerce.FLAGS}
    refund = state['outcome']['refund']['amount']
    action = {'refund_owed': refund, 'release_owed': t['amount'] - refund,
              'basis': 'LADDER_OUTCOME_IS_A_SIGNED_DECISION; PAYMENT_STILL_NEEDS_ITS_OWN_RAIL_OR_CUSTODY'}
    return {**base, 'decision': 'REFUND' if refund == t['amount'] else 'RELEASE' if refund == 0 else 'SPLIT',
            'refund': refund, 'action': action, **commerce.FLAGS}
