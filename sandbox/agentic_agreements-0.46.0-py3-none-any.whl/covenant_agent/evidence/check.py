"""Check evidence against a policy pinned to a terms hash.

The policy names adapter ids. It does not name a delivery clock. ``check``
never reads a deadline. Confidence basis points become a graded settlement
figure that economics can adopt. Nothing is submitted, and consensus is unchanged.

Chain SHOW and language SHOW are the shapes this result compiles toward.
Witness co-signatures are not identity attestations. An oracle, when one is
used, stays a separate funded service.
"""
import re
from copy import deepcopy

from ..codec import HEX, digest, public_key, sign, signature_ok
from ..errors import need
from .adapters import ADAPTERS, blob_sha256

POLICY = 'covenant-evidence-policy/0.1'
POLICY_LABEL = 'COVENANT-EVIDENCE-POLICY-0.1'
BUNDLE_LABEL = 'COVENANT-EVIDENCE-BUNDLE-0.1'
INTERFACE = 'covenant-evidence-interface/0.1'
_ID = re.compile(r'[A-Za-z0-9_.:-]{1,64}\Z')
_MIME = re.compile(r'[A-Za-z0-9][A-Za-z0-9.+-]{0,64}/[A-Za-z0-9][A-Za-z0-9.+-]{0,80}\Z')
_SOURCE = re.compile(r'[A-Za-z0-9_.:@-]{1,128}\Z')
_MAX_BLOB = 1_000_000


def _int(value):
    need(type(value) is int and not type(value) is bool, 'EVIDENCE_FIELDS')
    return value


def policy_body(terms_hash, adapters, claim, quorum, *, grade_floor_bps=0):
    need(type(terms_hash) is str and bool(HEX.fullmatch(terms_hash)), 'EVIDENCE_FIELDS')
    need(type(adapters) is list and 1 <= len(adapters) <= 16, 'EVIDENCE_FIELDS')
    need(len(set(adapters)) == len(adapters), 'EVIDENCE_FIELDS')
    for adapter in adapters:
        need(type(adapter) is str and 1 <= len(adapter) <= 128, 'EVIDENCE_FIELDS')
    need(type(claim) is dict and set(claim) == {'subject', 'predicate', 'expect'}, 'EVIDENCE_FIELDS')
    need(type(claim['subject']) is str and bool(_ID.fullmatch(claim['subject'])), 'EVIDENCE_FIELDS')
    need(type(claim['predicate']) is str and bool(_ID.fullmatch(claim['predicate'])), 'EVIDENCE_FIELDS')
    need(type(claim['expect']) is dict and 1 <= len(claim['expect']) <= 16, 'EVIDENCE_FIELDS')
    _int(quorum)
    need(0 <= quorum <= 16, 'EVIDENCE_FIELDS')
    _int(grade_floor_bps)
    need(0 <= grade_floor_bps <= 10000, 'EVIDENCE_FIELDS')
    return {
        'adapters': sorted(adapters),
        'claim': {'subject': claim['subject'], 'predicate': claim['predicate'], 'expect': deepcopy(claim['expect'])},
        'grade_floor_bps': grade_floor_bps,
        'profile': POLICY,
        'quorum': quorum,
        'terms_hash': terms_hash,
    }


def pin(terms_hash, adapters, claim, quorum, signers, *, grade_floor_bps=0):
    """Sign the adapter set against the terms hash. This is the BIND pin.

    It is not a chain BIND and it is not submitted.
    """
    need(type(signers) is list and 1 <= len(signers) <= 8, 'EVIDENCE_PIN')
    body = policy_body(terms_hash, adapters, claim, quorum, grade_floor_bps=grade_floor_bps)
    signatures = []
    seen = set()
    for signer in signers:
        who = public_key(signer)
        need(who not in seen, 'EVIDENCE_PIN')
        seen.add(who)
        signatures.append({'signer': who, 'signature': sign(signer, POLICY_LABEL, body)})
    signatures.sort(key=lambda row: row['signer'])
    return {
        'profile': POLICY,
        'body': body,
        'signatures': signatures,
        'pinned_at': 'BIND',
        'submitted': False,
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
    }


def pin_ok(pinned, terms_hash, *, bind_parties=None):
    need(type(pinned) is dict and pinned.get('profile') == POLICY, 'EVIDENCE_PIN')
    body = pinned.get('body')
    signatures = pinned.get('signatures')
    need(type(body) is dict and type(signatures) is list and signatures, 'EVIDENCE_PIN')
    need(body.get('terms_hash') == terms_hash, 'EVIDENCE_PIN')
    fresh = policy_body(body['terms_hash'], body['adapters'], body['claim'], body['quorum'],
                        grade_floor_bps=body['grade_floor_bps'])
    need(fresh == body, 'EVIDENCE_PIN')
    signers = []
    for row in signatures:
        need(type(row) is dict and set(row) == {'signer', 'signature'}, 'EVIDENCE_PIN')
        need(signature_ok(row['signer'], POLICY_LABEL, body, row['signature']), 'EVIDENCE_PIN')
        signers.append(row['signer'])
    need(signers == sorted(set(signers)), 'EVIDENCE_PIN')
    if bind_parties is not None:
        need(type(bind_parties) is list and len(bind_parties) == 2, 'EVIDENCE_PIN')
        need(set(bind_parties) <= set(signers), 'EVIDENCE_PIN')
    return True


def _mime(value):
    need(type(value) is str and bool(_MIME.fullmatch(value)), 'EVIDENCE_FIELDS')


def check(pinned, submissions, *, terms_hash, quantity=None, bind_parties=None, registry=None):
    """Score submissions against the pinned claim.

    ``quantity`` is optional and is used only for the graded amount. A deadline
    is not an input. Same ``source`` collapses to one supporter.
    """
    pin_ok(pinned, terms_hash, bind_parties=bind_parties)
    body = pinned['body']
    books = ADAPTERS if registry is None else registry
    for adapter_id in body['adapters']:
        need(adapter_id in books, 'EVIDENCE_ADAPTER')
    if quantity is not None:
        _int(quantity)
        need(0 <= quantity <= 2**53 - 1, 'EVIDENCE_FIELDS')
    need(type(submissions) is list and len(submissions) <= 32, 'EVIDENCE_FIELDS')
    if body['quorum'] != 0:
        need(1 <= len(submissions), 'EVIDENCE_FIELDS')
    rows = []
    notes = []
    for submission in submissions:
        rows.append(_one(submission, body, books, notes))
    by_source = {}
    for row in rows:
        if not row['supports']:
            continue
        previous = by_source.get(row['source'])
        if previous is None or row['confidence_bps'] > previous['confidence_bps']:
            by_source[row['source']] = row
    supporters = [by_source[key] for key in sorted(by_source)]
    confidence = 0 if not supporters else sum(row['confidence_bps'] for row in supporters) // len(supporters)
    if body['quorum'] == 0:
        # The parties accepted a single source, or none. Do not haircut the fee
        # for corroboration they did not ask for.
        met = True
        pay_bps = 10000
        notes.append('CORROBORATION_OPTIONAL')
    else:
        met = len(supporters) >= body['quorum']
        pay_bps = confidence if met and confidence >= body['grade_floor_bps'] else 0
    amount = None if quantity is None else quantity * pay_bps // 10000
    public = [{
        'adapter': row['adapter'],
        'blob_sha256': row['blob_sha256'],
        'confidence_bps': row['confidence_bps'],
        'mime': row['mime'],
        'provenance_kind': row['provenance_kind'],
        'reason': row['reason'],
        'source': row['source'],
        'supports': row['supports'],
    } for row in rows]
    content_hash = digest(BUNDLE_LABEL, {'rows': public, 'terms_hash': terms_hash})
    stance = 'SUPPORTS' if met else 'CHALLENGES'
    return {
        'profile': INTERFACE,
        'terms_hash': terms_hash,
        'met': met,
        'supporters': len(supporters),
        'quorum': body['quorum'],
        'confidence_bps': confidence,
        'rows': public,
        'notes': notes,
        'graded_settlement': {
            'interface': 'economics.graded_settlement',
            'pay_bps': pay_bps,
            'amount': amount,
            'quantity': quantity,
            'floor_bps': body['grade_floor_bps'],
            'applied': False,
            'consensus_changed': False,
            'execution_authorized': False,
        },
        'show': {
            'op': 'SHOW',
            'content_hash': content_hash,
            'description': 'EVIDENCE',
            'submitted': False,
            'ledger_touched': False,
            'chain_ledger_touched': False,
        },
        'language_show': {
            'kind': 'SHOW',
            'material': content_hash,
            'stance': stance,
            'method': 'evidence_quorum',
        },
        'pinned_at': 'BIND',
        'attestation': 'WITNESS_COSIGNATURE_NOT_IDENTITY_ATTESTATION',
        'oracle': 'SEPARATE_FUNDED_SERVICE_NOT_A_NEW_ORACLE',
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
        'deadline_consulted': False,
    }


def consume(report, receipt, *, payee, quantity):
    """Set applied once a rail receipt has consumed this split.

    The checker still does not move money. A transfer receipt for the payee
    share is the consumption. A held fee, or a receipt for a different sum,
    leaves applied false.
    """
    need(type(report) is dict and report.get('profile') == INTERFACE, 'EVIDENCE_CONSUME')
    need(report.get('applied') is False, 'EVIDENCE_CONSUME')
    graded = report.get('graded_settlement')
    need(type(graded) is dict and graded.get('applied') is False, 'EVIDENCE_CONSUME')
    _int(payee)
    _int(quantity)
    need(0 < payee <= quantity, 'EVIDENCE_CONSUME')
    if graded.get('quantity') is not None:
        need(graded['quantity'] == quantity, 'EVIDENCE_CONSUME')
    need(type(receipt) is dict and receipt.get('status') == 'OBSERVED', 'EVIDENCE_CONSUME')
    value = receipt.get('value')
    need(type(value) is dict and value.get('action') == 'TRANSFER' and value.get('amount') == payee,
         'EVIDENCE_CONSUME')
    out = deepcopy(report)
    settled = deepcopy(graded)
    settled['applied'] = True
    settled['consumed_payee'] = payee
    settled['consumed_refund'] = quantity - payee
    out['graded_settlement'] = settled
    out['applied'] = True
    out['execution_authorized'] = True
    return out


def _one(submission, body, books, notes):
    need(type(submission) is dict, 'EVIDENCE_FIELDS')
    adapter_id = submission.get('adapter')
    source = submission.get('source')
    mime = submission.get('mime')
    blob = submission.get('blob')
    provenance = submission.get('provenance')
    need(type(source) is str and bool(_SOURCE.fullmatch(source)), 'EVIDENCE_FIELDS')
    _mime(mime)
    need(type(blob) is bytes and 1 <= len(blob) <= _MAX_BLOB, 'EVIDENCE_FIELDS')
    kind = provenance.get('kind') if type(provenance) is dict else None
    base = {
        'adapter': adapter_id if type(adapter_id) is str else '',
        'source': source,
        'mime': mime,
        'blob_sha256': blob_sha256(blob),
        'provenance_kind': kind if type(kind) is str else '',
        'supports': False,
        'confidence_bps': 0,
        'reason': 'NOT_PINNED',
    }
    if adapter_id not in body['adapters']:
        return base
    adapter = books.get(adapter_id)
    need(adapter is not None, 'EVIDENCE_ADAPTER')
    reading = adapter.read(blob, mime, provenance, body['claim'])
    for note in reading.get('notes') or []:
        if note not in notes:
            notes.append(note)
    base['supports'] = reading['supports'] is True
    base['confidence_bps'] = reading['confidence_bps'] if base['supports'] else 0
    base['reason'] = reading['reason']
    return base
