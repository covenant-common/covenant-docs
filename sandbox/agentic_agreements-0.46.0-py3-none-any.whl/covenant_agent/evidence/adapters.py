"""Reference evidence adapters. Each one reads only its own claim field.

A delivery clock is not special. Timestamp is one adapter among the others.
Provenance kinds are C2PA, EXIF, DEVICE, ZKTLS, DKIM, WITNESS and HMAC. DKIM does
not query DNS or bind its carried key to an independently trusted domain key.
zkTLS here is a signature over the blob, not a proof. A generic signed reading
does not pin source authority or establish factual truth. The HMAC claim holds
the parties' adopted webhook key; strict image claims may pin an exact signer.
Source labels only deduplicate submissions; they do not prove independence.
This module does not choose the carrier or establish physical delivery.
"""
import hashlib
import hmac
import json
import re

from ..codec import canonical, loads, public_key, sign, signature_ok, valid_ed25519_key
from ..errors import need
from .exif import read_exif

PROVENANCE_LABEL = 'COVENANT-EVIDENCE-PROVENANCE-0.1'
KINDS = ('C2PA', 'EXIF', 'DEVICE', 'ZKTLS', 'DKIM', 'WITNESS', 'HMAC')
_CARRIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}\Z')
_ASCII = re.compile(r'[A-Za-z0-9_.:@+/-]{1,128}\Z')
_TIME_OP = ('before', 'after', 'at')


def blob_sha256(blob):
    return hashlib.sha256(blob).hexdigest()


def provenance_body(adapter, blob, mime, provenance):
    body = {
        'adapter': adapter,
        'blob_sha256': blob_sha256(blob),
        'kind': provenance['kind'],
        'mime': mime,
    }
    if provenance['kind'] == 'DKIM':
        body['domain'] = provenance['domain']
        body['selector'] = provenance['selector']
    if provenance['kind'] == 'C2PA':
        body['manifest_hash'] = provenance['manifest_hash']
        if provenance.get('assertions') is not None:
            body['assertions'] = provenance['assertions']
    return body


def sign_provenance(signer, *, adapter, blob, mime, kind, domain=None, selector=None, manifest_hash=None,
                    assertions=None):
    """Sign a provenance statement. The blob bytes stay outside the signature body."""
    provenance = {'kind': kind}
    if kind == 'DKIM':
        provenance['domain'] = domain
        provenance['selector'] = selector
    if kind == 'C2PA':
        provenance['manifest_hash'] = manifest_hash if manifest_hash is not None else blob_sha256(blob)
        if assertions is not None:
            provenance['assertions'] = assertions
    body = provenance_body(adapter, blob, mime, provenance)
    provenance['signer'] = public_key(signer)
    provenance['signature'] = sign(signer, PROVENANCE_LABEL, body)
    return provenance


def provenance_ok(adapter, blob, mime, provenance, allowed):
    if type(provenance) is not dict or provenance.get('kind') not in allowed:
        return False
    if provenance['kind'] == 'EXIF':
        return True
    body = provenance_body(adapter, blob, mime, provenance)
    try:
        canonical(body)
    except Exception:
        return False
    return signature_ok(provenance.get('signer'), PROVENANCE_LABEL, body, provenance.get('signature'))


def _reading(supports, confidence, reason, notes=()):
    return {'supports': supports, 'confidence_bps': confidence if supports else 0, 'reason': reason, 'notes': list(notes)}


def _expect(claim, field):
    expect = claim.get('expect')
    if type(expect) is not dict or type(expect.get(field)) is not dict:
        return None
    return expect[field]


class TimestampAdapter:
    """A signed instant compared with the claim's own op and time. Not a deadline."""

    id = 'covenant-evidence-adapter/timestamp/0.1'
    field = 'timestamp'

    def read(self, blob, mime, provenance, claim):
        if mime != 'application/vnd.covenant-time+json':
            return _reading(False, 0, 'MIME')
        if not provenance_ok(self.id, blob, mime, provenance, ('DEVICE', 'WITNESS')):
            return _reading(False, 0, 'PROVENANCE')
        expect = _expect(claim, self.field)
        if expect is None or expect.get('op') not in _TIME_OP or type(expect.get('time')) is not int:
            return _reading(False, 0, 'CLAIM_SHAPE')
        try:
            recorded = json.loads(blob.decode('ascii'))
        except (UnicodeError, json.JSONDecodeError):
            return _reading(False, 0, 'BLOB')
        if type(recorded) is not dict or type(recorded.get('time')) is not int or set(recorded) - {'time'}:
            return _reading(False, 0, 'BLOB')
        instant = recorded['time']
        target = expect['time']
        op = expect['op']
        holds = instant < target if op == 'before' else instant > target if op == 'after' else instant == target
        return _reading(holds, 10000, 'OK' if holds else 'CLAIM')


class ImageAdapter:
    """JPEG EXIF, or a C2PA-style signed manifest bound to the blob hash."""

    id = 'covenant-evidence-adapter/image/0.1'
    field = 'image'

    def read(self, blob, mime, provenance, claim):
        if mime not in ('image/jpeg', 'image/png', 'image/webp'):
            return _reading(False, 0, 'MIME')
        expect = _expect(claim, self.field)
        if expect is None:
            return _reading(False, 0, 'CLAIM_SHAPE')
        kind = provenance.get('kind') if type(provenance) is dict else None
        if kind == 'EXIF':
            return self._exif(blob, mime, expect)
        if kind == 'C2PA':
            return self._c2pa(blob, mime, provenance, expect)
        return _reading(False, 0, 'PROVENANCE')

    def _exif(self, blob, mime, expect):
        if mime != 'image/jpeg':
            return _reading(False, 0, 'MIME')
        found = read_exif(blob)
        if found is None:
            return _reading(False, 0, 'BLOB')
        if 'datetime' in expect and found.get('datetime') != expect['datetime']:
            return _reading(False, 0, 'CLAIM')
        if 'lat_e7' in expect or 'lon_e7' in expect:
            if found.get('lat_e7') != expect.get('lat_e7') or found.get('lon_e7') != expect.get('lon_e7'):
                return _reading(False, 0, 'CLAIM')
        if 'datetime' not in expect and 'lat_e7' not in expect and 'lon_e7' not in expect:
            return _reading(False, 0, 'CLAIM_SHAPE')
        return _reading(True, 8000, 'OK')

    def _c2pa(self, blob, mime, provenance, expect):
        if not provenance_ok(self.id, blob, mime, provenance, ('C2PA',)):
            return _reading(False, 0, 'PROVENANCE')
        if provenance.get('manifest_hash') != blob_sha256(blob):
            return _reading(False, 0, 'PROVENANCE')
        assertions = expect.get('assertions')
        if assertions is not None:
            got = provenance.get('assertions')
            if type(assertions) is not dict or type(got) is not dict or any(got.get(key) != value for key, value in assertions.items()):
                return _reading(False, 0, 'CLAIM')
        return _reading(True, 10000, 'OK', ('C2PA_MANIFEST_HASH_NOT_A_JUMBF_PARSER',))


class JsonAdapter:
    """JSON signed by a carried device/witness/DKIM/zkTLS key; trust is separate."""

    id = 'covenant-evidence-adapter/json/0.1'
    field = 'json'

    def read(self, blob, mime, provenance, claim):
        if mime != 'application/json':
            return _reading(False, 0, 'MIME')
        kind = provenance.get('kind') if type(provenance) is dict else None
        if not provenance_ok(self.id, blob, mime, provenance, ('DEVICE', 'WITNESS', 'DKIM', 'ZKTLS')):
            return _reading(False, 0, 'PROVENANCE')
        expect = _expect(claim, self.field)
        if expect is None or not expect:
            return _reading(False, 0, 'CLAIM_SHAPE')
        try:
            recorded = json.loads(bytes(blob).decode('utf-8'))
            canonical(recorded)
        except Exception:
            return _reading(False, 0, 'BLOB')
        if type(recorded) is not dict or any(recorded.get(key) != value for key, value in expect.items()):
            return _reading(False, 0, 'CLAIM')
        notes = []
        if kind == 'DKIM':
            notes.append('DKIM_DNS_NOT_QUERIED')
        if kind == 'ZKTLS':
            notes.append('ZKTLS_SIGNATURE_OF_STATEMENT_NOT_A_ZK_PROOF')
        return _reading(True, 10000, 'OK', notes)


class WitnessAdapter:
    """One co-signature over the blob. Several witnesses are several sources."""

    id = 'covenant-evidence-adapter/witness/0.1'
    field = 'witness'

    def read(self, blob, mime, provenance, claim):
        if not provenance_ok(self.id, blob, mime, provenance, ('WITNESS',)):
            return _reading(False, 0, 'PROVENANCE')
        expect = _expect(claim, self.field)
        if expect is None:
            return _reading(False, 0, 'CLAIM_SHAPE')
        wanted = expect.get('signer')
        if wanted is not None and wanted != provenance.get('signer'):
            return _reading(False, 0, 'CLAIM')
        return _reading(True, 10000, 'OK')


class GpsAdapter:
    """Integer e7 bounding box. Provenance is a device signature, not a clock."""

    id = 'covenant-evidence-adapter/gps/0.1'
    field = 'gps'

    def read(self, blob, mime, provenance, claim):
        if mime != 'application/vnd.covenant-gps+json':
            return _reading(False, 0, 'MIME')
        if not provenance_ok(self.id, blob, mime, provenance, ('DEVICE',)):
            return _reading(False, 0, 'PROVENANCE')
        expect = _expect(claim, self.field)
        if expect is None:
            return _reading(False, 0, 'CLAIM_SHAPE')
        box = [expect.get(name) for name in ('lat_min_e7', 'lat_max_e7', 'lon_min_e7', 'lon_max_e7')]
        if any(type(value) is not int for value in box):
            return _reading(False, 0, 'CLAIM_SHAPE')
        try:
            recorded = json.loads(blob.decode('ascii'))
        except (UnicodeError, json.JSONDecodeError):
            return _reading(False, 0, 'BLOB')
        if type(recorded) is not dict or type(recorded.get('lat_e7')) is not int or type(recorded.get('lon_e7')) is not int:
            return _reading(False, 0, 'BLOB')
        lat_min, lat_max, lon_min, lon_max = box
        inside = lat_min <= recorded['lat_e7'] <= lat_max and lon_min <= recorded['lon_e7'] <= lon_max
        return _reading(inside, 10000, 'OK' if inside else 'CLAIM')


def time_blob(instant):
    need(type(instant) is int and not type(instant) is bool, 'EVIDENCE_FIELDS')
    return canonical({'time': instant})


def json_blob(obj):
    return canonical(obj)


def gps_blob(lat_e7, lon_e7):
    return canonical({'lat_e7': lat_e7, 'lon_e7': lon_e7})


def sign_carrier(blob, *, key, carrier):
    """HMAC-SHA256 over the webhook bytes. The carrier name is the parties' choice."""
    need(type(blob) is bytes and 1 <= len(blob) <= 1_000_000, 'EVIDENCE_FIELDS')
    need(type(key) is bytes and len(key) == 32, 'EVIDENCE_FIELDS')
    need(type(carrier) is str and bool(_CARRIER.fullmatch(carrier)), 'EVIDENCE_FIELDS')
    mac = hmac.new(key, blob, hashlib.sha256).hexdigest()
    return {'kind': 'HMAC', 'carrier': carrier, 'mac': mac}


class CarrierWebhookAdapter:
    """One signed webhook. The parties name the carrier and the HMAC key in the claim."""

    id = 'covenant-evidence-adapter/carrier-webhook/0.1'
    field = 'webhook'

    def read(self, blob, mime, provenance, claim):
        if mime != 'application/json':
            return _reading(False, 0, 'MIME')
        expect = _expect(claim, self.field)
        if expect is None or 'carrier' not in expect or 'key_hex' not in expect:
            return _reading(False, 0, 'CLAIM_SHAPE')
        carrier = expect['carrier']
        key_hex = expect['key_hex']
        if type(carrier) is not str or not _CARRIER.fullmatch(carrier):
            return _reading(False, 0, 'CLAIM_SHAPE')
        if type(key_hex) is not str or len(key_hex) != 64 or any(ch not in '0123456789abcdef' for ch in key_hex):
            return _reading(False, 0, 'CLAIM_SHAPE')
        if type(provenance) is not dict or provenance.get('kind') != 'HMAC':
            return _reading(False, 0, 'PROVENANCE')
        if provenance.get('carrier') != carrier:
            return _reading(False, 0, 'CLAIM')
        mac = provenance.get('mac')
        if type(mac) is not str or len(mac) != 64:
            return _reading(False, 0, 'PROVENANCE')
        try:
            recorded = json.loads(bytes(blob).decode('utf-8'))
            canonical(recorded)
        except Exception:
            return _reading(False, 0, 'BLOB')
        expected_mac = hmac.new(bytes.fromhex(key_hex), blob, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_mac, mac):
            return _reading(False, 0, 'MAC')
        if type(recorded) is not dict:
            return _reading(False, 0, 'CLAIM')
        for name, value in expect.items():
            if name in ('carrier', 'key_hex'):
                continue
            if recorded.get(name) != value:
                return _reading(False, 0, 'CLAIM')
        return _reading(True, 10000, 'OK', ('CARRIER_CHOSEN_BY_PARTIES',))


def _exact_subset(recorded, expected):
    """Typed canonical equality, including nested values and missing versus null."""
    if type(recorded) is not dict or type(expected) is not dict:
        return False
    try:
        return all(key in recorded and canonical(recorded[key]) == canonical(value)
                   for key, value in expected.items())
    except Exception:
        return False


def _strict_expect(claim, field):
    """Reject absent, empty or noncanonical successor claim shapes locally."""
    if type(claim) is not dict:
        return None
    expect = _expect(claim, field)
    if not expect:
        return None
    try:
        canonical(expect)
    except (ValueError, TypeError, RecursionError):
        return None
    return expect


def _strict_blob(blob):
    return isinstance(blob, (bytes, bytearray)) and 1 <= len(blob) <= 1_000_000


def _strict_provenance_ok(adapter, blob, mime, provenance, allowed):
    """Malformed provenance is a refusal in /0.2, not an escaping shape error."""
    try:
        return provenance_ok(adapter, blob, mime, provenance, allowed)
    except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
        return False


class StrictJsonAdapter(JsonAdapter):
    """Successor: boolean/integer values and missing/null fields are distinct."""
    id = 'covenant-evidence-adapter/json/0.2'

    def read(self, blob, mime, provenance, claim):
        if mime != 'application/json':
            return _reading(False, 0, 'MIME')
        expect = _strict_expect(claim, self.field)
        if expect is None:
            return _reading(False, 0, 'CLAIM_SHAPE')
        if not _strict_blob(blob):
            return _reading(False, 0, 'BLOB')
        if not _strict_provenance_ok(self.id, blob, mime, provenance, ('DEVICE', 'WITNESS', 'DKIM', 'ZKTLS')):
            return _reading(False, 0, 'PROVENANCE')
        try:
            recorded = loads(bytes(blob))
        except (ValueError, TypeError, RecursionError):
            return _reading(False, 0, 'BLOB')
        if not _exact_subset(recorded, expect):
            return _reading(False, 0, 'CLAIM')
        notes = []
        if provenance['kind'] == 'DKIM':
            notes.append('DKIM_DNS_NOT_QUERIED')
        if provenance['kind'] == 'ZKTLS':
            notes.append('ZKTLS_SIGNATURE_OF_STATEMENT_NOT_A_ZK_PROOF')
        return _reading(True, 10000, 'OK', notes)


class StrictImageAdapter(ImageAdapter):
    """Exact requested metadata; a signed statement never establishes world truth.

    C2PA-style claims require nonempty ``assertions`` and may additionally pin
    ``manifest_hash`` and ``signer``. EXIF claims name only datetime/GPS fields.
    Unsupported, empty and null claims are refused rather than ignored.
    """
    id = 'covenant-evidence-adapter/image/0.2'

    def read(self, blob, mime, provenance, claim):
        if _strict_expect(claim, self.field) is None:
            return _reading(False, 0, 'CLAIM_SHAPE')
        if not _strict_blob(blob):
            return _reading(False, 0, 'BLOB')
        try:
            return super().read(blob, mime, provenance, claim)
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return _reading(False, 0, 'PROVENANCE')

    def _c2pa(self, blob, mime, provenance, expect):
        if (set(expect) - {'assertions', 'manifest_hash', 'signer'} or
                type(expect.get('assertions')) is not dict or not expect['assertions']):
            return _reading(False, 0, 'CLAIM_SHAPE')
        if 'manifest_hash' in expect and (type(expect['manifest_hash']) is not str or
                re.fullmatch(r'[0-9a-f]{64}', expect['manifest_hash']) is None):
            return _reading(False, 0, 'CLAIM_SHAPE')
        if 'signer' in expect and not valid_ed25519_key(expect['signer']):
            return _reading(False, 0, 'CLAIM_SHAPE')
        if not _strict_provenance_ok(self.id, blob, mime, provenance, ('C2PA',)):
            return _reading(False, 0, 'PROVENANCE')
        result = super()._c2pa(blob, mime, provenance, expect)
        if result['supports']:
            if (not _exact_subset(provenance.get('assertions'), expect['assertions']) or
                    any(provenance.get(field) != expect[field] for field in ('manifest_hash', 'signer') if field in expect)):
                return _reading(False, 0, 'CLAIM')
        return result

    def _exif(self, blob, mime, expect):
        if set(expect) - {'datetime', 'lat_e7', 'lon_e7'}:
            return _reading(False, 0, 'CLAIM_SHAPE')
        if 'datetime' in expect and (type(expect['datetime']) is not str or len(expect['datetime']) != 19):
            return _reading(False, 0, 'CLAIM_SHAPE')
        if any(type(expect[field]) is not int for field in ('lat_e7', 'lon_e7') if field in expect):
            return _reading(False, 0, 'CLAIM_SHAPE')
        result = super()._exif(blob, mime, expect)
        if result['supports'] and not _exact_subset(read_exif(blob), expect):
            return _reading(False, 0, 'CLAIM')
        return result


class StrictCarrierWebhookAdapter(CarrierWebhookAdapter):
    """Successor: an authenticated webhook must satisfy typed agreed values."""
    id = 'covenant-evidence-adapter/carrier-webhook/0.2'

    def read(self, blob, mime, provenance, claim):
        expected = _strict_expect(claim, self.field)
        if expected is None or not set(expected) - {'carrier', 'key_hex'}:
            return _reading(False, 0, 'CLAIM_SHAPE')
        if not _strict_blob(blob):
            return _reading(False, 0, 'BLOB')
        try:
            result = super().read(blob, mime, provenance, claim)
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return _reading(False, 0, 'PROVENANCE')
        if not result['supports']:
            return result
        try:
            recorded = loads(bytes(blob))
        except (ValueError, TypeError, RecursionError):
            return _reading(False, 0, 'BLOB')
        if not _exact_subset(recorded, {key: value for key, value in expected.items() if key not in ('carrier', 'key_hex')}):
            return _reading(False, 0, 'CLAIM')
        return result


ADAPTERS = {
    adapter.id: adapter
    for adapter in (TimestampAdapter(), ImageAdapter(), JsonAdapter(), WitnessAdapter(), GpsAdapter(),
                    CarrierWebhookAdapter(), StrictJsonAdapter(), StrictImageAdapter(),
                    StrictCarrierWebhookAdapter())
}


def adapter_for(adapter_id, registry):
    need(type(adapter_id) is str and bool(_ASCII.fullmatch(adapter_id)), 'EVIDENCE_ADAPTER')
    return registry.get(adapter_id)
