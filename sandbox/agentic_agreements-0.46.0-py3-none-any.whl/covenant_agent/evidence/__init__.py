"""Generic evidence adapters for a covenant pinned at BIND.

Any source reaches the same check through an adapter: a timestamp, an image,
signed JSON, a witness, a GPS fix, or an adapter registered later. The checker
does not special-case delivery time.
"""
from .adapters import (
    ADAPTERS, GpsAdapter, ImageAdapter, JsonAdapter, TimestampAdapter, WitnessAdapter,
    gps_blob, json_blob, sign_provenance, time_blob,
    StrictJsonAdapter, StrictImageAdapter, StrictCarrierWebhookAdapter,
)
from .check import check, consume, pin
from .exif import jpeg_exif

__all__ = [
    'ADAPTERS', 'check', 'consume', 'pin', 'sign_provenance', 'time_blob', 'json_blob', 'gps_blob', 'jpeg_exif',
    'TimestampAdapter', 'ImageAdapter', 'JsonAdapter', 'WitnessAdapter', 'GpsAdapter',
    'StrictJsonAdapter', 'StrictImageAdapter', 'StrictCarrierWebhookAdapter',
]
