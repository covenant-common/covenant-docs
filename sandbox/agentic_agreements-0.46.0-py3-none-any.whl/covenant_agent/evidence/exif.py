"""Minimal JPEG EXIF reader and fixture builder.

This is the reference image path for DateTime and GPS. It is not a general
JPEG or TIFF library. A fuller parser can replace ``read_exif`` later without
changing the adapter id.
"""
from ..errors import need

_DATETIME = 0x0132
_GPS_POINTER = 0x8825
_GPS_LAT_REF = 0x0001
_GPS_LAT = 0x0002
_GPS_LON_REF = 0x0003
_GPS_LON = 0x0004


def _u16(raw, offset, endian):
    return int.from_bytes(raw[offset:offset + 2], endian)


def _u32(raw, offset, endian):
    return int.from_bytes(raw[offset:offset + 4], endian)


def e7_to_rationals(value):
    """Degrees, zero minutes, and seconds that ``rationals_to_e7`` inverts."""
    need(type(value) is int and not type(value) is bool, 'EVIDENCE_FIELDS')
    sign = value < 0
    remainder = abs(value) % 10_000_000
    degrees = abs(value) // 10_000_000
    return sign, (degrees, 1), (0, 1), (remainder * 360, 1_000_000)


def rationals_to_e7(degrees, minutes, seconds):
    deg_num, deg_den = degrees
    min_num, min_den = minutes
    sec_num, sec_den = seconds
    if min(deg_den, min_den, sec_den) <= 0:
        return None
    return (deg_num * 10_000_000 // deg_den + min_num * 10_000_000 // (min_den * 60)
            + sec_num * 10_000_000 // (sec_den * 3600))


def _ifd(raw, offset, endian, base):
    if offset < 0 or offset + 2 > len(raw):
        return None
    count = _u16(raw, offset, endian)
    if count > 8 or offset + 2 + count * 12 + 4 > len(raw):
        return None
    entries = {}
    cursor = offset + 2
    for _ in range(count):
        tag = _u16(raw, cursor, endian)
        typ = _u16(raw, cursor + 2, endian)
        number = _u32(raw, cursor + 4, endian)
        stored = _u32(raw, cursor + 8, endian)
        entries[tag] = (typ, number, stored)
        cursor += 12
    return entries


def _ascii(raw, typ, number, stored, endian, base):
    if typ != 2 or number < 2 or number > 32:
        return None
    if number <= 4:
        blob = stored.to_bytes(4, endian)[:number]
    else:
        if stored < 0 or stored + number > len(raw):
            return None
        blob = raw[stored:stored + number]
    if blob[-1:] != b'\x00':
        return None
    text = blob[:-1]
    if not text or any(c < 32 or c > 126 for c in text):
        return None
    return text.decode('ascii')


def _rationals(raw, typ, number, stored, endian):
    if typ != 5 or number < 1 or number > 3 or stored < 0 or stored + number * 8 > len(raw):
        return None
    out = []
    for index in range(number):
        at = stored + index * 8
        out.append((_u32(raw, at, endian), _u32(raw, at + 4, endian)))
    return out


def read_exif(blob):
    """Return datetime and GPS e7 from a JPEG APP1 segment, or None."""
    if type(blob) is not bytes or len(blob) < 4 or blob[:2] != b'\xff\xd8':
        return None
    index = 2
    tiff = None
    while index + 1 < len(blob):
        if blob[index] != 0xFF:
            return None
        while index < len(blob) and blob[index] == 0xFF:
            index += 1
        if index >= len(blob):
            return None
        marker = blob[index]
        index += 1
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7 or marker == 0x01:
            if marker == 0xD9:
                break
            continue
        if index + 2 > len(blob):
            return None
        length = int.from_bytes(blob[index:index + 2], 'big')
        if length < 2 or index + length > len(blob):
            return None
        payload = blob[index + 2:index + length]
        index += length
        if marker == 0xE1 and payload.startswith(b'Exif\x00\x00'):
            tiff = payload[6:]
            break
        if marker == 0xDA:
            break
    if tiff is None or len(tiff) < 8:
        return None
    endian = 'little' if tiff[:2] == b'II' else 'big' if tiff[:2] == b'MM' else None
    if endian is None or _u16(tiff, 2, endian) != 42:
        return None
    ifd = _ifd(tiff, _u32(tiff, 4, endian), endian, 0)
    if ifd is None:
        return None
    found = {'datetime': None, 'lat_e7': None, 'lon_e7': None}
    if _DATETIME in ifd:
        typ, number, stored = ifd[_DATETIME]
        found['datetime'] = _ascii(tiff, typ, number, stored, endian, 0)
    if _GPS_POINTER in ifd:
        typ, number, stored = ifd[_GPS_POINTER]
        if typ == 4 and number == 1:
            gps = _ifd(tiff, stored, endian, 0)
            if gps is not None:
                found.update(_gps(tiff, gps, endian))
    return found


def _gps(raw, ifd, endian):
    out = {'lat_e7': None, 'lon_e7': None}
    lat_ref = _ascii(raw, *ifd[_GPS_LAT_REF], endian, 0) if _GPS_LAT_REF in ifd else None
    lon_ref = _ascii(raw, *ifd[_GPS_LON_REF], endian, 0) if _GPS_LON_REF in ifd else None
    if _GPS_LAT in ifd and lat_ref in ('N', 'S'):
        parts = _rationals(raw, *ifd[_GPS_LAT], endian)
        if parts is not None and len(parts) == 3:
            value = rationals_to_e7(*parts)
            if value is not None:
                out['lat_e7'] = -value if lat_ref == 'S' else value
    if _GPS_LON in ifd and lon_ref in ('E', 'W'):
        parts = _rationals(raw, *ifd[_GPS_LON], endian)
        if parts is not None and len(parts) == 3:
            value = rationals_to_e7(*parts)
            if value is not None:
                out['lon_e7'] = -value if lon_ref == 'W' else value
    return out


def _entry(tag, typ, number, value, endian):
    return (tag.to_bytes(2, endian) + typ.to_bytes(2, endian) + number.to_bytes(4, endian)
            + value.to_bytes(4, endian))


def jpeg_exif(*, datetime=None, lat_e7=None, lon_e7=None):
    """Build a tiny JPEG whose APP1 segment carries the given EXIF fields."""
    need(datetime is None or (type(datetime) is str and len(datetime) == 19), 'EVIDENCE_FIELDS')
    endian = 'little'
    extra = bytearray()
    gps_rationals = None
    if lat_e7 is not None or lon_e7 is not None:
        need(type(lat_e7) is int and type(lon_e7) is int, 'EVIDENCE_FIELDS')
        need(-90 * 10_000_000 <= lat_e7 <= 90 * 10_000_000, 'EVIDENCE_FIELDS')
        need(-180 * 10_000_000 <= lon_e7 <= 180 * 10_000_000, 'EVIDENCE_FIELDS')
        gps_rationals = (e7_to_rationals(lat_e7), e7_to_rationals(lon_e7))
    count = (1 if datetime is not None else 0) + (1 if gps_rationals is not None else 0)
    need(count >= 1, 'EVIDENCE_FIELDS')
    ifd_size = 2 + count * 12 + 4
    data_at = 8 + ifd_size
    body = bytearray(b'II' + (42).to_bytes(2, 'little') + (8).to_bytes(4, 'little'))
    body += count.to_bytes(2, 'little')
    if datetime is not None:
        raw = datetime.encode('ascii') + b'\x00'
        body += _entry(_DATETIME, 2, len(raw), data_at, endian)
        extra += raw
        data_at += len(raw)
    gps_at = None
    if gps_rationals is not None:
        gps_at = data_at
        body += _entry(_GPS_POINTER, 4, 1, gps_at, endian)
    body += (0).to_bytes(4, 'little')
    body += extra
    if gps_rationals is not None:
        lat_sign, lat_d, lat_m, lat_s = gps_rationals[0]
        lon_sign, lon_d, lon_m, lon_s = gps_rationals[1]
        rationals = [lat_d, lat_m, lat_s, lon_d, lon_m, lon_s]
        rational_at = gps_at + 2 + 4 * 12 + 4
        gps = bytearray((4).to_bytes(2, 'little'))
        gps += _entry(_GPS_LAT_REF, 2, 2, int.from_bytes((b'S\x00' if lat_sign else b'N\x00') + b'\x00\x00', 'little'), endian)
        gps += _entry(_GPS_LAT, 5, 3, rational_at, endian)
        gps += _entry(_GPS_LON_REF, 2, 2, int.from_bytes((b'W\x00' if lon_sign else b'E\x00') + b'\x00\x00', 'little'), endian)
        gps += _entry(_GPS_LON, 5, 3, rational_at + 24, endian)
        gps += (0).to_bytes(4, 'little')
        for num, den in rationals:
            gps += num.to_bytes(4, 'little') + den.to_bytes(4, 'little')
        need(len(body) == gps_at, 'EVIDENCE_FIELDS')
        body += gps
    segment = b'Exif\x00\x00' + bytes(body)
    length = len(segment) + 2
    return b'\xff\xd8' + b'\xff\xe1' + length.to_bytes(2, 'big') + segment + b'\xff\xd9'
