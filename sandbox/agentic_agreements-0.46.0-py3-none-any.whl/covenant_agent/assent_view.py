"""What you see is what you sign: one deterministic text for exact agreement bytes.

``render`` turns a bilateral /0.1 or /0.2 work order, or an open /0.3 order,
into printable ASCII lines. The text is a pure function of the canonical
agreement bytes and, when the envelope carries it, the task text those bytes
name by SHA-256. No clock, locale, network or model is read, so any verifier
recomputes the same bytes. Every signed field is shown and an unrendered field
refuses the whole rendering. The profile's own unsigned constructor must
rebuild the agreement byte for byte before anything is shown.

An owner approval binds the SHA-256 of these rendering bytes together with the
SHA-256 of the canonical agreement bytes. The rendering displays terms. It does
not establish delivery, payment, identity or the truth of any statement in the
task text, and it grants no authority to sign.
"""
from copy import deepcopy
import hashlib
import json

from .codec import canonical
from .errors import NativeError, need

VERSION = 'covenant-assent-rendering/0.1'
RENDERING_MEDIA_TYPE = 'text/plain; charset=us-ascii'
APP_URI = 'ui://covenant/assent-review'
APP_MEDIA_TYPE = 'text/html;profile=mcp-app'
RENDERING_URI = 'aap-assent://rendering/'
BILATERAL = ('covenant-bilateral/0.1', 'covenant-bilateral/0.2')
OPEN_WORK = 'covenant-bilateral/0.3'
MAX_AGREEMENT_BYTES = 65536
MAX_RENDERING_BYTES = 131072
LAST_RFC3339 = 253402300799
HEX = frozenset('0123456789abcdef')
FLAGS = {'signature_created': False, 'execution_authorized': False}


class _Taken:
    """Every field of a signed object must be shown exactly once."""

    def __init__(self, value):
        need(type(value) is dict, 'ASSENT_RENDER_FIELDS')
        self.value, self.seen = value, set()

    def __call__(self, name):
        need(name in self.value and name not in self.seen, 'ASSENT_RENDER_FIELDS')
        self.seen.add(name)
        return self.value[name]

    def done(self):
        need(self.seen == set(self.value), 'ASSENT_RENDER_FIELDS')


def _quote(text):
    need(type(text) is str, 'ASSENT_RENDER_FIELDS')
    return json.dumps(text, ensure_ascii=True)


def _hex(value):
    return type(value) is str and len(value) == 64 and set(value) <= HEX


def _civil(days):
    """Proleptic Gregorian date for days after 1970-01-01, by integer arithmetic only."""
    shifted = days + 719468
    era = shifted // 146097
    day_of_era = shifted - era * 146097
    year_of_era = (day_of_era - day_of_era // 1460 + day_of_era // 36524 - day_of_era // 146096) // 365
    day_of_year = day_of_era - (365 * year_of_era + year_of_era // 4 - year_of_era // 100)
    month_index = (5 * day_of_year + 2) // 153
    day = day_of_year - (153 * month_index + 2) // 5 + 1
    month = month_index + 3 if month_index < 10 else month_index - 9
    return year_of_era + era * 400 + (month <= 2), month, day


def utc(seconds):
    """RFC 3339 UTC text for integer Unix seconds; later than year 9999 is stated, not formatted."""
    need(type(seconds) is int and 0 <= seconds <= 2**53 - 1, 'ASSENT_RENDER_FIELDS')
    if seconds > LAST_RFC3339:
        return 'after 9999-12-31T23:59:59Z'
    days, rest = divmod(seconds, 86400)
    year, month, day = _civil(days)
    return '%04d-%02d-%02dT%02d:%02d:%02dZ' % (year, month, day, rest // 3600, rest % 3600 // 60, rest % 60)


def _bilateral_draft(value):
    """Rebuild the exact unsigned order with the profile's own constructor."""
    from . import bilateral_v2, envelope as legacy
    terms, parties = value.get('terms'), value.get('parties')
    need(type(terms) is dict and type(parties) is dict, 'ASSENT_RENDER_FIELDS')
    document = value.get('document')
    need(type(document) is dict and set(document) in ({'sha256'}, {'sha256', 'text'}), 'ASSENT_RENDER_FIELDS')
    text = document.get('text')
    arguments = dict(agent=parties['agent'], counterparty=parties['counterparty'], resolver=parties['resolver'],
                     appeal_resolver=parties['appeal_resolver'], quantity=terms['quantity'], unit=terms['unit'],
                     rail=terms['rail'], pay_to=terms['pay_to'], deadline=terms['deadline'],
                     challenge_window=terms['challenge_window'], timeout=terms['timeout'], effect=terms['effect'],
                     network=terms['network'], executor=parties['executor'], mandate=value.get('mandate'),
                     task_hash=None if text is not None else terms['task_hash'])
    if value['profile'] == BILATERAL[0]:
        return legacy.draft_order(text, **arguments)
    return bilateral_v2.draft_order(text, nonce=terms['nonce'], settlement_authority=terms['settlement_authority'],
                                    **arguments)


def agreement(value):
    """The exact signable agreement of an envelope, a draft or an open order.

    Returns the profile, the signed body, its canonical bytes and SHA-256, the
    profile's own agreement id and the verified task text when one is carried.
    """
    need(type(value) is dict, 'ASSENT_RENDER_PROFILE')
    try:
        if value.get('profile') in BILATERAL:
            draft = _bilateral_draft(value)
            body = {'profile': value['profile'], 'terms': value['terms'], 'parties': value['parties']}
            rebuilt = {'profile': draft['profile'], 'terms': draft['terms'], 'parties': draft['parties']}
            need(canonical(body) == canonical(rebuilt), 'ASSENT_RENDER_CHANGED')
            document = draft['document'].get('text')
            if value['profile'] == BILATERAL[0]:
                from .envelope import escrow_id
                native, kind = escrow_id(draft), 'escrow id'
            else:
                from .bilateral_v2 import identifier
                native, kind = identifier(draft), 'agreement identifier'
            profile = value['profile']
        elif type(value.get('body')) is dict and value['body'].get('profile') == OPEN_WORK:
            from . import open_work
            body = value['body']
            need(set(body) == {'profile', 'terms', 'customer', 'provider'} and type(body['terms']) is dict,
                 'ASSENT_RENDER_FIELDS')
            terms = body['terms']
            draft = open_work.draft(terms['task'], body['customer'], body['provider'], terms['quantity'],
                                    terms['payment'], terms['nonce'], terms['deadline'], context=terms['context'])
            need(canonical(body) == canonical(draft['body']) and value.get('id', draft['id']) == draft['id'],
                 'ASSENT_RENDER_CHANGED')
            native, kind, document, profile = draft['id'], 'order identifier', None, OPEN_WORK
        else:
            raise NativeError('ASSENT_RENDER_PROFILE')
    except NativeError:
        raise
    except (KeyError, TypeError, AttributeError, ValueError) as exc:
        code = getattr(exc, 'code', None) or str(exc)
        raise NativeError(code if code.startswith(('OPEN_WORK_', 'ASSENT_')) else 'ASSENT_RENDER_FIELDS') from None
    raw = canonical(body)
    need(len(raw) <= MAX_AGREEMENT_BYTES, 'ASSENT_RENDER_SIZE')
    return {'profile': profile, 'body': deepcopy(body), 'canonical': raw, 'sha256': hashlib.sha256(raw).hexdigest(),
            'agreement_id': native, 'agreement_id_kind': kind, 'document': document}


def _bilateral_lines(profile, body, native, kind, document):
    second = profile == BILATERAL[1]
    top = _Taken(body)
    need(top('profile') == profile, 'ASSENT_RENDER_PROFILE')
    terms, parties = _Taken(top('terms')), _Taken(top('parties'))
    version, task_hash = terms('version'), terms('task_hash')
    quantity, unit, effect = terms('quantity'), terms('unit'), terms('effect')
    rail, network, pay_to = terms('rail'), terms('network'), terms('pay_to')
    deadline, window, timeout = terms('deadline'), terms('challenge_window'), terms('timeout')
    principal, agent = parties('principal'), parties('agent')
    counterparty, executor = parties('counterparty'), parties('executor')
    resolver, appeal = parties('resolver'), parties('appeal_resolver')
    if second:
        nonce, clock, rule, authority = terms('nonce'), terms('deadline_clock'), terms('deadline_rule'), terms('settlement_authority')
    terms.done(); parties.done(); top.done()
    lines = ['Profile: ' + profile, 'Terms version: ' + version,
             'Agreement id: %s (the %s %s)' % (native, profile, kind), '',
             'AMOUNT',
             '  The principal pays %d %s.' % (quantity, unit),
             '  This is the integer quantity exactly as signed. The signed terms name no decimal places.',
             '  Effect: ' + effect, '',
             'PAYEE',
             '  Counterparty (paid on settlement): ' + counterparty,
             '  Pay to on the rail: ' + _quote(pay_to),
             '  Rail: %s on network %s' % (rail, _quote(network))]
    if second:
        lines.append('  Settlement authority: ' + (authority if authority is not None else 'none pinned'))
    lines += ['', 'PARTIES',
              '  Principal (pays): ' + principal,
              '  Agent (signs for the principal): ' + agent,
              '  Executor (may deliver for the counterparty): ' + executor, '',
              'DEADLINES']
    if second:
        lines += ['  Delivery deadline: %d = %s (clock %s: each party\'s adopted clock, not a proof of world time)'
                  % (deadline, utc(deadline), clock),
                  '  Deadline rule: %s. Delivery and the principal\'s release must be dated at or before the deadline.' % rule,
                  ('  Appeal window: %d seconds after the primary decision.' % window) if window else
                  '  Appeal window: 0. There is no appeal.']
    else:
        lines += ['  Delivery deadline: %d. The signed /0.1 terms name no clock; read as Unix seconds it is %s.'
                  % (deadline, utc(deadline)),
                  '  Challenge window: %d. It is the challenge period if a dispute is anchored on a chain; '
                  'local verification does not time it.' % window]
    lines += ['', 'ACCEPTANCE CRITERIA', '  Task SHA-256: ' + task_hash]
    if document is not None:
        lines += ['  Task text (%d characters; its SHA-256 equals the signed task hash):' % len(document),
                  '  ' + _quote(document)]
    else:
        lines.append('  Task text: not included. Only its SHA-256 is signed. Obtain the exact text and check '
                     'this hash before approving.')
    lines += ['  The delivery must satisfy this task. A resolver decides any dispute about it.', '',
              'REMEDIES',
              '  Resolver: ' + resolver,
              '  Appeal resolver: ' + appeal]
    if timeout == 'RELEASE_IF_UNDECIDED':
        lines.append('  If no decision exists after the deadline: RELEASE_IF_UNDECIDED. The principal may refund '
                     'the escrow to itself when the counterparty or the resolver stays silent.')
    else:
        lines.append('  If no decision exists after the deadline: %s. The escrow stays held until a resolver '
                     'decides; silence does not refund it.' % timeout)
    if second:
        lines += ['  The principal, the agent or the counterparty may open a dispute before settlement.',
                  '  The resolver decides first. A decision awards from 0 to %d %s to the counterparty; '
                  'REFUTED awards 0 and INDETERMINATE releases nothing.' % (quantity, unit)]
        if window:
            lines.append('  The appeal resolver may decide once more inside the appeal window.')
        lines += ['', 'ORDER', '  Order nonce: %s. It makes this order distinct from an otherwise identical one.' % nonce]
    else:
        lines += ['  The agent or the counterparty may open a dispute before settlement.',
                  '  The resolver or the appeal resolver records SUPPORTED, REFUTED or INDETERMINATE. SUPPORTED '
                  'pays the counterparty, REFUTED refunds the principal, INDETERMINATE releases nothing.']
    summary = {'amount': {'kind': 'MONEY', 'amount': quantity, 'unit': unit},
               'payee': {'key': counterparty, 'pay_to': pay_to}, 'payer': principal, 'agent': agent,
               'deadline': deadline, 'timeout': timeout, 'task_hash': task_hash,
               'task_text_included': document is not None}
    return lines, summary


def _open_lines(body, native, kind):
    top = _Taken(body)
    need(top('profile') == OPEN_WORK, 'ASSENT_RENDER_PROFILE')
    terms = _Taken(top('terms'))
    customer, provider = top('customer'), top('provider')
    version, task, quantity = terms('version'), terms('task'), terms('quantity')
    payment = _Taken(terms('payment'))
    nonce, deadline, clock, context = terms('nonce'), terms('deadline'), terms('clock'), terms('context')
    identifier, network, asset = payment('identifier'), payment('network'), payment('asset')
    unit, payee, adapter, instructions = payment('unit'), payment('payee'), payment('adapter'), payment('instructions')
    payment.done(); terms.done(); top.done()
    lines = ['Profile: ' + OPEN_WORK, 'Terms version: ' + version,
             'Agreement id: %s (the %s %s)' % (native, OPEN_WORK, kind), '',
             'AMOUNT',
             '  The customer pays %d of unit %s in asset %s.' % (quantity, _quote(unit), _quote(asset)),
             '  This is the integer quantity exactly as signed.', '',
             'PAYEE',
             '  Provider (performs the task and is paid): ' + provider,
             '  Pay to: ' + _quote(payee),
             '  Payment mechanism: %s on network %s' % (_quote(identifier), _quote(network)),
             '  Payment adapter: ' + (adapter if adapter is not None else 'none named'),
             '  Payment instructions (exact canonical JSON): ' +
             (canonical(instructions).decode('ascii') if instructions is not None else 'none'), '',
             'PARTIES', '  Customer (pays): ' + customer, '',
             'DEADLINES',
             '  Deadline: %d = %s (clock %s: each party\'s adopted clock, not a proof of world time)'
             % (deadline, utc(deadline), clock), '',
             'ACCEPTANCE CRITERIA',
             '  Task text (%d characters, inside the signed terms):' % len(task),
             '  ' + _quote(task),
             '  Context (exact canonical JSON): ' +
             (canonical(context).decode('ascii') if context is not None else 'none'), '',
             'REMEDIES',
             '  After both assents the parties append signed events: DELIVERY_CLAIM by the provider, '
             'PAYMENT_CLAIM by the customer, and DISPUTE or RECEIPT by either party.',
             '  This profile names no resolver. Signed claims are statements, not verified delivery or payment.', '',
             'ORDER', '  Order nonce: %s. It makes this order distinct from an otherwise identical one.' % nonce]
    summary = {'amount': {'kind': 'MONEY', 'amount': quantity, 'unit': unit}, 'asset': asset,
               'payee': {'key': provider, 'pay_to': payee}, 'payer': customer, 'agent': customer,
               'deadline': deadline, 'timeout': None, 'task_hash': hashlib.sha256(task.encode('ascii')).hexdigest(),
               'task_text_included': True}
    return lines, summary


def render(value):
    """The exact rendering, its SHA-256 and a typed summary. Nothing is signed or stored."""
    found = agreement(value)
    if found['profile'] in BILATERAL:
        lines, summary = _bilateral_lines(found['profile'], found['body'], found['agreement_id'],
                                          found['agreement_id_kind'], found['document'])
    else:
        lines, summary = _open_lines(found['body'], found['agreement_id'], found['agreement_id_kind'])
    raw_body = found['canonical'].decode('ascii')
    text = '\n'.join(['AAP AGREEMENT TO ASSENT', 'Rendering: ' + VERSION,
                      'Agreement SHA-256: %s (SHA-256 of the %d canonical agreement bytes below)'
                      % (found['sha256'], len(found['canonical'])), *lines, '',
                      'EXACT SIGNED AGREEMENT BYTES (canonical JSON, %d bytes)' % len(found['canonical']),
                      raw_body, '',
                      'WHAT THIS RENDERING DOES NOT ESTABLISH',
                      '  It shows the exact signed bytes. It does not show that the work, a payment, an identity '
                      'or any statement in the task text is true.',
                      '  An owner approval lets the named agent key sign this assent once. It is not a payment.',
                      'END', ''])
    raw = text.encode('ascii')
    need(len(raw) <= MAX_RENDERING_BYTES and all(byte == 10 or 32 <= byte <= 126 for byte in raw), 'ASSENT_RENDER_SIZE')
    digest = hashlib.sha256(raw).hexdigest()
    document = None
    if found['profile'] in BILATERAL:
        document = {'sha256': summary['task_hash']}
        if found['document'] is not None:
            document['text'] = found['document']
    return {'version': VERSION, 'profile': found['profile'], 'agreement_sha256': found['sha256'],
            'agreement_bytes': len(found['canonical']), 'agreement_id': found['agreement_id'],
            'rendering_sha256': digest, 'rendering_bytes': len(raw), 'uri': RENDERING_URI + digest,
            'media_type': RENDERING_MEDIA_TYPE, 'text': text, 'summary': summary, 'document': document, **FLAGS}


def public(rendered):
    """The model-facing view: hashes and typed terms, never the task prose in the rendering text.

    Task text stays in ``document`` so the prompt barrier quotes or withholds it.
    """
    need(type(rendered) is dict and rendered.get('version') == VERSION, 'ASSENT_RENDER_FIELDS')
    view = {key: deepcopy(rendered[key]) for key in ('version', 'profile', 'agreement_sha256', 'agreement_bytes',
                                                     'agreement_id', 'rendering_sha256', 'rendering_bytes', 'uri',
                                                     'media_type', 'summary', 'document')}
    view['rendering_text'] = 'HUMAN_CHANNELS_ONLY: MCP App resources/read, elicitation, AG-UI interrupt, owner approval tools'
    return {**view, **FLAGS}


def check(text, expected):
    """True when ``text`` is exactly the rendering named by ``expected``."""
    need(type(text) is str and _hex(expected), 'ASSENT_RENDER_FIELDS')
    try:
        raw = text.encode('ascii')
    except UnicodeError:
        return False
    return hashlib.sha256(raw).hexdigest() == expected


def resource_uri(rendering_sha256):
    need(_hex(rendering_sha256), 'ASSENT_RENDER_FIELDS')
    return RENDERING_URI + rendering_sha256


def rendering_from_uri(uri):
    need(type(uri) is str and uri.startswith(RENDERING_URI) and _hex(uri[len(RENDERING_URI):]), 'ASSENT_RESOURCE_UNKNOWN')
    return uri[len(RENDERING_URI):]


def app_resource():
    """The MCP Apps (SEP-1865) view template listed by ``resources/list``."""
    return {'uri': APP_URI, 'name': 'aap_assent_review', 'title': 'AAP agreement to sign',
            'description': 'Shows the exact rendering an owner approval binds, with its SHA-256 checked in the view.',
            'mimeType': APP_MEDIA_TYPE}


def app_contents():
    """``resources/read`` contents for the view: inline HTML, no external origin, no key material."""
    return {'uri': APP_URI, 'mimeType': APP_MEDIA_TYPE, 'text': APP_HTML,
            '_meta': {'ui': {'csp': {'connectDomains': [], 'resourceDomains': []}, 'prefersBorder': True}}}


APP_HTML = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<title>AAP agreement to sign</title>
<style>
*{box-sizing:border-box}
:root{font-family:"Times New Roman",Times,serif;font-size:16px;line-height:1.16;color:#000;background:#fff}
body{margin:0;padding:1rem;background:#fff;color:#000}
main{border:1px solid #000;padding:1rem;max-width:52rem}
h1,p,dl,dd,dt,pre{font-size:1rem;margin:0 0 .618rem}
h1,dt{font-weight:bold}
dd{margin-left:1rem;word-break:break-all}
pre{white-space:pre-wrap;word-break:break-word;font-family:"Times New Roman",Times,serif}
</style>
</head>
<body>
<main>
<h1>Agreement to sign</h1>
<p id="status" role="status">Waiting for the tool result.</p>
<dl>
<dt>Agreement SHA-256</dt><dd id="agreement">unknown</dd>
<dt>Rendering SHA-256</dt><dd id="rendering">unknown</dd>
<dt>Check in this view</dt><dd id="check">not run</dd>
</dl>
<pre id="text"></pre>
<p>Compare this SHA-256 with the one your own approval device shows before you approve. This view holds no key and cannot sign.</p>
</main>
<script>
(function () {
  'use strict';
  var next = 1, waiting = {};
  function post(message) { window.parent.postMessage(message, '*'); }
  function request(method, params) {
    var id = next++;
    post({jsonrpc: '2.0', id: id, method: method, params: params});
    return new Promise(function (resolve, reject) { waiting[id] = {resolve: resolve, reject: reject}; });
  }
  function notify(method, params) { post({jsonrpc: '2.0', method: method, params: params || {}}); }
  function put(id, text) { document.getElementById(id).textContent = String(text); }
  function resize() { notify('ui/notifications/size-changed', {height: document.documentElement.scrollHeight}); }
  function hex(buffer) {
    var bytes = new Uint8Array(buffer), out = '';
    for (var i = 0; i < bytes.length; i++) { out += (bytes[i] < 16 ? '0' : '') + bytes[i].toString(16); }
    return out;
  }
  function verify(text, expected) {
    if (!(window.crypto && window.crypto.subtle && window.TextEncoder)) { put('check', 'not available in this view; compare the hash on your approval device'); return; }
    window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)).then(function (digest) {
      put('check', hex(digest) === expected ? 'the displayed text has exactly this SHA-256' : 'MISMATCH: do not approve');
      resize();
    });
  }
  function show(result) {
    var data = result && result.structuredContent, view = data && data.assent;
    if (!view || typeof view.rendering_sha256 !== 'string' || typeof view.uri !== 'string') { put('status', 'This result carries no agreement rendering.'); resize(); return; }
    put('agreement', view.agreement_sha256); put('rendering', view.rendering_sha256);
    put('status', data.code === 'ASSENT_APPROVAL_REQUIRED' ? 'Owner approval is required. Nothing has been signed.' :
      data.code ? 'Refused: ' + data.code : 'Exact terms of this agreement.');
    request('resources/read', {uri: view.uri}).then(function (read) {
      var item = read && read.contents && read.contents[0];
      if (!item || typeof item.text !== 'string') { put('check', 'rendering unavailable'); return; }
      put('text', item.text); verify(item.text, view.rendering_sha256); resize();
    }, function () { put('check', 'rendering unavailable'); resize(); });
  }
  window.addEventListener('message', function (event) {
    if (event.source !== window.parent) { return; }
    var message = event.data;
    if (!message || message.jsonrpc !== '2.0') { return; }
    if (message.id !== undefined && waiting[message.id] && message.method === undefined) {
      var entry = waiting[message.id]; delete waiting[message.id];
      if (message.error) { entry.reject(message.error); } else { entry.resolve(message.result); }
      return;
    }
    if (message.method === 'ui/notifications/tool-result') { show(message.params); }
    else if (message.method === 'ui/resource-teardown' && message.id !== undefined) { post({jsonrpc: '2.0', id: message.id, result: {}}); }
  });
  request('ui/initialize', {appInfo: {name: 'aap-assent-review', version: '0.1.0'}, appCapabilities: {},
    protocolVersion: '2026-01-26'}).then(function () { notify('ui/notifications/initialized', {}); resize(); },
    function () { put('status', 'The host did not initialize this view.'); });
}());
</script>
</body>
</html>
'''
