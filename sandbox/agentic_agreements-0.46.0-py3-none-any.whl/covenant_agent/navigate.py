"""Find, explain and follow protocol actions without a network call.

``catalogue()`` joins the scanner (what exists) to the plain-language table
(what it is for). ``find`` matches words. ``next`` reads the agreement state
machine. Nothing here posts a transaction.
"""
from copy import deepcopy
import json
import re
from pathlib import Path

from covenant_language.safe_io import atomic_write

from . import action_jobs
from .action_copy import CATEGORIES, CORE, EXAMPLES, KEYWORDS, RELATED, SPEC
from .action_scan import observed_actions
from .errors import NativeError, need

VERSION = 'covenant-action-catalogue/0.1'
ROOT = Path(__file__).resolve().parents[1]
STOP = frozenset(
    'a an the to for of and or when they them someone i want my your please can you it on in with '
    'that this from into after before than then just really'.split()
)
SYNONYMS = {
    'pay': ('settle', 'payment', 'escrow', 'refund', 'stablecoin'),
    'payment': ('pay', 'settle'),
    'settle': ('pay', 'payment'),
    'deliver': ('delivery', 'handoff', 'work'),
    'delivery': ('deliver', 'show'),
    'delivered': ('deliver',),
    'agree': ('bind', 'propose', 'accept', 'terms', 'assent', 'offer'),
    'hire': ('propose', 'book', 'offer'),
    'verify': ('check', 'confirm', 'verdict', 'receipt'),
    'check': ('verify',),
    'private': ('privacy', 'shield', 'confidential'),
    'privacy': ('private', 'shield', 'confidential'),
    'govern': ('governance', 'vote', 'proposal'),
    'governance': ('govern', 'vote'),
    'reputation': ('endorse', 'signal'),
    'recover': ('recovery', 'rotate', 'continuity'),
    'dispute': ('challenge', 'appeal'),
    'loan': ('credit',),
    'lending': ('credit',),
    'secured': ('credit', 'collateral'),
    'collateral': ('credit',),
    'guarantor': ('guarantee', 'legal'),
    'guarantee': ('legal', 'guarantor'),
    'arbitration': ('legal', 'dispute'),
    'obligation': ('legal',),
    'obligations': ('legal',),
}
# Advanced drafting tools whose nested schemas have runnable synthetic examples.
ADVANCED_TOOLS = ('covenant_credit', 'covenant_legal')
TEMPLATES = (
    {
        'id': 'pay-on-delivery',
        'groups': (
            ('pay', 'settle', 'payment', 'compensate', 'escrow'),
            ('deliver', 'delivery', 'delivered', 'handoff', 'work'),
        ),
        'summary': 'Sign a work order, have the counterparty accept it, deliver the hash of the work, then settle a stablecoin. The chain stays idle unless someone opens a dispute.',
        'actions': list(CORE),
        'template': {
            'steps': ['covenant_propose', 'covenant_accept', 'covenant_deliver', 'covenant_settle'],
            'rail': 'x402',
            'unit': 'USDC',
            'fields': dict(EXAMPLES['work:covenant_propose']),
        },
    },
    {
        'id': 'agree-on-terms',
        'groups': (
            ('agree', 'bind', 'contract', 'terms', 'hire'),
        ),
        'summary': 'Propose a work order, or bind chain terms if the quantity is already a ledger resource.',
        'actions': ['work:covenant_propose', 'work:covenant_make', 'chain:BIND', 'language:OFFER'],
        'template': {'steps': ['covenant_propose', 'covenant_accept'], 'fields': dict(EXAMPLES['work:covenant_propose'])},
    },
    {
        'id': 'keep-it-private',
        'groups': (
            ('private', 'privacy', 'shield', 'confidential', 'secret'),
        ),
        'summary': 'Shielded and confidential chain operations hide note openings behind a proof.',
        'actions': ['chain:SHIELD_DEPOSIT', 'chain:SHIELD_TRANSFER', 'chain:CONFIDENTIAL_FUND'],
        'template': None,
    },
)
CHAIN_RULES = (
    {'id': 'chain:SHOW', 'when': {'held': True}},
    {'id': 'chain:DECIDE', 'when': {'held': True, 'state_in': ['BOUND', 'INDETERMINATE'], 'appeal_final': False}},
    {'id': 'chain:RESOLVE', 'when': {'held': True, 'state': 'CHALLENGED'}},
    {'id': 'chain:CHALLENGE', 'when': {'state_in': ['DECIDED', 'INDETERMINATE'], 'appeal_final': False, 'height_lte': 'challenge_end'}},
    {'id': 'chain:EXECUTE', 'when': {'held': True, 'state': 'DECIDED', 'result': 'SUPPORTED', 'height_gt': 'challenge_end'}},
    {'id': 'chain:RELEASE', 'when_any': (
        {'held': True, 'state': 'DECIDED', 'result': 'REFUTED', 'height_gt': 'challenge_end'},
        {'held': True, 'state_in': ['BOUND', 'INDETERMINATE'], 'timeout': 'RELEASE_IF_UNDECIDED',
         'height_gt': 'deadline', 'height_gt_or_absent': 'challenge_end'},
    )},
    {'id': 'chain:DISCHARGE', 'when': {'held': True}},
    {'id': 'chain:RECEIPT', 'when': {'state': 'AUTHORIZED'}},
)
WORK_RULES = {
    'PROPOSED': ['work:covenant_accept'],
    'BOUND': ['work:covenant_deliver', 'work:covenant_dispute'],
    'DELIVERED': ['work:covenant_settle', 'work:covenant_dispute'],
    'DISPUTED': ['work:covenant_decide'],
    'DECIDED': ['work:covenant_settle'],
    'SETTLED': [],
    'RELEASED': [],
    'INVALID': [],
}
_CACHE = None
_TOOL_SCHEMAS = None


def _example(action):
    if action['id'] in EXAMPLES:
        return dict(EXAMPLES[action['id']])
    numbers = {'quantity', 'limit', 'expiry', 'deadline', 'units', 'total', 'count', 'epoch', 'delay',
               'threshold', 'quorum_bps', 'challenge_blocks', 'appeal_blocks', 'unit_price', 'index',
               'generation', 'heartbeat', 'revision', 'amount', 'height'}
    body = {}
    for field in action['required']:
        body[field] = 1 if field in numbers else '<' + field + '>'
    return body


def _related(action, by_category):
    if action['id'] in RELATED:
        return list(RELATED[action['id']])
    prefix = action['name'].split('_')[0]
    pool = [other['id'] for other in by_category.get(action['category'], [])
            if other['id'] != action['id'] and other['name'].startswith(prefix)]
    if len(pool) < 3:
        pool.extend(other['id'] for other in by_category.get(action['category'], [])
                    if other['id'] != action['id'] and other['id'] not in pool)
    return pool[:3]


def catalogue():
    """The action catalogue. Raises if the source and the plain-language table disagree."""
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    observed = observed_actions()
    found = {row['id'] for row in observed}
    spec = set(SPEC)
    # Tool rows take their purpose from the tool catalog. The plain-language
    # table stays the curated list for chain, language, network and work.
    curated = {row['id'] for row in observed if row['family'] != 'tool'}
    missing = sorted(curated - spec)
    extra = sorted(spec - found)
    if missing or extra:
        raise NativeError('CATALOGUE_GAP', remediation=(
            'Actions in the code with no catalogue row: ' + ', '.join(missing) + '. '
            'Rows with no action in the code: ' + ', '.join(extra) + '.'
        ))
    staged = []
    for row in observed:
        if row['family'] == 'tool':
            category, tier, purpose = 'agent tools', 'advanced', row['hint'] or row['name']
        else:
            category, tier, purpose = SPEC[row['id']]
        need(category in CATEGORIES, 'CATALOGUE_GAP')
        need(tier in ('core', 'common', 'advanced'), 'CATALOGUE_GAP')
        if (row['id'] in CORE) != (tier == 'core'):
            raise NativeError('CATALOGUE_GAP', remediation=row['id'] + ' must be tier core exactly when it is one of the five verbs.')
        staged.append({
            'job': None, 'job_id': None, 'verb': None, 'kind': None,
            **row,
            'purpose': purpose,
            'category': category,
            'tier': tier,
            'keywords': list(KEYWORDS.get(row['id'], [])),
            'related': [],
            'example': None,
        })
    by_category = {}
    for row in staged:
        by_category.setdefault(row['category'], []).append(row)
    for row in staged:
        row['related'] = _related(row, by_category)
        row['example'] = _example(row)
        # Users meet jobs: every row names its job, its visible verb and the kind that selects it.
        placed = action_jobs.placement(row['id']) or {'job': None, 'job_id': None, 'verb': None, 'kind': None}
        row.update(placed)
    staged.sort(key=lambda row: (CATEGORIES.index(row['category']), {'core': 0, 'common': 1, 'advanced': 2}[row['tier']], row['id']))
    _CACHE = staged
    return staged


def _index():
    rows = catalogue()
    by_id = {row['id']: row for row in rows}
    by_name = {}
    for row in rows:
        by_name.setdefault(row['name'], []).append(row)
    return by_id, by_name


def _tool_parameters(name):
    """The exact installed ``parameters`` schema for one ``tool:NAME.ACTION`` row.

    It is read from the same keyless exchange catalog the action scanner lists,
    so explain never maintains a second copy of a nested schema.
    """
    global _TOOL_SCHEMAS
    if _TOOL_SCHEMAS is None:
        from covenant_chain.agent_exchange_tools import ExchangeTools
        from .action_scan import _ListedNetwork
        found = {}
        for tool in ExchangeTools(network=_ListedNetwork()).tools():
            for branch in tool['inputSchema'].get('oneOf') or []:
                properties = branch.get('properties') or {}
                verb = (properties.get('action') or {}).get('const')
                if verb:
                    found[tool['name'] + '.' + verb] = properties.get('parameters') or {'type': 'object'}
        _TOOL_SCHEMAS = found
    schema = _TOOL_SCHEMAS.get(name)
    return None if schema is None else deepcopy(schema)


def _with_schema(row):
    """Attach the nested call shape to a tool row; other families are unchanged."""
    row = dict(row)
    # Work actions whose decision field takes exact uppercase result values.
    decision_fields = {'covenant_decide': 'result', 'covenant_settle': 'decision'}
    if row.get('family') == 'work' and row['name'] in decision_fields:
        from .envelope import RESULTS
        field = decision_fields[row['name']]
        # Exact uppercase values; lowercase words are refused as RESULT.
        row['field_values'] = {field: sorted(RESULTS)}
        row['host_supplied'] = ['as_of', 'ledger']
        return row
    if row.get('family') != 'tool' or '.' not in row['name']:
        return row
    tool, verb = row['name'].split('.', 1)
    schema = _tool_parameters(row['name'])
    if schema is None:
        return row
    if tool == 'covenant_legal':
        from covenant_chain.advanced_schemas import compact_legal_schema
        schema = compact_legal_schema(schema)
        row['schema_encoding'] = 'STANDARD_JSON_SCHEMA_WITH_LOCAL_REFS'
    row['parameters_schema'] = schema
    row['call_shape'] = {'tool': tool, 'arguments': {'action': verb, 'parameters': 'OBJECT_MATCHING_parameters_schema'}}
    if tool in ADVANCED_TOOLS:
        from covenant_chain.advanced_schemas import describe
        described = describe(tool, {'type': 'object'})
        example = described['examples'][0]['arguments']
        if example['action'] == verb:
            row['example'] = {'parameters': deepcopy(example['parameters'])}
            row['example_is_synthetic'] = True
        row['describe_call'] = {'tool': tool, 'arguments': {'action': 'describe', 'parameters': {}}}
        row['guide'] = described['guide']
        row['signing_recipe'] = described['signing_recipe']
        row['execution_boundary'] = described.get('execution_boundary') or (
            'Drafting and assent payloads are not execution. Appointment, collateral control, '
            'funding and enforcement require separately adopted authority.')
        row['draft_is_executable'] = False
        if verb == 'node':
            row['node_usage'] = described['node_usage']
    row['execution_authorized'] = False
    return row


def _reserved(row):
    """A reserved 0.15 op name is always refused; say so instead of offering it."""
    if not row.get('id', '').startswith('chain:'):
        return row
    try:
        from covenant_chain.reserved_ops import refusal
    except ImportError:  # the agent-only wheel ships without covenant_chain
        return row
    code = refusal(row['id'][len('chain:'):])
    if code is not None:
        row['always_refused'] = code
    return row


def explain(action):
    """A visible verb with its job and kinds, one action, or every action sharing a bare name.

    ``propose`` returns the verb card; ``propose:marketplace.quick_trade`` the
    one action that kind names. Every row says its job, verb and kind first. A
    ``tool:`` row also returns the exact nested ``parameters_schema`` that the
    installed tool validates, so agents need not read validators. A bare tool
    name such as ``covenant_credit`` lists its actions as an ambiguous result.
    """
    need(type(action) is str and 1 <= len(action) <= 80, 'ARGUMENTS')
    by_id, by_name = _index()
    if action in by_id:
        return _reserved(_with_schema(by_id[action]))
    verb = action_jobs.split(action)
    if verb is not None:
        if verb[1] is None:
            return verb_card(verb[0])
        return explain(action_jobs.resolve(*verb))
    if action in INSTRUMENTS:
        return instrument_card(action)
    matches = by_name.get(action, [])
    if len(matches) == 1:
        return _reserved(_with_schema(matches[0]))
    if not matches and re.fullmatch(r'covenant_[a-z0-9_]{1,70}', action):
        matches = [row for row in catalogue() if row['family'] == 'tool' and row['name'].startswith(action + '.')]
    if len(matches) > 1:
        return {
            'ambiguous': True,
            'query': action,
            'entries': [dict(row) for row in matches],
            'remediation': 'Use the qualified id, for example ' + matches[0]['id'] + '.',
        }
    if len(matches) == 1:
        return _with_schema(matches[0])
    placed = action_jobs.placement(action)
    if placed is not None:
        return _outside_catalogue(action, placed)
    raise NativeError('ACTION_UNKNOWN', remediation='Call covenant.find with ordinary words, or covenant actions to see the tree.')


INSTRUMENTS = ('onboard', 'explain', 'call')


def _outside_catalogue(ident, placed):
    """An installed tool action the scanner does not list still has its job, verb and kind."""
    family, _, name = ident.partition(':')
    where = ('the work-order host (covenant_agent.server)' if family == 'native' else
             'the agent host; covenant_explain there returns its exact installed schema')
    return {**placed, 'id': ident, 'name': name, 'family': family, 'tier': 'advanced', 'category': None,
            'purpose': 'An installed tool action outside the action catalogue. Call it by its old name, or as '
                       'this verb with this kind, on ' + where + '.',
            'required': ['parameters'] if family == 'tool' and '.' in name else [], 'optional': [], 'nullable': [],
            'example': None, 'related': [], 'source': None, 'catalogued': False, 'execution_authorized': False}


def verb_card(verb, ranking=None):
    """One visible verb: its job, what it does and every kind, in order by nature or by use."""
    rows = _index()[0]
    if ranking and ranking.get('actions'):
        from .action_rank import order
        ordered = order(action_jobs.kinds(verb).values(), ranking, rows)
        return action_jobs.card(verb, rows, order=ordered, mode='USE')
    return action_jobs.card(verb, rows)


def instrument_card(name):
    """onboard, explain and call: the entry instruments beside the seven jobs."""
    data = action_jobs.document()
    need(name in data['instruments'], 'ACTION_UNKNOWN')
    return {'instrument': name, 'says': data['instruments'][name]['says'],
            'tools': list(data['instruments'][name]['tools']), 'model': data['model'],
            'golden_path': list(data['golden_path']), 'execution_authorized': False}


def _tokens(text):
    words = re.findall(r'[a-z0-9]+', text.lower())
    base = [word for word in words if word not in STOP and len(word) > 1]
    expanded = list(base)
    for word in base:
        expanded.extend(SYNONYMS.get(word, ()))
    # Keep order, drop duplicates.
    seen = set()
    out = []
    for word in expanded:
        if word not in seen:
            seen.add(word)
            out.append(word)
    return base, out


def _template_hit(expanded):
    have = set(expanded)
    found = []
    for template in TEMPLATES:
        if all(have & set(group) for group in template['groups']):
            found.append(template)
    return found


def find(query, diversify=False):
    """Match ordinary words to actions. No embeddings and no network.

    ``diversify`` re-ranks the best 32 matches by maximal marginal relevance
    (lambda 0.5) so near-duplicate actions do not crowd the eight shown.
    Without it the order is unchanged.
    """
    need(type(query) is str and len(query) <= 400, 'ARGUMENTS')
    need(type(diversify) is bool, 'ARGUMENTS')
    base, expanded = _tokens(query)
    templates = _template_hit(expanded) if base else []
    boosted = set()
    for template in templates:
        boosted.update(template['actions'])
    matches = []
    for row in catalogue():
        score = 0
        name_words = set(re.findall(r'[a-z0-9]+', row['name'].lower()))
        purpose_words = set(re.findall(r'[a-z0-9]+', row['purpose'].lower()))
        category_words = set(re.findall(r'[a-z0-9]+', row['category'].lower()))
        keyword_words = set()
        for keyword in row['keywords']:
            keyword_words.update(re.findall(r'[a-z0-9]+', keyword.lower()))
        for token in expanded:
            if token == row['name'].lower() or token in name_words:
                score += 12 if token in base else 8
            elif token in purpose_words:
                score += 3
            if token in category_words:
                score += 4
            if token in keyword_words:
                score += 5
        if row['id'] in boosted:
            score += 15
        if score:
            matches.append((score, row))
    matches.sort(key=lambda item: (-item[0], item[1]['id']))
    diversity = None
    shown = matches[:8]
    if diversify:
        from .biomimicry.inhibition import mmr
        pool = matches[:32]
        by_id = {row['id']: (score, row) for score, row in pool}
        diversity = mmr([{'id': row['id'], 'score': score, 'features': sorted(_feature_words(row))}
                         for score, row in pool], k=8)
        shown = [by_id[ident] for ident in diversity['order']]
        diversity = {key: diversity[key] for key in ('profile', 'method', 'lambda_bps', 'order', 'spend_input')}
    listed = []
    for score, row in shown:
        entry = {
            'job': row['job'], 'verb': row['verb'], 'kind': row['kind'],
            'id': row['id'], 'name': row['name'], 'purpose': row['purpose'],
            'category': row['category'], 'tier': row['tier'], 'score': score,
            'required': row['required'], 'example': row['example'],
        }
        if row['family'] == 'tool':
            # The flat example only says "parameters"; the nested schema is one call away.
            entry['schema_call'] = {'tool': 'covenant_explain', 'arguments': {
                'action': 'action', 'parameters': {'id': row['id']}}}
        listed.append(entry)
    template = None
    if templates:
        best = templates[0]
        template = {'id': best['id'], 'summary': best['summary'], 'actions': list(best['actions']),
                    'template': best['template']}
    from covenant_chain.onboarding import task_matches
    result = {
        'version': VERSION,
        'query': query,
        'offline': True,
        'jobs': _jobs_answer(set(expanded), matches),
        'matches': listed,
        'task_routes': task_matches(query),
        'template': template,
        'execution_authorized': False,
    }
    if diversity is not None:
        result['diversity'] = diversity
    return result


def _jobs_answer(words, scored, jobs_shown=3, verbs_shown=3, kinds_shown=2):
    """Answer by job first: the jobs and verbs the words name, then those of the best matches.

    Compact on purpose (Hick's law, and every byte travels twice over MCP):
    covenant_explain with a verb lists all of its kinds.
    """
    strength, kinds = {}, {}
    for verb in action_jobs.job_verbs():
        if verb in words:
            strength[verb] = 20
    for name, verb in action_jobs.aliases().items():
        if name in words:
            strength[verb] = 20
    jobs = action_jobs.jobs()
    for job in jobs:
        if set(re.findall(r'[a-z]+', job['title'].lower())) - STOP & words:
            for verb in job['verbs']:
                strength.setdefault(verb, 5)
    for score, row in scored[:32]:
        if row['verb'] is None:
            continue
        strength[row['verb']] = max(strength.get(row['verb'], 0), score)
        shown = kinds.setdefault(row['verb'], [])
        if len(shown) < kinds_shown:
            shown.append(row['kind'])
    answer = []
    for position, job in enumerate(jobs):
        chosen = sorted((verb for verb in job['verbs'] if verb in strength),
                        key=lambda verb: (-strength[verb], job['verbs'].index(verb)))
        if chosen:
            answer.append((-strength[chosen[0]], position, job, chosen[:verbs_shown]))
    answer.sort(key=lambda item: item[:2])
    return [{'job': job['title'], 'verbs': [{'verb': verb, 'kinds': kinds.get(verb, [])} for verb in chosen]}
            for _, _, job, chosen in answer[:jobs_shown]]


def _feature_words(row):
    words = set(re.findall(r'[a-z0-9]+', row['name'].lower()))
    words.update(re.findall(r'[a-z0-9]+', row['category'].lower()))
    for keyword in row['keywords']:
        words.update(re.findall(r'[a-z0-9]+', keyword.lower()))
    return {word[:80] for word in words if word}


def tree():
    """Core verbs first, then every other action inside its category."""
    rows = catalogue()
    categories = []
    for name in CATEGORIES:
        members = [row for row in rows if row['category'] == name]
        if not members:
            continue
        categories.append({
            'category': name,
            'common': [_brief(row) for row in members if row['tier'] in ('core', 'common')],
            'advanced': [_brief(row) for row in members if row['tier'] == 'advanced'],
        })
    return {
        'version': VERSION,
        'jobs': action_jobs.overview(),
        'core': [_brief(explain(name)) for name in CORE],
        'categories': categories,
        'counts': _counts(rows),
        'advanced_are_usable': True,
    }


def _brief(row):
    return {'id': row['id'], 'name': row['name'], 'purpose': row['purpose'], 'tier': row['tier'], 'category': row['category']}


def _counts(rows):
    counts = {name: 0 for name in CATEGORIES}
    tiers = {'core': 0, 'common': 0, 'advanced': 0}
    for row in rows:
        counts[row['category']] += 1
        tiers[row['tier']] += 1
    return {'total': len(rows), 'by_category': counts, 'by_tier': tiers}


def _height_value(agreement, field):
    if field == 'deadline':
        return agreement.get('terms', {}).get('deadline')
    if field == 'challenge_end':
        return agreement.get('challenge_end')
    return agreement.get(field)


def _clause_ready(agreement, clause, height):
    if clause.get('held') is True and agreement.get('held') is not True:
        return False, None
    if 'state' in clause and agreement.get('state') != clause['state']:
        return False, None
    if 'state_in' in clause and agreement.get('state') not in clause['state_in']:
        return False, None
    if 'appeal_final' in clause and bool(agreement.get('appeal_final')) != clause['appeal_final']:
        return False, None
    if 'result' in clause:
        decision = agreement.get('decision') or {}
        if decision.get('result') != clause['result']:
            return False, None
    if 'timeout' in clause and agreement.get('terms', {}).get('timeout') != clause['timeout']:
        return False, None
    needs = None
    for key, field in (('height_gt', 'gt'), ('height_lte', 'lte'), ('height_gt_or_absent', 'gt_or_absent')):
        if key not in clause:
            continue
        value = _height_value(agreement, clause[key])
        if key == 'height_gt_or_absent' and value is None:
            continue
        if height is None:
            needs = 'height'
            continue
        if value is None:
            return False, None
        if field == 'gt' and not height > value:
            return False, None
        if field == 'lte' and not height <= value:
            return False, None
        if field == 'gt_or_absent' and not height > value:
            return False, None
    if needs:
        return False, needs
    return True, None


def _chain_next(agreement, height):
    legal = []
    for rule in CHAIN_RULES:
        clauses = rule['when_any'] if 'when_any' in rule else (rule['when'],)
        ready = False
        needs = None
        for clause in clauses:
            ok, missing = _clause_ready(agreement, clause, height)
            if ok:
                ready = True
                needs = None
                break
            if missing == 'height':
                needs = 'height'
        if ready or needs:
            legal.append({
                'id': rule['id'],
                'ready': ready,
                'needs': needs,
                'reason': 'Legal in state ' + str(agreement.get('state')) + ' from the chain agreement rules.',
            })
    return legal


def next_actions(agreement_id, *, state=None, envelope=None, height=None, store=None, as_of=None):
    """Legal next actions for one agreement, from its current state."""
    need(type(agreement_id) is str and 1 <= len(agreement_id) <= 128, 'ARGUMENTS')
    if envelope is None and store is not None and agreement_id in store:
        from .codec import canonical
        blob = store.get(agreement_id)
        if blob is not None:
            envelope = json.loads(blob.decode('utf-8'))
    if envelope is not None:
        from .envelope import PROFILE, verify
        need(type(envelope) is dict and envelope.get('profile') in (PROFILE, 'covenant-bilateral/0.2'), 'PROFILE')
        successor = envelope['profile'] == 'covenant-bilateral/0.2'
        report = verify(envelope, **({'as_of': as_of} if successor else {}))
        ids = list(WORK_RULES.get(report['verdict'], []))
        if successor and report['verdict'] == 'DECIDED' and not envelope['dispute']['appeal']:
            if envelope['terms']['challenge_window'] > 0:
                ids.append('work:covenant_decide')
        rows = []
        for name in ids:
            ready, needs = True, None
            if successor and name in ('work:covenant_deliver', 'work:covenant_settle', 'work:covenant_decide'):
                if as_of is None:
                    ready, needs = False, 'owner_clock'
                elif name == 'work:covenant_deliver' or (name == 'work:covenant_settle' and report['verdict'] == 'DELIVERED'):
                    if as_of > envelope['terms']['deadline']:
                        ready, needs = False, 'DEADLINE_EXPIRED'
                elif report['verdict'] == 'DECIDED':
                    case = envelope['dispute']; decision = case['appeal'] or case['decision']
                    end = case['decision']['body']['at'] + envelope['terms']['challenge_window']
                    if name == 'work:covenant_settle':
                        if decision['body']['result'] == 'INDETERMINATE':
                            ready, needs = False, 'SETTLE_INDETERMINATE'
                        elif as_of < decision['body']['at'] or (not case['appeal'] and as_of < end):
                            ready, needs = False, 'APPEAL_WINDOW_OPEN'
                    elif not (case['decision']['body']['at'] <= as_of < end):
                        ready, needs = False, 'APPEAL_EXPIRED'
            rows.append(_next_row(name, ready, needs))
        return {
            'version': VERSION,
            'agreement_id': agreement_id,
            'family': 'work',
            'state': report['verdict'],
            'actions': rows,
            'clock_checked': successor and report['expiry_checked'],
            'authority_checked': False,
            'ledger_touched': False,
            'execution_authorized': False,
        }
    agreement = None
    if type(state) is dict:
        agreements = state.get('agreements') if type(state.get('agreements')) is dict else None
        if agreements and agreement_id in agreements:
            agreement = agreements[agreement_id]
        if height is None and type(state.get('height')) is int:
            height = state['height']
    if agreement is None:
        raise NativeError('AGREEMENT_NOT_FOUND', remediation=(
            'Pass the chain state that holds this agreement, or the bilateral envelope (or a store that has its CID).'
        ))
    rows = []
    for item in _chain_next(agreement, height):
        rows.append(_next_row(item['id'], item['ready'], item['needs']))
    return {
        'version': VERSION,
        'agreement_id': agreement_id,
        'family': 'chain',
        'state': agreement.get('state'),
        'height': height,
        'actions': rows,
        'ledger_touched': False,
        'execution_authorized': False,
    }


def _next_row(action_id, ready, needs):
    row = explain(action_id)
    return {
        'id': row['id'], 'name': row['name'], 'purpose': row['purpose'], 'category': row['category'],
        'tier': row['tier'], 'ready': ready, 'needs': needs, 'required': row['required'], 'example': row['example'],
    }


def perform(name, args, *, host=None):
    """Prepare any catalogued action. Work-order verbs run on the host. Chain ops are not broadcast.

    ``name`` may also be a visible verb (``settle``) or a verb with a kind
    (``refund:chain.RELEASE``). The verb resolves to exactly one old action,
    which then runs with the same arguments and refusals; the reply adds where
    it was routed and what usually comes next. Use history never picks the kind.
    """
    need(type(args) is dict, 'ARGUMENTS')
    verb = action_jobs.split(name)
    if verb is not None:
        tools = {item['name'] for item in getattr(host, 'tools', None) or []}
        ident = action_jobs.resolve(*verb, runnable=lambda i: not i.startswith('native:') or i[7:] in tools)
        if ident.startswith('native:'):
            result = host.call(ident[7:], args)
        else:
            result = perform(ident, args, host=host)
        ranking = host.use_ranking() if hasattr(host, 'use_ranking') else None
        from .action_rank import suggest_next
        routed = {'verb': verb[0], 'kind': action_jobs.kind_of(ident), 'id': ident,
                  'job': action_jobs.placement(ident)['job'], 'grants_authority': False}
        follow = suggest_next(ident, ranking, _index()[0])
        if type(result) is dict:
            return {**result, 'routing': routed, 'suggested_next': follow}
        return {'result': result, 'routing': routed, 'suggested_next': follow}
    described = explain(name)
    if described.get('ambiguous'):
        raise NativeError('ACTION_AMBIGUOUS', remediation=described['remediation'])
    missing = [field for field in described['required'] if field not in args]
    if missing:
        return {
            'status': 'NEEDS_FIELDS',
            'id': described['id'],
            'missing': missing,
            'example': described['example'],
            'remediation': 'Add the missing fields. An example is included.',
            'execution_authorized': False,
        }
    if described['family'] == 'work' and host is not None and host.signer is not None:
        tool = described['name']
        names = {item['name'] for item in host.tools}
        if tool in names:
            result = host.call(tool, args)
        elif tool == 'covenant_dispute':
            from .verbs import dispute
            need(set(args) <= {'envelope', 'reason', 'evidence_hash'}, 'ARGUMENTS')
            before = host._progress_before(args['envelope'])
            env = dispute(args['envelope'], signer=host.signer, reason=args['reason'], evidence_hash=args['evidence_hash'],
                          **host._progress_context(args['envelope']))
            result = {'envelope': env, 'cid': host._keep(env), 'ledger_touched': False, 'execution_authorized': False,
                      **host._progress_flags(before, env)}
            if hasattr(host, 'dispute_opened'):
                host.dispute_opened(env)
        elif tool == 'covenant_decide':
            from .verbs import decide
            need(set(args) <= {'envelope', 'result', 'evidence_hash', 'paid_amount'}, 'ARGUMENTS')
            before = host._progress_before(args['envelope'])
            env = decide(args['envelope'], signer=host.signer, result=args['result'], evidence_hash=args['evidence_hash'],
                         paid_amount=args.get('paid_amount'), **host._progress_context(args['envelope']))
            result = {'envelope': env, 'cid': host._keep(env), 'ledger_touched': False, 'execution_authorized': False,
                      **host._progress_flags(before, env)}
        else:
            result = _prepared(described, args)
        if type(result) is dict:
            result = dict(result)
            result['catalogue_id'] = described['id']
        return result
    if described['family'] == 'agent':
        if host is None or host.legacy is None:
            return {
                'status': 'PREPARED',
                'id': described['id'],
                'arguments': args,
                'remediation': 'Attach the covenant-agent host to run this legacy tool. The arguments are ready.',
                'execution_authorized': False,
                'ledger_touched': False,
            }
        result = host.legacy.call(described['name'], args)
        return {'status': 'CALLED', 'id': described['id'], 'result': result, 'execution_authorized': False, 'ledger_touched': False}
    return _prepared(described, args)


def _prepared(described, args):
    payload = {field: args[field] for field in list(described['required']) + list(described['optional']) if field in args}
    return {
        'status': 'PREPARED',
        'id': described['id'],
        'family': described['family'],
        'op': described['name'],
        'payload': payload,
        'source': described['source'],
        'remediation': 'The payload matches the required fields. Submitting it is a separate step on a chain or a language bundle you pin yourself.',
        'execution_authorized': False,
        'ledger_touched': False,
        'chain_ledger_touched': False,
    }


def render_tree():
    """The first list: the model, the golden path and seven jobs with their verbs."""
    view = action_jobs.overview()
    named = ''.join(f' {name} is a name for {verb}.' for name, verb in view['golden_path_names'].items())
    lines = [view['model'], '', 'Golden path: ' + ', '.join(view['golden_path']) + '.' + named, '']
    for number, job in enumerate(view['jobs'], 1):
        lines.append(f"{number}. {job['title']}")
        for row in job['verbs']:
            lines.append(f"   {row['verb']:<9} {row['says']} ({row['kinds']} kinds)")
        lines.append('')
    lines.append('Start with ' + ', '.join(view['instruments']) + '. ' + str(len(view['visible_verbs'])) +
                 ' visible verbs; ' + str(view['aliases']) + ' old names stay aliases that keep working.')
    lines.append('covenant explain <verb> lists its kinds. covenant actions --all lists every old name.')
    return '\n'.join(lines).rstrip() + '\n'


def render_full_tree():
    """Every catalogued action under its old category, core verbs first."""
    body = tree()
    lines = ['core']
    for row in body['core']:
        lines.append(f"  {row['name']:<28} {row['purpose']}")
    lines.append('')
    for category in body['categories']:
        common = category['common']
        advanced = category['advanced']
        lines.append(f"{category['category']}  ({len(common)} in front, {len(advanced)} advanced)")
        for row in common:
            if row['tier'] == 'core':
                continue
            lines.append(f"  {row['id']:<28} {row['purpose']}")
        if advanced:
            lines.append('  advanced')
            for row in advanced:
                lines.append(f"    {row['id']:<26} {row['purpose']}")
        lines.append('')
    counts = body['counts']
    lines.append(f"{counts['total']} actions. {counts['by_tier']['core']} core, {counts['by_tier']['common']} common, {counts['by_tier']['advanced']} advanced.")
    return '\n'.join(lines).rstrip() + '\n'


def render_markdown():
    rows = catalogue()
    counts = _counts(rows)
    view = action_jobs.overview()
    data = action_jobs.document()
    by_id = {row['id']: row for row in rows}
    lines = [
        '# Covenant actions',
        '',
        'Generated from the protocol source. Do not edit this file by hand.',
        'Regenerate it with `python -m covenant_agent --write`.',
        '',
        view['model'],
        '',
        f"{counts['total']} actions: {counts['by_tier']['core']} core, {counts['by_tier']['common']} common, {counts['by_tier']['advanced']} advanced.",
        f"They sit behind {len(data['verbs'])} verbs in seven jobs. "
        + ''.join(f"`{name}`, a golden-path step, is a name for `{row['verb']}`. " for name, row in data['aliases'].items())
        + 'With the entry instruments ' + ', '.join(data['instruments'])
        + f" that makes {len(view['visible_verbs'])} visible verbs.",
        'Call a verb with a kind: `covenant_call` takes `{"verb", "kind", "parameters"}` and `covenant_action` takes '
        '`verb:kind` as its name. Every old name below stays an alias that keeps working, with the same arguments, '
        'validation and refusals. A job, verb or kind grants no authority and changes no signed meaning.',
        'Without a kind, a verb uses the first of its defaults that the host can run. Kinds are listed in order by '
        'nature: everyday tier, AAP Core tools, then level. A host that adopts the private order by use '
        '(`covenant_agent.action_rank`) reorders lists and suggestions only.',
        '',
        '## Jobs and verbs',
        '',
    ]
    for number, job in enumerate(view['jobs'], 1):
        lines.extend([f"### {number}. {job['title']}", '', job['says'], ''])
        for row in job['verbs']:
            verb = data['verbs'][row['verb']]
            default = ', '.join('`' + kind + '`' for kind in verb['defaults']) or 'none; pass a kind'
            lines.append(f"- `{row['verb']}`: {row['says']} {row['kinds']} kinds. Default: {default}. "
                         f"Next: {', '.join(verb['next'])}.")
        lines.append('')
    lines.extend(['### Entry instruments', ''])
    for name, says in view['instruments'].items():
        lines.append(f"- `{name}`: {says}")
    lines.extend(['', '## Old names by verb', '',
                  'Each line is a kind and the old name it calls. Installed tools outside the action catalogue are marked.', ''])
    for verb in data['verbs']:
        lines.extend([f"### {verb}", ''])
        for ident in action_jobs.by_nature(action_jobs.kinds(verb).values(), by_id):
            note = '' if ident in by_id else ' (installed tool outside the catalogue)'
            lines.append(f"- `{action_jobs.kind_of(ident)}` = `{ident}`{note}")
        lines.append('')
    lines.extend(['## Core', ''])
    for name in CORE:
        lines.extend(_markdown_action(explain(name)))
    for category in tree()['categories']:
        lines.extend(['', f"## {category['category']}", ''])
        shown = [row for row in category['common'] if row['tier'] != 'core']
        if shown:
            lines.append('### Common')
            lines.append('')
            for brief in shown:
                lines.extend(_markdown_action(explain(brief['id'])))
        if category['advanced']:
            lines.append('### Advanced')
            lines.append('')
            for brief in category['advanced']:
                lines.extend(_markdown_action(explain(brief['id'])))
    return '\n'.join(lines).rstrip() + '\n'


def _markdown_action(row):
    optional = ', '.join(row['optional']) if row['optional'] else 'none'
    nullable = ''
    if row['nullable']:
        nullable = ' Nullable keys: ' + ', '.join(row['nullable']) + '.'
    related = ', '.join(row['related']) if row['related'] else 'none'
    return [
        f"#### {row['id']}",
        '',
        row['purpose'],
        '',
        f"- Job: {row['job']}; verb `{row['verb']}`; kind `{row['kind']}`",
        f"- Family: `{row['family']}`",
        f"- Tier: {row['tier']}",
        f"- Required: {', '.join(row['required']) if row['required'] else 'none'}",
        f"- Optional: {optional}.{nullable}",
        f"- Example: `{json.dumps(row['example'], sort_keys=True, separators=(',', ':'))}`",
        f"- Related: {related}",
        f"- Source: `{row['source']}`",
        '',
    ]


def _jsonable(value):
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    return value


def export_catalogue():
    rows = catalogue()
    data = action_jobs.document()
    by_id = {row['id']: row for row in rows}
    jobs = {'format': data['format'], 'model': data['model'], 'golden_path': data['golden_path'],
            'jobs': data['jobs'], 'aliases': data['aliases'], 'instruments': data['instruments'],
            'native': data['native'],
            'visible_verbs': action_jobs.visible_verbs(),
            # A list keeps the order by nature through sort_keys.
            'verbs': {verb: {**row, 'kinds': [{'kind': action_jobs.kind_of(ident), 'id': ident} for ident in
                                              action_jobs.by_nature(action_jobs.kinds(verb).values(), by_id)]}
                      for verb, row in data['verbs'].items()}}
    return _jsonable({
        'version': VERSION,
        'jobs': jobs,
        'core': list(CORE),
        'categories': list(CATEGORIES),
        'counts': _counts(rows),
        'actions': rows,
        'chain_rules': [dict(rule) for rule in CHAIN_RULES],
        'work_rules': WORK_RULES,
        'templates': [
            {'id': item['id'], 'groups': [list(group) for group in item['groups']], 'summary': item['summary'],
             'actions': list(item['actions']), 'template': item['template']}
            for item in TEMPLATES
        ],
        'synonyms': SYNONYMS,
        'stopwords': sorted(STOP),
    })


def write_documents():
    """Refresh the committed reference and the TypeScript catalogue copy."""
    payload = json.dumps(export_catalogue(), indent=2, sort_keys=True) + '\n'
    markdown = render_markdown()
    targets = [
        ROOT / 'docs' / 'ACTIONS.md',
        ROOT / 'sdk' / 'conformance' / 'actions.json',
        ROOT / 'sdk' / 'typescript' / 'actions.json',
    ]
    atomic_write(targets[0], markdown)
    for path in targets[1:]:
        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(path, payload)
    return targets


class Covenant:
    """Navigation and drafting: ``covenant.find``, ``covenant.draft``, and the rest."""

    def find(self, query):
        return find(query)

    def explain(self, action):
        return explain(action)

    def next(self, agreement_id, **kwargs):
        return next_actions(agreement_id, **kwargs)

    def action(self, name, args, host=None):
        return perform(name, args, host=host)

    def tree(self):
        return tree()

    def templates(self):
        from .drafting import library
        return library()

    def draft(self, text, **kwargs):
        from .drafting import draft
        return draft(text, **kwargs)

    def lint(self, document):
        from .drafting import lint
        return lint(document)

    def simulate(self, document):
        from .drafting import simulate
        return simulate(document)

    def counter(self, document, changes, party):
        from .drafting import counter
        return counter(document, changes, party=party)

    def accept_draft(self, document, party):
        from .drafting import accept_draft
        return accept_draft(document, party)

    def compose(self, parent, child):
        from .drafting import compose
        return compose(parent, child)


covenant = Covenant()


def main(argv=None):
    import sys
    args = list(sys.argv[1:] if argv is None else argv)
    if args == ['--write']:
        for path in write_documents():
            print(path)
        return 0
    # The seven jobs first; --all keeps the tree of every old name.
    print(render_full_tree() if args == ['--all'] else render_tree())
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
