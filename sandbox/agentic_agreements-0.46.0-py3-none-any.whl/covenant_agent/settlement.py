"""Stablecoin settlement instructions for x402 and AP2.

This ledger is a local simulation. It conserves the balances the owner loaded.
It does not broadcast a transaction, query a facilitator, or treat an external
transaction hash as verified. Protocol fees stay at zero so the economics
module can own the schedule.
"""
from copy import deepcopy

from .codec import canonical, digest, exact, public_key, sign, verify
from .errors import NativeError, need

STABLECOINS = frozenset({'USDC', 'USDT', 'DAI', 'USDG'})
NATIVE_UNITS = frozenset({'COV', 'NATIVE', 'payment'})
DEFAULT_X402_NETWORK = 'eip155:84532'
DEFAULT_AP2_NETWORK = 'ap2:testnet'
AP2_LABEL = 'COVENANT-AP2-MANDATE-0.1'
AP2_LINK_LABEL = 'COVENANT-AP2-MANDATE-LINK-0.1'
LINK_PROFILE = 'covenant-ap2-mandate-link/0.1'
RAIL_VERSION = 'covenant-settlement-rail/0.1'
GIVE_FIELDS = ('parent', 'holder', 'resource', 'limit', 'expiry', 'effects', 'profiles', 'delegate')
BIND_TERM_FIELDS = (
    'chain', 'principal', 'agent', 'counterparty', 'mandate', 'profile', 'resource', 'quantity',
    'effect', 'destination', 'executor', 'resolver', 'appeal_resolver', 'deadline',
    'challenge_blocks', 'timeout', 'terms_hash',
)
_SECRET_REQUEST_FIELDS = frozenset({'buyer', 'seller', 'signer'})


def require_stablecoin(unit):
    need(type(unit) is str, 'UNIT')
    if unit in NATIVE_UNITS:
        raise NativeError('NATIVE_TOKEN_SETTLEMENT_REFUSED')
    need(unit in STABLECOINS, 'STABLECOIN_REQUIRED')


class StablecoinLedger:
    """In-memory balances. One instance must be used from one thread."""

    def __init__(self, balances=None):
        self.accounts = {}
        self.escrow = {}
        self.receipts = {}
        for account, units in (balances or {}).items():
            need(type(account) is str and type(units) is dict, 'PAYMENT_FUNDS')
            for unit, amount in units.items():
                require_stablecoin(unit)
                need(type(amount) is int and 0 <= amount <= 2**53 - 1, 'QUANTITY')
                self._add(account, unit, amount)
        self._opened = self.total_map()

    def _add(self, account, unit, amount):
        row = self.accounts.setdefault(account, {})
        row[unit] = row.get(unit, 0) + amount
        need(row[unit] >= 0, 'PAYMENT_FUNDS')

    def balance(self, account, unit):
        return self.accounts.get(account, {}).get(unit, 0)

    def total(self, unit):
        held = sum(row['amount'] for row in self.escrow.values() if row['unit'] == unit and row['status'] == 'HELD')
        return held + sum(units.get(unit, 0) for units in self.accounts.values())

    def total_map(self):
        units = set(STABLECOINS)
        return {unit: self.total(unit) for unit in units if self.total(unit)}

    def move_to_escrow(self, effect_id, payer, unit, amount):
        require_stablecoin(unit)
        need(type(amount) is int and amount > 0, 'QUANTITY')
        if effect_id in self.escrow:
            row = self.escrow[effect_id]
            need(row['payer'] == payer and row['unit'] == unit and row['amount'] == amount, 'ESCROW_CONFLICT')
            return deepcopy(row)
        need(self.balance(payer, unit) >= amount, 'PAYMENT_FUNDS')
        self._add(payer, unit, -amount)
        self.escrow[effect_id] = {'payer': payer, 'unit': unit, 'amount': amount, 'status': 'HELD'}
        need(self.total_map() == self._opened, 'PAYMENT_FUNDS')
        return deepcopy(self.escrow[effect_id])

    def pay(self, effect_id, payee):
        row = self.escrow.get(effect_id)
        need(row is not None and row['status'] == 'HELD', 'ESCROW_STATE')
        self._add(payee, row['unit'], row['amount'])
        row['status'] = 'PAID'
        row['payee'] = payee
        need(self.total_map() == self._opened, 'PAYMENT_FUNDS')
        return deepcopy(row)

    def transfer(self, payer, payee, unit, amount):
        """Move units with no escrow row. The caller authenticates the payer first.

        Escrow stays move_to_escrow, pay and refund. The x402 exact rail calls this
        only after the payer's signature over the exact payment verified.
        """
        require_stablecoin(unit)
        need(type(payer) is str and type(payee) is str and payer != payee, 'PAYMENT_PARTIES')
        need(type(amount) is int and 0 < amount <= 2**53 - 1, 'QUANTITY')
        need(self.balance(payer, unit) >= amount, 'PAYMENT_FUNDS')
        self._add(payer, unit, -amount)
        self._add(payee, unit, amount)
        need(self.total_map() == self._opened, 'PAYMENT_FUNDS')
        return {'payer': payer, 'payee': payee, 'unit': unit, 'amount': amount, 'status': 'PAID', 'escrow': False}

    def refund(self, effect_id):
        row = self.escrow.get(effect_id)
        need(row is not None and row['status'] == 'HELD', 'ESCROW_STATE')
        self._add(row['payer'], row['unit'], row['amount'])
        row['status'] = 'REFUNDED'
        row['payee'] = row['payer']
        need(self.total_map() == self._opened, 'PAYMENT_FUNDS')
        return deepcopy(row)

    def remember(self, effect_id, receipt):
        previous = self.receipts.get(effect_id)
        if previous is not None:
            need(previous == receipt, 'SETTLEMENT_CONFLICT')
            return deepcopy(previous)
        self.receipts[effect_id] = deepcopy(receipt)
        return deepcopy(receipt)

    def observe(self, effect_id):
        if effect_id not in self.receipts:
            return {'status': 'NOT_OBSERVED', 'output_hash': None,
                    'assurance': 'SIMULATED_STABLECOIN_LEDGER'}
        raw = canonical(self.receipts[effect_id])
        return {'status': 'OBSERVED', 'output_hash': digest('COVENANT-SETTLEMENT-RECEIPT-0.1', self.receipts[effect_id]),
                'value': deepcopy(self.receipts[effect_id]), 'bytes': len(raw),
                'assurance': 'SIMULATED_STABLECOIN_LEDGER_NOT_EXTERNAL_PAYMENT'}


def x402_requirements(terms, source_cid, escrow_id):
    require_stablecoin(terms['unit'])
    return {
        'x402Version': 1,
        'scheme': 'exact',
        'network': terms['network'],
        'maxAmountRequired': str(terms['quantity']),
        'resource': 'urn:covenant:' + source_cid,
        'description': 'Covenant work-order settlement',
        'mimeType': 'application/json',
        'payTo': terms['pay_to'],
        'maxTimeoutSeconds': 600,
        'asset': terms['unit'],
        'extra': {
            'termsHash': terms['task_hash'],
            'escrowId': escrow_id,
            'assurance': 'COVENANT_BINDING_NOT_A_CHAIN_PAYMENT',
        },
    }


def ap2_mandate_body(terms, parties, escrow_id):
    require_stablecoin(terms['unit'])
    return {
        'ap2_version': '0.1',
        'mandate_type': 'PaymentMandate',
        'payer': parties['principal'],
        'payee': parties['counterparty'],
        'payment': {'currency': terms['unit'], 'amount': terms['quantity'], 'rail': 'stablecoin'},
        'terms_hash': terms['task_hash'],
        'escrow_id': escrow_id,
        'network': terms['network'],
    }


def sign_ap2_mandate(private, terms, parties, escrow_id):
    body = ap2_mandate_body(terms, parties, escrow_id)
    need(public_key(private) == parties['principal'], 'SIGNER_ROLE')
    return {'body': body, 'signature': sign(private, AP2_LABEL, body)}


def mandate_ok(mandate, terms, parties, escrow_id):
    try:
        exact(mandate, 'body signature')
        expected = ap2_mandate_body(terms, parties, escrow_id)
        if mandate['body'] != expected:
            return False
        return verify(parties['principal'], AP2_LABEL, mandate['body'], mandate['signature'])
    except Exception:
        return False


class _Rail:
    def __init__(self, rail, ledger, directory_label='local'):
        self.rail = rail
        self.ledger = ledger
        actions = ['SETTLE', 'AUTHORISE', 'CAPTURE', 'VOID']
        if rail == 'ap2':
            actions.append('LINK')
        self.manifest = {
            'version': RAIL_VERSION,
            'rail': rail,
            'unit_kind': 'STABLECOIN',
            'native_token': False,
            'assets': sorted(STABLECOINS),
            'instance': directory_label,
            'external_broadcast': False,
            'fee_schedule': 'DEFERRED_TO_ECONOMICS_MODULE',
            'fee_accountant': 'covenant_chain.economics',
            'protocol_fee': 0,
            'actions': actions,
            'scheme': 'covenant' if rail == 'x402' else 'ap2-mandate-link',
            'survival_improves': 'PAYMENT_REACH',
            'survival_dependency': 'OWNER_INSTALLED_SIMULATED_LEDGER',
            'survival_retire': 'UNREGISTER_ADAPTER_KEEP_LOCAL_RECEIPTS',
            'assurance': 'SIMULATED_STABLECOIN_LEDGER_NOT_CUSTODY_NOT_A_BANK',
        }
        canonical(self.manifest)

    def execute(self, effect_id, request):
        need(type(request) is dict and request.get('action') in self.manifest['actions'], 'ARGUMENTS')
        if request['action'] == 'SETTLE':
            return self._settle(effect_id, request)
        prior = self.observe(effect_id)
        if prior['status'] == 'OBSERVED':
            need(prior['value'].get('request_hash') == _request_hash(request), 'SETTLEMENT_CONFLICT')
            return prior
        if request['action'] == 'AUTHORISE':
            receipt = self._authorise(request)
        elif request['action'] == 'CAPTURE':
            receipt = self._capture(request)
        elif request['action'] == 'VOID':
            receipt = self._void(request)
        else:
            need(self.rail == 'ap2' and request['action'] == 'LINK', 'RAIL')
            receipt = link_ap2(request['envelope'], signer=request['signer'], cart_id=request.get('cart_id'))
        receipt['request_hash'] = _request_hash(request)
        receipt['fee_accountant'] = 'covenant_chain.economics'
        receipt['protocol_fee'] = 0
        self.ledger.remember(effect_id, receipt)
        return self.observe(effect_id)

    def _settle(self, effect_id, request):
        from .envelope import settle
        settled = settle(request['envelope'], request['signer'], self.ledger, rail=self.rail)
        self.ledger.remember(effect_id, settled['settlement'])
        return self.observe(effect_id)

    def _authorise(self, request):
        from covenant_x402.recourse import pay
        requirements = request['requirements']
        need(requirements.get('extra', {}).get('rail') == self.rail, 'RAIL')
        held = pay(requirements, buyer=request['buyer'], seller=request['seller'], ledger=self.ledger)
        held['action'] = 'AUTHORISE'
        held['refund_verb'] = None
        held['submitted'] = False
        return held

    def _capture(self, request):
        from covenant_x402.recourse import settle_delivery
        held = request['held']
        need(held['requirements']['extra']['rail'] == self.rail, 'RAIL')
        settled = settle_delivery(held, request['content'], seller=request['seller'], buyer=request['buyer'],
                                  ledger=self.ledger)
        settled['action'] = 'CAPTURE'
        settled['refund_verb'] = None
        settled['submitted'] = False
        return settled

    def _void(self, request):
        from covenant_x402.recourse import release_if_silent
        held = request['held']
        need(held['requirements']['extra']['rail'] == self.rail, 'RAIL')
        released = release_if_silent(held, buyer=request['buyer'], ledger=self.ledger, as_of=request['as_of'])
        released['action'] = 'VOID'
        return released

    def observe(self, effect_id):
        return self.ledger.observe(effect_id)


class X402Adapter(_Rail):
    def __init__(self, ledger, directory_label='local'):
        super().__init__('x402', ledger, directory_label)


class AP2Adapter(_Rail):
    def __init__(self, ledger, directory_label='local'):
        super().__init__('ap2', ledger, directory_label)


def _request_hash(request):
    public = {key: value for key, value in request.items() if key not in _SECRET_REQUEST_FIELDS}
    return digest('COVENANT-RAIL-REQUEST-0.1', public)


def _payment(terms):
    return {'currency': terms['unit'], 'amount': terms['quantity'], 'rail': 'stablecoin'}


def link_ap2(envelope, *, signer, cart_id=None):
    """Put the covenant id in AP2 intent and cart mandates, and map them to GIVE and BIND.

    The mapping is a view. It does not submit a transaction, open a mandate wallet,
    or quote a fee. ``economics.py`` remains the only chain fee accountant.
    """
    from .codec import public_key, sign
    from .envelope import PROFILE, content_id
    need(type(envelope) is dict and envelope.get('profile') == PROFILE, 'PROFILE')
    terms, parties = envelope['terms'], envelope['parties']
    need(terms.get('rail') == 'ap2', 'RAIL')
    need(public_key(signer) == parties['principal'], 'SIGNER_ROLE')
    if cart_id is None:
        cart_id = terms['task_hash']
    need(type(cart_id) is str and 1 <= len(cart_id) <= 128 and all(32 <= ord(c) <= 126 for c in cart_id), 'FIELDS')
    covenant_id = content_id(envelope)
    payment = _payment(terms)
    intent = {
        'profile': LINK_PROFILE,
        'mandate_type': 'IntentMandate',
        'covenant_id': covenant_id,
        'payer': parties['principal'],
        'payee': parties['counterparty'],
        'payment': payment,
        'terms_hash': terms['task_hash'],
        'network': terms['network'],
    }
    cart = {
        'profile': LINK_PROFILE,
        'mandate_type': 'CartMandate',
        'covenant_id': covenant_id,
        'cart_id': cart_id,
        'items': [{'id': terms['task_hash'], 'quantity': 1, 'amount': terms['quantity'], 'currency': terms['unit']}],
        'payer': parties['principal'],
        'payee': parties['counterparty'],
        'payment': payment,
        'terms_hash': terms['task_hash'],
        'network': terms['network'],
    }
    give = {
        'parent': None,
        'holder': parties['agent'],
        'resource': terms['unit'],
        'limit': terms['quantity'],
        'expiry': terms['deadline'],
        'effects': sorted({terms['effect']}),
        'profiles': ['covenant-work-order/0.1'],
        'delegate': False,
    }
    bind = {
        'chain': 'NOT_SUBMITTED',
        'principal': parties['principal'],
        'agent': parties['agent'],
        'counterparty': parties['counterparty'],
        'mandate': None,
        'profile': 'covenant-work-order/0.1',
        'resource': terms['unit'],
        'quantity': terms['quantity'],
        'effect': terms['effect'],
        'destination': terms['pay_to'],
        'executor': parties['executor'],
        'resolver': parties['resolver'],
        'appeal_resolver': parties['appeal_resolver'],
        'deadline': terms['deadline'],
        'challenge_blocks': terms['challenge_window'],
        'timeout': terms['timeout'],
        'terms_hash': terms['task_hash'],
    }
    need(tuple(give) == GIVE_FIELDS, 'FIELDS')
    need(tuple(bind) == BIND_TERM_FIELDS, 'FIELDS')
    reliance = _reliance_draft(parties, terms, covenant_id)
    return {
        'profile': LINK_PROFILE,
        'action': 'LINK',
        'covenant_id': covenant_id,
        'intent': {'body': intent, 'signature': sign(signer, AP2_LINK_LABEL, intent)},
        'cart': {'body': cart, 'signature': sign(signer, AP2_LINK_LABEL, cart)},
        'give': {'op': 'GIVE', 'fields': give, 'submitted': False, 'native_op_added': False,
                 'resource_note': 'STABLECOIN_CODE_NOT_A_NATIVE_RESOURCE'},
        'bind': {'op': 'BIND', 'terms': bind, 'assents': None, 'submitted': False, 'native_op_added': False,
                 'challenge_blocks_source': 'WORK_ORDER_CHALLENGE_WINDOW_SECONDS_NOT_CHAIN_HEIGHT'},
        'reliance': reliance,
        'refund_verb': None,
        'fee_accountant': 'covenant_chain.economics',
        'protocol_fee': 0,
        'fee_schedule': 'DEFERRED_TO_ECONOMICS_MODULE',
        'submitted': False,
        'chain_ledger_touched': False,
        'execution_authorized': False,
        'survival_improves': 'AGENT_PAYMENT_REACH',
        'survival_dependency': 'OWNER_INSTALLED_RAIL_AND_RELIANCE_DRAFT',
        'survival_retire': 'DROP_THE_ADAPTER_RECEIPTS_REMAIN_LOCAL',
    }


def _reliance_draft(parties, terms, covenant_id):
    """Draft a reliance intent. Does not open a mandate wallet or reserve funds."""
    from covenant_chain.reliance import INTENT, draft_intent
    adapter = digest('COVENANT-AP2-ADAPTER-0.1', {'rail': 'ap2'})
    effect = digest('COVENANT-AP2-EFFECT-0.1', {'covenant_id': covenant_id})
    request_hash = digest('COVENANT-AP2-LINK-REQUEST-0.1', {
        'covenant_id': covenant_id, 'terms_hash': terms['task_hash']})
    policy = {
        'version': 'covenant-mandate-wallet/0.1',
        'domain': digest('COVENANT-AP2-DOMAIN-0.1', {'profile': LINK_PROFILE}),
        'principal': parties['principal'],
        'not_before': 0,
        'expires': terms['deadline'],
        'limits': {terms['unit']: terms['quantity']},
        'per_action': {terms['unit']: terms['quantity']},
        'adapters': [adapter],
        'nonce': digest('COVENANT-AP2-NONCE-0.1', {'covenant_id': covenant_id}),
    }
    draft = draft_intent(
        policy, parties['agent'], adapter, effect, request_hash,
        {terms['unit']: terms['quantity']}, 0, terms['deadline'], policy['nonce'])
    return {
        'interface': 'covenant_chain.reliance.draft_intent',
        'intent_version': INTENT,
        'wallet_installed': False,
        'submitted': False,
        'policy': policy,
        'adapter': adapter,
        'effect': effect,
        'request_hash': request_hash,
        'draft': draft,
        'grant_target': draft['grant_target'],
        'grant_operation': draft['grant_operation'],
    }


def register_on(registry, adapter):
    """Register with covenant_chain.payment_rails.RailRegistry without editing it."""
    return registry.register(adapter)


class AgreedLinkAdapter:
    """The rail the parties already agreed to use.

    It is registered beside that rail. It does not keep a second ledger:
    execute and observe forward one call to the agreed target.
    """

    def __init__(self, registry, target):
        need(type(target) is str and len(target) == 64, 'RAIL')
        self.registry = registry
        self.target = target
        self.manifest = {
            'version': RAIL_VERSION,
            'rail': 'agreed-link',
            'target': target,
            'unit_kind': 'AGREED_RAIL',
            'native_token': False,
            'external_broadcast': False,
            'fee_schedule': 'THE_TARGET_RAIL',
        }
        canonical(self.manifest)

    def execute(self, effect_id, request):
        return self.registry.get(self.target).execute(effect_id, request)

    def observe(self, effect_id):
        return self.registry.get(self.target).observe(effect_id)
