"""Resolve a covenant by content id and verify it offline.

Local bytes are the default. IPFS, torrent and HTTP are named so an agent can
see them, and they stay unconfigured until the owner installs a fetcher.
A fetcher that returns different bytes is a hard failure, not a fallback.
"""
from .cid import cid_matches, describe_cid
from .codec import canonical, loads
from .envelope import PROFILE, VERSION, verify
from .errors import NativeError, REMEDIATION, need

LIGHT_PACKET = 'covenant-light-packet/0.1'
STUBBED = ('ipfs', 'torrent', 'http')
BILATERAL_PROFILES = (PROFILE, 'covenant-bilateral/0.2')


def source(name, fetch):
    """Wrap an owner-installed fetcher. fetch(cid) returns bytes or None."""
    def run(cid):
        blob = fetch(cid)
        if blob is None:
            return None
        if not cid_matches(cid, blob):
            raise NativeError('CID_MISMATCH')
        return bytes(blob)
    run.name = name
    run.configured = True
    return run


def light_verify(cid, *, store=None, genesis=None, sources=(), courier_chain=None, minimum_height=1,
                 ledger=None, as_of=None):
    tried = {}
    blob = None
    if store is not None:
        tried['local'] = 'TRIED'
        blob = store.get(cid)
    else:
        tried['local'] = 'SKIPPED'
    for item in sources:
        name = getattr(item, 'name', 'source')
        tried[name] = 'TRIED'
        if blob is None:
            found = item(cid)
            if found is not None:
                if not cid_matches(cid, found):
                    raise NativeError('CID_MISMATCH')
                blob = found
    for name in STUBBED:
        tried.setdefault(name, 'NOT_CONFIGURED')
    if blob is None:
        raise NativeError('CONTENT_NOT_FOUND')
    need(cid_matches(cid, blob), 'CID_MISMATCH')
    try:
        obj = loads(blob)
    except NativeError:
        obj = _courier_item(blob, courier_chain)
        if obj is None:
            raise
        carrier = 'courier'
    else:
        carrier = 'content'
        if type(obj) is dict and obj.get('profile') not in (*BILATERAL_PROFILES, LIGHT_PACKET):
            couriered = _courier_item(blob, courier_chain)
            if couriered is not None:
                obj = couriered
                carrier = 'courier'
    if type(obj) is not dict:
        raise NativeError('CONTENT_KIND')
    if obj.get('profile') == LIGHT_PACKET:
        report = _packet(obj, genesis, minimum_height)
    elif obj.get('profile') in BILATERAL_PROFILES:
        context = {'as_of': as_of} if obj['profile'] == 'covenant-bilateral/0.2' else {}
        report = verify(obj, genesis=genesis, minimum_height=minimum_height, ledger=ledger, **context)
    else:
        raise NativeError('CONTENT_KIND')
    canonical_bytes = canonical(obj)
    report = dict(report)
    report['addressed_cid'] = cid
    scheme = describe_cid(cid)
    report['addressed_hash_scheme'] = {name: scheme[name] for name in ('form', 'scheme', 'hash', 'codec', 'multibase')}
    report['carrier'] = carrier
    report['sources'] = tried
    report['offline'] = all(name not in tried or tried[name] != 'TRIED' or name == 'local' for name in tried)
    report['chain_ledger_touched'] = False
    report['ledger_touched'] = False
    report['execution_authorized'] = False
    if canonical_bytes != bytes(blob) and carrier == 'content':
        report['notes'] = list(report.get('notes') or []) + [
            'Stored bytes were not canonical. Signatures were checked on the parsed object.']
    report['version'] = VERSION
    return report


def _refused(code):
    hint = REMEDIATION.get(code, REMEDIATION['LIGHT_PROOF'])
    return {
        'version': VERSION, 'verdict': 'INVALID', 'ok': False, 'complete': False, 'code': code,
        'checks': [], 'failures': [{'code': code, 'passed': False, 'remediation': hint}],
        'remediation': [hint], 'next_action': hint, 'assurance': 'SIGNATURES_ONLY',
        'funds_observed': False, 'expiry_checked': False, 'notes': [], 'terms_hash': None, 'cid': None,
    }


def _packet(obj, genesis, minimum_height):
    need(type(obj.get('bundle')) is dict and type(obj.get('table')) is str and type(obj.get('key')) is str, 'LIGHT_PROOF')
    if genesis is None:
        return _refused('GENESIS_NOT_PINNED')
    try:
        from covenant_chain.crypto import genesis_id as chain_digest
        from covenant_chain.light import verify_light_bundle
    except ImportError:
        return _refused('LIGHT_VERIFIER_NOT_INSTALLED')
    try:
        chain = chain_digest(genesis)
        report = verify_light_bundle(genesis, obj['bundle'], chain, minimum_height, obj['table'], obj['key'])
    except (ValueError, TypeError, KeyError) as exc:
        code = str(exc)
        if not code.isascii() or not code.replace('_', 'A').isalpha() or not code.isupper():
            code = 'LIGHT_PROOF'
        return _refused(code if code in REMEDIATION or code.isupper() else 'LIGHT_PROOF')
    value = report.get('value')
    terms_hash = value.get('terms', {}).get('terms_hash') if type(value) is dict else None
    return {
        'version': VERSION, 'verdict': 'LIGHT_PACKET', 'ok': True, 'complete': False, 'code': 'OK',
        'checks': [], 'failures': [], 'remediation': [],
        'next_action': 'The light packet is committee-certified for the pinned genesis. History was not replayed.',
        'assurance': 'COMMITTEE_CERTIFIED', 'funds_observed': False, 'expiry_checked': False,
        'notes': ['Committee light proof matched the pinned genesis.'],
        'terms_hash': terms_hash, 'cid': None, 'table': obj['table'], 'key': obj['key'],
        'height': report.get('height'), 'chain': report.get('chain'),
    }


def _courier_item(blob, chain):
    if chain is None:
        return None
    try:
        from covenant_chain.courier import unpack
    except ImportError:
        return None
    try:
        text = blob.decode('utf-8') if isinstance(blob, (bytes, bytearray)) else blob
        items = unpack(text, chain)
    except (ValueError, TypeError, UnicodeError, KeyError):
        return None
    if len(items) == 1 and type(items[0]) is dict and items[0].get('profile') in (*BILATERAL_PROFILES, LIGHT_PACKET):
        return items[0]
    return None
