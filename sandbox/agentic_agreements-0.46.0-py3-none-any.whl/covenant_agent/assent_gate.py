"""Owner-threshold human approval before the agent key assents.

An owner adopts an approval policy by signing it with a key the agent host never
holds. The policy names the agent signer it constrains, typed MONEY thresholds,
the assent roles it covers and one approval method: a WebAuthn passkey the owner
registered (W3C WebAuthn Level 3 assertion, ES256) or a separate Ed25519 owner
key. Above a threshold the host's signer itself refuses to produce an assent
signature unless a fresh approval, issued by this host for one occurrence and
signed by the adopted method, binds the exact agreement bytes, the exact
rendering bytes the owner was shown, the amount, the payee and the role.

The owner-private journal (SQLite, WAL, synchronous FULL) records every issued
request and consumes each approval at most once. A request without an approval
leaves the agreement unsigned and retryable. Agreement text, tool arguments and
counterparty data are data here: they never install a policy, a method or a key.
Approvals bind terms; they are not payments and do not establish delivery.

Policy covenant-assent-policy/0.2 adds a covenant-risk-score/0.1 trigger: an
assent whose deterministic risk score (amount, irreversibility, counterparty
history from verified receipts, scope breadth, novelty) is above the owner's
threshold also needs approval. The trigger only adds approvals; it never waives
one the money threshold requires, and an unknown input scores highest. Policy
0.1 keeps its exact meaning. An owner watchdog, when installed, is asked to
admit each assent before signing, and refuses every assent while the agent's
authority is suspended.
"""
import argparse
import base64
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import sys
import threading
from urllib.parse import urlsplit

from covenant_chain import risk_score, verb_scopes

from . import assent_view
from .codec import canonical, digest, key_from_seed, loads, public_key, sign, valid_ed25519_key, verify
from .errors import NativeError, REMEDIATION, need

POLICY_VERSION = 'covenant-assent-policy/0.1'
RISK_POLICY_VERSION = 'covenant-assent-policy/0.2'
REQUEST_VERSION = 'covenant-assent-approval-request/0.1'
APPROVAL_VERSION = 'covenant-assent-approval/0.1'
JOURNAL_VERSION = 'covenant-assent-journal/0.1'
POLICY_LABEL = 'COVENANT-ASSENT-POLICY-0.1'
APPROVAL_LABEL = 'COVENANT-ASSENT-APPROVAL-0.1'
ROLES = ('agent', 'counterparty')
DECISIONS = ('APPROVE', 'REFUSE')
METHODS = ('OWNER_KEY', 'PASSKEY')
STATUSES = ('PENDING', 'APPROVED', 'REFUSED', 'CONSUMING', 'CONSUMED', 'FAILED')
MAX_PENDING = 64
MAX_ROWS = 2048
MAX_ROW_BYTES = 131072
MAX_FILE_BYTES = 262144
MAX_INTEGER = 2**53 - 1
HEX = re.compile(r'[0-9a-f]{64}\Z')
B64URL = re.compile(r'[A-Za-z0-9_-]{1,256}\Z')
UNIT = re.compile(r'[\x21-\x7e]{1,80}\Z')
RP_ID = re.compile(r'[a-z0-9.-]{1,253}\Z')
REQUEST_FIELDS = 'version policy signer role profile agreement rendering amount payee occurrence issued_at expires_at'
POLICY_FIELDS = {POLICY_VERSION: 'version owner signer roles thresholds method max_age not_before expires nonce',
                 RISK_POLICY_VERSION: 'version owner signer roles thresholds method max_age not_before expires nonce risk'}
WATCH_LABEL = 'COVENANT-ASSENT-WATCH-0.1'
LABELS = {
    'covenant-bilateral/0.1': ('COVENANT-WORK-ORDER-ASSENT-0.1', None),
    'covenant-bilateral/0.2': ('COVENANT-BILATERAL-0.2', 'ASSENT'),
}
FLAGS = {'execution_authorized': False, 'payment_rail_touched': False}


class ApprovalRequired(NativeError):
    """Nothing was signed. ``details`` names the exact pending request and how an owner answers it."""

    def __init__(self, details):
        super().__init__('ASSENT_APPROVAL_REQUIRED')
        self.details = details


def _int(value, code, minimum=0, maximum=MAX_INTEGER):
    need(type(value) is int and minimum <= value <= maximum, code)
    return value


def _key(value, code):
    need(type(value) is str and bool(HEX.fullmatch(value)) and valid_ed25519_key(value), code)
    return value


def _fields(value, names, code):
    need(type(value) is dict and set(value) == set(names.split()), code)


def _money(value, code):
    _fields(value, 'kind amount unit', code)
    need(value['kind'] == 'MONEY' and type(value['unit']) is str and bool(UNIT.fullmatch(value['unit'])), code)
    _int(value['amount'], code)
    return value


def _origin(value, rp_id):
    need(type(value) is str and 0 < len(value) <= 256 and value.isascii() and value.isprintable(), 'ASSENT_POLICY_FIELDS')
    parts = urlsplit(value)
    need(parts.scheme in ('https', 'http') and parts.hostname and not parts.username and not parts.password
         and parts.path == '' and not parts.query and not parts.fragment, 'ASSENT_POLICY_FIELDS')
    host = parts.hostname
    if parts.scheme == 'http':
        need(host in ('localhost', '127.0.0.1') or host.endswith('.localhost'), 'ASSENT_POLICY_FIELDS')
    # WebAuthn: the RP ID is the origin's host or a registrable suffix of it.
    need(host == rp_id or host.endswith('.' + rp_id), 'ASSENT_POLICY_FIELDS')


def separate_approver(approver, acting):
    """The self-approval rule, one place for this gate and covenant_agent.hire sessions.

    An approval a policy requires counts only when a key the acting agent does
    not hold signs it: the owner's or principal's own approval key. ``acting``
    is every key the acting agent, or the host it runs in, can sign with.
    """
    _key(approver, 'ASSENT_POLICY_FIELDS')
    need(approver not in acting, 'ASSENT_POLICY_SELF_APPROVAL')
    return approver


def _method(value, signer):
    need(type(value) is dict and value.get('kind') in METHODS, 'ASSENT_POLICY_FIELDS')
    if value['kind'] == 'OWNER_KEY':
        _fields(value, 'kind key', 'ASSENT_POLICY_FIELDS')
        separate_approver(value['key'], (signer,))
        return value
    _fields(value, 'kind credential_id public_key rp_id origin user_verification', 'ASSENT_POLICY_FIELDS')
    need(type(value['credential_id']) is str and bool(B64URL.fullmatch(value['credential_id'])), 'ASSENT_POLICY_FIELDS')
    need(type(value['rp_id']) is str and bool(RP_ID.fullmatch(value['rp_id'])), 'ASSENT_POLICY_FIELDS')
    need(type(value['user_verification']) is bool, 'ASSENT_POLICY_FIELDS')
    point = value['public_key']
    need(type(point) is str and len(point) == 130 and point.startswith('04') and
         all(c in '0123456789abcdef' for c in point), 'ASSENT_POLICY_FIELDS')
    from cryptography.hazmat.primitives.asymmetric import ec
    try:
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), bytes.fromhex(point))
    except ValueError:
        raise NativeError('ASSENT_POLICY_FIELDS') from None
    _origin(value['origin'], value['rp_id'])
    return value


def validate_policy(body):
    """An exact policy body; it carries no authority until its owner signature verifies."""
    need(type(body) is dict and body.get('version') in POLICY_FIELDS, 'ASSENT_POLICY_FIELDS')
    _fields(body, POLICY_FIELDS[body['version']], 'ASSENT_POLICY_FIELDS')
    _key(body['owner'], 'ASSENT_POLICY_FIELDS')
    _key(body['signer'], 'ASSENT_POLICY_FIELDS')
    separate_approver(body['owner'], (body['signer'],))
    roles = body['roles']
    need(type(roles) is list and roles and roles == sorted(set(roles)) and set(roles) <= set(ROLES), 'ASSENT_POLICY_FIELDS')
    thresholds = body['thresholds']
    need(type(thresholds) is list and len(thresholds) <= 16, 'ASSENT_POLICY_FIELDS')
    for item in thresholds:
        _money(item, 'ASSENT_POLICY_FIELDS')
    units = [item['unit'] for item in thresholds]
    need(units == sorted(set(units)), 'ASSENT_POLICY_FIELDS')
    _method(body['method'], body['signer'])
    _int(body['max_age'], 'ASSENT_POLICY_FIELDS', 30, 86400)
    _int(body['not_before'], 'ASSENT_POLICY_FIELDS')
    _int(body['expires'], 'ASSENT_POLICY_FIELDS')
    need(body['not_before'] <= body['expires'], 'ASSENT_POLICY_FIELDS')
    need(type(body['nonce']) is str and bool(HEX.fullmatch(body['nonce'])), 'ASSENT_POLICY_FIELDS')
    if body['version'] == RISK_POLICY_VERSION:
        try:
            risk_score.validate_policy(body['risk'])
        except ValueError:
            raise NativeError('ASSENT_POLICY_RISK') from None
    canonical(body)
    return True


def policy_body(owner, signer, *, method, thresholds=(), roles=('agent',), max_age=600, not_before=0,
                expires=MAX_INTEGER, nonce=None):
    """Build an exact policy body for an owner to sign. ``thresholds`` maps unit to the largest unapproved amount."""
    if type(thresholds) is dict:
        thresholds = [{'kind': 'MONEY', 'amount': amount, 'unit': unit} for unit, amount in sorted(thresholds.items())]
    body = {'version': POLICY_VERSION, 'owner': owner, 'signer': signer, 'roles': sorted(set(roles)),
            'thresholds': deepcopy(list(thresholds)), 'method': deepcopy(method), 'max_age': max_age,
            'not_before': not_before, 'expires': expires, 'nonce': secrets.token_hex(32) if nonce is None else nonce}
    validate_policy(body)
    return body


def risk_policy_body(owner, signer, *, method, risk, thresholds=(), roles=('agent',), max_age=600, not_before=0,
                     expires=MAX_INTEGER, nonce=None):
    """A covenant-assent-policy/0.2 body: the 0.1 fields plus a covenant-risk-score/0.1 trigger."""
    body = policy_body(owner, signer, method=method, thresholds=thresholds, roles=roles, max_age=max_age,
                       not_before=not_before, expires=expires, nonce=nonce)
    body.update(version=RISK_POLICY_VERSION, risk=deepcopy(risk))
    validate_policy(body)
    return body


def sign_policy(owner_private, body):
    validate_policy(body)
    need(public_key(owner_private) == body['owner'], 'ASSENT_POLICY_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(owner_private, POLICY_LABEL, body)}


def policy_id(body):
    validate_policy(body)
    return digest(POLICY_LABEL, body)


def verify_policy(record):
    """The adopted policy body, only when its owner signature verifies."""
    _fields(record, 'body signature', 'ASSENT_POLICY_FIELDS')
    validate_policy(record['body'])
    try:
        verify(record['body']['owner'], POLICY_LABEL, record['body'], record['signature'])
    except NativeError:
        raise NativeError('ASSENT_POLICY_SIGNATURE') from None
    return deepcopy(record['body'])


def approval_object(decision, request):
    need(decision in DECISIONS, 'ASSENT_APPROVAL_FIELDS')
    validate_request(request)
    return {'decision': decision, 'request': deepcopy(request)}


def passkey_challenge(request, decision='APPROVE'):
    """WebAuthn challenge: base64url SHA-256 of the labelled canonical decision and request."""
    from covenant_chain.signin import passkey_challenge as challenge
    return challenge({'label': APPROVAL_LABEL, **approval_object(decision, request)})


def sign_approval(private, request, decision='APPROVE'):
    """An OWNER_KEY approval record. Run by the owner's own tool; the key never reaches the agent host."""
    body = approval_object(decision, request)
    return {'version': APPROVAL_VERSION, 'decision': decision, 'request': deepcopy(request), 'method': 'OWNER_KEY',
            'proof': {'key': public_key(private), 'signature': sign(private, APPROVAL_LABEL, body)}}


def passkey_approval(request, assertion, decision='APPROVE'):
    """A PASSKEY approval record from a WebAuthn get() assertion over ``passkey_challenge``."""
    approval_object(decision, request)
    need(type(assertion) is dict, 'ASSENT_APPROVAL_FIELDS')
    return {'version': APPROVAL_VERSION, 'decision': decision, 'request': deepcopy(request), 'method': 'PASSKEY',
            'proof': deepcopy(assertion)}


def validate_request(request):
    _fields(request, REQUEST_FIELDS, 'ASSENT_APPROVAL_FIELDS')
    need(request['version'] == REQUEST_VERSION and request['role'] in ROLES and
         request['profile'] in LABELS, 'ASSENT_APPROVAL_FIELDS')
    for name in ('policy', 'agreement', 'rendering', 'occurrence'):
        need(type(request[name]) is str and bool(HEX.fullmatch(request[name])), 'ASSENT_APPROVAL_FIELDS')
    _key(request['signer'], 'ASSENT_APPROVAL_FIELDS')
    _money(request['amount'], 'ASSENT_APPROVAL_FIELDS')
    _fields(request['payee'], 'key pay_to', 'ASSENT_APPROVAL_FIELDS')
    _key(request['payee']['key'], 'ASSENT_APPROVAL_FIELDS')
    need(type(request['payee']['pay_to']) is str and 0 < len(request['payee']['pay_to']) <= 256, 'ASSENT_APPROVAL_FIELDS')
    _int(request['issued_at'], 'ASSENT_APPROVAL_FIELDS')
    _int(request['expires_at'], 'ASSENT_APPROVAL_FIELDS')
    need(request['issued_at'] <= request['expires_at'], 'ASSENT_APPROVAL_FIELDS')
    canonical(request)
    return True


def assent_messages(subject):
    """The exact message bytes an assent to ``subject`` signs, for the profile's own label."""
    found = assent_view.agreement(subject)
    need(found['profile'] in LABELS, 'ASSENT_RENDER_PROFILE')
    label, action = LABELS[found['profile']]
    if action is None:
        body = found['body']
    else:
        body = {'action': action, 'agreement': found['agreement_id']}
    return [label.encode('ascii') + b'\0' + canonical(body)]


def gated(message):
    """True for every assent-shaped message: an ASSENT label, or a /0.2 body whose action is ASSENT."""
    label, separator, body = bytes(message).partition(b'\0')
    if not separator:
        return False
    if b'ASSENT' in label:
        return True
    if label == b'COVENANT-BILATERAL-0.2':
        try:
            value = json.loads(body.decode('ascii'))
        except (UnicodeError, ValueError, RecursionError):
            return True
        return type(value) is not dict or value.get('action') == 'ASSENT'
    return False


class AssentGuard:
    """The host's Ed25519 signer. It refuses every assent message not covered by an exact one-shot permit.

    Other signatures (delivery, dispute, release, evidence) pass unchanged. A
    permit names exact message bytes computed from an approved or below-threshold
    agreement; no code path that skips the gate can obtain an assent signature.
    """

    def __init__(self, private):
        need(not isinstance(private, AssentGuard), 'ASSENT_GUARD_NESTED')
        self._private = private
        self._local = threading.local()

    def public_key(self):
        return self._private.public_key()

    def sign(self, message):
        message = bytes(message)
        if gated(message):
            permits = getattr(self._local, 'permits', None)
            need(permits is not None and permits.get(message) is False, 'ASSENT_APPROVAL_REQUIRED')
            permits[message] = True
        return self._private.sign(message)

    @contextmanager
    def permit(self, messages):
        need(getattr(self._local, 'permits', None) is None, 'ASSENT_GUARD_NESTED')
        permits = {bytes(message): False for message in messages}
        self._local.permits = permits
        try:
            yield permits
        finally:
            self._local.permits = None


def _private_file(fd):
    info = os.fstat(fd)
    need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid()
         and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'ASSENT_JOURNAL_STORAGE')
    return info


class Journal:
    """Owner-private SQLite record of issued requests, decisions and single consumption."""

    def __init__(self, path):
        self.path = Path(path).expanduser().absolute()
        need(self.path.parent.is_dir() and not self.path.is_symlink(), 'ASSENT_JOURNAL_STORAGE')
        parent = os.stat(self.path.parent)
        need(parent.st_uid == os.getuid() and stat.S_IMODE(parent.st_mode) & 0o022 == 0, 'ASSENT_JOURNAL_STORAGE')
        try:
            try:
                fd = os.open(self.path, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            except FileExistsError:
                fd = os.open(self.path, os.O_RDONLY | os.O_NOFOLLOW)
        except OSError:
            raise NativeError('ASSENT_JOURNAL_STORAGE') from None
        try:
            _private_file(fd)
        finally:
            os.close(fd)
        with self._connect(write=True) as db:
            db.execute('CREATE TABLE IF NOT EXISTS meta (name TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT')
            row = db.execute("SELECT value FROM meta WHERE name='format'").fetchone()
            if row is None:
                db.execute("INSERT INTO meta(name, value) VALUES ('format', ?)", (JOURNAL_VERSION,))
            else:
                need(row[0] == JOURNAL_VERSION, 'ASSENT_JOURNAL_VERSION')
            db.execute('CREATE TABLE IF NOT EXISTS policies (id TEXT PRIMARY KEY, record TEXT NOT NULL) STRICT')
            db.execute('CREATE TABLE IF NOT EXISTS requests ('
                       'occurrence TEXT PRIMARY KEY, status TEXT NOT NULL, policy TEXT NOT NULL, signer TEXT NOT NULL, '
                       'role TEXT NOT NULL, tool TEXT NOT NULL, call TEXT NOT NULL, arguments TEXT NOT NULL, subject TEXT NOT NULL, '
                       'agreement TEXT NOT NULL, rendering TEXT NOT NULL, request TEXT NOT NULL, approval TEXT, '
                       'result TEXT, outcome TEXT, issued_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, '
                       'decided_at INTEGER, consumed_at INTEGER) STRICT')
            db.execute('CREATE INDEX IF NOT EXISTS requests_call ON requests(call, signer)')
            db.execute('CREATE INDEX IF NOT EXISTS requests_agreement ON requests(agreement, signer, role)')
            db.execute('CREATE TABLE IF NOT EXISTS counters (credential TEXT PRIMARY KEY, sign_count INTEGER NOT NULL) STRICT')

    @contextmanager
    def _connect(self, write=False):
        try:
            fd = os.open(self.path, os.O_RDONLY | os.O_NOFOLLOW)
        except OSError:
            raise NativeError('ASSENT_JOURNAL_STORAGE') from None
        try:
            _private_file(fd)
        finally:
            os.close(fd)
        try:
            db = sqlite3.connect(self.path.as_uri() + '?mode=rw', uri=True, timeout=15, isolation_level=None)
        except sqlite3.Error:
            raise NativeError('ASSENT_JOURNAL_STORAGE') from None
        try:
            try:
                db.execute('PRAGMA busy_timeout=15000')
                db.execute('PRAGMA journal_mode=WAL')
                db.execute('PRAGMA synchronous=FULL')
                db.execute('BEGIN IMMEDIATE' if write else 'BEGIN')
            except sqlite3.Error:
                raise NativeError('ASSENT_JOURNAL_STORAGE') from None
            try:
                yield db
            except BaseException as exc:
                try:
                    db.execute('ROLLBACK')
                except sqlite3.Error:
                    pass
                if isinstance(exc, sqlite3.Error):
                    raise NativeError('ASSENT_JOURNAL_STORAGE') from None
                raise
            try:
                db.execute('COMMIT')
            except sqlite3.Error:
                raise NativeError('ASSENT_JOURNAL_STORAGE') from None
        finally:
            db.close()

    @staticmethod
    def _row(values):
        if values is None:
            return None
        names = ('occurrence status policy signer role tool call arguments subject agreement rendering request approval '
                 'result outcome issued_at expires_at decided_at consumed_at').split()
        row = dict(zip(names, values))
        for name in ('arguments', 'subject', 'request', 'approval', 'result'):
            if row[name] is not None:
                row[name] = loads(row[name])
        need(row['status'] in STATUSES, 'ASSENT_JOURNAL_STORAGE')
        return row

    def remember_policy(self, record):
        body = verify_policy(record)
        with self._connect(write=True) as db:
            db.execute('INSERT OR IGNORE INTO policies(id, record) VALUES (?, ?)',
                       (policy_id(body), canonical(record).decode('ascii')))

    def policy(self, ident):
        with self._connect() as db:
            row = db.execute('SELECT record FROM policies WHERE id=?', (ident,)).fetchone()
        need(row is not None, 'ASSENT_POLICY_CHANGED')
        return loads(row[0])

    def get(self, occurrence):
        with self._connect() as db:
            return self._row(db.execute('SELECT * FROM requests WHERE occurrence=?', (occurrence,)).fetchone())

    def find(self, *, agreement, rendering, signer, role, now, policy):
        with self._connect() as db:
            return self._row(db.execute(
                "SELECT * FROM requests WHERE agreement=? AND rendering=? AND signer=? AND role=? AND policy=? "
                "AND (status NOT IN ('PENDING','APPROVED') OR expires_at>=?) "
                "ORDER BY (status='CONSUMED') DESC, issued_at DESC LIMIT 1",
                (agreement, rendering, signer, role, policy, now)).fetchone())

    def by_call(self, call, signer, now, policy):
        with self._connect() as db:
            return self._row(db.execute(
                "SELECT * FROM requests WHERE call=? AND signer=? AND policy=? "
                "AND (status NOT IN ('PENDING','APPROVED') OR expires_at>=?) ORDER BY (status='CONSUMED') DESC, issued_at DESC LIMIT 1",
                (call, signer, policy, now)).fetchone())

    def issue(self, row, now):
        values = dict(row)
        for name in ('arguments', 'subject', 'request'):
            values[name] = canonical(values[name]).decode('ascii')
        need(sum(len(str(value)) for value in values.values()) <= MAX_ROW_BYTES, 'ASSENT_JOURNAL_FULL')
        with self._connect(write=True) as db:
            open_count = db.execute("SELECT COUNT(*) FROM requests WHERE status='PENDING' AND expires_at>=?",
                                    (now,)).fetchone()[0]
            need(open_count < MAX_PENDING, 'ASSENT_APPROVAL_BACKLOG')
            if db.execute('SELECT COUNT(*) FROM requests').fetchone()[0] >= MAX_ROWS:
                # Expired, decided rows carry no usable approval: an unknown occurrence is refused.
                db.execute("DELETE FROM requests WHERE occurrence IN (SELECT occurrence FROM requests "
                           "WHERE expires_at<? AND status NOT IN ('CONSUMING') ORDER BY expires_at LIMIT 256)", (now,))
                need(db.execute('SELECT COUNT(*) FROM requests').fetchone()[0] < MAX_ROWS, 'ASSENT_JOURNAL_FULL')
            db.execute('INSERT INTO requests(occurrence, status, policy, signer, role, tool, call, arguments, subject, '
                       'agreement, rendering, request, issued_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                       (values['occurrence'], 'PENDING', values['policy'], values['signer'], values['role'],
                        values['tool'], values['call'], values['arguments'], values['subject'], values['agreement'],
                        values['rendering'], values['request'], values['issued_at'], values['expires_at']))

    def _counter(self, db, credential, count):
        if count is None:
            return
        row = db.execute('SELECT sign_count FROM counters WHERE credential=?', (credential,)).fetchone()
        # WebAuthn L3 7.2 step 22: a non-increasing nonzero counter may indicate a cloned authenticator.
        need(row is None or (count == 0 and row[0] == 0) or count > row[0], 'ASSENT_PASSKEY_COUNTER')
        db.execute('INSERT INTO counters(credential, sign_count) VALUES (?, ?) ON CONFLICT(credential) '
                   'DO UPDATE SET sign_count=excluded.sign_count', (credential, count))

    def decide(self, occurrence, status, approval, now, counter=None):
        """PENDING to APPROVED once; PENDING or APPROVED to REFUSED. A refusal only ever blocks."""
        need(status in ('APPROVED', 'REFUSED'), 'ASSENT_JOURNAL_STORAGE')
        with self._connect(write=True) as db:
            self._state(db, occurrence, ('PENDING',) if status == 'APPROVED' else ('PENDING', 'APPROVED'))
            if counter is not None:
                self._counter(db, *counter)
            db.execute('UPDATE requests SET status=?, approval=?, decided_at=? WHERE occurrence=?',
                       (status, None if approval is None else canonical(approval).decode('ascii'), now, occurrence))

    def _state(self, db, occurrence, allowed):
        row = db.execute('SELECT status FROM requests WHERE occurrence=?', (occurrence,)).fetchone()
        need(row is not None, 'ASSENT_APPROVAL_UNKNOWN')
        if row[0] not in allowed:
            raise NativeError({'REFUSED': 'ASSENT_APPROVAL_REFUSED', 'CONSUMING': 'ASSENT_APPROVAL_OUTCOME_UNKNOWN',
                               'APPROVED': 'ASSENT_APPROVAL_REUSED'}.get(row[0], 'ASSENT_APPROVAL_REUSED'))
        return row[0]

    def reserve(self, occurrence, approval, now, counter=None):
        """PENDING or APPROVED to CONSUMING; afterwards this approval cannot authorize another signature."""
        with self._connect(write=True) as db:
            previous = self._state(db, occurrence, ('PENDING', 'APPROVED'))
            if counter is not None and previous == 'PENDING':
                self._counter(db, *counter)
            db.execute('UPDATE requests SET status=?, approval=?, decided_at=COALESCE(decided_at, ?), consumed_at=? '
                       'WHERE occurrence=?', ('CONSUMING', canonical(approval).decode('ascii'), now, now, occurrence))
            return previous

    def release(self, occurrence, previous):
        """Undo a reservation whose run produced no assent signature."""
        with self._connect(write=True) as db:
            self._state(db, occurrence, ('CONSUMING',))
            db.execute('UPDATE requests SET status=?, consumed_at=NULL WHERE occurrence=?',
                       ('APPROVED', occurrence))

    def finish(self, occurrence, status, result, outcome):
        need(status in ('CONSUMED', 'FAILED'), 'ASSENT_JOURNAL_STORAGE')
        raw = None if result is None else canonical(result).decode('ascii')
        if raw is not None and len(raw) > MAX_ROW_BYTES:
            raw, outcome = None, 'RESULT_NOT_RETAINED_SIZE'
        with self._connect(write=True) as db:
            self._state(db, occurrence, ('CONSUMING',))
            db.execute('UPDATE requests SET status=?, result=?, outcome=? WHERE occurrence=?',
                       (status, raw, outcome, occurrence))

    def payee_assents(self, payee):
        """How many assents this journal records as signed for a payee key, under any policy."""
        found = 0
        with self._connect() as db:
            for (raw,) in db.execute("SELECT request FROM requests WHERE status='CONSUMED'"):
                found += loads(raw)['payee']['key'] == payee
        return found

    def status(self, now):
        with self._connect() as db:
            counts = {name: 0 for name in STATUSES}
            for name, count in db.execute('SELECT status, COUNT(*) FROM requests GROUP BY status'):
                counts[name] = count
            expired = db.execute("SELECT COUNT(*) FROM requests WHERE status IN ('PENDING','APPROVED') AND expires_at<?",
                                 (now,)).fetchone()[0]
            pending = [self._row(row) for row in db.execute(
                "SELECT * FROM requests WHERE status IN ('PENDING','APPROVED') AND expires_at>=? "
                "ORDER BY issued_at LIMIT 64", (now,))]
        return {'format': JOURNAL_VERSION, 'counts': counts, 'expired_open': expired,
                'open': [{'occurrence': row['occurrence'], 'status': row['status'], 'request': row['request']}
                         for row in pending]}

    def backup(self, destination):
        """Online SQLite backup into a new owner-private file; never overwrites."""
        target = Path(destination).expanduser().absolute()
        need(target.parent.is_dir() and not os.path.lexists(target), 'ASSENT_JOURNAL_STORAGE')
        fd = os.open(target, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        os.close(fd)
        source = sqlite3.connect(self.path.as_uri() + '?mode=ro', uri=True, timeout=15)
        copy = sqlite3.connect(str(target))
        try:
            source.backup(copy)
        finally:
            copy.close()
            source.close()
        return str(target)


def prometheus(status):
    lines = ['# HELP covenant_assent_requests Owner approval requests in the assent journal by status.',
             '# TYPE covenant_assent_requests gauge']
    for name in STATUSES:
        lines.append('covenant_assent_requests{status="%s"} %d' % (name, status['counts'].get(name, 0)))
    lines += ['# HELP covenant_assent_expired_open Pending or approved requests past their expiry.',
              '# TYPE covenant_assent_expired_open gauge', 'covenant_assent_expired_open %d' % status['expired_open']]
    return '\n'.join(lines) + '\n'


def _passkey_counter(proof):
    try:
        raw = base64.urlsafe_b64decode(proof['authenticator_data'] + '=' * (-len(proof['authenticator_data']) % 4))
    except (ValueError, TypeError, KeyError):
        return None
    return int.from_bytes(raw[33:37], 'big') if len(raw) >= 37 else None


class AssentGate:
    """Owner-installed enforcement for one agent signer. Tool input cannot install or change it."""

    def __init__(self, policy_record, journal_path, *, clock, entropy=None, observer=None):
        self.policy = verify_policy(policy_record)
        self.record = deepcopy(policy_record)
        self.policy_hash = policy_id(self.policy)
        need(callable(clock) and (entropy is None or callable(entropy)) and (observer is None or callable(observer)),
             'ASSENT_POLICY_FIELDS')
        self.clock, self.observer = clock, observer
        self.entropy = entropy or (lambda: secrets.token_hex(32))
        self.journal = Journal(journal_path)
        self.journal.remember_policy(policy_record)
        self._risk_history = self._risk_scopes = self.watchdog = None

    def adopt_risk_sources(self, *, history=None, scopes=None):
        """Owner-installed risk inputs: history(payee) returns receipt counts or None; scopes the agent's grants."""
        need(history is None or callable(history), 'ASSENT_RISK_SOURCE')
        if scopes is not None:
            try:
                verb_scopes.scopes(scopes)
            except ValueError:
                raise NativeError('ASSENT_RISK_SOURCE') from None
        self._risk_history, self._risk_scopes = history, deepcopy(scopes)
        return {'history_installed': history is not None, 'scopes': deepcopy(scopes), **FLAGS}

    def install_watchdog(self, watchdog):
        """The owner's watchdog admits each assent before signing; a suspended agent signs nothing new."""
        need(callable(getattr(watchdog, 'admit', None)), 'ASSENT_WATCHDOG')
        self.watchdog = watchdog
        return {'watchdog_installed': True, **FLAGS}

    def now(self):
        value = self.clock()
        need(type(value) in (int, float) and 0 <= value <= MAX_INTEGER, 'CLOCK')
        return int(value)

    def _emit(self, kind, **fields):
        if self.observer is not None:
            self.observer(kind, fields)

    def describe(self):
        method = self.policy['method']
        public_method = {'kind': method['kind']}
        if method['kind'] == 'PASSKEY':
            public_method.update(rp_id=method['rp_id'], origin=method['origin'],
                                 user_verification=method['user_verification'])
        else:
            public_method['key'] = method['key']
        risk = None
        if self.policy['version'] == RISK_POLICY_VERSION:
            risk = {**deepcopy(self.policy['risk']), 'rule': 'ALSO_REQUIRED_ABOVE_RISK; NEVER_WAIVES_THE_MONEY_THRESHOLD',
                    'history_installed': self._risk_history is not None, 'scopes_installed': self._risk_scopes is not None}
        return {'policy': self.policy_hash, 'version': self.policy['version'], 'owner': self.policy['owner'],
                'signer': self.policy['signer'], 'roles': list(self.policy['roles']),
                'thresholds': deepcopy(self.policy['thresholds']), 'method': public_method,
                'max_age': self.policy['max_age'],
                'active': self.policy['not_before'] <= self.now() <= self.policy['expires'],
                'unlisted_unit': 'APPROVAL_REQUIRED_FOR_ANY_AMOUNT', 'risk': risk,
                'watchdog_installed': self.watchdog is not None, **FLAGS}

    def threshold(self, amount):
        for item in self.policy['thresholds']:
            if item['unit'] == amount['unit']:
                return item['amount']
        return None

    def required(self, role, amount):
        """Approval is required above the typed threshold; a unit the policy does not list always needs one."""
        if role not in self.policy['roles']:
            return False
        limit = self.threshold(amount)
        return limit is None or amount['amount'] > limit

    def assess(self, subject, role):
        need(role in ROLES, 'ASSENT_APPROVAL_ROLE')
        rendered = assent_view.render(subject)
        now = self.now()
        need(self.policy['not_before'] <= now <= self.policy['expires'], 'ASSENT_POLICY_INACTIVE')
        amount = rendered['summary']['amount']
        required, risk = self.required(role, amount), None
        if self.policy['version'] == RISK_POLICY_VERSION:
            risk = self._risk(rendered)
            # The risk trigger only adds approvals: it never removes one the money threshold requires.
            required = required or (role in self.policy['roles'] and risk['above'])
        return {'rendered': rendered, 'role': role, 'required': required, 'threshold': self.threshold(amount),
                'risk': risk, 'messages': assent_messages(subject), 'now': now}

    def _risk(self, rendered):
        summary = rendered['summary']
        payee = summary['payee']['key']
        history = None if self._risk_history is None else self._risk_history(payee)
        try:
            history = risk_score.history(history)
        except ValueError:
            raise NativeError('ASSENT_RISK_SOURCE') from None
        known = self.journal.payee_assents(payee) > 0 or (history is not None and sum(history.values()) > 0)
        # Gated work orders name a resolver and an appeal path: compensable, not reversible.
        irreversibility = 'COMPENSABLE' if rendered['profile'] in LABELS else 'IRREVERSIBLE'
        return risk_score.score(self.policy['risk'], amount=summary['amount'], irreversibility=irreversibility,
                                history_counts=history, scopes=self._risk_scopes, novel=not known)

    def _watch(self, assessment):
        if self.watchdog is None:
            return
        rendered = assessment['rendered']
        summary = rendered['summary']
        request = digest(WATCH_LABEL, {'agreement': rendered['agreement_sha256'],
                                       'rendering': rendered['rendering_sha256'], 'role': assessment['role']})
        self.watchdog.admit(self.policy['signer'], kind='ASSENT', scope='agreement:' + rendered['profile'] + ':ASSENT',
                            request=request, destination=summary['payee']['key'],
                            usage={summary['amount']['unit']: summary['amount']['amount']})

    def view(self, assessment):
        view = assent_view.public(assessment['rendered'])
        view.update(role=assessment['role'], approval_required=assessment['required'],
                    threshold=assessment['threshold'], policy=self.policy_hash)
        if assessment.get('risk') is not None:
            view['risk'] = deepcopy(assessment['risk'])
        return view

    def _request_for(self, assessment, *, tool, call, arguments, subject):
        rendered, now = assessment['rendered'], assessment['now']
        row = self.journal.find(agreement=rendered['agreement_sha256'], rendering=rendered['rendering_sha256'],
                                signer=self.policy['signer'], role=assessment['role'], now=now, policy=self.policy_hash)
        if row is not None:
            return row
        occurrence = self.entropy()
        need(type(occurrence) is str and bool(HEX.fullmatch(occurrence)), 'ASSENT_APPROVAL_FIELDS')
        request = {'version': REQUEST_VERSION, 'policy': self.policy_hash, 'signer': self.policy['signer'],
                   'role': assessment['role'], 'profile': rendered['profile'],
                   'agreement': rendered['agreement_sha256'], 'rendering': rendered['rendering_sha256'],
                   'amount': deepcopy(rendered['summary']['amount']),
                   'payee': deepcopy(rendered['summary']['payee']), 'occurrence': occurrence,
                   'issued_at': now, 'expires_at': now + self.policy['max_age']}
        validate_request(request)
        row = {'occurrence': occurrence, 'policy': self.policy_hash, 'signer': self.policy['signer'],
               'role': assessment['role'], 'tool': tool, 'call': call, 'arguments': arguments, 'subject': subject,
               'agreement': rendered['agreement_sha256'], 'rendering': rendered['rendering_sha256'],
               'request': request, 'issued_at': now, 'expires_at': request['expires_at']}
        self.journal.issue(row, now)
        self._emit('APPROVAL_REQUESTED', agreement=rendered['agreement_sha256'],
                   rendering=rendered['rendering_sha256'], occurrence=occurrence, role=assessment['role'],
                   profile=rendered['profile'], expires_at=request['expires_at'])
        return self.journal.get(occurrence)

    def pending_details(self, assessment, row, tool):
        method = self.policy['method']
        request = row['request']
        details = {'occurrence': request['occurrence'], 'request': deepcopy(request), 'assent': self.view(assessment),
                   'arguments': deepcopy(row['arguments']), 'tool': tool, 'status': row['status'],
                   'method': method['kind'], 'expires_at': request['expires_at'],
                   'journal': str(self.journal.path), 'signature_created': False, **FLAGS}
        if method['kind'] == 'PASSKEY':
            details['approval_url'] = method['origin'] + '/assent/approve?occurrence=' + request['occurrence']
            details['next'] = ('Owner: open approval_url on the device holding the registered passkey, check the '
                               'rendering SHA-256, approve, then retry this exact call.')
        else:
            details['owner_command'] = ('python -m covenant_agent.assent_gate approve --journal ' + str(self.journal.path) +
                                        ' --occurrence ' + request['occurrence'] + ' --key-file OWNER_APPROVAL_KEY_FILE'
                                        ' --confirm ' + request['rendering'])
            details['next'] = ('Owner: run `python -m covenant_agent.assent_gate render` with the same journal and '
                               'occurrence, read the text, then run owner_command with that SHA-256. Retry this exact call, '
                               'or pass the printed approval as the approval argument.')
        return details

    def _verify_proof(self, record):
        method = self.policy['method']
        need(record['method'] == method['kind'], 'ASSENT_APPROVAL_METHOD')
        body = approval_object(record['decision'], record['request'])
        proof = record['proof']
        if method['kind'] == 'OWNER_KEY':
            _fields(proof, 'key signature', 'ASSENT_APPROVAL_FIELDS')
            need(proof['key'] == method['key'], 'ASSENT_APPROVAL_SIGNATURE')
            try:
                verify(proof['key'], APPROVAL_LABEL, body, proof['signature'])
            except NativeError:
                raise NativeError('ASSENT_APPROVAL_SIGNATURE') from None
            return None
        _fields(proof, 'credential_id client_data_json authenticator_data signature', 'ASSENT_APPROVAL_FIELDS')
        from covenant_chain.signin import verify_passkey_assertion
        registration = {'credential_id': method['credential_id'], 'rp_id': method['rp_id'],
                        'public_key': method['public_key']}
        try:
            verify_passkey_assertion({'label': APPROVAL_LABEL, **body}, proof, registration, origin=method['origin'],
                                     require_user_verification=method['user_verification'])
        except ValueError as exc:
            code = str(exc)
            raise NativeError('ASSENT_PASSKEY_USER_VERIFICATION' if code in (
                'SIGNIN_PASSKEY_USER_PRESENT', 'SIGNIN_PASSKEY_USER_VERIFIED') else 'ASSENT_PASSKEY_ASSERTION',
                REMEDIATION.get('ASSENT_PASSKEY_ASSERTION', '') + ' Verifier code: ' + code + '.') from None
        return (method['credential_id'], _passkey_counter(proof))

    def _verified(self, record, now):
        """Shape, policy pin, host issuance, state, expiry and proof. Matching the terms is separate."""
        _fields(record, 'version decision request method proof', 'ASSENT_APPROVAL_FIELDS')
        need(record['version'] == APPROVAL_VERSION and record['decision'] in DECISIONS and
             record['method'] in METHODS, 'ASSENT_APPROVAL_FIELDS')
        request = record['request']
        validate_request(request)
        need(request['policy'] == self.policy_hash, 'ASSENT_POLICY_CHANGED')
        row = self.journal.get(request['occurrence'])
        need(row is not None, 'ASSENT_APPROVAL_UNKNOWN')
        need(canonical(row['request']) == canonical(request), 'ASSENT_APPROVAL_CHANGED')
        return row

    def _live(self, record, row, now):
        if row['status'] == 'REFUSED':
            raise NativeError('ASSENT_APPROVAL_REFUSED')
        if row['status'] == 'CONSUMING':
            raise NativeError('ASSENT_APPROVAL_OUTCOME_UNKNOWN')
        need(row['status'] in ('PENDING', 'APPROVED'), 'ASSENT_APPROVAL_REUSED')
        need(now <= record['request']['expires_at'], 'ASSENT_APPROVAL_EXPIRED')
        return self._verify_proof(record)

    def submit(self, record):
        """Store an owner's decision for a pending request (approval page, owner tool). Signs nothing."""
        now = self.now()
        row = self._verified(record, now)
        if row['approval'] is not None and canonical(row['approval']) == canonical(record):
            return {'occurrence': row['occurrence'], 'status': row['status'], 'stored': False,
                    'signature_created': False, **FLAGS}
        need(record['decision'] == 'REFUSE' or row['status'] != 'APPROVED', 'ASSENT_APPROVAL_REUSED')
        counter = self._live(record, row, now)
        status = 'APPROVED' if record['decision'] == 'APPROVE' else 'REFUSED'
        self.journal.decide(row['occurrence'], status, record, now, counter)
        self._emit('APPROVAL_GIVEN' if status == 'APPROVED' else 'APPROVAL_REFUSED', agreement=row['agreement'],
                   rendering=row['rendering'], occurrence=row['occurrence'], role=row['role'],
                   evidence='SIGNED_BY_' + record['method'])
        return {'occurrence': row['occurrence'], 'status': status, 'stored': True, 'signature_created': False, **FLAGS}

    def decline(self, occurrence, evidence):
        """A client-reported decline or abandonment. Unauthenticated, so it can only block, never approve."""
        need(type(occurrence) is str and bool(HEX.fullmatch(occurrence)), 'ASSENT_APPROVAL_FIELDS')
        row = self.journal.get(occurrence)
        need(row is not None and row['policy'] == self.policy_hash, 'ASSENT_APPROVAL_UNKNOWN')
        if row['status'] not in ('PENDING', 'APPROVED'):
            return {'occurrence': occurrence, 'status': row['status'], 'stored': False, **FLAGS}
        self.journal.decide(occurrence, 'REFUSED', None, self.now())
        self._emit('APPROVAL_REFUSED', agreement=row['agreement'], rendering=row['rendering'], occurrence=occurrence,
                   role=row['role'], evidence=evidence)
        return {'occurrence': occurrence, 'status': 'REFUSED', 'stored': True, **FLAGS}

    def rendering_text(self, rendering):
        """Re-render a journaled subject; only text whose SHA-256 matches is returned."""
        need(type(rendering) is str and bool(HEX.fullmatch(rendering)), 'ASSENT_RESOURCE_UNKNOWN')
        with self.journal._connect() as db:
            row = db.execute('SELECT subject FROM requests WHERE rendering=? LIMIT 1', (rendering,)).fetchone()
        if row is None:
            return None
        rendered = assent_view.render(loads(row[0]))
        return rendered['text'] if rendered['rendering_sha256'] == rendering else None

    def resolve_arguments(self, tool, arguments):
        """Retain the exact call's nonce, including a completed receipt for safe recovery."""
        row = self.journal.by_call(call_digest(tool, arguments), self.policy['signer'], self.now(), self.policy_hash)
        return deepcopy(row['arguments']) if row is not None else None

    def _replay(self, record, row, assessment):
        rendered = assessment['rendered']
        need(row['status'] == 'CONSUMED' and row['result'] is not None and row['approval'] is not None and
             canonical(row['approval']) == canonical(record) and row['agreement'] == rendered['agreement_sha256'] and
             row['rendering'] == rendered['rendering_sha256'] and row['role'] == assessment['role'],
             'ASSENT_APPROVAL_REUSED')
        return deepcopy(row['result'])

    def run(self, guard, assessment, *, tool, call, arguments, subject, approval, execute, retained=None):
        """Sign through ``execute`` only when the policy and an approval allow it.

        ``retained(result)`` re-checks a replayed result before it is returned.
        """
        rendered, role = assessment['rendered'], assessment['role']
        if not assessment['required']:
            self._watch(assessment)
            with guard.permit(assessment['messages']):
                result = execute()
            return result, {'status': 'NOT_REQUIRED', 'threshold': assessment['threshold'], 'consumed': False}
        now = assessment['now']
        if approval is None:
            row = self.journal.find(agreement=rendered['agreement_sha256'], rendering=rendered['rendering_sha256'],
                                    signer=self.policy['signer'], role=role, now=now, policy=self.policy_hash)
            if row is not None and row['status'] == 'REFUSED':
                raise NativeError('ASSENT_APPROVAL_REFUSED')
            if row is not None and row['status'] in ('CONSUMING', 'FAILED'):
                raise NativeError('ASSENT_APPROVAL_OUTCOME_UNKNOWN')
            if row is None or row['status'] not in ('APPROVED', 'CONSUMED'):
                row = self._request_for(assessment, tool=tool, call=call, arguments=arguments, subject=subject)
                raise ApprovalRequired(self.pending_details(assessment, row, tool))
            approval = row['approval']
        need(type(approval) is dict, 'ASSENT_APPROVAL_FIELDS')
        row = self._verified(approval, now)
        if row['status'] in ('CONSUMED', 'FAILED'):
            result = self._replay(approval, row, assessment)
            if retained is not None:
                retained(result)
            return result, {'status': 'REPLAYED', 'occurrence': row['occurrence'], 'consumed': True}
        request = approval['request']
        need(request['role'] == role, 'ASSENT_APPROVAL_ROLE')
        need(canonical(request['amount']) == canonical(rendered['summary']['amount']), 'ASSENT_APPROVAL_AMOUNT')
        need(canonical(request['payee']) == canonical(rendered['summary']['payee']), 'ASSENT_APPROVAL_PAYEE')
        need(request['agreement'] == rendered['agreement_sha256'], 'ASSENT_APPROVAL_AGREEMENT')
        need(request['rendering'] == rendered['rendering_sha256'], 'ASSENT_APPROVAL_RENDERING')
        need(request['signer'] == self.policy['signer'], 'ASSENT_APPROVAL_SIGNATURE')
        if approval['decision'] == 'REFUSE':
            self.submit(approval)
            raise NativeError('ASSENT_APPROVAL_REFUSED')
        counter = self._live(approval, row, now)
        self._watch(assessment)
        previous = self.journal.reserve(row['occurrence'], approval, now, counter)
        if previous == 'PENDING':
            self._emit('APPROVAL_GIVEN', agreement=row['agreement'], rendering=row['rendering'],
                       occurrence=row['occurrence'], role=role, evidence='SIGNED_BY_' + approval['method'])
        permits = None
        try:
            with guard.permit(assessment['messages']) as permits:
                result = execute()
        except BaseException as exc:
            if permits is None or not any(permits.values()):
                self.journal.release(row['occurrence'], previous)
            else:
                self.journal.finish(row['occurrence'], 'FAILED', None, 'FAILED_AFTER_SIGNATURE:' +
                                    (getattr(exc, 'code', None) or exc.__class__.__name__)[:80])
            raise
        if not any(permits.values()):
            self.journal.release(row['occurrence'], previous)
            return result, {'status': 'NO_NEW_ASSENT', 'occurrence': row['occurrence'], 'consumed': False}
        self.journal.finish(row['occurrence'], 'CONSUMED', result, 'SIGNED')
        return result, {'status': 'CONSUMED', 'occurrence': row['occurrence'], 'consumed': True,
                        'request': deepcopy(request)}


def call_digest(tool, arguments):
    return digest('COVENANT-ASSENT-CALL-0.1', {'tool': tool, 'arguments': arguments})


def _read_private(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0
             and info.st_size <= limit, 'ASSENT_KEY_FILE')
        return os.read(fd, limit + 1)
    finally:
        os.close(fd)


def _key_file(path):
    raw = _read_private(path, 66).strip()
    need(len(raw) == 64 and all(c in b'0123456789abcdef' for c in raw), 'ASSENT_KEY_FILE')
    return key_from_seed(raw.decode('ascii'))


def _json_file(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        need(stat.S_ISREG(os.fstat(fd).st_mode), 'ASSENT_APPROVAL_FIELDS')
        raw = os.read(fd, MAX_FILE_BYTES + 1)
    finally:
        os.close(fd)
    need(len(raw) <= MAX_FILE_BYTES, 'SIZE_LIMIT')
    return loads(raw)


def _write_new(path, value):
    from covenant_language.safe_io import atomic_write
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode('ascii')
    target = Path(path).expanduser().absolute()
    atomic_write(target, raw, mode=0o600, exclusive=True)
    return str(target)


def _journal_subject(journal, occurrence):
    row = journal.get(occurrence)
    need(row is not None, 'ASSENT_APPROVAL_UNKNOWN')
    rendered = assent_view.render(row['subject'])
    # The owner's own tool recomputes the rendering from the stored bytes; a mismatch is never displayed as approved.
    need(rendered['rendering_sha256'] == row['request']['rendering'] and
         rendered['agreement_sha256'] == row['request']['agreement'], 'ASSENT_APPROVAL_RENDERING')
    return row, rendered


def _pairs(items):
    found = {}
    for item in items:
        name, separator, value = item.partition('=')
        need(separator == '=' and value.isdigit() and name not in found, 'ASSENT_POLICY_RISK')
        found[name] = int(value)
    return found


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_agent.assent_gate',
        description='Owner tools for assent approval: adopt a policy, read the exact rendering, approve or refuse once.')
    commands = parser.add_subparsers(dest='command', required=True)
    policy = commands.add_parser('policy', help='Sign a new approval policy with the owner key file.')
    policy.add_argument('--owner-key-file', required=True, help='Owner Ed25519 seed hex file, mode 0600. Never printed.')
    policy.add_argument('--signer', required=True, help='Agent public key whose assents this policy gates.')
    policy.add_argument('--threshold', action='append', default=[], help='UNIT=LARGEST_UNAPPROVED_AMOUNT; repeatable.')
    policy.add_argument('--role', action='append', choices=ROLES, help='Gated assent role; repeatable (default agent and counterparty).')
    policy.add_argument('--approval-key', help='OWNER_KEY method: the approval public key (not the agent key).')
    policy.add_argument('--passkey-credential-id')
    policy.add_argument('--passkey-public-key', help='Uncompressed P-256 point hex from the passkey registration.')
    policy.add_argument('--rp-id')
    policy.add_argument('--origin', help='Approval page origin, for example http://localhost:8471.')
    policy.add_argument('--risk-above', type=int, help='Policy 0.2: also require approval above this risk score (basis points).')
    policy.add_argument('--risk-weight', action='append', default=[],
                        help='NAME=WEIGHT for amount, breadth, history, irreversibility, novelty (0..100); repeatable.')
    policy.add_argument('--risk-scale', action='append', default=[], help='UNIT=AMOUNT that scores 10000; repeatable.')
    policy.add_argument('--max-age', type=int, default=600)
    policy.add_argument('--expires', type=int, default=MAX_INTEGER)
    policy.add_argument('--out', required=True, help='New policy file (created 0600, never overwritten).')
    render = commands.add_parser('render', help='Print the exact rendering of a pending request or an envelope file.')
    render.add_argument('--journal')
    render.add_argument('--occurrence')
    render.add_argument('--envelope', help='Envelope or order JSON file to render instead of a journal request.')
    approve = commands.add_parser('approve', help='Approve or refuse one pending request with the owner key.')
    approve.add_argument('--journal', required=True)
    approve.add_argument('--occurrence', required=True)
    approve.add_argument('--key-file', required=True, help='Owner approval Ed25519 seed hex file, mode 0600. Never printed.')
    approve.add_argument('--confirm', required=True, help='The rendering SHA-256 you read with the render command.')
    approve.add_argument('--decision', choices=('approve', 'refuse'), default='approve')
    inspect = commands.add_parser('inspect', help='Print journal status as JSON, or Prometheus text.')
    inspect.add_argument('--journal', required=True)
    inspect.add_argument('--prometheus', action='store_true')
    backup = commands.add_parser('backup', help='Copy the journal into a new owner-private file.')
    backup.add_argument('--journal', required=True)
    backup.add_argument('--out', required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'policy':
            owner = _key_file(args.owner_key_file)
            thresholds = {}
            for item in args.threshold:
                unit, separator, amount = item.partition('=')
                need(separator == '=' and amount.isdigit() and unit not in thresholds, 'ASSENT_POLICY_FIELDS')
                thresholds[unit] = int(amount)
            if args.approval_key:
                need(not args.passkey_credential_id, 'ASSENT_POLICY_FIELDS')
                method = {'kind': 'OWNER_KEY', 'key': args.approval_key}
            else:
                method = {'kind': 'PASSKEY', 'credential_id': args.passkey_credential_id,
                          'public_key': args.passkey_public_key, 'rp_id': args.rp_id, 'origin': args.origin,
                          'user_verification': True}
            options = dict(method=method, thresholds=thresholds, roles=args.role or ['agent', 'counterparty'],
                           max_age=args.max_age, expires=args.expires)
            if args.risk_above is None:
                need(not args.risk_weight and not args.risk_scale, 'ASSENT_POLICY_RISK')
                body = policy_body(public_key(owner), args.signer, **options)
            else:
                weights = _pairs(args.risk_weight)
                need(set(weights) <= set(risk_score.FACTORS), 'ASSENT_POLICY_RISK')
                try:
                    risk = risk_score.policy(args.risk_above, {name: weights.get(name, 1) for name in risk_score.FACTORS},
                                             _pairs(args.risk_scale))
                except ValueError:
                    raise NativeError('ASSENT_POLICY_RISK') from None
                body = risk_policy_body(public_key(owner), args.signer, risk=risk, **options)
            record = sign_policy(owner, body)
            result = {'format': body['version'], 'policy': policy_id(body), 'path': _write_new(args.out, record),
                      'signer': body['signer'], 'roles': body['roles'], 'method': method['kind'], 'private_keys_in_output': False, **FLAGS}
        elif args.command == 'render':
            if args.envelope:
                need(not args.journal and not args.occurrence, 'ARGUMENTS')
                rendered = assent_view.render(_json_file(args.envelope))
            else:
                need(bool(args.journal and args.occurrence), 'ARGUMENTS')
                _, rendered = _journal_subject(Journal(args.journal), args.occurrence)
            sys.stdout.write(rendered['text'])
            sys.stdout.write('Rendering SHA-256: ' + rendered['rendering_sha256'] + '\n')
            return 0
        elif args.command == 'approve':
            journal = Journal(args.journal)
            row, rendered = _journal_subject(journal, args.occurrence)
            need(args.confirm == rendered['rendering_sha256'], 'ASSENT_CONFIRMATION')
            gate = AssentGate(journal.policy(row['policy']), args.journal, clock=lambda: int(__import__('time').time()))
            private = _key_file(args.key_file)
            record = sign_approval(private, row['request'], 'APPROVE' if args.decision == 'approve' else 'REFUSE')
            stored = gate.submit(record)
            result = {'approval': record, 'stored': stored, 'private_keys_in_output': False, **FLAGS}
        elif args.command == 'inspect':
            status = Journal(args.journal).status(int(__import__('time').time()))
            if args.prometheus:
                sys.stdout.write(prometheus(status))
                return 0
            result = {**status, **FLAGS}
        else:
            result = {'format': JOURNAL_VERSION, 'backup': Journal(args.journal).backup(args.out), **FLAGS}
    except (NativeError, ValueError, OSError, sqlite3.Error) as exc:
        code = exc.code if isinstance(exc, NativeError) else str(exc)
        if not re.fullmatch(r'[A-Z][A-Z0-9_]{0,100}', code or ''):
            code = 'ASSENT_OWNER_TOOL_FAILED'
        from .errors import refusal
        shape = refusal(code, REMEDIATION.get(code, 'Correct the named input and retry.'))
        print(json.dumps({'error': code, **shape, 'remediation': shape['fix'], **FLAGS}, sort_keys=True),
              file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
