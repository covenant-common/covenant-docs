"""Owner-local HTTP for assent approval: an AG-UI 1.0 SSE endpoint and a passkey approval page.

Loopback only. ``POST /agui`` runs one AG-UI run against the owner's host and
needs the bearer token the owner received in a private file (RFC 6750 section
2.1 Authorization header). ``GET /assent/approve`` shows the exact rendering of
one pending request; ``POST /assent/approve`` accepts a WebAuthn Level 3 get()
assertion over that exact request. The private key stays in the authenticator;
this page holds no key and cannot sign an assent. A recorded approval is used
only when the agent retries the exact call it was issued for.
"""
import argparse
from html import escape
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler
import json
import os
from pathlib import Path
import re
import secrets
import sys
import threading
from urllib.parse import parse_qs, urlsplit

from .errors import NativeError, REMEDIATION, need, refusal

MAX_BODY = 1048576
MAX_APPROVAL_BODY = 16384
COOKIE = 'covenant_assent'


def _json(raw):
    def pairs(items):
        result = {}
        for name, value in items:
            need(name not in result, 'ASSENT_HTTP_JSON')
            result[name] = value
        return result

    def invalid(_value):
        raise NativeError('ASSENT_HTTP_JSON')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=invalid)
    except (UnicodeError, ValueError, RecursionError):
        raise NativeError('ASSENT_HTTP_JSON') from None
    pending, nodes = [(value, 0)], 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        need(depth <= 32 and nodes <= 65536, 'ASSENT_HTTP_JSON')
        if type(item) is dict:
            pending.extend((child, depth + 1) for child in item.values())
        elif type(item) is list:
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is int:
            need(abs(item) <= 2**53 - 1, 'ASSENT_HTTP_JSON')
    return value


def _wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def make_server(host, *, port=0, token=None, max_connections=8, connection_seconds=10):
    """Bind the owner-local server. A PASSKEY policy fixes the origin and port its credential is scoped to."""
    from covenant_chain.http_limits import BoundedHTTPServer
    need(token is None or (type(token) is str and 32 <= len(token) <= 128), 'ASSENT_HTTP_TOKEN')
    gate = host.assent
    origin = None
    if gate is not None and gate.policy['method']['kind'] == 'PASSKEY':
        origin = gate.policy['method']['origin']
        parts = urlsplit(origin)
        need(parts.scheme == 'http' and parts.port is not None and port in (0, parts.port), 'ASSENT_HTTP_ORIGIN')
        port = parts.port
    need(type(port) is int and 0 <= port <= 65535, 'ASSENT_HTTP_PORT')

    class Server(BoundedHTTPServer):
        allow_reuse_address = True
        allow_reuse_port = False

    server = Server(('127.0.0.1', port), AssentHandler, max_connections=max_connections,
                    connection_seconds=connection_seconds)
    server.agent_host, server.gate, server.token = host, gate, token
    server.lock = threading.Lock()
    server.csrf, server.cookie = secrets.token_hex(32), secrets.token_hex(32)
    server.origin = origin or 'http://127.0.0.1:' + str(server.server_address[1])
    server.netloc = urlsplit(server.origin).netloc
    server.cookie_name = COOKIE + '_' + str(server.server_address[1])
    return server


class AssentHandler(BaseHTTPRequestHandler):
    server_version = 'AAPAssent'
    sys_version = ''

    def log_message(self, *_args):
        pass  # Paths, headers, tokens and agreement text never become request logs.

    def _send(self, status, body, media='application/json', *, cookie=False, nonce=None):
        self.send_response(status)
        self.send_header('Content-Type', media)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        source = "'nonce-%s'" % nonce if nonce else "'none'"
        self.send_header('Content-Security-Policy', "default-src 'none'; script-src %s; style-src %s; "
                         "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" % (source, source))
        if cookie:
            self.send_header('Set-Cookie', '%s=%s; HttpOnly; SameSite=Strict; Path=/assent'
                             % (self.server.cookie_name, self.server.cookie))
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def _error(self, code, status=400):
        shape = refusal(code, REMEDIATION.get(code, 'Correct the request and retry.'))
        self._send(status, _wire({'error': {**shape, 'remediation': shape['fix']}, 'execution_authorized': False}))

    def send_error(self, code, message=None, explain=None):
        self._error('ASSENT_HTTP_REFUSED', code)

    def _failure(self, exc):
        code = getattr(exc, 'code', None) or str(exc)
        if not re.fullmatch(r'[A-Z][A-Z0-9_]{0,100}', code):
            code = 'ASSENT_HTTP_REFUSED'
        status = {'AGUI_AUTH': 401, 'AGUI_ACCEPT': 406, 'ASSENT_APPROVAL_UNKNOWN': 404, 'ASSENT_HTTP_NOT_FOUND': 404,
                  'ASSENT_APPROVAL_REUSED': 409, 'ASSENT_APPROVAL_REFUSED': 409,
                  'ASSENT_APPROVAL_OUTCOME_UNKNOWN': 409, 'ASSENT_HTTP_SIZE': 413}.get(code, 400)
        self._error(code, status)

    def _host(self):
        need(self.headers.get_all('Host') == [self.server.netloc], 'ASSENT_HTTP_ORIGIN')

    def _body(self, limit):
        need(self.headers.get('Transfer-Encoding') is None and self.headers.get('Expect') is None, 'ASSENT_HTTP_FRAMING')
        need(self.headers.get_all('Content-Type') == ['application/json'], 'ASSENT_HTTP_CONTENT_TYPE')
        lengths = self.headers.get_all('Content-Length')
        need(lengths is not None and len(lengths) == 1 and lengths[0].isascii() and lengths[0].isdigit()
             and len(lengths[0]) <= 8, 'ASSENT_HTTP_FRAMING')
        length = int(lengths[0])
        need(0 < length <= limit, 'ASSENT_HTTP_SIZE')
        raw = self.rfile.read(length)
        need(len(raw) == length, 'ASSENT_HTTP_FRAMING')
        return _json(raw)

    def _session(self):
        need(self.headers.get_all('Origin') == [self.server.origin], 'ASSENT_HTTP_ORIGIN')
        cookies = self.headers.get_all('Cookie')
        need(cookies is not None and len(cookies) == 1, 'ASSENT_HTTP_SESSION')
        jar = SimpleCookie()
        try:
            jar.load(cookies[0])
        except Exception:
            raise NativeError('ASSENT_HTTP_SESSION') from None
        value = jar.get(self.server.cookie_name)
        need(value is not None and secrets.compare_digest(value.value, self.server.cookie), 'ASSENT_HTTP_SESSION')
        need(self.headers.get_all('X-Covenant-CSRF') == [self.server.csrf], 'ASSENT_HTTP_CSRF')

    def do_GET(self):
        try:
            self._host()
            parsed = urlsplit(self.path)
            if parsed.path == '/assent/approve':
                self._page(parsed.query)
            else:
                raise NativeError('ASSENT_HTTP_NOT_FOUND')
        except (NativeError, ValueError, OSError) as exc:
            self._failure(exc)

    def do_POST(self):
        try:
            self._host()
            parsed = urlsplit(self.path)
            need(parsed.query == '', 'ASSENT_HTTP_NOT_FOUND')
            if parsed.path == '/agui':
                self._agui()
            elif parsed.path == '/assent/approve':
                self._approve()
            else:
                raise NativeError('ASSENT_HTTP_NOT_FOUND')
        except (NativeError, ValueError, TypeError, OSError) as exc:
            self._failure(exc)

    def do_OPTIONS(self):
        self._error('ASSENT_HTTP_ORIGIN', 403)

    def _agui(self):
        from . import agui
        need(self.server.token is not None, 'ASSENT_HTTP_NOT_FOUND')
        offered = self.headers.get_all('Authorization')
        need(offered is not None and len(offered) == 1 and offered[0].startswith('Bearer ') and
             secrets.compare_digest(offered[0][7:].encode('ascii', 'replace'), self.server.token.encode('ascii')),
             'AGUI_AUTH')
        accept = ','.join(self.headers.get_all('Accept') or [])
        need('text/event-stream' in accept, 'AGUI_ACCEPT')
        run_input = self._body(agui.MAX_INPUT_BYTES)
        with self.server.lock:
            events = agui.run_events(self.server.agent_host, run_input)
        body = b''.join(agui.encode(event) for event in events)
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def _row(self, occurrence):
        gate = self.server.gate
        need(gate is not None, 'ASSENT_POLICY_NOT_INSTALLED')
        need(type(occurrence) is str and re.fullmatch(r'[0-9a-f]{64}', occurrence) is not None, 'ASSENT_APPROVAL_UNKNOWN')
        row = gate.journal.get(occurrence)
        need(row is not None and row['policy'] == gate.policy_hash, 'ASSENT_APPROVAL_UNKNOWN')
        return gate, row

    def _page(self, query):
        from . import assent_gate, assent_view
        values = parse_qs(query, keep_blank_values=True, max_num_fields=2, strict_parsing=True) if query else {}
        need(set(values) == {'occurrence'} and len(values['occurrence']) == 1, 'ASSENT_APPROVAL_UNKNOWN')
        with self.server.lock:
            gate, row = self._row(values['occurrence'][0])
            rendered = assent_view.render(row['subject'])
            # Recomputed here from the stored bytes; a mismatch is refused, never displayed for approval.
            need(rendered['rendering_sha256'] == row['request']['rendering'], 'ASSENT_APPROVAL_RENDERING')
            now = gate.now()
        request, method = row['request'], gate.policy['method']
        live = row['status'] in ('PENDING', 'APPROVED') and now <= request['expires_at']
        passkey = method['kind'] == 'PASSKEY' and live
        nonce = secrets.token_hex(16)
        data = {'occurrence': request['occurrence'], 'csrf': self.server.csrf}
        if passkey:
            data.update(credential=method['credential_id'], rp=method['rp_id'],
                        uv='required' if method['user_verification'] else 'preferred',
                        approve=assent_gate.passkey_challenge(request, 'APPROVE'),
                        refuse=assent_gate.passkey_challenge(request, 'REFUSE'))
        attributes = ' '.join('data-%s="%s"' % (name, escape(value, quote=True)) for name, value in sorted(data.items()))
        amount = request['amount']
        rows = [('Agreement SHA-256', request['agreement']), ('Rendering SHA-256', request['rendering']),
                ('Amount', '%d %s' % (amount['amount'], amount['unit'])),
                ('Payee key', request['payee']['key']), ('Pay to', request['payee']['pay_to']),
                ('Role', request['role']), ('Agent key', request['signer']),
                ('Expires', assent_view.utc(request['expires_at'])), ('Status', row['status'] if live else 'CLOSED')]
        listing = ''.join('<dt>%s</dt><dd>%s</dd>' % (escape(name), escape(str(value))) for name, value in rows)
        if passkey:
            controls = ('<p><button id="approve" class="primary" type="button">Approve with passkey</button> '
                        '<button id="refuse" type="button">Refuse with passkey</button></p>')
        elif method['kind'] == 'OWNER_KEY' and live:
            controls = ('<p>This policy uses an owner approval key. On the device holding it run:</p><pre>%s</pre>'
                        % escape(gate.pending_details({'rendered': rendered, 'role': row['role'], 'required': True,
                                                       'threshold': gate.threshold(amount)}, row, row['tool'])['owner_command']))
        else:
            controls = '<p>This request is closed. Nothing more can be recorded for it.</p>'
        page = APPROVAL_PAGE.format(nonce=nonce, attributes=attributes, listing=listing,
                                    rendering=escape(rendered['text']), controls=controls)
        self._send(200, page.encode('ascii'), 'text/html; charset=utf-8', cookie=True, nonce=nonce)

    def _approve(self):
        from . import assent_gate
        self._session()
        payload = self._body(MAX_APPROVAL_BODY)
        need(type(payload) is dict and set(payload) == {'occurrence', 'decision', 'assertion'} and
             payload['decision'] in ('APPROVE', 'REFUSE'), 'ASSENT_APPROVAL_FIELDS')
        with self.server.lock:
            gate, row = self._row(payload['occurrence'])
            need(gate.policy['method']['kind'] == 'PASSKEY', 'ASSENT_APPROVAL_METHOD')
            record = assent_gate.passkey_approval(row['request'], payload['assertion'], payload['decision'])
            result = gate.submit(record)
        self._send(200, _wire({'occurrence': result['occurrence'], 'status': result['status'],
                               'stored': result['stored'], 'signature_created': False, 'execution_authorized': False,
                               'next': 'Retry the agent call it was issued for; this page signs nothing.'}))


APPROVAL_PAGE = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="referrer" content="no-referrer">
<title>Approve an agreement - AAP</title>
<style nonce="{nonce}">
*{{box-sizing:border-box}}
:root{{font-family:"Times New Roman",Times,serif;font-size:16px;line-height:1.16;color:#000;background:#fff}}
body{{margin:1rem;background:#fff;color:#000}}
main{{max-width:52rem;margin:0 auto;border:1px solid #000;padding:1rem}}
h1,p,dl,dd,dt,pre{{font-size:1rem;margin:0 0 .618rem}}
h1,dt{{font-weight:bold}}
dd{{margin-left:1rem;word-break:break-all}}
pre{{white-space:pre-wrap;word-break:break-word;font-family:"Times New Roman",Times,serif}}
button{{font:inherit;line-height:1.16;color:#000;background:#fff;border:1px solid #000;border-radius:0;padding:.618rem}}
button.primary{{font-weight:bold;border-width:2px}}
</style>
</head>
<body>
<main id="main" {attributes}>
<h1>Approve an agreement</h1>
<p>This page signs nothing and holds no key. Approving lets the named agent key sign this exact assent once.
Compare the rendering SHA-256 with the one the agent's host showed you.</p>
<dl>{listing}</dl>
<pre>{rendering}</pre>
{controls}
<p id="status" role="status"></p>
</main>
<script nonce="{nonce}">
(function () {{
  'use strict';
  var main = document.getElementById('main'), status = document.getElementById('status');
  function bytes(text) {{
    var value = text.replace(/-/g, '+').replace(/_/g, '/');
    while (value.length % 4) {{ value += '='; }}
    var raw = atob(value), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) {{ out[i] = raw.charCodeAt(i); }}
    return out;
  }}
  function text(buffer) {{
    var data = new Uint8Array(buffer), raw = '';
    for (var i = 0; i < data.length; i++) {{ raw += String.fromCharCode(data[i]); }}
    return btoa(raw).replace(/\\+/g, '-').replace(/\\//g, '_').replace(/=+$/, '');
  }}
  function decide(decision) {{
    if (!(window.PublicKeyCredential && navigator.credentials)) {{ status.textContent = 'This browser cannot use a passkey here.'; return; }}
    var challenge = decision === 'APPROVE' ? main.dataset.approve : main.dataset.refuse;
    navigator.credentials.get({{publicKey: {{challenge: bytes(challenge), rpId: main.dataset.rp, timeout: 120000,
      userVerification: main.dataset.uv, allowCredentials: [{{type: 'public-key', id: bytes(main.dataset.credential)}}]}}}})
      .then(function (credential) {{
        return fetch('/assent/approve', {{method: 'POST', credentials: 'same-origin',
          headers: {{'Content-Type': 'application/json', 'X-Covenant-CSRF': main.dataset.csrf}},
          body: JSON.stringify({{occurrence: main.dataset.occurrence, decision: decision, assertion: {{
            credential_id: text(credential.rawId), client_data_json: text(credential.response.clientDataJSON),
            authenticator_data: text(credential.response.authenticatorData), signature: text(credential.response.signature)}}}})}});
      }})
      .then(function (response) {{ return response.json(); }})
      .then(function (body) {{
        status.textContent = body.status ? 'Recorded: ' + body.status + '. The agent may now retry its exact call.' :
          'Not recorded: ' + (body.error && body.error.code);
      }}, function () {{ status.textContent = 'The passkey ceremony did not complete. Nothing was recorded.'; }});
  }}
  var approve = document.getElementById('approve'), refuse = document.getElementById('refuse');
  if (approve) {{ approve.addEventListener('click', function () {{ decide('APPROVE'); }}); }}
  if (refuse) {{ refuse.addEventListener('click', function () {{ decide('REFUSE'); }}); }}
}}());
</script>
</body>
</html>
'''


def _write_token(path, token):
    from covenant_language.safe_io import atomic_write
    target = Path(path).expanduser().absolute()
    atomic_write(target, token + '\n', mode=0o600, exclusive=True)
    return str(target)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--config', required=True, help='Owner host config with an assent policy; a seed requires mode 0600.')
    parser.add_argument('--port', type=int, default=0, help='Loopback port; a PASSKEY policy fixes it to its origin port.')
    parser.add_argument('--token-file', help='New 0600 file that receives the AG-UI bearer token; omit to disable /agui.')
    args = parser.parse_args(argv)
    try:
        from .mcp import Host
        from .server import load_config
        host = Host(load_config(args.config))
        token = secrets.token_urlsafe(32) if args.token_file else None
        server = make_server(host, port=args.port, token=token)
        if token is not None:
            _write_token(args.token_file, token)
    except (NativeError, ValueError, OSError) as exc:
        code = getattr(exc, 'code', None) or 'ASSENT_HTTP_REFUSED'
        code = code if re.fullmatch(r'[A-Z][A-Z0-9_]{0,100}', code) else 'ASSENT_HTTP_REFUSED'
        print(json.dumps({'error': code, **refusal(code, REMEDIATION.get(code)), 'execution_authorized': False}),
              file=sys.stderr)
        return 1
    print(json.dumps({'url': server.origin, 'agui': token is not None, 'token_file': args.token_file,
                      'approval_page': host.assent is not None, 'local_only': True, 'execution_authorized': False}),
          flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
