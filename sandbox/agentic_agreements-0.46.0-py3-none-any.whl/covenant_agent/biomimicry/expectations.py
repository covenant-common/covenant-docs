"""Expected trajectory of one bilateral covenant, and the error class of an observation.

Error classes are the prediction-error alphabet the attention feed scores.
Nothing here reads a clock or a chain.
"""
from ..errors import need

ERRORS = ('ON_TRACK', 'EARLY', 'LATE', 'PARTIAL', 'DEVIATION', 'DISPUTED', 'SILENT')
# Surprise in basis points. LATE is graded inside classify and can exceed this base.
SURPRISE = {
    'ON_TRACK': 0,
    'EARLY': 1000,
    'LATE': 6000,
    'PARTIAL': 4000,
    'DEVIATION': 7000,
    'DISPUTED': 9000,
    'SILENT': 8500,
}
KINDS = ('ASSENT', 'DELIVERY', 'DECISION', 'RELEASE', 'DISPUTE', 'OTHER')


def trajectory(terms):
    """Events the terms already name. ``as_of`` is not consulted."""
    need(type(terms) is dict, 'ATTENTION_FIELDS')
    deadline = terms.get('deadline')
    window = terms.get('challenge_window', 0)
    need(type(deadline) is int and not type(deadline) is bool and deadline >= 0, 'ATTENTION_FIELDS')
    need(type(window) is int and not type(window) is bool and window >= 0, 'ATTENTION_FIELDS')
    return {
        'assent_by': deadline,
        'delivery_by': deadline,
        'decision_by': deadline + window,
        'release_after': deadline + window,
        'consensus_changed': False,
    }


def _surprise_late(lateness, window):
    span = window if window > 0 else 1
    grade = min(10000, lateness * 10000 // span)
    return min(10000, 4000 + grade * 6000 // 10000)


def classify(kind, *, due, at=None, as_of, partial=False, window=86400, not_before=None):
    """Return ``(error, surprise_bps)`` for one structured observation."""
    need(kind in KINDS, 'ATTENTION_FIELDS')
    need(type(due) is int and not type(due) is bool and due >= 0, 'ATTENTION_FIELDS')
    need(type(as_of) is int and not type(as_of) is bool and as_of >= 0, 'ATTENTION_FIELDS')
    need(type(window) is int and not type(window) is bool and window >= 0, 'ATTENTION_FIELDS')
    need(type(partial) is bool, 'ATTENTION_FIELDS')
    if at is not None:
        need(type(at) is int and not type(at) is bool and at >= 0, 'ATTENTION_FIELDS')
    if not_before is not None:
        need(type(not_before) is int and not type(not_before) is bool and not_before >= 0, 'ATTENTION_FIELDS')
    if kind == 'DISPUTE':
        return 'DISPUTED', SURPRISE['DISPUTED']
    if kind == 'OTHER':
        return 'DEVIATION', SURPRISE['DEVIATION']
    if partial:
        return 'PARTIAL', SURPRISE['PARTIAL']
    if at is None:
        if as_of > due:
            return 'SILENT', SURPRISE['SILENT']
        return 'ON_TRACK', SURPRISE['ON_TRACK']
    if not_before is not None and at < not_before:
        return 'EARLY', SURPRISE['EARLY']
    if at > due:
        return 'LATE', _surprise_late(at - due, window)
    return 'ON_TRACK', SURPRISE['ON_TRACK']
