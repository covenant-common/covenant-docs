"""SDK reflexes: circuit breaker, spend-velocity cap, fusion challenge, silence refund.

Refund-on-silence calls the existing ``release_if_silent`` path (PR #21's
RELEASE_IF_UNDECIDED rule). There is no new refund verb and no submission.
A pause stops new covenants with that counterparty in this process. It does
not invalidate a transaction.
"""
from ..envelope import open_dispute, release_if_silent
from ..errors import NativeError, need

WINDOW = 30 * 86400
DISPUTE_LIMIT = 2
PROFILE = 'covenant-reflex/0.1'


def _int(value):
    need(type(value) is int and not type(value) is bool, 'ATTENTION_FIELDS')
    return value


def circuit_breaker(counterparty, disputes, *, as_of, k=DISPUTE_LIMIT, window=WINDOW):
    """Pause after ``k`` disputes with this counterparty inside ``window`` seconds."""
    need(type(counterparty) is str and len(counterparty) == 64, 'ATTENTION_FIELDS')
    need(type(disputes) is list and len(disputes) <= 256, 'ATTENTION_FIELDS')
    _int(as_of)
    need(as_of >= 0, 'ATTENTION_FIELDS')
    _int(k)
    need(k >= 1, 'ATTENTION_FIELDS')
    _int(window)
    need(window >= 0, 'ATTENTION_FIELDS')
    recent = []
    for row in disputes:
        need(type(row) is dict and type(row.get('counterparty')) is str, 'ATTENTION_FIELDS')
        at = _int(row.get('at'))
        need(at >= 0, 'ATTENTION_FIELDS')
        if row['counterparty'] != counterparty:
            continue
        if as_of - window < at <= as_of:
            recent.append(at)
    paused = len(recent) >= k
    return {
        'profile': PROFILE,
        'hook': 'sdk_circuit_breaker',
        'paused': paused,
        'count': len(recent),
        'k': k,
        'window': window,
        'counterparty': counterparty,
        'action': 'PAUSE_NEW_COVENANTS' if paused else 'ALLOW',
        'invalidates_transactions': False,
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
    }


def spend_velocity(spent, proposed, limit):
    """True when ``spent + proposed`` still fits the mandate limit."""
    for value in (spent, proposed, limit):
        _int(value)
        need(value >= 0, 'ATTENTION_FIELDS')
    allowed = spent + proposed <= limit
    return {'allowed': allowed, 'spent': spent, 'proposed': proposed, 'limit': limit,
            'hook': 'sdk_circuit_breaker', 'consensus_changed': False, 'applied': False}


def guard(counterparty, disputes, *, as_of, spent=0, proposed=0, limit=None, k=DISPUTE_LIMIT, window=WINDOW):
    """Raise ``REFLEX_PAUSED`` when a new covenant should not be opened."""
    breaker = circuit_breaker(counterparty, disputes, as_of=as_of, k=k, window=window)
    if breaker['paused']:
        raise NativeError('REFLEX_PAUSED')
    if limit is not None:
        pace = spend_velocity(spent, proposed, limit)
        if not pace['allowed']:
            raise NativeError('REFLEX_PAUSED')
        breaker['spend'] = pace
    return breaker


def silence(envelope, *, signer, ledger, as_of, rail=None):
    """Refund through ``release_if_silent``. The chain is not asked."""
    result = release_if_silent(envelope, signer=signer, ledger=ledger, as_of=as_of, rail=rail)
    report = {
        'hook': 'pr21.release_if_silent',
        'refund_verb': None,
        'native_op': result.get('native_op'),
        'submitted': False,
        'verdict': result['verdict']['verdict'],
        'chain_ledger_touched': False,
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
        'action_needed': 'release_if_silent',
        'cid': result['cid'],
    }
    if envelope.get('profile') == 'covenant-bilateral/0.2':
        report.update(envelope=result['envelope'], replayed=result['replayed'],
                      reference_ledger_touched=not result['replayed'],
                      funds_observed=result['verdict']['funds_observed'])
    return report


def challenge(fusion, *, value, threshold, envelope=None, signer=None, ledger=None, as_of=None):
    """Open a local dispute when fusion already flagged an independent conflict."""
    need(type(fusion) is dict, 'FUSION_FIELDS')
    _int(value)
    _int(threshold)
    if not fusion.get('auto_dispute') or value < threshold:
        return {'action': 'NONE', 'submitted': False, 'consensus_changed': False, 'applied': False,
                'execution_authorized': False, 'hook': 'sdk_circuit_breaker'}
    plan = fusion.get('plan') or {}
    opened = False
    anchor = None
    if envelope is not None and signer is not None:
        context = {'ledger': ledger, 'as_of': as_of} if envelope.get('profile') == 'covenant-bilateral/0.2' else {}
        env = open_dispute(envelope, signer=signer, reason='FUSION_CONFLICT', evidence_hash=plan['evidence_hash'], **context)
        opened = True
        anchor = (env['dispute'].get('anchor') or {}).get('status')
    result = {
        'action': 'OPEN_DISPUTE',
        'submitted': False,
        'opened': opened,
        'anchor': anchor,
        'plan': {'reason': plan.get('reason'), 'evidence_hash': plan.get('evidence_hash'), 'submitted': False},
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
        'hook': 'sdk_circuit_breaker',
        'native_op': None,
    }
    if opened and envelope.get('profile') == 'covenant-bilateral/0.2':
        result['envelope'] = env
    return result


def evaluate(counterparty, disputes, *, as_of, spent=0, proposed=0, limit=None, k=DISPUTE_LIMIT, window=WINDOW,
             envelope=None, signer=None, ledger=None, rail=None, fusion=None, value=0, challenge_threshold=0,
             guard_new=False):
    """Run the reflexes and return them as attention items. Does not submit."""
    if guard_new:
        breaker = guard(counterparty, disputes, as_of=as_of, spent=spent, proposed=proposed, limit=limit, k=k, window=window)
    else:
        breaker = circuit_breaker(counterparty, disputes, as_of=as_of, k=k, window=window)
        if limit is not None:
            breaker['spend'] = spend_velocity(spent, proposed, limit)
    refund = None
    if envelope is not None and signer is not None and ledger is not None:
        refund = silence(envelope, signer=signer, ledger=ledger, as_of=as_of, rail=rail)
    opened = None
    if fusion is not None:
        opened = challenge(fusion, value=value, threshold=challenge_threshold, envelope=envelope, signer=signer,
                           ledger=ledger, as_of=as_of)
    attention = [{
        'tier': 'context',
        'type': 'REFLEX',
        'error': 'DEVIATION' if breaker['paused'] else 'ON_TRACK',
        'action_needed': breaker['action'],
        'counterparty': counterparty,
        'salience': 10000 if breaker['paused'] else 0,
        'hook': 'sdk_circuit_breaker',
    }]
    if refund is not None:
        attention.append({
            'tier': 'context',
            'type': 'REFLEX',
            'error': 'SILENT',
            'action_needed': 'release_if_silent',
            'counterparty': counterparty,
            'salience': 10000,
            'hook': 'pr21.release_if_silent',
        })
    return {
        'profile': PROFILE,
        'paused': breaker['paused'],
        'breaker': breaker,
        'refund_verb': None if refund is not None else None,
        'hook': 'pr21.release_if_silent' if refund is not None else 'sdk_circuit_breaker',
        'submitted': False,
        'native_op': None if refund is None else refund['native_op'],
        'verdict': None if refund is None else refund['verdict'],
        'chain_ledger_touched': False,
        'silence': refund,
        'challenge': opened,
        'attention': attention,
        'consensus_changed': False,
        'consensus': False,
        'applied': False,
        'execution_authorized': False,
        'invalidates_transactions': False,
    }
