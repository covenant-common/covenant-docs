"""Covenant attention feed. Predictive coding plus a salience gate.

Only observations that clear ``theta_alert`` are returned for the model context.
The band under that and at or above ``theta_digest`` is one digest line each.
Everything else is a log row for ``recall``. Thresholds are caller policy.
Free-text fields are dropped before scoring. No float and no clock.
"""
import hashlib
import re

from ..errors import need
from .expectations import ERRORS, classify

PROFILE = 'covenant-attention/0.1'
WEIGHTS = {'surprise': 3500, 'value': 2500, 'deadline': 2000, 'goal': 1000, 'risk': 1000}
HORIZON = 86400 * 7
HABITUATION_WINDOW = 86400 * 7
TOKEN_PER_ITEM = 32
GOAL = {
    'ON_TRACK': 0,
    'EARLY': 2000,
    'LATE': 10000,
    'PARTIAL': 10000,
    'DEVIATION': 10000,
    'DISPUTED': 10000,
    'SILENT': 10000,
}
ACTIONS = {
    'ON_TRACK': 'covenant_discover',
    'EARLY': 'covenant_verify',
    'LATE': 'covenant_dispute',
    'PARTIAL': 'covenant_verify',
    'DEVIATION': 'covenant_dispute',
    'DISPUTED': 'covenant_settle',
    'SILENT': 'release_if_silent',
}
_ID = re.compile(r'[A-Za-z0-9_.:-]{1,128}\Z')
_KEY = re.compile(r'[0-9a-f]{64}\Z')
_DROPPED = ('text', 'note', 'content', 'delivery', 'document', 'reason', 'quoted')


def _int(value, code='ATTENTION_FIELDS'):
    need(type(value) is int and not type(value) is bool, code)
    return value


def _bps(value):
    need(type(value) is int and not type(value) is bool and 0 <= value <= 10000, 'ATTENTION_FIELDS')
    return value


def salience(event, *, repeats, as_of, value_cap):
    """Integer score in 0..10000. Habituation halves the score once per prior repeat."""
    surprise = _bps(event['surprise'])
    value = event['value']
    norm = 0 if value_cap <= 0 else min(10000, value * 10000 // value_cap)
    due = event['due']
    if as_of >= due:
        proximity = 10000
    else:
        remaining = due - as_of
        proximity = 0 if remaining >= HORIZON else (HORIZON - remaining) * 10000 // HORIZON
    goal = _bps(event['goal'])
    risk = _bps(event['risk'])
    raw = (WEIGHTS['surprise'] * surprise + WEIGHTS['value'] * norm + WEIGHTS['deadline'] * proximity
           + WEIGHTS['goal'] * goal + WEIGHTS['risk'] * risk) // 10000
    factor = 10000
    for _ in range(repeats):
        factor //= 2
        if factor < 1:
            factor = 1
            break
    return min(10000, raw * factor // 10000)


def _prepare(event, as_of, value_cap):
    need(type(event) is dict, 'ATTENTION_FIELDS')
    kind = event.get('type')
    covenant_id = event.get('covenant_id')
    counterparty = event.get('counterparty')
    need(type(covenant_id) is str and bool(_ID.fullmatch(covenant_id)), 'ATTENTION_FIELDS')
    need(type(counterparty) is str and bool(_KEY.fullmatch(counterparty)), 'ATTENTION_FIELDS')
    value = _int(event.get('value'))
    need(0 <= value <= 2**53 - 1, 'INTEGER_RANGE')
    due = _int(event.get('due'))
    need(due >= 0, 'ATTENTION_FIELDS')
    window = event['window'] if 'window' in event else 86400
    error, surprise = classify(
        kind, due=due, at=event.get('at'), as_of=as_of, partial=event.get('partial', False),
        window=window, not_before=event.get('not_before'))
    risk = event['risk'] if 'risk' in event else 0
    _bps(risk)
    observed_at = event['at'] if event.get('at') is not None else as_of
    return {
        'type': kind,
        'covenant_id': covenant_id,
        'counterparty': counterparty,
        'value': value,
        'due': due,
        'at': observed_at,
        'error': error,
        'surprise': surprise,
        'goal': GOAL[error],
        'risk': risk,
        'value_cap': value_cap,
    }


def _item(prepared, score):
    return {
        'covenant_id': prepared['covenant_id'],
        'type': prepared['type'],
        'error': prepared['error'],
        'counterparty': prepared['counterparty'],
        'salience': score,
        'action_needed': ACTIONS[prepared['error']],
        'value': prepared['value'],
        'due': prepared['due'],
    }


def attend(events, *, as_of, theta_alert=7000, theta_digest=4000, k=5, budget_tokens=160, value_cap=10000,
           habituation_window=HABITUATION_WINDOW):
    """Split observations into context, digest, and log."""
    need(type(events) is list and len(events) <= 64, 'ATTENTION_FIELDS')
    _int(as_of)
    need(as_of >= 0, 'ATTENTION_FIELDS')
    _bps(theta_alert)
    _bps(theta_digest)
    need(theta_digest <= theta_alert, 'ATTENTION_FIELDS')
    _int(k)
    need(1 <= k <= 20, 'ATTENTION_FIELDS')
    _int(budget_tokens)
    need(0 <= budget_tokens <= 100000, 'ATTENTION_FIELDS')
    _int(value_cap)
    need(value_cap >= 1, 'ATTENTION_FIELDS')
    _int(habituation_window)
    need(habituation_window >= 0, 'ATTENTION_FIELDS')
    prepared = []
    for event in events:
        leaked = [name for name in _DROPPED if name in event]
        row = _prepare(event, as_of, value_cap)
        row['dropped_free_text'] = bool(leaked)
        prepared.append(row)
    scored = []
    for index, row in enumerate(prepared):
        repeats = 0
        for older in prepared[:index]:
            if older['type'] == row['type'] and older['counterparty'] == row['counterparty']:
                if row['at'] - habituation_window < older['at'] <= row['at']:
                    repeats += 1
        score = salience(row, repeats=repeats, as_of=as_of, value_cap=value_cap)
        item = _item(row, score)
        item['repeats'] = repeats
        item['dropped_free_text'] = row['dropped_free_text']
        scored.append(item)
    ranked = sorted(enumerate(scored), key=lambda pair: (-pair[1]['salience'], pair[0]))
    context, digest, log = [], [], []
    placed = set()
    tokens = 0
    for index, item in ranked:
        if item['salience'] >= theta_alert and len(context) < k and tokens + TOKEN_PER_ITEM <= budget_tokens:
            context.append(dict(item, tier='context'))
            placed.add(index)
            tokens += TOKEN_PER_ITEM
        elif item['salience'] >= theta_digest:
            line = item['error'] + ' ' + item['covenant_id'] + ' ' + item['action_needed']
            digest.append({'tier': 'digest', 'line': line, 'salience': item['salience'],
                           'covenant_id': item['covenant_id'], 'error': item['error'],
                           'action_needed': item['action_needed'], 'counterparty': item['counterparty'],
                           'repeats': item['repeats']})
        else:
            log.append(dict(item, tier='log'))
    positives = [index for index, item in enumerate(scored) if item['salience'] >= theta_alert]
    precision = 10000 if not context else len(context) * 10000 // len(context)
    recalled = sum(1 for index in positives if index in placed)
    recall_bps = 10000 if not positives else recalled * 10000 // len(positives)
    interrupt = bool(context)
    return {
        'profile': PROFILE,
        'context': context,
        'digest': digest,
        'log': log,
        'log_count': len(log),
        'interrupt': interrupt,
        'delivery': 'INTERRUPT' if interrupt else 'NEXT_TURN',
        'tokens': tokens,
        'theta_alert': theta_alert,
        'theta_digest': theta_digest,
        'k': k,
        'budget_tokens': budget_tokens,
        'precision_bps': precision,
        'recall_bps': recall_bps,
        'consensus_changed': False,
        'consensus': False,
        'applied': False,
        'execution_authorized': False,
    }


def for_model(report):
    """Context and digest only. The log stays behind recall."""
    shown = dict(report)
    shown.pop('log', None)
    return shown


def recall(log, *, covenant_id=None, error=None, counterparty=None, tier=None):
    """Retrieve logged rows. The query is structured, not free text."""
    need(type(log) is list, 'ATTENTION_FIELDS')
    if covenant_id is not None:
        need(type(covenant_id) is str and bool(_ID.fullmatch(covenant_id)), 'ATTENTION_FIELDS')
    if error is not None:
        need(error in ERRORS, 'ATTENTION_FIELDS')
    if counterparty is not None:
        need(type(counterparty) is str and bool(_KEY.fullmatch(counterparty)), 'ATTENTION_FIELDS')
    if tier is not None:
        need(tier in ('context', 'digest', 'log'), 'ATTENTION_FIELDS')
    rows = []
    for row in log:
        if covenant_id is not None and row.get('covenant_id') != covenant_id:
            continue
        if error is not None and row.get('error') != error:
            continue
        if counterparty is not None and row.get('counterparty') != counterparty:
            continue
        if tier is not None and row.get('tier') != tier:
            continue
        rows.append({key: value for key, value in row.items() if key not in _DROPPED})
    return {'profile': PROFILE, 'rows': rows, 'count': len(rows), 'consensus_changed': False,
            'applied': False, 'execution_authorized': False}


def text_sha256(text):
    """Hash used when a caller wants a pattern id. The text is not returned."""
    need(type(text) is str, 'ATTENTION_FIELDS')
    return hashlib.sha256(text.encode('utf-8')).hexdigest()
