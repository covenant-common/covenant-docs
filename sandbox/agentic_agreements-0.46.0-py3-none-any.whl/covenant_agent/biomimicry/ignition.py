"""Ignition: when a bilateral covenant should move on chain (biomimicry spec section 3).

Escalate (BIND, then SHOW) if any of:

- the covenant is ``DISPUTED``;
- it is ``SILENT`` past the deadline plus grace;
- ``value_at_risk >= v_ign`` (owner policy) and the error is at least ``LATE``;
- the counterparty asked for an on-chain anchor.

Otherwise it stays bilateral with a periodic anchor of commitments. This is a
pure decision for the SDK. It reads no clock and no chain, prepares no
transaction and submits nothing. The chain only ever sees valid transactions,
so the rule is consensus-neutral.
"""
from ..errors import need
from .expectations import ERRORS, SURPRISE

PROFILE = 'covenant-ignition/0.1'
# "At least LATE" is ranked by the base surprise of each error class:
# LATE, DEVIATION, SILENT and DISPUTED qualify; ON_TRACK, EARLY, PARTIAL do not.
LATE_OR_WORSE = tuple(error for error in ERRORS if SURPRISE[error] >= SURPRISE['LATE'])
CHAIN_PATH = ('BIND', 'SHOW')
REASONS = ('DISPUTED', 'SILENT_PAST_GRACE', 'VALUE_AT_RISK', 'COUNTERPARTY_REQUESTED_ANCHOR')


def _int(value, *, optional=False):
    if optional and value is None:
        return None
    need(type(value) is int and value >= 0, 'IGNITION_FIELDS')
    return value


def ignite(error, *, value_at_risk=0, v_ign=None, deadline=None, grace=0, as_of=None,
           anchor_requested=False):
    """Return the escalation decision for one bilateral covenant.

    ``error`` is a prediction-error class from ``expectations.classify``.
    ``v_ign`` is the owner's value threshold; ``None`` leaves the value rule off.
    ``deadline`` and ``as_of`` are required to escalate on silence.
    """
    need(error in ERRORS, 'IGNITION_FIELDS')
    _int(value_at_risk)
    _int(v_ign, optional=True)
    _int(deadline, optional=True)
    _int(grace)
    _int(as_of, optional=True)
    need(type(anchor_requested) is bool, 'IGNITION_FIELDS')
    if error == 'SILENT':
        need(deadline is not None and as_of is not None, 'IGNITION_SILENCE_NEEDS_DEADLINE')
    reasons = []
    if error == 'DISPUTED':
        reasons.append('DISPUTED')
    if error == 'SILENT' and as_of > deadline + grace:
        reasons.append('SILENT_PAST_GRACE')
    if v_ign is not None and value_at_risk >= v_ign and error in LATE_OR_WORSE:
        reasons.append('VALUE_AT_RISK')
    if anchor_requested:
        reasons.append('COUNTERPARTY_REQUESTED_ANCHOR')
    escalate = bool(reasons)
    return {
        'profile': PROFILE,
        'error': error,
        'escalate': escalate,
        'mode': 'CHAIN' if escalate else 'BILATERAL',
        'reasons': reasons,
        'path': list(CHAIN_PATH) if escalate else [],
        'anchor': None if escalate else 'PERIODIC_COMMITMENT_ANCHOR',
        'value_rule': 'NOT_CONFIGURED' if v_ign is None else 'OWNER_POLICY',
        'v_ign': v_ign,
        'value_at_risk': value_at_risk,
        'action_needed': 'PREPARE_BIND_THEN_SHOW' if escalate else 'NONE',
        'decision_only': True,
        'submitted': False,
        'native_op': None,
        'chain_ledger_touched': False,
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
    }
