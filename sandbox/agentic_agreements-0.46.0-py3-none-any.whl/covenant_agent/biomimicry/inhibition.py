"""Lateral inhibition for discovery results (biomimicry spec section 11).

Maximal marginal relevance: at each step pick the item with the largest
``relevance_i - lambda * max_j sim(i, j_selected)``, lambda = 0.5 by default.
Relevance is the caller's own organic score scaled to basis points of the best
score in the set. Similarity is the Jaccard overlap of feature words in basis
points. Spend, bids and payments are not inputs, so organic order stays
spend-blind. Integer arithmetic only; ties keep the incoming order.
"""
from ..errors import need

PROFILE = 'covenant-lateral-inhibition/0.1'
LAMBDA_BPS = 5000
MAX_ITEMS = 256


def similarity_bps(left, right):
    """Jaccard overlap of two feature sets in basis points. Two empty sets are 0."""
    a, b = set(left), set(right)
    union = a | b
    if not union:
        return 0
    return len(a & b) * 10000 // len(union)


def _features(value):
    need(type(value) in (list, tuple) and len(value) <= 256, 'INHIBITION_ITEMS')
    for item in value:
        need(type(item) is str and 0 < len(item) <= 80, 'INHIBITION_ITEMS')
    return frozenset(value)


def mmr(items, *, lam_bps=LAMBDA_BPS, k=None):
    """Re-rank ``items`` ({id, score, features}) by maximal marginal relevance."""
    need(type(items) is list and len(items) <= MAX_ITEMS, 'INHIBITION_ITEMS')
    need(type(lam_bps) is int and 0 <= lam_bps <= 10000, 'INHIBITION_LAMBDA')
    if k is None:
        k = len(items)
    need(type(k) is int and 0 <= k <= MAX_ITEMS, 'INHIBITION_ITEMS')
    rows = []
    seen = set()
    for position, item in enumerate(items):
        need(type(item) is dict and set(item) == {'id', 'score', 'features'}, 'INHIBITION_ITEMS')
        need(type(item['id']) is str and 0 < len(item['id']) <= 200 and item['id'] not in seen, 'INHIBITION_ITEMS')
        need(type(item['score']) is int and item['score'] >= 0, 'INHIBITION_ITEMS')
        seen.add(item['id'])
        rows.append((position, item['id'], item['score'], _features(item['features'])))
    best = max((row[2] for row in rows), default=0)
    relevance = {row[1]: (row[2] * 10000 // best if best else 0) for row in rows}
    pending = list(rows)
    chosen = []
    report = []
    while pending and len(chosen) < k:
        scored = []
        for position, ident, _score, feats in pending:
            overlap = max((similarity_bps(feats, picked[3]) for picked in chosen), default=0)
            value = relevance[ident] - lam_bps * overlap // 10000
            scored.append((-value, position, ident, overlap, value))
        scored.sort()
        _neg, position, ident, overlap, value = scored[0]
        pick = next(row for row in pending if row[0] == position)
        pending.remove(pick)
        chosen.append(pick)
        report.append({'id': ident, 'score': pick[2], 'relevance_bps': relevance[ident],
                       'max_similarity_bps': overlap, 'mmr_bps': value})
    return {
        'profile': PROFILE,
        'method': 'MMR',
        'lambda_bps': lam_bps,
        'order': [row['id'] for row in report],
        'rows': report,
        'dropped': [row[1] for row in pending],
        'spend_input': False,
        'organic_ranking': 'SPEND_BLIND',
        'view': True,
        'execution_authorized': False,
    }
