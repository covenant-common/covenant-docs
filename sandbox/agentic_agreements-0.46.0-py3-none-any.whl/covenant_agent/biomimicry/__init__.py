"""SDK nervous system for bilateral covenants.

Consensus is unchanged. ``adoption`` is the record PR #21 and the economics
module can call. Threat lists never become a validity rule.
"""
from .attention import attend, for_model, recall
from .fusion import fuse
from .ignition import ignite
from .inhibition import mmr
from .reflexes import circuit_breaker, evaluate, guard, silence
from .rpe import from_receipts, replay, rpe_update
from .threats import ThreatRegistry

PROFILE = 'covenant-biomimicry-interface/0.1'

__all__ = [
    'PROFILE', 'adoption', 'attend', 'for_model', 'recall', 'fuse', 'ignite', 'mmr',
    'circuit_breaker', 'evaluate', 'guard', 'silence',
    'from_receipts', 'replay', 'rpe_update', 'ThreatRegistry',
]


def adoption():
    """Clean interface. Nothing in this record is applied to consensus."""
    return {
        'profile': PROFILE,
        'consensus_changed': False,
        'consensus': False,
        'applied': False,
        'execution_authorized': False,
        'gates_execute': False,
        'invalidates_transactions': False,
        'hooks': {
            'pr21': ['release_if_silent', 'sdk_circuit_breaker'],
            'economics': ['rpe_update'],
            'resolver': 'covenant-fusion/0.1',
        },
        'attention': {'tool': 'covenant_attention', 'recall': 'covenant_recall', 'layer': 'SDK'},
        'threat_memory': {'tool': 'covenant_threat', 'invalidates_transactions': False, 'consensus': False},
        'ignition': {'tool': 'covenant_reflex', 'argument': 'ignition', 'profile': 'covenant-ignition/0.1',
                     'submits': False, 'layer': 'SDK'},
        'lateral_inhibition': {'tool': 'covenant_find', 'argument': 'diversify',
                               'profile': 'covenant-lateral-inhibition/0.1', 'spend_input': False, 'layer': 'SDK'},
        'layer_rule': 'SDK_AND_AGENT_ONLY',
    }
