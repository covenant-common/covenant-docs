"""Reward-prediction-error reputation. Integer basis points, prior 5,000.

``R += alpha * (outcome - R)`` with a larger step down than up, and a slower
step as the settled count grows. Every seventh update forgives half the gap
back to the prior when the outcome was not a loss and the case was not referred
to a resolver. The arithmetic is deterministic so a later consensus rule can
adopt ``rpe_update`` without changing the numbers. This module does not write
chain state.
"""
from ..errors import need

PRIOR = 5000
OUTCOMES = (0, 3000, 7000, 10000)
ALPHA_PLUS = 800
ALPHA_MINUS = 1600
INTERFACE = 'economics.rpe_update'
# Locked vectors: n=0, R=5000, honoured -> 5400; default -> 4200.
VECTORS = (
    {'n': 0, 'reputation': PRIOR, 'outcome': 10000, 'rpe_bps': 5400, 'adjustment': 400},
    {'n': 0, 'reputation': PRIOR, 'outcome': 0, 'rpe_bps': 4200, 'adjustment': -800},
)


def _toward_zero(numerator, denominator):
    need(denominator > 0, 'RPE_OUTCOME')
    if numerator >= 0:
        return numerator // denominator
    return -((-numerator) // denominator)


def rpe_update(reputation, outcome, n, *, referred=False):
    """One Rescorla-Wagner step. ``n`` is the count of updates already applied."""
    need(type(reputation) is int and not type(reputation) is bool, 'RPE_OUTCOME')
    need(type(n) is int and not type(n) is bool and n >= 0, 'RPE_OUTCOME')
    need(outcome in OUTCOMES, 'RPE_OUTCOME')
    need(type(referred) is bool, 'RPE_OUTCOME')
    delta = outcome - reputation
    if delta > 0:
        base = ALPHA_PLUS
    elif delta < 0:
        base = ALPHA_MINUS
    else:
        base = 0
    adjustment = _toward_zero(base * 64 * delta, 10000 * (64 + n))
    updated = reputation + adjustment
    step = n + 1
    forgiven = False
    if step % 7 == 0 and outcome != 0 and not referred and updated < PRIOR:
        updated += (PRIOR - updated) // 2
        forgiven = True
    return {
        'rpe_bps': updated,
        'delta': delta,
        'adjustment': adjustment,
        'n': step,
        'forgiven': forgiven,
        'referred': referred,
        'outcome': outcome,
        'consensus': False,
        'rpe_consensus': False,
        'interface': INTERFACE,
        'applied': False,
        'execution_authorized': False,
    }


def replay(outcomes, *, referred=None):
    """Fold outcomes in order, starting from the prior."""
    need(type(outcomes) is list and len(outcomes) <= 10000, 'RPE_OUTCOME')
    if referred is None:
        referred = [False] * len(outcomes)
    need(type(referred) is list and len(referred) == len(outcomes), 'RPE_OUTCOME')
    reputation = PRIOR
    last = None
    for index, outcome in enumerate(outcomes):
        last = rpe_update(reputation, outcome, index, referred=referred[index])
        reputation = last['rpe_bps']
    if last is None:
        return {'rpe_bps': PRIOR, 'n': 0, 'forgiven': False, 'referred': False, 'consensus': False,
                'rpe_consensus': False, 'interface': INTERFACE, 'applied': False,
                'execution_authorized': False, 'adjustment': 0, 'delta': 0}
    return last


def from_receipts(rows):
    """Map Covenant Score rows onto the outcome scale.

    A kept receipt is honoured on time (10,000). A broken receipt is a loss (0).
    The bilateral receipt does not carry a lateness grade, so 7,000 and 3,000
    are available to ``rpe_update`` directly and are not inferred here.
    """
    ordered = sorted(rows, key=lambda row: row['cid'])
    outcomes = []
    flags = []
    for row in ordered:
        outcomes.append(10000 if row['outcome'] == 'KEPT' else 0)
        flags.append(bool(row.get('arbitrated')))
    report = replay(outcomes, referred=flags)
    report['updates'] = len(outcomes)
    return report
