"""Evidence fusion weighted by each source's track record.

Profile ``covenant-fusion/0.1``. A resolver may adopt it. Consensus validity
is unchanged. Weights are ``10**6 / sigma**2``. The n-th independent source in a
class is scaled by ``1/sqrt(n)`` in integer arithmetic. The same operator inside
one class collapses to a single source. A verified PROOF fixes the estimate and
still leaves a cross-class disagreement able to open a dispute. Disputes are
plans: this function does not submit a transaction.
"""
from ..codec import digest
from ..errors import need

PROFILE = 'covenant-fusion/0.1'
CONFLICT_LABEL = 'COVENANT-FUSION-CONFLICT-0.1'
CLASSES = ('PARTY', 'ORACLE', 'PROOF', 'TEE', 'HUMAN')
PRIOR_SIGMA2 = 250000
FLOOR = 10000
W_NUM = 1000000
K_CONFLICT = 3


def isqrt(value):
    """Integer square root. ``value`` must be positive."""
    need(type(value) is int and value > 0, 'FUSION_FIELDS')
    guess = 1 << (value.bit_length() + 1) // 2
    while True:
        nxt = (guess + value // guess) // 2
        if nxt >= guess:
            return guess
        guess = nxt


def sigma2(trials, overturns):
    """Variance from overturns over trials. No history uses the prior."""
    need(type(trials) is int and not type(trials) is bool and trials >= 0, 'FUSION_FIELDS')
    need(type(overturns) is int and not type(overturns) is bool and 0 <= overturns <= max(trials, 0), 'FUSION_FIELDS')
    if trials == 0:
        need(overturns == 0, 'FUSION_FIELDS')
        return PRIOR_SIGMA2
    return max(FLOOR, overturns * W_NUM // trials)


def _weight(sig, nth):
    base = W_NUM // sig
    if base < 1:
        base = 1
    adjusted = base * 1000 // isqrt(nth * W_NUM)
    return adjusted


def _operator(source):
    return source.get('operator') or source.get('funding') or source['source']


def fuse(sources, *, value=0, v_multi=None):
    """Fuse ``sources`` into one integer estimate and a dispute plan when classes clash."""
    need(type(sources) is list and 1 <= len(sources) <= 32, 'FUSION_FIELDS')
    need(type(value) is int and not type(value) is bool and value >= 0, 'FUSION_FIELDS')
    if v_multi is not None:
        need(type(v_multi) is int and not type(v_multi) is bool and v_multi >= 0, 'FUSION_FIELDS')
    collapsed = []
    seen = set()
    dropped = 0
    for source in sources:
        need(type(source) is dict, 'FUSION_FIELDS')
        klass = source.get('class')
        name = source.get('source')
        need(klass in CLASSES, 'FUSION_FIELDS')
        need(type(name) is str and 1 <= len(name) <= 128 and all(32 <= ord(c) <= 126 for c in name), 'FUSION_FIELDS')
        reading = source.get('x')
        need(type(reading) is int and not type(reading) is bool and 0 <= reading <= 10000, 'FUSION_FIELDS')
        verified = source.get('verified', False)
        need(type(verified) is bool, 'FUSION_FIELDS')
        operator = _operator(source)
        need(type(operator) is str and 1 <= len(operator) <= 128 and all(32 <= ord(c) <= 126 for c in operator), 'FUSION_FIELDS')
        key = (klass, operator)
        if key in seen:
            dropped += 1
            continue
        seen.add(key)
        sig = sigma2(source.get('trials', 0), source.get('overturns', 0))
        collapsed.append({
            'class': klass, 'source': name, 'operator': operator, 'x': reading,
            'sigma2': sig, 'verified': verified and klass == 'PROOF',
        })
    by_class = {}
    weighted = []
    for source in collapsed:
        bucket = by_class.setdefault(source['class'], [])
        nth = len(bucket) + 1
        weight = _weight(source['sigma2'], nth)
        row = dict(source)
        row['nth'] = nth
        row['weight'] = weight
        bucket.append(row)
        weighted.append(row)
    class_view = {}
    for klass, rows in by_class.items():
        live = [row for row in rows if row['weight'] > 0]
        need(live, 'FUSION_FIELDS')
        proofs = [row for row in live if row['verified']]
        if proofs:
            chosen = max(proofs, key=lambda row: (row['weight'], -rows.index(row)))
            estimate = chosen['x']
            sig = chosen['sigma2']
        else:
            numerator = sum(row['weight'] * row['x'] for row in live)
            denominator = sum(row['weight'] for row in live)
            estimate = numerator // denominator
            sig = min(row['sigma2'] for row in live)
        operators = {row['operator'] for row in rows}
        class_view[klass] = {'x': estimate, 'sigma2': sig, 'operators': operators}
    classes = sorted(class_view)
    pairs = []
    for left in range(len(classes)):
        for right in range(left + 1, len(classes)):
            a_name, b_name = classes[left], classes[right]
            a, b = class_view[a_name], class_view[b_name]
            difference = abs(a['x'] - b['x'])
            bound = K_CONFLICT * isqrt(a['sigma2'] + b['sigma2'])
            if difference > bound:
                shared = not a['operators'].isdisjoint(b['operators'])
                pairs.append({
                    'a': a_name, 'b': b_name, 'left': a['x'], 'right': b['x'],
                    'bound': bound, 'independent': not shared,
                })
    disagreement = bool(pairs)
    independent_conflict = any(pair['independent'] for pair in pairs)
    used = set()
    independent_classes = 0
    for klass in classes:
        operators = class_view[klass]['operators']
        if operators.isdisjoint(used):
            independent_classes += 1
            used |= operators
    proofs = [row for row in weighted if row['verified'] and row['weight'] > 0]
    if proofs:
        estimate = max(proofs, key=lambda row: row['weight'])['x']
    else:
        live = [row for row in weighted if row['weight'] > 0]
        numerator = sum(row['weight'] * row['x'] for row in live)
        denominator = sum(row['weight'] for row in live)
        estimate = numerator // denominator
    plan = None
    if independent_conflict:
        plan = {
            'reason': 'FUSION_CONFLICT',
            'evidence_hash': digest(CONFLICT_LABEL, {'pairs': pairs, 'profile': PROFILE}),
            'submitted': False,
            'pairs': pairs,
        }
    high = v_multi is not None and value >= v_multi
    auto_decision = (not disagreement) and ((not high) or independent_classes >= 2)
    public_sources = [{
        'class': row['class'], 'source': row['source'], 'operator': row['operator'],
        'x': row['x'], 'weight': row['weight'], 'sigma2': row['sigma2'], 'nth': row['nth'],
        'verified': row['verified'],
    } for row in weighted]
    return {
        'profile': PROFILE,
        'estimate': estimate,
        'sources': public_sources,
        'collapsed': dropped,
        'disagreement': disagreement,
        'auto_dispute': independent_conflict,
        'auto_decision': auto_decision,
        'independent_classes': independent_classes,
        'plan': plan,
        'consensus': False,
        'consensus_changed': False,
        'applied': False,
        'execution_authorized': False,
        'submitted': False,
    }
