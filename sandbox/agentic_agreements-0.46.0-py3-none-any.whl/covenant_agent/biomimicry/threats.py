"""Opt-in signed threat memory. Nodes may deprioritise. Validity is untouched.

An entry names one pattern hash, one public key, or one offer id, plus a class
drawn only from observed harm. It becomes active at k distinct attestations,
before expiry, and only while no appeal is recorded. Screening withholds text
whose hash is on the active list. ``invalidates_transactions`` is always false.
"""
import hashlib

from ..codec import HEX, digest, public_key, sign, signature_ok, valid_ed25519_key
from ..errors import need

PROFILE = 'covenant-threat-memory/0.1'
LABEL = 'COVENANT-THREAT-0.1'
ATTEST = 'COVENANT-THREAT-ATTEST-0.1'
APPEAL = 'COVENANT-THREAT-APPEAL-0.1'
CLASSES = ('LOSS', 'DISPUTE', 'INJECTION', 'KEY_COMPROMISE')
_OFFER = lambda value: type(value) is str and 1 <= len(value) <= 128 and all(32 <= ord(c) <= 126 for c in value)


def _hex64(value):
    need(type(value) is str and bool(HEX.fullmatch(value)), 'THREAT_FIELDS')


class ThreatRegistry:
    def __init__(self, k=2):
        need(type(k) is int and not type(k) is bool and 1 <= k <= 16, 'THREAT_QUORUM')
        self.k = k
        self.entries = {}

    def propose(self, signer, *, pattern_hash=None, subject=None, offer_id=None, klass, evidence, expiry, k=None):
        targets = [value for value in (pattern_hash, subject, offer_id) if value is not None]
        need(len(targets) == 1, 'THREAT_FIELDS')
        need(klass in CLASSES, 'THREAT_NOVELTY')
        _hex64(evidence)
        need(type(expiry) is int and not type(expiry) is bool and expiry > 0, 'THREAT_FIELDS')
        quorum = self.k if k is None else k
        need(type(quorum) is int and not type(quorum) is bool and 1 <= quorum <= 16, 'THREAT_QUORUM')
        if pattern_hash is not None:
            _hex64(pattern_hash)
        if subject is not None:
            need(type(subject) is str and valid_ed25519_key(subject), 'THREAT_FIELDS')
        if offer_id is not None:
            need(_OFFER(offer_id), 'THREAT_FIELDS')
        body = {
            'class': klass,
            'evidence': evidence,
            'expiry': expiry,
            'k': quorum,
            'offer_id': offer_id,
            'pattern_hash': pattern_hash,
            'profile': PROFILE,
            'subject': subject,
        }
        entry_id = digest(LABEL, body)
        signature = sign(signer, LABEL, body)
        entry = {
            'id': entry_id,
            'body': body,
            'proposer': public_key(signer),
            'signature': signature,
            'attestations': [],
            'appeal': None,
        }
        need(signature_ok(entry['proposer'], LABEL, body, signature), 'SIGNATURE')
        self.entries[entry_id] = entry
        return self.public(entry, as_of=0)

    def attest(self, signer, entry_id):
        entry = self._entry(entry_id)
        who = public_key(signer)
        need(all(row['attester'] != who for row in entry['attestations']), 'THREAT_FIELDS')
        body = {'entry': entry_id}
        signature = sign(signer, ATTEST, body)
        need(signature_ok(who, ATTEST, body, signature), 'SIGNATURE')
        entry['attestations'].append({'attester': who, 'signature': signature})
        return self.public(entry, as_of=0)

    def appeal(self, signer, entry_id):
        entry = self._entry(entry_id)
        need(entry['appeal'] is None, 'THREAT_FIELDS')
        body = {'entry': entry_id}
        who = public_key(signer)
        signature = sign(signer, APPEAL, body)
        need(signature_ok(who, APPEAL, body, signature), 'SIGNATURE')
        entry['appeal'] = {'appellant': who, 'signature': signature}
        return self.public(entry, as_of=0)

    def _entry(self, entry_id):
        _hex64(entry_id)
        need(entry_id in self.entries, 'THREAT_FIELDS')
        return self.entries[entry_id]

    def _attestations_ok(self, entry):
        count = 0
        seen = set()
        body = {'entry': entry['id']}
        for row in entry['attestations']:
            who = row.get('attester')
            if who in seen:
                continue
            if signature_ok(who, ATTEST, body, row.get('signature')):
                seen.add(who)
                count += 1
        return count

    def status(self, entry, as_of):
        need(type(as_of) is int and not type(as_of) is bool and as_of >= 0, 'THREAT_FIELDS')
        if not signature_ok(entry['proposer'], LABEL, entry['body'], entry['signature']):
            return 'INVALID'
        appeal = entry.get('appeal')
        if appeal is not None and signature_ok(appeal.get('appellant'), APPEAL, {'entry': entry['id']}, appeal.get('signature')):
            return 'APPEALED'
        if as_of >= entry['body']['expiry']:
            return 'EXPIRED'
        if self._attestations_ok(entry) >= entry['body']['k']:
            return 'ACTIVE'
        return 'PROPOSED'

    def public(self, entry, *, as_of):
        state = self.status(entry, as_of)
        return {
            'profile': PROFILE,
            'id': entry['id'],
            'class': entry['body']['class'],
            'pattern_hash': entry['body']['pattern_hash'],
            'subject': entry['body']['subject'],
            'offer_id': entry['body']['offer_id'],
            'evidence': entry['body']['evidence'],
            'expiry': entry['body']['expiry'],
            'k': entry['body']['k'],
            'attestations': len(entry['attestations']),
            'status': state,
            'invalidates_transactions': False,
            'consensus_changed': False,
            'applied': False,
            'execution_authorized': False,
        }

    def false_positive_bps(self):
        quorum = []
        appealed = 0
        for entry in self.entries.values():
            if self._attestations_ok(entry) < entry['body']['k']:
                continue
            quorum.append(entry)
            appeal = entry.get('appeal')
            if appeal is not None and signature_ok(appeal.get('appellant'), APPEAL, {'entry': entry['id']}, appeal.get('signature')):
                appealed += 1
        return appealed * 10000 // max(1, len(quorum))

    def screen(self, text, *, as_of):
        need(type(text) is str, 'THREAT_FIELDS')
        digest_hex = hashlib.sha256(text.encode('utf-8')).hexdigest()
        for entry in self.entries.values():
            if self.status(entry, as_of) != 'ACTIVE':
                continue
            if entry['body']['pattern_hash'] == digest_hex:
                return {
                    'blocked': True,
                    'withheld': 'THREAT_MEMORY',
                    'quoted': None,
                    'pattern_hash': digest_hex,
                    'entry': entry['id'],
                    'invalidates_transactions': False,
                    'consensus_changed': False,
                    'applied': False,
                    'execution_authorized': False,
                }
        return {
            'blocked': False,
            'withheld': None,
            'quoted': None,
            'pattern_hash': digest_hex,
            'invalidates_transactions': False,
            'consensus_changed': False,
            'applied': False,
            'execution_authorized': False,
        }

    def report(self, *, as_of):
        rows = [self.public(entry, as_of=as_of) for entry in self.entries.values()]
        rows.sort(key=lambda row: row['id'])
        return {
            'profile': PROFILE,
            'entries': rows,
            'false_positive_bps': self.false_positive_bps(),
            'invalidates_transactions': False,
            'consensus_changed': False,
            'consensus': False,
            'applied': False,
            'execution_authorized': False,
        }
