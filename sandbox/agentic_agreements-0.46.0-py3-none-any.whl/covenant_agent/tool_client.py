"""Owner-installed MCP calls with durable uncertainty and descriptor pins.

Reviewed continuation of upstream cf782ef, with an explicitly new /0.2 profile.
The old /0.1 in-memory replay and heuristic prompt-barrier claims are not
adopted. This SDK starts trusted owner-installed programs, not sandboxed remote
code. A descriptor pin is not a binary pin, authority, honesty or world truth.

The successor configuration covenant-mcp-servers/0.3 adds verb-level scopes to
pins: each pinned tool has an owner rule that derives the covenant-verb-scope/0.1
scope of a call from its exact arguments and an allow list, so a SELECT-only pin
refuses a DROP with SCOPE_VIOLATION before any process starts. Its receipts are
covenant-tool-call/0.3 and record the derived scope. ScopedToolClient may also
report each call to an owner watchdog. /0.2 configurations and receipts keep
their exact bytes and meaning.
"""
from copy import deepcopy
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import selectors
import secrets
import signal
import sqlite3
import stat
import subprocess
import threading
import time

from covenant_chain import verb_scopes

from .errors import NativeError, need

PROFILE = 'covenant-tool-call/0.2'
CONFIG_PROFILE = 'covenant-mcp-servers/0.2'
SCOPED_PROFILE = 'covenant-tool-call/0.3'
SCOPED_CONFIG_PROFILE = 'covenant-mcp-servers/0.3'
RECEIPT_LABEL = 'COVENANT-TOOL-CALL-RECEIPT-0.2'
SCHEMA_PROFILE = 'covenant-mcp-input-subset/0.1'
PROTOCOL_VERSION = '2025-06-18'
MODERN_VERSION = '2026-07-28'
# Opt-in per server: tools/call names its call agreement and request id in _meta
# (covenant_chain.call_agreements). Data for the server; it grants nothing.
AGREEMENT_META = 'io.github.covenant-common/call-agreement'
UPSTREAM = 'https://github.com/covenant-common/covenant/commit/cf782efad87321be08b5ea60dc26d3f08cc3e923'
MAX_LINE = 262144
# Keys count as nodes; a 256 KiB line cannot hold many more than this.
MAX_JSON_NODES = 65536
MAX_WIRE = 1048576
MAX_MODEL_BYTES = 16384
MAX_EVENTS = 20000
MAX_STORAGE = 64 * 1024 * 1024
DEFAULT_TIMEOUT = 20
_IDENT = re.compile(r'[A-Za-z0-9_.:/+-]{1,128}\Z')
_REQUEST = re.compile(r'[A-Za-z0-9_.:-]{8,128}\Z')
_HASH = re.compile(r'[0-9a-f]{64}\Z')
_SCHEMA_KEYS = {'type', 'properties', 'required', 'additionalProperties', 'items',
                'minItems', 'maxItems', 'minLength', 'maxLength', 'minimum', 'maximum',
                'minProperties', 'maxProperties', 'enum', 'const', 'oneOf', 'anyOf', 'allOf',
                'description', 'title', 'default', '$schema'}
_TYPES = {'object', 'array', 'string', 'number', 'integer', 'boolean', 'null'}


def _json(value):
    pending, count = [(value, 0)], 0
    while pending:
        item, depth = pending.pop(); count += 1
        need(depth <= 32 and count <= MAX_JSON_NODES, 'TOOL_JSON_COMPLEXITY')
        if item is None or type(item) is bool:
            continue
        if type(item) is int:
            need(abs(item) <= 2**53 - 1, 'TOOL_INTEGER_RANGE')
        elif type(item) is float:
            need(math.isfinite(item) and abs(item) <= 2**53 - 1, 'TOOL_NONFINITE_NUMBER')
        elif type(item) is str:
            try:
                need(len(item.encode('utf-8')) <= MAX_LINE, 'TOOL_JSON_STRING')
            except UnicodeError:
                raise ValueError('TOOL_JSON_UTF8') from None
        elif type(item) is list:
            need(len(item) <= 4096, 'TOOL_JSON_ARRAY')
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is dict:
            need(len(item) <= 1024 and all(type(k) is str and len(k) <= 256 for k in item), 'TOOL_JSON_OBJECT')
            pending.extend((key, depth + 1) for key in item)
            pending.extend((child, depth + 1) for child in item.values())
        else:
            raise ValueError('TOOL_JSON_TYPE')
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                     allow_nan=False).encode('ascii')
    need(len(raw) <= MAX_WIRE, 'TOOL_JSON_SIZE')
    return raw


def _loads(raw, maximum=MAX_LINE):
    need(type(raw) is bytes and len(raw) <= maximum, 'TOOL_RESPONSE_SIZE')
    def pairs(values):
        result = {}
        for key, value in values:
            need(key not in result, 'TOOL_DUPLICATE_KEY'); result[key] = value
        return result
    def bad(_):
        raise ValueError('TOOL_NONFINITE_NUMBER')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=bad)
    except (UnicodeError, json.JSONDecodeError, RecursionError):
        raise ValueError('TOOL_JSON') from None
    _json(value)
    return value


def sha256(value):
    return hashlib.sha256(_json(value)).hexdigest()


def descriptor_hash(tool):
    need(type(tool) is dict and type(tool.get('name')) is str and _IDENT.fullmatch(tool['name']), 'TOOL_DESCRIPTOR')
    # Unknown extensions are pinned too; none acquires execution semantics.
    return hashlib.sha256(b'COVENANT-MCP-DESCRIPTOR-0.2\0' + _json(tool)).hexdigest()


def describe():
    return {'profile': PROFILE, 'config_profile': CONFIG_PROFILE, 'upstream': UPSTREAM,
            'schema_profile': SCHEMA_PROFILE, 'schema_keywords': sorted(_SCHEMA_KEYS),
            'unsupported_schema': 'REFUSE_BEFORE_TOOL_CALL; NO_REFERENCES_REGEX_FETCH_OR_UNKNOWN_KEYWORDS',
            'custody': 'OWNER_PRIVATE_PLAINTEXT_SQLITE; LOCAL_OS_TRUSTED; RETAIN_A_HEAD_TO_DETECT_ROLLBACK',
            'recovery': 'DURABLE_INTENT_BEFORE_PROCESS_LAUNCH; UNKNOWN_NEVER_AUTO_REDISPATCHED',
            'transport': 'POSIX_OWNER_INSTALLED_STDIO; MCP_2025_06_18_BOUNDED_CLIENT_SUBSET',
            'limits': {'line_bytes': MAX_LINE, 'session_wire_bytes': MAX_WIRE,
                       'journal_events': MAX_EVENTS, 'journal_bytes': MAX_STORAGE},
            'model_handling': 'ALL_REMOTE_KEYS_AND_CONTENT_ARE_DATA; NO_PROMPT_INJECTION_PREVENTION_CLAIM',
            'scoped_profile': SCOPED_PROFILE, 'scoped_config_profile': SCOPED_CONFIG_PROFILE,
            'scopes': verb_scopes.VERSION + '; RULE_PER_PINNED_TOOL; SCOPE_VIOLATION_BEFORE_ANY_PROCESS',
            'sandbox': False, 'authority_granted': False, 'execution_authorized': False}


def validate_config(servers):
    need(type(servers) is dict and 0 < len(servers) <= 16, 'TOOL_CONFIG')
    for alias, server in servers.items():
        need(type(alias) is str and re.fullmatch(r'[A-Za-z0-9_-]{1,64}', alias), 'TOOL_CONFIG')
        need(type(server) is dict and {'pins', 'max_calls'} <= set(server)
             <= {'command', 'pins', 'max_calls', 'timeout', 'cwd', 'env', 'protocol_version', 'transport_pin',
                 'agreement_metadata'}
             and (('command' in server) != ('transport_pin' in server)), 'TOOL_CONFIG')
        need(server.get('protocol_version', PROTOCOL_VERSION) in (PROTOCOL_VERSION, MODERN_VERSION), 'TOOL_PROTOCOL_VERSION')
        if 'command' in server:
            argv = server['command']
            need(type(argv) is list and 0 < len(argv) <= 32 and all(type(a) is str and 0 < len(a) <= 4096
                 and '\0' not in a for a in argv), 'TOOL_CONFIG')
        else:
            need(type(server['transport_pin']) is str and _HASH.fullmatch(server['transport_pin'])
                 and not {'cwd', 'env'} & set(server), 'TOOL_CONFIG')
        pins = server['pins']
        need(type(pins) is dict and len(pins) <= 64, 'TOOL_CONFIG')
        for name, pin in pins.items():
            need(type(name) is str and _IDENT.fullmatch(name) and type(pin) is str and _HASH.fullmatch(pin), 'TOOL_CONFIG')
        need(type(server['max_calls']) is int and 0 <= server['max_calls'] <= 1000000, 'TOOL_CONFIG')
        need(type(server.get('agreement_metadata', False)) is bool, 'TOOL_CONFIG')
        timeout = server.get('timeout', DEFAULT_TIMEOUT)
        need(type(timeout) in (int, float) and math.isfinite(timeout) and 0 < timeout <= 30, 'TOOL_CONFIG')
        cwd = server.get('cwd')
        need(cwd is None or type(cwd) is str and os.path.isabs(cwd) and '\0' not in cwd, 'TOOL_CONFIG')
        env = server.get('env', {})
        need(type(env) is dict and len(env) <= 64 and all(type(k) is str and type(v) is str
             and 0 < len(k) <= 128 and len(v) <= 32768 and '=' not in k and '\0' not in k + v
             for k, v in env.items()), 'TOOL_CONFIG')
    _json(servers)
    return servers


def validate_scoped_config(servers):
    """covenant-mcp-servers/0.3: the exact /0.2 server fields plus scopes, one rule per pinned tool."""
    need(type(servers) is dict and all(type(server) is dict and 'scopes' in server for server in servers.values()),
         'TOOL_SCOPE_CONFIG')
    validate_config({alias: {name: value for name, value in server.items() if name != 'scopes'}
                     for alias, server in servers.items()})
    for server in servers.values():
        scopes = server['scopes']
        need(type(scopes) is dict and set(scopes) == set(server['pins']), 'TOOL_SCOPE_CONFIG')
        for entry in scopes.values():
            need(type(entry) is dict and set(entry) == {'rule', 'allow'}, 'TOOL_SCOPE_CONFIG')
            try:
                verb_scopes.validate_rule(entry['rule'])
                verb_scopes.scopes(entry['allow'])
            except ValueError:
                raise NativeError('TOOL_SCOPE_CONFIG') from None
    _json(servers)
    return servers


def check_narrowed_config(parent, child):
    """A delegated /0.3 configuration may only narrow its parent's servers, pins, budgets and scopes."""
    validate_scoped_config(parent)
    validate_scoped_config(child)
    for alias, server in child.items():
        need(alias in parent, 'SCOPE_ESCALATION')
        held = parent[alias]
        need(all(server.get(name) == held.get(name) for name in
                 ('command', 'transport_pin', 'cwd', 'env', 'protocol_version')), 'SCOPE_ESCALATION')
        need(server['max_calls'] <= held['max_calls'] and
             server.get('timeout', DEFAULT_TIMEOUT) <= held.get('timeout', DEFAULT_TIMEOUT), 'SCOPE_ESCALATION')
        for tool, pin in server['pins'].items():
            need(held['pins'].get(tool) == pin and server['scopes'][tool]['rule'] == held['scopes'][tool]['rule'],
                 'SCOPE_ESCALATION')
            try:
                verb_scopes.narrows(server['scopes'][tool]['allow'], held['scopes'][tool]['allow'])
            except ValueError:
                raise NativeError('SCOPE_ESCALATION') from None
    return {'profile': SCOPED_CONFIG_PROFILE, 'narrowed': True, 'servers': sorted(child),
            'authority_granted': False, 'execution_authorized': False}


def _admit_schema(schema, depth=0):
    need(depth <= 16 and type(schema) in (dict, bool), 'TOOL_SCHEMA_UNSUPPORTED')
    if type(schema) is bool:
        return
    need(set(schema) <= _SCHEMA_KEYS, 'TOOL_SCHEMA_UNSUPPORTED')
    if '$schema' in schema:
        need(schema['$schema'] in ('https://json-schema.org/draft/2020-12/schema',
                                  'http://json-schema.org/draft-07/schema#'), 'TOOL_SCHEMA_UNSUPPORTED')
    if 'type' in schema:
        choices = schema['type'] if type(schema['type']) is list else [schema['type']]
        need(0 < len(choices) <= 7 and all(type(t) is str and t in _TYPES for t in choices), 'TOOL_SCHEMA_UNSUPPORTED')
    for field in ('minItems', 'maxItems', 'minLength', 'maxLength', 'minProperties', 'maxProperties'):
        if field in schema:
            need(type(schema[field]) is int and 0 <= schema[field] <= 2**53 - 1, 'TOOL_SCHEMA_UNSUPPORTED')
    for field in ('minimum', 'maximum'):
        if field in schema:
            need(type(schema[field]) in (int, float) and math.isfinite(schema[field]), 'TOOL_SCHEMA_UNSUPPORTED')
    if 'required' in schema:
        need(type(schema['required']) is list and len(schema['required']) <= 128
             and all(type(x) is str for x in schema['required'])
             and len(set(schema['required'])) == len(schema['required']), 'TOOL_SCHEMA_UNSUPPORTED')
    if 'properties' in schema:
        need(type(schema['properties']) is dict and len(schema['properties']) <= 128, 'TOOL_SCHEMA_UNSUPPORTED')
        for child in schema['properties'].values():
            _admit_schema(child, depth + 1)
    for field in ('additionalProperties', 'items'):
        if field in schema:
            _admit_schema(schema[field], depth + 1)
    if 'enum' in schema:
        need(type(schema['enum']) is list and 0 < len(schema['enum']) <= 128, 'TOOL_SCHEMA_UNSUPPORTED')
    for field in ('oneOf', 'anyOf', 'allOf'):
        if field in schema:
            need(type(schema[field]) is list and 0 < len(schema[field]) <= 8, 'TOOL_SCHEMA_UNSUPPORTED')
            for child in schema[field]:
                _admit_schema(child, depth + 1)


def _schema_matches(value, schema):
    if type(schema) is bool:
        return schema
    types = {'object': type(value) is dict, 'array': type(value) is list, 'string': type(value) is str,
             'integer': type(value) is int, 'number': type(value) in (int, float),
             'boolean': type(value) is bool, 'null': value is None}
    if 'type' in schema:
        choices = schema['type'] if type(schema['type']) is list else [schema['type']]
        if not any(types[t] for t in choices):
            return False
    if 'const' in schema and _json(value) != _json(schema['const']):
        return False
    if 'enum' in schema and not any(_json(value) == _json(v) for v in schema['enum']):
        return False
    if 'oneOf' in schema and sum(_schema_matches(value, s) for s in schema['oneOf']) != 1:
        return False
    if 'anyOf' in schema and not any(_schema_matches(value, s) for s in schema['anyOf']):
        return False
    if 'allOf' in schema and not all(_schema_matches(value, s) for s in schema['allOf']):
        return False
    if type(value) is dict:
        if not schema.get('minProperties', 0) <= len(value) <= schema.get('maxProperties', 2**53):
            return False
        if any(name not in value for name in schema.get('required', [])):
            return False
        properties = schema.get('properties', {})
        return all(_schema_matches(v, properties.get(k, schema.get('additionalProperties', True))) for k, v in value.items())
    if type(value) is list:
        return schema.get('minItems', 0) <= len(value) <= schema.get('maxItems', 2**53) and all(
            _schema_matches(v, schema.get('items', True)) for v in value)
    if type(value) is str:
        return schema.get('minLength', 0) <= len(value) <= schema.get('maxLength', 2**53)
    if type(value) in (int, float):
        return schema.get('minimum', -math.inf) <= value <= schema.get('maximum', math.inf)
    return True


def _extra_meta(extra):
    """Owner-chosen request metadata; MCP reserves the modelcontextprotocol prefix."""
    if extra is None:
        return {}
    need(type(extra) is dict and 0 < len(extra) <= 4 and all(
        type(k) is str and '/' in k and 'modelcontextprotocol' not in k.split('/')[0] for k in extra), 'TOOL_RESERVED_METADATA')
    _json(extra)
    return deepcopy(extra)


class StdioServer:
    """One bounded, synchronous owner process; one absolute session deadline."""
    def __init__(self, server):
        need(os.name == 'posix', 'TOOL_PLATFORM_UNSUPPORTED')
        self.deadline = time.monotonic() + server.get('timeout', DEFAULT_TIMEOUT)
        self.ident = 0; self.buffer = b''; self.received = 0; self.process = None
        self.modern = server.get('protocol_version', PROTOCOL_VERSION) == MODERN_VERSION
        env = {'PATH': os.defpath}
        for name in ('LANG', 'LC_ALL', 'TZ', 'SYSTEMROOT'):
            if name in os.environ:
                env[name] = os.environ[name]
        env.update(server.get('env', {}))
        try:
            self.process = subprocess.Popen(server['command'], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                            stderr=subprocess.DEVNULL, cwd=server.get('cwd'), env=env,
                                            shell=False, close_fds=True, start_new_session=True, bufsize=0)
            os.set_blocking(self.process.stdin.fileno(), False)
            os.set_blocking(self.process.stdout.fileno(), False)
            if self.modern:
                result = self.request('server/discover', {})
                need(type(result.get('supportedVersions')) is list and MODERN_VERSION in result['supportedVersions']
                     and type(result.get('capabilities')) is dict, 'TOOL_DISCOVER')
            else:
                result = self.request('initialize', {'protocolVersion': PROTOCOL_VERSION, 'capabilities': {},
                    'clientInfo': {'name': 'covenant-tool-client', 'version': '0.2'}})
                need(result.get('protocolVersion') == PROTOCOL_VERSION and type(result.get('capabilities')) is dict
                     and type(result.get('serverInfo')) is dict, 'TOOL_INITIALIZE')
                self._write({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        except BaseException:
            self.close(); raise

    def _wait(self, stream, event):
        left = self.deadline - time.monotonic()
        need(left > 0, 'TOOL_TIMEOUT')
        with selectors.DefaultSelector() as selector:
            selector.register(stream, event)
            need(bool(selector.select(left)), 'TOOL_TIMEOUT')

    def _write(self, value):
        raw = _json(value) + b'\n'
        need(len(raw) <= MAX_LINE, 'TOOL_REQUEST_SIZE')
        remaining = memoryview(raw)
        while remaining:
            self._wait(self.process.stdin, selectors.EVENT_WRITE)
            try:
                size = os.write(self.process.stdin.fileno(), remaining)
            except BlockingIOError:
                continue
            except OSError:
                raise ValueError('TOOL_SERVER_CLOSED') from None
            need(size > 0, 'TOOL_SERVER_CLOSED'); remaining = remaining[size:]

    def _line(self):
        while b'\n' not in self.buffer:
            need(len(self.buffer) <= MAX_LINE, 'TOOL_RESPONSE_SIZE')
            self._wait(self.process.stdout, selectors.EVENT_READ)
            try:
                raw = os.read(self.process.stdout.fileno(), min(65536, MAX_LINE + 1 - len(self.buffer)))
            except BlockingIOError:
                continue
            need(bool(raw), 'TOOL_SERVER_CLOSED')
            self.received += len(raw)
            need(self.received <= MAX_WIRE, 'TOOL_SESSION_SIZE')
            self.buffer += raw
            need(len(self.buffer) <= MAX_LINE or b'\n' in self.buffer, 'TOOL_RESPONSE_SIZE')
        raw, self.buffer = self.buffer.split(b'\n', 1)
        return _loads(raw)

    def request(self, method, params, extra_meta=None):
        self.ident += 1; ident = self.ident
        params = deepcopy(params)
        need('_meta' not in params or not self.modern, 'TOOL_RESERVED_METADATA')
        meta = _extra_meta(extra_meta)
        if self.modern:
            meta.update({'io.modelcontextprotocol/protocolVersion': MODERN_VERSION,
                         'io.modelcontextprotocol/clientCapabilities': {},
                         'io.modelcontextprotocol/clientInfo': {'name': 'covenant-tool-client', 'version': '0.2'}})
        if meta:
            need('_meta' not in params, 'TOOL_RESERVED_METADATA')
            params['_meta'] = meta
        self._write({'jsonrpc': '2.0', 'id': ident, 'method': method, 'params': params})
        for _ in range(128):
            message = self._line()
            need(type(message) is dict and message.get('jsonrpc') == '2.0', 'TOOL_RESPONSE')
            if 'id' not in message:
                need(type(message.get('method')) is str, 'TOOL_RESPONSE')
                continue  # no sampling, elicitation, nested tools or server requests
            need(type(message['id']) is int and message['id'] == ident, 'TOOL_RESPONSE_ID')
            need(('result' in message) != ('error' in message), 'TOOL_RESPONSE')
            need('error' not in message, 'TOOL_RPC_ERROR')
            need(type(message['result']) is dict, 'TOOL_RESPONSE')
            if self.modern:
                result = message['result']
                need(result.get('resultType') == 'complete', 'TOOL_RESULT_TYPE_UNSUPPORTED')
                meta = result.get('_meta')
                info = meta.get('io.modelcontextprotocol/serverInfo') if type(meta) is dict else None
                need(type(info) is dict and type(info.get('name')) is str and
                     type(info.get('version')) is str, 'TOOL_SERVER_INFO')
            return message['result']
        raise ValueError('TOOL_NOTIFICATION_LIMIT')

    def close(self):
        if self.process is None:
            return
        process = self.process; self.process = None
        for stream in (process.stdin, process.stdout):
            if stream is not None:
                stream.close()
        # Descendants may retain pipe descriptors even after the leader exits.
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=0.2)
        except subprocess.TimeoutExpired:
            pass
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=1)


def _private_directory(directory):
    path = Path(os.path.abspath(os.fspath(directory)))
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            try:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except FileNotFoundError:
                try:
                    os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = child
        info = os.fstat(fd)
        need(info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'TOOL_PRIVATE_DIRECTORY')
        return path, fd
    except BaseException:
        os.close(fd); raise


class _Journal:
    def __init__(self, directory, config, profile=CONFIG_PROFILE):
        self.path, self.fd = _private_directory(directory)
        self.db = None; self.lock = threading.RLock(); self.storage_id = None
        try:
            try:
                fd = os.open('tool-calls.sqlite', os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_NONBLOCK,
                             0o600, dir_fd=self.fd)
                os.close(fd)
            except FileExistsError:
                pass
            self._check()
            before = os.stat('tool-calls.sqlite', dir_fd=self.fd, follow_symlinks=False)
            self.db = sqlite3.connect(self.path / 'tool-calls.sqlite', isolation_level=None,
                                      timeout=10, check_same_thread=False)
            after = os.stat('tool-calls.sqlite', dir_fd=self.fd, follow_symlinks=False)
            need((before.st_dev, before.st_ino) == (after.st_dev, after.st_ino), 'TOOL_STORAGE_CHANGED')
            self.storage_id = (after.st_dev, after.st_ino)
            self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('CREATE TABLE IF NOT EXISTS context(pin TEXT PRIMARY KEY, instance TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS events(sequence INTEGER PRIMARY KEY, previous TEXT NOT NULL, id TEXT UNIQUE NOT NULL, body BLOB NOT NULL)')
            for action in ('UPDATE', 'DELETE'):
                self.db.execute(f"CREATE TRIGGER IF NOT EXISTS immutable_{action} BEFORE {action} ON events BEGIN SELECT RAISE(ABORT,'TOOL_APPEND_ONLY'); END")
            self.db.execute('BEGIN IMMEDIATE')
            try:
                pin = sha256({'profile': profile, 'servers': config})
                row = self.db.execute('SELECT pin,instance FROM context').fetchone()
                need(row is None or row[0] == pin, 'TOOL_CONFIGURATION_CHANGED')
                if row is None:
                    self.instance = secrets.token_hex(32)
                    self.db.execute('INSERT INTO context VALUES (?,?)', (pin, self.instance))
                else:
                    need(type(row[1]) is str and _HASH.fullmatch(row[1]), 'TOOL_STORAGE_CHANGED')
                    self.instance = row[1]
                self.db.execute('COMMIT')
            except BaseException:
                self.db.execute('ROLLBACK'); raise
            os.fsync(self.fd)
            self._check()
        except BaseException:
            self.close(); raise

    def _check(self):
        info = os.fstat(self.fd); actual = os.stat(self.path, follow_symlinks=False)
        need(stat.S_ISDIR(actual.st_mode) and (info.st_dev, info.st_ino) == (actual.st_dev, actual.st_ino)
             and stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_uid == os.getuid(), 'TOOL_PRIVATE_DIRECTORY')
        for name in ('tool-calls.sqlite', 'tool-calls.sqlite-wal', 'tool-calls.sqlite-shm', 'tool-calls.sqlite-journal'):
            try:
                entry = os.stat(name, dir_fd=self.fd, follow_symlinks=False)
            except FileNotFoundError:
                need(name != 'tool-calls.sqlite', 'TOOL_STORAGE_CHANGED')
                continue
            # An auxiliary close() on a SQLite inode releases this process's
            # POSIX locks. Inspect names without opening live DB/WAL/SHM files.
            need(stat.S_ISREG(entry.st_mode) and entry.st_uid == os.getuid() and entry.st_nlink == 1
                 and stat.S_IMODE(entry.st_mode) & 0o077 == 0, 'TOOL_PRIVATE_FILE')
            if name == 'tool-calls.sqlite' and self.storage_id is not None:
                need((entry.st_dev, entry.st_ino) == self.storage_id, 'TOOL_STORAGE_CHANGED')

    def _events(self):
        self._check(); previous = '0' * 64; events = []
        for sequence, prior, ref, raw in self.db.execute('SELECT sequence,previous,id,body FROM events ORDER BY sequence'):
            body = _loads(raw, MAX_WIRE)
            need(sequence == len(events) + 1 and previous == prior and
                 ref == sha256({'sequence': sequence, 'previous': prior, 'body': body}), 'TOOL_HISTORY_CHANGED')
            events.append({'sequence': sequence, 'previous': prior, 'id': ref, 'body': body}); previous = ref
        need(len(events) <= MAX_EVENTS, 'TOOL_STORAGE_QUOTA')
        return events

    def _append(self, events, alias, request, kind, value):
        body = {'alias': alias, 'request': request, 'kind': kind, 'value': value}
        raw = _json(body)
        # Reserve completion space for every unresolved intent before launch.
        states = self._states(events)
        pending = sum(v['state'] in ('PENDING', 'DISPATCHED') for v in states.values())
        used = self.db.execute('SELECT coalesce(sum(length(body)),0) FROM events').fetchone()[0]
        reservations = pending + (kind == 'INTENT') - (kind == 'COMPLETE')
        need(len(events) < MAX_EVENTS and used + len(raw) + max(0, reservations) * MAX_WIRE <= MAX_STORAGE,
             'TOOL_STORAGE_QUOTA')
        sequence = len(events) + 1; previous = events[-1]['id'] if events else '0' * 64
        ref = sha256({'sequence': sequence, 'previous': previous, 'body': body})
        self._states([*events, {'sequence': sequence, 'previous': previous, 'id': ref, 'body': body}])
        self.db.execute('INSERT INTO events VALUES (?,?,?,?)', (sequence, previous, ref, raw))
        return ref

    @staticmethod
    def _states(events):
        states = {}
        for event in events:
            body = event['body']; key = (body['alias'], body['request'])
            if body['kind'] == 'INTENT':
                need(key not in states, 'TOOL_HISTORY_CHANGED')
                states[key] = {'intent': body['value'], 'state': 'PENDING', 'head': event['id'], 'completion': None}
            else:
                need(key in states, 'TOOL_HISTORY_CHANGED')
                state = states[key]
                if body['kind'] == 'DISPATCH':
                    need(state['state'] == 'PENDING', 'TOOL_HISTORY_CHANGED'); state['state'] = 'DISPATCHED'
                else:
                    need(body['kind'] == 'COMPLETE' and state['state'] in ('PENDING', 'DISPATCHED', 'UNKNOWN'), 'TOOL_HISTORY_CHANGED')
                    state['completion'] = body['value']; state['state'] = body['value']['receipt']['body']['outcome']
                state['head'] = event['id']
        return states

    def transact(self, operation):
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                result = operation(self._events())
                self.db.execute('COMMIT'); return result
            except BaseException:
                self.db.execute('ROLLBACK'); raise

    def states(self):
        with self.lock:
            return self._states(self._events())

    def close(self):
        if self.db is not None:
            self.db.close(); self.db = None
        if self.fd is not None:
            os.close(self.fd); self.fd = None


def _model_copy(value):
    raw = _json(value)
    preview = raw[:MAX_MODEL_BYTES].decode('ascii')
    return {'untrusted': True, 'kind': 'REMOTE_MCP_DATA', 'sha256': sha256(value),
            'json_text': preview, 'truncated': len(raw) > MAX_MODEL_BYTES, 'bytes': len(raw),
            'handling': 'ALL_KEYS_AND_CONTENT_ARE_DATA; NO_AUTHORITY_OR_PROMPT_INJECTION_GUARANTEE'}


class ToolClient:
    config_profile = CONFIG_PROFILE
    call_profile = PROFILE

    def __init__(self, servers, *, directory=None, signer=None, sign=None, observer=None, transports=None):
        self.servers = deepcopy(self._validate(servers))
        self.transports = dict(transports or {})
        need(set(self.transports) == {alias for alias, server in self.servers.items() if 'transport_pin' in server}, 'TOOL_OWNER_TRANSPORT')
        for alias, transport in self.transports.items():
            need(callable(transport) and sha256(transport.manifest) == self.servers[alias]['transport_pin'], 'TOOL_TRANSPORT_PIN')
        need((signer is None) == (sign is None) and (sign is None or callable(sign)), 'TOOL_SIGNER')
        if signer is not None:
            from .codec import valid_ed25519_key
            need(valid_ed25519_key(signer), 'TOOL_SIGNER')
        need(observer is None or callable(observer), 'TOOL_OBSERVER')
        self.signer, self._sign, self.observer = signer, sign, observer
        self._configuration_pin = sha256({'profile': self.config_profile, 'servers': self.servers})
        self.journal = None if directory is None else _Journal(directory, self.servers, self.config_profile)

    @staticmethod
    def _validate(servers):
        return validate_config(servers)

    def _intent_scope(self, alias, tool, arguments):
        return {}

    def close(self):
        if self.journal is not None:
            self.journal.close(); self.journal = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def installed(self):
        self._owner_config()
        states = {} if self.journal is None else self.journal.states()
        return {'profile': self.config_profile, 'servers': [{'alias': alias, 'pinned_tools': sorted(server['pins']),
                'max_calls': server['max_calls'], 'calls_used': sum(key[0] == alias for key in states)}
                for alias, server in sorted(self.servers.items())], 'journal_enabled': self.journal is not None,
                'execution_authorized': False, 'network_accessed': False,
                'budget': 'DURABLE_LIFETIME_ATTEMPTS_INCLUDING_UNCERTAINTY_AND_PREFLIGHT_REFUSALS'}

    @staticmethod
    def _tools(server):
        tools, names, cursors, cursor = [], set(), set(), None
        for _ in range(64):
            result = server.request('tools/list', {} if cursor is None else {'cursor': cursor})
            page = result.get('tools')
            need(type(page) is list and len(tools) + len(page) <= 512, 'TOOL_RESPONSE')
            for tool in page:
                descriptor_hash(tool)
                need(tool['name'] not in names, 'TOOL_DUPLICATE_DESCRIPTOR')
                names.add(tool['name']); tools.append(tool)
            cursor = result.get('nextCursor')
            if cursor is None:
                return tools
            need(type(cursor) is str and 0 < len(cursor) <= 256 and cursor not in cursors, 'TOOL_PAGINATION')
            cursors.add(cursor)
        raise ValueError('TOOL_PAGINATION_LIMIT')

    def discover(self, alias):
        self._owner_config()
        need(type(alias) is str and alias in self.servers, 'TOOL_SERVER_UNKNOWN')
        server = self._server(alias)
        try:
            tools = self._tools(server)
        finally:
            server.close()
        pins = self.servers[alias]['pins']
        return {'profile': self.call_profile, 'alias': alias, 'tools': [{'name': t['name'], 'descriptor_sha256': descriptor_hash(t),
                'pinned': t['name'] in pins, 'pin_matches': pins.get(t['name']) == descriptor_hash(t),
                'descriptor_for_model': _model_copy(t)} for t in tools], 'untrusted': True,
                'process_started': True, 'tool_call_sent': False, 'network_accessed': None,
                'network_status': 'OWNER_PROCESS_ACTIVITY_NOT_OBSERVED', 'execution_authorized': False}

    @staticmethod
    def _check_schema(schema, arguments):
        _json(schema); _json(arguments); _admit_schema(schema)
        need(_schema_matches(arguments, schema), 'TOOL_ARGUMENTS')

    def _target(self, alias, tool, request_id, agreement):
        self._owner_config()
        need(type(alias) is str and alias in self.servers, 'TOOL_SERVER_UNKNOWN')
        need(type(tool) is str and tool in self.servers[alias]['pins'], 'TOOL_NOT_PINNED')
        need(type(request_id) is str and _REQUEST.fullmatch(request_id), 'TOOL_REQUEST_ID')
        need(agreement is None or type(agreement) is str and _IDENT.fullmatch(agreement), 'TOOL_AGREEMENT')

    def _intent(self, alias, tool, arguments, request_id, agreement):
        self._target(alias, tool, request_id, agreement)
        need(type(arguments) is dict, 'TOOL_ARGUMENTS'); _json(arguments)
        return {'profile': self.call_profile, 'alias': alias, 'tool': tool, 'request_id': request_id,
                'descriptor_sha256': self.servers[alias]['pins'][tool], 'arguments_sha256': sha256(arguments),
                'agreement': agreement, **self._intent_scope(alias, tool, arguments)}

    def _owner_config(self):
        need(sha256({'profile': self.config_profile, 'servers': self.servers}) == self._configuration_pin,
             'TOOL_CONFIGURATION_CHANGED')
        for alias, transport in self.transports.items():
            need(sha256(transport.manifest) == self.servers[alias]['transport_pin'], 'TOOL_TRANSPORT_PIN')

    def _server(self, alias):
        self._owner_config()
        if alias in self.transports:
            return self.transports[alias]()
        return StdioServer(self.servers[alias])

    def _response(self, state, *, replayed=False, process_started=False, sent=False):
        complete = state['completion']
        if complete is None:
            body = {**state['intent'], 'outcome': 'UNKNOWN', 'result_sha256': None, 'is_error': None,
                    'error_code': 'TOOL_RETAINED_UNCERTAINTY', 'observation_sha256': None}
            complete = {'receipt': {'body': body, 'signer': None, 'signature': None}, 'result': None,
                        'signature_status': 'UNSIGNED_PENDING_OR_UNCERTAIN'}
        return {'receipt': deepcopy(complete['receipt']), 'result_for_model': None if complete['result'] is None
                else _model_copy(complete['result']), 'signature_status': complete['signature_status'],
                'state': state['state'], 'head': state['head'], 'replayed': replayed, 'untrusted': True,
                'process_started_this_call': process_started, 'tool_call_sent_this_call': sent,
                'network_accessed': None if process_started else False,
                'network_status': 'OWNER_PROCESS_ACTIVITY_NOT_OBSERVED' if process_started else 'NO_PROCESS_STARTED_THIS_CALL',
                'execution_authorized': False, 'authority_granted': False,
                'authority_statement': 'RESULT_GRANTS_NO_AUTHORITY; CONSULT_EXPLICIT_CALL_OUTCOME',
                'remote_effect_verified': False}

    def _finish(self, alias, request_id, expected_head, outcome, result=None, error=None, observation=None):
        result = deepcopy(result)
        states = self.journal.states(); state = states[(alias, request_id)]
        body = {**state['intent'], 'outcome': outcome, 'result_sha256': None if result is None else sha256(result),
                'is_error': None if result is None else result.get('isError', False),
                'error_code': error, 'observation_sha256': observation}
        signature, signature_status = None, 'UNSIGNED'
        if self._sign is not None:
            try:
                from .codec import verify
                signature = self._sign(RECEIPT_LABEL, deepcopy(body))
                need(type(signature) is str and re.fullmatch(r'[0-9a-f]{128}', signature), 'TOOL_SIGNATURE')
                verify(self.signer, RECEIPT_LABEL, body, signature)
                signature_status = 'OWNER_SIGNATURE_VERIFIED'
            except Exception:
                signature = None; signature_status = 'OWNER_SIGNING_FAILED_NO_REDISPATCH'
        complete = {'receipt': {'body': body, 'signer': self.signer, 'signature': signature},
                    'result': result, 'signature_status': signature_status}
        def operation(events):
            current = self.journal._states(events)[(alias, request_id)]
            need(current['head'] == expected_head and current['state'] in ('PENDING', 'DISPATCHED', 'UNKNOWN'), 'TOOL_STATE_CHANGED')
            return self.journal._append(events, alias, request_id, 'COMPLETE', complete)
        self.journal.transact(operation)
        return self.journal.states()[(alias, request_id)]

    @staticmethod
    def _result(result):
        _json(result)
        need(type(result) is dict and ('isError' not in result or type(result['isError']) is bool), 'TOOL_RESULT')

    def call(self, alias, tool, arguments, *, request_id, agreement=None, crash=None):
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        _json(arguments); arguments = deepcopy(arguments)
        intent = self._intent(alias, tool, arguments, request_id, agreement)
        def reserve(events):
            states = self.journal._states(events); old = states.get((alias, request_id))
            if old is not None:
                need(_json(old['intent']) == _json(intent), 'TOOL_REQUEST_REUSED'); return False
            need(sum(key[0] == alias for key in states) < self.servers[alias]['max_calls'], 'TOOL_BUDGET')
            self.journal._append(events, alias, request_id, 'INTENT', intent); return True
        new = self.journal.transact(reserve)
        if not new:
            return self._response(self.journal.states()[(alias, request_id)], replayed=True)
        if crash == 'AFTER_INTENT':
            raise RuntimeError('SYNTHETIC_CRASH_AFTER_INTENT')
        server = None; sent = False; started = False
        try:
            server = self._server(alias); started = True
            live = next((t for t in self._tools(server) if t['name'] == tool), None)
            need(live is not None, 'TOOL_MISSING')
            need(descriptor_hash(live) == intent['descriptor_sha256'], 'TOOL_PIN_CHANGED')
            self._check_schema(live.get('inputSchema'), arguments)
            if live.get('outputSchema') is not None:
                _admit_schema(live['outputSchema'])
            def mark(events):
                need(self.journal._states(events)[(alias, request_id)]['state'] == 'PENDING', 'TOOL_STATE_CHANGED')
                return self.journal._append(events, alias, request_id, 'DISPATCH', {})
            self.journal.transact(mark); sent = True
            if self.servers[alias].get('agreement_metadata'):
                # Derived from the durable intent alone, so an exact retry sends the same bytes.
                result = server.request('tools/call', {'name': tool, 'arguments': arguments},
                                        extra_meta={AGREEMENT_META: {'agreement': agreement, 'request_id': request_id}})
            else:
                result = server.request('tools/call', {'name': tool, 'arguments': arguments})
            if crash == 'AFTER_RESPONSE':
                raise RuntimeError('SYNTHETIC_CRASH_AFTER_RESPONSE')
            self._result(result)
            if live.get('outputSchema') is not None:
                self._check_schema(live['outputSchema'], result.get('structuredContent'))
            state = self.journal.states()[(alias, request_id)]
            state = self._finish(alias, request_id, state['head'], 'RECORDED', result)
            return self._response(state, process_started=started, sent=sent)
        except (ValueError, OSError, TimeoutError) as error:
            code = str(error) if re.fullmatch(r'TOOL_[A-Z0-9_]{1,72}', str(error)) else 'TOOL_LOCAL_FAILURE'
            state = self.journal.states()[(alias, request_id)]
            state = self._finish(alias, request_id, state['head'], 'UNKNOWN' if sent else 'NOT_SENT', error=code)
            if not sent:
                raise ValueError(code) from None
            return self._response(state, process_started=started, sent=sent)
        finally:
            if server is not None:
                server.close()

    def inspect(self, alias, request_id):
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        need(type(alias) is str and alias in self.servers and type(request_id) is str
             and _REQUEST.fullmatch(request_id), 'TOOL_REQUEST_MISSING')
        state = self.journal.states().get((alias, request_id))
        need(state is not None, 'TOOL_REQUEST_MISSING')
        return self._response(state)

    def retained_result(self, alias, request_id):
        """The exact stored result for owner code (call agreements), never for a model.

        It is remote data: inspect it, hash it or check a countersignature; it grants nothing.
        """
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        need(type(alias) is str and alias in self.servers and type(request_id) is str
             and _REQUEST.fullmatch(request_id), 'TOOL_REQUEST_MISSING')
        state = self.journal.states().get((alias, request_id))
        need(state is not None, 'TOOL_REQUEST_MISSING')
        complete = state['completion']
        return {'state': state['state'], 'intent': deepcopy(state['intent']),
                'receipt': None if complete is None else deepcopy(complete['receipt']),
                'result': None if complete is None else deepcopy(complete['result']),
                'untrusted': True, 'authority_granted': False}

    def pending(self, alias=None):
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        need(alias is None or type(alias) is str and alias in self.servers, 'TOOL_SERVER_UNKNOWN')
        return {'profile': self.call_profile, 'pending': [{'alias': key[0], 'request_id': key[1], 'state': state['state'],
                'head': state['head']} for key, state in self.journal.states().items()
                if (alias is None or alias == key[0]) and state['state'] in ('PENDING', 'DISPATCHED', 'UNKNOWN')],
                'automatic_retry': False, 'execution_authorized': False}

    def reconcile(self, alias, request_id):
        need(self.observer is not None, 'TOOL_OBSERVER_REQUIRED')
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        need(type(alias) is str and alias in self.servers and type(request_id) is str
             and _REQUEST.fullmatch(request_id), 'TOOL_REQUEST_MISSING')
        state = self.journal.states().get((alias, request_id))
        need(state is not None, 'TOOL_REQUEST_MISSING')
        if state['state'] not in ('PENDING', 'DISPATCHED', 'UNKNOWN'):
            return self._response(state, replayed=True)
        observation = self.observer(deepcopy(state['intent']))
        if observation is None:
            return {**self._response(state), 'owner_observer_invoked': True, 'network_accessed': None,
                    'network_status': 'OWNER_OBSERVER_ACTIVITY_NOT_OBSERVED'}
        _json(observation)
        need(type(observation) is dict and set(observation) == {'result', 'evidence_sha256'}
             and type(observation['evidence_sha256']) is str and _HASH.fullmatch(observation['evidence_sha256']), 'TOOL_OBSERVATION')
        self._result(observation['result'])
        latest = self._finish(alias, request_id, state['head'], 'OBSERVED', observation['result'],
                              observation=observation['evidence_sha256'])
        return {**self._response(latest), 'owner_observer_invoked': True, 'network_accessed': None,
                'network_status': 'OWNER_OBSERVER_ACTIVITY_NOT_OBSERVED'}

    def connector_callback(self, alias, tool, *, agreement=None):
        """Owner fixes server, tool and agreement before installing the callback."""
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        self._target(alias, tool, 'callback-check', agreement)
        def invoke(parameters):
            need(type(parameters) is dict and set(parameters) == {'arguments', 'request_id'}, 'TOOL_CALLBACK_FIELDS')
            return self.call(alias, tool, parameters['arguments'], request_id=parameters['request_id'], agreement=agreement)
        # A public adapter pin must not be an unsalted guessing oracle for a
        # low-entropy owner credential in env. The private journal instance key
        # salts the configuration commitment and survives a normal restart.
        configuration = hmac.new(bytes.fromhex(self.journal.instance), self._configuration_pin.encode('ascii'),
                                 hashlib.sha256).hexdigest()
        invoke.implementation = sha256({'profile': self.call_profile, 'configuration': configuration,
            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'alias': alias, 'tool': tool, 'agreement': agreement})
        return invoke


class ScopedToolClient(ToolClient):
    """covenant-mcp-servers/0.3 pins with verb-level scopes; receipts are covenant-tool-call/0.3.

    Before any process starts, the owner's rule for the pinned tool derives the
    concrete scope of the call from its exact arguments, and the pin's allow list
    must cover it. With a watchdog installed, a pin refusal suspends the agent and
    every new call is first admitted by the watchdog. Replays, inspection, pending
    lists and reconciliation of earlier calls stay available while suspended.
    """
    config_profile = SCOPED_CONFIG_PROFILE
    call_profile = SCOPED_PROFILE

    def __init__(self, servers, *, directory=None, signer=None, sign=None, observer=None, transports=None,
                 watchdog=None, agent=None):
        need((watchdog is None) == (agent is None) and (watchdog is None or callable(getattr(watchdog, 'admit', None))),
             'TOOL_WATCHDOG')
        if agent is not None:
            from .codec import valid_ed25519_key
            need(type(agent) is str and valid_ed25519_key(agent), 'TOOL_WATCHDOG')
        self.watchdog, self.agent = watchdog, agent
        super().__init__(servers, directory=directory, signer=signer, sign=sign, observer=observer, transports=transports)

    @staticmethod
    def _validate(servers):
        return validate_scoped_config(servers)

    def scope(self, alias, tool, arguments):
        """The concrete scope this call exercises under the owner's rule; SCOPE_UNCLASSIFIED when none."""
        self._owner_config()
        need(type(alias) is str and alias in self.servers, 'TOOL_SERVER_UNKNOWN')
        need(type(tool) is str and tool in self.servers[alias]['pins'], 'TOOL_NOT_PINNED')
        try:
            return verb_scopes.derive(self.servers[alias]['scopes'][tool]['rule'], arguments)
        except ValueError:
            raise NativeError('SCOPE_UNCLASSIFIED') from None

    def _intent_scope(self, alias, tool, arguments):
        return {'scope': self.scope(alias, tool, arguments)}

    def call(self, alias, tool, arguments, *, request_id, agreement=None, crash=None):
        need(self.journal is not None, 'TOOL_JOURNAL_REQUIRED')
        self._target(alias, tool, request_id, agreement)
        if self.journal.states().get((alias, request_id)) is None:
            scope = self.scope(alias, tool, arguments)
            if not any(verb_scopes.covers(grant, scope) for grant in self.servers[alias]['scopes'][tool]['allow']):
                if self.watchdog is not None:
                    self.watchdog.suspend(self.agent, codes=['SCOPE'], event={
                        'kind': 'TOOL_CALL', 'scope': scope, 'request': alias + '/' + request_id,
                        'destination': 'mcp:' + alias})
                raise NativeError('SCOPE_VIOLATION')
            if self.watchdog is not None:
                self.watchdog.admit(self.agent, kind='TOOL_CALL', scope=scope, request=alias + '/' + request_id,
                                    destination='mcp:' + alias)
        return super().call(alias, tool, arguments, request_id=request_id, agreement=agreement, crash=crash)

    def installed(self):
        found = super().installed()
        for row in found['servers']:
            row['scopes'] = deepcopy(self.servers[row['alias']]['scopes'])
        found['watchdog_installed'] = self.watchdog is not None
        return found


def verify_receipt(receipt, public):
    from .codec import verify
    need(type(receipt) is dict and set(receipt) == {'body', 'signer', 'signature'}, 'TOOL_RECEIPT')
    need(receipt['signer'] == public and type(receipt['signature']) is str
         and type(receipt['body']) is dict and receipt['body'].get('profile') in (PROFILE, SCOPED_PROFILE),
         'TOOL_RECEIPT_SIGNER')
    verify(public, RECEIPT_LABEL, receipt['body'], receipt['signature'])
    return {'receipt_signature_verified': True, 'outcome': receipt['body']['outcome'],
            'remote_effect_verified': False, 'authority_granted': False}
