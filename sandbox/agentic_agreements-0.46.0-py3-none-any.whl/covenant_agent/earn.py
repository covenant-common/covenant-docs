"""Reference earning agent. One command runs the demo.

    python3 -m covenant_agent.earn

The agent sells a dataset check. A buyer discovers the organic offer, pays
through pay-with-recourse, and the agent is paid on delivery. The dataset is
bundled. URLs are not fetched. Keys are demo keys, not a wallet.
It takes no arguments. An unknown argument exits 2 with usage.
"""
import argparse
import json
import sys

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from covenant_x402.recourse import pay, quote, settle_delivery
from covenant_agent.codec import public_key
from covenant_agent.score import covenant_score, erc8004_reputation, score_credential

SAMPLE = 'item,qty\napples,2\npears,\noranges,4\n'
CHAIN = 'ab' * 32


def _key(n):
    return Ed25519PrivateKey.from_private_bytes(bytes([n]) + bytes(31))


def check_dataset(text):
    """Count rows and empty cells. Cell text is data, never an instruction."""
    if type(text) is not str or text.startswith(('http://', 'https://')):
        return {'status': 'REFUSED', 'reason': 'URL_NOT_FETCHED', 'followed_as_instructions': False}
    lines = [line for line in text.split('\n') if line != '']
    if not lines:
        return {'rows': 0, 'empty_cells': 0, 'columns': 0, 'followed_as_instructions': False}
    header = lines[0].split(',')
    empty = 0
    for line in lines[1:]:
        cells = line.split(',')
        empty += sum(1 for cell in cells if cell == '')
    return {'rows': len(lines) - 1, 'columns': len(header), 'empty_cells': empty,
            'header': ','.join(header), 'followed_as_instructions': False,
            'treated_as': 'DATA'}


def summarise(text):
    """Summarise supplied text. A bare URL is not fetched."""
    if type(text) is not str or not text.strip():
        return {'status': 'REFUSED', 'reason': 'DOCUMENT', 'followed_as_instructions': False}
    if text.startswith(('http://', 'https://')) and ' ' not in text:
        return {'status': 'REFUSED', 'reason': 'URL_NOT_FETCHED', 'followed_as_instructions': False}
    words = text.split()
    return {'words': len(words), 'head': ' '.join(words[:12]), 'treated_as': 'DATA',
            'followed_as_instructions': False}


class Directory:
    """Organic results and sponsored results stay in separate lists."""

    def __init__(self):
        self.organic = []
        self.sponsored = []

    def offer(self, *, agent, title, price, unit='USDC'):
        row = {'agent': agent, 'title': title, 'price': price, 'unit': unit, 'placement': 'ORGANIC', 'rank_weight': 0}
        self.organic.append(row)
        return row

    def sponsor(self, listing, escrow_ref):
        if type(escrow_ref) is not str or len(escrow_ref) < 8:
            from covenant_agent.errors import NativeError
            raise NativeError('SPONSOR_ESCROW_REQUIRED')
        row = dict(listing)
        row['placement'] = 'SPONSORED'
        row['escrow_ref'] = escrow_ref
        row['rank_weight'] = 0
        self.sponsored.append(row)
        self.organic = [item for item in self.organic if item['title'] != listing['title']]
        return row

    def find(self, query):
        def hit(row):
            return query.lower() in row['title'].lower()
        return {'organic': [row for row in self.organic if hit(row)],
                'sponsored': [row for row in self.sponsored if hit(row)],
                'mixed_rank': False, 'rank_weight': 0, 'pagerank_is_auction': False}


def run():
    buyer, seller, judge, appeal = _key(11), _key(12), _key(13), _key(14)
    seller_pub = public_key(seller)
    directory = Directory()
    offer = directory.offer(agent=seller_pub, title='Dataset check', price=5)
    found = directory.find('dataset')
    from covenant_agent.settlement import StablecoinLedger
    ledger = StablecoinLedger({public_key(buyer): {'USDC': 20}})
    requirements = quote(price=5, pay_to='0x' + '66' * 20, judge=public_key(judge), appeal=public_key(appeal),
                         resource='Check the bundled dataset.', deadline=1_900_000_000, rail='x402')
    held = pay(requirements, buyer=buyer, seller=seller, ledger=ledger)
    report = check_dataset(SAMPLE)
    content = 'rows=%d empty=%d' % (report['rows'], report['empty_cells'])
    settled = settle_delivery(held, content, seller=seller, buyer=buyer, ledger=ledger)
    envelope = settled['envelope']
    score = covenant_score([envelope], subject=seller_pub, chain_id=CHAIN)
    credential = score_credential(score, issuer=judge)
    return {
        'demo': 'covenant-earning-agent/0.1',
        'service': 'dataset-check',
        'url_fetch': False,
        'discovered': found['organic'][0]['title'] == offer['title'],
        'organic': len(found['organic']),
        'sponsored': len(found['sponsored']),
        'mixed_rank': False,
        'dataset': report,
        'verdict': settled['verdict']['verdict'],
        'paid': ledger.balance(seller_pub, 'USDC'),
        'escrow_before_delivery': 'HELD',
        'chain_ledger_touched': False,
        'external_broadcast': False,
        'protocol_fee': 0,
        'fee_accountant': 'covenant_chain.economics',
        'refund_verb': None,
        'score_bps': score['score_bps'],
        'score_view': score['view'],
        'gates_execute': score['gates_execute'],
        'native_balance': score['native_balance'],
        'chain_id': CHAIN,
        'erc8004_posted': erc8004_reputation(score)['posted'],
        'kya': credential['kya'],
        'keys': 'DEMO_NOT_A_WALLET',
    }


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_agent.earn',
                                     description='Run the reference earning agent demo.')
    parser.parse_args(argv)
    json.dump(run(), sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write('\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
