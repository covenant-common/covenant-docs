"""Post-approval watchdog: suspend an agent's authority, never its history, when it leaves what was approved.

The owner signs a covenant-watchdog-envelope/0.1 for one agent key: the verb
scopes it may exercise (covenant-verb-scope/0.1), the destinations it may
reach, a rate (at most ``count`` admitted actions in any ``window`` seconds)
and rolling spend windows per unit, valid between two owner-clock times. Gates
report each action before it happens: ScopedToolClient for MCP calls,
AssentGate for assents and SpendLedger (through spend_observer) for spending.
An action inside the envelope is admitted and counted. An action outside it, a
scope, destination, rate or spend departure, suspends the agent in the same
transaction that records the suspension; that action and every later one are
refused with AUTHORITY_SUSPENDED until the owner signs a
covenant-watchdog-reinstatement/0.1 naming that exact suspension. A gate that
detects a departure itself, such as a tool pin refusing a verb, reports it with
suspend(). Suspension only blocks, so it needs no signature; recovery does.

Suspension removes authority, not history: receipts, journals and agreements
stay intact and verifiable, a completed tool call can still be replayed and an
uncertain one reconciled. Every envelope, suspension and reinstatement is a
leaf of an RFC 6962 journal in the same SQLite file (covenant_chain.
witness_journal). With an owner-adopted witness policy and log key the watchdog
signs C2SP checkpoints, advances an owner-retained head with each log-signed
checkpoint and asks the adopted witnesses to cosign, so a store restored from
before a suspension is refused even with every witness offline, and anyone
holding the policy can check a suspension offline with verify_proof.

The owner clock and the owner-installed gates are trusted. Event fields are
data those gates report; nothing an agent sends adopts an envelope, lifts a
suspension or changes the owner.
"""
import argparse
from contextlib import contextmanager
from copy import deepcopy
import json
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import sys
import threading
import time

from covenant_chain import verb_scopes, witness_journal
from covenant_language.safe_io import durable_sqlite

from .codec import canonical, digest, key_from_seed, loads, public_key, sign, valid_ed25519_key, verify
from .errors import NativeError, REMEDIATION, need

ENVELOPE_VERSION = 'covenant-watchdog-envelope/0.1'
REINSTATEMENT_VERSION = 'covenant-watchdog-reinstatement/0.1'
STORE_VERSION = 'covenant-watchdog/0.1'
ENTRY_VERSION = 'covenant-watchdog-entry/0.1'
PROOF_VERSION = 'covenant-watchdog-proof/0.1'
ENVELOPE_LABEL = 'COVENANT-WATCHDOG-ENVELOPE-0.1'
REINSTATEMENT_LABEL = 'COVENANT-WATCHDOG-REINSTATEMENT-0.1'
ENTRY_LABEL = 'COVENANT-WATCHDOG-ENTRY-0.1'
EVENT_LABEL = 'COVENANT-WATCHDOG-EVENT-0.1'
JOURNAL = 'journal'
KINDS = ('ASSENT', 'SPEND', 'TOOL_CALL')
DEPARTURES = ('DESTINATION', 'OWNER', 'RATE', 'SCOPE', 'SPEND')
ENVELOPE_FIELDS = 'version owner agent approval scopes destinations rate spend not_before expires nonce'
REINSTATEMENT_FIELDS = 'version owner agent suspension issued_at nonce'
MAX_INTEGER = 2**53 - 1
MAX_WINDOW = 31622400
MAX_RATE = 1000000
MAX_EVENTS = 100000
MAX_JOURNAL = 100000
HEX = re.compile(r'[0-9a-f]{64}\Z')
REQUEST = re.compile(r'[A-Za-z0-9_.:/-]{8,200}\Z')
UNIT = re.compile(r'[\x21-\x7e]{1,80}\Z')
FLAGS = {'history_kept': True, 'execution_authorized': False}


class AuthoritySuspended(NativeError):
    """The agent's authority is suspended. ``details`` names the suspension and how the owner lifts it."""

    def __init__(self, details):
        super().__init__('AUTHORITY_SUSPENDED')
        self.details = details


def _key(value, code):
    need(type(value) is str and bool(HEX.fullmatch(value)) and valid_ed25519_key(value), code)


def _text(value, code):
    need(type(value) is str and 0 < len(value) <= 256 and value.isascii() and value.isprintable(), code)


def _int(value, code, minimum=0, maximum=MAX_INTEGER):
    need(type(value) is int and minimum <= value <= maximum, code)


def _scopes(values, code, concrete=False):
    try:
        if concrete:
            verb_scopes.parse(values, concrete=True)
        else:
            verb_scopes.scopes(values)
    except ValueError:
        raise NativeError(code) from None


def validate_envelope(body):
    """An exact envelope body; it carries no authority until the owner's signature verifies."""
    code = 'WATCHDOG_ENVELOPE_FIELDS'
    need(type(body) is dict and set(body) == set(ENVELOPE_FIELDS.split()) and body['version'] == ENVELOPE_VERSION, code)
    _key(body['owner'], code)
    _key(body['agent'], code)
    need(body['owner'] != body['agent'], 'WATCHDOG_SELF_SUPERVISION')
    need(body['approval'] is None or type(body['approval']) is str and bool(HEX.fullmatch(body['approval'])), code)
    _scopes(body['scopes'], code)
    destinations = body['destinations']
    if destinations is not None:
        need(type(destinations) is list and 1 <= len(destinations) <= 64, code)
        for item in destinations:
            _text(item, code)
        need(destinations == sorted(set(destinations)), code)
    rate = body['rate']
    need(type(rate) is dict and set(rate) == {'count', 'window'}, code)
    _int(rate['count'], code, 1, MAX_RATE)
    _int(rate['window'], code, 1, MAX_WINDOW)
    spend = body['spend']
    need(type(spend) is list and len(spend) <= 16, code)
    for row in spend:
        need(type(row) is dict and set(row) == {'unit', 'amount', 'window'} and type(row['unit']) is str and
             bool(UNIT.fullmatch(row['unit'])), code)
        _int(row['amount'], code)
        _int(row['window'], code, 1, MAX_WINDOW)
    order = [(row['unit'], row['window']) for row in spend]
    need(order == sorted(set(order)), code)
    _int(body['not_before'], code)
    _int(body['expires'], code)
    need(body['not_before'] < body['expires'], code)
    need(type(body['nonce']) is str and bool(HEX.fullmatch(body['nonce'])), code)
    canonical(body)
    return body


def envelope(owner, agent, *, scopes, rate, spend=(), destinations=None, approval=None, not_before=0,
             expires=MAX_INTEGER, nonce=None):
    """An exact envelope body for the owner to sign. ``rate`` is {"count": n, "window": seconds}."""
    body = {'version': ENVELOPE_VERSION, 'owner': owner, 'agent': agent, 'approval': approval,
            'scopes': deepcopy(scopes), 'destinations': deepcopy(destinations), 'rate': deepcopy(rate),
            'spend': deepcopy(list(spend)), 'not_before': not_before, 'expires': expires,
            'nonce': secrets.token_hex(32) if nonce is None else nonce}
    return validate_envelope(body)


def envelope_id(body):
    return digest(ENVELOPE_LABEL, validate_envelope(body))


def sign_envelope(owner_private, body):
    """The owner's own action, with a key the agent host never holds."""
    validate_envelope(body)
    need(public_key(owner_private) == body['owner'], 'WATCHDOG_ENVELOPE_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(owner_private, ENVELOPE_LABEL, body)}


def verify_envelope(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'WATCHDOG_ENVELOPE_FIELDS')
    body = validate_envelope(record['body'])
    try:
        verify(body['owner'], ENVELOPE_LABEL, body, record['signature'])
    except NativeError:
        raise NativeError('WATCHDOG_ENVELOPE_SIGNATURE') from None
    return deepcopy(body)


def validate_reinstatement(body):
    code = 'WATCHDOG_REINSTATEMENT_FIELDS'
    need(type(body) is dict and set(body) == set(REINSTATEMENT_FIELDS.split()) and
         body['version'] == REINSTATEMENT_VERSION, code)
    _key(body['owner'], code)
    _key(body['agent'], code)
    need(body['owner'] != body['agent'], 'WATCHDOG_SELF_SUPERVISION')
    for name in ('suspension', 'nonce'):
        need(type(body[name]) is str and bool(HEX.fullmatch(body[name])), code)
    _int(body['issued_at'], code)
    return body


def reinstatement(owner, agent, suspension, issued_at, nonce=None):
    """An exact reinstatement body naming one suspension, for the owner to sign."""
    return validate_reinstatement({'version': REINSTATEMENT_VERSION, 'owner': owner, 'agent': agent,
                                   'suspension': suspension, 'issued_at': issued_at,
                                   'nonce': secrets.token_hex(32) if nonce is None else nonce})


def sign_reinstatement(owner_private, body):
    validate_reinstatement(body)
    need(public_key(owner_private) == body['owner'], 'WATCHDOG_REINSTATEMENT_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(owner_private, REINSTATEMENT_LABEL, body)}


def verify_reinstatement(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'WATCHDOG_REINSTATEMENT_FIELDS')
    body = validate_reinstatement(record['body'])
    try:
        verify(body['owner'], REINSTATEMENT_LABEL, body, record['signature'])
    except NativeError:
        raise NativeError('WATCHDOG_REINSTATEMENT_SIGNATURE') from None
    return deepcopy(body)


def _event(agent, kind, scope, request, destination, usage):
    code = 'WATCHDOG_EVENT_FIELDS'
    _key(agent, code)
    need(kind in KINDS, code)
    _scopes(scope, code, concrete=True)
    need(type(request) is str and bool(REQUEST.fullmatch(request)), code)
    if destination is not None:
        _text(destination, code)
    usage = {} if usage is None else usage
    need(type(usage) is dict and len(usage) <= 16, code)
    for unit, amount in usage.items():
        need(type(unit) is str and bool(UNIT.fullmatch(unit)), code)
        _int(amount, code)
    return {'kind': kind, 'scope': scope, 'request': request, 'destination': destination, 'usage': deepcopy(usage)}


def _private(path):
    path = Path(os.path.abspath(os.fspath(path)))
    try:
        parent = os.stat(path.parent)
        need(stat.S_ISDIR(parent.st_mode) and parent.st_uid == os.getuid() and
             stat.S_IMODE(parent.st_mode) & 0o022 == 0 and not path.is_symlink(), 'WATCHDOG_STORAGE')
        fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    except OSError:
        raise NativeError('WATCHDOG_STORAGE') from None
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid() and
             stat.S_IMODE(info.st_mode) & 0o077 == 0, 'WATCHDOG_STORAGE')
        return path, (info.st_dev, info.st_ino)
    finally:
        os.close(fd)


def _witness_options(value):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    need(type(value) is dict and {'policy', 'log_key'} <= set(value) <= {'policy', 'log_key', 'witnesses', 'retained', 'clock'},
         'WATCHDOG_WITNESS')
    try:
        rules = witness_journal.validate_policy(value['policy'])
    except ValueError:
        raise NativeError('WATCHDOG_WITNESS') from None
    need(isinstance(value['log_key'], Ed25519PrivateKey) and
         bytes.fromhex(public_key(value['log_key'])) == rules['log']['public'], 'WATCHDOG_WITNESS')
    witnesses = value.get('witnesses') or {}
    clock = value.get('clock') or (lambda: int(time.time()))
    need(type(witnesses) is dict and callable(clock), 'WATCHDOG_WITNESS')
    return {'policy': deepcopy(value['policy']), 'rules': rules, 'log_key': value['log_key'],
            'witnesses': dict(witnesses), 'retained': value.get('retained'), 'clock': clock}


class Watchdog:
    """Owner-installed supervision for agent keys. Tool input can neither install nor relax it."""

    def __init__(self, path, *, owner, clock, witness=None):
        _key(owner, 'WATCHDOG_OWNER')
        need(callable(clock), 'WATCHDOG_CLOCK')
        self.owner, self.clock = owner, clock
        self.witness = None if witness is None else _witness_options(witness)
        self.path, self._inode = _private(path)
        self._lock = threading.RLock()
        self.db = sqlite3.connect(self.path, isolation_level=None, timeout=15, check_same_thread=False)
        try:
            self.db.execute('PRAGMA busy_timeout=15000')
            durable_sqlite(self.db)
            with self._write() as db:
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_meta (name TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT')
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_envelopes (agent TEXT PRIMARY KEY, envelope TEXT NOT NULL, '
                           'record TEXT NOT NULL, entry TEXT NOT NULL) STRICT')
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_events (agent TEXT NOT NULL, request TEXT NOT NULL, '
                           'at INTEGER NOT NULL, body TEXT NOT NULL, PRIMARY KEY (agent, request)) STRICT')
                db.execute('CREATE INDEX IF NOT EXISTS watchdog_events_window ON watchdog_events(agent, at)')
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_spend (agent TEXT NOT NULL, request TEXT NOT NULL, '
                           'unit TEXT NOT NULL, at INTEGER NOT NULL, amount INTEGER NOT NULL, '
                           'PRIMARY KEY (agent, request, unit)) STRICT')
                db.execute('CREATE INDEX IF NOT EXISTS watchdog_spend_window ON watchdog_spend(agent, unit, at)')
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_suspensions (entry TEXT PRIMARY KEY, agent TEXT NOT NULL, '
                           'at INTEGER NOT NULL, body TEXT NOT NULL) STRICT')
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_reinstatements (suspension TEXT PRIMARY KEY, '
                           'entry TEXT NOT NULL, nonce TEXT NOT NULL UNIQUE, at INTEGER NOT NULL, record TEXT NOT NULL) STRICT')
                db.execute('CREATE TABLE IF NOT EXISTS watchdog_clock (id INTEGER PRIMARY KEY CHECK (id = 0), '
                           'high INTEGER NOT NULL) STRICT')
                for table in ('watchdog_meta', 'watchdog_suspensions', 'watchdog_reinstatements'):
                    for action in ('UPDATE', 'DELETE'):
                        db.execute(f'CREATE TRIGGER IF NOT EXISTS {table}_{action.lower()}_refused BEFORE {action} ON '
                                   f"{table} BEGIN SELECT RAISE(ABORT, 'WATCHDOG_APPEND_ONLY'); END")
                pins = [('format', STORE_VERSION), ('owner', owner)]
                if self.witness is not None:
                    pins.append(('witness', witness_journal.policy_hash(self.witness['policy'])))
                for name, value in pins:
                    db.execute('INSERT OR IGNORE INTO watchdog_meta VALUES (?, ?)', (name, value))
                    found = db.execute('SELECT value FROM watchdog_meta WHERE name=?', (name,)).fetchone()[0]
                    need(found == value, {'format': 'WATCHDOG_VERSION', 'owner': 'WATCHDOG_OWNER'}.get(name, 'WATCHDOG_WITNESS'))
                self._witnessed = db.execute("SELECT 1 FROM watchdog_meta WHERE name='witness'").fetchone() is not None
                self.journal = witness_journal.Journal(db, JOURNAL, create=True)
            if self.witness is not None:
                with self._gate():
                    pass
        except sqlite3.Error:
            self.db.close()
            raise NativeError('WATCHDOG_STORAGE') from None
        except BaseException:
            self.db.close()
            raise

    def close(self):
        self.db.close()

    @contextmanager
    def _write(self):
        try:
            info = os.stat(self.path, follow_symlinks=False)
        except OSError:
            raise NativeError('WATCHDOG_STORAGE') from None
        need((info.st_dev, info.st_ino) == self._inode and stat.S_ISREG(info.st_mode), 'WATCHDOG_STORAGE')
        try:
            self.db.execute('BEGIN IMMEDIATE')
        except sqlite3.Error:
            raise NativeError('WATCHDOG_STORAGE') from None
        try:
            yield self.db
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
        try:
            self.db.execute('COMMIT')
        except sqlite3.Error:
            raise NativeError('WATCHDOG_STORAGE') from None

    def _now(self, db):
        value = self.clock()
        need(type(value) in (int, float) and math.isfinite(value) and 0 <= value <= MAX_INTEGER, 'WATCHDOG_CLOCK')
        now = int(value)
        row = db.execute('SELECT high FROM watchdog_clock WHERE id=0').fetchone()
        need(row is None or now >= row[0], 'WATCHDOG_CLOCK_ROLLBACK')
        db.execute('INSERT INTO watchdog_clock VALUES (0, ?) ON CONFLICT(id) DO UPDATE SET high=excluded.high', (now,))
        return now

    def _entry(self, db, kind, agent, now, detail):
        size = self.journal.size()
        need(size < MAX_JOURNAL, 'WATCHDOG_STORE_FULL')
        entry = {'version': ENTRY_VERSION, 'kind': kind, 'sequence': size,
                 'previous': self.journal.entry(size - 1) if size else None, 'at': now, 'agent': agent,
                 'detail': detail}
        reference = digest(ENTRY_LABEL, entry)
        self.journal.append(reference, canonical(entry), kind)
        return reference

    @staticmethod
    def _active(db, agent):
        row = db.execute('SELECT entry, at, body FROM watchdog_suspensions s WHERE agent=? AND NOT EXISTS '
                         '(SELECT 1 FROM watchdog_reinstatements r WHERE r.suspension = s.entry) '
                         'ORDER BY at DESC LIMIT 1', (agent,)).fetchone()
        return None if row is None else {'suspension': row[0], 'at': row[1], **loads(row[2])}

    def _details(self, agent, active):
        return {'agent': agent, 'suspension': active['suspension'], 'at': active['at'], 'codes': list(active['codes']),
                'envelope': active['envelope'], 'event': deepcopy(active['event']), 'owner': self.owner,
                'owner_command': ('python -m covenant_agent.watchdog reinstate --store ' + str(self.path) +
                                  ' --owner-key-file OWNER_KEY_FILE --agent ' + agent +
                                  ' --confirm ' + active['suspension']),
                'next': 'Owner: review the journaled suspension, then reinstate with the owner key, or adopt a new envelope first.',
                **FLAGS}

    def _suspend(self, db, agent, envelope_ref, codes, event, now):
        detail = {'envelope': envelope_ref, 'codes': sorted(set(codes)), 'event': event}
        entry = self._entry(db, 'SUSPENSION', agent, now, detail)
        db.execute('INSERT INTO watchdog_suspensions VALUES (?, ?, ?, ?)',
                   (entry, agent, now, canonical(detail).decode('ascii')))
        return {'suspension': entry, 'at': now, **detail}

    def _departures(self, db, body, event, now, agent):
        codes = []
        if not any(verb_scopes.covers(grant, event['scope']) for grant in body['scopes']):
            codes.append('SCOPE')
        if body['destinations'] is not None and event['destination'] not in body['destinations']:
            codes.append('DESTINATION')
        count = db.execute('SELECT count(*) FROM watchdog_events WHERE agent=? AND at>?',
                           (agent, now - body['rate']['window'])).fetchone()[0]
        if count + 1 > body['rate']['count']:
            codes.append('RATE')
        for unit, amount in event['usage'].items():
            windows = [row for row in body['spend'] if row['unit'] == unit]
            if amount and not windows:
                codes.append('SPEND')
            for row in windows:
                used = db.execute('SELECT coalesce(sum(amount), 0) FROM watchdog_spend WHERE agent=? AND unit=? AND at>?',
                                  (agent, unit, now - row['window'])).fetchone()[0]
                if used + amount > row['amount']:
                    codes.append('SPEND')
        return sorted(set(codes))

    def admit(self, agent, *, kind, scope, request, destination=None, usage=None):
        """Admit and count one reported action, or suspend the agent and refuse it."""
        event = _event(agent, kind, scope, request, destination, usage)
        suspended = None
        with self._lock:
            self._relied()
            with self._write() as db:
                now = self._now(db)
                active = self._active(db, agent)
                if active is not None:
                    raise AuthoritySuspended(self._details(agent, active))
                row = db.execute('SELECT envelope, record FROM watchdog_envelopes WHERE agent=?', (agent,)).fetchone()
                need(row is not None, 'WATCHDOG_NO_ENVELOPE')
                body = loads(row[1])['body']
                need(body['not_before'] <= now < body['expires'], 'WATCHDOG_ENVELOPE_INACTIVE')
                reference = digest(EVENT_LABEL, {'kind': kind, 'request': request})
                raw = canonical(event).decode('ascii')
                prior = db.execute('SELECT body FROM watchdog_events WHERE agent=? AND request=?',
                                   (agent, reference)).fetchone()
                if prior is not None:
                    need(prior[0] == raw, 'WATCHDOG_REQUEST_REUSED')
                    return {'admitted': True, 'replayed': True, 'agent': agent, 'envelope': row[0], **FLAGS}
                codes = self._departures(db, body, event, now, agent)
                if codes:
                    suspended = self._suspend(db, agent, row[0], codes, event, now)
                else:
                    db.execute('DELETE FROM watchdog_events WHERE at<=?', (now - MAX_WINDOW,))
                    db.execute('DELETE FROM watchdog_spend WHERE at<=?', (now - MAX_WINDOW,))
                    need(db.execute('SELECT count(*) FROM watchdog_events').fetchone()[0] < MAX_EVENTS,
                         'WATCHDOG_STORE_FULL')
                    db.execute('INSERT INTO watchdog_events VALUES (?, ?, ?, ?)', (agent, reference, now, raw))
                    for unit, amount in event['usage'].items():
                        db.execute('INSERT INTO watchdog_spend VALUES (?, ?, ?, ?, ?)', (agent, reference, unit, now, amount))
            if suspended is not None:
                self._publish()
                raise AuthoritySuspended(self._details(agent, suspended))
        return {'admitted': True, 'replayed': False, 'agent': agent, 'envelope': row[0], 'at': now, **FLAGS}

    def suspend(self, agent, *, codes=('OWNER',), event=None):
        """Suspend now, for a departure a gate detected itself or on the owner's word. Only ever blocks."""
        _key(agent, 'WATCHDOG_EVENT_FIELDS')
        codes = sorted(set(codes)) if type(codes) in (list, tuple) else None
        need(codes is not None and 0 < len(codes) and set(codes) <= set(DEPARTURES), 'WATCHDOG_EVENT_FIELDS')
        if event is not None:
            need(type(event) is dict and set(event) <= {'kind', 'scope', 'request', 'destination', 'usage'} and
                 {'kind', 'scope', 'request'} <= set(event), 'WATCHDOG_EVENT_FIELDS')
            event = _event(agent, event['kind'], event['scope'], event['request'], event.get('destination'),
                           event.get('usage'))
        with self._lock:
            with self._write() as db:
                now = self._now(db)
                active = self._active(db, agent)
                if active is not None:
                    return {'suspended': True, 'new': False, **self._details(agent, active)}
                row = db.execute('SELECT envelope FROM watchdog_envelopes WHERE agent=?', (agent,)).fetchone()
                suspended = self._suspend(db, agent, None if row is None else row[0], codes, event, now)
            self._publish()
            return {'suspended': True, 'new': True, **self._details(agent, suspended)}

    def adopt(self, record):
        """Install the owner's signed envelope for its agent. It does not lift a suspension."""
        body = verify_envelope(record)
        need(body['owner'] == self.owner, 'WATCHDOG_OWNER')
        reference = envelope_id(body)
        with self._lock:
            with self._write() as db:
                now = self._now(db)
                row = db.execute('SELECT envelope FROM watchdog_envelopes WHERE agent=?', (body['agent'],)).fetchone()
                if row is not None and row[0] == reference:
                    return {'agent': body['agent'], 'envelope': reference, 'adopted': True, 'replayed': True, **FLAGS}
                entry = self._entry(db, 'ENVELOPE', body['agent'], now, {'envelope': reference, 'record': deepcopy(record)})
                db.execute('INSERT INTO watchdog_envelopes VALUES (?, ?, ?, ?) ON CONFLICT(agent) DO UPDATE SET '
                           'envelope=excluded.envelope, record=excluded.record, entry=excluded.entry',
                           (body['agent'], reference, canonical(record).decode('ascii'), entry))
            self._publish()
        return {'agent': body['agent'], 'envelope': reference, 'entry': entry, 'adopted': True, 'replayed': False, **FLAGS}

    def reinstate(self, record):
        """Lift exactly the named suspension with the owner's signature; the suspension stays in history."""
        body = verify_reinstatement(record)
        need(body['owner'] == self.owner, 'WATCHDOG_OWNER')
        raw = canonical(record).decode('ascii')
        with self._lock:
            with self._write() as db:
                now = self._now(db)
                done = db.execute('SELECT entry, record FROM watchdog_reinstatements WHERE suspension=?',
                                  (body['suspension'],)).fetchone()
                if done is not None:
                    need(done[1] == raw, 'WATCHDOG_NOT_SUSPENDED')
                    return {'agent': body['agent'], 'suspension': body['suspension'], 'reinstatement': done[0],
                            'reinstated': True, 'replayed': True, **FLAGS}
                active = self._active(db, body['agent'])
                need(active is not None, 'WATCHDOG_NOT_SUSPENDED')
                need(active['suspension'] == body['suspension'], 'WATCHDOG_SUSPENSION_MISMATCH')
                need(active['at'] <= body['issued_at'] <= now, 'WATCHDOG_REINSTATEMENT_TIME')
                need(db.execute('SELECT 1 FROM watchdog_reinstatements WHERE nonce=?', (body['nonce'],)).fetchone() is None,
                     'WATCHDOG_REINSTATEMENT_REUSED')
                entry = self._entry(db, 'REINSTATEMENT', body['agent'], now,
                                    {'suspension': body['suspension'], 'record': deepcopy(record)})
                db.execute('INSERT INTO watchdog_reinstatements VALUES (?, ?, ?, ?, ?)',
                           (body['suspension'], entry, body['nonce'], now, raw))
            self._publish()
        return {'agent': body['agent'], 'suspension': body['suspension'], 'reinstatement': entry, 'reinstated': True,
                'replayed': False, **FLAGS}

    def suspended(self, agent):
        """The active suspension of an agent, or None."""
        _key(agent, 'WATCHDOG_EVENT_FIELDS')
        with self._lock:
            active = self._active(self.db, agent)
        return None if active is None else self._details(agent, active)

    def spend_observer(self):
        """An observer for covenant_chain.spend_windows.SpendLedger: each reservation is admitted first."""
        def observe(event):
            return self.admit(event['recipient'], kind='SPEND', scope=event['scope'], request=event['request'],
                              destination=event['counterparty'], usage=event['usage'])
        return observe

    def status(self):
        with self._lock:
            agents = {}
            for agent, reference in self.db.execute('SELECT agent, envelope FROM watchdog_envelopes ORDER BY agent'):
                agents[agent] = {'agent': agent, 'envelope': reference}
            for (agent,) in self.db.execute('SELECT DISTINCT agent FROM watchdog_suspensions ORDER BY agent'):
                agents.setdefault(agent, {'agent': agent, 'envelope': None})
            for agent, row in agents.items():
                active = self._active(self.db, agent)
                row.update(suspended=active is not None, suspension=None if active is None else active['suspension'],
                           codes=[] if active is None else list(active['codes']))
            counts = {name: self.db.execute(f'SELECT count(*) FROM watchdog_{name}').fetchone()[0]
                      for name in ('envelopes', 'events', 'suspensions', 'reinstatements')}
            size = self.journal.size()
            return {'format': STORE_VERSION, 'owner': self.owner, 'agents': [agents[name] for name in sorted(agents)],
                    'counts': counts, 'active_suspensions': sum(row['suspended'] for row in agents.values()),
                    'journal': {'size': size, 'root': self.journal.root(size)}, 'witnessed': self._witnessed, **FLAGS}

    def backup(self, destination):
        """Online SQLite backup into a new owner-private file; never overwrites."""
        target = Path(os.path.abspath(os.fspath(destination)))
        need(target.parent.is_dir() and not os.path.lexists(target), 'WATCHDOG_BACKUP')
        os.close(os.open(target, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600))
        copy = sqlite3.connect(target)
        try:
            with self._lock:
                self.db.backup(copy)
        finally:
            copy.close()
        return str(target)

    # Witnessing: an owner-adopted policy, log key, optional transports and retained head.

    @contextmanager
    def _gate(self):
        need(self.witness is not None, 'WATCHDOG_WITNESS_REQUIRED')
        options, retained = self.witness, None
        try:
            if options['retained'] is not None:
                retained = witness_journal.RetainedHead(options['retained'], options['rules']['origin'])
            yield witness_journal.Gate(self.journal, options['policy'], log_key=options['log_key'],
                                       clock=options['clock'], witnesses=options['witnesses'], retained=retained)
        except NativeError:
            raise
        except ValueError as exc:
            # The witness journal's own stable code, as an agent-host error with remediation.
            code = str(exc)
            raise NativeError(code if re.fullmatch(r'WITNESS_[A-Z0-9_]{1,60}', code) else 'WATCHDOG_WITNESS') from exc
        finally:
            if retained is not None:
                retained.close()

    def _relied(self):
        """Refuse every admission while the journal shows a rollback, fork or split view."""
        if self.witness is None:
            need(not self._witnessed, 'WATCHDOG_WITNESS_REQUIRED')
            return
        with self._gate() as gate:
            verdict = gate.verdict()
            if verdict['status'] == 'REFUSED':
                for value in verdict['evidence']:
                    gate.journal.store_evidence(value)
        need(verdict['status'] != 'REFUSED', 'WATCHDOG_JOURNAL_REFUSED')

    def _publish(self):
        """After a journal change: sign a checkpoint, advance the retained head, ask the witnesses."""
        if self.witness is None:
            return
        try:
            with self._gate() as gate:
                note = gate.publish()
                size = self.journal.size()
                if gate.retained is not None:
                    gate.retained.advance(size, self.journal.root(size), note)
                if gate.witnesses:
                    gate.collect()
        except (ValueError, sqlite3.Error, OSError):
            # The leaf is already committed; the next publish checkpoints it, and admissions re-check the verdict.
            return

    def checkpoint(self):
        with self._lock, self._gate() as gate:
            return gate.publish()

    def witness_round(self):
        """One add-checkpoint round to each installed witness, then the verdict."""
        with self._lock, self._gate() as gate:
            gate.publish()
            return {'witnesses': gate.collect(), 'verdict': gate.verdict(), **FLAGS}

    def proof(self, entry):
        """A journaled envelope, suspension or reinstatement with its inclusion proof, for offline checking."""
        need(type(entry) is str and bool(HEX.fullmatch(entry)), 'WATCHDOG_PROOF_ENTRY')
        with self._lock:
            row = self.db.execute(f'SELECT idx FROM {JOURNAL}_leaves WHERE entry=?', (entry,)).fetchone()
            need(row is not None, 'WATCHDOG_PROOF_ENTRY')
            with self._gate() as gate:
                bundle = gate.proof(row[0])
            return {'version': PROOF_VERSION, 'entry': loads(self.journal.body(row[0])), 'proof': bundle}

    def extension(self, old):
        with self._lock, self._gate() as gate:
            gate.check()
            return gate.extension(old)

    def evidence(self):
        with self._lock:
            return self.journal.evidence()


def verify_proof(bundle, policy_body, now):
    """Keyless and offline: VERIFIED only for an included entry under a fresh quorum of the adopted witnesses."""
    need(type(bundle) is dict and set(bundle) == {'version', 'entry', 'proof'} and bundle['version'] == PROOF_VERSION and
         type(bundle['entry']) is dict and type(bundle['proof']) is dict, 'WATCHDOG_PROOF_ENTRY')
    entry = bundle['entry']
    need(entry.get('version') == ENTRY_VERSION and entry.get('kind') in ('ENVELOPE', 'REINSTATEMENT', 'SUSPENSION'),
         'WATCHDOG_PROOF_ENTRY')
    found = {'kind': entry['kind'], 'agent': entry.get('agent'), 'at': entry.get('at'),
             'detail': deepcopy(entry.get('detail')), 'global_latest': 'UNKNOWN', **FLAGS}
    if bundle['proof'].get('entry') != digest(ENTRY_LABEL, entry):
        # The shown entry is not the journaled leaf: a changed record, never a suspension to rely on.
        return {'status': 'REFUSED', 'codes': ['WATCHDOG_PROOF_ENTRY'], 'included': False, **found}
    try:
        result = witness_journal.verify_proof(bundle['proof'], policy_body, now)
    except ValueError:
        raise NativeError('WATCHDOG_PROOF_ENTRY') from None
    return {'status': result['status'], 'codes': result['codes'], 'included': result['included'], **found}


def prometheus(status):
    lines = ['# HELP covenant_watchdog_active_suspensions Agents whose authority is suspended.',
             '# TYPE covenant_watchdog_active_suspensions gauge',
             'covenant_watchdog_active_suspensions %d' % status['active_suspensions'],
             '# HELP covenant_watchdog_records Watchdog records by kind.', '# TYPE covenant_watchdog_records gauge']
    for name in ('envelopes', 'events', 'suspensions', 'reinstatements'):
        lines.append('covenant_watchdog_records{kind="%s"} %d' % (name, status['counts'][name]))
    lines += ['# HELP covenant_watchdog_journal_size Leaves in the watchdog journal.',
              '# TYPE covenant_watchdog_journal_size gauge', 'covenant_watchdog_journal_size %d' % status['journal']['size']]
    return '\n'.join(lines) + '\n'


def describe():
    return {'envelope': ENVELOPE_VERSION, 'reinstatement': REINSTATEMENT_VERSION, 'store': STORE_VERSION,
            'departures': list(DEPARTURES), 'reporting_gates': ['ScopedToolClient', 'AssentGate', 'SpendLedger'],
            'suspension': 'AUTHORITY_ONLY; HISTORY_KEPT; SAME_TRANSACTION_AS_THE_JOURNAL_LEAF',
            'recovery': 'OWNER_SIGNED_REINSTATEMENT_OF_THE_EXACT_SUSPENSION',
            'journal': 'RFC6962_WITH_OPTIONAL_C2SP_CHECKPOINTS_COSIGNATURES_AND_RETAINED_HEAD',
            'clock': 'OWNER_SUPPLIED_NEVER_BACKWARDS', 'limits': {'events': MAX_EVENTS, 'journal_leaves': MAX_JOURNAL},
            **FLAGS}


def _read_private(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0
             and info.st_size <= limit, 'WATCHDOG_KEY_FILE')
        return os.read(fd, limit + 1)
    finally:
        os.close(fd)


def _key_file(path):
    raw = _read_private(path, 66).strip()
    need(len(raw) == 64 and all(c in b'0123456789abcdef' for c in raw), 'WATCHDOG_KEY_FILE')
    return key_from_seed(raw.decode('ascii'))


def _json_file(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        need(stat.S_ISREG(os.fstat(fd).st_mode), 'WATCHDOG_ENVELOPE_FIELDS')
        raw = os.read(fd, 262145)
    finally:
        os.close(fd)
    need(len(raw) <= 262144, 'SIZE_LIMIT')
    return loads(raw)


def _write_new(path, value):
    from covenant_language.safe_io import atomic_write
    target = Path(path).expanduser().absolute()
    atomic_write(target, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode('ascii'), mode=0o600, exclusive=True)
    return str(target)


def _window(text, code):
    amount, separator, seconds = text.partition('/')
    need(separator == '/' and amount.isdigit() and seconds.isdigit(), code)
    return int(amount), int(seconds)


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_agent.watchdog',
        description='Owner tools for the post-approval watchdog: sign an envelope, adopt it, inspect, back up, reinstate.')
    commands = parser.add_subparsers(dest='command', required=True)
    make = commands.add_parser('envelope', help='Sign a new envelope for one agent with the owner key file.')
    make.add_argument('--owner-key-file', required=True, help='Owner Ed25519 seed hex file, mode 0600. Never printed.')
    make.add_argument('--agent', required=True, help='Agent public key the envelope supervises.')
    make.add_argument('--scope', action='append', required=True, help='Verb scope namespace:resource:VERB; repeatable.')
    make.add_argument('--destination', action='append', help='Allowed destination; repeatable. Omit for any destination.')
    make.add_argument('--rate', required=True, help='COUNT/SECONDS: most admitted actions in any window.')
    make.add_argument('--spend', action='append', default=[], help='UNIT=AMOUNT/SECONDS rolling spend window; repeatable.')
    make.add_argument('--approval', help='Optional SHA-256 of the approval this envelope covers.')
    make.add_argument('--not-before', type=int, default=0)
    make.add_argument('--expires', type=int, default=MAX_INTEGER)
    make.add_argument('--out', required=True, help='New envelope file (created 0600, never overwritten).')
    adopt = commands.add_parser('adopt', help='Adopt a signed envelope into the watchdog store.')
    adopt.add_argument('--store', required=True)
    adopt.add_argument('--owner', required=True, help='Owner public key pinned in the store.')
    adopt.add_argument('--envelope', required=True)
    lift = commands.add_parser('reinstate', help='Lift one named suspension with the owner key.')
    lift.add_argument('--store', required=True)
    lift.add_argument('--owner-key-file', required=True, help='Owner Ed25519 seed hex file, mode 0600. Never printed.')
    lift.add_argument('--agent', required=True)
    lift.add_argument('--confirm', required=True, help='The suspension entry id you reviewed with inspect.')
    inspect = commands.add_parser('inspect', help='Print watchdog status as JSON, or Prometheus text.')
    inspect.add_argument('--store', required=True)
    inspect.add_argument('--owner', required=True)
    inspect.add_argument('--prometheus', action='store_true')
    backup = commands.add_parser('backup', help='Copy the watchdog store into a new owner-private file.')
    backup.add_argument('--store', required=True)
    backup.add_argument('--owner', required=True)
    backup.add_argument('--out', required=True)
    args = parser.parse_args(argv)
    clock = lambda: int(time.time())
    store = None
    try:
        if args.command == 'envelope':
            owner = _key_file(args.owner_key_file)
            count, seconds = _window(args.rate, 'WATCHDOG_ENVELOPE_FIELDS')
            spend = []
            for item in args.spend:
                unit, separator, rest = item.partition('=')
                need(separator == '=', 'WATCHDOG_ENVELOPE_FIELDS')
                amount, window = _window(rest, 'WATCHDOG_ENVELOPE_FIELDS')
                spend.append({'unit': unit, 'amount': amount, 'window': window})
            body = envelope(public_key(owner), args.agent, scopes=sorted(set(args.scope)),
                            rate={'count': count, 'window': seconds}, spend=sorted(spend, key=lambda r: (r['unit'], r['window'])),
                            destinations=None if not args.destination else sorted(set(args.destination)),
                            approval=args.approval, not_before=args.not_before, expires=args.expires)
            record = sign_envelope(owner, body)
            result = {'format': ENVELOPE_VERSION, 'envelope': envelope_id(body), 'path': _write_new(args.out, record),
                      'agent': body['agent'], 'private_keys_in_output': False, **FLAGS}
        elif args.command == 'reinstate':
            owner = _key_file(args.owner_key_file)
            store = Watchdog(args.store, owner=public_key(owner), clock=clock)
            body = reinstatement(public_key(owner), args.agent, args.confirm, clock())
            result = {**store.reinstate(sign_reinstatement(owner, body)), 'private_keys_in_output': False}
        else:
            store = Watchdog(args.store, owner=args.owner, clock=clock)
            if args.command == 'adopt':
                result = store.adopt(_json_file(args.envelope))
            elif args.command == 'inspect':
                if args.prometheus:
                    sys.stdout.write(prometheus(store.status()))
                    return 0
                result = store.status()
            else:
                result = {'format': STORE_VERSION, 'backup': store.backup(args.out), **FLAGS}
    except (NativeError, ValueError, OSError, sqlite3.Error) as exc:
        code = exc.code if isinstance(exc, NativeError) else str(exc)
        if not re.fullmatch(r'[A-Z][A-Z0-9_]{0,100}', code or ''):
            code = 'WATCHDOG_OWNER_TOOL_FAILED'
        print(json.dumps({'error': code, 'remediation': REMEDIATION.get(code, 'Correct the named input and retry.'),
                          **FLAGS}, sort_keys=True), file=sys.stderr)
        return 1
    finally:
        if store is not None:
            store.close()
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
