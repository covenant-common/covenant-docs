"""Draft a covenant from a template or one sentence.

The terms are a canonical object. Their hash is domain-separated with the label
``COVENANT-DRAFT-TERMS-0.1``. Plain English and markdown both carry that hash,
so a rendering can be checked against the terms without trusting the prose.

Nothing in this module calls a model or a network. ``draft`` invokes ``llm``
only when the caller passes that hook, and the hook cannot overwrite a field
the deterministic parse already filled. A draft does not sign, escrow, or
submit anything.

The record of an agreement is not this profile. ``compiled`` projects the
same terms onto ``agreement_builder.simple``, ``external_drafts.pack``, and,
when both parties are verification keys, ``human_agreements.prepare`` and
``contract_studio.draft``. ``compiled.parallel_record`` is false. The local
status on the document is negotiation metadata, not a ledger state.
"""
import copy
import re
from datetime import date, datetime, timedelta, timezone

from .codec import digest
from .errors import NativeError, need
from .pii import lint_text

PROFILE = 'covenant-draft/0.1'
LABEL = 'COVENANT-DRAFT-TERMS-0.1'
UNITS = ('USDC', 'USDT', 'DAI', 'USDG', 'GBP')
RAILS = ('x402', 'ap2')
TIMEOUTS = ('RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION')
EFFECTS = ('TRANSFER', 'CONSUME', 'AUTHORIZE')
LATE = ('refund', 'penalty', 'pay')
ORDER = (
    'payment-on-delivery',
    'milestone-escrow',
    'sla-penalties',
    'data-licence',
    'api-usage',
    'agent-subcontract',
    'agent-team',
    'bounty',
    'revenue-share',
    'confidentiality',
    'ad-campaign',
    'recurring-service',
)
WEEKDAYS = ('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday')
VAGUE = {'tbd', 'something', 'stuff', 'etc', 'reasonable', 'soon', 'later', 'various', 'miscellaneous', 'unlimited'}
HEX_KEY = re.compile(r'[0-9a-f]{64}\Z')
SCENARIOS = ('delivered', 'late', 'disputed', 'referee_silent')

TITLES = {
    'payment-on-delivery': ('Payment on delivery', 'One sum is escrowed and paid when the work is delivered. A miss follows the late rule.'),
    'milestone-escrow': ('Milestone escrow', 'The sum is split across named milestones. Each one is released when it is delivered.'),
    'sla-penalties': ('Service level with penalties', 'A fee is paid for a service target. A miss reduces the fee by an agreed fraction.'),
    'data-licence': ('Data licence', 'A fee buys use of a named dataset until a deadline. The licence ends then.'),
    'api-usage': ('API usage', 'A prepayment covers a named number of calls until a deadline.'),
    'agent-subcontract': ('Agent subcontract', 'A prime pays another agent for a named piece of work. The child can be funded by a parent escrow.'),
    'agent-team': ('Hire a team', 'One budget hires several agents. Each child is capped, and an unnamed child is not paid.'),
    'bounty': ('Bounty', 'A sponsor posts a sum. The first accepted claimant is paid, otherwise the sponsor is refunded.'),
    'revenue-share': ('Revenue share, mudarabah-style', 'One party provides capital and the other does the work. Profit is split by an agreed ratio. Loss is borne by the capital provider. There is no guaranteed return.'),
    'confidentiality': ('Confidentiality', 'One party discloses named information. The other keeps it confidential until a deadline. Monetary liability is capped.'),
    'ad-campaign': ('Ad campaign', 'A budget pays for a named campaign measured in impressions.'),
    'recurring-service': ('Recurring service', 'The same sum is due each period. The escrow holds the total.'),
}

_BASE = (
    ('payer', 'string', False, 'Payer', 'Who pays or provides the capital.'),
    ('payee', 'string', True, None, 'Who is paid or does the work.'),
    ('referee', 'string', False, None, 'Who decides a dispute. Empty until the parties name one.'),
    ('subject', 'string', True, None, 'The work, data, or duty, in a few words.'),
    ('quantity', 'integer', True, None, 'The escrowed sum, in the smallest whole unit.'),
    ('unit', 'unit', False, 'USDC', 'Stablecoin code.'),
    ('deadline', 'timestamp', False, None, 'Unix time, UTC, when the duty ends.'),
    ('deadline_text', 'string', False, None, 'The deadline as the parties wrote it.'),
    ('challenge_window', 'integer', False, 86400, 'Seconds in which a delivery can be challenged.'),
    ('rail', 'rail', False, 'x402', 'Stablecoin rail.'),
    ('timeout', 'timeout', False, 'RELEASE_IF_UNDECIDED', 'What happens if the referee stays silent.'),
    ('effect', 'effect', False, 'TRANSFER', 'TRANSFER, CONSUME, or AUTHORIZE.'),
    ('late_policy', 'late', False, 'refund', 'refund, penalty, or pay when the duty is late.'),
    ('penalty_bps', 'bps', False, 0, 'Penalty in basis points of the sum. 10000 is the whole sum.'),
    ('cap', 'integer', False, None, 'Most that can be owed. Defaults to the sum.'),
)


def _spec(*rows):
    return [{'name': name, 'type': kind, 'required': required, 'default': default, 'help': help_}
            for name, kind, required, default, help_ in rows]


def _with(overrides, extra=()):
    rows = []
    for name, kind, required, default, help_ in _BASE:
        if name in overrides:
            required, default = overrides[name]
        rows.append((name, kind, required, default, help_))
    rows.extend(extra)
    return _spec(*rows)


SPECS = {
    'payment-on-delivery': _with({}, (
        ('evidence', 'evidence', False, None, 'Named proof: photo, gps, temperature.'),
        ('refund_bps', 'bps', False, None, 'Partial refund in basis points. 5000 is half.'),
        ('unknown_default', 'hold', False, None, 'HOLD when a named reading is missing.'),
    )),
    'milestone-escrow': _with({}, (
        ('schedule', 'schedule', False, None, 'Milestones as name and amount. Two equal parts are used when this is omitted.'),
    )),
    'sla-penalties': _with({'late_policy': (False, 'penalty'), 'penalty_bps': (False, 500)}, (
        ('measure', 'integer', False, 9900, 'Uptime target in basis points. 9900 is 99 percent.'),
    )),
    'data-licence': _with({}),
    'api-usage': _with({}, (
        ('measure', 'integer', False, 10000, 'Calls covered by the prepayment.'),
    )),
    'agent-subcontract': _with({}),
    'agent-team': _with({'payee': (False, None), 'unit': (False, 'credits'), 'quantity': (False, None)}, (
        ('team_size', 'integer', False, None, 'How many agents to hire.'),
        ('per_agent', 'integer', False, None, 'Most one agent may be paid, in the same unit as the budget.'),
    )),
    'bounty': _with({'payee': (False, 'Claimant')}),
    'revenue-share': _with({'quantity': (True, None)}, (
        ('manager_bps', 'bps', False, 3000, 'Manager share of profit, in basis points.'),
        ('capital_bps', 'bps', False, 7000, 'Capital-provider share of profit, in basis points.'),
        ('illustrative_result', 'signed', False, 0, 'Profit above zero, or a loss below zero, used only by the simulator.'),
    )),
    'confidentiality': _with({
        'payer': (False, 'Discloser'),
        'payee': (False, 'Recipient'),
        'quantity': (False, 0),
        'cap': (False, 0),
        'late_policy': (False, 'penalty'),
        'penalty_bps': (False, 10000),
    }),
    'ad-campaign': _with({}, (
        ('measure', 'integer', False, 1000, 'Impressions the budget buys.'),
    )),
    'recurring-service': _with({'quantity': (False, None)}, (
        ('per_period', 'integer', False, None, 'Sum due each period. Defaults to quantity, which is then the per-period sum.'),
        ('periods', 'integer', False, 3, 'How many periods are escrowed.'),
        ('schedule', 'schedule', False, None, 'One row per period. Built from per_period when omitted.'),
    )),
}

_COUNT_WORDS = {
    'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6,
    'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10, 'eleven': 11, 'twelve': 12,
}
_TEMPLATE_RULES = (
    ('agent-team', re.compile(r'\bhire\b.+\bagents?\b', re.I)),
    ('revenue-share', re.compile(r'\b(?:revenue share|profit share|mudarabah)\b', re.I)),
    ('confidentiality', re.compile(r'\b(?:confidential(?:ity)?|non-disclosure|nda)\b', re.I)),
    ('ad-campaign', re.compile(r'\b(?:ad campaign|advertising campaign|impressions)\b', re.I)),
    ('api-usage', re.compile(r'\bapi\b|\bcalls\b', re.I)),
    ('data-licence', re.compile(r'\b(?:licen[cs]e|dataset)\b', re.I)),
    ('milestone-escrow', re.compile(r'\bmilestones?\b', re.I)),
    ('sla-penalties', re.compile(r'\bsla\b|\buptime\b', re.I)),
    ('bounty', re.compile(r'\bbounty\b', re.I)),
    ('recurring-service', re.compile(r'\b(?:recurring|subscription|per month|each month)\b', re.I)),
    ('agent-subcontract', re.compile(r'\bsubcontracts?\b|\bsub-covenant\b', re.I)),
    ('payment-on-delivery', re.compile(r'\bpay(?:s|ment)?\b|\bdeliver(?:s|ed|y)?\b', re.I)),
)
_SUBJECTS = (
    re.compile(r'\bdeliver(?:s|ed)?\s+(?:the\s+)?(.+?)\s+by\b', re.I),
    re.compile(r'\babout\s+(?:the\s+)?(.+?)(?:\s+until\b|\s+by\b|$)', re.I),
    re.compile(r'\bfor\s+(?:the\s+)?(.+?)\s+for\s+\d+\s+months?\b', re.I),
    re.compile(r'\bfor\s+(?:the\s+)?(.+?)\s+(?:by|until)\b', re.I),
    re.compile(r'\bcampaign\s+(.+?)\s+for\b', re.I),
)


def library():
    """Every template, its plain-English purpose, and its typed parameters."""
    return [{'id': name, 'title': TITLES[name][0], 'summary': TITLES[name][1], 'parameters': SPECS[name]}
            for name in ORDER]


def terms_hash(terms):
    return digest(LABEL, terms)


def bound(rendering, terms):
    """True when the prose cites the hash of these exact terms."""
    need(type(rendering) is str, 'DRAFT_FIELDS')
    return f'Terms hash: {terms_hash(terms)}.' in rendering


def template(name, **params):
    """Build a draft from typed parameters. Missing required fields are refused."""
    _known(name)
    missing = [row['name'] for row in SPECS[name] if row['required'] and row['name'] not in params]
    need(not missing, 'DRAFT_FIELDS')
    return _document(name, params, set(params), event='TEMPLATE', llm_called=False)


def bind_parties(document, *, payer, payee, referee=None):
    """Copy a draft so the named parties are verification keys.

    The terms hash changes. Earlier acceptances do not carry over. This is what
    lets propose run after a directory hit or a key exchange.
    """
    _require_terms(document)
    params = copy.deepcopy(document['parameters'])
    params['payer'] = payer
    params['payee'] = payee
    filled = set(document.get('filled') or [])
    filled.update(('payer', 'payee'))
    if referee:
        params['referee'] = referee
        filled.add('referee')
    return _document(document['template'], params, filled, event='KEYS',
                     llm_called=bool(document.get('llm_called')))


def draft(text, *, as_of=None, template=None, llm=None):
    """Parse one sentence into a draft.

    ``llm``, when passed, is called once with the sentence and may return a
    dict of parameters. It is not called otherwise. A value it returns is used
    only when the parser did not already fill that parameter.
    """
    sentence = _sentence(text)
    if template is not None:
        _known(template)
        chosen = template
    else:
        chosen = _match_template(sentence)
        if chosen is None:
            raise NativeError(
                'DRAFT_TEMPLATE',
                'No template matched this sentence. Pass one of: ' + ', '.join(ORDER)
                + '. List them with covenant draft --list.')
    supplied, unresolved = _extract(sentence, chosen, as_of)
    llm_called = False
    if llm is not None:
        hint = llm(sentence)
        need(type(hint) is dict, 'DRAFT_FIELDS')
        for key, value in hint.items():
            if key not in supplied:
                supplied[key] = value
        llm_called = True
    return _document(chosen, supplied, set(supplied), event='DRAFT', llm_called=llm_called,
                     unresolved=unresolved)


def lint(document):
    """Check a draft for terms the parties could not perform."""
    terms = _require_terms(document)
    findings = []

    def add(code, severity, path, detail):
        findings.append({'code': code, 'severity': severity, 'path': path, 'detail': detail})

    deadline = terms['time']['deadline']
    if type(deadline) is not int:
        add('MISSING_DEADLINE', 'error', 'time.deadline',
            'Name a deadline. An open end is not a duty the parties can perform.')
    referee = terms['parties']['referee']
    if referee is None:
        add('NO_REFEREE', 'warning', 'parties.referee',
            'Name a referee. With no referee, a dispute has nobody to decide it.')
    for role in ('payer', 'payee', 'referee'):
        value = terms['parties'][role]
        if value and not HEX_KEY.fullmatch(value):
            add('PARTY_UNKEYED', 'warning', f'parties.{role}',
                f'{value} is a name. A signature needs a 64-character public key before propose.')
    for path, value in (('subject', terms['subject']), ('parties.payer', terms['parties']['payer']),
                        ('parties.payee', terms['parties']['payee']), ('parties.referee', terms['parties']['referee'])):
        if type(value) is str and not HEX_KEY.fullmatch(value):
            kinds = sorted({row['kind'] for row in lint_text(value)})
            if kinds:
                add('PII_SUSPECTED', 'warning', path,
                    'This text looks like ' + ', '.join(kinds) + ' data. Keep contact and account details off the '
                    'signed terms. Put them in a private document and pass its hash.')
    quantity = terms['consideration']['quantity']
    cap = terms['consideration']['cap']
    name = terms['template']
    if type(cap) is not int:
        add('UNBOUNDED_LIABILITY', 'error', 'consideration.cap',
            'Cap the sum that can be owed. An open liability is not escrowed.')
    elif name != 'confidentiality' and type(quantity) is int and cap > quantity:
        add('UNBOUNDED_LIABILITY', 'error', 'consideration.cap',
            'The cap is above the escrowed sum, so the extra liability is not funded.')
    if 'unlimited' in _words(terms['subject']):
        add('UNBOUNDED_LIABILITY', 'error', 'subject',
            'The subject says the liability is unlimited. Name a cap.')
    if _vague(terms['subject']):
        add('GHARAR', 'error', 'subject',
            'The subject is too open to deliver or to check. Name the work in plain words.')
    if name != 'confidentiality' and quantity == 0:
        add('GHARAR', 'error', 'consideration.quantity',
            'The price is zero, so the bargain has no consideration to perform.')
    share = terms['share']
    if name == 'revenue-share' and (share['manager_bps'] in (0, 10000) or share['capital_bps'] in (0, 10000)):
        add('GHARAR', 'error', 'share',
            'A profit share of all or nothing is not an agreed split. Name both shares.')
    late = terms['settlement']['late_policy']
    penalty = terms['settlement']['penalty_bps']
    if late == 'refund' and penalty > 0:
        add('CONFLICT', 'error', 'settlement.late_policy',
            'A full refund and a penalty cannot both be taken from the same sum.')
    if name != 'confidentiality' and type(cap) is int and type(quantity) is int and cap < quantity:
        add('CONFLICT', 'error', 'consideration.cap',
            'The price is above the cap, so both clauses cannot be performed.')
    schedule = terms['schedule']
    if schedule and type(quantity) is int and sum(item['amount'] for item in schedule) != quantity:
        add('CONFLICT', 'error', 'schedule',
            'The schedule does not add up to the escrowed sum.')
    if name == 'revenue-share' and share['manager_bps'] + share['capital_bps'] != 10000:
        add('CONFLICT', 'error', 'share',
            'The profit shares do not add up to the whole profit.')
    funding = terms['funding']
    if funding['amount'] and funding['amount'] != quantity:
        add('FUNDING_MISMATCH', 'error', 'funding.amount',
            'The parent funding must equal the child price.')
    if name == 'agent-subcontract' and not funding['amount']:
        add('UNFUNDED_SUBCONTRACT', 'warning', 'funding.amount',
            'This subcontract names no parent escrow. Fund it, or have the prime pay it directly.')
    if terms['settlement']['timeout'] == 'HOLD_FOR_RESOLUTION' and referee is None:
        add('UNREACHABLE', 'error', 'settlement.timeout',
            'A silent hold with no referee never moves the escrow.')
    if terms['time']['challenge_window'] == 0:
        add('UNREACHABLE', 'error', 'time.challenge_window',
            'A challenge window of zero cannot be used to dispute a delivery.')
    if late == 'penalty' and penalty == 0:
        add('UNREACHABLE', 'error', 'settlement.penalty_bps',
            'The late rule is a penalty, and the penalty is zero.')
    if name in ('milestone-escrow', 'recurring-service') and not schedule:
        add('UNREACHABLE', 'error', 'schedule',
            'This template has no step that can be delivered.')
    children = document.get('children') or []
    allocated = 0
    for child in children:
        need(type(child) is dict and type(child.get('amount')) is int and child['amount'] > 0, 'DRAFT_FIELDS')
        allocated += child['amount']
    if type(quantity) is int and allocated > quantity:
        add('OVERDRAWN', 'error', 'children',
            'The children ask for more than the parent escrow holds.')
    findings.sort(key=lambda row: (row['code'], row['path']))
    return {
        'ok': not any(row['severity'] == 'error' for row in findings),
        'terms_hash': terms_hash(terms),
        'findings': findings,
        'execution_authorized': False,
    }


def simulate(document):
    """Show who receives what in four outcomes. This does not move funds."""
    terms = _require_terms(document)
    quantity = terms['consideration']['quantity']
    cap = terms['consideration']['cap'] if type(terms['consideration']['cap']) is int else quantity
    late = terms['settlement']['late_policy']
    penalty_bps = terms['settlement']['penalty_bps']
    timeout = terms['settlement']['timeout']
    name = terms['template']
    share = terms['share']
    rows = []
    for scenario in SCENARIOS:
        profit = 0
        loss = 0
        obligation = 0
        bearer = None
        if scenario == 'delivered' and name == 'revenue-share':
            result = share['illustrative_result']
            if result > 0:
                profit = result
                manager = result * share['manager_bps'] // 10000
                rows.append(_scenario(terms, scenario, quantity + (result - manager), manager, 0, profit, 0, 0, None,
                                      'The work is done. Profit is shared and the capital returns to the capital provider.'))
            elif result < 0:
                loss = min(quantity, -result)
                rows.append(_scenario(terms, scenario, quantity - loss, 0, 0, 0, loss, 0, None,
                                      'The work is done. The loss is borne by the capital provider, up to the capital.'))
            else:
                rows.append(_scenario(terms, scenario, quantity, 0, 0, 0, 0, 0, None,
                                      'The work is done. There is no profit to share and the capital returns.'))
            continue
        if scenario == 'delivered' and name == 'confidentiality':
            rows.append(_scenario(terms, scenario, 0, 0, 0, 0, 0, 0, None,
                                  'The confidence holds. No sum moves.'))
            continue
        if scenario == 'delivered' and name == 'agent-team':
            paid = sum(item['amount'] for item in terms['schedule']) if terms['schedule'] else 0
            rows.append(_scenario(terms, scenario, quantity - paid, paid, 0, 0, 0, 0, None,
                                  'Each child is paid its own cap when that child delivers. A failed child is not paid.'))
            continue
        if scenario == 'delivered':
            payee = min(quantity, cap)
            rows.append(_scenario(terms, scenario, quantity - payee, payee, 0, 0, 0, 0, None,
                                  'The work is in. The payee receives the consideration, up to the cap.'))
            continue
        if scenario == 'late' and name == 'confidentiality':
            obligation = cap
            bearer = 'payee'
            rows.append(_scenario(terms, scenario, 0, 0, quantity, 0, 0, obligation, bearer,
                                  'The confidence was broken. Monetary liability is the cap, and it is not taken from an empty escrow.'))
            continue
        if scenario == 'late':
            if late == 'refund':
                rows.append(_scenario(terms, scenario, quantity, 0, 0, 0, 0, 0, None,
                                      'The work is late. The payer is refunded.'))
            elif late == 'pay':
                payee = min(quantity, cap)
                rows.append(_scenario(terms, scenario, quantity - payee, payee, 0, 0, 0, 0, None,
                                      'The work is late. The terms still pay the payee.'))
            else:
                penalty = min(quantity * penalty_bps // 10000, cap, quantity)
                payee = min(quantity - penalty, cap)
                rows.append(_scenario(terms, scenario, quantity - payee, payee, 0, 0, 0, 0, None,
                                      'The work is late. The penalty returns to the payer and the rest is paid.'))
            continue
        if scenario == 'disputed':
            rows.append(_scenario(terms, scenario, 0, 0, quantity, 0, 0, 0, None,
                                  'The delivery is disputed. The escrow stays put until the referee decides.'))
            continue
        if timeout == 'RELEASE_IF_UNDECIDED':
            rows.append(_scenario(terms, scenario, quantity, 0, 0, 0, 0, 0, None,
                                  'The referee stayed silent. The timeout refunds the payer.'))
        else:
            rows.append(_scenario(terms, scenario, 0, 0, quantity, 0, 0, 0, None,
                                  'The referee stayed silent. The timeout holds the escrow.'))
    return {
        'template': name,
        'terms_hash': terms_hash(terms),
        'scenarios': rows,
        'execution_authorized': False,
    }


def counter(document, changes, *, party):
    """Return a new version with a diff. Earlier acceptances do not carry over."""
    terms = _require_terms(document)
    _party(terms, party)
    need(type(changes) is dict and changes, 'DRAFT_FIELDS')
    current = document['parameters']
    merged = dict(current)
    merged.update(changes)
    if 'quantity' in changes and 'cap' not in changes and current.get('cap') == current.get('quantity'):
        merged['cap'] = changes['quantity']
    built = _prepare(document['template'], merged, set(current) | set(changes))
    built['terms']['funding'] = copy.deepcopy(terms['funding'])
    diff = _diff(terms, built['terms'])
    need(diff, 'DRAFT_UNCHANGED')
    sealed = _seal(built['terms'])
    successor = copy.deepcopy(document)
    successor['parameters'] = built['parameters']
    successor['terms'] = built['terms']
    successor['terms_hash'] = sealed['terms_hash']
    successor['plain'] = sealed['plain']
    successor['markdown'] = sealed['markdown']
    successor['work_order'] = _project(built['terms'])
    successor['version'] = document['version'] + 1
    successor['status'] = 'COUNTERED'
    successor['acceptances'] = []
    successor['ambiguities'] = _ambiguities(document['template'], built['parameters'], None, set(changes))
    successor['history'] = list(document['history']) + [{
        'version': successor['version'],
        'event': 'COUNTER',
        'party': party,
        'terms_hash': sealed['terms_hash'],
        'diff': diff,
    }]
    successor['execution_authorized'] = False
    successor['compiled'] = _compile(successor)
    return successor


def accept_draft(document, party):
    """Record one party's acceptance of the current terms hash.

    Errors from the linter block acceptance. A warning, such as a party still
    being a name rather than a key, does not.
    """
    terms = _require_terms(document)
    _party(terms, party)
    need(document['terms_hash'] == terms_hash(terms), 'DRAFT_FIELDS')
    need(lint(document)['ok'], 'DRAFT_NOT_READY')
    successor = copy.deepcopy(document)
    digest_hex = successor['terms_hash']
    already = [row for row in successor['acceptances'] if row['party'] == party and row['terms_hash'] == digest_hex]
    if not already:
        successor['acceptances'] = list(successor['acceptances']) + [{'party': party, 'terms_hash': digest_hex}]
        successor['history'] = list(successor['history']) + [{
            'version': successor['version'],
            'event': 'ACCEPT',
            'party': party,
            'terms_hash': digest_hex,
            'diff': [],
        }]
    names = {terms['parties']['payer'], terms['parties']['payee']}
    accepted = {row['party'] for row in successor['acceptances'] if row['terms_hash'] == digest_hex}
    if names <= accepted:
        successor['status'] = 'ACCEPTED'
    return successor


def compose(parent, child):
    """Fund a child covenant from a parent escrow.

    The child's terms record the parent hash and the funded amount, so the
    child's own terms hash covers the link. The parent's commercial terms stay
    put. The parent document lists the child so a later child cannot overdraw it.
    """
    parent_terms = _require_terms(parent)
    child_terms = _require_terms(child)
    need(parent['terms_hash'] == terms_hash(parent_terms), 'DRAFT_FIELDS')
    need(child['terms_hash'] == terms_hash(child_terms), 'DRAFT_FIELDS')
    amount = child_terms['consideration']['quantity']
    need(type(amount) is int and amount > 0, 'DRAFT_FIELDS')
    used = sum(item['amount'] for item in parent.get('children') or [])
    need(used + amount <= parent_terms['consideration']['quantity'], 'DRAFT_OVERDRAWN')
    parent_out = copy.deepcopy(parent)
    child_out = copy.deepcopy(child)
    before = copy.deepcopy(child_out['terms'])
    child_out['terms']['funding'] = {'parent_terms_hash': parent_out['terms_hash'], 'amount': amount}
    sealed = _seal(child_out['terms'])
    child_out['terms_hash'] = sealed['terms_hash']
    child_out['plain'] = sealed['plain']
    child_out['markdown'] = sealed['markdown']
    child_out['work_order'] = _project(child_out['terms'])
    child_out['version'] = child_out['version'] + 1
    child_out['status'] = 'PROPOSED'
    child_out['acceptances'] = []
    child_out['history'] = list(child_out['history']) + [{
        'version': child_out['version'],
        'event': 'COMPOSE',
        'party': None,
        'terms_hash': sealed['terms_hash'],
        'diff': _diff(before, child_out['terms']),
    }]
    parent_out['children'] = list(parent_out.get('children') or []) + [{
        'terms_hash': child_out['terms_hash'],
        'amount': amount,
        'template': child_out['template'],
    }]
    child_out['compiled'] = _compile(child_out)
    return {'parent': parent_out, 'child': child_out}


def render(terms):
    return _seal(terms)


def _compile(document):
    """Project a draft onto the modules that already hold agreements.

    The plain text becomes a concept. The canonical terms become an external
    byte draft. A human work packet and a studio charter are built when both
    parties are Ed25519 keys. None of these calls sign, pay, or append a ledger.
    """
    import base64

    from covenant_language.agreement_builder import simple
    from covenant_language.external_drafts import pack
    from .codec import canonical

    concept = simple(document['plain'], title='Draft')
    packed = pack(base64.b64encode(canonical(document['terms'])).decode('ascii'),
                  title=document['template'], media_type='application/json', language='json')
    return {
        'basis': [
            'covenant_chain.human_agreements',
            'covenant_language.external_drafts',
            'covenant_language.contract_studio',
            'covenant_language.agreement_builder',
        ],
        'parallel_record': False,
        'concept_id': concept['id'],
        'concept_interpretation': concept['interpretation'],
        'external_draft_id': packed['id'],
        'external_source_sha256': packed['source_sha256'],
        'human_agreement': _human(document),
        'charter': _charter(document),
        'execution_authorized': False,
    }


def _party_keys(document):
    from covenant_language.key_validation import valid_ed25519_key
    parties = document['terms']['parties']
    payer, payee = parties['payer'], parties['payee']
    if not (valid_ed25519_key(payer) and valid_ed25519_key(payee) and payer != payee):
        return None
    named = {'payer': payer, 'payee': payee}
    referee = parties['referee']
    if referee and valid_ed25519_key(referee) and referee not in (payer, payee):
        named['referee'] = referee
    return named


def _job(document):
    terms = document['terms']
    subject = terms['subject'] or 'unnamed subject'
    deadline = terms['time']['deadline_text'] or (str(terms['time']['deadline']) if terms['time']['deadline'] is not None else None)
    quantity = terms['consideration']['quantity']
    job = {
        'title': TITLES[terms['template']][0],
        'scope': subject,
        'deliverables': [subject],
        'acceptance_checks': ['The named subject is delivered by the deadline.'],
        'schedule': {'delivery_deadline': deadline},
        'payment': {
            'service': 'stablecoin escrow' if quantity else None,
            'release_rule': terms['settlement']['late_policy'],
            'escrow': 'REQUESTED' if quantity else 'NOT_REQUESTED',
        },
    }
    if quantity:
        currency = terms['consideration']['unit']
        from covenant_chain.human_agreements import PRECISION
        job['price'] = {'amount_minor': quantity, 'currency': currency,
                        'minor_unit_digits': PRECISION.get(currency, 0)}
    if 'referee' in (_party_keys(document) or {}):
        job['dispute'] = {'required': True, 'reviewer': terms['parties']['referee']}
    return job


def _human(document):
    parties = _party_keys(document)
    preview = {'profile': 'covenant-human-agreement/0.1', 'job': _job(document), 'execution_authorized': False}
    if parties is None:
        return {**preview, 'ready': False, 'reason': 'NEEDS_VERIFICATION_KEYS'}
    from covenant_chain.human_agreements import prepare
    prepared = prepare(parties, preview['job'])
    return {
        'ready': True,
        'profile': 'covenant-human-agreement/0.1',
        'id': prepared['packet']['id'],
        'execution_authorized': False,
    }


def _charter(document):
    studio = 'finance_and_risk' if document['template'] in ('revenue-share', 'sla-penalties', 'confidentiality') else 'essentials'
    parties = _party_keys(document)
    if parties is None:
        return {'ready': False, 'reason': 'NEEDS_VERIFICATION_KEYS', 'studio_template': studio,
                'profile': 'covenant-contract-studio/0.1', 'execution_authorized': False}
    from covenant_language.contract_studio import draft as studio_draft
    charter_parties = {'payer': parties['payer'], 'payee': parties['payee']}
    drafted = studio_draft(
        TITLES[document['template']][0], document['terms_hash'],
        {'kind': 'covenant-draft', 'id': document['terms_hash']}, charter_parties, templates=[studio])
    return {
        'ready': True,
        'profile': 'covenant-contract-studio/0.1',
        'id': drafted['id'],
        'studio_template': studio,
        'execution_authorized': False,
    }


def _document(name, supplied, filled_keys, *, event, llm_called, unresolved=None):
    built = _prepare(name, supplied, filled_keys)
    sealed = _seal(built['terms'])
    parameters = built['parameters']
    body = {
        'profile': PROFILE,
        'template': name,
        'parameters': parameters,
        'filled': sorted(key for key in filled_keys if key in parameters),
        'terms': built['terms'],
        'terms_hash': sealed['terms_hash'],
        'plain': sealed['plain'],
        'markdown': sealed['markdown'],
        'ambiguities': _ambiguities(name, parameters, unresolved, filled_keys),
        'status': 'PROPOSED',
        'version': 1,
        'history': [{
            'version': 1,
            'event': event,
            'party': None,
            'terms_hash': sealed['terms_hash'],
            'diff': [],
        }],
        'acceptances': [],
        'children': [],
        'llm_called': llm_called,
        'execution_authorized': False,
        'work_order': _project(built['terms']),
    }
    if name == 'agent-team':
        body['team'] = [{
            'index': index, 'name': item['name'], 'cap': item['amount'], 'payee': None, 'state': 'PENDING',
        } for index, item in enumerate(parameters.get('schedule') or [], start=1)]
    body['compiled'] = _compile(body)
    return body


def _prepare(name, supplied, filled_keys):
    _known(name)
    allowed = {row['name'] for row in SPECS[name]}
    need(set(supplied) <= allowed, 'DRAFT_FIELDS')
    for key, value in supplied.items():
        _check_value(key, value)
    params = {row['name']: row['default'] for row in SPECS[name]}
    params.update(supplied)
    if name == 'revenue-share':
        if 'manager_bps' in filled_keys and 'capital_bps' not in filled_keys:
            params['capital_bps'] = 10000 - params['manager_bps']
        elif 'capital_bps' in filled_keys and 'manager_bps' not in filled_keys:
            params['manager_bps'] = 10000 - params['capital_bps']
    if name == 'milestone-escrow':
        if params.get('schedule'):
            if 'quantity' not in filled_keys:
                params['quantity'] = sum(item['amount'] for item in params['schedule'])
        elif type(params.get('quantity')) is int and params['quantity'] >= 2:
            first = params['quantity'] // 2
            params['schedule'] = [
                {'name': 'Milestone 1', 'amount': first},
                {'name': 'Milestone 2', 'amount': params['quantity'] - first},
            ]
        else:
            params['schedule'] = []
    if name == 'recurring-service':
        periods = params.get('periods') or 1
        params['periods'] = periods
        if 'per_period' not in filled_keys and type(params.get('quantity')) is int:
            params['per_period'] = params['quantity']
            params['quantity'] = params['per_period'] * periods
        elif type(params.get('per_period')) is int:
            params['quantity'] = params['per_period'] * periods
        if not params.get('schedule') and type(params.get('per_period')) is int:
            params['schedule'] = [{'name': f'Period {index}', 'amount': params['per_period']}
                                  for index in range(1, periods + 1)]
    if name == 'agent-team' and type(params.get('team_size')) is int and type(params.get('per_agent')) is int:
        params['schedule'] = [{'name': f'Agent {index}', 'amount': params['per_agent']}
                              for index in range(1, params['team_size'] + 1)]
        if 'quantity' not in filled_keys:
            params['quantity'] = params['team_size'] * params['per_agent']
        params['cap'] = params['per_agent']
    elif 'cap' not in filled_keys or params.get('cap') is None:
        params['cap'] = params['quantity'] if type(params.get('quantity')) is int else 0
    for key, value in params.items():
        if value is not None:
            _check_value(key, value)
    return {'parameters': params, 'terms': _terms(name, params)}


def _terms(name, params):
    schedule = params.get('schedule') or []
    return {
        'profile': PROFILE,
        'template': name,
        'parties': {
            'payer': params.get('payer') or '',
            'payee': params.get('payee') or '',
            'referee': params.get('referee'),
        },
        'subject': params.get('subject') or '',
        'consideration': {
            'quantity': params.get('quantity') if type(params.get('quantity')) is int else 0,
            'unit': params.get('unit') or 'USDC',
            'cap': params.get('cap') if type(params.get('cap')) is int else 0,
        },
        'time': {
            'deadline': params.get('deadline'),
            'deadline_text': params.get('deadline_text'),
            'challenge_window': params.get('challenge_window') if type(params.get('challenge_window')) is int else 86400,
        },
        'settlement': {
            'rail': params.get('rail') or 'x402',
            'timeout': params.get('timeout') or 'RELEASE_IF_UNDECIDED',
            'effect': params.get('effect') or 'TRANSFER',
            'late_policy': params.get('late_policy') or 'refund',
            'penalty_bps': params.get('penalty_bps') if type(params.get('penalty_bps')) is int else 0,
            'evidence': list(params.get('evidence') or []),
            'refund_bps': params.get('refund_bps') if type(params.get('refund_bps')) is int else 0,
            'unknown_default': params.get('unknown_default'),
        },
        'schedule': [{'name': item['name'], 'amount': item['amount']} for item in schedule],
        'share': {
            'manager_bps': params.get('manager_bps') if type(params.get('manager_bps')) is int else 0,
            'capital_bps': params.get('capital_bps') if type(params.get('capital_bps')) is int else 0,
            'illustrative_result': params.get('illustrative_result') if type(params.get('illustrative_result')) is int else 0,
            'loss_bearer': 'payer',
        },
        'measure': params.get('measure') if type(params.get('measure')) is int else None,
        'funding': {'parent_terms_hash': None, 'amount': 0},
    }


def _seal(terms):
    _require_shape(terms)
    digest_hex = terms_hash(terms)
    plain = _plain(terms, digest_hex)
    title = TITLES[terms['template']][0]
    markdown = f'# {title}\n\n{plain}\n'
    return {'terms_hash': digest_hex, 'plain': plain, 'markdown': markdown}


def _plain(terms, digest_hex):
    payer = terms['parties']['payer']
    payee = terms['parties']['payee']
    referee = terms['parties']['referee'] or 'no referee named'
    subject = terms['subject'] or 'an unnamed subject'
    when = _when(terms)
    unit = terms['consideration']['unit']
    quantity = terms['consideration']['quantity']
    cap = terms['consideration']['cap']
    late = terms['settlement']['late_policy']
    timeout = terms['settlement']['timeout']
    name = terms['template']
    if name == 'payment-on-delivery':
        price = f'{quantity} {unit}'
        if unit == 'GBP' and type(quantity) is int:
            price = f'{quantity} pence (GBP {quantity // 100}.{quantity % 100:02d})'
        sentences = [
            f'{payer} pays {payee} {price} for {subject} by {when}.',
            'The sum is released when the work is delivered.',
            f'If the work is late or missing, the rule is {late}.',
        ]
        evidence = terms['settlement'].get('evidence') or []
        if evidence:
            labels = {'photo': 'photo', 'gps': 'GPS', 'temperature': 'a temperature log',
                      'signature': 'a signature', 'timestamp': 'a timestamp', 'tracking': 'a tracking feed'}
            sentences.append('Proof of delivery: ' + ', '.join(labels.get(item, item) for item in evidence) + '.')
        if terms['settlement'].get('refund_bps') == 5000:
            sentences.append('If the temperature goes out of range, refund half the fee.')
        if terms['settlement'].get('unknown_default') == 'HOLD':
            sentences.append('A missing reading stays unknown and the fee is held.')
    elif name == 'milestone-escrow':
        parts = ', '.join(f"{item['amount']} {unit} for {item['name']}" for item in terms['schedule']) or 'none'
        sentences = [
            f'{payer} escrows {quantity} {unit} for {payee} to deliver {subject} by {when}.',
            f'Milestones: {parts}.',
            'Each milestone is paid when it is delivered.',
        ]
    elif name == 'sla-penalties':
        sentences = [
            f'{payer} pays {payee} {quantity} {unit} for {subject} through {when}.',
            f"The service target is {terms['measure']} basis points.",
            f"A miss reduces the fee by {terms['settlement']['penalty_bps']} basis points.",
        ]
    elif name == 'data-licence':
        sentences = [
            f'{payer} pays {payee} {quantity} {unit} for a licence to use {subject} until {when}.',
            'The licence ends at that time.',
        ]
    elif name == 'api-usage':
        sentences = [
            f'{payer} prepays {payee} {quantity} {unit} for {subject}, covering {terms["measure"]} calls, until {when}.',
        ]
    elif name == 'agent-subcontract':
        sentences = [
            f'{payer} pays {payee} {quantity} {unit} to perform {subject} by {when}.',
            'This work is a subcontract.',
        ]
    elif name == 'bounty':
        sentences = [
            f'{payer} posts a bounty of {quantity} {unit} for {subject}.',
            f'{payee} is paid if the work is accepted by {when}.',
            'Otherwise the bounty is refunded.',
        ]
    elif name == 'revenue-share':
        share = terms['share']
        sentences = [
            f'{payer} provides {quantity} {unit} of capital. {payee} does the work of {subject} until {when}.',
            f"Profits are shared {_percent(share['capital_bps'])} to {payer} and {_percent(share['manager_bps'])} to {payee}.",
            f'Losses are borne by {payer}. There is no guaranteed return.',
        ]
    elif name == 'confidentiality':
        sentences = [
            f'{payer} discloses {subject} to {payee}.',
            f'{payee} keeps it confidential until {when}.',
            'No fee is escrowed.' if quantity == 0 else f'{payer} escrows {quantity} {unit}.',
        ]
    elif name == 'ad-campaign':
        sentences = [
            f'{payer} pays {payee} {quantity} {unit} to run the campaign {subject} for {terms["measure"]} impressions by {when}.',
        ]
    elif name == 'recurring-service':
        per = terms['schedule'][0]['amount'] if terms['schedule'] else 0
        count = len(terms['schedule'])
        sentences = [
            f'{payer} pays {payee} {per} {unit} per period for {subject}, {count} periods, {quantity} {unit} in total, ending {when}.',
        ]
    elif name == 'agent-team':
        slots = len(terms['schedule'])
        each = terms['schedule'][0]['amount'] if terms['schedule'] else cap
        sentences = [
            f'{payer} hires {slots} agents for {subject}.',
            f'Each agent is capped at {each} {unit}. The budget is {quantity} {unit}.',
            'An unnamed agent is not paid. A failed step is not paid.',
        ]
    else:
        raise NativeError('DRAFT_TEMPLATE')
    funding = terms['funding']
    if funding['parent_terms_hash']:
        sentences.append(f"Funded by parent escrow {funding['parent_terms_hash']} for {funding['amount']} {unit}.")
    sentences.append(f'Referee: {referee}.')
    sentences.append(f'If the referee stays silent, the rule is {timeout}.')
    sentences.append(f'Liability is capped at {cap} {unit}.')
    sentences.append(f'Terms hash: {digest_hex}.')
    return ' '.join(sentences)


def _project(terms):
    if type(terms['time']['deadline']) is not int or terms['consideration']['quantity'] <= 0:
        return None
    note = 'Preview only. propose needs keys for the parties and the referee.'
    if terms['template'] in ('milestone-escrow', 'recurring-service'):
        note = 'Preview of the total escrow. The steps stay in the draft terms. propose needs keys.'
    return {
        'version': 'covenant-work-order/0.1',
        'preview': True,
        'execution_authorized': False,
        'task': terms['subject'],
        'quantity': terms['consideration']['quantity'],
        'unit': terms['consideration']['unit'],
        'rail': terms['settlement']['rail'],
        'pay_to': terms['parties']['payee'],
        'deadline': terms['time']['deadline'],
        'challenge_window': terms['time']['challenge_window'],
        'timeout': terms['settlement']['timeout'],
        'effect': terms['settlement']['effect'],
        'note': note,
    }


def _ambiguities(name, params, unresolved, filled_keys):
    rows = []

    def add(code, field, detail):
        rows.append({'code': code, 'field': field, 'detail': detail})

    if not params.get('payer') or params.get('payer') in ('Payer', 'Discloser'):
        add('PAYER_UNNAMED', 'payer', 'The payer is still a placeholder. Name the party who pays or discloses.')
    if not params.get('payee') or params.get('payee') in ('Claimant', 'Recipient'):
        add('PAYEE_UNNAMED', 'payee', 'The payee is still a placeholder. Name the party who is paid or receives.')
    for field in ('payer', 'payee', 'referee'):
        value = params.get(field)
        if value and not HEX_KEY.fullmatch(value):
            add('PARTY_UNKEYED', field, f'{value} is a name. A signature needs a 64-character public key.')
    if params.get('deadline') is None:
        if unresolved:
            add('DEADLINE_UNRESOLVED', 'deadline',
                f'{unresolved} needs an as_of date before it becomes a timestamp.')
        else:
            add('DEADLINE_UNNAMED', 'deadline', 'No deadline is set.')
    if not params.get('referee'):
        add('NO_REFEREE', 'referee', 'Name a referee so a dispute has someone to decide it.')
    if not params.get('subject'):
        add('SUBJECT_UNNAMED', 'subject', 'Name the subject of the covenant.')
    if name != 'confidentiality' and not params.get('quantity'):
        add('PRICE_UNNAMED', 'quantity', 'Name the price.')
    if name == 'milestone-escrow' and 'schedule' not in filled_keys:
        add('MILESTONE_SPLIT', 'schedule', 'The milestones were split in half. Name each milestone and its amount.')
    if name == 'revenue-share' and 'manager_bps' not in filled_keys and 'capital_bps' not in filled_keys:
        add('SHARE_DEFAULTED', 'manager_bps', 'The profit split defaulted to 70 percent capital and 30 percent manager.')
    if name == 'agent-team':
        size = params.get('team_size') or 0
        if not size:
            add('NEED_NAMED_PAYEES', 'team_size', 'Say how many agents, for example eight.')
        else:
            add('NEED_NAMED_PAYEES', 'payee',
                f'{size} agents are unnamed. Pass their public keys or search the directory.')
    rows.sort(key=lambda row: (row['code'], row['field']))
    return rows


def _sentence(text):
    need(type(text) is str and 1 <= len(text) <= 2000, 'DRAFT_TEXT')
    need(all(32 <= ord(char) <= 126 or char in '\n\t' for char in text), 'DRAFT_TEXT')
    sentence = ' '.join(text.split())
    need(sentence, 'DRAFT_TEXT')
    return sentence


def _match_template(sentence):
    for name, pattern in _TEMPLATE_RULES:
        if pattern.search(sentence):
            return name
    return None


def _extract(sentence, name, as_of):
    supplied = {}
    unresolved = None
    name_words = r'[A-Z][A-Za-z0-9]*(?:\s+[A-Z][A-Za-z0-9]*)*'
    pays = re.search(rf'\b({name_words})\s+[Pp]ays\s+({name_words})\b', sentence)
    if pays:
        supplied['payer'] = pays.group(1)
        supplied['payee'] = pays.group(2)
    else:
        pay = re.search(r'\b[Pp]ay\s+([A-Z][A-Za-z0-9]*)\b', sentence)
        if pay:
            supplied['payee'] = pay.group(1)
        else:
            toward = re.search(r'\bto\s+([A-Z][A-Za-z0-9]*)\b', sentence)
            if toward:
                supplied['payee'] = toward.group(1)
    money = re.search(r'\b(\d+)\s*(USDC|USDT|DAI|USDG)\b', sentence, re.I)
    if money:
        supplied['quantity'] = int(money.group(1))
        supplied['unit'] = money.group(2).upper()
    else:
        pence = re.search(r'\b(\d+)\s*(?:p|pence)\b', sentence, re.I)
        gbp = re.search(r'(?:GBP|£)\s*(\d+)(?:\.(\d{2}))?\b', sentence)
        if pence:
            supplied['quantity'] = int(pence.group(1))
            supplied['unit'] = 'GBP'
        elif gbp:
            supplied['quantity'] = int(gbp.group(1)) * 100 + int(gbp.group(2) or '0')
            supplied['unit'] = 'GBP'
    for pattern in _SUBJECTS:
        found = pattern.search(sentence)
        if found:
            subject = found.group(1).strip(' .,;:')
            subject = ' '.join(subject.split())
            if subject:
                supplied['subject'] = subject
                break
    dated = re.search(r'\b(?:by|until)\s+(\d{4}-\d{2}-\d{2})\b', sentence)
    weekday = re.search(r'\b(?:by|until)\s+(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b', sentence, re.I)
    clock = re.search(r'\b(?:by|before|due)\s+(\d{1,2}):(\d{2})\b', sentence)
    if clock and not dated and not weekday:
        hour, minute = int(clock.group(1)), int(clock.group(2))
        need(0 <= hour <= 23 and 0 <= minute <= 59, 'DRAFT_FIELDS')
        supplied['deadline_text'] = f'{hour:02d}:{minute:02d}'
        if as_of:
            year, month, day = _date_parts(as_of)
            supplied['deadline'] = int(datetime(year, month, day, hour, minute, tzinfo=timezone.utc).timestamp())
        else:
            unresolved = supplied['deadline_text']
    elif dated:
        supplied['deadline'] = _end_of_day(dated.group(1))
        supplied['deadline_text'] = dated.group(1)
    elif weekday:
        label = weekday.group(1).title()
        if as_of:
            resolved, text = _resolve_weekday(as_of, label)
            supplied['deadline'] = resolved
            supplied['deadline_text'] = text
        else:
            supplied['deadline_text'] = label
            unresolved = label
    if re.search(r'\bpenalty\s+(?:of\s+)?(\d+)\s*%', sentence, re.I):
        percent = int(re.search(r'\bpenalty\s+(?:of\s+)?(\d+)\s*%', sentence, re.I).group(1))
        need(0 <= percent <= 100, 'DRAFT_FIELDS')
        supplied['penalty_bps'] = percent * 100
        supplied['late_policy'] = 'penalty'
    if re.search(r'\brefund\s+if\s+not\b', sentence, re.I):
        supplied['late_policy'] = 'refund'
        supplied['timeout'] = 'RELEASE_IF_UNDECIDED'
    fields = {row['name'] for row in SPECS[name]}
    if re.search(r'\b(?:refund\s+half|half(?:\s+the\s+fee)?\s+refund|50\s*(?:%|percent)\s+refund|refund\s+50\s*(?:%|percent))\b', sentence, re.I):
        supplied['late_policy'] = 'penalty'
        supplied['penalty_bps'] = 5000
        if 'refund_bps' in fields:
            supplied['refund_bps'] = 5000
    evidence = []
    if re.search(r'\b(?:photo|photograph|picture)\b', sentence, re.I):
        evidence.append('photo')
    if re.search(r'\bGPS\b', sentence) or re.search(r'\bgps\b', sentence):
        evidence.append('gps')
    if re.search(r'\btemperature\b', sentence, re.I):
        evidence.append('temperature')
    if evidence and 'evidence' in fields:
        supplied['evidence'] = sorted(set(evidence))
    if re.search(r'\bmissing\b', sentence, re.I) and re.search(r'\bhold\b', sentence, re.I) and 'unknown_default' in fields:
        supplied['unknown_default'] = 'HOLD'
    referee = re.search(r'\breferee\s+([A-Z][A-Za-z0-9]*)\b', sentence)
    if referee:
        supplied['referee'] = referee.group(1)
    if re.search(r'\bap2\b', sentence, re.I):
        supplied['rail'] = 'ap2'
    elif re.search(r'\bx402\b', sentence, re.I):
        supplied['rail'] = 'x402'
    if name == 'milestone-escrow':
        steps = re.search(r'\b(\d+)\s+then\s+(\d+)(?:\s+then\s+(\d+))?\b', sentence)
        if steps:
            amounts = [int(item) for item in steps.groups() if item]
            total = sum(amounts)
            supplied['schedule'] = [{'name': f'Milestone {index}', 'amount': amount}
                                    for index, amount in enumerate(amounts, start=1)]
            if supplied.get('quantity') in (None, amounts[-1], total):
                supplied['quantity'] = total
    if name == 'recurring-service':
        months = re.search(r'\b(\d+)\s+months?\b', sentence, re.I)
        if months:
            supplied['periods'] = int(months.group(1))
            need(1 <= supplied['periods'] <= 120, 'DRAFT_FIELDS')
        if 'quantity' in supplied:
            supplied['per_period'] = supplied.pop('quantity')
    if name == 'agent-team':
        counted = re.search(
            r'\b(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s+agents?\b',
            sentence, re.I)
        if counted:
            token = counted.group(1).lower()
            supplied['team_size'] = int(token) if token.isdigit() else _COUNT_WORDS[token]
        priced = re.search(r'\b(\d+)\s+credits?\b', sentence, re.I)
        if priced:
            supplied['per_agent'] = int(priced.group(1))
            supplied['unit'] = 'credits'
            if 'team_size' in supplied:
                supplied['quantity'] = supplied['team_size'] * supplied['per_agent']
    if name == 'revenue-share':
        ratio = re.search(r'\b(\d+)\s*/\s*(\d+)\b', sentence)
        if ratio and int(ratio.group(1)) + int(ratio.group(2)) == 100:
            supplied['capital_bps'] = int(ratio.group(1)) * 100
            supplied['manager_bps'] = int(ratio.group(2)) * 100
    impressions = re.search(r'\b(\d+)\s+impressions\b', sentence, re.I)
    calls = re.search(r'\b(\d+)\s+calls\b', sentence, re.I)
    uptime = re.search(r'\b(\d+)%\s+uptime\b', sentence, re.I)
    if name == 'ad-campaign' and impressions:
        supplied['measure'] = int(impressions.group(1))
    if name == 'api-usage' and calls:
        supplied['measure'] = int(calls.group(1))
    if name == 'sla-penalties' and uptime:
        supplied['measure'] = int(uptime.group(1)) * 100
    return supplied, unresolved


def _end_of_day(iso):
    year, month, day = _date_parts(iso)
    moment = datetime(year, month, day, 23, 59, 59, tzinfo=timezone.utc)
    return int(moment.timestamp())


def _resolve_weekday(as_of, weekday_name):
    year, month, day = _date_parts(as_of)
    current = date(year, month, day)
    target = WEEKDAYS.index(weekday_name.lower())
    delta = (target - current.weekday()) % 7
    resolved = current + timedelta(days=delta)
    iso = resolved.isoformat()
    return _end_of_day(iso), f'{weekday_name.title()} {iso}'


def _date_parts(iso):
    need(type(iso) is str and re.fullmatch(r'\d{4}-\d{2}-\d{2}', iso) is not None, 'DRAFT_FIELDS')
    year, month, day = (int(part) for part in iso.split('-'))
    try:
        date(year, month, day)
    except ValueError:
        raise NativeError('DRAFT_FIELDS') from None
    return year, month, day


def _check_value(key, value):
    if key in ('payer', 'payee', 'referee', 'subject', 'deadline_text'):
        if key in ('referee', 'deadline_text') and value is None:
            return
        need(type(value) is str and 1 <= len(value) <= 400 and all(32 <= ord(char) <= 126 for char in value), 'DRAFT_FIELDS')
        return
    if key == 'deadline':
        need(value is None or (type(value) is int and 0 < value <= 2**53 - 1), 'DRAFT_FIELDS')
        return
    if key == 'periods':
        need(type(value) is int and 1 <= value <= 120, 'DRAFT_FIELDS')
        return
    if key in ('team_size',):
        need(type(value) is int and 1 <= value <= 32, 'DRAFT_FIELDS')
        return
    if key == 'per_agent':
        need(type(value) is int and 1 <= value <= 2**53 - 1, 'DRAFT_FIELDS')
        return
    if key in ('quantity', 'cap', 'challenge_window', 'measure', 'per_period'):
        if key in ('measure', 'per_period', 'cap') and value is None:
            return
        limit = 10000000 if key == 'challenge_window' else 2**53 - 1
        need(type(value) is int and 0 <= value <= limit, 'DRAFT_FIELDS')
        return
    if key == 'illustrative_result':
        need(type(value) is int and not isinstance(value, bool) and abs(value) <= 2**53 - 1, 'DRAFT_FIELDS')
        return
    if key == 'refund_bps':
        if value is None:
            return
        need(type(value) is int and 0 <= value <= 10000, 'DRAFT_FIELDS')
        return
    if key == 'penalty_bps' or key in ('manager_bps', 'capital_bps'):
        need(type(value) is int and 0 <= value <= 10000, 'DRAFT_FIELDS')
        return
    if key == 'evidence':
        if value is None:
            return
        allowed = ('photo', 'gps', 'temperature', 'signature', 'timestamp', 'tracking')
        need(type(value) is list and 1 <= len(value) <= 8 and value == sorted(set(value)), 'DRAFT_FIELDS')
        need(all(item in allowed for item in value), 'DRAFT_FIELDS')
        return
    if key == 'unknown_default':
        if value is None:
            return
        need(value == 'HOLD', 'DRAFT_FIELDS')
        return
    if key == 'unit':
        need(value in UNITS or value == 'credits', 'DRAFT_FIELDS')
        return
    if key == 'rail':
        need(value in RAILS, 'DRAFT_FIELDS')
        return
    if key == 'timeout':
        need(value in TIMEOUTS, 'DRAFT_FIELDS')
        return
    if key == 'effect':
        need(value in EFFECTS, 'DRAFT_FIELDS')
        return
    if key == 'late_policy':
        need(value in LATE, 'DRAFT_FIELDS')
        return
    if key == 'schedule':
        if value is None:
            return
        need(type(value) is list and len(value) <= 120, 'DRAFT_FIELDS')
        for item in value:
            need(type(item) is dict and set(item) == {'name', 'amount'}, 'DRAFT_FIELDS')
            _check_value('subject', item['name'])
            need(type(item['amount']) is int and item['amount'] > 0, 'DRAFT_FIELDS')
        return
    raise NativeError('DRAFT_FIELDS')


def _require_terms(document):
    need(type(document) is dict and type(document.get('terms')) is dict, 'DRAFT_FIELDS')
    terms = document['terms']
    _require_shape(terms)
    return terms


def _require_shape(terms):
    need(type(terms) is dict and terms.get('profile') == PROFILE and terms.get('template') in ORDER, 'DRAFT_TEMPLATE')
    for key in ('parties', 'consideration', 'time', 'settlement', 'share', 'funding'):
        need(type(terms.get(key)) is dict, 'DRAFT_FIELDS')
    need(type(terms.get('schedule')) is list, 'DRAFT_FIELDS')
    return terms


def _party(terms, party):
    need(party in (terms['parties']['payer'], terms['parties']['payee']), 'DRAFT_PARTY')


def _known(name):
    need(name in ORDER, 'DRAFT_TEMPLATE')


def _words(value):
    return set(re.findall(r"[a-z0-9']+", (value or '').lower()))


def _vague(subject):
    words = _words(subject)
    if not words or len((subject or '').strip()) < 3:
        return True
    if (subject or '').strip().lower() in {'as agreed', 'reasonable efforts'}:
        return True
    return bool(words & VAGUE)


def _when(terms):
    if terms['time']['deadline_text']:
        return terms['time']['deadline_text']
    if terms['time']['deadline'] is not None:
        return str(terms['time']['deadline'])
    return 'no deadline'


def _percent(bps):
    if bps % 100 == 0:
        return f'{bps // 100}%'
    return f'{bps} basis points'


def _diff(before, after, prefix=''):
    rows = []
    keys = sorted(set(before) | set(after))
    for key in keys:
        path = f'{prefix}.{key}' if prefix else key
        left = before.get(key)
        right = after.get(key)
        if type(left) is dict and type(right) is dict:
            rows.extend(_diff(left, right, path))
        elif left != right:
            rows.append({'path': path, 'before': left, 'after': right})
    return rows


def _scenario(terms, scenario, payer, payee, escrow, profit, loss, obligation, bearer, note):
    return {
        'scenario': scenario,
        'payer': payer,
        'payee': payee,
        'escrow': escrow,
        'profit': profit,
        'loss': loss,
        'obligation': obligation,
        'bearer': bearer,
        'lines': _lines(terms, payer, payee, escrow),
        'note': note,
    }


def _lines(terms, payer, payee, escrow):
    schedule = terms['schedule']
    quantity = terms['consideration']['quantity']
    if not schedule or quantity == 0:
        return []
    if payee == quantity and payer == 0 and escrow == 0:
        return [{'name': item['name'], 'payer': 0, 'payee': item['amount'], 'escrow': 0} for item in schedule]
    if payer == quantity and payee == 0 and escrow == 0:
        return [{'name': item['name'], 'payer': item['amount'], 'payee': 0, 'escrow': 0} for item in schedule]
    if payer == 0 and payee == 0 and escrow == quantity:
        return [{'name': item['name'], 'payer': 0, 'payee': 0, 'escrow': item['amount']} for item in schedule]
    return []
