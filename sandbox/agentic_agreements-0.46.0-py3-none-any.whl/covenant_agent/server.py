"""stdio MCP server for the agent-native verbs.

    python -m covenant_agent.server --keyless
    python -m covenant_agent.server --config host.json

The config file is owner-installed. If it contains a seed it must be mode 0600.
"""
import argparse
import json
import os
import stat
import sys
from pathlib import Path

from .codec import loads
from .errors import NativeError
from .barrier import present_to_model
from .mcp import HOST_VERSION, Host, Server, tool_error

MAX_INPUT = 16_000_000


def decode_request(raw):
    """Bounded tool JSON, separate from historical signed-object encoding.

    Draft renderings contain newlines. A request can carry those renderings
    without changing codec.loads/canonical or admitting new signed meanings.
    Envelopes and signing bodies still pass their original profile validators.
    """
    if type(raw) not in (str, bytes) or len(raw) > MAX_INPUT:
        raise NativeError('SIZE_LIMIT')
    def pairs(items):
        result = {}
        for name, value in items:
            if name in result:
                raise NativeError('DUPLICATE_KEY')
            result[name] = value
        return result
    def bad(_):
        raise NativeError('NONINTEGER_NUMBER')
    try:
        text = raw.decode('utf-8') if type(raw) is bytes else raw
        if text.startswith('\ufeff'):
            raise NativeError('JSON_BOM')
        value = json.loads(text, object_pairs_hook=pairs, parse_float=bad, parse_constant=bad)
        pending = [(value, 0)]; nodes = 0
        while pending:
            item, depth = pending.pop(); nodes += 1
            if depth > 40 or nodes > 500000:
                raise NativeError('DEPTH_LIMIT')
            if item is None or type(item) is bool:
                continue
            if type(item) is int:
                if abs(item) > 2**53 - 1:
                    raise NativeError('INTEGER_RANGE')
            elif type(item) is str:
                if len(item.encode('utf-8')) > 1_400_000:
                    raise NativeError('SIZE_LIMIT')
            elif type(item) is list:
                if len(item) > 20000:
                    raise NativeError('ARRAY_LIMIT')
                pending.extend((v, depth + 1) for v in item)
            elif type(item) is dict:
                if len(item) > 20000 or any(type(k) is not str or len(k) > 256 for k in item):
                    raise NativeError('MAP_KEY')
                pending.extend((v, depth + 1) for v in item.values())
            else:
                raise NativeError('TYPE')
        return value
    except NativeError:
        raise
    except (ValueError, RecursionError, UnicodeError) as exc:
        raise NativeError('INVALID_JSON') from exc


def load_config(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    info = os.fstat(fd)
    with os.fdopen(fd, 'rb') as stream:
        raw = stream.read(MAX_INPUT + 1)
    config = loads(raw)
    if type(config) is dict and (config.get('seed') or config.get('counterparty_seed')):
        if stat.S_IMODE(info.st_mode) & 0o077:
            raise NativeError('KEY_FILE_MODE')
    return config


def arguments():
    """The agent-native server's command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description='Agent-native Covenant MCP server')
    configs = parser.add_mutually_exclusive_group(required=True)
    configs.add_argument('--config', help='Owner host config. A file with a seed must be mode 0600.')
    configs.add_argument('--keyless', action='store_true', help='Discover and verify only. No signing key.')
    parser.add_argument('--legacy-config', help='Existing covenant-agent-tools config. Forwarded only by covenant_advanced.')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--once', action='store_true')
    mode.add_argument('--list-tools', action='store_true')
    mode.add_argument('--health', action='store_true',
                      help='check configuration and state, print a readiness report, exit 0 when ready')
    parser.add_argument('--log-json', action='store_true',
                        help='write redacted JSON-line operational logs to standard error')
    return parser


def _operator(name, args):
    """Operator tooling lives in covenant_chain; the SDK alone reports it as unavailable."""
    try:
        if name == 'health':
            from covenant_chain.ops_doctor import health_main
            return health_main('agent-native', args)
        from covenant_chain.observability import Log
        return Log('agent-native', sys.stderr)
    except ImportError:
        if name == 'health':
            print(json.dumps({'service': 'agent-native', 'status': 'not_ready',
                              'checks': {'operator_tooling': 'COVENANT_CHAIN_UNAVAILABLE'}}, sort_keys=True))
            return 1
        return None


def main(argv=None):
    args = arguments().parse_args(argv)
    if args.health:
        return _operator('health', args)
    log = _operator('log', args) if args.log_json else None
    try:
        if args.keyless:
            config = {'version': HOST_VERSION}
        else:
            config = load_config(args.config)
        legacy = None
        if args.legacy_config:
            from covenant_chain.agent_tools import AgentTools
            legacy = AgentTools(loads(Path(args.legacy_config).read_bytes()))
        host = Host(config, legacy=legacy)
        if args.list_tools:
            print(json.dumps({'tools': host.list_tools()}, sort_keys=True))
            return 0
        if args.once:
            request = decode_request(sys.stdin.buffer.read(MAX_INPUT + 1))
            if type(request) is not dict or set(request) != {'tool', 'arguments'}:
                raise NativeError('ARGUMENTS')
            print(json.dumps(present_to_model(host.call(request['tool'], request['arguments'])),
                             sort_keys=True, separators=(',', ':')))
            return 0
        server = Server(host)
        if log is not None:
            log.event('service_start', mode='keyless' if args.keyless else 'configured', pid=os.getpid())
        while True:
            raw = sys.stdin.buffer.readline(MAX_INPUT + 2)
            if not raw:
                return 0
            if len(raw) > MAX_INPUT + 1:
                sys.stdout.write(json.dumps({'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Message size limit'}}) + '\n')
                return 1
            try:
                request = decode_request(raw)
                reply = server.handle(request)
            except NativeError as exc:
                request = None
                reply = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': exc.code}}
            if log is not None:
                method = request.get('method') if type(request) is dict and type(request.get('method')) is str else 'invalid'
                failure = reply.get('error') if type(reply) is dict else None
                log.event('rpc', method=method[:64], outcome='jsonrpc_' + str(failure.get('code')) if type(failure) is dict else 'ok')
            if reply is not None:
                sys.stdout.write(json.dumps(reply, sort_keys=True, separators=(',', ':')) + '\n')
                sys.stdout.flush()
    except (NativeError, ValueError, TypeError, KeyError, OSError, UnicodeError) as exc:
        print(json.dumps(tool_error(exc), sort_keys=True), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
