"""Owner-selected data paths, before the durable MCP execution boundary.

No classifier can reliably detect instructions in arbitrary prose. This gate
constructs arguments from owner templates and specifically adopted signed data.
It does not sandbox the model, the process, the signer or the owner installation.
"""
from copy import deepcopy
import re
from .codec import canonical, digest, exact, verify, public_key, sign
from .errors import need

PROFILE = 'covenant-provenance-policy/0.1'
LABEL = 'COVENANT-PROVENANCE-FACT-0.1'


def fact(source, context, field, value, expiry):
    need(type(context) is str and type(field) is str and len(context) <= 256 and len(field) <= 256,
         'PROVENANCE_FIELD')
    need(type(expiry) is int and 0 <= expiry <= 2**53-1, 'PROVENANCE_TIME')
    result = {'source': source, 'context': context, 'field': field, 'value': deepcopy(value), 'expiry': expiry}
    canonical(result)
    return result


def sign_fact(private, context, field, value, expiry):
    body = fact(public_key(private), context, field, value, expiry)
    return {'body': body, 'signature': sign(private, LABEL, body)}


class ProvenanceGate:
    """Install locally; all argument keys are fixed or individually sourced.

    Dynamic source identities are trusted only for the particular field/context
    an owner chose. That trust can be mistaken; signatures prove attribution.
    Tiers add evidence requirements, not external atomicity or general authority.
    """
    def __init__(self, policy, *, agreement_verifier=None):
        exact(policy, 'profile alias tool descriptor tier fixed fields receipt_signers')
        need(policy['profile'] == PROFILE and type(policy['tier']) is int and 0 <= policy['tier'] <= 2, 'PROVENANCE_POLICY')
        need(type(policy['fixed']) is dict and type(policy['fields']) is dict and
             not set(policy['fixed']) & set(policy['fields']), 'PROVENANCE_POLICY')
        for name, rule in policy['fields'].items():
            exact(rule, 'source context field')
            need(all(type(v) is str for v in rule.values()), 'PROVENANCE_POLICY')
        need(type(policy['receipt_signers']) is list and len(set(policy['receipt_signers'])) == len(policy['receipt_signers']), 'PROVENANCE_POLICY')
        if policy['tier'] >= 1:
            need(bool(policy['receipt_signers']), 'PROVENANCE_RECEIPT_REQUIRED')
        need(agreement_verifier is None or callable(agreement_verifier), 'PROVENANCE_VERIFIER')
        self.policy = deepcopy(policy); self.pin = digest(PROFILE, policy)
        self.agreement_verifier = agreement_verifier

    def _unchanged(self):
        need(digest(PROFILE, self.policy) == self.pin, 'PROVENANCE_POLICY_CHANGED')

    def _intent(self, records, now, *, request_id=None, agreement=None):
        self._unchanged()
        p = deepcopy(self.policy)
        need(type(now) is int and 0 <= now <= 2**53-1 and type(records) is dict and
             set(records) == set(p['fields']), 'PROVENANCE_INPUTS')
        need((request_id is None and p['tier'] == 0) or
             type(request_id) is str and re.fullmatch(r'[A-Za-z0-9_.:-]{8,128}', request_id), 'PROVENANCE_OCCURRENCE')
        arguments = deepcopy(p['fixed'])
        for name, rule in p['fields'].items():
            record = records[name]; exact(record, 'body signature'); body = record['body']
            exact(body, 'source context field value expiry')
            need(all(body[k] == rule[k] for k in ('source', 'context', 'field')) and
                 type(body['expiry']) is int and now <= body['expiry'], 'PROVENANCE_SOURCE')
            need(canonical(fact(**body)) == canonical(body), 'PROVENANCE_FACT')
            verify(rule['source'], LABEL, body, record['signature'])
            arguments[name] = deepcopy(body['value'])
        intent = {'policy': self.pin, 'alias': p['alias'], 'tool': p['tool'], 'descriptor': p['descriptor'],
                  'arguments': arguments, 'agreement': agreement, 'request_id': request_id}
        self._unchanged()
        return p, intent

    def preview(self, records, now, *, request_id=None, agreement=None):
        """Exact unsigned receipt payload. No verifier, signer or dispatch runs."""
        p, intent = self._intent(records, now, request_id=request_id, agreement=agreement)
        return {'intent': intent, 'signing_payload': {'label': PROFILE+'-INTENT', 'body': deepcopy(intent)},
                'required_signers': deepcopy(p['receipt_signers']), 'signature_created': False,
                'agreement_verification': 'NOT_RUN', 'execution_authorized': False}

    def prepare(self, records, now, *, request_id=None, agreement=None, receipts=None):
        p, intent = self._intent(records, now, request_id=request_id, agreement=agreement)
        if p['tier'] >= 1:
            need(type(receipts) is list and len(receipts) == len(p['receipt_signers']), 'PROVENANCE_RECEIPT_REQUIRED')
            signers = set()
            for record in receipts:
                exact(record, 'signer signature')
                need(record['signer'] in p['receipt_signers'] and record['signer'] not in signers, 'PROVENANCE_RECEIPT_SIGNER')
                verify(record['signer'], PROFILE+'-INTENT', intent, record['signature']); signers.add(record['signer'])
        if p['tier'] == 2:
            need(agreement is not None and self.agreement_verifier is not None and
                 self.agreement_verifier(deepcopy(intent)) is True, 'PROVENANCE_AGREEMENT_NOT_ADOPTED')
        self._unchanged()
        return {'intent': intent, 'arguments': deepcopy(intent['arguments']), 'execution_authorized': False,
                'assurance': 'OWNER_SELECTED_SOURCES_AND_EXACT_TEMPLATE; ATTRIBUTION_NOT_TRUTH'}

    def call(self, client, records, now, *, request_id, agreement=None, receipts=None):
        prepared = self.prepare(records, now, request_id=request_id, agreement=agreement, receipts=receipts)
        intent = deepcopy(prepared['intent'])
        self._unchanged()
        need(client.servers.get(intent['alias'], {}).get('pins', {}).get(intent['tool']) == intent['descriptor'], 'PROVENANCE_DESCRIPTOR')
        self._unchanged()
        return client.call(intent['alias'], intent['tool'], intent['arguments'],
                           request_id=request_id, agreement=intent['agreement'])
