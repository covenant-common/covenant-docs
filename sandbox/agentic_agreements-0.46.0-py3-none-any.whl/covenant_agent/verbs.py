"""The five work-order verbs, plus one-call make and offline light verify.

propose, accept, deliver, verify and settle are the narrow waist. make packages
a signed proposal with its verdict. once() runs the happy path when both keys
are in this process. The chain is not contacted.
"""
from .codec import public_key
from .envelope import (
    PROFILE, TERMS_VERSION, VERBS, VERSION, accept, content_id, decide, deliver, open_dispute,
    propose, release_if_silent, settle, sign_mandate, verification_bundle, verify,
)
from .errors import REMEDIATION, need
from .light import light_verify
from .settlement import STABLECOINS

__all__ = ['discover', 'make', 'propose', 'accept', 'deliver', 'verify', 'settle', 'once',
           'light_verify', 'dispute', 'decide', 'advanced', 'sign_mandate', 'release_if_silent']


def discover():
    return {
        'version': VERSION,
        'verbs': list(VERBS),
        'one_call': 'covenant_make',
        'in_process_one_call': 'once',
        'light_verify': 'covenant_light_verify',
        'advanced': 'covenant_advanced',
        'find': 'covenant_find',
        'explain': 'covenant_explain',
        'next': 'covenant_next',
        'profiles': [PROFILE, TERMS_VERSION, 'covenant-bilateral/0.2', 'covenant-work-order/0.2'],
        'recommended_work_order_profile': 'covenant-bilateral/0.2',
        'historical_default': PROFILE,
        'rails': ['x402', 'ap2'],
        'units': sorted(STABLECOINS),
        'native_token_settlement': False,
        'chain_on_happy_path': False,
        'compiles_to': ['BIND', 'SHOW', 'DECIDE', 'CHALLENGE', 'RESOLVE', 'EXECUTE', 'RELEASE'],
        'service_alternative': ['SERVICE_BOOK', 'SERVICE_DECIDE', 'SERVICE_SETTLE'],
        'recourse': 'CHALLENGE then RESOLVE, or RELEASE under RELEASE_IF_UNDECIDED.',
        'parallel_status': False,
        'offline_verify': True,
        'execution_authorized': False,
        'ledger_touched': False,
        'chain_ledger_touched': False,
    }


def make(document=None, **kwargs):
    """One call for the proposer: signed terms, an assent request and a verdict."""
    proposed = propose(document, **kwargs)
    bundle = verification_bundle(proposed['envelope'])
    proposed['verification_bundle'] = bundle
    proposed['verdict'] = bundle['verdict']
    return proposed


def once(*, principal, counterparty, resolver, appeal_resolver, document, quantity, pay_to, deadline,
         delivery, ledger, unit='USDC', rail='x402', challenge_window=3600, network=None,
         executor=None, timeout='RELEASE_IF_UNDECIDED', effect='TRANSFER'):
    """Discover, make, sign, deliver, verify and settle. Both keys stay local.

    ``principal`` hires ``counterparty``. The chain ledger is not touched.
    ``ledger`` is the simulated stablecoin ledger, which does move.
    """
    found = discover()
    made = make(document, signer=principal, counterparty=public_key(counterparty), resolver=resolver,
                appeal_resolver=appeal_resolver, quantity=quantity, unit=unit, rail=rail, pay_to=pay_to,
                deadline=deadline, challenge_window=challenge_window, network=network, executor=executor,
                timeout=timeout, effect=effect)
    accepted = accept(made['envelope'], counterparty, ledger)
    delivered, raw = deliver(accepted, delivery, counterparty)
    settled = settle(delivered, principal, ledger, rail=rail)
    return {
        'version': VERSION,
        'discovered': found,
        'cid': settled['cid'],
        'verdict': settled['verdict'],
        'settlement': settled['settlement'],
        'envelope': settled['envelope'],
        'delivery_bytes': len(raw),
        'chain_ledger_touched': False,
        'ledger_touched': False,
        'payment_rail_touched': True,
        'execution_authorized': False,
        'feedback_hint': settled['feedback_hint'],
    }


def dispute(envelope, **kwargs):
    return open_dispute(envelope, **kwargs)


def advanced(action, *, legacy=None, tool=None, arguments=None):
    """Forward one legacy agent action. The old server still serves them directly."""
    need(action in ('list', 'call'), 'ARGUMENTS')
    if action == 'list':
        if legacy is None:
            return {'attached': False, 'tools': [], 'remediation': REMEDIATION['LEGACY_NOT_ATTACHED'],
                    'execution_authorized': False, 'ledger_touched': False}
        return {'attached': True, 'tools': [item['name'] for item in legacy.list_tools()],
                'execution_authorized': False, 'ledger_touched': False}
    need(legacy is not None, 'LEGACY_NOT_ATTACHED')
    need(type(tool) is str, 'ARGUMENTS')
    return legacy.call(tool, {} if arguments is None else arguments)


def addressed(envelope):
    return content_id(envelope)
