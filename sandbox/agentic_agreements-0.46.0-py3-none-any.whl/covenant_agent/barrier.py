"""Prompt barrier for text a model must not treat as instructions.

Biomimicry §12: tool results quote counterparty text as data with
``untrusted: true``. Instruction-shaped text and markup are withheld.
The signed envelope keeps its hash. This module does not change signed bytes
that the host stored; it only shapes the copy a model is shown.
"""
import hashlib

BARRIER_ID = 'biomimicry-12'
MODEL_TEXT_CAP = 512
_FENCE_END = '<<<END_UNTRUSTED_DATA>>>'
_MARKERS = (
    'ignore previous',
    'ignore all',
    'disregard previous',
    'disregard the',
    'system prompt',
    'you are now',
    'new instructions',
    'exfiltrate',
    'send the seed',
    'send your seed',
    'developer message',
    'do not follow the system',
)
_MARKUP = ('<', '>', 'javascript:', '</')


def _instruction_shaped(text):
    lowered = text.lower()
    if any(marker in lowered for marker in _MARKERS):
        return True
    return any(marker in lowered for marker in _MARKUP)


def quote_untrusted(text, role):
    """Quote one free-text field. The raw value is not copied when it is instruction-shaped."""
    if type(text) is not str or role not in ('document', 'delivery', 'content'):
        return {
            'untrusted': True, 'kind': 'DATA', 'role': 'document', 'sha256': None,
            'length': 0, 'cap': MODEL_TEXT_CAP, 'truncated': False,
            'withheld': 'INSTRUCTION_TEXT', 'followed_as_instructions': False,
            'prompt_barrier': BARRIER_ID, 'quoted': None,
        }
    raw = text.encode('utf-8', 'replace')
    digest = hashlib.sha256(raw).hexdigest()
    withheld = 'INSTRUCTION_TEXT' if _instruction_shaped(text) else None
    truncated = len(text) > MODEL_TEXT_CAP
    quoted = None
    if withheld is None:
        body = text[:MODEL_TEXT_CAP].replace('<<<', '<< <')
        quoted = f'<<<UNTRUSTED_DATA role={role}>>>\n{body}\n{_FENCE_END}'
    return {
        'untrusted': True,
        'kind': 'DATA',
        'role': role,
        'sha256': digest,
        'length': len(text),
        'cap': MODEL_TEXT_CAP,
        'truncated': truncated,
        'withheld': withheld,
        'followed_as_instructions': False,
        'prompt_barrier': BARRIER_ID,
        'quoted': quoted,
    }


def present_to_model(value):
    """Return a copy safe to place in a model context.

    Work-order ``document.text`` is replaced by its hash. ``delivery`` and
    ``content`` strings are removed. Both are attached as labeled quotes.
    Already-quoted ``untrusted`` lists are left as they are.
    """
    quotes = []

    def walk(node):
        if type(node) is list:
            return [walk(item) for item in node]
        if type(node) is not dict:
            return node
        if set(node) <= {'sha256', 'text'} and type(node.get('text')) is str and type(node.get('sha256')) is str:
            quotes.append(quote_untrusted(node['text'], 'document'))
            return {'sha256': node['sha256']}
        out = {}
        for key, item in node.items():
            if key == 'untrusted':
                out[key] = item
                continue
            if key in ('delivery', 'content') and type(item) is str:
                quotes.append(quote_untrusted(item, 'delivery' if key == 'delivery' else 'content'))
                continue
            out[key] = walk(item)
        return out

    shielded = walk(value)
    if type(shielded) is not dict or not quotes:
        return shielded
    existing = list(shielded.get('untrusted') or [])
    shielded = dict(shielded)
    shielded['untrusted'] = existing + quotes
    shielded['prompt_barrier'] = BARRIER_ID
    # The source CID continues to address the retained original bytes. Make
    # the text-stripped model projection's different content address explicit.
    if (type(value.get('envelope')) is dict and
            value['envelope'] != shielded.get('envelope')):
        from .cid import cid_from_bytes
        from .codec import canonical
        shielded['envelope_presentation'] = {
            'kind': 'TEXT_STRIPPED_PROJECTION',
            'source_cid': cid_from_bytes(canonical(value['envelope'])),
            'presented_cid': cid_from_bytes(canonical(shielded['envelope'])),
            'source_bytes_included': False,
            'instruction': 'Retain the original document separately. The source CID addresses original bytes; the presented CID addresses the returned envelope.',
        }
    return shielded
