"""Agent-initiated Stripe payments, refunds and outcome custody beside the owner Checkout gateway.

covenant_agent.stripe_gateway (profile covenant-stripe-checkout/0.1) lets a
payer finish an exact, payer-approved hosted Checkout and keeps conservative
custody in one owner directory. This module adds what that profile does not
do, in the same custody directory, under the same lock, with the same restricted
key transport and inside the same aggregate commitment budget:

* PaymentIntents an agent asks for (covenant-stripe-payment-action/0.1), paid
  with a Shared Payment Token or a saved payment method, then captured or
  cancelled; refunds, full or partial, of these payments and of Checkout ones.
* Checks before any provider call: an owner-signed payment policy, the agent's
  delegation grant (covenant-delegation-grant/0.1), the payer's exact
  authorisation and, above the owner's adopted threshold
  (covenant-assent-policy/0.1), a fresh owner approval of the exact action,
  consumed once.
* Durable reservations per agreement, per counterparty and per rolling period.
  A refusal before execution releases them. An UNKNOWN outcome keeps them and
  blocks any retry, any new Checkout and any other rail for the agreement and
  the payer until it is reconciled.
* Status-aware replies: a decline or a refusal before execution is FAILED; a
  timeout, a lost reply, 409, 424 or 5xx is UNKNOWN. Reconciliation retrieves
  the object by id, by metadata search, or by a same-key replay the owner asks
  for inside Stripe's 24-hour idempotency window. An event never moves state by
  itself; it triggers retrieval.
* An append-only evidence chain per agreement and a portable record whose
  signatures verify offline. Delivery stays separate; nothing marks a deal
  complete.

Provider replies are the owner's observations, not proof a third party can
verify. Codex's Checkout profile, policy and signed bytes are unchanged.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import time
from urllib.parse import urlencode, urlsplit

from covenant_chain import access_mechanisms as access
from covenant_chain.crypto import canonical, digest, exact, integer, key, need, public_key, sign, verify
from covenant_chain.secure_execution import SecretVault

from . import assent_gate, stripe_action as action
from .stripe_action import REMEDIATION as ACTION_REMEDIATION
from .stripe_gateway import MAX_BODY, StripeGateway, StripeHTTPTransport, _parse, _provider_id, effect_id
from .stripe_gateway import REMEDIATION as GATEWAY_REMEDIATION

POLICY_VERSION = 'covenant-stripe-payment-policy/0.1'
REQUEST_VERSION = 'covenant-stripe-payment-approval-request/0.1'
APPROVAL_VERSION = 'covenant-stripe-payment-approval/0.1'
RESOLUTION_VERSION = 'covenant-stripe-payment-resolution/0.1'
EVIDENCE_VERSION = 'covenant-stripe-payment-evidence/0.1'
RECORD_VERSION = 'covenant-stripe-payment-record/0.1'
POLICY_LABEL = 'COVENANT-STRIPE-PAYMENT-POLICY-0.1'
APPROVAL_LABEL = 'COVENANT-STRIPE-PAYMENT-APPROVAL-0.1'
RESOLUTION_LABEL = 'COVENANT-STRIPE-PAYMENT-RESOLUTION-0.1'
EVIDENCE_LABEL = 'COVENANT-STRIPE-PAYMENT-EVIDENCE-0.1'
LINK_LABEL = 'COVENANT-STRIPE-PAYMENT-EVIDENCE-LINK-0.1'
CREDENTIAL_LABEL = 'COVENANT-STRIPE-PAYMENT-CREDENTIAL-0.1'
GRANT_OPERATION = 'EXECUTE_STRIPE_PAYMENT_ACTION'
GRANT_TARGET = 'stripe-payment-gateway'
STATES = ('PREPARED', 'RESERVED', 'SUBMITTED', 'SUCCEEDED', 'FAILED', 'UNKNOWN', 'RECONCILED')
OPEN = ('PREPARED', 'RESERVED', 'SUBMITTED', 'UNKNOWN')
PAYMENT_STATUSES = ('requires_payment_method', 'requires_confirmation', 'requires_action', 'processing',
                    'requires_capture', 'canceled', 'succeeded')
REFUND_STATUSES = ('pending', 'requires_action', 'succeeded', 'failed', 'canceled')
CLOSED_DISPUTES = ('won', 'lost', 'warning_closed', 'prevented')
EVENT_TYPES = ('payment_intent.succeeded', 'payment_intent.payment_failed', 'payment_intent.processing',
               'payment_intent.canceled', 'payment_intent.requires_action', 'payment_intent.amount_capturable_updated',
               'refund.created', 'refund.updated', 'refund.failed', 'charge.refunded', 'charge.refund.updated',
               'charge.dispute.created', 'charge.dispute.updated', 'charge.dispute.closed',
               'charge.dispute.funds_withdrawn', 'charge.dispute.funds_reinstated')
EXTERNAL_KINDS = ('AAP_DISPUTE_OPENED', 'AAP_DISPUTE_UPDATED', 'AAP_DISPUTE_EVIDENCE_STAGED')
REPLAY_WINDOW = 82800  # 23 hours: inside the 24 hours Stripe keeps an idempotency key.
MAX_OPERATIONS = 100000
MAX_EVIDENCE = 400000
MAX_EVENTS = 200000
MAX_PENDING = 64
MAX_INTEGER = 2**53 - 1
TOKEN = re.compile(r'[A-Za-z0-9_.-]{1,128}\Z')
NONE = '0' * 64


def remediation(code):
    """What happened and what to do for a code the payment modules raise; Checkout codes keep the gateway's words."""
    return GATEWAY_REMEDIATION.get(code) or ACTION_REMEDIATION.get(code)


class Refusal(ValueError):
    """A stable code (str(error) is the code) and, for an owner step, the details needed to take it."""

    def __init__(self, code, details=None):
        super().__init__(code)
        self.code = code
        self.details = deepcopy(details) if details else {}


def _fields(value, names, code):
    need(type(value) is dict and set(value) == set(names.split()), code)


def _int(value, minimum=0, maximum=MAX_INTEGER):
    return value if type(value) is int and minimum <= value <= maximum else None


def _token(value):
    return value if type(value) is str and TOKEN.fullmatch(value) else None


def _object_id(value, prefix):
    if type(value) is dict:
        value = value.get('id')
    try:
        return _provider_id(value, prefix)
    except ValueError:
        return None


# ---------------------------------------------------------------- transport

class StripePaymentTransport(StripeHTTPTransport):
    """The owner Checkout transport, with replies that keep their HTTP status.

    StripeHTTPTransport.request() turns every non-2xx reply into
    STRIPE_PROVIDER_HTTP, which suits Checkout creation. A charge needs the
    status: a 402 decline and a refusal before execution are definite, while 409,
    424, 5xx, a timeout or a lost reply leave the outcome UNKNOWN. The fixed
    origin, loopback harness, mode, restricted-key, timeout and Stripe-Version
    rules are inherited unchanged, and this class can serve Checkout too.
    """

    def _secret(self):
        try:
            secret = self._credential()
        except BaseException:
            raise ValueError('STRIPE_CREDENTIAL_UNAVAILABLE') from None
        prefix = ('rk_live_',) if self.livemode else ('rk_test_', 'rkcs_test_')
        need(type(secret) is str and secret.startswith(prefix) and len(secret) <= 512 and
             re.fullmatch(r'[A-Za-z0-9_]+', secret), 'STRIPE_RESTRICTED_CREDENTIAL_MODE')
        return secret

    def exchange(self, method, path, *, data=None, idempotency=None, version=None):
        """One request; {status, body, sha256, replayed, should_retry, reason}. Never raises for the network."""
        import http.client
        import ssl
        need(method in ('GET', 'POST') and type(path) is str and path[:4] == '/v1/' and path[:5] != '/v1//' and
             len(path) <= 2048 and all(32 < ord(c) < 127 for c in path), 'STRIPE_REQUEST')
        need(version is None or version in action.API_VERSIONS, 'STRIPE_PAYMENT_API_VERSION')
        secret = self._secret()
        headers = {'Authorization': 'Bearer ' + secret, 'Stripe-Version': version or self.API_VERSION,
                   'Accept': 'application/json'}
        body = None
        if data is not None:
            body = urlencode(data).encode('ascii')
            need(len(body) <= 16384, 'STRIPE_REQUEST_SIZE')
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
        if idempotency is not None:
            key(idempotency)
            headers['Idempotency-Key'] = idempotency
        u = urlsplit(self.origin)
        connection = (http.client.HTTPConnection(u.hostname, u.port, timeout=self.timeout) if self.harness else
                      http.client.HTTPSConnection(u.hostname, timeout=self.timeout, context=ssl.create_default_context()))
        reply = {'status': None, 'body': None, 'sha256': None, 'replayed': False, 'should_retry': None,
                 'reason': 'NO_RESPONSE'}
        try:
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            raw = response.read(MAX_BODY + 1)
            reply.update(status=response.status, sha256=hashlib.sha256(raw).hexdigest(),
                         replayed=response.getheader('Idempotent-Replayed') == 'true',
                         should_retry={'true': True, 'false': False}.get(response.getheader('Stripe-Should-Retry')),
                         reason=None)
        except (OSError, http.client.HTTPException):
            return reply
        finally:
            connection.close()
            del secret
        if len(raw) > MAX_BODY:
            reply.update(reason='RESPONSE_SIZE')
            return reply
        try:
            reply['body'] = _parse(raw)
        except ValueError:
            reply['reason'] = 'RESPONSE_MALFORMED'
        return reply


# ---------------------------------------------------------------- owner policy

def policy_body(*, checkout_policy, principal, budgets, approval_policies=(), operations=action.OPERATIONS,
                sources=action.SOURCES, api_versions=action.API_VERSIONS, maximum_action_seconds=86400,
                webhook_tolerance=300, sequence=1, not_before=0, expires=MAX_INTEGER, nonce=None):
    """An exact payment policy for the owner (principal) to sign; it pins the adopted Checkout policy.

    budgets: [{operation: pay|refund, per_agreement, per_counterparty, per_period, period}] in minor
    units of the Checkout policy currency; per_counterparty and per_period roll over ``period`` seconds.
    """
    body = {'version': POLICY_VERSION, 'checkout_policy': checkout_policy, 'principal': principal,
            'sequence': sequence, 'approval_policies': sorted(approval_policies),
            'operations': sorted(operations), 'sources': sorted(sources), 'api_versions': sorted(api_versions),
            'budgets': sorted(deepcopy(list(budgets)), key=lambda row: row.get('operation', '') if type(row) is dict else ''),
            'maximum_action_seconds': maximum_action_seconds, 'webhook_tolerance': webhook_tolerance,
            'not_before': not_before, 'expires': expires, 'nonce': secrets.token_hex(32) if nonce is None else nonce}
    return validate_policy(body)


def validate_policy(body):
    code = 'STRIPE_PAYMENT_POLICY'
    _fields(body, 'version checkout_policy principal sequence approval_policies operations sources api_versions '
            'budgets maximum_action_seconds webhook_tolerance not_before expires nonce', code)
    need(body['version'] == POLICY_VERSION, code)
    for name in ('checkout_policy', 'nonce'):
        need(type(body[name]) is str and action.HEX.fullmatch(body[name]) is not None, code)
    action._party(body['principal'])
    need(_int(body['sequence'], 1) is not None, code)
    for name, allowed in (('operations', action.OPERATIONS), ('sources', action.SOURCES),
                          ('api_versions', action.API_VERSIONS)):
        values = body[name]
        need(type(values) is list and values and values == sorted(set(values)) and set(values) <= set(allowed), code)
    approvals = body['approval_policies']
    need(type(approvals) is list and len(approvals) <= 16 and approvals == sorted(set(approvals)) and
         all(type(v) is str and action.HEX.fullmatch(v) for v in approvals), code)
    budgets = body['budgets']
    need(type(budgets) is list and len(budgets) <= 2, code)
    seen = []
    for row in budgets:
        _fields(row, 'operation per_agreement per_counterparty per_period period', code)
        need(row['operation'] in ('pay', 'refund') and row['operation'] not in seen, code)
        for name in ('per_agreement', 'per_counterparty', 'per_period'):
            need(_int(row[name], 1, action.MAX_AMOUNT * 1000) is not None, code)
        need(_int(row['period'], 60, 31622400) is not None, code)
        seen.append(row['operation'])
    need(seen == sorted(seen), code)
    for operation in ('pay', 'refund'):
        need(operation not in body['operations'] or operation in seen, 'STRIPE_PAYMENT_BUDGET_MISSING')
    need(_int(body['maximum_action_seconds'], 60, 604800) is not None, code)
    need(_int(body['webhook_tolerance'], 1, 300) is not None, code)
    need(_int(body['not_before']) is not None and _int(body['expires']) is not None and
         body['not_before'] < body['expires'], code)
    canonical(body)
    return body


def policy_id(body):
    return digest(POLICY_LABEL, validate_policy(body))


def sign_policy(body, principal_private):
    validate_policy(body)
    need(public_key(principal_private) == body['principal'], 'STRIPE_PAYMENT_POLICY')
    return {'body': deepcopy(body), 'signature': sign(principal_private, POLICY_LABEL, body)}


def verify_policy(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'STRIPE_PAYMENT_POLICY')
    body = validate_policy(record['body'])
    try:
        verify(body['principal'], POLICY_LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('STRIPE_PAYMENT_POLICY') from None
    return deepcopy(body)


def credential_policy(policy, transport):
    """The credential class an action requires: a restricted key of this mode, origin and scope."""
    validate_policy(policy)
    return digest(CREDENTIAL_LABEL, {'credential': 'STRIPE_RESTRICTED_KEY', 'livemode': transport.livemode,
                                     'origin': transport.origin, 'assurance': transport.assurance,
                                     'operations': policy['operations'], 'api_versions': policy['api_versions']})


# ---------------------------------------------------------------- delegation grants

def grant_scope(gateway_pin):
    key(gateway_pin)
    return {'context': gateway_pin, 'target': {'kind': GRANT_TARGET, 'id': gateway_pin}, 'operation': GRANT_OPERATION}


def issue_grant(gateway_pin, issuer_private, agent, operations, *, not_before, expires, nonce=None,
                delegable=False, parent=None):
    """An owner-signed covenant-delegation-grant/0.1 envelope with stripe:<operation> capabilities."""
    scope = grant_scope(gateway_pin)
    need(type(operations) in (list, tuple) and operations and set(operations) <= set(action.OPERATIONS),
         'STRIPE_PAYMENT_GRANT')
    made = access.grant(scope['context'], scope['target'], scope['operation'], public_key(issuer_private), agent,
                        sorted('stripe:' + name for name in set(operations)), not_before, expires,
                        secrets.token_hex(32) if nonce is None else nonce, delegable=delegable, parent=parent)
    return {'grant': made['grant'], 'signature': sign(issuer_private, made['label'], made['body'])}


def grant_leaf(chain):
    need(type(chain) in (list, tuple) and chain and type(chain[-1]) is dict, 'STRIPE_PAYMENT_GRANT')
    try:
        return access.grant_id(chain[-1]['grant'])
    except (KeyError, TypeError, ValueError):
        raise ValueError('STRIPE_PAYMENT_GRANT') from None


# ---------------------------------------------------------------- owner approvals and resolutions

def validate_request(request):
    code = 'STRIPE_PAYMENT_APPROVAL_FIELDS'
    _fields(request, 'version policy gateway action rendering operation amount currency payer agreement '
            'occurrence issued_at expires_at', code)
    need(request['version'] == REQUEST_VERSION and request['operation'] in ('pay', 'refund'), code)
    for name in ('policy', 'gateway', 'action', 'rendering', 'agreement', 'occurrence', 'payer'):
        need(type(request[name]) is str and action.HEX.fullmatch(request[name]) is not None, code)
    need(_int(request['amount'], 1, action.MAX_AMOUNT) is not None and type(request['currency']) is str and
         action.CURRENCY.fullmatch(request['currency']) is not None, code)
    need(_int(request['issued_at']) is not None and _int(request['expires_at']) is not None and
         request['issued_at'] <= request['expires_at'], code)
    canonical(request)
    return request


def _approval_body(decision, request):
    need(decision in ('APPROVE', 'REFUSE'), 'STRIPE_PAYMENT_APPROVAL_FIELDS')
    validate_request(request)
    return {'decision': decision, 'request': deepcopy(request)}


def sign_approval(request, approval_private, decision='APPROVE'):
    """An OWNER_KEY decision. Run by the owner's own tool; the key never reaches the agent host."""
    body = _approval_body(decision, request)
    return {'version': APPROVAL_VERSION, 'decision': decision, 'request': deepcopy(request), 'method': 'OWNER_KEY',
            'proof': {'key': public_key(approval_private), 'signature': sign(approval_private, APPROVAL_LABEL, body)}}


def passkey_challenge(request, decision='APPROVE'):
    """The WebAuthn challenge a PASSKEY approval signs: base64url SHA-256 of the labelled decision."""
    from covenant_chain.signin import passkey_challenge as challenge
    return challenge({'label': APPROVAL_LABEL, **_approval_body(decision, request)})


def passkey_approval(request, assertion, decision='APPROVE'):
    _approval_body(decision, request)
    need(type(assertion) is dict, 'STRIPE_PAYMENT_APPROVAL_FIELDS')
    return {'version': APPROVAL_VERSION, 'decision': decision, 'request': deepcopy(request), 'method': 'PASSKEY',
            'proof': deepcopy(assertion)}


def _check_proof(record, policy):
    """Verify an approval decision against an owner-adopted assent policy; returns the passkey counter or None."""
    _fields(record, 'version decision request method proof', 'STRIPE_PAYMENT_APPROVAL_FIELDS')
    need(record['version'] == APPROVAL_VERSION, 'STRIPE_PAYMENT_APPROVAL_FIELDS')
    body = _approval_body(record['decision'], record['request'])
    method = policy['method']
    need(record['method'] == method['kind'], 'STRIPE_PAYMENT_APPROVAL_METHOD')
    proof = record['proof']
    if method['kind'] == 'OWNER_KEY':
        _fields(proof, 'key signature', 'STRIPE_PAYMENT_APPROVAL_FIELDS')
        need(proof['key'] == method['key'], 'STRIPE_PAYMENT_APPROVAL_SIGNATURE')
        try:
            verify(proof['key'], APPROVAL_LABEL, body, proof['signature'])
        except ValueError:
            raise ValueError('STRIPE_PAYMENT_APPROVAL_SIGNATURE') from None
        return None
    from covenant_chain.signin import verify_passkey_assertion
    _fields(proof, 'credential_id client_data_json authenticator_data signature', 'STRIPE_PAYMENT_APPROVAL_FIELDS')
    registration = {'credential_id': method['credential_id'], 'rp_id': method['rp_id'],
                    'public_key': method['public_key']}
    try:
        verify_passkey_assertion({'label': APPROVAL_LABEL, **body}, proof, registration, origin=method['origin'],
                                 require_user_verification=method['user_verification'])
        import base64
        raw = base64.urlsafe_b64decode(proof['authenticator_data'] + '=' * (-len(proof['authenticator_data']) % 4))
    except (ValueError, TypeError, KeyError):
        raise ValueError('STRIPE_PAYMENT_APPROVAL_PASSKEY') from None
    return (method['credential_id'], int.from_bytes(raw[33:37], 'big'))


def resolution_body(operation_id, decision, basis, at, principal, provider_ref=None):
    """An owner's signed reconciliation of an UNKNOWN operation after checking outside the gateway."""
    body = {'version': RESOLUTION_VERSION, 'operation': operation_id, 'decision': decision, 'basis': basis,
            'at': at, 'principal': principal, 'provider_ref': provider_ref}
    _resolution(body)
    return body


def _resolution(body):
    code = 'STRIPE_PAYMENT_RESOLUTION'
    _fields(body, 'version operation decision basis at principal provider_ref', code)
    need(body['version'] == RESOLUTION_VERSION and body['decision'] in ('NOT_EXECUTED', 'EXECUTED'), code)
    need(type(body['operation']) is str and action.HEX.fullmatch(body['operation']) is not None, code)
    need(type(body['basis']) is str and 0 < len(body['basis']) <= 256 and
         all(32 <= ord(c) <= 126 for c in body['basis']), code)
    need(_int(body['at']) is not None, code)
    action._party(body['principal'])
    need((body['decision'] == 'EXECUTED') == (body['provider_ref'] is not None), code)
    if body['provider_ref'] is not None:
        need(_object_id(body['provider_ref'], 'pi_') or _object_id(body['provider_ref'], 're_'), code)
    return body


def sign_resolution(body, principal_private):
    _resolution(body)
    need(public_key(principal_private) == body['principal'], 'STRIPE_PAYMENT_RESOLUTION')
    return {'body': deepcopy(body), 'signature': sign(principal_private, RESOLUTION_LABEL, body)}


# ---------------------------------------------------------------- webhook authentication

def verify_signature(raw_body, header, secret, now, tolerance=300):
    """Stripe-Signature over the exact raw body (docs.stripe.com/webhooks).

    HMAC-SHA256 with the endpoint secret over ``t + "." + body``; only v1 counts
    (v0 is Stripe's test-only scheme), every v1 value is compared in constant time,
    and the timestamp must lie within the tolerance of the owner clock. ``secret``
    is an owner callable returning one whsec_ value, or two while a secret rolls.
    Error codes match the Checkout gateway's own check.
    """
    need(callable(secret), 'STRIPE_WEBHOOK_SECRET_REQUIRED')
    need(type(raw_body) is bytes and len(raw_body) <= MAX_BODY and type(header) is str and len(header) <= 4096,
         'STRIPE_WEBHOOK_INPUT')
    need(type(tolerance) is int and 1 <= tolerance <= 300, 'STRIPE_WEBHOOK_TOLERANCE')
    stamps, signatures = [], []
    for field in header.split(','):
        name, separator, value = field.partition('=')
        need(separator and name in ('t', 'v1', 'v0'), 'STRIPE_WEBHOOK_SIGNATURE')
        if name == 't':
            need(value.isascii() and value.isdigit() and len(value) <= 12, 'STRIPE_WEBHOOK_SIGNATURE')
            stamps.append(int(value))
        elif name == 'v1':
            need(re.fullmatch('[0-9a-f]{64}', value) is not None, 'STRIPE_WEBHOOK_SIGNATURE')
            signatures.append(value)
    need(type(now) is int and len(stamps) == 1 and 1 <= len(signatures) <= 8 and abs(now - stamps[0]) <= tolerance,
         'STRIPE_WEBHOOK_STALE_OR_INVALID')
    try:
        values = secret()
    except BaseException:
        raise ValueError('STRIPE_WEBHOOK_SECRET_UNAVAILABLE') from None
    values = [values] if type(values) is str else values
    need(type(values) in (list, tuple) and 1 <= len(values) <= 2 and
         all(type(v) is str and v.startswith('whsec_') and len(v) <= 512 and re.fullmatch(r'[A-Za-z0-9_]+', v)
             for v in values), 'STRIPE_WEBHOOK_SECRET')
    message = str(stamps[0]).encode('ascii') + b'.' + raw_body
    matched = False
    for value in values:
        expected = hmac.new(value.encode('ascii'), message, hashlib.sha256).hexdigest()
        for signature in signatures:
            matched = hmac.compare_digest(expected, signature) or matched
    need(matched, 'STRIPE_WEBHOOK_SIGNATURE')
    return stamps[0]


# ---------------------------------------------------------------- gateway extension

class StripePayments:
    """Agent payment actions in the owner's Stripe custody directory.

    Pass an opened covenant_agent.stripe_gateway.StripeGateway whose transport is a
    StripePaymentTransport. Everything here shares that gateway's SQLite file,
    cross-process lock and aggregate budget; Checkout behaviour is unchanged.
    Owner methods (sources, approvals, resolutions, revocation, backup) belong
    to the owner process, never to an agent tool.
    """

    def __init__(self, gateway, policy_record, *, approval_policies=(), sources=None, clock=None,
                 webhook_secret=None, spend_observer=None, outcome_observer=None, evidence_observer=None):
        need(isinstance(gateway, StripeGateway), 'STRIPE_PAYMENT_GATEWAY')
        need(isinstance(gateway.transport, StripePaymentTransport), 'STRIPE_PAYMENT_TRANSPORT')
        policy = verify_policy(policy_record)
        need(policy['checkout_policy'] == gateway.pin, 'STRIPE_PAYMENT_POLICY_PIN')
        for hook in (clock, webhook_secret, spend_observer, outcome_observer, evidence_observer):
            need(hook is None or callable(hook), 'STRIPE_PAYMENT_FIELD')
        self.gateway, self.transport, self.db = gateway, gateway.transport, gateway.db
        self.checkout_policy = deepcopy(gateway.policy)
        self.record, self.policy, self.id = deepcopy(policy_record), policy, policy_id(policy)
        self.approvals = {}
        for record in approval_policies:
            try:
                body = assent_gate.verify_policy(record)
            except ValueError:
                raise ValueError('STRIPE_PAYMENT_APPROVAL_POLICY') from None
            ident = assent_gate.policy_id(body)
            need(body['owner'] == policy['principal'] and ident in policy['approval_policies'] and
                 body['signer'] not in self.approvals, 'STRIPE_PAYMENT_APPROVAL_POLICY')
            self.approvals[body['signer']] = (ident, body, deepcopy(record))
        need(sorted(row[0] for row in self.approvals.values()) == policy['approval_policies'],
             'STRIPE_PAYMENT_APPROVAL_POLICY')
        self.sources = SecretVault() if sources is None else sources
        need(isinstance(self.sources, SecretVault), 'STRIPE_PAYMENT_FIELD')
        self._clock = clock or (lambda: int(time.time()))
        self._webhook_secret = webhook_secret if webhook_secret is not None else gateway._webhook_secret
        self._spend_observer, self._outcome_observer = spend_observer, outcome_observer
        self._evidence_observer = evidence_observer
        self.observer_failures = 0  # outcome observer calls that raised; counted, never allowed to change an outcome
        self.credential_policy = credential_policy(policy, self.transport)
        with self.gateway._exclusive():
            self._schema()
            self._adopt()

    def __repr__(self):
        return '<StripePayments owner custody; credentials and sources redacted>'

    def observe_evidence(self, observer):
        """Install the owner's evidence observer (for example covenant_agent.stripe_disputes.Chargebacks)."""
        need(observer is None or callable(observer), 'STRIPE_PAYMENT_FIELD')
        self._evidence_observer = observer

    # -------------------------------------------------------- storage

    def _schema(self):
        for statement in (
                'CREATE TABLE IF NOT EXISTS stripe_payment_meta(name TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_policies(id TEXT PRIMARY KEY, sequence INTEGER NOT NULL, '
                'record TEXT NOT NULL, adopted_at INTEGER NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_operations(id TEXT PRIMARY KEY, action TEXT NOT NULL, '
                'record TEXT NOT NULL, authorization TEXT, chain TEXT NOT NULL, operation TEXT NOT NULL, '
                'agreement TEXT NOT NULL, payer TEXT NOT NULL, target TEXT, amount INTEGER NOT NULL, '
                'state TEXT NOT NULL, outcome TEXT, code TEXT, provider_ref TEXT, provider_status TEXT, '
                'approval TEXT, facts TEXT NOT NULL, created_at INTEGER NOT NULL, submitted_at INTEGER, '
                'updated_at INTEGER NOT NULL, attempts INTEGER NOT NULL) STRICT',
                'CREATE INDEX IF NOT EXISTS stripe_payment_operations_agreement ON stripe_payment_operations(agreement)',
                'CREATE INDEX IF NOT EXISTS stripe_payment_operations_payer ON stripe_payment_operations(payer, state)',
                'CREATE INDEX IF NOT EXISTS stripe_payment_operations_target ON stripe_payment_operations(target)',
                'CREATE TABLE IF NOT EXISTS stripe_payment_reservations(operation TEXT NOT NULL, bucket TEXT NOT NULL, '
                'amount INTEGER NOT NULL, at INTEGER NOT NULL, PRIMARY KEY(operation, bucket)) STRICT',
                'CREATE INDEX IF NOT EXISTS stripe_payment_reservations_bucket ON stripe_payment_reservations(bucket, at)',
                'CREATE TABLE IF NOT EXISTS stripe_payment_approvals(occurrence TEXT PRIMARY KEY, action TEXT NOT NULL, '
                'status TEXT NOT NULL, request TEXT NOT NULL, body TEXT NOT NULL, decision TEXT, '
                'issued_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, consumed_by TEXT) STRICT',
                'CREATE INDEX IF NOT EXISTS stripe_payment_approvals_action ON stripe_payment_approvals(action)',
                'CREATE TABLE IF NOT EXISTS stripe_payment_counters(credential TEXT PRIMARY KEY, '
                'sign_count INTEGER NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_events(id TEXT PRIMARY KEY, digest TEXT NOT NULL, '
                'type TEXT NOT NULL, route TEXT, reference TEXT, received_at INTEGER NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_observed(object TEXT PRIMARY KEY, state TEXT NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_disputes(id TEXT PRIMARY KEY, agreement TEXT NOT NULL, '
                'route TEXT NOT NULL, reference TEXT NOT NULL, payer TEXT NOT NULL, status TEXT NOT NULL, '
                'facts TEXT NOT NULL, updated_at INTEGER NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_revoked(grant_id TEXT PRIMARY KEY, at INTEGER NOT NULL) STRICT',
                'CREATE TABLE IF NOT EXISTS stripe_payment_evidence(sequence INTEGER PRIMARY KEY, agreement TEXT NOT NULL, '
                'id TEXT UNIQUE NOT NULL, previous TEXT NOT NULL, link TEXT UNIQUE NOT NULL, kind TEXT NOT NULL, '
                'operation TEXT, body TEXT NOT NULL) STRICT',
                'CREATE INDEX IF NOT EXISTS stripe_payment_evidence_agreement ON stripe_payment_evidence(agreement, sequence)'):
            self.db.execute(statement)
        for verb in ('UPDATE', 'DELETE'):
            self.db.execute(f'CREATE TRIGGER IF NOT EXISTS stripe_payment_evidence_no_{verb.lower()} BEFORE {verb} '
                            f"ON stripe_payment_evidence BEGIN SELECT RAISE(ABORT,'STRIPE_PAYMENT_APPEND_ONLY'); END")

    @contextmanager
    def _transaction(self):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield self.db
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
        self.db.execute('COMMIT')

    def _now(self):
        now = self._clock()
        need(type(now) is int and 0 < now <= MAX_INTEGER, 'STRIPE_PAYMENT_FIELD')
        return now

    def _adopt(self):
        now = self._now()
        with self._transaction() as db:
            row = db.execute("SELECT value FROM stripe_payment_meta WHERE name='principal'").fetchone()
            if row is None:
                db.execute("INSERT INTO stripe_payment_meta VALUES ('principal', ?)", (self.policy['principal'],))
            else:
                need(row[0] == self.policy['principal'], 'STRIPE_PAYMENT_POLICY_ROLLBACK')
            newest = db.execute('SELECT max(sequence) FROM stripe_payment_policies').fetchone()[0]
            known = db.execute('SELECT sequence FROM stripe_payment_policies WHERE id=?', (self.id,)).fetchone()
            if known is None:
                need(newest is None or self.policy['sequence'] > newest, 'STRIPE_PAYMENT_POLICY_ROLLBACK')
                db.execute('INSERT INTO stripe_payment_policies VALUES (?, ?, ?, ?)',
                           (self.id, self.policy['sequence'], canonical(self.record).decode('ascii'), now))
            else:
                need(known[0] == newest, 'STRIPE_PAYMENT_POLICY_ROLLBACK')

    def _row(self, operation_id):
        found = self.db.execute('SELECT id, action, record, authorization, chain, operation, agreement, payer, target, '
                                'amount, state, outcome, code, provider_ref, provider_status, approval, facts, '
                                'created_at, submitted_at, updated_at, attempts FROM stripe_payment_operations '
                                'WHERE id=?', (operation_id,)).fetchone()
        if found is None:
            return None
        names = ('id action record authorization chain operation agreement payer target amount state outcome code '
                 'provider_ref provider_status approval facts created_at submitted_at updated_at attempts').split()
        row = dict(zip(names, found))
        for name in ('record', 'authorization', 'chain', 'facts'):
            row[name] = None if row[name] is None else json.loads(row[name])
        row['body'] = row['record']['body']
        return row

    def _rows(self, where, arguments):
        ids = [value for (value,) in self.db.execute(
            'SELECT id FROM stripe_payment_operations WHERE ' + where + ' ORDER BY created_at, rowid', arguments)]
        return [self._row(ident) for ident in ids]

    def _evidence(self, db, agreement, kind, operation, body):
        count = db.execute('SELECT count(*) FROM stripe_payment_evidence').fetchone()[0]
        need(count < MAX_EVIDENCE, 'STRIPE_PAYMENT_STORE_FULL')
        last = db.execute('SELECT link FROM stripe_payment_evidence WHERE agreement=? ORDER BY sequence DESC LIMIT 1',
                          (agreement,)).fetchone()
        previous = last[0] if last else NONE
        record = {'version': EVIDENCE_VERSION, 'agreement': agreement, 'previous': previous, 'kind': kind,
                  'operation': operation, 'at': self._now(), 'body': deepcopy(body)}
        ident = digest(EVIDENCE_LABEL, record)
        link = digest(LINK_LABEL, {'previous': previous, 'evidence': ident})
        db.execute('INSERT INTO stripe_payment_evidence(agreement, id, previous, link, kind, operation, body) '
                   'VALUES (?, ?, ?, ?, ?, ?, ?)', (agreement, ident, previous, link, kind, operation,
                                                    canonical(record).decode('ascii')))
        return ident

    def append_evidence(self, agreement, kind, body):
        """Append an AAP dispute record (from covenant_agent.stripe_disputes) to the agreement's chain."""
        key(agreement)
        need(kind in EXTERNAL_KINDS and type(body) is dict, 'STRIPE_PAYMENT_EVIDENCE_KIND')
        with self.gateway._exclusive():
            with self._transaction() as db:
                return self._evidence(db, agreement, kind, None, body)

    # -------------------------------------------------------- description

    def describe(self):
        """What an agent needs to draft an action; no credential, source value or owner key."""
        return {**action.describe(), 'policy': self.id, 'checkout_policy': self.gateway.pin,
                'principal': self.policy['principal'], 'credential_policy': self.credential_policy,
                'merchant': self.checkout_policy['account'], 'currency': self.checkout_policy['currency'],
                'livemode': self.checkout_policy['livemode'], 'maximum_order': self.checkout_policy['maximum_order'],
                'operations': self.policy['operations'], 'sources': self.policy['sources'],
                'api_versions': self.policy['api_versions'], 'budgets': deepcopy(self.policy['budgets']),
                'maximum_action_seconds': self.policy['maximum_action_seconds'],
                'grant': {**grant_scope(self.gateway.pin), 'capabilities': ['stripe:' + name for name in
                                                                            self.policy['operations']]},
                'approval_thresholds': {signer: deepcopy(body['thresholds'])
                                        for signer, (_, body, _) in self.approvals.items()},
                'transport_assurance': self.transport.assurance}

    # -------------------------------------------------------- owner sources and revocations

    def add_source(self, kind, value):
        """Owner intake: hold a Shared Payment Token (spt_) or payment method (pm_) and return its reference."""
        need(kind in action.SOURCES, 'STRIPE_PAYMENT_SOURCE')
        _provider_id(value, 'spt_' if kind == 'shared_payment_token' else 'pm_')
        return self.sources.put(value.encode('ascii'))

    def revoke(self, grant_id):
        """Owner revocation of a delegation grant; it only ever blocks."""
        key(grant_id)
        with self.gateway._exclusive():
            with self._transaction() as db:
                db.execute('INSERT OR IGNORE INTO stripe_payment_revoked VALUES (?, ?)', (grant_id, self._now()))
        return {'grant': grant_id, 'revoked': True, 'execution_authorized': False}

    def _revoked(self):
        return [value for (value,) in self.db.execute('SELECT grant_id FROM stripe_payment_revoked ORDER BY grant_id')]

    # -------------------------------------------------------- checks before any provider call

    def _check_action(self, body, now):
        need(body['policy'] == self.id, 'STRIPE_PAYMENT_POLICY_PIN')
        need(self.policy['not_before'] <= now < self.policy['expires'], 'STRIPE_PAYMENT_POLICY_INACTIVE')
        need(body['principal'] == self.policy['principal'], 'STRIPE_PAYMENT_PRINCIPAL')
        need(body['merchant'] == self.checkout_policy['account'] and body['currency'] == self.checkout_policy['currency'] and
             body['livemode'] is self.checkout_policy['livemode'], 'STRIPE_PAYMENT_POLICY_TERMS')
        need(body['credential_policy'] == self.credential_policy, 'STRIPE_PAYMENT_CREDENTIAL_POLICY')
        need(body['operation'] in self.policy['operations'], 'STRIPE_PAYMENT_OPERATION_NOT_ADOPTED')
        need(body['api_version'] in self.policy['api_versions'], 'STRIPE_PAYMENT_API_VERSION')
        need(now < body['expires'] <= now + self.policy['maximum_action_seconds'], 'STRIPE_PAYMENT_EXPIRY')
        if body['operation'] == 'pay':
            need(body['source']['kind'] in self.policy['sources'], 'STRIPE_PAYMENT_SOURCE_NOT_ADOPTED')
            need(body['amount'] <= self.checkout_policy['maximum_order'], 'STRIPE_ORDER_LIMIT')
            need(body['payer'] in self.checkout_policy['payer_keys'], 'STRIPE_PAYER_NOT_ADOPTED')
            need(self.sources._contains(body['source']['reference']), 'STRIPE_PAYMENT_SOURCE_UNAVAILABLE')

    def _check_grant(self, body, chain, now):
        need(type(chain) in (list, tuple) and 1 <= len(chain) <= access.MAX_CHAIN, 'STRIPE_PAYMENT_GRANT')
        scope = grant_scope(self.gateway.pin)
        try:
            checked = access.verify_chain(list(chain), context=scope['context'], target=scope['target'],
                                          operation=scope['operation'], subject=body['agent'],
                                          capability='stripe:' + body['operation'],
                                          trusted_issuers=[self.policy['principal']], now=now,
                                          revoked=self._revoked())
        except (ValueError, TypeError, KeyError):
            raise ValueError('STRIPE_PAYMENT_GRANT_REFUSED') from None
        need(checked['leaf'] == body['grant'], 'STRIPE_PAYMENT_GRANT_MISMATCH')

    def _checkouts(self, column, value):
        rows = []
        for effect, raw, phase, observation in self.db.execute(
                'SELECT effect, body, phase, observation FROM stripe_intents WHERE json_extract(body, ?) = ?',
                ('$.' + column, value)):
            rows.append((effect, json.loads(raw), phase, json.loads(observation) if observation else None))
        return rows

    @staticmethod
    def _checkout_closed(intent, phase, observation):
        # Only an unpaid Checkout observed after its own expiry can no longer collect money.
        return (phase == 'OBSERVED' and observation is not None and observation.get('payment_state') == 'UNPAID'
                and observation.get('as_of', 0) > intent['expires'])

    def _paid(self, row):
        return (row['operation'] == 'pay' and row['state'] not in ('FAILED',) and row['outcome'] != 'FAILED' and
                row['provider_status'] != 'canceled')

    def blocking_reason(self, agreement=None, payer=None):
        """Why a new payment for this agreement or payer must wait, or None. Other rails may call this hook."""
        need(agreement is not None or payer is not None, 'STRIPE_PAYMENT_FIELD')
        with self.gateway._exclusive():
            return self._blocking(agreement, payer)

    def _blocking(self, agreement, payer):
        if agreement is not None:
            key(agreement)
            for row in self._rows('agreement=?', (agreement,)):
                if row['state'] in OPEN:
                    return 'STRIPE_PAYMENT_UNRESOLVED'
            for row in self._rows('agreement=?', (agreement,)):
                if self._paid(row):
                    return 'STRIPE_PAYMENT_ALREADY_PAID'
            for _, intent, phase, observation in self._checkouts('agreement', agreement):
                if observation is not None and observation.get('payment_state') in (
                        'PAID', 'PARTIALLY_REFUNDED', 'REFUNDED'):
                    return 'STRIPE_PAYMENT_ALREADY_PAID'
                if not self._checkout_closed(intent, phase, observation):
                    return 'STRIPE_PAYMENT_CHECKOUT_OPEN'
        if payer is not None:
            key(payer)
            if self._rows("payer=? AND state='UNKNOWN'", (payer,)):
                return 'STRIPE_PAYMENT_UNKNOWN_BLOCKS'
            for _, _, phase, _ in self._checkouts('payer', payer):
                if phase in ('ATTEMPTED', 'UNKNOWN'):
                    return 'STRIPE_PAYMENT_UNKNOWN_BLOCKS'
        return None

    def _target(self, body):
        """The payment an operation acts on: (kind, reference, payment_intent, facts) after its checks."""
        target = body['target']
        if target['kind'] == 'payment_action':
            row = self._row(target['id'])
            need(row is not None and row['operation'] == 'pay' and row['agreement'] == body['agreement'] and
                 row['payer'] == body['payer'], 'STRIPE_PAYMENT_TARGET')
            need(row['state'] in ('SUCCEEDED', 'RECONCILED') and row['outcome'] == 'SUCCEEDED' and
                 row['provider_ref'] is not None, 'STRIPE_PAYMENT_TARGET_STATE')
            facts, status = row['facts'], row['provider_status']
            if body['operation'] == 'capture':
                need(row['body']['capture_method'] == 'manual' and status == 'requires_capture',
                     'STRIPE_PAYMENT_TARGET_STATE')
                need(body['amount'] <= (facts.get('amount_capturable') or 0), 'STRIPE_PAYMENT_CAPTURE_LIMIT')
            elif body['operation'] == 'cancel':
                need(status in ('requires_capture', 'requires_action', 'requires_confirmation',
                                'requires_payment_method'), 'STRIPE_PAYMENT_TARGET_STATE')
                need(body['amount'] == row['amount'], 'STRIPE_PAYMENT_TARGET')
            else:
                need(status == 'succeeded', 'STRIPE_PAYMENT_TARGET_STATE')
            return 'payment_action', target['id'], row['provider_ref'], facts.get('amount_received') or 0, \
                facts.get('amount_refunded') or 0
        # A refund of a Checkout payment: refresh Codex's own reconciliation first.
        observed = self.gateway.observe(target['id'])
        intent, observation = observed['intent'], observed['observation']
        need(intent['agreement'] == body['agreement'] and intent['payer'] == body['payer'] and
             intent['currency'] == body['currency'], 'STRIPE_PAYMENT_TARGET')
        need(observation is not None and observation['payment_state'] in ('PAID', 'PARTIALLY_REFUNDED') and
             observation['payment_intent'] is not None, 'STRIPE_PAYMENT_TARGET_STATE')
        return 'checkout', target['id'], observation['payment_intent'], observation['amount'], \
            observation['amount_refunded']

    def _check_refund(self, body, received, provider_refunded):
        others = self._rows("operation='refund' AND target=?", (body['target']['id'],))
        succeeded = sum(row['amount'] for row in others if row['outcome'] == 'SUCCEEDED')
        flight = sum(row['amount'] for row in others if row['state'] in OPEN)
        need(body['amount'] <= received - max(provider_refunded, succeeded) - flight, 'STRIPE_PAYMENT_REFUND_LIMIT')

    def _check_blocks(self, body):
        if body['operation'] == 'pay':
            reason = self._blocking(body['agreement'], body['payer'])
            need(reason is None, reason)
            return
        for row in self._rows('target=?', (body['target']['id'],)):
            need(row['state'] not in OPEN, 'STRIPE_PAYMENT_UNRESOLVED')
        reason = self._blocking(None, body['payer'])
        need(reason is None, reason)

    def _approval_policy(self, agent):
        found = self.approvals.get(agent)
        need(found is not None, 'STRIPE_PAYMENT_APPROVAL_POLICY_MISSING')
        return found

    def approval_required(self, body):
        """Above the owner's threshold for the currency; a currency the policy does not list always needs one."""
        if body['operation'] not in ('pay', 'refund'):
            return False
        _, policy, _ = self._approval_policy(body['agent'])
        limit = next((row['amount'] for row in policy['thresholds'] if row['unit'].lower() == body['currency']), None)
        return limit is None or body['amount'] > limit

    def _request(self, body, reference, now):
        ident, policy, _ = self._approval_policy(body['agent'])
        rendering = action.render(body)
        request = {'version': REQUEST_VERSION, 'policy': ident, 'gateway': self.id, 'action': reference,
                   'rendering': rendering['sha256'], 'operation': body['operation'], 'amount': body['amount'],
                   'currency': body['currency'], 'payer': body['payer'], 'agreement': body['agreement'],
                   'occurrence': secrets.token_hex(32), 'issued_at': now, 'expires_at': now + policy['max_age']}
        validate_request(request)
        with self._transaction() as db:
            open_count = db.execute("SELECT count(*) FROM stripe_payment_approvals WHERE status='PENDING' AND "
                                    'expires_at>=?', (now,)).fetchone()[0]
            need(open_count < MAX_PENDING, 'STRIPE_PAYMENT_APPROVAL_BACKLOG')
            db.execute('INSERT INTO stripe_payment_approvals(occurrence, action, status, request, body, issued_at, '
                       'expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
                       (request['occurrence'], reference, 'PENDING', canonical(request).decode('ascii'),
                        canonical(body).decode('ascii'), now, request['expires_at']))
        return request

    def _required(self, request, agent):
        method = self._approval_policy(agent)[1]['method']
        details = {'occurrence': request['occurrence'], 'request': deepcopy(request), 'method': method['kind'],
                   'rendering_sha256': request['rendering'], 'expires_at': request['expires_at'],
                   'next': 'Owner: read the rendering (approval_rendering) and approve it with the adopted '
                           + ('passkey' if method['kind'] == 'PASSKEY' else 'owner approval key')
                           + ', then submit the same signed action again.',
                   'execution_authorized': False}
        raise Refusal('STRIPE_PAYMENT_APPROVAL_REQUIRED', details)

    def _approval(self, body, reference, supplied, now):
        if not self.approval_required(body):
            return None
        ident, policy, _ = self._approval_policy(body['agent'])
        need(policy['not_before'] <= now <= policy['expires'], 'STRIPE_PAYMENT_APPROVAL_POLICY_INACTIVE')
        if supplied is not None:
            need(type(supplied) is dict and type(supplied.get('request')) is dict and
                 supplied['request'].get('action') == reference, 'STRIPE_PAYMENT_APPROVAL_CHANGED')
            self.store_approval(supplied, _now=now)
        row = self.db.execute('SELECT occurrence, status, request, expires_at FROM stripe_payment_approvals WHERE '
                              'action=? ORDER BY issued_at DESC, occurrence DESC LIMIT 1', (reference,)).fetchone()
        if row is not None and row[1] == 'REFUSED':
            raise ValueError('STRIPE_PAYMENT_APPROVAL_REFUSED')
        if row is not None and row[1] == 'CONSUMED':
            raise ValueError('STRIPE_PAYMENT_APPROVAL_REUSED')
        if row is not None and row[1] == 'APPROVED' and now <= row[3]:
            return row[0]
        if row is not None and row[1] == 'PENDING' and now <= row[3]:
            self._required(json.loads(row[2]), body['agent'])
        self._required(self._request(body, reference, now), body['agent'])

    def store_approval(self, record, *, _now=None):
        """Verify and record an owner's decision on a request this gateway issued. Executes nothing."""
        now = self._now() if _now is None else _now
        need(type(record) is dict and type(record.get('request')) is dict, 'STRIPE_PAYMENT_APPROVAL_FIELDS')
        request = validate_request(record['request'])
        with self.gateway._exclusive():
            row = self.db.execute('SELECT status, request, body FROM stripe_payment_approvals WHERE occurrence=?',
                                  (request['occurrence'],)).fetchone()
            need(row is not None, 'STRIPE_PAYMENT_APPROVAL_UNKNOWN')
            need(json.loads(row[1]) == request and request['gateway'] == self.id, 'STRIPE_PAYMENT_APPROVAL_CHANGED')
            body = json.loads(row[2])
            ident, policy, _ = self._approval_policy(body['agent'])
            need(request['policy'] == ident, 'STRIPE_PAYMENT_APPROVAL_CHANGED')
            if row[0] == 'REFUSED':
                raise ValueError('STRIPE_PAYMENT_APPROVAL_REFUSED')
            if row[0] == 'CONSUMED':
                raise ValueError('STRIPE_PAYMENT_APPROVAL_REUSED')
            need(now <= request['expires_at'], 'STRIPE_PAYMENT_APPROVAL_EXPIRED')
            counter = _check_proof(record, policy)
            if row[0] == 'APPROVED' and record['decision'] == 'APPROVE':
                return {'occurrence': request['occurrence'], 'status': 'APPROVED', 'stored': False,
                        'execution_authorized': False}
            status = 'APPROVED' if record['decision'] == 'APPROVE' else 'REFUSED'
            with self._transaction() as db:
                if counter is not None:
                    seen = db.execute('SELECT sign_count FROM stripe_payment_counters WHERE credential=?',
                                      (counter[0],)).fetchone()
                    # WebAuthn: a non-increasing nonzero counter may be a cloned authenticator.
                    need(seen is None or (counter[1] == 0 and seen[0] == 0) or counter[1] > seen[0],
                         'STRIPE_PAYMENT_APPROVAL_PASSKEY')
                    db.execute('INSERT INTO stripe_payment_counters VALUES (?, ?) ON CONFLICT(credential) DO UPDATE '
                               'SET sign_count=excluded.sign_count', counter)
                db.execute('UPDATE stripe_payment_approvals SET status=?, decision=? WHERE occurrence=?',
                           (status, canonical(record).decode('ascii'), request['occurrence']))
            if status == 'REFUSED':
                raise ValueError('STRIPE_PAYMENT_APPROVAL_REFUSED')
            return {'occurrence': request['occurrence'], 'status': status, 'stored': True,
                    'execution_authorized': False}

    def pending_approvals(self):
        now = self._now()
        with self.gateway._exclusive():
            return [json.loads(raw) for (raw,) in self.db.execute(
            "SELECT request FROM stripe_payment_approvals WHERE status IN ('PENDING','APPROVED') AND expires_at>=? "
            'ORDER BY issued_at, occurrence LIMIT 64', (now,))]

    def approval_rendering(self, occurrence):
        """The exact text the owner reads, recomputed from the stored action and checked against the request."""
        key(occurrence)
        with self.gateway._exclusive():
            row = self.db.execute('SELECT request, body FROM stripe_payment_approvals WHERE occurrence=?',
                                  (occurrence,)).fetchone()
        need(row is not None, 'STRIPE_PAYMENT_APPROVAL_UNKNOWN')
        request, body = json.loads(row[0]), json.loads(row[1])
        rendered = action.render(body)
        need(rendered['sha256'] == request['rendering'] and action.action_id(body) == request['action'],
             'STRIPE_PAYMENT_APPROVAL_CHANGED')
        return {'request': request, **rendered}

    def _observe_spend(self, body):
        if self._spend_observer is None or body['operation'] not in ('pay', 'refund'):
            return
        event = {'kind': 'SPEND', 'request': 'urn:aap:stripe-payment:' + body['operation_id'],
                 'recipient': body['agent'], 'scope': 'stripe:%s:%s' % (body['merchant'], body['operation'].upper()),
                 'counterparty': body['payer'], 'usage': {body['currency']: body['amount']},
                 'operation': body['operation_id'], 'agreement': body['agreement']}
        try:
            self._spend_observer(event)
        except BaseException as error:
            cause = getattr(error, 'code', None) or str(error)
            raise Refusal('STRIPE_PAYMENT_OBSERVER_REFUSED',
                          {'cause': cause if type(cause) is str and re.fullmatch(r'[A-Z][A-Z0-9_]{1,80}', cause)
                           else 'OBSERVER'}) from None

    # -------------------------------------------------------- submission

    def submit(self, record, *, chain=(), authorization=None, approval=None):
        """Run one signed action: check, reserve, then call Stripe once. A resend never calls again."""
        body = action.verify_action(record)
        reference = action.action_id(body)
        with self.gateway._exclusive():
            row = self._row(body['operation_id'])
            if row is not None:
                need(row['action'] == reference, 'STRIPE_PAYMENT_OPERATION_REUSED')
                if row['state'] == 'PREPARED':
                    self._reserve(body['operation_id'])
                if self._row(body['operation_id'])['state'] == 'RESERVED':
                    return self._dispatch(body['operation_id'])
                return self.inspect(body['operation_id'])
            now = self._now()
            self._check_action(body, now)
            self._check_grant(body, chain, now)
            target = None
            if body['operation'] != 'pay':
                target = self._target(body)
                if body['operation'] == 'refund':
                    self._check_refund(body, target[3], target[4])
            self._check_blocks(body)
            if body['operation'] == 'pay':
                action.check_authorization(body, authorization)
            occurrence = self._approval(body, reference, approval, now)
            self._observe_spend(body)
            count = self.db.execute('SELECT count(*) FROM stripe_payment_operations').fetchone()[0]
            need(count < MAX_OPERATIONS, 'STRIPE_PAYMENT_STORE_FULL')
            facts = {} if target is None else {'target_route': target[0], 'payment_intent': target[2]}
            with self._transaction() as db:
                db.execute('INSERT INTO stripe_payment_operations(id, action, record, authorization, chain, operation, '
                           'agreement, payer, target, amount, state, approval, facts, created_at, updated_at, attempts) '
                           'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
                           (body['operation_id'], reference, canonical(record).decode('ascii'),
                            None if authorization is None else canonical(authorization).decode('ascii'),
                            canonical(list(chain)).decode('ascii'), body['operation'], body['agreement'],
                            body['payer'], None if target is None else target[1], body['amount'], 'PREPARED',
                            occurrence, canonical(facts).decode('ascii'), now, now))
                self._evidence(db, body['agreement'], 'ACTION_ACCEPTED', body['operation_id'], {
                    'action': reference, 'operation': body['operation'], 'amount': body['amount'],
                    'currency': body['currency'], 'grant': body['grant'], 'approval': occurrence,
                    'payer_authorized': authorization is not None, 'target': deepcopy(body['target']),
                    'checks': ['AGENT_SIGNATURE', 'POLICY', 'GRANT', 'BLOCKS'] +
                              (['PAYER_AUTHORIZATION'] if body['operation'] == 'pay' else []) +
                              (['OWNER_APPROVAL'] if occurrence else [])})
            self._reserve(body['operation_id'])
            return self._dispatch(body['operation_id'])

    def _buckets(self, body):
        """(bucket, limit, window) rows a pay or refund reserves under."""
        if body['operation'] not in ('pay', 'refund'):
            return []
        budget = next((row for row in self.policy['budgets'] if row['operation'] == body['operation']), None)
        need(budget is not None, 'STRIPE_PAYMENT_BUDGET_MISSING')
        name = body['operation']
        rows = [(name + ':agreement:' + body['agreement'], budget['per_agreement'], None),
                (name + ':counterparty:' + body['payer'], budget['per_counterparty'], budget['period']),
                (name + ':period', budget['per_period'], budget['period'])]
        if name == 'pay':
            rows.append(('pay:aggregate', self.checkout_policy['operation_budget'], None))
        return rows

    def _used(self, db, bucket, window, now):
        if window is None:
            return db.execute('SELECT coalesce(sum(amount), 0) FROM stripe_payment_reservations WHERE bucket=?',
                              (bucket,)).fetchone()[0]
        return db.execute('SELECT coalesce(sum(amount), 0) FROM stripe_payment_reservations WHERE bucket=? AND at>?',
                          (bucket, now - window)).fetchone()[0]

    def _commitments(self, db):
        return db.execute("SELECT coalesce(sum(json_extract(body,'$.amount')),0) FROM stripe_intents").fetchone()[0]

    def _reserve(self, operation_id):
        """PREPARED to RESERVED: every bucket and the shared Checkout aggregate in one transaction."""
        now = self._now()
        refused = None
        with self._transaction() as db:
            row = self._row(operation_id)
            if row['state'] != 'PREPARED':
                return
            body = row['body']
            buckets = self._buckets(body)
            for bucket, limit, window in buckets:
                used = self._used(db, bucket, window, now)
                if bucket == 'pay:aggregate':
                    used += self._commitments(db)
                if used + body['amount'] > limit:
                    refused = 'STRIPE_PAYMENT_BUDGET_EXCEEDED'
                    break
            if refused is None:
                for bucket, _, _ in buckets:
                    db.execute('INSERT INTO stripe_payment_reservations VALUES (?, ?, ?, ?)',
                               (operation_id, bucket, body['amount'], now))
                if row['approval'] is not None:
                    found = db.execute('SELECT status FROM stripe_payment_approvals WHERE occurrence=?',
                                       (row['approval'],)).fetchone()
                    need(found is not None and found[0] == 'APPROVED', 'STRIPE_PAYMENT_APPROVAL_REUSED')
                    db.execute("UPDATE stripe_payment_approvals SET status='CONSUMED', consumed_by=? WHERE occurrence=?",
                               (operation_id, row['approval']))
                db.execute("UPDATE stripe_payment_operations SET state='RESERVED', updated_at=? WHERE id=?",
                           (now, operation_id))
                self._evidence(db, body['agreement'], 'RESERVED', operation_id,
                               {'buckets': [bucket for bucket, _, _ in buckets], 'amount': body['amount']})
            else:
                db.execute("UPDATE stripe_payment_operations SET state='FAILED', outcome='FAILED', code=?, updated_at=? "
                           'WHERE id=?', (refused, now, operation_id))
                self._evidence(db, body['agreement'], 'REFUSED_BEFORE_PROVIDER', operation_id, {'code': refused})
        if refused is not None:
            raise ValueError(refused)

    def _source_value(self, body):
        reference = body['source']['reference']
        need(self.sources._contains(reference), 'STRIPE_PAYMENT_SOURCE_UNAVAILABLE')
        return self.sources._bind([reference])[reference]

    def _form(self, body, row, value):
        meta = action.metadata(body)
        tags = [('metadata[aap_agreement]', meta['aap_agreement']), ('metadata[aap_operation]', meta['aap_operation'])]
        operation = body['operation']
        if operation == 'pay':
            source = body['source']
            fields = [('amount', str(body['amount'])), ('currency', body['currency']), ('confirm', 'true'),
                      ('capture_method', body['capture_method'])]
            if source['kind'] == 'shared_payment_token':
                fields.append(('payment_method_data[shared_payment_granted_token]', value))
            else:
                fields += [('payment_method', value), ('automatic_payment_methods[enabled]', 'true'),
                           ('automatic_payment_methods[allow_redirects]', 'never')]
                if source['customer'] is not None:
                    fields.append(('customer', source['customer']))
            if source['off_session']:
                fields.append(('off_session', 'true'))
            return 'POST', '/v1/payment_intents', fields + tags
        intent = row['facts']['payment_intent']
        if operation == 'capture':
            return 'POST', '/v1/payment_intents/' + intent + '/capture', [('amount_to_capture', str(body['amount']))]
        if operation == 'cancel':
            return 'POST', '/v1/payment_intents/' + intent + '/cancel', []
        return 'POST', '/v1/refunds', [('payment_intent', intent), ('amount', str(body['amount']))] + tags

    def _token_scope(self, body, value, now):
        """Read the Shared Payment Token's own limits before any charge; nothing is charged on doubt."""
        reply = self.transport.exchange('GET', '/v1/shared_payment/granted_tokens/' + value,
                                        version=body['api_version'])
        token = reply['body']
        if reply['status'] != 200 or type(token) is not dict or token.get('object') != 'shared_payment.granted_token':
            return 'STRIPE_PAYMENT_TOKEN_UNVERIFIED', None
        limits = token.get('usage_limits')
        if type(limits) is not dict:
            return 'STRIPE_PAYMENT_TOKEN_UNVERIFIED', None
        facts = {'currency': _token(limits.get('currency')), 'max_amount': _int(limits.get('max_amount')),
                 'expires_at': _int(limits.get('expires_at')), 'deactivated': token.get('deactivated_at') is not None,
                 'recurring_interval': _token(limits.get('recurring_interval'))}
        if (token.get('id') != value or facts['currency'] != body['currency'] or facts['max_amount'] is None or
                facts['max_amount'] < body['amount'] or facts['deactivated'] or
                (facts['expires_at'] is not None and facts['expires_at'] <= now)):
            return 'STRIPE_PAYMENT_TOKEN_SCOPE', facts
        return None, facts

    def _dispatch(self, operation_id):
        row = self._row(operation_id)
        if row['state'] != 'RESERVED':
            return self.inspect(operation_id)
        body, now = row['body'], self._now()
        value = None
        if body['operation'] == 'pay':
            try:
                value = self._source_value(body)
            except ValueError:
                self._apply(operation_id, {'result': 'FAILED', 'code': 'STRIPE_PAYMENT_SOURCE_UNAVAILABLE',
                                           'provider_ref': None, 'provider_status': None, 'facts': {},
                                           'http_status': None, 'replayed': False, 'sha256': None}, 'BEFORE_PROVIDER')
                return self.inspect(operation_id)
        if body['operation'] == 'pay' and body['source']['kind'] == 'shared_payment_token':
            refused, facts = self._token_scope(body, value, now)
            with self._transaction() as db:
                self._evidence(db, body['agreement'], 'TOKEN_SCOPE', operation_id,
                               {'limits': facts, 'code': refused})
            if refused is not None:
                self._apply(operation_id, {'result': 'FAILED', 'code': refused, 'provider_ref': None,
                                           'provider_status': None, 'facts': {}, 'http_status': None,
                                           'replayed': False, 'sha256': None}, 'BEFORE_PROVIDER')
                return self.inspect(operation_id)
        with self._transaction() as db:
            db.execute("UPDATE stripe_payment_operations SET state='SUBMITTED', attempts=attempts+1, submitted_at=?, "
                       'updated_at=? WHERE id=?', (now, now, operation_id))
            self._evidence(db, body['agreement'], 'DISPATCH_INTENT', operation_id,
                           {'idempotency_key': action.idempotency_key(body), 'attempt': row['attempts'] + 1})
        method, path, fields = self._form(body, row, value)
        reply = self.transport.exchange(method, path, data=fields, idempotency=action.idempotency_key(body),
                                        version=body['api_version'])
        self._apply(operation_id, self._classify(body, row, reply), 'RESPONSE')
        return self.inspect(operation_id)

    def recover(self):
        """After a restart: a dispatch without a recorded reply is UNKNOWN, never success or failure."""
        with self.gateway._exclusive():
            moved = []
            for row in self._rows("state='SUBMITTED' AND provider_status IS NULL AND code IS NULL", ()):
                with self._transaction() as db:
                    db.execute("UPDATE stripe_payment_operations SET state='UNKNOWN', code=?, updated_at=? WHERE id=?",
                               ('STRIPE_PAYMENT_NO_RESPONSE', self._now(), row['id']))
                    self._evidence(db, row['agreement'], 'RESTART_RECOVERY', row['id'],
                                   {'from': 'SUBMITTED', 'to': 'UNKNOWN', 'code': 'STRIPE_PAYMENT_NO_RESPONSE'})
                moved.append(row['id'])
            return moved

    # -------------------------------------------------------- classification

    def _intent(self, value, body, pay_operation, amount, expected=None):
        need(type(value) is dict and value.get('object') == 'payment_intent', 'STRIPE_PAYMENT_RESPONSE')
        identifier = _object_id(value, 'pi_')
        need(identifier is not None and (expected is None or identifier == expected), 'STRIPE_PAYMENT_PROVIDER_BINDING')
        meta = value.get('metadata')
        need(type(meta) is dict and meta.get('aap_operation') == pay_operation and
             meta.get('aap_agreement') == body['agreement'] and value.get('livemode') is body['livemode'] and
             value.get('currency') == body['currency'] and type(value.get('amount')) is int and
             value['amount'] == amount, 'STRIPE_PAYMENT_PROVIDER_BINDING')
        status = value.get('status')
        need(status in PAYMENT_STATUSES, 'STRIPE_PAYMENT_RESPONSE')
        facts = {'payment_intent': identifier, 'status': status, 'amount': value['amount'],
                 'amount_received': _int(value.get('amount_received')),
                 'amount_capturable': _int(value.get('amount_capturable')),
                 'charge': _object_id(value.get('latest_charge'), 'ch_'),
                 'capture_method': _token(value.get('capture_method'))}
        charge = value.get('latest_charge')
        if type(charge) is dict and type(charge.get('balance_transaction')) is dict:
            facts['fee'] = _int(charge['balance_transaction'].get('fee'))
        return identifier, status, facts

    def _object(self, body, row, value):
        operation = body['operation']
        if operation == 'pay':
            identifier, status, facts = self._intent(value, body, body['operation_id'], body['amount'])
            if status == 'succeeded' or (status == 'requires_capture' and body['capture_method'] == 'manual'):
                result, code = 'SUCCEEDED', None
            elif status in ('processing', 'requires_action'):
                result, code = 'PENDING', None
            elif status == 'requires_capture':
                result, code = 'UNKNOWN', 'STRIPE_PAYMENT_RESPONSE'
            else:
                result, code = 'FAILED', 'STRIPE_PAYMENT_NOT_COMPLETED'
            return {'result': result, 'code': code, 'provider_ref': identifier, 'provider_status': status,
                    'facts': facts}
        target = self._row(body['target']['id']) if body['target']['kind'] == 'payment_action' else None
        if operation in ('capture', 'cancel'):
            identifier, status, facts = self._intent(value, body, target['id'], target['amount'],
                                                     row['facts']['payment_intent'])
            if operation == 'capture':
                if status == 'succeeded':
                    result, code = 'SUCCEEDED', None
                elif status == 'processing':
                    result, code = 'PENDING', None
                else:
                    result, code = 'FAILED', 'STRIPE_PAYMENT_NOT_CAPTURED'
            else:
                result, code = ('SUCCEEDED', None) if status == 'canceled' else ('FAILED', 'STRIPE_PAYMENT_NOT_CANCELLED')
            return {'result': result, 'code': code, 'provider_ref': identifier, 'provider_status': status,
                    'facts': facts}
        need(type(value) is dict and value.get('object') == 'refund', 'STRIPE_PAYMENT_RESPONSE')
        identifier = _object_id(value, 're_')
        meta = value.get('metadata')
        need(identifier is not None and value.get('payment_intent') == row['facts']['payment_intent'] and
             type(meta) is dict and meta.get('aap_operation') == body['operation_id'] and
             meta.get('aap_agreement') == body['agreement'] and value.get('currency') == body['currency'] and
             type(value.get('amount')) is int and value['amount'] == body['amount'], 'STRIPE_PAYMENT_PROVIDER_BINDING')
        status = value.get('status')
        need(status in REFUND_STATUSES, 'STRIPE_PAYMENT_RESPONSE')
        facts = {'refund': identifier, 'status': status, 'amount': value['amount'],
                 'failure_reason': _token(value.get('failure_reason')), 'payment_intent': row['facts']['payment_intent']}
        result, code = {'succeeded': ('SUCCEEDED', None), 'pending': ('PENDING', None),
                        'requires_action': ('PENDING', None)}.get(status, ('FAILED', 'STRIPE_PAYMENT_REFUND_FAILED'))
        return {'result': result, 'code': code, 'provider_ref': identifier, 'provider_status': status, 'facts': facts}

    def _classify(self, body, row, reply):
        """FAILED only when Stripe says nothing executed or the object says it ended unpaid; otherwise UNKNOWN."""
        base = {'http_status': reply['status'], 'replayed': reply['replayed'], 'sha256': reply['sha256'],
                'provider_ref': None, 'provider_status': None, 'facts': {}}
        status, value = reply['status'], reply['body']
        if status is None:
            return {**base, 'result': 'UNKNOWN', 'code': 'STRIPE_PAYMENT_NO_RESPONSE'}
        if 200 <= status < 300:
            if value is None:
                return {**base, 'result': 'UNKNOWN', 'code': 'STRIPE_PAYMENT_RESPONSE'}
            try:
                return {**base, **self._object(body, row, value)}
            except ValueError as error:
                code = str(error) if str(error).startswith('STRIPE_PAYMENT_') else 'STRIPE_PAYMENT_RESPONSE'
                return {**base, 'result': 'UNKNOWN', 'code': code}
        error = value.get('error') if type(value) is dict else None
        error = error if type(error) is dict else {}
        detail = {'error_type': _token(error.get('type')), 'error_code': _token(error.get('code')),
                  'decline_code': _token(error.get('decline_code'))}
        if status == 402:
            result = {**base, 'result': 'FAILED', 'code': 'STRIPE_PAYMENT_DECLINED', 'facts': detail}
            if body['operation'] == 'pay' and type(error.get('payment_intent')) is dict:
                try:
                    identifier, provider_status, facts = self._intent(error['payment_intent'], body,
                                                                      body['operation_id'], body['amount'])
                    result.update(provider_ref=identifier, provider_status=provider_status, facts={**facts, **detail})
                except ValueError:
                    pass
            return result
        if status in (400, 401, 403, 404):
            if detail['error_type'] == 'idempotency_error':
                return {**base, 'result': 'UNKNOWN', 'code': 'STRIPE_PAYMENT_IDEMPOTENCY_CONFLICT', 'facts': detail}
            return {**base, 'result': 'FAILED', 'code': 'STRIPE_PAYMENT_PROVIDER_REFUSED', 'facts': detail}
        if status == 409:
            return {**base, 'result': 'UNKNOWN', 'code': 'STRIPE_PAYMENT_IDEMPOTENCY_CONFLICT', 'facts': detail}
        if status == 429:
            return {**base, 'result': 'FAILED', 'code': 'STRIPE_PAYMENT_RATE_LIMITED', 'facts': detail}
        return {**base, 'result': 'UNKNOWN', 'code': 'STRIPE_PAYMENT_PROVIDER_ERROR', 'facts': detail}

    def _apply(self, operation_id, result, basis):
        """Record one classified reply. Provider truth wins on reconciliation; UNKNOWN never releases money."""
        now = self._now()
        with self._transaction() as db:
            row = self._row(operation_id)
            body, verdict, previous = row['body'], result['result'], row['state']
            final = basis in ('RECONCILE', 'REPLAY', 'RESOLUTION')
            outcome, code = row['outcome'], result['code']
            if verdict == 'SUCCEEDED':
                state, outcome = ('RECONCILED' if final else 'SUCCEEDED'), 'SUCCEEDED'
            elif verdict == 'FAILED':
                state, outcome = ('RECONCILED' if final else 'FAILED'), 'FAILED'
            elif verdict == 'PENDING':
                state = 'SUBMITTED'
            elif basis == 'RESPONSE' or previous == 'UNKNOWN':
                state = 'UNKNOWN'
            else:
                state, code = previous, row['code']
            facts = {**row['facts'], **result['facts']}
            provider_ref = result['provider_ref'] or row['provider_ref']
            provider_status = result['provider_status'] or row['provider_status']
            db.execute('UPDATE stripe_payment_operations SET state=?, outcome=?, code=?, provider_ref=?, '
                       'provider_status=?, facts=?, updated_at=? WHERE id=?',
                       (state, outcome, code, provider_ref, provider_status, canonical(facts).decode('ascii'),
                        now, operation_id))
            if outcome == 'FAILED':
                db.execute('DELETE FROM stripe_payment_reservations WHERE operation=?', (operation_id,))
            if verdict == 'SUCCEEDED' and body['operation'] in ('capture', 'cancel'):
                target = body['target']['id']
                target_row = self._row(target)
                target_facts = {**target_row['facts'], 'amount_received': result['facts'].get('amount_received'),
                                'amount_capturable': result['facts'].get('amount_capturable')}
                if body['operation'] == 'capture':
                    db.execute('UPDATE stripe_payment_reservations SET amount=? WHERE operation=?',
                               (result['facts'].get('amount_received') or 0, target))
                else:
                    db.execute('DELETE FROM stripe_payment_reservations WHERE operation=?', (target,))
                db.execute('UPDATE stripe_payment_operations SET provider_status=?, facts=?, updated_at=? WHERE id=?',
                           (result['provider_status'], canonical(target_facts).decode('ascii'), now, target))
            kind = {'RESPONSE': 'PROVIDER_OUTCOME', 'BEFORE_PROVIDER': 'REFUSED_BEFORE_PROVIDER',
                    'RESOLUTION': 'OWNER_RESOLUTION'}.get(basis, 'RECONCILED')
            self._evidence(db, row['agreement'], kind, operation_id, {
                'basis': basis, 'result': verdict, 'state': state, 'code': code, 'provider_ref': provider_ref,
                'provider_status': provider_status, 'http_status': result['http_status'],
                'replayed': result['replayed'], 'response_sha256': result['sha256'], 'facts': result['facts']})
        if self._outcome_observer is not None:
            try:
                self._outcome_observer({'kind': 'PAYMENT_OUTCOME', 'operation': operation_id,
                                        'agreement': row['agreement'], 'state': state, 'outcome': outcome,
                                        'provider_status': provider_status})
            except Exception:
                # An observer can watch outcomes; it can never change one. Its failures stay visible.
                self.observer_failures += 1

    # -------------------------------------------------------- reconciliation

    def _find(self, body, row):
        """Locate the provider object of an operation whose reply was lost: (found reply, count)."""
        operation_id = body['operation_id']
        if body['operation'] == 'pay':
            query = 'metadata["aap_operation"]:"%s"' % operation_id
            reply = self.transport.exchange('GET', '/v1/payment_intents/search?' + urlencode(
                {'query': query, 'limit': '10'}), version=body['api_version'])
        else:
            reply = self.transport.exchange('GET', '/v1/refunds?' + urlencode(
                {'payment_intent': row['facts']['payment_intent'], 'limit': '100'}), version=body['api_version'])
        listed = reply['body'].get('data') if reply['status'] == 200 and type(reply['body']) is dict else None
        if type(listed) is not list:
            return None, None
        found = [value for value in listed[:100] if type(value) is dict and type(value.get('metadata')) is dict and
                 value['metadata'].get('aap_operation') == operation_id]
        if len(found) == 1:
            return {**reply, 'body': found[0]}, 1
        return None, len(found)

    def _retrieve(self, body, row):
        if body['operation'] == 'refund':
            path = '/v1/refunds/' + row['provider_ref']
        elif body['operation'] == 'pay':
            path = '/v1/payment_intents/' + row['provider_ref']
        else:
            path = '/v1/payment_intents/' + row['facts']['payment_intent']
        return self.transport.exchange('GET', path, version=body['api_version'])

    def reconcile(self, operation_id, *, replay=False):
        """Settle an operation from Stripe's own objects; replay=True re-sends the identical request once."""
        key(operation_id)
        with self.gateway._exclusive():
            row = self._row(operation_id)
            need(row is not None, 'STRIPE_PAYMENT_OPERATION_UNKNOWN')
            body = row['body']
            if row['state'] in ('PREPARED', 'RESERVED') or (row['outcome'] == 'FAILED' and row['provider_ref'] is None
                                                            and row['state'] != 'UNKNOWN'):
                return {**self.inspect(operation_id), 'reconciliation': 'NOTHING_SENT_OR_REFUSED_BEFORE_EXECUTION'}
            note = 'RETRIEVED'
            if row['provider_ref'] is None and body['operation'] in ('pay', 'refund'):
                reply, count = self._find(body, row)
                if count is not None and count > 1:
                    with self._transaction() as db:
                        self._evidence(db, row['agreement'], 'DISCREPANCY', operation_id,
                                       {'code': 'STRIPE_PAYMENT_DUPLICATE_PROVIDER_OBJECTS', 'objects': count})
                    raise ValueError('STRIPE_PAYMENT_DUPLICATE_PROVIDER_OBJECTS')
                if reply is None and replay:
                    now = self._now()
                    need(row['submitted_at'] is not None and now - row['submitted_at'] <= REPLAY_WINDOW and
                         now < body['expires'], 'STRIPE_PAYMENT_REPLAY_WINDOW')
                    value = self._source_value(body) if body['operation'] == 'pay' else None
                    method, path, fields = self._form(body, row, value)
                    with self._transaction() as db:
                        self._evidence(db, row['agreement'], 'REPLAYED_SAME_KEY', operation_id,
                                       {'idempotency_key': action.idempotency_key(body)})
                    reply = self.transport.exchange(method, path, data=fields, idempotency=action.idempotency_key(body),
                                                    version=body['api_version'])
                    self._apply(operation_id, self._classify(body, row, reply), 'REPLAY')
                    return {**self.inspect(operation_id), 'reconciliation': 'REPLAYED_SAME_KEY'}
                if reply is None:
                    with self._transaction() as db:
                        self._evidence(db, row['agreement'], 'NOT_FOUND_YET', operation_id,
                                       {'search': 'EVENTUALLY_CONSISTENT_ABSENCE_IS_NOT_PROOF'})
                    return {**self.inspect(operation_id), 'reconciliation': 'NOT_FOUND_YET_NO_RETRY_AUTHORITY'}
                note = 'FOUND_BY_METADATA'
            else:
                reply = self._retrieve(body, row)
            self._apply(operation_id, self._classify(body, row, reply), 'RECONCILE')
            current = self._row(operation_id)
            if body['operation'] == 'pay' and current['provider_ref'] is not None:
                self._related('payment_action', operation_id, current['agreement'], current['payer'],
                              current['provider_ref'], body['api_version'])
            elif body['operation'] == 'refund' and current['facts'].get('target_route') == 'payment_action':
                self._related('payment_action', current['target'], current['agreement'], current['payer'],
                              current['facts']['payment_intent'], body['api_version'])
            elif body['operation'] == 'refund':
                self.observe_checkout(current['target'])
            return {**self.inspect(operation_id), 'reconciliation': note}

    def reconcile_due(self, *, limit=100):
        """Reconcile what needs it: UNKNOWN, pending past its reconcile_after, and unconfirmed outcomes."""
        now, done = self._now(), []
        with self.gateway._exclusive():
            rows = self._rows("state IN ('SUBMITTED','UNKNOWN','SUCCEEDED') OR (state='FAILED' AND provider_ref IS "
                              'NOT NULL)', ())[:limit]
        for row in rows:
            due = (row['submitted_at'] or row['created_at']) + row['body']['observation']['reconcile_after']
            if row['state'] == 'UNKNOWN' or now >= due:
                try:
                    done.append(self.reconcile(row['id']))
                except ValueError as error:
                    done.append({'operation': row['id'], 'code': str(error)})
        return done

    def _related(self, route, reference, agreement, payer, payment_intent, version):
        """Refunds and disputes Stripe holds for a payment, recorded once per new state."""
        facts = {}
        refunds = self.transport.exchange('GET', '/v1/refunds?' + urlencode(
            {'payment_intent': payment_intent, 'limit': '100'}), version=version)
        listed = refunds['body'].get('data') if refunds['status'] == 200 and type(refunds['body']) is dict else None
        if type(listed) is list:
            refunded = 0
            for value in listed[:100]:
                identifier = _object_id(value, 're_')
                status = value.get('status') if type(value) is dict else None
                amount = _int(value.get('amount')) if type(value) is dict else None
                if identifier is None or status not in REFUND_STATUSES or amount is None:
                    continue
                if status == 'succeeded':
                    refunded += amount
                meta = value.get('metadata') if type(value.get('metadata')) is dict else {}
                mine = type(meta.get('aap_operation')) is str and self.db.execute(
                    "SELECT 1 FROM stripe_payment_operations WHERE id=? AND operation='refund'",
                    (meta['aap_operation'],)).fetchone() is not None
                self._observed(agreement, 'PROVIDER_REFUND', identifier, status, {
                    'refund': identifier, 'status': status, 'amount': amount, 'payment_intent': payment_intent,
                    'initiated_by': 'GATEWAY' if mine else 'OUTSIDE_GATEWAY'})
            facts['amount_refunded'] = refunded
        disputes = self.transport.exchange('GET', '/v1/disputes?' + urlencode(
            {'payment_intent': payment_intent, 'limit': '100'}), version=version)
        listed = disputes['body'].get('data') if disputes['status'] == 200 and type(disputes['body']) is dict else None
        if type(listed) is list:
            open_amount = 0
            for value in listed[:100]:
                found = dispute_facts(value)
                if found is None:
                    continue
                if found['status'] not in CLOSED_DISPUTES:
                    open_amount += found['amount']
                self._dispute(route, reference, agreement, payer, found)
            facts['disputed_amount'] = open_amount
        if route == 'payment_action' and facts:
            with self._transaction() as db:
                row = self._row(reference)
                db.execute('UPDATE stripe_payment_operations SET facts=? WHERE id=?',
                           (canonical({**row['facts'], **facts}).decode('ascii'), reference))
        return facts

    def _observed(self, agreement, kind, identifier, state, body):
        with self._transaction() as db:
            seen = db.execute('SELECT state FROM stripe_payment_observed WHERE object=?', (identifier,)).fetchone()
            if seen is not None and seen[0] == state:
                return False
            db.execute('INSERT INTO stripe_payment_observed VALUES (?, ?) ON CONFLICT(object) DO UPDATE SET '
                       'state=excluded.state', (identifier, state))
            self._evidence(db, agreement, kind, None, body)
        return True

    def _dispute(self, route, reference, agreement, payer, found):
        now = self._now()
        with self._transaction() as db:
            seen = db.execute('SELECT status, facts FROM stripe_payment_disputes WHERE id=?', (found['id'],)).fetchone()
            if seen is not None and json.loads(seen[1]) == found:
                return
            db.execute('INSERT INTO stripe_payment_disputes VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE '
                       'SET status=excluded.status, facts=excluded.facts, updated_at=excluded.updated_at',
                       (found['id'], agreement, route, reference, payer, found['status'],
                        canonical(found).decode('ascii'), now))
            self._evidence(db, agreement, 'PROVIDER_DISPUTE', reference if route == 'payment_action' else None,
                           {'route': route, 'reference': reference, 'new': seen is None, **found})
        if self._evidence_observer is not None:
            self._evidence_observer('PROVIDER_DISPUTE', {'route': route, 'reference': reference,
                                                         'agreement': agreement, 'payer': payer, 'dispute': found})

    def observe_checkout(self, effect):
        """Codex's Checkout observation, then the refund and dispute objects behind its payment."""
        with self.gateway._exclusive():
            observed = self.gateway.observe(effect)
            intent, observation = observed['intent'], observed['observation']
            facts = {}
            if observation is not None and observation.get('payment_intent'):
                facts = self._related('checkout', effect, intent['agreement'], intent['payer'],
                                      observation['payment_intent'], action.API_VERSION)
            return {**observed, 'provider_objects': facts}

    def disputes(self, agreement):
        key(agreement)
        with self.gateway._exclusive():
            return self._disputes(agreement)

    def _disputes(self, agreement):
        return [{'id': ident, 'route': route, 'reference': reference, 'payer': payer, 'status': status,
                 'facts': json.loads(facts), 'updated_at': updated}
                for ident, route, reference, payer, status, facts, updated in self.db.execute(
                    'SELECT id, route, reference, payer, status, facts, updated_at FROM stripe_payment_disputes '
                    'WHERE agreement=? ORDER BY id', (agreement,))]

    def dispute(self, identifier):
        """One recorded provider dispute: {id, agreement, route, reference, payer, status, facts, updated_at}."""
        need(_object_id(identifier, 'du_') or _object_id(identifier, 'dp_'), 'STRIPE_DISPUTE_UNKNOWN')
        with self.gateway._exclusive():
            row = self.db.execute('SELECT id, agreement, route, reference, payer, status, facts, updated_at FROM '
                                  'stripe_payment_disputes WHERE id=?', (identifier,)).fetchone()
        need(row is not None, 'STRIPE_DISPUTE_UNKNOWN')
        return dict(zip(('id', 'agreement', 'route', 'reference', 'payer', 'status', 'facts', 'updated_at'),
                        (*row[:6], json.loads(row[6]), row[7])))

    def chain(self, agreement):
        """The agreement's evidence chain, oldest first."""
        key(agreement)
        with self.gateway._exclusive():
            return self._chain(agreement)

    def resolve(self, record):
        """An owner's signed resolution of an UNKNOWN operation that Stripe's API could not settle."""
        need(type(record) is dict and set(record) == {'body', 'signature'}, 'STRIPE_PAYMENT_RESOLUTION')
        body = _resolution(record['body'])
        need(body['principal'] == self.policy['principal'], 'STRIPE_PAYMENT_RESOLUTION')
        try:
            verify(body['principal'], RESOLUTION_LABEL, body, record['signature'])
        except ValueError:
            raise ValueError('STRIPE_PAYMENT_RESOLUTION') from None
        with self.gateway._exclusive():
            row = self._row(body['operation'])
            need(row is not None, 'STRIPE_PAYMENT_OPERATION_UNKNOWN')
            need(row['state'] == 'UNKNOWN' and row['provider_ref'] is None, 'STRIPE_PAYMENT_RESOLUTION_STATE')
            if body['decision'] == 'EXECUTED':
                # The owner points at the object; Stripe's own copy still decides the outcome.
                with self._transaction() as db:
                    db.execute('UPDATE stripe_payment_operations SET provider_ref=? WHERE id=?',
                               (body['provider_ref'], body['operation']))
                    self._evidence(db, row['agreement'], 'OWNER_RESOLUTION', body['operation'],
                                   {'resolution': deepcopy(record), 'next': 'RETRIEVE'})
                return self.reconcile(body['operation'])
            self._apply(body['operation'], {'result': 'FAILED', 'code': 'STRIPE_PAYMENT_RESOLUTION',
                                            'provider_ref': None, 'provider_status': None,
                                            'facts': {'resolution': digest(RESOLUTION_LABEL, body),
                                                      'basis': 'OWNER_SIGNED_NOT_EXECUTED'},
                                            'http_status': None, 'replayed': False, 'sha256': None}, 'RESOLUTION')
            with self._transaction() as db:
                self._evidence(db, row['agreement'], 'OWNER_RESOLUTION', body['operation'],
                               {'resolution': deepcopy(record)})
            return self.inspect(body['operation'])

    # -------------------------------------------------------- webhooks

    def _locate(self, value):
        """(route, reference) of the operation an authenticated event object belongs to, or (None, None)."""
        kind = value.get('object')
        meta = value.get('metadata') if type(value.get('metadata')) is dict else {}
        if kind in ('payment_intent', 'refund') and type(meta.get('aap_operation')) is str:
            row = self._row(meta['aap_operation']) if action.HEX.fullmatch(meta['aap_operation']) else None
            if row is not None:
                return 'payment_action', row['id']
        intent = value.get('id') if kind == 'payment_intent' else value.get('payment_intent')
        intent = _object_id(intent, 'pi_')
        charge = _object_id(value.get('id') if kind == 'charge' else value.get('charge'), 'ch_')
        if intent is not None:
            for row in self._rows("operation='pay' AND provider_ref=?", (intent,)):
                return 'payment_action', row['id']
            for (effect,) in self.db.execute("SELECT effect FROM stripe_intents WHERE "
                                             "json_extract(observation,'$.payment_intent')=?", (intent,)):
                return 'checkout', effect
        if charge is not None:
            for (ident,) in self.db.execute("SELECT id FROM stripe_payment_operations WHERE operation='pay' AND "
                                            "json_extract(facts,'$.charge')=?", (charge,)):
                return 'payment_action', ident
            for (effect,) in self.db.execute("SELECT effect FROM stripe_intents WHERE "
                                             "json_extract(observation,'$.charge_id')=?", (charge,)):
                return 'checkout', effect
        return None, None

    def ingest_event(self, raw_body, signature_header):
        """Authenticate a PaymentIntent, refund or dispute event, keep it once, then reconcile by retrieval."""
        now = self._now()
        verify_signature(raw_body, signature_header, self._webhook_secret, now, self.policy['webhook_tolerance'])
        event = _parse(raw_body)
        identifier = _object_id(event.get('id'), 'evt_')
        need(identifier is not None, 'STRIPE_PAYMENT_EVENT')
        need(event.get('type') in EVENT_TYPES and event.get('livemode') is self.checkout_policy['livemode'] and
             event.get('account', self.checkout_policy['account']) == self.checkout_policy['account'], 'STRIPE_PAYMENT_EVENT_SCOPE')
        data = event.get('data')
        need(type(data) is dict and type(data.get('object')) is dict, 'STRIPE_PAYMENT_EVENT')
        fingerprint = hashlib.sha256(raw_body).hexdigest()
        with self.gateway._exclusive():
            old = self.db.execute('SELECT digest, route, reference FROM stripe_payment_events WHERE id=?',
                                  (identifier,)).fetchone()
            if old is not None:
                need(old[0] == fingerprint, 'STRIPE_PAYMENT_EVENT_REPLAY_CHANGED')
                return {'event': identifier, 'type': event['type'], 'duplicate': True, 'route': old[1],
                        'reference': old[2], 'execution_authorized': False}
            route, reference = self._locate(data['object'])
            with self._transaction() as db:
                count = db.execute('SELECT count(*) FROM stripe_payment_events').fetchone()[0]
                need(count < MAX_EVENTS, 'STRIPE_PAYMENT_STORE_FULL')
                db.execute('INSERT INTO stripe_payment_events VALUES (?, ?, ?, ?, ?, ?)',
                           (identifier, fingerprint, event['type'], route, reference, now))
                agreement = None
                if route == 'payment_action':
                    agreement = self._row(reference)['agreement']
                elif route == 'checkout':
                    agreement = json.loads(self.db.execute('SELECT body FROM stripe_intents WHERE effect=?',
                                                           (reference,)).fetchone()[0])['agreement']
                if agreement is not None:
                    self._evidence(db, agreement, 'PROVIDER_EVENT', reference if route == 'payment_action' else None,
                                   {'event': identifier, 'type': event['type'], 'created': _int(event.get('created')),
                                    'object': _token(data['object'].get('id')), 'body_sha256': fingerprint,
                                    'authentication': 'STRIPE_SIGNATURE_HMAC_SHA256_VERIFIED',
                                    'route': route, 'reference': reference})
            # Never advance money from the event alone: pull the provider objects.
            state = None
            if route == 'payment_action':
                state = self.reconcile(reference)['state']
            elif route == 'checkout':
                self.observe_checkout(reference)
            return {'event': identifier, 'type': event['type'], 'duplicate': False, 'route': route,
                    'reference': reference, 'state': state, 'execution_authorized': False}

    # -------------------------------------------------------- Checkout under the shared rules

    def checkout(self, intent, approval):
        """Codex's Checkout execute(), refused while a payment action for the agreement or payer is unresolved."""
        effect = effect_id(intent)
        with self.gateway._exclusive():
            for row in self._rows('agreement=?', (intent['agreement'],)):
                need(row['state'] not in OPEN, 'STRIPE_PAYMENT_UNRESOLVED')
                need(not self._paid(row), 'STRIPE_PAYMENT_PAYMENT_OPEN')
            need(not self._rows("payer=? AND state='UNKNOWN'", (intent['payer'],)), 'STRIPE_PAYMENT_UNKNOWN_BLOCKS')
            exists = self.db.execute('SELECT 1 FROM stripe_intents WHERE effect=?', (effect,)).fetchone()
            if exists is None and type(intent.get('amount')) is int:
                held = self._commitments(self.db) + self._used(self.db, 'pay:aggregate', None, 0)
                need(held + intent['amount'] <= self.checkout_policy['operation_budget'], 'STRIPE_BUDGET_EXCEEDED')
            return self.gateway.execute(intent, approval)

    # -------------------------------------------------------- views and records

    def inspect(self, operation_id):
        key(operation_id)
        with self.gateway._exclusive():
            return self._inspect(operation_id)

    def _inspect(self, operation_id):
        row = self._row(operation_id)
        need(row is not None, 'STRIPE_PAYMENT_OPERATION_UNKNOWN')
        held = dict(self.db.execute('SELECT bucket, amount FROM stripe_payment_reservations WHERE operation=?',
                                    (operation_id,)).fetchall())
        result = {'version': action.VERSION, 'operation_id': operation_id, 'action': row['action'],
                  'operation': row['operation'], 'agreement': row['agreement'], 'payer': row['payer'],
                  'target': row['target'], 'amount': row['amount'], 'currency': row['body']['currency'],
                  'state': row['state'], 'outcome': row['outcome'], 'code': row['code'],
                  'provider_ref': row['provider_ref'], 'provider_status': row['provider_status'],
                  'facts': deepcopy(row['facts']), 'reservations': held, 'approval': row['approval'],
                  'attempts': row['attempts'], 'created_at': row['created_at'], 'submitted_at': row['submitted_at'],
                  'updated_at': row['updated_at'], 'blocks_new_payments': row['state'] in OPEN,
                  'provider': self.transport.assurance, 'delivery_verified': False,
                  'remaining_obligations': 'CHECK_THE_AGREEMENT_SEPARATELY', 'execution_authorized': False}
        if row['code'] is not None:
            result['explanation'] = action.explain(row['code'])
        return result

    def _chain(self, agreement):
        return [{'record': json.loads(body), 'previous': previous, 'link': link}
                for body, previous, link in self.db.execute(
                    'SELECT body, previous, link FROM stripe_payment_evidence WHERE agreement=? ORDER BY sequence',
                    (agreement,))]

    def portable_record(self, agreement):
        """Everything both sides need to review the payment a week later, without a provider dashboard."""
        key(agreement)
        with self.gateway._exclusive():
            operations = []
            approvals = {}
            for row in self._rows('agreement=?', (agreement,)):
                decision = None
                if row['approval'] is not None:
                    found = self.db.execute('SELECT decision FROM stripe_payment_approvals WHERE occurrence=?',
                                            (row['approval'],)).fetchone()
                    decision = json.loads(found[0]) if found and found[0] else None
                    ident, _, policy = self._approval_policy(row['body']['agent'])
                    approvals[ident] = policy
                operations.append({'record': row['record'], 'authorization': row['authorization'],
                                   'grant_chain': row['chain'], 'approval': decision, 'state': row['state'],
                                   'outcome': row['outcome'], 'code': row['code'], 'provider_ref': row['provider_ref'],
                                   'provider_status': row['provider_status'], 'facts': row['facts']})
            policies = [json.loads(raw) for (raw,) in self.db.execute(
                'SELECT record FROM stripe_payment_policies ORDER BY sequence')]
            checkout = [self.gateway.portable_record(effect) for effect, _, _, _ in self._checkouts('agreement', agreement)]
            chain = self._chain(agreement)
            disputes = self._disputes(agreement)
            return {'version': RECORD_VERSION, 'checkout_policy': self.gateway.pin, 'payment_policies': policies,
                    'approval_policies': [approvals[ident] for ident in sorted(approvals)], 'agreement': agreement,
                    'operations': operations, 'checkout': checkout, 'disputes': disputes, 'evidence': chain,
                    'head': chain[-1]['link'] if chain else NONE, 'provider': self.transport.assurance,
                    'evidence_kind': 'OWNER_REPORTED_OBSERVATION_REVERIFY_WITH_PROVIDER',
                    'credentials_included': False, 'delivery_verified': False, 'complete': False,
                    'public_disclosure_authorized': False}

    def snapshot(self):
        """Counts for health, readiness and metrics; no identifiers, amounts per party or secrets."""
        with self.gateway._exclusive():
            return self._snapshot()

    def _snapshot(self):
        now = self._now()
        states = dict(self.db.execute('SELECT state, count(*) FROM stripe_payment_operations GROUP BY state').fetchall())
        approvals = dict(self.db.execute(
            "SELECT status, count(*) FROM stripe_payment_approvals WHERE status IN ('PENDING','APPROVED') AND "
            'expires_at>=? GROUP BY status', (now,)).fetchall())
        reserved = dict(self.db.execute("SELECT substr(bucket, 1, instr(bucket, ':')-1), sum(amount) FROM "
                                        "stripe_payment_reservations WHERE bucket LIKE '%:agreement:%' GROUP BY 1"))
        return {'states': {state: states.get(state, 0) for state in STATES},
                'approvals': {status: approvals.get(status, 0) for status in ('PENDING', 'APPROVED')},
                'reserved': {name: reserved.get(name, 0) for name in ('pay', 'refund')},
                'checkout_commitments': self._commitments(self.db),
                'events': self.db.execute('SELECT count(*) FROM stripe_payment_events').fetchone()[0],
                'open_disputes': self.db.execute('SELECT count(*) FROM stripe_payment_disputes WHERE status NOT IN '
                                                 "('won','lost','warning_closed','prevented')").fetchone()[0],
                'evidence': self.db.execute('SELECT count(*) FROM stripe_payment_evidence').fetchone()[0],
                'observer_failures': self.observer_failures}

    def backup(self, destination):
        """An online SQLite copy of the whole custody file (Checkout and payments) into a new 0600 file."""
        target = Path(destination).expanduser().absolute()
        need(target.parent.is_dir() and not os.path.lexists(target), 'STRIPE_PAYMENT_BACKUP')
        parent = os.stat(target.parent)
        need(parent.st_uid == os.getuid() and stat.S_IMODE(parent.st_mode) & 0o077 == 0, 'STRIPE_PAYMENT_BACKUP')
        os.close(os.open(target, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600))
        with self.gateway._exclusive():
            copy = sqlite3.connect(str(target))
            try:
                from covenant_language.safe_io import durable_sqlite
                durable_sqlite(copy, journal='DELETE')  # the copy is one self-contained, fully synced file
                self.db.backup(copy)
            finally:
                copy.close()
        return str(target)


def dispute_facts(value):
    """The bounded facts of one Stripe Dispute object, or None when it is not one."""
    if type(value) is not dict or value.get('object') != 'dispute':
        return None
    identifier = _object_id(value, 'du_') or _object_id(value, 'dp_')
    details = value.get('evidence_details') if type(value.get('evidence_details')) is dict else {}
    amount = _int(value.get('amount'))
    status = _token(value.get('status'))
    if identifier is None or amount is None or status is None:
        return None
    return {'id': identifier, 'status': status, 'reason': _token(value.get('reason')), 'amount': amount,
            'currency': _token(value.get('currency')), 'charge': _object_id(value.get('charge'), 'ch_'),
            'payment_intent': _object_id(value.get('payment_intent'), 'pi_'),
            'due_by': _int(details.get('due_by')), 'has_evidence': details.get('has_evidence') is True,
            'past_due': details.get('past_due') is True,
            'is_charge_refundable': value.get('is_charge_refundable') is True,
            'created': _int(value.get('created'))}


def verify_record(record, *, expected_principal, expected_agreement, expected_head=None, checkout_policy=None):
    """Check a portable payment record offline: signatures, grants at acceptance, approvals and the chain.

    Provider facts stay owner observations; current authority and delivery are not established here.
    """
    _fields(record, 'version checkout_policy payment_policies approval_policies agreement operations checkout '
            'disputes evidence head provider evidence_kind credentials_included delivery_verified complete '
            'public_disclosure_authorized', 'STRIPE_PAYMENT_RECORD_PROFILE')
    need(record['version'] == RECORD_VERSION and record['credentials_included'] is False and
         record['delivery_verified'] is False and record['complete'] is False and
         record['evidence_kind'] == 'OWNER_REPORTED_OBSERVATION_REVERIFY_WITH_PROVIDER',
         'STRIPE_PAYMENT_RECORD_PROFILE')
    key(expected_principal); key(expected_agreement)
    need(record['agreement'] == expected_agreement, 'STRIPE_PAYMENT_RECORD_PIN')
    need(type(record['payment_policies']) is list and record['payment_policies'], 'STRIPE_PAYMENT_RECORD_PROFILE')
    policies = {}
    for item in record['payment_policies']:
        body = verify_policy(item)
        need(body['principal'] == expected_principal and body['checkout_policy'] == record['checkout_policy'],
             'STRIPE_PAYMENT_RECORD_PIN')
        policies[policy_id(body)] = body
    approval_policies = {}
    for item in record['approval_policies']:
        try:
            body = assent_gate.verify_policy(item)
        except ValueError:
            raise ValueError('STRIPE_PAYMENT_APPROVAL_POLICY') from None
        need(body['owner'] == expected_principal, 'STRIPE_PAYMENT_RECORD_PIN')
        approval_policies[assent_gate.policy_id(body)] = body
    previous, accepted = NONE, {}
    for row in record['evidence']:
        _fields(row, 'record previous link', 'STRIPE_PAYMENT_RECORD_CHAIN')
        entry = row['record']
        need(type(entry) is dict and entry.get('version') == EVIDENCE_VERSION and entry.get('previous') == previous and
             entry.get('agreement') == expected_agreement and row['previous'] == previous, 'STRIPE_PAYMENT_RECORD_CHAIN')
        link = digest(LINK_LABEL, {'previous': previous, 'evidence': digest(EVIDENCE_LABEL, entry)})
        need(row['link'] == link, 'STRIPE_PAYMENT_RECORD_CHAIN')
        if entry.get('kind') == 'ACTION_ACCEPTED':
            accepted[entry['operation']] = entry['at']
        previous = link
    need(record['head'] == previous and (expected_head is None or expected_head == previous), 'STRIPE_PAYMENT_RECORD_PIN')
    counts = {'actions': 0, 'payer_authorizations': 0, 'grants_at_acceptance': 0, 'approvals': 0}
    for row in record['operations']:
        body = action.verify_action(row['record'])
        need(body['agreement'] == expected_agreement and body['principal'] == expected_principal and
             body['policy'] in policies and body['operation_id'] in accepted, 'STRIPE_PAYMENT_RECORD_PIN')
        counts['actions'] += 1
        if body['operation'] == 'pay':
            action.check_authorization(body, row['authorization'])
            counts['payer_authorizations'] += 1
        pin = policies[body['policy']]['checkout_policy']
        scope = grant_scope(pin)
        try:
            checked = access.verify_chain(row['grant_chain'], context=scope['context'], target=scope['target'],
                                          operation=scope['operation'], subject=body['agent'],
                                          capability='stripe:' + body['operation'],
                                          trusted_issuers=[expected_principal], now=accepted[body['operation_id']])
        except (ValueError, TypeError, KeyError):
            raise ValueError('STRIPE_PAYMENT_GRANT_REFUSED') from None
        need(checked['leaf'] == body['grant'], 'STRIPE_PAYMENT_GRANT_MISMATCH')
        counts['grants_at_acceptance'] += 1
        if row['approval'] is not None:
            request = row['approval']['request']
            need(request['action'] == action.action_id(body) and request['policy'] in approval_policies and
                 row['approval']['decision'] == 'APPROVE', 'STRIPE_PAYMENT_APPROVAL_CHANGED')
            _check_proof(row['approval'], approval_policies[request['policy']])
            counts['approvals'] += 1
    checkout = 'NOT_CHECKED'
    if checkout_policy is not None:
        from .stripe_gateway import verify_record as verify_checkout
        for item in record['checkout']:
            verify_checkout(item, checkout_policy, expected_effect=item['effect'])
        checkout = 'PAYER_APPROVALS_VERIFIED'
    return {'agreement': expected_agreement, 'head': previous, **{k + '_verified': v for k, v in counts.items()},
            'evidence_chain': 'VERIFIED', 'checkout_records': checkout,
            'revocation': 'NOT_RECHECKED_OFFLINE_ONLY_AS_OF_ACCEPTANCE', 'provider_payment_verified': False,
            'provider_status': 'REVERIFY_WITH_ADOPTED_PROVIDER', 'delivery_verified': False,
            'current_authority': 'NOT_ESTABLISHED', 'execution_authorized': False}


def prometheus(snapshot):
    """Prometheus text exposition (format 0.0.4) of snapshot()."""
    lines = ['# HELP aap_stripe_payment_operations Payment actions in owner custody, by state.',
             '# TYPE aap_stripe_payment_operations gauge']
    lines += ['aap_stripe_payment_operations{state="%s"} %d' % (state, snapshot['states'][state]) for state in STATES]
    lines += ['# HELP aap_stripe_payment_approvals Owner approval requests not yet used, by status.',
              '# TYPE aap_stripe_payment_approvals gauge']
    lines += ['aap_stripe_payment_approvals{status="%s"} %d' % (status, count)
              for status, count in sorted(snapshot['approvals'].items())]
    lines += ['# HELP aap_stripe_payment_reserved_minor_units Amounts held by reservations, by operation.',
              '# TYPE aap_stripe_payment_reserved_minor_units gauge']
    lines += ['aap_stripe_payment_reserved_minor_units{operation="%s"} %d' % (name, amount)
              for name, amount in sorted(snapshot['reserved'].items())]
    for name, text in (('checkout_commitments', 'Retained Checkout commitments in minor units.'),
                       ('events', 'Authenticated provider events kept.'),
                       ('open_disputes', 'Provider disputes not yet closed.'),
                       ('evidence', 'Evidence records in the payment chains.')):
        lines += ['# HELP aap_stripe_payment_%s %s' % (name, text),
                  '# TYPE aap_stripe_payment_%s gauge' % name,
                  'aap_stripe_payment_%s %d' % (name, snapshot[name])]
    lines += ['# HELP aap_stripe_payment_observer_failures_total Outcome observer calls that raised; outcomes are unchanged.',
              '# TYPE aap_stripe_payment_observer_failures_total counter',
              'aap_stripe_payment_observer_failures_total %d' % snapshot['observer_failures']]
    return '\n'.join(lines) + '\n'


def describe():
    return {**action.describe(), 'extends': 'covenant_agent.stripe_gateway (covenant-stripe-checkout/0.1, unchanged)',
            'policy': POLICY_VERSION, 'approval': APPROVAL_VERSION, 'record': RECORD_VERSION,
            'states': list(STATES), 'unknown_blocks': ['retry', 'checkout', 'other rails'],
            'reconciliation': ['retrieve by id', 'metadata search', 'same-key replay within 23 hours on request',
                               'owner-signed resolution'],
            'webhooks': list(EVENT_TYPES), 'delivery_verified': False}
