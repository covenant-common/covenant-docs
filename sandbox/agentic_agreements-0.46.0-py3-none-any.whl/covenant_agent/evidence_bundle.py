"""Portable, verifiable agreement-evidence bundles between hosts.

A bundle carries exact retained bytes (signed envelopes and delivered content)
with their CIDs and no clock claim, a digest over the whole body and, when the exporting host has
a signer, an Ed25519 signature under a dedicated label. The label is not an
assent label: exporting states only "this host held these bytes".

Import checks everything before it stores anything, and refuses:

* an unknown format or extra fields (EVIDENCE_BUNDLE_FORMAT),
* a body that no longer matches its digest (EVIDENCE_BUNDLE_DIGEST),
* a bad exporter signature (EVIDENCE_BUNDLE_SIGNATURE),
* a bundle from an exporter other than the pinned one, or addressed to a
  different audience (EVIDENCE_BUNDLE_FOREIGN),
* an unpinned bundle (EVIDENCE_BUNDLE_UNPINNED): the caller must pin either the
  exporter key or the exact bundle digest it obtained separately,
* bytes that do not hash to their CID (EVIDENCE_CID_MISMATCH),
* envelopes that fail their own profile verification (EVIDENCE_ENVELOPE_INVALID).

Importing retains bytes. It does not adopt the exporter's provider, observe a
payment, establish delivery or grant authority.
"""
import base64
import re

from .cid import cid_from_bytes, cid_matches
from .codec import canonical, digest, loads, public_key, sign, signature_ok
from .errors import NativeError, need

VERSION = 'covenant-evidence-bundle/0.1'
LABEL = 'COVENANT-EVIDENCE-BUNDLE-0.1'
PROFILES = ('covenant-bilateral/0.1', 'covenant-bilateral/0.2')
MAX_ENTRIES = 64
MAX_TOTAL = 2_000_000
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_BODY = ('format', 'exporter', 'audience', 'entries')


def _key(value):
    return type(value) is str and bool(_HEX.fullmatch(value))


def _kind(blob):
    if not blob.startswith(b'{'):
        return 'CONTENT', None
    try:
        value = loads(blob)
    except ValueError:
        return 'CONTENT', None
    if type(value) is dict and value.get('profile') in PROFILES and canonical(value) == blob:
        return 'ENVELOPE', value
    return 'CONTENT', None


def _linked(envelope):
    return [row['content_cid'] for row in envelope.get('deliveries') or []
            if type(row) is dict and type(row.get('content_cid')) is str]


def bundle_digest(body):
    return digest(LABEL, {key: body[key] for key in _BODY})


def export(store, cids, *, signer=None, audience=None, include_linked=True):
    """Bundle exact retained bytes; linked delivery content is added when held."""
    need(type(cids) is list and 1 <= len(cids) <= MAX_ENTRIES and all(type(c) is str for c in cids), 'EVIDENCE_CIDS')
    need(audience is None or _key(audience), 'PUBLIC_KEY')
    wanted = list(dict.fromkeys(cids))
    blobs = {}
    missing_linked = []
    position = 0
    while position < len(wanted):
        cid = wanted[position]
        position += 1
        blob = store.get(cid)
        if blob is None:
            need(cid not in cids, 'EVIDENCE_CONTENT_NOT_FOUND')
            missing_linked.append(cid)
            continue
        canonical_cid = cid_from_bytes(blob)
        blobs[canonical_cid] = blob
        kind, value = _kind(blob)
        if include_linked and kind == 'ENVELOPE':
            for linked in _linked(value):
                if linked not in wanted:
                    wanted.append(linked)
        need(len(blobs) <= MAX_ENTRIES, 'EVIDENCE_BUNDLE_SIZE')
    need(sum(len(blob) for blob in blobs.values()) <= MAX_TOTAL, 'EVIDENCE_BUNDLE_SIZE')
    entries = [{'cid': cid, 'kind': _kind(blob)[0], 'bytes_base64': base64.b64encode(blob).decode('ascii')}
               for cid, blob in sorted(blobs.items())]
    body = {'format': VERSION, 'exporter': public_key(signer) if signer is not None else None,
            'audience': audience, 'entries': entries}
    value = bundle_digest(body)
    bundle = {**body, 'bundle_digest': value,
              'signature': sign(signer, LABEL, {'bundle_digest': value}) if signer is not None else None}
    return {'bundle': bundle, 'bundle_digest': value, 'entries': len(entries),
            'missing_linked': sorted(missing_linked), 'signed': signer is not None,
            'portable': True, 'payment_observed': False, 'execution_authorized': False,
            'next_action': ('Give the recipient this bundle and, separately, the exporter key or bundle_digest '
                            'to pin. The recipient imports with covenant_evidence_import.')}


def check(bundle, *, expected_exporter=None, expected_digest=None, audience=None):
    """Verify a bundle completely without storing anything; returns decoded entries."""
    need(type(bundle) is dict and set(bundle) == set(_BODY) | {'bundle_digest', 'signature'}, 'EVIDENCE_BUNDLE_FORMAT')
    need(bundle['format'] == VERSION, 'EVIDENCE_BUNDLE_FORMAT')
    need(bundle['exporter'] is None or _key(bundle['exporter']), 'EVIDENCE_BUNDLE_FORMAT')
    need(bundle['audience'] is None or _key(bundle['audience']), 'EVIDENCE_BUNDLE_FORMAT')
    entries = bundle['entries']
    need(type(entries) is list and 1 <= len(entries) <= MAX_ENTRIES, 'EVIDENCE_BUNDLE_FORMAT')
    need(expected_exporter is None or _key(expected_exporter), 'PUBLIC_KEY')
    need(expected_digest is None or _key(expected_digest), 'EVIDENCE_DIGEST_PIN')
    need(audience is None or _key(audience), 'PUBLIC_KEY')
    try:
        computed = bundle_digest(bundle)
    except NativeError:
        raise NativeError('EVIDENCE_BUNDLE_FORMAT') from None
    need(bundle['bundle_digest'] == computed, 'EVIDENCE_BUNDLE_DIGEST')
    need(expected_exporter is not None or expected_digest is not None, 'EVIDENCE_BUNDLE_UNPINNED')
    if expected_digest is not None:
        need(computed == expected_digest, 'EVIDENCE_BUNDLE_FOREIGN')
    if expected_exporter is not None:
        need(bundle['exporter'] == expected_exporter, 'EVIDENCE_BUNDLE_FOREIGN')
        need(type(bundle['signature']) is str and
             signature_ok(expected_exporter, LABEL, {'bundle_digest': computed}, bundle['signature']),
             'EVIDENCE_BUNDLE_SIGNATURE')
    elif bundle['signature'] is not None:
        need(bundle['exporter'] is not None and type(bundle['signature']) is str and
             signature_ok(bundle['exporter'], LABEL, {'bundle_digest': computed}, bundle['signature']),
             'EVIDENCE_BUNDLE_SIGNATURE')
    need(bundle['audience'] is None or bundle['audience'] == audience, 'EVIDENCE_BUNDLE_FOREIGN')
    decoded = []
    seen = set()
    total = 0
    for entry in entries:
        need(type(entry) is dict and set(entry) == {'cid', 'kind', 'bytes_base64'} and
             entry['kind'] in ('ENVELOPE', 'CONTENT') and type(entry['cid']) is str and
             type(entry['bytes_base64']) is str, 'EVIDENCE_BUNDLE_FORMAT')
        try:
            blob = base64.b64decode(entry['bytes_base64'], validate=True)
        except (ValueError, UnicodeError):
            raise NativeError('EVIDENCE_BUNDLE_FORMAT') from None
        need(blob and base64.b64encode(blob).decode('ascii') == entry['bytes_base64'], 'EVIDENCE_BUNDLE_FORMAT')
        try:
            matched = cid_matches(entry['cid'], blob) and cid_from_bytes(blob) == entry['cid']
        except NativeError:
            matched = False
        need(matched, 'EVIDENCE_CID_MISMATCH')
        need(entry['cid'] not in seen, 'EVIDENCE_BUNDLE_DUPLICATE')
        seen.add(entry['cid'])
        total += len(blob)
        need(total <= MAX_TOTAL, 'EVIDENCE_BUNDLE_SIZE')
        kind, value = _kind(blob)
        need(kind == entry['kind'], 'EVIDENCE_BUNDLE_FORMAT')
        verdict = None
        if kind == 'ENVELOPE':
            from .envelope import verify
            report = verify(value)
            need(report['ok'], 'EVIDENCE_ENVELOPE_INVALID')
            verdict = report['verdict']
        decoded.append((entry['cid'], kind, blob, verdict))
    return computed, decoded


def import_bundle(store, bundle, *, expected_exporter=None, expected_digest=None, audience=None):
    """All-or-nothing import into ``store`` after :func:`check` passes."""
    computed, decoded = check(bundle, expected_exporter=expected_exporter,
                              expected_digest=expected_digest, audience=audience)
    imported, present = [], []
    for cid, _kind_name, blob, _verdict in decoded:
        (present if cid in store else imported).append(cid)
    for _cid, _kind_name, blob, _verdict in decoded:
        store.put(blob)
    return {'version': VERSION, 'bundle_digest': computed, 'exporter': bundle['exporter'],
            'pinned_by': 'EXPORTER_KEY' if expected_exporter is not None else 'BUNDLE_DIGEST',
            'imported': imported, 'already_present': present,
            'envelopes': [{'cid': cid, 'signed_stage': verdict} for cid, kind, _blob, verdict in decoded if kind == 'ENVELOPE'],
            'content': [cid for cid, kind, _blob, _verdict in decoded if kind == 'CONTENT'],
            'trust': 'BYTES_AND_SIGNATURES_CHECKED; SIGNED_CLAIMS_NOT_WORLD_TRUTH; EXPORTER_PROVIDER_NOT_ADOPTED',
            'funds_observed': False, 'payment_rail_touched': False, 'execution_authorized': False}
