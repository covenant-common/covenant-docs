"""Graft: the Universal Commerce Protocol (UCP) checkout, bound to the same AAP record.

Implements the subset confirmed in Universal-Commerce-Protocol/ucp release
v2026-08-25 (Apache-2.0): docs/specification/overview/index.md sections
"Namespace Governance" (naming and authority binding), "Extensions",
"Schema Composition" and "Capability Declaration in Responses"; the schemas
source/schemas/shopping/checkout.json, order.json, types/line_item.json,
types/adjustment.json, types/fulfillment_event.json and
common/types/totals.json; and the order webhook rules of
docs/specification/shopping/order/index.md.

The extension io.github.covenant-common.shopping.agreement extends
dev.ucp.shopping.checkout and dev.ucp.shopping.order with the same
aap_agreement field the ACP extension carries, so one AAP record covers either
checkout. The RFC 9530 body digest is recorded and compared when supplied.
An order webhook's RFC 9421 signature is verified when the platform passes the
received request and the business keys it adopted from that business's UCP
profile, under docs/specification/signatures.md "REST Request Verification"
and overview "Identity Resolution Algorithm" of the same release: untagged or
web-bot-auth signatures only; @method, @authority, @path (and @query),
content-digest with sha-256, content-type and every present ucp-agent,
signature-agent and idempotency-key header covered; a web-bot-auth keyid is
the key's RFC 7638 thumbprint. Without them the evidence says
RFC9421_NOT_VERIFIED, as before.
"""
from copy import deepcopy
import hashlib
import ipaddress
import re
from urllib.parse import urlsplit

from . import commerce
from .errors import NativeError

VERSION = '2026-08-25'
NAME = commerce.EXTENSION
PARENTS = ('dev.ucp.shopping.checkout', 'dev.ucp.shopping.order')
SCHEMA_URL = 'https://covenant-common.github.io/covenant-docs/schemas/ucp-aap-agreement-2026-10-25.json'
BASE = {'dev.ucp.shopping.checkout': 'https://ucp.dev/schemas/shopping/checkout.json',
        'dev.ucp.shopping.order': 'https://ucp.dev/schemas/shopping/order.json'}
# Pattern copied from source/schemas/common/types/reverse_domain_name.json (Apache-2.0, see NOTICE).
REVERSE_DOMAIN = re.compile(r'^[a-z](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9_-]*[a-z0-9_])?)+$')
STATUSES = ('incomplete', 'requires_escalation', 'ready_for_complete', 'complete_in_progress', 'completed', 'canceled')

HINTS = {
    'UCP_URL': 'Pass an https URL of at most 512 printable characters without user information or backslashes.',
    'UCP_AUTHORITY': 'The schema URL host, reversed, must equal or be a label-aligned prefix of the entity name.',
    'UCP_EXTENSION': 'Use the reverse-domain name and parents returned by covenant_commerce.extension.',
    'UCP_CHECKOUT': 'Pass a UCP checkout response (2026-08-25) with ucp, id, line_items, status, currency, totals and links.',
    'UCP_CHECKOUT_CLOSED': 'This checkout is canceled. Start a new checkout before drafting an agreement.',
    'UCP_TOTALS': 'UCP totals must contain exactly one subtotal and one total, each with an integer amount.',
    'UCP_LINE_ITEMS': 'Each line item needs id, item.id, an integer quantity and integer totals.',
    'UCP_ORDER': 'Pass the full UCP order entity with ucp, id, checkout_id, permalink_url, line_items, fulfillment, currency and totals.',
    'UCP_ORDER_FOREIGN': 'This order references another checkout than the agreed checkout_id.',
    'UCP_CONTENT_DIGEST': 'The Content-Digest header does not match the SHA-256 of the exact body (RFC 9530).',
    'UCP_COMPLETED': 'Pass the completed checkout response with status completed and order {id, permalink_url}.',
    'UCP_SIGNATURE': 'The webhook RFC 9421 signature did not verify under the business keys you adopted; do not record it '
                     'as authenticated. Pass request {method, target_uri, headers}, signer_keys (the adopted profile keys) '
                     'and now together.',
}
SIGNED_HEADERS = ('ucp-agent', 'signature-agent', 'idempotency-key')


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS.get(code) or commerce.HINTS[code])


def _url(value):
    need(type(value) is str and value.startswith('https://') and 8 < len(value) <= 512 and
         all(33 <= ord(c) <= 126 for c in value) and '\\' not in value, 'UCP_URL')
    return value


def authority(name, schema_url):
    """UCP authority binding: reversed schema host equals, or is a label-aligned prefix of, the name."""
    need(type(name) is str and REVERSE_DOMAIN.fullmatch(name) is not None, 'UCP_EXTENSION')
    _url(schema_url)
    parts = urlsplit(schema_url)
    need(parts.scheme == 'https' and '@' not in parts.netloc and not parts.netloc.startswith('['), 'UCP_AUTHORITY')
    host = (parts.hostname or '').rstrip('.')
    try:
        ipaddress.ip_address(host)
        literal = True
    except ValueError:
        literal = False
    labels = host.split('.')
    need(not literal and len(labels) >= 2 and all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label)
                                                  for label in labels), 'UCP_AUTHORITY')
    prefix = '.'.join(reversed(labels))
    need(name == prefix or name.startswith(prefix + '.'), 'UCP_AUTHORITY')
    return {'name': name, 'schema': schema_url, 'authority': prefix, 'binding': 'EXACT' if name == prefix else 'PREFIX',
            'meaning': 'PROVENANCE_OF_THE_NAME_ONLY_NOT_TRUST', **commerce.FLAGS}


def json_schema(schema_url=SCHEMA_URL):
    """The self-describing UCP extension schema: one $defs entry per parent capability."""
    _url(schema_url)
    field = commerce.field_schema()
    field.pop('$schema'); field.pop('$id')
    defs = {'aap_agreement': field}
    for parent in PARENTS:
        defs[parent] = {'title': ('Checkout' if parent.endswith('checkout') else 'Order') + ' with AAP agreement reference',
                        'allOf': [{'$ref': BASE[parent]},
                                  {'type': 'object', 'properties': {commerce.FIELD: {
                                      '$ref': '#/$defs/aap_agreement',
                                      'ucp_request': {'create': 'optional', 'update': 'optional', 'complete': 'omit'}
                                      if parent.endswith('checkout') else 'omit'}}}]}
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': schema_url, 'name': NAME,
            'version': commerce.EXTENSION_VERSION, 'title': 'AAP agreement reference',
            'description': 'Binds a UCP checkout and its order to an Agentic Agreements Protocol (AAP) agreement. '
                           'Data only: it grants no assent, payment or release authority.',
            'requires': {'protocol': {'min': VERSION},
                         'capabilities': {parent: {'min': VERSION} for parent in PARENTS}},
            '$defs': defs}


def extension(schema_url=SCHEMA_URL, spec_url=commerce.SPEC_URL):
    """The profile capability entry (business or platform) and its authority check."""
    _url(spec_url)
    entry = {'version': commerce.EXTENSION_VERSION, 'spec': spec_url, 'schema': _url(schema_url), 'extends': list(PARENTS)}
    return {'protocol': 'UCP', 'version': VERSION, 'field': commerce.FIELD, 'capabilities': {NAME: [entry]},
            'response_capability': {NAME: [{'version': commerce.EXTENSION_VERSION}]},
            'authority': authority(NAME, schema_url), 'schema_document': json_schema(schema_url),
            'rules': ['Pruned with its parents by the UCP intersection algorithm; absent means not active.',
                      'The field is never placed inside the reserved ucp member.',
                      'An echoed aap_agreement must equal the reference the platform sent; any change refuses.'],
            'publication': 'SCHEMA_AND_SPEC_URLS_ARE_PROPOSED_UNTIL_THE_OWNER_PUBLISHES_THEM', **commerce.FLAGS}


def _parse(raw):
    value, data = commerce.document(raw)
    return commerce.no_credentials(value), data


def _int(value, code):
    need(type(value) is int and 0 <= value <= commerce.MAX, code)
    return value


def _text(value, code, limit=256):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _totals(totals, code):
    """Exactly one subtotal and one total (common/types/totals.json)."""
    need(type(totals) is list and len(totals) <= 64, code)
    seen = {}
    for row in totals:
        need(type(row) is dict and type(row.get('type')) is str and type(row.get('amount')) is int and
             abs(row['amount']) <= commerce.MAX, code)
        if row['type'] in ('subtotal', 'total'):
            need(row['type'] not in seen, code)
            seen[row['type']] = row['amount']
    need(set(seen) == {'subtotal', 'total'} and seen['total'] >= 0, code)
    return seen['total']


def _envelope(value, code):
    ucp = value.get('ucp')
    need(type(ucp) is dict and type(ucp.get('version')) is str, code)
    need(ucp['version'] == VERSION, 'COMMERCE_PROTOCOL_VERSION')
    capabilities = ucp.get('capabilities') or {}
    need(type(capabilities) is dict, code)
    return NAME in capabilities


def checkout(raw, merchant):
    """Read a UCP checkout response into AAP order terms; buyer details are only hashed."""
    session, data = _parse(raw)
    need(type(session) is dict and {'ucp', 'id', 'line_items', 'status', 'currency', 'totals', 'links'} <= set(session),
         'UCP_CHECKOUT')
    active = _envelope(session, 'UCP_CHECKOUT')
    _text(session['id'], 'UCP_CHECKOUT')
    need(session['status'] in STATUSES, 'UCP_CHECKOUT')
    need(session['status'] != 'canceled', 'UCP_CHECKOUT_CLOSED')
    total = _totals(session['totals'], 'UCP_TOTALS')
    lines = session['line_items']
    need(type(lines) is list and 1 <= len(lines) <= 32, 'UCP_LINE_ITEMS')
    items = []
    for line in lines:
        need(type(line) is dict and type(line.get('item')) is dict and type(line.get('quantity')) is int and
             line['quantity'] >= 1, 'UCP_LINE_ITEMS')
        _text(line.get('id'), 'UCP_LINE_ITEMS'); _text(line['item'].get('id'), 'UCP_LINE_ITEMS')
        line_total = None
        rows = line.get('totals')
        need(type(rows) is list and len(rows) <= 64, 'UCP_LINE_ITEMS')
        for row in rows:
            need(type(row) is dict and type(row.get('amount')) is int and abs(row['amount']) <= commerce.MAX, 'UCP_LINE_ITEMS')
            if row.get('type') == 'total' and row['amount'] >= 0:
                line_total = row['amount']
        title = line['item'].get('title')
        title = title if type(title) is str and 0 < len(title.encode('utf-8')) <= 256 else None
        items.append({'id': line['id'], 'quantity': line['quantity'], 'total': line_total, 'title': title})
    terms = commerce.order('UCP', VERSION, hashlib.sha256(data).hexdigest(), session['id'], merchant,
                           session['currency'], total, items, None, None)
    echoed = session.get(commerce.FIELD)
    return {'order': terms, 'status': session['status'], 'extension_active': active,
            'echo': commerce.echo_status(echoed),
            'content_digest': commerce.content_digest(data), 'buyer_details': 'HASHED_IN_CHECKOUT_NOT_COPIED',
            **commerce.FLAGS}


def draft(raw, merchant, parties, context, acceptance, remedy, remedy_reference=None):
    """An AAP agreement draft from a UCP checkout, plus the update body that carries its reference."""
    read = checkout(raw, merchant)
    made = commerce.draft(read['order'], parties, context, acceptance, remedy, remedy_reference=remedy_reference)
    made['checkout_update'] = {commerce.FIELD: deepcopy(made['reference'])}
    made['extension_active'] = read['extension_active']
    return made


def _digest_header(header, data):
    if header is None:
        return {'method': 'RFC9421_NOT_VERIFIED', 'status': 'NOT_CHECKED', 'detail': 'NO_CONTENT_DIGEST_SUPPLIED'}
    need(type(header) is str and len(header) <= 512, 'UCP_CONTENT_DIGEST')
    members = [m.strip() for m in header.split(',')]
    expected = commerce.content_digest(data)
    need(expected in members, 'UCP_CONTENT_DIGEST')
    return {'method': 'RFC9421_NOT_VERIFIED', 'status': 'NOT_CHECKED',
            'detail': 'CONTENT_DIGEST_MATCHES_BODY; SIGNATURE_NOT_VERIFIED_SO_SENDER_NOT_AUTHENTICATED'}


def _signed_request(request, data, signer_keys, now):
    """Verify the business's RFC 9421 webhook signature against keys the platform adopted; never fetches a profile."""
    from covenant_chain import http_signatures as httpsig
    need(type(request) is dict and set(request) == {'method', 'target_uri', 'headers'} and signer_keys is not None
         and type(now) is int, 'UCP_SIGNATURE')
    try:
        received = httpsig.message({**request, 'body': data})
        required = ['@method', '@authority', '@path', 'content-digest', 'content-type']
        required += ['@query'] if received['query'] is not None else []
        required += [name for name in SIGNED_HEADERS if httpsig.field(received, name) is not None]
        keys = signer_keys
        if type(keys) is str:
            keys = commerce.document(keys.encode('utf-8'))[0]
        result = httpsig.verify(received, keys, now, tag=[None, httpsig.WEB_BOT_AUTH_TAG], required=required)
        digests = httpsig.check_content_digest(httpsig.field(received, 'content-digest'), data)
        need('sha-256' in digests['algorithms'], 'UCP_SIGNATURE')
    except ValueError as error:
        code = str(error)
        raise NativeError('UCP_SIGNATURE', HINTS['UCP_SIGNATURE'] + (' (' + code + ')' if code.startswith('HTTPSIG_') else '')) from None
    profile = httpsig.field(received, 'ucp-agent')
    detail = ('SIGNATURE_VERIFIED; KEYID ' + result['keyid'] + '; ALG ' + result['algorithm'] + '; COVERED ' +
              ' '.join(result['covered']) + '; CONTENT_DIGEST sha-256; SIGNED_UCP_AGENT ' + (profile or 'ABSENT') +
              '; KEYS_ADOPTED_BY_CALLER_NOT_FETCHED')
    return {'method': 'RFC9421_HTTP_MESSAGE_SIGNATURE', 'status': 'VERIFIED', 'detail': detail[:2048]}


def order_event(application, raw_body, *, content_digest_header=None, request=None, signer_keys=None, now=None):
    """Record a UCP order webhook (full order entity) as evidence for the agreement.

    With ``request`` (the received method, target URI and headers), ``signer_keys`` (the business
    profile keys the platform adopted) and ``now`` (the caller's clock), the webhook's RFC 9421
    signature must verify; otherwise the evidence records RFC9421_NOT_VERIFIED.
    """
    t = commerce.terms(application)
    order, data = _parse(raw_body)
    need(type(order) is dict and {'ucp', 'id', 'checkout_id', 'permalink_url', 'line_items', 'fulfillment',
                                  'currency', 'totals'} <= set(order), 'UCP_ORDER')
    _envelope(order, 'UCP_ORDER')
    _text(order['id'], 'UCP_ORDER'); _text(order['checkout_id'], 'UCP_ORDER')
    need(order['checkout_id'] == t['checkout_id'], 'UCP_ORDER_FOREIGN')
    summary = {'order': order['id'], 'checkout_id': order['checkout_id'], 'total': _totals(order['totals'], 'UCP_TOTALS'),
               'currency': order['currency'] if type(order['currency']) is str and len(order['currency']) == 3 else None,
               'line_items': [], 'fulfillment_events': [], 'adjustments': []}
    for row in order['line_items'] if type(order['line_items']) is list else []:
        quantity = row.get('quantity') if type(row) is dict else None
        if type(quantity) is dict and type(row.get('id')) is str:
            summary['line_items'].append({'id': row['id'][:256], **{k: quantity[k] for k in ('original', 'total', 'fulfilled')
                                                                   if type(quantity.get(k)) is int},
                                          'status': str(row.get('status'))[:32]})
    fulfillment = order['fulfillment'] if type(order['fulfillment']) is dict else {}
    for row in commerce.items(fulfillment.get('events')):
        if type(row) is dict and type(row.get('id')) is str:
            summary['fulfillment_events'].append({'id': row['id'][:256], 'type': str(row.get('type'))[:32],
                                                  'occurred_at': str(row.get('occurred_at'))[:64]})
    for row in commerce.items(order.get('adjustments')):
        if type(row) is dict and type(row.get('id')) is str:
            signed = [r.get('amount') for r in commerce.items(row.get('totals')) if type(r) is dict and r.get('type') == 'total'
                      and type(r.get('amount')) is int]
            summary['adjustments'].append({'id': row['id'][:256], 'type': str(row.get('type'))[:32],
                                           'status': str(row.get('status'))[:32], 'total': signed[0] if signed else None})
    for name in ('line_items', 'fulfillment_events', 'adjustments'):
        summary[name] = summary[name][:64]
    echoed = order.get(commerce.FIELD)
    summary['reference_echo'] = commerce.echo_status(echoed, application)
    if request is not None:
        need(content_digest_header is None, 'UCP_SIGNATURE')
        authentication = _signed_request(request, data, signer_keys, now)
    else:
        need(signer_keys is None, 'UCP_SIGNATURE')
        authentication = _digest_header(content_digest_header, data)
    return commerce.evidence('UCP', 'ORDER_EVENT', t['application'], data, summary, authentication=authentication)


def completed(application, raw):
    """Record the completed UCP checkout with its order confirmation; the total is compared, never trusted."""
    t = commerce.terms(application)
    session, data = _parse(raw)
    need(type(session) is dict and session.get('status') == 'completed' and type(session.get('order')) is dict, 'UCP_COMPLETED')
    _envelope(session, 'UCP_COMPLETED')
    need(session.get('id') == t['checkout_id'], 'UCP_ORDER_FOREIGN')
    order = session['order']
    _text(order.get('id'), 'UCP_COMPLETED')
    total = _totals(session.get('totals'), 'UCP_TOTALS')
    currency = session.get('currency')
    summary = {'order': order['id'], 'checkout_id': session['id'], 'session_total': total,
               'session_currency': currency if type(currency) is str and len(currency) == 3 else None,
               'price_matches': total == t['amount'] and type(currency) is str and currency.lower() == t['currency'].lower()}
    echoed = session.get(commerce.FIELD)
    summary['reference_echo'] = commerce.echo_status(echoed, application)
    return commerce.evidence('UCP', 'CHECKOUT_COMPLETED', t['application'], data, summary)
