"""Machine-readable codes for the agent-native work-order surface.

A code is the exception text. Remediation is a separate hint an agent can follow
without guessing. Hints never tell the caller to weaken a signature check.

``refusal`` is the one shape every refusal takes where it crosses the agent
boundary: status REFUSED, code, what (what happened), fix (what to do next),
retry (yes, after the fix, or no) and reference, a link to the code's entry in
docs/REFERENCE.html. The field names match the aap command's refusals.
"""
from functools import lru_cache
import json
from pathlib import Path
import re

REMEDIATION = {
    'PROGRESS_CONFLICT': 'Reload the retained signed progress and reconcile its exact lineage. A stale or conflicting branch cannot replace it.',
    'DELIVERY_CID': 'Obtain the exact delivery whose retained bytes match its CID; do not replace the CID to accept changed content.',
    'APPEAL_PARENT': 'Bind this appeal to the exact retained primary decision and obtain a fresh authorized signature.',
    'DECISION_BINDING': 'Check the decision agreement, evidence hash and authorized resolver against the retained order.',
    'COMMERCE_PROTOCOL_VERSION': 'Use a supported declared ACP or UCP snapshot; preserve the received bytes and select an explicit compatible adapter.',
    'COMMERCE_CLOCK': 'Pass a nonnegative integer observation time under the adopted clock policy; a signed timestamp remains a claim.',
    'OPEN_WORK_TEXT': 'Supply bounded printable text for this exact open-order field; use a separate byte document for other encodings.',
    'OPEN_WORK_HASH': 'Supply the retained 64-character lowercase SHA-256 reference for the exact object.',
    'OPEN_WORK_KEY': 'Supply a supported verification key; never a private signing seed.',
    'OPEN_WORK_INTEGER': 'Supply an exact nonnegative integer within the documented bound; booleans and floats are not quantities.',
    'OPEN_WORK_RAIL': 'Declare the rail identifier and its adopted verifier. An unknown rail remains unverified.',
    'OPEN_WORK_DISTINCT_PARTIES': 'Use distinct actual party keys for this open order and obtain their fresh exact assent.',
    'OPEN_WORK_CHANGED': 'The order changed. Preserve the earlier version, review the complete successor and obtain fresh signatures.',
    'OPEN_WORK_CLAIMS': 'Supply only the exact typed claims required by the selected open-order action; claims do not prove execution.',
    'OPEN_WORK_RECORDS': 'Supply the bounded complete record list in its original causal order.',
    'OPEN_WORK_ASSENT': 'Obtain the missing valid party assent over the exact order and selected profile.',
    'OPEN_WORK_NOT_BOUND': 'Both required parties must explicitly assent before advancing this order.',
    'OPEN_WORK_EVENT_CHAIN': 'Restore the exact prior head and sequence; do not splice events from another order or branch.',
    'OPEN_WORK_CLOCK_ORDER': 'Keep event times within the adopted ordering constraints. Resolve clock uncertainty before advancing.',
    'OPEN_WORK_ACTION': 'Select an action permitted by this open-order profile and current state.',
    'OPEN_WORK_EVENT_AUTHORITY': 'Obtain this event from the role explicitly authorized in the agreed order; metadata cannot grant that role.',
    'OPEN_WORK_OBSERVER': 'The owner must install the appropriate observation adapter; agreement text cannot install one.',
    'OPEN_WORK_OBSERVATION': 'Obtain an exact observation under the adopted source and verifier. Missing or invalid evidence remains unknown.',
    'SIZE_LIMIT': 'Shorten the document or content. The canonical form must stay inside the byte cap.',
    'DEPTH_LIMIT': 'Flatten the object. Nested containers are capped.',
    'INTEGER_RANGE': 'Use an integer between 0 and 2^53-1. Booleans and floats are refused.',
    'ASCII_PROFILE': 'Use printable ASCII only. Put human prose off the signed record and pass its hash.',
    'ARRAY_LIMIT': 'Shorten the list.',
    'MAP_LIMIT': 'Remove extra fields.',
    'MAP_KEY': 'Use short printable ASCII field names.',
    'TYPE': 'Use JSON objects, arrays, strings, integers, booleans or null.',
    'DUPLICATE_KEY': 'Remove the duplicate JSON key and resend the object.',
    'NONINTEGER_NUMBER': 'Send integers only. Decimals are refused.',
    'INVALID_JSON': 'Send one JSON value with no trailing data.',
    'JSON_BOM': 'Remove the byte-order mark.',
    'PUBLIC_KEY': 'Pass a 64-character lowercase hex Ed25519 public key.',
    'PARTY_REQUIRED': 'This host has no installed signer. Pass party as the 64-character public key to summarize.',
    'OBLIGATION_LIMIT': 'Use an integer limit from 1 through 4096.',
    'CONTENT_CORRUPT': 'A retained file no longer matches its CID. Restore it from a verified evidence bundle; never edit stored bytes.',
    'CONTENT_DIRECTORY': 'Set content_dir to an existing directory path without symlinks or parent references.',
    'CONTENT_DIRECTORY_MISSING': 'Create the owner-private content_dir (mode 0700) before starting the host.',
    'CONTENT_DIRECTORY_PERMISSIONS': 'content_dir must belong to the host user and exclude group and other access (chmod 700).',
    'EVIDENCE_CIDS': 'Pass cids as a list of 1 to 64 content ids this host retains.',
    'EVIDENCE_CONTENT_NOT_FOUND': 'This host does not retain that CID. Export from the host that holds it, or import its bundle first.',
    'EVIDENCE_BUNDLE_SIZE': 'Split the export: at most 64 entries and 2,000,000 retained bytes per bundle.',
    'EVIDENCE_BUNDLE_FORMAT': 'Pass the exact covenant-evidence-bundle/0.1 object unchanged, as exported.',
    'EVIDENCE_BUNDLE_DIGEST': 'The bundle changed after export. Obtain an unmodified copy from the exporter.',
    'EVIDENCE_BUNDLE_SIGNATURE': 'The exporter signature does not verify. Obtain an unmodified bundle; do not re-pin a different key to force a pass.',
    'EVIDENCE_BUNDLE_FOREIGN': 'The bundle comes from a different exporter, matches a different digest, or is addressed to another host. Check the pin you obtained separately.',
    'EVIDENCE_BUNDLE_UNPINNED': 'Pass expected_exporter (the exporter public key) or expected_digest (bundle_digest) obtained separately from the bundle.',
    'EVIDENCE_BUNDLE_DUPLICATE': 'Each CID may appear once in a bundle.',
    'EVIDENCE_CID_MISMATCH': 'An entry\'s bytes do not hash to its CID. The bundle was altered; obtain an unmodified copy.',
    'EVIDENCE_ENVELOPE_INVALID': 'An envelope in the bundle fails its own signature or profile checks. It was not imported.',
    'EVIDENCE_DIGEST_PIN': 'expected_digest must be the 64-character bundle_digest.',
    'SIGNATURE': 'Obtain a fresh signature over the unchanged body. Do not edit terms to match an old signature.',
    'SIGNATURE_ENCODING': 'Pass a 128-character lowercase hex Ed25519 signature.',
    'FIELDS': 'Use the exact field set from the tool schema or the verification bundle.',
    'DOCUMENT': 'Pass 1 to 4096 bytes of printable ASCII, or pass task_hash and omit the text.',
    'TASK_HASH': 'Pass the SHA-256 hex of the exact document bytes.',
    'DOCUMENT_HASH': 'The document text does not hash to task_hash. Send the original bytes or drop the text.',
    'QUANTITY': 'Use a positive integer quantity.',
    'UNIT': 'Set unit to a stablecoin code.',
    'NATIVE_TOKEN_SETTLEMENT_REFUSED': 'Settle in USDC, USDT, DAI or USDG. The native token is not a settlement unit.',
    'STABLECOIN_REQUIRED': 'Use one of USDC, USDT, DAI or USDG. Other assets are refused by this adapter.',
    'RAIL': 'Set rail to x402 or ap2.',
    'PAY_TO': 'Set pay_to to 1..256 printable ASCII characters, such as a stablecoin address.',
    'DEADLINE': 'Set deadline to a positive integer timestamp. Offline verify does not compare it to a clock.',
    'CHALLENGE_WINDOW': 'Set challenge_window to a positive integer of at most 10000000 seconds.',
    'TIMEOUT_POLICY': 'Set timeout to RELEASE_IF_UNDECIDED or HOLD_FOR_RESOLUTION.',
    'EFFECT': 'Set effect to TRANSFER, CONSUME or AUTHORIZE.',
    'NETWORK': 'Set network to a short ASCII rail network id. x402 defaults to eip155:84532 (a test network).',
    'TERMS_VERSION': 'Use the exact terms version paired with the signed profile: /0.1 or /0.2. Never relabel a signed agreement.',
    'PROFILE': 'Use a supported, explicitly versioned covenant-bilateral envelope. Never relabel existing signatures.',
    'WORK_ORDER_PROFILE': 'This owner requires bilateral /0.2 for new effects. Historical /0.1 records remain readable.',
    'PROFILE_UPGRADE_REQUIRED': 'These features require an explicitly agreed bilateral /0.2 successor; existing /0.1 signatures cannot be upgraded in place.',
    'ORDER_NONCE': 'Use a fresh 64-hex nonce for a new order, or reuse the exact signed envelope for a retry.',
    'DEADLINE_EXPIRED': 'Automatic delivery/release is past the signed deadline. Follow the agreed dispute or refund procedure.',
    'CLOCK_ORDER': 'Use an owner-adopted time at or after the preceding signed event.',
    'EVIDENCE_NOT_BOUND': 'Cite the agreed task hash before delivery, or the exact signed delivery hash after delivery.',
    'APPEAL_WINDOW_OPEN': 'Wait until the agreed primary appeal window ends, or obtain the named appeal decision.',
    'APPEAL_EXPIRED': 'The appeal must occur at or after the primary decision and strictly before its window ends.',
    'APPEAL_FINAL': 'There is no further appeal in this agreed profile. Agree a separate procedure for a new matter.',
    'SETTLEMENT_AUTHORITY': 'Use the independently installed authority pinned in the signed terms. Agreement data cannot install one.',
    'SETTLEMENT_STORAGE': 'Use a private owner-controlled regular settlement database in a trusted directory.',
    'SETTLEMENT_NOT_INITIALIZED': 'The owner must initialize the shared reference ledger before attaching agent hosts.',
    'SETTLEMENT_ALREADY_INITIALIZED': 'Do not reset an existing authority or recreate opening balances on each client.',
    'SETTLEMENT_CLOCK_AHEAD': 'The claimed settlement time is ahead of the authority: its clock or, with a time policy, the evidence upper bound. Retry when that clock reaches it, or claim the assessed not_before; a host clock cannot close a window early.',
    'SETTLEMENT_CLOCK': 'The owner must install a callable authority clock that returns Unix seconds between 0 and 2^53-1.',
    'SETTLEMENT_NOT_OBSERVED': 'Obtain the receipt through the owner-adopted provider; a counterparty receipt alone is not observed funds.',
    'SETTLEMENT_TIME_POLICY': 'Install a valid covenant-time-evidence/0.1 policy only when initializing a new authority, and reopen with the same policy or none. It cannot be added to or changed on an authority in use.',
    'TIME_POLICY_NOT_INSTALLED': 'This authority has no owner-installed time policy, so it does not read time evidence. Omit time_evidence or use an authority whose owner adopted one.',
    'TIME_EVIDENCE_REQUIRED': 'This authority judges a silent refund or an unappealed decision by owner-adopted time evidence. Pass a covenant-time-evidence/0.1 bundle; a party clock is not accepted.',
    'TIME_UNDETERMINED': 'The evidence interval reaches across the deadline or window end, or the sources did not agree. Gather fresh evidence later; unknown time never settles.',
    'TIME_EVIDENCE_SUBJECT': 'Gather the bundle for this agreement: its subject must be the agreement identifier.',
    'TIME_EVIDENCE_INVALID': 'The time evidence is malformed or a signature failed. Gather it again from the adopted sources; never edit an observation.',
    'TIME_EVIDENCE_UNAVAILABLE': 'Time evidence needs the covenant_chain package from agentic-agreements. The SDK-only wheel does not include it.',
    'SETTLEMENT_WITNESS_UNKNOWN': 'The authority journal lacks a fresh witness quorum. Restore witness access and retry; do not relax the policy to pass.',
    'SETTLEMENT_WITNESS_REFUSED': 'The authority journal conflicts with a retained head or a witness. Keep the evidence and stop relying on this copy.',
    'SETTLEMENT_WITNESS_REQUIRED': 'This store is witnessed. Open it with the owner-adopted witness policy and authority journal key.',
    'SETTLEMENT_WITNESS_CONFIG': 'The witness policy names another log origin or key than this store adopted. Use the adopted one.',
    'SETTLEMENT_WITNESS_RACE': 'Another writer extended the journal after it was witnessed. Retry so the new head is witnessed first.',
    'SETTLEMENT_WITNESS': 'Pass an owner-adopted witness policy and the matching Ed25519 authority journal key.',
    'SETTLEMENT_JOURNAL_ENTRY': 'The receipt has no journal entry in this store. Ask the authority that recorded it.',
    'SETTLEMENT_PROOF_INVALID': 'The receipt, its journal entry and its inclusion proof do not match. Request a fresh proof from the authority.',
    'EXPLICIT_NATIVE_ADOPTION_REQUIRED': 'This bilateral version has no automatic native-chain mapping. Use an explicitly adopted native profile.',
    'DISTINCT_PARTIES': 'The agent and the counterparty must be different keys.',
    'RESOLVER_CONFLICT': 'The resolver and appeal resolver must differ from the parties and from each other.',
    'MANDATE_REQUIRED': 'When the principal is not the agent, attach a signed local mandate that covers this quantity, unit, rail and effect.',
    'MANDATE_UNEXPECTED': 'Omit the mandate when the principal is the agent.',
    'MANDATE_PRINCIPAL': 'The mandate principal must equal parties.principal.',
    'MANDATE_HOLDER': 'The mandate holder must equal parties.agent.',
    'MANDATE_SCOPE': 'Narrow the work order so quantity, deadline, unit, rail and effect fit inside the mandate.',
    'MANDATE_VERSION': 'Use mandate version covenant-local-mandate/0.1.',
    'SIGNER_ROLE': 'Sign with the key for the required role. Tool arguments cannot supply a private key.',
    'SIGNER_NOT_INSTALLED': 'The host has no owner-installed signing key. Ask the owner to configure one, or use the SDK in the owner process.',
    'DUPLICATE_ASSENT': 'This key has already signed. Do not add a second assent.',
    'AGENT_ASSENT': 'The agent must sign the exact terms and parties.',
    'COUNTERPARTY_ASSENT': 'The counterparty must covenant_accept this exact envelope.',
    'ROLE_MISMATCH': 'The assent role does not match the signer.',
    'UNKNOWN_ASSENT': 'Remove the assent from a key that is not the agent or the counterparty.',
    'NOT_DELIVERABLE': 'Deliver only after both parties have signed and before settlement or dispute.',
    'CONTENT_SIZE': 'Send between 1 and 1000000 content bytes.',
    'DELIVERY': 'The delivery signature does not cover this terms hash and content hash.',
    'NOT_SETTLEABLE': 'Settle a delivered covenant, or a decided dispute. Propose, accept and deliver first.',
    'DISPUTE_OPEN': 'The resolver must decide before settle routes escrow.',
    'SETTLE_INDETERMINATE': 'An indeterminate decision does not release funds. Obtain a supported or refuted decision.',
    'NOT_DISPUTABLE': 'Open this payment dispute only from a bound or delivered covenant. A settled receipt cannot reopen escrow. For remaining corrections or support, retain the exact settled envelope and CID in covenant_review case /0.4, record the duty and conflicting assertions in performance, and explicitly agree any separate arbitration or remedy. A review does not reverse payment or establish discharge.',
    'DISPUTE_AUTHORITY': 'Only the agent or the counterparty can open a dispute.',
    'DECISION_AUTHORITY': 'Only the resolver or the appeal resolver can decide.',
    'RESULT': 'Use result SUPPORTED, REFUTED or INDETERMINATE.',
    'PAYMENT_FUNDS': 'The payer does not have that stablecoin balance on this ledger.',
    'ESCROW_CONFLICT': 'This escrow id already holds different terms. Do not reuse it.',
    'ESCROW_STATE': 'Escrow is not held. Do not pay it out twice.',
    'SETTLEMENT_CONFLICT': 'A different settlement is already recorded for this covenant.',
    'SETTLEMENT_BINDING': 'The settlement receipt does not match the signed terms, delivery and rail instruction.',
    'RELEASE_SIGNATURE': 'The principal must sign the release, or a resolver decision must authorize it.',
    'AP2_MANDATE': 'The AP2 mandate must be signed by the principal over this amount, unit and terms hash.',
    'CID': 'Pass a CIDv1 (multibase base32, raw SHA-256) or sha256:<64 hex>.',
    'CID_MISMATCH': 'The bytes are not the content named by this CID. Fetch another copy or stop.',
    'CONTENT_NOT_FOUND': 'The CID is not in the local store or a configured source. Offline verify does not guess a host.',
    'CONTENT_KIND': 'The bytes are not a bilateral envelope, a light packet or a courier packet.',
    'SOURCE_NOT_CONFIGURED': 'This source has no owner-installed fetcher. Local bytes still verify.',
    'GENESIS_NOT_PINNED': 'Pin genesis in the host config before treating a light proof as committee-certified.',
    'LIGHT_TERMS': 'The certified agreement does not commit to this document hash.',
    'LIGHT_PARTIES': 'The certified agreement names different parties or a different quantity.',
    'LIGHT_PROOF': 'The light proof failed. Obtain a committee-certified bundle for this genesis.',
    'ANCHOR_REQUIRES_CHAIN_MANDATE': 'A delegated principal needs an existing chain mandate id before an anchor transaction can be built.',
    'ANCHOR_CHALLENGE_BLOCKS': 'Set anchor challenge_blocks to an integer from 0 to 10000.',
    'ANCHOR_MANDATE': 'A principal who is the agent must anchor with mandate null.',
    'ANCHOR_FIELDS': 'Pass genesis, resource, profile, deadline_height and the agent and counterparty keys to build an anchor.',
    'PII_DETECTED': 'The text holds an e-mail address, phone number or long digit run. Move it to a private document and pass task_hash, or ask the owner to use warn mode.',
    'PII_MODE': 'Use PII preflight mode warn or strict.',
    'DESCRIPTION': 'Pass a string of at most 100000 characters.',
    'AGREEMENT_ID': 'Pass the 64-character lowercase hex agreement key, or a CID of a stored envelope.',
    'ERASABLE_STORE_DIRECTORY': 'Use an owner-only (mode 0700) directory that is not a symlink for the private store.',
    'ERASABLE_STORE_FILE': 'A private store file is not an owner-only regular file. Restore its mode or remove it.',
    'ERASABLE_STORE_INDEX': 'The private store index does not match this agreement. Do not copy indexes between agreements.',
    'ERASABLE_STORE_LIMIT': 'This agreement already holds the maximum number of stored items.',
    'ERASABLE_KIND': 'Use kind document, envelope, delivery, annex or evidence.',
    'ERASABLE_NAME': 'Use a short lowercase name: letters, digits, dot, dash or underscore.',
    'ERASABLE_SECRET': 'Pass a 64-character lowercase hex salt or key.',
    'DOCUMENT_NOT_FOUND': 'That document is not in the private store for this agreement.',
    'DOCUMENT_SHREDDED': 'The document key was destroyed. The ciphertext cannot be opened. Obtain a fresh copy from a party.',
    'DOCUMENT_CIPHERTEXT': 'The stored ciphertext does not open under its key. Treat the copy as damaged.',
    'SALT_NOT_FOUND': 'No salt of that name is stored for this agreement.',
    'ANNEX_KEY_NOT_FOUND': 'No annex key of that name is stored for this agreement.',
    'TOOL_NOT_INSTALLED': 'The owner has not installed mcp_servers in this host config. A tool argument cannot add a server.',
    'TOOL_JOURNAL_REQUIRED': 'The owner must set tool_journal, a private directory, before this host can call external tools.',
    'KEY_MATERIAL_REFUSED': 'Remove private keys, seeds and secrets from tool arguments. The host uses its installed key.',
    'ARGUMENTS': 'Pass exactly the fields from the tool schema.',
    'KEY_FILE_MODE': 'The host config is readable by group or others. Restrict it to the owner and retry.',
    'HOST_CONFIG': 'Use host config version covenant-agent-native-host/0.1.',
    'LEGACY_NOT_ATTACHED': 'The full catalog is still served by covenant-agent. Attach that host to forward a legacy call.',
    'BOTH_KEYS_NOT_ENABLED': 'covenant_once is not a default tool. A real counterparty signs on its own host.',
    'SANDBOX_REQUIRED': 'covenant_once holds both party seeds on one host. Set sandbox true only in a test. Do not load a counterparty seed on a live host.',
    'COURIER_CONTEXT': 'Pin the courier chain before unpacking a packet.',
    'LIGHT_VERIFIER_NOT_INSTALLED': 'Committee verification needs the covenant_chain package. Signature and hash checks still ran.',
    'CATALOGUE_GAP': 'An action in the source has no catalogue row, or a catalogue row names an action the source does not have.',
    'ACTION_UNKNOWN': 'That action is not in the catalogue. Use covenant.find with ordinary words, or list the tree.',
    'ACTION_AMBIGUOUS': 'That bare name is used by more than one family. Pass the qualified id, such as chain:SAY or language:SAY.',
    'VERB_UNKNOWN': 'Use one of the visible verbs. covenant_explain with a verb such as propose lists its job and kinds.',
    'VERB_KIND_UNKNOWN': 'That kind does not belong to this verb. covenant_explain with the verb lists its kinds; the old name still works.',
    'VERB_KIND_REQUIRED': 'This verb has several kinds and no default this host can run. Pass verb:kind, with a kind from covenant_explain.',
    'VERB_KIND_NOT_HERE': 'That kind names an action this host does not run. Use the host that runs it, or another kind.',
    'JOBS_ACTION_ID': 'An action id is family:name, for example chain:BIND or tool:covenant_marketplace.quick_trade.',
    'JOBS_SIZE': 'The shipped job map exceeds 1 MiB. Restore the released covenant_agent/data/action_jobs.json.',
    'JOBS_DUPLICATE_FIELD': 'The job map repeats a JSON key. Keep exactly one row per action id.',
    'JOBS_FIELDS': 'The job map holds format, model, note, golden_path, jobs, verbs, instruments, native and actions; nothing else.',
    'JOBS_FORMAT': 'This reader understands aap-action-jobs/0.1 only. A changed meaning is a new format.',
    'JOBS_TEXT': 'Use short, trimmed plain text for every title and description in the job map.',
    'JOBS_SEVEN': 'The job map has exactly seven jobs, in the experience model order.',
    'JOBS_JOB': 'Each job has a unique short id, a title, a description and one to six verbs.',
    'JOBS_VERB_TWICE': 'A verb belongs to exactly one job. Remove the second listing.',
    'JOBS_VERBS_ORDER': 'List every verb under verbs in the same order the jobs list them.',
    'JOBS_VERB': 'Each verb has a description, at most four default kinds and one to four next verbs.',
    'JOBS_VERB_EMPTY': 'Every visible verb names at least one action, and every action names a visible verb.',
    'JOBS_GOLDEN_PATH': 'The golden path lists visible verbs only.',
    'JOBS_INSTRUMENTS': 'Each entry instrument has a description and the tool names that serve it.',
    'JOBS_TOO_MANY_VERBS': 'Keep visible verbs, entry instruments included, to 35 or fewer; give a new action a kind instead.',
    'JOBS_ACTIONS': 'The job map names 1 to 8192 actions.',
    'JOBS_ACTION_VERB': 'Assign the action one of the visible verbs.',
    'JOBS_KIND_TWICE': 'Two actions spell the same kind. Rename neither; report the collision so the spelling rule is extended.',
    'JOBS_DEFAULT_KIND': 'A default kind must be a kind of that same verb.',
    'JOBS_NATIVE': 'Map each work-order host tool name to an action id the job map contains.',
    'JOBS_ORDER': 'Order a verb card by NATURE or by USE only.',
    'RANK_NODE_CAPACITY': 'More than 256 distinct actions were used; the least supported stay dormant in their order by nature.',
    'RANK_TRACE_SCOPE': 'Pass trace_scope with owner, context, contacts, now and max_age chosen by the host owner.',
    'RANK_RECORDS': 'Pass at most 4096 retained work orders and 256 feature-use traces.',
    'RANK_OWN_KEYS': 'Pass this host\'s own public keys (64 lowercase hex), at most 8.',
    'RANK_CAPACITY': 'The traces name more than 256 distinct features. Rank a narrower owner context.',
    'RANK_CAP': 'Use a per-counterparty cap from 1 to 16.',
    'RANK_DAMPING': 'Use damping in basis points from 0 to 9500.',
    'RANK_ITERATIONS': 'Use 1 to 100 iterations.',
    'RANK_LIMIT': 'Ask for 1 to 8 suggestions.',
    'RANK_INPUT': 'The input file holds envelopes, own_keys, and optionally traces and trace_scope; nothing else.',
    'RANK_INPUT_SIZE': 'Keep the owner-local rank input at or under 2 MiB.',
    'AGREEMENT_NOT_FOUND': 'Pass the chain state that holds this agreement, or the bilateral envelope for this content id.',
    'DRAFT_TEMPLATE': 'Use a template id from the drafting library, such as payment-on-delivery.',
    'DRAFT_FIELDS': 'Use the typed parameters for that template. Integers stay integers, and names stay printable ASCII.',
    'DRAFT_TEXT': 'Pass one short printable sentence for the drafter to parse.',
    'DRAFT_PARTY': 'The accepting or countering party must be the payer or the payee named in the terms.',
    'DRAFT_UNCHANGED': 'Change at least one term. An empty counter is not a new version.',
    'DRAFT_OVERDRAWN': 'The parent escrow cannot fund this child. Lower the child price or pick a parent with enough unallocated sum.',
    'DRAFT_NOT_READY': 'Resolve the linter errors before both parties accept. Warnings can stay, errors cannot.',
    'SILENCE_NOT_DUE': 'Pass as_of greater than the deadline. This function does not read a clock. Silence refunds only when the timeout is RELEASE_IF_UNDECIDED.',
    'RECOURSE_JUDGE': 'Name a judge and a different appeal judge. Both are 64-character hex keys, and neither may be a party.',
    'SCORE_CHAIN': 'Pin the same chain id the score was computed for. A fork id does not verify.',
    'SCORE_RECEIPTS': 'Pass settled or released receipts for one stablecoin unit. The score reads those receipts and does not keep a balance.',
    'SCORE_SUBJECT': 'Pass the agent public key the score is about.',
    'SPONSOR_ESCROW_REQUIRED': 'Sponsored placement needs an explicit escrow reference. Organic results stay in their own list.',
    'ATTENTION_FIELDS': 'Pass structured events: type, covenant id, counterparty, value, and due. Thresholds are integers from 0 to 10000, and the digest threshold cannot exceed the alert threshold.',
    'THREAT_NOVELTY': 'Threat class must be LOSS, DISPUTE, INJECTION, or KEY_COMPROMISE. Novelty alone is not a threat.',
    'THREAT_QUORUM': 'Use an attestation threshold from 1 to 16. An entry is active only once that many signatures are present.',
    'THREAT_FIELDS': 'Name one pattern hash, subject key, or offer id, plus a 64-hex evidence hash and an expiry. Appeal and attest refer to an entry id.',
    'FUSION_FIELDS': 'Each source needs a class, a source id, and an integer reading from 0 to 10000. Trials and overturns are integers.',
    'RPE_OUTCOME': 'Outcome must be 0, 3000, 7000, or 10000. Reputation and the settled count are integers. This update does not write consensus.',
    'REFLEX_PAUSED': 'New covenants with this counterparty are paused, or the spend would exceed the mandate limit. Existing agreements are unchanged and no transaction is invalidated.',
    'EVIDENCE_FIELDS': 'Use the evidence policy shape: terms hash, pinned adapter ids, a claim, and an integer quorum. Blobs are bytes with a mime type.',
    'EVIDENCE_PIN': 'The evidence policy must be signed for this terms hash. A policy signed for another covenant does not apply.',
    'EVIDENCE_ADAPTER': 'That adapter id is not registered. Pin only adapters this process can run, or register the adapter first.',
    'ASSENT_APPROVAL_REQUIRED': 'Nothing was signed. A person must approve the exact rendering with the owner\'s adopted method (passkey page or owner approval key), then retry the same call, or pass the approval record as approval.',
    'ASSENT_APPROVAL_REFUSED': 'This exact request was refused by the owner or declined by a client. Nothing was signed. Plain retries retain the refusal. Review with the owner before changing terms, using a new /0.2 nonce, or installing a newly owner-signed policy.',
    'ASSENT_APPROVAL_REUSED': 'This approval was already used or answered. Each approval authorizes one signature for one occurrence. The first result stays readable by its CID; request a new approval for any other assent.',
    'ASSENT_APPROVAL_EXPIRED': 'The approval request expired. Retry the call without the approval to receive a fresh request, and have the owner approve it again.',
    'ASSENT_APPROVAL_UNKNOWN': 'This host did not issue that occurrence, or it was pruned after expiry. Retry the call without the approval to receive a request this host issued.',
    'ASSENT_APPROVAL_CHANGED': 'The approval names a request that differs from the one this host issued. Approve the exact issued request; never edit a request after it is issued.',
    'ASSENT_APPROVAL_AGREEMENT': 'The approval binds different agreement bytes. Altered terms need a new request and a new approval.',
    'ASSENT_APPROVAL_RENDERING': 'The approval binds a different rendering than these exact bytes produce. Re-render with the owner tool and approve that exact text.',
    'ASSENT_APPROVAL_AMOUNT': 'The approval was given for a different amount or unit. A different amount needs a new request and a new approval.',
    'ASSENT_APPROVAL_PAYEE': 'The approval was given for a different payee or pay-to address. A different payee needs a new request and a new approval.',
    'ASSENT_APPROVAL_ROLE': 'The approval covers the other assent role. Request an approval for the role this call signs.',
    'ASSENT_APPROVAL_FIELDS': 'Pass the exact covenant-assent-approval/0.1 record: version, decision, request, method and proof.',
    'ASSENT_APPROVAL_METHOD': 'Approve with the method the owner policy adopted (passkey or owner key). Another method is not accepted.',
    'ASSENT_APPROVAL_SIGNATURE': 'The approval is not signed by the owner key the policy adopted. Sign the unchanged request with that key.',
    'ASSENT_APPROVAL_OUTCOME_UNKNOWN': 'An earlier signing attempt did not finish. Its outcome is unknown and never becomes approval. Inspect retained envelopes and reconcile any external effects with the owner before proposing different work; a retry does not issue another approval.',
    'ASSENT_APPROVAL_BACKLOG': 'Too many approval requests are pending. Let the owner answer or let them expire before asking again.',
    'ASSENT_PASSKEY_ASSERTION': 'The passkey assertion does not verify for the adopted credential, origin, RP ID and this exact request challenge.',
    'ASSENT_PASSKEY_USER_VERIFICATION': 'The authenticator did not report the user presence or verification the policy requires. Approve again with user verification.',
    'ASSENT_PASSKEY_COUNTER': 'The passkey signature counter did not increase, which can indicate a cloned authenticator. Check the device before approving again.',
    'ASSENT_POLICY_FIELDS': 'Use the exact covenant-assent-policy/0.1 body: owner, signer, roles, typed MONEY thresholds sorted by unit, one method, max_age 30..86400, validity and nonce.',
    'ASSENT_POLICY_SELF_APPROVAL': 'The owner key and the approval key must differ from the agent signer key; an agent cannot approve its own assent.',
    'ASSENT_POLICY_SIGNATURE': 'The policy is not signed by its owner key. Have the owner sign the exact policy body.',
    'ASSENT_POLICY_SIGNER': 'The installed policy constrains a different agent key. Install a policy signed for this host signer.',
    'ASSENT_POLICY_CHANGED': 'The approval was issued under a different owner policy. Request a new approval under the installed policy.',
    'ASSENT_POLICY_INACTIVE': 'The installed owner policy is outside its validity window. No assent is signed until the owner installs a current policy.',
    'ASSENT_POLICY_NOT_INSTALLED': 'This host has no owner approval policy, so it has no approval journal to read.',
    'ASSENT_JOURNAL_STORAGE': 'Use a regular owner-private journal file (mode 0600, one link) in a directory only the owner can write.',
    'ASSENT_JOURNAL_VERSION': 'The journal has an unknown format. Use software that reads covenant-assent-journal/0.1, or restore a backup.',
    'ASSENT_JOURNAL_FULL': 'The journal is at its row bound with unexpired requests, or the request is too large. Let requests expire, or back up and rotate the journal.',
    'ASSENT_GUARD_NESTED': 'One signing call at a time may hold a permit. Retry after the current call finishes.',
    'ASSENT_KEY_FILE': 'The owner key file must be a regular file owned by you with mode 0600 holding one 64-hex seed.',
    'ASSENT_CONFIRMATION': 'Pass --confirm with the exact rendering SHA-256 the render command printed for this occurrence.',
    'ASSENT_OWNER_TOOL_FAILED': 'The owner tool could not complete. Check the paths and files named in the command.',
    'ASSENT_RENDER_FIELDS': 'The agreement has missing, extra or malformed fields. Only exact profile bytes are rendered.',
    'ASSENT_RENDER_CHANGED': 'The supplied terms are not what the profile constructor produces for them. Use the unchanged envelope or order.',
    'ASSENT_RENDER_PROFILE': 'Render a covenant-bilateral/0.1 or /0.2 envelope or a covenant-bilateral/0.3 order.',
    'ASSENT_RENDER_SIZE': 'The agreement or its rendering exceeds the display bound. Shorten the task text or move prose off the signed record.',
    'ASSENT_RESOURCE_UNKNOWN': 'This host holds no rendering with that SHA-256. Call covenant_assent_review first, then read its uri.',
    'ASSENT_REQUEST_STATE': 'The requestState is not one this server sealed for this exact call, or it expired. Retry the original call without requestState.',
    'ASSENT_ELICITATION_RESULT': 'Answer the approval elicitation with accept and the requested fields, decline, or cancel.',
    'AGUI_INPUT': 'Send one AG-UI 1.0 RunAgentInput: threadId, runId and messages, plus at most one of forwardedProps.aap {tool, arguments} or resume.',
    'AGUI_PROTOCOL': 'This producer speaks AG-UI protocol 1.x. Omit protocolVersion or send a 1.x version.',
    'AGUI_TOOL': 'forwardedProps.aap names one allowed host tool with an arguments object.',
    'AGUI_RESUME': 'Each resume entry names one distinct interruptId with status resolved (with the signed approval record as payload) or cancelled.',
    'AGUI_EVENT': 'An event outside the emitted AG-UI 1.0 set or over the size bound was refused.',
    'AGUI_AUTH': 'Send the owner AG-UI bearer token in one Authorization: Bearer header (RFC 6750). The token lives in the owner token file.',
    'AGUI_ACCEPT': 'Send Accept: text/event-stream; this endpoint answers only with an AG-UI event stream.',
    'AGUI_RUN_FAILED': 'The run failed after it started. Nothing further was signed; read RUN_ERROR and retry with a new runId.',
    'ASSENT_HTTP_JSON': 'Send one JSON object without duplicate keys or non-finite numbers, inside the depth and size bounds.',
    'ASSENT_HTTP_REFUSED': 'The request was refused. Use the documented route, method and headers.',
    'ASSENT_HTTP_ORIGIN': 'Use the exact origin and Host this owner-local server serves; a passkey policy fixes that origin.',
    'ASSENT_HTTP_FRAMING': 'Send one Content-Length body without Transfer-Encoding or Expect.',
    'ASSENT_HTTP_CONTENT_TYPE': 'Send Content-Type: application/json.',
    'ASSENT_HTTP_SIZE': 'The body exceeds the bound for this route.',
    'ASSENT_HTTP_SESSION': 'Open the approval page first; its same-site session cookie is required to record a decision.',
    'ASSENT_HTTP_CSRF': 'Send the X-Covenant-CSRF header from the approval page.',
    'ASSENT_HTTP_NOT_FOUND': 'Use GET or POST /assent/approve, or POST /agui when the owner enabled AG-UI.',
    'ASSENT_HTTP_TOKEN': 'The AG-UI bearer token must be 32 to 128 characters generated by the owner tool.',
    'ASSENT_HTTP_PORT': 'Use a loopback port from 0 to 65535.',
    'ASSENT_POLICY_RISK': 'A covenant-assent-policy/0.2 risk field must be an exact covenant-risk-score/0.1 policy: above_bps, five weights and a sorted amount scale.',
    'ASSENT_RISK_SOURCE': 'Install risk sources as the owner: history is a callable returning receipt counts or null, scopes a sorted verb-scope list or null.',
    'ASSENT_WATCHDOG': 'Install an owner watchdog object with admit(); a tool argument cannot install or remove one.',
    'AUTHORITY_SUSPENDED': 'The owner\'s watchdog suspended this agent after an action left the approved envelope. Nothing new is signed, called or spent. Earlier records stay readable; the owner reviews the journaled suspension and reinstates with the owner key.',
    'SCOPE_VIOLATION': 'This call\'s verb on this resource is outside the scopes the owner pinned for the tool. Do not retry with another tool or verb to reach the same effect; ask the owner.',
    'SCOPE_UNCLASSIFIED': 'The call could not be classified under the tool\'s scope rule. Send one plain statement or one listed argument value; comments, several statements, WITH and EXPLAIN are refused.',
    'SCOPE_ESCALATION': 'A delegated tool configuration may only narrow: the same servers, pins and rules, fewer calls and allow-lists inside the parent\'s.',
    'TOOL_CONFIGURATION_CHANGED': 'This tool journal belongs to a different owner configuration or profile. Open it with the exact servers, pins and profile it was created with, or give the new configuration its own journal directory.',
    'TOOL_SCOPE_CONFIG': 'Use covenant-mcp-servers/0.3: every server carries scopes mapping each pinned tool to a FIXED, ARGUMENT or SQL rule and a sorted allow list.',
    'TOOL_WATCHDOG': 'Install a watchdog together with the agent public key it supervises, or neither.',
    'WATCHDOG_OWNER': 'Open the store with the owner public key pinned in it, and sign envelopes and reinstatements with that owner\'s key.',
    'WATCHDOG_CLOCK': 'The owner clock must return a non-negative integer number of seconds.',
    'WATCHDOG_CLOCK_ROLLBACK': 'The owner clock ran backwards. Fix the clock; windows and suspensions cannot be judged against an earlier time.',
    'WATCHDOG_STORAGE': 'Keep the watchdog store as an owner-only regular file (mode 0600) in a directory others cannot write; restore it from a backup if it was replaced.',
    'WATCHDOG_VERSION': 'This file is not a covenant-watchdog/0.1 store. Open the right file; never edit its pins.',
    'WATCHDOG_STORE_FULL': 'The store reached its bound. Let old events leave the longest window, or back up and start a new store with the owner.',
    'WATCHDOG_BACKUP': 'Choose a new backup path in an existing directory; a backup never overwrites a file.',
    'WATCHDOG_ENVELOPE_FIELDS': 'Use the exact covenant-watchdog-envelope/0.1 body: owner, agent, approval, sorted scopes, destinations, rate {count, window}, sorted spend windows, validity and nonce.',
    'WATCHDOG_ENVELOPE_SIGNATURE': 'The envelope is not signed by its owner key. Have the owner sign the exact body.',
    'WATCHDOG_SELF_SUPERVISION': 'The owner key must differ from the supervised agent key; an agent cannot approve or reinstate itself.',
    'WATCHDOG_NO_ENVELOPE': 'The owner has not adopted an envelope for this agent, so nothing it does is approved. Ask the owner to sign and adopt one.',
    'WATCHDOG_ENVELOPE_INACTIVE': 'The adopted envelope is outside its validity window. Ask the owner for a current envelope.',
    'WATCHDOG_EVENT_FIELDS': 'Report an action as an agent key, kind ASSENT, SPEND or TOOL_CALL, a concrete scope, a request id, an optional destination and integer usage.',
    'WATCHDOG_REQUEST_REUSED': 'This request id was reported for a different action. Use a new id for a new action.',
    'WATCHDOG_REINSTATEMENT_FIELDS': 'Use the exact covenant-watchdog-reinstatement/0.1 body: owner, agent, suspension, issued_at and nonce.',
    'WATCHDOG_REINSTATEMENT_SIGNATURE': 'The reinstatement is not signed by its owner key. Have the owner sign the exact body.',
    'WATCHDOG_NOT_SUSPENDED': 'This agent has no active suspension for that reinstatement. Inspect the store and name the current suspension.',
    'WATCHDOG_SUSPENSION_MISMATCH': 'The reinstatement names a different suspension than the active one. Review the newest suspension and confirm its id.',
    'WATCHDOG_REINSTATEMENT_TIME': 'Date the reinstatement at or after the suspension and not in the future of the owner clock.',
    'WATCHDOG_REINSTATEMENT_REUSED': 'That reinstatement nonce was already used. Sign a new reinstatement.',
    'WATCHDOG_WITNESS': 'Install the witness options as the owner: the adopted policy, its log key and optional transports, retained head and clock; the pinned policy may not change.',
    'WATCHDOG_WITNESS_REQUIRED': 'This store was opened with a witness policy. Open it with the same policy and log key before admitting actions.',
    'WATCHDOG_JOURNAL_REFUSED': 'The journal shows a rollback, fork or split view. Nothing is admitted; restore the newest store and investigate the kept evidence.',
    'WATCHDOG_PROOF_ENTRY': 'Name a journaled envelope, suspension or reinstatement entry and pass the unchanged proof bundle.',
    'WATCHDOG_KEY_FILE': 'The owner key file must be a regular file owned by you with mode 0600 holding one 64-hex seed.',
    'WATCHDOG_OWNER_TOOL_FAILED': 'The owner tool could not complete. Check the paths and files named in the command.',

    'PAYMENT_PARTIES': 'Name a payer and a different payee, both as strings. A payment to oneself is refused.',
    'PLUGIN_DISABLED': 'This optional settlement plugin is off. The host owner turns its flag on in the host configuration; a tool call cannot.',
    'X402_ATR': 'Pass the agreement hash as 64 lowercase hex characters, for example atr_hash(exact agreement bytes).',
    'X402_ATR_BYTES': 'Pass the exact agreement-terms bytes, 1 to 262144 of them, to compute atrHash.',
    'X402_ATR_MISMATCH': 'The challenge, the payment and the expected agreement must carry the same x402Version 2, scheme exact and extensions.legalContext.info.atrHash. Ask for a fresh challenge; do not relabel the hash.',
    'X402_TERMS': 'The payment must accept one of the offered requirements exactly, and authorization.to and authorization.value must equal payTo and amount. Sign a fresh payment for the offered terms.',
    'X402_AUTHORIZATION': 'Pass authorization with from, to, value, validAfter, validBefore and a 64-hex nonce. from is the payer public key.',
    'X402_AUTHORIZATION_WINDOW': 'as_of must be at or after validAfter and before validBefore. as_of is the caller assertion; sign a new payment with a current window instead of changing the clock.',
    'X402_REPLAY': 'This payer already spent that nonce on this ledger. Sign a new payment with a fresh nonce.',
    'X402_TIMEOUT': 'Set maxTimeoutSeconds to an integer from 1 to 86400.',
    'X402_HEADER': 'Pass one base64 JSON object of at most 16384 characters, as carried in PAYMENT-REQUIRED, PAYMENT-SIGNATURE or PAYMENT-RESPONSE.',
    'OFFLINE_OWNER_KEY_MISSING': 'owner.key is not in this custody directory. Restore it from your own backup or run guardian recovery (offline_cli recover). Running init again creates a new key that cannot open the existing vault.',
    'TOOL_JSON_COMPLEXITY': 'A JSON value sent to or returned by the tool nests deeper than 32 levels or holds more than 65536 values. Send smaller arguments; if the reply is too large, ask the tool owner to return less.',
    'TOOL_INTEGER_RANGE': 'A number sent to or returned by the tool is outside the exact integer range of plus or minus 2^53-1. Use a smaller value; a tool that needs larger numbers must carry them as strings in its schema.',
    'TOOL_NONFINITE_NUMBER': 'A number sent to or returned by the tool is NaN, infinite, or a float beyond plus or minus 2^53-1. Send finite numbers only; ask the tool owner to fix a reply that contains one.',
    'TOOL_JSON_STRING': 'A text value sent to or returned by the tool is longer than 262144 bytes. Send shorter text, or pass a hash and move large content through a channel you agreed.',
    'TOOL_JSON_UTF8': 'A text value sent to or returned by the tool cannot be encoded as UTF-8 (for example a lone surrogate). Send valid Unicode text; ask the tool owner to fix a reply that contains one.',
    'TOOL_JSON_ARRAY': 'A list sent to or returned by the tool has more than 4096 items. Send fewer items per call, or split the work into several calls.',
    'TOOL_JSON_OBJECT': 'An object sent to or returned by the tool has more than 1024 fields or a field name longer than 256 characters. Send fewer or shorter fields.',
    'TOOL_JSON_TYPE': 'A value sent to or returned by the tool is not plain JSON (object, list, text, number, true, false or null). Convert it to plain JSON before the call.',
    'TOOL_JSON_SIZE': 'A JSON message to or from the tool is larger than 1048576 bytes once encoded. Send smaller arguments, or ask the tool owner to return a smaller result.',
    'TOOL_RESPONSE_SIZE': 'A reply line from the tool, or a stored journal record, is over its byte limit (262144 bytes per reply line). Ask the tool owner to return a smaller result; AAP never reads a cut-off reply.',
    'TOOL_DUPLICATE_KEY': 'The tool reply repeats a JSON field name, so its meaning is ambiguous. Ask the tool owner to send each field once; AAP never picks one of the values.',
    'TOOL_JSON': 'The tool reply, or a stored journal record, is not valid UTF-8 JSON. Ask the tool owner to fix the server output; AAP does not guess at a malformed reply.',
    'TOOL_DESCRIPTOR': 'A tool description from the server has no valid name (1 to 128 letters, digits or _.:/+-). Ask the tool owner to fix the tool list; calls are refused until it is valid.',
    'TOOL_CONFIG': 'The MCP server configuration is invalid. Each of 1 to 16 servers needs pins, max_calls (0 to 1000000) and exactly one of command or transport_pin, with a timeout above 0 and at most 30 seconds. The host owner fixes it; a tool call cannot.',
    'TOOL_PROTOCOL_VERSION': 'The configured protocol_version is not one this client speaks. The host owner sets 2025-06-18 or 2026-07-28, or leaves it out to use 2025-06-18.',
    'TOOL_SCHEMA_UNSUPPORTED': 'The tool\'s schema uses JSON Schema features this client cannot check (references, patterns, formats or unknown keywords) or nests deeper than 16 levels. Ask the tool owner for a simpler schema; the call is refused before it is sent.',
    'TOOL_PLATFORM_UNSUPPORTED': 'This client starts local tool servers only on POSIX systems such as Linux and macOS. Run the host on a POSIX system, or have the host owner install an owner transport for that server.',
    'TOOL_DISCOVER': 'The tool server did not answer server/discover with version 2026-07-28 among its supported versions. Ask the tool owner to support it, or have the host owner configure protocol_version 2025-06-18.',
    'TOOL_INITIALIZE': 'The tool server did not finish the 2025-06-18 initialize handshake with a protocol version, capabilities and server info. Ask the tool owner to fix the server, or have the host owner configure the version it supports.',
    'TOOL_TIMEOUT': 'The tool server did not answer before the session deadline (the configured timeout, at most 30 seconds). If the call was refused or is recorded NOT_SENT, nothing reached the tool: try later with a new request_id. If it is recorded UNKNOWN, reconcile it first.',
    'TOOL_REQUEST_SIZE': 'A request line to the tool server would be larger than 262144 bytes, so it was not written. Send smaller arguments; inspect the old request in the journal before you use a new request_id.',
    'TOOL_SERVER_CLOSED': 'The tool server closed its connection or exited. If the call was refused or is recorded NOT_SENT, nothing reached the tool; if it is recorded UNKNOWN, reconcile it before any new call. Ask the tool owner why the server stopped.',
    'TOOL_SESSION_SIZE': 'The tool server sent more than 1048576 bytes in one session. Ask the tool owner to return less data per call; AAP stops reading at that limit.',
    'TOOL_RESERVED_METADATA': 'A request to the tool server already carried _meta, which this client fills in itself for version 2026-07-28. Do not put _meta in request parameters; report it if AAP itself produced it.',
    'TOOL_RESPONSE': 'The tool server sent a malformed JSON-RPC 2.0 message, or listed more than 512 tools. Ask the tool owner to fix the server; AAP does not use a malformed reply.',
    'TOOL_RESPONSE_ID': 'The tool server answered with a different request id than the one asked. Ask the tool owner to fix the server; AAP never matches an answer to the wrong request.',
    'TOOL_RPC_ERROR': 'The tool server returned a JSON-RPC error instead of a result. Check the tool name and arguments against the schema from discover; if they are right, ask the tool owner.',
    'TOOL_RESULT_TYPE_UNSUPPORTED': 'The version 2026-07-28 tool server returned a result whose resultType is not complete. This client does not follow partial or streamed results; ask the tool owner for a complete result.',
    'TOOL_SERVER_INFO': 'The version 2026-07-28 tool server reply lacks a serverInfo name and version in its _meta. Ask the tool owner to include them; the reply is not used.',
    'TOOL_NOTIFICATION_LIMIT': 'The tool server sent more than 128 messages without answering the request. Ask the tool owner to fix the server; the client stopped waiting.',
    'TOOL_PRIVATE_DIRECTORY': 'The call journal directory is not private: it must belong to the host user, allow no group or other access, and have no symlinks on its path. The host owner runs chmod 700 on it or picks another private directory.',
    'TOOL_STORAGE_CHANGED': 'The call journal file was replaced, moved or removed while in use. Stop, and have the host owner restore the original journal from a backup; never start a fresh journal to hide pending calls.',
    'TOOL_CONFIGURATION_CHANGED': 'The MCP server configuration differs from the one this journal or client was opened with. The host owner restores the original configuration, or resolves pending calls and opens a new journal directory for the new one.',
    'TOOL_PRIVATE_FILE': 'A call journal file is not a private regular file (owned by the host user, no group or other access, one link). The host owner fixes its permissions or restores it; never share the journal directory.',
    'TOOL_HISTORY_CHANGED': 'The call journal\'s hash chain is broken, so its history was edited or damaged. Stop using it and have the host owner restore a verified backup; never delete records to make it pass.',
    'TOOL_STORAGE_QUOTA': 'The call journal is full (20000 events or 64 MiB, counting space kept for unfinished calls). The host owner reconciles pending calls and archives this journal before opening a new directory.',
    'TOOL_OWNER_TRANSPORT': 'The owner transports do not match the servers configured with transport_pin. The host owner gives exactly one transport for each such server and none for the others.',
    'TOOL_TRANSPORT_PIN': 'An owner transport\'s manifest no longer hashes to its configured transport_pin. The host owner reinstalls the reviewed transport; a pin changes only after the owner reviews the new one.',
    'TOOL_SIGNER': 'The receipt signer setup is invalid. The host owner passes both signer (a valid Ed25519 public key) and sign (a callable), or neither.',
    'TOOL_OBSERVER': 'The observer given to the client is not callable. The host owner passes a function that looks up a call outcome, or leaves it out.',
    'TOOL_DUPLICATE_DESCRIPTOR': 'The tool server lists the same tool name twice, so a pin would be ambiguous. Ask the tool owner to fix the tool list; the call is refused.',
    'TOOL_PAGINATION': 'The tool server\'s list cursor is invalid or repeats an earlier page. Ask the tool owner to fix paging in tools/list.',
    'TOOL_PAGINATION_LIMIT': 'The tool server\'s list did not end within 64 pages. Ask the tool owner to fix paging or list fewer tools.',
    'TOOL_SERVER_UNKNOWN': 'No MCP server with that alias is configured on this host. Use an alias from installed(); the host owner adds servers in configuration, never through a call.',
    'TOOL_ARGUMENTS': 'The arguments do not match the pinned tool\'s input schema, or the tool\'s structured result does not match its output schema. Fix the arguments using the schema from discover; for a bad result, ask the tool owner.',
    'TOOL_NOT_PINNED': 'That tool is not pinned in the host\'s MCP configuration, so it cannot be called. The host owner reviews the tool and adds its description pin; a call cannot add one.',
    'TOOL_REQUEST_ID': 'The request_id is not 8 to 128 letters, digits or _.:- characters. Choose one request_id per intended call and keep it for every retry of that same call.',
    'TOOL_AGREEMENT': 'The deal reference is not a valid ID (1 to 128 letters, digits or _.:/+-). Pass the exact ID of the deal, or leave agreement out.',
    'TOOL_SIGNATURE': 'The owner\'s signing function did not return a valid 128-hex Ed25519 signature for the receipt. The call stays recorded with an unsigned receipt; the host owner fixes the signing setup.',
    'TOOL_STATE_CHANGED': 'The journal entry for this request changed while the call ran, so another process recorded it. Inspect the request to read its recorded outcome; do not send it again.',
    'TOOL_RESULT': 'The tool result is not a JSON object whose isError, if present, is true or false. Ask the tool owner to fix the result; a call that was sent stays recorded as UNKNOWN.',
    'TOOL_REQUEST_REUSED': 'This request_id was already used for a different server, tool or arguments. Use a new request_id for a new call, or resend exactly the original call to read its recorded outcome.',
    'TOOL_BUDGET': 'This server\'s lifetime call budget (max_calls, counting every attempt) is used up. The host owner decides whether more calls are intended; changing max_calls changes the configuration and needs a new journal directory.',
    'SYNTHETIC_CRASH_AFTER_INTENT': 'This is a crash injected by a test after the call intent was recorded and before anything was sent. Inspect the request; outside tests never pass the crash argument.',
    'TOOL_MISSING': 'The pinned tool is not in the server\'s current tool list. Ask the tool owner whether it was removed or renamed; the host owner pins a replacement only after review.',
    'TOOL_PIN_CHANGED': 'The live tool description no longer matches the owner\'s pin, so the tool may behave differently. Nothing was sent; the host owner reviews the new description before changing the pin.',
    'SYNTHETIC_CRASH_AFTER_RESPONSE': 'This is a crash injected by a test after the tool answered and before the outcome was recorded, so the journal shows an unknown outcome. Reconcile the request; outside tests never pass the crash argument.',
    'TOOL_REQUEST_MISSING': 'No call with that server alias and request_id is in the journal. Check both values; a request this client never recorded was never sent by it.',
    'TOOL_OBSERVER_REQUIRED': 'This unknown call can only be reconciled by an owner observer, and none is installed. The host owner installs an observer that looks up the real outcome; until then the call stays UNKNOWN.',
    'TOOL_OBSERVATION': 'The observer returned something other than {result, evidence_sha256} with a 64-hex evidence hash. The host owner fixes the observer; the call stays UNKNOWN until a valid observation is recorded.',
    'TOOL_CALLBACK_FIELDS': 'The connector callback takes exactly arguments and request_id. Pass only those two fields; the host owner fixed the server, tool and deal when installing it.',
    'TOOL_RECEIPT': 'The tool-call receipt is not an object with exactly body, signer and signature. Pass the receipt exactly as the client returned it.',
    'TOOL_RECEIPT_SIGNER': 'The receipt is not signed by the expected public key, or its body is not a covenant-tool-call/0.2 receipt. Check it against the key you pinned for that host; another signer is not accepted.',
    'OWNER_DIRECTORY': 'The owner directory is missing or not a directory, or its path is empty or contains "..". Pass the absolute path of an existing owner-private directory; owner_config may create only the last part, under an existing parent.',
    'OWNER_DIRECTORY_PERMISSIONS': 'The owner directory belongs to another user or is open to group or other users. As its owner, run chmod 700 on it (or choose a private directory) and run the command again.',
    'OWNER_FILE_PERMISSIONS': 'An owner file is not a private regular file of the host user (mode 0600, one link; owner_config files at most 65536 bytes). Fix it as its owner with chmod 600, or restore it from your own backup.',
    'OWNER_JSON': 'An owner file is not one valid JSON object (no repeated keys, at most 8 levels deep). Restore the original file from your own backup; do not hand-edit generated files.',
    'OWNER_CONFIG_EXISTS': 'A configuration file with that name already exists, and owner_config never overwrites one. Review the existing file; to replace it, move it aside yourself first.',
    'OWNER_SECRET_IN_CONFIG': 'The configuration has a field whose name suggests a secret (seed, secret, private, password, token_value or api_key). Remove it: owner files may name the environment variable that holds a secret, never the secret.',
    'BUILDER_PUBLISHERS': 'No valid trusted publisher was given. Pass 1 to 64 --publisher entries as ACCOUNT_HEX=PUBLIC_KEY_HEX, each 64 lowercase hex characters, using the publisher\'s real public key.',
    'BUILDER_POLICIES': 'The economics policies are not a list of at most 32 objects. Pass fewer policies, each as a JSON object.',
    'BUILDER_CONFIG': 'The builder owner file does not hold exactly version covenant-builder-owner/0.1, trusted_publishers, trusted_accounts, economics_policies and backends. Recreate it with python -m covenant_agent.owner_config builder instead of editing it.',
    'BUILDER_MECHANISMS': 'The mechanisms argument is not a MechanismRegistry. In the owner process, pass your own MechanismRegistry with its registered handlers, or leave it out.',
    'BUILDER_CONFIG_MISSING': 'There is no builder-owner.json in the owner directory. Create it with python -m covenant_agent.owner_config builder --directory DIR --publisher ACCOUNT=KEY.',
    'RAIL_NETWORK': 'The network name is not 1 to 80 lowercase letters, digits or :._- starting with a letter or digit (for example base-sepolia). Pass the network name the payment provider documents.',
    'RAIL_CREDENTIAL_ENV': 'The credential variable name is not 2 to 64 uppercase letters, digits or underscores starting with a letter. Pass the NAME of the environment variable that holds the credential, never its value.',
    'RAIL_ENDPOINT': 'The payment endpoint is not an https:// URL of 9 to 256 characters without a user name (@) or query (?). Pass the plain https endpoint of the provider, or leave it out.',
    'RAIL_PROVIDER_PIN': 'The provider pin is not 64 lowercase hex characters. Pass the exact pin you got from the provider through a channel you trust, or leave it out.',
    'RAIL_CONFIG': 'A saved payment method file is not exactly what owner_config writes, so it was changed. Recreate it with python -m covenant_agent.owner_config rail instead of editing it.',
    'OWNER_FILE_TOO_LARGE': 'A demo file is over the inspection limit (65536 bytes for JSON files, 32 MiB for reference.sqlite). Restore the original generated file; a larger store needs its own owner review.',
    'OWNER_SNAPSHOT_CHANGED': 'A file or the directory changed while it was being inspected. Stop every program writing to the demo directory and inspect it again before using the result.',
    'OWNER_CLOCK': 'A host file\'s clock_time is not a whole number from 0 to 2^53-1, or it differs from the manifest clock. Restore the generated host files so every role uses the manifest\'s clock.',
    'OWNER_MANIFEST': 'The demo manifest does not match this directory (format, version, provider, authority pin, or the four role hosts and identities). Restore the original key-free manifest for this exact directory; never adopt pins from an edited or unrelated one.',
    'OWNER_MANIFEST_CLOCK': 'The manifest clock is neither REAL_LOCAL_TIME with no time nor SANDBOX_FIXED with a whole-number time. Restore the original manifest that demo_setup wrote.',
    'OWNER_SQLITE_SNAPSHOT_UNAVAILABLE': 'This Python\'s sqlite3 module cannot load a database snapshot in memory (it has no deserialize). Run the inspection with Python 3.11 or later built against a current SQLite.',
    'OWNER_PROVIDER': 'The reference.sqlite file is not a covenant-reference-settlement-sqlite/0.2 store with a valid instance ID. Restore the original store from your own backup; inspection never creates, repairs or funds one.',
    'OWNER_CONFIG_FIELDS': 'A role host file has missing or extra fields; it needs version, seed, sandbox, work_order_profile, settlement_db and optionally clock_time. Restore it from your own backup; never paste its seed into a tool.',
    'OWNER_CONFIG_VERSION': 'A role host file names a different host version than this package runs. Recreate the demo with this package\'s demo_setup, or use the package version that wrote it.',
    'OWNER_CONFIG_SANDBOX': 'A role host file does not set sandbox to true, so it is not the generated synthetic demo. Inspection only recognises demo files; restore the generated file.',
    'OWNER_CONFIG_PROFILE': 'A role host file does not use the covenant-bilateral/0.2 work-order version the demo requires. Restore the generated host file.',
    'OWNER_CONFIG_PROVIDER_PATH': 'A role host file points settlement_db somewhere other than reference.sqlite in this directory. Restore the generated host file so all four roles share one reference store.',
    'OWNER_IDENTITY': 'A role host file\'s key does not produce the public identity listed in the manifest. Restore that role\'s file from your own backup; never change the manifest to match.',
    'OWNER_PROVIDER_BUSY': 'The reference.sqlite store has an active -wal, -shm or -journal file, so a host may still be writing. Stop the demo hosts and inspect again.',
    'OWNER_AUTHORITY_PIN': 'The reference store\'s authority ID does not match the manifest or the pin you passed. Check that you are inspecting the right directory; never accept a different authority to make it pass.',
    'DEMO_DIRECTORY': 'The demo directory is not a new private directory whose last part is a real name (not empty, ".", or ".."). Pass a new path under an existing parent, for example ~/aap-demo.',
    'DEMO_BALANCE': 'The opening test balance is not a whole number from 1 to 2^53-1 synthetic units. Pass a positive integer, or leave it out for 1000.',
    'DEMO_CLOCK': 'The fixed sandbox clock is not a whole number from 0 to 2^53-1 seconds. Pass a Unix time in that range, or leave it out to use the real local clock.',
    'DEMO_DIRECTORY_EXISTS': 'The demo directory already exists, and demo_setup never reuses or refills one. Choose a new directory name; check an old one with --inspect instead.',
    'DEMO_IDENTITIES': 'Two generated test identities came out equal, which should never happen. Run demo_setup again with a new directory, and report it if it repeats.',
    'CARD_COMPLEXITY': 'The agent card nests deeper than 32 levels or has more than 8192 values, or more than 8192 entries in one list or object. Ask the publisher for a smaller card; AAP does not read past these limits.',
    'CARD_SIZE_OR_SUBSET': 'A text value in the agent card is not plain ASCII or is longer than 262144 characters. Ask the publisher for a card in the supported ASCII subset.',
    'CARD_CYCLE': 'The card object refers to itself, so it cannot be serialised. Build the card from plain JSON data with no circular references.',
    'CARD_SUBSET': 'The card holds a value outside the supported subset: only text, whole numbers, true, false, null, lists and objects with text keys. Convert it to that subset; decimals are not supported.',
    'CARD_SIZE': 'The agent card is larger than the limit (262144 bytes overall, 65536 bytes of signed content). Ask the publisher for a smaller card.',
    'CARD_BASE64': 'A signature or header in the card is not valid unpadded base64url of at most 16384 characters. Get the card again exactly as published; do not re-encode it.',
    'CARD_SHAPE': 'The agent card is not a JSON object. Pass the card object itself, not a string or a list.',
    'CARD_NORMALIZATION_REQUIRED': 'The card has an empty list in a repeated field such as skills or tags, which this signing subset refuses. Remove empty lists before signing; ask the publisher to re-sign a normalised card.',
    'CARD_SIGNING_INPUT': 'The signing input needs a card object without signatures and a key ID of 1 to 256 characters. Remove existing signatures and pass a kid.',
    'CARD_TRUST': 'The trusted key map is not an object, or now is not a whole Unix time from 0 to 2^53-1. Pass your own trusted key map and the current Unix time.',
    'CARD_PIN': 'The card\'s content ID does not match the ID you pinned, so the card changed. Get the card you pinned; review a new version before pinning it.',
    'CARD_SIGNATURES': 'The card does not carry a list of 1 to 8 signatures. Get the signed card exactly as its publisher issued it.',
    'CARD_ALGORITHM': 'A card signature header is not alg EdDSA with typ JOSE and a text kid. Only EdDSA (Ed25519) cards are accepted here; ask the publisher for one.',
    'CARD_KEY_NOT_CURRENT': 'The trusted key for this card is outside its validity window, revoked, or not a valid Ed25519 key. Get a card signed by a current key in your trust map; never extend a revoked key.',
    'CARD_SIGNATURE': 'A card signature from a trusted key does not verify over the card\'s exact content. Get an unmodified card from its publisher; never edit the card or pin a different key to make it pass.',
    'CARD_NO_TRUSTED_SIGNATURE': 'No signature on the card comes from a key in your trust map. Get the publisher\'s key through a channel you trust and add it yourself; a key named inside the card is not trust.',
    'CARD_ENDPOINT': 'The server card does not list 1 to 16 endpoints that each start with https:// or stdio:. Pass only such endpoints.',
    'CARD_TOOLS_PIN': 'The tools pin is not 64 lowercase hex characters (the hash of the pinned tool list). Pass the exact pin you computed.',
    'PROVENANCE_FIELD': 'A fact\'s context or field is not text of at most 256 characters. Shorten them to the exact names the owner\'s policy uses.',
    'PROVENANCE_TIME': 'A fact\'s expiry is not a whole Unix time from 0 to 2^53-1. Pass an integer expiry in that range.',
    'PROVENANCE_POLICY': 'The provenance policy is malformed: it needs version covenant-provenance-policy/0.1, tier 0, 1 or 2, separate fixed and sourced fields, text source rules and distinct receipt signers. The host owner fixes the policy; tool input cannot.',
    'PROVENANCE_RECEIPT_REQUIRED': 'This policy tier needs named receipt signers and one receipt from each. The host owner names the signers in the policy, and each one signs the exact intent.',
    'PROVENANCE_VERIFIER': 'The deal verifier given to the gate is not callable. The host owner installs a verifier function, or leaves it out.',
    'PROVENANCE_POLICY_CHANGED': 'The loaded policy changed after the gate was installed. Stop, and have the host owner reinstall the reviewed policy; a changed policy is never used silently.',
    'PROVENANCE_INPUTS': 'The records do not match the policy\'s sourced fields exactly, or now is not a whole Unix time. Pass one signed record per sourced field and the current Unix time.',
    'PROVENANCE_OCCURRENCE': 'The request_id is missing or is not 8 to 128 letters, digits or _.:- (only tier 0 may leave it out). Pass one stable request_id per intended call and reuse it for retries of that call.',
    'PROVENANCE_SOURCE': 'A record comes from a different source, context or field than the policy names, or it has expired. Get a current record signed by the source the owner chose for that field.',
    'PROVENANCE_FACT': 'A record\'s body is not a valid fact (source, context, field, value, expiry). Pass the record exactly as its source signed it.',
    'PROVENANCE_RECEIPT_SIGNER': 'A receipt comes from a signer the policy does not name, or the same signer appears twice. Collect one receipt from each named signer over the exact intent.',
    'PROVENANCE_AGREEMENT_NOT_ADOPTED': 'This tier 2 call needs a deal reference that the owner\'s verifier confirms as adopted, and that check did not pass. Get the deal signed and adopted first; text that claims adoption is not adoption.',
    'PROVENANCE_DESCRIPTOR': 'The tool description pinned in the client differs from the one the policy names. Nothing was called; the host owner aligns the policy and the client\'s pins after reviewing the tool.',
    'IDENTIFIER_REGISTRY_PIN': 'The identifier is not text, or the registry hash you pinned does not match this registry. Pin the registry_hash from catalog() of the registry version you reviewed.',
    'IDENTIFIER_UNKNOWN_EXPLICIT_ADOPTION_REQUIRED': 'The identifier is not in this registry, so it has no agreed meaning here. Use a listed ID or version; a new one needs its own explicit adoption.',
    'SETTLEMENT_PROOF_REQUIRED': 'A required signed record (the deal, its settlement receipt or its time evidence) is missing. Pass the complete record you retained; the settlement authority does not rebuild it.',
    'SETTLEMENT_LIMIT': 'The record limit is not a whole number from 1 to 4096. Pass a limit in that range.',
    'ORDER_FINAL': 'This order is already settled, so only an earlier step of its own history can be sent again. Read the final record with covenant_verify; a change needs a new order and fresh signatures.',
    'SETTLEMENT_ADAPTER': 'The ledger given for a split payment is neither the shared reference store nor the in-memory test ledger. The host owner passes one of those; this package wires no other payment method.',
    'IGNITION_FIELDS': 'An escalation input is invalid: error must be a known class such as LATE or DISPUTED, amounts and times whole numbers of 0 or more, and anchor_requested true or false. Pass values of those types.',
    'IGNITION_SILENCE_NEEDS_DEADLINE': 'A SILENT deal can only be judged against its deadline, and deadline or as_of is missing. Pass both the agreed deadline and the time you observed, as whole Unix seconds.',
    'INHIBITION_ITEMS': 'The result list is too large or malformed: at most 256 items (and k at most 256), each with at most 256 feature words of 1 to 80 characters. Send fewer or shorter items.',
    'INHIBITION_LAMBDA': 'The diversity weight lam_bps is not a whole number from 0 to 10000 basis points. Pass a value in that range, or leave it out for 5000.',
    'EVIDENCE_CONSUME': 'The report and receipt do not fit one consumption: it needs an unapplied covenant-evidence-interface/0.1 report and an OBSERVED TRANSFER receipt for exactly the payee share (0 < payee <= quantity). Pass both unchanged; an applied report is never consumed twice.',
    'CONTENT_BASE64': 'The content_base64 value is not canonical standard base64 of 1 to 1000000 bytes (at most 1333336 characters, with padding). Encode the exact file bytes with standard base64 and send the result unchanged.',
    'CONTENT_LIMIT': 'The item limit is not a whole number from 1 to 100000. Pass a limit in that range.',
    'COMMERCE_EVIDENCE_KIND': 'That evidence kind (an allowance) exists only for ACP; UCP evidence is ORDER_EVENT or CHECKOUT_COMPLETED. Use protocol ACP for an allowance, or choose a kind your protocol supports.',
    'COMMERCE_ACTION': 'That covenant_commerce action does not exist. Read covenant_commerce describe, or covenant_explain, for the exact action names and send one of them.',
    'BUILDER_TRUST': 'A trusted account entry is not ACCOUNT_HEX=PUBLIC_KEY_HEX with 64 lowercase hex characters each, or there are more than 64. Pass at most 64 --trusted-account entries in that form, using the real public key.',
    'DEMO_SETUP_FAILED': 'The synthetic demo setup did not finish. Use a new directory under an existing trusted parent, and keep any partial private files for the owner to inspect; nothing real was created.',
    'OWNER_CONFIG_FAILED': 'The owner configuration command did not finish. Check the directory and arguments it names, then run it again; owner files are never overwritten.',
    'OWNER_INVALID_COMPONENT': 'A demo file could not be read the way the generated demo expects. Restore the original file from your own backup and inspect again.',
    'OWNER_FILE_MISSING': 'A file the demo needs is missing from the directory. Restore it from your own backup, or create a new demo in a new directory.',
    'OWNER_SYMLINK': 'A path in the demo directory is a symbolic link, and inspection never follows links. Replace it with the real file or directory.',
    'OWNER_DIRECTORY_OR_SYMLINK': 'A part of the demo path is not a directory, or is a symbolic link. Pass the real directory path, with no links in it.',
    'OWNER_ACCESS_DENIED': 'The operating system refused access to a demo file. Run the inspection as the user who owns the demo directory.',
    'OWNER_FILE_UNREADABLE': 'A demo file could not be read. Check that the disk and the file are intact, then inspect again.',
    'COMMERCE_SIGNATURE_UCP_ONLY':
        'RFC 9421 webhook signatures are checked for UCP order events only; ACP webhooks use the '
        'Merchant-Signature HMAC in the owner SDK (covenant_agent.commerce_acp).',
    'JOBS_ALIAS':
        'An alias in the job map is not a new plain word for one visible verb with a description, there are '
        'more than eight, or one shares a name with an entry instrument. Restore the released '
        'covenant_agent/data/action_jobs.json.',
    'PARTY_UNKEYED': "Replace the name with that party's 64-character lowercase hex verification key.",
    'PRINCIPAL_APPROVAL':
        'Sign the exact approval_request body with the adopted approver key, APPROVE to allow the spend or '
        'DECLINE to block it, and pass {body, signature}. A decline always blocks.',
    'PRINCIPAL_APPROVAL_SIGNATURE':
        'The decision is not signed by the adopted approver for this hire, policy and amount. Ask the owner to '
        'sign the exact approval_request body. Nothing was reserved.',
}


GENERIC_FIX = 'Correct the named input and retry. Do not change owner trust to force a pass.'


class NativeError(ValueError):
    """A stable code plus a remediation string. str(error) is the code."""

    def __init__(self, code, remediation=None):
        super().__init__(code)
        self.code = code
        self.remediation = remediation if remediation is not None else REMEDIATION.get(code, GENERIC_FIX)


def need(ok, code):
    if not ok:
        raise NativeError(code)


REFUSAL_FIELDS = ('code', 'what', 'fix', 'retry', 'reference')
REFERENCE = 'docs/REFERENCE.html'
RETRY = ('yes', 'after the fix', 'no')
# retry "yes": the same call, unchanged, can succeed later: a busy or rate-limited
# service, a temporary outage, a lock wait, a clock or witness that has not caught
# up, or a timeout whose documented recovery is to retry the same retained request.
RETRYABLE = frozenset({
    'AGREEMENT_HTTP_RATE', 'ANNOUNCE_RATE', 'CONNECTOR_RATE_LIMIT', 'GATEWAY_HOST_UNAVAILABLE',
    'INTENT_MARKET_BIDDING_OPEN', 'LOCK_TIMEOUT', 'OWNER_PROVIDER_BUSY', 'OWNER_SNAPSHOT_CHANGED',
    'PROOF_RATE_LIMIT', 'PROVIDER_RATE_LIMIT', 'PROVIDER_UNAVAILABLE', 'RELAY_BUSY', 'RELAY_RATE_LIMIT',
    'REQUEST_STORAGE_UNAVAILABLE_INSPECT_AND_RETRY_EXACT_OPERATION', 'RPC_UNREACHABLE',
    'SETTLEMENT_CLOCK_AHEAD', 'SETTLEMENT_WITNESS_RACE', 'SETTLEMENT_WITNESS_UNKNOWN', 'STRIPE_PROVIDER_UNAVAILABLE',
    'TIMED_LIGHT_ADMISSION_LIMIT', 'TOOL_ADMISSION_BACKPRESSURE', 'TOOL_ADMISSION_RATE', 'TOOL_TIMEOUT',
})
# retry "no": this step can never succeed again for the same deal or request.
FINAL = frozenset({
    'ACCREDITATION_STATUS_REVOKED', 'APPEAL_EXPIRED', 'APPEAL_FINAL', 'DEADLINE_EXPIRED', 'DUPLICATE_ASSENT', 'ORDER_FINAL',
    'SETTLEMENT_CONFLICT', 'X402_REPLAY',
})
CATALOG = Path(__file__).resolve().parents[1] / 'covenant_chain' / 'data' / 'error_fixes.json'
CODE = re.compile(r'[A-Z][A-Z0-9_]{0,100}\Z')
_SENTENCE = re.compile(r'(?<=\.)\s+(?=[A-Z])')
# A fix text that opens with one of these words starts by saying what happened.
_DESCRIPTIVE = frozenset({'A', 'An', 'Another', 'Both', 'Each', 'Every', 'It', 'Its', 'No', 'Nothing', 'One',
                          'Some', 'That', 'The', 'There', 'These', 'This', 'Those', 'Two', 'Your'})


@lru_cache(maxsize=1)
def _catalog():
    """{code: fix or None} from tools/build_lead_docs.py; empty when absent, so refusals never fail on it."""
    try:
        with open(CATALOG, 'rb') as stream:
            value = json.loads(stream.read(4_000_001))
    except (OSError, ValueError):
        return {}
    codes = value.get('codes') if type(value) is dict else None
    return {code: fix for code, fix in codes.items()
            if type(code) is str and (fix is None or type(fix) is str)} if type(codes) is dict else {}


def catalog_fix(code):
    """The fix text written for this code where every place raising it shares that text, else None."""
    fix = _catalog().get(code)
    return fix if type(fix) is str and fix else None


def reference(code):
    return REFERENCE + '#' + code if code in _catalog() else REFERENCE + '#errors'


def retry_for(code):
    return 'yes' if code in RETRYABLE else 'no' if code in FINAL else 'after the fix'


def what_happened(code, fix):
    """The fix text's first sentence when it says what happened; otherwise a plain statement of the refusal."""
    first = _SENTENCE.split(fix.strip(), 1)[0] if type(fix) is str and fix.strip() else ''
    if first.endswith('.') and len(first) <= 240 and first.split(None, 1)[0] in _DESCRIPTIVE:
        return first
    return 'The call was refused with code ' + code + '.'


def refusal(code, fix=None, *, what=None, retry=None):
    """status, code, what, fix, retry and reference: the one shape of a refusal at the agent boundary.

    ``fix`` is the caller's own guidance; without it the shared catalog, then the
    generic advice, apply. The shape describes a refusal; it grants nothing.
    """
    code = code if type(code) is str and CODE.fullmatch(code) else 'INVALID_INPUT_OR_PROOF'
    if not (type(fix) is str and fix.strip()) or fix == GENERIC_FIX:
        fix = catalog_fix(code) or GENERIC_FIX
    if not (type(what) is str and what.strip()):
        what = what_happened(code, fix)
    return {'status': 'REFUSED', 'code': code, 'what': what, 'fix': fix,
            'retry': retry if retry in RETRY else retry_for(code), 'reference': reference(code)}


def shaped(body):
    """An HTTP or JSON-RPC refusal body with the shared fields added; keys already present win.

    {'error': CODE, ...} gains status, code, what, fix, retry and reference. A
    JSON-RPC error whose message is a CODE carries them in error.data.
    """
    if type(body) is not dict:
        return body
    error = body.get('error')
    if type(error) is str and CODE.fullmatch(error):
        return _keep_first(body, refusal(error))
    if type(error) is dict and type(error.get('message')) is str and CODE.fullmatch(error['message']):
        data = error.get('data')
        if data is None or type(data) is dict:
            return {**body, 'error': {**error, 'data': _keep_first(data or {}, refusal(error['message']))}}
    return body


def _keep_first(first, extra):
    """first's keys, values and order unchanged, then extra's other keys."""
    return {**first, **{key: value for key, value in extra.items() if key not in first}}
