"""Agent payment actions beside the owner Stripe Checkout gateway.

Profile covenant-stripe-payment-action/0.1 names one operation (pay, capture,
cancel or refund) that an agent asks the owner's Stripe gateway to carry out
for one exact agreement version. It extends covenant_agent.stripe_gateway,
whose Checkout profile covenant-stripe-checkout/0.1 and signed bytes are
unchanged: Checkout lets a payer finish a hosted page; this record lets an
agent charge a Shared Payment Token or a saved payment method directly.

A record never carries a credential. A Shared Payment Token or saved payment
method is named by an owner vault reference and the restricted API key stays
in the owner transport. Signing or holding a record grants nothing: the
owner's gateway checks the agent's delegation grant, the payer's exact
authorisation, the owner's own approval above its adopted threshold and a
durable budget (covenant_agent.stripe_payments).
"""
from copy import deepcopy
import hashlib
import json
import re
import secrets

from covenant_chain.crypto import canonical, digest, exact, integer, need, public_key, sign, verify
from covenant_language.key_validation import valid_ed25519_key

from .assent_view import utc

VERSION = 'covenant-stripe-payment-action/0.1'
ACTION_LABEL = 'COVENANT-STRIPE-PAYMENT-ACTION-0.1'
PAYER_LABEL = 'COVENANT-STRIPE-PAYMENT-PAYER-0.1'
IDEMPOTENCY_LABEL = 'COVENANT-STRIPE-PAYMENT-IDEMPOTENCY-0.1'
REFERENCE = 'docs/STRIPE_GATEWAY.html'
OPERATIONS = ('pay', 'capture', 'cancel', 'refund')
SOURCES = ('payment_method', 'shared_payment_token')
CAPTURE_METHODS = ('automatic', 'automatic_async', 'manual')
TARGETS = ('payment_action', 'checkout')
# The release StripeHTTPTransport pins, and the preview release Stripe's
# Shared Payment Token pages use in every example (docs.stripe.com/agentic-commerce).
API_VERSION = '2026-09-30.endive'
PREVIEW_VERSION = '2026-09-30.preview'
API_VERSIONS = (API_VERSION, PREVIEW_VERSION)
UNKNOWN_RULE = 'BLOCK_UNTIL_RECONCILED'
PROVIDER_FEES = 'MERCHANT_BORNE_UNQUOTED_STRIPE_CONTRACT'
MAX_AMOUNT = 99999999
# docs.stripe.com/currencies: zero-decimal currencies; ISK and UGX are written
# as two-decimal values whose decimal part is always 00. Three-decimal ISO 4217
# currencies are refused until their Stripe rule is confirmed.
ZERO_DECIMAL = frozenset('bif clp djf gnf jpy kmf krw mga pyg rwf vnd vuv xaf xof xpf'.split())
WHOLE_UNITS = frozenset(('isk', 'ugx'))
UNCONFIRMED = frozenset('bhd iqd jod kwd lyd omr tnd'.split())
FIELDS = ('version policy agreement revision principal agent grant credential_policy operation target payer '
          'merchant amount currency description expires api_version source capture_method observation '
          'operation_id gateway_fee provider_fees livemode')
HEX = re.compile(r'[0-9a-f]{64}\Z')
ACCOUNT = re.compile(r'acct_[A-Za-z0-9]{1,80}\Z')
CUSTOMER = re.compile(r'cus_[A-Za-z0-9]{1,80}\Z')
CURRENCY = re.compile(r'[a-z]{3}\Z')

# Every refusal teaches: what happened, the fix and whether a retry helps.
# Checkout codes from covenant_agent.stripe_gateway are explained here too; that
# module still raises them unchanged.
ERRORS = {
    'STRIPE_PAYMENT_PROFILE': ('The record is not a covenant-stripe-payment-action/0.1 action.', 'Draft it with stripe_action.draft.', 'after the fix'),
    'STRIPE_PAYMENT_FIELD': ('A field of the payment action is missing, extra or malformed.', 'Use exactly the documented fields and value shapes.', 'after the fix'),
    'STRIPE_PAYMENT_PARTIES': ('Owner, agent and payer must be three different valid public keys.', 'Name the owner (principal), its agent and the paying party separately.', 'after the fix'),
    'STRIPE_PAYMENT_OPERATION': ('The operation is not pay, capture, cancel or refund.', 'Choose one of the four operations.', 'after the fix'),
    'STRIPE_PAYMENT_TARGET': ('The target does not fit the operation or this payment.', 'A pay has no target; capture and cancel name a pay action; a refund names a pay action or a Checkout effect of the same agreement and payer.', 'after the fix'),
    'STRIPE_PAYMENT_MERCHANT': ('The merchant is not a Stripe account id (acct_...).', "Use the owner's adopted Stripe account id.", 'after the fix'),
    'STRIPE_PAYMENT_CURRENCY': ('The currency is not a three-letter lowercase ISO 4217 code.', 'Write the currency in lowercase, for example usd.', 'after the fix'),
    'STRIPE_PAYMENT_CURRENCY_UNCONFIRMED': ('Three-decimal currencies are refused until their Stripe rule is confirmed.', 'Use a two-decimal or zero-decimal currency.', 'no'),
    'STRIPE_PAYMENT_AMOUNT': ('The amount must be an integer from 1 to 99999999 minor units.', 'Write the amount in minor units: 2500 is 25.00 USD, 500 is 500 JPY.', 'after the fix'),
    'STRIPE_PAYMENT_WHOLE_UNITS': ('ISK and UGX amounts are written with two decimals that must be 00.', 'Use a multiple of 100.', 'after the fix'),
    'STRIPE_PAYMENT_API_VERSION': ('The Stripe API version is not one this gateway pins, or a Shared Payment Token needs the preview version.', 'Use 2026-09-30.endive, or 2026-09-30.preview for a Shared Payment Token.', 'after the fix'),
    'STRIPE_PAYMENT_SOURCE': ('The payment source does not fit the operation.', 'A pay names one owner vault reference of kind shared_payment_token or payment_method; a token has no customer and no manual capture; other operations have no source.', 'after the fix'),
    'STRIPE_PAYMENT_CAPTURE_METHOD': ('The capture method is not automatic, automatic_async or manual.', 'Choose one Stripe capture method for a pay.', 'after the fix'),
    'STRIPE_PAYMENT_OBSERVATION': ('The observation and recovery policy is malformed.', 'Give webhooks (true or false), reconcile_after (1 to 86400 seconds) and unknown BLOCK_UNTIL_RECONCILED.', 'after the fix'),
    'STRIPE_PAYMENT_FEES': ('The gateway fee must be 0 and Stripe fees are merchant-borne and unquoted.', 'Keep gateway_fee 0 and provider_fees MERCHANT_BORNE_UNQUOTED_STRIPE_CONTRACT.', 'after the fix'),
    'STRIPE_PAYMENT_MODE': ('livemode must be true or false.', 'Use the mode of the owner policy; sandbox is the default.', 'after the fix'),
    'STRIPE_PAYMENT_TEXT': ('The description must be 1 to 120 printable ASCII characters.', 'Shorten or simplify the description.', 'after the fix'),
    'STRIPE_PAYMENT_AGENT_SIGNER': ('The signing key is not the agent named in the action.', 'Sign with the agent key the action names.', 'after the fix'),
    'STRIPE_PAYMENT_AGENT_SIGNATURE': ("The agent's signature does not verify over these exact bytes.", 'Obtain a fresh agent signature over the unchanged action.', 'after the fix'),
    'STRIPE_PAYMENT_RECORD': ('A signed action is {body, signature}.', 'Send the record exactly as sign_action returned it.', 'after the fix'),
    'STRIPE_PAYMENT_PAYER_SIGNER': ('The authorising key is not the payer named in the action.', 'The payer signs its own exact authorisation.', 'after the fix'),
    'STRIPE_PAYMENT_PAYER_BINDING': ("The payer's authorisation names another action or signer.", 'Ask the payer to authorise this exact action.', 'after the fix'),
    'STRIPE_PAYMENT_PAYER_SIGNATURE': ("The payer's authorisation does not verify over this exact action.", 'Ask the payer to authorise the unchanged action again; changed terms need a fresh authorisation.', 'after the fix'),
    'STRIPE_PAYMENT_PAYER_REQUIRED': ("A pay needs the payer's exact authorisation.", "Send the payer's signature from stripe_action.authorize.", 'after the fix'),
    'STRIPE_PAYMENT_POLICY': ('The payment policy is malformed or its owner signature does not verify.', 'Build it with stripe_payments.policy_body and sign it with the owner key.', 'after the fix'),
    'STRIPE_PAYMENT_POLICY_PIN': ('The action or policy names another Checkout policy or payment policy.', "Draft the action against this gateway's current policy id.", 'after the fix'),
    'STRIPE_PAYMENT_POLICY_ROLLBACK': ('An older or different-owner payment policy was offered after a newer one.', 'Adopt only a newer policy signed by the same owner.', 'no'),
    'STRIPE_PAYMENT_POLICY_INACTIVE': ('The owner payment policy is not active at the adopted time.', 'Ask the owner to adopt a current policy.', 'after the fix'),
    'STRIPE_PAYMENT_POLICY_TERMS': ('Merchant, currency or mode differ from the owner Checkout policy.', 'Use the adopted account, currency and mode.', 'after the fix'),
    'STRIPE_PAYMENT_PRINCIPAL': ('The principal is not the owner who signed the payment policy.', 'Name the adopted owner key as principal.', 'after the fix'),
    'STRIPE_PAYMENT_CREDENTIAL_POLICY': ('The action names another credential policy.', "Use credential_policy from this gateway's describe().", 'after the fix'),
    'STRIPE_PAYMENT_OPERATION_NOT_ADOPTED': ('The owner policy does not adopt this operation.', 'Ask the owner to adopt it, or use another operation.', 'no'),
    'STRIPE_PAYMENT_SOURCE_NOT_ADOPTED': ('The owner policy does not adopt this kind of payment source.', 'Use an adopted source kind.', 'no'),
    'STRIPE_PAYMENT_SOURCE_UNAVAILABLE': ('The owner vault holds no payment source under this reference.', "Ask the owner's intake to register the token or payment method again.", 'after the fix'),
    'STRIPE_PAYMENT_EXPIRY': ('The action has expired or lives longer than the owner policy allows.', 'Draft a new action that expires inside the allowed window.', 'after the fix'),
    'STRIPE_PAYMENT_GRANT': ('The delegation chain is missing or malformed.', "Send the owner's covenant-delegation-grant/0.1 chain for this agent.", 'after the fix'),
    'STRIPE_PAYMENT_GRANT_REFUSED': ("The agent's delegation grant does not cover this operation now.", 'Ask the owner for a current grant with the stripe:<operation> capability; revoked or expired grants stay refused.', 'after the fix'),
    'STRIPE_PAYMENT_GRANT_MISMATCH': ('The action names another leaf grant than the chain proves.', 'Name the leaf grant id of the chain you send.', 'after the fix'),
    'STRIPE_PAYMENT_TARGET_STATE': ('The target payment is not in a state that allows this operation.', 'Reconcile the target first; capture needs an authorised manual payment, cancel an uncaptured one, refund a captured one.', 'after reconciliation'),
    'STRIPE_PAYMENT_REFUND_LIMIT': ('The refund would exceed what remains refundable.', 'Refund at most the captured amount less earlier and pending refunds.', 'after the fix'),
    'STRIPE_PAYMENT_CAPTURE_LIMIT': ('The capture exceeds the authorised amount.', 'Capture at most the amount the payment can capture.', 'after the fix'),
    'STRIPE_PAYMENT_UNRESOLVED': ('Another operation for this agreement or payment is still in flight or UNKNOWN.', 'Reconcile it first. A new attempt could pay twice.', 'after reconciliation'),
    'STRIPE_PAYMENT_UNKNOWN_BLOCKS': ('A payment between these parties has an UNKNOWN outcome.', 'Reconcile it before any retry, Checkout or other rail. A new idempotency key or another provider could pay twice.', 'after reconciliation'),
    'STRIPE_PAYMENT_ALREADY_PAID': ('This agreement already has a payment, through a payment action or Checkout, that succeeded or is pending.', 'Refund or cancel it, or draft a new agreement; profile 0.1 takes one payment per agreement.', 'no'),
    'STRIPE_PAYMENT_CHECKOUT_OPEN': ('A Checkout for this agreement may still be paid or is unresolved.', 'Observe the Checkout after its expiry, or finish the payment through it.', 'after reconciliation'),
    'STRIPE_PAYMENT_PAYMENT_OPEN': ('A payment action for this agreement may still be paid.', 'Reconcile or cancel it before creating a Checkout.', 'after reconciliation'),
    'STRIPE_PAYMENT_OPERATION_REUSED': ('This operation id already names a different action.', 'Draft the new action with a fresh operation_id.', 'after the fix'),
    'STRIPE_PAYMENT_BUDGET_MISSING': ('The owner policy has no budget for this operation.', 'Ask the owner to adopt a pay or refund budget.', 'no'),
    'STRIPE_PAYMENT_BUDGET_EXCEEDED': ('A reservation would exceed the owner budget for the agreement, counterparty, period or Checkout aggregate.', 'Wait for the period to pass, or ask the owner for a new budget. Nothing was sent to Stripe.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_REQUIRED': ("The amount is above the owner's threshold. Nothing was sent to Stripe.", "The owner reads the exact rendering, approves it with the adopted method, then the same action is submitted again.", 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_POLICY': ('An approval policy is not owner-signed, names another owner or is not adopted.', 'Supply the owner-signed covenant-assent-policy/0.1 records the payment policy lists.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_POLICY_MISSING': ('No adopted approval policy covers this agent, so no limit can be checked.', 'Ask the owner to adopt an approval policy for this agent key.', 'no'),
    'STRIPE_PAYMENT_APPROVAL_POLICY_INACTIVE': ("The owner's approval policy is not active now.", 'Ask the owner to adopt a current approval policy.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_FIELDS': ('The approval record or request is malformed.', 'Send the approval exactly as the owner tool produced it.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_UNKNOWN': ('This gateway did not issue the approval request.', 'Submit the action without an approval to obtain a fresh request.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_CHANGED': ('The approval names other action bytes, another gateway policy or a changed request.', 'Changed terms need a new request and a fresh owner approval.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_EXPIRED': ('The approval request expired before use.', 'Submit again for a new request and approve it in time.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_METHOD': ("The approval uses another method than the owner's adopted one.", 'Approve with the adopted owner key or passkey.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_SIGNATURE': ("The owner approval signature does not verify.", 'Approve again with the adopted approval key; never re-pin a key to force a pass.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_PASSKEY': ('The passkey assertion does not verify, lacks user verification or repeats a counter.', 'Approve again on the registered device.', 'after the fix'),
    'STRIPE_PAYMENT_APPROVAL_REFUSED': ('The owner refused this exact action.', 'Do not retry it. Propose different terms if the owner wants them.', 'no'),
    'STRIPE_PAYMENT_APPROVAL_REUSED': ('This approval was already consumed by another operation.', 'Each approval authorises one operation; submit again for a new request.', 'no'),
    'STRIPE_PAYMENT_APPROVAL_BACKLOG': ('Too many approval requests are pending.', 'Let the owner decide or let requests expire.', 'yes'),
    'STRIPE_PAYMENT_OBSERVER_REFUSED': ("The owner's spend observer refused this action (for example a suspended agent).", 'Ask the owner; a refusal by the observer is never bypassed.', 'no'),
    'STRIPE_PAYMENT_TRANSPORT': ('The gateway transport is not a StripePaymentTransport.', 'Install StripePaymentTransport (it extends StripeHTTPTransport) in the owner gateway.', 'after the fix'),
    'STRIPE_PAYMENT_GATEWAY': ('The payment extension needs an owner StripeGateway.', 'Open the owner custody with covenant_agent.stripe_gateway.StripeGateway first.', 'after the fix'),
    'STRIPE_PAYMENT_OPERATION_UNKNOWN': ('This gateway holds no operation with that id.', 'Check the operation id.', 'after the fix'),
    'STRIPE_PAYMENT_TOKEN_SCOPE': ("The Shared Payment Token's own limits do not cover this charge, or it is deactivated.", 'Ask the payer for a token with the exact currency, a large enough maximum and a later expiry.', 'after the fix'),
    'STRIPE_PAYMENT_TOKEN_UNVERIFIED': ("The token's limits could not be read, so nothing was charged.", 'Submit a new action later.', 'after the fix'),
    'STRIPE_PAYMENT_NO_RESPONSE': ('No reply arrived: timeout, reset or lost response. The charge may have happened.', 'Reconcile. Never retry with a new operation or another rail first.', 'after reconciliation'),
    'STRIPE_PAYMENT_RESPONSE': ('Stripe replied 2xx with a body that is not the expected object.', 'Reconcile by retrieval.', 'after reconciliation'),
    'STRIPE_PAYMENT_PROVIDER_BINDING': ("The provider object does not carry this action's agreement, operation, amount, currency or mode.", 'Reconcile; a foreign object is never credited.', 'after reconciliation'),
    'STRIPE_PAYMENT_PROVIDER_ERROR': ('Stripe answered 424 or 5xx. The outcome is UNKNOWN.', 'Reconcile by retrieval before anything else.', 'after reconciliation'),
    'STRIPE_PAYMENT_IDEMPOTENCY_CONFLICT': ('Stripe reports a conflict (409) or an idempotency error for this operation. The outcome is UNKNOWN.', 'Reconcile; do not send different parameters under the same operation.', 'after reconciliation'),
    'STRIPE_PAYMENT_DECLINED': ('Stripe declined the charge (402). No money moved.', 'Ask the payer for another source and submit a new action.', 'after the fix'),
    'STRIPE_PAYMENT_PROVIDER_REFUSED': ('Stripe refused the request before execution (400, 401, 403 or 404). No money moved.', 'Correct the request or the restricted key permissions, then submit a new action.', 'after the fix'),
    'STRIPE_PAYMENT_RATE_LIMITED': ('Stripe rate-limited the request (429) before executing it. No money moved.', 'Submit a new action after a pause.', 'yes'),
    'STRIPE_PAYMENT_NOT_COMPLETED': ('The PaymentIntent ended without collecting money.', 'Submit a new action with another source if the deal still needs payment.', 'after the fix'),
    'STRIPE_PAYMENT_NOT_CAPTURED': ('The payment is still uncaptured after the capture.', 'Reconcile later or capture again with a new operation.', 'after reconciliation'),
    'STRIPE_PAYMENT_NOT_CANCELLED': ('The payment was not cancelled.', 'Reconcile; a captured payment needs a refund instead.', 'after reconciliation'),
    'STRIPE_PAYMENT_REFUND_FAILED': ('Stripe reports the refund failed or was cancelled.', 'Reconcile and decide another remedy with the payer.', 'after the fix'),
    'STRIPE_PAYMENT_REPLAY_WINDOW': ("A same-key replay is allowed only within 23 hours of the first attempt and before the action expires.", 'Reconcile by retrieval, or ask the owner to sign a resolution.', 'no'),
    'STRIPE_PAYMENT_DUPLICATE_PROVIDER_OBJECTS': ('Stripe holds more than one object for one operation.', 'Stop and ask the owner: refund the duplicate through the Dashboard or a refund action.', 'no'),
    'STRIPE_PAYMENT_RESOLUTION': ("The owner's resolution record is malformed or not signed by the owner.", 'Sign covenant-stripe-payment-resolution/0.1 with the owner key.', 'after the fix'),
    'STRIPE_PAYMENT_RESOLUTION_STATE': ('Only an UNKNOWN operation without a known provider object can be resolved by the owner.', 'Reconcile by retrieval instead.', 'no'),
    'STRIPE_PAYMENT_EVENT_SCOPE': ('The event type, mode or account is not one this gateway adopts.', 'Send PaymentIntent, refund and dispute events of the adopted account and mode.', 'no'),
    'STRIPE_PAYMENT_EVENT_REPLAY_CHANGED': ('An event id arrived again with different bytes.', 'Investigate; the stored event stands.', 'no'),
    'STRIPE_PAYMENT_EVENT': ('The event body is not a Stripe event with an object.', 'Send the raw webhook body unchanged.', 'no'),
    'STRIPE_PAYMENT_STORE_FULL': ('The payment custody store reached its bound.', 'Open a new custody directory after exporting the records.', 'no'),
    'STRIPE_PAYMENT_EVIDENCE_KIND': ('Only dispute records can be appended from outside this module.', 'Use stripe_disputes for AAP dispute records.', 'no'),
    'STRIPE_PAYMENT_RECORD_PROFILE': ('The portable payment record is malformed or of another profile.', 'Export it with portable_record and pass it unchanged.', 'no'),
    'STRIPE_PAYMENT_RECORD_CHAIN': ('The evidence chain of the portable record does not verify.', 'Obtain an unmodified record; compare with an independently retained head.', 'no'),
    'STRIPE_PAYMENT_RECORD_PIN': ('The record is for another agreement, owner or head than you expected.', 'Check the pins you obtained separately.', 'no'),
    'STRIPE_PAYMENT_BACKUP': ('The backup target exists or is unusable.', 'Name a new file in an owner-private directory.', 'after the fix'),
    'STRIPE_DISPUTE_RECORD': ('The chargeback dispute record is malformed or changed.', 'Use the record stripe_disputes produced, unchanged.', 'no'),
    'STRIPE_DISPUTE_UNKNOWN': ('No provider dispute with that id is recorded for this agreement.', 'Reconcile the payment so its disputes are read first.', 'after reconciliation'),
    'STRIPE_DISPUTE_LADDER': ("The dispute ladder is not the one the agreement's parties adopted, or the actor is not a disputant.", 'Pass {policy, adoptions, events} of the adopted ladder and a disputant role.', 'after the fix'),
    'STRIPE_DISPUTE_EVIDENCE': ('The evidence for Stripe is too large or contains unsupported fields.', 'Keep under 150000 characters in total; AAP sends only hashes, amounts and times.', 'after the fix'),
    'STRIPE_DISPUTE_CLOSED': ('The provider dispute is closed; evidence can no longer change it.', 'Record the outcome; no new evidence is staged.', 'no'),
    'STRIPE_DISPUTE_STAGE': ('Stripe did not accept the staged evidence.', 'Reconcile the dispute, then stage again; AAP never submits evidence to the bank.', 'after reconciliation'),
    'STRIPE_SERVICE_ROUTE': ('The owner service has no such route.', 'Use a route that describe lists.', 'after the fix'),
    'STRIPE_SERVICE_SIZE': ('The request body is larger than the route allows.', 'Send at most 64 KiB of JSON, or 1 MiB for a Stripe event.', 'after the fix'),
    'STRIPE_SERVICE_FAILED': ('An owner command failed without a more specific code.', 'Run the command again with valid arguments; credentials are never printed.', 'after the fix'),
    # Owner configuration codes (covenant_agent.owner_config) as the Stripe service reports them.
    'OWNER_CONFIG_MISSING': ('The owner directory has no stripe-owner.json.', 'Write it with stripe_service.write_config, or name the right --directory.', 'after the fix'),
    'OWNER_CONFIG_EXISTS': ('stripe-owner.json already exists; it is never overwritten.', 'Move the old file aside deliberately, then write the new one.', 'after the fix'),
    'OWNER_JSON': ('stripe-owner.json has missing, extra or invalid fields, or another version.', 'Write it again with stripe_service.write_config, which checks every field; timeout is 1 to 25 seconds.', 'after the fix'),
    'OWNER_SECRET_IN_CONFIG': ('The configuration holds what looks like a key or signing secret.', 'Keep credentials in your secret service; the file only names the environment variables that hold them.', 'after the fix'),
    'RAIL_CREDENTIAL_ENV': ('key_env or webhook_env is not an upper-case environment variable name.', 'Use names such as AAP_STRIPE_KEY and AAP_STRIPE_WEBHOOK_SECRET.', 'after the fix'),
    'OWNER_DIRECTORY': ('The owner directory is missing or is not a directory.', 'Create it with mode 0700, or name the right --directory.', 'after the fix'),
    'OWNER_DIRECTORY_PERMISSIONS': ('The owner directory belongs to another user or others can read it.', 'Run chmod 700 on it as the user who runs the gateway.', 'after the fix'),
    'OWNER_FILE_PERMISSIONS': ('stripe-owner.json belongs to another user, others can read it, or it is too large.', 'Run chmod 600 on it as the user who runs the gateway.', 'after the fix'),
    'STRIPE_REVIEW_INPUT': ('The review input is not a portable payment record or delivery check.', 'Pass the exported record and, separately, the verified delivery receipt.', 'after the fix'),
    # Checkout codes raised by covenant_agent.stripe_gateway.
    'STRIPE_ACCOUNT': ('The account is not a Stripe account id (acct_...).', 'Adopt the exact merchant account id.', 'after the fix'),
    'STRIPE_ACCOUNT_MISMATCH': ('The restricted key belongs to another Stripe account.', 'Install the key of the adopted account.', 'after the fix'),
    'STRIPE_AMOUNT': ('The amount must be 1 to 99999999 minor units.', 'Write the amount in minor units.', 'after the fix'),
    'STRIPE_APPROVAL_BINDING': ("The payer's approval names another intent or signer.", 'Ask the payer to approve this exact intent.', 'after the fix'),
    'STRIPE_APPROVAL_SIGNER': ('The approving key is not the payer of the intent.', 'The payer signs its own approval.', 'after the fix'),
    'STRIPE_BUDGET': ('The maximum order exceeds the operation budget.', 'Set maximum_order at or below operation_budget.', 'after the fix'),
    'STRIPE_BUDGET_EXCEEDED': ("The owner's cumulative commitment budget is used up.", 'Ask the owner for an explicit new budget; commitments are never released automatically.', 'no'),
    'STRIPE_CHARGE_STATE': ('The charge reports an impossible refund or dispute state.', 'Reconcile again; investigate the provider data.', 'after reconciliation'),
    'STRIPE_CHARGE_TERMS': ('The charge does not match the approved amount, currency, mode or payment.', 'Investigate; a foreign charge is never credited.', 'no'),
    'STRIPE_CHECKOUT_EXPIRY': ('A Checkout must expire 30 minutes to 24 hours after now.', 'Prepare an intent with an expiry in that window.', 'after the fix'),
    'STRIPE_CHECKOUT_URL': ('Stripe returned a Checkout URL outside checkout.stripe.com.', 'Do not give the URL to anyone; reconcile.', 'after reconciliation'),
    'STRIPE_CREDENTIAL_GETTER': ('The credential must come from an owner callable.', 'Pass a function that reads the restricted key from the owner secret service.', 'after the fix'),
    'STRIPE_CREDENTIAL_UNAVAILABLE': ('The owner secret service did not supply the key.', 'Fix the owner secret service; the key is never printed.', 'after the fix'),
    'STRIPE_CURRENCY': ('The currency is not a three-letter lowercase code.', 'Write the currency in lowercase.', 'after the fix'),
    'STRIPE_CUSTODY_CHANGED': ('Stored custody no longer matches its approval.', 'Restore the custody directory from a verified backup.', 'no'),
    'STRIPE_DUPLICATE_JSON_KEY': ('Provider JSON repeats a member name.', 'Treat the reply as unknown and reconcile.', 'after reconciliation'),
    'STRIPE_HARNESS': ('loopback_harness must be true or false.', 'Use the documented flag.', 'after the fix'),
    'STRIPE_HARNESS_ORIGIN': ('The local harness must be http://127.0.0.1:PORT in sandbox mode.', 'Use a loopback origin.', 'after the fix'),
    'STRIPE_INTENT_CHANGED': ('The intent differs from what the policy rebuilds.', 'Prepare the intent again with the adopted policy.', 'after the fix'),
    'STRIPE_JSON': ('The provider reply is not JSON.', 'Reconcile by retrieval.', 'after reconciliation'),
    'STRIPE_LIVE_NOT_ADOPTED': ('Live mode needs a live policy and an explicitly live-adopted transport.', 'Stay in sandbox unless the owner adopts live mode.', 'no'),
    'STRIPE_MODE': ('livemode must be true or false.', 'Use the documented flag.', 'after the fix'),
    'STRIPE_MULTIPLE_SESSIONS': ('More than one Checkout carries this intent.', 'Stop and investigate in the Dashboard.', 'no'),
    'STRIPE_OPERATION_UNKNOWN': ('No Checkout with that effect id is held.', 'Check the effect id.', 'after the fix'),
    'STRIPE_ORDER_LIMIT': ('The amount exceeds the owner maximum per order.', 'Lower the amount or ask the owner.', 'after the fix'),
    'STRIPE_ORIGIN': ('The provider origin must be exactly https://api.stripe.com.', 'Use the fixed origin.', 'after the fix'),
    'STRIPE_OUTCOME_UNKNOWN_RECONCILE': ('A Checkout attempt has an UNKNOWN outcome.', 'Call observe(effect) to reconcile before anything else.', 'after reconciliation'),
    'STRIPE_PAID_WITHOUT_PAYMENT': ('Checkout says paid but no payment is visible.', 'Reconcile again later.', 'after reconciliation'),
    'STRIPE_PAYERS': ('Payer keys must be 1 to 64 distinct keys.', 'Adopt the exact payer keys.', 'after the fix'),
    'STRIPE_PAYER_NOT_ADOPTED': ('The payer is not adopted by the owner policy.', 'Ask the owner to adopt this payer key.', 'no'),
    'STRIPE_PAYMENT_RECEIVED': ('The PaymentIntent received another amount than approved.', 'Investigate; nothing is credited.', 'no'),
    'STRIPE_PAYMENT_STATUS': ('The PaymentIntent status is not a documented one.', 'Reconcile later.', 'after reconciliation'),
    'STRIPE_PAYMENT_TERMS': ('The PaymentIntent does not match the approved terms.', 'Investigate; a foreign payment is never credited.', 'no'),
    'STRIPE_POLICY': ('The Checkout policy differs from what make_policy builds.', 'Build it with make_policy.', 'after the fix'),
    'STRIPE_PROFILE': ('The intent is not covenant-stripe-checkout/0.1.', 'Prepare it with the gateway.', 'after the fix'),
    'STRIPE_PROVIDER_BINDING': ("The provider object does not carry this intent's metadata.", 'Investigate; nothing is credited.', 'no'),
    'STRIPE_PROVIDER_HTTP': ('Stripe answered with a non-2xx status.', 'Reconcile with observe(effect).', 'after reconciliation'),
    'STRIPE_PROVIDER_ID': ('A provider id has the wrong prefix or characters.', 'Use the id Stripe returned.', 'after the fix'),
    'STRIPE_PROVIDER_UNAVAILABLE': ('Stripe could not be reached.', 'Reconcile with observe(effect) when reachable.', 'after reconciliation'),
    'STRIPE_RECONCILIATION_LIMIT': ('Reconciliation read more pages than allowed.', 'Reconcile with the session id.', 'after reconciliation'),
    'STRIPE_RECONCILIATION_RESPONSE': ('A list reply was malformed.', 'Reconcile again later.', 'after reconciliation'),
    'STRIPE_RECORD_ASSURANCE': ('The portable Checkout record overstates its assurance.', 'Use the record as exported.', 'no'),
    'STRIPE_RECORD_BOUND': ('The portable Checkout record is too large or malformed.', 'Use the record as exported.', 'no'),
    'STRIPE_RECORD_PIN': ('The Checkout record is for another effect.', 'Check the effect you retained.', 'no'),
    'STRIPE_RECORD_PROFILE': ('The Checkout record is of another profile.', 'Use covenant-stripe-observation-record/0.1.', 'no'),
    'STRIPE_REQUEST': ('The provider request path is not allowed.', 'Use the transport methods.', 'after the fix'),
    'STRIPE_REQUEST_SIZE': ('The provider request body is too large.', 'Shorten the request.', 'after the fix'),
    'STRIPE_RESPONSE': ('The provider reply is not a JSON object.', 'Reconcile.', 'after reconciliation'),
    'STRIPE_RESPONSE_SIZE': ('The provider reply is larger than 1 MiB.', 'Reconcile.', 'after reconciliation'),
    'STRIPE_RESTRICTED_CREDENTIAL_MODE': ("Only a restricted key of the policy's mode is accepted (rk_test_ or rkcs_test_ in sandbox, rk_live_ live).", 'Create a restricted key with only the needed permissions.', 'after the fix'),
    'STRIPE_RETURN_ORIGIN': ('The return origin must be a bare https origin.', 'Use https://your-host without a path.', 'after the fix'),
    'STRIPE_SESSION': ('The reply is not a Checkout Session.', 'Reconcile.', 'after reconciliation'),
    'STRIPE_SESSION_CHANGED': ('Stripe returned another session than the one retained.', 'Investigate.', 'no'),
    'STRIPE_SESSION_STATUS': ('The session status is not a documented one.', 'Reconcile later.', 'after reconciliation'),
    'STRIPE_SESSION_TERMS': ('The session does not match the approved terms.', 'Investigate; nothing is credited.', 'no'),
    'STRIPE_TEXT': ('Text must be printable ASCII within its bound.', 'Shorten or simplify it.', 'after the fix'),
    'STRIPE_TIMEOUT': ('The timeout must be 1 to 60 seconds.', 'Choose a bounded timeout.', 'after the fix'),
    'STRIPE_TRANSPORT_MODE': ('The transport mode differs from the policy mode.', 'Use the same mode for both.', 'after the fix'),
    'STRIPE_WEBHOOK_FOREIGN': ('The authenticated event belongs to another operation.', 'Deliver it to its own operation.', 'no'),
    'STRIPE_WEBHOOK_INPUT': ('The webhook body or header is missing or too large.', 'Pass the raw body bytes and the Stripe-Signature header unchanged.', 'no'),
    'STRIPE_WEBHOOK_OBJECT': ('The event carries no object.', 'Pass the raw body unchanged.', 'no'),
    'STRIPE_WEBHOOK_REPLAY_CHANGED': ('An event id arrived again with different bytes.', 'Investigate; the stored event stands.', 'no'),
    'STRIPE_WEBHOOK_SCOPE': ('The event type, mode or account is not adopted.', 'Subscribe only to the documented events.', 'no'),
    'STRIPE_WEBHOOK_SECRET': ('The webhook signing secret is not a whsec_ value.', "Install the endpoint's signing secret in the owner secret service.", 'after the fix'),
    'STRIPE_WEBHOOK_SECRET_REQUIRED': ('No webhook signing secret is installed.', 'Pass an owner callable that reads the secret.', 'after the fix'),
    'STRIPE_WEBHOOK_SECRET_UNAVAILABLE': ('The owner secret service did not supply the signing secret.', 'Fix the owner secret service.', 'after the fix'),
    'STRIPE_WEBHOOK_SIGNATURE': ('The Stripe-Signature does not verify over the raw body.', 'Pass the raw body unchanged; never re-serialise it.', 'no'),
    'STRIPE_WEBHOOK_STALE_OR_INVALID': ('The signature timestamp is outside the tolerance or malformed.', 'Synchronise the owner clock (NTP); Stripe resends with a fresh timestamp.', 'yes'),
    'STRIPE_WEBHOOK_TOLERANCE': ('The tolerance must be 1 to 300 seconds.', 'Never use 0; keep at most 300.', 'after the fix'),
}

# What happened, then what to do, for each code the Stripe payment modules raise that no other
# table explains: the plain-text form tools/production_readiness.py and the shared error catalogue
# read. ERRORS keeps the retry hints; Checkout codes keep stripe_gateway's words.
REMEDIATION = {
    'STRIPE_PAYMENT_FIELD':
        'A field of the payment action is missing, extra or malformed. Use exactly the documented fields and '
        'value shapes.',
    'STRIPE_PAYMENT_PARTIES':
        'Owner, agent and payer must be three different valid public keys. Name the owner (principal), its '
        'agent and the paying party separately.',
    'STRIPE_PAYMENT_TEXT':
        'The description must be 1 to 120 printable ASCII characters. Shorten or simplify the description.',
    'STRIPE_PAYMENT_CURRENCY':
        'The currency is not a three-letter lowercase ISO 4217 code. Write the currency in lowercase, for '
        'example usd.',
    'STRIPE_PAYMENT_CURRENCY_UNCONFIRMED':
        'Three-decimal currencies are refused until their Stripe rule is confirmed. Use a two-decimal or '
        'zero-decimal currency.',
    'STRIPE_PAYMENT_AMOUNT':
        'The amount must be an integer from 1 to 99999999 minor units. Write the amount in minor units: 2500 '
        'is 25.00 USD, 500 is 500 JPY.',
    'STRIPE_PAYMENT_WHOLE_UNITS':
        'ISK and UGX amounts are written with two decimals that must be 00. Use a multiple of 100.',
    'STRIPE_PAYMENT_SOURCE':
        'The payment source does not fit the operation. A pay names one owner vault reference of kind '
        'shared_payment_token or payment_method; a token has no customer and no manual capture; other '
        'operations have no source.',
    'STRIPE_PAYMENT_PROFILE':
        'The record is not a covenant-stripe-payment-action/0.1 action. Draft it with stripe_action.draft.',
    'STRIPE_PAYMENT_OPERATION':
        'The operation is not pay, capture, cancel or refund. Choose one of the four operations.',
    'STRIPE_PAYMENT_TARGET':
        'The target does not fit the operation or this payment. A pay has no target; capture and cancel name '
        'a pay action; a refund names a pay action or a Checkout effect of the same agreement and payer.',
    'STRIPE_PAYMENT_MERCHANT':
        "The merchant is not a Stripe account id (acct_...). Use the owner's adopted Stripe account id.",
    'STRIPE_PAYMENT_API_VERSION':
        'The Stripe API version is not one this gateway pins, or a Shared Payment Token needs the preview '
        'version. Use 2026-09-30.endive, or 2026-09-30.preview for a Shared Payment Token.',
    'STRIPE_PAYMENT_CAPTURE_METHOD':
        'The capture method is not automatic, automatic_async or manual. Choose one Stripe capture method '
        'for a pay.',
    'STRIPE_PAYMENT_OBSERVATION':
        'The observation and recovery policy is malformed. Give webhooks (true or false), reconcile_after (1 '
        'to 86400 seconds) and unknown BLOCK_UNTIL_RECONCILED.',
    'STRIPE_PAYMENT_FEES':
        'The gateway fee must be 0 and Stripe fees are merchant-borne and unquoted. Keep gateway_fee 0 and '
        'provider_fees MERCHANT_BORNE_UNQUOTED_STRIPE_CONTRACT.',
    'STRIPE_PAYMENT_MODE':
        'livemode must be true or false. Use the mode of the owner policy; sandbox is the default.',
    'STRIPE_PAYMENT_AGENT_SIGNER':
        'The signing key is not the agent named in the action. Sign with the agent key the action names.',
    'STRIPE_PAYMENT_RECORD':
        'A signed action is {body, signature}. Send the record exactly as sign_action returned it.',
    'STRIPE_PAYMENT_AGENT_SIGNATURE':
        "The agent's signature does not verify over these exact bytes. Obtain a fresh agent signature over "
        'the unchanged action.',
    'STRIPE_PAYMENT_PAYER_SIGNER':
        'The authorising key is not the payer named in the action. The payer signs its own exact '
        'authorisation.',
    'STRIPE_PAYMENT_PAYER_REQUIRED':
        "A pay needs the payer's exact authorisation. Send the payer's signature from "
        'stripe_action.authorize.',
    'STRIPE_PAYMENT_PAYER_BINDING':
        "The payer's authorisation names another action or signer. Ask the payer to authorise this exact "
        'action.',
    'STRIPE_PAYMENT_PAYER_SIGNATURE':
        "The payer's authorisation does not verify over this exact action. Ask the payer to authorise the "
        'unchanged action again; changed terms need a fresh authorisation.',
    'STRIPE_PAYMENT_POLICY':
        'The payment policy is malformed or its owner signature does not verify. Build it with '
        'stripe_payments.policy_body and sign it with the owner key.',
    'STRIPE_PAYMENT_POLICY_PIN':
        'The action or policy names another Checkout policy or payment policy. Draft the action against this '
        "gateway's current policy id.",
    'STRIPE_PAYMENT_POLICY_ROLLBACK':
        'An older or different-owner payment policy was offered after a newer one. Adopt only a newer policy '
        'signed by the same owner.',
    'STRIPE_PAYMENT_POLICY_INACTIVE':
        'The owner payment policy is not active at the adopted time. Ask the owner to adopt a current '
        'policy.',
    'STRIPE_PAYMENT_POLICY_TERMS':
        'Merchant, currency or mode differ from the owner Checkout policy. Use the adopted account, currency '
        'and mode.',
    'STRIPE_PAYMENT_PRINCIPAL':
        'The principal is not the owner who signed the payment policy. Name the adopted owner key as '
        'principal.',
    'STRIPE_PAYMENT_CREDENTIAL_POLICY':
        "The action names another credential policy. Use credential_policy from this gateway's describe().",
    'STRIPE_PAYMENT_OPERATION_NOT_ADOPTED':
        'The owner policy does not adopt this operation. Ask the owner to adopt it, or use another '
        'operation.',
    'STRIPE_PAYMENT_SOURCE_NOT_ADOPTED':
        'The owner policy does not adopt this kind of payment source. Use an adopted source kind.',
    'STRIPE_PAYMENT_SOURCE_UNAVAILABLE':
        "The owner vault holds no payment source under this reference. Ask the owner's intake to register "
        'the token or payment method again.',
    'STRIPE_PAYMENT_EXPIRY':
        'The action has expired or lives longer than the owner policy allows. Draft a new action that '
        'expires inside the allowed window.',
    'STRIPE_PAYMENT_GRANT':
        "The delegation chain is missing or malformed. Send the owner's covenant-delegation-grant/0.1 chain "
        'for this agent.',
    'STRIPE_PAYMENT_GRANT_REFUSED':
        "The agent's delegation grant does not cover this operation now. Ask the owner for a current grant "
        'with the stripe:<operation> capability; revoked or expired grants stay refused.',
    'STRIPE_PAYMENT_GRANT_MISMATCH':
        'The action names another leaf grant than the chain proves. Name the leaf grant id of the chain you '
        'send.',
    'STRIPE_PAYMENT_TARGET_STATE':
        'The target payment is not in a state that allows this operation. Reconcile the target first; '
        'capture needs an authorised manual payment, cancel an uncaptured one, refund a captured one.',
    'STRIPE_PAYMENT_REFUND_LIMIT':
        'The refund would exceed what remains refundable. Refund at most the captured amount less earlier '
        'and pending refunds.',
    'STRIPE_PAYMENT_CAPTURE_LIMIT':
        'The capture exceeds the authorised amount. Capture at most the amount the payment can capture.',
    'STRIPE_PAYMENT_UNRESOLVED':
        'Another operation for this agreement or payment is still in flight or UNKNOWN. Reconcile it first. '
        'A new attempt could pay twice.',
    'STRIPE_PAYMENT_UNKNOWN_BLOCKS':
        'A payment between these parties has an UNKNOWN outcome. Reconcile it before any retry, Checkout or '
        'other rail. A new idempotency key or another provider could pay twice.',
    'STRIPE_PAYMENT_PAYMENT_OPEN':
        'A payment action for this agreement may still be paid. Reconcile or cancel it before creating a '
        'Checkout.',
    'STRIPE_PAYMENT_OPERATION_REUSED':
        'This operation id already names a different action. Draft the new action with a fresh operation_id.',
    'STRIPE_PAYMENT_BUDGET_MISSING':
        'The owner policy has no budget for this operation. Ask the owner to adopt a pay or refund budget.',
    'STRIPE_PAYMENT_APPROVAL_POLICY':
        'An approval policy is not owner-signed, names another owner or is not adopted. Supply the '
        'owner-signed covenant-assent-policy/0.1 records the payment policy lists.',
    'STRIPE_PAYMENT_APPROVAL_POLICY_MISSING':
        'No adopted approval policy covers this agent, so no limit can be checked. Ask the owner to adopt an '
        'approval policy for this agent key.',
    'STRIPE_PAYMENT_APPROVAL_POLICY_INACTIVE':
        "The owner's approval policy is not active now. Ask the owner to adopt a current approval policy.",
    'STRIPE_PAYMENT_APPROVAL_FIELDS':
        'The approval record or request is malformed. Send the approval exactly as the owner tool produced '
        'it.',
    'STRIPE_PAYMENT_APPROVAL_UNKNOWN':
        'This gateway did not issue the approval request. Submit the action without an approval to obtain a '
        'fresh request.',
    'STRIPE_PAYMENT_APPROVAL_CHANGED':
        'The approval names other action bytes, another gateway policy or a changed request. Changed terms '
        'need a new request and a fresh owner approval.',
    'STRIPE_PAYMENT_APPROVAL_EXPIRED':
        'The approval request expired before use. Submit again for a new request and approve it in time.',
    'STRIPE_PAYMENT_APPROVAL_METHOD':
        "The approval uses another method than the owner's adopted one. Approve with the adopted owner key "
        'or passkey.',
    'STRIPE_PAYMENT_APPROVAL_SIGNATURE':
        'The owner approval signature does not verify. Approve again with the adopted approval key; never '
        're-pin a key to force a pass.',
    'STRIPE_PAYMENT_APPROVAL_PASSKEY':
        'The passkey assertion does not verify, lacks user verification or repeats a counter. Approve again '
        'on the registered device.',
    'STRIPE_PAYMENT_APPROVAL_REFUSED':
        'The owner refused this exact action. Do not retry it. Propose different terms if the owner wants '
        'them.',
    'STRIPE_PAYMENT_APPROVAL_REUSED':
        'This approval was already consumed by another operation. Each approval authorises one operation; '
        'submit again for a new request.',
    'STRIPE_PAYMENT_APPROVAL_BACKLOG':
        'Too many approval requests are pending. Let the owner decide or let requests expire.',
    'STRIPE_PAYMENT_TRANSPORT':
        'The gateway transport is not a StripePaymentTransport. Install StripePaymentTransport (it extends '
        'StripeHTTPTransport) in the owner gateway.',
    'STRIPE_PAYMENT_GATEWAY':
        'The payment extension needs an owner StripeGateway. Open the owner custody with '
        'covenant_agent.stripe_gateway.StripeGateway first.',
    'STRIPE_PAYMENT_OPERATION_UNKNOWN':
        'This gateway holds no operation with that id. Check the operation id.',
    'STRIPE_PAYMENT_RESPONSE':
        'Stripe replied 2xx with a body that is not the expected object. Reconcile by retrieval.',
    'STRIPE_PAYMENT_PROVIDER_BINDING':
        "The provider object does not carry this action's agreement, operation, amount, currency or mode. "
        'Reconcile; a foreign object is never credited.',
    'STRIPE_PAYMENT_REPLAY_WINDOW':
        'A same-key replay is allowed only within 23 hours of the first attempt and before the action '
        'expires. Reconcile by retrieval, or ask the owner to sign a resolution.',
    'STRIPE_PAYMENT_DUPLICATE_PROVIDER_OBJECTS':
        'Stripe holds more than one object for one operation. Stop and ask the owner: refund the duplicate '
        'through the Dashboard or a refund action.',
    'STRIPE_PAYMENT_RESOLUTION':
        "The owner's resolution record is malformed or not signed by the owner. Sign "
        'covenant-stripe-payment-resolution/0.1 with the owner key.',
    'STRIPE_PAYMENT_RESOLUTION_STATE':
        'Only an UNKNOWN operation without a known provider object can be resolved by the owner. Reconcile '
        'by retrieval instead.',
    'STRIPE_PAYMENT_EVENT_SCOPE':
        'The event type, mode or account is not one this gateway adopts. Send PaymentIntent, refund and '
        'dispute events of the adopted account and mode.',
    'STRIPE_PAYMENT_EVENT_REPLAY_CHANGED':
        'An event id arrived again with different bytes. Investigate; the stored event stands.',
    'STRIPE_PAYMENT_EVENT':
        'The event body is not a Stripe event with an object. Send the raw webhook body unchanged.',
    'STRIPE_PAYMENT_STORE_FULL':
        'The payment custody store reached its bound. Open a new custody directory after exporting the '
        'records.',
    'STRIPE_PAYMENT_EVIDENCE_KIND':
        'Only dispute records can be appended from outside this module. Use stripe_disputes for AAP dispute '
        'records.',
    'STRIPE_PAYMENT_RECORD_PROFILE':
        'The portable payment record is malformed or of another profile. Export it with portable_record and '
        'pass it unchanged.',
    'STRIPE_PAYMENT_RECORD_CHAIN':
        'The evidence chain of the portable record does not verify. Obtain an unmodified record; compare '
        'with an independently retained head.',
    'STRIPE_PAYMENT_RECORD_PIN':
        'The record is for another agreement, owner or head than you expected. Check the pins you obtained '
        'separately.',
    'STRIPE_PAYMENT_BACKUP':
        'The backup target exists or is unusable. Name a new file in an owner-private directory.',
    'STRIPE_DISPUTE_RECORD':
        'The chargeback dispute record is malformed or changed. Use the record stripe_disputes produced, '
        'unchanged.',
    'STRIPE_DISPUTE_UNKNOWN':
        'No provider dispute with that id is recorded for this agreement. Reconcile the payment so its '
        'disputes are read first.',
    'STRIPE_DISPUTE_LADDER':
        "The dispute ladder is not the one the agreement's parties adopted, or the actor is not a disputant. "
        'Pass {policy, adoptions, events} of the adopted ladder and a disputant role.',
    'STRIPE_DISPUTE_EVIDENCE':
        'The evidence for Stripe is too large or contains unsupported fields. Keep under 150000 characters '
        'in total; AAP sends only hashes, amounts and times.',
    'STRIPE_DISPUTE_CLOSED':
        'The provider dispute is closed; evidence can no longer change it. Record the outcome; no new '
        'evidence is staged.',
    'STRIPE_DISPUTE_STAGE':
        'Stripe did not accept the staged evidence. Reconcile the dispute, then stage again; AAP never '
        'submits evidence to the bank.',
    'OWNER_CONFIG_MISSING':
        'The owner directory has no stripe-owner.json. Write it with stripe_service.write_config, or name '
        'the right --directory.',
    'STRIPE_REVIEW_INPUT':
        'The review input is not a portable payment record or delivery check. Pass the exported record and, '
        'separately, the verified delivery receipt.',
}


def explain(code):
    """What happened, the fix, whether a retry helps and the reference entry for one stable code."""
    if code in ERRORS:
        what, fix, retry = ERRORS[code]
        return {'code': code, 'what': what, 'fix': fix, 'retry': retry, 'reference': REFERENCE + '#' + code}
    from .errors import REMEDIATION
    return {'code': code, 'what': 'Refused with ' + code + '.',
            'fix': REMEDIATION.get(code, 'Correct the named input and retry. Do not change owner trust to force a pass.'),
            'retry': 'after the fix', 'reference': REFERENCE + '#errors'}


def _hex(value):
    need(type(value) is str and HEX.fullmatch(value) is not None, 'STRIPE_PAYMENT_FIELD')
    return value


def _party(value):
    need(type(value) is str and HEX.fullmatch(value) is not None and valid_ed25519_key(value), 'STRIPE_PAYMENT_PARTIES')
    return value


def _text(value, maximum=120):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value),
         'STRIPE_PAYMENT_TEXT')
    return value


def amount(value, currency):
    """Integer minor units under the currency's documented Stripe rule."""
    need(type(currency) is str and CURRENCY.fullmatch(currency) is not None, 'STRIPE_PAYMENT_CURRENCY')
    need(currency not in UNCONFIRMED, 'STRIPE_PAYMENT_CURRENCY_UNCONFIRMED')
    need(type(value) is int and 1 <= value <= MAX_AMOUNT, 'STRIPE_PAYMENT_AMOUNT')
    need(currency not in WHOLE_UNITS or value % 100 == 0, 'STRIPE_PAYMENT_WHOLE_UNITS')
    return value


def money(value, currency):
    """Human text for minor units, for example 2500 usd is 25.00 USD and 500 jpy is 500 JPY."""
    amount(value, currency)
    if currency in ZERO_DECIMAL:
        return '%d %s' % (value, currency.upper())
    return '%d.%02d %s' % (value // 100, value % 100, currency.upper())


def source(kind, reference, *, customer=None, off_session=False):
    """A payment source by owner vault reference; the token or method value is never in the record."""
    value = {'kind': kind, 'reference': reference, 'customer': customer, 'off_session': off_session}
    _source(value)
    return value


def _source(value):
    need(type(value) is dict and set(value) == {'kind', 'reference', 'customer', 'off_session'} and
         value['kind'] in SOURCES and type(value['off_session']) is bool and
         (value['customer'] is None or type(value['customer']) is str and CUSTOMER.fullmatch(value['customer'])),
         'STRIPE_PAYMENT_SOURCE')
    need(type(value['reference']) is str and HEX.fullmatch(value['reference']) is not None and
         (value['kind'] == 'payment_method' or value['customer'] is None), 'STRIPE_PAYMENT_SOURCE')


def validate(body):
    """The exact action body; it authorises nothing by itself."""
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'STRIPE_PAYMENT_FIELD')
    need(body['version'] == VERSION, 'STRIPE_PAYMENT_PROFILE')
    for name in ('policy', 'agreement', 'grant', 'credential_policy', 'operation_id'):
        _hex(body[name])
    for name in ('principal', 'agent', 'payer'):
        _party(body[name])
    need(len({body['principal'], body['agent'], body['payer']}) == 3, 'STRIPE_PAYMENT_PARTIES')
    need(type(body['revision']) is int and 1 <= body['revision'] <= 2**53 - 1 and
         type(body['expires']) is int and 1 <= body['expires'] <= 2**53 - 1, 'STRIPE_PAYMENT_FIELD')
    operation, target = body['operation'], body['target']
    need(operation in OPERATIONS, 'STRIPE_PAYMENT_OPERATION')
    if operation == 'pay':
        need(target is None, 'STRIPE_PAYMENT_TARGET')
    else:
        need(type(target) is dict and set(target) == {'kind', 'id'} and target['kind'] in TARGETS and
             type(target['id']) is str and HEX.fullmatch(target['id']) is not None and
             (operation == 'refund' or target['kind'] == 'payment_action'), 'STRIPE_PAYMENT_TARGET')
    need(type(body['merchant']) is str and ACCOUNT.fullmatch(body['merchant']) is not None, 'STRIPE_PAYMENT_MERCHANT')
    amount(body['amount'], body['currency'])
    _text(body['description'])
    need(body['api_version'] in API_VERSIONS, 'STRIPE_PAYMENT_API_VERSION')
    if operation == 'pay':
        _source(body['source'])
        need(body['capture_method'] in CAPTURE_METHODS, 'STRIPE_PAYMENT_CAPTURE_METHOD')
        if body['source']['kind'] == 'shared_payment_token':
            need(body['api_version'] == PREVIEW_VERSION, 'STRIPE_PAYMENT_API_VERSION')
            need(body['source']['customer'] is None and body['capture_method'] != 'manual', 'STRIPE_PAYMENT_SOURCE')
    else:
        need(body['source'] is None and body['capture_method'] is None, 'STRIPE_PAYMENT_SOURCE')
    observation = body['observation']
    need(type(observation) is dict and set(observation) == {'webhooks', 'reconcile_after', 'unknown'} and
         type(observation['webhooks']) is bool and observation['unknown'] == UNKNOWN_RULE and
         type(observation['reconcile_after']) is int and 1 <= observation['reconcile_after'] <= 86400,
         'STRIPE_PAYMENT_OBSERVATION')
    need(body['gateway_fee'] == 0 and type(body['gateway_fee']) is int and body['provider_fees'] == PROVIDER_FEES,
         'STRIPE_PAYMENT_FEES')
    need(type(body['livemode']) is bool, 'STRIPE_PAYMENT_MODE')
    canonical(body)  # Every field is bounded above, so the canonical action stays near 1.5 KB.
    return body


def draft(*, policy, agreement, revision, principal, agent, grant, credential_policy, operation, payer, merchant,
          amount, currency, description, expires, api_version=API_VERSION, target=None, source=None,
          capture_method=None, webhooks=True, reconcile_after=900, operation_id=None, livemode=False):
    """An exact unsigned action. Choose a fresh operation_id for every new attempt; reuse it only to resend."""
    body = dict(version=VERSION, policy=policy, agreement=agreement, revision=revision, principal=principal,
                agent=agent, grant=grant, credential_policy=credential_policy, operation=operation,
                target=deepcopy(target), payer=payer, merchant=merchant, amount=amount, currency=currency,
                description=description, expires=expires, api_version=api_version, source=deepcopy(source),
                capture_method=capture_method,
                observation={'webhooks': webhooks, 'reconcile_after': reconcile_after, 'unknown': UNKNOWN_RULE},
                operation_id=secrets.token_hex(32) if operation_id is None else operation_id,
                gateway_fee=0, provider_fees=PROVIDER_FEES, livemode=livemode)
    return validate(body)


def action_id(body):
    return digest(ACTION_LABEL, validate(body))


def sign_action(body, agent_private):
    """The agent's signature over the exact action. Run by the agent host; it carries no authority."""
    validate(body)
    need(public_key(agent_private) == body['agent'], 'STRIPE_PAYMENT_AGENT_SIGNER')
    return {'body': deepcopy(body), 'signature': sign(agent_private, ACTION_LABEL, body)}


def verify_action(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'STRIPE_PAYMENT_RECORD')
    body = validate(record['body'])
    try:
        verify(body['agent'], ACTION_LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('STRIPE_PAYMENT_AGENT_SIGNATURE') from None
    return deepcopy(body)


def authorize(body, payer_private):
    """The payer's exact authorisation of one action, as Checkout's approve() is for one intent."""
    reference = action_id(body)
    need(public_key(payer_private) == body['payer'], 'STRIPE_PAYMENT_PAYER_SIGNER')
    return {'version': VERSION, 'action': reference, 'signer': body['payer'],
            'signature': sign(payer_private, PAYER_LABEL, body)}


def check_authorization(body, authorization):
    reference = action_id(body)
    need(authorization is not None, 'STRIPE_PAYMENT_PAYER_REQUIRED')
    need(type(authorization) is dict and set(authorization) == {'version', 'action', 'signer', 'signature'} and
         authorization['version'] == VERSION and authorization['action'] == reference and
         authorization['signer'] == body['payer'], 'STRIPE_PAYMENT_PAYER_BINDING')
    try:
        verify(body['payer'], PAYER_LABEL, body, authorization['signature'])
    except ValueError:
        raise ValueError('STRIPE_PAYMENT_PAYER_SIGNATURE') from None
    return reference


def idempotency_key(body):
    """Stripe Idempotency-Key for this operation: stable across resends, never equal to a Checkout effect id."""
    return digest(IDEMPOTENCY_LABEL, {'operation': validate(body)['operation_id']})


def metadata(body):
    """The only metadata sent to Stripe: the agreement digest and the operation id, no personal data."""
    return {'aap_agreement': body['agreement'], 'aap_operation': body['operation_id']}


def render(body):
    """Deterministic ASCII text an owner reads before approving, and its SHA-256."""
    validate(body)
    value = money(body['amount'], body['currency'])
    operation, target = body['operation'], body['target']
    if operation == 'pay':
        kind = 'Shared Payment Token' if body['source']['kind'] == 'shared_payment_token' else 'saved payment method'
        what = ['  Charge %s to the payer through Stripe account %s.' % (value, body['merchant']),
                "  Source: the payer's %s held by the owner under vault reference %s. The credential is not shown."
                % (kind, body['source']['reference']),
                '  Capture: %s%s.' % (body['capture_method'], '; the payer is not present (off session)'
                                      if body['source']['off_session'] else '')]
    elif operation == 'capture':
        what = ['  Capture %s of the authorised payment action %s.' % (value, target['id'])]
    elif operation == 'cancel':
        what = ['  Cancel the uncaptured payment action %s, releasing %s.' % (target['id'], value)]
    else:
        what = ['  Refund %s to the payer from %s %s.' % (
            value, 'payment action' if target['kind'] == 'payment_action' else 'Checkout effect', target['id'])]
    lines = ['AAP PAYMENT ACTION TO APPROVE', 'Profile: ' + VERSION, 'Action id: ' + action_id(body), '',
             'WHAT HAPPENS', *what, '  Description: ' + json.dumps(body['description']), '',
             'PARTIES',
             '  Owner (principal): ' + body['principal'],
             '  Agent acting for the owner: ' + body['agent'],
             '  Payer: ' + body['payer'], '',
             'AGREEMENT',
             '  Exact agreement SHA-256: %s, revision %d' % (body['agreement'], body['revision']), '',
             'LIMITS',
             '  Expires: %d = %s (owner-adopted clock)' % (body['expires'], utc(body['expires'])),
             '  Gateway fee: 0. Stripe processing fees are borne by the merchant and not quoted here.',
             '  Delegation grant: ' + body['grant'],
             '  Credential policy: ' + body['credential_policy'], '',
             'PROVIDER',
             '  Stripe API version %s, %s mode.' % (body['api_version'], 'LIVE' if body['livemode'] else 'sandbox'),
             '  Webhooks expected: %s. Reconcile by retrieval after %d seconds.' % (
                 'yes' if body['observation']['webhooks'] else 'no', body['observation']['reconcile_after']),
             '  An UNKNOWN outcome blocks any retry and any switch to Checkout or another rail until it is reconciled.',
             '  Operation id: ' + body['operation_id'], '',
             'EXACT SIGNED ACTION BYTES (canonical JSON)', canonical(body).decode('ascii'), '',
             'WHAT THIS APPROVAL DOES NOT ESTABLISH',
             '  It approves this one action once. It is not delivery, not cardholder authentication and not',
             '  proof that Stripe will accept the charge.', 'END', '']
    text = '\n'.join(lines)
    raw = text.encode('ascii')
    return {'text': text, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def schema():
    """JSON Schema (2020-12) of a signed action record, bounded for HTTP and tool use."""
    hex64 = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
    text = {'type': 'string', 'minLength': 1, 'maxLength': 120}
    target = {'oneOf': [{'type': 'null'}, {'type': 'object', 'additionalProperties': False,
                                           'required': ['kind', 'id'], 'properties': {
                                               'kind': {'enum': list(TARGETS)}, 'id': hex64}}]}
    origin = {'oneOf': [{'type': 'null'}, {'type': 'object', 'additionalProperties': False,
                                           'required': ['kind', 'reference', 'customer', 'off_session'],
                                           'properties': {'kind': {'enum': list(SOURCES)}, 'reference': hex64,
                                                          'customer': {'type': ['string', 'null'],
                                                                       'pattern': '^cus_[A-Za-z0-9]{1,80}$'},
                                                          'off_session': {'type': 'boolean'}}}]}
    properties = {name: hex64 for name in ('policy', 'agreement', 'principal', 'agent', 'grant',
                                            'credential_policy', 'payer', 'operation_id')}
    properties.update(
        version={'const': VERSION}, revision={'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
        operation={'enum': list(OPERATIONS)}, target=target,
        merchant={'type': 'string', 'pattern': '^acct_[A-Za-z0-9]{1,80}$'},
        amount={'type': 'integer', 'minimum': 1, 'maximum': MAX_AMOUNT},
        currency={'type': 'string', 'pattern': '^[a-z]{3}$'}, description=text,
        expires={'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
        api_version={'enum': list(API_VERSIONS)}, source=origin,
        capture_method={'enum': [*CAPTURE_METHODS, None]},
        observation={'type': 'object', 'additionalProperties': False,
                     'required': ['webhooks', 'reconcile_after', 'unknown'],
                     'properties': {'webhooks': {'type': 'boolean'},
                                    'reconcile_after': {'type': 'integer', 'minimum': 1, 'maximum': 86400},
                                    'unknown': {'const': UNKNOWN_RULE}}},
        gateway_fee={'const': 0}, provider_fees={'const': PROVIDER_FEES}, livemode={'type': 'boolean'})
    body = {'type': 'object', 'additionalProperties': False, 'maxProperties': len(properties),
            'required': sorted(properties), 'properties': properties}
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'title': 'AAP Stripe payment action',
            'type': 'object', 'additionalProperties': False, 'required': ['body', 'signature'],
            'properties': {'body': body, 'signature': {'type': 'string', 'pattern': '^[0-9a-f]{128}$'}}}


def describe():
    return {'profile': VERSION, 'operations': list(OPERATIONS), 'sources': list(SOURCES),
            'api_versions': list(API_VERSIONS), 'checkout_profile_unchanged': 'covenant-stripe-checkout/0.1',
            'credentials_in_record': False, 'metadata_sent': ['aap_agreement', 'aap_operation'],
            'unknown_outcome': UNKNOWN_RULE, 'guide': REFERENCE, 'execution_authorized': False}
