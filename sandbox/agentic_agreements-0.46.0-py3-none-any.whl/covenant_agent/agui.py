"""AG-UI 1.0 events for the assent lifecycle, framed as HTTP Server-Sent Events.

GRAFT, unchanged: AG-UI protocol 1.0 (ag-ui-protocol/ag-ui spec/1.0/schema.json,
"HTTP + Server-Sent Events" binding, "Interrupts and Resume"). One POST of a
RunAgentInput runs one host call and answers with a text/event-stream of
standard events only: RUN_STARTED, TOOL_CALL_START/ARGS/END/RESULT, CUSTOM,
STATE_SNAPSHOT, RUN_FINISHED and RUN_ERROR. Each SSE event carries exactly one
JSON event on one ``data:`` line with LF framing.

Lifecycle facts travel as CUSTOM events named ``aap.agreement.proposed``,
``aap.agreement.accepted``, ``aap.approval.requested``, ``aap.approval.given``,
``aap.approval.refused`` and ``aap.dispute.opened``; each value carries the
agreement and rendering SHA-256. A required owner approval ends the run with the
normative interrupt outcome; the next run resumes it with the signed approval
record as the payload. Frontend data, payloads and messages are data: only the
host's own gate decides whether its key signs.
"""
from copy import deepcopy
import hashlib
import json
import re

from .barrier import present_to_model
from .errors import NativeError, need

PROTOCOL = '1.0'
INTERRUPT_REASON = 'aap.owner_approval'
EVENT_NAMES = {
    'AGREEMENT_PROPOSED': 'aap.agreement.proposed',
    'AGREEMENT_ACCEPTED': 'aap.agreement.accepted',
    'APPROVAL_REQUESTED': 'aap.approval.requested',
    'APPROVAL_GIVEN': 'aap.approval.given',
    'APPROVAL_REFUSED': 'aap.approval.refused',
    'DISPUTE_OPENED': 'aap.dispute.opened',
}
TOOLS = ('covenant_propose', 'covenant_make', 'covenant_accept', 'covenant_assent_review', 'covenant_discover',
         'covenant_verify', 'covenant_action')
INPUT_FIELDS = frozenset({'threadId', 'runId', 'protocolVersion', 'parentRunId', 'state', 'messages', 'tools',
                          'context', 'forwardedProps', 'resume'})
EMITTED = frozenset({'RUN_STARTED', 'RUN_FINISHED', 'RUN_ERROR', 'TOOL_CALL_START', 'TOOL_CALL_ARGS',
                     'TOOL_CALL_END', 'TOOL_CALL_RESULT', 'CUSTOM', 'STATE_SNAPSHOT'})
MAX_INPUT_BYTES = 1048576
MAX_EVENT_BYTES = 1048576
IDENT = re.compile(r'[\x21-\x7e]{1,128}\Z')
RESPONSE_SCHEMA = {
    'type': 'object', 'additionalProperties': False,
    'required': ['version', 'decision', 'request', 'method', 'proof'],
    'description': 'The covenant-assent-approval/0.1 record the owner method produced for this exact request.',
    'properties': {'version': {'const': 'covenant-assent-approval/0.1'},
                   'decision': {'enum': ['APPROVE', 'REFUSE']}, 'request': {'type': 'object'},
                   'method': {'enum': ['OWNER_KEY', 'PASSKEY']}, 'proof': {'type': 'object'}},
}


def _text(value, code='AGUI_INPUT'):
    need(type(value) is str and bool(IDENT.fullmatch(value)), code)
    return value


def validate_input(value):
    """A closed AG-UI 1.0 RunAgentInput, bounded. Returns (thread, run, action)."""
    need(type(value) is dict and set(value) <= INPUT_FIELDS and {'threadId', 'runId', 'messages'} <= set(value),
         'AGUI_INPUT')
    thread, run = _text(value['threadId']), _text(value['runId'])
    need(type(value['messages']) is list and len(value['messages']) <= 256 and
         all(type(item) is dict for item in value['messages']), 'AGUI_INPUT')
    if 'protocolVersion' in value:
        need(type(value['protocolVersion']) is str and value['protocolVersion'].split('.')[0] == '1', 'AGUI_PROTOCOL')
    if 'parentRunId' in value:
        _text(value['parentRunId'])
    for name in ('tools', 'context'):
        need(type(value.get(name, [])) is list and len(value.get(name, [])) <= 128, 'AGUI_INPUT')
    props = value.get('forwardedProps', {})
    need(type(props) is dict, 'AGUI_INPUT')
    call = props.get('aap')
    resume = value.get('resume')
    need(call is None or resume is None, 'AGUI_INPUT')
    if call is not None:
        need(type(call) is dict and set(call) == {'tool', 'arguments'} and call['tool'] in TOOLS and
             type(call['arguments']) is dict, 'AGUI_TOOL')
        return thread, run, ('call', call['tool'], deepcopy(call['arguments']))
    if resume is not None:
        need(type(resume) is list and 1 <= len(resume) <= 8, 'AGUI_RESUME')
        need(len({entry.get('interruptId') for entry in resume if type(entry) is dict}) == len(resume), 'AGUI_RESUME')
        entries = []
        for entry in resume:
            need(type(entry) is dict and {'interruptId', 'status'} <= set(entry) <=
                 {'interruptId', 'status', 'payload', 'metadata'} and entry['status'] in ('resolved', 'cancelled'),
                 'AGUI_RESUME')
            _text(entry['interruptId'], 'AGUI_RESUME')
            need(entry['status'] == 'cancelled' or type(entry.get('payload')) is dict, 'AGUI_RESUME')
            entries.append(deepcopy(entry))
        return thread, run, ('resume', entries)
    return thread, run, ('status',)


def encode(event):
    """One SSE event: ``data: <one JSON event>`` and a blank line, LF only."""
    need(type(event) is dict and event.get('type') in EMITTED, 'AGUI_EVENT')
    raw = json.dumps(event, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')
    need(len(raw) <= MAX_EVENT_BYTES and b'\n' not in raw and b'\r' not in raw, 'AGUI_EVENT')
    return b'data: ' + raw + b'\n\n'


def decode(stream):
    """Parse an AG-UI SSE body back into events; other SSE fields and comments are ignored."""
    need(type(stream) is bytes and len(stream) <= 64 * MAX_EVENT_BYTES, 'AGUI_EVENT')
    events = []
    for block in stream.split(b'\n\n'):
        data = [line[5:].lstrip(b' ') for line in block.split(b'\n') if line.startswith(b'data:')]
        if data:
            events.append(json.loads(b'\n'.join(data).decode('utf-8')))
    return events


def _custom(event):
    names = {'agreement': 'agreement_sha256', 'rendering': 'rendering_sha256'}
    value = {names.get(key, key): deepcopy(item) for key, item in event.items() if key != 'kind'}
    return {'type': 'CUSTOM', 'name': EVENT_NAMES[event['kind']], 'value': value}


def _snapshot(host):
    gate = host.assent
    if gate is None:
        return {'type': 'STATE_SNAPSHOT', 'snapshot': {'aap': {'owner_policy': None, 'open_approvals': []}}}
    status = gate.journal.status(gate.now())
    rows = [{'occurrence': row['occurrence'], 'status': row['status'],
             'agreement_sha256': row['request']['agreement'], 'rendering_sha256': row['request']['rendering'],
             'amount': row['request']['amount'], 'payee': row['request']['payee'], 'role': row['request']['role'],
             'expires_at': row['request']['expires_at']} for row in status['open']]
    return {'type': 'STATE_SNAPSHOT', 'snapshot': {'aap': {'owner_policy': gate.describe(), 'open_approvals': rows}}}


def _interrupt(host, details, tool_call):
    from .assent_view import utc
    text = host.rendering_text(details['assent']['rendering_sha256']) or ''
    if details['method'] == 'PASSKEY':
        how = 'Open ' + details['approval_url'] + ' on the device holding the registered passkey.'
    else:
        how = 'Run the owner command on the device holding the owner approval key: ' + details['owner_command']
    metadata = {'aap': {'request': deepcopy(details['request']), 'method': details['method'],
                        'agreement_sha256': details['assent']['agreement_sha256'],
                        'rendering_sha256': details['assent']['rendering_sha256'],
                        'approval_url': details.get('approval_url')}}
    return {'id': details['occurrence'], 'reason': INTERRUPT_REASON, 'toolCallId': tool_call,
            'message': 'Owner approval required. Nothing has been signed. ' + how +
                       ' Resume with the signed approval record, or cancel to refuse.\n\n' + text,
            'responseSchema': deepcopy(RESPONSE_SCHEMA), 'expiresAt': utc(details['expires_at']), 'metadata': metadata}


def _call(host, run, tool, arguments, index):
    """One host call as standard tool-call events, lifecycle CUSTOM events and its result."""
    from .assent_gate import ApprovalRequired
    from .mcp import tool_error
    tool_call = 'aap-' + hashlib.sha256((run + '\0' + str(index)).encode('ascii')).hexdigest()[:24]
    out = [{'type': 'TOOL_CALL_START', 'toolCallId': tool_call, 'toolCallName': tool},
           {'type': 'TOOL_CALL_ARGS', 'toolCallId': tool_call,
            'delta': json.dumps(arguments, sort_keys=True, separators=(',', ':'), ensure_ascii=True)},
           {'type': 'TOOL_CALL_END', 'toolCallId': tool_call}]
    mark = host._event_sequence
    interrupt = None
    try:
        value = present_to_model(host.call(tool, arguments))
    except ApprovalRequired as exc:
        value = present_to_model(tool_error(exc))
        interrupt = _interrupt(host, exc.details, tool_call)
    except (NativeError, ValueError, TypeError, KeyError, OSError) as exc:
        value = tool_error(exc)
    out += [_custom(event) for event in host.events if event['sequence'] > mark]
    out.append({'type': 'TOOL_CALL_RESULT', 'messageId': tool_call + '-result', 'toolCallId': tool_call,
                'role': 'tool', 'content': json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)})
    return out, interrupt


def run_events(host, run_input):
    """The complete event list for one run. Input errors raise before RUN_STARTED (the HTTP layer answers 4xx)."""
    thread, run, action = validate_input(run_input)
    events = [{'type': 'RUN_STARTED', 'threadId': thread, 'runId': run, 'protocolVersion': PROTOCOL}]
    interrupts = []
    try:
        if action[0] == 'call':
            out, interrupt = _call(host, run, action[1], action[2], 0)
            events += out
            if interrupt is not None:
                interrupts.append(interrupt)
        elif action[0] == 'resume':
            for index, entry in enumerate(action[1]):
                gate = host.assent
                row = gate.journal.get(entry['interruptId']) if gate is not None and \
                    re.fullmatch(r'[0-9a-f]{64}', entry['interruptId']) else None
                if row is None or row['policy'] != gate.policy_hash:
                    # 1.0 producer rule: proceed without an unrecognised entry and surface a warning.
                    events.append({'type': 'CUSTOM', 'name': 'aap.warning',
                                   'value': {'code': 'ASSENT_APPROVAL_UNKNOWN', 'interruptId': entry['interruptId']}})
                    continue
                if entry['status'] == 'cancelled':
                    mark = host._event_sequence
                    gate.decline(row['occurrence'], 'AGUI_INTERRUPT_CANCELLED')
                    events += [_custom(event) for event in host.events if event['sequence'] > mark]
                    continue
                arguments = dict(row['arguments'], approval=entry['payload'])
                out, interrupt = _call(host, run, row['tool'], arguments, index)
                events += out
                still = gate.journal.get(row['occurrence'])
                if interrupt is not None or (still is not None and still['status'] == 'PENDING' and
                                             still['expires_at'] >= gate.now()):
                    # The entry did not answer it: keep the interrupt open rather than finish as success.
                    from .assent_view import public, render
                    rendered = render(row['subject'])
                    host._remember_rendering(rendered)
                    details = gate.pending_details({'rendered': rendered, 'role': row['role'],
                                                    'required': True, 'threshold': gate.threshold(row['request']['amount'])},
                                                   still or row, row['tool'])
                    interrupts.append(interrupt or _interrupt(host, details, out[0]['toolCallId']))
        events.append(_snapshot(host))
    except (NativeError, ValueError, TypeError, KeyError, OSError) as exc:
        code = getattr(exc, 'code', None) or str(exc)
        events.append({'type': 'RUN_ERROR', 'message': 'The run failed after it started; nothing further was signed.',
                       'code': code if re.fullmatch(r'[A-Z][A-Z0-9_]{0,100}', code) else 'AGUI_RUN_FAILED'})
        return events
    finished = {'type': 'RUN_FINISHED', 'threadId': thread, 'runId': run}
    finished['outcome'] = {'type': 'interrupt', 'interrupts': interrupts} if interrupts else {'type': 'success'}
    events.append(finished)
    return events
