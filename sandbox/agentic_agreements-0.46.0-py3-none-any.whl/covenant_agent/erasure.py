"""Erasure-ready local storage for off-chain agreement material.

Each stored document gets its own random AES-256-GCM key. Ciphertext lives
under ``data/`` and keys, salts, annex keys and the index live under ``keys/``.
Deleting a key shreds its document: a ciphertext copy left in a backup or a
sync folder can no longer be opened, provided the key file itself was not
copied. ``forget`` removes everything this store holds for one agreement.

What this cannot do, stated plainly:

- On-chain hashes are permanent. Forgetting deletes the local salt and the
  document, so the hash can no longer be opened or linked from this machine.
  It does not remove the hash from the chain or from any archive.
- Copies already delivered to counterparties, resolvers, relays, mirrors or
  archives are outside this store and are not erased.
- File deletion unlinks. Key files are overwritten with zeros first, but SSD
  wear levelling, file-system snapshots and backups of the ``keys/`` directory
  can keep old bytes. Keep ``keys/`` out of backups if erasure matters.
"""
import hashlib
import json
import os
import re
import secrets
import stat
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .cid import parse_cid
from .errors import NativeError, need

VERSION = 'covenant-erasable-store/0.1'
FORGET_VERSION = 'covenant-forget/0.1'
AAD_LABEL = 'COVENANT-ERASABLE-DOCUMENT-0.1'
MAX_DOCUMENT = 4_000_000
MAX_ITEMS = 4096
HEX64 = re.compile(r'[0-9a-f]{64}\Z')
NAME = re.compile(r'[a-z0-9][a-z0-9_.-]{0,63}\Z')
KINDS = frozenset({'document', 'envelope', 'delivery', 'annex', 'evidence'})
ON_CHAIN = ('On-chain hashes are permanent. This removed local salts, keys and cached documents only, so '
            'this machine can no longer open or link those hashes. Nothing on the chain or in an archive changed.')
REMOTE = ('Copies already sent to counterparties, resolvers, relays, mirrors or archives are not erased by '
          'this call.')


def _private_dir(path, code):
    path = Path(path)
    if not path.exists():
        path.mkdir(mode=0o700, parents=True)
    need(path.is_dir() and not path.is_symlink(), code)
    need(stat.S_IMODE(path.stat().st_mode) & 0o077 == 0, code)
    return path


def _write_private(path, data):
    temp = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
    fd = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(temp, path)


def _read_private(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'ERASABLE_STORE_FILE')
        need(info.st_size <= MAX_DOCUMENT + 64, 'ERASABLE_STORE_FILE')
        chunks = []
        while True:
            chunk = os.read(fd, 1 << 20)
            if not chunk:
                break
            chunks.append(chunk)
        return b''.join(chunks)
    finally:
        os.close(fd)


def _wipe(path):
    """Overwrite a key file with zeros, then unlink it. Best effort, see module note."""
    try:
        size = path.lstat().st_size
    except FileNotFoundError:
        return False
    if path.is_file() and not path.is_symlink():
        # readiness: in-place Best-effort key erasure intentionally overwrites the existing inode before unlinking; no new record is published.
        fd = os.open(path, os.O_WRONLY | os.O_NOFOLLOW)
        try:
            os.write(fd, bytes(size))
            os.fsync(fd)
        finally:
            os.close(fd)
    path.unlink()
    return True


def agreement_key(value):
    need(type(value) is str and HEX64.fullmatch(value) is not None, 'AGREEMENT_ID')
    return value


class ErasableStore:
    """Local off-chain store with one key per document. Not a sync service."""

    def __init__(self, directory):
        self.root = _private_dir(directory, 'ERASABLE_STORE_DIRECTORY')
        self.keys = _private_dir(self.root / 'keys', 'ERASABLE_STORE_DIRECTORY')
        self.data = _private_dir(self.root / 'data', 'ERASABLE_STORE_DIRECTORY')

    def _index_path(self, agreement):
        return self.keys / agreement_key(agreement) / 'index.json'

    def _index(self, agreement):
        path = self._index_path(agreement)
        if not path.exists():
            return {'version': VERSION, 'agreement': agreement, 'documents': {}, 'salts': {}, 'annex_keys': {}}
        index = json.loads(_read_private(path))
        need(type(index) is dict and index.get('version') == VERSION and index.get('agreement') == agreement,
             'ERASABLE_STORE_INDEX')
        return index

    def _save(self, agreement, index):
        _private_dir(self.keys / agreement, 'ERASABLE_STORE_DIRECTORY')
        _write_private(self._index_path(agreement), json.dumps(index, sort_keys=True).encode('ascii'))

    def _aad(self, agreement, document):
        return json.dumps({'label': AAD_LABEL, 'agreement': agreement, 'document': document},
                          sort_keys=True, separators=(',', ':')).encode('ascii')

    def put_document(self, agreement, raw, *, kind='document'):
        """Encrypt under a fresh key. The same bytes for one agreement are stored once."""
        index = self._index(agreement)
        need(isinstance(raw, (bytes, bytearray)) and 0 < len(raw) <= MAX_DOCUMENT, 'CONTENT_SIZE')
        need(kind in KINDS, 'ERASABLE_KIND')
        raw = bytes(raw)
        sha = hashlib.sha256(raw).hexdigest()
        for document, row in index['documents'].items():
            if row['sha256'] == sha:
                return {'agreement': agreement, 'document': document, 'sha256': sha, 'stored': False}
        need(len(index['documents']) < MAX_ITEMS, 'ERASABLE_STORE_LIMIT')
        document = secrets.token_hex(16)
        key = AESGCM.generate_key(bit_length=256)
        nonce = secrets.token_bytes(12)
        sealed = nonce + AESGCM(key).encrypt(nonce, raw, self._aad(agreement, document))
        _private_dir(self.data / agreement, 'ERASABLE_STORE_DIRECTORY')
        _private_dir(self.keys / agreement, 'ERASABLE_STORE_DIRECTORY')
        _write_private(self.keys / agreement / (document + '.key'), key.hex().encode('ascii'))
        _write_private(self.data / agreement / (document + '.bin'), sealed)
        index['documents'][document] = {'kind': kind, 'sha256': sha, 'bytes': len(raw)}
        self._save(agreement, index)
        return {'agreement': agreement, 'document': document, 'sha256': sha, 'stored': True}

    def get_document(self, agreement, document):
        index = self._index(agreement)
        need(type(document) is str and document in index['documents'], 'DOCUMENT_NOT_FOUND')
        key_path = self.keys / agreement / (document + '.key')
        need(key_path.exists(), 'DOCUMENT_SHREDDED')
        key = bytes.fromhex(_read_private(key_path).decode('ascii'))
        sealed = _read_private(self.data / agreement / (document + '.bin'))
        need(len(sealed) > 28, 'DOCUMENT_CIPHERTEXT')
        try:
            raw = AESGCM(key).decrypt(sealed[:12], sealed[12:], self._aad(agreement, document))
        except InvalidTag as exc:
            raise NativeError('DOCUMENT_CIPHERTEXT') from exc
        need(hashlib.sha256(raw).hexdigest() == index['documents'][document]['sha256'], 'DOCUMENT_CIPHERTEXT')
        return raw

    def shred(self, agreement, document):
        """Destroy one document key first, then its ciphertext and index row."""
        index = self._index(agreement)
        need(type(document) is str and document in index['documents'], 'DOCUMENT_NOT_FOUND')
        key_removed = _wipe(self.keys / agreement / (document + '.key'))
        data = self.data / agreement / (document + '.bin')
        data_removed = data.exists()
        if data_removed:
            data.unlink()
        del index['documents'][document]
        self._save(agreement, index)
        return {'agreement': agreement, 'document': document, 'key_destroyed': key_removed,
                'ciphertext_removed': data_removed}

    def _secret(self, agreement, field, name, value):
        index = self._index(agreement)
        need(type(name) is str and NAME.fullmatch(name) is not None, 'ERASABLE_NAME')
        need(type(value) is str and HEX64.fullmatch(value) is not None, 'ERASABLE_SECRET')
        need(name in index[field] or len(index[field]) < MAX_ITEMS, 'ERASABLE_STORE_LIMIT')
        index[field][name] = value
        self._save(agreement, index)
        return {'agreement': agreement, 'name': name, 'stored': True}

    def put_salt(self, agreement, name, salt):
        """Keep a 64-hex commitment salt. Deleting it makes the public hash unopenable here."""
        return self._secret(agreement, 'salts', name, salt)

    def put_annex_key(self, agreement, name, key):
        return self._secret(agreement, 'annex_keys', name, key)

    def salt(self, agreement, name):
        value = self._index(agreement)['salts'].get(name)
        need(value is not None, 'SALT_NOT_FOUND')
        return value

    def annex_key(self, agreement, name):
        value = self._index(agreement)['annex_keys'].get(name)
        need(value is not None, 'ANNEX_KEY_NOT_FOUND')
        return value

    def agreements(self):
        return sorted(p.name for p in self.keys.iterdir() if p.is_dir() and HEX64.fullmatch(p.name))

    def find(self, cid):
        """Agreement whose stored document has these exact bytes, or None."""
        sha = parse_cid(cid).hex()
        for agreement in self.agreements():
            if any(row['sha256'] == sha for row in self._index(agreement)['documents'].values()):
                return agreement
        return None

    def known_payloads(self):
        """SHA-256 of every stored off-chain document. archive.pack refuses these."""
        found = set()
        for agreement in self.agreements():
            found.update(row['sha256'] for row in self._index(agreement)['documents'].values())
        return sorted(found)

    def forget(self, agreement):
        agreement_key(agreement)
        removed = {'documents': 0, 'document_keys': 0, 'salts': 0, 'annex_keys': 0}
        key_dir = self.keys / agreement
        data_dir = self.data / agreement
        if key_dir.is_dir() and not key_dir.is_symlink():
            index = self._index(agreement)
            removed['salts'] = len(index['salts'])
            removed['annex_keys'] = len(index['annex_keys'])
            for entry in sorted(key_dir.iterdir()):
                if entry.name.endswith('.key') and _wipe(entry):
                    removed['document_keys'] += 1
            _wipe(key_dir / 'index.json')
            for entry in list(key_dir.iterdir()):
                _wipe(entry)
            key_dir.rmdir()
        if data_dir.is_dir() and not data_dir.is_symlink():
            for entry in list(data_dir.iterdir()):
                entry.unlink()
                removed['documents'] += 1
            data_dir.rmdir()
        return removed


def forget_receipt(reference, agreement, removed, cids=()):
    """The one result shape for SDK, MCP and CLI."""
    removed = dict(removed)
    total = sum(removed.values())
    return {
        'version': FORGET_VERSION,
        'reference': reference,
        'agreement': agreement,
        'found': total > 0,
        'removed': dict(sorted(removed.items())),
        'removed_cids': sorted(cids),
        'on_chain': ON_CHAIN,
        'remote_copies': REMOTE,
        'chain_ledger_touched': False,
        'ledger_touched': False,
        'execution_authorized': False,
    }


def covenant_forget(cid, *, store=None, content=None):
    """Delete local salts, annex keys and cached off-chain documents for one agreement.

    ``cid`` is the CID (or ``sha256:<hex>``) of any stored version of the
    envelope, or the 64-hex local agreement key. ``store`` is an
    ``ErasableStore``; ``content`` is an in-process ``ContentStore``. Only what
    those two hold is removed. On-chain hashes are permanent.
    """
    need(type(cid) is str and 0 < len(cid) <= 128, 'CID')
    agreement = None
    if HEX64.fullmatch(cid):
        agreement = cid
    else:
        parse_cid(cid)
        if content is not None:
            agreement = content.agreement_of(cid)
        if agreement is None and store is not None:
            agreement = store.find(cid)
    removed = {'documents': 0, 'document_keys': 0, 'salts': 0, 'annex_keys': 0, 'cached_blobs': 0}
    cids = []
    if agreement is not None:
        if content is not None:
            cids = content.forget_agreement(agreement)
            removed['cached_blobs'] = len(cids)
        if store is not None:
            for name, count in store.forget(agreement).items():
                removed[name] += count
    return forget_receipt(cid, agreement, removed, cids)
