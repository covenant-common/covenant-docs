"""Explicit bilateral /0.2: unique orders, dated effects and appealable splits.

Historical /0.1 remains unchanged. Time is an owner-adopted input, not a proof
of world time: each signed ``at`` is its signer's claim from its own host
clock. A shared settlement authority (``settlement_ledger_v2``) is the time
authority for money movement. By default it refuses a settlement claimed ahead
of its own clock and judges appeal windows and silence by that clock, so a
party's fast host clock cannot pre-empt an appeal or a timely delivery. An
authority whose owner installed a covenant-time-evidence/0.1 policy judges a
silent refund or an unappealed decision by the ``time_evidence`` bundle passed
to ``settle`` instead; the signed ``at`` should then be the bundle's
not_before. The in-memory sandbox ledger has no clock of its own and only
checks the signed claims. Settlement evidence is distinguished from an actual
observation through the owner's installed ledger. No remote text installs a
provider.
"""
from copy import deepcopy
import secrets
import time

from .codec import canonical, digest, exact, public_key, sha256_hex, sign, signature_ok
from .errors import NativeError, need
from .cid import cid_from_bytes, parse_cid
from . import envelope as legacy
from .settlement_ledger_v2 import settle_split

PROFILE = 'covenant-bilateral/0.2'
TERMS = 'covenant-work-order/0.2'
LABEL = 'COVENANT-BILATERAL-0.2'


def _int(value, minimum=0):
    need(type(value) is int and minimum <= value <= 2**53-1, 'INTEGER_RANGE')
    return value


def _now(as_of):
    return _int(int(time.time()) if as_of is None else as_of)


def _hash(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def body(env):
    return {'profile': PROFILE, 'terms': env['terms'], 'parties': env['parties']}


def identifier(env):
    return digest(LABEL+'-AGREEMENT', body(env))


def _signed(key, value):
    return {'body': value, 'signer': public_key(key), 'signature': sign(key, LABEL, value)}


def _check_signed(record, expected, signer):
    exact(record, 'body signer signature')
    need(canonical(record['body']) == canonical(expected) and record['signer'] == signer and
         signature_ok(signer, LABEL, record['body'], record['signature']), 'SIGNATURE')


def _live(ledger, envelope):
    return ledger.progress(envelope) if ledger is not None and hasattr(ledger, 'progress') else deepcopy(envelope)


def _register(ledger, envelope, *, fund=False):
    if ledger is not None and hasattr(ledger, 'register_progress'):
        return ledger.register_progress(envelope, fund=fund)
    return envelope


def _retry(record, signer, **values):
    need(record['signer'] == public_key(signer) and all(
        canonical(record['body'][key]) == canonical(value) for key, value in values.items()),
        'PROGRESS_CONFLICT')


def draft_order(document=None, *, agent, nonce, settlement_authority=None, **kwargs):
    """The exact unsigned /0.2 order ``propose`` signs for ``agent``. No key is read.

    Historical /0.1 draft validation is reused, not its signed interpretation.
    The nonce is explicit so an owner gate can approve these bytes before signing.
    """
    window = kwargs.get('challenge_window', 3600)
    _int(window)
    args = {**kwargs, 'challenge_window': max(1, window)}
    env = legacy.draft_order(document, agent=agent, **args)
    env['profile'] = PROFILE
    env['terms'].update(version=TERMS, nonce=nonce, challenge_window=window, deadline_clock='OWNER_UNIX_SECONDS',
                        deadline_rule='AUTOMATIC_RELEASE_BEFORE_DEADLINE',
                        settlement_authority=settlement_authority)
    need(_hash(env['terms']['nonce']), 'ORDER_NONCE')
    need(settlement_authority is None or _hash(settlement_authority), 'SETTLEMENT_AUTHORITY')
    return env


def propose(document=None, *, signer, nonce=None, settlement_authority=None, **kwargs):
    env = draft_order(document, agent=public_key(signer), nonce=secrets.token_hex(32) if nonce is None else nonce,
                      settlement_authority=settlement_authority, **kwargs)
    env['assents'] = [_signed(signer, {'action': 'ASSENT', 'agreement': identifier(env)})]
    verdict = verify(env)
    need(verdict['ok'], verdict['code'])
    return {'version': TERMS, 'envelope': env, 'cid': legacy.content_id(env),
            'signed_terms': env['assents'][0], 'assent_request': {
                'label': LABEL, 'body': env['assents'][0]['body'], 'required_signer': env['parties']['counterparty']},
            'execution_authorized': False, 'chain_ledger_touched': False}


def accept(envelope, signer, ledger=None):
    checked = verify(envelope)
    need(checked['ok'], checked['code']); need(checked['verdict'] == 'PROPOSED', 'DUPLICATE_ASSENT')
    env = _live(ledger, envelope)
    need(public_key(signer) == env['parties']['counterparty'], 'SIGNER_ROLE')
    if len(env['assents']) == 2:
        return _register(ledger, env, fund=True)
    env['assents'].append(_signed(signer, {'action': 'ASSENT', 'agreement': identifier(env)}))
    if ledger is not None:
        need(env['terms']['settlement_authority'] is None or
             getattr(ledger, 'instance', None) == env['terms']['settlement_authority'], 'SETTLEMENT_AUTHORITY')
        if hasattr(ledger, 'register_progress'):
            return _register(ledger, env, fund=True)
        ledger.move_to_escrow(identifier(env), env['parties']['principal'], env['terms']['unit'], env['terms']['quantity'])
    return env


def deliver(envelope, content, signer, *, as_of=None, ledger=None):
    checked = verify(envelope)
    need(checked['ok'], checked['code']); need(checked['verdict'] == 'BOUND', 'NOT_DELIVERABLE')
    env = _live(ledger, envelope)
    need(public_key(signer) in {env['parties']['counterparty'], env['parties']['executor']}, 'SIGNER_ROLE')
    need(type(content) in (str, bytes, bytearray), 'CONTENT_SIZE')
    try:
        raw = content.encode('ascii') if type(content) is str else bytes(content)
    except UnicodeError as exc:
        raise NativeError('ASCII_PROFILE') from exc
    need(1 <= len(raw) <= 1_000_000, 'CONTENT_SIZE')
    if env['deliveries']:
        _retry(env['deliveries'][0], signer, content_hash=sha256_hex(raw), content_cid=cid_from_bytes(raw))
        return env, raw
    need(verify(env)['verdict'] == 'BOUND', 'NOT_DELIVERABLE')
    at = _now(as_of); need(at <= env['terms']['deadline'], 'DEADLINE_EXPIRED')
    value = {'action': 'DELIVER', 'agreement': identifier(env), 'content_hash': sha256_hex(raw),
             'content_cid': cid_from_bytes(raw), 'at': at}
    env['deliveries'] = [{**_signed(signer, value), 'content_hash': value['content_hash'],
                          'content_cid': value['content_cid']}]
    return _register(ledger, env), raw


def _bound_evidence(env, evidence_hash):
    known = ({d['content_hash'] for d in env['deliveries']} if env['deliveries']
             else {env['terms']['task_hash']})
    need(_hash(evidence_hash) and evidence_hash in known, 'EVIDENCE_NOT_BOUND')


def open_dispute(envelope, *, signer, reason, evidence_hash, as_of=None, anchor=None, ledger=None):
    checked = verify(envelope)
    need(checked['ok'], checked['code']); need(checked['verdict'] in ('BOUND', 'DELIVERED'), 'NOT_DISPUTABLE')
    env = _live(ledger, envelope)
    need(public_key(signer) in {env['parties']['principal'], env['parties']['agent'], env['parties']['counterparty']}, 'DISPUTE_AUTHORITY')
    _bound_evidence(env, evidence_hash)
    need(type(reason) is str and 1 <= len(reason) <= 200, 'FIELDS'); canonical(reason)
    need(anchor is None, 'EXPLICIT_NATIVE_ADOPTION_REQUIRED')
    if env['dispute'] is not None:
        _retry(env['dispute']['opening'], signer, reason=reason, evidence_hash=evidence_hash)
        return env
    need(verify(env)['verdict'] in ('BOUND', 'DELIVERED'), 'NOT_DISPUTABLE')
    at = _now(as_of)
    if env['deliveries']:
        need(at >= env['deliveries'][0]['body']['at'], 'CLOCK_ORDER')
    value = {'action': 'DISPUTE', 'agreement': identifier(env), 'evidence_hash': evidence_hash,
             'reason': reason, 'at': at}
    env['dispute'] = {'opening': _signed(signer, value), 'evidence_hash': evidence_hash,
                      'decision': None, 'appeal': None}
    return _register(ledger, env)


def decide(envelope, *, signer, result, evidence_hash, paid_amount=None, as_of=None, ledger=None):
    checked = verify(envelope)
    need(checked['ok'], checked['code']); need(checked['verdict'] in ('DISPUTED', 'DECIDED'), 'DISPUTE_OPEN')
    need(envelope['dispute']['appeal'] is None, 'APPEAL_FINAL')
    requested_stage = 'decision' if envelope['dispute']['decision'] is None else 'appeal'
    env = _live(ledger, envelope)
    _bound_evidence(env, evidence_hash)
    need(result in legacy.RESULTS, 'RESULT')
    quantity = env['terms']['quantity']
    if paid_amount is None and result != 'INDETERMINATE':
        paid_amount = quantity if result == 'SUPPORTED' else 0
    if result == 'INDETERMINATE':need(paid_amount is None, 'RESULT')
    else:need(type(paid_amount) is int and 0 <= paid_amount <= quantity and
              (result != 'REFUTED' or paid_amount == 0), 'QUANTITY')
    previous_record = env['dispute'][requested_stage]
    if previous_record is not None:
        _retry(previous_record, signer, result=result, evidence_hash=evidence_hash, paid_amount=paid_amount)
        return env
    need(verify(env)['verdict'] in ('DISPUTED', 'DECIDED'), 'DISPUTE_OPEN')
    at = _now(as_of)
    need(at >= env['dispute']['opening']['body']['at'], 'CLOCK_ORDER')
    primary = env['dispute']['decision']; stage = 'PRIMARY' if primary is None else 'APPEAL'
    if primary is None:
        need(public_key(signer) == env['parties']['resolver'], 'DECISION_AUTHORITY')
        parent = digest(LABEL, env['dispute']['opening'])
    else:
        need(env['dispute']['appeal'] is None and env['terms']['challenge_window'] > 0,
             'APPEAL_FINAL')
        need(public_key(signer) == env['parties']['appeal_resolver'], 'DECISION_AUTHORITY')
        need(primary['body']['at'] <= at < primary['body']['at'] + env['terms']['challenge_window'],
             'APPEAL_EXPIRED')
        parent = digest(LABEL, primary)
    value = {'action': 'DECIDE', 'agreement': identifier(env), 'stage': stage, 'parent': parent,
             'result': result, 'paid_amount': paid_amount, 'evidence_hash': evidence_hash, 'at': at}
    env['dispute']['decision' if primary is None else 'appeal'] = _signed(signer, value)
    return _register(ledger, env)


def _effective(env):
    return ((env.get('dispute') or {}).get('appeal') or (env.get('dispute') or {}).get('decision'))


def _settlement_body(env, *, action, paid, at, authorized_by):
    return {'profile': TERMS, 'agreement': identifier(env), 'action': action,
            'amount': env['terms']['quantity'], 'paid_amount': paid,
            'refunded_amount': env['terms']['quantity']-paid,
            'unit': env['terms']['unit'], 'rail': env['terms']['rail'],
            'payer': env['parties']['principal'], 'payee': env['parties']['counterparty'],
            'settlement_authority': env['terms']['settlement_authority'],
            'decision': digest(LABEL, _effective(env)) if _effective(env) else None,
            'at': at, 'authorized_by': authorized_by,
            'assurance': 'OWNER_ADOPTED_REFERENCE_LEDGER_NOT_EXTERNAL_PAYMENT',
            'protocol_fee': 0, 'external_verification': 'NOT_PERFORMED'}


def settle(envelope, signer, ledger, *, rail=None, as_of=None, silent=False, time_evidence=None):
    checked = verify(envelope, ledger=ledger)
    need(checked['ok'], checked['code'])
    env = _live(ledger, envelope)
    checked = verify(env, ledger=ledger)
    need(checked['ok'], checked['code'])
    effect = identifier(env)
    if env['settlement'] is None:
        previous = ledger.observe(effect)
        if previous['status'] == 'OBSERVED':
            env['settlement'] = deepcopy(previous['value'])
            checked = verify(env, ledger=ledger)
            need(checked['ok'] and checked['funds_observed'], 'SETTLEMENT_CONFLICT')
    if env['settlement'] is not None:
        need(checked['funds_observed'], 'SETTLEMENT_NOT_OBSERVED')
        return {'envelope': env, 'settlement': env['settlement']['body'], 'cid': legacy.content_id(env),
                'verdict': checked, 'replayed': True, 'payment_rail_touched': False,
                'execution_authorized': False, 'chain_ledger_touched': False}
    at = _now(as_of); decision = _effective(env); who = public_key(signer)
    if silent:
        need(env['terms']['timeout'] == 'RELEASE_IF_UNDECIDED' and at > env['terms']['deadline'] and
             decision is None and checked['verdict'] in ('BOUND', 'DISPUTED'), 'SILENCE_NOT_DUE')
        need(who == env['parties']['principal'], 'SIGNER_ROLE')
        paid, authorized = 0, 'silent_refund'
    elif decision is not None:
        need(decision['body']['result'] != 'INDETERMINATE', 'SETTLE_INDETERMINATE')
        need(who in {env['parties']['principal'], env['parties']['resolver'], env['parties']['appeal_resolver']}, 'SIGNER_ROLE')
        need(at >= decision['body']['at'], 'CLOCK_ORDER')
        if env['dispute']['appeal'] is None:
            need(at >= decision['body']['at'] + env['terms']['challenge_window'], 'APPEAL_WINDOW_OPEN')
        paid, authorized = decision['body']['paid_amount'], 'resolver_decision'
    else:
        need(checked['verdict'] == 'DELIVERED', 'NOT_SETTLEABLE')
        need(who == env['parties']['principal'], 'SIGNER_ROLE')
        need(at <= env['terms']['deadline'], 'DEADLINE_EXPIRED')
        need(at >= env['deliveries'][0]['body']['at'], 'CLOCK_ORDER')
        paid, authorized = env['terms']['quantity'], 'principal_release'
    need(rail is None or rail == env['terms']['rail'], 'RAIL')
    need(env['terms']['settlement_authority'] is None or
         getattr(ledger, 'instance', None) == env['terms']['settlement_authority'], 'SETTLEMENT_AUTHORITY')
    action = 'REFUND_PRINCIPAL' if paid == 0 else 'PAY_COUNTERPARTY' if paid == env['terms']['quantity'] else 'SPLIT'
    value = _settlement_body(env, action=action, paid=paid, at=at, authorized_by=authorized)
    env['settlement'] = _signed(signer, value)
    # Validate the entire signed result before any economic mutation.
    verdict = verify(env); need(verdict['ok'], verdict['code'])
    settle_split(ledger, effect, env['parties']['principal'], env['parties']['counterparty'],
                 env['terms']['unit'], env['terms']['quantity'], paid, env['settlement'], envelope=env,
                 time_evidence=time_evidence)
    verdict = verify(env, ledger=ledger, as_of=at)
    return {'envelope': env, 'settlement': value, 'cid': legacy.content_id(env), 'verdict': verdict,
            'replayed': False, 'payment_rail_touched': True, 'chain_ledger_touched': False,
            'ledger_touched': True, 'execution_authorized': False,
            'feedback_hint': legacy._feedback_hint('settle')}


def verify(env, *, ledger=None, as_of=None, **unused):
    stage = 'INVALID'; code = 'FIELDS'; observed = False; expired = None
    try:
        if as_of is not None:_now(as_of)
        exact(env, 'profile terms parties document mandate assents deliveries escrow settlement dispute')
        need(env['profile'] == PROFILE, 'PROFILE')
        t, p = env['terms'], env['parties']
        expected = {'version','task_hash','quantity','unit','rail','pay_to','deadline','challenge_window',
                    'timeout','effect','network','nonce','deadline_clock','deadline_rule','settlement_authority'}
        need(type(t) is dict and set(t) == expected and t['version'] == TERMS, 'TERMS_VERSION')
        need(_hash(t['nonce']), 'ORDER_NONCE')
        need(t['deadline_clock'] == 'OWNER_UNIX_SECONDS' and
             t['deadline_rule'] == 'AUTOMATIC_RELEASE_BEFORE_DEADLINE', 'DEADLINE')
        need(t['settlement_authority'] is None or _hash(t['settlement_authority']), 'SETTLEMENT_AUTHORITY')
        _int(t['challenge_window'])
        # Historical draft validation is reused only for shared field types and mandates.
        # Only replace fields used by the unsigned historical validator. It
        # never mutates this input; shallow construction avoids recursively
        # copying an unvalidated malformed document/mandate before refusal.
        draft = dict(env); draft['profile'] = legacy.PROFILE
        draft['terms'] = {k:v for k,v in t.items() if k not in
            {'nonce','deadline_clock','deadline_rule','settlement_authority'}}
        draft['terms'].update(version=legacy.TERMS_VERSION, challenge_window=max(1,t['challenge_window']))
        draft.update(assents=[], deliveries=[], dispute=None, settlement=None, escrow=None)
        check = legacy.verify(draft, draft=True)
        failures = [f for f in check['failures'] if f['code'] not in ('AGENT_ASSENT','COUNTERPARTY_ASSENT')]
        need(not failures, failures[0]['code'] if failures else 'FIELDS')
        need(type(env['assents']) is list and 1 <= len(env['assents']) <= 2, 'ASSENT')
        expected_assent = {'action':'ASSENT','agreement':identifier(env)}
        _check_signed(env['assents'][0], expected_assent, p['agent'])
        if len(env['assents']) == 2:_check_signed(env['assents'][1], expected_assent, p['counterparty'])
        stage = 'PROPOSED' if len(env['assents']) == 1 else 'BOUND'
        need(type(env['deliveries']) is list and len(env['deliveries']) <= 1 and env['escrow'] is None, 'FIELDS')
        if env['deliveries']:
            need(stage == 'BOUND', 'COUNTERPARTY_ASSENT')
            d = env['deliveries'][0]; exact(d, 'body signer signature content_hash content_cid')
            b=d['body'];exact(b,'action agreement content_hash content_cid at')
            need(_hash(d['content_hash']) and d['content_hash'] == b['content_hash'] and
                 d['content_cid'] == b['content_cid'] and b['action']=='DELIVER' and
                 b['agreement']==identifier(env) and b['at'] <= t['deadline'], 'DELIVERY')
            need(parse_cid(d['content_cid']).hex() == d['content_hash'], 'DELIVERY_CID')
            _int(b['at']); need(d['signer'] in (p['executor'],p['counterparty']), 'SIGNER_ROLE')
            _check_signed({k:d[k] for k in ('body','signer','signature')},b,d['signer']); stage='DELIVERED'
        dispute=env['dispute']
        if dispute is not None:
            need(stage in ('BOUND','DELIVERED'), 'NOT_DISPUTABLE')
            exact(dispute,'opening evidence_hash decision appeal'); opening=dispute['opening'];b=opening['body']
            exact(b,'action agreement evidence_hash reason at');_int(b['at']);_bound_evidence(env,b['evidence_hash'])
            need(b['action']=='DISPUTE' and b['agreement']==identifier(env) and
                 b['evidence_hash']==dispute['evidence_hash'] and type(b['reason']) is str and
                 1 <= len(b['reason']) <= 200 and opening['signer'] in
                 (p['principal'],p['agent'],p['counterparty']), 'DISPUTE_AUTHORITY')
            _check_signed(opening,b,opening['signer']);stage='DISPUTED'
            if env['deliveries']:need(b['at']>=env['deliveries'][0]['body']['at'],'CLOCK_ORDER')
            previous=opening
            for key,signer,kind in (('decision',p['resolver'],'PRIMARY'),('appeal',p['appeal_resolver'],'APPEAL')):
                d=dispute[key]
                if d is None:
                    need(key!='decision' or dispute['appeal'] is None,'APPEAL_PARENT');continue
                b=d['body'];exact(b,'action agreement stage parent result paid_amount evidence_hash at');_int(b['at'])
                need(b['action']=='DECIDE' and b['agreement']==identifier(env) and b['stage']==kind and
                     b['parent']==digest(LABEL,previous) and b['at']>=previous['body']['at'], 'DECISION_BINDING')
                _bound_evidence(env,b['evidence_hash']);need(b['result'] in legacy.RESULTS,'RESULT')
                if b['result']=='INDETERMINATE':need(b['paid_amount'] is None,'RESULT')
                else:need(type(b['paid_amount']) is int and 0 <= b['paid_amount'] <= t['quantity'] and
                          (b['result']!='REFUTED' or b['paid_amount']==0),'QUANTITY')
                if kind=='APPEAL':
                    need(t['challenge_window']>0 and b['at']<previous['body']['at']+t['challenge_window'],'APPEAL_EXPIRED')
                _check_signed(d,b,signer);previous=d;stage='DECIDED'
        settlement=env['settlement']
        if settlement is not None:
            need(stage in ('BOUND','DELIVERED','DISPUTED','DECIDED'),'NOT_SETTLEABLE')
            b=settlement['body'];_int(b['at']);decision=_effective(env);auth=b['authorized_by']
            if auth=='principal_release':
                need(stage=='DELIVERED' and b['at']<=t['deadline'],'DEADLINE_EXPIRED');paid=t['quantity']
                need(b['at']>=env['deliveries'][0]['body']['at'],'CLOCK_ORDER')
                need(settlement['signer']==p['principal'],'SIGNER_ROLE')
            elif auth=='resolver_decision':
                need(decision is not None and decision['body']['result']!='INDETERMINATE','SETTLE_INDETERMINATE')
                need(settlement['signer'] in (p['principal'],p['resolver'],p['appeal_resolver']),'SIGNER_ROLE')
                paid=decision['body']['paid_amount'];_int(paid)
                earliest=decision['body']['at']+(t['challenge_window'] if dispute['appeal'] is None else 0)
                need(b['at']>=earliest,'APPEAL_WINDOW_OPEN')
            else:
                need(auth=='silent_refund' and decision is None and stage in ('BOUND','DISPUTED') and
                     b['at']>t['deadline'] and t['timeout']=='RELEASE_IF_UNDECIDED' and
                     settlement['signer']==p['principal'],'SILENCE_NOT_DUE');paid=0
            action='REFUND_PRINCIPAL' if paid==0 else 'PAY_COUNTERPARTY' if paid==t['quantity'] else 'SPLIT'
            expected_body=_settlement_body(env,action=action,paid=paid,at=b['at'],authorized_by=auth)
            _check_signed(settlement,expected_body,settlement['signer'])
            stage='RELEASED' if paid==0 else 'SETTLED'
            if ledger is not None:
                need(t['settlement_authority'] is None or getattr(ledger,'instance',None)==t['settlement_authority'],
                     'SETTLEMENT_AUTHORITY')
                receipt=ledger.observe(identifier(env))
                observed=(receipt['status']=='OBSERVED' and canonical(receipt['value'])==canonical(settlement))
        canonical(env);code='OK'
        if as_of is not None:expired=_now(as_of)>t['deadline']
    except (NativeError,KeyError,TypeError,ValueError,IndexError,AttributeError) as exc:
        code=getattr(exc,'code',str(exc)) or 'FIELDS';stage='INVALID'
    return {'version':TERMS,'ok':stage!='INVALID','verdict':stage,'code':code,
            'complete':stage in ('SETTLED','RELEASED'),'funds_observed':observed,
            'expiry_checked':as_of is not None and stage!='INVALID','expired':expired,
            'cid':legacy.content_id(env) if stage!='INVALID' else None,
            'terms_hash':env['terms'].get('task_hash') if type(env) is dict and type(env.get('terms')) is dict else None,
            'checks':[],'failures':[] if stage!='INVALID' else [{'code':code}],
            'assurance':'OFFLINE_SIGNATURES_NOT_EXTERNAL_PAYMENT','execution_authorized':False,
            'progress_guarantee':('ONLY_HISTORY_REGISTERED_WITH_ADOPTED_PROVIDER' if
                ledger is not None and hasattr(ledger,'register_progress') else 'NO_SHARED_BRANCH_SAFETY'),
            'chain_ledger_touched':False,'notes':['Time depends on the owner-adopted clock; delivery time is a signed claim.',
                'Payment is observed only through the independently installed settlement authority.',
                'Disconnected updates cannot constrain an authority that has not received them.'],
            'compiles_to':{'submitted':False,'execution_authorized':False,
                          'native_adoption':'EXPLICIT_MAPPING_REQUIRED'}}
