"""Hire and manage N agents under one budget.

One session searches the directory, drafts the team from a sentence, and signs
each offer with a delegated mandate. The principal signs the policy, the access
grant, and any later override. The principal seed never signs an offer.
MandateWallet.reserve is the hold. A hash is not evidence.

The session derives every key it signs with, the principal key included, so it
is the acting agent. An approval that ``approval_policy`` requires (above
``approval_limit``, ALWAYS, or a new counterparty) therefore counts only when the
owner's or principal's own approval key, adopted as ``approver``, signs it
(``covenant-mandate-approval/1.1``). That is the self-approval rule of the
assent gate, ``assent_gate.separate_approver``. An APPROVE that the session signs
itself (``record``, or an unsigned decision) never satisfies a required
approval. A DECLINE, signed or not, always blocks.
"""
from copy import deepcopy
import hashlib
import os
import tempfile

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from covenant_chain import access_mechanisms as access
from covenant_chain import arbitration, principal, reliance
from covenant_chain.adapters import AdapterRegistry, RecordAdapter
from covenant_chain.crypto import FieldError, public_key, sign, verify
from covenant_chain.directory_network import api, sign_document
from covenant_chain.reliance_review import plan as compile_plan
from covenant_chain.workflow_store import canonical, identifier
from covenant_language import legal_composition as legal
from covenant_language import market_blueprints
from covenant_language.marketplace import escrow_policy
from covenant_language.safe_io import atomic_write

from .assent_gate import separate_approver
from .drafting import draft as draft_sentence
from .errors import NativeError
from .evidence.check import pin as pin_evidence

CHAIN = 'a' * 64
CLOCK = 100
POLICY_EXPIRES = 1_000_000_000
INTENT_EXPIRES = 900_000_000
WITNESS = 'covenant-evidence-adapter/witness/0.1'
SKILL = '7' * 64
APPROVAL_POLICIES = ('ALWAYS', 'ABOVE_LIMIT', 'NEW_COUNTERPARTY', 'NEVER_WITHIN_SCOPE')
APPROVAL_LABEL = 'COVENANT-MANDATE-APPROVAL-1'
OWNER_APPROVAL_VERSION = 'covenant-mandate-approval/1.1'
OWNER_APPROVAL_LABEL = 'COVENANT-MANDATE-APPROVAL-1.1'
OWNER_APPROVAL_FIELDS = frozenset(('version', 'policy', 'mandate', 'principal', 'approver', 'counterparty', 'amount',
                                   'decision'))


def _key(label):
    return Ed25519PrivateKey.from_private_bytes(
        hashlib.sha256(f'covenant-hire-0.1:{label}'.encode()).digest())


def _hid(*parts):
    return hashlib.sha256(('covenant-hire-0.1:' + ':'.join(parts)).encode()).hexdigest()


def _seed_instance(directory, instance):
    """Write the adapter-instance file of a fresh private directory."""
    os.makedirs(directory, mode=0o700)
    atomic_write(os.path.join(directory, 'adapter-instance'), instance.encode('ascii'),
                 mode=0o600, exclusive=True, follow_symlinks=False)


def _positive(value, path):
    if type(value) is bool or type(value) is not int or not 1 <= value <= 2**53 - 1:
        raise FieldError(
            'INTEGER', path, 'integer 1..9007199254740991',
            f'{path} must be a positive integer. Set {path}, then run the hire again.')
    return value


def approval_body(mandate, principal, approver, policy, counterparty, amount, decision='APPROVE'):
    """The exact covenant-mandate-approval/1.1 body the owner's approval key signs."""
    return {'version': OWNER_APPROVAL_VERSION, 'policy': policy, 'mandate': mandate, 'principal': principal,
            'approver': approver, 'counterparty': counterparty, 'amount': amount, 'decision': decision}


def sign_approval(approver_key, body):
    """Owner-side: sign an approval body with the owner's or principal's own approval key.

    Run by the owner's tool. The key never reaches the hiring session."""
    return {'body': deepcopy(body), 'signature': sign(approver_key, OWNER_APPROVAL_LABEL, body)}


def _profile(identity, name, summary, price):
    return {
        'subject_kind': 'AGENT', 'identity': identity, 'principal': identity, 'grant': None,
        'name': name, 'summary': summary, 'capabilities': ['research'],
        'skills': [{'source': 'MODULE', 'id': SKILL, 'name': 'research-notes'}],
        'pricing': {'amount': price, 'asset': 'CVT', 'unit': 'job'},
        'sla': {'response_seconds': 3600, 'availability_bps': 9900}, 'availability': 'AVAILABLE',
        'domain': 'research', 'a2a': None, 'mcp': {'url': 'https://agent.example/mcp'},
        'portfolio': ['https://agent.example/work'],
    }


class Session:
    """In-process hire. Close it when the report is done. Keys stay in memory."""

    def __init__(self, task, budget, per_agent_cap, sentence=None, *, directory=None,
                 documents=None, agents=None, disposable=True, as_of='2026-10-22', board=None,
                 approval_policy='NEVER_WITHIN_SCOPE', approval_limit=None, decisions=None,
                 arbitrators=None, approver=None):
        self.task = task
        self.budget = _positive(budget, 'budget')
        self.per_agent_cap = _positive(per_agent_cap, 'per_agent_cap')
        self.session_cap = self.per_agent_cap
        self.principal_spend = self.per_agent_cap
        self.sentence = sentence
        self.as_of = as_of
        self.directory = directory
        self.board = board
        self.documents = list(documents or [])
        self._given_agents = list(agents or [])
        self.disposable = disposable
        if approval_policy not in APPROVAL_POLICIES:
            raise FieldError(
                'APPROVAL_POLICY', 'approval_policy',
                'ALWAYS | ABOVE_LIMIT | NEW_COUNTERPARTY | NEVER_WITHIN_SCOPE',
                'Set approval_policy to ALWAYS, ABOVE_LIMIT, NEW_COUNTERPARTY, or NEVER_WITHIN_SCOPE.')
        self.approval_policy = approval_policy
        self.approval_limit = self.per_agent_cap if approval_limit is None else _positive(approval_limit, 'approval_limit')
        if decisions is not None and type(decisions) is not list:
            raise FieldError(
                'PRINCIPAL_APPROVAL', 'decisions', 'a list of {counterparty, amount, decision}',
                'Pass decisions as a list. APPROVE allows a spend. DECLINE blocks it.')
        self._pending_decisions = list(decisions or [])
        self.approver = None if approver is None else self._party(approver, 'approver')
        self.approvals = []
        self.declines = []
        self._known_counterparties = set()
        self.arbitrators = list(arbitrators or [])
        self.clock = [CLOCK]
        self.grant_state = {'as_of': 0, 'valid_until': POLICY_EXPIRES, 'revoked': [], 'successors': {}}
        self.steps = []
        self.override_log = []
        self.wallet = None
        self.adapter = None
        self._root = None
        self._owned_temp = None
        self.draft_document = None
        self.legal = None
        self.evidence = None
        self.escrows = []
        self.directory_result = None
        self.principal_key = None
        self.delegate_key = None
        self.opened = False

    def open(self):
        if self.sentence:
            self.draft_document = draft_sentence(self.sentence, as_of=self.as_of)
            if self.draft_document['template'] != 'agent-team':
                raise FieldError(
                    'DRAFT_TEMPLATE', 'sentence', 'a hire sentence such as "Hire eight agents for 100 credits each"',
                    'Pass a sentence the agent-team template matches, or omit the sentence and pass a team size.')
            size = self.draft_document['parameters'].get('team_size')
            each = self.draft_document['parameters'].get('per_agent')
            if type(size) is not int or type(each) is not int:
                raise FieldError(
                    'NEED_NAMED_PAYEES', 'sentence', 'a count and a per-agent amount',
                    'Say how many agents and how many credits each, for example "Hire eight agents for 100 credits each".')
            if each != self.per_agent_cap:
                raise FieldError(
                    'RELIANCE_PER_ACTION', 'per_agent_cap', f'integer equal to the sentence amount {each}',
                    f'The sentence pays {each} and per_agent_cap is {self.per_agent_cap}. Use the same number for both.')
            self.team_size = size
        else:
            self.team_size = len(self._given_agents) or 1
        if self.team_size * self.per_agent_cap > self.budget:
            raise FieldError(
                'RELIANCE_BUDGET_EXCEEDED', 'budget',
                f'integer >= {self.team_size * self.per_agent_cap}',
                f'{self.team_size} agents at {self.per_agent_cap} need {self.team_size * self.per_agent_cap}, '
                f'and budget is {self.budget}. Raise the budget or lower the cap, then hire again.')
        if self.per_agent_cap > self.budget:
            raise FieldError(
                'RELIANCE_PER_ACTION', 'per_agent_cap', f'integer 1..{self.budget}',
                f'per_agent_cap {self.per_agent_cap} is above budget {self.budget}. Lower the cap.')
        self.principal_key = _key('principal')
        self.delegate_key = _key('delegate')
        self.resolver_key = _key('resolver')
        self.appeal_key = _key('appeal')
        self.principal_pub = public_key(self.principal_key)
        self.delegate_pub = public_key(self.delegate_key)
        self.resolver_pub = public_key(self.resolver_key)
        self.appeal_pub = public_key(self.appeal_key)
        if self.principal_pub == self.delegate_pub:
            raise FieldError('PRINCIPAL_AUTHORITY', 'delegate', 'a key different from the principal',
                             'Generate the delegate from its own label. Do not reuse the principal seed.')
        self._root = self.directory
        if self._root is None:
            self._owned_temp = tempfile.TemporaryDirectory()
            self._root = self._owned_temp.name
        try:
            self._search()
            if self.approver is not None:
                self._separate(self.approver)
            self._apply_decisions()
            self._screen_approvals()
            self._legal()
            self._wallet()
            self._reserve_team()
            self._pin()
            self.opened = True
            return self
        except BaseException:
            self.close()
            raise

    def close(self):
        if self.wallet is not None:
            self.wallet.close()
            self.wallet = None
        if self.adapter is not None:
            self.adapter.close()
            self.adapter = None
        if self._owned_temp is not None:
            self._owned_temp.cleanup()
            self._owned_temp = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *_exc):
        self.close()

    def _board(self):
        if self.board is None:
            return None
        if hasattr(self.board, 'documents'):
            return self.board
        from covenant_chain.directory_board import DirectoryBoard
        return DirectoryBoard(self.board)

    def _party(self, value, path):
        if type(value) is not str or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
            raise FieldError(
                'PARTY_UNKEYED', path, '^[0-9a-f]{64}$',
                f'{path} is not a verification key. Pass the 64-character lowercase hex key.')
        return value

    def record(self, counterparty, amount, decision):
        """Session-held principal signature on an approval or a decline. A decline blocks later spends.

        The session holds this key, so an APPROVE recorded here never satisfies an
        approval the policy requires; ``submit_approval`` takes the owner's."""
        counterparty = self._party(counterparty, 'approval.counterparty')
        amount = _positive(amount, 'approval.amount')
        if decision not in ('APPROVE', 'DECLINE'):
            raise FieldError(
                'PRINCIPAL_APPROVAL', 'approval.decision', 'APPROVE or DECLINE',
                'Record APPROVE to allow the spend, or DECLINE to block it. A decline always blocks.')
        body = {
            'version': 'covenant-mandate-approval/1.0', 'policy': self.approval_policy,
            'mandate': getattr(self, 'id', None), 'principal': self.principal_pub,
            'counterparty': counterparty, 'amount': amount, 'decision': decision,
        }
        row = {'body': body, 'signature': sign(self.principal_key, APPROVAL_LABEL, body)}
        verify(self.principal_pub, APPROVAL_LABEL, body, row['signature'])
        if decision == 'DECLINE':
            self.declines.append(row)
        else:
            self.approvals.append(row)
        return row

    def _acting(self, *extra):
        """Every key this session can sign with, plus the payees: none of them can approve a spend."""
        keys = {self.principal_pub, self.delegate_pub, self.resolver_pub, self.appeal_pub}
        return keys | set(getattr(self, 'agents', ())) | set(extra)

    def _separate(self, approver, *extra):
        try:
            return separate_approver(approver, self._acting(*extra))
        except NativeError as exc:
            raise FieldError(
                exc.code, 'approver', "the principal's or owner's own approval key",
                'This session or a payee holds that key, so its approval would be self-approval. Adopt the '
                "principal's or owner's separate approval key as approver. Nothing was reserved.") from None

    def approval_request(self, counterparty, amount, decision='APPROVE'):
        """The exact body the adopted approver key signs for this hire. Signs nothing."""
        if self.approver is None:
            raise FieldError(
                'PRINCIPAL_APPROVER', 'approver', 'the 64-hex public key of the owner approval key',
                "Adopt the principal's or owner's approval key as approver when you open the session.")
        if getattr(self, 'id', None) is None:
            raise FieldError(
                'PRINCIPAL_APPROVAL', 'mandate', 'a searched hire', 'Open the session once; then ask for the request.')
        counterparty = self._party(counterparty, 'approval.counterparty')
        if decision not in ('APPROVE', 'DECLINE'):
            raise FieldError('PRINCIPAL_APPROVAL', 'approval.decision', 'APPROVE or DECLINE',
                             'Ask for APPROVE to allow the spend, or DECLINE to block it.')
        return approval_body(self.id, self.principal_pub, self.approver, self.approval_policy, counterparty,
                             _positive(amount, 'approval.amount'), decision)

    def submit_approval(self, row, path='approval'):
        """Accept a decision signed by the adopted approver key. A key this session holds is refused."""
        if self.approver is None:
            raise FieldError(
                'PRINCIPAL_APPROVER', 'approver', 'the 64-hex public key of the owner approval key',
                "A signed approval needs an adopted approver. Open the session with the principal's or owner's "
                'approval key as approver.')
        self._separate(self.approver)
        body = row.get('body') if type(row) is dict and set(row) == {'body', 'signature'} else None
        if type(body) is not dict or set(body) != OWNER_APPROVAL_FIELDS or body['version'] != OWNER_APPROVAL_VERSION \
                or body['decision'] not in ('APPROVE', 'DECLINE'):
            raise FieldError(
                'PRINCIPAL_APPROVAL', path, f'a signed {OWNER_APPROVAL_VERSION} decision',
                'Sign the exact body from approval_request with the approver key and pass {body, signature}.')
        expected = self.approval_request(body['counterparty'], body['amount'], body['decision'])
        try:
            if body != expected:
                raise ValueError('BINDING')
            verify(self.approver, OWNER_APPROVAL_LABEL, body, row['signature'])
        except ValueError:
            raise FieldError(
                'PRINCIPAL_APPROVAL_SIGNATURE', path, 'the approver signature over this exact hire',
                'The decision is not signed by the adopted approver for this hire, policy and amount. '
                'Ask the owner to sign the exact approval_request body. Nothing was reserved.') from None
        (self.declines if body['decision'] == 'DECLINE' else self.approvals).append(deepcopy(row))
        return row

    def _apply_decisions(self):
        for index, row in enumerate(self._pending_decisions):
            if type(row) is not dict:
                raise FieldError(
                    'PRINCIPAL_APPROVAL', 'decisions', 'objects with counterparty, amount, and decision',
                    'Each decision names the counterparty key, the amount, and APPROVE or DECLINE.')
            if set(row) == {'body', 'signature'}:
                self.submit_approval(row, f'decisions[{index}]')
            else:
                self.record(row.get('counterparty'), row.get('amount'), row.get('decision'))

    def _needs_approval(self, agent, amount):
        if self.approval_policy == 'ALWAYS':
            return True
        if self.approval_policy == 'ABOVE_LIMIT':
            return amount > self.approval_limit
        if self.approval_policy == 'NEW_COUNTERPARTY':
            return agent not in self._known_counterparties
        return False

    def _require_approval(self, agent, amount, index):
        for row in self.declines:
            if row['body']['counterparty'] == agent:
                raise FieldError(
                    'PRINCIPAL_DECLINED', f'steps[{index}].approval', 'no recorded decline',
                    f'A recorded decline blocks this counterparty. approval_policy {self.approval_policy} '
                    'does not override a decline. Nothing was reserved.')
        if not self._needs_approval(agent, amount):
            return
        # Only the adopted approver counts, never a key this session holds (assent_gate.separate_approver).
        approved = self.approver is not None and any(
            row['body']['version'] == OWNER_APPROVAL_VERSION and row['body']['approver'] == self.approver and
            row['body']['counterparty'] == agent and row['body']['amount'] >= amount
            for row in self.approvals)
        if approved:
            self._separate(self.approver, agent)
            return
        raise FieldError(
            'PRINCIPAL_APPROVAL', f'steps[{index}].approval', f'an APPROVE covering {amount} signed by the approver key',
            f'approval_policy is {self.approval_policy}. The owner\'s or principal\'s own approval key (approver) '
            'must sign approval_request for this counterparty and amount; an approval this session signs itself '
            'never counts. Pass the signed decision, then hire again. A recorded decline always blocks. '
            'Nothing was reserved.')

    def _screen_approvals(self):
        for index, agent in enumerate(self.agents, start=1):
            self._require_approval(agent, self.per_agent_cap, index)
        self._known_counterparties.update(self.agents)

    def _search(self):
        if not self.documents and not self._given_agents:
            if not self.disposable:
                raise FieldError(
                    'DIRECTORY_QUERY', 'agents', 'signed PROFILE documents or disposable true',
                    'Pass signed directory profiles, or set disposable so this process can mint profile keys.')
            keys = [_key(f'agent:{index:02d}') for index in range(1, self.team_size + 1)]
            self.documents = [
                sign_document(key, CHAIN, 'PROFILE', 1, _profile(
                    public_key(key), f'Research {index:02d}', 'research partner', self.per_agent_cap))
                for index, key in enumerate(keys, start=1)
            ]
        elif self._given_agents and not self.documents:
            for index, agent in enumerate(self._given_agents):
                if type(agent) is not str or len(agent) != 64:
                    raise FieldError(
                        'PARTY_UNKEYED', f'agents[{index}].public_key', '^[0-9a-f]{64}$',
                        f'agents[{index}].public_key is not a verification key. '
                        'Search the directory or pass a 64-character lowercase hex key.')
        board = self._board()
        if board is not None:
            for envelope in self.documents:
                try:
                    board.accept(envelope)
                except ValueError as exc:
                    if str(exc) != 'DIRECTORY_CHAIN':
                        raise
                    raise FieldError(
                        'DIRECTORY_CHAIN', 'directory.chain', board.chain,
                        f'The shared directory is chain {board.chain}. Sign profiles on that chain and search again.') from exc
        documents = list(board.documents()) if board is not None else list(self.documents)
        if not documents:
            documents = list(self.documents)
        found = api({'action': 'search', 'parameters': {
            'query': 'research', 'capability': 'research', 'domain': 'research', 'documents': documents}})
        self.directory_result = found
        organic = [row['identity'] for row in found.get('organic', [])]
        chosen = organic[:self.team_size]
        if self._given_agents and not self.documents:
            chosen = list(self._given_agents)
        if len(chosen) < self.team_size:
            raise FieldError(
                'DIRECTORY_QUERY', 'directory.organic', f'at least {self.team_size} profiles',
                f'The directory returned {len(chosen)} agents and the team needs {self.team_size}. '
                'Sign more PROFILE documents and search again.')
        self.agents = chosen
        self.id = identifier('covenant-hire-0.1', {
            'task': self.task, 'budget': self.budget, 'per_agent_cap': self.per_agent_cap,
            'sentence': self.sentence or '', 'agents': sorted(self.agents)})

    def _legal(self):
        parties = {
            'principal': self.principal_pub, 'delegate': self.delegate_pub,
            'resolver': self.resolver_pub, 'appeal': self.appeal_pub,
        }
        for index, agent in enumerate(self.agents, start=1):
            parties[f'agent{index}'] = agent
        asset = market_blueprints.asset('covenant-hire', 'credits', 'credits')
        duty = legal.node('OBLIGATION', {
            'debtor': 'delegate', 'creditor': 'principal', 'performance': 'hire the named agents under the cap'})
        mandate = legal.node('DELEGATION', {
            'grantor': 'principal', 'delegate': 'delegate',
            'powers': ['spend_credits', 'hire_subagent'], 'subdelegation': False,
            'approval_policy': self.approval_policy})
        guarantee = legal.node('GUARANTEE', {
            'guarantor': 'principal', 'beneficiary': 'delegate', 'resource': 'credits',
            'maximum': self.per_agent_cap,
        }, references=[legal.reference('SELF', 'duty')])
        self.legal = legal.draft(
            'Hire a team', parties, {'credits': asset},
            {'duty': duty, 'mandate': mandate, 'guarantee': guarantee},
            [legal.reference('SELF', 'mandate'), legal.reference('SELF', 'guarantee')])

    def _wallet(self):
        receipts = self._root + '/receipts'
        if self._owned_temp is not None:
            # A disposable session derives its keys from labels. Its scratch
            # record adapter takes its instance id from the session id the same
            # way, so the same hire gives the same plan id.
            _seed_instance(receipts, _hid('adapter-instance', self.id))
        self.adapter = RecordAdapter(receipts)
        registry = AdapterRegistry()
        self.inner = registry.register(self.adapter)
        self.domain = _hid('domain', self.task)
        self.policy = dict(
            version=reliance.VERSION, domain=self.domain, principal=self.principal_pub,
            not_before=0, expires=POLICY_EXPIRES, limits={'credits': self.budget},
            per_action={'credits': self.per_agent_cap}, adapters=[self.inner], nonce=_hid('policy', self.id))
        signing = reliance.policy_payload(self.policy)
        envelope = {'policy': self.policy, 'signature': sign(self.principal_key, signing['label'], signing['body'])}
        self.wallet = reliance.MandateWallet(
            self._root + '/wallet', envelope, domain=self.domain, clock=lambda: self.clock[0],
            current_state=lambda: deepcopy(self.grant_state), adapters=registry)
        drafted = access.grant(
            self.domain, {'kind': 'mandate-wallet', 'id': self.wallet.id}, reliance.OPERATION,
            self.principal_pub, self.delegate_pub, ['adapter:' + self.inner], 0, INTENT_EXPIRES,
            _hid('grant', self.id))
        self.grant_id = drafted['id']
        self.chain = [{'grant': drafted['grant'], 'signature': sign(self.principal_key, drafted['label'], drafted['body'])}]
        self.permit_id = _hid('permit', self.id)
        self.profile_id = _hid('profile', self.id)

    def _intent(self, agent, amount, label):
        cap = self.policy['per_action']['credits']
        request = {'task': self.task, 'counterparty': agent, 'cap': amount, 'label': label}
        request_hash = hashlib.sha256(canonical(request)).hexdigest()
        effect = _hid('effect', self.id, label)
        nonce = _hid('nonce', self.id, label)
        # Amounts above the wallet cap are refused here, before reserve, by draft_intent.
        drafted = reliance.draft_intent(
            self.policy, self.delegate_pub, self.inner, effect, request_hash,
            {'credits': amount}, 0, INTENT_EXPIRES, nonce)
        if amount <= cap and amount > self.session_cap:
            raise FieldError(
                'PRINCIPAL_SPEND', 'spend', f'integer 1..{self.session_cap}',
                f'The principal narrowed the cap to {self.session_cap}. {amount} would widen it. '
                'Lower the allocation. The wallet per-action cap is still '
                f'{cap}, and that does not override the principal.')
        envelope = {'intent': drafted['intent'], 'signature': sign(self.delegate_key, drafted['label'], drafted['body'])}
        return envelope, request, effect, drafted

    def _hold(self, agent, amount, label, index):
        envelope, request, effect, drafted = self._intent(agent, amount, label)
        held = self.wallet.reserve(envelope, self.chain)
        asset = market_blueprints.asset('covenant-hire', 'credits', 'credits')
        terms_hash = (self.draft_document or {}).get('terms_hash') or _hid('terms', self.task)
        escrow = escrow_policy(
            'Hire escrow', self.principal_pub, asset, amount, self.principal_pub, agent,
            sorted({self.resolver_pub, self.appeal_pub}), 1, terms_hash,
            {'on': 'SUPPORTED_AFTER_CHALLENGE_WINDOW'}, {'on': 'TIMEOUT_POLICY'})
        self.escrows.append({'id': escrow['id'], 'amount': amount, 'payee': agent, 'moved': False, 'funded': False})
        step = {
            'index': index, 'id': _hid('step', self.id, str(index)), 'counterparty': agent,
            'allocation': amount, 'state': 'PENDING', 'wallet_state': 'HELD', 'paid': 0,
            'intent_id': held['id'], 'envelope': envelope, 'request': request, 'effect': effect,
            'content_id': None, 'preimage_verified': False, 'reason': None, 'recovery_ms': None,
            'replaced': False, 'silence_release': False, 'panel': None, 'ladder': None,
        }
        return step

    def _reserve_team(self):
        for index, agent in enumerate(self.agents, start=1):
            self.steps.append(self._hold(agent, self.per_agent_cap, f'slot-{index}', index))

    def _pin(self):
        terms_hash = (self.draft_document or {}).get('terms_hash') or _hid('terms', self.task)
        self.evidence = pin_evidence(
            terms_hash, [WITNESS],
            {'subject': 'hire-team', 'predicate': 'delivered', 'expect': {'witness': {'signer': self.delegate_pub}}},
            1, [self.delegate_key])

    def _step(self, index):
        if type(index) is bool or type(index) is not int or not 1 <= index <= len(self.steps):
            raise FieldError(
                'RELIANCE_STEPS', 'steps', f'integer 1..{len(self.steps)}',
                'Pass the step index from the hire report, starting at 1.')
        return self.steps[index - 1]

    def refuse_over_cap(self, amount):
        """Ask draft_intent for more than the wallet cap. Nothing is reserved."""
        before = self.wallet.inspect()['balances']
        try:
            self._intent(self.agents[0], amount, 'over-cap-probe')
        except FieldError:
            after = self.wallet.inspect()['balances']
            if after != before:
                raise FieldError(
                    'RELIANCE_BUDGET_EXCEEDED', 'balances', 'unchanged',
                    'The refusal changed a balance. That is a bug: draft_intent must not hold funds.')
            raise
        raise FieldError(
            'RELIANCE_PER_ACTION', 'allocations.credits', f'integer 1..{self.per_agent_cap}',
            f'{amount} was accepted against a cap of {self.per_agent_cap}. Refuse it before reserve.')

    def dispatch(self, index):
        step = self._step(index)
        if step['state'] != 'PENDING':
            raise FieldError(
                'RELIANCE_STEPS', f'steps[{index}].state', 'PENDING',
                f'Step {index} is {step["state"]}. Dispatch only a PENDING step.')
        if index > 1 and self.steps[index - 2]['state'] not in {'DELIVERED', 'SETTLED'}:
            raise FieldError(
                'WAITING_FOR_EVIDENCE', f'steps[{index}].state', 'previous step DELIVERED',
                f'Step {index - 1} is not DELIVERED. Deliver it, then dispatch step {index}. This step stays PENDING.')
        receipt = self.wallet.execute(step['envelope'], self.chain, step['effect'], step['request'])
        step['wallet_state'] = 'STARTED'
        step['state'] = 'RUNNING'
        step['dispatch_receipt'] = receipt.get('status')
        return step['state']

    def deliver(self, index, artifact, prior=None):
        step = self._step(index)
        if type(artifact) is not bytes:
            raise FieldError(
                'EVIDENCE_PREIMAGE', 'artifact', 'raw bytes',
                'Pass the artifact bytes. A hash alone is not evidence. The step is unchanged.')
        digest_hex = hashlib.sha256(artifact).hexdigest()
        if index > 1:
            previous = self.steps[index - 2]
            if type(prior) is not bytes or hashlib.sha256(prior).hexdigest() != previous.get('content_id'):
                self._fail_step(step, 'EVIDENCE_PREIMAGE', 0)
                return step['state']
        if step['state'] != 'RUNNING':
            raise FieldError(
                'RELIANCE_NOT_STARTED', f'steps[{index}].state', 'RUNNING',
                f'Dispatch step {index} before delivering it. It is {step["state"]}.')
        step['content_id'] = digest_hex
        step['preimage_verified'] = True
        step['state'] = 'DELIVERED'
        return step['state']

    def fail(self, index, reason, recovery_ms):
        step = self._step(index)
        if type(reason) is not str or not reason:
            raise FieldError('RELIANCE_FAILURE', 'reason', 'a short string', 'Name why this step failed.')
        if type(recovery_ms) is bool or type(recovery_ms) is not int or recovery_ms < 0:
            raise FieldError('INTEGER', 'recovery_ms', 'integer >= 0', 'Pass recovery_ms in milliseconds.')
        self._fail_step(step, reason, recovery_ms)
        return step['state']

    def _fail_step(self, step, reason, recovery_ms):
        if step['wallet_state'] == 'HELD':
            self.wallet.cancel(step['intent_id'])
            step['wallet_state'] = 'CANCELLED'
        step['state'] = 'FAILED'
        step['reason'] = reason
        step['recovery_ms'] = recovery_ms
        step['paid'] = 0

    def replace(self, index, public):
        step = self._step(index)
        if step['state'] != 'FAILED':
            raise FieldError(
                'RELIANCE_STEPS', f'steps[{index}].state', 'FAILED',
                f'Step {index} is {step["state"]}. Replace only a FAILED step.')
        if type(public) is not str or len(public) != 64 or any(c not in '0123456789abcdef' for c in public):
            raise FieldError(
                'PARTY_UNKEYED', f'agents[{index}].public_key', '^[0-9a-f]{64}$',
                'Pass the replacement agent verification key. A display name cannot be paid.')
        if step['wallet_state'] != 'CANCELLED':
            raise FieldError(
                'RELIANCE_CANNOT_RELEASE_AFTER_START', f'steps[{index}].wallet_state', 'CANCELLED',
                'This hold already started, so it cannot be released or replaced. Leave it unpaid.')
        self._require_approval(public, self.session_cap, index)
        amount = self.session_cap
        prior_reason = step['reason']
        prior_recovery = step['recovery_ms']
        replacement = self._hold(public, amount, f'replace-{index}-{public[:8]}', index)
        self._known_counterparties.add(public)
        replacement['replaced'] = True
        replacement['prior_reason'] = prior_reason
        replacement['prior_recovery_ms'] = prior_recovery
        self.steps[index - 1] = replacement
        return replacement['state']

    def propose(self, amount):
        """Refuse a widened allocation after the principal has narrowed the cap."""
        if amount > self.session_cap and amount <= self.policy['per_action']['credits']:
            raise FieldError(
                'PRINCIPAL_SPEND', 'spend', f'integer 1..{self.session_cap}',
                f'The principal narrowed the cap to {self.session_cap}. {amount} would widen it. '
                'The wallet per-action cap does not override the principal.')
        return self._intent(self.agents[0], amount, 'propose-probe')

    def override(self, spend):
        _positive(spend, 'spend')
        if self.grant_id is None:
            raise FieldError(
                'GRANT_MISSING', 'grant', 'a live access grant id',
                'Sign an access grant from the principal to the delegate before narrowing. This call does not submit.')
        if spend > self.principal_spend:
            raise FieldError(
                'PRINCIPAL_SPEND', 'spend', f'integer 1..{self.principal_spend}',
                f'{spend} would widen the principal cap {self.principal_spend}. The principal can only narrow.')
        counterparties = sorted({step['counterparty'] for step in self.steps})
        policy = principal.draft(
            self.principal_pub, self.delegate_pub, self.grant_id, self.permit_id, 'reliance.execute',
            self.domain, {'credits': spend}, INTENT_EXPIRES, ['AUTHORIZE'], [self.profile_id],
            counterparties, 10)
        signature = sign(self.principal_key, principal.LABEL, policy)
        verify(self.principal_pub, principal.LABEL, policy, signature)
        self.principal_spend = spend
        self.session_cap = spend
        probe = reliance.draft_intent(
            self.policy, self.delegate_pub, self.inner, _hid('effect', self.id, 'narrow-check'),
            _hid('request', self.id, 'narrow-check'), {'credits': spend}, 0, INTENT_EXPIRES,
            _hid('nonce', self.id, 'narrow-check'))
        narrowed = principal.reliance_narrows(self.policy, probe['intent'], {'credits': self.budget})
        row = {'spend': spend, 'submitted': False, 'execution_authorized': False,
               'narrows': narrowed['narrows'], 'widens_grant': narrowed['widens_grant']}
        self.override_log.append(row)
        return row

    def kill(self, index):
        step = self._step(index)
        agreement = {'held': True, 'state': 'BOUND'}
        if step['wallet_state'] == 'HELD' and step['state'] == 'PENDING':
            decision = principal.revoke_before_settlement(agreement, 'HELD')
            self.wallet.cancel(step['intent_id'])
            step['wallet_state'] = 'CANCELLED'
            step['state'] = 'FAILED'
            step['reason'] = 'KILLED'
            step['paid'] = 0
        else:
            decision = principal.revoke_before_settlement(agreement, None)
        return {'state': step['state'], 'paid': step['paid'], **decision}

    def dispute(self, index):
        step = self._step(index)
        step['state'] = 'DISPUTED'
        return step['state']

    def silence(self, index, *, timeout='RELEASE_IF_UNDECIDED', panel_missed=False, state=None,
                agreement=None, height=1):
        """Refund a silent step after the arbiter ladder. No prior panel case is required."""
        step = self._step(index)
        ladder = arbitration.ArbiterAdapter(
            self.resolver_pub, self.arbitrators, category='hire',
            exclude=(self.principal_pub, self.delegate_pub, step['counterparty'])).escalate(
                state=state if panel_missed else None,
                agreement=agreement if panel_missed else None,
                height=height, tid=step['id'])
        step['ladder'] = ladder['ladder']
        step['panel'] = ladder['panel']
        if timeout == 'HOLD_FOR_RESOLUTION':
            step['state'] = 'DISPUTED'
            return step['state']
        if step['wallet_state'] == 'HELD':
            self.wallet.cancel(step['intent_id'])
            step['wallet_state'] = 'CANCELLED'
        step['state'] = 'SETTLED'
        step['paid'] = 0
        step['silence_release'] = True
        return step['state']

    def settle(self):
        for step in self.steps:
            if step['state'] == 'DELIVERED':
                step['state'] = 'SETTLED'
                step['paid'] = step['allocation']
        return [step['state'] for step in self.steps]

    def principal_signed_offers(self):
        for step in self.steps:
            payload = reliance.intent_payload(step['envelope']['intent'])
            verify(self.delegate_pub, payload['label'], payload['body'], step['envelope']['signature'])
            try:
                verify(self.principal_pub, payload['label'], payload['body'], step['envelope']['signature'])
            except ValueError:
                continue
            return True
        return False

    def report(self):
        balances = self.wallet.inspect()['balances'] if self.wallet is not None else None
        observations = {}
        failures = {}
        plan_steps = []
        for index, step in enumerate(self.steps):
            expected = step['content_id'] or _hid('expected', step['id'])
            dependencies = [] if index == 0 else [self.steps[index - 1]['id']]
            plan_steps.append({
                'id': step['id'], 'purpose': self.task[:200], 'actor': step['counterparty'],
                'adapter': self.inner, 'dependencies': dependencies,
                'allocations': {'credits': max(1, step['allocation'])}, 'expected_output': expected,
                'deadline': INTENT_EXPIRES, 'fallback': 'Replace the agent or leave the step unpaid.',
            })
            if step['state'] in {'DELIVERED', 'SETTLED'} and step['preimage_verified'] and step['paid']:
                observations[step['id']] = step['content_id']
            if step['state'] == 'FAILED':
                failures[step['id']] = {'reason': step['reason'] or 'FAILED', 'recovery_ms': step['recovery_ms'] or 0}
        compiled = compile_plan(
            self.task, plan_steps, observations=observations, failures=failures,
            available=None if balances is None else {'credits': balances['credits']['available']})
        rows = []
        for step in self.steps:
            rows.append({
                'index': step['index'], 'counterparty': step['counterparty'], 'state': step['state'],
                'paid': step['paid'], 'allocation': step['allocation'], 'reason': step['reason'],
                'recovery_ms': step['recovery_ms'], 'preimage_verified': step['preimage_verified'],
                'content_id': step['content_id'], 'replaced': step['replaced'],
                'prior_reason': step.get('prior_reason'), 'prior_recovery_ms': step.get('prior_recovery_ms'),
                'silence_release': step['silence_release'], 'panel': step['panel'], 'ladder': step['ladder'],
            })
        legal_view = self.legal or {}
        return {
            'status': 'OPEN' if self.opened else 'UNOPENED',
            'id': getattr(self, 'id', None),
            'task': self.task,
            'budget': self.budget,
            'per_agent_cap': self.per_agent_cap,
            'session_cap': self.session_cap,
            'steps': rows,
            'balances': balances,
            'directory': {
                'organic': len((self.directory_result or {}).get('organic') or []),
                'paid_boosts_organic': (self.directory_result or {}).get('paid_boosts_organic'),
            },
            'draft': None if self.draft_document is None else {
                'template': self.draft_document['template'],
                'terms_hash': self.draft_document['terms_hash'],
                'team_size': self.draft_document['parameters'].get('team_size'),
                'per_agent': self.draft_document['parameters'].get('per_agent'),
                'ambiguities': [row['code'] for row in self.draft_document['ambiguities']],
            },
            'legal': {
                'delegation_authority': legal_view.get('delegation_authority'),
                'guarantee_collateral_in_draft': legal_view.get('guarantee_collateral'),
                'guarantee_collateral': 'RESERVED' if self.steps else 'NOT_RESERVED',
                'execution_authorized': False,
            },
            'evidence': None if self.evidence is None else {
                'pinned_at': self.evidence['pinned_at'], 'submitted': self.evidence['submitted'],
            },
            'escrow': {'count': len(self.escrows), 'moved': False, 'funded': False},
            'override_log': list(self.override_log),
            'principal_signed_offers': self.principal_signed_offers() if self.steps else False,
            'execution_authorized': False,
            'ledger_touched': False,
            'keys': 'DISPOSABLE',
            'plan': {'id': compiled['id'], 'execution_authorized': compiled['execution_authorized'],
                     'statuses': [row['status'] for row in compiled['steps']]},
            'reservation': 'MandateWallet.reserve',
            'approval_policy': self.approval_policy,
        }


def hire(task, budget, per_agent_cap, sentence=None, **kwargs):
    """Open a team and return the session. The caller closes it."""
    session = Session(task, budget, per_agent_cap, sentence, **kwargs)
    return session.open()


def orchestrate(task='Research the named question', budget=800, per_agent_cap=100,
                sentence='Hire eight agents for 100 credits each.', as_of='2026-10-22',
                approval_policy='NEVER_WITHIN_SCOPE', decisions=None, board=None, arbitrators=None, approver=None):
    """The tester scenario: eight agents, a real cap, one failure, one replacement."""
    session = Session(task, budget, per_agent_cap, sentence, as_of=as_of, disposable=True,
                      approval_policy=approval_policy, decisions=decisions, board=board,
                      arbitrators=arbitrators, approver=approver)
    try:
        session.open()
        if session.directory_result['organic'].__len__() != 8 or session.directory_result['paid_boosts_organic']:
            raise FieldError('DIRECTORY_QUERY', 'directory.organic', '8 organic profiles',
                             'Search returned a boosted or short list. Organic rank must ignore spend.')
        if session.wallet.inspect()['balances']['credits']['available'] != 0:
            raise FieldError('RELIANCE_BUDGET_EXCEEDED', 'balances.credits.available', '0',
                             'Eight reservations of 100 should consume a budget of 800.')
        try:
            session.refuse_over_cap(500)
            refused = None
        except FieldError as exc:
            refused = exc
        if refused is None or refused.code != 'RELIANCE_PER_ACTION' or refused.issues[0]['path'] != 'allocations.credits':
            raise FieldError('RELIANCE_PER_ACTION', 'allocations.credits', 'a refusal naming 500 and 100',
                             'A 500 request against a 100 cap must be refused before reserve.')
        if '500' not in refused.next_action or '100' not in refused.next_action:
            raise FieldError('RELIANCE_PER_ACTION', 'allocations.credits', 'both amounts in the next step',
                             'Name the requested amount and the cap in the refusal.')
        if session.wallet.inspect()['balances']['credits']['available'] != 0:
            raise FieldError('RELIANCE_BUDGET_EXCEEDED', 'balances', 'unchanged after the refusal',
                             'The over-cap refusal must not move a reservation.')
        first = b'step-1-bytes'
        second = b'step-2-bytes'
        third = b'step-3-bytes'
        session.dispatch(1)
        session.deliver(1, first)
        session.dispatch(2)
        session.deliver(2, second, prior=first)
        session.dispatch(3)
        try:
            session.dispatch(4)
            early = None
        except FieldError as exc:
            early = exc
        if early is None or early.path != 'steps[4].state' or session.steps[3]['state'] != 'PENDING':
            raise FieldError(
                'WAITING_FOR_EVIDENCE', 'steps[4].state', 'PENDING',
                'Dispatching step 4 before step 3 is delivered must be refused, and step 4 must stay PENDING.')
        session.deliver(3, third, prior=second)
        session.fail(4, 'agent stopped', 120000)
        if session.steps[3]['paid'] != 0 or session.steps[3]['recovery_ms'] != 120000:
            raise FieldError('RELIANCE_FAILURE', 'steps[4].paid', '0', 'A failed step is not paid.')
        if session.wallet.inspect()['balances']['credits']['available'] != 100:
            raise FieldError('RELIANCE_BUDGET_EXCEEDED', 'balances.credits.available', '100',
                             'Cancelling the unsent step should return its 100 credits.')
        session.override(40)
        try:
            session.override(200)
            widened = False
        except FieldError as exc:
            widened = exc.code == 'PRINCIPAL_SPEND' and exc.path == 'spend'
        if not widened:
            raise FieldError('PRINCIPAL_SPEND', 'spend', 'a refusal', 'A principal override cannot widen the cap.')
        replacement = _key('replacement')
        session.replace(4, public_key(replacement))
        if session.steps[3]['state'] != 'PENDING' or session.steps[3]['allocation'] != 40:
            raise FieldError('PRINCIPAL_SPEND', 'steps[4].allocation', '40',
                             'The replacement must reserve the narrowed cap, not the old one.')
        try:
            session.propose(100)
            proposed = False
        except FieldError as exc:
            proposed = exc.code == 'PRINCIPAL_SPEND'
        if not proposed:
            raise FieldError('PRINCIPAL_SPEND', 'spend', 'a refusal of 100 after a narrow to 40',
                             'The session cap, not only the wallet cap, must refuse 100.')
        session.dispute(5)
        session.silence(5)
        ladder = session.steps[4]['ladder'] or []
        if not session.steps[4]['silence_release'] or session.steps[4]['panel'] != 'NOT_SEATED':
            raise FieldError('SILENCE_NOT_DUE', 'steps[5].panel', 'NOT_SEATED',
                             'With no registry the ladder asks the chosen arbiter, recruits nobody, and refunds.')
        if [row['rung'] for row in ladder] != ['chosen_arbiter', 'protocol_panel']:
            raise FieldError('SILENCE_NOT_DUE', 'steps[5].ladder', 'chosen_arbiter then protocol_panel',
                             'A silence refund escalates before it releases the hold.')
        if ladder[0]['outcome'] != 'SILENT' or ladder[1]['outcome'] != 'NOT_SEATED':
            raise FieldError('SILENCE_NOT_DUE', 'steps[5].ladder', 'SILENT then NOT_SEATED',
                             'The chosen arbiter was silent and no protocol panel was seated.')
        if session.steps[4]['paid'] != 0:
            raise FieldError('RELIANCE_FAILURE', 'steps[5].paid', '0', 'A silence refund pays nothing.')
        session.kill(8)
        if session.steps[7]['reason'] != 'KILLED' or session.steps[7]['paid'] != 0:
            raise FieldError('GRANT_MISSING', 'steps[8].reason', 'KILLED', 'Kill releases a PENDING step and pays nothing.')
        session.deliver(6, b'step-6-bytes', prior=b'not-the-previous-artifact')
        if session.steps[5]['state'] != 'FAILED' or session.steps[5]['paid'] != 0:
            raise FieldError('EVIDENCE_PREIMAGE', 'steps[6].state', 'FAILED',
                             'A bad prior fails that step only.')
        if session.steps[2]['state'] != 'DELIVERED':
            raise FieldError('EVIDENCE_PREIMAGE', 'steps[3].state', 'DELIVERED',
                             'A bad prior on a later step must not fail the plan.')
        try:
            session.deliver(7, {'hash': 'abc'})
            hashed = False
        except FieldError as exc:
            hashed = exc.code == 'EVIDENCE_PREIMAGE' and exc.path == 'artifact'
        if not hashed or session.steps[6]['state'] != 'PENDING':
            raise FieldError('EVIDENCE_PREIMAGE', 'artifact', 'a field error and an unchanged step',
                             'A hash without bytes is refused and does not fail the step.')
        session.settle()
        for index in (1, 2, 3):
            step = session.steps[index - 1]
            if step['state'] != 'SETTLED' or step['paid'] != 100:
                raise FieldError('RELIANCE_FAILURE', f'steps[{index}].paid', '100',
                                 'A delivered step settles at its reservation.')
        if session.principal_signed_offers():
            raise FieldError('PRINCIPAL_AUTHORITY', 'signature', 'the delegate',
                             'The principal signed an offer. Offers must use the delegate key.')
        report = session.report()
        report['status'] = 'PASS'
        report['over_cap'] = {'code': refused.code, 'path': refused.path, 'next_action': refused.next_action}
        report['states'] = [step['state'] for step in report['steps']]
        return report
    finally:
        session.close()
