"""Order by use: a private PageRank over actions used together in honoured deals.

The order by nature (the job map and the levels) is fixed in advance. Once a
host has kept promises, this second order ranks the actions inside each job by
what actually helped, and suggests what usually comes next. It is computed
locally from this host's own history, with no telemetry, from two kinds of
verified record:

* settled work orders in which this host signed one side and the worker was
  paid in full (PAY_COUNTERPARTY), checked offline from their signatures; and
* dual-signed feature-use traces bound to FULFILLED outcome receipts, admitted
  under feature_use_rank's owner scope, cluster caps and conflict rules.

The steps of an honoured deal are its successful calls: each one left a signed
record. Raw calls, clicks, views and installs are not inputs at all. Failed,
refunded, split, disputed-open or unsettled deals count nothing. One deal counts
once however often it is replayed, an action counts once per deal, and one
counterparty supports at most ``per_counterparty_cap`` deals. Deals in which
this host holds both sides count nothing. The walk is feature_use_rank's integer
PageRank with damping, over actions used together or one after the other, plus
the work-order state machine's declared dependencies.

The rank orders lists and suggestions only. It never changes authority, a
signed meaning, the kind a verb uses by default, or whether an action exists:
unused actions stay listed, dormant, after the used ones in their order by
nature. Without history the order by nature comes back unchanged.
"""
import argparse
import json
from pathlib import Path

from . import action_jobs
from .errors import need

FORMAT = 'aap-action-use-rank/0.1'
MAX_ENVELOPES = 4096
MAX_TRACES = 256
MAX_NODES = 256
MAX_INPUT = 2097152
ASSURANCE = 'OWN_VERIFIED_HONOURED_HISTORY_NOT_WORLD_TRUTH_OR_SYBIL_PROOF'
PROPOSE, ACCEPT, DELIVER = 'work:covenant_propose', 'work:covenant_accept', 'work:covenant_deliver'
DISPUTE, DECIDE, SETTLE = 'work:covenant_dispute', 'work:covenant_decide', 'work:covenant_settle'
# Declared dependencies: the work-order state machine (PROPOSED, BOUND, DELIVERED, DISPUTED, DECIDED).
DEPENDENCIES = ((PROPOSE, ACCEPT), (ACCEPT, DELIVER), (ACCEPT, DISPUTE), (DELIVER, SETTLE),
                (DELIVER, DISPUTE), (DISPUTE, DECIDE), (DECIDE, SETTLE))
FLAGS = {'private': True, 'telemetry': False, 'authority_changed': False, 'meaning_changed': False,
         'availability_changed': False, 'default_kinds_changed': False, 'execution_authorized': False}


def describe():
    return {'format': FORMAT, 'maturity': 'experimental',
            'counts': ['SETTLED_WORK_ORDER_PAID_IN_FULL_WITH_THIS_HOST_ON_ONE_SIDE',
                       'DUAL_SIGNED_TRACE_OF_A_FULFILLED_OUTCOME_UNDER_OWNER_SCOPE'],
            'never_counts': ['RAW_CALLS', 'CLICKS', 'VIEWS', 'INSTALLS', 'FAILED_OR_REFUNDED_WORK',
                             'UNSETTLED_OR_DISPUTED_WORK', 'SELF_DEALING', 'OTHER_HOSTS_DEALS'],
            'walk': 'INTEGER_PAGERANK_WITH_DAMPING_OVER_CO_USE_SEQUENCE_AND_DECLARED_DEPENDENCIES',
            'without_history': 'ORDER_BY_NATURE', 'assurance': ASSURANCE, **FLAGS}


def _sides(parties):
    def keys(names):
        return {parties[name] for name in names if type(parties.get(name)) is str}
    return keys(('principal', 'agent')), keys(('counterparty', 'executor'))


def _settled_action(envelope):
    settlement = envelope.get('settlement')
    if type(settlement) is not dict:
        return None
    if envelope.get('profile') == 'covenant-bilateral/0.2':
        body = settlement.get('body')
        return body.get('action') if type(body) is dict else None
    return settlement.get('action')


def _steps(envelope):
    steps = [PROPOSE, ACCEPT]
    if envelope.get('deliveries'):
        steps.append(DELIVER)
    dispute = envelope.get('dispute')
    if type(dispute) is dict and dispute:
        steps.append(DISPUTE)
        if dispute.get('decision') or dispute.get('appeal'):
            steps.append(DECIDE)
    steps.append(SETTLE)
    return steps


def envelope_usage(envelope, own_keys):
    """('usage', row) for an honoured deal of this host, else ('reject', reason)."""
    from .envelope import escrow_id, verify
    if type(envelope) is not dict or type(envelope.get('parties')) is not dict:
        return 'reject', 'RANK_NOT_A_WORK_ORDER'
    if _settled_action(envelope) != 'PAY_COUNTERPARTY':
        # Cheap check first: unsettled, refunded or split work is never verified for rank.
        return 'reject', 'RANK_NOT_HONOURED'
    try:
        report = verify(envelope)
        agreement = escrow_id(envelope)
    except (ValueError, KeyError, TypeError):
        return 'reject', 'RANK_INVALID_RECORD'
    if report.get('verdict') != 'SETTLED':
        return 'reject', 'RANK_NOT_HONOURED' if report.get('ok') else 'RANK_INVALID_RECORD'
    payer, worker = _sides(envelope['parties'])
    mine_payer, mine_worker = payer & own_keys, worker & own_keys
    if mine_payer and mine_worker:
        return 'reject', 'RANK_SELF_DEALING'
    if not (mine_payer or mine_worker):
        return 'reject', 'RANK_NOT_OWN_HISTORY'
    other = sorted(worker if mine_payer else payer)
    if not other:
        return 'reject', 'RANK_INVALID_RECORD'
    return 'usage', {'agreement': agreement, 'counterparty': other[0], 'actions': _steps(envelope),
                     'evidence': 'SETTLED_WORK_ORDER'}


def _feature_action(feature, routes):
    """Map a trace feature to one catalogued action id; anything else is dropped."""
    if feature.startswith('extension:action:'):
        ident = feature[len('extension:action:'):]
        return ident if action_jobs.verb_of(ident) else None
    if feature.startswith('extension:route:'):
        route = routes.get(feature[len('extension:route:'):])
        ident = None if route is None else 'tool:' + route['native_tool'] + '.' + route['action']
        return ident if action_jobs.verb_of(ident) else None
    if feature.startswith('tool:'):
        if action_jobs.verb_of(feature):
            return feature
        members = action_jobs.tool_actions(feature[len('tool:'):])
        return members[0] if len(members) == 1 else None
    return None


def _trace_usages(rows, scope, rejected):
    from covenant_chain import feature_use_rank as use
    need(type(scope) is dict and set(scope) <= {'owner', 'context', 'contacts', 'now', 'max_age', 'per_cluster_cap'}
         and {'owner', 'context', 'contacts', 'now', 'max_age'} <= set(scope), 'RANK_TRACE_SCOPE')
    need(type(rows) is list and len(rows) <= MAX_TRACES, 'RANK_RECORDS')
    parsed, features = [], {}
    for row in rows:
        try:
            source, trace, _ = use._trace(row)
        except (ValueError, KeyError, TypeError):
            continue  # feature_use_rank counts the same rejection below
        parsed.append((source, trace))
        for name in trace['features']:
            features[name] = {'level': 'ORGANON', 'core': False}
    if not features:
        if rows:
            rejected['USE_MALFORMED'] = rejected.get('USE_MALFORMED', 0) + len(rows)
        return []
    need(len(features) <= use.MAX_FEATURES, 'RANK_CAPACITY')
    admitted = use.rank(rows, features, **scope)
    for reason, count in admitted['rejected'].items():
        rejected[reason] = rejected.get(reason, 0) + count
    accepted = set(admitted['accepted_agreements'])
    from covenant_chain.onboarding import task_catalog
    routes = {route['id']: route for route in task_catalog()['routes']}
    usages = []
    for source, trace in parsed:
        if source['agreement'] not in accepted:
            continue
        accepted.discard(source['agreement'])
        actions = [ident for ident in (_feature_action(name, routes) for name in trace['features']) if ident]
        other = sorted(key for key in source['parties'] if key != scope['owner'])
        if actions and other:
            usages.append({'agreement': source['agreement'], 'counterparty': other[0], 'actions': actions,
                           'evidence': 'DUAL_SIGNED_FULFILLED_TRACE'})
    return usages


def _count(rejected, reason):
    rejected[reason] = rejected.get(reason, 0) + 1


def _from_usages(usages, rejected, per_counterparty_cap, damping_bps, iterations):
    from covenant_chain.feature_use_rank import _walk
    need(type(per_counterparty_cap) is int and 1 <= per_counterparty_cap <= 16, 'RANK_CAP')
    need(type(damping_bps) is int and 0 <= damping_bps <= 9500, 'RANK_DAMPING')
    need(type(iterations) is int and 1 <= iterations <= 100, 'RANK_ITERATIONS')
    deals = {}
    for usage in usages:
        if usage['agreement'] in deals:
            _count(rejected, 'RANK_DUPLICATE_AGREEMENT')
            continue
        deals[usage['agreement']] = usage
    per, accepted = {}, []
    for agreement in sorted(deals):
        usage = deals[agreement]
        if per.get(usage['counterparty'], 0) >= per_counterparty_cap:
            _count(rejected, 'RANK_COUNTERPARTY_CAP')
            continue
        per[usage['counterparty']] = per.get(usage['counterparty'], 0) + 1
        # An action counts once per deal; first use keeps its place in the sequence.
        accepted.append(list(dict.fromkeys(usage['actions'])))
    support, edges, transitions = {}, {}, {}
    for actions in accepted:
        for ident in actions:
            support[ident] = support.get(ident, 0) + 1
        for a in actions:
            for b in actions:
                if a != b:
                    edges[a, b] = edges.get((a, b), 0) + 1
        for a, b in zip(actions, actions[1:]):
            edges[a, b] = edges.get((a, b), 0) + 1
            transitions.setdefault(a, {})[b] = transitions.get(a, {}).get(b, 0) + 1
    nodes = sorted(support, key=lambda ident: (-support[ident], action_jobs.nature_key(ident)))[:MAX_NODES]
    if len(support) > MAX_NODES:
        rejected['RANK_NODE_CAPACITY'] = len(support) - MAX_NODES
    nodes = sorted(nodes)
    mass = {}
    if nodes:
        for a, b in DEPENDENCIES:
            if a in support and b in support:
                edges[a, b] = edges.get((a, b), 0) + 1
        adjacency = {ident: {} for ident in nodes}
        for (a, b), weight in sorted(edges.items()):
            if a in adjacency and b in adjacency:
                adjacency[a][b] = weight
        mass = _walk(nodes, adjacency, {ident: support[ident] for ident in nodes}, damping_bps, iterations)
    return {'format': FORMAT, 'maturity': 'experimental', 'order': 'USE' if mass else 'NATURE',
            'honoured_agreements': len(accepted), 'counterparties': len(per), 'damping_bps': damping_bps,
            'per_counterparty_cap': per_counterparty_cap,
            'actions': {ident: {'rank_ppb': mass[ident], 'supported_agreements': support[ident]} for ident in nodes},
            'transitions': {a: dict(sorted(row.items())) for a, row in sorted(transitions.items())
                            if a in mass},
            'rejected': dict(sorted(rejected.items())), 'assurance': ASSURANCE, **FLAGS}


def rank(*, envelopes=(), own_keys=(), traces=(), trace_scope=None, per_counterparty_cap=4,
         damping_bps=8500, iterations=40):
    """Rank actions from this host's own verified history; nothing else is an input."""
    envelopes, traces = list(envelopes), list(traces)
    need(len(envelopes) <= MAX_ENVELOPES, 'RANK_RECORDS')
    own = set(own_keys)
    need(all(type(key) is str and len(key) == 64 for key in own) and len(own) <= 8, 'RANK_OWN_KEYS')
    rejected, usages = {}, []
    for envelope in envelopes:
        status, value = envelope_usage(envelope, own)
        if status == 'usage':
            usages.append(value)
        else:
            _count(rejected, value)
    if traces:
        usages.extend(_trace_usages(traces, trace_scope, rejected))
    return _from_usages(usages, rejected, per_counterparty_cap, damping_bps, iterations)


def local(store, own_keys, memo=None):
    """Rank from the work orders this host retained. ``memo`` keeps per-CID verdicts between calls.

    Each signed version of one deal is a separate blob; the agreement id unites
    them, so a deal counts once and its earlier versions are not refusals.
    """
    from .codec import loads
    from .envelope import escrow_id
    own = set(own_keys)
    memo = {} if memo is None else memo
    if len(memo) > 2 * MAX_ENVELOPES:
        memo.clear()
    usages, others = {}, {}
    for cid, blob in store.items(limit=MAX_ENVELOPES):
        if cid not in memo:
            try:
                value = loads(blob)
            except (ValueError, TypeError, UnicodeError):
                value = None
            status, found = envelope_usage(value, own)
            try:
                agreement = found['agreement'] if status == 'usage' else escrow_id(value)
            except (ValueError, KeyError, TypeError):
                agreement = None
            memo[cid] = (status, found, agreement)
        status, found, agreement = memo[cid]
        if status == 'usage':
            usages.setdefault(agreement, found)
        elif found != 'RANK_NOT_A_WORK_ORDER':
            others.setdefault(agreement or cid, found)
    rejected = {}
    for agreement, reason in sorted(others.items()):
        if agreement not in usages:
            _count(rejected, reason)
    return _from_usages([usages[agreement] for agreement in sorted(usages)], rejected, 4, 8500, 40)


def order(idents, ranking=None, rows=None):
    """Used actions by rank, then dormant ones by nature. The set is never changed."""
    natural = action_jobs.by_nature(list(idents), rows)
    used = (ranking or {}).get('actions') or {}
    if not used:
        return natural
    place = {ident: position for position, ident in enumerate(natural)}
    ranked = sorted((i for i in natural if i in used), key=lambda i: (-used[i]['rank_ppb'], place[i]))
    return ranked + [i for i in natural if i not in used]


def suggest_next(ident, ranking=None, rows=None, limit=3):
    """What usually followed this action in honoured deals, then what follows by nature."""
    need(type(limit) is int and 1 <= limit <= 8, 'RANK_LIMIT')
    rows = rows or {}
    used = (ranking or {}).get('actions') or {}
    follows = ((ranking or {}).get('transitions') or {}).get(ident) or {}
    observed = sorted(follows, key=lambda b: (-follows[b], -used.get(b, {}).get('rank_ppb', 0),
                                              action_jobs.nature_key(b, rows.get(b))))
    out = [{'id': b, 'why': 'USE'} for b in observed if action_jobs.verb_of(b)]
    for b in action_jobs.nature_next(ident, rows):
        if b not in follows:
            out.append({'id': b, 'why': 'NATURE'})
    for row in out:
        row.update({'verb': action_jobs.verb_of(row['id']), 'kind': action_jobs.kind_of(row['id'])})
    return out[:limit]


def _adopted(ranking):
    return type(ranking) is dict and bool(ranking.get('actions'))


def rerank_find(result, ranking):
    """Within each job of a find answer, kinds by use. Without adopted history: unchanged."""
    if not _adopted(ranking) or type(result) is not dict or type(result.get('jobs')) is not list:
        return result
    used = ranking['actions']
    def weight(verb, kind):
        ident = action_jobs.kinds(verb).get(kind)
        return -used.get(ident, {}).get('rank_ppb', 0)
    jobs = []
    for job in result['jobs']:
        verbs = []
        for row in job['verbs']:
            kinds = sorted(row['kinds'], key=lambda kind: weight(row['verb'], kind))
            verbs.append({**row, 'kinds': kinds})
        jobs.append({**job, 'verbs': verbs})
    return {**result, 'jobs': jobs, 'order': 'USE'}


def rerank_explain(result, ranking):
    """A verb card in order by use. Rows, refusals and other replies are unchanged."""
    if not _adopted(ranking) or type(result) is not dict or type(result.get('kinds')) is not list:
        return result
    from .navigate import verb_card
    return verb_card(result['verb'], ranking)


def rerank_next(result, ranking):
    """Legal next actions in order by use. The legal set and each row are unchanged."""
    if not _adopted(ranking) or type(result) is not dict or type(result.get('actions')) is not list:
        return result
    used = ranking['actions']
    place = {row['id']: position for position, row in enumerate(result['actions'])}
    ordered = sorted(result['actions'], key=lambda row: (-used.get(row['id'], {}).get('rank_ppb', 0), place[row['id']]))
    return {**result, 'actions': ordered, 'order': 'USE'}


def main(argv=None):
    parser = argparse.ArgumentParser(description='Inspect the private order by use from owner-local history.')
    parser.add_argument('--input', type=Path, help='Owner-local JSON: envelopes, own_keys, optional traces and '
                                                  'trace_scope. At most 2 MiB; never fetched.')
    args = parser.parse_args(argv)
    if args.input is None:
        result = describe()
    else:
        with args.input.open('rb') as stream:
            raw = stream.read(MAX_INPUT + 1)
        need(len(raw) <= MAX_INPUT, 'RANK_INPUT_SIZE')
        from .codec import loads
        body = loads(raw)
        need(type(body) is dict and set(body) <= {'envelopes', 'own_keys', 'traces', 'trace_scope'}, 'RANK_INPUT')
        result = rank(**body)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
