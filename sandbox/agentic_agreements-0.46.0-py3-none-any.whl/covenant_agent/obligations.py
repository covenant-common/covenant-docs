"""Read-only purchase and obligation summary over one host's own records.

One call answers "what have I bought or agreed, and what do I currently owe or
am I owed?" for one party key. Every figure carries its basis:

* ``OBSERVED`` is read now from the settlement provider the owner installed on
  this host (escrow rows and receipts). It is still a local reference ledger,
  not an external payment.
* ``CLAIMED`` comes from signed envelopes this host retains or its provider
  registered. A signature is a statement by a key, not proof of delivery,
  quality, freshness or legal effect.

Nonmonetary promises written in a document are never extracted or judged.
Agreements known only to other hosts are absent. Nothing is signed, moved,
registered or submitted.
"""
from copy import deepcopy
import hashlib

from .codec import canonical, loads
from .errors import need

VERSION = 'covenant-obligation-summary/0.1'
PROFILES = ('covenant-bilateral/0.1', 'covenant-bilateral/0.2')
PORTABLE_PROFILE = 'covenant-bilateral/0.3'
RANK = {'PROPOSED': 1, 'BOUND': 2, 'DELIVERED': 3, 'DISPUTED': 4, 'DECIDED': 5, 'SETTLED': 6, 'RELEASED': 6}
ROLE_ORDER = ('principal', 'agent', 'counterparty', 'executor', 'resolver', 'appeal_resolver')
OPEN_STAGES = ('PROPOSED', 'BOUND', 'DELIVERED', 'DISPUTED', 'DECIDED')


def _hex(value):
    return type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def _identity(envelope):
    if envelope['profile'] == 'covenant-bilateral/0.2':
        from .bilateral_v2 import identifier
        return identifier(envelope)
    from .envelope import escrow_id
    return escrow_id(envelope)


def _verdict(envelope):
    from .envelope import verify
    try:
        return verify(envelope)
    except (ValueError, TypeError, KeyError):
        return {'ok': False, 'verdict': 'INVALID'}


def _profile(value):
    if type(value) is not dict:
        return None
    body = value.get('body')
    return value.get('profile') or (body.get('profile') if type(body) is dict else None)


def envelopes_from_store(store, limit=4096):
    """Retained bilateral envelopes and portable orders; other blobs are skipped."""
    found = []
    for _cid, blob in store.items(limit=limit):
        if not blob.startswith(b'{'):
            continue
        try:
            value = loads(blob)
        except ValueError:
            continue
        if _profile(value) in (*PROFILES, PORTABLE_PROFILE):
            found.append(value)
    return found


def _paid(envelope):
    settlement = envelope.get('settlement')
    if settlement is None:
        return None
    if envelope['profile'] == 'covenant-bilateral/0.2':
        return settlement['body']['paid_amount']
    return envelope['terms']['quantity'] if settlement.get('action') == 'PAY_COUNTERPARTY' else 0


def _signed_claims(envelope, stage):
    dispute = envelope.get('dispute')
    decision = None
    if dispute:
        chosen = dispute.get('appeal') or dispute.get('decision')
        if chosen:
            body = chosen.get('body', chosen)
            decision = {'result': body.get('result'), 'paid_amount': body.get('paid_amount'),
                        'stage': body.get('stage', 'PRIMARY')}
    paid = _paid(envelope)
    quantity = envelope['terms']['quantity']
    return {'stage': stage, 'assents': len(envelope.get('assents') or []),
            'deliveries': [{'content_hash': d['content_hash'], 'content_cid': d.get('content_cid'),
                            'signer': d.get('signer'), 'performance_verified': False}
                           for d in envelope.get('deliveries') or []],
            'dispute_open': bool(dispute) and decision is None,
            'decision': decision,
            'settlement': None if paid is None else {'paid_amount': paid, 'refunded_amount': quantity - paid},
            'basis': 'CLAIMED: SIGNED_ENVELOPE_RETAINED_LOCALLY; NOT_FRESHNESS_OR_WORLD_TRUTH'}


def _observe(ledger, effect, envelope, provider_row):
    """Escrow and receipt as the installed provider reports them now."""
    if provider_row is not None:
        escrow, receipt = provider_row['escrow'], provider_row['receipt']
    elif ledger is not None and hasattr(ledger, 'escrow') and hasattr(ledger, 'receipts'):
        escrow, receipt = deepcopy(ledger.escrow.get(effect)), deepcopy(ledger.receipts.get(effect))
    else:
        return {'status': 'NO_PROVIDER_INSTALLED', 'escrow': None, 'receipt_matches_signed_settlement': None,
                'basis': 'OBSERVED: NOTHING; THIS_HOST_HAS_NO_OWNER_INSTALLED_SETTLEMENT_PROVIDER'}
    if escrow is None and receipt is None:
        status = 'NOT_OBSERVED'
    else:
        status = 'OBSERVED'
    matches = None
    if receipt is not None:
        matches = envelope.get('settlement') is not None and canonical(receipt) == canonical(envelope['settlement'])
    row = None
    if escrow is not None:
        row = {'status': escrow.get('status'), 'amount': escrow.get('amount'), 'unit': escrow.get('unit'),
               'payer': escrow.get('payer'), 'payee': escrow.get('payee'),
               'paid_amount': escrow.get('paid_amount'), 'refunded_amount': escrow.get('refunded_amount')}
        if row['paid_amount'] is None and row['status'] in ('PAID', 'REFUNDED'):
            row['paid_amount'] = row['amount'] if row['status'] == 'PAID' else 0
            row['refunded_amount'] = row['amount'] - row['paid_amount']
    return {'status': status, 'escrow': row, 'receipt_matches_signed_settlement': matches,
            'basis': 'OBSERVED: OWNER_INSTALLED_LOCAL_REFERENCE_PROVIDER; NOT_EXTERNAL_PAYMENT'}


def _duties(party_roles, envelope, stage, as_of):
    """Next protocol duties implied by signed terms and stage, never by prose."""
    deadline = envelope['terms']['deadline']
    late = as_of is not None and as_of > deadline
    duties = []
    seller = {'counterparty', 'executor'} & set(party_roles)
    buyer = {'principal', 'agent'} & set(party_roles)
    if stage == 'PROPOSED' and 'counterparty' in party_roles:
        duties.append({'duty': 'ASSENT_DECISION', 'owed_by': 'THIS_PARTY', 'detail': 'Accept the exact terms or decline; nothing binds until then.'})
    if stage == 'PROPOSED' and buyer:
        duties.append({'duty': 'AWAITING_COUNTERPARTY_ASSENT', 'owed_by': 'COUNTERPARTY', 'detail': 'No money is committed by a one-sided proposal.'})
    if stage == 'BOUND' and seller:
        duties.append({'duty': 'DELIVERY_DEADLINE_PASSED' if late else 'DELIVERY_DUE', 'owed_by': 'THIS_PARTY', 'deadline': deadline})
    if stage == 'BOUND' and buyer:
        duties.append({'duty': 'AWAITING_DELIVERY', 'owed_by': 'COUNTERPARTY', 'deadline': deadline})
    if stage == 'DELIVERED' and buyer:
        duties.append({'duty': 'RELEASE_OR_DISPUTE_DECISION', 'owed_by': 'THIS_PARTY', 'deadline': deadline})
    if stage == 'DELIVERED' and seller:
        duties.append({'duty': 'AWAITING_RELEASE_OR_DISPUTE', 'owed_by': 'COUNTERPARTY', 'deadline': deadline})
    if stage == 'DISPUTED':
        owner = 'THIS_PARTY' if {'resolver', 'appeal_resolver'} & set(party_roles) else 'RESOLVER'
        duties.append({'duty': 'DECISION_DUE', 'owed_by': owner})
    if stage == 'DECIDED':
        duties.append({'duty': 'SETTLEMENT_AFTER_APPEAL_WINDOW', 'owed_by': 'ANY_AUTHORIZED_SETTLER'})
    for duty in duties:
        duty['basis'] = 'CLAIMED: SIGNED_TERMS_AND_STAGE; PERFORMANCE_NOT_VERIFIED'
    return duties


def _money(party_roles, envelope, stage, observed):
    """Per-agreement money from this party's side, with observed and claimed kept apart."""
    quantity = envelope['terms']['quantity']
    unit = envelope['terms']['unit']
    # Funds leave the principal's account; an agent signing under a mandate is not the payer.
    payer = 'principal' in party_roles
    payee = 'counterparty' in party_roles
    claimed = {'payable_pending': 0, 'receivable_pending': 0, 'paid': 0, 'received': 0, 'refunded': 0}
    paid = _paid(envelope)
    if stage in ('BOUND', 'DELIVERED', 'DISPUTED', 'DECIDED'):
        if payer:
            claimed['payable_pending'] = quantity
        if payee:
            claimed['receivable_pending'] = quantity
    elif paid is not None:
        if payer:
            claimed['paid'], claimed['refunded'] = paid, quantity - paid
        if payee:
            claimed['received'] = paid
    seen = {'held_in_escrow': 0, 'paid': 0, 'received': 0, 'refunded': 0}
    escrow = observed.get('escrow')
    if escrow is not None:
        if escrow['status'] == 'HELD' and payer:
            seen['held_in_escrow'] = escrow['amount']
        if escrow['paid_amount'] is not None:
            if payer:
                seen['paid'], seen['refunded'] = escrow['paid_amount'], escrow['refunded_amount']
            if payee:
                seen['received'] = escrow['paid_amount']
    return {'unit': unit, 'quantity': quantity, 'claimed': claimed,
            'observed': seen if observed['status'] != 'NO_PROVIDER_INSTALLED' else None}


def _portable(order, party):
    """Project verified signatures and event claims; no settlement adapter mapping."""
    from . import open_work
    checked = open_work.inspect(order, order['id'])
    body, terms = order['body'], order['body']['terms']
    roles = [role for role in ('customer', 'provider') if body[role] == party]
    if not roles:
        return None
    stage = checked['status']
    quantity = terms['quantity']
    claimed = {'payable_pending': quantity if stage == 'BOUND' and 'customer' in roles else 0,
               'receivable_pending': quantity if stage == 'BOUND' and 'provider' in roles else 0,
               'paid': 0, 'received': 0, 'refunded': 0}
    events = [{'action': e['body']['action'], 'evidence': e['body']['evidence'],
               'claimed_at': e['body']['at'], 'signer': e['signer'],
               'performance_verified': False} for e in order['events']]
    return {'agreement': order['id'], 'profile': PORTABLE_PROFILE, 'roles': roles,
            'side': 'BUYER' if 'customer' in roles else 'SELLER',
            'counterparties': {r: body[r] for r in ('customer', 'provider') if body[r] != party},
            'terms': {'quantity': quantity, 'unit': terms['payment']['unit'],
                      'rail': terms['payment']['identifier'], 'deadline': terms['deadline'],
                      'task_hash': hashlib.sha256(terms['task'].encode('utf-8')).hexdigest()},
            'signed': {'stage': stage, 'assents': len(checked['approved']), 'events': events,
                       'head': checked['head'],
                       'basis': 'UNSIGNED_PORTABLE_PROPOSAL; NO_ASSENT' if not checked['approved'] else
                                'CLAIMED: PARTIAL_PORTABLE_ASSENT; NOT_MUTUALLY_ADOPTED' if stage=='PROPOSED' else
                                'CLAIMED: EXACT_PORTABLE_SIGNATURES; NO_EVENT_PROVES_PERFORMANCE_OR_PAYMENT'},
            'provider': {'status': 'UNSUPPORTED_PROFILE_OBSERVATION', 'escrow': None,
                         'receipt_matches_signed_settlement': None,
                         'basis': 'NO_PORTABLE_PAYMENT_OBSERVER_ADOPTED_BY_THIS_SUMMARY'},
            'money': {'unit': terms['payment']['unit'], 'quantity': quantity, 'claimed': claimed,
                      'observed': None, 'basis': 'DECLARED_PRICE; PAYMENT_CLAIMS_DO_NOT_REDUCE_PENDING_AMOUNT'},
            'protocol_duties': [{'duty': 'REVIEW_PORTABLE_PERFORMANCE_AND_PAYMENT' if stage == 'BOUND' else 'ASSENT_DECISION',
                                 'owed_by': 'UNKNOWN', 'deadline': terms['deadline'],
                                 'basis': 'SIGNED_TERMS; EVENT_CLAIMS_DO_NOT_DISCHARGE_DUTIES'}],
            'document_obligations': 'UNASSESSED_PROSE; PORTABLE_TASK_NOT_INTERPRETED',
            'open': True, 'protocol_open': True, 'all_obligations_complete': None,
            'conflict': None, 'currentness': 'UNKNOWN; RETAINED_LOCAL_HISTORY_ONLY',
            'performance_verified': False, 'external_payment_verified': False}


def summary(party, *, envelopes=(), ledger=None, as_of=None, limit=256):
    """Summarize every locally known agreement naming ``party``.

    ``envelopes`` are retained signed envelopes (claims). ``ledger`` is the
    owner-installed provider, or None when this host observes no payments.
    """
    need(_hex(party), 'PUBLIC_KEY')
    need(as_of is None or (type(as_of) is int and 0 <= as_of <= 2**53 - 1), 'INTEGER_RANGE')
    need(type(limit) is int and 1 <= limit <= 4096, 'OBLIGATION_LIMIT')
    candidates = {}
    portable = {}
    unsupported_profiles = {}
    ignored = 0
    provider_rows = {}
    truncated = False
    provider = None
    if ledger is not None and hasattr(ledger, 'records_for'):
        found = ledger.records_for(party, limit=limit)
        provider, truncated = found['instance'], found['truncated']
        for row in found['rows']:
            provider_rows[row['agreement']] = row
            candidates.setdefault(row['agreement'], []).append(row['progress'])
    elif ledger is not None:
        provider = getattr(ledger, 'instance', 'IN_PROCESS_REFERENCE_LEDGER')
    for envelope in envelopes:
        profile = _profile(envelope)
        if profile == PORTABLE_PROFILE:
            try:
                row = _portable(envelope, party)
                if row is not None:
                    portable.setdefault(row['agreement'], []).append((envelope, row))
            except (ValueError, TypeError, KeyError):
                ignored += 1
            continue
        if profile not in PROFILES:
            ignored += 1
            if type(profile) is str and len(profile) <= 128:
                unsupported_profiles[profile] = unsupported_profiles.get(profile, 0) + 1
            continue
        parties = envelope.get('parties')
        if type(parties) is not dict or party not in parties.values():
            continue
        try:
            effect = _identity(envelope)
        except (ValueError, TypeError, KeyError):
            ignored += 1
            continue
        candidates.setdefault(effect, []).append(envelope)
    rows = []
    for effect in sorted(candidates):
        best = None
        for envelope in candidates[effect]:
            checked = _verdict(envelope)
            if not checked.get('ok'):
                ignored += 1
                continue
            key = (RANK.get(checked['verdict'], 0), len(envelope.get('deliveries') or []), len(envelope.get('assents') or []))
            if best is None or key > best[0]:
                best = (key, envelope, checked['verdict'])
        if best is None:
            continue
        _key, envelope, stage = best
        roles = [role for role in ROLE_ORDER if envelope['parties'].get(role) == party]
        if 'agent' in roles and 'principal' not in roles:
            roles.append('principal_represented')
        observed = _observe(ledger, effect, envelope, provider_rows.get(effect))
        if (observed['receipt_matches_signed_settlement'] is False or
                (observed['escrow'] is not None and stage in ('SETTLED', 'RELEASED') and observed['escrow']['status'] == 'HELD')):
            conflict = 'PROVIDER_AND_SIGNED_RECORD_DISAGREE'
        else:
            conflict = None
        side = ('BUYER' if {'principal', 'agent'} & set(roles) else
                'SELLER' if {'counterparty', 'executor'} & set(roles) else 'REVIEWER')
        others = {role: key for role, key in envelope['parties'].items() if key != party and role in ('principal', 'counterparty')}
        rows.append({
            'agreement': effect, 'profile': envelope['profile'], 'roles': roles, 'side': side,
            'counterparties': others,
            'terms': {'quantity': envelope['terms']['quantity'], 'unit': envelope['terms']['unit'],
                      'rail': envelope['terms']['rail'], 'deadline': envelope['terms']['deadline'],
                      'task_hash': envelope['terms']['task_hash'],
                      'settlement_authority': envelope['terms'].get('settlement_authority')},
            'signed': _signed_claims(envelope, stage),
            'provider': observed,
            'money': _money(roles, envelope, stage, observed),
            'protocol_duties': _duties(roles, envelope, stage, as_of),
            'document_obligations': 'NOT_EXTRACTED: WRITTEN_DUTIES_SURVIVE_PAYMENT; DECLARE_THEM_IN_COVENANT_COORDINATION_REVIEW',
            'open': stage in OPEN_STAGES, 'protocol_open': stage in OPEN_STAGES,
            'all_obligations_complete': None, 'conflict': conflict,
        })
        if len(rows) == limit:
            truncated = truncated or len(candidates) > limit
            break
    for effect in sorted(portable):
        histories = portable[effect]
        order, row = max(histories, key=lambda item: (len(item[0]['events']), len(item[0]['assents']), canonical(item[0])))
        # An event prefix is an earlier view; competing branches stay visible.
        branches = [o for o, _r in histories if o['events'] != order['events'][:len(o['events'])]]
        row['history'] = {'retained_records': len(histories), 'selected_events': len(order['events']),
                          'selection': 'LONGEST_RETAINED_EVENT_CHAIN; NOT_GLOBAL_CURRENTNESS',
                          'conflicting_event_histories': len(branches)}
        if branches:
            row['conflict'] = 'CONFLICTING_RETAINED_PORTABLE_EVENT_HISTORIES'
        rows.append(row)
    rows.sort(key=lambda row: row['agreement'])
    if len(rows) > limit:
        truncated = True
        rows = rows[:limit]
    for row in rows:
        row['obligation_coverage'] = {'profile': row['profile'],
            'history': 'RETAINED_LOCAL_RECORDS_ONLY; SUPERSESSION_AND_OTHER_HOSTS_UNKNOWN',
            'prose': 'UNASSESSED; WRITTEN_DUTIES_MAY_SURVIVE_PROTOCOL_COMPLETION',
            'nonmonetary': 'ONLY_PROTOCOL_DUTIES; NO_TYPED_DOCUMENT_OBLIGATION_EXTRACTION',
            'completion': 'UNKNOWN; NO_GLOBAL_OBLIGATION_OR_LEGAL_DISCHARGE_CHECK'}
    totals = {}
    for row in rows:
        unit = row['money']['unit']
        total = totals.setdefault(unit, {'claimed': {'payable_pending': 0, 'receivable_pending': 0, 'paid': 0, 'received': 0, 'refunded': 0},
                                         'observed': None})
        for key, value in row['money']['claimed'].items():
            total['claimed'][key] += value
        if row['money']['observed'] is not None:
            if total['observed'] is None:
                total['observed'] = {'held_in_escrow': 0, 'paid': 0, 'received': 0, 'refunded': 0}
            for key, value in row['money']['observed'].items():
                total['observed'][key] += value
    return {
        'version': VERSION, 'party': party,
        'clock': 'OWNER_HOST_CLOCK' if as_of is not None else 'NOT_SUPPLIED; DEADLINES_NOT_COMPARED',
        'agreements': rows, 'open_count': sum(1 for row in rows if row['open']),
        'protocol_open_count': sum(1 for row in rows if row['protocol_open']),
        'open_count_basis': 'PROTOCOL_STEPS_ONLY; WRITTEN_DUTIES_NOT_EXTRACTED',
        'all_obligations_complete': None,
        'totals_by_unit': totals,
        'provider': {'installed': ledger is not None, 'instance': provider,
                     'assurance': 'LOCAL_REFERENCE_LEDGER_NOT_EXTERNAL_PAYMENT' if ledger is not None else 'NONE'},
        'ignored_records': ignored, 'truncated': truncated,
        'coverage_details': {'profiles': {**{p: 'SIGNED_PROTOCOL_AND_REFERENCE_PROVIDER' for p in PROFILES},
                                          PORTABLE_PROFILE: 'SIGNED_TERMS_AND_EVENT_CLAIMS_ONLY; PAYMENT_OBSERVER_UNSUPPORTED'},
            'unsupported_profiles': unsupported_profiles,
            'host': 'ONLY_RETAINED_OR_OWNER_PROVIDER_REGISTERED_RECORDS',
            'history': 'LATEST_GLOBAL_STATE_AND_OTHER_HOSTS_UNKNOWN',
            'prose': 'UNASSESSED; NO_INFERRED_FULFILLMENT', 'nonmonetary': 'PROTOCOL_STEPS_ONLY',
            'output_limit': limit, 'truncated': truncated,
            'truncation_basis': 'OUTPUT_AND_PROVIDER_LIMITS_ONLY; CALLER_STORE_SCAN_MAY_BE_BOUNDED',
            'source_completeness': 'NOT_ESTABLISHED; ONLY_CALLER_SUPPLIED_COLLECTION'},
        'labels': {'OBSERVED': 'Read now from the provider the owner installed on this host.',
                   'CLAIMED': 'Signed envelopes this host retained or its provider registered; not freshness, delivery quality or legal effect.'},
        'coverage': 'ONLY_AGREEMENTS_THIS_HOST_RETAINED_OR_ITS_PROVIDER_REGISTERED; OTHER_HOSTS_UNKNOWN',
        'read_only': True, 'payment_rail_touched': False, 'ledger_touched': False,
        'chain_ledger_touched': False, 'external_payment_verified': False,
        'execution_authorized': False,
    }
