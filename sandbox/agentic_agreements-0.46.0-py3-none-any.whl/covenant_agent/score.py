"""Covenant Score. A view computed from receipts, not a balance.

The number does not gate EXECUTE, does not move a ledger, and is meaningful
only for the chain id it names. A fork with another id does not verify.
Light clients recompute the integer formula and the commitment. They do not
ask a committee light client.
"""
from .biomimicry.rpe import from_receipts
from .codec import HEX, digest, public_key, sign, verify
from .envelope import verify as verify_envelope
from .errors import need

PROFILE = 'covenant-score/0.1'
LABEL = 'COVENANT-SCORE-0.1'
VC_LABEL = 'COVENANT-SCORE-VC-0.1'
# One distinct counterparty is worth 2500 bps of weight. Four reach the cap.
_DIVERSITY_STEP = 2500


def covenant_score(receipts, *, subject, chain_id):
    """Score ``subject`` from settled or released envelopes.

    Kept value is stake on receipts the subject honoured. Broken value is
    stake refunded away from the subject as counterparty. Weight falls when
    the counterparties are few, so one friendly key cannot fill the score.
    """
    need(type(subject) is str and bool(HEX.fullmatch(subject)), 'SCORE_SUBJECT')
    need(type(chain_id) is str and bool(HEX.fullmatch(chain_id)), 'SCORE_CHAIN')
    need(type(receipts) is list and len(receipts) <= 256, 'SCORE_RECEIPTS')
    rows = []
    unit = None
    for envelope in receipts:
        report = verify_envelope(envelope)
        need(report['complete'], 'SCORE_RECEIPTS')
        parties = envelope['parties']
        need(subject in {parties['counterparty'], parties['principal']}, 'SCORE_SUBJECT')
        this = envelope['terms']['unit']
        unit = this if unit is None else unit
        need(this == unit, 'SCORE_RECEIPTS')
        other = parties['principal'] if subject == parties['counterparty'] else parties['counterparty']
        paid_to_subject = report['verdict'] == 'SETTLED' and envelope['settlement']['payee'] == subject
        refunded_from_subject = (report['verdict'] == 'RELEASED' and subject == parties['counterparty']
                                 and envelope['settlement']['action'] == 'REFUND_PRINCIPAL')
        if paid_to_subject:
            outcome = 'KEPT'
        elif refunded_from_subject:
            outcome = 'BROKEN'
        else:
            continue
        decision = (envelope.get('dispute') or {}).get('decision')
        rows.append({
            'cid': report['cid'],
            'outcome': outcome,
            'quantity': envelope['terms']['quantity'],
            'unit': this,
            'counterparty': other,
            'arbitrated': decision is not None,
            'arbitration_result': None if decision is None else decision.get('result'),
        })
    rows.sort(key=lambda row: row['cid'])
    kept = sum(row['quantity'] for row in rows if row['outcome'] == 'KEPT')
    broken = sum(row['quantity'] for row in rows if row['outcome'] == 'BROKEN')
    total = kept + broken
    stakes = {}
    for row in rows:
        stakes[row['counterparty']] = stakes.get(row['counterparty'], 0) + row['quantity']
    diversity = min(10000, len(stakes) * _DIVERSITY_STEP)
    score = 0 if total == 0 else kept * diversity // total
    arbitrated = sum(1 for row in rows if row['arbitrated'])
    losses = sum(1 for row in rows if row['arbitration_result'] == 'REFUTED' and row['outcome'] == 'BROKEN')
    body = {
        'broken_value': broken,
        'chain_id': chain_id,
        'diversity_bps': diversity,
        'kept_value': kept,
        'profile': PROFILE,
        'receipts': [row['cid'] for row in rows],
        'score_bps': score,
        'subject': subject,
        'unit': unit,
    }
    commitment = digest(LABEL, body)
    rpe = from_receipts(rows)
    return {
        'profile': PROFILE,
        'view': True,
        'native_balance': False,
        'covenant_score': score,
        'score_bps': score,
        'diversity_bps': diversity,
        'kept_value': kept,
        'broken_value': broken,
        'value_at_stake': total,
        'counterparties': len(stakes),
        'arbitrated': arbitrated,
        'arbitration_losses': losses,
        'unit': unit,
        'subject': subject,
        'chain_id': chain_id,
        'receipts': rows,
        'commitment': commitment,
        'gates_execute': False,
        'applied': False,
        'execution_authorized': False,
        'path': 'LOCAL_RECOMPUTE_NOT_A_COMMITTEE_LIGHT_CLIENT',
        'sybil': 'COUNTERPARTY_DIVERSITY_AND_STAKE',
        'fork_bound': True,
        'rpe_bps': rpe['rpe_bps'],
        'rpe_updates': rpe['updates'],
        'rpe_consensus': False,
        'rpe_interface': 'economics.rpe_update',
    }


def verify_score(packet, chain_id, envelopes=None):
    """Light check: same chain id, same formula, same commitment."""
    need(type(packet) is dict and packet.get('chain_id') == chain_id, 'SCORE_CHAIN')
    need(bool(HEX.fullmatch(chain_id)), 'SCORE_CHAIN')
    recomputed = False
    if envelopes is not None:
        fresh = covenant_score(envelopes, subject=packet['subject'], chain_id=chain_id)
        need(fresh['score_bps'] == packet['score_bps'], 'SCORE_RECEIPTS')
        need(fresh['commitment'] == packet['commitment'], 'SCORE_CHAIN')
        recomputed = True
    body = {
        'broken_value': packet['broken_value'],
        'chain_id': packet['chain_id'],
        'diversity_bps': packet['diversity_bps'],
        'kept_value': packet['kept_value'],
        'profile': PROFILE,
        'receipts': [row['cid'] for row in packet['receipts']],
        'score_bps': packet['score_bps'],
        'subject': packet['subject'],
        'unit': packet['unit'],
    }
    need(digest(LABEL, body) == packet['commitment'], 'SCORE_CHAIN')
    need(packet.get('gates_execute') is False and packet.get('native_balance') is False, 'SCORE_RECEIPTS')
    return {'verified': True, 'chain_id': chain_id, 'commitment': packet['commitment'],
            'view': True, 'gates_execute': False, 'execution_authorized': False,
            'path': 'LOCAL_RECOMPUTE_NOT_A_COMMITTEE_LIGHT_CLIENT', 'fork_bound': True,
            'recomputed': recomputed}


def erc8004_reputation(packet):
    """ERC-8004 shaped reputation entries. ``posted`` is false. Nothing is sent."""
    need(packet.get('fork_bound') is True and packet.get('gates_execute') is False, 'SCORE_RECEIPTS')
    return {
        'schema': 'erc8004-reputation-export/0.1',
        'standard': 'ERC-8004',
        'posted': False,
        'chainId': packet['chain_id'],
        'agent': packet['subject'],
        'tag': 'covenant-score',
        'value': packet['score_bps'],
        'valueDecimals': 4,
        'feedbacks': [{
            'cid': row['cid'],
            'value': packet['score_bps'] if row['outcome'] == 'KEPT' else 0,
            'tag': row['outcome'],
        } for row in packet['receipts']],
        'forkBound': True,
        'gatesExecute': False,
        'nativeBalance': False,
        'assurance': 'VIEW_OF_RECEIPTS_NOT_AN_ETHEREUM_TRANSACTION',
    }


def score_credential(packet, *, issuer):
    """A credential a Know-Your-Agent check can read. It is a behaviour signal."""
    body = {'chainId': packet['chain_id'], 'commitment': packet['commitment'],
            'scoreBps': packet['score_bps'], 'subject': packet['subject']}
    issuer_id = public_key(issuer)
    return {
        '@context': ['https://www.w3.org/2018/credentials/v1'],
        'type': ['VerifiableCredential', 'CovenantScoreCredential'],
        'issuer': issuer_id,
        'credentialSubject': {'id': 'covenant:agent:' + packet['subject'], 'covenantScoreBps': packet['score_bps'],
                              'chainId': packet['chain_id']},
        'proof': {'type': 'Ed25519Signature2020', 'proofPurpose': 'assertionMethod',
                  'verificationMethod': issuer_id, 'commitment': packet['commitment'],
                  'proofValue': sign(issuer, VC_LABEL, body)},
        'kya': 'BEHAVIOUR_SIGNAL_NOT_AN_IDENTITY_CHECK',
        'gates_execute': False,
        'posted': False,
    }


def verify_credential(credential, chain_id):
    body = {'chainId': credential['credentialSubject']['chainId'],
            'commitment': credential['proof']['commitment'],
            'scoreBps': credential['credentialSubject']['covenantScoreBps'],
            'subject': credential['credentialSubject']['id'].removeprefix('covenant:agent:')}
    need(body['chainId'] == chain_id, 'SCORE_CHAIN')
    need(verify(credential['issuer'], VC_LABEL, body, credential['proof']['proofValue']), 'SIGNATURE')
    return {'verified': True, 'chain_id': chain_id, 'kya': credential['kya'], 'gates_execute': False}
