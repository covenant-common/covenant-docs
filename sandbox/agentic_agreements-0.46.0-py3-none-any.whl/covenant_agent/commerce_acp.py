"""Graft: the Agentic Commerce Protocol (ACP) checkout, bound to an AAP agreement.

Implements the subset confirmed in agentic-commerce-protocol snapshot
2026-04-17 (Apache-2.0): rfcs/rfc.extensions.md sections 3, 4 and 6
(extension declaration, negotiation, versioning), the CheckoutSession, Order
and Total schemas of spec/2026-04-17/openapi/openapi.agentic_checkout.yaml,
the WebhookEvent and Merchant-Signature rule of
openapi.agentic_checkout_webhook.yaml, and the delegate-payment Allowance of
rfcs/rfc.delegate_payment.md section 3.5.

The extension adds one field, aap_agreement, to checkout requests, the
checkout session and the order. A merchant's echo, order webhooks and payment
allowances become evidence for the AAP record. None of them is assent,
payment, delivery or permission to release funds. Card data and payment
credentials are refused, never hashed or stored.
"""
from copy import deepcopy
import hashlib
import hmac
import re

from . import commerce
from .errors import NativeError

VERSION = '2026-04-17'
IDENTIFIER = commerce.EXTENSION + '@' + commerce.EXTENSION_VERSION
EXTENDS = ['$.CheckoutSessionCreateRequest.' + commerce.FIELD, '$.CheckoutSessionUpdateRequest.' + commerce.FIELD,
           '$.CheckoutSession.' + commerce.FIELD, '$.Order.' + commerce.FIELD]
# Patterns copied from spec/2026-04-17/json-schema/schema.extension.json (Apache-2.0, see NOTICE).
IDENTIFIER_PATTERN = re.compile(r'^[a-z][a-z0-9_-]*(@\d{4}-\d{2}-\d{2})?$|^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9_-]*)+(@\d{4}-\d{2}-\d{2})?$')
EXTENDS_PATTERN = re.compile(r'^\$\.[A-Za-z][A-Za-z0-9]*(\.[A-Za-z][A-Za-z0-9_]*)*$')
STATUSES = ('incomplete', 'not_ready_for_payment', 'requires_escalation', 'authentication_required',
            'ready_for_payment', 'pending_approval', 'complete_in_progress', 'completed', 'canceled',
            'in_progress', 'expired')
CLOSED = ('canceled', 'expired')

HINTS = {
    'ACP_URL': 'Pass an https URL of at most 512 printable characters without user information.',
    'ACP_CHECKOUT': 'Pass the merchant CheckoutSession response for API version 2026-04-17 with its required fields.',
    'ACP_CHECKOUT_CLOSED': 'This checkout is canceled or expired. Start a new checkout before drafting an agreement.',
    'ACP_TOTAL': 'The checkout needs exactly one Total of type total with an integer amount in minor units.',
    'ACP_LINE_ITEMS': 'Each line item needs id, item.id, an integer quantity and integer totals.',
    'ACP_ORDER': 'Pass a WebhookEvent {type, data} whose data is the full Order with type order.',
    'ACP_ORDER_FOREIGN': 'This order belongs to another checkout session than the agreed checkout_id.',
    'ACP_WEBHOOK_SIGNATURE': 'Merchant-Signature must be t=<unix seconds>,v1=<64 hex> over timestamp.raw_body with the shared secret.',
    'ACP_WEBHOOK_STALE': 'The Merchant-Signature timestamp is outside the tolerance of the owner-adopted clock.',
    'ACP_COMPLETED': 'Pass the CheckoutSession returned by complete, with status completed and an order.',
    'ACP_ALLOWANCE': 'Pass only the delegate-payment allowance object: reason, max_amount, currency, checkout_session_id, merchant_id, expires_at.',
}


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS.get(code) or commerce.HINTS[code])


def _url(value):
    need(value is None or type(value) is str and value.startswith('https://') and 8 < len(value) <= 512 and
         all(33 <= ord(c) <= 126 for c in value) and '@' not in value.split('/', 3)[2], 'ACP_URL')
    return value


def extension(schema_url=commerce.SCHEMA_URL, spec_url=commerce.SPEC_URL):
    """The request identifier, response declaration and discovery entry (rfc.extensions.md section 3)."""
    _url(schema_url); _url(spec_url)
    declaration = {'name': IDENTIFIER, 'extends': list(EXTENDS)}
    discovery = {'name': IDENTIFIER}
    for name, value in (('schema', schema_url), ('spec', spec_url)):
        if value is not None:
            declaration[name] = value
            discovery[name] = value
    return {'protocol': 'ACP', 'version': VERSION, 'field': commerce.FIELD,
            'request': {'capabilities': {'extensions': [IDENTIFIER]}}, 'response': declaration,
            'discovery': discovery, 'field_schema': commerce.field_schema(),
            'rules': ['Merchants that do not support the extension omit it; agents continue without it (rfc.extensions.md 4.1).',
                      'The field is optional; it never changes required ACP fields or their meaning (section 5.3).',
                      'An echoed aap_agreement must equal the reference the agent sent; any change refuses.'],
            'publication': 'SCHEMA_AND_SPEC_URLS_ARE_PROPOSED_UNTIL_THE_OWNER_PUBLISHES_THEM', **commerce.FLAGS}


def _parse(raw):
    value, data = commerce.document(raw)
    return commerce.no_credentials(value), data


def _int(value, code):
    need(type(value) is int and 0 <= value <= commerce.MAX, code)
    return value


def _text(value, code, limit=256):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _total(totals, code, required=True):
    need(type(totals) is list and len(totals) <= 64, code)
    found = []
    for row in totals:
        need(type(row) is dict and type(row.get('type')) is str and type(row.get('display_text')) is str, code)
        _int(row.get('amount'), code)
        if row['type'] == 'total':
            found.append(row['amount'])
    need(len(found) == 1 or not required and not found, code)
    return found[0] if found else None


def _extension_active(capabilities):
    rows = capabilities.get('extensions') if type(capabilities) is dict else None
    if type(rows) is not list:
        return False
    for row in rows:
        name = row.get('name') if type(row) is dict else row
        if type(name) is str and (name == commerce.EXTENSION or name.startswith(commerce.EXTENSION + '@')):
            return True
    return False


def checkout(raw, merchant):
    """Read a CheckoutSession (2026-04-17) into AAP order terms; buyer details are only hashed."""
    session, data = _parse(raw)
    need(type(session) is dict and {'id', 'status', 'currency', 'line_items', 'totals', 'fulfillment_options',
                                    'messages', 'links', 'capabilities'} <= set(session), 'ACP_CHECKOUT')
    protocol = session.get('protocol')
    need(protocol is None or type(protocol) is dict and protocol.get('version') == VERSION, 'COMMERCE_PROTOCOL_VERSION')
    _text(session['id'], 'ACP_CHECKOUT')
    need(session['status'] in STATUSES, 'ACP_CHECKOUT')
    need(session['status'] not in CLOSED, 'ACP_CHECKOUT_CLOSED')
    need(type(session['capabilities']) is dict, 'ACP_CHECKOUT')
    total = _total(session['totals'], 'ACP_TOTAL')
    lines = session['line_items']
    need(type(lines) is list and 1 <= len(lines) <= 32, 'ACP_LINE_ITEMS')
    items = []
    for line in lines:
        need(type(line) is dict and type(line.get('item')) is dict and type(line.get('quantity')) is int and
             line['quantity'] >= 1, 'ACP_LINE_ITEMS')
        _text(line.get('id'), 'ACP_LINE_ITEMS'); _text(line['item'].get('id'), 'ACP_LINE_ITEMS')
        line_total = _total(line.get('totals'), 'ACP_LINE_ITEMS', required=False)
        title = line.get('name')
        title = title if type(title) is str and 0 < len(title.encode('utf-8')) <= 256 else None
        items.append({'id': line['id'], 'quantity': line['quantity'], 'total': line_total, 'title': title})
    fulfillment = deliver_by = None
    selected = session.get('selected_fulfillment_options')
    if type(selected) is list and selected and type(selected[0]) is dict:
        option_id = selected[0].get('option_id')
        kind = selected[0].get('type')
        for option in session['fulfillment_options'] if type(session['fulfillment_options']) is list else []:
            if type(option) is dict and option.get('id') == option_id:
                kind = kind or option.get('type')
                latest = option.get('latest_delivery_time')
                if type(latest) is str and 0 < len(latest) <= 64 and all(32 <= ord(c) <= 126 for c in latest):
                    deliver_by = latest
        fulfillment = kind if type(kind) is str and re.fullmatch(r'[a-z_]{1,32}', kind) else None
    terms = commerce.order('ACP', VERSION, hashlib.sha256(data).hexdigest(), session['id'], merchant,
                           session['currency'], total, items, fulfillment, deliver_by)
    echoed = session.get(commerce.FIELD)
    return {'order': terms, 'status': session['status'], 'extension_active': _extension_active(session['capabilities']),
            'echo': commerce.echo_status(echoed),
            'content_digest': commerce.content_digest(data), 'buyer_details': 'HASHED_IN_CHECKOUT_NOT_COPIED',
            **commerce.FLAGS}


def draft(raw, merchant, parties, context, acceptance, remedy, remedy_reference=None):
    """An AAP agreement draft from a supplied checkout session, plus the update body that carries it."""
    read = checkout(raw, merchant)
    made = commerce.draft(read['order'], parties, context, acceptance, remedy, remedy_reference=remedy_reference)
    # Extensions are negotiated on create (capabilities); the update request only gains the field.
    made['checkout_update'] = {commerce.FIELD: deepcopy(made['reference'])}
    made['create_capabilities'] = {'extensions': [IDENTIFIER]}
    made['extension_active'] = read['extension_active']
    return made


def merchant_signature(header, raw_body, secret, now=None, tolerance=300):
    """Verify ACP's webhook HMAC: HMAC-SHA256(secret, t + "." + raw_body) in Merchant-Signature."""
    need(type(header) is str and len(header) <= 128, 'ACP_WEBHOOK_SIGNATURE')
    found = re.fullmatch(r't=(\d{1,12}),v1=([a-fA-F0-9]{64})', header)
    need(found is not None and isinstance(secret, (bytes, bytearray)) and 16 <= len(secret) <= 4096 and
         isinstance(raw_body, (bytes, bytearray)), 'ACP_WEBHOOK_SIGNATURE')
    stamp = int(found.group(1))
    expected = hmac.new(bytes(secret), found.group(1).encode('ascii') + b'.' + bytes(raw_body), hashlib.sha256).hexdigest()
    need(hmac.compare_digest(expected, found.group(2).lower()), 'ACP_WEBHOOK_SIGNATURE')
    freshness = 'NOT_CHECKED'
    if now is not None:
        need(type(now) is int and type(tolerance) is int and 0 < tolerance <= 3600, 'COMMERCE_CLOCK')
        need(abs(now - stamp) <= tolerance, 'ACP_WEBHOOK_STALE')
        freshness = 'WITHIN_TOLERANCE_OF_OWNER_CLOCK'
    return {'method': 'HMAC_SHA256_SHARED_SECRET', 'status': 'VERIFIED',
            'detail': 'HOLDER_OF_THE_SHARED_WEBHOOK_SECRET; NOT_NON_REPUDIABLE; FRESHNESS_' + freshness}


def _order_summary(order, application):
    t = commerce.terms(application)
    need(type(order) is dict and {'id', 'checkout_session_id', 'permalink_url'} <= set(order), 'ACP_ORDER')
    _text(order['id'], 'ACP_ORDER'); _text(order['checkout_session_id'], 'ACP_ORDER')
    need(order['checkout_session_id'] == t['checkout_id'], 'ACP_ORDER_FOREIGN')
    status = order.get('status')
    summary = {'order': order['id'], 'checkout_id': order['checkout_session_id'],
               'status': status if type(status) is str and len(status) <= 64 else None,
               'line_items': [], 'fulfillments': [], 'adjustments': [], 'total': None, 'amount_refunded': None}
    for row in commerce.items(order.get('line_items')):
        quantity = row.get('quantity') if type(row) is dict else None
        if type(quantity) is dict and type(row.get('id')) is str:
            summary['line_items'].append({'id': row['id'][:256], **{k: quantity.get(k) for k in ('ordered', 'current', 'fulfilled')
                                                                   if type(quantity.get(k)) is int}})
    for row in commerce.items(order.get('fulfillments')):
        if type(row) is dict and type(row.get('id')) is str:
            delivered = [e.get('occurred_at') for e in commerce.items(row.get('events')) if type(e) is dict and e.get('type') == 'delivered'
                         and type(e.get('occurred_at')) is str]
            summary['fulfillments'].append({'id': row['id'][:256], 'type': str(row.get('type'))[:32],
                                            'status': str(row.get('status'))[:32],
                                            'delivered_at': delivered[-1][:64] if delivered else None})
    for row in commerce.items(order.get('adjustments')):
        if type(row) is dict and type(row.get('id')) is str:
            summary['adjustments'].append({'id': row['id'][:256], 'type': str(row.get('type'))[:32],
                                           'status': str(row.get('status'))[:32],
                                           'amount': row.get('amount') if type(row.get('amount')) is int else None,
                                           'currency': row.get('currency') if type(row.get('currency')) is str and len(row['currency']) == 3 else None})
    totals = order.get('totals')
    if type(totals) is list:
        for row in totals:
            if type(row) is dict and type(row.get('amount')) is int and row.get('type') in ('total', 'amount_refunded'):
                summary['total' if row['type'] == 'total' else 'amount_refunded'] = row['amount']
    for name in ('line_items', 'fulfillments', 'adjustments'):
        summary[name] = summary[name][:64]
    echoed = order.get(commerce.FIELD)
    summary['reference_echo'] = commerce.echo_status(echoed, application)
    return summary


def order_event(application, raw_body, *, merchant_signature_header=None, secret=None, now=None, tolerance=300):
    """Record an ACP order webhook (order_create or order_update) as evidence for the agreement."""
    t = commerce.terms(application)
    event, data = _parse(raw_body)
    need(type(event) is dict and set(event) == {'type', 'data'} and type(event['type']) is str and
         0 < len(event['type']) <= 64 and type(event['data']) is dict and event['data'].get('type') == 'order', 'ACP_ORDER')
    summary = _order_summary(event['data'], application)
    summary['event'] = event['type']
    authentication = None
    if merchant_signature_header is not None and secret is not None:
        authentication = merchant_signature(merchant_signature_header, data, secret, now, tolerance)
    elif merchant_signature_header is not None:
        authentication = {'method': 'HMAC_SHA256_SHARED_SECRET', 'status': 'NOT_CHECKED',
                          'detail': 'SHARED_SECRET_NOT_SUPPLIED_TO_THIS_CALL'}
    return commerce.evidence('ACP', 'ORDER_EVENT', t['application'], data, summary, authentication=authentication)


def completed(application, raw):
    """Record the completed CheckoutSession with its order; the charged total is compared, never trusted."""
    t = commerce.terms(application)
    session, data = _parse(raw)
    need(type(session) is dict and session.get('status') == 'completed' and type(session.get('order')) is dict, 'ACP_COMPLETED')
    need(session.get('id') == t['checkout_id'], 'ACP_ORDER_FOREIGN')
    total = _total(session.get('totals'), 'ACP_TOTAL')
    summary = _order_summary(session['order'], application)
    currency = session.get('currency')
    summary.update(session_total=total, session_currency=currency if type(currency) is str and len(currency) == 3 else None,
                   price_matches=total == t['amount'] and type(currency) is str and currency.lower() == t['currency'].lower())
    return commerce.evidence('ACP', 'CHECKOUT_COMPLETED', t['application'], data, summary)


def allowance(application, raw):
    """Record a delegate-payment Allowance (rfc.delegate_payment.md 3.5) against the agreed price."""
    t = commerce.terms(application)
    value, data = _parse(raw)
    need(type(value) is dict and set(value) == {'reason', 'max_amount', 'currency', 'checkout_session_id',
                                                'merchant_id', 'expires_at'}, 'ACP_ALLOWANCE')
    need(value['reason'] == 'one_time', 'ACP_ALLOWANCE')
    _int(value['max_amount'], 'ACP_ALLOWANCE'); _text(value['checkout_session_id'], 'ACP_ALLOWANCE')
    _text(value['merchant_id'], 'ACP_ALLOWANCE'); _text(value['expires_at'], 'ACP_ALLOWANCE', 64)
    need(type(value['currency']) is str and re.fullmatch('[a-z]{3}', value['currency']) is not None, 'ACP_ALLOWANCE')
    summary = {'max_amount': value['max_amount'], 'currency': value['currency'],
               'checkout_id': value['checkout_session_id'], 'merchant_id': value['merchant_id'],
               'expires_at': value['expires_at'],
               'session_matches': value['checkout_session_id'] == t['checkout_id'],
               'currency_matches': value['currency'] == t['currency'].lower(),
               'covers_price': value['max_amount'] >= t['amount'], 'exact_cap': value['max_amount'] == t['amount']}
    return commerce.evidence('ACP', 'PAYMENT_ALLOWANCE', t['application'], data, summary)
