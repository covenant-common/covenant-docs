"""Bilateral work orders. Happy-path bytes never become a chain transaction.

Two parties sign the exact terms. Delivery, dispute and settlement are further
signatures over those terms. A verifier needs the bytes and the public keys,
not a node and not a hosted RPC.
"""
import hashlib
from copy import deepcopy

from .cid import cid_from_bytes
from .codec import canonical, digest, exact, public_key, sha256_hex, sign, signature_ok
from .errors import NativeError, REMEDIATION, need
from .pii import preflight
from .settlement import (
    DEFAULT_AP2_NETWORK, DEFAULT_X402_NETWORK, NATIVE_UNITS, STABLECOINS,
    ap2_mandate_body, mandate_ok, require_stablecoin, sign_ap2_mandate, x402_requirements,
)

VERSION = 'covenant-agent-native/0.1'
PROFILE = 'covenant-bilateral/0.1'
TERMS_VERSION = 'covenant-work-order/0.1'
MANDATE_VERSION = 'covenant-local-mandate/0.1'
ASSENT_LABEL = 'COVENANT-WORK-ORDER-ASSENT-0.1'
MANDATE_LABEL = 'COVENANT-LOCAL-MANDATE-0.1'
DELIVER_LABEL = 'COVENANT-WORK-ORDER-DELIVER-0.1'
RELEASE_LABEL = 'COVENANT-WORK-ORDER-RELEASE-0.1'
DECIDE_LABEL = 'COVENANT-WORK-ORDER-DECIDE-0.1'
DISPUTE_LABEL = 'COVENANT-WORK-ORDER-DISPUTE-0.1'
EFFECTS = frozenset({'TRANSFER', 'CONSUME', 'AUTHORIZE'})
TIMEOUTS = frozenset({'RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION'})
RAILS = frozenset({'x402', 'ap2'})
RESULTS = frozenset({'SUPPORTED', 'REFUTED', 'INDETERMINATE'})
VERBS = ('covenant_propose', 'covenant_accept', 'covenant_deliver', 'covenant_verify', 'covenant_settle')

NEXT = {
    'INVALID': 'Fix the failed checks. Do not change owner trust to force a pass.',
    'PROPOSED': 'Counterparty calls covenant_accept on this exact envelope.',
    'BOUND': 'Counterparty calls covenant_deliver with the work-product bytes.',
    'DELIVERED': 'Principal calls covenant_settle. Payment is a stablecoin on x402 or AP2. The chain is not required.',
    'DISPUTED': 'Resolver records SUPPORTED or REFUTED, then covenant_settle routes escrow.',
    'DECIDED': 'Principal or resolver calls covenant_settle to pay or refund the escrow.',
    'SETTLED': 'No further payment. Keep the CID. The receipt is the record.',
    'RELEASED': 'Escrow returned to the principal. Keep the CID.',
}


def _check(checks, code, ok):
    checks.append({'code': code, 'passed': bool(ok),
                   'remediation': None if ok else REMEDIATION.get(code, NEXT['INVALID'])})
    return bool(ok)


def _ascii(value, limit, code):
    return type(value) is str and 1 <= len(value) <= limit and all(32 <= ord(c) <= 126 for c in value)


def hash_document(text):
    need(type(text) is str, 'DOCUMENT')
    try:
        raw = text.encode('ascii')
    except UnicodeError as exc:
        raise NativeError('DOCUMENT') from exc
    need(1 <= len(raw) <= 4096 and all(32 <= b <= 126 for b in raw), 'DOCUMENT')
    return hashlib.sha256(raw).hexdigest()


def assent_body(terms, parties):
    return {'profile': PROFILE, 'terms': terms, 'parties': parties}


def parties_hash(parties):
    return digest('COVENANT-PARTIES-0.1', parties)


def escrow_id(envelope):
    return digest('COVENANT-ESCROW-0.1', assent_body(envelope['terms'], envelope['parties']))


def content_id(envelope):
    return cid_from_bytes(canonical(envelope))


def sign_mandate(principal, *, holder, unit, limit, expiry, rails, effects):
    require_stablecoin(unit)
    body = {
        'version': MANDATE_VERSION,
        'principal': public_key(principal),
        'holder': holder,
        'unit': unit,
        'limit': limit,
        'expiry': expiry,
        'rails': sorted(set(rails)),
        'effects': sorted(set(effects)),
    }
    need(type(limit) is int and limit > 0, 'MANDATE_SCOPE')
    need(type(expiry) is int and expiry > 0, 'MANDATE_SCOPE')
    need(body['rails'] and set(body['rails']) <= RAILS, 'MANDATE_SCOPE')
    need(body['effects'] and set(body['effects']) <= EFFECTS, 'MANDATE_SCOPE')
    return {'body': body, 'signature': sign(principal, MANDATE_LABEL, body)}


def _terms_dict(task_hash, quantity, unit, rail, pay_to, deadline, challenge_window, timeout, effect, network):
    return {
        'version': TERMS_VERSION,
        'task_hash': task_hash,
        'quantity': quantity,
        'unit': unit,
        'rail': rail,
        'pay_to': pay_to,
        'deadline': deadline,
        'challenge_window': challenge_window,
        'timeout': timeout,
        'effect': effect,
        'network': network,
    }


def draft_order(document=None, *, agent, counterparty, resolver, appeal_resolver, quantity, unit='USDC',
                rail='x402', pay_to, deadline, challenge_window=3600, timeout='RELEASE_IF_UNDECIDED',
                effect='TRANSFER', network=None, executor=None, mandate=None, task_hash=None):
    """The exact unsigned /0.1 envelope ``propose`` signs for ``agent``. No key is read.

    An owner approval gate renders these bytes before the agent key signs them.
    """
    if document is not None:
        task_hash = hash_document(document)
        stored = {'sha256': task_hash, 'text': document}
    else:
        need(type(task_hash) is str and len(task_hash) == 64, 'TASK_HASH')
        stored = {'sha256': task_hash}
    if network is None:
        network = DEFAULT_X402_NETWORK if rail == 'x402' else DEFAULT_AP2_NETWORK
    if mandate is None:
        principal = agent
    else:
        exact(mandate, 'body signature')
        principal = mandate['body']['principal']
    parties = {
        'principal': principal,
        'agent': agent,
        'counterparty': counterparty,
        'executor': executor or counterparty,
        'resolver': resolver,
        'appeal_resolver': appeal_resolver,
    }
    terms = _terms_dict(task_hash, quantity, unit, rail, pay_to, deadline, challenge_window, timeout, effect, network)
    envelope = {
        'profile': PROFILE,
        'terms': terms,
        'parties': parties,
        'document': stored,
        'mandate': mandate,
        'assents': [],
        'deliveries': [],
        'escrow': None,
        'settlement': None,
        'dispute': None,
    }
    # Fail closed before an assent exists, so a bad draft is not signed.
    draft_report = verify(envelope, draft=True)
    for failure in draft_report['failures']:
        if failure['code'] not in ('AGENT_ASSENT', 'COUNTERPARTY_ASSENT'):
            raise NativeError(failure['code'])
    return envelope


def propose(document=None, *, signer, counterparty, resolver, appeal_resolver, quantity, unit='USDC',
            rail='x402', pay_to, deadline, challenge_window=3600, timeout='RELEASE_IF_UNDECIDED',
            effect='TRANSFER', network=None, executor=None, mandate=None, task_hash=None,
            profile=PROFILE, nonce=None, settlement_authority=None, pii='warn'):
    screened = preflight(document, mode=pii)
    if profile == 'covenant-bilateral/0.2':
        from . import bilateral_v2
        result = bilateral_v2.propose(document, signer=signer, counterparty=counterparty,
            resolver=resolver, appeal_resolver=appeal_resolver, quantity=quantity, unit=unit,
            rail=rail, pay_to=pay_to, deadline=deadline, challenge_window=challenge_window,
            timeout=timeout, effect=effect, network=network, executor=executor, mandate=mandate,
            task_hash=task_hash, nonce=nonce, settlement_authority=settlement_authority)
        result['pii'] = screened
        return result
    need(profile == PROFILE and nonce is None and settlement_authority is None, 'PROFILE')
    agent = public_key(signer)
    envelope = draft_order(document, agent=agent, counterparty=counterparty, resolver=resolver,
                           appeal_resolver=appeal_resolver, quantity=quantity, unit=unit, rail=rail, pay_to=pay_to,
                           deadline=deadline, challenge_window=challenge_window, timeout=timeout, effect=effect,
                           network=network, executor=executor, mandate=mandate, task_hash=task_hash)
    terms, parties = envelope['terms'], envelope['parties']
    body = assent_body(terms, parties)
    assent = {'signer': agent, 'role': 'agent', 'signature': sign(signer, ASSENT_LABEL, body)}
    envelope['assents'] = [assent]
    cid = content_id(envelope)
    return {
        'version': VERSION,
        'envelope': envelope,
        'cid': cid,
        'signed_terms': {'label': ASSENT_LABEL, 'body': body, 'signer': agent, 'signature': assent['signature']},
        'assent_request': {
            'label': ASSENT_LABEL,
            'body': body,
            'required_role': 'counterparty',
            'required_signer': counterparty,
            'signed_by': [agent],
        },
        'chain_ledger_touched': False,
        'execution_authorized': False,
        'pii': screened,
    }


def accept(envelope, signer, ledger=None):
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import accept as next_accept
        return next_accept(envelope, signer, ledger)
    env = deepcopy(envelope)
    report = verify(env)
    if report['verdict'] == 'INVALID':
        raise NativeError(report['code'])
    need(report['verdict'] == 'PROPOSED', 'DUPLICATE_ASSENT')
    who = public_key(signer)
    need(who == env['parties']['counterparty'], 'SIGNER_ROLE')
    need(all(row['signer'] != who for row in env['assents']), 'DUPLICATE_ASSENT')
    body = assent_body(env['terms'], env['parties'])
    env['assents'].append({'signer': who, 'role': 'counterparty', 'signature': sign(signer, ASSENT_LABEL, body)})
    env['assents'] = sorted(env['assents'], key=lambda row: (row['signer'], row['role']))
    if ledger is not None:
        effect = escrow_id(env)
        ledger.move_to_escrow(effect, env['parties']['principal'], env['terms']['unit'], env['terms']['quantity'])
        env['escrow'] = {
            'id': effect, 'unit': env['terms']['unit'], 'amount': env['terms']['quantity'],
            'payer': env['parties']['principal'], 'status': 'HELD',
            'assurance': 'SIMULATED_STABLECOIN_LEDGER',
        }
    return env


def deliver(envelope, content, signer, *, as_of=None, ledger=None):
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import deliver as next_deliver
        return next_deliver(envelope, content, signer, as_of=as_of, ledger=ledger)
    need(as_of is None and ledger is None, 'PROFILE_UPGRADE_REQUIRED')
    env = deepcopy(envelope)
    report = verify(env)
    need(report['verdict'] == 'BOUND', 'NOT_DELIVERABLE')
    who = public_key(signer)
    need(who in {env['parties']['counterparty'], env['parties']['executor']}, 'SIGNER_ROLE')
    if type(content) is str:
        try:
            raw = content.encode('ascii')
        except UnicodeError as exc:
            raise NativeError('ASCII_PROFILE') from exc
    else:
        need(isinstance(content, (bytes, bytearray)), 'CONTENT_SIZE')
        raw = bytes(content)
    need(1 <= len(raw) <= 1_000_000, 'CONTENT_SIZE')
    content_hash = sha256_hex(raw)
    body = delivery_body(env, content_hash)
    env['deliveries'].append({
        'signer': who,
        'signature': sign(signer, DELIVER_LABEL, body),
        'content_hash': content_hash,
        'content_cid': cid_from_bytes(raw),
    })
    return env, raw


def delivery_body(envelope, content_hash):
    return {
        'content_hash': content_hash,
        'parties_hash': parties_hash(envelope['parties']),
        'terms_hash': envelope['terms']['task_hash'],
    }


def open_dispute(envelope, *, signer, reason, evidence_hash, anchor=None, as_of=None, ledger=None):
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import open_dispute as next_dispute
        return next_dispute(envelope, signer=signer, reason=reason, evidence_hash=evidence_hash,
                            anchor=anchor, as_of=as_of, ledger=ledger)
    need(as_of is None and ledger is None, 'PROFILE_UPGRADE_REQUIRED')
    env = deepcopy(envelope)
    report = verify(env)
    need(report['verdict'] in ('BOUND', 'DELIVERED'), 'NOT_DISPUTABLE')
    who = public_key(signer)
    need(who in {env['parties']['agent'], env['parties']['counterparty']}, 'DISPUTE_AUTHORITY')
    need(_ascii(reason, 200, 'FIELDS'), 'FIELDS')
    need(type(evidence_hash) is str and len(evidence_hash) == 64, 'TASK_HASH')
    body = {
        'action': 'OPEN',
        'evidence_hash': evidence_hash,
        'parties_hash': parties_hash(env['parties']),
        'reason': reason,
        'terms_hash': env['terms']['task_hash'],
    }
    env['dispute'] = {
        'reason': reason,
        'evidence_hash': evidence_hash,
        'opener': who,
        'signature': sign(signer, DISPUTE_LABEL, body),
        'decision': None,
        'anchor': {'status': 'NOT_REQUESTED', 'ledger_touched': False, 'transactions': [],
                   'chain_ledger_touched': False},
    }
    if anchor is not None:
        from .anchor import build_anchor
        built = build_anchor(env, anchor)
        submit = anchor.get('submit')
        if submit is not None:
            result = submit(built['transactions'])
            built['status'] = 'SUBMITTED'
            built['chain_ledger_touched'] = True
            built['ledger_touched'] = True
            built['submit_result'] = _public_result(result)
        else:
            built['status'] = 'READY_NOT_SUBMITTED'
            built['chain_ledger_touched'] = False
        env['dispute']['anchor'] = built
    return env


def decide(envelope, *, signer, result, evidence_hash, paid_amount=None, as_of=None, ledger=None):
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import decide as next_decide
        return next_decide(envelope, signer=signer, result=result, evidence_hash=evidence_hash,
                           paid_amount=paid_amount, as_of=as_of, ledger=ledger)
    need(as_of is None and paid_amount is None and ledger is None, 'PROFILE_UPGRADE_REQUIRED')
    env = deepcopy(envelope)
    report = verify(env)
    need(report['verdict'] == 'DISPUTED', 'DISPUTE_OPEN')
    who = public_key(signer)
    need(who in {env['parties']['resolver'], env['parties']['appeal_resolver']}, 'DECISION_AUTHORITY')
    need(result in RESULTS, 'RESULT')
    need(type(evidence_hash) is str and len(evidence_hash) == 64, 'TASK_HASH')
    body = decision_body(env, result, evidence_hash)
    env['dispute']['decision'] = {
        'result': result,
        'evidence_hash': evidence_hash,
        'signer': who,
        'signature': sign(signer, DECIDE_LABEL, body),
    }
    return env


def decision_body(envelope, result, evidence_hash):
    return {
        'evidence_hash': evidence_hash,
        'parties_hash': parties_hash(envelope['parties']),
        'result': result,
        'terms_hash': envelope['terms']['task_hash'],
    }


def release_body(envelope, action, content_hash):
    return {
        'action': action,
        'amount': envelope['terms']['quantity'],
        'content_hash': content_hash,
        'parties_hash': parties_hash(envelope['parties']),
        'terms_hash': envelope['terms']['task_hash'],
        'unit': envelope['terms']['unit'],
    }


def settle(envelope, signer, ledger, *, rail=None, as_of=None):
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import settle as next_settle
        return next_settle(envelope, signer, ledger, rail=rail, as_of=as_of)
    need(as_of is None, 'PROFILE_UPGRADE_REQUIRED')
    env = deepcopy(envelope)
    report = verify(env, ledger=ledger)
    if report['verdict'] in ('SETTLED', 'RELEASED'):
        return {'envelope': env, 'cid': content_id(env), 'settlement': env['settlement'],
                'verdict': report, 'replayed': True, 'chain_ledger_touched': False,
                'ledger_touched': False, 'payment_rail_touched': False, 'execution_authorized': False,
                'feedback_hint': _feedback_hint('settle')}
    need(report['verdict'] in ('DELIVERED', 'DECIDED'), 'NOT_SETTLEABLE')
    if report['verdict'] == 'DISPUTED':
        raise NativeError('DISPUTE_OPEN')
    decision = env['dispute']['decision'] if env.get('dispute') else None
    if decision and decision['result'] == 'INDETERMINATE':
        raise NativeError('SETTLE_INDETERMINATE')
    action = 'REFUND_PRINCIPAL' if decision and decision['result'] == 'REFUTED' else 'PAY_COUNTERPARTY'
    who = public_key(signer)
    content_hash = env['deliveries'][0]['content_hash'] if env['deliveries'] else env['dispute']['evidence_hash']
    body = release_body(env, action, content_hash)
    if decision is None:
        need(who == env['parties']['principal'], 'SIGNER_ROLE')
        authorization = sign(signer, RELEASE_LABEL, body)
        authorized_by = 'principal_release'
    else:
        need(who in {env['parties']['principal'], env['parties']['resolver'], env['parties']['appeal_resolver']},
             'SIGNER_ROLE')
        authorization = decision['signature']
        authorized_by = 'resolver_decision'
    chosen = rail or env['terms']['rail']
    need(chosen == env['terms']['rail'], 'RAIL')
    effect = escrow_id(env)
    if env.get('escrow') is None:
        ledger.move_to_escrow(effect, env['parties']['principal'], env['terms']['unit'], env['terms']['quantity'])
        env['escrow'] = {'id': effect, 'unit': env['terms']['unit'], 'amount': env['terms']['quantity'],
                         'payer': env['parties']['principal'], 'status': 'HELD',
                         'assurance': 'SIMULATED_STABLECOIN_LEDGER'}
    payee = env['parties']['principal'] if action == 'REFUND_PRINCIPAL' else env['parties']['counterparty']
    if action == 'PAY_COUNTERPARTY':
        ledger.pay(effect, payee)
    else:
        ledger.refund(effect)
    env['escrow']['status'] = 'PAID' if action == 'PAY_COUNTERPARTY' else 'REFUNDED'
    source = content_id(env)
    instruction = {'rail': chosen, 'x402': None, 'ap2': None}
    if chosen == 'x402':
        instruction['x402'] = x402_requirements(env['terms'], source, effect)
    else:
        if who == env['parties']['principal'] and decision is None:
            instruction['ap2'] = sign_ap2_mandate(signer, env['terms'], env['parties'], effect)
        else:
            # The principal already bound the terms. A resolver-directed AP2
            # payout reuses a mandate signed here only when the signer is the principal.
            if who == env['parties']['principal']:
                instruction['ap2'] = sign_ap2_mandate(signer, env['terms'], env['parties'], effect)
            else:
                instruction['ap2'] = {
                    'body': ap2_mandate_body(env['terms'], env['parties'], effect),
                    'signature': None,
                    'note': 'RESOLVER_DIRECTED_NO_PAYER_SIGNATURE',
                }
    env['settlement'] = {
        'action': action,
        'amount': env['terms']['quantity'],
        'asset': env['terms']['unit'],
        'assurance': 'SIMULATED_STABLECOIN_LEDGER_NOT_EXTERNAL_PAYMENT',
        'authorization': authorization,
        'authorized_by': authorized_by,
        'content_hash': content_hash,
        'external_tx': None,
        'external_verification': 'NOT_PERFORMED',
        'fee_schedule': 'DEFERRED_TO_ECONOMICS_MODULE',
        'instruction': instruction,
        'network': env['terms']['network'],
        'payee': payee,
        'payer': env['parties']['principal'],
        'protocol_fee': 0,
        'rail': chosen,
        'source_cid': source,
        'unit': env['terms']['unit'],
    }
    if decision is None:
        # Bind the receipt itself with the principal's release signature. The
        # authorization field already holds it; repeat the check in verify.
        need(signature_ok(env['parties']['principal'], RELEASE_LABEL, body, authorization), 'RELEASE_SIGNATURE')
    ledger.remember(effect, env['settlement'])
    verdict = verify(env, ledger=ledger)
    return {'envelope': env, 'cid': content_id(env), 'settlement': env['settlement'], 'verdict': verdict,
            'replayed': False,         'chain_ledger_touched': False, 'ledger_touched': False, 'payment_rail_touched': True,
            'execution_authorized': False, 'feedback_hint': _feedback_hint('settle')}


def release_if_silent(envelope, *, signer, ledger, as_of, rail=None):
    """Refund escrow when the counterparty or the referee stays silent.

    This is the existing RELEASE path for timeout RELEASE_IF_UNDECIDED. It is
    not a new refund verb. ``as_of`` is caller-supplied. No clock is read.
    """
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import settle as next_settle
        return next_settle(envelope, signer, ledger, rail=rail, as_of=as_of, silent=True)
    env = deepcopy(envelope)
    report = verify(env, ledger=ledger)
    if report['verdict'] == 'RELEASED' and (env.get('settlement') or {}).get('authorized_by') == 'release_if_undecided':
        return {'envelope': env, 'cid': content_id(env), 'settlement': env['settlement'],
                'verdict': report, 'replayed': True, 'refund_verb': None, 'native_op': 'RELEASE',
                'submitted': False, 'chain_ledger_touched': False, 'ledger_touched': False,
                'payment_rail_touched': False, 'execution_authorized': False}
    need(env['terms']['timeout'] == 'RELEASE_IF_UNDECIDED', 'TIMEOUT_POLICY')
    need(type(as_of) is int and not type(as_of) is bool and as_of > env['terms']['deadline'], 'SILENCE_NOT_DUE')
    need(report['verdict'] in ('BOUND', 'DISPUTED'), 'NOT_SETTLEABLE')
    if report['verdict'] == 'DISPUTED':
        need(env['dispute'].get('decision') is None, 'DISPUTE_OPEN')
    who = public_key(signer)
    need(who == env['parties']['principal'], 'SIGNER_ROLE')
    action = 'REFUND_PRINCIPAL'
    content_hash = env['terms']['task_hash']
    body = release_body(env, action, content_hash)
    authorization = sign(signer, RELEASE_LABEL, body)
    chosen = rail or env['terms']['rail']
    need(chosen == env['terms']['rail'], 'RAIL')
    effect = escrow_id(env)
    if env.get('escrow') is None:
        ledger.move_to_escrow(effect, env['parties']['principal'], env['terms']['unit'], env['terms']['quantity'])
        env['escrow'] = {'id': effect, 'unit': env['terms']['unit'], 'amount': env['terms']['quantity'],
                         'payer': env['parties']['principal'], 'status': 'HELD',
                         'assurance': 'SIMULATED_STABLECOIN_LEDGER'}
    ledger.refund(effect)
    env['escrow']['status'] = 'REFUNDED'
    source = content_id(env)
    instruction = {'rail': chosen, 'x402': None, 'ap2': None}
    if chosen == 'x402':
        instruction['x402'] = x402_requirements(env['terms'], source, effect)
    else:
        instruction['ap2'] = sign_ap2_mandate(signer, env['terms'], env['parties'], effect)
    env['settlement'] = {
        'action': action,
        'amount': env['terms']['quantity'],
        'asset': env['terms']['unit'],
        'assurance': 'SIMULATED_STABLECOIN_LEDGER_NOT_EXTERNAL_PAYMENT',
        'authorization': authorization,
        'authorized_by': 'release_if_undecided',
        'content_hash': content_hash,
        'external_tx': None,
        'external_verification': 'NOT_PERFORMED',
        'fee_schedule': 'DEFERRED_TO_ECONOMICS_MODULE',
        'instruction': instruction,
        'network': env['terms']['network'],
        'payee': env['parties']['principal'],
        'payer': env['parties']['principal'],
        'protocol_fee': 0,
        'rail': chosen,
        'source_cid': source,
        'unit': env['terms']['unit'],
    }
    need(signature_ok(env['parties']['principal'], RELEASE_LABEL, body, authorization), 'RELEASE_SIGNATURE')
    ledger.remember(effect, env['settlement'])
    verdict = verify(env, ledger=ledger)
    return {'envelope': env, 'cid': content_id(env), 'settlement': env['settlement'], 'verdict': verdict,
            'replayed': False, 'refund_verb': None, 'native_op': 'RELEASE', 'submitted': False,
            'silent_path': 'RELEASE', 'chain_ledger_touched': False, 'ledger_touched': False,
            'payment_rail_touched': True, 'execution_authorized': False}


def _feedback_hint(surface):
    from covenant_chain.feedback_intake import feedback_hint
    return feedback_hint(surface)


def _public_result(result):
    if type(result) is dict:
        try:
            canonical(result)
        except NativeError:
            return {'called': True, 'result': 'UNRECORDED'}
        return result
    return {'called': True}


def _collect_shape(envelope, checks, draft):
    ok_profile = _check(checks, 'PROFILE', type(envelope) is dict and envelope.get('profile') == PROFILE)
    if not ok_profile:
        return False
    allowed = {'profile', 'terms', 'parties', 'document', 'mandate', 'assents', 'deliveries', 'escrow', 'settlement', 'dispute', 'light'}
    required = allowed - {'light'}
    if not required <= set(envelope) <= allowed:
        _check(checks, 'FIELDS', False)
        return False
    terms = envelope.get('terms')
    parties = envelope.get('parties')
    if type(terms) is not dict:
        _check(checks, 'FIELDS', False)
        return False
    _check(checks, 'TERMS_VERSION', terms.get('version') == TERMS_VERSION)
    _check(checks, 'TASK_HASH', type(terms.get('task_hash')) is str and len(terms.get('task_hash', '')) == 64
           and all(c in '0123456789abcdef' for c in terms.get('task_hash', '')))
    _check(checks, 'QUANTITY', type(terms.get('quantity')) is int and 1 <= terms.get('quantity', 0) <= 2**53 - 1)
    unit = terms.get('unit')
    if unit in NATIVE_UNITS:
        _check(checks, 'NATIVE_TOKEN_SETTLEMENT_REFUSED', False)
    else:
        _check(checks, 'STABLECOIN_REQUIRED', unit in STABLECOINS)
    _check(checks, 'RAIL', terms.get('rail') in RAILS)
    _check(checks, 'PAY_TO', _ascii(terms.get('pay_to'), 256, 'PAY_TO'))
    _check(checks, 'DEADLINE', type(terms.get('deadline')) is int and 1 <= terms.get('deadline', 0) <= 2**53 - 1)
    _check(checks, 'CHALLENGE_WINDOW', type(terms.get('challenge_window')) is int and 1 <= terms.get('challenge_window', 0) <= 10_000_000)
    _check(checks, 'TIMEOUT_POLICY', terms.get('timeout') in TIMEOUTS)
    _check(checks, 'EFFECT', terms.get('effect') in EFFECTS)
    _check(checks, 'NETWORK', _ascii(terms.get('network'), 80, 'NETWORK'))
    expected_terms = {'version', 'task_hash', 'quantity', 'unit', 'rail', 'pay_to', 'deadline',
                      'challenge_window', 'timeout', 'effect', 'network'}
    _check(checks, 'FIELDS', set(terms) == expected_terms)
    if type(parties) is not dict:
        _check(checks, 'FIELDS', False)
        return False
    names = {'principal', 'agent', 'counterparty', 'executor', 'resolver', 'appeal_resolver'}
    keys_ok = set(parties) == names and all(
        type(parties.get(name)) is str and len(parties.get(name, '')) == 64 for name in names)
    from .codec import valid_ed25519_key
    keys_ok = keys_ok and all(valid_ed25519_key(parties[name]) for name in names)
    _check(checks, 'PUBLIC_KEY', keys_ok)
    if keys_ok:
        _check(checks, 'DISTINCT_PARTIES', parties['agent'] != parties['counterparty'])
        _check(checks, 'RESOLVER_CONFLICT',
               parties['resolver'] not in {parties['agent'], parties['counterparty']}
               and parties['appeal_resolver'] not in {parties['agent'], parties['counterparty'], parties['resolver']}
               and parties['executor'] not in {parties['resolver'], parties['appeal_resolver']})
    document = envelope.get('document')
    if type(document) is dict and 'text' in document and type(terms.get('task_hash')) is str:
        try:
            _check(checks, 'DOCUMENT_HASH', hash_document(document['text']) == terms['task_hash'] == document.get('sha256'))
        except NativeError as exc:
            _check(checks, exc.code, False)
    elif type(document) is dict and document.get('sha256') == terms.get('task_hash'):
        _check(checks, 'DOCUMENT_HASH', True)
    else:
        _check(checks, 'DOCUMENT_HASH', False)
    if not keys_ok:
        return True
    _collect_mandate(envelope, checks)
    _collect_assents(envelope, checks, draft)
    _collect_deliveries(envelope, checks)
    _collect_dispute(envelope, checks)
    _collect_settlement(envelope, checks)
    return True


def _collect_mandate(envelope, checks):
    parties = envelope['parties']
    mandate = envelope.get('mandate')
    if parties['principal'] == parties['agent']:
        _check(checks, 'MANDATE_UNEXPECTED', mandate is None)
        return
    if type(mandate) is not dict:
        _check(checks, 'MANDATE_REQUIRED', False)
        return
    body = mandate.get('body')
    if type(body) is not dict or set(body) != {'version', 'principal', 'holder', 'unit', 'limit', 'expiry', 'rails', 'effects'}:
        _check(checks, 'MANDATE_VERSION', False)
        return
    _check(checks, 'MANDATE_VERSION', body.get('version') == MANDATE_VERSION)
    _check(checks, 'MANDATE_PRINCIPAL', body.get('principal') == parties['principal'])
    _check(checks, 'MANDATE_HOLDER', body.get('holder') == parties['agent'])
    terms = envelope['terms']
    scope = (body.get('unit') == terms.get('unit') and type(body.get('limit')) is int
             and type(terms.get('quantity')) is int and terms['quantity'] <= body['limit']
             and type(body.get('expiry')) is int and type(terms.get('deadline')) is int
             and terms['deadline'] <= body['expiry']
             and body.get('rails') == sorted(set(body.get('rails') or [])) and terms.get('rail') in (body.get('rails') or [])
             and body.get('effects') == sorted(set(body.get('effects') or [])) and terms.get('effect') in (body.get('effects') or []))
    _check(checks, 'MANDATE_SCOPE', scope)
    _check(checks, 'SIGNATURE', signature_ok(body.get('principal'), MANDATE_LABEL, body, mandate.get('signature')))


def _collect_assents(envelope, checks, draft):
    parties = envelope['parties']
    rows = envelope.get('assents')
    if type(rows) is not list:
        _check(checks, 'AGENT_ASSENT', False)
        return
    body = assent_body(envelope['terms'], parties)
    seen = set()
    agent_ok = False
    counterparty_ok = False
    unknown = False
    role_bad = False
    sig_bad = False
    for row in rows:
        if type(row) is not dict or set(row) != {'signer', 'role', 'signature'}:
            sig_bad = True
            continue
        if row['signer'] in seen:
            _check(checks, 'DUPLICATE_ASSENT', False)
        seen.add(row['signer'])
        if row['signer'] == parties['agent'] and row['role'] == 'agent':
            agent_ok = signature_ok(row['signer'], ASSENT_LABEL, body, row['signature'])
            sig_bad = sig_bad or not agent_ok
        elif row['signer'] == parties['counterparty'] and row['role'] == 'counterparty':
            counterparty_ok = signature_ok(row['signer'], ASSENT_LABEL, body, row['signature'])
            sig_bad = sig_bad or not counterparty_ok
        elif row['signer'] in {parties['agent'], parties['counterparty']}:
            role_bad = True
        else:
            unknown = True
    if not draft:
        _check(checks, 'AGENT_ASSENT', agent_ok)
    elif not agent_ok:
        _check(checks, 'AGENT_ASSENT', False)
    _check(checks, 'COUNTERPARTY_ASSENT', counterparty_ok)
    if role_bad:
        _check(checks, 'ROLE_MISMATCH', False)
    if unknown:
        _check(checks, 'UNKNOWN_ASSENT', False)
    if sig_bad:
        _check(checks, 'SIGNATURE', False)


def _collect_deliveries(envelope, checks):
    rows = envelope.get('deliveries')
    if type(rows) is not list:
        _check(checks, 'DELIVERY', False)
        return
    if not rows:
        return
    parties = envelope['parties']
    allowed = {parties['counterparty'], parties['executor']}
    good = True
    for row in rows:
        if type(row) is not dict or not {'signer', 'signature', 'content_hash'} <= set(row):
            good = False
            continue
        if row['signer'] not in allowed or type(row['content_hash']) is not str or len(row['content_hash']) != 64:
            good = False
            continue
        good = good and signature_ok(row['signer'], DELIVER_LABEL, delivery_body(envelope, row['content_hash']), row['signature'])
    _check(checks, 'DELIVERY', good)


def _collect_dispute(envelope, checks):
    dispute = envelope.get('dispute')
    if dispute is None:
        return
    if type(dispute) is not dict:
        _check(checks, 'SIGNATURE', False)
        return
    parties = envelope['parties']
    body = {
        'action': 'OPEN',
        'evidence_hash': dispute.get('evidence_hash'),
        'parties_hash': parties_hash(parties),
        'reason': dispute.get('reason'),
        'terms_hash': envelope['terms'].get('task_hash'),
    }
    opener_ok = dispute.get('opener') in {parties['agent'], parties['counterparty']} and signature_ok(
        dispute.get('opener'), DISPUTE_LABEL, body, dispute.get('signature'))
    _check(checks, 'DISPUTE_AUTHORITY', opener_ok)
    decision = dispute.get('decision')
    if decision is None:
        return
    if type(decision) is not dict:
        _check(checks, 'DECISION_AUTHORITY', False)
        return
    dbody = {
        'evidence_hash': decision.get('evidence_hash'),
        'parties_hash': parties_hash(parties),
        'result': decision.get('result'),
        'terms_hash': envelope['terms'].get('task_hash'),
    }
    _check(checks, 'DECISION_AUTHORITY',
           decision.get('signer') in {parties['resolver'], parties['appeal_resolver']}
           and decision.get('result') in RESULTS
           and signature_ok(decision.get('signer'), DECIDE_LABEL, dbody, decision.get('signature')))


def _collect_settlement(envelope, checks):
    settlement = envelope.get('settlement')
    if settlement is None:
        return
    silence = (type(settlement) is dict and settlement.get('authorized_by') == 'release_if_undecided'
               and settlement.get('action') == 'REFUND_PRINCIPAL' and not envelope.get('deliveries')
               and not (envelope.get('dispute') or {}).get('decision')
               and envelope['terms'].get('timeout') == 'RELEASE_IF_UNDECIDED')
    if type(settlement) is not dict or not envelope.get('deliveries') and not (envelope.get('dispute') or {}).get('decision') and not silence:
        _check(checks, 'SETTLEMENT_BINDING', False)
        return
    terms = envelope['terms']
    parties = envelope['parties']
    try:
        pre = deepcopy(envelope)
        pre['settlement'] = None
        source = content_id(pre)
        effect = escrow_id(envelope)
    except NativeError:
        _check(checks, 'SETTLEMENT_BINDING', False)
        return
    content_hash = settlement.get('content_hash')
    action = settlement.get('action')
    payee = parties['principal'] if action == 'REFUND_PRINCIPAL' else parties['counterparty']
    bound = (settlement.get('source_cid') == source and settlement.get('unit') == terms.get('unit')
             and settlement.get('amount') == terms.get('quantity') and settlement.get('rail') == terms.get('rail')
             and settlement.get('payee') == payee and settlement.get('payer') == parties['principal']
             and settlement.get('protocol_fee') == 0 and settlement.get('external_verification') == 'NOT_PERFORMED')
    if envelope.get('deliveries'):
        bound = bound and content_hash == envelope['deliveries'][0]['content_hash']
    elif silence:
        bound = bound and content_hash == terms.get('task_hash')
    instruction = settlement.get('instruction') or {}
    if terms.get('rail') == 'x402':
        bound = bound and instruction.get('x402') == x402_requirements(terms, source, effect)
    elif terms.get('rail') == 'ap2':
        mandate = instruction.get('ap2')
        if settlement.get('authorized_by') == 'principal_release':
            bound = bound and mandate_ok(mandate, terms, parties, effect)
        else:
            bound = bound and type(mandate) is dict and mandate.get('body') == ap2_mandate_body(terms, parties, effect)
    else:
        bound = False
    if settlement.get('authorized_by') in ('principal_release', 'release_if_undecided'):
        body = release_body(envelope, action, content_hash)
        bound = bound and signature_ok(parties['principal'], RELEASE_LABEL, body, settlement.get('authorization'))
        if settlement.get('authorized_by') == 'release_if_undecided':
            bound = bound and silence
    elif settlement.get('authorized_by') == 'resolver_decision':
        decision = (envelope.get('dispute') or {}).get('decision') or {}
        bound = bound and settlement.get('authorization') == decision.get('signature')
    else:
        bound = False
    _check(checks, 'SETTLEMENT_BINDING', bound)


def _stage(envelope, checks):
    failed = {row['code'] for row in checks if not row['passed']}
    # A missing counterparty signature is the proposed stage, not damage,
    # unless later signatures already claim a finished covenant.
    soft = set()
    if 'COUNTERPARTY_ASSENT' in failed and not envelope.get('deliveries') and envelope.get('settlement') is None and envelope.get('dispute') is None:
        soft.add('COUNTERPARTY_ASSENT')
    hard = failed - soft
    if hard:
        return 'INVALID', False
    if 'COUNTERPARTY_ASSENT' in failed:
        return 'PROPOSED', True
    dispute = envelope.get('dispute')
    if dispute:
        settlement = envelope.get('settlement') or {}
        if settlement.get('authorized_by') == 'release_if_undecided' and settlement.get('action') == 'REFUND_PRINCIPAL':
            return 'RELEASED', True
        if dispute.get('decision') and envelope.get('settlement'):
            action = envelope['settlement'].get('action')
            return ('RELEASED' if action == 'REFUND_PRINCIPAL' else 'SETTLED'), True
        if dispute.get('decision'):
            return 'DECIDED', True
        return 'DISPUTED', True
    if envelope.get('settlement'):
        action = envelope['settlement'].get('action')
        return ('RELEASED' if action == 'REFUND_PRINCIPAL' else 'SETTLED'), True
    if envelope.get('deliveries'):
        return 'DELIVERED', True
    return 'BOUND', True


def compile_to_native(envelope, stage):
    """Map a local signature stage onto the native flow. This does not submit it.

    The stage on the envelope is not an agreement state. Chain state appears
    only after BIND, DECIDE, CHALLENGE, RESOLVE, EXECUTE or RELEASE, or the
    mission SERVICE_BOOK, SERVICE_DECIDE and SERVICE_SETTLE path.
    """
    timeout = None
    if type(envelope) is dict and type(envelope.get('terms')) is dict:
        timeout = envelope['terms'].get('timeout')
    release = timeout == 'RELEASE_IF_UNDECIDED'
    return {
        'ledger_status': 'NOT_RECORDED',
        'local_signature_stage': stage,
        'local_signature_stage_is_not_chain_state': True,
        'parallel_status': False,
        'native_flow': ['BIND', 'SHOW', 'DECIDE', 'CHALLENGE', 'RESOLVE', 'EXECUTE', 'RELEASE'],
        'service_flow': ['SERVICE_BOOK', 'SERVICE_DECIDE', 'SERVICE_SETTLE'],
        'recourse': 'CHALLENGE then RESOLVE, or RELEASE when the timeout is RELEASE_IF_UNDECIDED.',
        'release_if_referee_silent': release,
        'submitted': False,
        'execution_authorized': False,
    }


def verify(envelope, *, ledger=None, genesis=None, minimum_height=1, draft=False, as_of=None):
    if type(envelope) is dict and envelope.get('profile') == 'covenant-bilateral/0.2':
        from .bilateral_v2 import verify as next_verify
        return next_verify(envelope, ledger=ledger, as_of=as_of)
    checks = []
    notes = []
    light_assurance = None
    shaped = type(envelope) is dict
    if shaped:
        _collect_shape(envelope, checks, draft)
    else:
        _check(checks, 'PROFILE', False)
    verdict, ok = _stage(envelope if shaped else {}, checks)
    if shaped and type(envelope.get('document')) is dict and 'text' not in envelope['document'] and verdict != 'INVALID':
        notes.append('Document bytes are not in the bundle. Confirm task_hash out of band.')
    if shaped and envelope.get('escrow') and verdict != 'INVALID':
        notes.append('Escrow is a record on this envelope. It is not observed unless you pass the same ledger.')
    funds_observed = False
    if ledger is not None and shaped and envelope.get('settlement') and verdict in ('SETTLED', 'RELEASED'):
        effect = escrow_id(envelope)
        observed = ledger.observe(effect)
        funds_observed = observed['status'] == 'OBSERVED' and observed['value']['action'] == envelope['settlement']['action']
    if shaped and envelope.get('light'):
        light_assurance, light_notes, light_ok = _verify_light(envelope, genesis, minimum_height)
        notes.extend(light_notes)
        if not light_ok and light_assurance not in ('GENESIS_NOT_PINNED',):
            _check(checks, light_assurance if light_assurance in REMEDIATION else 'LIGHT_PROOF', False)
            verdict, ok = 'INVALID', False
        elif light_assurance == 'GENESIS_NOT_PINNED':
            notes.append(REMEDIATION['GENESIS_NOT_PINNED'])
    failures = [row for row in checks if not row['passed']]
    if verdict == 'PROPOSED':
        failures = [row for row in failures if row['code'] != 'COUNTERPARTY_ASSENT']
    code = 'OK' if ok else (failures[0]['code'] if failures else 'FIELDS')
    cid = None
    if shaped and ok:
        try:
            cid = content_id(envelope)
        except NativeError:
            cid = None
    assurance = 'OFFLINE_SIGNATURES'
    if light_assurance == 'COMMITTEE_CERTIFIED':
        assurance = 'COMMITTEE_CERTIFIED'
    elif light_assurance:
        assurance = 'SIGNATURES_ONLY'
    return {
        'version': VERSION,
        'verdict': verdict,
        'ok': ok,
        'complete': verdict in ('SETTLED', 'RELEASED'),
        'code': code,
        'checks': checks,
        'failures': failures,
        'remediation': [row['remediation'] for row in failures],
        'next_action': NEXT.get(verdict, NEXT['INVALID']),
        'cid': cid,
        'terms_hash': envelope['terms']['task_hash'] if shaped and type(envelope.get('terms')) is dict else None,
        'assurance': assurance,
        'chain_ledger_touched': False,
        'funds_observed': funds_observed,
        'expiry_checked': False,
        'execution_authorized': False,
        'notes': notes,
        'compiles_to': compile_to_native(envelope if shaped else None, verdict),
    }


def _verify_light(envelope, genesis, minimum_height):
    section = envelope.get('light')
    if type(section) is not dict or not {'bundle', 'table', 'key'} <= set(section):
        return 'LIGHT_PROOF', ['Light section is missing bundle, table or key.'], False
    if genesis is None:
        return 'GENESIS_NOT_PINNED', [], True
    try:
        from covenant_chain.crypto import genesis_id as chain_digest
        from covenant_chain.light import verify_light_bundle
    except ImportError:
        return 'LIGHT_VERIFIER_NOT_INSTALLED', [REMEDIATION['LIGHT_VERIFIER_NOT_INSTALLED']], True
    try:
        chain = chain_digest(genesis)
        report = verify_light_bundle(genesis, section['bundle'], chain, minimum_height, section['table'], section['key'])
    except (ValueError, TypeError, KeyError) as exc:
        code = str(exc)
        if code not in REMEDIATION:
            code = 'LIGHT_PROOF'
        return code, [REMEDIATION.get(code, str(exc))], False
    if section['table'] == 'agreements':
        value = report.get('value') or {}
        terms = value.get('terms') or {}
        parties = envelope['parties']
        if terms.get('terms_hash') != envelope['terms']['task_hash']:
            return 'LIGHT_TERMS', [REMEDIATION['LIGHT_TERMS']], False
        if (terms.get('principal') != parties['principal'] or terms.get('counterparty') != parties['counterparty']
                or terms.get('quantity') != envelope['terms']['quantity']):
            return 'LIGHT_PARTIES', [REMEDIATION['LIGHT_PARTIES']], False
    return 'COMMITTEE_CERTIFIED', ['Committee light proof matched the pinned genesis. History was not replayed.'], True


def verification_bundle(envelope, **extra):
    verdict = verify(envelope, **extra)
    return {
        'profile': 'covenant-verification-bundle/0.1',
        'cid': content_id(envelope) if verdict['ok'] else None,
        'envelope': envelope,
        'verdict': verdict,
    }
