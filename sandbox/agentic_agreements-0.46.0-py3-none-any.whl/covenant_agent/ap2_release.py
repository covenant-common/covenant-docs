"""AP2 release on verified delivery: an AP2 PaymentMandate bound to an AAP release condition.

The Agent Payments Protocol (AP2, google-agentic-commerce/AP2 v0.2.0,
Apache-2.0) proves that a user authorized a payment: the PaymentMandate
(vct mandate.payment.1, code/sdk/schemas/ap2/payment_mandate.json) names the
payee, the amount and the checkout (transaction_id is the base64url SHA-256 of
the merchant-signed checkout JWT, docs/ap2/specification.md "Payment
Mandate"). It does not prove delivery.

This module takes the decoded mandate claims, checks them against the AAP
commerce agreement (amount, currency, payee, expiry and, when supplied, the
checkout JWT hash) and builds a release condition both parties sign: release
only on a verified AAP delivery receipt that meets the typed acceptance
criteria. Evaluation reports whether the condition is met. It never releases,
pays or verifies the SD-JWT signature itself. New 0.2 conditions require an
owner-installed verifier to authenticate the exact mandate claims bytes and
its agreement-bound condition. Historical 0.1 keeps its optional-verifier
meaning when read and is explicitly labelled as legacy.
"""
import base64
import hashlib
import re

from covenant_language import agreement_application as application_profile

from . import commerce
from .errors import NativeError

LEGACY_CONDITION = 'urn:aap:ap2-release-condition:0.1'
LEGACY_CONDITION_LABEL = 'AAP-AP2-RELEASE-CONDITION-0.1'
CONDITION = 'urn:aap:ap2-release-condition:0.2'
CONDITION_LABEL = 'AAP-AP2-RELEASE-CONDITION-0.2'
VCT = 'mandate.payment.1'
B64URL = re.compile(r'[A-Za-z0-9_-]{1,256}\Z')

HINTS = {
    'AP2_MANDATE': 'Pass the decoded PaymentMandate claims (vct mandate.payment.1) as JSON: transaction_id, payee, payment_amount, payment_instrument.',
    'AP2_AMOUNT': 'The mandate amount differs from the agreed price. Obtain a mandate for the exact agreed amount.',
    'AP2_CURRENCY': 'The mandate currency differs from the agreed currency.',
    'AP2_PAYEE': 'The mandate payee id must equal the merchant named in the AAP agreement.',
    'AP2_EXPIRED': 'The mandate is expired at the owner-adopted time. Obtain a fresh mandate.',
    'AP2_NOT_YET_VALID': 'The mandate iat is later than the owner-adopted time.',
    'AP2_TRANSACTION': 'transaction_id must be the unpadded base64url SHA-256 of the exact checkout JWT.',
    'AP2_CONDITION': 'Pass the exact release condition returned by condition(), unchanged.',
    'AP2_CONDITION_CHANGED': 'The condition no longer matches the agreement or mandate. Build and sign a new condition.',
    'AP2_APPROVALS': 'Pass approvals as [{party, signature}] from buyer and seller over the condition assent payload.',
    'AP2_VERIFIER': 'Install the mandate verifier as an owner Python callable; tool input cannot supply one.',
}


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS.get(code) or commerce.HINTS[code])


def _text(value, limit, code='AP2_MANDATE'):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _time(value):
    need(value is None or type(value) is int and 0 <= value <= commerce.MAX, 'AP2_MANDATE')
    return value


def mandate(raw):
    """Decoded PaymentMandate claims (AP2 v0.2). Unknown claims are ignored, never copied."""
    value, data = commerce.document(raw, 65536)
    need(type(value) is dict and value.get('vct') == VCT, 'AP2_MANDATE')
    need(type(value.get('transaction_id')) is str and B64URL.fullmatch(value['transaction_id']) is not None, 'AP2_MANDATE')
    payee, amount, instrument = value.get('payee'), value.get('payment_amount'), value.get('payment_instrument')
    need(type(payee) is dict and type(amount) is dict and type(instrument) is dict, 'AP2_MANDATE')
    _text(payee.get('id'), 256); need(type(payee.get('name')) is str and 0 < len(payee['name']) <= 256, 'AP2_MANDATE')
    need(type(amount.get('amount')) is int and 0 <= amount['amount'] <= commerce.MAX and
         type(amount.get('currency')) is str and re.fullmatch('[A-Za-z]{3}', amount['currency']) is not None, 'AP2_MANDATE')
    _text(instrument.get('id'), 256); _text(instrument.get('type'), 64)
    execution = value.get('execution_date')
    need(execution is None or type(execution) is str and len(execution) <= 64 and execution.isprintable(), 'AP2_MANDATE')
    return {'vct': VCT, 'transaction_id': value['transaction_id'], 'payee': payee['id'], 'payee_name': payee['name'],
            'amount': amount['amount'], 'currency': amount['currency'], 'instrument_type': instrument['type'],
            'execution_date': execution, 'iat': _time(value.get('iat')), 'exp': _time(value.get('exp')),
            'sha256': hashlib.sha256(data).hexdigest()}


def transaction_id(checkout_jwt):
    """AP2: base64url SHA-256 of the checkout JWT, without padding."""
    _text(checkout_jwt, 65536, 'AP2_TRANSACTION')
    return base64.urlsafe_b64encode(hashlib.sha256(checkout_jwt.encode('ascii')).digest()).rstrip(b'=').decode('ascii')


def _checked(application, agreement, raw_mandate, as_of, checkout_jwt, version=CONDITION):
    t = commerce.terms(application); commerce._hex(agreement)
    need(type(as_of) is int and 0 <= as_of <= commerce.MAX, 'COMMERCE_CLOCK')
    m = mandate(raw_mandate)
    need(m['amount'] == t['amount'], 'AP2_AMOUNT')
    need(m['currency'].lower() == t['currency'].lower(), 'AP2_CURRENCY')
    need(m['payee'] == t['merchant'], 'AP2_PAYEE')
    need(m['iat'] is None or m['iat'] <= as_of, 'AP2_NOT_YET_VALID')
    binding = 'NOT_CHECKED_NO_CHECKOUT_JWT'
    if checkout_jwt is not None:
        need(transaction_id(checkout_jwt) == m['transaction_id'], 'AP2_TRANSACTION')
        binding = 'CHECKOUT_JWT_HASH_MATCHES'
    need(version in (CONDITION, LEGACY_CONDITION), 'AP2_CONDITION')
    body = {'version': version, 'agreement': agreement, 'application': t['application'], 'mandate': m['sha256'],
            'vct': VCT, 'transaction_id': m['transaction_id'], 'amount': m['amount'], 'currency': m['currency'],
            'payee': m['payee'], 'criteria': t['criteria'], 'requires': 'VERIFIED_AAP_DELIVERY_RECEIPT_MEETS_CRITERIA',
            'receipt_signer': 'buyer', 'not_after': m['exp'], 'on_failure': t['remedy']}
    return t, m, body, binding


def condition(application, agreement, raw_mandate, *, as_of, checkout_jwt=None):
    """A release condition linking the mandate to a verified AAP delivery receipt, for both parties to sign."""
    t, m, body, binding = _checked(application, agreement, raw_mandate, as_of, checkout_jwt)
    need(m['exp'] is None or as_of < m['exp'], 'AP2_EXPIRED')
    return {'condition': body, 'id': application_profile.content_id(CONDITION, body),
            'assent_payload': {'label': CONDITION_LABEL, 'body': body, 'required_signers': dict(t['parties'])},
            'transaction_binding': binding, 'mandate_signature': 'NOT_VERIFIED_SD_JWT_NEEDS_OWNER_VERIFIER',
            'release': 'ONLY_WHEN_EVALUATE_REPORTS_RELEASE_CONDITION_MET', **commerce.FLAGS}


def evaluate(application, agreement, condition_body, approvals, raw_mandate, receipt, adoption, *, as_of,
             checkout_jwt=None, mandate_verifier=None):
    """Is the release condition met? A decision record only; it moves no funds."""
    from covenant_chain.crypto import verify as verify_signature
    need(type(condition_body) is dict, 'AP2_CONDITION')
    t, m, rebuilt, binding = _checked(application, agreement, raw_mandate, as_of, checkout_jwt, condition_body.get('version'))
    legacy = rebuilt['version'] == LEGACY_CONDITION
    label = LEGACY_CONDITION_LABEL if legacy else CONDITION_LABEL
    need(application_profile.canonical(rebuilt) == application_profile.canonical(condition_body), 'AP2_CONDITION_CHANGED')
    need(type(approvals) is list and len(approvals) <= 2, 'AP2_APPROVALS')
    signed = set()
    for approval in approvals:
        need(type(approval) is dict and set(approval) == {'party', 'signature'} and approval['party'] in t['parties']
             and approval['party'] not in signed, 'AP2_APPROVALS')
        try:
            verify_signature(t['parties'][approval['party']], label, rebuilt, approval['signature'])
        except ValueError:
            raise NativeError('AP2_APPROVALS', HINTS['AP2_APPROVALS']) from None
        signed.add(approval['party'])
    adopted = signed == {'buyer', 'seller'}
    signature = 'NOT_VERIFIED_SD_JWT_NEEDS_OWNER_VERIFIER'
    if mandate_verifier is not None:
        need(callable(mandate_verifier), 'AP2_VERIFIER')
        # The successor gives the owner verifier exact received claims bytes and the
        # entire signed condition, including agreement and mandate digest. Tool data
        # cannot install this callable or provide its verdict. Legacy keeps its ABI.
        evidence = m['sha256'] if legacy else commerce.document(raw_mandate, 65536)[1]
        signature = 'VERIFIED_BY_OWNER_INSTALLED_VERIFIER' if mandate_verifier(evidence, dict(rebuilt)) is True else 'REFUSED_BY_OWNER_VERIFIER'
    checked = None if receipt is None else commerce.verify_receipt(application, agreement, receipt, adoption)
    expired = m['exp'] is not None and as_of >= m['exp']
    if not adopted:
        status = 'UNKNOWN_CONDITION_NOT_ADOPTED_BY_BOTH_PARTIES'
    elif signature == 'REFUSED_BY_OWNER_VERIFIER':
        status = 'RELEASE_REFUSED_MANDATE_NOT_VERIFIED'
    elif not legacy and signature != 'VERIFIED_BY_OWNER_INSTALLED_VERIFIER':
        status = 'NEEDS_ADOPTED_MANDATE_VERIFIER'
    elif expired:
        status = 'MANDATE_EXPIRED'
    elif checked is None:
        status = 'UNKNOWN_NO_DELIVERY_RECEIPT'
    elif checked['delivery_verified']:
        status = 'RELEASE_CONDITION_MET'
    elif checked['verdict'] == 'FAILS' and checked['agreement_adoption'] == 'VERIFIED':
        status = 'RELEASE_REFUSED_CRITERIA_NOT_MET'
    else:
        status = 'UNKNOWN_DELIVERY_NOT_VERIFIED'
    return {'condition': application_profile.content_id(rebuilt['version'], rebuilt), 'status': status,
            'receipt': None if checked is None else checked['receipt'],
            'verdict': None if checked is None else checked['verdict'],
            'mandate': m['sha256'], 'mandate_signature': signature,
            'profile_assurance': 'LEGACY_0.1_MANDATE_VERIFICATION_OPTIONAL' if legacy else '0.2_REQUIRES_ADOPTED_MANDATE_VERIFIER',
            'release_authorized': False, 'transaction_binding': binding,
            'on_failure': t['remedy'] if status == 'RELEASE_REFUSED_CRITERIA_NOT_MET' else None,
            'clock': 'OWNER_ADOPTED_ASSERTION_NOT_OBSERVED',
            'next': 'Present the condition, its approvals and the verified receipt to the payment processor or the escrow '
                    'quorum. This record moves no funds.' if status == 'RELEASE_CONDITION_MET' else
                    'Do not release. Follow the agreed remedy or obtain the missing evidence.',
            **commerce.FLAGS}
