"""A2A Agent Card extension, ERC-8004 export, and framework tool specs.

These are records and schemas. Nothing here posts to Ethereum, probes a URL,
or imports the OpenAI or LangChain packages. The chain-bound ERC-8004 pointer
(experimental, from Cursor PR 77 WP-12) names a native ledger receipt by
``covenant:{chain_id}:{receipt}``; it is a pointer, not a validation result.
"""
from .codec import HEX, canonical, valid_ed25519_key
from .envelope import VERSION, content_id, verify
from .errors import need
from .mcp import tool_descriptors

EXTENSION_URI = 'https://covenant.dev/extensions/agent-native/0.1'
CARD_VERSION = 'covenant-a2a-card/0.1'
ACCEPTED_PROFILES = (
    'covenant-work-order/0.1',
    'covenant-bilateral/0.1',
    'covenant-pay-with-recourse/0.1',
)
LOCAL_VERIFIER = 'LOCAL_ENVELOPE_VERIFY'
ERC8004_LEDGER_URI = 'covenant:{chain_id}:{receipt}'


def agent_card(*, name, url, description='Covenant work orders: exact terms, held stablecoin, named resolver, receipt.',
               verifier=LOCAL_VERIFIER, profiles=None):
    need(type(name) is str and 1 <= len(name) <= 80, 'FIELDS')
    need(type(url) is str and url.startswith('https://') and len(url) <= 200, 'FIELDS')
    need(type(description) is str and 1 <= len(description) <= 400, 'FIELDS')
    if verifier != LOCAL_VERIFIER:
        need(type(verifier) is str and bool(HEX.fullmatch(verifier)) and valid_ed25519_key(verifier), 'PUBLIC_KEY')
    accepted = list(ACCEPTED_PROFILES if profiles is None else profiles)
    need(1 <= len(accepted) <= 8, 'FIELDS')
    for profile in accepted:
        need(type(profile) is str and 1 <= len(profile) <= 80, 'FIELDS')
    verbs = ['covenant_propose', 'covenant_accept', 'covenant_deliver', 'covenant_verify', 'covenant_settle']
    return {
        'protocolVersion': '1.0',
        'name': name,
        'description': description,
        'url': url,
        'version': '0.1.0',
        'defaultInputModes': ['application/json'],
        'defaultOutputModes': ['application/json'],
        'capabilities': {
            'streaming': False,
            'extensions': [{
                'uri': EXTENSION_URI,
                'description': 'Five-verb Covenant work orders with offline verify and x402 or AP2 settlement.',
                'required': False,
                'params': {
                    'profile': CARD_VERSION,
                    'verbs': verbs,
                    'oneCall': 'covenant_make',
                    'lightVerify': 'covenant_light_verify',
                    'profiles': accepted,
                    'acceptedProfiles': accepted,
                    'verifier': verifier,
                    'verifierProvesEndpoint': False,
                    'settlement': ['x402', 'ap2'],
                    'units': ['USDC', 'USDT', 'DAI', 'USDG'],
                    'nativeTokenSettlement': False,
                    'offlineDefault': True,
                    'provesEndpoint': False,
                },
            }],
        },
        'skills': [{
            'id': 'covenant-work-order',
            'name': 'Covenant work order',
            'description': description,
            'tags': ['covenant', 'escrow', 'x402', 'ap2'],
            'inputModes': ['application/json'],
            'outputModes': ['application/json'],
        }],
    }


def erc8004_validation(envelope):
    """Export a settled receipt as an ERC-8004-shaped validation record.

    ``posted`` is false. This function does not send a transaction.
    """
    report = verify(envelope)
    need(report['complete'], 'NOT_SETTLEABLE')
    honoured = report['verdict'] == 'SETTLED'
    return {
        'schema': 'erc8004-validation-export/0.1',
        'standard': 'ERC-8004',
        'posted': False,
        'agent': envelope['parties']['counterparty'],
        'validator': envelope['parties']['resolver'],
        'covenant_cid': report['cid'],
        'terms_hash': report['terms_hash'],
        'outcome': 'HONOURED' if honoured else 'REFUNDED',
        'response': 1 if honoured else 0,
        'tag': 'covenant-receipt',
        'evidence_hash': envelope['settlement']['content_hash'],
        'rail': envelope['settlement']['rail'],
        'assurance': 'OFFLINE_BILATERAL_RECEIPT_NOT_AN_ETHEREUM_TRANSACTION',
        'version': VERSION,
    }


def erc8004_pointer(chain_id, receipt):
    """ERC-8004 response URI for a native ledger receipt, bound to one chain id.

    ``posted`` is false and the issuer key is not part of it. A verifier still
    reads the receipt from that chain; the pointer proves nothing by itself.
    """
    need(type(chain_id) is str and bool(HEX.fullmatch(chain_id)), 'FIELDS')
    need(type(receipt) is str and bool(HEX.fullmatch(receipt)), 'FIELDS')
    return {
        'schema': 'erc8004-ledger-pointer/0.1',
        'standard': 'ERC-8004',
        'posted': False,
        'uri': ERC8004_LEDGER_URI.format(chain_id=chain_id, receipt=receipt),
        'chainId': chain_id,
        'receipt': receipt,
        'issuer_on_ledger': False,
        'assurance': 'POINTER_TO_A_LEDGER_RECEIPT_NOT_A_VALIDATION',
        'execution_authorized': False,
    }


def erc8004_pointer_bound(record, chain_id):
    """True only when the pointer names this chain id and its own receipt."""
    if type(record) is not dict or type(chain_id) is not str or not HEX.fullmatch(chain_id):
        return False
    receipt = record.get('receipt')
    if type(receipt) is not str or not HEX.fullmatch(receipt):
        return False
    return record.get('chainId') == chain_id and record.get('uri') == ERC8004_LEDGER_URI.format(
        chain_id=chain_id, receipt=receipt)


def openai_function_tools():
    """Tool definitions in the OpenAI Responses / Agents SDK function shape.

    The package does not import openai. Bind the callbacks in the host.
    """
    return [{'type': 'function', 'name': tool['name'], 'description': tool['description'],
             'parameters': tool['inputSchema']} for tool in tool_descriptors()]


def langchain_tool_specs():
    """Specs a LangChain StructuredTool can wrap. LangChain is not required."""
    specs = [{'name': tool['name'], 'description': tool['description'], 'args_schema': tool['inputSchema']}
             for tool in tool_descriptors()]
    try:
        import langchain_core  # noqa: F401
        installed = True
    except ImportError:
        installed = False
    return {'installed': installed, 'specs': specs,
            'note': 'Bind these specs to host callbacks. No model is imported or called.'}


def offer_artifact(envelope, *, name='Covenant offer', verifier=LOCAL_VERIFIER):
    """One A2A artifact for a covenant offer. The connector does not adopt extensions."""
    need(type(name) is str and 1 <= len(name) <= 200, 'FIELDS')
    if verifier != LOCAL_VERIFIER:
        need(type(verifier) is str and bool(HEX.fullmatch(verifier)) and valid_ed25519_key(verifier), 'PUBLIC_KEY')
    covenant_id = content_id(envelope)
    payload = {
        'profile': envelope['profile'],
        'covenant_id': covenant_id,
        'terms_hash': envelope['terms']['task_hash'],
        'quantity': envelope['terms']['quantity'],
        'unit': envelope['terms']['unit'],
        'rail': envelope['terms']['rail'],
        'verifier': verifier,
    }
    return {
        'artifactId': covenant_id,
        'name': name,
        'description': 'Covenant offer pinned by content id',
        'parts': [{'mediaType': 'application/vnd.covenant-offer+json', 'text': canonical(payload).decode('ascii')}],
        'metadata': {
            'profile': envelope['profile'],
            'covenant_id': covenant_id,
            'terms_hash': envelope['terms']['task_hash'],
            'acceptedProfiles': list(ACCEPTED_PROFILES),
            'verifier': verifier,
            'provesEndpoint': False,
        },
    }


def offer_task(envelope, *, name='Covenant offer', verifier=LOCAL_VERIFIER):
    """Local A2A task. No URL is fetched and no extension is installed on the connector."""
    artifact = offer_artifact(envelope, name=name, verifier=verifier)
    return {
        'id': artifact['metadata']['covenant_id'],
        'contextId': envelope['terms']['task_hash'],
        'status': {'state': 'TASK_STATE_SUBMITTED'},
        'artifacts': [artifact],
    }
