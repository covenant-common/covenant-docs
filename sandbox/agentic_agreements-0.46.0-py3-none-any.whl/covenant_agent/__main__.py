"""python -m covenant_agent prints the seven jobs; --all every action; --write refreshes the reference."""
from .navigate import main

if __name__ == '__main__':
    raise SystemExit(main())
