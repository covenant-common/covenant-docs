"""Key-free owner handoff and explicit, read-only synthetic custody inspection.

Only the owner CLI reads local paths. This module installs no provider, launches
no host and grants no authority. Inspection reads private custody internally;
its response is an allowlist, never a returned configuration or exception text.
"""
import json
import errno
import os
from pathlib import Path
import re
import sqlite3
import stat
import sys

from .codec import key_from_seed, public_key
from .errors import NativeError, need
from .mcp import HOST_VERSION

ROLES = ('buyer', 'seller', 'resolver', 'appeal')
PROFILE = 'covenant-bilateral/0.2'
HEX = re.compile(r'[0-9a-f]{64}\Z')


def handoff():
    """Static typed discovery: safe for agent tools; never reads a local path."""
    return {'format': 'covenant-owner-setup-handoff/0.1',
        'status': 'OWNER_INSPECTION_REQUIRED',
        'inspection': {'interface': 'OWNER_LOCAL_CLI_ONLY',
            'command': ['python', '-m', 'covenant_agent.demo_setup', '--inspect',
                        '--directory', '/OWNER_SELECTED_EXISTING_DEMO'],
            'input_schema': {'type': 'object', 'additionalProperties': False,
                'properties': {'directory': {'type': 'string', 'minLength': 1},
                    'expected_authority': {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}},
                'required': ['directory']},
            'optional_pin_flag': '--expected-authority',
            'checks': ['PRIVATE_OWNER_CUSTODY', 'EXACT_DEMO_CONFIG', 'ROLE_IDENTITIES',
                       'MANIFEST_BINDING', 'REFERENCE_AUTHORITY_PIN', 'FIXED_OR_REAL_CLOCK'],
            'reads_private_custody_in_owner_process': True,
            'agent_receives': 'ALLOWLISTED_STATUS_ONLY_NEVER_CONFIG_BYTES',
            'changes_files': False},
        'owner_choices': [
            {'component': 'custody', 'required': 'Each real party installs its own signing custody; the demo owner controls all four synthetic actors.'},
            {'component': 'provider', 'required': 'Owner adopts a payment provider and its exact authority pin; local reference SQLite is synthetic only.'},
            {'component': 'configuration', 'required': 'Owner selects the exact work-order version, separate role hosts and clock; inspection only recognizes the generated synthetic demo.'},
            {'component': 'delegation', 'required': 'Native principal policy and a live scoped grant require their own configured native host and current state. They do not authorize this separate bilateral host.'},
            {'component': 'builder_registries', 'required': 'Owner writes key-free publisher and account trust, then starts the runtime host with load_builder registries. Application backends stay owner-registered Python handlers.',
             'command': ['python', '-m', 'covenant_agent.owner_config', 'builder', '--directory', '/OWNER_SELECTED_DIRECTORY',
                         '--publisher', 'PUBLISHER_ACCOUNT_HEX=PUBLISHER_PUBLIC_KEY_HEX']},
            {'component': 'external_rail', 'required': 'Owner may declare an x402 or AP2 payment method by network and credential variable name. This package runs no outside payment method; a declaration stays DECLARED_NOT_EXECUTABLE.',
             'command': ['python', '-m', 'covenant_agent.owner_config', 'rail', '--directory', '/OWNER_SELECTED_DIRECTORY',
                         '--rail', 'x402', '--network', 'OWNER_SELECTED_NETWORK', '--credential-env', 'OWNER_CREDENTIAL_VARIABLE_NAME']},
            {'component': 'durable_evidence', 'required': 'Owner adds content_dir, an existing private directory, to a host config so kept IDs survive restart; covenant_evidence_export and covenant_evidence_import move pinned bundles between hosts.'}],
        'boundaries': ['MANIFEST_IS_NOT_A_TRUST_CREDENTIAL',
                       'SNAPSHOT_IS_NOT_A_LIVE_HOST_OR_PAYMENT_PROBE',
                       'NO_PRODUCTION_PROVIDER_INSTALLER',
                       'NO_INHERITED_PRINCIPAL_MANDATE_AUTHORITY',
                       'DECLARED_RAIL_IS_NOT_AN_EXECUTABLE_RAIL'],
        'guide': 'docs/OWNER_SETUP.html', 'custody_created': False,
        'provider_installed': False, 'execution_authorized': False,
        'network_accessed': False, 'persisted': False}


def _stamp(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_ctime_ns, info.st_mode, info.st_uid, info.st_nlink)


def _open_directory(directory):
    need(isinstance(directory, (str, Path)) and str(directory).strip(), 'OWNER_DIRECTORY')
    path = Path(directory).expanduser().absolute()
    need('..' not in path.parts, 'OWNER_DIRECTORY')
    # Walk without resolving symlinks, including intermediate components. No
    # untrusted manifest path can redirect any of these descriptor-relative reads.
    fd = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        info = os.fstat(fd)
        need(info.st_uid == os.getuid() and info.st_mode & 0o077 == 0, 'OWNER_DIRECTORY_PERMISSIONS')
        return path, fd
    except BaseException:
        os.close(fd)
        raise


def _read(fd, name, *, limit=65536):
    opened = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
    try:
        info = os.fstat(opened)
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
             info.st_uid == os.getuid() and info.st_mode & 0o077 == 0,
             'OWNER_FILE_PERMISSIONS')
        need(info.st_size <= limit, 'OWNER_FILE_TOO_LARGE')
        with os.fdopen(opened, 'rb', closefd=False) as stream:
            raw = stream.read(limit + 1)
        need(len(raw) <= limit and _stamp(info) == _stamp(os.fstat(opened)),
             'OWNER_SNAPSHOT_CHANGED')
        return raw, _stamp(info)
    finally:
        os.close(opened)


def _json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'OWNER_JSON')
            result[key] = value
        return result
    try:
        result = json.loads(raw, object_pairs_hook=pairs)
    except (ValueError, UnicodeError, RecursionError):
        raise NativeError('OWNER_JSON') from None
    need(type(result) is dict, 'OWNER_JSON')
    return result


def _clock(config):
    clock = config.get('clock_time')
    need('clock_time' not in config or (type(clock) is int and 0 <= clock <= 2**53 - 1),
         'OWNER_CLOCK')
    return {'mode': 'REAL_LOCAL_TIME' if clock is None else 'SANDBOX_FIXED', 'at': clock}


def _manifest(value, path):
    need(value.get('format') == 'covenant-reference-demo/0.1' and
         value.get('synthetic_only') is True and value.get('profile') == PROFILE and
         value.get('directory') == str(path) and
         value.get('provider') == 'SINGLE_LOCAL_SQLITE_REFERENCE_AUTHORITY', 'OWNER_MANIFEST')
    need(type(value.get('settlement_authority')) is str and
         HEX.fullmatch(value['settlement_authority']), 'OWNER_MANIFEST')
    clock = value.get('clock')
    need(type(clock) is dict and set(clock) == {'mode', 'at'} and
         ((clock['mode'] == 'REAL_LOCAL_TIME' and clock['at'] is None) or
          (clock['mode'] == 'SANDBOX_FIXED' and type(clock['at']) is int and
           0 <= clock['at'] <= 2**53 - 1)), 'OWNER_MANIFEST_CLOCK')
    hosts = value.get('hosts')
    need(type(hosts) is dict and set(hosts) == set(ROLES), 'OWNER_MANIFEST')
    for role in ROLES:
        host = hosts[role]
        need(type(host) is dict and type(host.get('identity')) is str and
             HEX.fullmatch(host['identity']) and
             host.get('config_path') == str(path / (role + '.json')), 'OWNER_MANIFEST')
    need(len({hosts[role]['identity'] for role in ROLES}) == 4, 'OWNER_MANIFEST')


def _authority(raw):
    # An in-memory snapshot cannot initialize/migrate/refund the original DB or
    # create journal/WAL files. Active journals are refused by the caller.
    db = sqlite3.connect(':memory:')
    try:
        need(hasattr(db, 'deserialize'), 'OWNER_SQLITE_SNAPSHOT_UNAVAILABLE')
        db.deserialize(raw)
        db.execute('PRAGMA query_only=ON')
        db.execute('PRAGMA trusted_schema=OFF')
        db.set_progress_handler(lambda: 1, 100000)
        tables = db.execute("SELECT name FROM sqlite_schema WHERE type='table' "
                            "AND name IN ('reference_state', 'reference_records')").fetchall()
        need({row[0] for row in tables} == {'reference_state', 'reference_records'}, 'OWNER_PROVIDER')
        db.execute('SELECT kind, key, value FROM reference_records LIMIT 0')
        row = db.execute('SELECT value FROM reference_state WHERE id=1 AND length(value)<=65536').fetchone()
        need(row is not None, 'OWNER_PROVIDER')
        value = _json(row[0])
        need(value.get('storage_format') == 'covenant-reference-settlement-sqlite/0.2' and
             type(value.get('instance')) is str and HEX.fullmatch(value['instance']),
             'OWNER_PROVIDER')
        return value['instance']
    finally:
        db.close()


def inspect_demo(directory, *, expected_authority=None):
    """Inspect only an existing generated demo; never instantiate a runtime host.

    The local manifest is a consistency reference, not an external trust root.
    A separately retained authority pin can optionally be checked as well.
    Results are point-in-time setup evidence, not execution/payment authority.
    """
    result = {'format': 'covenant-owner-readiness/0.1', 'synthetic_only': True,
        'status': 'OWNER_ACTION_REQUIRED', 'components': [], 'hosts': {},
        'settlement_authority': None, 'profile': PROFILE, 'clock': None,
        'external_pin_checked': False, 'private_keys_in_output': False,
        'execution_authorized': False, 'payment_verified': False,
        'host_liveness': 'NOT_CHECKED', 'production_readiness': 'NOT_ASSESSED',
        'provider_observation': 'STORAGE_SHAPE_AND_AUTHORITY_PIN_ONLY',
        'principal_mandate_authority': 'NOT_INHERITED_BY_BILATERAL_HOST',
        'network_accessed': False, 'persisted': False,
        'observation': 'LOCAL_FILE_SNAPSHOT_RECHECK_BEFORE_USE'}
    stamps = {}

    def check(component, action, next_step):
        try:
            value = action()
        except (NativeError, OSError, ValueError, TypeError, KeyError, sqlite3.Error) as exc:
            # Fixed labels only: exception messages and private input values
            # must never appear in an agent-visible response.
            code = exc.code if isinstance(exc, NativeError) else 'OWNER_INVALID_COMPONENT'
            if isinstance(exc, OSError):
                code = {errno.ENOENT: 'OWNER_FILE_MISSING', errno.ELOOP: 'OWNER_SYMLINK',
                        errno.ENOTDIR: 'OWNER_DIRECTORY_OR_SYMLINK',
                        errno.EACCES: 'OWNER_ACCESS_DENIED'}.get(exc.errno, 'OWNER_FILE_UNREADABLE')
            result['components'].append({'component': component, 'status': 'BLOCKED',
                                         'code': code, 'next': next_step})
            return None
        result['components'].append({'component': component, 'status': 'CHECKED'})
        return value

    opened = check('directory', lambda: _open_directory(directory),
        'Select an existing owner-private demo directory with no symlink path components. No files were created.')
    if opened is None:
        return result
    path, fd = opened
    try:
        directory_stamp = _stamp(os.fstat(fd))

        def read(name, **kwargs):
            raw, stamp = _read(fd, name, **kwargs)
            stamps[name] = stamp
            return raw

        def manifest():
            value = _json(read('manifest.json'))
            _manifest(value, path)
            return value

        value = check('manifest', manifest,
            'Restore the original key-free manifest for this exact directory; do not adopt pins from an unrelated or edited manifest.')
        if value is None:
            return result
        clocks = []
        for role in ROLES:
            def config(role=role):
                private = _json(read(role + '.json'))
                required = {'version', 'seed', 'sandbox', 'work_order_profile', 'settlement_db'}
                need(required <= set(private) <= required | {'clock_time'}, 'OWNER_CONFIG_FIELDS')
                need(private['version'] == HOST_VERSION, 'OWNER_CONFIG_VERSION')
                need(private['sandbox'] is True, 'OWNER_CONFIG_SANDBOX')
                need(private['work_order_profile'] == PROFILE, 'OWNER_CONFIG_PROFILE')
                need(private['settlement_db'] == str(path / 'reference.sqlite'), 'OWNER_CONFIG_PROVIDER_PATH')
                identity = public_key(key_from_seed(private['seed']))
                need(identity == value['hosts'][role]['identity'], 'OWNER_IDENTITY')
                clock = _clock(private)
                need(clock == value.get('clock'), 'OWNER_CLOCK')
                return {'identity': identity, 'clock': clock}
            found = check('host:' + role, config,
                'Owner checks ' + role + '.json: private regular one-key file, current host version, /0.2 sandbox profile, original role identity, shared reference DB path and manifest clock. Restore from retained custody; never paste secrets into tool arguments.')
            if found is not None:
                clocks.append(found['clock'])

        def provider():
            for suffix in ('-wal', '-shm', '-journal'):
                try:
                    os.stat('reference.sqlite' + suffix, dir_fd=fd, follow_symlinks=False)
                except FileNotFoundError:
                    continue
                raise NativeError('OWNER_PROVIDER_BUSY')
            pin = _authority(read('reference.sqlite', limit=32 * 1024 * 1024))
            need(pin == value['settlement_authority'], 'OWNER_AUTHORITY_PIN')
            if expected_authority is not None:
                need(type(expected_authority) is str and HEX.fullmatch(expected_authority) and
                     pin == expected_authority, 'OWNER_AUTHORITY_PIN')
            return pin
        pin = check('provider', provider,
            'Owner checks private reference.sqlite and its original authority pin. Close active writers before retrying; snapshots over 32 MiB or active journals need separate owner review. Inspection never initializes, migrates or funds storage.')

        def stable():
            need(directory_stamp == _stamp(os.fstat(fd)), 'OWNER_SNAPSHOT_CHANGED')
            need(directory_stamp == _stamp(path.stat(follow_symlinks=False)), 'OWNER_SNAPSHOT_CHANGED')
            for name, stamp in stamps.items():
                need(stamp == _stamp(os.stat(name, dir_fd=fd, follow_symlinks=False)),
                     'OWNER_SNAPSHOT_CHANGED')
            return True
        check('snapshot', stable, 'Directory or files changed during inspection. Stop writers and inspect again before using any result.')
        if all(row['status'] == 'CHECKED' for row in result['components']):
            result['status'] = 'READY_FOR_SYNTHETIC_HOST_LAUNCH'
            result['settlement_authority'] = pin
            result['external_pin_checked'] = expected_authority is not None
            result['clock'] = clocks[0]
            for role in ROLES:
                config_path = str(path / (role + '.json'))
                result['hosts'][role] = {'identity': value['hosts'][role]['identity'],
                    'command': sys.executable,
                    'args': ['-m', 'covenant_agent.server', '--config', config_path]}
            result['next'] = 'Launch selected synthetic hosts separately, discover their actual schemas and independently observe any retained settlement. Fixed sandbox clocks do not advance after restart.'
        return result
    finally:
        os.close(fd)
