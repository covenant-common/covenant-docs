"""Pinned-key JWS cards over a bounded ASCII/integer JCS-compatible subset.

No jku fetch, implicit key trust, OAuth, endpoint authorization, revocation feed,
or full protobuf normalization is inferred. Sign normalized explicit-presence
cards; this subset refuses empty repeated fields before JCS canonicalization.
"""
from copy import deepcopy
import base64
import re
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from .codec import canonical, loads, digest, public_key, valid_ed25519_key, exact
from .errors import need

PROFILE = 'covenant-signed-card-subset/0.1'
_REPEATED = frozenset(('supportedInterfaces', 'skills', 'tags', 'examples', 'inputModes',
                      'outputModes', 'defaultInputModes', 'defaultOutputModes',
                      'securityRequirements', 'extensions'))


def _bounded(value):
    """Reject excessive/cyclic SDK values before deepcopy or tree traversal."""
    pending = [(value, 0, False)]; active = set(); nodes = size = 0
    while pending:
        row, depth, leaving = pending.pop()
        if leaving:
            active.remove(id(row)); continue
        nodes += 1
        need(depth <= 32 and nodes <= 8192, 'CARD_COMPLEXITY')
        if type(row) is str:
            need(row.isascii() and len(row) <= 262144, 'CARD_SIZE_OR_SUBSET'); size += len(row) + 2
        elif row is None or type(row) in (bool, int): size += 24
        elif type(row) in (dict, list):
            need(id(row) not in active, 'CARD_CYCLE'); active.add(id(row))
            need(len(row) <= 8192, 'CARD_COMPLEXITY'); size += len(row) + 2
            pending.append((row, depth, True))
            if type(row) is dict:
                for name, child in row.items():
                    need(type(name) is str, 'CARD_SUBSET')
                    pending.extend(((name, depth + 1, False), (child, depth + 1, False)))
            else: pending.extend((child, depth + 1, False) for child in row)
        else: raise ValueError('CARD_SUBSET')
        need(size <= 262144, 'CARD_SIZE')


def _b64(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _decode(text):
    need(type(text) is str and 0 < len(text) <= 16384 and re.fullmatch('[A-Za-z0-9_-]+', text), 'CARD_BASE64')
    raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    need(_b64(raw) == text, 'CARD_BASE64')
    return raw


def _payload(card):
    need(type(card) is dict, 'CARD_SHAPE')
    _bounded(card)
    value = {k: deepcopy(v) for k, v in card.items() if k != 'signatures'}
    # Unknown scalar protobuf defaults cannot safely be guessed away. An owner
    # adopts this explicit-presence subset, not an arbitrary reconstructed proto.
    pending = [value]
    while pending:
        row = pending.pop()
        if type(row) is dict:
            for k, v in row.items():
                need(not (k in _REPEATED and v == []), 'CARD_NORMALIZATION_REQUIRED')
                pending.append(v)
        elif type(row) is list:
            pending.extend(row)
    raw = canonical(value)
    need(len(raw) <= 65536, 'CARD_SIZE')
    return raw


def sign_card(card, private, kid):
    need(type(card) is dict and 'signatures' not in card and type(kid) is str and 0 < len(kid) <= 256, 'CARD_SIGNING_INPUT')
    header = _b64(canonical({'alg': 'EdDSA', 'kid': kid, 'typ': 'JOSE'}))
    signature = _b64(private.sign((header + '.' + _b64(_payload(card))).encode('ascii')))
    return {**deepcopy(card), 'signatures': [{'protected': header, 'signature': signature}]}


def verify_card(card, trusted_keys, now, expected_id=None):
    """Owner trust map: kid -> {key, not_before, expiry, revoked}.

    Acceptance authenticates a descriptor snapshot. It grants no network/tool
    authority and makes no claim the descriptor is globally the latest version.
    """
    need(type(trusted_keys) is dict and type(now) is int and 0 <= now <= 2**53-1, 'CARD_TRUST')
    raw = _payload(card); pin = digest(PROFILE, loads(raw))
    need(expected_id is None or expected_id == pin, 'CARD_PIN')
    records = card.get('signatures')
    need(type(records) is list and 0 < len(records) <= 8, 'CARD_SIGNATURES')
    accepted = set()
    for record in records:
        exact(record, 'protected signature')
        header = loads(_decode(record['protected']))
        exact(header, 'alg kid typ')
        need(header['alg'] == 'EdDSA' and header['typ'] == 'JOSE' and type(header['kid']) is str, 'CARD_ALGORITHM')
        if header['kid'] not in trusted_keys:
            continue
        trust = trusted_keys[header['kid']]; exact(trust, 'key not_before expiry revoked')
        need(valid_ed25519_key(trust['key']) and type(trust['not_before']) is int and
             type(trust['expiry']) is int and trust['not_before'] <= now <= trust['expiry'] and
             trust['revoked'] is False, 'CARD_KEY_NOT_CURRENT')
        signature = _decode(record['signature']); need(len(signature) == 64, 'CARD_SIGNATURE')
        try:
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(trust['key'])).verify(signature,
                (record['protected'] + '.' + _b64(raw)).encode('ascii'))
        except InvalidSignature:
            raise ValueError('CARD_SIGNATURE') from None
        accepted.add(header['kid'])
    need(bool(accepted), 'CARD_NO_TRUSTED_SIGNATURE')
    return {'profile': PROFILE, 'id': pin, 'signers': sorted(accepted), 'signature_verified': True,
            'freshness': 'OWNER_KEY_WINDOW_ONLY; GLOBAL_LATEST_UNKNOWN',
            'canonicalization': 'ASCII_INTEGER_EXPLICIT_PRESENCE_SUBSET',
            'network_accessed': False, 'execution_authorized': False}


def mcp_server_card(name, version, endpoints, *, tools_pin, protocols=None):
    """AAP descriptor for registries; not an official registry submission."""
    need(type(endpoints) is list and 0 < len(endpoints) <= 16 and
         all(type(v) is str and v.startswith(('https://', 'stdio:')) for v in endpoints), 'CARD_ENDPOINT')
    need(type(tools_pin) is str and re.fullmatch('[0-9a-f]{64}', tools_pin), 'CARD_TOOLS_PIN')
    body = {'profile': 'covenant-mcp-server-card/0.1', 'name': name, 'version': version,
            'endpoints': deepcopy(endpoints), 'toolsPin': tools_pin,
            'protocolVersions': ['2026-07-28', '2025-06-18'] if protocols is None else deepcopy(protocols),
            'publication': 'UNPUBLISHED_OWNER_DEPLOYMENT_REQUIRED'}
    _payload(body)
    return body
