"""Seven jobs, one visible verb per job action, every old name an alias.

A deal is a promise both sides sign. Proof shows it was kept. If it wasn't,
there is a fair way to fix it. Users meet those jobs; the levels stay internal
architecture. The job map is data (``data/action_jobs.json``): each action id
names exactly one verb, and each verb belongs to exactly one job. The jobs and
their verbs are the experience model's own, word for word. ``settle``, the
golden path's third step, is a name for ``release``. A kind picks one action
under a verb and is spelled from its old name, so ``propose`` with kind
``marketplace.quick_trade`` is ``tool:covenant_marketplace.quick_trade``.

Placement is navigation only. It never grants authority, never changes a
signed meaning and never removes an action: a verb with a kind calls the same
action with the same arguments, validation and refusals, and every old name
keeps working. A verb called without a kind uses the first data default this
host can run, never an order learned from use.
"""
from copy import deepcopy
from functools import lru_cache
from importlib.resources import files
import json
import re

from .errors import need

FORMAT = 'aap-action-jobs/0.1'
MAX_BYTES = 1048576
VISIBLE_LIMIT = 35
CARD_DETAIL = 12
FAMILIES = ('tool', 'agent', 'work', 'native', 'chain', 'language', 'network', 'domain', 'maintenance')
# These families spell their names with the covenant_ prefix the kind drops.
PREFIXED = ('agent', 'work', 'native')
LEVEL_ORDER = ('ORGANON', 'L0', 'L1', 'L2', 'L3', 'L4')
TIER_ORDER = {'core': 0, 'common': 1, 'advanced': 2}
_WORD = re.compile(r'[a-z]{2,16}\Z')
_ID = re.compile(r'([a-z]+):([A-Za-z][A-Za-z0-9_.]{0,119})\Z')
_KIND = re.compile(r'[A-Za-z][A-Za-z0-9_.]{0,79}\Z')
_TOOL = re.compile(r'[a-z][a-z0-9_]{0,79}\Z')


def kind_of(ident):
    """The kind that names one action under its verb, spelled from the old id."""
    match = _ID.fullmatch(ident) if type(ident) is str else None
    need(match is not None and match.group(1) in FAMILIES, 'JOBS_ACTION_ID')
    family, name = match.groups()
    if family in ('tool',) + PREFIXED and name.startswith('covenant_'):
        name = name[len('covenant_'):]
    kind = name if family == 'tool' else family + '.' + name
    need(_KIND.fullmatch(kind) is not None, 'JOBS_ACTION_ID')
    return kind


def _unique(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'JOBS_DUPLICATE_FIELD')
        value[key] = item
    return value


def _text(value, limit=400):
    need(type(value) is str and 0 < len(value) <= limit and value == value.strip(), 'JOBS_TEXT')


def validate(data):
    """Check the job map shape; it is data, never authority or execution."""
    need(type(data) is dict and set(data) == {'format', 'model', 'note', 'golden_path', 'jobs', 'verbs',
                                             'aliases', 'instruments', 'native', 'actions'}, 'JOBS_FIELDS')
    need(data['format'] == FORMAT, 'JOBS_FORMAT')
    _text(data['model']); _text(data['note'], 1000)
    need(type(data['jobs']) is list and len(data['jobs']) == 7, 'JOBS_SEVEN')
    seen = []
    for job in data['jobs']:
        need(type(job) is dict and set(job) == {'id', 'title', 'says', 'verbs'}, 'JOBS_JOB')
        need(type(job['id']) is str and _WORD.fullmatch(job['id']) is not None, 'JOBS_JOB')
        _text(job['title'], 40); _text(job['says'])
        need(type(job['verbs']) is list and 1 <= len(job['verbs']) <= 6, 'JOBS_JOB')
        for verb in job['verbs']:
            need(type(verb) is str and _WORD.fullmatch(verb) is not None and verb not in seen, 'JOBS_VERB_TWICE')
            seen.append(verb)
    need(len({job['id'] for job in data['jobs']}) == 7, 'JOBS_JOB')
    need(type(data['verbs']) is dict and list(data['verbs']) == seen, 'JOBS_VERBS_ORDER')
    for verb, row in data['verbs'].items():
        need(type(row) is dict and set(row) == {'says', 'defaults', 'next'}, 'JOBS_VERB')
        _text(row['says'])
        need(type(row['defaults']) is list and len(row['defaults']) <= 4 and
             all(type(k) is str and _KIND.fullmatch(k) for k in row['defaults']), 'JOBS_VERB')
        need(type(row['next']) is list and 1 <= len(row['next']) <= 4 and set(row['next']) <= set(seen), 'JOBS_VERB')
    need(type(data['aliases']) is dict and len(data['aliases']) <= 8, 'JOBS_ALIAS')
    for name, row in data['aliases'].items():
        # A golden-path name for one job verb: never a second verb, never a new job.
        need(_WORD.fullmatch(name) is not None and name not in seen and type(row) is dict and
             set(row) == {'verb', 'says'} and row['verb'] in seen, 'JOBS_ALIAS')
        _text(row['says'])
    need(type(data['golden_path']) is list and data['golden_path'] and
         set(data['golden_path']) <= set(seen) | set(data['aliases']), 'JOBS_GOLDEN_PATH')
    need(type(data['instruments']) is dict and data['instruments'], 'JOBS_INSTRUMENTS')
    for name, row in data['instruments'].items():
        need(_WORD.fullmatch(name) is not None and type(row) is dict and set(row) == {'says', 'tools'}, 'JOBS_INSTRUMENTS')
        _text(row['says'])
        need(type(row['tools']) is list and row['tools'] and
             all(type(t) is str and _TOOL.fullmatch(t) for t in row['tools']), 'JOBS_INSTRUMENTS')
    need(not set(data['instruments']) & set(data['aliases']), 'JOBS_ALIAS')
    visible = seen + list(data['aliases']) + [name for name in data['instruments'] if name not in seen]
    need(len(visible) <= VISIBLE_LIMIT, 'JOBS_TOO_MANY_VERBS')
    actions = data['actions']
    need(type(actions) is dict and 1 <= len(actions) <= 8192, 'JOBS_ACTIONS')
    kinds = {}
    for ident, verb in actions.items():
        kind = kind_of(ident)
        need(verb in data['verbs'], 'JOBS_ACTION_VERB')
        # Kinds are spelled injectively from old ids, so one kind is one action.
        need(kind not in kinds, 'JOBS_KIND_TWICE')
        kinds[kind] = ident
    need(set(actions.values()) == set(data['verbs']), 'JOBS_VERB_EMPTY')
    for verb, row in data['verbs'].items():
        need(all(k in kinds and actions[kinds[k]] == verb for k in row['defaults']), 'JOBS_DEFAULT_KIND')
    need(type(data['native']) is dict and len(data['native']) <= 256, 'JOBS_NATIVE')
    for tool, ident in data['native'].items():
        need(type(tool) is str and _TOOL.fullmatch(tool) is not None and ident in actions, 'JOBS_NATIVE')
    return True


@lru_cache(maxsize=1)
def _document():
    raw = files(__package__).joinpath('data/action_jobs.json').read_bytes()
    need(len(raw) <= MAX_BYTES, 'JOBS_SIZE')
    data = json.loads(raw, object_pairs_hook=_unique)
    validate(data)
    by_kind = {kind_of(ident): ident for ident in data['actions']}
    by_verb = {verb: [] for verb in data['verbs']}
    for ident, verb in data['actions'].items():
        by_verb[verb].append(ident)
    job_of_verb = {verb: job for job in data['jobs'] for verb in job['verbs']}
    by_tool = {}
    for ident in data['actions']:
        family, _, name = ident.partition(':')
        if family == 'tool':
            by_tool.setdefault(name.split('.')[0], []).append(ident)
    return data, by_kind, by_verb, job_of_verb, by_tool


def document():
    """A copy of the job map. A caller cannot change later placement through it."""
    return deepcopy(_document()[0])


def job_verbs():
    """The visible job verbs, in job order."""
    return list(_document()[0]['verbs'])


def aliases():
    """Golden-path names for job verbs, such as settle for release."""
    return {name: row['verb'] for name, row in _document()[0]['aliases'].items()}


def callable_verbs():
    """Every verb covenant_call accepts: the job verbs, then their golden-path names."""
    data = _document()[0]
    return list(data['verbs']) + list(data['aliases'])


def visible_verbs():
    """Job verbs, golden-path names and the entry instruments: everything shown on first contact."""
    data = _document()[0]
    verbs = callable_verbs()
    return verbs + [name for name in data['instruments'] if name not in verbs]


def _verb(name):
    """The job verb a callable verb names: itself, or the verb a golden-path name stands for."""
    data = _document()[0]
    if type(name) is str and name in data['aliases']:
        return data['aliases'][name]['verb']
    return name


def jobs():
    return deepcopy(_document()[0]['jobs'])


def verb_says(verb):
    data = _document()[0]
    if type(verb) is str and verb in data['aliases']:
        return data['aliases'][verb]['says']
    need(verb in _document()[2], 'VERB_UNKNOWN')
    return data['verbs'][verb]['says']


def verb_of(ident):
    return _document()[0]['actions'].get(ident) if type(ident) is str else None


def placement(ident):
    """Job, verb and kind of one action id, or None when the map has no row for it."""
    verb = verb_of(ident)
    if verb is None:
        return None
    job = _document()[3][verb]
    return {'job': job['title'], 'job_id': job['id'], 'verb': verb, 'kind': kind_of(ident)}


def kinds(verb):
    """Every action id under one verb (or its golden-path name), keyed by kind."""
    verb = _verb(verb)
    need(verb in _document()[2], 'VERB_UNKNOWN')
    return {kind_of(ident): ident for ident in _document()[2][verb]}


def tool_actions(tool):
    """Every mapped action id of one installed tool name, in id order."""
    return sorted(_document()[4].get(tool, ())) if type(tool) is str else []


def split(name):
    """('propose', None) for a verb, ('propose', kind) for propose:kind, else None."""
    if type(name) is not str or len(name) > 120:
        return None
    verb, colon, kind = name.partition(':')
    if _verb(verb) not in _document()[2]:
        return None
    if not colon:
        return verb, None
    need(_KIND.fullmatch(kind) is not None, 'VERB_KIND_UNKNOWN')
    return verb, kind


def resolve(verb, kind=None, *, runnable=None):
    """One action id for a verb and kind.

    Without a kind, the first data default this host can run is used. The
    choice never depends on use history, so the same call keeps one meaning.
    """
    data, by_kind, by_verb = _document()[:3]
    verb = _verb(verb)
    need(type(verb) is str and verb in by_verb, 'VERB_UNKNOWN')
    runnable = runnable or (lambda ident: True)
    if kind is not None:
        need(type(kind) is str and _KIND.fullmatch(kind) is not None and kind in by_kind
             and data['actions'][by_kind[kind]] == verb, 'VERB_KIND_UNKNOWN')
        need(runnable(by_kind[kind]), 'VERB_KIND_NOT_HERE')
        return by_kind[kind]
    for name in data['verbs'][verb]['defaults']:
        if runnable(by_kind[name]):
            return by_kind[name]
    choices = [ident for ident in by_verb[verb] if runnable(ident)]
    need(choices, 'VERB_KIND_NOT_HERE')
    need(len(choices) == 1, 'VERB_KIND_REQUIRED')
    return choices[0]


@lru_cache(maxsize=1)
def _levels():
    try:
        from covenant_chain.aap_levels import core_tools, module_level, tool_level
    except ImportError:  # an agent-only install orders by tier and id alone
        return None
    return tool_level, module_level, frozenset(core_tools())


def _level(ident, row):
    """(AAP Core tool?, level) of one action; chain and language ids take their module's level."""
    found = _levels()
    if found is None:
        return False, 'L4'
    tool_level, module_level, core = found
    family, _, name = ident.partition(':')
    tool = name.split('.')[0]
    level = tool_level(tool) if family in ('tool', 'agent', 'native', 'work') else None
    if level is None and row is not None and type(row.get('source')) is str:
        level = module_level(row['source'])
    return tool in core, level if level in LEVEL_ORDER else 'L4'


def nature_key(ident, row=None):
    """Order by nature: everyday tier, AAP Core tools, then level order, then id. Never use."""
    core, level = _level(ident, row)
    return (TIER_ORDER.get((row or {}).get('tier'), 2), 0 if core else 1, LEVEL_ORDER.index(level), ident)


def by_nature(idents, rows=None):
    rows = rows or {}
    return sorted(idents, key=lambda ident: nature_key(ident, rows.get(ident)))


def _home(ident):
    family, _, name = ident.partition(':')
    return name.split('.')[0] if family in ('tool', 'native') else family


def nature_next(ident, rows=None):
    """Next actions by nature: the next verbs, preferring kinds from the same tool or family."""
    verb = verb_of(ident)
    if verb is None:
        return []
    data, by_kind, by_verb = _document()[:3]
    home = _home(ident)
    suggested = []
    for following in data['verbs'][verb]['next']:
        candidates = [other for other in by_verb[following] if other != ident and _home(other) == home]
        if candidates:
            suggested.append(by_nature(candidates, rows)[0])
        elif data['verbs'][following]['defaults']:
            suggested.append(by_kind[data['verbs'][following]['defaults'][0]])
    return list(dict.fromkeys(suggested))


def card(verb, rows=None, *, order=None, mode='NATURE', detail=CARD_DETAIL):
    """What a verb does, its job and its kinds; ``order`` is an optional ranked id list."""
    data, _, by_verb, job_of_verb = _document()[:4]
    asked, verb = verb, _verb(verb)
    need(type(verb) is str and verb in by_verb, 'VERB_UNKNOWN')
    need(mode in ('NATURE', 'USE'), 'JOBS_ORDER')
    rows = rows or {}
    members = by_nature(by_verb[verb], rows)
    if order is not None:
        inside = set(members)
        ranked = [ident for ident in order if ident in inside]
        chosen = set(ranked)
        members = ranked + [ident for ident in members if ident not in chosen]
    job = job_of_verb[verb]
    top = []
    for ident in members[:detail]:
        row = rows.get(ident) or {}
        top.append({'kind': kind_of(ident), 'id': ident, 'purpose': row.get('purpose') or row.get('hint') or '',
                    'tier': row.get('tier', 'advanced')})
    named = {} if asked == verb else {'golden_path_name': asked, 'golden_path_says': data['aliases'][asked]['says']}
    return {'job': job['title'], 'job_id': job['id'], 'verb': verb, 'says': data['verbs'][verb]['says'], **named,
            'order': mode, 'kinds_total': len(members), 'kinds': [kind_of(ident) for ident in members],
            'top': top, 'default_kinds': list(data['verbs'][verb]['defaults']),
            'next_verbs': list(data['verbs'][verb]['next']),
            'call': {'tool': 'covenant_call', 'arguments': {'verb': asked, 'kind': kind_of(members[0]),
                                                          'parameters': {}}},
            'alias_rule': 'Every kind is an old name: the same action, arguments, validation and refusals.',
            'execution_authorized': False, 'authority_changed': False}


def overview():
    """The first list: the model, the golden path, seven jobs and their verbs."""
    data, _, by_verb = _document()[:3]
    return {'format': FORMAT, 'model': data['model'], 'golden_path': list(data['golden_path']),
            'jobs': [{'id': job['id'], 'title': job['title'], 'says': job['says'],
                      'verbs': [{'verb': verb, 'says': data['verbs'][verb]['says'], 'kinds': len(by_verb[verb])}
                                for verb in job['verbs']]} for job in data['jobs']],
            'golden_path_names': aliases(),
            'instruments': {name: row['says'] for name, row in data['instruments'].items()},
            'visible_verbs': visible_verbs(), 'aliases': len(data['actions']),
            'execution_authorized': False, 'authority_changed': False}
