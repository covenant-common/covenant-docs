"""PII preflight before a work order or covenant draft leaves this process.

The rule is ``covenant_chain.salted_terms.pii_lint``: e-mail addresses, phone
numbers and long digit runs. It is a local check, not consensus, and it does not
change any signed byte. The default mode warns and never blocks. ``strict``
refuses with ``PII_DETECTED`` before anything is signed.

The agent SDK wheel installs without ``covenant_chain``. When that package is
absent, the identical patterns below are used, and a test pins them to the
chain rule so the two cannot drift.
"""
import re

from .errors import need

VERSION = 'covenant-pii-preflight/0.1'
MODES = ('warn', 'strict')
MAX_TEXT = 100000
# Mirror of covenant_chain.salted_terms. Only used when that module is absent.
EMAIL = re.compile(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}')
PHONE = re.compile(r'(?:\+|00)?[0-9][0-9 ()\-]{8,}[0-9]')
CARD = re.compile(r'(?:\d[ \-]?){13,19}')
ADVICE = ('Move contact details and account numbers off the signed record. Keep them in a private, '
          'salted or encrypted document and pass its hash.')


def _mirror(text):
    need(type(text) is str and len(text) <= MAX_TEXT, 'DESCRIPTION')
    findings = []
    for kind, pattern in (('email', EMAIL), ('phone', PHONE), ('card', CARD)):
        for match in pattern.finditer(text):
            findings.append({'kind': kind, 'start': match.start(), 'end': match.end()})
    return findings


def lint_text(text):
    """Findings as ``[{kind, start, end}]``. Offsets are Unicode code points."""
    try:
        from covenant_chain.salted_terms import pii_lint
    except ImportError:
        return _mirror(text)
    return pii_lint(text)


def preflight(text, *, mode='warn', field='document'):
    """Return a report. ``strict`` raises PII_DETECTED when anything is found.

    The report names kinds and offsets only. It never echoes the matched text.
    """
    need(mode in MODES, 'PII_MODE')
    need(type(field) is str and 0 < len(field) <= 80, 'PII_MODE')
    findings = [] if text is None else lint_text(text)
    if findings and mode == 'strict':
        need(False, 'PII_DETECTED')
    return {
        'version': VERSION,
        'mode': mode,
        'field': field,
        'findings': findings,
        'kinds': sorted({row['kind'] for row in findings}),
        'blocked': False,
        'advice': ADVICE if findings else None,
        'signed_bytes_changed': False,
    }
