"""Owner-controlled Checkout approvals and conservative operation custody.

A new profile; historical agreements and payment rails are unchanged. Provider
credentials belong to the installed owner transport, never the signed intent.
A Checkout charge is not an outbound Stripe Pay transfer or delivery evidence.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import hmac
import json
import re
import secrets
import threading
import time
from urllib.parse import urlsplit, urlencode

from covenant_chain.crypto import canonical, digest, exact, integer, key, need, public_key, sign, verify
from covenant_chain.workflow_store import WorkflowStore

VERSION = 'covenant-stripe-checkout/0.1'
POLICY_VERSION = 'covenant-stripe-checkout-policy/0.1'
APPROVAL_LABEL = 'COVENANT-STRIPE-CHECKOUT-APPROVAL-0.1'
MAX_BODY = 1048576
ACCOUNT = re.compile(r'acct_[A-Za-z0-9]{1,80}\Z')
CURRENCY = re.compile(r'[a-z]{3}\Z')
PROVIDER_ID = re.compile(r'[A-Za-z][A-Za-z0-9_]{1,250}\Z')

# Fix text for each refusal code raised here: what happened, then what to do next.
# tools/build_lead_docs.py copies it into the error catalogue every agent host reads.
REMEDIATION = {
    'STRIPE_TEXT':
        'A text field is empty, too long or not plain printable ASCII (most fields take up to 160 characters,'
        ' a description up to 120). Use short printable ASCII text.',
    'STRIPE_AMOUNT':
        "The amount is not a whole number from 1 to 99999999 in the currency's smallest unit, such as cents. "
        'Give the amount in the smallest unit, within that range.',
    'STRIPE_ACCOUNT':
        'The merchant account is not a Stripe account ID (acct_ followed by letters and digits). Pass the '
        'exact account ID from the Stripe dashboard.',
    'STRIPE_PAYERS': 'The payer keys are not a list of 1 to 64 distinct keys. List each adopted payer key once.',
    'STRIPE_CURRENCY':
        'The currency is not a three-letter lowercase code such as usd. Use the lowercase currency code.',
    'STRIPE_BUDGET':
        'The maximum order is larger than the operation budget. Set maximum_order at or below '
        'operation_budget.',
    'STRIPE_MODE': 'The live mode flag is not true or false. Pass a boolean; false means the Stripe test sandbox.',
    'STRIPE_RETURN_ORIGIN':
        'The return origin is not a plain https origin with no user, path, query or fragment. Pass an origin '
        'such as https://shop.example.',
    'STRIPE_POLICY':
        'The policy differs from the one make_policy builds from its own fields. Rebuild it with make_policy;'
        ' never edit a policy by hand.',
    'STRIPE_PAYER_NOT_ADOPTED':
        'The payer key is not one the owner adopted in this policy. Pay with an adopted key, or ask the owner'
        ' to adopt this one.',
    'STRIPE_ORDER_LIMIT':
        'The amount is above the maximum order in the policy. Use a smaller amount, or ask the owner to '
        'review the limit.',
    'STRIPE_PROFILE':
        'The intent is not version covenant-stripe-checkout/0.1. Prepare the intent again with this package.',
    'STRIPE_APPROVAL_SIGNER': 'The approving key is not the payer the intent names. Approve with that payer key.',
    'STRIPE_INTENT_CHANGED':
        'The intent differs from what prepare builds from its own fields, so it was changed after it was '
        'made. Prepare a new intent and get a fresh payer approval.',
    'STRIPE_APPROVAL_BINDING':
        'The approval does not belong to this exact intent and payer. Get a new approval over the exact '
        'intent you will execute.',
    'STRIPE_RESPONSE_SIZE':
        'The provider answer is larger than 1048576 bytes, so it was not read. Observe again later; if it '
        'repeats, the owner checks the provider account.',
    'STRIPE_DUPLICATE_JSON_KEY':
        'The provider answer repeats a JSON key, so its meaning is unclear and it was not used. Observe '
        'again; if it repeats, stop and have the owner check the transport.',
    'STRIPE_JSON':
        'The provider answer is not valid JSON. Observe again; if it repeats, stop and have the owner check '
        'the transport.',
    'STRIPE_RESPONSE':
        'The provider answer is not a JSON object, so it was not used. Observe again and do not rely on this '
        'answer.',
    'STRIPE_CREDENTIAL_GETTER':
        'The transport needs a function that returns the restricted key, and got something else. The owner '
        'passes a function, so the key never enters a record.',
    'STRIPE_LIVE_NOT_ADOPTED':
        'The transport asked for live mode without allow_live, or a mode flag is not true or false. Only the '
        'owner turns on live mode, with allow_live=True.',
    'STRIPE_HARNESS': 'The loopback_harness flag is not true or false. Pass a boolean.',
    'STRIPE_HARNESS_ORIGIN':
        'The test harness origin is not http://127.0.0.1 with a port, in test mode. Use a loopback address '
        'and port; the harness never counts as Stripe.',
    'STRIPE_ORIGIN': 'The provider origin is not https://api.stripe.com. Leave the origin at its fixed default.',
    'STRIPE_TIMEOUT': 'The timeout is not a whole number of seconds from 1 to 60. Pass a timeout in that range.',
    'STRIPE_REQUEST':
        'The provider request is not a GET or POST to a /v1/ path. Use the gateway methods; they build valid '
        'requests.',
    'STRIPE_CREDENTIAL_UNAVAILABLE':
        'The owner key function failed, so no request was sent. The owner fixes the key source and tries '
        'again.',
    'STRIPE_RESTRICTED_CREDENTIAL_MODE':
        'The key is not a restricted key for this mode (rk_test_ or rkcs_test_ for test, rk_live_ for live). '
        'The owner sets a restricted key of the right mode; secret keys (sk_) are never used.',
    'STRIPE_REQUEST_SIZE': 'The request body is larger than 16384 bytes. Shorten the description.',
    'STRIPE_PROVIDER_HTTP':
        'The provider answered with an error status. The owner checks the account and the key permissions, '
        'then observes again before any new attempt.',
    'STRIPE_PROVIDER_UNAVAILABLE':
        'The provider could not be reached or the connection failed. Try again later; for a checkout already '
        'attempted, run observe to reconcile and never create it twice.',
    'STRIPE_RECONCILIATION_RESPONSE':
        'The provider list answer is malformed, so the search for the checkout stopped. Observe again later '
        'and do not create a new checkout meanwhile.',
    'STRIPE_MULTIPLE_SESSIONS':
        'Two or more checkouts carry this intent ID, which should never happen. Stop and have the owner '
        'review the Stripe account before anything else.',
    'STRIPE_RECONCILIATION_LIMIT':
        'The search for the checkout went through 10 pages without an answer. Have the owner look for it in '
        'the Stripe dashboard; do not create a new one.',
    'STRIPE_PROVIDER_ID':
        'A provider ID does not have the expected form (cs_, pi_, ch_ or evt_ followed by letters and '
        'digits). Pass the exact ID the provider returned.',
    'STRIPE_PROVIDER_BINDING':
        'The provider object metadata does not match this agreement, intent, revision and payer. Treat it as '
        'another payment and check the ID you passed.',
    'STRIPE_SESSION':
        'The provider object is not a checkout session. Pass the checkout session ID that starts with cs_.',
    'STRIPE_SESSION_TERMS':
        'The checkout session terms (mode, currency, amount, expiry or agreement) differ from the approved '
        'intent. Do not use this session; have the owner review it.',
    'STRIPE_SESSION_STATUS':
        'The checkout session has a status this gateway does not know. Observe again later; if it persists, '
        'the owner reviews the session.',
    'STRIPE_TRANSPORT_MODE':
        'The transport mode (test or live) differs from the policy mode. Use a transport and a policy of the '
        'same mode.',
    'STRIPE_OPERATION_UNKNOWN':
        'No checkout with that effect ID is held in this gateway. Check the effect ID, or execute the '
        'approved intent first.',
    'STRIPE_CUSTODY_CHANGED':
        'The stored intent or approval no longer checks out, so the gateway store was changed. Stop, and have'
        ' the owner restore the store from a backup.',
    'STRIPE_ACCOUNT_MISMATCH':
        'The provider key belongs to another account than the policy names, so nothing was sent. The owner '
        'sets the key of the adopted account.',
    'STRIPE_OUTCOME_UNKNOWN_RECONCILE':
        'The checkout may or may not have been created. Run observe to find out; never execute the same '
        'intent again until it is reconciled.',
    'STRIPE_CHECKOUT_EXPIRY':
        'The checkout expiry is less than 30 minutes or more than 24 hours from now. Prepare a new intent '
        'with an expiry in that range and get a fresh approval.',
    'STRIPE_BUDGET_EXCEEDED':
        'This checkout would take the gateway past its operation budget. The owner reviews the budget; a '
        'retry cannot add room.',
    'STRIPE_CHECKOUT_URL':
        'The checkout link is not an https link on checkout.stripe.com. Do not send it to the payer; observe '
        'again and have the owner check the account.',
    'STRIPE_SESSION_CHANGED':
        'The provider returned another checkout session than the one recorded for this intent. Stop, and have'
        ' the owner review both sessions.',
    'STRIPE_PAYMENT_TERMS':
        'The payment terms (amount, currency, mode or ID) differ from the approved intent. Do not count this '
        'payment; have the owner review it.',
    'STRIPE_PAYMENT_STATUS':
        'The payment has a status this gateway does not know. Observe again later; the payment does not count'
        ' until it is understood.',
    'STRIPE_PAYMENT_RECEIVED':
        'The payment says succeeded, but the amount received or the session payment status does not match. Do'
        ' not count it as paid; observe again later.',
    'STRIPE_CHARGE_TERMS':
        'The charge terms (amount, currency, mode or payment) differ from the approved intent. Do not count '
        'this charge; have the owner review it.',
    'STRIPE_CHARGE_STATE':
        'The charge refund or dispute fields are malformed, or the refund is larger than the amount. Observe '
        'again later; the owner reviews the charge if it repeats.',
    'STRIPE_PAID_WITHOUT_PAYMENT':
        'The session says paid, but no paid payment backs it. Do not count it as paid; observe again later '
        'and have the owner review it.',
    'STRIPE_WEBHOOK_SECRET_REQUIRED':
        'No webhook secret function is installed, so events cannot be checked. The owner passes '
        'webhook_secret when opening the gateway.',
    'STRIPE_WEBHOOK_INPUT':
        'The webhook body or signature header is the wrong type or too large (body up to 1048576 bytes, '
        'header up to 4096 characters). Pass the raw body bytes and the Stripe-Signature header as received.',
    'STRIPE_WEBHOOK_TOLERANCE':
        'The tolerance is not a whole number of seconds from 1 to 300. Pass a tolerance in that range.',
    'STRIPE_WEBHOOK_SIGNATURE':
        'The Stripe-Signature header is malformed, or no signature in it matches the body. Pass the raw body '
        'and header unchanged; never rebuild the body.',
    'STRIPE_WEBHOOK_STALE_OR_INVALID':
        'The webhook timestamp is outside the tolerance, or the header has no single timestamp or too many '
        'signatures. Check the server clock and let the provider deliver the event again.',
    'STRIPE_WEBHOOK_SECRET_UNAVAILABLE':
        'The owner webhook secret function failed. The owner fixes the secret source; the provider delivers '
        'the event again later.',
    'STRIPE_WEBHOOK_SECRET':
        'The webhook secret is not a whsec_ signing secret. The owner sets the signing secret of the Stripe '
        'webhook endpoint.',
    'STRIPE_WEBHOOK_SCOPE':
        'The event type, mode or account is not one this gateway handles. Ignore it, or check that the '
        'endpoint is set for the adopted account and mode.',
    'STRIPE_WEBHOOK_OBJECT':
        'The event does not carry a checkout session, payment or charge object. Ignore it; only those objects'
        ' are read.',
    'STRIPE_WEBHOOK_FOREIGN':
        'The event is about another session, payment or charge than this intent. Pass the event with the '
        'effect ID it belongs to.',
    'STRIPE_WEBHOOK_REPLAY_CHANGED':
        'An event with this ID was seen before with another body or intent. Keep both as proof and have the '
        'owner review the endpoint.',
    'STRIPE_RECORD_PROFILE':
        'The record is not version covenant-stripe-observation-record/0.1. Export the record again with '
        'portable_record.',
    'STRIPE_RECORD_BOUND':
        'The record is larger than 65536 bytes, or has an unknown phase or a malformed observation. Export '
        'the record again with portable_record.',
    'STRIPE_RECORD_PIN':
        'The record is for another effect than the one you expected. Check the effect ID and the record you '
        'were given.',
    'STRIPE_RECORD_ASSURANCE':
        'The record claims more than an owner report can say about provider evidence, delivery or disclosure.'
        ' Treat it as untrusted and ask for the record as exported.',
}



def _text(value, maximum=160):
    need(type(value) is str and 0 < len(value) <= maximum and
         all(32 <= ord(c) <= 126 for c in value), 'STRIPE_TEXT')
    return value


def _money(value):
    integer(value, True)
    need(value <= 99999999, 'STRIPE_AMOUNT')
    return value


def make_policy(*, account, payer_keys, currency='usd', maximum_order=2500,
                operation_budget=10000, return_origin, livemode=False):
    need(type(account) is str and ACCOUNT.fullmatch(account), 'STRIPE_ACCOUNT')
    need(type(payer_keys) is list and 1 <= len(payer_keys) <= 64 and
         len(set(payer_keys)) == len(payer_keys), 'STRIPE_PAYERS')
    for payer in payer_keys: key(payer)
    need(type(currency) is str and CURRENCY.fullmatch(currency), 'STRIPE_CURRENCY')
    _money(maximum_order); _money(operation_budget)
    need(maximum_order <= operation_budget, 'STRIPE_BUDGET')
    need(type(livemode) is bool, 'STRIPE_MODE')
    _text(return_origin, 240)
    u = urlsplit(return_origin)
    need(u.scheme == 'https' and u.hostname and u.netloc == u.hostname and
         not u.username and not u.password and u.path in ('', '/') and
         not u.query and not u.fragment, 'STRIPE_RETURN_ORIGIN')
    return dict(version=POLICY_VERSION, account=account, payer_keys=sorted(payer_keys),
                currency=currency, maximum_order=maximum_order,
                operation_budget=operation_budget, return_origin='https://'+u.hostname,
                livemode=livemode, gateway_fee=0,
                provider_fees='MERCHANT_BORNE_UNQUOTED_STRIPE_CONTRACT')


def _policy(policy):
    exact(policy, 'version account payer_keys currency maximum_order operation_budget return_origin livemode gateway_fee provider_fees')
    rebuilt = make_policy(**{k: policy[k] for k in ('account', 'payer_keys', 'currency',
        'maximum_order', 'operation_budget', 'return_origin', 'livemode')})
    need(policy == rebuilt, 'STRIPE_POLICY')
    return digest('COVENANT-STRIPE-CHECKOUT-POLICY-0.1', policy)


def prepare(policy, *, agreement, revision, payer, amount, description, expires,
            nonce=None):
    pin = _policy(policy); key(agreement); key(payer); _money(amount)
    integer(revision, True); integer(expires, True); _text(description, 120)
    need(payer in policy['payer_keys'], 'STRIPE_PAYER_NOT_ADOPTED')
    need(amount <= policy['maximum_order'], 'STRIPE_ORDER_LIMIT')
    nonce = secrets.token_hex(32) if nonce is None else nonce
    key(nonce)
    return dict(version=VERSION, policy=pin, agreement=agreement, revision=revision,
                payer=payer, merchant=policy['account'], amount=amount,
                currency=policy['currency'], description=description,
                expires=expires, nonce=nonce, gateway_fee=0,
                provider_fees=policy['provider_fees'], livemode=policy['livemode'])


def effect_id(intent):
    exact(intent, 'version policy agreement revision payer merchant amount currency description expires nonce gateway_fee provider_fees livemode')
    need(intent['version'] == VERSION, 'STRIPE_PROFILE')
    return digest('COVENANT-STRIPE-CHECKOUT-INTENT-0.1', intent)


def approve(intent, private_key):
    reference = effect_id(intent)
    need(public_key(private_key) == intent['payer'], 'STRIPE_APPROVAL_SIGNER')
    return dict(version=VERSION, effect=reference, signer=intent['payer'],
                signature=sign(private_key, APPROVAL_LABEL, intent))


def _check_approval(policy, intent, approval):
    reference = effect_id(intent)
    rebuilt = prepare(policy, **{k: intent[k] for k in ('agreement', 'revision', 'payer',
        'amount', 'description', 'expires', 'nonce')})
    need(intent == rebuilt, 'STRIPE_INTENT_CHANGED')
    exact(approval, 'version effect signer signature')
    need(approval['version'] == VERSION and approval['effect'] == reference and
         approval['signer'] == intent['payer'], 'STRIPE_APPROVAL_BINDING')
    verify(intent['payer'], APPROVAL_LABEL, intent, approval['signature'])
    return reference


def _parse(raw):
    need(type(raw) is bytes and len(raw) <= MAX_BODY, 'STRIPE_RESPONSE_SIZE')
    def pairs(rows):
        out = {}
        for name, value in rows:
            need(name not in out, 'STRIPE_DUPLICATE_JSON_KEY'); out[name] = value
        return out
    def bad(value): raise ValueError('STRIPE_JSON')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=bad)
    except (UnicodeError, json.JSONDecodeError, RecursionError):
        raise ValueError('STRIPE_JSON') from None
    need(type(value) is dict, 'STRIPE_RESPONSE')
    return value


def profile():
    return dict(version=VERSION, route='CHECKOUT_COLLECTION',
        stripe_pay_transfer=False, owner_installation_required=True,
        default='SANDBOX', secrets_in_records=False,
        provider_fees='MERCHANT_BORNE_UNQUOTED_STRIPE_CONTRACT',
        budget='CUMULATIVE_CHECKOUT_COMMITMENTS_NO_AUTOMATIC_RELEASE',
        delivery_verified=False, legal_discharge=False,
        finality='NO_IRREVERSIBLE_FINALITY_OR_BANK_PAYOUT_CLAIM')


def describe():
    return {**profile(), 'actions': ['prepare', 'approve', 'execute', 'observe', 'ingest_event', 'verify_record'],
            'onboarding': 'Owner adopts exact merchant account and payer keys; payer signs exact intent; owner transport executes.'}


class StripeHTTPTransport:
    """Owner-only bounded HTTPS transport, without a runtime SDK dependency.

    Production origin is fixed. The explicit loopback harness is a local
    protocol simulator and can never establish Stripe-observed payment.
    Credential values remain only inside this trusted owner process.
    """
    API_VERSION = '2026-09-30.endive'

    def __init__(self, credential, *, livemode=False, allow_live=False,
                 origin='https://api.stripe.com', loopback_harness=False, timeout=10):
        need(callable(credential), 'STRIPE_CREDENTIAL_GETTER')
        need(type(livemode) is bool and type(allow_live) is bool and
             (not livemode or allow_live), 'STRIPE_LIVE_NOT_ADOPTED')
        need(type(loopback_harness) is bool, 'STRIPE_HARNESS')
        if loopback_harness:
            u = urlsplit(origin)
            need(u.scheme == 'http' and u.hostname == '127.0.0.1' and
                 u.port and u.netloc == '127.0.0.1:'+str(u.port) and
                 not u.path and not u.query and not u.fragment and not livemode,
                 'STRIPE_HARNESS_ORIGIN')
        else:
            need(origin == 'https://api.stripe.com', 'STRIPE_ORIGIN')
        need(type(timeout) is int and 1 <= timeout <= 60, 'STRIPE_TIMEOUT')
        self._credential = credential; self.livemode = livemode
        self.origin = origin; self.timeout = timeout; self.harness = loopback_harness
        self.assurance = 'LOCAL_HTTP_PROTOCOL_SIMULATOR' if loopback_harness else 'STRIPE_AUTHENTICATED_API'

    def __repr__(self):
        return '<StripeHTTPTransport owner credential redacted>'

    def request(self, method, path, *, data=None, idempotency=None):
        import http.client
        import ssl
        need(method in ('GET', 'POST') and type(path) is str and path.startswith('/v1/') and
             not path.startswith('//') and '\r' not in path and '\n' not in path,
             'STRIPE_REQUEST')
        try: secret = self._credential()
        except BaseException: raise ValueError('STRIPE_CREDENTIAL_UNAVAILABLE') from None
        prefix = ('rk_live_',) if self.livemode else ('rk_test_', 'rkcs_test_')
        need(type(secret) is str and secret.startswith(prefix) and
             len(secret) <= 512 and re.fullmatch(r'[A-Za-z0-9_]+', secret), 'STRIPE_RESTRICTED_CREDENTIAL_MODE')
        u = urlsplit(self.origin)
        connection = (http.client.HTTPConnection(u.hostname, u.port, timeout=self.timeout)
            if self.harness else http.client.HTTPSConnection(u.hostname, timeout=self.timeout,
                                                            context=ssl.create_default_context()))
        headers = {'Authorization': 'Bearer '+secret, 'Stripe-Version': self.API_VERSION,
                   'Accept': 'application/json'}
        body = None
        if data is not None:
            body = urlencode(data).encode('ascii')
            need(len(body) <= 16384, 'STRIPE_REQUEST_SIZE')
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
        if idempotency is not None:
            key(idempotency); headers['Idempotency-Key'] = idempotency
        try:
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            raw = response.read(MAX_BODY+1)
            need(200 <= response.status < 300, 'STRIPE_PROVIDER_HTTP')
            need(len(raw) <= MAX_BODY, 'STRIPE_RESPONSE_SIZE')
            return _parse(raw)
        except (OSError, http.client.HTTPException):
            raise ValueError('STRIPE_PROVIDER_UNAVAILABLE') from None
        finally:
            connection.close()
            del secret

    def account(self):
        return self.request('GET', '/v1/account')

    def create_session(self, intent, reference, return_origin):
        metadata = {'aap_agreement': intent['agreement'], 'aap_intent': reference,
                    'aap_revision': str(intent['revision']), 'aap_payer': intent['payer']}
        # The suffix derives from the random signed intent nonce. It remains
        # identical on an exact retry, including Stripe idempotency replay.
        suffix = ''.join(chr(97+(int(reference[i:i+2], 16) % 26)) for i in range(0, 16, 2))
        params = {'mode': 'payment', 'success_url': return_origin+'/payment/complete?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url': return_origin+'/payment/cancelled',
            'client_reference_id': intent['agreement'], 'expires_at': str(intent['expires']),
            'line_items[0][price_data][currency]': intent['currency'],
            'line_items[0][price_data][unit_amount]': str(intent['amount']),
            'line_items[0][price_data][product_data][name]': intent['description'],
            'line_items[0][quantity]': '1', 'integration_identifier': 'aap_gateway_'+suffix,
            'adaptive_pricing[enabled]': 'false'}
        for name, value in metadata.items():
            params['metadata['+name+']'] = value
            params['payment_intent_data[metadata]['+name+']'] = value
        return self.request('POST', '/v1/checkout/sessions', data=params, idempotency=reference)

    def retrieve_session(self, identifier):
        _provider_id(identifier, 'cs_')
        return self.request('GET', '/v1/checkout/sessions/'+identifier)

    def retrieve_payment(self, identifier):
        _provider_id(identifier, 'pi_')
        return self.request('GET', '/v1/payment_intents/'+identifier)

    def retrieve_charge(self, identifier):
        _provider_id(identifier, 'ch_')
        return self.request('GET', '/v1/charges/'+identifier)

    def find_session(self, reference, intent):
        found = []; cursor = None
        for _ in range(10):
            query = {'limit': '100', 'created[gte]': str(max(0, intent['expires']-86400))}
            if cursor: query['starting_after'] = cursor
            result = self.request('GET', '/v1/checkout/sessions?'+urlencode(query))
            rows = result.get('data')
            need(type(rows) is list and len(rows) <= 100 and type(result.get('has_more')) is bool,
                 'STRIPE_RECONCILIATION_RESPONSE')
            for row in rows:
                need(type(row) is dict, 'STRIPE_RECONCILIATION_RESPONSE')
                metadata = row.get('metadata')
                need(type(metadata) is dict, 'STRIPE_RECONCILIATION_RESPONSE')
                if metadata.get('aap_intent') == reference: found.append(row)
            need(len(found) <= 1, 'STRIPE_MULTIPLE_SESSIONS')
            if not result['has_more']: return found[0] if found else None
            need(bool(rows), 'STRIPE_RECONCILIATION_RESPONSE')
            cursor = _provider_id(rows[-1].get('id'), 'cs_')
        raise ValueError('STRIPE_RECONCILIATION_LIMIT')


def _provider_id(value, prefix):
    need(type(value) is str and PROVIDER_ID.fullmatch(value) and value.startswith(prefix), 'STRIPE_PROVIDER_ID')
    return value


def _metadata(value, intent, reference):
    need(type(value) is dict and value.get('aap_agreement') == intent['agreement'] and
         value.get('aap_intent') == reference and value.get('aap_revision') == str(intent['revision']) and
         value.get('aap_payer') == intent['payer'], 'STRIPE_PROVIDER_BINDING')


def _session(value, intent, reference):
    need(type(value) is dict and value.get('object') == 'checkout.session', 'STRIPE_SESSION')
    _provider_id(value.get('id'), 'cs_')
    need(value.get('livemode') is intent['livemode'] and value.get('mode') == 'payment' and
         value.get('currency') == intent['currency'] and type(value.get('expires_at')) is int and
         value['expires_at'] == intent['expires'] and type(value.get('amount_total')) is int and
         value['amount_total'] == intent['amount'] and value.get('client_reference_id') == intent['agreement'],
         'STRIPE_SESSION_TERMS')
    _metadata(value.get('metadata'), intent, reference)
    need(value.get('payment_status') in ('paid', 'unpaid') and
         value.get('status') in ('open', 'complete', 'expired'), 'STRIPE_SESSION_STATUS')
    return value


class StripeGateway:
    """One owner custody directory, with conservative aggregate commitments.

    All operations share the same directory. Copying that directory, rolling
    it back, changing owner policy or running independent hosts is outside this
    local budget boundary. No automatic retry follows ambiguous dispatch.
    """
    def __init__(self, directory, policy, transport, *, clock=None, webhook_secret=None):
        self.policy = deepcopy(policy); self.pin = _policy(self.policy)
        need(transport.livemode is policy['livemode'], 'STRIPE_TRANSPORT_MODE')
        self.transport = transport; self._clock = clock or (lambda: int(time.time()))
        self._webhook_secret = webhook_secret; self._mutex = threading.RLock(); self._lock_depth = 0
        self.store = WorkflowStore(directory, {'profile': VERSION, 'policy': self.policy,
            'transport_assurance': transport.assurance}, check_same_thread=False)
        self.db = self.store.db
        self.db.execute('CREATE TABLE IF NOT EXISTS stripe_intents(effect TEXT PRIMARY KEY,body BLOB NOT NULL,approval BLOB NOT NULL,phase TEXT NOT NULL,session TEXT,observation BLOB)')
        columns = {row[1] for row in self.db.execute('PRAGMA table_info(stripe_intents)')}
        if 'checkout_url' not in columns: self.db.execute('ALTER TABLE stripe_intents ADD COLUMN checkout_url TEXT')
        self.db.execute('CREATE TABLE IF NOT EXISTS stripe_events(id TEXT PRIMARY KEY,effect TEXT NOT NULL,digest TEXT NOT NULL,type TEXT NOT NULL)')

    @contextmanager
    def _exclusive(self):
        # Nested owner operations must not release the outer cross-process
        # flock. RLock alone only serializes threads using this one object.
        with self._mutex:
            if self._lock_depth:
                self._lock_depth += 1
                try: yield
                finally: self._lock_depth -= 1
            else:
                with self.store.exclusive():
                    self._lock_depth = 1
                    try: yield
                    finally: self._lock_depth = 0

    def _now(self):
        now = self._clock(); integer(now, True); return now

    def prepare(self, **kwargs):
        return prepare(self.policy, **kwargs)

    def _get(self, reference):
        key(reference)
        row = self.db.execute('SELECT body,approval,phase,session,observation FROM stripe_intents WHERE effect=?', (reference,)).fetchone()
        need(row is not None, 'STRIPE_OPERATION_UNKNOWN')
        intent = json.loads(row[0]); approval = json.loads(row[1])
        need(_check_approval(self.policy, intent, approval) == reference, 'STRIPE_CUSTODY_CHANGED')
        return intent, row[2], row[3], json.loads(row[4]) if row[4] else None

    def inspect(self, reference):
        with self._exclusive():
            intent, phase, session, observation = self._get(reference)
            return {'version': VERSION, 'effect': reference, 'intent': intent, 'phase': phase,
                    'session_id': session, 'observation': observation,
                    'budget_used': self.db.execute('SELECT coalesce(sum(json_extract(body,\'$.amount\')),0) FROM stripe_intents').fetchone()[0],
                    'budget_limit': self.policy['operation_budget'], 'delivery_verified': False,
                    'remaining_obligations': 'CHECK_THE_AGREEMENT_SEPARATELY',
                    'retained_head': (self.store.events()[-1]['id'] if self.store.events() else '0'*64)}

    def _account(self):
        value = self.transport.account()
        need(type(value) is dict and value.get('object') == 'account' and
             value.get('id') == self.policy['account'], 'STRIPE_ACCOUNT_MISMATCH')

    def execute(self, intent, approval):
        reference = _check_approval(self.policy, intent, approval)
        with self._exclusive():
            old = self.db.execute('SELECT phase FROM stripe_intents WHERE effect=?', (reference,)).fetchone()
            if old:
                # Inspection is safe after the approval expires; it does not
                # make a second provider call or create another checkout.
                self._get(reference)
                need(old[0] not in ('ATTEMPTED', 'UNKNOWN'), 'STRIPE_OUTCOME_UNKNOWN_RECONCILE')
                result = self.inspect(reference)
                result['checkout_url'] = self.db.execute('SELECT checkout_url FROM stripe_intents WHERE effect=?', (reference,)).fetchone()[0]
                return result
            now = self._now()
            need(now+1800 <= intent['expires'] <= now+86400, 'STRIPE_CHECKOUT_EXPIRY')
            self._account()  # Read-only identity check before any dispatch.
            self.db.execute('BEGIN IMMEDIATE')
            try:
                used = self.db.execute('SELECT coalesce(sum(json_extract(body,\'$.amount\')),0) FROM stripe_intents').fetchone()[0]
                need(used+intent['amount'] <= self.policy['operation_budget'], 'STRIPE_BUDGET_EXCEEDED')
                self.db.execute('INSERT INTO stripe_intents(effect,body,approval,phase,session,observation) VALUES (?,?,?,?,?,?)',
                    (reference, canonical(intent), canonical(approval), 'ATTEMPTED', None, None))
                self.db.execute('COMMIT')
            except BaseException:
                self.db.execute('ROLLBACK'); raise
            self.store.append('STRIPE_ATTEMPT', reference, {'intent': reference, 'as_of': now})
            # Keep the local owner lock across I/O. A crashed process leaves
            # ATTEMPTED durable, and another process must reconcile it.
            try:
                session = _session(self.transport.create_session(intent, reference, self.policy['return_origin']), intent, reference)
                url = session.get('url')
                if url is not None:
                    _text(url, 2048); parsed = urlsplit(url)
                    need(parsed.scheme == 'https' and parsed.netloc == 'checkout.stripe.com' and
                         not parsed.username and not parsed.password, 'STRIPE_CHECKOUT_URL')
                self.store.append('STRIPE_CREATED', reference, {'session': session['id'], 'as_of': self._now()})
                self.db.execute('UPDATE stripe_intents SET phase=?,session=?,checkout_url=? WHERE effect=?',
                                ('CREATED', session['id'], url, reference))
                result = self.inspect(reference)
                result['checkout_url'] = url
                return result
            except BaseException:
                self.db.execute('UPDATE stripe_intents SET phase=? WHERE effect=?', ('UNKNOWN', reference))
                raise ValueError('STRIPE_OUTCOME_UNKNOWN_RECONCILE') from None

    def observe(self, reference):
        with self._exclusive():
            intent, phase, identifier, previous = self._get(reference)
            self._account()
            session = self.transport.retrieve_session(identifier) if identifier else self.transport.find_session(reference, intent)
            if session is None:
                return {**self.inspect(reference), 'reconciliation': 'NOT_FOUND_YET_NO_RETRY_AUTHORITY'}
            session = _session(session, intent, reference)
            if identifier: need(session['id'] == identifier, 'STRIPE_SESSION_CHANGED')
            state = 'UNPAID'; refund = 0; disputed = False; payment_id = None; charge_id = None
            if session.get('payment_intent') is not None:
                payment_id = _provider_id(session['payment_intent'], 'pi_')
                payment = self.transport.retrieve_payment(payment_id)
                need(type(payment) is dict and payment.get('object') == 'payment_intent' and
                     payment.get('id') == payment_id and payment.get('livemode') is intent['livemode'] and
                     payment.get('currency') == intent['currency'] and type(payment.get('amount')) is int and
                     payment['amount'] == intent['amount'], 'STRIPE_PAYMENT_TERMS')
                _metadata(payment.get('metadata'), intent, reference)
                need(payment.get('status') in ('requires_payment_method', 'requires_confirmation', 'requires_action',
                     'processing', 'requires_capture', 'canceled', 'succeeded'), 'STRIPE_PAYMENT_STATUS')
                if payment.get('status') == 'succeeded':
                    need(type(payment.get('amount_received')) is int and payment['amount_received'] == intent['amount'] and
                         session['payment_status'] == 'paid', 'STRIPE_PAYMENT_RECEIVED')
                    state = 'PAID'
                elif payment.get('status') == 'processing': state = 'PENDING'
                if payment.get('latest_charge') is not None:
                    charge_id = _provider_id(payment['latest_charge'], 'ch_')
                    charge = self.transport.retrieve_charge(charge_id)
                    need(type(charge) is dict and charge.get('object') == 'charge' and charge.get('id') == charge_id and
                         charge.get('payment_intent') == payment_id and charge.get('livemode') is intent['livemode'] and
                         charge.get('currency') == intent['currency'] and type(charge.get('amount')) is int and
                         charge['amount'] == intent['amount'], 'STRIPE_CHARGE_TERMS')
                    refund = charge.get('amount_refunded'); integer(refund)
                    need(refund <= intent['amount'] and type(charge.get('disputed')) is bool, 'STRIPE_CHARGE_STATE')
                    disputed = charge['disputed']
                    if refund: state = 'REFUNDED' if refund == intent['amount'] else 'PARTIALLY_REFUNDED'
            need(session['payment_status'] != 'paid' or state in ('PAID', 'PARTIALLY_REFUNDED', 'REFUNDED'),
                 'STRIPE_PAID_WITHOUT_PAYMENT')
            real_provider = self.transport.assurance == 'STRIPE_AUTHENTICATED_API'
            observation = dict(payment_state=state, amount=intent['amount'], currency=intent['currency'],
                amount_refunded=refund, dispute_reported=disputed, as_of=self._now(),
                payment_intent=payment_id, charge_id=charge_id, provider=self.transport.assurance,
                provider_observed=real_provider, simulated_provider_observed=not real_provider,
                sandbox=not intent['livemode'], irreversible_finality=False,
                bank_payout_verified=False, delivery_verified=False)
            checkout_url = session.get('url')
            if checkout_url is not None:
                _text(checkout_url, 2048); parsed = urlsplit(checkout_url)
                need(parsed.scheme == 'https' and parsed.netloc == 'checkout.stripe.com', 'STRIPE_CHECKOUT_URL')
            self.store.append('STRIPE_OBSERVATION', reference, observation)
            self.db.execute('UPDATE stripe_intents SET phase=?,session=?,observation=?,checkout_url=? WHERE effect=?',
                ('OBSERVED', session['id'], canonical(observation), checkout_url, reference))
            return self.inspect(reference)

    def ingest_event(self, reference, raw_body, signature_header, *, tolerance=300):
        need(callable(self._webhook_secret), 'STRIPE_WEBHOOK_SECRET_REQUIRED')
        need(type(raw_body) is bytes and len(raw_body) <= MAX_BODY and type(signature_header) is str and
             len(signature_header) <= 4096, 'STRIPE_WEBHOOK_INPUT')
        need(type(tolerance) is int and 1 <= tolerance <= 300, 'STRIPE_WEBHOOK_TOLERANCE')
        fields = signature_header.split(','); timestamps = []; signatures = []
        for field in fields:
            name, separator, value = field.partition('=')
            need(separator and name in ('t', 'v1', 'v0'), 'STRIPE_WEBHOOK_SIGNATURE')
            if name == 't':
                need(value.isascii() and value.isdigit() and len(value) <= 12, 'STRIPE_WEBHOOK_SIGNATURE')
                timestamps.append(int(value))
            elif name == 'v1':
                need(re.fullmatch('[0-9a-f]{64}', value), 'STRIPE_WEBHOOK_SIGNATURE'); signatures.append(value)
        need(len(timestamps) == 1 and 1 <= len(signatures) <= 8 and
             abs(self._now()-timestamps[0]) <= tolerance, 'STRIPE_WEBHOOK_STALE_OR_INVALID')
        try: secret = self._webhook_secret()
        except BaseException: raise ValueError('STRIPE_WEBHOOK_SECRET_UNAVAILABLE') from None
        need(type(secret) is str and secret.startswith('whsec_') and len(secret) <= 512 and
             re.fullmatch(r'[A-Za-z0-9_]+', secret),
             'STRIPE_WEBHOOK_SECRET')
        expected = hmac.new(secret.encode('ascii'), str(timestamps[0]).encode('ascii')+b'.'+raw_body, hashlib.sha256).hexdigest()
        need(any(hmac.compare_digest(expected, signature) for signature in signatures), 'STRIPE_WEBHOOK_SIGNATURE')
        event = _parse(raw_body); _provider_id(event.get('id'), 'evt_')
        allowed = ('checkout.session.completed', 'checkout.session.async_payment_succeeded',
                   'checkout.session.async_payment_failed', 'checkout.session.expired',
                   'payment_intent.succeeded', 'payment_intent.payment_failed',
                   'charge.refunded', 'charge.dispute.created', 'charge.dispute.closed')
        need(event.get('type') in allowed and event.get('livemode') is self.policy['livemode'] and
             event.get('account', self.policy['account']) == self.policy['account'], 'STRIPE_WEBHOOK_SCOPE')
        data = event.get('data'); need(type(data) is dict and type(data.get('object')) is dict, 'STRIPE_WEBHOOK_OBJECT')
        value = data['object']; raw_hash = hashlib.sha256(raw_body).hexdigest()
        with self._exclusive():
            intent, phase, identifier, observation = self._get(reference)
            metadata = value.get('metadata')
            if value.get('object') != 'checkout.session' and observation is None:
                observation = self.observe(reference)['observation']
            if value.get('object') == 'checkout.session':
                _session(value, intent, reference)
                need(identifier is None or value['id'] == identifier, 'STRIPE_WEBHOOK_FOREIGN')
                if identifier is None:
                    self.db.execute('UPDATE stripe_intents SET session=? WHERE effect=?', (value['id'], reference))
            elif metadata and metadata.get('aap_intent') == reference:
                _metadata(metadata, intent, reference)
                need(value.get('object') in ('payment_intent', 'charge'), 'STRIPE_WEBHOOK_OBJECT')
                if value['object'] == 'payment_intent':
                    need(observation is not None and value.get('id') == observation.get('payment_intent'), 'STRIPE_WEBHOOK_FOREIGN')
                else:
                    need(observation is not None and value.get('payment_intent') == observation.get('payment_intent'), 'STRIPE_WEBHOOK_FOREIGN')
            else:
                need(observation is not None and value.get('object') == 'dispute' and
                     value.get('charge') == observation.get('charge_id') and observation.get('charge_id') is not None,
                     'STRIPE_WEBHOOK_FOREIGN')
            old = self.db.execute('SELECT effect,digest FROM stripe_events WHERE id=?', (event['id'],)).fetchone()
            if old:
                need(old == (reference, raw_hash), 'STRIPE_WEBHOOK_REPLAY_CHANGED')
            else:
                self.db.execute('INSERT INTO stripe_events VALUES (?,?,?,?)', (event['id'], reference, raw_hash, event['type']))
                self.store.append('STRIPE_EVENT', reference, {'id': event['id'], 'type': event['type'], 'digest': raw_hash})
        # Never advance money from the incoming event alone. Pull the actual
        # provider object; late/out-of-order events therefore cannot regress it.
        return self.observe(reference)

    def portable_record(self, reference):
        with self._exclusive():
            intent, phase, session, observation = self._get(reference)
            approval = json.loads(self.db.execute('SELECT approval FROM stripe_intents WHERE effect=?', (reference,)).fetchone()[0])
            return dict(version='covenant-stripe-observation-record/0.1', intent=intent, payer_approval=approval,
                effect=reference, phase=phase, session_id=session, observation=observation,
                evidence='OWNER_REPORTED_OBSERVATION_REVERIFY_WITH_PROVIDER',
                delivery_verified=False, public_disclosure_authorized=False)

    def close(self):
        self.store.close()


def verify_record(record, policy, *, expected_effect):
    """Check exact payer approval offline; provider claims remain unverified."""
    exact(record, 'version intent payer_approval effect phase session_id observation evidence delivery_verified public_disclosure_authorized')
    need(record['version'] == 'covenant-stripe-observation-record/0.1', 'STRIPE_RECORD_PROFILE')
    key(expected_effect)
    need(len(canonical(record)) <= 65536 and record['phase'] in ('ATTEMPTED', 'UNKNOWN', 'CREATED', 'OBSERVED') and
         (record['observation'] is None or type(record['observation']) is dict), 'STRIPE_RECORD_BOUND')
    if record['session_id'] is not None: _provider_id(record['session_id'], 'cs_')
    reference = _check_approval(policy, record['intent'], record['payer_approval'])
    need(reference == expected_effect == record['effect'], 'STRIPE_RECORD_PIN')
    need(record['evidence'] == 'OWNER_REPORTED_OBSERVATION_REVERIFY_WITH_PROVIDER' and
         record['delivery_verified'] is False and record['public_disclosure_authorized'] is False,
         'STRIPE_RECORD_ASSURANCE')
    return dict(effect=reference, payer_signature_verified=True, provider_payment_verified=False,
        delivery_verified=False, current_authority='NOT_ESTABLISHED',
        provider_status='REVERIFY_WITH_ADOPTED_PROVIDER', execution_authorized=False)


class _ProtocolSimulator:
    """Private demo harness: local HTTP, no Stripe account and no real money."""
    KEY = 'rk_test_SYNTHETIC_LOCAL_HTTP_ONLY'
    WEBHOOK = 'whsec_SYNTHETIC_LOCAL_HTTP_ONLY'

    def __init__(self, account='acct_localdemo'):
        self.account_id = account; self.sessions = {}; self.payments = {}; self.charges = {}
        self.requests = []; self.creates = 0; self.disconnect_after_create = False
        self.override = None

    def __enter__(self):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from urllib.parse import parse_qs
        harness = self
        class Handler(BaseHTTPRequestHandler):
            timeout = 5

            def log_message(self, *args): pass
            def do_GET(self): self.handle_api('GET')
            def do_POST(self): self.handle_api('POST')
            def handle_api(self, method):
                if self.headers.get('Authorization') != 'Bearer '+harness.KEY:
                    self.send_response(401); self.end_headers(); return
                url = urlsplit(self.path)
                body = self.rfile.read(int(self.headers.get('Content-Length', '0')))
                fields = {k: v[0] for k, v in parse_qs(body.decode()).items()} if body else {}
                harness.requests.append((method, self.path, deepcopy(fields)))
                result = None
                if method == 'GET' and url.path == '/v1/account':
                    result = {'object': 'account', 'id': harness.account_id}
                elif method == 'POST' and url.path == '/v1/checkout/sessions':
                    token = self.headers.get('Idempotency-Key')
                    result = next((row for row in harness.sessions.values() if row['metadata']['aap_intent'] == token), None)
                    if result is None:
                        harness.creates += 1; identifier = 'cs_test_local_'+str(harness.creates)
                        metadata = {name[9:-1]: value for name, value in fields.items() if name.startswith('metadata[')}
                        result = dict(object='checkout.session', id=identifier, livemode=False, mode=fields['mode'],
                            currency=fields['line_items[0][price_data][currency]'], amount_total=int(fields['line_items[0][price_data][unit_amount]']),
                            client_reference_id=fields['client_reference_id'], expires_at=int(fields['expires_at']),
                            metadata=metadata, status='open', payment_status='unpaid', payment_intent=None,
                            url='https://checkout.stripe.com/c/pay/SYNTHETIC_LOCAL_ONLY_'+str(harness.creates))
                        harness.sessions[identifier] = result
                    if harness.override: result = {**result, **harness.override}
                    if harness.disconnect_after_create:
                        self.close_connection = True
                        return
                elif method == 'GET' and url.path == '/v1/checkout/sessions':
                    result = {'object': 'list', 'data': list(harness.sessions.values()), 'has_more': False}
                elif method == 'GET' and url.path.startswith('/v1/checkout/sessions/'):
                    result = harness.sessions.get(url.path.rsplit('/', 1)[-1])
                elif method == 'GET' and url.path.startswith('/v1/payment_intents/'):
                    result = harness.payments.get(url.path.rsplit('/', 1)[-1])
                elif method == 'GET' and url.path.startswith('/v1/charges/'):
                    result = harness.charges.get(url.path.rsplit('/', 1)[-1])
                if result is None:
                    self.send_response(404); self.end_headers(); return
                raw = json.dumps(result).encode()
                self.send_response(200); self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(raw))); self.end_headers(); self.wfile.write(raw)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True); self.thread.start()
        self.origin = 'http://127.0.0.1:'+str(self.server.server_port)
        return self

    def __exit__(self, *args):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=5)

    def transport(self):
        return StripeHTTPTransport(lambda: self.KEY, origin=self.origin, loopback_harness=True)

    def pay(self, reference):
        row = next(row for row in self.sessions.values() if row['metadata']['aap_intent'] == reference)
        index = row['id'].rsplit('_', 1)[-1]; payment_id = 'pi_local_'+index; charge_id = 'ch_local_'+index
        row.update(status='complete', payment_status='paid', payment_intent=payment_id)
        self.payments[payment_id] = dict(object='payment_intent', id=payment_id, livemode=False,
            amount=row['amount_total'], amount_received=row['amount_total'], currency=row['currency'],
            metadata=deepcopy(row['metadata']), status='succeeded', latest_charge=charge_id)
        self.charges[charge_id] = dict(object='charge', id=charge_id, payment_intent=payment_id,
            livemode=False, amount=row['amount_total'], currency=row['currency'], amount_refunded=0, disputed=False)
        return deepcopy(row)

    def event(self, value, *, now, kind='checkout.session.completed', identifier='evt_local_1'):
        event = dict(object='event', id=identifier, type=kind, livemode=False,
                     account=self.account_id, created=now, data={'object': deepcopy(value)})
        raw = json.dumps(event, separators=(',', ':')).encode()
        signature = hmac.new(self.WEBHOOK.encode(), str(now).encode()+b'.'+raw, hashlib.sha256).hexdigest()
        return raw, 't='+str(now)+',v1='+signature


# Public, explicitly synthetic owner-test harness; never a Stripe observation.
LocalStripeSimulator = _ProtocolSimulator

def demo(directory=None):
    """Run actual loopback HTTP requests against a clearly labelled simulator."""
    import tempfile
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    with tempfile.TemporaryDirectory() as temporary, _ProtocolSimulator() as provider:
        private = Ed25519PrivateKey.generate(); now = int(time.time())
        policy = make_policy(account=provider.account_id, payer_keys=[public_key(private)],
            return_origin='https://merchant.example', maximum_order=2500, operation_budget=5000)
        gateway = StripeGateway(directory or temporary+'/owner', policy, provider.transport(),
            clock=lambda: now, webhook_secret=lambda: provider.WEBHOOK)
        try:
            intent = gateway.prepare(agreement=hashlib.sha256(b'SYNTHETIC chart order').hexdigest(),
                revision=1, payer=public_key(private), amount=2500, description='Synthetic one-page chart', expires=now+3600)
            first = gateway.execute(intent, approve(intent, private)); reference = first['effect']
            provider.pay(reference)
            paid = gateway.observe(reference)
            charge = next(iter(provider.charges.values())); charge['amount_refunded'] = 500
            refunded = gateway.observe(reference)
            record = gateway.portable_record(reference)
            return dict(version=VERSION, demonstration='LOCAL_HTTP_SIMULATOR_NO_STRIPE_ACCOUNT_NO_MONEY',
                first_phase=first['phase'], payment_state=paid['observation']['payment_state'],
                refund_state=refunded['observation']['payment_state'],
                amount_refunded=refunded['observation']['amount_refunded'],
                real_provider_observed=paid['observation']['provider_observed'],
                requests=len(provider.requests), repeated_execution_creates=gateway.execute(intent, approve(intent, private))['phase'],
                provider_creates=provider.creates, portable_record_contains_credentials=False,
                delivery_verified=record['delivery_verified'])
        finally: gateway.close()


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Owner-controlled Stripe Checkout gateway; never an outbound Stripe Pay transfer.')
    parser.add_argument('action', choices=('profile', 'demo'))
    args = parser.parse_args(argv)
    value = demo() if args.action == 'demo' else describe()
    print(json.dumps(value, sort_keys=True, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
