"""Content stores. Possession of a CID is not trust in a host.

``ContentStore`` is process-local and forgets everything on exit.
``DurableContentStore`` keeps the same content-addressed bytes in an
owner-private directory so a retained CID still resolves after a restart. Each
read rechecks the bytes against their name; a changed file is refused, never
returned. Neither store verifies signatures or decides what the bytes mean.
"""
import hashlib
import os
from pathlib import Path
import re
import secrets
import stat

from .cid import cid_from_bytes, cid_from_digest, parse_cid
from .errors import NativeError, need

MAX_BLOB = 2_000_000
_NAME = re.compile(r'[0-9a-f]{64}\Z')


class _AgreementCache:
    """Find and drop every retained version of one agreement. Shared by both stores."""

    @staticmethod
    def _envelope(blob):
        from .codec import loads
        try:
            value = loads(blob)
        except (ValueError, TypeError, UnicodeError):
            return None
        if type(value) is dict and type(value.get('terms')) is dict and type(value.get('parties')) is dict:
            return value
        return None

    @staticmethod
    def _agreement(envelope):
        from .envelope import escrow_id
        try:
            return escrow_id(envelope)
        except (ValueError, TypeError, UnicodeError):
            return None

    def agreement_of(self, cid):
        """Local agreement key of a stored envelope: stable across its signed versions."""
        blob = self.get(cid)
        envelope = None if blob is None else self._envelope(blob)
        return None if envelope is None else self._agreement(envelope)

    @classmethod
    def _doomed(cls, pairs, agreement):
        """Digests of every envelope version for ``agreement`` and the delivery bytes it names."""
        doomed = set()
        for digest, blob in pairs:
            envelope = cls._envelope(blob)
            if envelope is None or cls._agreement(envelope) != agreement:
                continue
            doomed.add(digest)
            for row in envelope.get('deliveries') or []:
                value = row.get('content_hash') if type(row) is dict else None
                if type(value) is str and len(value) == 64:
                    try:
                        doomed.add(bytes.fromhex(value))
                    except ValueError:
                        pass
        return doomed


class ContentStore(_AgreementCache):
    def __init__(self):
        self._by_sha = {}

    def put(self, blob):
        blob = bytes(blob)
        need(1 <= len(blob) <= MAX_BLOB, 'CONTENT_SIZE')
        digest = hashlib.sha256(blob).digest()
        self._by_sha[digest] = blob
        return cid_from_bytes(blob)

    def get(self, cid):
        return self._by_sha.get(parse_cid(cid))

    def __contains__(self, cid):
        try:
            return parse_cid(cid) in self._by_sha
        except Exception:
            return False

    def items(self, limit=4096):
        """Retained (cid, bytes) pairs in digest order, at most ``limit``."""
        need(type(limit) is int and 1 <= limit <= 100000, 'CONTENT_LIMIT')
        return [(cid_from_bytes(self._by_sha[key]), self._by_sha[key]) for key in sorted(self._by_sha)[:limit]]


    def forget_agreement(self, agreement):
        """Drop every cached envelope version for one agreement and its delivery bytes."""
        removed = []
        for digest in self._doomed(list(self._by_sha.items()), agreement):
            blob = self._by_sha.pop(digest, None)
            if blob is not None:
                removed.append(cid_from_bytes(blob))
        return sorted(removed)


class DurableContentStore(_AgreementCache):
    """Owner-private, restart-safe content-addressed files; one file per SHA-256.

    The directory must already exist, belong to this user and exclude group and
    other access. Writes go to a private temporary file, are synced, then
    atomically renamed. A file whose bytes no longer hash to its name is refused
    with CONTENT_CORRUPT, so on-disk tampering cannot be read back as evidence.
    """

    def __init__(self, directory):
        need(isinstance(directory, (str, Path)) and str(directory).strip(), 'CONTENT_DIRECTORY')
        path = Path(directory).expanduser().absolute()
        need('..' not in path.parts, 'CONTENT_DIRECTORY')
        try:
            info = os.lstat(path)
        except FileNotFoundError:
            raise NativeError('CONTENT_DIRECTORY_MISSING') from None
        need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode), 'CONTENT_DIRECTORY')
        need(info.st_uid == os.getuid() and info.st_mode & 0o077 == 0, 'CONTENT_DIRECTORY_PERMISSIONS')
        self.path = path

    def _file(self, digest_hex):
        return self.path / digest_hex

    def put(self, blob):
        blob = bytes(blob)
        need(1 <= len(blob) <= MAX_BLOB, 'CONTENT_SIZE')
        digest_hex = hashlib.sha256(blob).hexdigest()
        target = self._file(digest_hex)
        try:
            if self.get('sha256:' + digest_hex) is not None:
                return cid_from_bytes(blob)
        except NativeError:
            pass  # A corrupted copy is replaced by these verified bytes.
        temporary = self.path / ('.tmp-' + secrets.token_hex(16))
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(blob)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, target)
        except BaseException:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
            raise
        directory_fd = os.open(self.path, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
        return cid_from_bytes(blob)

    def get(self, cid):
        digest_hex = parse_cid(cid).hex()
        try:
            fd = os.open(self._file(digest_hex), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            return None
        try:
            info = os.fstat(fd)
            need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and
                 info.st_mode & 0o077 == 0 and info.st_size <= MAX_BLOB, 'CONTENT_CORRUPT')
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                blob = stream.read(MAX_BLOB + 1)
        finally:
            os.close(fd)
        need(hashlib.sha256(blob).hexdigest() == digest_hex, 'CONTENT_CORRUPT')
        return blob

    def __contains__(self, cid):
        try:
            return self.get(cid) is not None
        except Exception:
            return False

    def items(self, limit=4096):
        need(type(limit) is int and 1 <= limit <= 100000, 'CONTENT_LIMIT')
        names = sorted(name for name in os.listdir(self.path) if _NAME.fullmatch(name))[:limit]
        found = []
        for name in names:
            blob = self.get('sha256:' + name)
            if blob is not None:
                found.append((cid_from_bytes(blob), blob))
        return found

    def _retained(self):
        for name in sorted(os.listdir(self.path)):
            if not _NAME.fullmatch(name):
                continue
            try:
                blob = self.get('sha256:' + name)
            except NativeError:
                continue  # A corrupt file is not read as an envelope; it is never returned either.
            if blob is not None:
                yield bytes.fromhex(name), blob

    def forget_agreement(self, agreement):
        """Delete every retained envelope version for one agreement and its delivery bytes.

        Each removal is an unlink followed by a directory sync, so a crash leaves
        a file either present and intact or gone.
        """
        removed = []
        for digest in self._doomed(self._retained(), agreement):
            try:
                os.unlink(self._file(digest.hex()))
            except FileNotFoundError:
                continue
            removed.append(cid_from_digest(digest))
        if removed:
            directory_fd = os.open(self.path, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        return sorted(removed)
