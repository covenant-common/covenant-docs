"""Chargebacks as AAP dispute records; AAP evidence goes back to Stripe only as staged text.

When a payer disputes a card payment with its bank, Stripe opens a Dispute
(docs.stripe.com/api/disputes/object). covenant_agent.stripe_payments reads
these objects for agent payments and for Checkout payments and keeps their
provider facts. This module turns each provider dispute into an AAP dispute
record bound to the exact agreement and payment (profile
covenant-stripe-chargeback-dispute/0.1), keeps its duties current as Stripe's
status changes, can open the agreement's own adopted dispute ladder
(covenant_language.agreement_procedures), and exports AAP evidence as Stripe
dispute evidence text. Evidence is staged with submit=false; the owner reviews
and submits it in the Dashboard.

A chargeback decides who keeps the money under card-network rules. It is not a
finding about delivery or about the agreement, and nothing here marks a deal
complete. The week-later review keeps each fact separate.
"""
from copy import deepcopy
import hashlib
import json

from covenant_chain.crypto import canonical, digest, key, need
from covenant_language import agreement_procedures as procedures

from . import stripe_payments as payments_module
from .stripe_action import REMEDIATION as ACTION_REMEDIATION  # fix text for the codes raised here (payments_module.remediation)
from .assent_view import utc

DISPUTE_VERSION = 'covenant-stripe-chargeback-dispute/0.1'
REVIEW_VERSION = 'covenant-stripe-deal-review/0.1'
DISPUTE_LABEL = 'COVENANT-STRIPE-CHARGEBACK-DISPUTE-0.1'
STAGE_LABEL = 'COVENANT-STRIPE-DISPUTE-EVIDENCE-0.1'
EVIDENCE_LIMIT = 150000
OPEN = ('warning_needs_response', 'needs_response', 'warning_under_review', 'under_review')
RECORD_FIELDS = ('version agreement route reference provider provider_dispute payment_intent charge claimant '
                 'respondent reason amount currency provider_status evidence_due_by duties observed_at basis '
                 'finding_on_delivery')


def duties(status, amount, due_by, respondent):
    """What each party still owes while the provider dispute moves; data, never authority."""
    if status in ('needs_response', 'warning_needs_response'):
        return [{'duty': 'RESPOND_TO_PROVIDER_DISPUTE', 'by': respondent, 'due_by': due_by, 'status': 'OPEN'}]
    if status in ('under_review', 'warning_under_review'):
        return [{'duty': 'AWAIT_CARD_NETWORK_DECISION', 'by': None, 'due_by': None, 'status': 'OPEN'}]
    if status == 'lost':
        return [{'duty': 'NONE_AMOUNT_RETURNED_TO_PAYER_BY_CHARGEBACK', 'by': None, 'due_by': None,
                 'status': 'CLOSED', 'amount': amount},
                {'duty': 'COUNT_CHARGEBACK_AGAINST_ANY_AGREED_REFUND', 'by': respondent, 'due_by': None,
                 'status': 'OPEN', 'amount': amount}]
    if status == 'won':
        return [{'duty': 'NONE_FUNDS_KEPT_BY_MERCHANT', 'by': None, 'due_by': None, 'status': 'CLOSED'}]
    if status in ('warning_closed', 'prevented'):
        return [{'duty': 'NONE_INQUIRY_CLOSED', 'by': None, 'due_by': None, 'status': 'CLOSED'}]
    return [{'duty': 'RECONCILE_UNDOCUMENTED_STATUS', 'by': respondent, 'due_by': None, 'status': 'OPEN'}]


def dispute_record(payments, identifier):
    """The AAP record of one provider dispute, built from the facts the owner gateway observed."""
    row = payments.dispute(identifier)
    facts = row['facts']
    respondent = payments.policy['principal']
    body = {'version': DISPUTE_VERSION, 'agreement': row['agreement'], 'route': row['route'],
            'reference': row['reference'], 'provider': 'stripe', 'provider_dispute': row['id'],
            'payment_intent': facts['payment_intent'], 'charge': facts['charge'], 'claimant': row['payer'],
            'respondent': respondent, 'reason': facts['reason'], 'amount': facts['amount'],
            'currency': facts['currency'], 'provider_status': facts['status'], 'evidence_due_by': facts['due_by'],
            'duties': duties(facts['status'], facts['amount'], facts['due_by'], respondent),
            'observed_at': row['updated_at'], 'basis': 'PROVIDER_CHARGEBACK_OBSERVED', 'finding_on_delivery': 'NONE'}
    return {'id': digest(DISPUTE_LABEL, body), 'record': body}


def check(made):
    need(type(made) is dict and set(made) == {'id', 'record'}, 'STRIPE_DISPUTE_RECORD')
    body = made['record']
    need(type(body) is dict and set(body) == set(RECORD_FIELDS.split()) and body['version'] == DISPUTE_VERSION and
         digest(DISPUTE_LABEL, body) == made['id'], 'STRIPE_DISPUTE_RECORD')
    return body


class Chargebacks:
    """The owner's dispute mapper. Install with payments.observe_evidence(Chargebacks(payments)).

    Each new provider dispute state observed by the gateway becomes an AAP
    dispute record appended to the agreement's evidence chain: opened once,
    then updated on each status change.
    """

    def __init__(self, payments):
        need(isinstance(payments, payments_module.StripePayments), 'STRIPE_DISPUTE_RECORD')
        self.payments = payments

    def __call__(self, kind, value):
        if kind == 'PROVIDER_DISPUTE':
            return self.record(value['dispute']['id'])
        return None

    def record(self, identifier):
        made = dispute_record(self.payments, identifier)
        body = made['record']
        earlier = [row['record'] for row in self.payments.chain(body['agreement'])
                   if row['record']['kind'] in ('AAP_DISPUTE_OPENED', 'AAP_DISPUTE_UPDATED') and
                   row['record']['body'].get('provider_dispute') == identifier]
        if earlier and earlier[-1]['body'].get('dispute') == made['id']:
            return made
        self.payments.append_evidence(body['agreement'], 'AAP_DISPUTE_UPDATED' if earlier else 'AAP_DISPUTE_OPENED',
                                      {'dispute': made['id'], **deepcopy(body)})
        return made


def ladder_payload(made, ladder, actor, at, outcome):
    """The OPEN event on the agreement's adopted ladder, claiming with this dispute record.

    actor is 'claimant' (the payer) or 'respondent' (the owner); the matching
    party must be a disputant of the ladder. The actor signs the payload with
    its own key outside this module; the ladder, not the card network, decides.
    """
    body = check(made)
    need(type(ladder) is dict and set(ladder) == {'policy', 'adoptions', 'events'} and
         actor in ('claimant', 'respondent'), 'STRIPE_DISPUTE_LADDER')
    policy = ladder['policy']
    try:
        ident = procedures.identifier(policy)
    except (ValueError, TypeError, KeyError):
        raise ValueError('STRIPE_DISPUTE_LADDER') from None
    configuration = policy['configuration']
    need(policy['kind'] == 'ESCALATION', 'STRIPE_DISPUTE_LADDER')
    roles = {canonical(policy['parties'][role]): role for role in configuration['disputants']}
    role = roles.get(canonical(body['claimant'] if actor == 'claimant' else body['respondent']))
    need(role is not None and outcome in configuration['outcomes'], 'STRIPE_DISPUTE_LADDER')
    payload = procedures.event_payload(policy, ladder['adoptions'], ladder['events'], role, 'OPEN',
                                       {'claim': made['id'], 'result': deepcopy(outcome), 'bond_receipt': None}, at)
    return {'ladder': ident, 'actor': role, 'event_payload': payload,
            'next': 'The %s signs event_payload.body with its own key; the agreed ladder decides.' % actor,
            'execution_authorized': False}


def _ascii(value, limit):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 or c == '\n' for c in value),
         'STRIPE_DISPUTE_EVIDENCE')
    return value


def stripe_evidence(made, review=None, *, product_description=None, service_date=None):
    """Stripe dispute evidence fields carrying AAP facts: hashes, public keys, amounts and times, no personal data."""
    body = check(made)
    lines = ['AAP agreement evidence for disputed payment %s (Stripe dispute %s).' % (
                 body['payment_intent'] or body['charge'], body['provider_dispute']),
             'Exact agreement SHA-256: %s.' % body['agreement'],
             'Paying party key: %s. Merchant owner key: %s.' % (body['claimant'], body['respondent'])]
    if review is not None:
        need(type(review) is dict and review.get('version') == REVIEW_VERSION and
             review.get('agreement') == body['agreement'], 'STRIPE_REVIEW_INPUT')
        signatures = review['signatures']
        lines.append('The payer key signed an exact authorisation of %d payment action(s); %d owner approval(s) and '
                     '%d delegation grant(s) verify offline.' % (signatures['payer_authorizations_verified'],
                                                                 signatures['approvals_verified'],
                                                                 signatures['grants_at_acceptance_verified']))
        delivery = review['delivery']
        if type(delivery) is dict:
            lines.append('Delivery check: verdict %s, recorded at %s, verified %s.' % (
                delivery['verdict'], utc(delivery['at']), 'yes' if delivery['delivery_verified'] else 'no'))
        else:
            lines.append('Delivery check: not supplied with this evidence.')
        lines.append('Refunds observed: %d minor units. Portable record head: %s.' % (review['refunded'], review['head']))
    lines.append('The complete signed AAP record can be shared on request. It is evidence, not a decision.')
    fields = {'evidence[uncategorized_text]': _ascii('\n'.join(lines), 20000)}
    if product_description is not None:
        fields['evidence[product_description]'] = _ascii(product_description, 20000)
    if service_date is not None:
        fields['evidence[service_date]'] = utc(service_date)[:10]
    need(sum(len(value) for value in fields.values()) <= EVIDENCE_LIMIT, 'STRIPE_DISPUTE_EVIDENCE')
    return fields


def stage_evidence(payments, made, fields):
    """Stage evidence on the provider dispute (submit=false). AAP never submits evidence to the bank."""
    body = check(made)
    need(type(fields) is dict and fields and all(type(k) is str and k.startswith('evidence[') and type(v) is str
                                                  for k, v in fields.items()), 'STRIPE_DISPUTE_EVIDENCE')
    need(sum(len(value) for value in fields.values()) <= EVIDENCE_LIMIT, 'STRIPE_DISPUTE_EVIDENCE')
    current = payments.dispute(body['provider_dispute'])
    need(current['status'] in OPEN, 'STRIPE_DISPUTE_CLOSED')
    # Evidence text has line breaks, so it is hashed as JSON rather than as an ASCII-profile record.
    fingerprint = hashlib.sha256(json.dumps(fields, sort_keys=True).encode('ascii')).hexdigest()
    token = digest(STAGE_LABEL, {'dispute': made['id'], 'fields': fingerprint})
    reply = payments.transport.exchange('POST', '/v1/disputes/' + body['provider_dispute'],
                                        data=sorted(fields.items()) + [('submit', 'false')], idempotency=token)
    need(reply['status'] == 200 and type(reply['body']) is dict and
         reply['body'].get('id') == body['provider_dispute'], 'STRIPE_DISPUTE_STAGE')
    payments.append_evidence(body['agreement'], 'AAP_DISPUTE_EVIDENCE_STAGED', {
        'dispute': made['id'], 'provider_dispute': body['provider_dispute'], 'fields': sorted(fields),
        'fields_sha256': fingerprint, 'submitted_to_bank': False})
    return {'provider_dispute': body['provider_dispute'], 'staged': True, 'submitted_to_bank': False,
            'next': 'Owner: review the staged evidence in the Stripe Dashboard and submit it there.',
            'execution_authorized': False}


def review(record, *, expected_principal, delivery=None, checkout_policy=None):
    """The week-later review of a portable payment record: each fact kept separate, nothing marked complete.

    delivery is the result of the agreement's own delivery check, for example
    covenant_agent.commerce.verify_receipt; it is never inferred from payment.
    """
    need(type(record) is dict, 'STRIPE_REVIEW_INPUT')
    verified = payments_module.verify_record(record, expected_principal=expected_principal,
                                             expected_agreement=record.get('agreement'),
                                             checkout_policy=checkout_policy)
    accepted, refunds, disputes = {}, {}, {}
    for row in record['evidence']:
        entry = row['record']
        if entry['kind'] == 'ACTION_ACCEPTED':
            accepted[entry['operation']] = entry['at']
        elif entry['kind'] == 'PROVIDER_REFUND':
            refunds[entry['body']['refund']] = entry['body']
        elif entry['kind'] in ('AAP_DISPUTE_OPENED', 'AAP_DISPUTE_UPDATED'):
            disputes[entry['body']['provider_dispute']] = entry['body']
    operations = [{'operation': row['record']['body']['operation'], 'operation_id': row['record']['body']['operation_id'],
                   'amount': row['record']['body']['amount'], 'state': row['state'], 'outcome': row['outcome'],
                   'provider_status': row['provider_status'],
                   'permission_assessed_at': accepted.get(row['record']['body']['operation_id'])}
                  for row in record['operations']]
    if delivery is None:
        delivered = 'NOT_SUPPLIED'
    else:
        need(type(delivery) is dict and delivery.get('verdict') in ('MEETS', 'FAILS', 'INCOMPLETE') and
             type(delivery.get('delivery_verified')) is bool and type(delivery.get('at')) is int, 'STRIPE_REVIEW_INPUT')
        delivered = {'verdict': delivery['verdict'], 'delivery_verified': delivery['delivery_verified'],
                     'at': delivery['at'], 'basis': delivery.get('basis', 'SUPPLIED_DELIVERY_CHECK')}
    remaining = []
    if delivered == 'NOT_SUPPLIED' or not delivered['delivery_verified']:
        remaining.append({'duty': 'DELIVERY_NOT_VERIFIED', 'status': 'OPEN'})
    for row in operations:
        if row['state'] in payments_module.OPEN:
            remaining.append({'duty': 'RECONCILE_PAYMENT', 'operation_id': row['operation_id'], 'status': 'OPEN'})
    for value in refunds.values():
        if value['status'] in ('pending', 'requires_action'):
            remaining.append({'duty': 'REFUND_IN_FLIGHT', 'refund': value['refund'], 'status': 'OPEN'})
    for value in disputes.values():
        remaining += [{**duty, 'provider_dispute': value['provider_dispute']} for duty in value['duties']
                      if duty['status'] == 'OPEN']
    settled = {row['provider_ref']: row['record']['body']['amount'] for row in record['operations']
               if row['record']['body']['operation'] == 'refund' and row['outcome'] == 'SUCCEEDED' and
               row['provider_ref'] is not None}
    settled.update({name: value['amount'] for name, value in refunds.items() if value['status'] == 'succeeded'})
    return {'version': REVIEW_VERSION, 'agreement': record['agreement'], 'head': verified['head'],
            'signatures': {name: verified[name] for name in verified if name.endswith('_verified')
                           and type(verified[name]) is int},
            'operations': operations,
            'refunded': sum(settled.values()),
            'refunds': sorted(refunds.values(), key=lambda value: value['refund']),
            'disputes': [disputes[name] for name in sorted(disputes)], 'delivery': delivered,
            'remaining': remaining, 'provider_payment_verified': False,
            'provider_status': verified['provider_status'], 'current_authority': 'NOT_ESTABLISHED',
            'complete': False, 'complete_marked_by_gateway': False, 'execution_authorized': False}


def describe():
    return {'profile': DISPUTE_VERSION, 'review': REVIEW_VERSION, 'evidence_to_provider': 'STAGED_ONLY_SUBMIT_FALSE',
            'chargeback_is_delivery_finding': False, 'complete_marked': False, 'execution_authorized': False}
