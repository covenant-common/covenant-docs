"""AAP commerce agreements for agent checkouts, with evidence and delivery receipts.

One record covers an Agentic Commerce Protocol (ACP) or Universal Commerce
Protocol (UCP) checkout: a typed exchange agreement (urn:aap:agreement-
application:0.1), the reference a checkout extension carries, content-addressed
evidence of order and payment events, and the buyer's signed delivery receipt
checked against the typed acceptance criteria.

Checkout, order and payment messages are evidence. They never assent, pay,
release escrow or complete an obligation. The parties' own signatures on the
exact typed terms decide, and a receipt verdict is recomputed here, never taken
from the signer. Nothing in this module reads a clock, opens a socket or signs.
"""
from copy import deepcopy
from decimal import Decimal, DecimalException
import base64
import hashlib
import json
import re

from covenant_language import agreement_application as application_profile

from .errors import NativeError

PROFILE = 'urn:aap:commerce-agreement:0.1'
EXTENSION = 'io.github.covenant-common.shopping.agreement'
EXTENSION_VERSION = '2026-10-25'
FIELD = 'aap_agreement'
APPLICATION_URN = 'urn:aap:agreement-application:0.1:'
AGREEMENT_URN = 'urn:aap:agreement:'
EVIDENCE = 'urn:aap:commerce-evidence:0.1'
RECEIPT = 'urn:aap:delivery-receipt:0.1'
RECEIPT_LABEL = 'AAP-DELIVERY-RECEIPT-0.1'
JOURNAL = 'urn:aap:commerce-journal:0.1'
# Proposed publication under the organisation's own GitHub Pages domain. Publishing is an owner step.
SPEC_URL = 'https://covenant-common.github.io/covenant-docs/commerce-agreement-2026-10-25.html'
SCHEMA_URL = 'https://covenant-common.github.io/covenant-docs/schemas/aap-agreement-2026-10-25.json'
# Tested snapshots. Another snapshot is refused rather than read by guesswork.
SNAPSHOTS = {'ACP': ('2026-04-17',), 'UCP': ('2026-08-25',)}
REMEDIES = ('AAP_ESCROW', 'DISPUTE_LADDER', 'RECORD_ONLY')
VERDICTS = ('MEETS', 'FAILS', 'INCOMPLETE')
ORDER_FIELDS = frozenset(('protocol', 'version', 'checkout', 'checkout_id', 'merchant', 'currency', 'total',
                          'items', 'fulfillment', 'deliver_by'))
MAX_DOCUMENT = 1 << 20
MAX_CRITERIA = 8192
MAX = 2**53 - 1
HEX = re.compile(r'[0-9a-f]{64}\Z')
FLAGS = {'execution_authorized': False, 'payment_authorized': False, 'release_authorized': False}
TEMPLATE = ('AAP commerce agreement {{aap_profile}} for {{protocol}} checkout {{checkout_id}} '
            '(snapshot {{checkout}}) with merchant {{merchant}}. Items: {{items}}. Price: {{price}}. '
            'Fulfilment: {{fulfillment}}; deliver by {{deliver_by}}. The seller delivers; the buyer accepts '
            'or rejects against the typed acceptance criteria in a signed delivery receipt. A rejection is '
            'resolved by {{remedy}} ({{remedy_reference}}). Checkout, order and payment messages are evidence, '
            'not assent, payment or release.')

HINTS = {
    'COMMERCE_DOCUMENT': 'Pass the exact received JSON bytes (UTF-8) of one checkout, order or payment message.',
    'COMMERCE_DOCUMENT_SIZE': 'Send at most 1 MiB of JSON. Split unrelated messages into separate evidence records.',
    'COMMERCE_DOCUMENT_JSON': 'Send one well-formed UTF-8 JSON value without a byte-order mark, NaN or Infinity.',
    'COMMERCE_DOCUMENT_DEPTH': 'The document nests or repeats too much (depth 32, 50000 values). Send the protocol message itself.',
    'COMMERCE_DUPLICATE_KEY': 'The JSON repeats a member name. Request an unambiguous original; do not pick one of the values.',
    'COMMERCE_NUMBER': 'Use JSON numbers of at most 40 characters. Money must be an integer in minor units.',
    'COMMERCE_CREDENTIAL_REFUSED': 'Remove card numbers, CVCs, tokens and payment credentials. AAP records only checkout, order and allowance facts.',
    'COMMERCE_TEXT': 'Use the documented bounded text: printable ASCII identifiers, UTF-8 display text within its byte cap.',
    'COMMERCE_HASH': 'Pass a 64-character lowercase hex SHA-256 value.',
    'COMMERCE_PROTOCOL': 'Use protocol ACP or UCP.',
    'COMMERCE_PROTOCOL_VERSION': 'Use a tested snapshot: ACP 2026-04-17 or UCP 2026-08-25. Other versions need their own reviewed adapter.',
    'COMMERCE_CURRENCY': 'Use a three-letter ISO 4217 currency code exactly as the checkout states it.',
    'COMMERCE_AMOUNT': 'Use an integer amount in minor units from 0 to 9007199254740991; booleans and decimals are refused.',
    'COMMERCE_ORDER': 'Pass order terms with exactly protocol, version, checkout, checkout_id, merchant, currency, total, items, fulfillment and deliver_by.',
    'COMMERCE_ITEMS': 'Pass 1 to 32 line items with an id, an integer quantity of at least 1 and optional integer total.',
    'COMMERCE_REMEDY': 'Choose AAP_ESCROW with an escrow policy id, DISPUTE_LADDER with an escalation policy id, or RECORD_ONLY with neither.',
    'COMMERCE_CRITERIA_SIZE': 'Keep the typed acceptance criteria within 8192 canonical bytes so the checkout extension stays small.',
    'COMMERCE_NOT_COMMERCE_AGREEMENT': 'This typed application is not an exact urn:aap:commerce-agreement:0.1 model. Draft it with covenant_commerce.draft.',
    'COMMERCE_REFERENCE': 'Use the exact aap_agreement object returned by covenant_commerce.draft or reference.',
    'COMMERCE_REFERENCE_CHANGED': 'The checkout carries different agreement terms. Do not complete checkout; ask the merchant to echo the exact reference.',
    'COMMERCE_EVIDENCE_KIND': 'Use an evidence kind documented for this protocol.',
    'COMMERCE_EVIDENCE_SUMMARY': 'Evidence summaries are bounded objects produced by the protocol adapter.',
    'COMMERCE_EVIDENCE_LIST': 'Cite at most 32 distinct 64-hex evidence record ids.',
    'COMMERCE_RECEIPT': 'Pass the receipt as {body, observed, signature} exactly as prepared and signed.',
    'COMMERCE_RECEIPT_CHANGED': 'The signed receipt does not match the recomputed criteria results. Prepare a new receipt with receipt_payload.',
    'COMMERCE_RECEIPT_CRITERION': 'Observe only criteria named in the agreed acceptance criteria.',
    'COMMERCE_RECEIPT_SIGNATURE': 'The buyer key named in the agreement must sign the exact receipt body.',
    'COMMERCE_ADOPTION': 'Pass adoption as {echoes, approvals, expected_closure} from the assented agreement, or omit it.',
    'COMMERCE_CLOCK': 'Pass an owner-adopted integer time in seconds; it is an assertion, not an observed clock.',
    'COMMERCE_JOURNAL_ENTRY': 'Record only evidence or receipt outputs from this module, unchanged.',
    'COMMERCE_JOURNAL_HEAD': 'The journal head differs from the head you retained. Investigate before relying on this history.',
    'COMMERCE_JOURNAL_CHANGED': 'The stored journal no longer verifies. Restore it from a backup and compare with your retained head.',
    'COMMERCE_JOURNAL_KEY_REUSED': 'This idempotency key already stores a different record. Use a new key for a new effect.',
    'COMMERCE_JOURNAL_QUOTA': 'This journal is full (100000 records or 256 MiB). Start a new journal directory and retain both heads.',
    'COMMERCE_SIGNATURE_UCP_ONLY': 'RFC 9421 webhook signatures are checked for UCP order events only; ACP webhooks use '
                                   'the Merchant-Signature HMAC in the owner SDK (covenant_agent.commerce_acp).',
}


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS[code])


def _hex(value, code='COMMERCE_HASH'):
    need(type(value) is str and HEX.fullmatch(value) is not None, code)
    return value


def _ascii(value, limit=256, code='COMMERCE_TEXT'):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _utf8(value, limit=1024, code='COMMERCE_TEXT'):
    need(type(value) is str and bool(value), code)
    try:
        size = len(value.encode('utf-8'))
    except UnicodeError:
        raise NativeError(code, HINTS[code]) from None
    need(size <= limit, code)
    return value


def _amount(value):
    need(type(value) is int and 0 <= value <= MAX, 'COMMERCE_AMOUNT')
    return value


def _currency(value):
    need(type(value) is str and re.fullmatch(r'[A-Za-z]{3}', value) is not None, 'COMMERCE_CURRENCY')
    return value


def items(value):
    """A received array, or nothing: never iterate a string or object that should have been a list."""
    return value if type(value) is list else []


def content_digest(data):
    """RFC 9530 Content-Digest member for the exact bytes."""
    return 'sha-256=:' + base64.b64encode(hashlib.sha256(bytes(data)).digest()).decode('ascii') + ':'


def document(raw, limit=MAX_DOCUMENT):
    """Parse exact received JSON with byte, depth, count and duplicate-key bounds.

    Returns (value, exact_bytes). Numbers with a fraction or exponent become
    Decimal so a tax rate never turns into binary floating point; money fields
    are separately required to be integers by each adapter.
    """
    need(isinstance(raw, (bytes, bytearray, str)), 'COMMERCE_DOCUMENT')
    try:
        data = raw.encode('utf-8') if type(raw) is str else bytes(raw)
    except UnicodeError:
        raise NativeError('COMMERCE_DOCUMENT_JSON', HINTS['COMMERCE_DOCUMENT_JSON']) from None
    need(0 < len(data) <= limit, 'COMMERCE_DOCUMENT_SIZE')

    def pairs(items):
        out = {}
        for name, item in items:
            need(name not in out, 'COMMERCE_DUPLICATE_KEY')
            out[name] = item
        return out

    def integer(text):
        need(len(text) <= 40, 'COMMERCE_NUMBER')
        return int(text)

    def fraction(text):
        need(len(text) <= 40, 'COMMERCE_NUMBER')
        try:
            number = Decimal(text)
        except DecimalException:
            raise NativeError('COMMERCE_NUMBER', HINTS['COMMERCE_NUMBER']) from None
        need(number.is_finite(), 'COMMERCE_NUMBER')
        return number

    def constant(_):
        raise NativeError('COMMERCE_DOCUMENT_JSON', HINTS['COMMERCE_DOCUMENT_JSON'])

    try:
        text = data.decode('utf-8')
        need(not text.startswith('﻿'), 'COMMERCE_DOCUMENT_JSON')
        value = json.loads(text, object_pairs_hook=pairs, parse_int=integer, parse_float=fraction,
                           parse_constant=constant)
    except RecursionError:
        raise NativeError('COMMERCE_DOCUMENT_DEPTH', HINTS['COMMERCE_DOCUMENT_DEPTH']) from None
    except (UnicodeError, json.JSONDecodeError):
        raise NativeError('COMMERCE_DOCUMENT_JSON', HINTS['COMMERCE_DOCUMENT_JSON']) from None
    pending, count = [(value, 0)], 0
    while pending:
        node, depth = pending.pop()
        count += 1
        need(depth <= 32 and count <= 50000, 'COMMERCE_DOCUMENT_DEPTH')
        if type(node) is dict:
            for name, item in node.items():
                need(len(name) <= 256, 'COMMERCE_TEXT')
                pending.append((item, depth + 1))
        elif type(node) is list:
            pending.extend((item, depth + 1) for item in node)
        elif type(node) is str:
            need(len(node) <= 65536, 'COMMERCE_TEXT')
    return value, data


# Keys that carry card numbers or payment credentials in ACP (PaymentData, delegate_payment)
# and UCP (pan_credential, token_credential). Such a document is refused, never hashed or stored.
CREDENTIAL_KEYS = frozenset(('payment_method', 'payment_data', 'credential', 'number', 'cvc', 'token'))


def no_credentials(value):
    pending = [value]
    while pending:
        node = pending.pop()
        if type(node) is dict:
            need(not CREDENTIAL_KEYS & set(node), 'COMMERCE_CREDENTIAL_REFUSED')
            pending.extend(node.values())
        elif type(node) is list:
            pending.extend(node)
    return value


def order(protocol, version, checkout, checkout_id, merchant, currency, total, items,
          fulfillment=None, deliver_by=None):
    """Protocol-neutral order terms one AAP record binds for either checkout."""
    need(protocol in SNAPSHOTS, 'COMMERCE_PROTOCOL')
    need(version in SNAPSHOTS[protocol], 'COMMERCE_PROTOCOL_VERSION')
    _hex(checkout); _ascii(checkout_id); _ascii(merchant); _currency(currency); _amount(total)
    need(type(items) is list and 1 <= len(items) <= 32, 'COMMERCE_ITEMS')
    rows = []
    for item in items:
        need(type(item) is dict and set(item) == {'id', 'quantity', 'total', 'title'}, 'COMMERCE_ITEMS')
        _ascii(item['id'], 256, 'COMMERCE_ITEMS')
        need(type(item['quantity']) is int and 1 <= item['quantity'] <= MAX, 'COMMERCE_ITEMS')
        need(item['total'] is None or type(item['total']) is int and 0 <= item['total'] <= MAX, 'COMMERCE_ITEMS')
        if item['title'] is not None:
            _utf8(item['title'], 256)
        rows.append(deepcopy(item))
    need(len({row['id'] for row in rows}) == len(rows), 'COMMERCE_ITEMS')
    if fulfillment is not None:
        _ascii(fulfillment, 64)
    if deliver_by is not None:
        _ascii(deliver_by, 64)
    return {'protocol': protocol, 'version': version, 'checkout': checkout, 'checkout_id': checkout_id,
            'merchant': merchant, 'currency': currency, 'total': total, 'items': rows,
            'fulfillment': fulfillment, 'deliver_by': deliver_by}


def machine(amount):
    """The rehearsed finite exchange model: deliver, accept or reject, then refund or release."""
    _amount(amount)
    events = {'DELIVER': ['seller'], 'ACCEPT': ['buyer'], 'REJECT': ['buyer'], 'CANCEL': ['buyer'],
              'REFUND': ['seller'], 'RELEASE': ['buyer']}
    moves = {'OFFERED': {'DELIVER': 'DELIVERED', 'REJECT': 'CONTESTED', 'CANCEL': 'REFUNDED', 'REFUND': 'REFUNDED'},
             'DELIVERED': {'ACCEPT': 'SETTLED', 'REJECT': 'CONTESTED', 'REFUND': 'REFUNDED', 'RELEASE': 'SETTLED'},
             'CONTESTED': {'REFUND': 'REFUNDED', 'RELEASE': 'SETTLED'}}
    transitions = []
    for state in ('OFFERED', 'DELIVERED', 'CONTESTED'):
        for event in events:
            target = moves[state].get(event, state)
            release = [{'party': 'seller' if target == 'SETTLED' else 'buyer', 'amount': amount}] \
                if target in ('SETTLED', 'REFUNDED') else []
            transitions.append({'from': state, 'event': event, 'to': target, 'guard': {}, 'release': release})
    return {'states': ['OFFERED', 'DELIVERED', 'CONTESTED', 'SETTLED', 'REFUNDED'], 'initial': 'OFFERED',
            'terminals': ['SETTLED', 'REFUNDED'], 'events': events, 'facts': [], 'transitions': transitions}


def norms():
    n = application_profile.norm
    return [n('delivery', 'OBLIGATION', 'seller', 'DELIVER', beneficiary='buyer', deadline='CANCEL', reparations=['cancel_refund']),
            n('cancel_refund', 'OBLIGATION', 'buyer', 'CANCEL', beneficiary='buyer'),
            n('remedy', 'OBLIGATION', 'seller', 'REFUND', beneficiary='buyer', trigger='REJECT'),
            n('seller_refund', 'POWER', 'seller', 'REFUND', discharges=['delivery']),
            n('buyer_release', 'POWER', 'buyer', 'RELEASE', trigger='REJECT', discharges=['remedy', 'delivery']),
            n('acceptance', 'PERMISSION', 'buyer', 'ACCEPT', trigger='DELIVER'),
            n('rejection', 'PERMISSION', 'buyer', 'REJECT', trigger='DELIVER')]


def _items_text(rows):
    text = '; '.join(f"{row['quantity']} x {row['title'] or row['id']} [{row['id']}]" for row in rows)
    return text if len(text.encode('utf-8')) <= 4096 else text.encode('utf-8')[:4093].decode('utf-8', 'ignore') + '...'


def acceptance_hash(acceptance):
    """The exact value each party's meaning echo signs."""
    return application_profile.content_id('AAP-ACCEPTANCE-0.1', acceptance)


def draft(order_terms, parties, context, acceptance, remedy, *, remedy_reference=None, title=None):
    """An unsigned AAP exchange agreement for the parties' explicit assent."""
    need(type(order_terms) is dict and set(order_terms) == ORDER_FIELDS, 'COMMERCE_ORDER')
    o = order(**order_terms)
    need(remedy in REMEDIES, 'COMMERCE_REMEDY')
    need((remedy == 'RECORD_ONLY') == (remedy_reference is None), 'COMMERCE_REMEDY')
    if remedy_reference is not None:
        _hex(remedy_reference)
    application_profile.typed_map(acceptance)
    need(bool(acceptance) and len(application_profile.canonical(acceptance)) <= MAX_CRITERIA, 'COMMERCE_CRITERIA_SIZE')
    terms = {'aap_profile': {'kind': 'TEXT', 'value': PROFILE},
             'protocol': {'kind': 'TEXT', 'value': o['protocol'] + ' ' + o['version']},
             'checkout_id': {'kind': 'TEXT', 'value': o['checkout_id']},
             'checkout': {'kind': 'HASH', 'value': o['checkout']},
             'merchant': {'kind': 'TEXT', 'value': o['merchant']},
             'items': {'kind': 'TEXT', 'value': _items_text(o['items'])},
             'price': {'kind': 'MONEY', 'amount': o['total'], 'unit': o['currency']},
             'fulfillment': {'kind': 'TEXT', 'value': o['fulfillment'] or 'UNSPECIFIED'},
             'deliver_by': {'kind': 'TEXT', 'value': o['deliver_by'] or 'UNSPECIFIED'},
             'remedy': {'kind': 'TEXT', 'value': remedy},
             'remedy_reference': {'kind': 'HASH', 'value': remedy_reference} if remedy_reference
                                 else {'kind': 'TEXT', 'value': 'NONE'}}
    name = title or ('Commerce agreement ' + o['checkout_id'])[:256]
    made = application_profile.draft(name, parties, context, norms(), machine(o['total']),
                                     {'amount': o['total'], 'unit': o['currency']}, acceptance, TEMPLATE, terms=terms)
    app = made['application']
    report = application_profile.rehearse(app)
    # The model is fixed by this module; an unsafe report would be a defect here, not caller input.
    need(report['status'] == 'SAFE_WITHIN_MODEL', 'COMMERCE_NOT_COMMERCE_AGREEMENT')
    echoes = {role: application_profile.echo_payload(app, role, acceptance) for role in sorted(app['parties'])}
    return {'profile': PROFILE, 'application': app, 'application_id': made['id'], 'order': o,
            'reference': reference(app), 'rehearsal': {'status': report['status'], 'id': report['id']},
            'echo_payloads': {role: {'label': e['label'], 'body': e['body']} for role, e in echoes.items()},
            'next': ['Each role signs its echo_payloads entry with its own key outside this tool.',
                     'covenant_contract_application.prepare with the application and both signed echoes.',
                     'Both roles sign prepared.assent_payload; verify, then update the checkout aap_agreement '
                     'with reference(application, agreement_id).'],
            'assent': 'NOT_GIVEN', **FLAGS}


def terms(application):
    """Read a commerce agreement back, refusing any application not built by draft()."""
    pin = application_profile.identifier(application)
    t = application['terms']
    need(t.get('aap_profile') == {'kind': 'TEXT', 'value': PROFILE}, 'COMMERCE_NOT_COMMERCE_AGREEMENT')
    need(set(t) == {'aap_profile', 'protocol', 'checkout_id', 'checkout', 'merchant', 'items', 'price',
                    'fulfillment', 'deliver_by', 'remedy', 'remedy_reference'}, 'COMMERCE_NOT_COMMERCE_AGREEMENT')
    price = t['price']
    need(price['kind'] == 'MONEY' and set(application['parties']) == {'buyer', 'seller'}, 'COMMERCE_NOT_COMMERCE_AGREEMENT')
    canonical = application_profile.canonical
    need(canonical(application['machine']) == canonical(machine(price['amount'])) and
         canonical(application['norms']) == canonical(norms()) and application['template'] == TEMPLATE and
         canonical(application['escrow']) == canonical({'amount': price['amount'], 'unit': price['unit']}) and
         not application['rule_packs'] and application['precedence'] == ['EXPLICIT'], 'COMMERCE_NOT_COMMERCE_AGREEMENT')
    remedy = t['remedy'].get('value')
    need(remedy in REMEDIES and (t['remedy_reference']['kind'] == 'HASH') == (remedy != 'RECORD_ONLY'),
         'COMMERCE_NOT_COMMERCE_AGREEMENT')
    protocol, _, version = t['protocol']['value'].partition(' ')
    return {'application': pin, 'protocol': protocol, 'version': version, 'checkout': t['checkout']['value'],
            'checkout_id': t['checkout_id']['value'], 'merchant': t['merchant']['value'],
            'amount': price['amount'], 'currency': price['unit'], 'remedy': remedy,
            'remedy_reference': t['remedy_reference']['value'] if remedy != 'RECORD_ONLY' else None,
            'parties': deepcopy(application['parties']), 'acceptance': deepcopy(application['acceptance']),
            'criteria': acceptance_hash(application['acceptance'])}


def _criteria_items(acceptance):
    rows = []
    for name in sorted(acceptance):
        value = acceptance[name]
        row = {'name': name, 'kind': value['kind']}
        row.update({'amount': value['amount'], 'unit': value['unit']} if value['kind'] == 'MONEY' else {'value': value['value']})
        rows.append(row)
    return rows


def reference(application, agreement=None):
    """The aap_agreement object an ACP or UCP checkout extension carries."""
    t = terms(application)
    if agreement is not None:
        _hex(agreement)
    return {'profile': PROFILE, 'application': APPLICATION_URN + t['application'],
            'agreement': None if agreement is None else AGREEMENT_URN + agreement,
            'checkout': t['checkout'], 'price': {'amount': t['amount'], 'currency': t['currency']},
            'remedy': t['remedy'], 'criteria': {'hash': t['criteria'], 'items': _criteria_items(t['acceptance'])}}


def field_schema():
    """JSON Schema (2020-12) of the aap_agreement field both checkout extensions add."""
    hex64 = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
    plain = ['INTEGER', 'BOOLEAN', 'TEXT', 'HASH', 'ROLE']
    item = {'type': 'object', 'additionalProperties': False, 'required': ['name', 'kind'],
            'properties': {'name': {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'},
                           'kind': {'enum': plain + ['MONEY']}, 'value': {'type': ['integer', 'boolean', 'string']},
                           'amount': {'type': 'integer', 'minimum': 0, 'maximum': MAX},
                           'unit': {'type': 'string', 'minLength': 1, 'maxLength': 128}},
            'oneOf': [{'properties': {'kind': {'const': 'MONEY'}}, 'required': ['amount', 'unit'],
                       'not': {'required': ['value']}},
                      {'properties': {'kind': {'enum': plain}}, 'required': ['value'],
                       'not': {'anyOf': [{'required': ['amount']}, {'required': ['unit']}]}}]}
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': SCHEMA_URL,
            'title': 'AAP agreement reference', 'type': 'object', 'additionalProperties': False,
            'description': 'Reference from a checkout to an Agentic Agreements Protocol (AAP) agreement and a summary of its '
                           'typed acceptance criteria. Data only: it grants no assent, payment or release authority.',
            'required': ['profile', 'application', 'agreement', 'checkout', 'price', 'remedy', 'criteria'],
            'properties': {
                'profile': {'const': PROFILE},
                'application': {'type': 'string', 'pattern': '^urn:aap:agreement-application:0\\.1:[0-9a-f]{64}$'},
                'agreement': {'type': ['string', 'null'], 'pattern': '^urn:aap:agreement:[0-9a-f]{64}$'},
                'checkout': hex64,
                'price': {'type': 'object', 'additionalProperties': False, 'required': ['amount', 'currency'],
                          'properties': {'amount': {'type': 'integer', 'minimum': 0, 'maximum': MAX},
                                         'currency': {'type': 'string', 'pattern': '^[A-Za-z]{3}$'}}},
                'remedy': {'enum': list(REMEDIES)},
                'criteria': {'type': 'object', 'additionalProperties': False, 'required': ['hash', 'items'],
                             'properties': {'hash': hex64, 'items': {'type': 'array', 'minItems': 1, 'maxItems': 32,
                                                                    'items': item}}}}}


def check_reference(value, application=None, agreement=None):
    """Validate a received aap_agreement object and, given the application, require an exact echo."""
    need(type(value) is dict and set(value) == {'profile', 'application', 'agreement', 'checkout', 'price',
                                                'remedy', 'criteria'}, 'COMMERCE_REFERENCE')
    need(value['profile'] == PROFILE, 'COMMERCE_REFERENCE')
    need(type(value['application']) is str and value['application'].startswith(APPLICATION_URN), 'COMMERCE_REFERENCE')
    _hex(value['application'][len(APPLICATION_URN):], 'COMMERCE_REFERENCE')
    need(value['agreement'] is None or type(value['agreement']) is str and value['agreement'].startswith(AGREEMENT_URN),
         'COMMERCE_REFERENCE')
    if value['agreement'] is not None:
        _hex(value['agreement'][len(AGREEMENT_URN):], 'COMMERCE_REFERENCE')
    _hex(value['checkout'], 'COMMERCE_REFERENCE')
    price = value['price']
    need(type(price) is dict and set(price) == {'amount', 'currency'}, 'COMMERCE_REFERENCE')
    _amount(price['amount']); _currency(price['currency'])
    need(value['remedy'] in REMEDIES, 'COMMERCE_REFERENCE')
    criteria = value['criteria']
    need(type(criteria) is dict and set(criteria) == {'hash', 'items'} and type(criteria['items']) is list
         and 1 <= len(criteria['items']) <= 32, 'COMMERCE_REFERENCE')
    _hex(criteria['hash'], 'COMMERCE_REFERENCE')
    rebuilt = {}
    for row in criteria['items']:
        need(type(row) is dict and type(row.get('name')) is str, 'COMMERCE_REFERENCE')
        typed = {k: v for k, v in row.items() if k != 'name'}
        try:
            application_profile.name(row['name']); application_profile.typed(typed)
        except ValueError:
            raise NativeError('COMMERCE_REFERENCE', HINTS['COMMERCE_REFERENCE']) from None
        need(row['name'] not in rebuilt, 'COMMERCE_REFERENCE')
        rebuilt[row['name']] = typed
    need(acceptance_hash(rebuilt) == criteria['hash'] and [r['name'] for r in criteria['items']] == sorted(rebuilt),
         'COMMERCE_REFERENCE')
    if application is not None:
        expected = reference(application, agreement)
        need(application_profile.canonical(expected) == application_profile.canonical(value), 'COMMERCE_REFERENCE_CHANGED')
    return {'reference': deepcopy(value), 'application': value['application'][len(APPLICATION_URN):],
            'agreement': None if value['agreement'] is None else value['agreement'][len(AGREEMENT_URN):],
            'exact_echo': application is not None, 'assent': 'NOT_ESTABLISHED_BY_A_CHECKOUT_ECHO', **FLAGS}


def echo_status(value, application=None):
    """Classify a merchant's echoed aap_agreement without refusing the surrounding evidence."""
    if value is None:
        return {'status': 'ABSENT', 'agreement': None}
    try:
        info = check_reference(value)
    except NativeError:
        return {'status': 'MALFORMED', 'agreement': None}
    if application is None:
        return {'status': 'WELL_FORMED', 'agreement': info['agreement']}
    try:
        check_reference(value, application, info['agreement'])
    except NativeError:
        return {'status': 'CHANGED', 'agreement': info['agreement']}
    return {'status': 'EXACT', 'agreement': info['agreement']}


AUTHENTICATION_METHODS = ('NONE', 'HMAC_SHA256_SHARED_SECRET', 'RFC9421_NOT_VERIFIED', 'HTTP_TLS_ONLY',
                          'RFC9421_HTTP_MESSAGE_SIGNATURE')
AUTHENTICATION_STATUS = ('NOT_AUTHENTICATED', 'VERIFIED', 'NOT_CHECKED')


def evidence(protocol, kind, agreement, data, summary, *, authentication=None):
    """A content-addressed record of exact external bytes bound to one AAP agreement or application id."""
    need(protocol in ('ACP', 'UCP', 'MPP', 'AP2'), 'COMMERCE_PROTOCOL')
    _ascii(kind, 64, 'COMMERCE_EVIDENCE_KIND'); _hex(agreement)
    need(isinstance(data, (bytes, bytearray)) and 0 < len(data) <= MAX_DOCUMENT, 'COMMERCE_DOCUMENT_SIZE')
    auth = {'method': 'NONE', 'status': 'NOT_AUTHENTICATED'} if authentication is None else deepcopy(authentication)
    need(type(auth) is dict and set(auth) <= {'method', 'status', 'detail'} and auth.get('method') in AUTHENTICATION_METHODS
         and auth.get('status') in AUTHENTICATION_STATUS, 'COMMERCE_EVIDENCE_SUMMARY')
    need(type(summary) is dict, 'COMMERCE_EVIDENCE_SUMMARY')
    try:
        need(len(application_profile.canonical(summary)) <= 32768, 'COMMERCE_EVIDENCE_SUMMARY')
        application_profile.canonical(auth)
    except NativeError:
        raise
    except ValueError:
        raise NativeError('COMMERCE_EVIDENCE_SUMMARY', HINTS['COMMERCE_EVIDENCE_SUMMARY']) from None
    record = {'version': EVIDENCE, 'protocol': protocol, 'kind': kind, 'agreement': agreement,
              'sha256': hashlib.sha256(bytes(data)).hexdigest(), 'content_digest': content_digest(data),
              'bytes': len(data), 'summary': deepcopy(summary), 'authentication': auth}
    return {'id': application_profile.content_id('AAP-COMMERCE-EVIDENCE-0.1', record), 'record': record,
            'assurance': 'EXACT_BYTES_AND_PARSED_SUMMARY; A_STATEMENT_BY_ITS_SENDER_NOT_DELIVERY_OR_PAYMENT_PROOF',
            'obligation_completed': False, **FLAGS}


def evidence_list(values):
    need(type(values) is list and len(values) <= 32 and len(set(map(str, values))) == len(values), 'COMMERCE_EVIDENCE_LIST')
    for value in values:
        _hex(value, 'COMMERCE_EVIDENCE_LIST')
    return sorted(values)


def _results(acceptance, observed):
    application_profile.typed_map(observed)
    need(set(observed) <= set(acceptance), 'COMMERCE_RECEIPT_CRITERION')
    canonical = application_profile.canonical
    results = {name: ('NOT_OBSERVED' if name not in observed else
                      'MET' if canonical(observed[name]) == canonical(acceptance[name]) else 'NOT_MET')
               for name in acceptance}
    values = set(results.values())
    verdict = 'FAILS' if 'NOT_MET' in values else 'INCOMPLETE' if 'NOT_OBSERVED' in values else 'MEETS'
    return results, verdict


def receipt_payload(application, agreement, observed, evidence_ids, at):
    """The buyer's delivery receipt body; the verdict is computed, never chosen."""
    t = terms(application); _hex(agreement)
    need(type(at) is int and 0 <= at <= MAX, 'COMMERCE_CLOCK')
    results, verdict = _results(t['acceptance'], observed)
    body = {'version': RECEIPT, 'agreement': agreement, 'application': t['application'], 'criteria': t['criteria'],
            'observed': application_profile.content_id('AAP-DELIVERY-OBSERVED-0.1', observed),
            'results': results, 'verdict': verdict, 'evidence': evidence_list(evidence_ids), 'at': at}
    return {'label': RECEIPT_LABEL, 'body': body, 'observed': deepcopy(observed), 'signer_role': 'buyer',
            'signature_created': False, **FLAGS}


def receipt_id(body):
    return application_profile.content_id('AAP-DELIVERY-RECEIPT-ID-0.1', body)


def verify_receipt(application, agreement, receipt, adoption=None):
    """Recompute the receipt, check the buyer's signature and, if supplied, the agreement's assent."""
    from covenant_chain.crypto import verify as verify_signature
    need(type(receipt) is dict and set(receipt) == {'body', 'observed', 'signature'} and type(receipt['body']) is dict,
         'COMMERCE_RECEIPT')
    body = receipt['body']
    need(set(body) == {'version', 'agreement', 'application', 'criteria', 'observed', 'results', 'verdict',
                       'evidence', 'at'}, 'COMMERCE_RECEIPT')
    expected = receipt_payload(application, agreement, receipt['observed'], body['evidence'], body['at'])
    need(application_profile.canonical(expected['body']) == application_profile.canonical(body), 'COMMERCE_RECEIPT_CHANGED')
    try:
        verify_signature(application['parties']['buyer'], RECEIPT_LABEL, body, receipt['signature'])
    except ValueError:
        raise NativeError('COMMERCE_RECEIPT_SIGNATURE', HINTS['COMMERCE_RECEIPT_SIGNATURE']) from None
    adopted = 'NOT_CHECKED'
    if adoption is not None:
        need(type(adoption) is dict and set(adoption) == {'echoes', 'approvals', 'expected_closure'}, 'COMMERCE_ADOPTION')
        application_profile.verify(application, adoption['echoes'], adoption['approvals'], agreement,
                                   adoption['expected_closure'])
        adopted = 'VERIFIED'
    verified = body['verdict'] == 'MEETS' and adopted == 'VERIFIED'
    return {'receipt': receipt_id(body), 'agreement': agreement, 'application': body['application'],
            'verdict': body['verdict'], 'results': deepcopy(body['results']), 'evidence': list(body['evidence']),
            'at': body['at'], 'signature': 'BUYER_SIGNATURE_VERIFIED', 'agreement_adoption': adopted,
            'delivery_verified': verified,
            'basis': 'BUYER_SIGNED_OBSERVATIONS_EXACTLY_MATCH_TYPED_CRITERIA' if verified else
                     'NOT_VERIFIED_DELIVERY; VERDICT_' + body['verdict'] + '_ADOPTION_' + adopted,
            'clock': 'SIGNED_ASSERTION_NOT_OBSERVED', 'world_truth': 'NOT_ESTABLISHED', **FLAGS}


class CommerceJournal:
    """Append-only local journal of evidence and signed receipts, hash-chained in SQLite (WAL, FULL sync).

    Each append runs in one IMMEDIATE transaction that extends the stored head,
    so a crash leaves the old or the new chain. Retrying a record returns its
    stored entry; ids are content hashes, so a changed record is a new id.
    Opening and audit() re-verify the whole chain; a retained head detects
    alteration or rollback, not global currentness. UPDATE, DELETE and REPLACE
    are refused by triggers.
    """
    MAX_RECORDS = 100000
    MAX_BYTES = 256 * 1024 * 1024

    def __init__(self, directory):
        from covenant_chain.workflow_store import WorkflowStore
        self.store = WorkflowStore(directory, {'journal': JOURNAL})
        db = self.store.db
        with self.store.exclusive():
            db.execute('CREATE TABLE IF NOT EXISTS commerce_journal(sequence INTEGER PRIMARY KEY, record TEXT UNIQUE NOT NULL, '
                       'kind TEXT NOT NULL, key TEXT UNIQUE, agreement TEXT, application TEXT, previous TEXT NOT NULL, '
                       'id TEXT UNIQUE NOT NULL, body BLOB NOT NULL)')
            db.execute('CREATE INDEX IF NOT EXISTS commerce_journal_agreement ON commerce_journal(agreement)')
            db.execute('CREATE INDEX IF NOT EXISTS commerce_journal_application ON commerce_journal(application)')
            for operation in ('UPDATE', 'DELETE'):
                db.execute(f"CREATE TRIGGER IF NOT EXISTS commerce_journal_no_{operation.lower()} BEFORE {operation} "
                           f"ON commerce_journal BEGIN SELECT RAISE(ABORT,'COMMERCE_JOURNAL_APPEND_ONLY'); END")
            db.execute("CREATE TRIGGER IF NOT EXISTS commerce_journal_no_replace BEFORE INSERT ON commerce_journal "
                       "WHEN EXISTS(SELECT 1 FROM commerce_journal WHERE sequence=NEW.sequence OR record=NEW.record OR id=NEW.id "
                       "OR key=NEW.key) "
                       "BEGIN SELECT RAISE(ABORT,'COMMERCE_JOURNAL_APPEND_ONLY'); END")
        self.audit()

    @staticmethod
    def _link(sequence, previous, kind, record, key, body):
        return application_profile.content_id('AAP-COMMERCE-JOURNAL-0.1', {'sequence': sequence, 'previous': previous,
                                                                         'kind': kind, 'record': record, 'key': key,
                                                                         'body': hashlib.sha256(body).hexdigest()})

    def record(self, entry, key=None):
        """Store an evidence output {id, record} or a signed receipt {body, observed, signature}, unchanged.

        key is an optional idempotency key (64 hex), such as a rail effect id: the
        same key with the same record replays; with a different record it refuses.
        """
        need(type(entry) is dict, 'COMMERCE_JOURNAL_ENTRY')
        if key is not None:
            _hex(key)
        if set(entry) == {'body', 'observed', 'signature'}:
            need(type(entry['body']) is dict and entry['body'].get('version') == RECEIPT, 'COMMERCE_JOURNAL_ENTRY')
            value, ref, kind = entry, receipt_id(entry['body']), 'RECEIPT'
            bound = (entry['body'].get('agreement'), entry['body'].get('application'))
        else:
            value = entry.get('record')
            need(type(value) is dict and value.get('version') == EVIDENCE, 'COMMERCE_JOURNAL_ENTRY')
            ref, kind = application_profile.content_id('AAP-COMMERCE-EVIDENCE-0.1', value), 'EVIDENCE'
            need(entry.get('id') == ref, 'COMMERCE_JOURNAL_ENTRY')
            bound = (value.get('agreement'), None)
        body = application_profile.canonical(value)
        db = self.store.db
        with self.store.exclusive():
            db.execute('BEGIN IMMEDIATE')
            try:
                if key is not None:
                    prior = db.execute('SELECT record,id FROM commerce_journal WHERE key=?', (key,)).fetchone()
                    need(prior is None or prior[0] == ref, 'COMMERCE_JOURNAL_KEY_REUSED')
                row = db.execute('SELECT id FROM commerce_journal WHERE record=?', (ref,)).fetchone()
                if row is not None:
                    db.execute('COMMIT')
                    return {'id': ref, 'kind': kind, 'event': row[0], 'replayed': True, **FLAGS}
                last = db.execute('SELECT sequence,id FROM commerce_journal ORDER BY sequence DESC LIMIT 1').fetchone()
                sequence, previous = (last[0] + 1, last[1]) if last else (1, '0' * 64)
                used = db.execute('SELECT coalesce(sum(length(body)),0) FROM commerce_journal').fetchone()[0]
                need(sequence <= self.MAX_RECORDS and used + len(body) <= self.MAX_BYTES, 'COMMERCE_JOURNAL_QUOTA')
                event = self._link(sequence, previous, kind, ref, key, body)
                db.execute('INSERT INTO commerce_journal VALUES (?,?,?,?,?,?,?,?,?)',
                           (sequence, ref, kind, key, bound[0], bound[1], previous, event, body))
                db.execute('COMMIT')
            except BaseException:
                db.execute('ROLLBACK'); raise
        return {'id': ref, 'kind': kind, 'event': event, 'replayed': False, **FLAGS}

    def find(self, key):
        """The record stored under an idempotency key, or None."""
        _hex(key)
        row = self.store.db.execute('SELECT record,kind,body FROM commerce_journal WHERE key=?', (key,)).fetchone()
        return None if row is None else {'id': row[0], 'kind': row[1], 'record': json.loads(row[2])}

    def entries(self, application_id=None):
        """Records bound to one agreement or application id (or all), in journal order."""
        query, arguments = 'SELECT record,kind,body FROM commerce_journal ORDER BY sequence', ()
        if application_id is not None:
            _hex(application_id)
            query = 'SELECT record,kind,body FROM commerce_journal WHERE agreement=? OR application=? ORDER BY sequence'
            arguments = (application_id, application_id)
        return [{'id': record, 'kind': kind, 'record': json.loads(body)} for record, kind, body in
                self.store.db.execute(query, arguments)]

    def audit(self, expected_head=None):
        previous, count = '0' * 64, 0
        for sequence, record, kind, key, prior, event, body in self.store.db.execute(
                'SELECT sequence,record,kind,key,previous,id,body FROM commerce_journal ORDER BY sequence'):
            try:
                value = json.loads(body)
                ref = receipt_id(value['body']) if kind == 'RECEIPT' else \
                    application_profile.content_id('AAP-COMMERCE-EVIDENCE-0.1', value)
                intact = (sequence == count + 1 and prior == previous and ref == record and
                          application_profile.canonical(value) == bytes(body) and
                          event == self._link(sequence, prior, kind, record, key, bytes(body)))
            except (KeyError, TypeError, ValueError):
                intact = False
            need(intact, 'COMMERCE_JOURNAL_CHANGED')
            previous, count = event, sequence
        if expected_head is not None:
            _hex(expected_head); need(previous == expected_head, 'COMMERCE_JOURNAL_HEAD')
        return {'version': JOURNAL, 'head': previous, 'records': count, 'chain_reverified': True,
                'currentness': 'RETAINED_HEAD_ONLY_NOT_GLOBAL', **FLAGS}

    def close(self):
        self.store.close()
