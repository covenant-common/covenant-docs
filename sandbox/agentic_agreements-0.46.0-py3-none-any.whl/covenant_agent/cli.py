"""Navigate every protocol action, and draft a covenant, from the terminal.

    covenant actions
    covenant actions --all
    covenant actions search pay when they deliver
    covenant explain settle
    covenant explain chain:BIND
    covenant next <id> --state chain.json --height 20
    covenant draft --as-of 2026-10-22 pay Alice 50 USDC when she delivers the logo by Friday
    covenant lint draft.json
    covenant simulate draft.json
    covenant counter draft.json --party Alice --set quantity=40
    covenant feedback --category bug --severity high --tool covenant_settle --text "the receipt omitted the payee"
    covenant hire --demo
    covenant forget <cid> --store ~/.covenant/private-store
"""
import argparse
import json
import os
import sys
from pathlib import Path

from .codec import loads
from .drafting import counter, draft, library, lint, simulate
from .errors import NativeError
from covenant_chain.crypto import FieldError
from .navigate import explain, find, next_actions, render_full_tree, render_tree


def _print(value):
    if type(value) is str:
        sys.stdout.write(value if value.endswith('\n') else value + '\n')
    else:
        sys.stdout.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def _load(path):
    with open(path, 'rb') as handle:
        return loads(handle.read())


def _load_draft(path):
    with open(path, 'r', encoding='utf-8') as handle:
        document = json.load(handle)
    if type(document) is not dict:
        raise NativeError('DRAFT_FIELDS')
    return document


def _changes(pairs):
    changes = {}
    for pair in pairs:
        if '=' not in pair:
            raise NativeError('DRAFT_FIELDS')
        key, value = pair.split('=', 1)
        if value.lstrip('-').isdigit():
            value = int(value)
        changes[key] = value
    return changes



class Parser(argparse.ArgumentParser):
    """Argument mistakes answer in the same JSON refusal shape as every other refusal (salvaged Cursor PR 58)."""

    def error(self, message):
        from .errors import refusal
        body = {'status': 'REFUSED', 'reason': 'ARGUMENTS',
                **refusal('ARGUMENTS', 'Run covenant actions for every action, or add --help after a command.',
                          what='The command line was not understood: ' + message),
                'remediation': message, 'next_action': 'covenant actions', 'execution_authorized': False}
        self.exit(2, json.dumps(body, sort_keys=True) + '\n')


def main(argv=None):
    incoming = list(sys.argv[1:] if argv is None else argv)
    if incoming and incoming[0] in {'pair', 'ble', 'nfc', 'gps', 'sync', 'reconcile'}:
        from covenant_chain.farm_cli import main as farm_main
        return farm_main(incoming)
    parser = Parser(prog='covenant')
    commands = parser.add_subparsers(dest='command', required=True, parser_class=Parser)
    actions = commands.add_parser('actions', help='Show the seven jobs and their verbs, or search them.')
    actions.add_argument('rest', nargs='*')
    actions.add_argument('--all', action='store_true', help='List every old name under its category.')
    explained = commands.add_parser('explain', help='Describe one action.')
    explained.add_argument('action')
    follow = commands.add_parser('next', help='List the legal next steps for a deal.')
    follow.add_argument('agreement_id')
    follow.add_argument('--state', help='Ledger state JSON whose `agreements` field holds the deal.')
    follow.add_argument('--envelope', help='The signed two-party deal as JSON.')
    follow.add_argument('--height', type=int)
    drafted = commands.add_parser('draft', help='Turn one sentence into a covenant draft.')
    drafted.add_argument('text', nargs='*')
    drafted.add_argument('--as-of', dest='as_of')
    drafted.add_argument('--template')
    drafted.add_argument('--list', action='store_true', help='List the template library.')
    checked = commands.add_parser('lint', help='Lint a draft JSON file.')
    checked.add_argument('path')
    simulated = commands.add_parser('simulate', help='Simulate delivered, late, disputed, and silent-referee outcomes.')
    simulated.add_argument('path')
    countered = commands.add_parser('counter', help='Counter a draft and print the new version.')
    countered.add_argument('path')
    countered.add_argument('--party', required=True)
    countered.add_argument('--set', dest='sets', action='append', default=[])
    noted = commands.add_parser('feedback', help='Redact a feedback report. Nothing is filed or paid.')
    noted.add_argument('--category', required=True)
    noted.add_argument('--severity', required=True)
    noted.add_argument('--tool', required=True)
    noted.add_argument('--text', required=True)
    noted.add_argument('--steps')
    noted.add_argument('--reference')
    noted.add_argument('--agent')
    noted.add_argument('--issue', action='store_true', help='Print a GitHub issue template. Nothing is filed.')
    hired = commands.add_parser('hire', help='Hire a team of agents under one budget.')
    hired.add_argument('--demo', action='store_true', help='Run the eight-agent scenario and print the report.')
    hired.add_argument('--task', default='Research the named question')
    hired.add_argument('--budget', type=int, default=800)
    hired.add_argument('--per-agent-cap', dest='per_agent_cap', type=int, default=100)
    hired.add_argument('--sentence', default='Hire eight agents for 100 credits each.')
    hired.add_argument('--as-of', dest='as_of', default='2026-10-22')
    hired.add_argument('--approval-policy', dest='approval_policy', default='NEVER_WITHIN_SCOPE',
                       choices=['ALWAYS', 'ABOVE_LIMIT', 'NEW_COUNTERPARTY', 'NEVER_WITHIN_SCOPE'],
                       help='Principal approval. NEVER_WITHIN_SCOPE is the one-call default. A recorded decline always blocks.')
    forgotten = commands.add_parser('forget', help='Delete local salts, annex keys and cached off-ledger documents for one deal. Hashes on a ledger are permanent.')
    forgotten.add_argument('cid', metavar='ID', help='ID of a stored deal version, such as sha256:<hex>, or the 64-hex deal key.')
    forgotten.add_argument('--store', help='Private store directory. Default: $COVENANT_HOME/private-store.')
    args = parser.parse_args(argv)
    try:
        if args.command == 'actions':
            if not args.rest:
                _print(render_full_tree() if args.all else render_tree())
                return 0
            if args.rest[0] != 'search' or len(args.rest) < 2:
                parser.error('use: covenant actions search <words>')
            _print(find(' '.join(args.rest[1:])))
            return 0
        if args.command == 'explain':
            _print(explain(args.action))
            return 0
        if args.command == 'draft':
            if args.list:
                _print(library())
                return 0
            if not args.text:
                parser.error('pass the sentence, or --list')
            _print(draft(' '.join(args.text), as_of=args.as_of, template=args.template))
            return 0
        if args.command == 'lint':
            _print(lint(_load_draft(args.path)))
            return 0
        if args.command == 'simulate':
            _print(simulate(_load_draft(args.path)))
            return 0
        if args.command == 'counter':
            _print(counter(_load_draft(args.path), _changes(args.sets), party=args.party))
            return 0
        if args.command == 'hire':
            from .hire import orchestrate
            _print(orchestrate(args.task, args.budget, args.per_agent_cap, args.sentence, as_of=args.as_of,
                               approval_policy=args.approval_policy))
            return 0
        if args.command == 'forget':
            from .erasure import ErasableStore, covenant_forget
            home = Path(os.environ.get('COVENANT_HOME', Path.home() / '.covenant'))
            directory = Path(args.store) if args.store else home / 'private-store'
            # Never create a store just to report that it was empty.
            store = ErasableStore(directory) if directory.exists() else None
            _print(covenant_forget(args.cid, store=store))
            return 0
        if args.command == 'feedback':
            from covenant_chain.feedback_intake import compose, issue_template, share
            made = share(compose(args.category, args.severity, args.tool, args.text, args.steps, args.reference, args.agent))
            _print(issue_template(made) if args.issue else made)
            return 0
        state = _load(args.state) if args.state else None
        envelope = _load(args.envelope) if args.envelope else None
        _print(next_actions(args.agreement_id, state=state, envelope=envelope, height=args.height))
        return 0
    except FieldError as exc:
        from .errors import refusal
        sys.stdout.write(json.dumps({'status': 'REFUSED', 'reason': exc.code, **refusal(exc.code, exc.next_action),
                                     'issues': exc.issues, 'next_action': exc.next_action}, sort_keys=True) + '\n')
        return 1
    except (NativeError, OSError, ValueError) as exc:
        code = exc.code if isinstance(exc, NativeError) else 'ARGUMENTS'
        hint = exc.remediation if isinstance(exc, NativeError) else 'Check the command arguments and try again.'
        from covenant_chain.feedback_intake import feedback_hint
        report = feedback_hint('error', code)
        from .errors import refusal
        sys.stderr.write(json.dumps({'status': 'REFUSED', 'reason': code, **refusal(code, hint), 'remediation': hint,
                                     'feedback_hint': report, 'report_this': report['report_this']}, sort_keys=True) + '\n')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
