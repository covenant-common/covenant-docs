"""SDK entry for a redacted feedback report.

Storage, when an owner inbox is configured, is the existing founder desk.
This function does not store, file, or pay.
"""
def feedback_report(category, severity, tool, text, steps=None, reference=None, agent=None):
    from covenant_chain.feedback_intake import compose, share
    return share(compose(category, severity, tool, text, steps, reference, agent))
