"""Escrow-backed channel successor preview, never a historical reducer patch.

All transitions run on a copied native 0.16 state using real native balance and
fee helpers. A reserved invalid-key vault holds actual simulated ledger units;
per-channel reservations cannot exceed it. This engine is NOT INSTALLED in the
historical reducer, is not a deployable funding request, and observes no live
payment. Steward adoption requires explicit successor consensus integration.
"""
from copy import deepcopy
import hashlib
from pathlib import Path

from . import app, economics
from .balances import amount, move
from .crypto import canonical, digest, exact, integer, key, need, verification_key, verify
from .state import check_deltas, materialize, Table

VERSION = 'covenant-escrow-channel/0.2'
OPEN_LABEL = 'AAP-ESCROW-CHANNEL-OPEN-0.2'
STATE_LABEL = 'AAP-ESCROW-CHANNEL-STATE-0.2'
TX_LABEL = 'AAP-ESCROW-CHANNEL-TRANSACTION-0.2'
VAULT = '0' * 64  # Invalid small-order Ed25519 point, not a generated account key.
MAX_CHANNELS = 64
MAX_EVENTS = 4096
MAX_WIRE = 65536
ACTIONS = ('CHANNEL_FUND', 'CHANNEL_CLOSE', 'CHANNEL_CHALLENGE', 'CHANNEL_SETTLE', 'CHANNEL_REFUND')
BOUNDARY = 'NOT_INSTALLED_IN_HISTORICAL_REDUCER'


def _terms(t):
    canonical(t)
    exact(t, 'version chain context base_checkpoint funding_head nonce left right controllers resource left_deposit right_deposit challenge_blocks funding_deadline')
    need(t['version'] == VERSION, 'CHANNEL_SUCCESSOR_VERSION')
    for field in ('chain', 'context', 'base_checkpoint', 'funding_head', 'nonce', 'left', 'right'): key(t[field])
    need(t['left'] < t['right'] and VAULT not in (t['left'], t['right']), 'CHANNEL_SUCCESSOR_PARTIES')
    exact(t['controllers'], 'left right')
    for value in t['controllers'].values(): verification_key(value)
    need(canonical(t['controllers']['left']) != canonical(t['controllers']['right']), 'CHANNEL_SUCCESSOR_DISTINCT_CONTROLLERS')
    need(type(t['resource']) is str and 0 < len(t['resource']) <= 80, 'CHANNEL_SUCCESSOR_RESOURCE')
    for field in ('left_deposit', 'right_deposit', 'funding_deadline'): integer(t[field])
    integer(t['challenge_blocks'], True)
    need(1 <= t['challenge_blocks'] <= 10000, 'CHANNEL_SUCCESSOR_WINDOW')
    total = t['left_deposit'] + t['right_deposit']
    need(0 < total <= 2**32-1, 'CHANNEL_SUCCESSOR_TOTAL')
    return total


def identifier(terms):
    _terms(terms)
    return digest('AAP-ESCROW-CHANNEL-ID-0.2', terms)


def state_payload(terms, left_balance, right_balance, sequence):
    total = _terms(terms)
    for value in (left_balance, right_balance, sequence): integer(value)
    need(left_balance + right_balance == total, 'CHANNEL_SUCCESSOR_ALLOCATION')
    need(sequence != 0 or (left_balance, right_balance) == (terms['left_deposit'], terms['right_deposit']), 'CHANNEL_SUCCESSOR_INITIAL_ALLOCATION')
    body = {'version': VERSION, 'chain': terms['chain'], 'context': terms['context'],
        'base_checkpoint': terms['base_checkpoint'], 'channel': identifier(terms), 'sequence': sequence,
        'left_balance': left_balance, 'right_balance': right_balance, 'total': total}
    return {'label': STATE_LABEL, 'body': body}


def _proofs(terms, label, body, approvals):
    need(type(approvals) is list and len(approvals) == 2, 'CHANNEL_SUCCESSOR_TWO_ASSENTS')
    roles = set()
    for approval in approvals:
        exact(approval, 'role signature'); role = approval['role']
        need(type(role) is str and role in ('left', 'right') and role not in roles, 'CHANNEL_SUCCESSOR_ASSENT_ROLE')
        verify(terms['controllers'][role], label, body, approval['signature']); roles.add(role)
    need(roles == {'left', 'right'}, 'CHANNEL_SUCCESSOR_TWO_ASSENTS')


def authenticate(terms, packet):
    exact(packet, 'state approvals')
    state = packet['state']
    exact(state, 'version chain context base_checkpoint channel sequence left_balance right_balance total')
    expected = state_payload(terms, state['left_balance'], state['right_balance'], state['sequence'])
    need(state == expected['body'], 'CHANNEL_SUCCESSOR_STATE_BINDING')
    _proofs(terms, STATE_LABEL, state, packet['approvals'])
    return state


def _state_id(engine):
    return digest('AAP-ESCROW-CHANNEL-ENGINE-0.2', {
        'version': engine['version'], 'chain': engine['chain'], 'context': engine['context'],
        'base_checkpoint': engine['base_checkpoint'], 'height': engine['height'],
        'native_state_root': app.state_hash(engine['native']), 'channels': engine['channels'],
        'unallocated_surplus': engine['unallocated_surplus'], 'receipts': engine['receipts']})


def audit(engine):
    need(engine['version'] == VERSION and engine['activation'] == BOUNDARY, 'CHANNEL_SUCCESSOR_ENGINE')
    native = engine['native']
    need(native.get('protocol') == app.MIGRATION_VERSION and native['chain'] == engine['chain'], 'CHANNEL_SUCCESSOR_NATIVE_PROFILE')
    need(app.controller(native, VAULT) == VAULT and VAULT not in native['controllers'], 'CHANNEL_SUCCESSOR_VAULT_CONTROLLER')
    need(not any(g['principal'] == VAULT for g in native['grants'].values()), 'CHANNEL_SUCCESSOR_VAULT_GRANT')
    for name in ('continuity_policies', 'recovery_policies', 'recovery_requests', 'permissions'):
        need(VAULT not in native.get(name, {}), 'CHANNEL_SUCCESSOR_VAULT_OVERRIDE')
    need(len(engine['channels']) <= MAX_CHANNELS and len(engine['receipts']) <= MAX_EVENTS, 'CHANNEL_SUCCESSOR_STATE_BOUND')
    integer(engine['height'])
    need(set(engine['unallocated_surplus']) == set(native['resources']), 'CHANNEL_SUCCESSOR_SURPLUS_RESOURCES')
    reserved = {rid: 0 for rid in native['resources']}
    for ref, row in engine['channels'].items():
        exact(row, 'terms opening initial funded held status candidate opened_at challenge_end payouts')
        exact(row['funded'], 'left right')
        t = row['terms']; total = _terms(t)
        need(ref == identifier(t) and t['chain'] == engine['chain'] and t['context'] == engine['context'] and t['base_checkpoint'] == engine['base_checkpoint'], 'CHANNEL_SUCCESSOR_CHANNEL_BINDING')
        need(t['resource'] in native['resources'], 'CHANNEL_SUCCESSOR_RESOURCE')
        _proofs(t, OPEN_LABEL, t, row['opening'])
        initial = authenticate(t, row['initial']); need(initial['sequence'] == 0, 'CHANNEL_SUCCESSOR_INITIAL')
        for role in ('left', 'right'):
            integer(row['funded'][role]); need(row['funded'][role] <= t[role + '_deposit'], 'CHANNEL_SUCCESSOR_OVERFUND')
        need(row['status'] in ('FUNDING', 'OPEN', 'CLOSING', 'SETTLED', 'REFUNDED'), 'CHANNEL_SUCCESSOR_STATUS')
        held = sum(row['funded'].values()) if row['status'] in ('FUNDING', 'OPEN', 'CLOSING') else 0
        need(row['held'] == held and held <= total, 'CHANNEL_SUCCESSOR_RESERVATION')
        if row['status'] in ('OPEN', 'CLOSING', 'SETTLED'): need(sum(row['funded'].values()) == total, 'CHANNEL_SUCCESSOR_NOT_FULLY_FUNDED')
        if row['status'] in ('FUNDING', 'OPEN'):
            need(row['candidate'] is None and row['opened_at'] is None and row['challenge_end'] is None and row['payouts'] is None, 'CHANNEL_SUCCESSOR_LIFECYCLE')
        if row['status'] == 'FUNDING': need(0 < held < total, 'CHANNEL_SUCCESSOR_PARTIAL_FUNDING')
        if row['status'] in ('CLOSING', 'SETTLED'):
            integer(row['opened_at'], True); integer(row['challenge_end'], True)
            need(row['candidate'] is not None and row['challenge_end'] == row['opened_at'] + t['challenge_blocks'] and
                 row['opened_at'] <= engine['height'], 'CHANNEL_SUCCESSOR_CLOSE_WINDOW')
            candidate = authenticate(t, row['candidate'])
            if row['status'] == 'CLOSING': need(row['payouts'] is None, 'CHANNEL_SUCCESSOR_LIFECYCLE')
            else:
                need(engine['height'] > row['challenge_end'] and row['payouts'] == {'left': candidate['left_balance'], 'right': candidate['right_balance']}, 'CHANNEL_SUCCESSOR_SETTLEMENT')
        if row['status'] == 'REFUNDED':
            need(sum(row['funded'].values()) < total and row['payouts'] == row['funded'] and engine['height'] > t['funding_deadline'] and
                 row['candidate'] is None and row['opened_at'] is None and row['challenge_end'] is None, 'CHANNEL_SUCCESSOR_REFUND')
        reserved[t['resource']] += held
    for rid in native['resources']:
        integer(engine['unallocated_surplus'].get(rid, 0))
        expected = reserved[rid] + engine['unallocated_surplus'].get(rid, 0)
        need(amount(native['balances'], VAULT, rid) == expected and amount(native['authority_available'], VAULT, rid) == expected, 'CHANNEL_SUCCESSOR_VAULT_RESERVATIONS')
    app.invariant(native)
    return {'reserved': reserved, 'unallocated_surplus': deepcopy(engine['unallocated_surplus']),
            'native_invariant': 'PASSED', 'live_payment_verified': False}


def preview(native_state, context, *, expected_native_root, height=0):
    """Explicit local simulation fork; emits no ordinary MOVE/funding transaction."""
    key(context); key(expected_native_root); integer(height)
    need(native_state.get('protocol') == app.MIGRATION_VERSION, 'CHANNEL_SUCCESSOR_NATIVE_PROFILE')
    need(app.state_hash(native_state) == expected_native_root, 'CHANNEL_SUCCESSOR_BASE_CHECKPOINT')
    native = deepcopy(native_state)
    engine = {'version': VERSION, 'activation': BOUNDARY, 'chain': native['chain'], 'context': context,
        'base_checkpoint': expected_native_root, 'height': height, 'native': native, 'channels': {},
        'unallocated_surplus': {rid: amount(native['balances'], VAULT, rid) for rid in native['resources']},
        'receipts': {}}
    audit(engine); engine['head'] = _state_id(engine)
    return engine


def prepare(engine, left, right, resource, left_deposit, right_deposit, nonce, challenge_blocks, funding_deadline):
    need(engine['head'] == _state_id(engine), 'CHANNEL_SUCCESSOR_ENGINE_HEAD'); audit(engine)
    t = {'version': VERSION, 'chain': engine['chain'], 'context': engine['context'],
        'base_checkpoint': engine['base_checkpoint'], 'funding_head': engine['head'], 'nonce': nonce,
        'left': left, 'right': right,
        'controllers': {'left': deepcopy(app.controller(engine['native'], left)), 'right': deepcopy(app.controller(engine['native'], right))},
        'resource': resource, 'left_deposit': left_deposit, 'right_deposit': right_deposit,
        'challenge_blocks': challenge_blocks, 'funding_deadline': funding_deadline}
    _terms(t); need(resource in engine['native']['resources'], 'CHANNEL_SUCCESSOR_RESOURCE')
    need(funding_deadline > engine['height'], 'CHANNEL_SUCCESSOR_FUNDING_EXPIRED')
    return {'terms': t, 'id': identifier(t), 'opening_payload': {'label': OPEN_LABEL, 'body': deepcopy(t)},
            'initial_state_payload': state_payload(t, left_deposit, right_deposit, 0),
            'activation': BOUNDARY, 'native_funding_request_emitted': False, 'execution_authorized': False}


def transaction_payload(engine, actor, action, payload, *, height, maximum_fee):
    """Successor-only authorization; historical app rejects this wire profile."""
    need(engine['head'] == _state_id(engine), 'CHANNEL_SUCCESSOR_ENGINE_HEAD')
    key(actor); integer(height, True); integer(maximum_fee)
    need(action in ACTIONS, 'CHANNEL_SUCCESSOR_ACTION')
    policy = economics.policy_at(engine['native'], height)
    body = {'v': app.MIGRATION_VERSION, 'application': VERSION, 'chain': engine['chain'], 'context': engine['context'],
        'base_checkpoint': engine['base_checkpoint'], 'engine_head': engine['head'], 'height': height,
        'actor': actor, 'controller': deepcopy(app.controller(engine['native'], actor)),
        'nonce': engine['native']['nonces'].get(actor, 0), 'action': action, 'payload': deepcopy(payload),
        'fee': {'policy': policy['id'], 'max_amount': maximum_fee, 'sponsor': None}}
    canonical(body)
    return {'label': TX_LABEL, 'body': body, 'activation': BOUNDARY, 'native_funding_request_emitted': False}


def apply(engine, transaction, *, height, expected_head):
    """Atomic deterministic transition on a copied preview, with real native fees."""
    key(expected_head); integer(height, True)
    need(engine['head'] == expected_head == _state_id(engine), 'CHANNEL_SUCCESSOR_ENGINE_HEAD'); audit(engine)
    canonical(transaction); need(len(canonical(transaction)) <= MAX_WIRE, 'CHANNEL_SUCCESSOR_WIRE_BOUND')
    exact(transaction, 'body signature'); b = transaction['body']
    exact(b, 'v application chain context base_checkpoint engine_head height actor controller nonce action payload fee')
    need(b['v'] == app.MIGRATION_VERSION and b['application'] == VERSION and b['chain'] == engine['chain'] and
         b['context'] == engine['context'] and b['base_checkpoint'] == engine['base_checkpoint'] and b['engine_head'] == expected_head, 'CHANNEL_SUCCESSOR_TRANSACTION_BINDING')
    need(b['height'] == height and height >= engine['height'], 'CHANNEL_SUCCESSOR_HEIGHT')
    key(b['actor']); integer(b['nonce']); need(b['action'] in ACTIONS and type(b['payload']) is dict, 'CHANNEL_SUCCESSOR_ACTION')
    need(b['actor'] != VAULT and b['controller'] == app.controller(engine['native'], b['actor']), 'CHANNEL_SUCCESSOR_TRANSACTION_CONTROLLER')
    verify(b['controller'], TX_LABEL, b, transaction['signature'])
    need(b['nonce'] == engine['native']['nonces'].get(b['actor'], 0), 'CHANNEL_SUCCESSOR_NONCE')
    economics.validate_fee_envelope(b['fee']); need(b['fee']['sponsor'] is None, 'CHANNEL_SUCCESSOR_SPONSOR_UNSUPPORTED')
    tid = digest('AAP-ESCROW-CHANNEL-TX-0.2', b)
    need(tid not in engine['receipts'] and len(engine['receipts']) < MAX_EVENTS, 'CHANNEL_SUCCESSOR_REPLAY_OR_EVENT_BOUND')
    out = deepcopy(engine); native = app.begin_block(out['native'], height); out['native'] = native
    chosen = economics.activate(native, height)
    need(b['controller'] == app.controller(native, b['actor']), 'CHANNEL_SUCCESSOR_DISPATCH_CONTROLLER_CHANGED')
    p = b['payload']; actor = b['actor']; action = b['action']
    if action == 'CHANNEL_FUND':
        exact(p, 'terms opening initial amount'); t = p['terms']; total = _terms(t); ref = identifier(t)
        need(t['chain'] == out['chain'] and t['context'] == out['context'] and t['base_checkpoint'] == out['base_checkpoint'], 'CHANNEL_SUCCESSOR_CHANNEL_BINDING')
        need(t['resource'] in native['resources'] and total <= native['supply'][t['resource']], 'CHANNEL_SUCCESSOR_RESOURCE')
        need(actor in (t['left'], t['right']) and height <= t['funding_deadline'], 'CHANNEL_SUCCESSOR_FUNDING_PARTY_OR_EXPIRY')
        _proofs(t, OPEN_LABEL, t, p['opening']); initial = authenticate(t, p['initial'])
        need(initial['sequence'] == 0, 'CHANNEL_SUCCESSOR_INITIAL')
        for role in ('left', 'right'):
            need(t['controllers'][role] == app.controller(native, t[role]), 'CHANNEL_SUCCESSOR_FUNDING_CONTROLLER_CHANGED')
        row = out['channels'].get(ref)
        if row is None:
            need(t['funding_head'] == engine['head'] and len(out['channels']) < MAX_CHANNELS, 'CHANNEL_SUCCESSOR_FUNDING_HEAD_OR_BOUND')
            row = {'terms': deepcopy(t), 'opening': deepcopy(p['opening']), 'initial': deepcopy(p['initial']),
                'funded': {'left': 0, 'right': 0}, 'held': 0, 'status': 'FUNDING', 'candidate': None,
                'opened_at': None, 'challenge_end': None, 'payouts': None}
            out['channels'][ref] = row
        need(row['terms'] == t and row['status'] == 'FUNDING', 'CHANNEL_SUCCESSOR_STATUS')
        role = 'left' if actor == t['left'] else 'right'; integer(p['amount'], True)
        need(row['funded'][role] + p['amount'] <= t[role + '_deposit'], 'CHANNEL_SUCCESSOR_OVERFUND')
        move(native, actor, VAULT, t['resource'], p['amount'])
        row['funded'][role] += p['amount']; row['held'] += p['amount']
        if row['held'] == total: row['status'] = 'OPEN'
    else:
        exact(p, 'channel state' if action in ('CHANNEL_CLOSE', 'CHANNEL_CHALLENGE') else 'channel')
        key(p['channel']); ref = p['channel']; need(ref in out['channels'], 'CHANNEL_SUCCESSOR_MISSING')
        row = out['channels'][ref]; t = row['terms']; need(actor in (t['left'], t['right']), 'CHANNEL_SUCCESSOR_PARTY')
        if action in ('CHANNEL_CLOSE', 'CHANNEL_CHALLENGE'):
            state = authenticate(t, p['state'])
            if action == 'CHANNEL_CLOSE':
                need(row['status'] == 'OPEN', 'CHANNEL_SUCCESSOR_STATUS')
                row['status'] = 'CLOSING'; row['opened_at'] = height
                row['challenge_end'] = height + t['challenge_blocks']; integer(row['challenge_end'])
            else:
                need(row['status'] == 'CLOSING' and height <= row['challenge_end'], 'CHANNEL_SUCCESSOR_CHALLENGE_WINDOW')
                need(state['sequence'] > row['candidate']['state']['sequence'], 'CHANNEL_SUCCESSOR_STALE_CHALLENGE')
            row['candidate'] = deepcopy(p['state'])
        elif action == 'CHANNEL_SETTLE':
            need(row['status'] == 'CLOSING' and height > row['challenge_end'], 'CHANNEL_SUCCESSOR_CHALLENGE_NOT_MATURE')
            state = authenticate(t, row['candidate'])
            payouts = {'left': state['left_balance'], 'right': state['right_balance']}
            need(sum(payouts.values()) == row['held'], 'CHANNEL_SUCCESSOR_RESERVATION')
            for role, quantity in payouts.items():
                if quantity: move(native, VAULT, t[role], t['resource'], quantity)
            row['held'] = 0; row['status'] = 'SETTLED'; row['payouts'] = payouts
        elif action == 'CHANNEL_REFUND':
            need(row['status'] == 'FUNDING' and height > t['funding_deadline'], 'CHANNEL_SUCCESSOR_REFUND_NOT_MATURE')
            for role, quantity in row['funded'].items():
                if quantity: move(native, VAULT, t[role], t['resource'], quantity)
            row['held'] = 0; row['status'] = 'REFUNDED'; row['payouts'] = deepcopy(row['funded'])
    # The maintained native fee engine debits only the authenticated actor.
    # Internal fee adapter only: this projection is never a native transaction
    # request and carries no independently valid native transaction signature.
    # The maintained fee engine prices its exact bytes and the scoped action.
    fee_view = {'body': {**deepcopy(b), 'op': action}, 'signature': transaction['signature']}
    economics.charge(native, engine['native'], fee_view, chosen, tid, height)
    native['nonces'][actor] = b['nonce'] + 1; integer(native['nonces'][actor])
    out['height'] = height
    out['receipts'][tid] = {'action': action, 'actor': actor, 'channel': ref, 'height': height,
        'fee': native['fee_receipts'][tid]['amount'], 'fee_resource': native['fee_receipts'][tid]['resource'],
        'activation': BOUNDARY, 'simulated_native_balance_transition': True, 'live_payment_verified': False}
    # New unsolicited vault credits are surplus, never new channel credit.
    reserved = {rid: sum(r['held'] for r in out['channels'].values() if r['terms']['resource'] == rid) for rid in native['resources']}
    for rid in native['resources']:
        extra = amount(native['balances'], VAULT, rid) - reserved[rid]
        need(extra >= out['unallocated_surplus'].get(rid, 0), 'CHANNEL_SUCCESSOR_SURPLUS_SPEND')
        out['unallocated_surplus'][rid] = extra
    check_deltas(native); audit(out); out['head'] = _state_id(out)
    return out


def native_carrier(native_state):
    """Explicit native Table transport; the returned root is a claim to pin."""
    need(native_state.get('protocol') == app.MIGRATION_VERSION, 'CHANNEL_SUCCESSOR_NATIVE_PROFILE')
    app.invariant(native_state)
    value = {'format': 'covenant-channel-native-input/0.1',
        'native_tables': sorted(name for name, value in native_state.items() if isinstance(value, Table)),
        'state': materialize(native_state), 'native_root': app.state_hash(native_state)}
    canonical(value)
    return value


def preview_snapshot(native_input, context, *, expected_native_root, height=0):
    """JSON-native entry; no plain-map root is silently substituted for Tables."""
    canonical(native_input); key(expected_native_root)
    exact(native_input, 'format native_tables state native_root')
    need(native_input['format'] == 'covenant-channel-native-input/0.1', 'CHANNEL_SUCCESSOR_SNAPSHOT_VERSION')
    names = native_input['native_tables']
    need(type(names) is list and len(names) <= 128 and all(type(name) is str for name in names) and names == sorted(set(names)), 'CHANNEL_SUCCESSOR_SNAPSHOT_TABLES')
    need(type(native_input['state']) is dict and native_input['native_root'] == expected_native_root, 'CHANNEL_SUCCESSOR_BASE_CHECKPOINT')
    native = deepcopy(native_input['state'])
    for name in names:
        need(name in native and type(native[name]) is dict, 'CHANNEL_SUCCESSOR_SNAPSHOT_TABLES')
        native[name] = Table(native[name])
    need(app.state_hash(native) == expected_native_root, 'CHANNEL_SUCCESSOR_BASE_CHECKPOINT')
    return snapshot(preview(native, context, expected_native_root=expected_native_root, height=height))


def snapshot(engine):
    """Explicit JSON transport for the simulated state; never a chain receipt."""
    need(engine['head'] == _state_id(engine), 'CHANNEL_SUCCESSOR_ENGINE_HEAD'); audit(engine)
    tables = sorted(name for name, value in engine['native'].items() if isinstance(value, Table))
    carrier = deepcopy(engine); carrier['native'] = materialize(engine['native'])
    value = {'format': 'covenant-channel-preview-snapshot/0.1', 'native_tables': tables, 'engine': carrier}
    canonical(value)
    return value


def restore_snapshot(carrier, *, expected_head):
    """Restore exact Table semantics only under an independently retained head."""
    canonical(carrier); key(expected_head)
    exact(carrier, 'format native_tables engine')
    need(carrier['format'] == 'covenant-channel-preview-snapshot/0.1', 'CHANNEL_SUCCESSOR_SNAPSHOT_VERSION')
    names = carrier['native_tables']
    need(type(names) is list and len(names) <= 128 and all(type(name) is str for name in names) and names == sorted(set(names)), 'CHANNEL_SUCCESSOR_SNAPSHOT_TABLES')
    out = deepcopy(carrier['engine'])
    need(type(out) is dict and type(out.get('native')) is dict, 'CHANNEL_SUCCESSOR_SNAPSHOT_ENGINE')
    for name in names:
        need(name in out['native'] and type(out['native'][name]) is dict, 'CHANNEL_SUCCESSOR_SNAPSHOT_TABLES')
        out['native'][name] = Table(out['native'][name])
    need(out['head'] == expected_head == _state_id(out), 'CHANNEL_SUCCESSOR_ENGINE_HEAD'); audit(out)
    return out


def proposal():
    body = {'version': VERSION, 'base_protocol': app.MIGRATION_VERSION,
        'proposed_protocol': 'covenant-native/0.17-channel-draft', 'activation': BOUNDARY,
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'actions': list(ACTIONS),
        'vault': VAULT, 'vault_rule': 'RESERVED_INVALID_KEY_ACCOUNT; CHANNEL_RESERVATIONS_PLUS_UNALLOCATED_SURPLUS',
        'required_adoption': ['Steward-reviewed explicit successor specification and genesis/upgrade activation.',
            'Native reducer operation dispatch, reserved-vault guards, authenticated channel tables and state-root changes.',
            'Native fee/work admission policy and independent implementation/conformance qualification.',
            'Real operators, external security review, recovery/liveness assumptions and explicit live deployment.'],
        'historical_scale_channel': 'UNMODIFIED_SIGNED_NET_ANCHOR; NOT_REINTERPRETED_AS_ESCROW',
        'deployable_funding_request': False, 'execution_authorized': False}
    return {'id': digest('AAP-ESCROW-CHANNEL-UPGRADE-PROPOSAL-0.2', body), **body}


def describe():
    return {**proposal(), 'accounting': 'REAL_BALANCE_AND_AUTHORITY_MOVES_IN_COPIED_NATIVE_016_STATE; SIMULATION_ONLY',
        'fees': 'ACTUAL_NATIVE_ECONOMICS_QUOTE_AND_CHARGE_ON_EXPLICIT_INTERNAL_FEE_VIEW; NO_FEE_WAIVER; SPONSORS_UNSUPPORTED',
        'challenge': 'HIGHER_CO_SIGNED_SEQUENCE_ONLY; FIXED_DEADLINE_NEVER_EXTENDED_BY_CHALLENGES',
        'disappearance': 'EITHER_PARTY_MAY_CLOSE_WITH_LAST_CO_SIGNED_STATE_AND_SETTLE_AFTER_WINDOW',
        'partial_funding': 'AFTER_FUNDING_DEADLINE_RETURN_ONLY_EACH_ACTUAL_FUNDER_CONTRIBUTION',
        'state_keys': 'FIXED_EXACT_SUITE_DESCRIPTORS_AT_FUNDING; CURRENT_NATIVE_CONTROLLER_RECHECKED_FOR_OUTER_TRANSACTION',
        'height_basis': 'EXPLICIT_PROPOSED_BLOCK_HEIGHT; NOT_A_HOST_CLOCK_OR_LIVE_FINALITY_OBSERVATION',
        'snapshot_transport': 'EXPLICIT_BOUNDED_JSON_CARRIER; RESTORE_REQUIRES_INDEPENDENT_EXPECTED_ENGINE_HEAD',
        'supported_state_keys': 'EXACT_ED25519_OR_ML_DSA_65; GUARDED_CONTINUITY_DESCRIPTORS_UNSUPPORTED',
        'limits': {'channels': MAX_CHANNELS, 'events': MAX_EVENTS, 'wire_bytes': MAX_WIRE, 'challenge_blocks': 10000},
        'live_payment_verified': False}
