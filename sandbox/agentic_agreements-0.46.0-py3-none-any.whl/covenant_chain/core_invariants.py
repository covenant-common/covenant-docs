"""Machine-checked limits of the ossified core.

The checks are dormant until a chain sets ``features.core_invariants`` and
the height reaches ``activation``. A chain that never sets the feature still
accepts the fee schedules it accepted before, including one that raises a
founder line. After activation, founder share cannot rise and each posted
fee coefficient stays under ``FEE_CAP``.

Supply, confiscation, and chain-id binding are properties the tests and the
freeze checklist exercise directly. They are not a second interpreter.
"""
from .crypto import integer, need
from .feature_gate import INVARIANTS, active

SUPPLY_CAP = 2**53 - 1
FEE_CAP = 10_000
FOUNDER_PURPOSES = frozenset({'founder'})


def founder_bps(policy):
    return sum(row['bps'] for row in policy['beneficiaries'] if str(row.get('purpose', '')).lower() in FOUNDER_PURPOSES)


def enforce_schedule(state, previous, proposed, height):
    """Refuse a fee schedule that raises the founder line or breaks the cap."""
    if not active(state, INVARIANTS, height):
        return
    need(founder_bps(proposed) <= founder_bps(previous), 'FOUNDER_SHARE_RISES')
    need(proposed['base_fee'] <= FEE_CAP and proposed['per_kib'] <= FEE_CAP, 'PROTOCOL_FEE_CAP')
    for amount in proposed['work_fees'].values():
        integer(amount)
        need(amount <= FEE_CAP, 'PROTOCOL_FEE_CAP')


def assert_supply(state):
    for resource, quantity in state['supply'].items():
        need(type(quantity) is int and 0 <= quantity <= SUPPLY_CAP, 'SUPPLY_CAP')
        need(type(resource) is str, 'RESOURCE')


def assert_chain_binding(body_chain, state_chain):
    need(body_chain == state_chain, 'CHAIN')


def falling_balances(before, after):
    """Accounts whose balance in some resource is lower after a transition."""
    debited = set()
    for who, balances in before.items():
        for resource, quantity in balances.items():
            if after.get(who, {}).get(resource, 0) < quantity:
                debited.add(who)
    return debited


def assert_no_confiscation(before, after, allowed):
    """Every account that lost units consented or is the fee payer named in the tx."""
    for who in falling_balances(before, after):
        need(who in allowed, 'CONFISCATION')
