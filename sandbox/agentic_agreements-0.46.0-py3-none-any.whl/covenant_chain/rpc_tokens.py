"""Per-host RPC admission tokens.

Each gateway stores only the SHA-256 of a token, plus that token's host,
scopes, rate and revocation bit. The plaintext is written once, mode 600,
into the operator file for that host. A shared token that opens every host
is not issued. Rotation revokes the old hash and returns a new plaintext.
"""
import hashlib
import json
import os
import re
import secrets
from pathlib import Path

from covenant_language.safe_io import atomic_write

from .crypto import canonical, exact, integer, need

SCOPES = ('message', 'proof', 'read', 'submit')
STORE_VERSION = 'covenant-rpc-tokens/1'
HEX64 = re.compile(r'[0-9a-f]{64}\Z')


def token_hash(token):
    need(type(token) is str and HEX64.fullmatch(token) is not None, 'RPC_TOKEN')
    return hashlib.sha256(token.encode('ascii')).hexdigest()


def _scopes(value):
    if value is None:
        return None
    need(type(value) is list and 1 <= len(value) <= len(SCOPES) and value == sorted(set(value)), 'RPC_SCOPE')
    for scope in value:
        need(scope in SCOPES, 'RPC_SCOPE')
    return list(value)


def coerce_record(value):
    """Accept the legacy identity string or a scoped record. Never a plaintext token."""
    if type(value) is str:
        need(0 < len(value) <= 80, 'GATEWAY_TOKEN_IDENTITY')
        return {'identity': value, 'host': '', 'scopes': None, 'rate': None, 'burst': None, 'revoked': False}
    exact(value, 'identity host scopes rate burst revoked')
    need(type(value['identity']) is str and 0 < len(value['identity']) <= 80, 'GATEWAY_TOKEN_IDENTITY')
    need(type(value['host']) is str and len(value['host']) <= 80, 'RPC_HOST')
    scopes = _scopes(value['scopes'])
    rate, burst = value['rate'], value['burst']
    if rate is None:
        need(burst is None, 'RPC_RATE')
    else:
        integer(rate)
        integer(burst, True)
        need(rate <= 100000 and burst <= 10000, 'RPC_RATE')
    need(type(value['revoked']) is bool, 'RPC_REVOKED')
    return {'identity': value['identity'], 'host': value['host'], 'scopes': scopes,
            'rate': rate, 'burst': burst, 'revoked': value['revoked']}


def validate_token_map(tokens):
    need(type(tokens) is dict and len(tokens) <= 512, 'GATEWAY_TOKEN_LIMIT')
    identities = set()
    for hashed, value in tokens.items():
        need(type(hashed) is str and HEX64.fullmatch(hashed) is not None, 'GATEWAY_TOKEN_HASH')
        record = coerce_record(value)
        if record['revoked']:
            continue
        need(record['identity'] not in identities, 'GATEWAY_TOKEN_IDENTITY')
        identities.add(record['identity'])
    return tokens


def index_tokens(tokens):
    """Return hash index, live identity index, and per-identity rate overrides."""
    validate_token_map(tokens)
    by_hash = {}
    by_identity = {}
    limits = {}
    for hashed, value in tokens.items():
        record = coerce_record(value)
        record['hash'] = hashed
        by_hash[hashed] = record
        if record['revoked']:
            continue
        by_identity[record['identity']] = record
        if record['rate'] is not None:
            limits[record['identity']] = (record['rate'], record['burst'])
    return by_hash, by_identity, limits


def scope_allows(scopes, method, path):
    if scopes is None:
        return True
    if method == 'GET':
        return 'read' in scopes
    if path in {'/submit', '/preview'}:
        return 'submit' in scopes
    if path in {'/proof', '/light-proof', '/light-proofs'}:
        return 'proof' in scopes
    if path in {'/message', '/feedback', '/causal'}:
        return 'message' in scopes
    return False


def _record(host, identity, scopes, rate, burst, token):
    need(type(host) is str and 0 < len(host) <= 80, 'RPC_HOST')
    scopes = _scopes(list(scopes))
    integer(rate)
    integer(burst, True)
    need(rate <= 100000 and burst <= 10000, 'RPC_RATE')
    digest = token_hash(token)
    return digest, {'id': digest, 'identity': identity, 'host': host, 'scopes': scopes,
                    'rate': rate, 'burst': burst, 'revoked': False, 'rotated_from': None}


class TokenStore:
    """Hashed records only. Plaintext exists in the return value of issue/rotate."""

    def __init__(self, records=None):
        self.records = []
        for record in records or []:
            self.records.append(self._load(record))

    @staticmethod
    def _load(record):
        exact(record, 'id identity host scopes rate burst revoked rotated_from')
        need(HEX64.fullmatch(record['id']) is not None, 'GATEWAY_TOKEN_HASH')
        coerced = coerce_record({key: record[key] for key in ('identity', 'host', 'scopes', 'rate', 'burst', 'revoked')})
        rotated = record['rotated_from']
        need(rotated is None or (type(rotated) is str and HEX64.fullmatch(rotated) is not None), 'RPC_ROTATION')
        return {**coerced, 'id': record['id'], 'rotated_from': rotated}

    def _live(self, host, identity):
        return [row for row in self.records if row['host'] == host and row['identity'] == identity and not row['revoked']]

    def issue(self, host, scopes=('message', 'proof', 'read', 'submit'), rate=2, burst=8, identity=None):
        identity = identity or f'rpc-{host}'
        need(not self._live(host, identity), 'RPC_TOKEN_EXISTS')
        token = secrets.token_hex(32)
        digest, record = _record(host, identity, scopes, rate, burst, token)
        self.records.append(record)
        return token

    def revoke(self, token_id):
        row = self._by_id(token_id)
        need(not row['revoked'], 'RPC_REVOKED')
        row['revoked'] = True
        return row

    def rotate(self, token_id):
        row = self._by_id(token_id)
        need(not row['revoked'], 'RPC_REVOKED')
        row['revoked'] = True
        token = secrets.token_hex(32)
        digest, record = _record(row['host'], row['identity'], row['scopes'], row['rate'], row['burst'], token)
        record['rotated_from'] = row['id']
        self.records.append(record)
        return token

    def _by_id(self, token_id):
        for row in self.records:
            if row['id'] == token_id:
                return row
        raise ValueError('RPC_TOKEN_MISSING')

    def public(self):
        body = {'v': STORE_VERSION, 'tokens': [{**row} for row in self.records]}
        raw = canonical(body)
        need(token_material(raw) is None, 'RPC_TOKEN_LEAK')
        return json.loads(raw)

    def gateway_map(self, host):
        """Live tokens for one host. A revoked hash is not a credential."""
        out = {}
        for row in self.records:
            if row['host'] != host or row['revoked']:
                continue
            out[row['id']] = {'identity': row['identity'], 'host': row['host'], 'scopes': list(row['scopes']),
                              'rate': row['rate'], 'burst': row['burst'], 'revoked': False}
        need(len(out) >= 1, 'RPC_TOKEN_MISSING')
        return out

    def write(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        os.chmod(directory, 0o700)
        path = directory / 'rpc-token-store.json'
        _secret(path, canonical(self.public()))
        return path


def token_material(raw):
    """Return a 64-hex bearer if one was stored by mistake. Hashes are not bearers.

    A hash is also 64 hex characters, so this only flags a value stored under a
    key the store never uses for hashes (``token`` or ``plaintext``).
    """
    text = raw.decode('ascii') if isinstance(raw, bytes) else raw
    for key in ('"token"', '"plaintext"', '"secret"'):
        if key in text:
            return key
    return None


def _secret(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(path, data, mode=0o600, exclusive=True)
    os.chmod(path, 0o600)


def issue_host_set(hosts, scopes=('message', 'proof', 'read', 'submit'), rate=2, burst=8):
    """One live token per host. Plaintexts stay in the returned dict, not the store."""
    need(type(hosts) is list and hosts == sorted(set(hosts)) and len(hosts) >= 1, 'RPC_HOST')
    store = TokenStore()
    plain = {}
    for host in hosts:
        plain[host] = store.issue(host, scopes=scopes, rate=rate, burst=burst)
    hashes = [token_hash(token) for token in plain.values()]
    need(len(set(hashes)) == len(hashes), 'RPC_TOKEN_SHARED')
    return store, plain


def write_admin_tokens(admin, store, plain):
    """Operator copies. Each host file is mode 600. The store has no plaintext."""
    admin = Path(admin)
    folder = admin / 'rpc-tokens'
    folder.mkdir(parents=True, exist_ok=True)
    os.chmod(folder, 0o700)
    for host, token in plain.items():
        _secret(folder / host, token + '\n')
    _secret(admin / 'rpc-token-store.json', canonical(store.public()))
    legacy = admin / 'rpc-token'
    need(not legacy.exists(), 'RPC_TOKEN_SHARED')


def read_host_token(admin, host):
    """Token for one host. A leftover shared file is only a fallback for old bundles."""
    path = Path(admin) / 'rpc-tokens' / host
    if path.is_file():
        token = path.read_text().strip()
        token_hash(token)
        return token
    legacy = Path(admin) / 'rpc-token'
    if legacy.is_file():
        token = legacy.read_text().strip()
        token_hash(token)
        return token
    raise ValueError('RPC_TOKEN_MISSING')
