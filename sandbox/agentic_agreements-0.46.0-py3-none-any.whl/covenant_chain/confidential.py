"""Opt-in native 0.10 confidential allocations and fee-paying notes.

Real, locally pinned Groth16 proofs; classical and single-operator sandbox.
The pool, issuer, funded total/count, fee, relay key and timing stay public.
Private openings and spending secrets must NEVER be published as evidence.
"""
import json
import os
import subprocess
from copy import deepcopy
from functools import lru_cache
from pathlib import Path
from .crypto import canonical, exact, integer, key, loads, need
from .shielded import BackendUnavailable, LEAF_CAP, field, scalar, secret, owner_id, tree, P, room_for, commit_outputs, root_accepted, seal_epoch
from .state import Table

PROFILE = 'covenant-confidential-transition/0.1'
OPERATIONS = {'CONFIDENTIAL_CLAIM', 'CONFIDENTIAL_TRANSFER'}
TABLES = ('confidential_config', 'confidential_admission', 'confidential_campaigns', 'confidential_domains', 'confidential_reserved')
WIRE_CLASS = 8192
MAX_AGE = 8


def backend_root():
    root = Path(os.environ.get('COVENANT_ZK_ROOT', Path(__file__).resolve().parents[1] / 'zk')).resolve()
    if not (root / 'confidential/bridge.mjs').is_file():
        raise BackendUnavailable('CONFIDENTIAL_BACKEND_UNAVAILABLE')
    return root


def bridge(op, **values):
    raw = canonical({'op': op, **values})
    need(len(raw) <= 1500000, 'CONFIDENTIAL_BACKEND_INPUT')
    # Same rule as the shielded pool: a slow or stuck verifier is unavailable,
    # not an invalid proof. Proving is allowed a longer local deadline.
    from .shielded import run_bridge
    return run_bridge(backend_root() / 'confidential/bridge.mjs', raw, 180 if op == 'prove' else 120,
                      'CONFIDENTIAL_BACKEND_UNAVAILABLE', 'CONFIDENTIAL_BACKEND_REJECTED', 1500000)


def descriptor():
    return bridge('descriptor')


def validate_descriptor(value):
    need(type(value) is dict and value.get('setup') in {'SINGLE_OPERATOR_SANDBOX', 'VERIFIED_MULTIPARTY'}, 'CONFIDENTIAL_PROFILE')
    fields = 'version depth public_signals vk_sha256 circuit_sha256 setup quantum_resistant'
    if value['setup'] == 'VERIFIED_MULTIPARTY':
        fields += ' ceremony'
    exact(value, fields)
    need(value['version'] == PROFILE and type(value['depth']) is int and value['depth'] == 10 and
         type(value['public_signals']) is int and value['public_signals'] == 14 and
         value['quantum_resistant'] is False, 'CONFIDENTIAL_PROFILE')
    key(value['vk_sha256']); key(value['circuit_sha256'])
    if value['setup'] == 'VERIFIED_MULTIPARTY':
        from .zk_ceremony import verify_ceremony
        verify_ceremony(value['ceremony'], profile=PROFILE, circuit_sha256=value['circuit_sha256'], vk_sha256=value['vk_sha256'])


def initialize(state, genesis):
    conf = genesis['confidential']
    need(type(conf) is dict and len(conf) <= 8, 'CONFIDENTIAL_CONFIG')
    for rid, desc in conf.items():
        need(rid in state['shielded_config'], 'CONFIDENTIAL_RESOURCE')
        validate_descriptor(desc)
    admission = genesis['confidential_admission']
    need(type(admission) is dict and set(admission) == set(conf), 'CONFIDENTIAL_ADMISSION')
    for policy in admission.values():
        exact(policy, 'funders reserved_limit')
        need(type(policy['funders']) is list and 1 <= len(policy['funders']) <= 32 and
             policy['funders'] == sorted(set(policy['funders'])), 'CONFIDENTIAL_FUNDERS')
        for funder in policy['funders']: key(funder)
        integer(policy['reserved_limit'], True)
        need(2 <= policy['reserved_limit'] <= 1024, 'CONFIDENTIAL_RESERVATION_LIMIT')
    for name in TABLES:
        state[name] = Table(conf if name == 'confidential_config' else admission if name == 'confidential_admission' else {})
    for rid in conf:
        state['confidential_reserved'][rid] = 0


def u32(value, positive=False):
    integer(value, positive); need(value < 2**32, 'CONFIDENTIAL_QUANTITY')
    return value


def grant_domain(domain):
    key(domain)
    return scalar('COVENANT-CONFIDENTIAL-GRANT-DOMAIN-0.1', domain)


def allocation_manifest(chain, pool, domain, grants):
    """PRIVATE manifest. Publish ONLY pool/domain/root/total/count.

    Hidden owners are Poseidon hashes of privately held spend secrets, rather
    than public account identities. Manual allocation is not Sybil resistance.
    """
    key(chain); key(domain)
    need(type(pool) is str and 0 < len(pool) <= 80, 'CONFIDENTIAL_POOL')
    need(type(grants) is list and 1 <= len(grants) <= 1024, 'CONFIDENTIAL_GRANTS')
    normalized = []
    for grant in grants:
        exact(grant, 'owner amount unlock salt')
        field(grant['owner']); field(grant['salt'])
        need(int(grant['salt']) < 2**248, 'CONFIDENTIAL_SALT')
        u32(grant['amount'], True); integer(grant['unlock'])
        normalized.append(deepcopy(grant))
    need(len({g['salt'] for g in normalized}) == len(normalized), 'CONFIDENTIAL_SALT_REUSE')
    total = sum(g['amount'] for g in normalized); u32(total, True)
    asset = scalar('COVENANT-SHIELDED-ASSET', pool)
    rows = [{'owner': g['owner'], 'amount': str(g['amount']), 'unlock': str(g['unlock']),
             'salt': g['salt'], 'grantDomain': grant_domain(domain), 'asset': asset} for g in normalized]
    result = bridge('allocation_tree', grants=rows)
    need(int(result['total']) == total and result['count'] == len(grants), 'CONFIDENTIAL_MANIFEST_SUM')
    need(len(set(result['leaves'])) == len(grants), 'CONFIDENTIAL_DUPLICATE_GRANT')
    openings = [{'grant': g, 'index': i, **result['paths'][i], 'leaf': result['leaves'][i]}
                for i, g in enumerate(normalized)]
    return {'chain': chain, 'pool': pool, 'domain': domain, 'root': result['root'],
            'total': total, 'count': len(grants), 'openings': openings,
            'confidentiality': 'PRIVATE_MANIFEST_PRIVATE_CLAIMS_PUBLIC_POOL'}


def fee_amount(chosen, op):
    body = chosen['body']
    from .economics import fee_cost
    return u32(fee_cost(body,op,8))


def action_id(chain, actor, op, payload, fee):
    return scalar('COVENANT-CONFIDENTIAL-ACTION-0.1', {'chain': chain, 'actor': actor, 'nonce': 0,
        'op': op, 'pool': payload['pool'], 'memo': payload['memo'],
        'campaign': payload['campaign'], 'height': payload['proof_height'], 'fee': fee})


def signals(state, op, payload, actor, fee, chosen):
    claim = op == 'CONFIDENTIAL_CLAIM'
    campaign = state['confidential_campaigns'][payload['campaign']] if claim else None
    return [payload['root'], payload['nullifier'], *payload['outputs'],
        scalar('COVENANT-SHIELDED-DOMAIN', state['chain']), scalar('COVENANT-SHIELDED-ASSET', payload['pool']),
        action_id(state['chain'], actor, op, payload, fee), str(fee_amount(chosen, op)), str(int(claim)),
        campaign['root'] if claim else '0', str(campaign['total']) if claim else '0',
        str(campaign['count']) if claim else '0', grant_domain(campaign['domain']) if claim else '0',
        str(payload['proof_height'])]


def _verify(raw):
    from .verifier import mode
    return _verify_cached(raw, mode())


@lru_cache(maxsize=128)
def _verify_cached(raw, verifier_mode):
    from .verifier import check
    return check(verifier_mode, 'confidential', json.loads(raw))


def apply(state, previous, op, payload, actor, nonce, tid, height, tx, chosen):
    if not op.startswith('CONFIDENTIAL_'):
        return None
    from .balances import add, amount
    if op == 'CONFIDENTIAL_FUND':
        exact(payload, 'pool domain root total count')
        pool = payload['pool']; key(payload['domain']); field(payload['root'])
        u32(payload['total'], True); integer(payload['count'], True)
        need(pool in state['confidential_config'] and 1 <= payload['count'] <= 1024, 'CONFIDENTIAL_POOL')
        need(chosen['body']['resource'] == pool, 'CONFIDENTIAL_FEE_RESOURCE')
        admission = state['confidential_admission'][pool]
        need(actor in admission['funders'], 'CONFIDENTIAL_FUNDING_AUTHORITY')
        need(payload['total'] >= payload['count'] * (fee_amount(chosen, 'CONFIDENTIAL_CLAIM') + 1), 'CONFIDENTIAL_MINIMUM_FUNDING')
        need(payload['domain'] not in state['confidential_domains'], 'CONFIDENTIAL_DOMAIN_REUSE')
        meta = state['shielded_pools'][pool]
        notes = meta['notes']
        reserved = state['confidential_reserved'][pool]
        need(reserved + 2 * payload['count'] <= admission['reserved_limit'], 'CONFIDENTIAL_POOL_FULL')
        slots = 2 * payload['count']
        from .governance import archive_limit, pool_rollover
        cap = archive_limit(state)
        roll = pool_rollover(state, 'deposit', height)
        if len(notes) + reserved + slots > LEAF_CAP:
            need(roll and room_for(meta, slots, reserved=reserved, kind='deposit', archive_cap=cap), 'CONFIDENTIAL_POOL_FULL')
            seal_epoch(meta, kind='deposit', archive_cap=cap)
            notes = meta['notes']
        need(len(notes) + reserved + slots <= LEAF_CAP, 'CONFIDENTIAL_POOL_FULL')
        need(amount(state['balances'], actor, pool) >= payload['total'] and
             amount(state['authority_available'], actor, pool) >= payload['total'], 'CONFIDENTIAL_BACKING')
        add(state['balances'], actor, pool, -payload['total'])
        add(state['authority_available'], actor, pool, -payload['total'])
        state['shielded_escrow'][pool] += payload['total']
        state['confidential_reserved'][pool] += 2 * payload['count']
        state['confidential_campaigns'][tid] = {**deepcopy(payload), 'issuer': actor, 'funded_at': height}
        state['confidential_domains'][payload['domain']] = tid
        return []
    need(op in OPERATIONS, 'CONFIDENTIAL_OPERATION')
    exact(payload, 'pool root nullifier outputs memo proof_height campaign proof')
    need(len(canonical(tx)) <= WIRE_CLASS, 'CONFIDENTIAL_WIRE_LIMIT')
    pool = payload['pool']; need(pool in state['confidential_config'], 'CONFIDENTIAL_POOL')
    descriptor_value = state['confidential_config'][pool]; validate_descriptor(descriptor_value)
    from .economics import validate_fee_envelope
    fee = tx['body']['fee']; validate_fee_envelope(fee)
    need(fee['sponsor'] is None and fee['policy'] == chosen['id'], 'CONFIDENTIAL_FEE_POLICY')
    need(chosen['body']['resource'] == pool, 'CONFIDENTIAL_FEE_RESOURCE')
    need(fee_amount(chosen, op) <= fee['max_amount'], 'FEE_CAP')
    need(nonce == 0 and actor not in previous['nonces'] and actor not in previous['controllers'] and
         actor not in previous['balances'], 'CONFIDENTIAL_ONE_TIME_ACTOR')
    field(payload['root']); field(payload['nullifier']); key(payload['memo'])
    integer(payload['proof_height'], True)
    from .governance import archive_limit, freshness_limit, pool_rollover
    need(0 <= height - payload['proof_height'] <= freshness_limit(state), 'CONFIDENTIAL_FRESHNESS')
    need(payload['nullifier'] != '0' and payload['nullifier'] not in state['shielded_nullifiers'], 'CONFIDENTIAL_DOUBLE_SPEND')
    need(type(payload['outputs']) is list and len(payload['outputs']) == 2, 'CONFIDENTIAL_OUTPUTS')
    meta = state['shielded_pools'][pool]; notes = meta['notes']
    for output in payload['outputs']:
        field(output); need(output != '0' and output not in notes, 'CONFIDENTIAL_OUTPUT_EXISTS')
    need(payload['outputs'][0] != payload['outputs'][1], 'CONFIDENTIAL_DUPLICATE_OUTPUT')
    if op == 'CONFIDENTIAL_CLAIM':
        key(payload['campaign']);         need(payload['campaign'] in previous['confidential_campaigns'], 'CONFIDENTIAL_CAMPAIGN')
        campaign = state['confidential_campaigns'][payload['campaign']]
        need(campaign['pool'] == pool and payload['root'] == '0', 'CONFIDENTIAL_CLAIM_CONTEXT')
        need(payload['proof_height'] >= campaign['funded_at'], 'CONFIDENTIAL_FRESHNESS')
        need(state['confidential_reserved'][pool] >= 2 and _fits(meta, 2, state, height), 'CONFIDENTIAL_POOL_FULL')
    else:
        need(payload['campaign'] is None and root_accepted(meta, payload['root']), 'CONFIDENTIAL_ROOT')
        need(_fits(meta, 2, state, height, reserved=state['confidential_reserved'][pool]), 'CONFIDENTIAL_POOL_FULL')
    need(type(payload['proof']) is dict and len(canonical(payload['proof'])) <= 6000, 'CONFIDENTIAL_PROOF_SIZE')
    _verify(canonical({'vkHash': descriptor_value['vk_sha256'],
                      'publicSignals': signals(state, op, payload, actor, fee, chosen), 'proof': payload['proof']}))
    state['shielded_nullifiers'][payload['nullifier']] = {'pool': pool, 'event': tid}
    if op == 'CONFIDENTIAL_CLAIM':
        state['confidential_reserved'][pool] -= 2
    cap = archive_limit(state)
    roll = pool_rollover(state, 'transfer', height)
    commit_outputs(meta, payload['outputs'], kind='transfer', rollover=roll, archive_cap=cap)
    return [payload['campaign']] if payload['campaign'] is not None else []


def _fits(meta, extra, state, height, reserved=0):
    from .governance import archive_limit, pool_rollover
    if not pool_rollover(state, 'transfer', height):
        return len(meta['notes']) + reserved + extra <= LEAF_CAP
    return room_for(meta, extra, reserved=reserved, kind='transfer', archive_cap=archive_limit(state))


def make_transition(state, op, actor, fee, height, outputs, *, campaign=None,
                    opening=None, input_note=None, spend_secret=None, memo='0' * 64):
    """Return PUBLIC payload, PRIVATE outputs, PRIVATE raw witness for auditing.

    Explicit actor and fee pins let callers inspect exactly what they authorize.
    Wallet callers should use confidential_sdk and keep openings encrypted.
    """
    from .economics import policy_at, validate_fee_envelope
    need(op in OPERATIONS, 'CONFIDENTIAL_OPERATION'); key(actor); key(memo)
    validate_fee_envelope(fee); chosen = policy_at(state, height)
    need(fee['policy'] == chosen['id'] and fee['sponsor'] is None, 'CONFIDENTIAL_FEE_POLICY')
    need(type(outputs) is list and len(outputs) == 2, 'CONFIDENTIAL_OUTPUTS')
    for output in outputs:
        exact(output, 'owner quantity'); field(output['owner']); u32(output['quantity'])
    claim = op == 'CONFIDENTIAL_CLAIM'
    if claim:
        key(campaign); need(campaign in state['confidential_campaigns'], 'CONFIDENTIAL_CAMPAIGN')
        pool = state['confidential_campaigns'][campaign]['pool']; g = opening['grant']
        need(owner_id(spend_secret) == g['owner'], 'CONFIDENTIAL_WALLET_OWNER')
        qty = g['amount']; blind = '0'; birth = '0'; siblings = ['0'] * 10; directions = ['0'] * 10
        grant_witness = {'grantAmount': str(g['amount']), 'grantUnlock': str(g['unlock']), 'grantSalt': g['salt'],
            'grantIndex': str(opening['index']), 'grantSiblings': opening['siblings'],
            'grantSums': opening['sums'], 'grantDirections': opening['directions']}
        root = '0'; leaf = opening['leaf']
        nf = bridge('hash', values=[spend_secret, leaf, scalar('COVENANT-SHIELDED-DOMAIN', state['chain']),
                                    grant_domain(state['confidential_campaigns'][campaign]['domain'])])
    else:
        need(input_note is not None and spend_secret is not None and campaign is None, 'CONFIDENTIAL_WITNESS')
        pool = input_note.get('pool')
        need(pool in state['confidential_config'], 'CONFIDENTIAL_POOL')
        need(owner_id(spend_secret) == input_note['owner'], 'CONFIDENTIAL_WALLET_OWNER')
        qty = input_note['quantity']; blind = input_note['blind']; birth = input_note['birth']
        domain = scalar('COVENANT-SHIELDED-DOMAIN', state['chain']); asset = scalar('COVENANT-SHIELDED-ASSET', pool)
        leaf = bridge('hash', values=[input_note['owner'], str(qty), blind, domain, asset, birth])
        need(leaf == input_note['commitment'], 'CONFIDENTIAL_WALLET_NOTE')
        notes = state['shielded_pools'][pool]['notes']; need(leaf in notes, 'CONFIDENTIAL_WALLET_MEMBERSHIP')
        path = tree(notes, notes.index(leaf)); root = path['root']; siblings = path['siblings']; directions = path['directions']
        nf = bridge('hash', values=[spend_secret, leaf, domain])
        grant_witness = {'grantAmount': '0', 'grantUnlock': '0', 'grantSalt': '0', 'grantIndex': '0',
                         'grantSiblings': ['0'] * 10, 'grantSums': ['0'] * 10, 'grantDirections': ['0'] * 10}
    need(chosen['body']['resource'] == pool, 'CONFIDENTIAL_FEE_RESOURCE')
    fee_qty = fee_amount(chosen, op); need(fee_qty <= fee['max_amount'], 'FEE_CAP')
    need(qty == sum(o['quantity'] for o in outputs) + fee_qty, 'CONFIDENTIAL_WALLET_SUM')
    p = {'pool': pool, 'root': root, 'nullifier': nf, 'outputs': [], 'memo': memo,
         'proof_height': height, 'campaign': campaign}
    act = action_id(state['chain'], actor, op, p, fee)
    domain = scalar('COVENANT-SHIELDED-DOMAIN', state['chain']); asset = scalar('COVENANT-SHIELDED-ASSET', pool)
    private_outputs = []
    for out in outputs:
        ob = secret(); commitment = bridge('hash', values=[out['owner'], str(out['quantity']), ob, domain, asset, act])
        p['outputs'].append(commitment)
        private_outputs.append({'pool': pool, **out, 'blind': ob, 'birth': act, 'commitment': commitment})
    sig = signals(state, op, p, actor, fee, chosen)
    names = 'root nullifier output0 output1 domain asset action fee claim grantRoot grantTotal grantCount grantDomain height'.split()
    witness = dict(zip(names, sig))
    witness.update(secret=field(spend_secret), inputQuantity=str(qty), inputBlind=blind, inputBirth=birth,
                   siblings=siblings, directions=directions, owners=[o['owner'] for o in private_outputs],
                   quantities=[str(o['quantity']) for o in private_outputs], blinds=[o['blind'] for o in private_outputs],
                   **grant_witness)
    p['proof'] = bridge('prove', witness=witness)['proof']
    return p, private_outputs, witness
