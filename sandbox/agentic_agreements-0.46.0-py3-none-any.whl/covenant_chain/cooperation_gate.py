"""Negotiated, certified file publication with a separate read-only recovery path.

The only effect is a bounded write-once file beneath an operator-selected root.
No bank, robot, URL, arbitrary filesystem destination or model-held credential.
"""
from copy import deepcopy
import hashlib
from pathlib import Path

from covenant_language.agentic import object_id
from covenant_language.handoff import FileOutbox
from .app import controller
from .crypto import digest, exact, key, need, sign, verify
from .cooperation import (FILE, REVIEWED_FILE, _meaning, _file_descriptor,
                          _reviewed_file_descriptor, _assess_bundle)
from .reliable import SubmissionJournal

LABEL = 'COVENANT-NEGOTIATED-FILE-GATE-0.1'


def execution_body(bundle, payload):
    need(type(payload) is bytes, 'FILE_PAYLOAD')
    m = _meaning(bundle['proposal'])
    effect = m['terms']['effect']
    content = hashlib.sha256(payload).hexdigest()
    if effect['profile'] == FILE:
        _file_descriptor(effect)
        need(content == effect['payload_hash'] and len(payload) == effect['bytes'], 'GATE_CONTENT')
    else:
        _reviewed_file_descriptor(effect)
        need(len(payload) <= effect['max_bytes'], 'GATE_CONTENT_SIZE')
    for ref in (bundle['chain'], bundle['job']):
        key(ref)
    return dict(chain=bundle['chain'], job=bundle['job'], proposal=object_id(bundle['proposal']),
                profile=effect['profile'], content=content)


def execution_approval(private_key, bundle, payload):
    """Explicit provider approval of this exact publication; never inferred."""
    return sign(private_key, LABEL, execution_body(bundle, payload))


class NegotiatedFileGate:
    def __init__(self, directory, genesis, expected_chain, policy, *, minimum_height=0):
        self.directory = Path(directory)
        self.journal = SubmissionJournal(self.directory/'trust', genesis, expected_chain,
                                         minimum_height=minimum_height)
        try:
            self.outbox = FileOutbox(self.directory/'effects')
        except BaseException:
            self.journal.close()
            raise
        self.genesis, self.chain, self.policy = deepcopy(genesis), expected_chain, policy

    def execute(self, bundle, expected_job, payload, signature, *, crash=None):
        report, verified = _assess_bundle(bundle, self.genesis, self.chain, expected_job,
                                          self.policy, journal=self.journal, stage='EXECUTE')
        need(report['ready_for_stage'], 'COOPERATION_PREREQUISITES:'+','.join(report['missing']))
        body = execution_body(bundle, payload)
        job = verified['state']['service_jobs'][expected_job]
        if body['profile'] == REVIEWED_FILE:
            need(job['decision']['evidence'] == body['content'], 'GATE_JUDGED_CONTENT')
        verify(controller(verified['state'], job['provider']), LABEL, body, signature)
        effect = digest(LABEL, body)
        self.outbox.enqueue(effect, payload)
        result = self.outbox.run(effect, crash=crash)
        return dict(effect=effect, result=result, request=body, verified_height=verified['height'],
                    assurance='LOCAL_WRITE_ONCE_FILE', receipt=self.outbox.observe(effect))

    def reconcile(self, request):
        """Observe existing bytes. This method cannot create or repair an effect."""
        exact(request, 'chain job proposal profile content')
        need(request['chain'] == self.chain and request['profile'] in {FILE, REVIEWED_FILE}, 'GATE_CONTEXT')
        for field in ('chain','job','content'):
            key(request[field])
        from covenant_language.agentic import _hash
        _hash(request['proposal'])
        return self.outbox.observe(digest(LABEL, request))

    def close(self):
        self.outbox.close()
        self.journal.close()
