"""Optional deterministic acceptance-test condition leaf with pinned runners.

Maturity: experimental. Clean-room. A leaf commits to a test digest, an image
digest (SHA-256 of the program bytes) and an inputs hash. A runner signs a
verdict over those hashes, its output hash and a grade in basis points. The leaf
pins the runner keys the parties accept and a quorum of distinct pinned runners
that must agree. A verdict from a key the leaf does not pin, or from a party,
does not count: that is the self-asserted and party-signed evidence PR 87 does
not pay (evidence_grade: an omitted floor is THIRD_PARTY_SIGNED). A wrong image,
a binding mismatch or a disagreement is UNKNOWN and names the leaf's arbiter.
Graded outcomes compare the agreed grade with the leaf's minimum.

``rerun`` recomputes the output hash offline from the same image, inputs and
program bytes; it hashes and does not execute anything. The plugin is inert
until a host puts ``plugin()`` into a ``conditions.Context(profile="covenant-conditions/0.3", plugins=...)``.
Validation of the leaf lives here so the covenant-conditions/0.1 validator keeps
its meaning: without the plugin a ``test`` leaf stays UNSUPPORTED_CONDITION.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847), where any two
self-made keys satisfied the leaf; runner pinning, the party exclusion and the
quorum are this port's correctness fix.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify

LABEL = 'COVENANT-TEST-VERDICT-0.1'
MODEL_ATTESTATION = 'MODEL_ATTESTATION'
SYSTEM = 'acceptance-verdict/1'
PROGRAM_MAX = 65536
MAX_RUNNERS = 8
MAX_VERDICTS = 8
LEAF_FIELDS = 'kind test image inputs minimum_grade_bps arbiter runners quorum verdicts'
VERDICT_FIELDS = 'kind test image inputs outputs grade_bps runner'


def program_digest(program):
    need(type(program) is bytes and 0 < len(program) <= PROGRAM_MAX, 'TEST_PROGRAM')
    return hashlib.sha256(program).hexdigest()


def rerun(image_digest, inputs_hash, program):
    """Offline cross-check: same image, inputs and program bytes give the same output hash."""
    key(image_digest)
    key(inputs_hash)
    need(program_digest(program) == image_digest, 'TEST_IMAGE')
    return hashlib.sha256(bytes.fromhex(image_digest) + bytes.fromhex(inputs_hash) + program).hexdigest()


def _grade(value):
    integer(value)
    need(value <= 10000, 'TEST_GRADE')


def verdict(signing_key, *, test_digest, image_digest, inputs_hash, outputs_hash, grade_bps):
    """A runner's signed verdict. The runner key rides in the body; the leaf decides whether it counts."""
    for ref in (test_digest, image_digest, inputs_hash, outputs_hash):
        key(ref)
    _grade(grade_bps)
    body = {'kind': MODEL_ATTESTATION, 'test': test_digest, 'image': image_digest, 'inputs': inputs_hash,
            'outputs': outputs_hash, 'grade_bps': grade_bps, 'runner': public_key(signing_key)}
    canonical(body)
    return {'body': body, 'signature': sign(signing_key, LABEL, body), 'label': LABEL, 'execution_authorized': False}


def verify_verdict(envelope, *, runners=None):
    """True for a well-formed verdict whose signature verifies; with ``runners``, only from a pinned key."""
    if type(envelope) is not dict or not {'body', 'signature'} <= set(envelope) or \
            not set(envelope) <= {'body', 'signature', 'label', 'execution_authorized'}:
        return False
    if envelope.get('label', LABEL) != LABEL or envelope.get('execution_authorized', False) is not False:
        return False
    body = envelope['body']
    try:
        exact(body, VERDICT_FIELDS)
        need(body['kind'] == MODEL_ATTESTATION, 'TEST_KIND')
        for ref in ('test', 'image', 'inputs', 'outputs', 'runner'):
            key(body[ref])
        _grade(body['grade_bps'])
        if runners is not None and body['runner'] not in runners:
            return False
        verify(body['runner'], LABEL, body, envelope['signature'])
    except (ValueError, TypeError):
        return False
    return True


def _runners(value):
    need(type(value) is list and 1 <= len(value) <= MAX_RUNNERS and all(type(v) is str for v in value) and value == sorted(set(value)), 'TEST_RUNNERS')
    for runner in value:
        try:
            need(type(runner) is str, 'TEST_RUNNERS')
            verification_key(runner)
        except ValueError:
            raise ValueError('TEST_RUNNERS') from None


def validate_leaf(expression):
    """Exact leaf fields. TEST_MALFORMED, TEST_GRADE, TEST_RUNNERS, TEST_QUORUM or TEST_VERDICTS otherwise."""
    try:
        exact(expression, LEAF_FIELDS)
        need(expression['kind'] == 'test', 'TEST_MALFORMED')
        for name in ('test', 'image', 'inputs', 'arbiter'):
            key(expression[name])
    except ValueError:
        raise ValueError('TEST_MALFORMED') from None
    _grade(expression['minimum_grade_bps'])
    _runners(expression['runners'])
    quorum = expression['quorum']
    need(type(quorum) is int and 1 <= quorum <= len(expression['runners']), 'TEST_QUORUM')
    need(type(expression['verdicts']) is list and len(expression['verdicts']) <= MAX_VERDICTS, 'TEST_VERDICTS')
    return True


def leaf(test_digest, image_digest, inputs_hash, minimum_grade_bps, arbiter, *, runners, quorum):
    """A condition leaf with the pinned runner keys and the agreeing quorum the parties chose."""
    need(type(runners) in (list, tuple, set) and all(type(item) is str for item in runners), 'TEST_RUNNERS')
    value = {'kind': 'test', 'test': test_digest, 'image': image_digest, 'inputs': inputs_hash,
             'minimum_grade_bps': minimum_grade_bps, 'arbiter': arbiter, 'runners': sorted(runners),
             'quorum': quorum, 'verdicts': []}
    validate_leaf(value)
    return value


def _escalation(arbiter, reason):
    return {'status': 'UNKNOWN', 'arbiter': arbiter, 'reason': reason, 'human_or_arbiter': True,
            'execution_authorized': False}


def _unknown(report, arbiter, reason, **facts):
    return report('UNKNOWN', reason, escalation=_escalation(arbiter, reason), **facts)


def evaluate(expression, report, *, parties=()):
    """Condition handler ``(expression, leaf_report) -> (status, meta)`` for one ``test`` leaf.

    ``parties`` are the agreement's party keys; a runner among them is not an
    independent runner. ``report`` is the conditions module's leaf recorder.
    """
    party_keys = set(parties)
    arbiter = expression.get('arbiter') if type(expression) is dict else None
    try:
        validate_leaf(expression)
    except ValueError as exc:
        return _unknown(report, arbiter if type(arbiter) is str else None, 'TEST_MALFORMED', detail=str(exc))
    verdicts = expression['verdicts']
    if not verdicts:
        return _unknown(report, arbiter, 'TEST_VERDICTS')
    pinned = set(expression['runners'])
    checked = []
    for item in verdicts:
        if not verify_verdict(item):
            return _unknown(report, arbiter, 'TEST_SIGNATURE')
        body = item['body']
        if body['runner'] not in pinned:
            return _unknown(report, arbiter, 'TEST_RUNNER_UNPINNED', runner=body['runner'])
        if body['runner'] in party_keys:
            return _unknown(report, arbiter, 'TEST_RUNNER_PARTY', runner=body['runner'])
        if body['image'] != expression['image']:
            return _unknown(report, arbiter, 'TEST_IMAGE', image=body['image'])
        if body['test'] != expression['test'] or body['inputs'] != expression['inputs']:
            return _unknown(report, arbiter, 'TEST_BINDING')
        checked.append(body)
    runners = [row['runner'] for row in checked]
    if len(set(runners)) != len(runners):
        return _unknown(report, arbiter, 'TEST_DUPLICATE_RUNNER')
    if len({row['outputs'] for row in checked}) != 1 or len({row['grade_bps'] for row in checked}) != 1:
        return _unknown(report, arbiter, 'TEST_DISAGREEMENT')
    if len(runners) < expression['quorum']:
        return report('UNKNOWN', 'TEST_QUORUM', runners=len(runners), quorum=expression['quorum'], escalation=None)
    from .evidence_grade import assurance_of
    # Pinned and not a party: the label evidence_grade gives it, at the default floor.
    assurance = assurance_of(signer=runners[0], parties=party_keys, pinned=pinned, cryptographic=False)
    grade = checked[0]['grade_bps']
    status = 'SATISFIED' if grade >= expression['minimum_grade_bps'] else 'UNSATISFIED'
    return report(status, 'TEST_GRADE', grade_bps=grade, outputs=checked[0]['outputs'], runners=len(runners),
                  assurance=assurance, world_truth='NOT_ESTABLISHED', escalation=None)


def plugin(*, parties=()):
    """The ``test`` handler a host installs: ``Context(..., profile='covenant-conditions/0.3', plugins={'test': plugin(parties=...)})``."""
    party_keys = tuple(parties)
    for party in party_keys:
        key(party)

    def handler(expression, report):
        return evaluate(expression, report, parties=party_keys)

    return handler


def register_verifier(registry, *, runners=None):
    """ProofRegistry check ``acceptance-verdict/1``. With ``runners``, only pinned runner keys verify."""
    from .proof_facility import binary
    if runners is not None:
        _runners(sorted(set(runners)))
        runners = sorted(set(runners))
    scope = ('Signature of a pinned runner over test, image, input and output hashes and a grade. Not world truth.'
             if runners is not None else
             'Signature by the runner key carried in the statement; that key is not pinned, so this is attribution only.')
    manifest = {
        'system': SYSTEM,
        'semantics': digest('COVENANT-TEST-VERDICT-VERIFIER-0.1', {'kind': MODEL_ATTESTATION, 'runners': runners}),
        'implementation': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': scope,
        'trust': 'PINNED_RUNNER_SIGNATURE' if runners is not None else 'LOCAL_SIGNATURE',
    }

    def callback(envelope):
        try:
            signature = binary(envelope['proof'], 8192).decode('ascii')
        except (ValueError, UnicodeError):
            return False
        return verify_verdict({'body': envelope['statement'], 'signature': signature},
                              runners=None if runners is None else set(runners))

    return registry.register(manifest, callback)


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Acceptance-test leaf. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    args = parser.parse_args(argv)
    print(json.dumps({'plugin': 'acceptance_test', 'enabled': bool(args.enabled), 'evidence': MODEL_ATTESTATION,
                      'runners': 'PINNED_IN_THE_LEAF', 'floor': 'THIRD_PARTY_SIGNED', 'maturity': 'experimental',
                      'execution_authorized': False}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
