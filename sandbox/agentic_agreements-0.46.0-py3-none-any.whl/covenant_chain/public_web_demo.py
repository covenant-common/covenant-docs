"""Build four synthetic, consented public pages without publishing a service.

Run with a NEW --db path, then use covenant-public-web serve on loopback.
Demo keys exist in memory for this run only; no key or private source is saved.
This is not a mainnet deployment, payment, native inclusion proof or endorsement.
"""
import argparse
from pathlib import Path
import tempfile

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .agent_network import AgentNetwork
from .crypto import canonical, digest, public_key
from .directory_network import sign_document
from .public_web import PublicWebStore, approve
from covenant_language import marketplace


def build_demo(path, origin='http://127.0.0.1:8787'):
    path = Path(path)
    if path.exists():
        raise ValueError('WEB_DEMO_REQUIRES_NEW_DATABASE')
    keys = [Ed25519PrivateKey.generate() for _ in range(4)]
    identities = [public_key(k) for k in keys]
    by_public = dict(zip(identities, keys))
    chain = digest('COVENANT-PUBLIC-WEB-DEMO', {'synthetic':True})
    owner, buyer, resolver, appeal = identities
    market = marketplace.market('Synthetic services', owner,
                                 description='Synthetic community for public service adverts.')
    listing = marketplace.listing(market['id'], owner, 'Synthetic research report',
        offer=[{'asset': marketplace.asset('service','synthetic-report','report'), 'amount':1}],
        want=[{'asset': marketplace.asset('demo','synthetic-credit','credit'), 'amount':90}],
        category='Research', custom={'client_files':'SYNTHETIC_PRIVATE_CLIENT_FILE'})['record']
    profile = sign_document(keys[0], chain, 'PROFILE', 1, {
        'subject_kind':'AGENT','identity':owner,'principal':owner,'grant':None,
        'name':'Synthetic research agent','summary':'Offers synthetic research reports.',
        'capabilities':['Research'],'skills':[],'pricing':None,'sla':None,
        'availability':'AVAILABLE','domain':'Synthetic services','a2a':None,'mcp':None,
        'portfolio':[]})
    receipt = sign_document(keys[2], chain, 'SETTLEMENT', 1, {
        'agreement':digest('DEMO-AGREEMENT',{}),'terms_hash':digest('DEMO-TERMS',{}),
        'parties':sorted([owner,buyer]),'resolver':resolver,'appeal_resolver':appeal,
        'quantity':90,'asset':'DEMO','milestone':'Synthetic witness only; no funds moved.','height':0})
    store = PublicWebStore(path, origin)
    try:
        with tempfile.TemporaryDirectory(prefix='aap-public-web-demo-') as forum_path:
            network = AgentNetwork(forum_path, chain, keys[0], identities)
            try:
                group = network.emit('GROUP','demo-group', {
                    'name':'Synthetic community','kind':'forum','charter':'Synthetic demonstration.',
                    'open_posting':True})
                # emit returns the event id plus metadata; exact source comes
                # from the validated local event map, never a whole forum dump.
                group_id = group['id']
                posted = network.emit('POST','demo-post', {
                    'thread':None,'title':'Synthetic public discussion',
                    'content':'How should a community compare public service offers?',
                    'tags':['synthetic']}, group=group_id)
                post = network.events()[posted['id']]
                records = []
                for kind,source,fields in [
                    ('marketplace',listing,['title','category','offer','want']),
                    ('profile',profile,['title','summary','subject_kind','capabilities']),
                    ('social',post,['title','text','tags']),
                    ('ledger',receipt,['title','milestone']),
                ]:
                    prepared = store.prepare(kind, source, fields, 'INDEXED')
                    approvals = [approve(by_public[actor],prepared['body']) for actor in prepared['required_signers']]
                    records.append(store.publish(kind,source,prepared['body'],approvals))
            finally:
                network.store.close()
        return {'synthetic':True,'database':str(path),'origin':store.origin,'records':records,
                'private_keys_saved':False,'private_sources_saved':False,'deployed':False,
                'native_inclusion_proved':False,'payments_executed':False}
    finally:
        store.close()


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db', required=True)
    p.add_argument('--origin', default='http://127.0.0.1:8787')
    args = p.parse_args(argv)
    print(canonical(build_demo(args.db,args.origin)).decode())


if __name__ == '__main__':
    main()
