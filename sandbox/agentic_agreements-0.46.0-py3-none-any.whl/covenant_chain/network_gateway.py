"""TLS network gateway candidate; native validator stays on literal loopback.

Peer and RPC listeners have separate admission/concurrency budgets. Admission
is an operator service policy, never transaction authority or Sybil resistance.
No built-in mainnet activation or dependency-check bypass is supplied.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import hmac
import ipaddress
import json
import logging
import re
import secrets
import signal
import time
from pathlib import Path
from urllib.parse import urlsplit

try:
    import aiohttp
    from aiohttp import web
except ImportError:
    aiohttp = None
    web = None

from . import observability
from .capabilities import verify_capability
from .crypto import canonical, need, loads, exact
from .launch_security import validate_peers, read_signing_key
from .security import require_patched_backend
from .transport import require_tls_backend, read_config, tls_context, validate_pins

MAX_REQUEST = 1024 * 1024


def match_token_hash(tokens, presented):
    """Constant-time match of a bearer hash against every adopted token hash."""
    need(type(presented) is str and len(presented) == 64, 'RPC_ADMISSION')
    matched = [name for hashed, name in tokens.items()
               if type(hashed) is str and len(hashed) == len(presented) and hmac.compare_digest(presented, hashed)]
    need(len(matched) == 1, 'RPC_ADMISSION')
    return matched[0]


MAX_RESPONSE = 4 * 1024 * 1024
POST_RPC = {'/submit', '/preview', '/proof', '/light-proof', '/light-proofs', '/feedback', '/causal'}
GET_RPC = {'/context', '/genesis', '/record', '/offers', '/blocks', '/feedback', '/feedback/dashboard'}
PROOF_RPC = {'/proof', '/light-proof', '/light-proofs'}
TOKEN_SCOPES = ('proof', 'read', 'submit')
# Admission credentials only. They are not a consensus operation and they are not genesis data.
DEFAULT_RATE, DEFAULT_BURST = 16, 32
DEFAULT_WORK_RATE, DEFAULT_WORK_BURST = 2, 8
# Advertised admission price in credits. The gateway does not collect it.
DEFAULT_PRICE = 1
_TOKEN_FIELDS = ('identity', 'scopes', 'rate', 'burst', 'work_rate', 'work_burst')


def token_hash(token):
    need(type(token) is str and re.fullmatch(r'[0-9a-f]{64}', token) is not None, 'GATEWAY_TOKEN')
    return hashlib.sha256(token.encode('ascii')).hexdigest()


def token_record(identity, scopes=('proof', 'read', 'submit'), rate=DEFAULT_RATE, burst=DEFAULT_BURST,
                 work_rate=DEFAULT_WORK_RATE, work_burst=DEFAULT_WORK_BURST, price=DEFAULT_PRICE):
    """One host or admin credential. A string identity in an old config is this record with the defaults."""
    scopes = list(scopes)
    need(type(identity) is str and 0 < len(identity) <= 80, 'GATEWAY_TOKEN_IDENTITY')
    need(bool(scopes) and scopes == sorted(set(scopes)) and set(scopes) <= set(TOKEN_SCOPES), 'GATEWAY_SCOPE')
    for value in (rate, burst, work_rate, work_burst):
        need(type(value) is int and 0 <= value <= 1000, 'GATEWAY_TOKEN_RATE')
    need(type(price) is int and 0 <= price <= 2**53 - 1, 'GATEWAY_PRICE')
    return {'identity': identity, 'scopes': scopes, 'rate': rate, 'burst': burst,
            'work_rate': work_rate, 'work_burst': work_burst, 'price': price}


def admission_quote(record=None):
    """Rate limit and price an agent can read before it sends. Nothing is charged here."""
    if record is None:
        record = token_record('gateway')
    elif type(record) is str or 'price' not in record:
        record = normalize_token(record)
    return {'rate': record['rate'], 'burst': record['burst'], 'work_rate': record['work_rate'],
            'work_burst': record['work_burst'], 'price': record['price'], 'unit': 'credits',
            'charged_by_gateway': False}


def normalize_token(value):
    if type(value) is str:
        return token_record(value)
    need(type(value) is dict, 'FIELDS')
    need(set(value) <= set(_TOKEN_FIELDS) | {'price'}, 'FIELDS')
    core = {name: value[name] for name in _TOKEN_FIELDS}
    exact(core, 'identity scopes rate burst work_rate work_burst')
    return token_record(value['identity'], value['scopes'], value['rate'], value['burst'],
                        value['work_rate'], value['work_burst'], value.get('price', DEFAULT_PRICE))


def issue_token(identity, **policy):
    """Mint a bearer. The secret stays with the operator; only its hash is configured."""
    raw = secrets.token_hex(32)
    record = token_record(identity, **policy)
    return {'token': raw, 'hash': token_hash(raw), 'record': record}


def rotate_token(tokens, previous_hash, identity, **policy):
    """Replace one hash. Returns a new map and the new secret. Does not write genesis."""
    need(type(tokens) is dict and previous_hash in tokens, 'GATEWAY_TOKEN_HASH')
    issued = issue_token(identity, **policy)
    updated = {hashed: value for hashed, value in tokens.items() if hashed != previous_hash}
    updated[issued['hash']] = issued['record']
    return updated, issued


def scope_allows(scopes, method, path):
    if method == 'GET':
        return 'read' in scopes and (path in GET_RPC or re.fullmatch(r'/tx/[0-9a-f]{64}', path) is not None)
    if method == 'POST' and path in PROOF_RPC:
        return 'proof' in scopes
    return method == 'POST' and path in POST_RPC and 'submit' in scopes


def gateway_backend_status():
    if aiohttp is None:
        raise ValueError('AIOHTTP_REQUIRED')
    match = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)', aiohttp.__version__)
    parts = tuple(map(int, match.groups())) if match else ()
    return {'aiohttp': aiohttp.__version__, 'acceptable': (3, 14, 4) <= parts < (3, 15, 0),
            'reviewed_family': '>=3.14.4,<3.15'}


def require_gateway_backend():
    need(gateway_backend_status()['acceptable'], 'UNAPPROVED_GATEWAY_BACKEND')
    require_patched_backend()
    require_tls_backend()


def validate_gateway(config):
    exact(config, 'backend peer rpc')
    validate_peers({'backend': config['backend']})
    need(urlsplit(config['backend']).hostname == '127.0.0.1', 'GATEWAY_BACKEND_IPV4_LOOPBACK')
    for kind in ('peer', 'rpc'):
        value = config[kind]
        exact(value, 'host port tls_config' + (' tokens' if kind == 'rpc' else ''))
        try:ipaddress.ip_address(value['host'])
        except (ValueError, TypeError) as exc:raise ValueError('GATEWAY_BIND_IP') from exc
        need(type(value['port']) is int and 1 <= value['port'] <= 65535, 'GATEWAY_PORT')
        need(type(value['tls_config']) is str and Path(value['tls_config']).is_absolute(), 'GATEWAY_CONFIG_PATH')
    need((config['peer']['host'], config['peer']['port']) != (config['rpc']['host'], config['rpc']['port']), 'GATEWAY_LISTENER_COLLISION')
    tokens = config['rpc']['tokens']
    need(type(tokens) is dict and len(tokens) <= 512, 'GATEWAY_TOKEN_LIMIT')
    identities = set()
    for hashed, value in tokens.items():
        need(type(hashed) is str and re.fullmatch('[0-9a-f]{64}', hashed) is not None, 'GATEWAY_TOKEN_HASH')
        identity = normalize_token(value)['identity']
        need(identity not in identities, 'GATEWAY_TOKEN_IDENTITY')
        # A 64-hex identity is a chain key, not an admission label.
        need(re.fullmatch('[0-9a-f]{64}', identity) is None, 'GATEWAY_TOKEN_NOT_CHAIN_KEY')
        identities.add(identity)
    return config


class Budget:
    """Fixed membership and one anonymous class; no unbounded per-IP/key map.

    ``limits`` optionally sets a rate and burst per identity. Identities omitted
    from it keep the shared rate and burst. Membership stays closed.
    """
    def __init__(self, identities, *, concurrent, per_identity, rate, burst, limits=None):
        self.allowed = set(identities)
        self.count = 0
        self.counts = {key: 0 for key in identities}
        self.limits = {}
        for key in identities:
            spec = (limits or {}).get(key, {})
            if type(spec) is tuple and len(spec) == 2:
                self.limits[key] = spec
            else:
                self.limits[key] = (spec.get('rate', rate), spec.get('burst', burst))
        self.tokens = {key: float(self.limits[key][1]) for key in identities}
        self.updated = {key: time.monotonic() for key in identities}
        self.concurrent, self.per_identity = concurrent, per_identity
        self.rate, self.burst = rate, burst

    def acquire(self, identity):
        if identity not in self.allowed:return False
        now = time.monotonic()
        rate, burst = self.limits[identity]
        self.tokens[identity] = min(burst, self.tokens[identity] + max(0, now - self.updated[identity]) * rate)
        self.updated[identity] = now
        if self.count >= self.concurrent or self.counts[identity] >= self.per_identity or self.tokens[identity] < 1:
            return False
        self.tokens[identity] -= 1
        self.count += 1;self.counts[identity] += 1
        return True

    def release(self, identity):
        self.count -= 1;self.counts[identity] -= 1


class CappedServer(web.Server if web is not None else object):
    """Bound HTTP connections after TLS; close every connection within 70s.

    A Groth16 check can outlast a few seconds. The connection cap, not a
    short clock, bounds a slow handshake. Kernel queues and TLS floods still
    need external protection. No secret-bearing HTTP/access log is enabled.
    Listener budgets are separate.
    """
    def __init__(self, handler, limit):
        self.limit = limit
        parser_log=logging.getLogger('covenant.gateway.parser')
        if not parser_log.handlers:parser_log.addHandler(logging.NullHandler())
        parser_log.propagate=False
        super().__init__(handler, handler_cancellation=True, access_log=None,logger=parser_log,
                         keepalive_timeout=1, max_line_size=4096, max_field_size=4096,
                         max_headers=32, read_bufsize=16384, auto_decompress=False,
                         lingering_time=0)

    def connection_made(self, handler, transport):
        if len(self.connections) >= self.limit:
            transport.close()
            return
        super().connection_made(handler, transport)
        asyncio.get_running_loop().call_later(70, transport.close)


LEGAL_CONTEXT_PATH = '/.well-known/legal-context.json'


class Gateway:
    def __init__(self, config, peer_config, rpc_config, descriptor=None, descriptor_now=None, legal_context=None):
        validate_gateway(config)
        if peer_config is not None:validate_pins(peer_config['pins'])
        self.config, self.peer_config, self.rpc_config = config, peer_config, rpc_config
        # Optional LCP discovery bytes (experimental, lcp_emit). Served only when the
        # owner assigns them, through the same anonymous well-known branch below.
        self.legal_context_bytes = None
        if legal_context is not None:
            from .lcp_emit import check_discovery
            self.legal_context_bytes = check_discovery(legal_context)
        if descriptor is None:
            need(descriptor_now is None, 'GATEWAY_DESCRIPTOR_TIME')
            self.descriptor_bytes = None
        else:
            need(type(descriptor_now) is int, 'GATEWAY_DESCRIPTOR_TIME')
            verify_capability(descriptor, descriptor_now)
            self.descriptor_bytes = canonical(descriptor)
        self.pin_identity = {pin: member for member, pins in (peer_config['pins'] if peer_config else {}).items() for pin in pins}
        self.peer_budget = Budget(peer_config['pins'] if peer_config else [], concurrent=8, per_identity=2, rate=35, burst=70)
        self._bind_tokens(config['rpc']['tokens'])
        self.runners = []
        self.session = None
        self.forwarded = {'peer': 0, 'rpc': 0}
        self.rejected = {'peer': 0, 'rpc': 0}
        self.upstream_failures = 0
        self._observe()

    def _observe(self):
        routes = GET_RPC | POST_RPC | {'/message', '/tx/*', '/.well-known/covenant'}
        self.ops = observability.Ops('gateway', routes=routes)
        self.ops.health.add('listeners', lambda: bool(self.runners) or 'GATEWAY_NOT_LISTENING')
        self.ops.health.add('backend_library', lambda: gateway_backend_status()['acceptable'] or 'UNAPPROVED_GATEWAY_BACKEND')
        # Passive: three consecutive upstream failures; a probe never opens a backend connection itself.
        self.ops.health.add('upstream', lambda: self.upstream_failures < 3 or 'GATEWAY_UPSTREAM_UNAVAILABLE')
        self.ops.queue('peer_in_flight', lambda: self.peer_budget.count)
        self.ops.queue('rpc_in_flight', lambda: self.rpc_budget.count)
        self.ops.queue('rpc_work_in_flight', lambda: self.rpc_work.count)
        self.ops.metrics.counter('aap_gateway_forwarded_total', 'Requests forwarded to the validator backend.',
                                 ('listener',), fn=lambda: {(kind,): count for kind, count in self.forwarded.items()})
        self.ops.metrics.counter('aap_gateway_rejected_total', 'Requests refused before or at the backend.',
                                 ('listener',), fn=lambda: {(kind,): count for kind, count in self.rejected.items()})

    def _bind_tokens(self, tokens):
        records = {hashed: normalize_token(value) for hashed, value in tokens.items()}
        identities = [record['identity'] for record in records.values()]
        self.rpc_tokens = {hashed: record['identity'] for hashed, record in records.items()}
        self.rpc_scopes = {record['identity']: record['scopes'] for record in records.values()}
        self.rpc_prices = {record['identity']: record['price'] for record in records.values()}
        self.rpc_prices['anonymous'] = DEFAULT_PRICE
        self.rpc_quotes = {record['identity']: admission_quote(record) for record in records.values()}
        self.rpc_budget = Budget(['anonymous', *identities], concurrent=4, per_identity=1, rate=DEFAULT_RATE, burst=DEFAULT_BURST,
                                 limits={record['identity']: {'rate': record['rate'], 'burst': record['burst']} for record in records.values()})
        self.rpc_work = Budget(identities, concurrent=4, per_identity=1, rate=DEFAULT_WORK_RATE, burst=DEFAULT_WORK_BURST,
                               limits={record['identity']: {'rate': record['work_rate'], 'burst': record['work_burst']} for record in records.values()})

    def replace_rpc_tokens(self, tokens):
        """Operator rotation of the admission map. Not a transaction and not safe to call mid-request."""
        copied = {hashed: value for hashed, value in tokens.items()}
        probe = {'backend': self.config['backend'], 'peer': self.config['peer'], 'rpc': {**self.config['rpc'], 'tokens': copied}}
        validate_gateway(probe)
        self.config['rpc']['tokens'] = copied
        self._bind_tokens(copied)

    def _limited(self, error, identity, kind):
        quote = admission_quote()
        if kind == 'rpc' and identity in self.rpc_quotes:
            quote = self.rpc_quotes[identity]
        return {'error': error, **quote}

    def identity(self, request, kind):
        if kind == 'peer':
            ssl_object = request.transport.get_extra_info('ssl_object')
            need(ssl_object is not None, 'PEER_TLS_REQUIRED')
            raw = ssl_object.getpeercert(binary_form=True)
            need(bool(raw), 'PEER_CERT_REQUIRED')
            member = self.pin_identity.get(hashlib.sha256(raw).hexdigest())
            need(member is not None, 'PEER_CERT_NOT_ADOPTED')
            hints = request.headers.getall('X-Covenant-Peer', [])
            need(len(hints) == 1 and hmac.compare_digest(member, hints[0]), 'PEER_HEADER_BINDING')
            return member
        auth = request.headers.getall('Authorization', [])
        if not auth:return 'anonymous'
        need(len(auth) == 1 and re.fullmatch(r'Bearer [0-9a-f]{64}', auth[0]) is not None, 'RPC_ADMISSION')
        presented = hashlib.sha256(auth[0][7:].encode('ascii')).hexdigest()
        return match_token_hash(self.rpc_tokens, presented)

    async def handle(self, request, kind):
        """Probes, then the admission path; every reply is counted with its stable code."""
        started = time.monotonic()
        path = request.raw_path.partition('?')[0]
        probe = self.ops.probe(request.method, path)
        if probe is not None:
            status, content_type, body = probe
            reply = web.Response(body=body, status=status, content_type=content_type,
                                 headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})
        else:
            reply = await self._admit(request, kind)
        self.ops.observe_reply(request.method, path, reply.status, time.monotonic() - started, reply.body)
        return reply

    async def _admit(self, request, kind):
        budget = self.peer_budget if kind == 'peer' else self.rpc_budget
        identity = None;acquired = False;work_acquired = False
        try:
            identity = self.identity(request, kind)
            raw_path = request.raw_path
            need(len(raw_path) <= 2048 and raw_path.startswith('/') and not raw_path.startswith('//') and
                 '%' not in raw_path.partition('?')[0] and all(33 <= ord(c) <= 126 for c in raw_path) and
                 '\\' not in raw_path and '#' not in raw_path, 'GATEWAY_TARGET')
            path = raw_path.partition('?')[0]
            legal = path == LEGAL_CONTEXT_PATH and self.legal_context_bytes is not None
            if kind == 'rpc' and request.method == 'GET' and (path == '/.well-known/covenant' or legal) and '?' not in raw_path:
                need(not request.headers.getall('Content-Encoding', []) and not request.headers.getall('Transfer-Encoding', []), 'GATEWAY_ENCODING')
                lengths = request.headers.getall('Content-Length', [])
                need(len(lengths) <= 1, 'GATEWAY_FRAMING')
                need(not request.can_read_body and (not lengths or lengths == ['0']), 'GATEWAY_GET_BODY')
                acquired = budget.acquire(identity)
                if not acquired:
                    self.rejected[kind] += 1
                    return web.json_response(self._limited('GATEWAY_ADMISSION_LIMIT', identity, kind), status=429, headers={'Retry-After': '1'})
                headers = {'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}
                if legal:
                    return web.Response(body=self.legal_context_bytes, status=200, content_type='application/json', headers=headers)
                if self.descriptor_bytes is None:
                    return web.json_response({'error': 'CAPABILITY_UNPUBLISHED'}, status=404, headers=headers)
                return web.Response(body=self.descriptor_bytes, status=200, content_type='application/json', headers=headers)
            if kind == 'peer':
                allowed = (request.method == 'POST' and path in {'/message', '/submit'} and '?' not in raw_path) or (request.method == 'GET' and path == '/blocks')
            else:
                allowed = (request.method == 'GET' and (path in GET_RPC or re.fullmatch('/tx/[0-9a-f]{64}', path))) or (request.method == 'POST' and path in POST_RPC and '?' not in raw_path)
                if identity == 'anonymous':
                    allowed = request.method == 'GET' and path in {'/context', '/genesis'} and '?' not in raw_path
                elif allowed:
                    allowed = scope_allows(self.rpc_scopes[identity], request.method, path)
            need(bool(allowed), 'GATEWAY_ROUTE_DENIED')
            # Reject compression/framing before reading attacker-controlled bytes.
            need(not request.headers.getall('Content-Encoding', []) and not request.headers.getall('Transfer-Encoding', []), 'GATEWAY_ENCODING')
            lengths = request.headers.getall('Content-Length', [])
            need(len(lengths) <= 1, 'GATEWAY_FRAMING')
            if request.method == 'POST':
                need(len(lengths) == 1 and re.fullmatch('[0-9]{1,8}', lengths[0]) is not None, 'GATEWAY_FRAMING')
                size = int(lengths[0]);need(0 < size <= MAX_REQUEST, 'GATEWAY_BODY_SIZE')
                need(request.headers.get('Content-Type', '').lower() == 'application/json', 'GATEWAY_CONTENT_TYPE')
            else:
                size = 0
                need(not request.can_read_body and (not lengths or lengths == ['0']), 'GATEWAY_GET_BODY')
            acquired = budget.acquire(identity)
            if not acquired:
                self.rejected[kind] += 1
                return web.json_response(self._limited('GATEWAY_ADMISSION_LIMIT', identity, kind), status=429, headers={'Retry-After': '1'})
            if kind == 'rpc' and request.method == 'POST':
                work_acquired=self.rpc_work.acquire(identity)
                if not work_acquired:
                    self.rejected[kind] += 1
                    return web.json_response(self._limited('GATEWAY_WORK_RATE_LIMIT', identity, kind), status=429, headers={'Retry-After': '1'})
            # Cheap reads stay on a short deadline. Proof submission and peer
            # gossip can outlast a Groth16 check; a short clock must not turn a
            # completed accept into a client-visible failure.
            slow = request.method == 'POST' and path in {'/submit', '/preview', '/message'}
            deadline = 60 if slow else 2.5
            # The body itself stays on a short clock so a drip cannot hold a
            # slot. Only a complete proof submission gets the long deadline.
            async with asyncio.timeout(2.5):
                body = bytearray()
                while len(body) < size:
                    chunk = await request.content.read(min(16384, size - len(body)))
                    need(bool(chunk), 'GATEWAY_TRUNCATED_BODY')
                    body.extend(chunk)
            headers = {'Content-Type': 'application/json'}
            if kind == 'peer':headers['X-Covenant-Peer'] = identity
            async with asyncio.timeout(deadline):
                async with self.session.request(request.method, self.config['backend'] + raw_path,
                                                data=bytes(body) if size else None, headers=headers,
                                                allow_redirects=False,
                                                timeout=aiohttp.ClientTimeout(total=deadline)) as reply:
                    need(200 <= reply.status < 300 or 400 <= reply.status < 500, 'GATEWAY_BACKEND_RESPONSE')
                    need(not reply.headers.get('Content-Encoding'), 'GATEWAY_BACKEND_ENCODING')
                    result = bytearray()
                    async for chunk in reply.content.iter_chunked(16384):
                        need(len(result) + len(chunk) <= MAX_RESPONSE, 'GATEWAY_REPLY_SIZE')
                        result.extend(chunk)
                    self.forwarded[kind] += 1
                    self.upstream_failures = 0
                    return web.Response(body=bytes(result), status=reply.status, content_type='application/json',
                                        headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})
        except (ValueError, KeyError, TypeError) as exc:
            self.rejected[kind] += 1
            return web.json_response({'error': str(exc)[:160]}, status=403)
        except (TimeoutError, aiohttp.ClientError, OSError):
            self.rejected[kind] += 1
            self.upstream_failures += 1
            return web.json_response({'error': 'GATEWAY_UPSTREAM_OR_DEADLINE'}, status=503)
        finally:
            if work_acquired:self.rpc_work.release(identity)
            if acquired:budget.release(identity)

    async def start(self, listeners=('peer','rpc')):
        need(type(listeners) is tuple and listeners and all(k in {'peer','rpc'} for k in listeners) and len(set(listeners))==len(listeners),'GATEWAY_LISTENERS')
        self.session = aiohttp.ClientSession(trust_env=False, auto_decompress=False,
                            cookie_jar=aiohttp.DummyCookieJar(), timeout=aiohttp.ClientTimeout(total=60),
                            connector=aiohttp.TCPConnector(limit=12, force_close=True))
        try:
            for kind, tls_config, cap in (('peer', self.peer_config, 48), ('rpc', self.rpc_config, 16)):
                if kind not in listeners:continue
                need(tls_config is not None,'GATEWAY_TLS_CONFIG_REQUIRED')
                async def handle(request, k=kind):return await self.handle(request, k)
                runner = web.ServerRunner(CappedServer(handle, cap), shutdown_timeout=3)
                await runner.setup();self.runners.append(runner)
                settings = self.config[kind]
                site = web.TCPSite(runner, settings['host'], settings['port'],
                        ssl_context=tls_context(tls_config, server=True, mutual=kind == 'peer'), backlog=32)
                await site.start()
        except BaseException:
            await self.close()
            raise

    async def close(self):
        for runner in self.runners:await runner.cleanup()
        self.runners.clear()
        if self.session is not None:await self.session.close()


async def serve(config,listener,options=None):
    require_gateway_backend()
    gate = Gateway(config, read_config(config['peer']['tls_config']) if listener=='peer' else None,
                   read_config(config['rpc']['tls_config']) if listener=='rpc' else None)
    stopping = asyncio.Event()
    loop = asyncio.get_running_loop()
    for signum in (signal.SIGINT, signal.SIGTERM):loop.add_signal_handler(signum, stopping.set)
    await gate.start((listener,))
    observability.start(gate.ops, options)
    print(json.dumps({'gateway_started': True, 'transport_candidate': True, 'public_mainnet_qualified': False,
                      'admission': admission_quote()}), flush=True)
    try:await stopping.wait()
    finally:
        await gate.close()
        gate.ops.close()


def arguments():
    """The gateway's command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--listener',required=True,choices=['peer','rpc'],help='run in separate peer/RPC processes and resource groups')
    observability.add_arguments(parser)
    return parser


def main():
    args = arguments().parse_args()
    from .operator_surface import announce_console_path
    announce_console_path()
    # Admission token hashes are not bearer credentials; file parents are trusted.
    config = loads(read_signing_key(args.config))
    validate_gateway(config)
    asyncio.run(serve(config,args.listener,args))


if __name__ == '__main__':main()
