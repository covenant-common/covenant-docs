"""Copy number: count the AAP references actually present in documents you supply.

Assembly theory reads an object by two numbers: how hard it is to build and how
many copies exist. AAP's copies outside this repository start at about one.
This tool measures copies the only honest way available offline: it reads
local files you hand it (captured carriers: x402 and MPP headers, A2A and MCP
messages, checkouts, registration files, legal-context.json, RSL, zone files,
JSON-LD, OASF records) and counts the references that sit in each protocol's
designated field, using the same readers as ``embedding_points``.

It reports the measures named in docs/ZERO_TO_ONE.html: protocols carrying the
field, independent hosts, and agreements per day. Hosts are names seen in the
carriers or given in the manifest; their independence is not verified. A day
comes from the manifest or from a date the carrier itself states; anything else
is ``undated``. A reference found outside a designated field is reported as
unattributed and is not a placement. Unknown never becomes counted.

Local files only: nothing is fetched, resolved, signed or sent.
"""
import argparse
import json
import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

from . import aap_reference, embedding_points, interop_codec
from .aap_reference import FLAGS
from .crypto import need

VERSION = 'urn:aap:copy-number:0.1'
MATURITY = 'experimental'
MAX_FILES = 10000
MAX_FILE = 1048576
MAX_TOTAL = 64 * 1048576
MAX_MANIFEST = 1048576
DAY = re.compile(r'\d{4}-\d{2}-\d{2}\Z')
HOST = re.compile(r'[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?\Z')
HEADER = re.compile(r'([A-Za-z0-9-]{1,64}):[ \t]*(.*)\Z')
JSON_ORDER = ('ap2', 'x402', 'mpp', 'erc-8004', 'erc-8183', 'oasf', 'lcp', 'schema-org', 'ucp', 'acp', 'mcp', 'a2a')
LOOSE = re.compile(r'urn:aap:ref:0\.1:b[a-z2-7]{58}[A-Za-z0-9._~%:@/!$&()*+=;-]*')

ADVICE = {
    'COPY_INPUT': 'Pass local file or directory paths, or documents as {name, raw bytes} with optional protocol, host and observed day.',
    'COPY_LIMIT': 'Split the corpus: at most 10000 files of 1 MiB each and 64 MiB in total per run.',
    'COPY_MANIFEST': 'Use a JSON Lines manifest of {"path", "protocol"?, "host"?, "observed"?: "YYYY-MM-DD"} within 1 MiB.',
    'COPY_PROTOCOL': 'Name a protocol listed by embedding_points.placements(), or omit it to let the reader recognise the carrier.',
    'COPY_HOST': 'Give a host as a lower-case DNS name.',
    'COPY_DAY': 'Give the observed day as YYYY-MM-DD.',
}


def remediation(code):
    return ADVICE.get(code) or embedding_points.remediation(code)


def _document(item):
    need(type(item) is dict and set(item) <= {'name', 'raw', 'protocol', 'host', 'observed'}, 'COPY_INPUT')
    need(type(item.get('name')) is str and 0 < len(item['name']) <= 4096, 'COPY_INPUT')
    need(type(item.get('raw')) in (bytes, bytearray) and len(item['raw']) <= MAX_FILE, 'COPY_LIMIT')
    if item.get('protocol') is not None:
        need(item['protocol'] in embedding_points.BY_ID, 'COPY_PROTOCOL')
    if item.get('host') is not None:
        need(type(item['host']) is str and HOST.fullmatch(item['host']) is not None, 'COPY_HOST')
    if item.get('observed') is not None:
        need(type(item['observed']) is str and DAY.fullmatch(item['observed']) is not None, 'COPY_DAY')
    return item


def _headers(text):
    """Carriers in an HTTP header dump: Link, WWW-Authenticate Payment, Authorization Payment and x402 headers."""
    found = []
    for line in text.splitlines()[:512]:
        match = HEADER.fullmatch(line.strip())
        if match is None:
            continue
        name, value = match.group(1).lower(), match.group(2).strip()
        if name == 'link':
            found.append(('http-link', value))
        elif name in ('www-authenticate', 'authorization', 'payment-authorization') and value.startswith('Payment '):
            found.append(('mpp', value))
        elif name in ('payment-required', 'payment-signature', 'payment-response'):
            found.append(('x402', value))
    return found


def _is(value, kind):
    return type(value) is kind


SHAPES = {
    'ap2': lambda d: d.get('vct') == embedding_points.AP2_VCT,
    'x402': lambda d: d.get('x402Version') == 2 or (_is(d.get('success'), bool) and 'transaction' in d and 'network' in d),
    'mpp': lambda d: _is(d.get('challenge'), dict) and 'payload' in d,
    'erc-8004': lambda d: d.get('type') == embedding_points.ERC8004_TYPE or all(
        name in d for name in ('agentRegistry', 'agentId', 'clientAddress', 'createdAt')),
    'erc-8183': lambda d: all(name in d for name in ('evaluator', 'expiredAt', 'description')),
    'oasf': lambda d: all(name in d for name in ('schema_version', 'skills', 'authors')),
    'lcp': lambda d: _is(d.get('terms'), str) and 'id' not in d,
    'schema-org': lambda d: 'schema.org' in json.dumps(d.get('@context', ''))[:4096],
    'ucp': lambda d: _is(d.get('ucp'), dict),
    'acp': lambda d: _is(d.get('line_items'), list) and ('capabilities' in d or 'protocol' in d),
    'mcp': lambda d: '_meta' in d or (d.get('jsonrpc') == '2.0' and (
        '/' in str(d.get('method', '')) or (_is(d.get('result'), dict) and (
            '_meta' in d['result'] or 'tools' in d['result'] or 'content' in d['result'])))),
    'a2a': lambda d: _is(d.get('capabilities'), dict) or ('role' in d and _is(d.get('parts'), list)) or (
        'artifactId' in d) or (_is(d.get('status'), dict) and 'id' in d) or (
        d.get('jsonrpc') == '2.0' and str(d.get('method', '')) in ('SendMessage', 'SendStreamingMessage', 'GetTask'))
        or (d.get('jsonrpc') == '2.0' and _is(d.get('result'), dict) and ('task' in d['result'] or 'message' in d['result'])),
}


def carriers(raw, hint=None):
    """[(protocol, carrier)] recognised in one document; a manifest hint names the protocol directly."""
    try:
        text = bytes(raw).decode('utf-8')
    except UnicodeDecodeError:
        return []
    stripped = text.lstrip()
    if hint is not None:
        if hint in embedding_points.TEXT_CARRIERS or hint == 'x402' and not stripped.startswith('{'):
            return [(hint, stripped if hint != 'mpp' else stripped.strip())]
        return [(hint, raw)]
    if stripped.startswith('{'):
        try:
            value = interop_codec.parse(bytes(raw), max_bytes=embedding_points.MAX_CARRIER,
                                        max_depth=embedding_points.MAX_DEPTH, max_nodes=embedding_points.MAX_NODES)
        except ValueError:
            return []
        if type(value) is not dict:
            return []
        for protocol in JSON_ORDER:
            if SHAPES[protocol](value):
                return [(protocol, value)]
        return []
    if stripped.startswith('<'):
        return [('rsl', text)] if '<rsl' in stripped[:4096] else []
    if embedding_points.TXT_TYPE.search(text):
        return [('dns', text)]
    return _headers(text)


def scan(documents):
    """The copy-number report for supplied documents (dicts of name, raw bytes and optional manifest facts)."""
    need(type(documents) in (list, tuple), 'COPY_INPUT')
    need(len(documents) <= MAX_FILES, 'COPY_LIMIT')
    rows = [_document(item) for item in documents]
    need(sum(len(item['raw']) for item in rows) <= MAX_TOTAL, 'COPY_LIMIT')
    by_protocol, hosts, signed = Counter(), set(), 0
    agreements, receipts, per_day = set(), set(), defaultdict(set)
    recognised, placements, unsupported, refused, unattributed = 0, [], [], [], []
    for item in rows:
        found_any = False
        attributed = set()
        for protocol, carrier in carriers(item['raw'], item.get('protocol')):
            try:
                result = embedding_points.extract(protocol, carrier)
            except ValueError as error:
                refused.append({'document': item['name'], 'protocol': protocol, 'code': str(error)})
                continue
            found_any = True
            unsupported += [{'document': item['name'], 'protocol': protocol, **row} for row in result['unsupported']]
            refused += [{'document': item['name'], 'protocol': protocol, **row} for row in result['refused']]
            context = result['context']
            host = item.get('host') or context.get('host')
            day = item.get('observed') or context.get('day') or 'undated'
            for row in result['found']:
                ref = aap_reference.decode(row['reference'])
                attributed.add(row['reference'])
                placements.append({'document': item['name'], 'protocol': protocol, 'location': row['location'],
                                   'reference': row['reference'], 'host': host, 'day': day})
                by_protocol[protocol] += 1
                agreements.add(ref['agreement'])
                if 'receipt' in ref:
                    receipts.add(ref['receipt'])
                if 'signature' in ref:
                    signed += 1
                per_day[day].add(ref['agreement'])
                if host:
                    hosts.add(host)
        recognised += found_any
        try:
            text = bytes(item['raw']).decode('utf-8', 'replace')
        except (TypeError, ValueError):
            text = ''
        for token in sorted(set(LOOSE.findall(text)))[:64]:
            try:
                compact = aap_reference.encode(aap_reference.decode(token))
            except ValueError:
                continue
            if compact not in attributed:
                unattributed.append({'document': item['name'], 'reference': compact})
    days = {day: len(ids) for day, ids in sorted(per_day.items())}
    return {'version': VERSION, 'maturity': MATURITY, 'documents': len(rows), 'recognised': recognised,
            'unrecognised': len(rows) - recognised, 'placements': len(placements),
            'by_protocol': dict(sorted(by_protocol.items())), 'protocols_carrying': len(by_protocol),
            'distinct_agreements': len(agreements), 'distinct_receipts': len(receipts),
            'distinct_hosts': len(hosts), 'hosts': sorted(hosts), 'agreements_per_day': days,
            'signed_placements': signed, 'signatures_checked': False,
            'unsupported': unsupported, 'refused': refused, 'unattributed': unattributed,
            'detail': placements[:1000],
            'measures': {'protocols_carrying_the_field': len(by_protocol),
                         'independent_hosts': {'value': len(hosts), 'basis': 'HOST_NAMES_SEEN_INDEPENDENCE_NOT_VERIFIED'},
                         'agreements_per_day': days},
            **FLAGS}


def _read(path):
    with open(path, 'rb') as handle:
        raw = handle.read(MAX_FILE + 1)
    need(len(raw) <= MAX_FILE, 'COPY_LIMIT')
    return raw


def _files(paths):
    out = []
    for given in paths:
        path = Path(given)
        need(not path.is_symlink(), 'COPY_INPUT')
        if path.is_dir():
            for root, directories, names in os.walk(path, followlinks=False):
                directories[:] = sorted(d for d in directories if not (Path(root) / d).is_symlink())
                for name in sorted(names):
                    child = Path(root) / name
                    if child.is_file() and not child.is_symlink():
                        out.append(child)
                        need(len(out) <= MAX_FILES, 'COPY_LIMIT')
        else:
            need(path.is_file(), 'COPY_INPUT')
            out.append(path)
            need(len(out) <= MAX_FILES, 'COPY_LIMIT')
    return out


def _manifest(path):
    raw = _read(path)
    need(len(raw) <= MAX_MANIFEST, 'COPY_MANIFEST')
    entries = {}
    for line in raw.decode('utf-8', 'strict').splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except ValueError:
            raise ValueError('COPY_MANIFEST') from None
        need(type(row) is dict and type(row.get('path')) is str and set(row) <= {'path', 'protocol', 'host', 'observed'},
             'COPY_MANIFEST')
        entries[str(Path(path).parent / row['path'])] = {name: row[name] for name in ('protocol', 'host', 'observed')
                                                        if name in row}
    return entries


def scan_paths(paths, manifest=None):
    """Read local files (directories are walked; symbolic links are refused) and scan them."""
    need(type(paths) in (list, tuple) and 0 < len(paths) <= MAX_FILES, 'COPY_INPUT')
    facts = _manifest(manifest) if manifest is not None else {}
    skip = Path(manifest).resolve() if manifest is not None else None
    documents = []
    for path in _files(paths):
        if skip is not None and path.resolve() == skip:
            continue
        documents.append({'name': str(path), 'raw': _read(path), **facts.get(str(path), {})})
    return scan(documents)


def describe():
    return {'module': 'covenant_chain.copy_number', 'version': VERSION, 'maturity': MATURITY,
            'job': 'Keep records: show, export, verify',
            'measures': ['protocols carrying the field', 'independent hosts (names seen; independence not verified)',
                         'agreements per day (manifest or carrier dates; otherwise undated)'],
            'limits': {'files': MAX_FILES, 'file_bytes': MAX_FILE, 'total_bytes': MAX_TOTAL},
            'errors': {code: text for code, text in ADVICE.items()}, **FLAGS}


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_chain.copy_number',
                                     description='Count AAP references in local files. Nothing is fetched or sent.')
    parser.add_argument('paths', nargs='*', help='files or directories to read')
    parser.add_argument('--manifest', help='JSON Lines of {path, protocol, host, observed} relative to the manifest')
    parser.add_argument('--describe', action='store_true')
    args = parser.parse_args(argv)
    try:
        result = describe() if args.describe or not args.paths else scan_paths(args.paths, args.manifest)
    except (ValueError, OSError, UnicodeError) as error:
        code = str(error) if str(error) in ADVICE else 'COPY_INPUT'
        print(json.dumps({'status': 'REFUSED', 'code': code, 'fix': remediation(code)}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
