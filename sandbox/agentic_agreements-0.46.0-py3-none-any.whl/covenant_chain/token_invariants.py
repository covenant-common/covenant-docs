"""Ossified core. Changing one of these requires a new opt-in profile, not an in-place edit.

`check` is consensus: a violation rejects the transaction.
"""
from .crypto import need
from .emissions import HALVING_BLOCKS_FLOOR
from .founder_share import BANDS, CEILING_BPS

MAX_SUPPLY = 1_000_000_000
ONAAH_NUM = 1
ONAAH_DEN = 6
EFFICIENCY_RATCHET_FLOOR_BPS = 5000
BURN_SHARE_FLOOR_BPS = 2000
TREASURY_PRINCIPAL_IS_UNSELLABLE = True
SHMITA_YEARS = 7
NO_MINT = True
NO_FIXED_YIELD = True
NO_RANDOM_REWARDS = True


def onaah_holds(price, measured_cost):
    """(price - cost) / cost ≤ 1/6. A zero cost admits no margin."""
    if type(price) is not int or type(measured_cost) is not int:
        return False
    if price < 0 or measured_cost < 0:
        return False
    if measured_cost == 0:
        return price == 0
    return (price - measured_cost) * ONAAH_DEN <= measured_cost * ONAAH_NUM


def user_saving(previous_cost, new_cost, ratchet_bps=EFFICIENCY_RATCHET_FLOOR_BPS):
    """At least half of a measured unit-cost drop is owed to users before any founder line."""
    if type(previous_cost) is not int or type(new_cost) is not int:
        return 0
    if ratchet_bps < EFFICIENCY_RATCHET_FLOOR_BPS:
        return None
    saving = previous_cost - new_cost
    if saving <= 0:
        return 0
    return saving * ratchet_bps // 10000


def check(previous, nxt, op):
    """Return a list of violation codes. Empty means the transition may commit."""
    violations = []
    if op in {'ECON_LOTTERY', 'ECON_RAFFLE', 'ECON_MINT', 'STAKE_APY', 'LIQUID_STAKE', 'ECON_REHYPOTHECATE'}:
        violations.append('OSSIFIED_FORBIDDEN')
    policy = nxt.get('economic_policy') if hasattr(nxt, 'get') else None
    if not policy or 'scale' not in policy:
        return violations
    body = (policy.get('active') or {}).get('body') or {}
    scale = body.get('scale') or {}
    supply = (scale.get('supply') or {}).get('total')
    if supply is not None and supply > MAX_SUPPLY:
        violations.append('MAX_SUPPLY')
    token = (scale.get('supply') or {}).get('resource')
    if token and 'supply' in previous and 'supply' in nxt:
        if nxt['supply'].get(token, 0) > previous['supply'].get(token, 0):
            violations.append('MINT')
    points = scale.get('points') or {}
    if points.get('halving_blocks', HALVING_BLOCKS_FLOOR) < HALVING_BLOCKS_FLOOR:
        violations.append('EMISSIONS_FASTER')
    if scale.get('shariah_mode') and (op.startswith('PREDICTION') or op.startswith('CREDIT') or op in {'ECON_LOTTERY', 'LIQUID_STAKE', 'ECON_REHYPOTHECATE'}):
        violations.append('SHARIAH_FORBIDDEN')
    for event in (policy.get('scale') or {}).get('ledger') or []:
        if event.get('rate_bps', 0) > CEILING_BPS or event.get('minted', 0):
            violations.append('FOUNDER_CORE')
            break
        if event.get('flow') == 'cost_report' and event.get('gross', 0) > event.get('cost', 0):
            drop = event['gross'] - event['cost']
            owed = drop * EFFICIENCY_RATCHET_FLOOR_BPS // 10000
            if event.get('users', 0) < owed:
                violations.append('EFFICIENCY_RATCHET')
                break
    meter = policy.get('scale') or {}
    floor = meter.get('treasury_principal')
    if floor is not None and meter.get('treasury_principal_spent', 0):
        violations.append('WAQF_PRINCIPAL')
    receipts = nxt.get('fee_receipts')
    old = previous.get('fee_receipts') if hasattr(previous, 'get') else None
    if receipts is not None and old is not None:
        for key, receipt in receipts.items():
            if key in old:
                continue
            row = receipt.get('scale') or {}
            if 'unit_price' in row and 'unit_cost' in row and not onaah_holds(row['unit_price'], row['unit_cost']):
                violations.append('ONAAH_CAP')
                break
    return violations


def shmita_expired(height, assessed_height, blocks_per_day, referred=False):
    """Minor reputation penalties expire after seven years unless a resolver referred them (prozbul)."""
    from .crypto import integer
    integer(height)
    integer(assessed_height)
    integer(blocks_per_day, True)
    if referred:
        return False
    return height >= assessed_height + SHMITA_YEARS * 365 * blocks_per_day


def assert_ok(previous, nxt, op):
    violations = check(previous, nxt, op)
    need(not violations, violations[0] if violations else 'CORE')
    return True


# The published bands are the only schedule this profile will pay.
OSSIFIED_BANDS = BANDS
