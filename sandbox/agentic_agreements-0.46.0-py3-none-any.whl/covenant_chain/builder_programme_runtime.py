"""Owner-adopted builder commerce, with no agent-side custody or code loading.

Business assent and signed delivery are reviewed before preparing the existing
ECON_CLEAR payload. Native consensus still requires its own all-account
approvals, balance checks and bounded fee envelope; it does not interpret this
new profile. The caller supplies an independently adopted chain/height view.
"""
from copy import deepcopy

from covenant_language import builder_programme as b, developer_apps as apps
from covenant_language import developer_economics as economics, mechanism_plans as p
from .crypto import canonical as trust_wire, verify, verification_key
from .developer_runtime import ApplicationRegistry, CALL, call_id
from .ecosystem import LABEL as NATIVE_LABEL, approval_body


class BuilderProgrammeRegistry:
    def __init__(self, applications, trusted_accounts):
        b.need(isinstance(applications, ApplicationRegistry), 'BUILDER_APPLICATIONS')
        b.need(type(trusted_accounts) is dict and len(trusted_accounts) <= 128,
               'BUILDER_TRUST')
        for actor, key in trusted_accounts.items():
            p.ref(actor)
            verification_key(key)
        self.applications = applications
        self.accounts = deepcopy(trusted_accounts)
        self._trust = trust_wire(self.accounts)
        self.programmes = {}

    def _trust_check(self):
        b.need(trust_wire(self.accounts) == self._trust, 'BUILDER_TRUST_CHANGED')

    def _verify(self, actor, payload, signature):
        self._trust_check()
        b.need(actor in self.accounts, 'BUILDER_ACCOUNT_NOT_ADOPTED')
        verify(self.accounts[actor], payload['label'], payload['body'], signature)

    def _account(self, actor):
        p.ref(actor)
        self._trust_check()
        b.need(actor in self.accounts, 'BUILDER_ACCOUNT_NOT_ADOPTED')

    def adopt(self, programme, sponsor_signature):
        self._trust_check()
        ref = b.identifier(programme)
        b.need(ref not in self.programmes, 'BUILDER_ALREADY_ADOPTED')
        b.need(len(self.programmes) < b.MAX_PROGRAMMES, 'BUILDER_PROGRAMME_LIMIT')
        self._verify(programme['sponsor'], b.assent_payload(programme), sponsor_signature)
        for application in programme['applications']:
            entry = self.applications.check(application)
            policy = self.applications.policies[entry['manifest']['economics']]
            b.need(policy['resource'] == programme['resource'], 'BUILDER_RESOURCE_MISMATCH')
        for award in programme['awards']:
            self._account(award['recipient'])
            for actor in award['acceptors']:
                self._account(actor)
        if programme['supersedes'] is not None:
            old = self.check(programme['supersedes'])['programme']
            b.need(old['sponsor'] == programme['sponsor'] and
                   old['name'] == programme['name'], 'BUILDER_SUCCESSOR_SCOPE')
        self.programmes[ref] = {'programme': deepcopy(programme),
                                'signature': deepcopy(sponsor_signature)}
        return {'programme': ref, 'adopted': True,
                'declared_award_budget': sum(a['amount'] for a in programme['awards']),
                'funding': 'UNRESERVED_DECLARED_TERMS_NOT_A_FUNDED_CAMPAIGN',
                'security_inherited': False, 'execution_authorized': False}

    def check(self, programme):
        p.ref(programme)
        self._trust_check()
        b.need(programme in self.programmes, 'BUILDER_PROGRAMME_NOT_ADOPTED')
        entry = self.programmes[programme]
        body = entry['programme']
        b.need(b.identifier(body) == programme, 'BUILDER_PROGRAMME_CHANGED')
        self._verify(body['sponsor'], b.assent_payload(body), entry['signature'])
        for application in body['applications']:
            installed = self.applications.check(application)
            policy = self.applications.policies[installed['manifest']['economics']]
            b.need(policy['resource'] == body['resource'], 'BUILDER_RESOURCE_MISMATCH')
        return entry

    def describe(self):
        return {'version': b.VERSION,
                'programmes': [{'id': ref,
                                'programme': deepcopy(self.check(ref)['programme']),
                                'funding': 'UNRESERVED_DECLARED_TERMS_NOT_A_FUNDED_CAMPAIGN'}
                               for ref in sorted(self.programmes)],
                'installation': 'OWNER_ONLY_TRUST_AND_APPLICATION_ADOPTION',
                'privacy': 'OWNER_HELD_RECORDS_EXPORT_REQUIRES_HOLDER_ACTION',
                'execution_authorized': False}

    def _make_quote(self, programme, services, payer, chain, context, nonce,
                    valid_from, valid_until, cap, native_fee_cap, native_fee_resource=None,
                    *, _quoted=False):
        body = self.check(programme)['programme']
        native_fee_resource = body['resource'] if native_fee_resource is None else native_fee_resource
        b.text(native_fee_resource, 80)
        for ref in (chain, context, nonce):
            p.ref(ref)
        self._account(payer)
        for value in (valid_from, valid_until, cap, native_fee_cap):
            b.integer(value)
        b.need(valid_from <= valid_until, 'BUILDER_INTERVAL')
        b.need(type(services) is list and 1 <= len(services) <= b.MAX_SERVICES,
               'BUILDER_SERVICE_LIMIT')
        rows = []
        amounts = {}
        seen = set()
        for service in services:
            b.fields(service, 'call performer request' if _quoted else 'call performer')
            call = service['call']
            if _quoted:
                b.fields(call, 'version application operation context units')
                b.need(call['version'] == CALL, 'APPLICATION_CALL_VERSION')
                p.ref(call['application'])
                apps.name(call['operation'])
                p.ref(call['context'])
                b.integer(call['units'], True)
                request = service['request']
                p.ref(request)
            else:
                request = call_id(call)
            b.need(request not in seen, 'BUILDER_DUPLICATE_REQUEST')
            seen.add(request)
            b.need(call['context'] == context, 'BUILDER_CALL_CONTEXT')
            b.need(call['application'] in body['applications'], 'BUILDER_APP_NOT_ELIGIBLE')
            self._account(service['performer'])
            record = self.applications.check(call['application'])
            b.need(call['operation'] in record['manifest']['routes'], 'APPLICATION_OPERATION')
            closure = apps.resolve(call['application'],
                                   [v['manifest'] for v in self.applications.entries.values()])
            quoted = self.applications.quote(call['application'], call['units'])
            b.need(quoted['resource'] == body['resource'], 'BUILDER_RESOURCE_MISMATCH')
            for row in quoted['allocations']:
                amounts[row['account']] = economics.total([
                    amounts.get(row['account'], 0), row['amount']])
            # Quote holders see the exact request commitment, never arguments.
            public_call = {key: deepcopy(call[key]) for key in
                           ('version', 'application', 'operation', 'context', 'units')}
            rows.append({'request': request, 'call': public_call,
                         'performer': service['performer'], 'closure': closure['closure'],
                         'policy': quoted['policy'], 'amount': quoted['amount'],
                         'allocations': deepcopy(quoted['allocations'])})
        rows.sort(key=lambda row: row['request'])
        coordination = b.split(body['coordination_fee'], body['shares'])
        for row in coordination:
            amounts[row['account']] = economics.total([
                amounts.get(row['account'], 0), row['amount']])
        b.need(len(amounts) <= 64, 'BUILDER_BENEFICIARY_LIMIT')
        total = economics.total([sum(row['amount'] for row in rows),
                                 body['coordination_fee']])
        same_resource = body['resource'] == native_fee_resource
        maximum = economics.total([total, native_fee_cap]) if same_resource else total
        b.need(maximum <= cap, 'BUILDER_AGGREGATE_CAP')
        retained = amounts.get(payer, 0)
        quote = {'version': b.QUOTE_VERSION, 'programme': programme, 'chain': chain,
                 'context': context, 'nonce': nonce, 'payer': payer,
                 'valid_from': valid_from, 'valid_until': valid_until,
                 'resource': body['resource'], 'unit': body['unit'], 'services': rows,
                 'coordination_fee': body['coordination_fee'],
                 'coordination_allocations': coordination, 'service_amount': total,
                 'allocations': [{'account': actor, 'amount': amount}
                                 for actor, amount in sorted(amounts.items())],
                 'payer_retained_allocation': retained, 'payer_net_outflow': total - retained,
                 'native_fee_resource': native_fee_resource, 'native_fee_cap': native_fee_cap,
                 'maximum_total': maximum, 'cap': cap,
                 'cap_scope': ('COMBINED_SAME_RESOURCE' if same_resource else
                               'SERVICE_RESOURCE_ONLY_SEPARATE_NATIVE_CAP')}
        b.quote_identifier(quote)
        return quote

    def quote(self, programme, services, payer, chain, context, nonce,
              valid_from, valid_until, cap, native_fee_cap, native_fee_resource=None):
        quote = self._make_quote(programme, services, payer, chain, context, nonce,
                                 valid_from, valid_until, cap, native_fee_cap, native_fee_resource)
        return {'id': b.quote_identifier(quote), 'quote': quote,
                'assent_payload': b.quote_payload(quote),
                'required_signers': sorted({payer} | {s['performer'] for s in quote['services']}),
                'fee_basis': 'EXPLICIT_SELECTED_CALLS_PLUS_DISCLOSED_COORDINATION_FEE',
                'dependency_royalties': 'NONE_UNLESS_EXPLICITLY_SELECTED_OR_IN_ADOPTED_TARIFF',
                'native_fee_resource_required': quote['native_fee_resource'],
                'price_caps': self._price_caps(quote), 'cap_scope': quote['cap_scope'],
                'cross_resource_conversion': 'NONE_NO_NUMERIC_CROSS_ASSET_TOTAL',
                'funding': 'NOT_VERIFIED_OR_RESERVED',
                'privacy': 'ARGUMENTS_WITHHELD_REQUEST_DIGEST_PUBLIC_TO_QUOTE_HOLDERS',
                'security_inherited': False, 'execution_authorized': False}

    def verify_quote(self, quote):
        ref = b.quote_identifier(quote)
        expected = self._make_quote(
            quote['programme'], [{'call': s['call'], 'performer': s['performer'],
                                  'request': s['request']}
                                 for s in quote['services']],
            quote['payer'], quote['chain'], quote['context'], quote['nonce'],
            quote['valid_from'], quote['valid_until'], quote['cap'], quote['native_fee_cap'],
            quote['native_fee_resource'],
            _quoted=True)
        b.need(p.canonical(quote) == p.canonical(expected), 'BUILDER_QUOTE_CHANGED')
        return ref

    def verify_call_opening(self, quote, call):
        """Optional local check of a privately exchanged original call."""
        self.verify_quote(quote)
        request = call_id(call)
        rows = [row for row in quote['services'] if row['request'] == request]
        b.need(len(rows) == 1, 'BUILDER_CALL_OPENING')
        projection = {key: deepcopy(call[key]) for key in
                      ('version', 'application', 'operation', 'context', 'units')}
        b.need(p.canonical(projection) == p.canonical(rows[0]['call']),
               'BUILDER_CALL_OPENING')
        return {'quote': b.quote_identifier(quote), 'request': request,
                'opening_verified': True, 'arguments_returned': False,
                'execution_authorized': False}

    def _approvals(self, actors, payload, approvals):
        b.need(type(approvals) is list and len(approvals) == len(actors),
               'BUILDER_APPROVALS')
        seen = set()
        for approval in approvals:
            b.fields(approval, 'account signature')
            actor = approval['account']
            p.ref(actor)
            b.need(actor in actors and actor not in seen, 'BUILDER_APPROVAL_SCOPE')
            seen.add(actor)
            self._verify(actor, payload, approval['signature'])
        b.need(seen == set(actors), 'BUILDER_APPROVALS')

    def delivery(self, quote, request, evidence):
        ref = self.verify_quote(quote)
        p.ref(request)
        rows = [row for row in quote['services'] if row['request'] == request]
        b.need(len(rows) == 1, 'BUILDER_DELIVERY_REQUEST')
        return b.delivery_draft(ref, request, rows[0]['performer'], evidence)

    def _deliveries(self, quote, deliveries):
        ref = self.verify_quote(quote)
        b.need(type(deliveries) is list and len(deliveries) == len(quote['services']),
               'BUILDER_DELIVERIES')
        services = {row['request']: row for row in quote['services']}
        seen = set()
        ids = []
        for signed in deliveries:
            b.fields(signed, 'delivery signature')
            delivery = signed['delivery']
            did = b.delivery_identifier(delivery)
            request = delivery['request']
            b.need(delivery['quote'] == ref and request in services and request not in seen,
                   'BUILDER_DELIVERY_SCOPE')
            b.need(delivery['performer'] == services[request]['performer'],
                   'BUILDER_DELIVERY_PERFORMER')
            self._verify(delivery['performer'], b.delivery_payload(delivery), signed['signature'])
            seen.add(request)
            ids.append(did)
        return sorted(ids)

    def acceptance(self, quote, deliveries):
        ids = self._deliveries(quote, deliveries)
        return b.acceptance_draft(b.quote_identifier(quote), quote['payer'], ids)

    @staticmethod
    def _price_caps(record):
        caps = [{'resource': record['resource'], 'amount': record['cap']}]
        if record['native_fee_resource'] != record['resource']:
            caps.append({'resource': record['native_fee_resource'],
                         'amount': record['native_fee_cap']})
        return caps

    @staticmethod
    def _current(record, chain, current_height, native_fee_resource):
        p.ref(chain)
        b.integer(current_height)
        b.text(native_fee_resource, 80)
        b.need(chain == record['chain'], 'BUILDER_CHAIN_SCOPE')
        b.need(record['valid_from'] <= current_height <= record['valid_until'],
               'BUILDER_QUOTE_NOT_CURRENT')
        b.need(native_fee_resource == record['native_fee_resource'], 'BUILDER_NATIVE_FEE_RESOURCE')

    @staticmethod
    def _native_plan(clearing, resource, transfers, chain, native_fee_cap,
                     native_fee_resource=None):
        payload = {'clearing': clearing, 'resource': resource,
                   'transfers': deepcopy(transfers), 'approvals': []}
        actors = sorted({actor for row in transfers
                         for actor in (row['source'], row['destination'])})
        return {'operation': 'ECON_CLEAR' if transfers else None, 'payload': payload,
                'native_approval_payload': {'label': NATIVE_LABEL,
                                             'body': approval_body(chain, 'ECON_CLEAR', payload)} if transfers else None,
                'required_accounts': actors, 'required_signers': actors,
                'native_account_authority': 'RESOLVE_CURRENT_CONTROLLERS_OR_WORLD_GOVERNANCE_FOR_EACH_ACCOUNT',
                'native_fee_envelope': {'max_amount': native_fee_cap, 'sponsor': None} if transfers else None,
                'native_fee_resource': resource if native_fee_resource is None else native_fee_resource,
                'native_fee_policy': 'OWNER_MUST_PIN_CURRENT_NATIVE_POLICY_IN_TRANSACTION',
                'native_fee_enforced': False,
                'native_business_enforcement': False,
                'native_approval_lifetime': 'NO_NATIVE_EXPIRY_AFTER_SIGNATURE; VALID_UNTIL_IS_OWNER_PREPARATION_CHECK_ONLY',
                'settlement_required': bool(transfers),
                'funding': 'NOT_VERIFIED_OR_RESERVED',
                'submission': 'OWNER_MUST_CHECK_CURRENT_CHAIN_STATE_AND_USE_NATIVE_FEE_CAP' if transfers else 'NO_NATIVE_TRANSFER_REQUIRED_DO_NOT_SUBMIT',
                'consensus_business_checks': 'NONE_THIS_IS_OWNER_RUNTIME_REVIEW',
                'execution_authorized': False}

    def prepare_settlement(self, quote, quote_approvals, deliveries, acceptance,
                           chain, current_height, native_fee_resource):
        ref = self.verify_quote(quote)
        self._current(quote, chain, current_height, native_fee_resource)
        actors = {quote['payer']} | {row['performer'] for row in quote['services']}
        self._approvals(actors, b.quote_payload(quote), quote_approvals)
        expected = self.acceptance(quote, deliveries)
        b.fields(acceptance, 'acceptance signature')
        b.acceptance_identifier(acceptance['acceptance'])
        b.need(p.canonical(acceptance['acceptance']) == p.canonical(expected['acceptance']),
               'BUILDER_ACCEPTANCE_SCOPE')
        self._verify(quote['payer'], expected['assent_payload'], acceptance['signature'])
        transfers = [{'source': quote['payer'], 'destination': row['account'],
                      'amount': row['amount']} for row in quote['allocations']
                     if row['amount'] and row['account'] != quote['payer']]
        # Never derive replay identity from receipts, signature bytes or subsets.
        clearing = p._id('COVENANT-BUILDER-CLEARING-0.1', {'quote': ref})
        return {**self._native_plan(clearing, quote['resource'], transfers, chain,
                                   quote['native_fee_cap'], quote['native_fee_resource']),
                'quote': ref, 'acceptance': expected['id'],
                'price_caps': self._price_caps(quote), 'cap_scope': quote['cap_scope'],
                'assurance': 'EXACT_BUSINESS_ASSENT_AND_SIGNED_ASSERTIONS_NOT_TRUTH',
                'replay': 'SAME_QUOTE_SAME_CLEARING_NATIVE_LEDGER_REFUSES_REUSE',
                'current_height': current_height,
                'height_assurance': 'CALLER_ADOPTED_OBSERVATION_NOT_CONSENSUS_EXPIRY'}

    def _award(self, programme, award):
        body = self.check(programme)['programme']
        b.name(award)
        rows = [row for row in body['awards'] if row['name'] == award]
        b.need(len(rows) == 1, 'BUILDER_AWARD_NOT_FOUND')
        return body, rows[0]

    def award_offer(self, programme, award, chain, context, valid_from, valid_until,
                    cap, native_fee_cap, native_fee_resource=None):
        body, row = self._award(programme, award)
        native_fee_resource = body['resource'] if native_fee_resource is None else native_fee_resource
        b.text(native_fee_resource, 80)
        for ref in (chain, context):
            p.ref(ref)
        for value in (valid_from, valid_until, cap, native_fee_cap):
            b.integer(value)
        b.need(valid_from <= valid_until, 'BUILDER_INTERVAL')
        same_resource = body['resource'] == native_fee_resource
        maximum = economics.total([row['amount'], native_fee_cap]) if same_resource else row['amount']
        b.need(maximum <= cap, 'BUILDER_AGGREGATE_CAP')
        offer = {'version': b.AWARD_OFFER_VERSION, 'programme': programme, 'award': award,
                 'chain': chain, 'context': context, 'valid_from': valid_from,
                 'valid_until': valid_until, 'resource': body['resource'], 'unit': body['unit'],
                 'sponsor': body['sponsor'], 'recipient': row['recipient'], 'amount': row['amount'],
                 'deliverable': row['deliverable'], 'acceptors': deepcopy(row['acceptors']),
                 'native_fee_resource': native_fee_resource, 'native_fee_cap': native_fee_cap,
                 'maximum_total': maximum, 'cap': cap,
                 'cap_scope': ('COMBINED_SAME_RESOURCE' if same_resource else
                               'SERVICE_RESOURCE_ONLY_SEPARATE_NATIVE_CAP')}
        return {'id': b.award_offer_identifier(offer), 'offer': offer,
                'assent_payload': b.award_offer_payload(offer),
                'price_caps': self._price_caps(offer), 'cap_scope': offer['cap_scope'],
                'cross_resource_conversion': 'NONE_NO_NUMERIC_CROSS_ASSET_TOTAL',
                'funding': 'UNRESERVED_ONE_TIME_AWARD_NOT_A_FUNDED_CAMPAIGN',
                'replay': 'ONE_CLEARING_PER_ADOPTED_PROGRAMME_AWARD_PER_NATIVE_CHAIN',
                'execution_authorized': False}

    def verify_award_offer(self, offer):
        ref = b.award_offer_identifier(offer)
        expected = self.award_offer(offer['programme'], offer['award'], offer['chain'],
                                    offer['context'], offer['valid_from'], offer['valid_until'],
                                    offer['cap'], offer['native_fee_cap'], offer['native_fee_resource'])['offer']
        b.need(p.canonical(offer) == p.canonical(expected), 'BUILDER_AWARD_OFFER_CHANGED')
        return ref

    def award_delivery(self, offer, evidence):
        ref = self.verify_award_offer(offer)
        return b.award_delivery_draft(ref, offer['recipient'], evidence)

    def _award_delivery(self, offer, delivery):
        ref = self.verify_award_offer(offer)
        b.fields(delivery, 'delivery signature')
        body = delivery['delivery']
        did = b.award_delivery_identifier(body)
        b.need(body['offer'] == ref and body['recipient'] == offer['recipient'],
               'BUILDER_AWARD_DELIVERY_SCOPE')
        self._verify(offer['recipient'], b.award_delivery_payload(body), delivery['signature'])
        return did

    def award_acceptance(self, offer, delivery):
        did = self._award_delivery(offer, delivery)
        return b.award_acceptance_draft(b.award_offer_identifier(offer), did)

    def prepare_award(self, offer, delivery, acceptance, approvals, chain,
                      current_height, native_fee_resource):
        self.verify_award_offer(offer)
        self._current(offer, chain, current_height, native_fee_resource)
        expected = self.award_acceptance(offer, delivery)
        b.award_acceptance_identifier(acceptance)
        b.need(p.canonical(acceptance) == p.canonical(expected['acceptance']),
               'BUILDER_AWARD_ACCEPTANCE_SCOPE')
        self._approvals(set(offer['acceptors']), expected['assent_payload'], approvals)
        transfers = [] if offer['recipient'] == offer['sponsor'] else [
            {'source': offer['sponsor'], 'destination': offer['recipient'],
             'amount': offer['amount']}]
        clearing = p._id('COVENANT-BUILDER-AWARD-CLEARING-0.1',
                         {'programme': offer['programme'], 'award': offer['award'],
                          'chain': chain})
        return {**self._native_plan(clearing, offer['resource'], transfers, chain,
                                   offer['native_fee_cap'], offer['native_fee_resource']),
                'offer': b.award_offer_identifier(offer), 'acceptance': expected['id'],
                'price_caps': self._price_caps(offer), 'cap_scope': offer['cap_scope'],
                'declared_budget': 'UNRESERVED; NATIVE_BALANCES_AND_FIXED_ONE_TIME_IDS_ONLY',
                'cross_chain_budget': 'NO_SHARED_BUDGET_OR_GLOBAL_DOUBLE_SPEND_GUARANTEE',
                'assurance': 'AGREED_ACCEPTOR_ATTESTATIONS_NOT_INDEPENDENT_TRUTH',
                'current_height': current_height,
                'height_assurance': 'CALLER_ADOPTED_OBSERVATION_NOT_CONSENSUS_EXPIRY'}

    def prepare_refund(self, quote, refunds, case, chain, current_height, native_fee_cap):
        ref = self.verify_quote(quote)
        p.ref(case)
        p.ref(chain)
        b.need(chain == quote['chain'], 'BUILDER_CHAIN_SCOPE')
        b.integer(current_height)
        b.integer(native_fee_cap)
        b.need(type(refunds) is list and 1 <= len(refunds) <= 64, 'BUILDER_REFUNDS')
        maxima = {row['account']: row['amount'] for row in quote['allocations']
                  if row['account'] != quote['payer']}
        seen = set()
        rows = []
        for row in refunds:
            b.fields(row, 'account amount')
            p.ref(row['account'])
            b.integer(row['amount'], True)
            b.need(row['account'] in maxima and row['account'] not in seen and
                   row['amount'] <= maxima[row['account']], 'BUILDER_REFUND_SCOPE')
            seen.add(row['account'])
            rows.append(deepcopy(row))
        rows.sort(key=lambda row: row['account'])
        clearing = p._id('COVENANT-BUILDER-REFUND-CLEARING-0.1',
                         {'quote': ref, 'case': case, 'refunds': rows})
        transfers = [{'source': row['account'], 'destination': quote['payer'],
                      'amount': row['amount']} for row in rows]
        return {**self._native_plan(clearing, quote['resource'], transfers, chain,
                                   native_fee_cap, quote['native_fee_resource']),
                'quote': ref, 'case': case, 'current_height': current_height,
                'payment_observation': 'NOT_VERIFIED_NO_ASSERTION_ORIGINAL_WAS_PAID',
                'refund_authority': 'NONE_ALL_NATIVE_ACCOUNTS_MUST_EXPLICITLY_APPROVE',
                'refund_limits': 'PER_PROPOSAL_NOT_CUMULATIVE_ACROSS_CASES',
                'quote_expiry': 'DOES_NOT_PREVENT_SEPARATELY_AGREED_LATER_REFUND'}
