"""Roughtime messages: build, parse, verify and chain them, with no network.

IETF draft-ietf-ntp-roughtime-19 is the primary wire profile: version 1, and
0x8000000c, which drafts 12 to 19 use for testing with the same meaning.
Google's original protocol stays available as the older, widely deployed
leg: unframed packets, 64-byte nonces, full SHA-512 and microsecond times.

A valid response proves only that the holder of a pinned long-term key signed
an interval after it saw the request (draft section 5.4). It does not make the
time true. Deriving each nonce from the previous response orders the answers,
so a later answer whose interval ends before an earlier one begins is a signed
proof that at least one of the two servers lied (section 8.2). Reports use the
section 8.4.1 JSON form. Only ``udp_exchange``, the default transport of
``measure``, opens a socket, and only for an explicit owner-supplied server
list. Nothing here reads the wall clock.
"""
import base64
import hashlib
import math
import os
import struct
import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from covenant_language.key_validation import valid_ed25519_key

from .crypto import need

IETF, GOOGLE = 'IETF', 'GOOGLE'
PROTOCOLS = (IETF, GOOGLE)
VERSION_1 = 0x00000001
VERSION_DRAFT = 0x8000000c
IETF_VERSIONS = (VERSION_1, VERSION_DRAFT)
HEADER = b'ROUGHTIM'
REQUEST_BYTES = 1024
MAX_PACKET = 4096
MAX_TAGS = 64
MAX_PATH = 32
MAX_LINKS = 32
NONCE_BYTES = {IETF: 32, GOOGLE: 64}
CERT_CONTEXT = {IETF: b'RoughTime v1 delegation signature\x00',
                GOOGLE: b'RoughTime v1 delegation signature--\x00'}
RESPONSE_CONTEXT = b'RoughTime v1 response signature\x00'
GOOGLE_PAD = b'PAD\xff'


def tag(name):
    """Four tag octets: capital ASCII letters, then zero padding (section 4.1.3)."""
    need(type(name) is str and 1 <= len(name) <= 4 and name.isascii() and name.isupper(), 'ROUGHTIME_TAG')
    return name.encode('ascii').ljust(4, b'\x00')


def _u32(value):
    return struct.pack('<I', value)


def _uint(raw, size, code):
    need(type(raw) is bytes and len(raw) == size, code)
    return int.from_bytes(raw, 'little')


def _number(raw):
    return struct.unpack('<I', raw)[0]


def encode(fields):
    """Encode a map of four-byte tags to values, sorted by tag number (section 4.2)."""
    need(type(fields) is dict and 1 <= len(fields) <= MAX_TAGS and all(
        type(name) is bytes and len(name) == 4 and type(value) is bytes and len(value) % 4 == 0
        for name, value in fields.items()), 'ROUGHTIME_MESSAGE')
    items = sorted(fields.items(), key=lambda item: _number(item[0]))
    offsets, at = [], 0
    for index, (_name, value) in enumerate(items):
        if index:
            offsets.append(at)
        at += len(value)
    return (_u32(len(items)) + b''.join(map(_u32, offsets)) + b''.join(name for name, _ in items) +
            b''.join(value for _, value in items))


def decode(raw):
    """Strictly parse one message. Unknown tags are kept; callers ignore them."""
    need(type(raw) is bytes and 4 <= len(raw) <= MAX_PACKET and len(raw) % 4 == 0, 'ROUGHTIME_MESSAGE')
    count = _number(raw[:4])
    need(1 <= count <= MAX_TAGS and 8 * count <= len(raw), 'ROUGHTIME_MESSAGE')
    offsets = [0] + [_number(raw[4 + 4 * i:8 + 4 * i]) for i in range(count - 1)]
    names = [raw[4 * count + 4 * i:4 * count + 4 * i + 4] for i in range(count)]
    body = raw[8 * count:]
    numbers = [_number(name) for name in names]
    need(all(a < b for a, b in zip(numbers, numbers[1:])), 'ROUGHTIME_TAG_ORDER')
    need(all(value % 4 == 0 for value in offsets) and all(a <= b for a, b in zip(offsets, offsets[1:])) and
         offsets[-1] <= len(body), 'ROUGHTIME_MESSAGE')
    ends = offsets[1:] + [len(body)]
    return {name: body[start:end] for name, start, end in zip(names, offsets, ends)}


def frame(message):
    """IETF packet: "ROUGHTIM", the uint32 message length, the message (section 5)."""
    need(type(message) is bytes and len(message) <= MAX_PACKET - 12, 'ROUGHTIME_FRAME')
    return HEADER + _u32(len(message)) + message


def unframe(packet):
    need(type(packet) is bytes and 12 <= len(packet) <= MAX_PACKET and packet[:8] == HEADER and
         _number(packet[8:12]) == len(packet) - 12, 'ROUGHTIME_FRAME')
    return packet[12:]


def _value(message, name, size=None, code='ROUGHTIME_FIELDS'):
    value = message.get(tag(name))
    need(value is not None and (size is None or len(value) == size), code)
    return value


def _versions(raw):
    need(len(raw) % 4 == 0 and 4 <= len(raw) <= 128, 'ROUGHTIME_VERSION')
    values = [_number(raw[i:i + 4]) for i in range(0, len(raw), 4)]
    need(all(a < b for a, b in zip(values, values[1:])), 'ROUGHTIME_VERSION')
    return values


def _hash(data, protocol):
    full = hashlib.sha512(data).digest()
    return full[:32] if protocol == IETF else full


def key_bytes(public_key):
    """A pinned long-term key as 64 lowercase hex characters; small-order keys refused."""
    need(type(public_key) is str and valid_ed25519_key(public_key), 'ROUGHTIME_PUBLIC_KEY')
    return bytes.fromhex(public_key)


def server_hash(public_key):
    """SRV value H(0xff || public_key), section 5.1.4."""
    return _hash(b'\xff' + key_bytes(public_key), IETF)


def request(nonce, protocol=IETF, *, public_key=None, versions=IETF_VERSIONS):
    """A request padded to 1024 message bytes (section 5.1; Google pads with PAD\\xff)."""
    need(protocol in PROTOCOLS, 'ROUGHTIME_PROTOCOL')
    need(type(nonce) is bytes and len(nonce) == NONCE_BYTES[protocol], 'ROUGHTIME_NONCE')
    if protocol == GOOGLE:
        fields, pad = {tag('NONC'): nonce}, GOOGLE_PAD
    else:
        need(type(versions) in (tuple, list) and 1 <= len(versions) <= 32 and
             all(type(v) is int and 0 < v < 2**32 for v in versions) and list(versions) == sorted(set(versions)),
             'ROUGHTIME_VERSION')
        fields, pad = {tag('VER'): b''.join(map(_u32, versions)), tag('NONC'): nonce, tag('TYPE'): _u32(0)}, tag('ZZZZ')
        if public_key is not None:
            fields[tag('SRV')] = server_hash(public_key)
    fields[pad] = b''
    fields[pad] = bytes(REQUEST_BYTES - len(encode(fields)))
    message = encode(fields)
    return message if protocol == GOOGLE else frame(message)


def protocol_of(packet):
    """IETF packets carry the ROUGHTIM header; Google's original packets do not."""
    need(type(packet) is bytes, 'ROUGHTIME_FRAME')
    return IETF if packet[:8] == HEADER else GOOGLE


def request_nonce(packet, protocol=IETF):
    """The nonce a request commits to, after checking its mandatory tags."""
    need(protocol in PROTOCOLS, 'ROUGHTIME_PROTOCOL')
    if protocol == GOOGLE:
        return _value(decode(packet), 'NONC', 64, 'ROUGHTIME_NONCE')
    message = decode(unframe(packet))
    _versions(_value(message, 'VER', code='ROUGHTIME_VERSION'))
    need(_value(message, 'TYPE', 4) == _u32(0), 'ROUGHTIME_TYPE')
    return _value(message, 'NONC', 32, 'ROUGHTIME_NONCE')


def _signature(public, message, signature, code):
    try:
        Ed25519PublicKey.from_public_bytes(public).verify(signature, message)
    except (InvalidSignature, ValueError):
        raise ValueError(code) from None


def merkle_root(leaf, path, index, protocol=IETF):
    """Section 5.3.1: bits of INDX from least significant; unused bits must be zero."""
    size = 32 if protocol == IETF else 64
    need(type(path) is bytes and len(path) % size == 0 and len(path) // size <= MAX_PATH, 'ROUGHTIME_MERKLE_PATH')
    value = _hash(b'\x00' + leaf, protocol)
    for depth in range(len(path) // size):
        node = path[depth * size:(depth + 1) * size]
        value = _hash(b'\x01' + node + value if (index >> depth) & 1 else b'\x01' + value + node, protocol)
    need(index >> (len(path) // size) == 0, 'ROUGHTIME_MERKLE_INDEX')
    return value


def verify_response(request_packet, response_packet, public_key, protocol=IETF):
    """Check one answer against its request and a pinned key (section 5.4).

    Returns the signed interval and, rounded outward, whole Unix seconds.
    """
    need(protocol in PROTOCOLS, 'ROUGHTIME_PROTOCOL')
    long_term = key_bytes(public_key)
    nonce = request_nonce(request_packet, protocol)
    response = decode(response_packet if protocol == GOOGLE else unframe(response_packet))
    if protocol == IETF:
        need(_value(response, 'TYPE', 4) == _u32(1), 'ROUGHTIME_TYPE')
        need(_value(response, 'NONC', 32) == nonce, 'ROUGHTIME_NONCE')
        named = decode(unframe(request_packet)).get(tag('SRV'))
        need(named is None or named == server_hash(public_key), 'ROUGHTIME_SRV')
    signed = _value(response, 'SREP')
    certificate = decode(_value(response, 'CERT'))
    delegation = _value(certificate, 'DELE')
    _signature(long_term, CERT_CONTEXT[protocol] + delegation, _value(certificate, 'SIG', 64), 'ROUGHTIME_CERT_SIGNATURE')
    dele = decode(delegation)
    online = _value(dele, 'PUBK', 32)
    need(valid_ed25519_key(online.hex()), 'ROUGHTIME_DELEGATED_KEY')
    _signature(online, RESPONSE_CONTEXT + signed, _value(response, 'SIG', 64), 'ROUGHTIME_SIGNATURE')
    srep = decode(signed)
    midpoint = _uint(_value(srep, 'MIDP'), 8, 'ROUGHTIME_FIELDS')
    radius = _uint(_value(srep, 'RADI'), 4, 'ROUGHTIME_FIELDS')
    mint = _uint(_value(dele, 'MINT'), 8, 'ROUGHTIME_FIELDS')
    maxt = _uint(_value(dele, 'MAXT'), 8, 'ROUGHTIME_FIELDS')
    need(0 < radius <= midpoint, 'ROUGHTIME_RADIUS')
    need(mint <= midpoint <= maxt, 'ROUGHTIME_DELEGATION_WINDOW')
    index = _uint(_value(response, 'INDX'), 4, 'ROUGHTIME_FIELDS')
    path = _value(response, 'PATH')
    root = _value(srep, 'ROOT', 32 if protocol == IETF else 64)
    leaf = request_packet if protocol == IETF else nonce
    need(merkle_root(leaf, path, index, protocol) == root, 'ROUGHTIME_MERKLE_PATH')
    version = None
    if protocol == IETF:
        version = _uint(_value(srep, 'VER'), 4, 'ROUGHTIME_VERSION')
        offered = _versions(_value(decode(unframe(request_packet)), 'VER'))
        supported = _versions(_value(srep, 'VERS', code='ROUGHTIME_VERSION'))
        need(version in IETF_VERSIONS and version in offered and version in supported, 'ROUGHTIME_VERSION')
    scale = 1 if protocol == IETF else 1_000_000
    return {'protocol': protocol, 'version': version, 'midpoint': midpoint, 'radius': radius,
            'unit': 'SECONDS' if protocol == IETF else 'MICROSECONDS',
            'lower': (midpoint - radius) // scale, 'upper': -(-(midpoint + radius) // scale),
            'nonce': nonce.hex(), 'delegated_key': online.hex(), 'delegation': [mint, maxt],
            'index': index, 'path_nodes': len(path) // (32 if protocol == IETF else 64)}


def chain_nonce(previous, rand, protocol=IETF):
    """IETF: H(previous || rand) (section 8.2). Google: SHA-512(SHA-512(previous) || blind)."""
    need(protocol in PROTOCOLS, 'ROUGHTIME_PROTOCOL')
    need(type(previous) is bytes and previous and type(rand) is bytes and len(rand) == NONCE_BYTES[protocol],
         'ROUGHTIME_BLIND')
    if protocol == IETF:
        return _hash(previous + rand, IETF)
    return hashlib.sha512(hashlib.sha512(previous).digest() + rand).digest()


def verify_chain(links, start=None):
    """Verify each link, each nonce derivation and causal order.

    ``links`` hold bytes: protocol, public_key, rand, request, response. With
    ``start`` the first nonce must derive from it, so every answer postdates it.
    Without ``start`` the first nonce is free, as in a section 8.4.1 report.
    A pair (i, j), i before j, violates causal order when the interval of i
    begins after the interval of j ends. Each such pair is a signed proof that
    at least one of the two servers answered with the wrong time.
    """
    need(type(links) is list and 1 <= len(links) <= MAX_LINKS, 'ROUGHTIME_CHAIN')
    results, previous = [], start
    for link in links:
        need(type(link) is dict and {'protocol', 'public_key', 'request', 'response'} <= set(link) <=
             {'protocol', 'public_key', 'rand', 'request', 'response'}, 'ROUGHTIME_CHAIN')
        protocol = link['protocol']
        nonce = request_nonce(link['request'], protocol)
        if previous is not None:
            need(nonce == chain_nonce(previous, link.get('rand'), protocol), 'ROUGHTIME_CHAIN_NONCE')
        results.append(verify_response(link['request'], link['response'], link['public_key'], protocol))
        previous = link['response']
    violations = [[i, j] for i in range(len(results)) for j in range(i + 1, len(results))
                  if results[i]['lower'] > results[j]['upper']]
    return {'links': results, 'violations': violations, 'causal_order': not violations,
            'start_bound': start is not None}


def _b64(raw):
    return base64.b64encode(raw).decode('ascii')


def unb64(text, limit=MAX_PACKET):
    """Canonical standard Base64 (RFC 4648 section 4), as section 8.4.1 uses."""
    need(type(text) is str and 0 < len(text) <= 4 * limit // 3 + 4, 'ROUGHTIME_BASE64')
    try:
        raw = base64.b64decode(text.encode('ascii'), validate=True)
    except (ValueError, UnicodeError):
        raise ValueError('ROUGHTIME_BASE64') from None
    need(_b64(raw) == text, 'ROUGHTIME_BASE64')
    return raw


def malfeasance_report(links):
    """The application/roughtime-malfeasance+json body for a verified chain (section 8.4.1).

    The first rand is omitted: outside AAP its nonce has no previous response.
    """
    checked = verify_chain(links)
    need(checked['violations'], 'ROUGHTIME_NO_MALFEASANCE')
    rows = []
    for position, link in enumerate(links):
        row = {'publicKey': _b64(key_bytes(link['public_key'])), 'request': _b64(link['request']),
               'response': _b64(link['response'])}
        if position:
            row['rand'] = _b64(link['rand'])
        rows.append(row)
    return {'responses': rows}


def verify_malfeasance_report(report):
    """Re-verify a section 8.4.1 report from its own bytes; it trusts no reporter."""
    need(type(report) is dict and set(report) == {'responses'} and type(report['responses']) is list, 'ROUGHTIME_REPORT')
    links = []
    for position, row in enumerate(report['responses']):
        need(type(row) is dict and {'publicKey', 'request', 'response'} <= set(row) <=
             {'publicKey', 'request', 'response', 'rand'} and (position == 0 or 'rand' in row), 'ROUGHTIME_REPORT')
        request_packet = unb64(row['request'])
        link = {'protocol': protocol_of(request_packet), 'public_key': unb64(row['publicKey'], 32).hex(),
                'request': request_packet, 'response': unb64(row['response'])}
        if position:
            link['rand'] = unb64(row['rand'], 64)
        links.append(link)
    checked = verify_chain(links)
    return {'responses': len(links), 'intervals': [[row['lower'], row['upper']] for row in checked['links']],
            'violations': checked['violations'], 'malfeasance_proven': bool(checked['violations']),
            'liar_identified': False}


def _address(text):
    need(type(text) is str and 0 < len(text) <= 300 and ':' in text, 'ROUGHTIME_ADDRESS')
    host, _, port = text.rpartition(':')
    if host.startswith('[') and host.endswith(']'):
        host = host[1:-1]
    need(host and port.isdigit() and 0 < int(port) < 65536, 'ROUGHTIME_ADDRESS')
    return host, int(port)


def udp_exchange(address, packet, timeout):
    """Send one datagram to an owner-supplied host:port and return one reply."""
    import socket
    host, port = _address(address)
    family, kind, proto, _name, target = socket.getaddrinfo(host, port, type=socket.SOCK_DGRAM)[0]
    with socket.socket(family, kind, proto) as channel:
        channel.settimeout(timeout)
        channel.sendto(packet, target)
        reply, _sender = channel.recvfrom(MAX_PACKET)
    return reply


def measure(servers, start, *, rounds=1, transport=None, monotonic=time.monotonic, random=os.urandom,
            timeout=3.0, attempts=2):
    """Query an explicit owner-supplied server list in sequence, chaining each nonce.

    ``servers`` rows: source, protocol, public_key and address. The first nonce
    derives from ``start``. Elapsed seconds run from each request to the end of
    the chain on the local monotonic clock, rounded up; seal evidence promptly.
    An invalid answer is discarded and retried, as section 7 requires.
    """
    need(type(rounds) is int and rounds in (1, 2) and type(servers) is list and
         1 <= len(servers) and len(servers) * rounds <= MAX_LINKS, 'ROUGHTIME_SERVERS')
    need(type(start) is bytes and start and type(attempts) is int and 1 <= attempts <= 5, 'ROUGHTIME_SERVERS')
    exchange = udp_exchange if transport is None else transport
    need(callable(exchange), 'ROUGHTIME_TRANSPORT')
    links, sent, previous = [], [], start
    for _round in range(rounds):
        for server in servers:
            need(type(server) is dict and set(server) == {'source', 'protocol', 'public_key', 'address'} and
                 server['protocol'] in PROTOCOLS, 'ROUGHTIME_SERVERS')
            protocol, failure = server['protocol'], 'ROUGHTIME_NO_VALID_RESPONSE'
            for _attempt in range(attempts):
                rand = random(NONCE_BYTES[protocol])
                packet = request(chain_nonce(previous, rand, protocol), protocol, public_key=server['public_key'])
                started = monotonic()
                try:
                    reply = exchange(server['address'], packet, timeout)
                    verify_response(packet, reply, server['public_key'], protocol)
                except (OSError, ValueError) as exc:
                    failure = str(exc) if isinstance(exc, ValueError) else 'ROUGHTIME_TRANSPORT'
                    continue
                break
            else:
                raise ValueError(failure)
            sent.append(started)
            links.append({'source': server['source'], 'rand': _b64(rand), 'request': _b64(packet), 'response': _b64(reply)})
            previous = reply
    end = monotonic()
    for link, started in zip(links, sent):
        link['elapsed_seconds'] = max(0, math.ceil(end - started))
    return links
