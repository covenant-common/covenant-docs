"""Self-issued sign-in: the agent or person is its own OpenID provider.

An owner-adopted option beside the hosted provider in signin.py. A relying party
accepts "Sign in with Covenant" without that host: the subject's wallet or agent
answers a Self-Issued OP request with an ID token it signs itself (iss equals
sub), and the relying party checks the signature against the subject's own key.

* did:aap and did:covenant: the account key the DID names, under the AAP DID
  document's verification method ``#account``; nothing to resolve.
* did:key (W3C CCG did:key v0.9): an Ed25519 Multikey; nothing to resolve.
* did:web and did:wba aliases: a DID document the relying party already holds,
  whose key is bound to an AAP key by the document's own proof or a
  covenant-did-binding/0.1 record (did_binding.py) and listed for authentication.
* urn:ietf:params:oauth:jwk-thumbprint:sha-256 (RFC 9278, RFC 7638): an OKP
  Ed25519 key carried in sub_jwk.

GRAFT, wire unchanged: OpenID Connect Self-Issued OpenID Provider v2, draft 13
(28 November 2023), sections 6.1, 7.2.1, 7.5, 8, 9, 10, 11.1, 11.2 and 15.1;
OpenID Connect Core 1.0 errata 2 section 2; JWS compact serialization (RFC 7515
section 7.1) with EdDSA (RFC 8037 section 3.1); JWT (RFC 7519); W3C DID Core 1.0
(Recommendation, 19 July 2022) sections 3.2 and 5.3.1. The account key signs the
JWS signing input, which never contains the 0x00 byte that follows the label of
every AAP-signed message, so a token cannot be replayed as an AAP record.

Not implemented: request objects (request, request_uri), signed requests,
OpenID Federation and DID client identifiers, ES256 subjects, encrypted ID tokens
and Verifiable Presentations (OpenID4VP). An accepted token proves that the
holder of the subject's key approved this client_id and nonce near iat; every
other claim is self-asserted (SIOP v2 section 13.1.1).
"""
from copy import deepcopy
import hmac
import re
import secrets
import threading
from urllib.parse import parse_qs, quote, urlencode, urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .crypto import canonical, integer, key, need, public_key
from . import did_binding
from . import interop_codec as codec
from .scale.identity import did, resolve_did

VERSION = 'covenant-self-issued/0.1'
SIOP = 'OpenID Connect Self-Issued OpenID Provider v2 draft 13 (2023-11-28)'
STATIC_AUDIENCE = 'https://self-issued.me/v2'
THUMBPRINT = 'urn:ietf:params:oauth:jwk-thumbprint'
THUMBPRINT_PREFIX = THUMBPRINT + ':sha-256:'
SYNTAX = ('did:aap', 'did:covenant', 'did:key', 'did:web', 'did:wba', THUMBPRINT)
RESPONSE_MODES = ('fragment', 'direct_post')
SCHEMES = ('siopv2', 'openid')
ALGORITHM = 'EdDSA'
MAX_TOKEN = 16384
MAX_LIFETIME = 3600
NONCE = re.compile(r'[\x21-\x7e]{16,512}\Z')
STATE = re.compile(r'[\x20-\x7e]{1,512}\Z')
ERRORS = {'SELF_ISSUED_SUBJECT_SYNTAX': 'subject_syntax_types_not_supported',
          'SELF_ISSUED_CLIENT_METADATA': 'invalid_client_metadata_object',
          'SELF_ISSUED_METADATA_VALUE': 'client_metadata_value_not_supported',
          'SELF_ISSUED_CLIENT': 'unauthorized_client',
          'SELF_ISSUED_USER_CANCELLED': 'user_cancelled'}

PROVES = ['the holder of the subject key signed this ID token for this client_id and nonce',
          'for did:web or did:wba subjects, that the key is bound to an AAP key by a signature of that key']
DOES_NOT_PROVE = ['legal identity, personhood, a balance or KYB; use hidden credentials or attribute proofs',
                  'any claim other than sub: self-issued claims are self-asserted (SIOP v2 section 13.1.1)',
                  'domain control for did:web or did:wba: the document bytes are what the relying party supplied',
                  'that the request reached the right device in a cross-device flow (SIOP v2 section 13.3)',
                  'authority to sign, spend or bind; execution_authorized is always false']

REMEDIATION = {
    'SELF_ISSUED_CLIENT': 'Use client_id equal to redirect_uri (SIOP v2 section 7.2.1) or a client the wallet registered.',
    'SELF_ISSUED_REDIRECT': 'Use an https redirect_uri (http only on loopback) without fragment or credentials.',
    'SELF_ISSUED_NONCE': 'Send a printable nonce of 16 to 512 characters and keep it to check the answer.',
    'SELF_ISSUED_STATE': 'Use printable ASCII state of at most 512 characters.',
    'SELF_ISSUED_REQUEST': 'Send response_type=id_token, scope with openid, id_token_type subject_signed_id_token, without request or request_uri.',
    'SELF_ISSUED_CLIENT_METADATA': 'Send client_metadata as a JSON object naming subject_syntax_types_supported.',
    'SELF_ISSUED_METADATA_VALUE': 'Ask for EdDSA ID tokens; this wallet signs with Ed25519 only.',
    'SELF_ISSUED_SUBJECT_SYNTAX': 'Accept did:aap, did:covenant, did:key, did:web, did:wba or the JWK thumbprint syntax.',
    'SELF_ISSUED_RESPONSE_MODE': 'Use response_mode fragment (same device) or direct_post (cross device).',
    'SELF_ISSUED_TOKEN': 'Supply a compact JWS of three base64url parts within 16 KiB.',
    'SELF_ISSUED_HEADER': 'Use a protected header of alg EdDSA, optional typ JWT and kid; no keys or crit in the header.',
    'SELF_ISSUED_CLAIMS': 'Include iss, sub, aud, nonce, iat and exp with the documented types.',
    'SELF_ISSUED_NOT_SELF_ISSUED': 'iss differs from sub: verify it as a hosted provider token instead.',
    'SELF_ISSUED_AUDIENCE': 'The token was issued to another client_id.',
    'SELF_ISSUED_NONCE_MISMATCH': 'The token answers another request; start a new sign-in.',
    'SELF_ISSUED_TIME': 'The token is expired, not yet valid, too old or lives longer than an hour.',
    'SELF_ISSUED_KID': 'Set kid to the DID URL of the verification method that signed (did:aap uses #account).',
    'SELF_ISSUED_SUB_JWK': 'Carry sub_jwk only for the JWK thumbprint syntax and never for a DID subject.',
    'SELF_ISSUED_THUMBPRINT': 'sub must be the RFC 9278 thumbprint URI of the Ed25519 key in sub_jwk.',
    'SELF_ISSUED_DOCUMENT_REQUIRED': 'Supply the did:web or did:wba document bytes you hold for this subject.',
    'SELF_ISSUED_KEY_NOT_BOUND': 'The signing key is listed but not bound to an AAP key by its own signature.',
    'SELF_ISSUED_CHAIN': 'The did:aap subject names another chain than the one you accept.',
    'SELF_ISSUED_SIGNATURE': 'The Ed25519 signature does not verify under the subject key.',
    'SELF_ISSUED_SIGNER': 'Sign with the private key of the subject named in the prepared token.',
    'SELF_ISSUED_ISSUER_NOT_ADOPTED': 'Adopt the hosted issuer pins or accept self-issued tokens before relying on this one.',
    'SELF_ISSUED_NONCE_UNKNOWN': 'This nonce was never issued here, has expired or was already used.',
    'SELF_ISSUED_NONCE_LIMIT': 'Too many sign-ins are pending; let some expire.',
    'SELF_ISSUED_STORE_STATE': 'The nonce store does not hold this relying party\'s state; use its own directory.',
    'SELF_ISSUED_STORE_WRITE': 'The nonce store could not be written; nothing was issued or consumed.',
}


def remediation(code):
    return REMEDIATION.get(code, did_binding.remediation(code))


def _loopback(host):
    return host in ('localhost', '127.0.0.1', '::1')


def _redirect(value):
    need(type(value) is str and 0 < len(value) <= 512 and value.isascii() and value.isprintable(), 'SELF_ISSUED_REDIRECT')
    try:
        parts = urlsplit(value)
        port = parts.port
    except ValueError:
        raise ValueError('SELF_ISSUED_REDIRECT') from None
    need(parts.scheme in ('https', 'http') and bool(parts.hostname) and not parts.fragment and parts.username is None
         and parts.password is None and (port is None or 0 < port < 65536), 'SELF_ISSUED_REDIRECT')
    need(parts.scheme == 'https' or _loopback(parts.hostname), 'SELF_ISSUED_REDIRECT')
    return value


def _client_id(value):
    need(type(value) is str and 0 < len(value) <= 512 and value.isascii() and value.isprintable(), 'SELF_ISSUED_CLIENT')
    return value


def _nonce(value):
    need(type(value) is str and NONCE.fullmatch(value) is not None, 'SELF_ISSUED_NONCE')
    return value


def _state(value):
    need(value is None or (type(value) is str and STATE.fullmatch(value) is not None), 'SELF_ISSUED_STATE')
    return value


def _syntax(values):
    need(type(values) in (list, tuple) and 1 <= len(values) <= len(SYNTAX) and len(set(values)) == len(values)
         and all(value in SYNTAX for value in values), 'SELF_ISSUED_SUBJECT_SYNTAX')
    return list(values)


def client_metadata(subject_syntax_types=SYNTAX):
    """RP metadata for a non-pre-registered client (SIOP v2 sections 7.3 and 7.5)."""
    return {'subject_syntax_types_supported': _syntax(subject_syntax_types), 'id_token_signed_response_alg': ALGORITHM}


def request(client_id, redirect_uri, nonce, *, state=None, response_mode='fragment', subject_syntax_types=SYNTAX,
            scheme='siopv2'):
    """A Self-Issued OP authorization request (SIOP v2 section 9) as parameters and an invocation URI.

    client_id equals redirect_uri (section 7.2.1): the request is unsigned and the
    wallet learns the relying party only from these parameters. Keep the nonce.
    """
    need(client_id == _redirect(redirect_uri), 'SELF_ISSUED_CLIENT')
    _nonce(nonce); _state(state)
    need(response_mode in RESPONSE_MODES, 'SELF_ISSUED_RESPONSE_MODE')
    need(scheme in SCHEMES, 'SELF_ISSUED_REQUEST')
    params = {'response_type': 'id_token', 'scope': 'openid', 'client_id': client_id, 'redirect_uri': redirect_uri,
              'nonce': nonce, 'id_token_type': 'subject_signed_id_token',
              'client_metadata': canonical(client_metadata(subject_syntax_types)).decode('ascii')}
    if response_mode != 'fragment':
        params['response_mode'] = response_mode
    if state is not None:
        params['state'] = state
    return {'parameters': params, 'uri': scheme + '://?' + urlencode(params, quote_via=quote),
            'nonce': nonce, 'state': state, 'version': VERSION, 'execution_authorized': False}


def parse_request(value, *, registered=None):
    """Wallet side: a bounded, checked request; ``origin`` is what to show the person before approving.

    ``registered`` maps pre-registered client_id to its redirect URIs (section 7.1);
    such a request must not carry client_metadata (section 7.4).
    """
    if type(value) is str:
        need(len(value) <= 8192 and value.isascii(), 'SELF_ISSUED_REQUEST')
        query = urlsplit(value).query if '://' in value else value
        parsed = parse_qs(query, keep_blank_values=True, max_num_fields=32)
        need(all(len(items) == 1 for items in parsed.values()), 'SELF_ISSUED_REQUEST')
        value = {name: items[0] for name, items in parsed.items()}
    need(type(value) is dict and all(type(item) is str for item in value.values()), 'SELF_ISSUED_REQUEST')
    need('request' not in value and 'request_uri' not in value and 'client_metadata_uri' not in value, 'SELF_ISSUED_REQUEST')
    need(value.get('response_type') == 'id_token' and 'openid' in value.get('scope', '').split(' '), 'SELF_ISSUED_REQUEST')
    need('subject_signed_id_token' in value.get('id_token_type', 'subject_signed_id_token').split(' '), 'SELF_ISSUED_REQUEST')
    redirect = _redirect(value.get('redirect_uri'))
    client = value.get('client_id')
    if client == redirect:
        try:
            metadata = codec.parse(value.get('client_metadata', ''), 4096, 4, 64)
        except ValueError:
            raise ValueError('SELF_ISSUED_CLIENT_METADATA') from None
        need(type(metadata) is dict and type(metadata.get('subject_syntax_types_supported')) is list,
             'SELF_ISSUED_CLIENT_METADATA')
        offered = metadata['subject_syntax_types_supported']
        need(all(type(item) is str for item in offered) and len(offered) <= 32, 'SELF_ISSUED_CLIENT_METADATA')
        need(metadata.get('id_token_signed_response_alg', ALGORITHM) == ALGORITHM, 'SELF_ISSUED_METADATA_VALUE')
        usable = [item for item in SYNTAX if item in offered or (item.startswith('did:') and 'did' in offered)]
        need(bool(usable), 'SELF_ISSUED_SUBJECT_SYNTAX')
    else:
        need(type(registered) is dict and client in registered and redirect in registered[client], 'SELF_ISSUED_CLIENT')
        need('client_metadata' not in value, 'SELF_ISSUED_CLIENT_METADATA')
        usable = list(SYNTAX)
    mode = value.get('response_mode', 'fragment')
    need(mode in RESPONSE_MODES, 'SELF_ISSUED_RESPONSE_MODE')
    return {'client_id': client, 'redirect_uri': redirect, 'nonce': _nonce(value.get('nonce')),
            'state': _state(value.get('state')), 'response_mode': mode, 'subject_syntax_types': usable,
            'origin': urlsplit(redirect).hostname, 'execution_authorized': False}


def _subject_syntax(subject):
    if subject.startswith(THUMBPRINT_PREFIX):
        return THUMBPRINT
    parts = subject.split(':')
    return 'did:' + parts[1] if len(parts) >= 3 and parts[0] == 'did' else None


def prepare_id_token(parsed, subject, *, now, lifetime=300, key_hex=None):
    """The unsigned Self-Issued ID token for ``subject``; sign its signing_input locally.

    ``subject`` is a did:aap/did:covenant, did:key, did:web or did:wba DID, or None for
    the JWK thumbprint syntax of ``key_hex``. For an alias DID, ``key_hex`` names
    the bound key that will sign; its verification method must be ``#key-1`` style
    and is given by the DID document the relying party holds.
    """
    need(type(parsed) is dict and {'client_id', 'nonce', 'subject_syntax_types'} <= set(parsed), 'SELF_ISSUED_REQUEST')
    integer(now); integer(lifetime, True)
    need(lifetime <= MAX_LIFETIME, 'SELF_ISSUED_TIME')
    header = {'alg': ALGORITHM, 'typ': 'JWT'}
    claims = {'aud': parsed['client_id'], 'nonce': _nonce(parsed['nonce']), 'iat': now, 'exp': now + lifetime}
    if subject is None:
        signer = key_hex
        jwk = codec.okp_jwk(key_hex)
        subject = THUMBPRINT_PREFIX + codec.jwk_thumbprint(key_hex)
        claims['sub_jwk'] = jwk
    else:
        need(type(subject) is str and 0 < len(subject) <= 2048, 'SELF_ISSUED_SUBJECT_SYNTAX')
        method = _subject_syntax(subject)
        if method in ('did:aap', 'did:covenant'):
            signer = resolve_did(subject)[1]
            header['kid'] = subject + '#account'
        elif method == 'did:key':
            text = subject[len('did:key:'):]
            signer = codec.from_multikey(text)
            header['kid'] = subject + '#' + text
        else:
            need(method in ('did:web', 'did:wba') and key_hex is not None, 'SELF_ISSUED_SUBJECT_SYNTAX')
            did_binding.parse_did(subject)
            signer = key_hex
            header['kid'] = subject + '#key-1'
    need(_subject_syntax(subject) in parsed['subject_syntax_types'], 'SELF_ISSUED_SUBJECT_SYNTAX')
    key(signer)
    claims.update(iss=subject, sub=subject)
    signing_input = codec.b64url(codec.jcs(header)) + '.' + codec.b64url(codec.jcs(claims))
    return {'header': header, 'claims': claims, 'signing_input': signing_input, 'required_signer': signer,
            'signature_created': False, 'execution_authorized': False}


def sign_id_token(prepared, private_key, *, kid=None):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred.

    ``kid`` overrides the default verification method for a did:web or did:wba alias.
    """
    need(isinstance(private_key, Ed25519PrivateKey) and public_key(private_key) == prepared['required_signer'],
         'SELF_ISSUED_SIGNER')
    header, claims = deepcopy(prepared['header']), prepared['claims']
    if kid is not None:
        need(type(kid) is str and kid.startswith(claims['sub'] + '#') and len(kid) <= 2300, 'SELF_ISSUED_KID')
        header['kid'] = kid
    signing_input = codec.b64url(codec.jcs(header)) + '.' + codec.b64url(codec.jcs(claims))
    return signing_input + '.' + codec.b64url(private_key.sign(signing_input.encode('ascii')))


def response(parsed, id_token):
    """The authorization response (section 10): a fragment redirect, or a direct_post form for the wallet to send."""
    fields = {'id_token': id_token}
    if parsed.get('state') is not None:
        fields['state'] = parsed['state']
    if parsed['response_mode'] == 'direct_post':
        return {'mode': 'direct_post', 'post': {'url': parsed['redirect_uri'], 'form': fields},
                'sent': False, 'execution_authorized': False}
    return {'mode': 'fragment', 'redirect': parsed['redirect_uri'] + '#' + urlencode(fields, quote_via=quote),
            'sent': False, 'execution_authorized': False}


def error_response(parsed_or_redirect, code, *, state=None):
    """A section 10.3 error redirect for a refused request; ``code`` is one of this module's codes."""
    redirect = parsed_or_redirect['redirect_uri'] if type(parsed_or_redirect) is dict else _redirect(parsed_or_redirect)
    fields = {'error': ERRORS.get(code, 'invalid_request'), 'error_description': code}
    if state is not None:
        fields['state'] = _state(state)
    return {'redirect': redirect + '#' + urlencode(fields, quote_via=quote), 'execution_authorized': False}


def _parts(token):
    need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.isascii() and token.count('.') == 2,
         'SELF_ISSUED_TOKEN')
    head, body, tail = token.split('.')
    try:
        header = codec.parse(codec.b64url_decode(head, 4096), 4096, 4, 32)
        claims = codec.parse(codec.b64url_decode(body, MAX_TOKEN), MAX_TOKEN, 8, 512)
        signature = codec.b64url_decode(tail, 64)
    except ValueError:
        raise ValueError('SELF_ISSUED_TOKEN') from None
    need(type(header) is dict and type(claims) is dict and len(signature) == 64, 'SELF_ISSUED_TOKEN')
    return head + '.' + body, header, claims, signature


def peek(token):
    """Unverified iss, sub and nonce of any compact JWS, to route it to its verifier. Never a trust decision."""
    need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.isascii() and token.count('.') == 2,
         'SELF_ISSUED_TOKEN')
    try:
        claims = codec.parse(codec.b64url_decode(token.split('.')[1], MAX_TOKEN), MAX_TOKEN, 8, 512)
    except ValueError:
        raise ValueError('SELF_ISSUED_TOKEN') from None
    need(type(claims) is dict, 'SELF_ISSUED_TOKEN')
    return {name: claims.get(name) for name in ('iss', 'sub', 'nonce')}


def _resolve(subject, header, claims, *, documents, bindings, now, chain, accept):
    syntax = _subject_syntax(subject)
    need(syntax in accept, 'SELF_ISSUED_SUBJECT_SYNTAX')
    kid = header.get('kid')
    if syntax == THUMBPRINT:
        need(type(claims.get('sub_jwk')) is dict, 'SELF_ISSUED_SUB_JWK')
        try:
            found = codec.from_okp_jwk(claims['sub_jwk'])
        except ValueError:
            raise ValueError('SELF_ISSUED_SUB_JWK') from None
        need(THUMBPRINT_PREFIX + codec.jwk_thumbprint(found) == subject, 'SELF_ISSUED_THUMBPRINT')
        return found, 'JWK_THUMBPRINT', None if chain is None else did(found, chain)
    need('sub_jwk' not in claims, 'SELF_ISSUED_SUB_JWK')
    if syntax in ('did:aap', 'did:covenant'):
        subject_chain, found = resolve_did(subject)
        need(chain is None or chain == subject_chain, 'SELF_ISSUED_CHAIN')
        need(kid == subject + '#account', 'SELF_ISSUED_KID')
        return found, 'SELF_CERTIFYING_DID', did(found, subject_chain)
    if syntax == 'did:key':
        text = subject[len('did:key:'):]
        try:
            found = codec.from_multikey(text)
        except ValueError:
            raise ValueError('SELF_ISSUED_SUBJECT_SYNTAX') from None
        need(kid == subject + '#' + text, 'SELF_ISSUED_KID')
        return found, 'SELF_CERTIFYING_DID', None if chain is None else did(found, chain)
    need(type(documents) is dict and subject in documents, 'SELF_ISSUED_DOCUMENT_REQUIRED')
    checked = did_binding.verify_document(subject, documents[subject])
    resolved = did_binding.resolve(subject, document=documents[subject], bindings=bindings, now=now)
    need(type(kid) is str and kid in checked['authentication'], 'SELF_ISSUED_KID')
    found = checked['keys'].get(kid)
    bound = [row for row in resolved['bound_keys'] if row['key'] == found]
    need(found is not None and resolved['status'] == 'BOUND' and bool(bound), 'SELF_ISSUED_KEY_NOT_BOUND')
    aliases = [alias for alias in resolved['aap_dids'] if resolve_did(alias)[1] == found
               and (chain is None or resolve_did(alias)[0] == chain)]
    aap = aliases[0] if aliases else None if chain is None else did(found, chain)
    return found, bound[0]['basis'], aap


def verify_id_token(id_token, *, client_id, nonce, now, max_age=300, clock_skew=0, documents=None, bindings=(),
                    chain=None, accept=SYNTAX):
    """Relying-party validation of a Self-Issued ID token (SIOP v2 section 11.1), offline.

    ``documents`` maps did:web or did:wba subjects to document bytes you already
    hold; ``chain`` maps self-certifying keys to did:aap accounts on that chain.
    """
    _client_id(client_id); _nonce(nonce); integer(now); integer(max_age, True); integer(clock_skew)
    need(max_age <= 86400 and clock_skew <= 120, 'SELF_ISSUED_TIME')
    accept = _syntax(accept)
    if chain is not None:
        key(chain)
    signing_input, header, claims, signature = _parts(id_token)
    need(set(header) <= {'alg', 'typ', 'kid'} and header.get('alg') == ALGORITHM
         and header.get('typ', 'JWT') == 'JWT' and (header.get('kid') is None or type(header['kid']) is str),
         'SELF_ISSUED_HEADER')
    need({'iss', 'sub', 'aud', 'nonce', 'iat', 'exp'} <= set(claims), 'SELF_ISSUED_CLAIMS')
    need(all(type(claims[name]) is str and 0 < len(claims[name]) <= 2048 for name in ('iss', 'sub', 'nonce')),
         'SELF_ISSUED_CLAIMS')
    need(claims['iss'] == claims['sub'], 'SELF_ISSUED_NOT_SELF_ISSUED')
    audience = [claims['aud']] if type(claims['aud']) is str else claims['aud']
    need(type(audience) is list and 1 <= len(audience) <= 8 and all(type(item) is str for item in audience),
         'SELF_ISSUED_CLAIMS')
    need(client_id in audience, 'SELF_ISSUED_AUDIENCE')
    need(len(audience) == 1 or claims.get('azp') == client_id, 'SELF_ISSUED_AUDIENCE')
    need(hmac.compare_digest(claims['nonce'].encode('utf-8'), nonce.encode('utf-8')), 'SELF_ISSUED_NONCE_MISMATCH')
    for name in ('iat', 'exp', 'nbf', 'auth_time'):
        if name in claims:
            need(type(claims[name]) is int and 0 <= claims[name] <= 2**53 - 1, 'SELF_ISSUED_CLAIMS')
    need(claims['iat'] < claims['exp'] <= claims['iat'] + MAX_LIFETIME and claims['iat'] <= now + clock_skew
         and now < claims['exp'] + clock_skew and now - claims['iat'] <= max_age + clock_skew, 'SELF_ISSUED_TIME')
    need('nbf' not in claims or claims['nbf'] <= now + clock_skew, 'SELF_ISSUED_TIME')
    found, basis, aap = _resolve(claims['sub'], header, claims, documents=documents, bindings=bindings, now=now,
                                 chain=chain, accept=accept)
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(found)).verify(signature, signing_input.encode('ascii'))
    except InvalidSignature:
        raise ValueError('SELF_ISSUED_SIGNATURE') from None
    return {'version': VERSION, 'path': 'SELF_ISSUED', 'self_issued': True, 'subject': claims['sub'],
            'syntax': _subject_syntax(claims['sub']), 'key': found, 'did_aap': aap,
            'account': None if aap is None else resolve_did(aap)[1], 'basis': basis,
            'claims': {name: deepcopy(claims[name]) for name in ('iss', 'sub', 'aud', 'nonce', 'iat', 'exp')},
            'nonce_checked': True, 'audience_checked': True, 'proves': list(PROVES),
            'does_not_prove': list(DOES_NOT_PROVE), 'execution_authorized': False}


def accept_sign_in(id_token, *, client_id, nonce, now, self_issued=True, hosted=None, **options):
    """Owner-adopted sign-in paths side by side: self-issued (iss equals sub) and/or one pinned hosted issuer.

    ``hosted`` is {'issuer', 'client_id', 'jwks'} for the RS256 provider of signin.py.
    The token's unverified iss only chooses which verifier runs; nothing is trusted from it.
    """
    claims = peek(id_token)
    need(type(self_issued) is bool, 'SELF_ISSUED_ISSUER_NOT_ADOPTED')
    if claims['iss'] is not None and claims['iss'] == claims['sub']:
        need(self_issued, 'SELF_ISSUED_ISSUER_NOT_ADOPTED')
        return verify_id_token(id_token, client_id=client_id, nonce=nonce, now=now, **options)
    need(type(hosted) is dict and set(hosted) == {'issuer', 'client_id', 'jwks'} and claims['iss'] == hosted['issuer'],
         'SELF_ISSUED_ISSUER_NOT_ADOPTED')
    from .signin import relying_party_check
    checked = relying_party_check(id_token, issuer=hosted['issuer'], client_id=hosted['client_id'], jwks=hosted['jwks'],
                                  nonce=nonce, now=now)
    return {'version': VERSION, 'path': 'HOSTED_PROVIDER', 'self_issued': False, 'subject': checked['subject'],
            'syntax': 'did:aap', 'key': checked['account'], 'did_aap': did(checked['account'], checked['chain']),
            'account': checked['account'], 'basis': 'PINNED_HOSTED_ISSUER_RS256', 'claims': checked['claims'],
            'nonce_checked': True, 'audience_checked': True, 'proves': list(PROVES[:1]),
            'does_not_prove': list(DOES_NOT_PROVE), 'execution_authorized': False}


class NonceBook:
    """Relying-party nonces: issued once, consumed once (SIOP v2 sections 11.1 and 11.2).

    Pass ``store`` (an owner directory, covenant-identity-store/0.1) to keep them
    across restarts; otherwise a restart forgets which nonces are outstanding.
    """

    def __init__(self, *, clock, ttl=300, store=None, relying_party='default', limit=4096):
        need(callable(clock), 'SELF_ISSUED_NONCE')
        integer(ttl, True); integer(limit, True)
        need(ttl <= 3600 and limit <= 65536, 'SELF_ISSUED_NONCE_LIMIT')
        self._clock, self._ttl, self._limit = clock, ttl, limit
        self._lock = threading.RLock()
        self._open = {}
        self._store = None
        if store is not None:
            from .identity_store import StateFile
            need(type(relying_party) is str and 0 < len(relying_party) <= 256 and relying_party.isascii(),
                 'SELF_ISSUED_STORE_STATE')
            self._store = StateFile(store, 'self-issued-nonces', kind='covenant-self-issued-nonces/0.1',
                                    context={'relying_party': relying_party})
            try:
                saved = self._store.load()
                if saved is not None:
                    need(type(saved) is dict and all(type(v) is int for v in saved.values()), 'SELF_ISSUED_STORE_STATE')
                    self._open = dict(saved)
            except BaseException:
                self._store.close()
                raise

    def close(self):
        if self._store is not None:
            self._store.close()

    def _now(self):
        now = self._clock()
        integer(now)
        return now

    def _save(self, undo):
        if self._store is None:
            return
        try:
            self._store.save(dict(self._open))
        except OSError:
            undo()
            raise ValueError('SELF_ISSUED_STORE_WRITE') from None

    def issue(self):
        with self._lock:
            now = self._now()
            for nonce in [n for n, expires in self._open.items() if expires <= now]:
                del self._open[nonce]
            need(len(self._open) < self._limit, 'SELF_ISSUED_NONCE_LIMIT')
            nonce = secrets.token_urlsafe(32)
            self._open[nonce] = now + self._ttl
            self._save(lambda: self._open.pop(nonce, None))
            return nonce

    def consume(self, nonce):
        with self._lock:
            now = self._now()
            expires = self._open.get(nonce) if type(nonce) is str else None
            need(expires is not None and now < expires, 'SELF_ISSUED_NONCE_UNKNOWN')
            del self._open[nonce]
            self._save(lambda: self._open.__setitem__(nonce, expires))
            return True

    def pending(self):
        with self._lock:
            return len(self._open)


def sign_in(id_token, *, client_id, nonces, **options):
    """Verify a token against a nonce this relying party issued, then spend that nonce once."""
    need(isinstance(nonces, NonceBook), 'SELF_ISSUED_NONCE_UNKNOWN')
    claimed = peek(id_token)['nonce']
    need(type(claimed) is str, 'SELF_ISSUED_CLAIMS')
    now = nonces._now()
    result = accept_sign_in(id_token, client_id=client_id, nonce=_nonce(claimed), now=now, **options)
    nonces.consume(claimed)
    return {**result, 'nonce_spent': True}


def discovery():
    """Static Self-Issued OP metadata for AAP wallets (SIOP v2 sections 6.1 and 15.1)."""
    return {'authorization_endpoint': 'siopv2:', 'issuer': STATIC_AUDIENCE, 'response_types_supported': ['id_token'],
            'scopes_supported': ['openid'], 'subject_types_supported': ['public'],
            'id_token_signing_alg_values_supported': [ALGORITHM], 'request_object_signing_alg_values_supported': [],
            'request_parameter_supported': False, 'request_uri_parameter_supported': False,
            'subject_syntax_types_supported': list(SYNTAX), 'id_token_types_supported': ['subject_signed_id_token'],
            'response_modes_supported': list(RESPONSE_MODES)}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_OPTIONAL_SIGN_IN', 'protocol': SIOP,
            'beside': 'covenant-signin-oidc/0.1 hosted provider (signin.py); both paths may be adopted together',
            'subject_syntax_types': list(SYNTAX), 'algorithm': 'EdDSA (Ed25519, RFC 8037)',
            'client_registration': 'CLIENT_ID_EQUALS_REDIRECT_URI_OR_PRE_REGISTERED',
            'not_implemented': ['request objects and request_uri', 'signed requests', 'OpenID Federation and DID client ids',
                                'ES256 or other non-Ed25519 subjects', 'encrypted ID tokens', 'OpenID4VP presentations'],
            'subject_privacy': 'DID_AAP_IS_A_PUBLIC_IDENTIFIER; USE_A_PER_RELYING_PARTY_DID_KEY_FOR_UNLINKABILITY',
            'replay': 'NONCEBOOK_ISSUES_AND_SPENDS_EACH_NONCE_ONCE', 'proves': list(PROVES),
            'does_not_prove': list(DOES_NOT_PROVE), 'remediation': dict(REMEDIATION), 'network_accessed': False,
            'execution_authorized': False}
