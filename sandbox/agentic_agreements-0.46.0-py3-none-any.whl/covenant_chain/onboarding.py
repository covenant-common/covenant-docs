"""Zero-friction onboarding above the existing agent and sponsor escrow.

The installable distribution is ``agentic-agreements``. The console
script ``covenant-agent`` already points at ``agent_server``. Prepared PyPI and
npm aliases repeat that script and vendor no second runtime. Nothing here is
published. Import packages keep the ``covenant`` prefix.

The free tier is an ``ECON_SPONSOR_CREATE`` payload. It escrows units the
issuer already holds. It does not mint, and it does not open a treasury beside
the sponsor escrow.
"""
from copy import deepcopy
import hashlib
import fcntl
from contextlib import contextmanager
from importlib.resources import files
import json
import os
import re
import stat
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from covenant_language._version import __version__
from covenant_language.safe_io import atomic_write, lock_file
from .crypto import canonical, digest, exact, integer, key, loads, need, public_key

VERSION = 'covenant-onboarding/0.1'
WELL_KNOWN = 'covenant-well-known/0.1'
CONSENSUS_CHANGE = None
PYPI_DISTRIBUTION = 'agentic-agreements'
CONSOLE_SCRIPT = 'covenant-agent'
NPM_PACKAGE = 'agentic-agreements'
ONE_LINE_PYPI = 'uvx --from agentic-agreements covenant-agent --keyless'
ONE_LINE_NPM = 'npx -y agentic-agreements'
VERIFICATION_METHODS = {'PASSKEY', 'PERSONHOOD', 'STAKE', 'IDENTITY'}
# Opt-in encrypted local identity. The plaintext identity.hex format is unchanged.
KEYSTORE_VERSION = 'covenant-encrypted-keystore/0.1'
KEYSTORE_FILE = 'identity.enc.json'
PASSPHRASE_ENV = 'COVENANT_KEY_PASSPHRASE'
SCRYPT_N = 2 ** 17
# At most 128 MiB and one default work factor per untrusted local document.
SCRYPT_LIMITS = {'n': (2 ** 15, 2 ** 17), 'r': (8, 8), 'p': (1, 1)}
VERIFIER_FILES = (
    'covenant_language/core.py',
    'implementations/js/verify.mjs',
    'implementations/rust/common-verify/src/lib.rs',
)


def task_catalog():
    """The maintained task map ships in the wheel; no checkout or URL is read."""
    document = json.loads(files(__package__).joinpath('data/agent_tasks.json').read_text('utf-8'))
    need(document['format'] == 'covenant-agent-tasks/0.1'
         and document['version'] == __version__, 'AGENT_TASK_CATALOG_VERSION')
    return document


def paid_work():
    """Discover the separate signed-work interface; never create custody here."""
    from covenant_agent.mcp import tool_descriptors
    from covenant_agent.owner_setup import handoff
    names = {'covenant_make', 'covenant_accept', 'covenant_deliver',
             'covenant_settle', 'covenant_verify', 'covenant_action',
             'covenant_obligations', 'covenant_evidence_export', 'covenant_evidence_import'}
    from .plain_words import golden_pointer
    return {'golden_path': golden_pointer(), 'format': 'covenant-paid-work-entry/0.1',
        'profile': 'covenant-bilateral/0.2', 'status': 'OWNER_SETUP_REQUIRED',
        'interface': {'module': 'covenant_agent.server',
                      'arguments': 'DIRECT_FIELDS_NOT_ACTION_PARAMETERS',
                      'tools': [deepcopy(t) for t in tool_descriptors() if t['name'] in names]},
        'owner_setup': {
            'readiness': handoff(),
            'synthetic_demo_command': ['python', '-m', 'covenant_agent.demo_setup',
                '--directory', '/OWNER_SELECTED_NEW_DIRECTORY'],
            'creates': ['FOUR_PRIVATE_ONE_KEY_TEST_CONFIGS', 'FUNDED_LOCAL_REFERENCE_AUTHORITY',
                        'KEY_FREE_MANIFEST_WITH_EXACT_HOST_COMMANDS'],
            'requires': ['EXPLICIT_OWNER_DECISION_TO_CREATE_SYNTHETIC_CUSTODY',
                         'NEW_DIRECTORY_UNDER_TRUSTED_PARENT'],
            'production': 'EACH_REAL_PARTY_INSTALLS_OWN_CUSTODY_AND_ADOPTS_ITS_PROVIDER'},
        'steps': ['OWNER_INSTALLS_CUSTODY_AND_PROVIDER', 'BUYER_MAKES_EXACT_TERMS',
                  'SELLER_ACCEPTS_EXACT_ENVELOPE', 'SELLER_DELIVERS_EXACT_BYTES',
                  'BUYER_RELEASES_OR_ADOPTED_REVIEWERS_DECIDE',
                  'RECIPIENT_INDEPENDENTLY_VERIFIES', 'RETRY_ORIGINAL_REQUEST_AFTER_LOST_REPLY'],
        'dispute': {'tool': 'covenant_action', 'name': 'work:covenant_decide',
                    'result': ['SUPPORTED', 'REFUTED', 'INDETERMINATE'],
                    'optional_paid_amount': 'EXACT_INTEGER_PARTIAL_AWARD_FOR_SUPPORTED_FINDING'},
        'after_purchase': {'summary': 'covenant_obligations',
                           'summary_labels': 'OBSERVED_FROM_INSTALLED_PROVIDER_VS_CLAIMED_SIGNED_ENVELOPES',
                           'evidence': ['covenant_evidence_export', 'covenant_evidence_import'],
                           'durable_store': 'OWNER_CONFIG_content_dir_PRIVATE_DIRECTORY',
                           'written_duties': 'NOT_EXTRACTED; PAYMENT_DOES_NOT_DISCHARGE_THEM'},
        'delivery': 'ASCII_CONTENT_OR_CONTENT_BASE64_FOR_EXACT_FILE_BYTES; SEPARATE_FILE_HANDOFF',
        'milestones': 'EXPLICIT_SEPARATE_ORDERS_OR_SEPARATELY_ADOPTED_COMPOSITION; NO_AUTOMATIC_MAPPING',
        'prior_draft': 'NO_CONVERSION_OR_INHERITED_ASSENT_FROM_MARKETPLACE_OR_PROSE_DRAFTS',
        'guide': 'docs/BILATERAL_WORK_ORDERS_02.html',
        'boundaries': ['SYNTHETIC_USDC_LABEL_IS_NOT_REAL_USDC',
                       'LOCAL_SQLITE_IS_NOT_DECENTRALIZED_FINALITY',
                       'PLAIN_PRIVATE_TEST_FILES_ARE_NOT_ENCRYPTED_CUSTODY'],
        'custody_created': False, 'agreement_signed': False, 'execution_authorized': False,
        'network_accessed': False, 'persisted': False, 'payment_verified': False}


def task_matches(query, limit=5):
    """Bounded phrase matching, offered as suggestions rather than interpretation."""
    need(type(query) is str and len(query) <= 400, 'AGENT_TASK_QUERY')
    need(type(limit) is int and 1 <= limit <= 256, 'AGENT_TASK_MATCH_LIMIT')
    words = re.findall(r'[a-z0-9]+', query.lower())
    normalized = ' ' + ' '.join(words) + ' '
    matches = []
    for route in task_catalog()['routes']:
        if query.strip().lower() == route['id']:
            score = 1000
        else:
            score = sum(4 + len(phrase.split()) for keyword in route['keywords']
                        if (phrase := ' '.join(re.findall(r'[a-z0-9]+', keyword.lower())))
                        and ' ' + phrase + ' ' in normalized)
        if score:
            matches.append({'id': route['id'], 'purpose': route['purpose'], 'score': score,
                'guide_call': {'tool': 'covenant_onboard', 'arguments': {
                    'action': 'guide', 'parameters': {'task': route['id']}}}})
    return sorted(matches, key=lambda row: (-row['score'], row['id']))[:limit]


def task_guide(*, query='', task=None, parameters=None):
    """Return exact local call schemas. Never infer missing terms or execute a call."""
    from .tool_input import ToolInputError, validate_schema
    need(type(query) is str and len(query) <= 400, 'AGENT_TASK_QUERY')
    need(task is None or (type(task) is str and 1 <= len(task) <= 80), 'AGENT_TASK_ID')
    need(parameters is None or type(parameters) is dict, 'AGENT_TASK_PARAMETERS')
    catalog = task_catalog()
    by_id = {row['id']: row for row in catalog['routes']}
    candidates = task_matches(query) if task is None else []
    selected = by_id.get(task)
    if task is None and candidates and (len(candidates) == 1
                                       or candidates[0]['score'] > candidates[1]['score']):
        selected = by_id[candidates[0]['id']]
    from .plain_words import golden_pointer
    # Lead with the model and a pointer; covenant_onboard start sends the exact calls once.
    result = {'golden_path': golden_pointer(), 'format': catalog['format'], 'version': __version__,
        'status': 'TASK_UNKNOWN' if task is not None and selected is None else 'SELECT_TASK',
        'matching': 'LOCAL_KEYWORD_SUGGESTIONS_NOT_SEMANTIC_INTERPRETATION',
        'validation': 'SCHEMA_ONLY_PRECONDITIONS_CHECKED_BY_CALLED_TOOL',
        'call_convention': 'NATIVE_MCP_TOOL_WITH_ACTION_AND_PARAMETERS',
        'candidates': candidates, 'task': None, 'next_call': None,
        'execution_authorized': False, 'automatic_assent': False,
        'publicly_published': False, 'network_accessed': False, 'persisted': False,
        'browser_required': False, 'public_discovery': catalog['public_discovery'],
        'first_draft_call': {'tool': 'covenant_onboard', 'arguments': {'action': 'start', 'parameters': {}}}}
    if selected is None:
        result['available_tasks'] = [{'id': row['id'], 'purpose': row['purpose']} for row in by_id.values()]
        return result
    result['task'] = {name: deepcopy(selected[name]) for name in (
        'id', 'purpose', 'native_tool', 'action', 'boundary')}
    result['input_schema'] = deepcopy(selected['input_schema'])
    chosen = {} if parameters is None else deepcopy(parameters)
    request = {'tool': selected['native_tool'], 'arguments': {
        'action': selected['action'], 'parameters': chosen}}
    result['request_template'] = {'tool': selected['native_tool'], 'arguments': {
        'action': selected['action'], 'parameters': {}}}
    result['missing_parameters'] = sorted(set(selected['required_parameters']) - set(chosen))
    try:
        validate_schema(request['arguments'], selected['input_schema'])
    except ToolInputError as exc:
        # Paths and constraints are schema-owned; no rejected value is repeated.
        result['status'] = 'NEEDS_PARAMETERS' if result['missing_parameters'] else 'INVALID_PARAMETERS'
        result['issues'] = deepcopy(exc.issues)
    else:
        result['status'] = 'READY_TO_CALL'
        result['next_call'] = request
        # A client that lists only the core profile reaches the same tool here.
        result['router_call'] = {'tool': 'covenant_call', 'arguments': deepcopy(request)}
    return result


def main():
    """Agent entry from an installed package, without MCP or a browser."""
    import argparse
    parser = argparse.ArgumentParser(description='Find an AAP task and its exact installed call schema. No execution.')
    parser.add_argument('--query', default='')
    parser.add_argument('--task')
    args = parser.parse_args()
    try:
        result = task_guide(query=args.query, task=args.task)
    except ValueError as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=True, sort_keys=True))
    return 0


def install_card():
    """One-line paths. The PyPI alias name collides with the console script on purpose."""
    return {
        'version': VERSION,
        'pypi_distribution': PYPI_DISTRIBUTION,
        'console_script': CONSOLE_SCRIPT,
        'one_line_pypi': ONE_LINE_PYPI,
        'one_line_alias_prepared_not_published': 'uvx covenant-agent --keyless',
        'npm_package': NPM_PACKAGE,
        'one_line_npm': ONE_LINE_NPM,
        'published': False,
        'vendors_second_runtime': False,
        'name_collision': (
            'covenant-agent is the console script of agentic-agreements. '
            'The prepared PyPI project of the same name is an unpublished alias '
            'and contains no Python modules.'
        ),
        'execution_authorized': False,
    }


def registry_listing():
    """MCP registry server card plus the collision note. Not a live registration."""
    card = install_card()
    server = {
        '$schema': 'https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json',
        'name': 'io.github.covenant-common/covenant-agent',
        'title': 'Agentic Agreements Protocol (AAP)',
        'description': 'Agentic Agreements Protocol (AAP): local keyless drafting, invites and verification.',
        'version': __version__,
        'repository': {'url': 'https://github.com/covenant-common/covenant', 'source': 'github'},
        'packages': [
            {
                'registryType': 'pypi',
                'identifier': PYPI_DISTRIBUTION,
                'version': __version__,
                'runtimeHint': 'uvx',
                'packageArguments': [{'type': 'named', 'name': '--keyless'}],
                'transport': {'type': 'stdio'},
            },
            {
                'registryType': 'npm',
                'identifier': NPM_PACKAGE,
                'version': __version__,
                'runtimeHint': 'npx',
                'packageArguments': [{'type': 'named', 'name': '--keyless'}],
                'transport': {'type': 'stdio'},
            },
        ],
    }
    return {
        'server': server,
        'covenant': card,
        'listed': False,
        'published': False,
        'implementation': 'covenant_chain.agent_server',
    }


def _keystore_aad(kdf):
    return canonical({'version': KEYSTORE_VERSION, 'kdf': kdf, 'cipher': 'AES-256-GCM'})


def _derive(passphrase, kdf):
    return Scrypt(salt=bytes.fromhex(kdf['salt']), length=32, n=kdf['n'], r=kdf['r'], p=kdf['p']).derive(
        passphrase.encode('utf-8'))


def seal_identity(secret, passphrase):
    """Encrypt a raw 32-byte Ed25519 seed under a passphrase. Returns the file document."""
    need(type(secret) is bytes and len(secret) == 32, 'LOCAL_KEY_FILE')
    need(type(passphrase) is str and 8 <= len(passphrase) <= 1024, 'LOCAL_KEY_PASSPHRASE')
    kdf = {'name': 'scrypt', 'n': SCRYPT_N, 'r': 8, 'p': 1, 'salt': os.urandom(16).hex()}
    nonce = os.urandom(12)
    sealed = AESGCM(_derive(passphrase, kdf)).encrypt(nonce, secret, _keystore_aad(kdf))
    return {'version': KEYSTORE_VERSION, 'kdf': kdf, 'cipher': 'AES-256-GCM', 'nonce': nonce.hex(),
            'ciphertext': sealed.hex()}


def open_identity(document, passphrase):
    """Return the raw seed. A wrong passphrase and a damaged file both refuse LOCAL_KEY_PASSPHRASE."""
    exact(document, 'version kdf cipher nonce ciphertext')
    need(document['version'] == KEYSTORE_VERSION and document['cipher'] == 'AES-256-GCM', 'LOCAL_KEY_FORMAT')
    kdf = document['kdf']
    exact(kdf, 'name n r p salt')
    need(kdf['name'] == 'scrypt', 'LOCAL_KEY_FORMAT')
    for name, (low, high) in SCRYPT_LIMITS.items():
        need(type(kdf[name]) is int and low <= kdf[name] <= high, 'LOCAL_KEY_FORMAT')
    need(kdf['n'] & (kdf['n'] - 1) == 0, 'LOCAL_KEY_FORMAT')
    for name, size in (('salt', 16), ('nonce', 12)):
        value = kdf[name] if name == 'salt' else document[name]
        need(type(value) is str and len(value) == 2 * size and all(c in '0123456789abcdef' for c in value), 'LOCAL_KEY_FORMAT')
    raw = document['ciphertext']
    need(type(raw) is str and len(raw) == 96 and all(c in '0123456789abcdef' for c in raw), 'LOCAL_KEY_FORMAT')
    need(type(passphrase) is str and 8 <= len(passphrase) <= 1024, 'LOCAL_KEY_PASSPHRASE')
    try:
        secret = AESGCM(_derive(passphrase, kdf)).decrypt(bytes.fromhex(document['nonce']), bytes.fromhex(raw),
                                                          _keystore_aad(kdf))
    except InvalidTag as exc:
        raise ValueError('LOCAL_KEY_PASSPHRASE') from exc
    need(len(secret) == 32, 'LOCAL_KEY_FILE')
    return secret


class LocalKeyStore:
    """One Ed25519 identity in an owner directory. Created on first use, never printed.

    With a passphrase, given here or in ``COVENANT_KEY_PASSPHRASE``, a new
    identity is written as ``identity.enc.json`` (covenant-encrypted-keystore/0.1:
    scrypt plus AES-256-GCM). Without one, ``identity.hex`` is written as before.
    An existing plaintext file still loads and is not rewritten. Both files
    present at once is refused. The passphrase is never logged or returned.

    Only an owner Python call or COVENANT_KEY_PASSPHRASE supplies a passphrase.
    Neither tools nor public onboarding requests accept it. This trusts the OS;
    encryption at rest cannot protect a key from its unlocked owner process.
    """
    def __init__(self, directory, passphrase=None):
        path = Path(directory)
        need(path.is_dir() and not path.is_symlink(), 'LOCAL_KEY_DIRECTORY')
        need(stat.S_IMODE(path.stat().st_mode) & 0o077 == 0, 'LOCAL_KEY_DIRECTORY')
        self.directory = path
        self.path = path / 'identity.hex'
        self.encrypted_path = path / KEYSTORE_FILE
        if passphrase is None:
            passphrase = os.environ.get(PASSPHRASE_ENV) or None
        need(passphrase is None or (type(passphrase) is str and 8 <= len(passphrase) <= 1024), 'LOCAL_KEY_PASSPHRASE')
        self._passphrase = passphrase

    def __repr__(self):
        return f'LocalKeyStore({str(self.directory)!r}, format={self.format!r})'

    @property
    def format(self):
        """'encrypted', 'plaintext', or None when nothing is stored yet."""
        if os.path.lexists(self.encrypted_path):
            return 'encrypted'
        if os.path.lexists(self.path):
            return 'plaintext'
        return None

    @contextmanager
    def _locked(self):
        fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            info = os.fstat(fd)
            need(info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'LOCAL_KEY_DIRECTORY')
            lock_file(fd)
            yield
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def ensure(self):
        with self._locked():
            need(not (os.path.lexists(self.path) and os.path.lexists(self.encrypted_path)), 'LOCAL_KEY_AMBIGUOUS')
            if self.format is None:
                raw = Ed25519PrivateKey.generate().private_bytes_raw()
                target = self.encrypted_path if self._passphrase is not None else self.path
                data = canonical(seal_identity(raw, self._passphrase)) if self._passphrase is not None else (raw.hex() + '\n').encode('ascii')
                atomic_write(target, data, mode=0o600, exclusive=True, follow_symlinks=False)
            return self._load()

    def _load(self):
        need(not (os.path.lexists(self.path) and os.path.lexists(self.encrypted_path)), 'LOCAL_KEY_AMBIGUOUS')
        encrypted = os.path.lexists(self.encrypted_path)
        target = self.encrypted_path if encrypted else self.path
        need(target.is_file() and not target.is_symlink(), 'LOCAL_KEY_FILE')
        fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            info = os.fstat(fd)
            need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid()
                 and stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_size <= (4096 if encrypted else 128), 'LOCAL_KEY_FILE')
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                raw = stream.read(4097 if encrypted else 129)
        finally:
            os.close(fd)
        if encrypted:
            need(self._passphrase is not None, 'LOCAL_KEY_PASSPHRASE_REQUIRED')
            return Ed25519PrivateKey.from_private_bytes(open_identity(loads(raw), self._passphrase))
        try:
            encoded = raw.decode('ascii').strip()
        except UnicodeError:
            raise ValueError('LOCAL_KEY_FILE') from None
        key(encoded)
        return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(encoded))

    def load(self):
        with self._locked():
            return self._load()

    def public(self):
        return public_key(self.ensure())


def free_tier_sponsor(*, resource, actors, operations, unit_fee, first_n, expiry, verification):
    """Payload for an existing sponsor escrow. The issuer must already hold ``budget``.

    ``first_n`` is a unit budget (``unit_fee * first_n``), which is what
    ``ECON_SPONSOR_CREATE`` can enforce. It is not a separate covenant counter
    and it is not a new pot.

    A PASSKEY verification is checked, not declared: ``verification`` also
    carries the subject's WebAuthn get() ``assertion`` and the issuer's
    ``relying_party`` (``webauthn.RelyingParty``), which registered the
    credential and issued the challenge. The assertion is verified against
    that stored record (WebAuthn Level 3 section 7.2), the challenge is spent
    and the credential stays bound to this subject. A key carried by the
    request is never used.
    """
    from . import webauthn
    from .economics import label
    label(resource)
    integer(unit_fee, True)
    integer(first_n, True)
    integer(expiry, True)
    need(1 <= first_n <= 64, 'FREE_TIER_COUNT')
    need(type(actors) is list and 1 <= len(actors) <= 256, 'SPONSOR_SCOPE')
    need(actors == sorted(set(actors)), 'SPONSOR_SCOPE')
    for actor in actors:
        key(actor)
    need(type(operations) is list and 1 <= len(operations) <= 64, 'SPONSOR_SCOPE')
    need(operations == sorted(set(operations)), 'SPONSOR_SCOPE')
    for op in operations:
        label(op)
    passkey = isinstance(verification, dict) and verification.get('method') == 'PASSKEY'
    if passkey:
        webauthn.require_assertion(verification.get('assertion'))
        exact(verification, 'method subject issuer_accepted assertion relying_party')
        party = webauthn.require_relying_party(verification['relying_party'])
    else:
        exact(verification, 'method subject issuer_accepted')
    need(verification['method'] in VERIFICATION_METHODS, 'FREE_TIER_VERIFICATION')
    key(verification['subject'])
    need(verification['issuer_accepted'] is True, 'FREE_TIER_VERIFICATION')
    need(verification['subject'] in actors, 'FREE_TIER_SUBJECT')
    per_actor = unit_fee * first_n
    integer(per_actor, True)
    budget = per_actor * len(actors)
    integer(budget, True)
    if passkey:
        # Last, so a refused request spends no challenge; the record is the relying party's, never the request's.
        proof = party.commit(party.verify(verification['subject'], verification['assertion']))
        recorded = {'method': 'PASSKEY', 'subject': verification['subject'], 'issuer_accepted': True, 'passkey': proof}
    else:
        recorded = deepcopy(verification)
    payload = {
        'resource': resource,
        'budget': budget,
        'actors': list(actors),
        'operations': list(operations),
        'per_actor_cap': per_actor,
        'expiry': expiry,
    }
    return {
        'version': VERSION,
        'operation': 'ECON_SPONSOR_CREATE',
        'payload': payload,
        'pot': 'EXISTING_SPONSOR_ESCROW',
        'new_treasury': False,
        'mint': False,
        'covenant_count': 'UNIT_BUDGET_NOT_A_SEPARATE_COUNTER',
        'first_n': first_n,
        'verification': recorded,
        'personhood_established': False,
        'execution_authorized': False,
        'submitted': False,
    }


def verifier_pins(root=None):
    """Content hashes of the verifiers that ship in this tree. Missing files are omitted."""
    base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    pins = []
    for relative in VERIFIER_FILES:
        path = base / relative
        if path.is_file() and not path.is_symlink():
            pins.append({'path': relative, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    return {
        'profile': 'covenant-common/0.1',
        'suite': 'Ed25519',
        'pins': pins,
        'native_reducer': 'PYTHON_APPLY_TRANSACTION_ONLY',
    }


def well_known(*, protocol, chain, profiles, fee_resource=None, arbiter_policy=None, root=None):
    """Locator document. No peer URLs, no account balances, no DNS dialing."""
    need(type(protocol) is str and 0 < len(protocol) <= 80, 'WELL_KNOWN_PROTOCOL')
    key(chain)
    need(type(profiles) is list and profiles == sorted(set(profiles)) and len(profiles) <= 64, 'WELL_KNOWN_PROFILES')
    for name in profiles:
        need(type(name) is str and 0 < len(name) <= 80, 'WELL_KNOWN_PROFILES')
    if fee_resource is not None:
        need(type(fee_resource) is str and 0 < len(fee_resource) <= 80, 'WELL_KNOWN_FEE')
    policy = arbiter_policy or 'DISTINCT_RESOLVER_AND_APPEAL_RESOLVER_REQUIRED_BY_BIND'
    need(type(policy) is str and 0 < len(policy) <= 200, 'WELL_KNOWN_ARBITER')
    document = {
        'version': WELL_KNOWN,
        'protocol': protocol,
        'chain': chain,
        'profiles': list(profiles),
        'fee_resource': fee_resource,
        'verifiers': verifier_pins(root),
        'arbiter_policy': policy,
        'endpoints': {
            'openapi': '/.well-known/openapi.json',
            'context': '/context',
            'record': '/record',
        },
        'state_dump': 'ADVISORY_ONLY_NOT_TRUTH',
        'dns_dialing': False,
        'locators_only': True,
        'peer_addresses_included': False,
    }
    canonical(document)
    return document


def agent_card_for_node(node):
    """Public card for the chain listener. It carries no tenant secret."""
    return {
        'name': 'Covenant chain node',
        'description': 'Public card for this chain listener. Agreement service authentication stays on its own module.',
        'version': '0.1',
        'supportedInterfaces': [],
        'capabilities': {},
        'defaultInputModes': ['application/json'],
        'defaultOutputModes': ['application/json'],
        'service': 'covenant_chain.a2a_agreement_service',
        'chain': node.chain_id,
        'execution_authorized': False,
    }


def well_known_for_node(node):
    genesis = node.genesis
    policy = (genesis.get('economics') or {}).get('fee_policy') or {}
    return well_known(
        protocol=genesis['protocol'],
        chain=node.chain_id,
        profiles=sorted(genesis.get('profiles') or {}),
        fee_resource=policy.get('resource'),
    )


def openapi_document():
    """OpenAPI 3.1 for the node RPC plus the onboarding tool names.

    MCP itself is stdio, not this HTTP server. ``/state`` is documented as an
    advisory dump. Tool argument schemas are served by ``covenant-agent --list-tools``.
    """
    from .tool_surface import DEFAULT_ALLOW
    node_get = {
        '/status': 'Consensus and process status. Not a substitute for a light-client proof.',
        '/context': 'Chain id, protocol and applied height.',
        '/record': 'One table row. Query table and key.',
        '/offers': 'Bounded offer page.',
        '/state': 'Rate-limited advisory dump. Proofs are /proof and /light-proof.',
        '/genesis': 'Configured genesis document.',
        '/blocks': 'Committed blocks from a height.',
        '/tx/{id}': 'One transaction or pending status.',
        '/evidence': 'Bounded consensus equivocation evidence seen by this node. Observation only; no penalty.',
        '/.well-known/covenant.json': 'Profiles, verifier pins and arbiter policy. Locators only.',
        '/.well-known/openapi.json': 'This document.',
    }
    node_post = {
        '/submit': 'Submit one signed transaction.',
        '/preview': 'Project one transaction. binding is false.',
        '/proof': 'State-record proof at the latest applied checkpoint.',
        '/light-proof': 'Light-client checkpoint bundle for one record.',
        '/light-proofs': 'Up to eight light-client bundles.',
        '/message': 'Authenticated consensus ingress.',
    }
    paths = {}
    for path, summary in node_get.items():
        paths[path] = {'get': {'summary': summary, 'responses': {'200': {'description': 'JSON'}}}}
    for path, summary in node_post.items():
        paths[path] = {'post': {'summary': summary, 'responses': {'200': {'description': 'JSON'}}}}
    document = {
        'openapi': '3.1.0',
        'info': {
            'title': 'Covenant node and agent surface',
            'version': __version__,
            'summary': 'Node HTTP plus the stdio MCP server covenant-agent.',
        },
        'paths': paths,
        'x-state-is-truth': False,
        'x-mcp': {
            'transport': 'stdio',
            'command': CONSOLE_SCRIPT,
            'implementation': 'covenant_chain.agent_server',
            'default_allow': {name: list(actions) for name, actions in sorted(DEFAULT_ALLOW.items())},
            'argument_schemas': 'covenant-agent --list-tools',
        },
    }
    return document


if __name__ == '__main__':
    raise SystemExit(main())
