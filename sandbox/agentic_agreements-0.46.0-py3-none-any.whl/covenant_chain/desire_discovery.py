"""Bounded desire-based discovery of arbitrary existing typed targets.

This is an application view, not a successor interpretation of signed network
events. Catalog text, attributes and graph edges are caller supplied claims.
Authenticated contextual opinions are reported separately from relevance and
graph position. None of these grants authority or certifies performance.

``objects`` contains exact dictionaries with target, title, description,
attributes and links. A target is the existing {kind, id} type (64 hex id).
``desire`` accepts query (Unicode lexical search), context (exact opinion scope),
requirements (exact top-level attribute values), strict_requirements (default
False), weights (relevance/pagerank/reputation; default 50/20/30), and trust_seeds
([{actor, weight}]). Known failed requirements exclude a candidate; missing
attributes remain UNKNOWN and are excluded only when strict_requirements=True.
No user-supplied code, regular expressions, network calls or connectors run.

Object PageRank accepts explicit [{from, to}] edges and [{target, weight}] seeds.
Without seeds, matched lexical relevance seeds it, or a uniform distribution
when there is no lexical match. Catalog links are adopted along with the supplied
objects. Unknown link destinations are reported and omitted; an explicit edge or
seed outside the selected catalog is rejected. Requirements never silently grow
the graph. Reputation uses only the selected network's verified events, exact
context and optional group. Copied (target, origin) evidence is counted once
across authors. All raw contradictions stay visible; only outcomes from authors
with positive adopted trust mass can conflict for reputation weighting. An
untrusted copy cannot erase a trusted report by contradicting its origin.
Trust-graph grants belong to their author: only that author's contradictory
ENDORSE outcomes at a subject/origin can remove that author's positive edge.
Another signer cannot revoke it by copying the origin with a negative claim.

Bounds: 256 objects, 4096 combined links/edges, 32 attributes/requirements, 64
query terms, 1 MiB canonical input, and the existing network's 2048-event bound.
"""
from copy import deepcopy
import hashlib
import re

from covenant_language.agentic import canonical
from .crypto import integer, key, need
from .agent_network import unpack
from .discovery_rank import pagerank
from .voting import target, target_id

VERSION = 'covenant-desire-discovery/0.1'
SCORE_SCALE = 1_000_000
MAX_OBJECTS = 256
MAX_EDGES = 4096
DEFAULT_WEIGHTS = {'relevance': 50, 'pagerank': 20, 'reputation': 30}


def _fields(value, allowed, required=()):
    need(type(value) is dict and set(required) <= set(value) <= set(allowed),
         'DESIRE_FIELDS')


def _text(value, limit, *, nonempty=False):
    need(type(value) is str and len(value.encode('utf-8')) <= limit
         and (not nonempty or bool(value)), 'DESIRE_TEXT')


def _tokens(value):
    return set(re.findall(r'\w+', value.casefold(), flags=re.UNICODE))


def _object(value):
    _fields(value, ('target', 'title', 'description', 'attributes', 'links'),
            ('target', 'title', 'description', 'attributes', 'links'))
    target(value['target'])
    _text(value['title'], 512, nonempty=True)
    _text(value['description'], 4096)
    attrs = value['attributes']
    need(type(attrs) is dict and len(attrs) <= 32, 'DESIRE_ATTRIBUTES')
    for name in attrs:
        _text(name, 128, nonempty=True)
    canonical(attrs)
    need(type(value['links']) is list and len(value['links']) <= 64,
         'DESIRE_LINKS')
    for link in value['links']:
        target(link)


def _desire(value):
    _fields(value, ('query', 'context', 'requirements', 'strict_requirements',
                    'weights', 'trust_seeds'))
    result = deepcopy(value)
    result.setdefault('query', '')
    result.setdefault('context', None)
    result.setdefault('requirements', {})
    result.setdefault('strict_requirements', False)
    _text(result['query'], 256)
    terms = _tokens(result['query'])
    need(len(terms) <= 64, 'DESIRE_QUERY_TERMS')
    if result['context'] is not None:
        _text(result['context'], 80, nonempty=True)
    need(type(result['strict_requirements']) is bool, 'DESIRE_STRICT')
    needs = result['requirements']
    need(type(needs) is dict and len(needs) <= 32, 'DESIRE_REQUIREMENTS')
    for name in needs:
        _text(name, 128, nonempty=True)
    canonical(needs)
    weights = result.get('weights', DEFAULT_WEIGHTS)
    _fields(weights, DEFAULT_WEIGHTS, DEFAULT_WEIGHTS)
    for value in weights.values():
        integer(value)
        need(value <= 10000, 'DESIRE_WEIGHT')
    need(sum(weights.values()) > 0, 'DESIRE_ZERO_WEIGHT')
    result['weights'] = deepcopy(weights)
    if 'trust_seeds' in result:
        seeds = result['trust_seeds']
        need(type(seeds) is list and 0 < len(seeds) <= 64,
             'DESIRE_TRUST_SEEDS')
        seen = set()
        for seed in seeds:
            _fields(seed, ('actor', 'weight'), ('actor', 'weight'))
            key(seed['actor'])
            integer(seed['weight'], True)
            need(seed['actor'] not in seen, 'DESIRE_DUPLICATE_TRUST_SEED')
            seen.add(seed['actor'])
        result['trust_seeds'] = sorted(seeds, key=lambda item: item['actor'])
    return result, terms


def _requirements(obj, desire):
    rows = []
    for name, expected in sorted(desire['requirements'].items()):
        if name not in obj['attributes']:
            state = 'UNKNOWN'
        else:
            state = ('MATCH' if canonical(obj['attributes'][name]) ==
                     canonical(expected) else 'MISMATCH')
        # Values themselves are already present in the caller's input catalog;
        # the diagnosis does not interpolate possibly sensitive contents.
        rows.append({'attribute': name, 'status': state})
    status = ('FAILED' if any(r['status'] == 'MISMATCH' for r in rows) else
              'UNKNOWN' if any(r['status'] == 'UNKNOWN' for r in rows) else
              'SATISFIED')
    eligible = status != 'FAILED' and not (
        desire['strict_requirements'] and status == 'UNKNOWN')
    return {'status': status, 'eligible': eligible, 'checks': rows,
            'basis': 'CALLER_SUPPLIED_ATTRIBUTES_NOT_VERIFIED_FACTS'}


def _relevance(obj, terms):
    if not terms:
        return SCORE_SCALE
    title = _tokens(obj['title'])
    description = _tokens(obj['description'])
    # Decode canonical JSON for Unicode terms instead of searching JSON's
    # ASCII escape sequences. This changes no attribute comparison semantics.
    import json
    attrs = _tokens(json.dumps(obj['attributes'], ensure_ascii=False,
                               sort_keys=True, separators=(',', ':')))
    points = sum(3 if word in title else 2 if word in description else
                 1 if word in attrs else 0 for word in terms)
    return SCORE_SCALE * points // (3 * len(terms))


def _reputation(network, desire, targets, group, now=None):
    context = desire['context']
    basis = 'NO_NETWORK'
    events = {}
    trust = {}
    seeds = {}
    trust_evidence = []
    ignored_external_endorsements = 0
    if network is None:
        need(group is None and 'trust_seeds' not in desire,
             'DESIRE_NETWORK_REQUIRED')
    else:
        events = network.events()  # Full signature and causal validation.
        if group is not None:
            key(group)
            need(group in events and events[group]['body']['kind'] == 'GROUP',
                 'DESIRE_GROUP')
        seeds = ({v['actor']: v['weight'] for v in desire['trust_seeds']}
                 if 'trust_seeds' in desire else dict(network.seeds))
        need(set(seeds) <= network.peers, 'DESIRE_TRUST_SEED_NOT_ADMITTED')
        basis = ('CALLER_ADOPTED_TRUST_SEEDS' if 'trust_seeds' in desire else
                 'OWNER_ADOPTED_NETWORK_SEEDS')
        # Each author's exact context-matched, internally unconflicted origin
        # can grant that author's edge. Another signer cannot revoke it by
        # copying the origin. External subjects never grow the rank graph.
        endorsements = {}
        for ref, event in sorted(events.items()):
            body = event['body']
            if body['kind'] != 'ENDORSE' or (group is not None and
                                             body['group'] != group):
                continue
            opinion = unpack(body)
            if 'result' not in opinion or 'origin' not in opinion or 'subject' not in opinion:
                continue
            from .network_incentives import endorsement_counts
            if not endorsement_counts(opinion, events, body['actor'], now):
                continue
            if context is None or opinion['context'] != context:
                continue
            entry = endorsements.setdefault((opinion['subject'], opinion['origin']),
                                             {'authors': set(), 'outcomes': set(),
                                              'author_outcomes': {}, 'events': []})
            entry['authors'].add(body['actor'])
            entry['outcomes'].add(opinion['result'])
            entry['author_outcomes'].setdefault(body['actor'], set()).add(opinion['result'])
            entry['events'].append(ref)
        edges = []
        for (subject, origin), entry in sorted(endorsements.items()):
            if subject not in network.peers:
                ignored_external_endorsements += 1
                continue
            edge_authors = sorted(author for author, values in entry['author_outcomes'].items()
                                  if values == {'POSITIVE'})
            edges.extend([[author, subject] for author in edge_authors])
            # References come from already authenticated envelopes. No external
            # origin is silently presented as a verified document.
            trust_evidence.append({'subject': subject, 'origin': origin,
                'authors': sorted(entry['authors']), 'outcomes': sorted(entry['outcomes']),
                'events': sorted(entry['events']),
                'raw_conflict': len(entry['outcomes']) > 1,
                'author_outcomes': {author: sorted(values) for author, values
                                    in sorted(entry['author_outcomes'].items())},
                'edge_authors': edge_authors,
                'adopted_positive_edges': bool(edge_authors)})
        trust = pagerank(sorted(network.peers), edges, seeds)
    records = {}
    ignored = 0
    for event_id, event in sorted(events.items()):
        body = event['body']
        if body['kind'] not in {'SIGNAL', 'ENDORSE'} or (group is not None and
                                                        body['group'] != group):
            continue
        opinion = unpack(body)
        if body['kind'] == 'ENDORSE':
            from .network_incentives import endorsement_counts
            if 'result' not in opinion or 'origin' not in opinion or not endorsement_counts(opinion, events, body['actor'], now):
                continue
        if context is None or opinion['context'] != context:
            continue
        subject = (opinion['target'] if body['kind'] == 'SIGNAL' else
                   {'kind': 'agent', 'id': opinion['subject']})
        sid = target_id(subject)
        if sid not in targets:
            ignored += 1
            continue
        value = opinion['signal'] if body['kind'] == 'SIGNAL' else opinion['result']
        entry = records.setdefault((sid, opinion['origin']),
                                   {'authors': set(), 'outcomes': set(),
                                    'outcome_authors': {}, 'engagement': set(),
                                    'events': []})
        entry['authors'].add(body['actor'])
        entry['events'].append(event_id)
        if value in {'POSITIVE', 'NEGATIVE', 'UNKNOWN'}:
            entry['outcomes'].add(value)
            entry['outcome_authors'].setdefault(value, set()).add(body['actor'])
        else:
            entry['engagement'].add(value)
    summaries = {}
    for sid in sorted(targets):
        rows = []
        counts = dict(positive_origins=0, negative_origins=0, unknown_origins=0,
                      conflicting_origins=0, promotion_origins=0,
                      recommendation_origins=0, weighted_conflicting_origins=0,
                      qualified_positive_origins=0, qualified_negative_origins=0,
                      qualified_unknown_origins=0)
        weighted = {'POSITIVE': 0, 'NEGATIVE': 0, 'UNKNOWN': 0}
        for (subject, origin), entry in sorted(records.items()):
            if subject != sid:
                continue
            outcomes = sorted(entry['outcomes'])
            conflict = len(outcomes) > 1
            outcome_mass = {outcome: max((trust.get(author, 0) for author in authors),
                                         default=0) for outcome, authors
                            in sorted(entry['outcome_authors'].items())}
            qualified = sorted(outcome for outcome, mass in outcome_mass.items() if mass > 0)
            weighted_conflict = len(qualified) > 1
            mass = max(outcome_mass.values(), default=0)
            if conflict:
                counts['conflicting_origins'] += 1
            elif outcomes:
                outcome = outcomes[0]
                counts[outcome.lower() + '_origins'] += 1
            if weighted_conflict:
                counts['weighted_conflicting_origins'] += 1
            elif qualified:
                outcome = qualified[0]
                counts['qualified_' + outcome.lower() + '_origins'] += 1
                weighted[outcome] += outcome_mass[outcome]
            counts['promotion_origins'] += int('PROMOTE' in entry['engagement'])
            counts['recommendation_origins'] += int('RECOMMEND' in entry['engagement'])
            rows.append({'origin': origin, 'authors': sorted(entry['authors']),
                         'outcomes': outcomes, 'engagement': sorted(entry['engagement']),
                         'outcome_authors': {outcome: sorted(authors) for outcome, authors
                                             in sorted(entry['outcome_authors'].items())},
                         'events': sorted(entry['events']), 'conflict': conflict,
                         'raw_conflict': conflict, 'weighted_conflict': weighted_conflict,
                         'qualified_outcomes': qualified,
                         'outcome_author_mass_ppb': outcome_mass,
                         'trusted_author_mass_ppb': mass})
        denominator = sum(weighted.values())
        reputation_score = (SCORE_SCALE // 2 if denominator == 0 else
                            SCORE_SCALE * (denominator + weighted['POSITIVE'] -
                                           weighted['NEGATIVE']) // (2 * denominator))
        summaries[sid] = {
            **counts, 'evidence': rows, 'score_ppm': reputation_score,
            'weighted_origin_mass': weighted,
            'status': ('CONTEXT_NOT_SELECTED' if context is None else
                       'NO_TRUSTED_UNCONFLICTED_OUTCOMES' if denominator == 0 else
                       'CONTEXTUAL_SIGNED_OPINIONS'),
            'origin_independence': 'NOT_ESTABLISHED',
            'reputation_is_authority_or_fact': False,
        }
    return summaries, {'context': context, 'group': group, 'trust_basis': basis,
                       'trust_seeds': [{'actor': actor, 'weight': weight}
                                       for actor, weight in sorted(seeds.items())],
                       'trust_graph_evidence': trust_evidence,
                       'external_endorsement_origins_excluded_from_trust_graph': ignored_external_endorsements,
                       'network_domain': network.domain if network is not None else None,
                       'network_snapshot': (hashlib.sha256(
                           b'COVENANT-DISCOVERY-NETWORK-SNAPSHOT-0.1\0' +
                           ''.join(sorted(events)).encode('ascii')).hexdigest()
                           if network is not None else None),
                       'trusted_actor_mass_ppb': [
                           {'actor': actor, 'mass_ppb': trust[actor]} for actor in sorted(trust)],
                       'unrelated_evidence_events_ignored': ignored,
                       'evidence_deduplication': 'ONE_TARGET_ORIGIN_ACROSS_AUTHORS',
                       'weighting_conflicts': 'ONLY_OUTCOMES_WITH_POSITIVE_ADOPTED_AUTHOR_MASS',
                       'trust_edge_grants': 'PER_AUTHOR_UNCONFLICTED_POSITIVE_SUBJECT_ORIGIN',
                       'promotions_recommendations_usage_are_positive_outcomes': False,
                       'scope': 'VERIFIED_LOCAL_REPLICA_NOT_GLOBAL_FRESHNESS'}


def discover(objects, desire, edges=None, seeds=None, network=None, group=None, now=None):
    """Return deterministic relevance, adopted PageRank and contextual evidence.

    Results contain excluded candidates as well as the eligible ranking. The
    default score is relevance 50, object PageRank 20 and outcome lower bound 30.
    The outcome bound is ``attributes['outcome_lb_bps']`` when that receipt view
    is present, and 0 when it is absent. Signed opinions do not move the default
    score. An explicit weight map still blends the opinion score.
    """
    need(type(objects) is list and len(objects) <= MAX_OBJECTS,
         'DESIRE_OBJECTS')
    parsed, terms = _desire(desire)
    input_size = len(canonical(parsed)) + len(objects) + 64
    for value in objects:
        _object(value)
        input_size += len(canonical(value))
        need(input_size <= 1_000_000, 'DESIRE_INPUT_SIZE')
    by_id = {target_id(obj['target']): deepcopy(obj) for obj in objects}
    need(len(by_id) == len(objects), 'DESIRE_DUPLICATE_TARGET')
    for obj in by_id.values():
        normalized = {target_id(dest): dest for dest in obj['links']}
        obj['links'] = [normalized[sid] for sid in sorted(normalized)]
    edges = [] if edges is None else edges
    need(type(edges) is list, 'DESIRE_EDGES')
    need(len(edges) + sum(len(obj['links']) for obj in objects) <= MAX_EDGES,
         'DESIRE_EDGE_LIMIT')
    links = []
    unknown = {}
    for source, obj in sorted(by_id.items()):
        for dest in obj['links']:
            destination = target_id(dest)
            if destination in by_id:
                links.append([source, destination])
            else:
                unknown[destination] = deepcopy(dest)
    for edge in edges:
        _fields(edge, ('from', 'to'), ('from', 'to'))
        source, destination = [target_id(edge[name]) for name in ('from', 'to')]
        need(source in by_id and destination in by_id, 'DESIRE_EDGE_UNKNOWN')
        input_size += len(canonical(edge))
        links.append([source, destination])
    requirements = {sid: _requirements(obj, parsed) for sid, obj in by_id.items()}
    relevance = {sid: _relevance(obj, terms) for sid, obj in by_id.items()}
    selected = sorted(sid for sid in by_id if requirements[sid]['eligible'])
    seed_weights = {}
    if seeds is not None:
        need(type(seeds) is list and 0 < len(seeds) <= MAX_OBJECTS,
             'DESIRE_SEEDS')
        for seed in seeds:
            _fields(seed, ('target', 'weight'), ('target', 'weight'))
            ref = target_id(seed['target'])
            integer(seed['weight'], True)
            need(ref in by_id and ref not in seed_weights, 'DESIRE_SEED_UNKNOWN_OR_DUPLICATE')
            need(ref in selected, 'DESIRE_SEED_REQUIREMENTS')
            input_size += len(canonical(seed))
            seed_weights[ref] = seed['weight']
        seed_basis = 'CALLER_ADOPTED_OBJECT_SEEDS'
    else:
        seed_weights = {sid: relevance[sid] for sid in selected if relevance[sid] > 0}
        seed_basis = 'DESIRE_LEXICAL_RELEVANCE'
        if not seed_weights:
            seed_weights = {sid: 1 for sid in selected}
            seed_basis = 'UNIFORM_NO_LEXICAL_MATCH'
    need(input_size <= 1_000_000, 'DESIRE_INPUT_SIZE')
    rank_edges = sorted({tuple(edge) for edge in links
                         if edge[0] in selected and edge[1] in selected})
    mass = (pagerank(selected, [list(edge) for edge in rank_edges], seed_weights)
            if selected else {})
    reputation, provenance = _reputation(network, parsed, by_id, group, now)
    max_mass = max(mass.values(), default=1)
    rows = []
    for sid, obj in sorted(by_id.items()):
        graph_score = SCORE_SCALE * mass.get(sid, 0) // max_mass
        opinion_ppm = reputation[sid]['score_ppm']
        bound = obj['attributes'].get('outcome_lb_bps')
        outcome_ppm = bound * SCORE_SCALE // 10000 if type(bound) is int and 0 <= bound <= 10000 else 0
        default_rank = parsed['weights'] == DEFAULT_WEIGHTS
        components = {'relevance': relevance[sid], 'pagerank': graph_score,
                      'reputation': outcome_ppm if default_rank else opinion_ppm}
        score = (sum(components[name] * weight for name, weight in parsed['weights'].items())
                 // sum(parsed['weights'].values()))
        rows.append({'target': obj['target'], 'title': obj['title'],
                     'requirements': requirements[sid], 'score_ppm': score,
                     'components_ppm': components, 'pagerank_mass_ppb': mass.get(sid, 0),
                     'reputation': reputation[sid]})
    ranked = sorted([row for row in rows if row['requirements']['eligible']],
                    key=lambda row: (-row['score_ppm'], target_id(row['target'])))
    excluded = sorted([row for row in rows if not row['requirements']['eligible']],
                      key=lambda row: target_id(row['target']))
    # Fingerprint supplied catalog and exact selection policy; no claim that the
    # caller's mutable metadata was an immutable, party-agreed statement.
    fingerprint = hashlib.sha256(b'COVENANT-DESIRE-DISCOVERY-0.1\0' + canonical({
        'catalog_sha256': hashlib.sha256(b''.join(
            canonical(by_id[sid]) for sid in sorted(by_id))).hexdigest(),
        'desire_sha256': hashlib.sha256(canonical(parsed)).hexdigest(),
        'edge_set_sha256': hashlib.sha256(b''.join(
            canonical([a, b]) for a, b in sorted(set(tuple(edge) for edge in links)))).hexdigest(),
        'seeds': [{'target': by_id[sid]['target'], 'weight': weight}
                  for sid, weight in sorted(seed_weights.items())],
        'group': group, 'network_snapshot': provenance['network_snapshot'],
        'trust_seeds': provenance['trust_seeds']})).hexdigest()
    return {'version': VERSION, 'selection': fingerprint, 'desire': parsed,
            'ranking': ranked, 'excluded': excluded,
            'status': 'RANKED' if ranked else 'NO_ELIGIBLE_OBJECTS',
            'graph': {'nodes': len(selected), 'edges': len(rank_edges),
                      'seed_basis': seed_basis,
                      'seeds': [{'target': by_id[sid]['target'], 'weight': weight}
                                for sid, weight in sorted(seed_weights.items())],
                      'unknown_link_targets': [unknown[sid] for sid in sorted(unknown)[:256]],
                      'unknown_link_targets_omitted': max(0, len(unknown) - 256),
                      'mass_ppb': sum(mass.values()),
                      'algorithm': 'BOUNDED_PERSONALIZED_PAGERANK'},
            'provenance': provenance,
            'catalog_attributes_graph_ownership_truth': 'CALLER_ADOPTED_NOT_ESTABLISHED',
            'verified_proof_or_connector_execution': False,
            'execution_authorized': False}
