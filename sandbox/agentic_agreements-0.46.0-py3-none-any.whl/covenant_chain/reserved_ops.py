"""Operation names covenant-native/0.15 reserves only to refuse.

These names exist so that a transaction asking for them is refused with a
stable code instead of UNKNOWN_OPERATION. On a chain running economics/0.3
(tokenomics), the reducer refuses each with the code below and leaves state
unchanged. tests/test_reserved_ops.py checks the reducer against this table,
so the table cannot drift from consensus. Nothing here changes consensus.
"""

OSSIFIED = 'OSSIFIED_FORBIDDEN'      # unbacked yield, mint, chance, reuse of collateral
MARKET_STAKE = 'USE_MARKET_STAKE'    # stakes and bonds are market STAKE_OPEN and friends
RESERVE_POT = 'USE_RESERVE_POT'      # treasury flows are the market_reserve pot

RESERVED = {
    'ECON_LIQUID_STAKE': OSSIFIED,
    'ECON_LOTTERY': OSSIFIED,
    'ECON_MINT': OSSIFIED,
    'ECON_RAFFLE': OSSIFIED,
    'ECON_REHYPOTHECATE': OSSIFIED,
    'LIQUID_STAKE': OSSIFIED,
    'STAKE_APY': OSSIFIED,
    'ECON_STAKE_CLAIM': MARKET_STAKE,
    'ECON_STAKE_DELEGATE': MARKET_STAKE,
    'ECON_STAKE_LOCK': MARKET_STAKE,
    'ECON_STAKE_SLASH': MARKET_STAKE,
    'ECON_STAKE_UNBOND': MARKET_STAKE,
    'ECON_STAKE_WITHDRAW': MARKET_STAKE,
    'ECON_STAKE_WORK': MARKET_STAKE,
    'ECON_TREASURY_INCOME': RESERVE_POT,
    'ECON_TREASURY_SPEND': RESERVE_POT,
}


def refusal(op):
    """The code a 0.15 tokenomics chain must refuse op with, or None if op is not reserved."""
    return RESERVED.get(op)
