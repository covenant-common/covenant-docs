"""Optional local password factors and scoped, signed delegation gates.

These are owner-installed LOCAL checks. They do not sign for another person,
replace native controller/payment quorums, consume challenges, or establish
external state. The owner supplies a trusted clock and current revocation state.
Password checks assume a trusted local host and protected outer channel; this is
not PAKE, a remote authentication server, rate limiting or password recovery.
"""
from copy import deepcopy
import hashlib
import hmac
import os
from pathlib import Path
from types import MethodType

from covenant_language import mechanism_plans as p
from .crypto import verify, verification_key

VERSION = 'covenant-delegation-grant/0.1'
POLICY_VERSION = 'covenant-access-policy/0.1'
CHALLENGE_VERSION = 'covenant-access-challenge/0.1'
GRANT_LABEL = 'COVENANT-DELEGATION-GRANT-0.1'
CHALLENGE_LABEL = 'COVENANT-ACCESS-CHALLENGE-0.1'
MAX_CHAIN = 8
MAX_CREDENTIAL_BYTES = 1024
SCRYPT_N, SCRYPT_R, SCRYPT_P = 16384, 8, 1


def _need(condition, code):
    if not condition:
        raise ValueError(code)


def _exact(value, names):
    _need(type(value) is dict and set(value) == set(names.split()), 'ACCESS_FIELDS')


def _integer(value, positive=False):
    _need(type(value) is int and (1 if positive else 0) <= value <= 2**53 - 1, 'ACCESS_INTEGER')


def _text(value, maximum=128):
    _need(type(value) is str and 0 < len(value) <= maximum, 'ACCESS_TEXT')


def _target(value):
    _exact(value, 'kind id')
    _text(value['kind'], 80)
    p.ref(value['id'])


def _capabilities(value):
    _need(type(value) is list and 1 <= len(value) <= 32, 'ACCESS_CAPABILITIES')
    for item in value:
        _text(item)
    _need(len(set(value)) == len(value), 'ACCESS_DUPLICATE_CAPABILITY')


def _same(left, right):
    return p.canonical(left) == p.canonical(right)


def validate_grant(record):
    p.canonical(record)
    _exact(record, 'version context target operation issuer delegate capabilities not_before expires nonce delegable parent supersedes')
    _need(record['version'] == VERSION, 'ACCESS_GRANT_VERSION')
    p.ref(record['context'])
    _target(record['target'])
    _text(record['operation'])
    verification_key(record['issuer'])
    verification_key(record['delegate'])
    _need(not _same(record['issuer'], record['delegate']), 'ACCESS_SELF_DELEGATION')
    _capabilities(record['capabilities'])
    _integer(record['not_before'])
    _integer(record['expires'], True)
    _need(record['not_before'] < record['expires'], 'ACCESS_GRANT_INTERVAL')
    p.ref(record['nonce'])
    _need(type(record['delegable']) is bool, 'ACCESS_DELEGABLE')
    for name in ('parent', 'supersedes'):
        if record[name] is not None:
            p.ref(record[name])
    return True


def grant_id(record):
    validate_grant(record)
    return p._id('COVENANT-DELEGATION-GRANT-0.1', record)


def grant_payload(record):
    return {'label': GRANT_LABEL,
        'body': {'grant': grant_id(record), 'context': record['context']},
        'execution_authorized': False}


def grant(context, target, operation, issuer, delegate, capabilities, not_before,
          expires, nonce, delegable=False, parent=None, supersedes=None):
    record = dict(version=VERSION, context=context, target=deepcopy(target),
        operation=operation, issuer=deepcopy(issuer), delegate=deepcopy(delegate),
        capabilities=deepcopy(capabilities), not_before=not_before, expires=expires,
        nonce=nonce, delegable=delegable, parent=parent, supersedes=supersedes)
    return {'id': grant_id(record), 'grant': record, **grant_payload(record),
        'authority': 'EXACT_ISSUER_SIGNATURE_REQUIRED_NOT_NATIVE_CONTROLLER_AUTHORITY'}


def amend_grant(before, changes):
    validate_grant(before)
    _need(type(changes) is dict and bool(changes) and set(changes) <= {
        'delegate', 'capabilities', 'not_before', 'expires', 'nonce', 'delegable'},
        'ACCESS_AMEND_FIELDS')
    record = {**deepcopy(before), **deepcopy(changes), 'supersedes': grant_id(before)}
    return {'id': grant_id(record), 'grant': record, **grant_payload(record),
        'fresh_issuer_signature_required': True,
        'prior_grant_invalidation': 'OWNER_MUST_ADOPT_SUCCESSOR_IN_CURRENT_REVOCATION_STATE'}


def verify_envelope(envelope):
    _exact(envelope, 'grant signature')
    record = envelope['grant']
    payload = grant_payload(record)
    verify(record['issuer'], payload['label'], payload['body'], envelope['signature'])
    return record


def verify_chain(chain, *, context, target, operation, subject, capability,
                 trusted_issuers, now, revoked=(), successors=None):
    """Check only the exact caller-pinned scope and supplied current state.

    The caller must authenticate freshness/completeness of issuer and revocation
    inputs. AccessDesk supplies these from its owner-held policy/state, never
    from a tool argument or the credential presented by the delegate.
    """
    p.ref(context); _target(target); _text(operation); verification_key(subject)
    _text(capability); _integer(now)
    _need(type(trusted_issuers) is list and 1 <= len(trusted_issuers) <= 32, 'ACCESS_TRUSTED_ISSUERS')
    for issuer in trusted_issuers:
        verification_key(issuer)
    _need(type(chain) is list and 1 <= len(chain) <= MAX_CHAIN, 'ACCESS_CHAIN_LIMIT')
    revoked = set(revoked)
    _need(len(revoked) <= 4096, 'ACCESS_REVOCATION_LIMIT')
    for ref in revoked:
        p.ref(ref)
    successors = {} if successors is None else successors
    _need(type(successors) is dict and len(successors) <= 4096, 'ACCESS_SUCCESSOR_STATE')
    for old, new in successors.items():
        p.ref(old); p.ref(new)
    seen = set(); actors = set(); nonces = set(); previous = None; root = None
    for envelope in chain:
        record = verify_envelope(envelope); ref = grant_id(record)
        _need(ref not in seen and record['nonce'] not in nonces, 'ACCESS_CHAIN_REPLAY')
        seen.add(ref); nonces.add(record['nonce'])
        _need(record['context'] == context and _same(record['target'], target)
            and record['operation'] == operation, 'ACCESS_SCOPE_MISMATCH')
        _need(record['not_before'] <= now < record['expires'], 'ACCESS_GRANT_EXPIRED_OR_NOT_YET_VALID')
        _need(ref not in revoked and ref not in successors, 'ACCESS_GRANT_REVOKED_OR_SUPERSEDED')
        if record['supersedes'] is not None:
            _need(successors.get(record['supersedes']) == ref, 'ACCESS_SUCCESSOR_NOT_ADOPTED')
        if previous is None:
            _need(record['parent'] is None and any(_same(record['issuer'], issuer)
                for issuer in trusted_issuers), 'ACCESS_UNTRUSTED_ROOT')
            actors.add(p.canonical(record['issuer'])); root = ref
        else:
            _need(previous['delegable'] and record['parent'] == grant_id(previous)
                and _same(record['issuer'], previous['delegate']), 'ACCESS_PARENT_AUTHORITY')
            _need(set(record['capabilities']) <= set(previous['capabilities']), 'ACCESS_CAPABILITY_WIDENING')
            _need(record['not_before'] >= previous['not_before']
                and record['expires'] <= previous['expires'], 'ACCESS_INTERVAL_WIDENING')
        actor = p.canonical(record['delegate'])
        _need(actor not in actors, 'ACCESS_DELEGATION_CYCLE')
        actors.add(actor); previous = record
    _need(_same(previous['delegate'], subject) and capability in previous['capabilities'], 'ACCESS_SUBJECT_OR_CAPABILITY')
    return {'verified': True, 'root': root, 'leaf': grant_id(previous),
        'subject': deepcopy(subject), 'capability': capability,
        'authority': 'EXACT_DELEGATED_SCOPE_NOT_NATIVE_SIGNING_OR_SETTLEMENT',
        'revocation': 'ONLY_AS_COMPLETE_AND_FRESH_AS_CALLER_TRUSTED_STATE',
        'execution_authorized': False}


def challenge_id(challenge):
    _exact(challenge, 'version policy context target operation subject capability request_hash call_context nonce not_before expires')
    _need(challenge['version'] == CHALLENGE_VERSION, 'ACCESS_CHALLENGE_VERSION')
    for name in ('policy', 'context', 'request_hash', 'call_context', 'nonce'):
        p.ref(challenge[name])
    _target(challenge['target']); _text(challenge['operation'])
    verification_key(challenge['subject']); _text(challenge['capability'])
    _integer(challenge['not_before']); _integer(challenge['expires'], True)
    _need(challenge['not_before'] < challenge['expires'], 'ACCESS_CHALLENGE_INTERVAL')
    return p._id('COVENANT-ACCESS-CHALLENGE-0.1', challenge)


def challenge_payload(challenge):
    return {'id': challenge_id(challenge), 'label': CHALLENGE_LABEL,
        'body': {'challenge': challenge_id(challenge), 'policy': challenge['policy'],
            'call_context': challenge['call_context']}, 'execution_authorized': False}


def _password_bytes(value):
    _need(type(value) is str, 'ACCESS_CREDENTIAL')
    encoded = value.encode('utf-8')
    _need(1 <= len(encoded) <= MAX_CREDENTIAL_BYTES, 'ACCESS_CREDENTIAL_SIZE')
    return encoded


class _PasswordVerifier:
    def __init__(self, password):
        self._salt = os.urandom(32)
        self._digest = self._derive(_password_bytes(password))

    def _derive(self, password):
        return hashlib.scrypt(password, salt=self._salt, n=SCRYPT_N,
            r=SCRYPT_R, p=SCRYPT_P, dklen=32, maxmem=64 * 1024 * 1024)

    def matches(self, password):
        return hmac.compare_digest(self._derive(_password_bytes(password)), self._digest)

    def __repr__(self):
        return '<Owner-held password verifier: redacted>'


class AccessDesk:
    """One owner-adopted scope and pure LOCAL access-factor callbacks.

    Owner-only setup can install credentials, issue/replace public challenges,
    and update revocations. Verification never consumes challenges or writes
    state. Repeated verification of an unchanged current challenge is allowed;
    single-use transactions require the separately adopted effect ledger.
    """
    def __init__(self, context, target, operation, capabilities, issuers, *, clock,
                 state_max_age=300, instance=None):
        p.ref(context); _target(target); _text(operation); _capabilities(capabilities)
        _need(type(issuers) is list and 1 <= len(issuers) <= 32, 'ACCESS_TRUSTED_ISSUERS')
        for issuer in issuers:
            verification_key(issuer)
        _need(len({p.canonical(issuer) for issuer in issuers}) == len(issuers), 'ACCESS_DUPLICATE_ISSUER')
        _need(callable(clock), 'ACCESS_TRUSTED_CLOCK')
        _integer(state_max_age, True); _need(state_max_age <= 3600, 'ACCESS_STATE_MAX_AGE')
        instance = os.urandom(32).hex() if instance is None else instance
        p.ref(instance)
        self.policy = dict(version=POLICY_VERSION, instance=instance, context=context, target=deepcopy(target),
            operation=operation, capabilities=deepcopy(capabilities), issuers=deepcopy(issuers),
            state_max_age=state_max_age)
        self.ref = p._id('COVENANT-ACCESS-POLICY-0.1', self.policy)
        self._policy_bytes = p.canonical(self.policy)
        self.clock = clock; self._passwords = {}; self._challenges = {}
        self._dummy = _PasswordVerifier(os.urandom(32).hex())
        self._sequence = -1; self._as_of = 0; self._valid_until = 0
        self._revoked = set(); self._successors = {}
        self.refresh_state()

    def __repr__(self):
        return '<AccessDesk policy=' + self.ref + ' credentials=redacted>'

    def _now(self):
        value = self.clock(); _integer(value)
        return value

    def _policy(self):
        _need(p.canonical(self.policy) == self._policy_bytes, 'ACCESS_POLICY_CHANGED')
        return self.policy

    def _fresh(self):
        self._policy(); now = self._now()
        _need(self._as_of <= now < self._valid_until, 'ACCESS_REVOCATION_STATE_STALE')
        return now

    def refresh_state(self, *, sequence=None, as_of=None, valid_until=None,
                      revoked=None, successors=None):
        """Owner-only adoption; the framework cannot prove remote completeness."""
        self._policy(); now = self._now()
        seq = self._sequence + 1 if sequence is None else sequence
        as_of = now if as_of is None else as_of
        valid_until = as_of + self.policy['state_max_age'] if valid_until is None else valid_until
        for value in (seq, as_of, valid_until):
            _integer(value)
        _need(seq > self._sequence and self._as_of <= as_of <= now < valid_until
            and 0 < valid_until - as_of <= self.policy['state_max_age'], 'ACCESS_STATE_FRESHNESS')
        extra = set(() if revoked is None else revoked)
        _need(len(extra | self._revoked) <= 4096, 'ACCESS_REVOCATION_LIMIT')
        for ref in extra:
            p.ref(ref)
        additions = {} if successors is None else successors
        _need(type(additions) is dict and len(set(additions) | set(self._successors)) <= 4096, 'ACCESS_SUCCESSOR_STATE')
        for old, new in additions.items():
            p.ref(old); p.ref(new)
            _need(old != new and (old not in self._successors or self._successors[old] == new), 'ACCESS_SUCCESSOR_CONFLICT')
        merged = {**self._successors, **additions}
        for start in merged:
            current = start; seen = set()
            while current in merged:
                _need(current not in seen, 'ACCESS_SUCCESSOR_CYCLE')
                seen.add(current); current = merged[current]
        self._sequence, self._as_of, self._valid_until = seq, as_of, valid_until
        self._revoked |= extra | set(additions)
        self._successors = merged

    def revoke(self, grant):
        p.ref(grant)
        self.refresh_state(revoked=[grant])

    def adopt_successor(self, before, after):
        first, second = verify_envelope(before), verify_envelope(after)
        _need(second['supersedes'] == grant_id(first)
            and all(_same(first[name], second[name]) for name in
                ('context', 'target', 'operation', 'issuer', 'parent')), 'ACCESS_SUCCESSOR_TRANSITION')
        _need(first['context'] == self.policy['context'] and _same(first['target'], self.policy['target'])
            and first['operation'] == self.policy['operation'], 'ACCESS_SCOPE_MISMATCH')
        self.refresh_state(successors={grant_id(first): grant_id(second)})

    def public_state(self):
        return dict(policy=self.ref, sequence=self._sequence, as_of=self._as_of,
            valid_until=self._valid_until, revoked=sorted(self._revoked),
            successors=deepcopy(self._successors), challenge_count=len(self._challenges),
            state_source='TRUSTED_OWNER_CLOCK_AND_REVOCATION_ADOPTION',
            custody='IN_MEMORY_OWNER_MUST_RESTORE_CURRENT_STATE_BEFORE_REUSING_A_RETAINED_INSTANCE',
            verification_consumes_challenge=False, execution_authorized=False)

    def set_password(self, subject, password):
        """Owner-only local enrollment. Neither plaintext nor verifier returned."""
        self._policy(); verification_key(subject)
        _need(len(self._passwords) < 256 or p.canonical(subject) in self._passwords, 'ACCESS_CREDENTIAL_LIMIT')
        self._passwords[p.canonical(subject)] = _PasswordVerifier(password)

    def _key(self, call_context, subject, capability, request_hash):
        return p.canonical([call_context, subject, capability, request_hash])

    def issue_challenge(self, call_context, subject, capability, request_hash, ttl=60, *, replace=False):
        now = self._fresh(); p.ref(call_context); verification_key(subject); _text(capability)
        p.ref(request_hash); _integer(ttl, True)
        _need(capability in self.policy['capabilities'] and ttl <= 300
            and type(replace) is bool, 'ACCESS_CHALLENGE_SCOPE_OR_TTL')
        key = self._key(call_context, subject, capability, request_hash)
        existing = self._challenges.get(key)
        if not replace and existing is not None and existing['not_before'] <= now < existing['expires']:
            challenge = deepcopy(existing)
            return {'challenge': challenge, **challenge_payload(challenge),
                'challenge_reused': True,
                'repeated_exact_verification': 'ALLOWED_WHILE_CURRENT_AND_UNEXPIRED_NOT_SINGLE_USE'}
        # Issuance is an owner mutation; pure verification never prunes state.
        self._challenges = {k: v for k, v in self._challenges.items() if now < v['expires']}
        _need(key in self._challenges or len(self._challenges) < 1024, 'ACCESS_CHALLENGE_LIMIT')
        challenge = dict(version=CHALLENGE_VERSION, policy=self.ref,
            context=self.policy['context'], target=deepcopy(self.policy['target']),
            operation=self.policy['operation'], subject=deepcopy(subject), capability=capability,
            request_hash=request_hash, call_context=call_context, nonce=os.urandom(32).hex(),
            not_before=now, expires=min(now + ttl, self._valid_until))
        challenge_id(challenge)
        self._challenges[key] = deepcopy(challenge)
        return {'challenge': challenge, **challenge_payload(challenge),
            'challenge_reused': False,
            'repeated_exact_verification': 'ALLOWED_WHILE_CURRENT_AND_UNEXPIRED_NOT_SINGLE_USE'}

    def _check_challenge(self, context, challenge):
        from .mechanism_runtime import call_context
        now = self._fresh()
        _need(type(context) is dict and context.get('context') == self.policy['context']
            and _same(context.get('target'), self.policy['target']), 'ACCESS_CONTEXT_OR_TARGET')
        parameters = context['parameters']; _exact(parameters, 'subject capability request_hash')
        verification_key(parameters['subject']); _text(parameters['capability']); p.ref(parameters['request_hash'])
        _need(parameters['capability'] in self.policy['capabilities'], 'ACCESS_CAPABILITY')
        _need(challenge_id(challenge) and challenge['policy'] == self.ref
            and challenge['context'] == self.policy['context']
            and _same(challenge['target'], self.policy['target'])
            and challenge['operation'] == self.policy['operation']
            and _same(challenge['subject'], parameters['subject'])
            and challenge['capability'] == parameters['capability']
            and challenge['request_hash'] == parameters['request_hash']
            and challenge['call_context'] == call_context(context)
            and challenge['not_before'] <= now < challenge['expires'], 'ACCESS_CHALLENGE_SCOPE_OR_EXPIRY')
        key = self._key(challenge['call_context'], challenge['subject'], challenge['capability'], challenge['request_hash'])
        _need(key in self._challenges and _same(challenge, self._challenges[key]), 'ACCESS_CHALLENGE_NOT_CURRENT')
        return now

    def password(self, context, evidence):
        try:
            _exact(evidence, 'challenge password')
            self._check_challenge(context, evidence['challenge'])
            subject = p.canonical(evidence['challenge']['subject'])
            verifier = self._passwords.get(subject, self._dummy)
            matched = verifier.matches(evidence['password'])
            return matched and subject in self._passwords
        except Exception:
            return False

    def delegation(self, context, evidence):
        try:
            _exact(evidence, 'challenge chain signature')
            challenge = evidence['challenge']; now = self._check_challenge(context, challenge)
            verify_chain(evidence['chain'], context=self.policy['context'], target=self.policy['target'],
                operation=self.policy['operation'], subject=challenge['subject'],
                capability=challenge['capability'], trusted_issuers=self.policy['issuers'], now=now,
                revoked=self._revoked, successors=self._successors)
            payload = challenge_payload(challenge)
            verify(challenge['subject'], payload['label'], payload['body'], evidence['signature'])
            return True
        except Exception:
            return False

    def install(self, registry, name='Scoped local access factors'):
        self._policy()
        implementation = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        semantics = p._id('COVENANT-ACCESS-SEMANTICS-0.1', {
            'policy': self.ref, 'chain_depth': MAX_CHAIN,
            'challenge': 'EXACT_PLAN_CALL_CONTEXT_TARGET_OPERATION_SUBJECT_CAPABILITY_REQUEST_HASH_NONCE_EXPIRY',
            'password': 'OWNER_HELD_SALTED_SCRYPT_LOCAL_FACTOR_NOT_KEY_POSSESSION',
            'state': 'OWNER_CLOCK_AND_CURRENT_REVOCATION_STATE_NOT_REMOTE_COMPLETENESS'})
        manifest = p.manifest(name, 'access', semantics, implementation, {
            'password': {'mode': 'LOCAL', 'description': 'Pure local password-factor check; no issuer impersonation or challenge consumption.'},
            'delegation': {'mode': 'LOCAL', 'description': 'Pure current-scope chain and delegate challenge-signature check.'}},
            assurances={'policy': deepcopy(self.policy), 'maximum_chain': MAX_CHAIN,
                'password_cost': {'n': SCRYPT_N, 'r': SCRYPT_R, 'p': SCRYPT_P},
                'native_controller_or_payment_authority': False, 'verification_writes_state': False},
            assumptions=['Trusted owner clock, credential custody and fresh complete revocation adoption.',
                'A retained owner instance may be reused only after current revocations and credential custody are restored.',
                'Passwords require a protected outer channel and owner rate controls; this is not PAKE.',
                'Current challenges are reused; forced replacement is a separate owner-only action.',
                'Exact checks can repeat; single-use effects and native approvals remain separate.'])['manifest']
        handlers = {'password': self.password, 'delegation': self.delegation}
        for operation, function in (('password', AccessDesk.password), ('delegation', AccessDesk.delegation)):
            handler = handlers[operation]
            _need(type(handler) is MethodType and handler.__self__ is self
                and handler.__func__ is function, 'ACCESS_HANDLER_CHANGED')
        ref = p.mechanism_id(manifest)
        if ref in registry.describe():
            for operation, expected in handlers.items():
                existing_manifest, handler, adapter = registry.get(ref, operation, 'LOCAL')
                _need(_same(existing_manifest, manifest) and adapter is None
                    and type(handler) is MethodType and handler.__self__ is self
                    and handler.__func__ is expected.__func__, 'ACCESS_INSTALLATION_CONFLICT')
            return ref
        return registry.register(manifest, handlers)
