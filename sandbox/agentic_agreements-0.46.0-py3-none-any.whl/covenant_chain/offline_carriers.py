"""Bounded byte carriers. Carrier success never certifies settlement."""
import hashlib
import io
import ipaddress
import os
from pathlib import Path
import re
import socket
import stat
import struct
import time

from covenant_language.safe_io import atomic_write

from . import crypto as c, offline as o

HEADER = struct.Struct('!4s32sHHIH')
MAGIC = b'CVF1'
MAX_FRAMES = 1024


def frames(raw, *, mtu=200):
    c.need(type(raw) is bytes and 0 < len(raw) <= o.MAX_PACKET, 'OFFLINE_FRAME_INPUT')
    c.need(type(mtu) is int and 128 <= mtu <= 1024, 'OFFLINE_MTU')
    size = mtu-HEADER.size; count = (len(raw)+size-1)//size
    c.need(count <= MAX_FRAMES, 'OFFLINE_FRAME_COUNT')
    digest = hashlib.sha256(raw).digest()
    return [HEADER.pack(MAGIC, digest, count, i, len(raw), size)+raw[i*size:(i+1)*size]
            for i in range(count)]


def _frame(raw):
    c.need(type(raw) is bytes and HEADER.size < len(raw) <= 1024, 'OFFLINE_FRAME_SIZE')
    magic, ref, count, index, total, size = HEADER.unpack(raw[:HEADER.size])
    c.need(magic == MAGIC and 82 <= size <= 978 and 0 < total <= o.MAX_PACKET and
           count == (total+size-1)//size and 1 <= count <= MAX_FRAMES and index < count,
           'OFFLINE_FRAME_HEADER')
    data = raw[HEADER.size:]
    c.need(len(data) == min(size, total-index*size), 'OFFLINE_FRAME_LENGTH')
    return ref.hex(), (count, total, size), index, data


class Reassembler:
    """Bounded untrusted fragments; first arrival fixes the expiry, not retries."""
    def __init__(self, *, max_sessions=8, max_bytes=131072, lifetime=600):
        c.need(type(max_sessions) is int and 1 <= max_sessions <= 16 and
               type(max_bytes) is int and o.MAX_PACKET <= max_bytes <= 1048576 and
               type(lifetime) is int and 1 <= lifetime <= 86400, 'OFFLINE_REASSEMBLY_POLICY')
        self.max_sessions, self.max_bytes, self.lifetime = max_sessions, max_bytes, lifetime
        self.sessions = {}

    def snapshot(self):
        return [{'at': v['at'], 'frames': [o.b64(HEADER.pack(MAGIC, bytes.fromhex(ref),
            v['meta'][0], i, v['meta'][1], v['meta'][2])+data) for i, data in sorted(v['parts'].items())]}
            for ref, v in sorted(self.sessions.items())]

    def restore(self, snapshot, *, now):
        c.integer(now)
        c.need(not self.sessions and type(snapshot) is list and len(snapshot) <= self.max_sessions,
               'OFFLINE_REASSEMBLY_SNAPSHOT')
        for item in snapshot:
            c.exact(item, 'at frames'); c.integer(item['at'])
            c.need(item['at'] <= now and type(item['frames']) is list and
                   1 <= len(item['frames']) <= MAX_FRAMES, 'OFFLINE_REASSEMBLY_SNAPSHOT')
            if now >= item['at']+self.lifetime:
                continue
            ref = None
            for encoded in item['frames']:
                raw = o.unb64(encoded, 1024); current, _, _, _ = _frame(raw)
                c.need(ref is None or current == ref, 'OFFLINE_REASSEMBLY_SNAPSHOT')
                ref = current
                c.need(self.accept(raw, now=now) is None, 'OFFLINE_REASSEMBLY_SNAPSHOT_COMPLETE')
            self.sessions[ref]['at'] = item['at']

    def expire(self, now):
        c.integer(now)
        self.sessions = {k: v for k, v in self.sessions.items() if v['at'] <= now < v['at']+self.lifetime}

    def accept(self, raw, *, now):
        ref, meta, index, data = _frame(raw); self.expire(now)
        if ref not in self.sessions:
            c.need(len(self.sessions) < self.max_sessions and
                   sum(v['meta'][1] for v in self.sessions.values())+meta[1] <= self.max_bytes,
                   'OFFLINE_REASSEMBLY_QUOTA')
            self.sessions[ref] = {'at': now, 'meta': meta, 'parts': {}}
        item = self.sessions[ref]
        c.need(item['meta'] == meta, 'OFFLINE_FRAME_CONFLICT')
        c.need(index not in item['parts'] or item['parts'][index] == data, 'OFFLINE_FRAME_CONFLICT')
        item['parts'][index] = data
        if len(item['parts']) != meta[0]:
            return None
        raw = b''.join(item['parts'][i] for i in range(meta[0])); del self.sessions[ref]
        c.need(hashlib.sha256(raw).hexdigest() == ref, 'OFFLINE_REASSEMBLY_HASH')
        return raw


def read_file(path, *, limit=o.MAX_PACKET):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        c.need(stat.S_ISREG(info.st_mode) and info.st_size <= limit, 'OFFLINE_FILE_SIZE_OR_TYPE')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(limit+1)
        c.need(len(raw) <= limit, 'OFFLINE_FILE_SIZE_OR_TYPE')
        return raw
    finally:
        os.close(fd)


def write_file(path, raw):
    """Exclusive private file; never follows a final symlink or overwrites."""
    c.need(type(raw) is bytes and len(raw) <= 2*1024*1024, 'OFFLINE_EXPORT_LIMIT')
    atomic_write(Path(path), raw, mode=0o600, exclusive=True, follow_symlinks=False)


def _png_chunk(tag, data):
    import zlib
    return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)


def _png_text(png, key):
    """Read one Latin-1 tEXt value. Used when zxing-cpp is not installed."""
    c.need(type(png) is bytes and png.startswith(b'\x89PNG\r\n\x1a\n'), 'OFFLINE_QR_CONTENT')
    index = 8
    wanted = key.encode('latin-1')
    while index + 12 <= len(png):
        length = struct.unpack('>I', png[index:index+4])[0]
        tag = png[index+4:index+8]
        c.need(index + 12 + length <= len(png), 'OFFLINE_QR_CONTENT')
        data = png[index+8:index+8+length]
        if tag == b'tEXt' and data.startswith(wanted + b'\x00'):
            return data[len(wanted)+1:].decode('latin-1')
        if tag == b'IEND':
            return None
        index += 12 + length
    return None


def _insert_text(png, key, value):
    c.need(png.startswith(b'\x89PNG\r\n\x1a\n'), 'OFFLINE_QR_CONTENT')
    chunk = _png_chunk(b'tEXt', key.encode('latin-1') + b'\x00' + value.encode('latin-1'))
    index = 8
    while index + 12 <= len(png):
        length = struct.unpack('>I', png[index:index+4])[0]
        tag = png[index+4:index+8]
        c.need(index + 12 + length <= len(png), 'OFFLINE_QR_CONTENT')
        if tag == b'IEND':
            return png[:index] + chunk + png[index:]
        index += 12 + length
    raise ValueError('OFFLINE_QR_CONTENT')


def _fallback_png(text):
    """A one-pixel PNG that still carries the frame when the qrcode package is absent."""
    import zlib
    signature = b'\x89PNG\r\n\x1a\n'
    ihdr = _png_chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 0, 0, 0, 0))
    ident = _png_chunk(b'IDAT', zlib.compress(b'\x00\x00'))
    end = _png_chunk(b'IEND', b'')
    return _insert_text(signature + ihdr + ident + end, 'Covenant-QR', text)


def qr_png(frame):
    """Render one encrypted frame. qrcode/Pillow when installed, otherwise a PNG fallback."""
    _frame(frame)
    text = 'COV1:' + o.b64(frame)
    try:
        import qrcode
        qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=6, border=4)
        qr.add_data(text)
        qr.make(fit=True)
        stream = io.BytesIO()
        qr.make_image(fill_color='black', back_color='white').save(stream, format='PNG')
        png = stream.getvalue()
    except Exception:
        png = _fallback_png(text)
    if _png_text(png, 'Covenant-QR') is None:
        png = _insert_text(png, 'Covenant-QR', text)
    return png


def _frame_from_text(text):
    c.need(type(text) is str and text.startswith('COV1:'), 'OFFLINE_QR_CONTENT')
    raw = o.unb64(text[5:], 1024)
    _frame(raw)
    return raw


def _qr_png_dimensions(png):
    """Validate the fixed PNG header before importing or invoking any decoder.

    A QR carrier only accepts PNG. In particular, other image plug-ins must not
    inspect an untrusted input before its format and raster size are bounded.
    This preflight does not decompress pixels or certify the embedded frame.
    """
    import zlib
    c.need(type(png) is bytes and len(png) <= 2*1024*1024, 'OFFLINE_QR_IMAGE_LIMIT')
    c.need(len(png) >= 33 and png[:8] == b'\x89PNG\r\n\x1a\n' and
           png[8:16] == b'\x00\x00\x00\x0dIHDR', 'OFFLINE_QR_CONTENT')
    header = png[16:29]
    c.need(zlib.crc32(b'IHDR' + header) & 0xffffffff ==
           struct.unpack('>I', png[29:33])[0], 'OFFLINE_QR_CONTENT')
    width, height, depth, color, compression, filtering, interlace = struct.unpack('>IIBBBBB', header)
    c.need(width > 0 and height > 0 and width*height <= 4000000, 'OFFLINE_QR_DIMENSIONS')
    depths = {0: (1, 2, 4, 8, 16), 2: (8, 16), 3: (1, 2, 4, 8),
              4: (8, 16), 6: (8, 16)}
    c.need(color in depths and depth in depths[color] and compression == 0 and
           filtering == 0 and interlace in (0, 1), 'OFFLINE_QR_CONTENT')
    return width, height


def scan_qr(png):
    """One visual frame or explicit PNG metadata fallback, never optical truth.

    Conflicting visual/text frames and multiple QR candidates fail closed. A
    minimal installation cannot inspect pixels: its metadata-only result still
    requires the signed packet and expected agreement to be verified separately.
    """
    dimensions = _qr_png_dimensions(png)
    text = _png_text(png, 'Covenant-QR')
    metadata_frame = _frame_from_text(text) if text is not None else None
    try:
        import PIL
        import zxingcpp
        # A core-only installation may already contain an older Pillow. Do not
        # select its native parsers merely because the optional modules import.
        # This adopted release range is a local dependency floor, not artifact
        # provenance or a claim that every future 13.x build has been audited.
        version = getattr(PIL, '__version__', None)
        c.need(type(version) is str and re.fullmatch(r'13\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)', version),
               'OFFLINE_QR_PILLOW_13_REQUIRED')
        from PIL import Image
    except ImportError:
        return metadata_frame if metadata_frame is not None else _frame_from_text(None)
    with Image.open(io.BytesIO(png), formats=('PNG',)) as image:
        c.need(image.format == 'PNG' and image.size == dimensions, 'OFFLINE_QR_DIMENSIONS')
        results = zxingcpp.read_barcodes(image, formats=zxingcpp.BarcodeFormat.QRCode)
    c.need(len(results) <= 1, 'OFFLINE_QR_AMBIGUOUS')
    if len(results) == 1 and results[0].valid:
        visual_frame = _frame_from_text(results[0].text)
        c.need(metadata_frame is None or metadata_frame == visual_frame, 'OFFLINE_QR_CONFLICT')
        return visual_frame
    return metadata_frame if metadata_frame is not None else _frame_from_text(None)


def _address(host):
    # Numeric addresses only; no DNS, proxies, redirects or remote URL selection.
    try:
        address = ipaddress.IPv4Address(host)
    except (ValueError, TypeError) as exc:
        raise ValueError('OFFLINE_LOCAL_IPV4_REQUIRED') from exc
    c.need((address.is_loopback or address in ipaddress.IPv4Network('10.0.0.0/8') or
            address in ipaddress.IPv4Network('172.16.0.0/12') or
            address in ipaddress.IPv4Network('192.168.0.0/16') or address.is_link_local)
           and not address.is_multicast and not address.is_unspecified, 'OFFLINE_LOCAL_IPV4_REQUIRED')
    c.need(str(address) not in ('169.254.169.254', '169.254.170.2'), 'OFFLINE_LOCAL_IPV4_REQUIRED')
    return str(address)


def send_local(raw, *, host, port, timeout=3):
    """Owner-selected LAN destination. No application ACK is inferred."""
    c.need(type(raw) is bytes and 0 < len(raw) <= o.MAX_PACKET, 'OFFLINE_LOCAL_SIZE')
    host = _address(host)
    c.need(type(port) is int and 1 <= port <= 65535 and type(timeout) in (int, float)
           and 0 < timeout <= 10, 'OFFLINE_LOCAL_POLICY')
    with socket.create_connection((host, port), timeout=timeout) as sock:
        timer = time.monotonic()+timeout
        sock.sendall(struct.pack('!I', len(raw))+raw)
        sock.settimeout(max(0.001, timer-time.monotonic()))
        c.need(sock.recv(1) == b'R', 'OFFLINE_LOCAL_UNCERTAIN')
    return {'transport': 'BYTES_RETAINED', 'recipient_verified': False, 'ledger_confirmed': False}


def receive_local(listener, retain, *, timeout=3):
    """One bounded connection on an owner-bound socket; authenticate in retain.

    retain(raw) must durably retain and validate before returning. This helper
    never starts a listener, exposes tools, or changes firewall/radio settings.
    """
    c.need(type(timeout) in (int, float) and 0 < timeout <= 10, 'OFFLINE_LOCAL_POLICY')
    _address(listener.getsockname()[0]); listener.settimeout(timeout)
    sock, _ = listener.accept()
    with sock:
        deadline = time.monotonic()+timeout
        def read_exact(size):
            chunks = []
            while size:
                remaining = deadline-time.monotonic()
                c.need(remaining > 0, 'OFFLINE_LOCAL_TIMEOUT'); sock.settimeout(remaining)
                chunk = sock.recv(size); c.need(bool(chunk), 'OFFLINE_LOCAL_TRUNCATED')
                chunks.append(chunk); size -= len(chunk)
            return b''.join(chunks)
        size, = struct.unpack('!I', read_exact(4))
        c.need(0 < size <= o.MAX_PACKET, 'OFFLINE_LOCAL_SIZE')
        raw = read_exact(size); result = retain(raw)
        sock.settimeout(max(0.001, deadline-time.monotonic())); sock.sendall(b'R')
        return result


class MeshtasticCarrier:
    """Use an owner-opened Serial/BLE/TCP interface. One paced frame per call."""
    def __init__(self, interface, *, destination, port=256, channel=0, interval=5, clock=time.monotonic):
        import re
        c.need(type(destination) is str and re.fullmatch(r'![0-9a-f]{8}', destination) is not None,
               'OFFLINE_MESH_UNICAST_REQUIRED')
        c.need(type(port) is int and 256 <= port <= 511 and type(channel) is int and 0 <= channel <= 7
               and type(interval) in (int, float) and 1 <= interval <= 3600, 'OFFLINE_MESH_POLICY')
        self.interface, self.destination, self.port, self.channel = interface, destination, port, channel
        self.interval, self.clock, self.next_send = interval, clock, 0

    def send(self, frame):
        _frame(frame); c.need(len(frame) <= 200, 'OFFLINE_MESH_FRAME_SIZE')
        now = self.clock(); c.need(now >= self.next_send, 'OFFLINE_MESH_PACING')
        # Reserve the interval even when the SDK fails: outcome may be uncertain.
        self.next_send = now+self.interval
        self.interface.sendData(frame, destinationId=self.destination, portNum=self.port,
            wantAck=True, wantResponse=False, channelIndex=self.channel)
        return {'transport': 'RADIO_SUBMITTED', 'recipient_verified': False, 'ledger_confirmed': False}

    def received_frame(self, packet):
        c.need(type(packet) is dict and packet.get('fromId') == self.destination,
               'OFFLINE_MESH_PEER')
        decoded = packet.get('decoded')
        port_value = decoded.get('portnum') if type(decoded) is dict else None
        port_matches = ((type(port_value) is int and port_value == self.port) or
                        (self.port == 256 and port_value == 'PRIVATE_APP'))
        c.need(type(decoded) is dict and port_matches and
               type(packet.get('channel', 0)) is int and packet.get('channel', 0) == self.channel,
               'OFFLINE_MESH_PORT_CHANNEL')
        raw = decoded.get('payload'); _frame(raw)
        c.need(len(raw) <= 200, 'OFFLINE_MESH_FRAME_SIZE')
        return raw


def canonical_payload(value):
    """The one carrier encoding. QR, BLE, mesh, NFC, and compact frames carry these bytes.

    A phone-shaped GPS value becomes integer microdegrees before the bytes are
    sealed. Floats never leave the device.
    """
    from .geo_fix import GPS_KEYS, normalize_claim

    def gps(item):
        if type(item) is dict and GPS_KEYS & set(item):
            return normalize_claim(item)
        if type(item) is dict:
            return {name: gps(child) if type(child) is dict else child for name, child in item.items()}
        if type(item) is list:
            return [gps(child) if type(child) in (dict, list) else child for child in item]
        return item

    if isinstance(value, (bytes, bytearray)):
        raw = bytes(value)
        out = c.canonical(gps(c.loads(raw)))
        c.need(out == raw, 'CARRIER_CANONICAL')
        return out
    c.need(type(value) is dict, 'CARRIER_CANONICAL')
    return c.canonical(gps(value))


def compact_frames(payload, chunk_len=512):
    """#61 content-id split. Joining restores the canonical payload bytes."""
    raw = payload if type(payload) is bytes else canonical_payload(payload)
    c.need(type(chunk_len) is int and 1 <= chunk_len <= 65535, 'COMPACT_FRAGMENT')
    c.need(0 < len(raw) <= o.MAX_PACKET, 'COMPACT_FRAGMENT')
    content_id = hashlib.sha256(raw).hexdigest()
    count = (len(raw) + chunk_len - 1) // chunk_len
    c.need(1 <= count <= 20000, 'COMPACT_FRAGMENT')
    frames = []
    for index in range(count):
        chunk = raw[index * chunk_len:(index + 1) * chunk_len]
        frames.append({'content_id': content_id, 'n': count, 'i': index, 'chunk': chunk.hex()})
    return frames


def compact_join(parts):
    c.need(type(parts) is list and 1 <= len(parts) <= 20000, 'COMPACT_FRAGMENT')
    ordered = [None] * len(parts)
    expected_n = None
    expected_id = None
    for part in parts:
        c.exact(part, 'content_id n i chunk')
        count, index = part['n'], part['i']
        c.integer(count, True)
        c.integer(index)
        c.need(count == len(parts) and index < count, 'COMPACT_FRAGMENT')
        if expected_n is None:
            expected_n, expected_id = count, part['content_id']
        c.need(count == expected_n and part['content_id'] == expected_id, 'COMPACT_FRAGMENT')
        c.need(type(part['content_id']) is str and len(part['content_id']) == 64, 'COMPACT_FRAGMENT')
        c.need(ordered[index] is None, 'COMPACT_FRAGMENT')
        text = part['chunk']
        c.need(type(text) is str and len(text) % 2 == 0, 'COMPACT_FRAGMENT')
        ordered[index] = bytes.fromhex(text)
    raw = b''.join(ordered)
    c.need(hashlib.sha256(raw).hexdigest() == expected_id, 'COMPACT_FRAGMENT')
    return raw


def describe_limits():
    """Byte-carrier bounds (salvaged Cursor PR 58). Carrier success never certifies settlement."""
    return {'magic': MAGIC.decode('ascii'), 'max_frames': MAX_FRAMES, 'execution_authorized': False}
