"""Optional DNS TXT lookup for the signed seed list.

``match_seed_txt`` checks records the caller already has. ``resolve_seed_list``
sends a TXT query to a literal resolver address the caller names. Nothing here
uses a system resolver or a default public DNS server.
"""
from __future__ import annotations

import ipaddress
import socket
import struct

from .crypto import need
from .discovery import match_seed_txt


def _encode_name(name):
    labels = name.split('.')
    raw = bytearray()
    for label in labels:
        encoded = label.encode('ascii')
        raw.append(len(encoded))
        raw.extend(encoded)
    raw.append(0)
    return bytes(raw)


def _decode_name(packet, offset):
    labels = []
    hops = 0
    while True:
        if offset >= len(packet) or hops > 16:
            raise ValueError('SEED_DNS_PACKET')
        length = packet[offset]
        if length == 0:
            return '.'.join(labels), offset + 1
        if length & 0xC0 == 0xC0:
            if offset + 1 >= len(packet):
                raise ValueError('SEED_DNS_PACKET')
            pointer = ((length & 0x3F) << 8) | packet[offset + 1]
            target, _ignored = _decode_name(packet, pointer)
            if labels:
                target = '.'.join(labels) + '.' + target if target else '.'.join(labels)
            return target, offset + 2
        offset += 1
        if offset + length > len(packet):
            raise ValueError('SEED_DNS_PACKET')
        labels.append(packet[offset:offset + length].decode('ascii'))
        offset += length
        hops += 1


def query_txt(name, server, port=53, timeout=2):
    """Ask one literal resolver for TXT records. Returns the decoded strings."""
    address = ipaddress.ip_address(server)
    need(type(name) is str and 1 < len(name) <= 253, 'SEED_NAME')
    need(type(port) is int and 1 <= port <= 65535, 'SEED_DNS_PORT')
    query_id = 0xC0DE
    header = struct.pack('>HHHHHH', query_id, 0x0100, 1, 0, 0, 0)
    message = header + _encode_name(name) + struct.pack('>HH', 16, 1)
    family = socket.AF_INET6 if address.version == 6 else socket.AF_INET
    sock = socket.socket(family, socket.SOCK_DGRAM)
    try:
        sock.settimeout(timeout)
        sock.sendto(message, (server, port))
        packet, _source = sock.recvfrom(2048)
    finally:
        sock.close()
    return _txt_answers(packet, query_id)


def _txt_answers(packet, query_id):
    if len(packet) < 12:
        raise ValueError('SEED_DNS_PACKET')
    ident, flags, qdcount, ancount, _ns, _ar = struct.unpack('>HHHHHH', packet[:12])
    need(ident == query_id and (flags & 0x000F) == 0, 'SEED_DNS_PACKET')
    offset = 12
    for _question in range(qdcount):
        _name, offset = _decode_name(packet, offset)
        offset += 4
    texts = []
    for _answer in range(ancount):
        _name, offset = _decode_name(packet, offset)
        if offset + 10 > len(packet):
            raise ValueError('SEED_DNS_PACKET')
        rtype, _rclass, _ttl, rdlength = struct.unpack('>HHIH', packet[offset:offset + 10])
        offset += 10
        rdata = packet[offset:offset + rdlength]
        offset += rdlength
        if rtype != 16:
            continue
        cursor = 0
        parts = []
        while cursor < len(rdata):
            size = rdata[cursor]
            cursor += 1
            parts.append(rdata[cursor:cursor + size].decode('ascii'))
            cursor += size
        texts.append(''.join(parts))
    return texts


def resolve_seed_list(seeds, now, server, port=53, timeout=2):
    """Resolve every seed name and require a TXT record signed by that operator."""
    txt_map = {}
    for operator in seeds['operators']:
        for name in operator['names']:
            txt_map[name] = query_txt(name, server, port, timeout)
    report = match_seed_txt(seeds, txt_map, now)
    report['dns_contacted'] = True
    report['resolver'] = server
    return report
