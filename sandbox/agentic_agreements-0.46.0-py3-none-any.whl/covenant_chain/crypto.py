"""Exact, bounded wire encoding and domain-separated sandbox authentication.

``COVENANT_RUST_ENCODING`` is ``off`` (default), ``shadow``, or ``on``.
``off`` is this module. ``shadow`` runs the ``covenant_encoding`` extension
beside it and raises ``ENCODING_DISAGREEMENT`` when the bytes or the owned
error codes differ. ``on`` returns the extension's result. Python remains
the normative encoder until that gate is the default.
"""
import hashlib
import json
import os
import re
import threading
from collections import OrderedDict
from covenant_language.key_validation import valid_ed25519_key
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.exceptions import InvalidSignature
MAX_BYTES = 4_000_000
HEX = re.compile(r'[0-9a-f]{64}\Z')

def need(ok, code):
    if not ok: raise ValueError(code)

def _encoding_mode():
    value = os.environ.get('COVENANT_RUST_ENCODING', 'off')
    need(value in {'off', 'shadow', 'on'}, 'ENCODING_MODE')
    return value

def _rust_encoding():
    try:
        import covenant_encoding
    except ImportError as exc:
        raise ValueError('ENCODING_UNAVAILABLE') from exc
    return covenant_encoding

def _same_encoding_failure(py_err, rust_err):
    if py_err is None or rust_err is None: return False
    if str(py_err) == str(rust_err): return True
    # Python keeps the decoder's message for malformed JSON. The extension
    # reports INVALID_JSON. Both refused the text.
    return str(rust_err) == 'INVALID_JSON' and type(py_err) is json.JSONDecodeError

def _shadow(py_fn, rust_fn):
    py_err = rust_err = None
    py_value = rust_value = None
    try: py_value = py_fn()
    except ValueError as exc: py_err = exc
    try: rust_value = rust_fn()
    except ValueError as exc: rust_err = exc
    if py_err is not None or rust_err is not None:
        if not _same_encoding_failure(py_err, rust_err): raise ValueError('ENCODING_DISAGREEMENT')
        raise py_err
    if py_value != rust_value: raise ValueError('ENCODING_DISAGREEMENT')
    return py_value

def check(value, depth=0):
    mode = _encoding_mode()
    if mode == 'off': return _check_py(value, depth)
    rust = _rust_encoding()
    if mode == 'on': return rust.check(value, depth)
    return _shadow(lambda: _check_py(value, depth), lambda: rust.check(value, depth))

def _check_py(value, depth=0):
    need(depth <= 40, 'DEPTH_LIMIT')
    if value is None or type(value) is bool: return
    if type(value) is int: need(abs(value) <= 2**53-1, 'INTEGER_RANGE')
    elif type(value) is str: need(len(value) <= 100000 and all(32 <= ord(c) <= 126 for c in value), 'ASCII_PROFILE')
    elif type(value) is list:
        need(len(value) <= 20000, 'ARRAY_LIMIT')
        for v in value: _check_py(v, depth+1)
    elif type(value) is dict:
        need(len(value) <= 20000, 'MAP_LIMIT')
        for k,v in value.items():
            need(type(k) is str and len(k) <= 256 and all(32 <= ord(c) <= 126 for c in k), 'MAP_KEY')
            _check_py(v, depth+1)
    else: raise ValueError('TYPE')

def _canonical_py(obj):
    _check_py(obj)
    raw=json.dumps(obj,sort_keys=True,separators=(',', ':'),ensure_ascii=True,allow_nan=False).encode('ascii')
    need(len(raw)<=MAX_BYTES,'SIZE_LIMIT')
    return raw

def canonical(obj):
    mode = _encoding_mode()
    if mode == 'off': return _canonical_py(obj)
    rust = _rust_encoding()
    if mode == 'on': return rust.canonical(obj)
    return _shadow(lambda: _canonical_py(obj), lambda: bytes(rust.canonical(obj)))

def loads(raw):
    mode = _encoding_mode()
    if mode == 'off': return _loads_py(raw)
    rust = _rust_encoding()
    if mode == 'on': return rust.loads(raw)
    return _shadow(lambda: _loads_py(raw), lambda: rust.loads(raw))

def _loads_py(raw):
    need(isinstance(raw,(str,bytes)) and len(raw)<=MAX_BYTES,'SIZE_LIMIT')
    def pairs(items):
        out={}
        for k,v in items:
            need(k not in out,'DUPLICATE_KEY');out[k]=v
        return out
    def bad(v): raise ValueError('NONINTEGER_NUMBER')
    try:
        if isinstance(raw, bytes): raw = raw.decode('utf-8')
        need(not raw.startswith('\ufeff'), 'JSON_BOM')
        obj=json.loads(raw,object_pairs_hook=pairs,parse_float=bad,parse_constant=bad)
    except (RecursionError, UnicodeError) as exc:
        raise ValueError('INVALID_JSON') from exc
    _canonical_py(obj)
    return obj

def digest(label,obj):
    return hashlib.sha256(label.encode('ascii')+b'\0'+canonical(obj)).hexdigest()

def public_key(key): return key.descriptor if hasattr(key,'descriptor') else key.public_key().public_bytes_raw().hex()
def sign(key,label,body):
    if hasattr(key,'sign_native'):return key.sign_native(label,body)
    return key.sign(label.encode('ascii')+b'\0'+canonical(body)).hex()
# Successful signature checks are pure functions of the key, the label, the
# signature and the canonical body. Gossip repeats those checks. Failures are
# not cached. Guarded continuity keys are not cached: pause and epoch are state.
_VERIFY_CACHE_MAX = 4096
_verify_cache = OrderedDict()
_verify_cache_lock = threading.Lock()
_verify_cache_enabled = True

def suspend_verify_cache():
    """Measure or test the uncached verifier. Does not change results either way."""
    class Guard:
        def __enter__(self):
            global _verify_cache_enabled
            self.previous = _verify_cache_enabled
            _verify_cache_enabled = False
            return self
        def __exit__(self, exc_type, exc, tb):
            global _verify_cache_enabled
            _verify_cache_enabled = self.previous
            return False
    return Guard()

def clear_verify_cache():
    with _verify_cache_lock:
        _verify_cache.clear()

def _cache_hit(token):
    if not _verify_cache_enabled:
        return False
    with _verify_cache_lock:
        if token not in _verify_cache:
            return False
        _verify_cache.move_to_end(token)
        return True

def _cache_store(token):
    if not _verify_cache_enabled:
        return
    with _verify_cache_lock:
        _verify_cache[token] = True
        _verify_cache.move_to_end(token)
        while len(_verify_cache) > _VERIFY_CACHE_MAX:
            _verify_cache.popitem(last=False)

def _message(label, body):
    return label.encode('ascii') + b'\0' + canonical(body)

def _token(identity, label, signature, message):
    return (identity, label, signature, hashlib.sha256(message).digest())

def verify(public,label,body,signature):
    if type(public) is dict and public.get('suite')=='covenant-controller-and-hash/0.1':
        from .guarded import verify_guarded
        return verify_guarded(public,label,body,signature)
    if type(public) is dict:
        verification_key(public)
        from pqcrypto.sign import ml_dsa_65
        need(type(signature) is str and re.fullmatch('[0-9a-f]+',signature) is not None and len(signature)==2*ml_dsa_65.SIGNATURE_SIZE,'PQ_SIGNATURE_ENCODING')
        message = _message(label, body)
        token = _token(canonical(public), label, signature, message)
        if _cache_hit(token):
            return True
        need(ml_dsa_65.verify(bytes.fromhex(public['key']), message, bytes.fromhex(signature)), 'SIGNATURE')
        _cache_store(token)
        return True
    need(type(public) is str and bool(HEX.fullmatch(public)) and valid_ed25519_key(public), 'PUBLIC_KEY')
    need(type(signature) is str and bool(re.fullmatch('[0-9a-f]{128}',signature)), 'SIGNATURE_ENCODING')
    try:
        message = _message(label, body)
        token = _token(public, label, signature, message)
        if not _cache_hit(token):
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(bytes.fromhex(signature), message)
            _cache_store(token)
    except (ValueError,InvalidSignature) as e: raise ValueError('SIGNATURE') from e
    return True

def exact(obj, fields): need(type(obj) is dict and set(obj)==set(fields.split()),'FIELDS')
def integer(v, positive=False): need(type(v) is int and (1 if positive else 0)<=v<=2**53-1,'INTEGER')
def key(v): need(type(v) is str and bool(HEX.fullmatch(v)),'KEY')

class PQPrivate:
    """Optional ML-DSA-65 key; native identity is distinct from this controller."""
    def __init__(self,public,secret):
        self.descriptor={'suite':'ML-DSA-65','key':public.hex()};self.secret=secret
        verification_key(self.descriptor)
        verify(self.descriptor,'COVENANT-KEY-POSSESSION',{},self.sign(b'COVENANT-KEY-POSSESSION\0{}').hex())
    def sign(self,message):
        from pqcrypto.sign import ml_dsa_65
        return ml_dsa_65.sign(self.secret,message)
    def private_record(self):return {'suite':'ML-DSA-65','public':self.descriptor['key'],'secret':self.secret.hex()}

def pq_keypair():
    from pqcrypto.sign import ml_dsa_65
    pub,secret=ml_dsa_65.generate_keypair();return PQPrivate(pub,secret)

def verification_key(value):
    if type(value) is str:
        key(value);need(valid_ed25519_key(value),'PUBLIC_KEY');return
    exact(value,'suite key');need(value['suite']=='ML-DSA-65','UNSUPPORTED_SIGNATURE_SUITE')
    from pqcrypto.sign import ml_dsa_65
    need(type(value['key']) is str and re.fullmatch('[0-9a-f]+',value['key']) is not None and len(value['key'])==2*ml_dsa_65.PUBLIC_KEY_SIZE,'PQ_PUBLIC_KEY')

class FieldError(ValueError):
    """A refusal that names the field, the expected shape, and the next step."""

    def __init__(self, code, path, expected, next_action):
        super().__init__(code)
        self.code = code
        self.path = path
        self.issues = [{'path': path, 'code': code, 'expected': expected}]
        self.next_action = next_action


def resolve_party(value, path):
    """A party is a verification key. A display name is PARTY_UNKEYED, not KEY."""
    if type(value) is str and HEX.fullmatch(value) is None:
        raise FieldError(
            'PARTY_UNKEYED', path, '^[0-9a-f]{64}$',
            f'{path} is a name. Replace it with that party\'s 64-character lowercase hex Ed25519 verification key.')
    try:
        verification_key(value)
    except ValueError as exc:
        code = str(exc)
        if code == 'KEY':
            code = 'PUBLIC_KEY'
        raise FieldError(
            code, path, '^[0-9a-f]{64}$',
            f'{path} must be a 64-character lowercase hex Ed25519 verification key.') from exc
    return value


def aesgcm_siv(key_bytes):
    """AES-GCM-SIV from cryptography>=50. Older builds get a refusal, not a traceback."""
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCMSIV
    except ImportError as exc:
        raise ValueError('CRYPTOGRAPHY_VERSION') from exc
    return AESGCMSIV(key_bytes)

def load_private(raw):
    raw=raw.strip()
    if raw.startswith('{'):
        obj=loads(raw);exact(obj,'suite public secret');need(obj['suite']=='ML-DSA-65','UNSUPPORTED_SIGNATURE_SUITE')
        return PQPrivate(bytes.fromhex(obj['public']),bytes.fromhex(obj['secret']))
    return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(raw))


def _migration_intent_document(genesis):
    """Exact 0.16 identity material, below application/proof/adoption layers.

    Only the recursive halt witness is omitted. Keep this leaf helper separate
    from migration validation: every historical crypto caller must not import
    the application state machine merely to compute a genesis identifier.
    """
    from copy import deepcopy
    from .profile import MIGRATION_VERSION
    need(type(genesis) is dict and genesis.get('protocol') == MIGRATION_VERSION, 'MIGRATION_NATIVE_PROFILE')
    canonical(genesis)
    out = deepcopy(genesis)
    if 'migration' in out:
        migration = out['migration']
        need(type(migration) is dict and type(migration.get('halt')) is dict, 'MIGRATION_FIELDS')
        need('statements' in migration['halt'], 'MIGRATION_HALT')
        migration['halt'].pop('statements')
    return out


def _migration_successor_digest(genesis):
    return digest('COVENANT-WORLD-MIGRATION-INTENT-0.2', _migration_intent_document(genesis))


def genesis_id(genesis):
    """Native identity. Historical profiles keep their exact full-document hash.

    Only native 0.16 adopts an exact intent independent of its recursive halt
    authorization witness. This function establishes identity, not validity;
    callers must still validate genesis through app.genesis_state.
    """
    from .profile import MIGRATION_VERSION
    if type(genesis) is dict and genesis.get('protocol') == MIGRATION_VERSION:
        return digest('COVENANT-GENESIS-0.16', {'intent': _migration_successor_digest(genesis)})
    return digest('COVENANT-GENESIS', genesis)
