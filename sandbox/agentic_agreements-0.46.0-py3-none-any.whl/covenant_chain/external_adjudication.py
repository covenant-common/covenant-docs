"""External adjudicators as ladder stages the parties name in advance: Internet Court, Kleros and UMA.

GRAFT through one adapter per adjudicator (``adjudicator_genlayer``,
``adjudicator_kleros``, ``adjudicator_uma``). Before any dispute exists, both
disputants sign adjudication terms (``urn:aap:external-adjudication:0.1``)
that fix:

* the AAP ladder stage the outside decision may inform: an OPTIMISTIC or
  JUDGMENT stage of an adopted escalation procedure, or the PRIMARY or APPEAL
  phase of a chain panel (the same binding ``arbitration_interop`` uses);
* the adjudicator by kind, network and pinned contract identity;
* the exact case: title, claim, typed criteria, evidence hashes and the AAP
  agreement it is about;
* an explicit table from the adjudicator's answers to AAP results.

``request`` returns the exact bytes that adjudicator needs. ``outcome`` takes
its published decision as bytes the owner supplies (nothing is fetched),
checks it against the pinned identity and the request, and returns an evidence
record for the agreed stage. ``ladder_step`` and ``panel_step`` prepare the one
ladder event that record supports, unsigned. The ladder still decides: an
outside ruling never opens or finalizes a ladder, moves escrow or closes an
appeal the parties kept; AAP's own signed terms decide any escrow effect.
"""
from copy import deepcopy
import re

from . import adjudicator_genlayer, adjudicator_kleros, adjudicator_uma
from . import arbitration_interop as interop
from .crypto import canonical, digest, key, need, verification_key, verify

VERSION = 'urn:aap:external-adjudication:0.1'
LABEL = 'AAP-EXTERNAL-ADJUDICATION-0.1'
REQUEST = 'urn:aap:external-adjudication-request:0.1'
RECORD = 'urn:aap:external-ruling-evidence:0.1'
FIELDS = ('version', 'ladder', 'parties', 'adjudicator', 'case', 'options', 'required_assurance')
ADAPTERS = {'GENLAYER': adjudicator_genlayer, 'KLEROS': adjudicator_kleros, 'UMA': adjudicator_uma}
MAPPINGS = ('MAPPED', 'NO_RESULT_FOR_ANSWER', 'REFUSED_TO_DECIDE')
MAX_TERMS = 65536
_ROLE = re.compile(r'[A-Za-z][A-Za-z0-9_.:-]{0,63}\Z')
_ADDRESS = re.compile(r'0x[0-9a-f]{40}\Z')
FLAGS = {'authority': 'EVIDENCE_ONLY', 'escrow_effect': 'DECIDED_BY_AAP_TERMS_AND_LADDER',
         'execution_authorized': False, 'submitted': False, 'network_accessed': False}

REMEDIATION = {
    'ADJUDICATION_TERMS': 'Use exactly the fields of terms_draft: version ladder parties adjudicator case options required_assurance.',
    'ADJUDICATION_VERSION': 'Use urn:aap:external-adjudication:0.1; a meaning change needs a new version string.',
    'ADJUDICATION_KIND': 'Name the adjudicator kind: GENLAYER (Internet Court), KLEROS or UMA.',
    'ADJUDICATION_PARTIES': 'Name claimant and respondent as {role, key, account}: distinct ladder roles, their AAP keys, lowercase 0x accounts or null.',
    'ADJUDICATION_CASE': 'Give case {title, claim, criteria, evidence, agreement}: printable text, a typed criteria map, sorted unique SHA-256 evidence hashes.',
    'ADJUDICATION_OPTIONS': 'List 2 to 16 options {answer, label, result}; each answer once, each non-null result once.',
    'ADJUDICATION_ASSURANCE': 'Choose required_assurance from the adapter list; a weaker supplied outcome is refused.',
    'ADJUDICATION_SIGNATURES': 'Supply exactly one signature from each of claimant and respondent over the exact terms.',
    'ADJUDICATION_SIZE': 'Keep the terms under 64 KiB of canonical JSON; reference long material by hash.',
    'ADJUDICATION_NOT_FINAL': 'The adjudicator has not published a final decision; wait for it, or climb the ladder without it.',
    'ADJUDICATION_RECORD': 'Pass the exact evidence record outcome returned and its id.',
    'ADJUDICATION_PANEL_RESULT': 'Panel results are {remedy, payee_bps, penalty}; procedure results are typed maps.',
}


def remediation(code):
    if code in REMEDIATION:
        return REMEDIATION[code]
    if code in interop.REMEDIATION:
        return interop.REMEDIATION[code]
    for kind in sorted(ADAPTERS):
        table = adapter(kind).REMEDIATION
        if code in table:
            return table[code]
    from .evm_evidence import remediation as evm_remediation
    return evm_remediation(code)


def adapter(kind):
    need(type(kind) is str and kind in ADAPTERS, 'ADJUDICATION_KIND')
    return ADAPTERS[kind]


def _text(value, limit, code, lines=False):
    allowed = (lambda c: 32 <= ord(c) <= 126 or (lines and c == '\n'))
    need(type(value) is str and 0 < len(value) <= limit and all(allowed(c) for c in value), code)


def _case(case):
    from covenant_language.agreement_application import typed_map
    need(type(case) is dict and set(case) == {'title', 'claim', 'criteria', 'evidence', 'agreement'}, 'ADJUDICATION_CASE')
    _text(case['title'], 200, 'ADJUDICATION_CASE'); _text(case['claim'], 8000, 'ADJUDICATION_CASE')
    need(type(case['criteria']) is dict and 1 <= len(case['criteria']) <= 32, 'ADJUDICATION_CASE')
    typed_map(case['criteria'])
    evidence = case['evidence']
    need(type(evidence) is list and len(evidence) <= 32, 'ADJUDICATION_CASE')
    for item in evidence: key(item)
    need(evidence == sorted(set(evidence)), 'ADJUDICATION_CASE')
    key(case['agreement'])


def _parties(parties):
    need(type(parties) is dict and set(parties) == {'claimant', 'respondent'}, 'ADJUDICATION_PARTIES')
    for side in parties.values():
        need(type(side) is dict and set(side) == {'role', 'key', 'account'}, 'ADJUDICATION_PARTIES')
        need(type(side['role']) is str and _ROLE.match(side['role']) is not None, 'ADJUDICATION_PARTIES')
        need(type(side['key']) is str, 'ADJUDICATION_PARTIES'); verification_key(side['key'])
        need(side['account'] is None or (type(side['account']) is str and _ADDRESS.match(side['account'])), 'ADJUDICATION_PARTIES')
    claimant, respondent = parties['claimant'], parties['respondent']
    need(claimant['role'] != respondent['role'] and claimant['key'] != respondent['key'], 'ADJUDICATION_PARTIES')
    need(claimant['account'] is None or claimant['account'] != respondent['account'], 'ADJUDICATION_PARTIES')


def _options(options, kind):
    need(type(options) is list and 2 <= len(options) <= 16, 'ADJUDICATION_OPTIONS')
    for row in options:
        need(type(row) is dict and set(row) == {'answer', 'label', 'result'}, 'ADJUDICATION_OPTIONS')
        _text(row['label'], 200, 'ADJUDICATION_OPTIONS')
        if row['result'] is not None:
            try:
                interop.ladder_result(kind, row['result'], 'ADJUDICATION_PANEL_RESULT')
            except ValueError as exc:
                raise ValueError('ADJUDICATION_PANEL_RESULT' if kind == 'PANEL' else str(exc)) from None
    answers = [canonical(row['answer']) for row in options]
    results = [canonical(row['result']) for row in options if row['result'] is not None]
    need(len(set(answers)) == len(answers) and len(set(results)) == len(results), 'ADJUDICATION_OPTIONS')


def validate_terms(terms):
    need(type(terms) is dict and set(terms) == set(FIELDS), 'ADJUDICATION_TERMS')
    need(terms['version'] == VERSION, 'ADJUDICATION_VERSION')
    ladder = interop.ladder_reference(terms['ladder'])
    _parties(terms['parties'])
    if ladder['kind'] == 'PANEL':
        need({side['role'] for side in terms['parties'].values()} == {'agent', 'counterparty'}, 'ADJUDICATION_PARTIES')
    need(type(terms['adjudicator']) is dict, 'ADJUDICATION_KIND')
    module = adapter(terms['adjudicator'].get('kind'))
    _case(terms['case'])
    _options(terms['options'], ladder['kind'])
    module.validate(terms['adjudicator'], terms['options'], terms['parties'], terms['case'])
    need(terms['required_assurance'] in module.ASSURANCE, 'ADJUDICATION_ASSURANCE')
    need(len(canonical(terms)) <= MAX_TERMS, 'ADJUDICATION_SIZE')
    return terms


def terms_id(terms):
    return digest(LABEL, validate_terms(terms))


def terms_draft(*, ladder, parties, adjudicator, case, options, required_assurance=None):
    """The exact terms both disputants sign. Preparing them signs and sends nothing."""
    module = adapter(adjudicator.get('kind') if type(adjudicator) is dict else None)
    terms = {'version': VERSION, 'ladder': deepcopy(ladder), 'parties': deepcopy(parties),
             'adjudicator': deepcopy(adjudicator), 'case': deepcopy(case), 'options': deepcopy(options),
             'required_assurance': module.ASSURANCE[0] if required_assurance is None else required_assurance}
    ident = terms_id(terms)
    return {'terms': terms, 'id': ident, 'signing_payload': {'label': LABEL, 'body': deepcopy(terms)},
            'required_signers': [parties['claimant']['key'], parties['respondent']['key']], **FLAGS}


def adopt(terms, signatures, *, policy=None, chain_terms=None):
    """Both disputants' signatures over the exact terms, checked against the ladder they name."""
    ident = terms_id(terms)
    need(type(signatures) is list and len(signatures) == 2, 'ADJUDICATION_SIGNATURES')
    signed = set()
    for row in signatures:
        need(type(row) is dict and set(row) == {'side', 'signature'} and row['side'] in ('claimant', 'respondent')
             and row['side'] not in signed, 'ADJUDICATION_SIGNATURES')
        verify(terms['parties'][row['side']]['key'], LABEL, terms, row['signature'])
        signed.add(row['side'])
    results = [row['result'] for row in terms['options'] if row['result'] is not None]
    interop.check_ladder(terms['ladder'], terms['parties'], results, policy=policy, chain_terms=chain_terms)
    return {'terms': deepcopy(terms), 'id': ident, 'signed_by': sorted(signed), 'ladder': deepcopy(terms['ladder']), **FLAGS}


def request(terms, signatures, *, policy=None, chain_terms=None):
    """The exact request the adjudicator needs: documents to publish and calls the owner may submit."""
    adopted = adopt(terms, signatures, policy=policy, chain_terms=chain_terms)
    built = adapter(terms['adjudicator']['kind']).request(terms, adopted['id'])
    body = {'version': REQUEST, 'terms': adopted['id'], 'adjudicator': terms['adjudicator']['kind'],
            'commitment': built['commitment']}
    return {'request': body, 'id': digest(REQUEST, body), **built, 'signed_by': adopted['signed_by'], **FLAGS}


def record_id(record):
    from covenant_language.agreement_application import content_id
    return content_id(RECORD, record)


def outcome(terms, signatures, evidence, *, policy=None, chain_terms=None, **inputs):
    """Verify a published decision against the signed terms and make it an evidence record.

    ``evidence`` is the adjudicator's own published bytes as the owner obtained
    them (event logs or receipt proofs, or a finalized transaction); ``inputs``
    are adapter pins such as ``trusted_blocks``. The record's mapped result is
    the parties' own table row for the answer, or None.
    """
    adopted = adopt(terms, signatures, policy=policy, chain_terms=chain_terms)
    module = adapter(terms['adjudicator']['kind'])
    built = module.request(terms, adopted['id'])
    request_id = digest(REQUEST, {'version': REQUEST, 'terms': adopted['id'], 'adjudicator': terms['adjudicator']['kind'],
                                  'commitment': built['commitment']})
    ruling = module.outcome(terms, adopted['id'], built, evidence, **inputs)
    need(ruling['final'] is True, 'ADJUDICATION_NOT_FINAL')
    need(module.ASSURANCE.index(ruling['assurance']) <= module.ASSURANCE.index(terms['required_assurance']),
         'ADJUDICATION_ASSURANCE')
    row = next((row for row in terms['options'] if canonical(row['answer']) == canonical(ruling['answer'])), None)
    if ruling['answer'] is None:
        mapping, mapped = 'REFUSED_TO_DECIDE', None
    else:
        need(row is not None, ruling.get('unmapped_code', 'ADJUDICATION_OPTIONS'))
        mapping, mapped = ('MAPPED', deepcopy(row['result'])) if row['result'] is not None else ('NO_RESULT_FOR_ANSWER', None)
    record = {'version': RECORD, 'terms': adopted['id'], 'ladder': deepcopy(terms['ladder']),
              'adjudicator': module.identity(terms['adjudicator']), 'request': request_id,
              'ruling': {'answer': deepcopy(ruling['answer']), 'case': deepcopy(ruling['case']), 'at': ruling['at']},
              'assurance': ruling['assurance'], 'sources': deepcopy(ruling['sources']),
              'mapping': mapping, 'mapped_result': mapped}
    ident = record_id(record)
    return {'record': record, 'id': ident, 'evidence_reference': ident, 'verification': deepcopy(ruling), **FLAGS}


def _checked_record(terms, record, expected):
    need(type(record) is dict and record.get('version') == RECORD and record_id(record) == expected, 'ADJUDICATION_RECORD')
    need(record['terms'] == terms_id(terms) and record['ladder'] == terms['ladder'], 'ADJUDICATION_RECORD')
    return expected


def ladder_step(terms, signatures, record, expected_record, policy, adoptions, events, *, actor, at, bond_receipt=None):
    """The one procedure event the record supports at the agreed stage, unsigned; the actor signs it."""
    adopt(terms, signatures, policy=policy)
    ident = _checked_record(terms, record, expected_record)
    return interop.procedure_step(terms['ladder'], ident, record['mapped_result'], policy, adoptions, events,
                                  actor=actor, at=at, bond_receipt=bond_receipt)


def panel_step(terms, signatures, record, expected_record, chain_terms, *, chain):
    """PANEL_EVIDENCE citing the record and the ballot body a seated arbitrator may choose to sign."""
    adopt(terms, signatures, chain_terms=chain_terms)
    ident = _checked_record(terms, record, expected_record)
    return interop.panel_evidence_step(terms['ladder'], ident, record['mapped_result'], chain_terms, chain=chain,
                                       description='External adjudicator ruling evidence record')


def describe():
    return {'version': VERSION, 'record': RECORD, 'request': REQUEST, 'label': LABEL, 'decision': 'GRAFT',
            'adjudicators': {kind: adapter(kind).describe() for kind in sorted(ADAPTERS)},
            'flow': ['terms_draft: both disputants sign the exact terms before a dispute',
                     'request: exact documents and calls for the named adjudicator; the owner publishes or submits them',
                     'outcome: the published decision, supplied as bytes, checked against pins and request -> evidence record',
                     'ladder_step / panel_step: the one unsigned ladder event the record supports'],
            'mappings': list(MAPPINGS),
            'escrow': 'AAP terms and ladder only; an outside ruling never releases or moves escrow',
            'appeal': 'Later ladder stages stay open exactly as the adopted procedure allows',
            'remediation': deepcopy(REMEDIATION), **FLAGS}
