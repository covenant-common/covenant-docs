"""Assignment of a payment claim (receivable factoring). Maturity: experimental.

Clean-room: no wienerlabs source. A claim can be sold on any named rail, with
or without escrow, including as an offline voucher the worker signs. The
public record keeps a salted price digest, never the price. Reputation stays
with the worker. After a sale the host routes payment to the assignee even
when a release payload omits the payee, and refuses a different payee.

Only the worker can sell or reassign a claim: the signing key must be the
worker's. ``route`` re-verifies the stored voucher before it names a payee, so
an edited host row cannot redirect payment.

Under ``islamic_commercial_review`` (the drafting profile in
covenant_language.contract_sources) only a sale of debt at par is accepted: a
discount, a service fee or interest raises RIBA_DISCOUNT_REFUSED. When a scale
profile turns covenant_chain.shariah_mode on, that profile is forced. This is
a host profile gate, not a religious ruling. The priced variant stays
available when the profile is unset.
"""
from copy import deepcopy

from .crypto import digest, exact, integer, key, need, public_key, sign, verify

FACTOR_VERSION = 'covenant-receivable-assignment/0.1'
VOUCHER_VERSION = 'covenant-factor-voucher/0.1'
VOUCHER_LABEL = 'COVENANT-FACTOR-VOUCHER-0.1'
PRICE_LABEL = 'COVENANT-FACTOR-PRICE-0.1'
ISLAMIC_PROFILE = 'islamic_commercial_review'
SALE_OF_DEBT = 'sale_of_debt'
DISCOUNT = 'discount'
_VOUCHER = 'version claim worker assignee face price_digest rail escrow variant profile'
_PUBLIC = ('version', 'claim', 'worker', 'assignee', 'face', 'price_digest', 'rail', 'escrow', 'variant',
           'profile', 'reputation_subject')


def quote(*, face, price, variant, rail, profile=None, service_fee=0, interest_bps=0, escrow=False, scale=None):
    """Price a sale of a claim. No loan is created and nothing moves."""
    integer(face, True)
    integer(price, True)
    integer(service_fee)
    integer(interest_bps)
    need(interest_bps <= 10000, 'FACTOR_INTEREST')
    need(type(escrow) is bool, 'ESCROW')
    need(type(rail) is str and 1 <= len(rail) <= 128, 'RAIL')
    need(variant in (SALE_OF_DEBT, DISCOUNT), 'FACTOR_VARIANT')
    if profile is not None:
        need(type(profile) is str and 1 <= len(profile) <= 80, 'FACTOR_PROFILE')
    need(scale is None or type(scale) is dict, 'FACTOR_SCALE')
    from .shariah_mode import enabled as shariah_enabled
    if shariah_enabled(scale):
        need(profile in (None, ISLAMIC_PROFILE), 'FACTOR_PROFILE')
        profile = ISLAMIC_PROFILE
    islamic = profile == ISLAMIC_PROFILE
    at_par = price == face and service_fee == 0 and interest_bps == 0
    if islamic and (variant != SALE_OF_DEBT or not at_par):
        raise ValueError('RIBA_DISCOUNT_REFUSED')
    if variant == SALE_OF_DEBT and not at_par:
        raise ValueError('FACTOR_PAR')
    if variant == DISCOUNT and price > face:
        raise ValueError('FACTOR_PRICE')
    return {
        'version': FACTOR_VERSION,
        'variant': variant,
        'profile': profile,
        'face': face,
        'price': price,
        'service_fee': service_fee,
        'interest_bps': interest_bps,
        'rail': rail,
        'escrow': escrow,
        'sale_of_debt': variant == SALE_OF_DEBT and at_par,
        'profile_gate': (
            'islamic_commercial_review accepts a sale at par and refuses a discount, a fee, or interest. '
            'This is a host profile gate, not a religious ruling.') if islamic else None,
        'loan_created': False,
        'execution_authorized': False,
    }


def _voucher_body(record):
    body = {name: record[name] for name in _VOUCHER.split()}
    exact(body, _VOUCHER)
    return body


def sign_voucher(private_key, record):
    """The worker signs the exact voucher body. Another key is refused."""
    body = _voucher_body(record)
    need(public_key(private_key) == body['worker'], 'FACTOR_SIGNER')
    return {'body': body, 'signature': sign(private_key, VOUCHER_LABEL, body)}


def redeem_voucher(voucher, current_assignee):
    """Check a signed voucher with no network. A changed payee supersedes it."""
    exact(voucher, 'body signature')
    body = voucher['body']
    exact(body, _VOUCHER)
    need(body['version'] == VOUCHER_VERSION, 'FACTOR_VOUCHER')
    verify(body['worker'], VOUCHER_LABEL, body, voucher['signature'])
    if body['assignee'] != current_assignee:
        raise ValueError('VOUCHER_SUPERSEDED')
    return {
        'payee': current_assignee,
        'reputation_subject': body['worker'],
        'rail': body['rail'],
        'escrow': body['escrow'],
        'offline': True,
        'execution_authorized': False,
    }


class AssignmentBook:
    """The host's in-memory record of who is paid. The native release payload never names the payee.

    The signed voucher the assignee holds is the portable record; this book is
    a host convenience and is not persisted.
    """

    def __init__(self):
        self.rows = {}

    def _row(self, claim):
        key(claim)
        need(claim in self.rows, 'FACTOR_UNKNOWN_CLAIM')
        return self.rows[claim]

    def sell(self, claim, *, worker, assignee, face, price, salt, rail, signer,
             variant=SALE_OF_DEBT, profile=None, service_fee=0, interest_bps=0,
             escrow=False, enabled=False, scale=None):
        """Flag-gated sale signed by the worker. One assignment per claim."""
        need(enabled is True, 'PLUGIN_DISABLED')
        key(claim)
        key(worker)
        key(assignee)
        key(salt)
        need(worker != assignee, 'FACTOR_PARTIES')
        need(public_key(signer) == worker, 'FACTOR_SIGNER')
        need(claim not in self.rows, 'FACTOR_ASSIGNED')
        quoted = quote(
            face=face, price=price, variant=variant, rail=rail, profile=profile,
            service_fee=service_fee, interest_bps=interest_bps, escrow=escrow, scale=scale)
        record = {
            'version': VOUCHER_VERSION,
            'claim': claim,
            'worker': worker,
            'assignee': assignee,
            'face': face,
            'price_digest': digest(PRICE_LABEL, {'price': price, 'salt': salt}),
            'rail': rail,
            'escrow': escrow,
            'variant': variant,
            'profile': quoted['profile'],
            'reputation_subject': worker,
        }
        record['voucher'] = sign_voucher(signer, record)
        self.rows[claim] = record
        return self.public(claim) | {'quoted': quoted}

    def reassign(self, claim, assignee, signer):
        """A new payee supersedes the previous voucher. Only the worker signs again."""
        row = self._row(claim)
        key(assignee)
        need(assignee != row['worker'], 'FACTOR_PARTIES')
        need(public_key(signer) == row['worker'], 'FACTOR_SIGNER')
        changed = dict(row, assignee=assignee)
        changed['voucher'] = sign_voucher(signer, changed)
        self.rows[claim] = changed
        return self.public(claim)

    def public(self, claim):
        """The record without the price or the salt."""
        row = self._row(claim)
        shown = {name: deepcopy(row[name]) for name in _PUBLIC}
        shown['voucher'] = deepcopy(row['voucher'])
        shown['execution_authorized'] = False
        return shown

    def route(self, claim, payload=None):
        """Pay the stored assignee after re-verifying the voucher. A different payee is refused."""
        row = self._row(claim)
        need(payload is None or type(payload) is dict, 'FACTOR_PAYLOAD')
        need(row['voucher']['body'] == _voucher_body(row), 'FACTOR_VOUCHER')
        redeemed = redeem_voucher(row['voucher'], row['assignee'])
        if payload and 'payee' in payload and payload['payee'] != redeemed['payee']:
            raise ValueError('ASSIGNEE_BYPASS_REFUSED')
        return {
            'payee': redeemed['payee'],
            'reputation_subject': redeemed['reputation_subject'],
            'rail': redeemed['rail'],
            'escrow': redeemed['escrow'],
            'assigned': True,
            'voucher_verified': True,
            'execution_authorized': False,
        }

    def redeem(self, claim):
        row = self._row(claim)
        return redeem_voucher(row['voucher'], row['assignee'])
