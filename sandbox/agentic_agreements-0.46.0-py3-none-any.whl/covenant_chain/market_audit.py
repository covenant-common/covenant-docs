"""Market custody identity. Kept off market.py so conservation does not import app."""

from collections import defaultdict

from .crypto import need


def check_accounting_deltas(s):
    """Held custody equals reserve + funded pot + principal + allocated rewards."""
    d = defaultdict(int)
    for rid, old, new in s['market_reserve'].changes():
        d[rid] += new['available'] - (old or {}).get('available', 0)
    for rid, old, new in s['market_rewards'].changes():
        d[rid] += new - (old or 0)
    for _, old, new in s['service_stakes'].changes():
        for row, mult in ((old, -1), (new, 1)):
            if row:
                d[row['resource']] += mult * row['amount']
                d[row['reward_resource']] += mult * row['claimable']
    for rid, old, new in s['market_held'].changes():
        d[rid] -= new - (old or 0)
    need(all(v == 0 for v in d.values()), 'MARKET_CUSTODY_ACCOUNTING')
