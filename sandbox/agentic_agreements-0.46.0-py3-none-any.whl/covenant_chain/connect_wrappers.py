"""Existing AAP adapters under the AAP Connect contracts, plus a reference fixture per kind.

Each class wraps an adapter that already shipped and changes none of its
signed formats: the disposable-credit rail and the simulated stablecoin
ledger (payment_rail), the AAP award tribunal (adjudicator), did:wba and
did:web documents (identity_provider), signed-discovery carriers
(discovery_source), the covenant-evidence-interface/0.1 readers
(evidence_source), CVF1 mesh frames and BPv7 bundles (transport), and NANDA
AgentFacts records (registry_export). Where the wrapped code lacked a contract
property, the wrapper adds it: the stablecoin transfer gains idempotent effect
ids, the tribunal also signs a contract decision.

reference(kind) builds one wrapped adapter with deterministic synthetic keys and
the conformance fixture for it. It is the worked example for every kind and the
input to the conformance suite. Nothing here moves real value, fetches or
contacts anyone.
"""
from copy import deepcopy
import hashlib
import shutil
import tempfile
import time

from . import connect
from .connect import ConnectError, b64, check, unb64
from .crypto import canonical, digest, public_key

FIXTURE_NOW = 1000
SOURCE_LEVEL = frozenset(('DISCOVERY_SOURCE', 'DISCOVERY_JSON', 'DISCOVERY_SIZE', 'DISCOVERY_DOCUMENT',
                          'DISCOVERY_FOREIGN_DOCUMENT', 'DISCOVERY_COMPLEXITY', 'DISCOVERY_JSON_TYPE', 'AGENTFACTS'))


def _account(label):
    return digest('AAP-CONNECT-SYNTHETIC-ACCOUNT', {'label': label})


def _none(effect, status, assurance):
    return {'status': status, 'effect': effect, 'receipt_sha256': None, 'payer': None, 'recipient': None,
            'unit': None, 'amount': None, 'fee': None, 'assurance': assurance}


class DemoCreditRail:
    """payment_rails.DemoPaymentRail (local disposable credits) under the payment_rail contract."""

    def __init__(self, rail):
        from .payment_rails import DemoPaymentRail
        check(isinstance(rail, DemoPaymentRail), 'CONNECT_ADAPTER')
        self.rail = rail

    def quote(self, payload):
        preview = self.rail.preview(dict(payload['request']))
        return {'amount': preview['amount'], 'fee': preview['network_fee']['amount'],
                'total_debit': preview['total_debit'], 'unit': preview['unit'],
                'within_fee_cap': preview['within_requested_fee_cap'],
                'sufficient_balance': preview['sufficient_balance_at_local_read'], 'funding': 'NOT_RESERVED'}

    def execute(self, payload):
        return self._observation(payload['effect'], self.rail.execute(payload['effect'], dict(payload['request'])))

    def observe(self, payload):
        return self._observation(payload['effect'], self.rail.observe(payload['effect']))

    @staticmethod
    def _observation(effect, seen):
        if seen['status'] != 'OBSERVED':
            return _none(effect, 'NOT_OBSERVED', seen['assurance'])
        value = seen['value']
        return {'status': 'OBSERVED', 'effect': effect, 'receipt_sha256': seen['output_hash'], 'payer': value['payer'],
                'recipient': value['recipient'], 'unit': value['unit'], 'amount': value['amount'],
                'fee': value['network_fee']['amount'], 'assurance': seen['assurance']}


class SimulatedStablecoinRail:
    """covenant_agent.settlement.StablecoinLedger transfers, with the idempotent effect ids the contract needs."""

    connect_native = {'PAYMENT_PARTIES': 'CONNECT_RAIL_REQUEST'}

    def __init__(self, ledger, rail='x402'):
        from covenant_agent.settlement import StablecoinLedger
        check(isinstance(ledger, StablecoinLedger) and rail in ('x402', 'ap2'), 'CONNECT_ADAPTER')
        self.ledger, self.rail = ledger, rail

    def quote(self, payload):
        from covenant_agent.settlement import require_stablecoin
        request = payload['request']
        require_stablecoin(request['unit'])
        return {'amount': request['amount'], 'fee': 0, 'total_debit': request['amount'], 'unit': request['unit'],
                'within_fee_cap': True, 'funding': 'NOT_RESERVED',
                'sufficient_balance': self.ledger.balance(request['payer'], request['unit']) >= request['amount']}

    def execute(self, payload):
        effect, request = payload['effect'], payload['request']
        binding = digest('AAP-CONNECT-STABLECOIN-REQUEST-0.1', request)
        prior = self.ledger.receipts.get(effect)
        if prior is None:
            moved = self.ledger.transfer(request['payer'], request['recipient'], request['unit'], request['amount'])
            self.ledger.remember(effect, {**moved, 'rail': self.rail, 'request': binding, 'fee': 0})
        else:
            check(prior.get('request') == binding, 'CONNECT_RAIL_RETRY_CHANGED')
        return self.observe({'effect': effect})

    def observe(self, payload):
        seen = self.ledger.observe(payload['effect'])
        if seen['status'] != 'OBSERVED':
            return _none(payload['effect'], 'NOT_OBSERVED', seen['assurance'])
        value = seen['value']
        return {'status': 'OBSERVED', 'effect': payload['effect'], 'receipt_sha256': seen['output_hash'],
                'payer': value['payer'], 'recipient': value['payee'], 'unit': value['unit'],
                'amount': value['amount'], 'fee': value['fee'], 'assurance': seen['assurance']}


class TribunalAdjudicator:
    """An AAP award tribunal (award_documents) under the adjudicator contract.

    rule(case) returns (outcome_index, reasons) or None to decline: a human panel,
    a model or a fixed rule installed by the tribunal. Every member signs the
    JSON award and its PDF; the first member also signs the contract decision,
    whose record_sha256 names the award. Awards stay retrievable by case id.
    """

    def __init__(self, members, rule, *, method='EXPERT_DETERMINATION', seat=None, title='AAP Connect decision'):
        check(type(members) is list and 1 <= len(members) <= 16 and callable(rule), 'CONNECT_ADAPTER')
        self.members, self.rule, self.method, self.seat, self.title = list(members), rule, method, seat, title
        self.keys = [public_key(member) for member in members]
        self.awards = {}

    def decide(self, case):
        from . import award_documents as awards
        check(not set(self.keys) & {row['key'] for row in case['parties']}, 'CONNECT_ADJUDICATOR_CONFLICT')
        check(case['as_of'] <= 253402300799, 'CONNECT_ADJUDICATOR_CASE')
        chosen = self.rule(deepcopy(case))
        check(chosen is not None, 'CONNECT_ADJUDICATOR_DECLINED')
        check(type(chosen) is tuple and len(chosen) == 2 and type(chosen[1]) is str, 'CONNECT_ADJUDICATOR_DECLINED')
        index, reasons = chosen
        check(type(index) is int and 0 <= index < len(case['outcomes']), 'CONNECT_ADJUDICATOR_OUTCOME')
        body = {'version': awards.VERSION, 'case': case['case'], 'title': self.title,
                'issued': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(case['as_of'])), 'seat': self.seat,
                'method': self.method,
                'parties': [{'role': row['role'], 'name': row['role'], 'key': row['key']} for row in case['parties']],
                'tribunal': [{'name': 'member-' + str(number + 1), 'key': value} for number, value in enumerate(self.keys)],
                'threshold': len(self.keys) // 2 + 1,
                'basis': {'kind': 'PROCEDURE', 'reference': case['agreement'], 'head': None},
                'agreement': {'reference': case['agreement'],
                              'clause': 'Stage ' + case['stage'] + ' of the fair-fix ladder both parties signed.'},
                'sections': [{'heading': 'Decision', 'paragraphs': [reasons]}],
                'outcome': deepcopy(case['outcomes'][index]), 'escrow_effect': 'DECIDED_BY_AAP_TERMS_AND_LADDER'}
        issued = awards.issue(body, self.members)
        self.awards[case['case']] = issued
        decision = connect.decision_body(case, index, self.keys[0], hashlib.sha256(reasons.encode('utf-8')).hexdigest(),
                                         issued['id'], case['as_of'])
        return connect.sign_decision(decision, self.members[0])


class DidWebIdentity:
    """did:wba and did:web documents (did_binding) under the identity_provider contract."""

    formats = ('did:wba', 'did:web')

    def verify(self, credential):
        from .did_binding import resolve
        check(credential['format'] in self.formats, 'CONNECT_IDENTITY_FORMAT')
        check(credential['subject'][:len(credential['format']) + 1] == credential['format'] + ':',
              'CONNECT_IDENTITY_SUBJECT')
        found = resolve(credential['subject'], document=credential['document'], bindings=credential['bindings'],
                        now=credential['now'])
        return {'format': credential['format'], 'subject': credential['subject'], 'status': found['status'],
                'bound_keys': [{'key': row['key'], 'basis': row['basis']} for row in found['bound_keys']],
                'listed_keys': list(found['listed_without_key_signature']),
                'document_sha256': found['document_sha256']}


class SignedDiscoverySource:
    """One signed-discovery carrier (DIRECT, WELL_KNOWN, DNS_TXT, AGENTFACTS ...) under the discovery_source contract."""

    def __init__(self, source='WELL_KNOWN'):
        from .signed_discovery import SOURCES
        check(source in SOURCES and source != 'TLOG', 'CONNECT_ADAPTER')
        self.source = source

    def read(self, payload):
        from .signed_discovery import gather
        item = payload['item']
        check(item.get('source') == self.source, 'CONNECT_DISCOVERY_ITEM')
        found = gather([deepcopy(item)], payload['now'])
        rows, conflicts = [], []
        for agent in found['agents']:
            for row in agent['descriptors']:
                classes = agent['descriptor']['task_classes'] if row['id'] == agent['selected'] else []
                rows.append({'id': row['id'], 'key': agent['key'], 'sequence': row['sequence'],
                             'status': row['status'], 'task_classes': list(classes)})
            conflicts += [{'key': agent['key'], 'kind': entry['kind']} for entry in agent['conflicts']]
        excluded = [{'reason': row['reason'] if connect._CODE.fullmatch(row['reason']) else 'DISCOVERY_EXCLUDED'}
                    for row in found['excluded']]
        if not rows and excluded and all(row['reason'] in SOURCE_LEVEL for row in excluded):
            raise ConnectError('CONNECT_DISCOVERY_ITEM', native=excluded[0]['reason'])
        return {'descriptors': rows[:64], 'excluded': excluded[:64], 'pointers': len(found['pointers']),
                'conflicts': conflicts[:16], 'sources_add_trust': False}


class EvidenceInterfaceSource:
    """A covenant-evidence-interface/0.1 reader (covenant_agent.evidence) under the evidence_source contract."""

    def __init__(self, reader):
        check(callable(getattr(reader, 'read', None)) and type(getattr(reader, 'id', None)) is str, 'CONNECT_ADAPTER')
        self.reader = reader

    def read(self, payload):
        raw = unb64(payload['blob_base64'], 'CONNECT_EVIDENCE_INPUT')
        reading = self.reader.read(raw, payload['mime'], deepcopy(payload['provenance']), deepcopy(payload['claim']))
        return {'supports': reading['supports'], 'confidence_bps': reading['confidence_bps'],
                'reason': reading['reason'], 'blob_sha256': hashlib.sha256(raw).hexdigest(),
                'notes': [note for note in reading['notes'] if type(note) is str][:8]}


class MeshFrameTransport:
    """CVF1 hash frames (offline_carriers) under the transport contract: any order, duplicates ignored."""

    def __init__(self, mtu=200):
        check(type(mtu) is int and 128 <= mtu <= 1024, 'CONNECT_ADAPTER')
        self.mtu = mtu

    def encode(self, payload):
        from .offline_carriers import frames
        raw = unb64(payload['payload_base64'], 'CONNECT_TRANSPORT_INPUT')
        return {'frames': [b64(frame) for frame in frames(raw, mtu=self.mtu)],
                'payload_sha256': hashlib.sha256(raw).hexdigest()}

    def decode(self, payload):
        from .offline_carriers import HEADER, Reassembler
        assembler, done, reference = Reassembler(max_sessions=1, max_bytes=131072), None, None
        for text_value in payload['frames']:
            raw = unb64(text_value, 'CONNECT_TRANSPORT_FRAME', 1024)
            check(len(raw) > HEADER.size, 'CONNECT_TRANSPORT_FRAME')
            current = raw[4:36].hex()
            if done is not None:
                check(current == reference, 'CONNECT_TRANSPORT_MISMATCH')
                continue
            result = assembler.accept(raw, now=0)
            if result is not None:
                done, reference = result, current
        check(done is not None, 'CONNECT_TRANSPORT_INCOMPLETE')
        return {'payload_base64': b64(done), 'payload_sha256': hashlib.sha256(done).hexdigest()}


class Bpv7Transport:
    """One RFC 9171 bundle per payload (dtn_bundle) under the transport contract. No clock: Bundle Age 0."""

    connect_native = {'BPV7_PAYLOAD_SIZE': 'CONNECT_TRANSPORT_INPUT', 'BPV7_SIZE': 'CONNECT_TRANSPORT_INPUT'}

    def __init__(self, source='dtn://aap-sender/connect', destination='dtn://aap-receiver/connect',
                 lifetime_ms=86400000):
        from .dtn_bundle import eid
        eid(source), eid(destination)
        check(type(lifetime_ms) is int and 0 < lifetime_ms <= 2**53 - 1, 'CONNECT_ADAPTER')
        self.source, self.destination, self.lifetime_ms = source, destination, lifetime_ms

    def encode(self, payload):
        from .dtn_bundle import encode_bundle
        raw = unb64(payload['payload_base64'], 'CONNECT_TRANSPORT_INPUT')
        bundle = encode_bundle(raw, source=self.source, destination=self.destination, created_ms=0,
                               lifetime_ms=self.lifetime_ms, bundle_age_ms=0)
        return {'frames': [b64(bundle)], 'payload_sha256': hashlib.sha256(raw).hexdigest()}

    def decode(self, payload):
        from .dtn_bundle import open_bundle
        # One bundle per payload; an identical duplicate is the same bundle carried twice.
        check(len(set(payload['frames'])) == 1, 'CONNECT_TRANSPORT_MISMATCH')
        raw = unb64(payload['frames'][0], 'CONNECT_TRANSPORT_FRAME', connect.MAX_PAYLOAD + 8192)
        try:
            opened = open_bundle(raw, now_ms=0)
        except ValueError as error:
            code = str(error)
            raise ConnectError('CONNECT_TRANSPORT_FRAME', native=code if connect._CODE.fullmatch(code) else None) from None
        return {'payload_base64': b64(opened['payload']), 'payload_sha256': hashlib.sha256(opened['payload']).hexdigest()}


class AgentFactsExport:
    """NANDA AgentFacts records carrying the signed AAP descriptor (registry_records) under registry_export."""

    def __init__(self, provider=None):
        self.provider = deepcopy(provider or {'name': 'AAP Connect synthetic provider',
                                              'url': 'https://provider.example.invalid/'})

    def export(self, payload):
        from .registry_records import agentfacts
        made = agentfacts(deepcopy(payload['descriptor']), self.provider, signed=False)
        return {'format': 'NANDA_AGENTFACTS_V1', 'records': [canonical(made['agentfacts']).decode('ascii')],
                'media_type': 'application/json', 'descriptor': made['descriptor']}

    def parse(self, payload):
        from .signed_discovery import gather
        found = gather([{'source': 'AGENTFACTS', 'document': record} for record in payload['records']], payload['now'])
        ids = sorted({row['id'] for agent in found['agents'] for row in agent['descriptors']})
        excluded = [{'reason': row['reason'] if connect._CODE.fullmatch(row['reason']) else 'REGISTRY_EXCLUDED'}
                    for row in found['excluded']]
        return {'descriptors': ids[:16], 'excluded': excluded[:16], 'sources_add_trust': False}


# Reference fixtures: one worked example per kind -----------------------------------

def example_descriptor(label='example', *, issued_at=1, expires=10**9, name='AAP Connect example agent'):
    """A signed synthetic agent descriptor for examples: a real signature by a labelled test key."""
    from .signed_discovery import descriptor, sign_descriptor
    secret = connect.synthetic_key(label)
    prepared = descriptor(public_key(secret), 0, None, issued_at, expires, name, 'Synthetic example; not a live agent.',
                          ['aap-connect.example'], [{'transport': 'https', 'uri': 'https://agent.example.invalid/a2a'}])
    return sign_descriptor(prepared['body'], secret)


def _payment(directory):
    from .payment_rails import DemoPaymentRail
    payer, recipient = _account('payer'), _account('recipient')
    policy = {'version': 'covenant-network-fee/0.1', 'unit': 'credit', 'fixed': 1, 'bps': 100, 'minimum': 1,
              'maximum': 50, 'beneficiary': _account('fee-beneficiary'),
              'token': {'version': 'covenant-token-utility/0.1', 'resource': 'credit-token', 'discount_bps': 0,
                        'credit_prices': {}}}
    rail = DemoPaymentRail(directory, 'credit', {payer: 1000}, policy)
    request = {'action': 'TRANSFER', 'payer': payer, 'recipient': recipient, 'unit': 'credit', 'amount': 100,
               'maximum_fee': 10}
    return DemoCreditRail(rail), {'request': request, 'overdraft_amount': 1_000_000}, {}, rail.close


def _stablecoin(_directory):
    from covenant_agent.settlement import StablecoinLedger
    payer, recipient = _account('stablecoin-payer'), _account('stablecoin-recipient')
    ledger = StablecoinLedger({payer: {'USDC': 1000}})
    request = {'action': 'TRANSFER', 'payer': payer, 'recipient': recipient, 'unit': 'USDC', 'amount': 250,
               'maximum_fee': 0}
    return SimulatedStablecoinRail(ledger), {'request': request, 'overdraft_amount': 1_000_000}, {}, None


def example_case():
    """A two-party case with three agreed outcomes; synthetic keys only."""
    parties = [{'role': 'buyer', 'key': public_key(connect.synthetic_key('case/buyer'))},
               {'role': 'seller', 'key': public_key(connect.synthetic_key('case/seller'))}]
    return {'case': digest('AAP-CONNECT-EXAMPLE-CASE', {'n': 1}), 'agreement': digest('AAP-CONNECT-EXAMPLE-DEAL', {'n': 1}),
            'claim': digest('AAP-CONNECT-EXAMPLE-CLAIM', {'n': 1}), 'stage': 'judgment', 'parties': parties,
            'outcomes': [{'remedy': 'release'}, {'remedy': 'refund'}, {'remedy': 'split', 'payee_bps': 5000}],
            'evidence': [digest('AAP-CONNECT-EXAMPLE-EVIDENCE', {'n': 1})], 'as_of': 1_800_000_000}


def evidence_rule(case):
    """Synthetic example rule: release when evidence was supplied, otherwise refund."""
    return (0, 'Delivery evidence was supplied and not contested.') if case['evidence'] else \
        (1, 'No delivery evidence was supplied.')


def _adjudicator(_directory):
    member = connect.synthetic_key('tribunal/member-1')
    return (TribunalAdjudicator([member], evidence_rule), {'case': example_case()},
            {'output_keys': [public_key(member)]}, None)


def _identity(_directory):
    from . import did_binding
    secret = connect.synthetic_key('identity/agent')
    agent = public_key(secret)
    did = did_binding.wba_did(agent, 'agent.example.invalid', ['agents', 'example'])
    prepared = did_binding.document(agent, did)
    signed = did_binding.sign_document(prepared, secret)
    listed = 'did:web:listed.example.invalid:agents:example'
    unsigned = {'@context': ['https://www.w3.org/ns/did/v1'], 'id': listed,
                'verificationMethod': [{'id': listed + '#key-1', 'type': 'Multikey', 'controller': listed,
                                        'publicKeyMultibase': prepared['document']['verificationMethod'][0]['publicKeyMultibase']}],
                'authentication': [listed + '#key-1'], 'assertionMethod': [listed + '#key-1']}
    fixture = {'key': agent,
               'valid': {'format': 'did:wba', 'subject': did, 'document': canonical(signed).decode('ascii'),
                         'bindings': [], 'now': FIXTURE_NOW},
               'unsigned': {'format': 'did:web', 'subject': listed, 'document': canonical(unsigned).decode('ascii'),
                            'bindings': [], 'now': FIXTURE_NOW}}
    return DidWebIdentity(), fixture, {}, None


def well_known_item(envelope):
    from .signed_discovery import encode
    try:
        body = encode(envelope)
    except ValueError:
        body = canonical(envelope).decode('ascii')
    return {'source': 'WELL_KNOWN', 'origin': 'https://agent.example.invalid', 'body': body}


def _discovery(_directory):
    return SignedDiscoverySource('WELL_KNOWN'), {'carry': well_known_item}, {}, None


def _evidence(_directory):
    from covenant_agent.evidence.adapters import JsonAdapter, json_blob, sign_provenance
    device = connect.synthetic_key('evidence/device')
    reader = JsonAdapter()
    blob = json_blob({'parcel': 'A-1', 'status': 'delivered'})
    provenance = sign_provenance(device, adapter=reader.id, blob=blob, mime='application/json', kind='DEVICE')
    fixture = {'observation': {'blob_base64': b64(blob), 'mime': 'application/json', 'provenance': provenance,
                               'claim': {'expect': {'json': {'status': 'delivered'}}}},
               'unsupported_claim': {'expect': {'json': {'status': 'returned'}}}}
    return EvidenceInterfaceSource(reader), fixture, {}, None


def _mesh(_directory):
    return MeshFrameTransport(200), {'max_payload': 20000}, {}, None


def _bundle(_directory):
    return Bpv7Transport(), {'max_payload': 20000}, {}, None


def _registry(_directory):
    return AgentFactsExport(), {'options': {}}, {}, None


REFERENCES = {'payment_rail': _payment, 'payment_rail/stablecoin': _stablecoin, 'adjudicator': _adjudicator,
              'identity_provider': _identity, 'discovery_source': _discovery, 'evidence_source': _evidence,
              'transport': _mesh, 'transport/bpv7': _bundle, 'registry_export': _registry}


def reference(name, directory=None):
    """(adapter, fixture, pins, close) for one wrapped existing adapter. Synthetic keys; disposable state."""
    check(type(name) is str and name in REFERENCES, 'CONNECT_KIND')
    owned = None
    if directory is None:
        owned = tempfile.mkdtemp(prefix='aap-connect-')
        directory = owned
    adapter, fixture, pins, close = REFERENCES[name](directory)

    def closer():
        if close is not None:
            close()
        if owned is not None:
            shutil.rmtree(owned, ignore_errors=True)
    return {'kind': name.split('/', 1)[0], 'adapter': adapter, 'fixture': fixture, 'pins': pins, 'close': closer,
            'implementation': connect.implementation_sha256(adapter)}
