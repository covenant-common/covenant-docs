"""Read-only view of the scale-economies profile.

Derived from chain state. It does not submit transactions, mint supply, or
authorize execution. A chain that did not select covenant-economics/0.3 reports
the profile as inactive.
"""
import html

from .crypto import integer, key
from .kept_promises import epoch_budget, honoured_rows, score_rows, usage_snapshot
from .scale_fees import protocol_price, scale_view
from .rule_sets import active_rule_sets
from .tokenomics_config import (CONSENSUS, FOUNDER_FEE_ABSOLUTE_CAP_BPS, OPEN_PARAMETERS,
    SCALE_VERSION, live_meter, live_policy)
from .founder_share import effective_rate_bps
from .vesting import supply_amounts, team_unlocked

LEADERBOARD = 32
AD_SHARE_VERSION = 'covenant-ad-share/0.1'


def view(state, height, account=None):
    integer(height)
    if account is not None:
        key(account)
    body = live_policy(state)
    report = {'height': height, 'profile': SCALE_VERSION if body else None,
              'scale_economies_shared': body is not None, 'execution_authorized': False,
              'token_issuance': 0, 'general_access_requires_token': False,
              'consensus': list(CONSENSUS), 'open_parameters': list(OPEN_PARAMETERS),
              'rule_sets': list(active_rule_sets(state.get('protocol') if hasattr(state, 'get') else None))}
    if body is None:
        policy = state.get('economic_policy') if hasattr(state, 'get') else None
        active = (policy or {}).get('active', {}).get('body', {}) if policy else {}
        report['active_version'] = active.get('version') if type(active) is dict else None
        return report
    scale = body['scale']
    meter = live_meter(state) or {}
    rows = honoured_rows(state, height)
    bonds = meter.get('bonds') or {}
    scored = score_rows(rows, height, scale['points'], bonds, scale['integrator'])
    usage = usage_snapshot(rows, height, scale['window']['blocks_per_day'])
    snapshot = scale_view(state, height, scale)
    priced = protocol_price(body, snapshot)
    board = sorted(scored['accounts'].items(), key=lambda item: (-item[1]['points'], item[0]))[:LEADERBOARD]
    resource = scale['supply']['resource']
    funded = _funded(state, resource)
    illustrative = supply_amounts(scale['supply'])
    illustrative['label'] = 'ILLUSTRATIVE_NOT_A_BALANCE'
    report.update(model=scale['model'],
                  supply={'resource': resource, 'funded_total': sum(funded.values()),
                          'accounts': len(funded), 'label': 'LEDGER_BALANCES'},
                  illustrative_schedule=illustrative,
                  balances=[{'account': account_id, 'amount': amount}
                            for account_id, amount in sorted(funded.items(), key=lambda item: (-item[1], item[0]))[:LEADERBOARD]],
                  balances_truncated=len(funded) > LEADERBOARD,
                  team_vesting=team_unlocked(scale['supply'], scale['vesting'], scale['window']['blocks_per_day'], height, usage),
                  usage=usage, qualified_volume=snapshot['qualified_volume'], unit_price=priced['unit_price'],
                  unit_cost=priced['unit_cost'], tier_bps=priced['tier_bps'],
                  reference_unit_price=body['base_fee'], ad_subsidy_credit=snapshot['ad_subsidy_credit'],
                  reserve_balance=snapshot['reserve_balance'],
                  funding_deficit=priced['planning_report']['funding_deficit'],
                  reported_unit_cost=meter.get('reported_unit_cost'),
                  previous_reported_unit_cost=meter.get('previous_reported_unit_cost'),
                  savings_to_users=meter.get('savings_to_users', 0),
                  savings_returned_bps=meter.get('savings_returned_bps', 0),
                  ratchet_ceiling=meter.get('ratchet_ceiling'),
                  epoch=epoch_budget(height, scale['points']), kept_promises=len(rows),
                  leaderboard=[{'account': who, **row} for who, row in board],
                  leaderboard_truncated=len(scored['accounts']) > LEADERBOARD,
                  wash_accounts=scored['wash_accounts'][:LEADERBOARD],
                  reputation_method=scored['reputation_method'], bonds=len(bonds),
                  last_flags=dict(meter.get('last_flags') or {}),
                  ad_share={'version': AD_SHARE_VERSION, 'auction': 'NOT_IMPLEMENTED_INTERFACE_ONLY'},
                  caps=dict(scale['caps']), founder_fee_absolute_cap_bps=FOUNDER_FEE_ABSOLUTE_CAP_BPS,
                  bps_do_not_set_the_take=True, shariah_mode=scale['shariah_mode'],
                  founder_shadow=meter.get('founder_shadow', True),
                  founder_rate_bps=effective_rate_bps((meter.get('totals') or {}).get('gross', 0)),
                  endowment_remaining=meter.get('endowment_remaining', 0),
                  endowment_claimable=meter.get('endowment_claimable', 0),
                  founder_totals={'gross': (meter.get('totals') or {}).get('gross', 0),
                                  'founder': (meter.get('totals') or {}).get('founder', 0),
                                  'fixed_apy': False, 'token_issuance': 0},
                  staking={'positions': len(meter.get('positions') or {}), 'fixed_apy': False,
                           'rewards': 'REALISED_FEE_AND_WORK'},
                  fork_defence={'chain': state.get('chain'), 'reputation_portable': False,
                                'positions_portable': False, 'receipts_portable': False})
    if account is not None:
        from .token_rebates import integrator_entitlement, rebate_entitlement
        report['account'] = {'id': account, 'points': scored['accounts'].get(account),
                             'rebate': rebate_entitlement(state, account, height),
                             'integrator': integrator_entitlement(state, account, height),
                             'bond': bonds.get(account, 0),
                             'balance': funded.get(account, 0), 'resource': resource}
    return report



def _funded(state, resource):
    """Balances the ledger actually holds. The illustrative genesis schedule is not this."""
    balances = state.get('balances') if hasattr(state, 'get') else None
    funded = {}
    if not hasattr(balances, 'items'):
        return funded
    for holder, row in balances.items():
        if type(row) is not dict:
            continue
        amount = row.get(resource, 0)
        if type(amount) is int and amount > 0:
            funded[holder] = amount
    return funded


def _cell(value):
    return html.escape(str(value), quote=True)


def render_html(report):
    """A small read-only page. No scripts, no writes, no token gate."""
    rows = []
    rows.append('<h1>Covenant economics</h1>')
    rows.append('<p>Read-only. This page does not authorize execution and does not issue tokens. '
                'Access does not require a token.</p>')
    if not report.get('scale_economies_shared'):
        rows.append('<p>Scale-economies profile is inactive on this chain. Active fee profile: '
                    + _cell(report.get('active_version')) + '.</p>')
    else:
        rows.append('<p>Profile ' + _cell(report['profile']) + ', model ' + _cell(report['model']) + '.</p>')
        supply = report['supply']
        rows.append('<h2>Funded balances</h2><p>These are ledger balances of '
                    + _cell(supply.get('resource')) + '. Total ' + _cell(supply.get('funded_total'))
                    + ' across ' + _cell(supply.get('accounts')) + ' accounts. '
                    + _cell(supply.get('label')) + '.</p>')
        rows.append('<table><tr><th>Account</th><th>Amount</th></tr>')
        for row in report.get('balances') or []:
            rows.append('<tr><td>' + _cell(row['account']) + '</td><td>' + _cell(row['amount']) + '</td></tr>')
        if not report.get('balances'):
            rows.append('<tr><td colspan="2">No funded balance of the supply resource.</td></tr>')
        rows.append('</table>')
        schedule = report.get('illustrative_schedule') or {}
        rows.append('<h2>Illustrative schedule, not a balance</h2><p>'
                    + _cell(schedule.get('label'))
                    + '. Nothing here was issued. The genesis split and its total are not holdings.</p>')
        rows.append('<table><tr><th>Field</th><th>Value</th></tr>')
        for name in ('total', 'community', 'team', 'foundation', 'ecosystem', 'liquidity', 'emissions', 'genesis_drop'):
            if name in schedule:
                rows.append('<tr><td>' + _cell(name) + '</td><td>' + _cell(schedule[name]) + '</td></tr>')
        rows.append('</table>')
        rows.append('<table><tr><th>Field</th><th>Value</th></tr>')
        for name in ('height', 'qualified_volume', 'unit_cost', 'unit_price', 'tier_bps',
                     'reference_unit_price', 'reported_unit_cost', 'savings_to_users',
                     'savings_returned_bps', 'ad_subsidy_credit', 'kept_promises', 'funding_deficit',
                     'rule_sets', 'endowment_remaining', 'endowment_claimable', 'founder_rate_bps'):
            rows.append('<tr><td>' + _cell(name) + '</td><td>' + _cell(report.get(name)) + '</td></tr>')
        vest = report['team_vesting']
        for name in ('unlocked', 'locked', 'time_unlocked', 'milestone_unlocked'):
            rows.append('<tr><td>team.' + _cell(name) + '</td><td>' + _cell(vest[name]) + '</td></tr>')
        rows.append('</table>')
        rows.append('<h2>Kept-promise points</h2><table><tr><th>Account</th><th>Points</th><th>Bonded</th></tr>')
        for row in report['leaderboard']:
            rows.append('<tr><td>' + _cell(row['account']) + '</td><td>' + _cell(row['points'])
                        + '</td><td>' + _cell(row['bonded']) + '</td></tr>')
        if not report['leaderboard']:
            rows.append('<tr><td colspan="3">No settled, honoured covenants in the score.</td></tr>')
        rows.append('</table>')
    rows.append('<h2>Consensus boundary</h2><ul>')
    for line in report['consensus']:
        rows.append('<li>' + _cell(line) + '</li>')
    rows.append('</ul><h2>Open parameters</h2><ul>')
    for line in report['open_parameters']:
        rows.append('<li>' + _cell(line) + '</li>')
    rows.append('</ul>')
    return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Covenant economics</title></head><body>' + ''.join(rows) + '</body></html>'
