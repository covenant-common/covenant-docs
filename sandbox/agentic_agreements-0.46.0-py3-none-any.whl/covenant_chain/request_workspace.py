"""Private saved requests above the historical agreement profiles.

Conversation, proposals, selections and claimed outcomes are untrusted data.
This local, plaintext journal never signs, executes, fetches, publishes or
changes native state. The owner filesystem is trusted: retained heads detect
alteration, but do not prevent replacement with an older valid database.
"""
from copy import deepcopy
from functools import wraps
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import threading

VERSION = 'covenant-request-workspace/0.1'
KINDS = ('NOTE', 'PROPOSAL', 'SELECT', 'REVISE', 'EVIDENCE', 'OUTCOME')
MAX_EVENT_BYTES = 65536
MAX_REQUEST_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 32 * 1024 * 1024
MAX_EVENTS = 512
MAX_REQUESTS = 1024
MAX_DEPTH = 24
DEFAULT_MEANING = ('The declared parties adopt the exact referenced request snapshot and selected '
                   'proposal under these stated terms. Selection is not prior assent, and source '
                   'text is not automatically interpreted or executed. All proposal metadata is '
                   'preserved as exact declared claims; agreement does not establish their truth.')
_HASH = re.compile(r'[0-9a-f]{64}\Z')
_OP = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,95}\Z')
_ZERO = '0' * 64
TEMPLATE = 'covenant-request-template/0.1'


def _need(ok, code):
    if not ok:
        raise ValueError(code)


def canonical(value):
    """Exact, bounded JSON: bool and integer remain different; no floats."""
    pending = [(value, 0)]
    nodes = 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        _need(depth <= MAX_DEPTH and nodes <= 8192, 'REQUEST_COMPLEXITY_LIMIT')
        if item is None or type(item) is bool:
            continue
        if type(item) is int:
            _need(abs(item) <= 2**53 - 1, 'REQUEST_INTEGER_RANGE')
        elif type(item) is str:
            try:
                size = len(item.encode('utf-8'))
            except UnicodeError:
                raise ValueError('REQUEST_UTF8') from None
            _need(size <= 32768, 'REQUEST_STRING_LIMIT')
        elif type(item) is list:
            _need(len(item) <= 1024, 'REQUEST_ARRAY_LIMIT')
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is dict:
            _need(len(item) <= 512 and all(type(k) is str for k in item), 'REQUEST_OBJECT')
            for key, child in item.items():
                _need(len(key) <= 128, 'REQUEST_KEY_LIMIT')
                try:
                    key.encode('utf-8')
                except UnicodeError:
                    raise ValueError('REQUEST_UTF8') from None
                pending.append((child, depth + 1))
        else:
            raise ValueError('REQUEST_JSON_TYPE')
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'),
                     allow_nan=False).encode('utf-8')
    _need(len(raw) <= MAX_EVENT_BYTES, 'REQUEST_EVENT_SIZE')
    return raw


def _id(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + canonical(value)).hexdigest()


def _hash(value):
    _need(type(value) is str and _HASH.fullmatch(value) is not None, 'REQUEST_REFERENCE')


def _template(record, expected_id):
    _hash(expected_id)
    _fields(record, ('profile', 'name', 'tags', 'source', 'need', 'terms', 'metadata', 'documents'),
            ('profile', 'name', 'tags', 'source', 'need', 'terms', 'metadata', 'documents'))
    _need(record['profile'] == TEMPLATE and
          _id('COVENANT-REQUEST-TEMPLATE-0.1', record) == expected_id, 'REQUEST_TEMPLATE_CHANGED')
    _need_value(record['need'])
    _need(type(record['terms']) is str and bool(record['terms'].strip()) and
          type(record['metadata']) is dict and type(record['documents']) is dict and type(record['name']) is str and
          1 <= len(record['name']) <= 128, 'REQUEST_TEMPLATE_FIELDS')
    tags = record['tags']
    _need(type(tags) is list and len(tags) <= 16 and
          all(type(t) is str and 1 <= len(t) <= 64 for t in tags) and
          tags == sorted(set(tags)), 'REQUEST_TEMPLATE_TAGS')
    _fields(record['source'], ('request', 'head', 'proposal', 'parent_template'), ('request', 'head', 'proposal'))
    for ref in record['source'].values():
        _hash(ref)


def _fields(value, allowed, required=()):
    _need(type(value) is dict and set(required) <= set(value) <= set(allowed), 'REQUEST_FIELDS')


def _need_value(value):
    _fields(value, ('goal', 'requirements', 'details'), ('goal', 'requirements', 'details'))
    _need(type(value['goal']) is str and bool(value['goal'].strip()), 'REQUEST_GOAL')
    _need(type(value['requirements']) is dict and type(value['details']) is dict, 'REQUEST_OBJECT')
    canonical(value)


def _flags():
    return {'private': True, 'encrypted': False, 'published': False,
            'agreement_adopted': False, 'signature_created': False,
            'execution_authorized': False, 'chain_ledger_touched': False,
            'payment_verified': False, 'network': False}


def describe():
    """Describe preparation without opening a filesystem or requiring a host."""
    return {'version': VERSION, 'kinds': list(KINDS),
            'reuse': {'save': 'covenant_request_write.save_template',
                      'find': 'covenant_request.templates', 'adapt': 'covenant_request_write.reuse_template',
                      'adopt': 'Explicit SELECT, agreement with fresh context and separate role signatures',
                      'documents': 'Explicitly supplied inert method bytes; no fetch, execution or inherited authority'},
            'limits': {'event_bytes': MAX_EVENT_BYTES, 'request_bytes': MAX_REQUEST_BYTES,
                       'total_bytes': MAX_TOTAL_BYTES, 'events_per_request': MAX_EVENTS,
                       'requests': MAX_REQUESTS, 'depth': MAX_DEPTH},
            'storage': 'OWNER_PRIVATE_PLAINTEXT_LOCAL_SQLITE_NOT_CONSENSUS',
            'integrity': 'HASH_LINKS_AND_LOCAL_CAS; RETAIN_HEAD_SEPARATELY_TO_DETECT_ROLLBACK',
            'proposal': {'terms': 'Exact UTF8 text', 'need_revision': 'Optional current revision hash',
                         'parent_proposal': 'Optional earlier proposal event hash',
                         'allow_stale_branch': 'Explicit bool; old-need proposals cannot be selected',
                         'metadata': 'Optional bounded JSON object; untrusted data'},
            'comparison': 'requirements fields compare to same-named metadata fields as exact typed '
                          'literal declarations; absence is UNKNOWN, no semantics or world verification. '
                          'requirements.budget {amount,unit} separately compares metadata.price {amount,unit} '
                          'as an integer ceiling only when units match exactly; no currency conversion.',
            'selection': 'SELECT {proposal:<exact proposal event hash>}; no assent or execution',
            'revision': 'REVISE a nonempty goal/requirements/details patch; clears selection',
            'retry': 'Supply create.operation_id and reuse exact original append arguments after an uncertain reply. '
                     'Retries return the original committed snapshot; get observes latest.',
            'agreement': 'Choose a current-need proposal, inspect exact source documents, '
                         'then obtain separate role signatures on the external-draft payload.',
            **_flags()}


def _directory(directory):
    """Create/open real directory components without following symlinks."""
    path = Path(os.path.abspath(os.fspath(directory)))
    # macOS exposes its OS-owned temporary roots through these two fixed
    # aliases. Expand only their exact standard target, then continue the
    # no-follow component walk. User-created symlinks remain inadmissible.
    for alias, target in (('/var', '/private/var'), ('/tmp', '/private/tmp')):
        if str(path) == alias or str(path).startswith(alias + '/'):
            try:
                actual_target = os.readlink(alias)
            except OSError:
                continue
            if actual_target in (target, target.lstrip('/')):
                path = Path(target + str(path)[len(alias):])
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            try:
                next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except FileNotFoundError:
                try:
                    os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
                next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        info = os.fstat(fd)
        _need(info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0,
              'REQUEST_PRIVATE_DIRECTORY')
        return path, fd
    except BaseException:
        os.close(fd)
        raise


def _serialized(method):
    """One owner instance serializes its SQLite connection across SDK threads."""
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return guarded


class RequestWorkspace:
    """A bounded local journal; independent processes use transactional CAS."""
    def __init__(self, directory):
        self._lock = threading.RLock()
        self.directory, self._dirfd = _directory(directory)
        self.db = None
        try:
            try:
                fd = os.open('requests.sqlite', os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o600, dir_fd=self._dirfd)
                os.close(fd)
            except FileExistsError:
                pass
            self._check_files()
            before = os.stat('requests.sqlite', dir_fd=self._dirfd, follow_symlinks=False)
            self.db = sqlite3.connect(self.directory / 'requests.sqlite', isolation_level=None,
                                      timeout=10, check_same_thread=False)
            after = os.stat('requests.sqlite', dir_fd=self._dirfd, follow_symlinks=False)
            _need((before.st_dev, before.st_ino) == (after.st_dev, after.st_ino), 'REQUEST_STORAGE_CHANGED')
            self._database_identity = (after.st_dev, after.st_ino)
            self.db.execute('PRAGMA journal_mode=WAL')
            self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('PRAGMA foreign_keys=ON')
            self.db.execute('CREATE TABLE IF NOT EXISTS requests '
                            '(ordinal INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, nonce TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS events '
                            '(request TEXT NOT NULL REFERENCES requests(id), sequence INTEGER NOT NULL, '
                            'id TEXT UNIQUE NOT NULL, operation TEXT NOT NULL, body BLOB NOT NULL, '
                            'PRIMARY KEY(request,sequence), UNIQUE(request,operation))')
            self.db.execute('CREATE TABLE IF NOT EXISTS create_operations '
                            '(operation TEXT PRIMARY KEY, intent TEXT NOT NULL, '
                            'request TEXT UNIQUE NOT NULL REFERENCES requests(id))')
            for table in ('requests', 'events', 'create_operations'):
                for action in ('UPDATE', 'DELETE'):
                    self.db.execute(f'CREATE TRIGGER IF NOT EXISTS immutable_{table}_{action.lower()} '
                                    f'BEFORE {action} ON {table} BEGIN SELECT '
                                    "RAISE(ABORT,'REQUEST_APPEND_ONLY'); END")
            self._check_files()
        except BaseException:
            self.close()
            raise

    def _check_files(self):
        info = os.fstat(self._dirfd)
        actual = os.stat(self.directory, follow_symlinks=False)
        _need(stat.S_ISDIR(actual.st_mode) and (actual.st_dev, actual.st_ino) == (info.st_dev, info.st_ino)
              and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0,
              'REQUEST_PRIVATE_DIRECTORY')
        for name in ('requests.sqlite', 'requests.sqlite-wal', 'requests.sqlite-shm', 'requests.sqlite-journal'):
            try:
                file_info = os.stat(name, dir_fd=self._dirfd, follow_symlinks=False)
            except FileNotFoundError:
                _need(name != 'requests.sqlite', 'REQUEST_STORAGE_CHANGED')
                continue
            # Never open/close a live SQLite file outside SQLite: POSIX close()
            # drops every process fcntl lock on that inode, including the WAL
            # dead-man lock. lstat-equivalent checks retain no-follow safety.
            _need(stat.S_ISREG(file_info.st_mode) and file_info.st_nlink == 1
                  and file_info.st_uid == os.getuid() and stat.S_IMODE(file_info.st_mode) & 0o077 == 0,
                  'REQUEST_PRIVATE_FILE')
            if name == 'requests.sqlite' and hasattr(self, '_database_identity'):
                _need((file_info.st_dev, file_info.st_ino) == self._database_identity,
                      'REQUEST_STORAGE_CHANGED')

    @_serialized
    def close(self):
        if self.db is not None:
            self.db.close()
            self.db = None
        if getattr(self, '_dirfd', None) is not None:
            os.close(self._dirfd)
            self._dirfd = None

    @_serialized
    def __enter__(self):
        return self

    @_serialized
    def __exit__(self, *_):
        self.close()

    @_serialized
    def describe(self):
        return describe()

    @_serialized
    def save_template(self, request_id, expected_head, name, operation_id, tags=None, documents=None):
        """Save an exact selected snapshot as a private, untrusted reusable method."""
        _hash(expected_head)
        events = self._history(request_id)
        prior = next((i for i, e in enumerate(events) if e['id'] == expected_head), None)
        _need(prior is not None, 'REQUEST_TEMPLATE_SOURCE_HEAD')
        state = self._project(request_id, events[:prior + 1])
        selected = next((p for p in state['proposals'] if p['id'] == state['selected_proposal']), None)
        _need(selected is not None, 'REQUEST_SELECTION_REQUIRED')
        _need(type(name) is str and bool(name.strip()) and len(name) <= 128, 'REQUEST_TEMPLATE_NAME')
        tags = [] if tags is None else tags
        _need(type(tags) is list and len(tags) <= 16 and
              all(type(t) is str and 1 <= len(t) <= 64 for t in tags) and
              len(set(tags)) == len(tags), 'REQUEST_TEMPLATE_TAGS')
        source = {'request': request_id, 'head': expected_head, 'proposal': selected['id']}
        need_snapshot = deepcopy(state['need'])
        parent = need_snapshot['details'].pop('reused_method', None)
        if parent is not None:
            _fields(parent, ('id', 'template', 'adoption'), ('id', 'template', 'adoption'))
            _need(parent['adoption'] == 'FRESH_SELECTION_CONTEXT_AND_ROLE_SIGNATURES_REQUIRED',
                  'REQUEST_TEMPLATE_RESERVED_PROVENANCE')
            _template(parent['template'], parent['id'])
            source['parent_template'] = parent['id']
        documents = {} if documents is None else documents
        _need(type(documents) is dict, 'REQUEST_TEMPLATE_DOCUMENTS')
        if parent is not None and not documents:
            documents = parent['template']['documents']
        record = {'profile': TEMPLATE, 'name': name, 'tags': sorted(tags),
                  'source': source,
                  'need': need_snapshot, 'terms': selected['terms'],
                  'metadata': deepcopy(selected['metadata']), 'documents': deepcopy(documents)}
        ref = _id('COVENANT-REQUEST-TEMPLATE-0.1', record)
        saved = self.append(request_id, expected_head, 'NOTE',
                            {'type': 'REUSABLE_METHOD', 'template': record, 'template_id': ref}, operation_id)
        return {'id': ref, 'template': record, 'saved_event': saved['head'],
                'operation': saved['operation'], 'successful_performance': 'NOT_ESTABLISHED',
                'adopted': False, **_flags()}

    @_serialized
    def templates(self, query='', cursor=None, limit=20):
        """Page private saved templates; popularity is never inferred from saving."""
        _need(type(query) is str and len(query) <= 128, 'REQUEST_TEMPLATE_QUERY')
        _need(type(limit) is int and 1 <= limit <= 100, 'REQUEST_PAGE_LIMIT')
        self._check_files()
        floor = 0
        if cursor is not None:
            _hash(cursor)
            row = self.db.execute('SELECT rowid FROM events WHERE id=?', (cursor,)).fetchone()
            _need(row is not None, 'REQUEST_CURSOR')
            floor = row[0]
        # Logical history is already quota-bounded to 32 MiB. Validate each
        # matching record through its hash-linked history before returning it.
        rows = self.db.execute('SELECT rowid,request,id FROM events WHERE rowid>? AND '
                               'instr(CAST(body AS TEXT),?)>0 ORDER BY rowid',
                               (floor, '"type":"REUSABLE_METHOD"')).fetchall()
        results = []
        invalid = 0
        for _, request_id, event_id in rows:
            event = next(e for e in self._history(request_id) if e['id'] == event_id)
            value = event['value']
            if event['kind'] != 'NOTE' or value.get('type') != 'REUSABLE_METHOD':
                continue
            record = value.get('template')
            ref = value.get('template_id')
            try:
                _template(record, ref)
            except ValueError:
                invalid += 1
                continue
            haystack = ' '.join([record['name'], *record['tags'], record['need']['goal']]).casefold()
            if query.casefold() not in haystack:
                continue
            results.append({'id': ref, 'template': record, 'saved_event': event_id,
                            'adopted': False, 'successful_performance': 'NOT_ESTABLISHED'})
            if len(results) > limit:
                break
        more = len(results) > limit
        results = results[:limit]
        return {'templates': results, 'next_cursor': results[-1]['saved_event'] if more else None,
                'invalid_claims_ignored': invalid,
                'ranking': 'LOCAL_APPEND_ORDER_NOT_REPUTATION', **_flags()}

    @_serialized
    def reuse_template(self, template, expected_id, operation_id, goal=None, terms=None,
                      requirements=None, metadata=None):
        """Create a fresh, unselected proposal. Old signatures/authority never transfer."""
        _template(template, expected_id)
        _need(type(operation_id) is str and len(operation_id) <= 80 and
              _OP.fullmatch(operation_id) is not None, 'REQUEST_OPERATION_ID')
        need = template['need']
        # Provenance is retained in full, so edits are inspectable and every
        # selected agreement opens the exact new proposal and original method.
        details = deepcopy(need['details'])
        _need('reused_method' not in details, 'REQUEST_TEMPLATE_RESERVED_PROVENANCE')
        details['reused_method'] = {'id': expected_id, 'template': deepcopy(template),
                                    'adoption': 'FRESH_SELECTION_CONTEXT_AND_ROLE_SIGNATURES_REQUIRED'}
        chosen_terms = template['terms'] if terms is None else terms
        chosen_metadata = template['metadata'] if metadata is None else metadata
        _need(type(chosen_terms) is str and bool(chosen_terms.strip()) and
              type(chosen_metadata) is dict, 'REQUEST_TEMPLATE_FIELDS')
        canonical({'terms': chosen_terms, 'metadata': chosen_metadata})
        created = self.create(need['goal'] if goal is None else goal,
                              need['requirements'] if requirements is None else requirements,
                              details, operation_id + ':create')
        proposed = self.append(created['id'], created['head'], 'PROPOSAL',
                               {'terms': chosen_terms, 'metadata': chosen_metadata},
                               operation_id + ':proposal')
        return {**proposed, 'template_id': expected_id, 'adopted': False,
                'next_action': 'REVIEW_COMPARE_SELECT_THEN_PREPARE_WITH_FRESH_CONTEXT_AND_ROLE_SIGNATURES'}

    def _history(self, request_id):
        _hash(request_id)
        record = self.db.execute('SELECT nonce FROM requests WHERE id=?', (request_id,)).fetchone()
        _need(record is not None, 'REQUEST_MISSING')
        rows = self.db.execute('SELECT sequence,id,operation,body FROM events WHERE request=? '
                               'ORDER BY sequence LIMIT ?', (request_id, MAX_EVENTS + 1)).fetchall()
        _need(1 <= len(rows) <= MAX_EVENTS, 'REQUEST_HISTORY_CHANGED')
        previous = _ZERO
        events = []
        total = 0
        for expected, (sequence, ref, operation, raw) in enumerate(rows, 1):
            _need(type(raw) is bytes and len(raw) <= MAX_EVENT_BYTES, 'REQUEST_HISTORY_CHANGED')
            try:
                body = json.loads(raw)
            except (ValueError, UnicodeError, RecursionError):
                raise ValueError('REQUEST_HISTORY_CHANGED') from None
            _need(canonical(body) == raw, 'REQUEST_HISTORY_CHANGED')
            _fields(body, ('version', 'request', 'sequence', 'previous', 'kind', 'value', 'operation_id', 'intent'),
                    ('version', 'request', 'sequence', 'previous', 'kind', 'value', 'operation_id', 'intent'))
            _need(body['version'] == VERSION and body['request'] == request_id and type(sequence) is int
                  and type(body['sequence']) is int and sequence == expected == body['sequence']
                  and body['previous'] == previous and body['operation_id'] == operation
                  and _id('COVENANT-REQUEST-EVENT-0.1', body) == ref, 'REQUEST_HISTORY_CHANGED')
            _hash(body['intent'])
            events.append({'id': ref, **body})
            total += len(raw)
            previous = ref
        _need(total <= MAX_REQUEST_BYTES, 'REQUEST_HISTORY_CHANGED')
        _need(events[0]['kind'] == 'CREATE' and events[0]['operation_id'] == '@create', 'REQUEST_HISTORY_CHANGED')
        _need(_id('COVENANT-REQUEST-0.1', {'nonce': record[0], 'need': events[0]['value']}) == request_id,
              'REQUEST_HISTORY_CHANGED')
        return events

    def _project(self, request_id, events):
        need_value = None
        revision = None
        selection = None
        proposals = {}
        revisions = {}
        for event in events:
            kind, value = event['kind'], event['value']
            if kind in ('CREATE', 'REVISE'):
                _need((kind == 'CREATE') == (revision is None), 'REQUEST_HISTORY_CHANGED')
                _need_value(value)
                need_value = deepcopy(value)
                revision = event['id']
                revisions[revision] = deepcopy(value)
                selection = None
            elif kind == 'PROPOSAL':
                _fields(value, ('terms', 'need_revision', 'parent_proposal', 'allow_stale_branch', 'metadata'),
                        ('terms', 'need_revision', 'parent_proposal', 'allow_stale_branch', 'metadata'))
                _need(type(value['terms']) is str and bool(value['terms'].strip())
                      and type(value['metadata']) is dict and type(value['allow_stale_branch']) is bool,
                      'REQUEST_PROPOSAL')
                _hash(value['need_revision'])
                _need(value['need_revision'] in revisions, 'REQUEST_NEED_REVISION')
                if value['parent_proposal'] is not None:
                    _hash(value['parent_proposal'])
                    _need(value['parent_proposal'] in proposals, 'REQUEST_PARENT_PROPOSAL')
                    _need(proposals[value['parent_proposal']]['need_revision'] == value['need_revision'],
                          'REQUEST_PARENT_REVISION')
                _need(value['need_revision'] == revision or value['allow_stale_branch'], 'REQUEST_STALE_PROPOSAL')
                proposals[event['id']] = {'id': event['id'], **deepcopy(value)}
            elif kind == 'SELECT':
                _fields(value, ('proposal',), ('proposal',))
                _hash(value['proposal'])
                _need(value['proposal'] in proposals, 'REQUEST_PROPOSAL_MISSING')
                _need(proposals[value['proposal']]['need_revision'] == revision, 'REQUEST_STALE_SELECTION')
                selection = value['proposal']
            else:
                _need(kind in ('NOTE', 'EVIDENCE', 'OUTCOME') and type(value) is dict, 'REQUEST_KIND')
        return {'version': VERSION, 'id': request_id, 'request_id': request_id,
                'head': events[-1]['id'], 'need_revision': revision, 'need': need_value,
                'selected_proposal': selection, 'proposals': list(proposals.values()),
                'events': deepcopy(events), 'saved': True, 'state': 'SELECTED' if selection else 'OPEN',
                'claims': 'MESSAGES_EVIDENCE_AND_OUTCOMES_ARE_UNTRUSTED_LOCAL_RECORDS', **_flags()}

    def _get(self, request_id):
        return self._project(request_id, self._history(request_id))

    @_serialized
    def get(self, request_id):
        self._check_files()
        return self._get(request_id)

    def _insert(self, request_id, events, kind, value, operation_id, intent):
        body = {'version': VERSION, 'request': request_id, 'sequence': len(events) + 1,
                'previous': events[-1]['id'] if events else _ZERO, 'kind': kind,
                'value': deepcopy(value), 'operation_id': operation_id, 'intent': intent}
        raw = canonical(body)
        _need(len(events) < MAX_EVENTS, 'REQUEST_EVENT_QUOTA')
        used = self.db.execute('SELECT coalesce(sum(length(body)),0) FROM events WHERE request=?',
                               (request_id,)).fetchone()[0]
        total = self.db.execute('SELECT coalesce(sum(length(body)),0) FROM events').fetchone()[0]
        _need(used + len(raw) <= MAX_REQUEST_BYTES and total + len(raw) <= MAX_TOTAL_BYTES,
              'REQUEST_STORAGE_QUOTA')
        ref = _id('COVENANT-REQUEST-EVENT-0.1', body)
        candidate = {'id': ref, **body}
        # Validate the prospective state before extending the journal.
        self._project(request_id, [*events, candidate])
        self.db.execute('INSERT INTO events VALUES (?,?,?,?,?)',
                        (request_id, len(events) + 1, ref, operation_id, raw))
        return ref

    @_serialized
    def create(self, goal, requirements=None, details=None, operation_id=None):
        value = {'goal': goal, 'requirements': {} if requirements is None else requirements,
                 'details': {} if details is None else details}
        _need_value(value)
        _need(operation_id is None or (type(operation_id) is str and _OP.fullmatch(operation_id) is not None),
              'REQUEST_OPERATION_ID')
        intent = _id('COVENANT-REQUEST-CREATE-0.1', value)
        nonce = secrets.token_hex(32)
        request_id = _id('COVENANT-REQUEST-0.1', {'nonce': nonce, 'need': value})
        self._check_files()
        self.db.execute('BEGIN IMMEDIATE')
        try:
            if operation_id is not None:
                prior = self.db.execute('SELECT intent,request FROM create_operations WHERE operation=?',
                                        (operation_id,)).fetchone()
                if prior is not None:
                    _need(prior[0] == intent, 'REQUEST_OPERATION_CHANGED')
                    result = self._project(prior[1], self._history(prior[1])[:1])
                    self.db.execute('COMMIT')
                    return {**result, 'operation': {'id': operation_id, 'event': result['head'], 'replayed': True},
                            'replay_basis': 'ORIGINAL_COMMITTED_SNAPSHOT; GET_TO_OBSERVE_LATEST'}
            _need(self.db.execute('SELECT count(*) FROM requests').fetchone()[0] < MAX_REQUESTS,
                  'REQUEST_COUNT_QUOTA')
            self.db.execute('INSERT INTO requests(id,nonce) VALUES (?,?)', (request_id, nonce))
            self._insert(request_id, [], 'CREATE', value, '@create', intent)
            if operation_id is not None:
                self.db.execute('INSERT INTO create_operations VALUES (?,?,?)', (operation_id, intent, request_id))
            result = self._get(request_id)
            self.db.execute('COMMIT')
            return result if operation_id is None else {
                **result, 'operation': {'id': operation_id, 'event': result['head'], 'replayed': False},
                'replay_basis': 'ORIGINAL_COMMITTED_SNAPSHOT; GET_TO_OBSERVE_LATEST'}
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    @_serialized
    def append(self, request_id, expected_head, kind, value, operation_id):
        _hash(request_id)
        _hash(expected_head)
        _need(type(kind) is str and kind in KINDS, 'REQUEST_KIND')
        _need(type(operation_id) is str and _OP.fullmatch(operation_id) is not None, 'REQUEST_OPERATION_ID')
        _need(type(value) is dict, 'REQUEST_OBJECT')
        intent = _id('COVENANT-REQUEST-APPEND-0.1', {'request': request_id, 'expected_head': expected_head,
                                                   'kind': kind, 'value': value, 'operation_id': operation_id})
        value = deepcopy(value)
        self._check_files()
        self.db.execute('BEGIN IMMEDIATE')
        try:
            events = self._history(request_id)
            previous = next((event for event in events if event['operation_id'] == operation_id), None)
            if previous is not None:
                _need(previous['intent'] == intent, 'REQUEST_OPERATION_CHANGED')
                # Return the original committed result, even after later changes.
                result = self._project(request_id, events[:previous['sequence']])
                ref = previous['id']
                replayed = True
            else:
                state = self._project(request_id, events)
                _need(state['head'] == expected_head, 'REQUEST_HEAD_CHANGED')
                if kind == 'REVISE':
                    _fields(value, ('goal', 'requirements', 'details'))
                    _need(bool(value), 'REQUEST_REVISION_EMPTY')
                    value = {**state['need'], **value}
                    _need_value(value)
                    _need(canonical(value) != canonical(state['need']), 'REQUEST_REVISION_UNCHANGED')
                elif kind == 'PROPOSAL':
                    _fields(value, ('terms', 'need_revision', 'parent_proposal', 'allow_stale_branch', 'metadata'),
                            ('terms',))
                    value = {'terms': value['terms'], 'need_revision': value.get('need_revision', state['need_revision']),
                             'parent_proposal': value.get('parent_proposal'),
                             'allow_stale_branch': value.get('allow_stale_branch', False),
                             'metadata': value.get('metadata', {})}
                ref = self._insert(request_id, events, kind, value, operation_id, intent)
                result = self._get(request_id)
                replayed = False
            self.db.execute('COMMIT')
            return {**result, 'operation': {'id': operation_id, 'event': ref, 'replayed': replayed},
                    'replay_basis': 'ORIGINAL_COMMITTED_SNAPSHOT; GET_TO_OBSERVE_LATEST'}
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    @_serialized
    def list(self, cursor=None, limit=20):
        _need(type(limit) is int and 1 <= limit <= 100, 'REQUEST_PAGE_LIMIT')
        self._check_files()
        floor = 0
        if cursor is not None:
            _hash(cursor)
            row = self.db.execute('SELECT ordinal FROM requests WHERE id=?', (cursor,)).fetchone()
            _need(row is not None, 'REQUEST_CURSOR')
            floor = row[0]
        rows = self.db.execute('SELECT ordinal,id FROM requests WHERE ordinal>? ORDER BY ordinal LIMIT ?',
                               (floor, limit + 1)).fetchall()
        items = []
        for _, ref in rows[:limit]:
            value = self._get(ref)
            items.append({key: value[key] for key in ('id', 'head', 'need_revision', 'state', 'selected_proposal')})
            items[-1]['goal'] = value['need']['goal']
        return {'version': VERSION, 'items': items,
                'next_cursor': rows[limit - 1][1] if len(rows) > limit else None, **_flags()}

    @_serialized
    def compare(self, request_id):
        state = self.get(request_id)
        proposals = {proposal['id']: proposal for proposal in state['proposals']}
        rows = []
        for proposal in proposals.values():
            parent = proposals.get(proposal['parent_proposal'])
            requirements = []
            for field, expected in sorted(state['need']['requirements'].items()):
                present = field in proposal['metadata']
                declared = proposal['metadata'].get(field)
                status = ('UNKNOWN' if not present else 'EXACT_DECLARED_MATCH'
                          if canonical(expected) == canonical(declared) else 'DECLARED_MISMATCH')
                requirements.append({'field': field, 'expected': deepcopy(expected),
                                     'declared': deepcopy(declared), 'present': present, 'status': status})
            rows.append({**deepcopy(proposal), 'matches_current_need': proposal['need_revision'] == state['need_revision'],
                         'selected': proposal['id'] == state['selected_proposal'],
                         'terms_sha256': hashlib.sha256(proposal['terms'].encode('utf-8')).hexdigest(),
                         'parent_terms': None if parent is None else parent['terms'],
                         'terms_changed_from_parent': None if parent is None else
                         proposal['terms'].encode('utf-8') != parent['terms'].encode('utf-8'),
                         'requirements_comparison': requirements,
                         'budget_comparison': _budget(state['need']['requirements'].get('budget'),
                                                      proposal['metadata'].get('price')),
                         'interpretation': 'EXACT_SOURCE_COMPARISON_NOT_SEMANTIC_OR_LEGAL_EQUIVALENCE'})
        return {'version': VERSION, 'id': request_id, 'head': state['head'],
                'need_revision': state['need_revision'], 'selected_proposal': state['selected_proposal'],
                'proposals': rows, **_flags()}

    @_serialized
    def agreement(self, request_id, parties, context, meaning=DEFAULT_MEANING):
        """Prepare the existing external-source profile, with no signing/write."""
        from covenant_language import external_drafts
        canonical(parties)
        canonical(meaning)
        _hash(context)
        state = self.get(request_id)
        selected = next((p for p in state['proposals'] if p['id'] == state['selected_proposal']), None)
        _need(selected is not None and selected['need_revision'] == state['need_revision'], 'REQUEST_SELECTION_REQUIRED')
        # Each input was independently bounded by its historical event. The
        # document combines both exact openings, so allow their combined size
        # without relaxing event admission limits or dropping proposal metadata.
        request_source = json.dumps({'version': VERSION, 'request': request_id, 'need_revision': state['need_revision'],
                                     'need': state['need'], 'selected_proposal': selected['id'],
                                     'proposal': selected}, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode('utf-8')
        _need(len(request_source) <= external_drafts.MAX_BYTES, 'REQUEST_AGREEMENT_SIZE')
        terms_source = selected['terms'].encode('utf-8')
        sources = {'request': request_source, 'terms': terms_source}
        documents = {}
        inspectable = {}
        for alias, raw in sources.items():
            encoded = base64.b64encode(raw).decode('ascii')
            packed = external_drafts.pack(encoded, title='Request snapshot' if alias == 'request' else 'Selected proposal',
                                          media_type='application/json' if alias == 'request' else 'text/plain',
                                          language='opaque')
            documents[alias] = packed['document']
            inspectable[alias] = {'source_base64': encoded, 'source_sha256': packed['source_sha256'],
                                 'bytes': len(raw), 'document_id': packed['id']}
        prepared = external_drafts.prepare(documents, parties, context, title='Request agreement', meaning=meaning)
        return {'version': VERSION, 'request_id': request_id, 'head': state['head'],
                'need_revision': state['need_revision'], 'selected_proposal': selected['id'],
                'sources': inspectable, 'prepare_input': {'documents': documents, 'parties': deepcopy(parties),
                                                        'context': context, 'title': 'Request agreement', 'meaning': meaning},
                'prepared': prepared, 'next_action': 'REVIEW_EXACT_DOCUMENTS_AND_OBTAIN_SEPARATE_ROLE_SIGNATURES',
                'recorded': False, **_flags()}


def _budget(budget, price):
    result = {'status': 'UNKNOWN', 'budget': deepcopy(budget), 'price': deepcopy(price),
              'basis': 'UNVERIFIED_DECLARED_EXACT_UNIT_INTEGER_CEILING; NO_FX_OR_EXECUTION_AUTHORITY'}
    if not (type(budget) is dict and type(price) is dict
            and {'amount', 'unit'} <= set(budget) and {'amount', 'unit'} <= set(price)
            and type(budget['amount']) is int and type(price['amount']) is int
            and budget['amount'] >= 0 and price['amount'] >= 0
            and type(budget['unit']) is str and bool(budget['unit'])
            and type(price['unit']) is str and bool(price['unit'])):
        return result
    if budget['unit'].encode('utf-8') != price['unit'].encode('utf-8'):
        result['status'] = 'INCOMPARABLE_UNIT'
    else:
        result['status'] = 'WITHIN_DECLARED_BUDGET' if price['amount'] <= budget['amount'] else 'EXCEEDS_DECLARED_BUDGET'
    return result
