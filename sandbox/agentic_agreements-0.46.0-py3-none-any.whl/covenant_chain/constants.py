"""Shared names for the Agentic Agreements Protocol.

Wire identifiers keep the historical prefix. Prose uses ``PRODUCT_NAME``.
``LEGACY_SLUG`` is the one place that prefix is spelled.
"""

PRODUCT_NAME = 'Agentic Agreements Protocol'
LEGACY_SLUG = 'covenant'
TOOL_PREFIX = LEGACY_SLUG + '_'
SURFACE_ROUTE = '/surface'
SURFACE_METHOD = 'surface/describe'
AGENT_SURFACE_FIELDS = 'AGENT_SURFACE_FIELDS'
AGENT_SURFACE_REFUSED = 'AGENT_SURFACE_REFUSED'


def tool(suffix):
    """Build a wire tool name from a suffix. The prefix is not repeated."""
    if type(suffix) is not str or not suffix or '/' in suffix or suffix.startswith(TOOL_PREFIX):
        raise ValueError(AGENT_SURFACE_FIELDS)
    return TOOL_PREFIX + suffix


SURFACE_TOOL = tool('surface')
