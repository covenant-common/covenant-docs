"""Append-only revenue ledger. Every fee and reward inflow is an event. Totals are public.

Founder payments are recorded only against an inflow in the same transaction.
The ledger does not mint and does not spend treasury principal.
"""
from .crypto import integer, need
from .founder_share import FLOWS

EVENT_LIMIT = 4096


def empty_totals():
    return {'gross': 0, 'cost': 0, 'founder': 0, 'users': 0, 'protocol': 0}


def record(meter, height, flow, source_op, gross, cost, founder, users, protocol, rate_bps, band, revenue=True):
    need(flow in FLOWS, 'LEDGER_FLOW')
    integer(height)
    integer(gross)
    integer(cost)
    integer(founder)
    integer(users)
    integer(protocol)
    integer(rate_bps)
    # Measured cost can exceed the charged gross when the reference price caps a deficit.
    # Founder and user legs still cannot exceed the gross, and nothing is minted.
    need(founder <= gross and users <= gross and protocol <= gross, 'LEDGER_CONSERVATION')
    event = {'height': height, 'flow': flow, 'source_op': source_op, 'gross': gross, 'cost': cost,
             'founder': founder, 'users': users, 'protocol': protocol, 'rate_bps': rate_bps,
             'band': band, 'minted': 0, 'revenue': bool(revenue)}
    # A cost observation is on this same ledger. It is not revenue, so it does not
    # move the founder schedule or the revenue totals.
    if revenue:
        totals = dict(meter.get('totals') or empty_totals())
        for name in ('gross', 'cost', 'founder', 'users', 'protocol'):
            totals[name] = totals.get(name, 0) + event[name]
        meter['totals'] = totals
        meter['rolling_gross'] = meter.get('rolling_gross', 0) + gross
    rows = list(meter.get('ledger') or [])
    rows.append(event)
    meter['ledger'] = rows[-EVENT_LIMIT:]
    return event


def public_totals(meter):
    totals = dict(meter.get('totals') or empty_totals())
    totals.update(execution_authorized=False, token_issuance=0, queryable=True)
    return totals


def by_flow(meter):
    found = {}
    for event in meter.get('ledger') or []:
        row = found.setdefault(event['flow'], {'gross': 0, 'founder': 0, 'events': 0})
        row['gross'] += event['gross']
        row['founder'] += event['founder']
        row['events'] += 1
    return found
