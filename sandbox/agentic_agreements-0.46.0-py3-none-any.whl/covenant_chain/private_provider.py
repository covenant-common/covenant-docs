"""Successor provider replication 0.2: encrypted journal, scoped inclusion proofs.

No lifetime command/history wire limit. Individual commands, pages and proofs
remain bounded. Validators retain complete signing journals and see plaintext;
clients receive only selected account receipts and opaque sibling commitments.
Quorum validates private global transitions. Inclusion is not a ZK proof.
"""
from collections import OrderedDict
from copy import deepcopy
from dataclasses import dataclass
import fcntl
import hashlib
import hmac
import os
from pathlib import Path
import secrets
import sys
import threading
from types import SimpleNamespace

from cryptography.exceptions import InvalidTag
from covenant_language.safe_io import atomic_write
from . import crypto as c, resource_provider as p, provider_replication as old
from .agent_tools import decode
from .consensus import Engine
from .storage import Journal
from .workflow_store import canonical, identifier

VERSION = 'covenant-provider-replication/0.2'
RECEIPT = 'covenant-private-provider-receipt/0.2'
PROOF = 'covenant-account-provider-proof/0.2'
COMMAND_LABEL = 'COVENANT-PRIVATE-PROVIDER-COMMAND-0.2'
MAX_ENVELOPE_BYTES = 100000
PAGE_LIMIT = 16
PAGE_BYTES = 500000
MAX_PROOF_BYTES = 650000
SUITE = 'AES-256-GCM-SIV'
CLUSTER_OBSERVES_PLAINTEXT = 'CLUSTER_OBSERVES_PLAINTEXT'


def privacy_boundary():
    """What a 0.2 provider receipt does and does not hide.

    Validators still see the plaintext command. The client receipt does not
    include other accounts. This is not a zero-knowledge proof.
    """
    return {'boundary': CLUSTER_OBSERVES_PLAINTEXT,
            'validators_observe_command_plaintext': True,
            'zero_knowledge': False,
            'client_receipt_hides_other_accounts': True}


def _context_body(context):
    c.exact(context,'version cluster provider validators faults max_clock_skew privacy_key_hash')
    body = {k:deepcopy(v) for k,v in context.items() if k != 'cluster'}
    c.need(body['version'] == VERSION,'PRIVATE_PROVIDER_VERSION')
    c.key(body['provider']); c.key(body['privacy_key_hash'])
    validators,f = body['validators'],body['faults']
    c.need(type(f) is int and 1 <= f <= 3 and type(validators) is dict and len(validators) == 3*f+1,'PRIVATE_PROVIDER_COMMITTEE')
    # Preserve the established bounded validator grammar without exposing the
    # private provider specification to proof recipients.
    import re
    for name,key in validators.items():
        c.need(type(name) is str and re.fullmatch('[a-z0-9_-]{1,32}',name),'PRIVATE_PROVIDER_MEMBER')
        c.verification_key(key)
    c.need(len({identifier('REPLICA-KEY',k) for k in validators.values()}) == len(validators),'PRIVATE_PROVIDER_DUPLICATE_KEY')
    c.need(type(body['max_clock_skew']) is int and 0 <= body['max_clock_skew'] <= 30,'PRIVATE_PROVIDER_CLOCK')
    return body


def validate_context(context):
    body = _context_body(context)
    c.need(context['cluster'] == identifier('COVENANT-PRIVATE-PROVIDER-CLUSTER-0.2',body),'PRIVATE_PROVIDER_CLUSTER')


def public_context(spec):
    if 'cluster' in spec:
        validate_context(spec); return deepcopy(spec)
    c.exact(spec,'version provider validators faults max_clock_skew privacy_key_hash')
    p.validate_spec(spec['provider'])
    body = {**deepcopy(spec),'provider':p.provider_id(spec['provider'])}
    context = {**body,'cluster':identifier('COVENANT-PRIVATE-PROVIDER-CLUSTER-0.2',body)}
    validate_context(context); return context


def validate_spec(spec):
    c.need(type(spec) is dict and 'cluster' not in spec,'PRIVATE_PROVIDER_PRIVATE_SPEC_REQUIRED')
    public_context(spec)


def cluster_id(spec): return public_context(spec)['cluster']
def config(spec):
    ctx = public_context(spec)
    return {'chain_id':ctx['cluster'],'validators':ctx['validators'],'faults':ctx['faults']}


def draft_command(context_or_spec,wallet,subject,epoch,operation,parameters,not_before,expires,nonce):
    ctx = public_context(context_or_spec)
    draft = p.draft_command(ctx['provider'],wallet,subject,epoch,operation,parameters,not_before,expires,nonce)
    draft.update(cluster=ctx['cluster'],label=COMMAND_LABEL,
                 body={'cluster':ctx['cluster'],'command':draft['id'],'provider':ctx['provider']})
    return draft


def verify_command(envelope,context):
    validate_context(context); c.exact(envelope,'cluster command signature')
    command = envelope['command']; cid = p.command_id(command)
    c.need(envelope['cluster'] == context['cluster'] and command['provider'] == context['provider'],'PRIVATE_PROVIDER_COMMAND_SCOPE')
    c.verify(command['subject'],COMMAND_LABEL,{'cluster':context['cluster'],'command':cid,'provider':context['provider']},envelope['signature'])
    c.need(len(canonical(envelope)) <= MAX_ENVELOPE_BYTES,'PRIVATE_PROVIDER_COMMAND_SIZE')
    return command


def _hash(raw): return hashlib.sha256(raw).digest()
EMPTY = [_hash(b'COVENANT-PRIVATE-SMT-EMPTY-0.2')]
for _ in range(256): EMPTY.append(_hash(b'\x01'+EMPTY[-1]+EMPTY[-1]))


@dataclass(frozen=True,slots=True)
class Branch:
    left: object
    right: object
    digest: bytes
    leaf: object = None


def record_key(kind,**identity):
    return identifier('COVENANT-PRIVATE-PROVIDER-RECORD-0.2',{'kind':kind,**identity})


def _leaf_hash(key,salt,value):
    return _hash(b'\x00'+bytes.fromhex(key)+bytes.fromhex(salt)+_hash(canonical(value)))


def root_hash(root): return (root.digest if root else EMPTY[256]).hex()


def put(root,key,value,salt):
    c.key(key); c.key(salt)
    c.need(len(canonical(value)) <= 65536,'PRIVATE_PROVIDER_RECORD_LIMIT')
    path = int(key,16)
    def update(node,depth):
        if depth == 256:
            return Branch(None,None,_leaf_hash(key,salt,value),(key,salt,deepcopy(value)))
        left,right = (node.left,node.right) if node else (None,None)
        if (path >> (255-depth)) & 1: right = update(right,depth+1)
        else: left = update(left,depth+1)
        empty = EMPTY[255-depth]
        return Branch(left,right,_hash(b'\x01'+(left.digest if left else empty)+(right.digest if right else empty)))
    return update(root,0)


def witness(root,key):
    c.key(key); path = int(key,16); node = root; siblings = []
    for depth in range(256):
        c.need(node is not None,'PRIVATE_PROVIDER_RECORD_MISSING')
        bit = (path >> (255-depth)) & 1
        sibling = node.left if bit else node.right
        siblings.append((sibling.digest if sibling else EMPTY[255-depth]).hex())
        node = node.right if bit else node.left
    c.need(node is not None and node.leaf[0] == key,'PRIVATE_PROVIDER_RECORD_MISSING')
    _,salt,value = node.leaf
    return {'key':key,'salt':salt,'value':deepcopy(value),'siblings':siblings}


def verify_witness(proof,root,key):
    c.exact(proof,'key salt value siblings'); c.key(root); c.key(key); c.key(proof['salt'])
    c.need(proof['key'] == key and type(proof['siblings']) is list and len(proof['siblings']) == 256,'PRIVATE_PROVIDER_WITNESS')
    digest = _leaf_hash(key,proof['salt'],proof['value']); path = int(key,16)
    for depth in range(255,-1,-1):
        other = proof['siblings'][depth]; c.key(other); other = bytes.fromhex(other)
        digest = _hash(b'\x01'+(other+digest if (path>>(255-depth))&1 else digest+other))
    c.need(hmac.compare_digest(digest.hex(),root),'PRIVATE_PROVIDER_WITNESS_ROOT')
    return deepcopy(proof['value'])


def verify_certificate(context,entry):
    validate_context(context); c.exact(entry,'block certificate'); b,q = entry['block'],entry['certificate']
    c.exact(b,'chain height parent txs state_root'); c.exact(q,'height round block_id votes')
    c.integer(b['height'],True); c.integer(q['height'],True); c.integer(q['round'])
    c.need(b['chain'] == context['cluster'] and b['height'] == q['height'] and q['round'] < 2**31,'PRIVATE_PROVIDER_CERT_CONTEXT')
    c.key(b['parent']); c.key(b['state_root']); _check_tx(b['txs'])
    bid = c.digest('COVENANT_CHAIN_BLOCK',b); c.need(bid == q['block_id'],'PRIVATE_PROVIDER_BLOCK_ID')
    c.need(type(q['votes']) is list and 2*context['faults']+1 <= len(q['votes']) <= len(context['validators']),'PRIVATE_PROVIDER_QUORUM')
    seen = set()
    for vote in q['votes']:
        c.exact(vote,'kind body signer signature'); who = vote['signer']
        c.need(type(who) is str and who in context['validators'] and who not in seen,'PRIVATE_PROVIDER_VOTER'); seen.add(who)
        body = {'chain':context['cluster'],'height':b['height'],'round':q['round'],'block_id':bid}
        c.need(vote['kind'] == 'precommit' and c.canonical(vote['body']) == c.canonical(body),'PRIVATE_PROVIDER_VOTE')
        c.verify(context['validators'][who],'COVENANT_CHAIN_PRECOMMIT',body,vote['signature'])
    return {'height':b['height'],'head':bid,'state_root':b['state_root']}


def _check_tx(txs):
    import re
    c.need(type(txs) is list and len(txs) == 1,'PRIVATE_PROVIDER_TRANSACTIONS')
    tx = txs[0]; c.exact(tx,'at nonce ciphertext'); c.integer(tx['at'])
    c.need(type(tx['nonce']) is str and re.fullmatch('[0-9a-f]{24}',tx['nonce']),'PRIVATE_PROVIDER_NONCE')
    chunks = tx['ciphertext']
    c.need(type(chunks) is list and 1 <= len(chunks) <= 7 and all(type(x) is str and 0 < len(x) <= 32768 and
           len(x)%2 == 0 and re.fullmatch('[0-9a-f]+',x) for x in chunks),'PRIVATE_PROVIDER_CIPHERTEXT')
    raw = ''.join(chunks)
    c.need(32 <= len(raw) <= 2*(MAX_ENVELOPE_BYTES+16) and chunks == [raw[i:i+32768] for i in range(0,len(raw),32768)],'PRIVATE_PROVIDER_CIPHER_SIZE')
    return tx


def _checkpoint(value):
    c.exact(value,'height head state_root'); c.integer(value['height'],True); c.key(value['head']); c.key(value['state_root'])


def verify_checkpoint(entry,*,context,minimum_checkpoint=None,floor=None):
    cp = verify_certificate(context,entry)
    if minimum_checkpoint is None:
        c.need(floor is None,'PRIVATE_PROVIDER_UNREQUESTED_FLOOR'); return cp
    _checkpoint(minimum_checkpoint)
    c.need(cp['height'] >= minimum_checkpoint['height'],'PRIVATE_PROVIDER_CHECKPOINT_ROLLBACK')
    if cp['height'] == minimum_checkpoint['height']:
        c.need(cp == minimum_checkpoint and floor is None,'PRIVATE_PROVIDER_CHECKPOINT_FORK')
    else:
        value = verify_witness(floor,cp['state_root'],record_key('checkpoint',height=minimum_checkpoint['height']))
        c.need(canonical(value) == canonical(minimum_checkpoint),'PRIVATE_PROVIDER_CHECKPOINT_FORK')
    return cp


def verify_receipt(proof,command=None,*,context,expected_wallet=None,expected_request=None,
                   minimum_checkpoint=None,now=None,max_age=None):
    c.need(len(canonical(proof)) <= MAX_PROOF_BYTES,'PRIVATE_PROVIDER_PROOF_LIMIT')
    c.exact(proof,'version checkpoint receipt inclusion floor')
    c.need(proof['version'] == PROOF,'PRIVATE_PROVIDER_PROOF_VERSION')
    cp = verify_checkpoint(proof['checkpoint'],context=context,minimum_checkpoint=minimum_checkpoint,floor=proof['floor']); r = proof['receipt']
    c.exact(r,'version cluster provider wallet request at command_height value raw_records_disclosed assurance')
    c.need(r['version'] == RECEIPT and r['cluster'] == context['cluster'] and r['provider'] == context['provider'] and
           r['raw_records_disclosed'] is False and r['assurance'] == 'QUORUM_VALIDATED_LOGICAL_INVENTORY','PRIVATE_PROVIDER_RECEIPT')
    c.key(r['wallet']); c.key(r['request']); c.integer(r['at']); c.integer(r['command_height'],True)
    c.need(r['command_height'] <= cp['height'] and r['at'] <= proof['checkpoint']['block']['txs'][0]['at'],'PRIVATE_PROVIDER_RECEIPT_TIME')
    _value(r['value'],r['wallet'])
    if command is not None:
        p.validate_command(command)
        c.need(expected_wallet is None or expected_wallet == command['wallet'],'PRIVATE_PROVIDER_EXPECTED_RECEIPT')
        c.need(expected_request is None or expected_request == p.command_id(command),'PRIVATE_PROVIDER_EXPECTED_RECEIPT')
        expected_wallet = command['wallet']; expected_request = p.command_id(command)
        c.need(command['provider'] == context['provider'] and command['not_before'] <= r['at'] < command['expires'],'PRIVATE_PROVIDER_COMMAND_INTERVAL')
    c.need(expected_wallet is not None and expected_request is not None,'PRIVATE_PROVIDER_EXPECTATIONS_REQUIRED')
    c.need(r['wallet'] == expected_wallet and r['request'] == expected_request,'PRIVATE_PROVIDER_EXPECTED_RECEIPT')
    leaf = verify_witness(proof['inclusion'],cp['state_root'],record_key('receipt',wallet=r['wallet'],request=r['request']))
    c.need(canonical(leaf) == canonical(r),'PRIVATE_PROVIDER_RECEIPT_CHANGED')
    if now is not None or max_age is not None:
        c.integer(now); c.integer(max_age)
        c.need(now-max_age <= r['at'] <= now+context['max_clock_skew'],'PRIVATE_PROVIDER_RECEIPT_STALE')
    return {**deepcopy(r),**cp}


def _value(value,wallet):
    c.need(type(value) is dict,'PRIVATE_PROVIDER_VALUE')
    if 'wallet' in value:
        c.exact(value,'wallet custody balances scope raw_records_disclosed hold_counts holds_disclosed')
        c.need(value['wallet'] == wallet and value['raw_records_disclosed'] is False and value['holds_disclosed'] is False and
               value['scope'] == 'PROVIDER_OWNED_LOGICAL_INVENTORY; EXTERNAL_BACKING_NOT_ESTABLISHED','PRIVATE_PROVIDER_SNAPSHOT')
        lease = value['custody']; c.exact(lease,'epoch holder expires checkpoint')
        c.integer(lease['epoch']); c.integer(lease['expires']); c.key(lease['checkpoint'])
        if lease['holder'] is not None: c.verification_key(lease['holder'])
        balances = value['balances']; c.need(type(balances) is dict and 1<=len(balances)<=32,'PRIVATE_PROVIDER_BALANCES')
        for balance in balances.values():
            c.exact(balance,'limit allocated available')
            for amount in balance.values(): c.integer(amount)
            c.need(balance['allocated']+balance['available'] == balance['limit'],'PRIVATE_PROVIDER_BALANCE_CONSERVATION')
        counts = value['hold_counts']
        c.need(type(counts) is dict and set(counts)<=set(('HELD','CONSUMED','EXPIRED','CANCELLED')),'PRIVATE_PROVIDER_HOLD_COUNTS')
        for amount in counts.values(): c.integer(amount,True)
    elif 'physical_delivery' in value:
        c.exact(value,'hold status state output_hash request_hash expires assurance physical_delivery')
        c.key(value['hold'])
        c.need(value['physical_delivery'] == 'NOT_ESTABLISHED' and value['assurance'] == 'PROVIDER_ATOMIC_LOGICAL_INVENTORY_ENTITLEMENT' and
               value['state'] in ('ABSENT','HELD','EXPIRED','CANCELLED','CONSUMED') and
               value['status'] == ('OBSERVED' if value['state']=='CONSUMED' else 'NOT_OBSERVED'),'PRIVATE_PROVIDER_OBSERVATION')
        if value['state'] == 'ABSENT':
            c.need(value['output_hash'] is None and value['request_hash'] is None and value['expires'] is None,'PRIVATE_PROVIDER_ABSENT')
        else:
            c.key(value['request_hash']); c.integer(value['expires'],True)
            c.need(value['output_hash'] == value['request_hash'] if value['state']=='CONSUMED' else value['output_hash'] is None,'PRIVATE_PROVIDER_OUTPUT')
    elif 'request_hash' in value:
        c.exact(value,'hold state request_hash'); c.key(value['hold']); c.key(value['request_hash'])
        c.need(value['state'] in ('HELD','CONSUMED'),'PRIVATE_PROVIDER_RESERVE')
    else:
        c.exact(value,'hold state'); c.key(value['hold']); c.need(value['state']=='CANCELLED','PRIVATE_PROVIDER_CANCEL')


def account_summary(spec,state,wallet):
    snapshot = p._snapshot(spec,state,wallet,state['clock'])
    counts = {}
    for hold in snapshot.pop('holds').values(): counts[hold['state']] = counts.get(hold['state'],0)+1
    return {**snapshot,'hold_counts':counts,'holds_disclosed':False}


class ProviderReplica(old.ProviderReplica):
    """Incrementally replayed durable replica; no authoritative derived cache.
    Full journal and signing floor are retained. No history-only active restore.
    """
    history_page_limit = PAGE_LIMIT

    def __init__(self,directory,spec,member,key,*,privacy_key,clock,base_timeout=.1,
                 minimum_checkpoint=None,initialize=False,peer_histories=()):
        validate_spec(spec)
        c.need(type(privacy_key) is bytes and len(privacy_key) == 32 and hashlib.sha256(privacy_key).hexdigest() == spec['privacy_key_hash'],'PRIVATE_PROVIDER_ENCRYPTION_KEY')
        c.need(member in spec['validators'] and c.public_key(key) == spec['validators'][member],'REPLICA_SIGNER')
        c.need(callable(clock) and type(initialize) is bool,'REPLICA_OWNER_CONFIGURATION')
        self.spec = deepcopy(spec); self.context = public_context(spec); self.member = member; self.clock = clock
        self.privacy_key = privacy_key; self.cipher = c.aesgcm_siv(privacy_key); self.protocol = sys.modules[__name__]
        self.lock = threading.RLock(); self.pending = {}; self.failed = False; self.engine = None; self.owner = None
        self.state = p.initial_state(spec['provider']); self.head = p.ZERO; self.height = 0; self.tree = None
        self.last_entry = None; self.prepared = OrderedDict()
        self.directory = Path(directory); self.directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        c.need(not self.directory.is_symlink() and self.directory.stat().st_mode & 0o077 == 0,'REPLICA_PRIVATE_DIRECTORY')
        try:
            fd = os.open(self.directory/'owner.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600); self.owner = os.fdopen(fd,'r+b')
            try: fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as exc: raise ValueError('REPLICA_ALREADY_OPEN') from exc
            path = self.directory/'consensus'; exists = Path(str(path)+'.sqlite3').exists()
            c.need(exists or initialize,'REPLICA_SAFETY_STORAGE_REQUIRED')
            pin = {'cluster':self.context['cluster'],'member':member}; marker = self.directory/'identity.json'
            if exists: c.need(marker.exists() and decode(marker.read_bytes()) == pin,'REPLICA_STORAGE_IDENTITY')
            else:
                c.need(not marker.exists(),'REPLICA_SAFETY_STORAGE_MISSING')
                old.refuse_prior_signing(spec,member,peer_histories,protocol=self.protocol)
                atomic_write(marker,canonical(pin),mode=0o600,exclusive=True,follow_symlinks=False)
            db = Path(str(path)+'.sqlite3'); fd = os.open(db,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600); os.close(fd)
            c.need(db.stat().st_mode & 0o077 == 0,'REPLICA_PRIVATE_DATABASE')
            if exists:
                journal = Journal(path)
                try:
                    stored = journal.load(); c.need(stored is not None,'REPLICA_SAFETY_STORAGE_MISSING')
                    for (raw,) in journal.db.execute('SELECT body FROM commits ORDER BY height'):
                        self._replay_entry(decode(raw))
                    self._check_floor(minimum_checkpoint)
                    profile = SimpleNamespace(config=config,cluster_id=cluster_id,apply_block=self._safety_block)
                    old._validate_safety(spec,member,stored,{'state':self.state,'height':self.height,'head':self.head},protocol=profile)
                finally: journal.close()
            else: c.need(minimum_checkpoint is None,'PRIVATE_PROVIDER_CHECKPOINT_MISSING')
            self.engine = Engine(path,member,key,config(spec),self._build,self._validate,base_timeout=base_timeout,proposal_admission=self._admit)
            c.need(self.engine.s['height'] == self.height+1 and self.engine.s['parent'] == self.head,'REPLICA_SAFETY_HISTORY_MISMATCH')
        except BaseException:
            self.close(); raise

    def _salt(self,key,height):
        return hmac.new(self.privacy_key,b'COVENANT-PRIVATE-LEAF-0.2\0'+bytes.fromhex(key)+height.to_bytes(8,'big'),hashlib.sha256).hexdigest()

    def _aad(self,height,parent,at):
        return canonical({'cluster':self.context['cluster'],'height':height,'parent':parent,'at':at,'suite':SUITE})

    def _evaluate(self,block,height,parent):
        c.exact(block,'chain height parent txs state_root')
        c.need(type(block['height']) is int and block['height'] == height and block['parent'] == parent and block['chain'] == self.context['cluster'],'PRIVATE_PROVIDER_BLOCK_CONTEXT')
        tx = _check_tx(block['txs'])
        try: raw = self.cipher.decrypt(bytes.fromhex(tx['nonce']),bytes.fromhex(''.join(tx['ciphertext'])),self._aad(height,parent,tx['at']))
        except InvalidTag as exc: raise ValueError('PRIVATE_PROVIDER_CIPHER_AUTH') from exc
        envelope = decode(raw); c.need(canonical(envelope) == raw,'PRIVATE_PROVIDER_CIPHER_ENCODING')
        command = verify_command(envelope,self.context)
        state,value = p.transition(self.spec['provider'],self.state,command,tx['at'],parent)
        if command['operation'] in ('snapshot','handover','freeze'): value = account_summary(self.spec['provider'],state,command['wallet'])
        receipt = {'version':RECEIPT,'cluster':self.context['cluster'],'provider':self.context['provider'],
            'wallet':command['wallet'],'request':p.command_id(command),'at':tx['at'],'command_height':height,'value':value,
            'raw_records_disclosed':False,'assurance':'QUORUM_VALIDATED_LOGICAL_INVENTORY'}
        tree = self.tree
        if self.height:
            key = record_key('checkpoint',height=self.height); tree = put(tree,key,self._checkpoint_value(),self._salt(key,height))
        for wallet in self.spec['provider']['accounts']:
            key = record_key('account',wallet=wallet); summary = account_summary(self.spec['provider'],state,wallet)
            # Summary is internal authenticated state; only explicitly requested
            # receipt records are exported. No account roster in public context.
            try: prior = witness(tree,key)['value']
            except ValueError: prior = None
            if prior != summary: tree = put(tree,key,summary,self._salt(key,height))
        key = record_key('receipt',wallet=command['wallet'],request=receipt['request'])
        tree = put(tree,key,receipt,self._salt(key,height))
        return state,tree,receipt

    def _safety_block(self,spec,state,block,height,parent):
        candidate = self._evaluate(block,height,parent)
        c.need(root_hash(candidate[1]) == block['state_root'],'PRIVATE_PROVIDER_STATE_ROOT')
        return candidate

    def _validate(self,block,height,parent):
        self._healthy(); c.need(height == self.height+1 and parent == self.head,'REPLICA_APPLICATION_FLOOR')
        bid = c.digest('COVENANT_CHAIN_BLOCK',block)
        if bid not in self.prepared:
            candidate = self._evaluate(block,height,parent)
            c.need(root_hash(candidate[1]) == block['state_root'],'PRIVATE_PROVIDER_STATE_ROOT')
            self.prepared[bid] = candidate
            while len(self.prepared)>8: self.prepared.popitem(last=False)
        return True

    def _build(self,height,parent):
        for cid,envelope in list(self.pending.items()):
            now = self.clock(); c.integer(now)
            try:
                p.transition(self.spec['provider'],self.state,envelope['command'],now,parent)
                nonce = secrets.token_bytes(12)
                ciphertext = self.cipher.encrypt(nonce,canonical(envelope),self._aad(height,parent,now)).hex()
                block = {'chain':self.context['cluster'],'height':height,'parent':parent,'txs':[{'at':now,'nonce':nonce.hex(),
                    'ciphertext':[ciphertext[i:i+32768] for i in range(0,len(ciphertext),32768)]}],'state_root':p.ZERO}
                candidate = self._evaluate(block,height,parent); block['state_root'] = root_hash(candidate[1])
                self.prepared[c.digest('COVENANT_CHAIN_BLOCK',block)] = candidate
                while len(self.prepared)>8:self.prepared.popitem(last=False)
                return block
            except ValueError: self.pending.pop(cid,None)
        return None

    def _replay_entry(self,entry):
        cp = verify_certificate(self.context,entry)
        c.need(cp['height'] == self.height+1,'PRIVATE_PROVIDER_HISTORY_GAP')
        candidate = self._evaluate(entry['block'],self.height+1,self.head)
        c.need(root_hash(candidate[1]) == cp['state_root'],'PRIVATE_PROVIDER_STATE_ROOT')
        self.state,self.tree,_ = candidate; self.height,self.head = cp['height'],cp['head']; self.last_entry = deepcopy(entry)
        self.pending.pop(candidate[2]['request'],None); self.prepared.clear()

    def _refresh(self):
        self._healthy()
        try:
            for (raw,) in self.engine.journal.db.execute('SELECT body FROM commits WHERE height>? ORDER BY height',(self.height,)):
                self._replay_entry(decode(raw))
        except BaseException: self.failed = True; raise

    def _checkpoint_value(self):
        return {'height':self.height,'head':self.head,'state_root':root_hash(self.tree)}

    def checkpoint(self):
        with self.lock:
            self._healthy(); return self._checkpoint_value()

    def _check_floor(self,floor):
        if floor is None: return None
        _checkpoint(floor); c.need(self.height >= floor['height'],'PRIVATE_PROVIDER_CHECKPOINT_MISSING')
        if self.height == floor['height']:
            c.need(self._checkpoint_value() == floor,'PRIVATE_PROVIDER_CHECKPOINT_FORK'); return None
        proof = witness(self.tree,record_key('checkpoint',height=floor['height']))
        c.need(canonical(proof['value']) == canonical(floor),'PRIVATE_PROVIDER_CHECKPOINT_FORK'); return proof

    def submit(self,envelope):
        with self.lock:
            self._healthy(); command = verify_command(envelope,self.context); cid = p.command_id(command)
            prior = self.receipt(command)
            if prior is not None: return prior
            p.transition(self.spec['provider'],self.state,command,self.clock(),self.head)
            c.need(cid in self.pending or len(self.pending)<128,'REPLICA_PENDING_LIMIT')
            self.pending[cid] = deepcopy(envelope); return None

    def receipt(self,command,minimum_checkpoint=None):
        with self.lock:
            self._healthy(); p.validate_command(command)
            c.need(command['provider'] == self.context['provider'],'PRIVATE_PROVIDER_COMMAND_SCOPE')
            try: inclusion = witness(self.tree,record_key('receipt',wallet=command['wallet'],request=p.command_id(command)))
            except ValueError: return None
            floor = self._check_floor(minimum_checkpoint)
            proof = {'version':PROOF,'checkpoint':deepcopy(self.last_entry),'receipt':inclusion['value'],'inclusion':inclusion,'floor':floor}
            c.need(len(canonical(proof)) <= MAX_PROOF_BYTES,'PRIVATE_PROVIDER_PROOF_LIMIT'); return proof

    def history(self,start=1,limit=PAGE_LIMIT):
        with self.lock:
            self._healthy(); c.integer(start,True); c.integer(limit,True); c.need(limit<=PAGE_LIMIT,'PRIVATE_PROVIDER_PAGE_LIMIT')
            out = []; size = 2
            for (raw,) in self.engine.journal.db.execute('SELECT body FROM commits WHERE height>=? ORDER BY height LIMIT ?',(start,limit)):
                if size+len(raw)+1 > PAGE_BYTES: break
                out.append(decode(raw)); size += len(raw)+1
            return out

    def rpc_command(self,value,wallet=None):
        if type(value) is dict and set(value) == {'envelope','minimum_checkpoint'}:
            envelope,floor = value['envelope'],value['minimum_checkpoint']
        else: envelope,floor = value,None
        command = verify_command(envelope,self.context)
        c.need(wallet is None or command['wallet'] == wallet,'PRIVATE_PROVIDER_ACCOUNT_SCOPE')
        result = self.submit(envelope)
        return self.receipt(command,minimum_checkpoint=floor) if result is not None else None
