"""Read-only builder journey. Adoption, keys and native submission stay owner-side."""
from copy import deepcopy

from covenant_language import builder_programme as b, developer_apps as a
from .cooperation_interface import HASH, INT, OBJECT, TEXT


def spec():
    records = {'type': 'array', 'maxItems': 64, 'items': OBJECT}
    refs = {'type': 'array', 'maxItems': 64, 'items': HASH}
    height = {'chain': HASH, 'current_height': INT, 'native_fee_resource': TEXT}
    return ('covenant_builder',
        'Build and inspect an immutable builder programme, quote selected application services '
        'with one aggregate price cap, obtain exact delivery/acceptance payloads, and prepare '
        'existing native settlement or separately authorised refund. Dependencies have no '
        'automatic royalty. Every result is a proposal; no signing, owner adoption, '
        'reservation, publication, token issuance, code loading or payment occurs here.', True, [
        ('spec', {}, ()),
        ('draft', {'name': TEXT, 'sponsor': HASH, 'resource': TEXT, 'unit': TEXT,
            'applications': refs, 'coordination_fee': INT, 'shares': records,
            'awards': records, 'terms': {'type': 'string', 'minLength': 1, 'maxLength': 8192},
            'supersedes': HASH}, ('name', 'sponsor', 'resource', 'unit', 'applications')),
        ('inspect', {'programme': OBJECT}, ('programme',)),
        ('adopted', {}, ()),
        ('layers', {'application': HASH}, ('application',)),
        ('verify_call_opening', {'quote': OBJECT, 'call': OBJECT}, ('quote', 'call')),
        ('quote', {'programme_id': HASH, 'services': records, 'payer': HASH,
            'chain': HASH, 'context': HASH, 'nonce': HASH, 'valid_from': INT,
            'valid_until': INT, 'cap': INT, 'native_fee_cap': INT, 'native_fee_resource': TEXT},
            ('programme_id', 'services', 'payer', 'chain', 'context', 'nonce',
             'valid_from', 'valid_until', 'cap', 'native_fee_cap')),
        ('delivery', {'quote': OBJECT, 'request': HASH, 'evidence': refs},
            ('quote', 'request', 'evidence')),
        ('acceptance', {'quote': OBJECT, 'deliveries': records}, ('quote', 'deliveries')),
        ('prepare_settlement', {'quote': OBJECT, 'quote_approvals': records,
            'deliveries': records, 'acceptance': OBJECT, **height},
            ('quote', 'quote_approvals', 'deliveries', 'acceptance', *height)),
        ('award_offer', {'programme_id': HASH, 'award': TEXT, 'chain': HASH,
            'context': HASH, 'valid_from': INT, 'valid_until': INT, 'cap': INT,
            'native_fee_cap': INT, 'native_fee_resource': TEXT},
            ('programme_id', 'award', 'chain', 'context', 'valid_from',
             'valid_until', 'cap', 'native_fee_cap')),
        ('award_delivery', {'offer': OBJECT, 'evidence': refs}, ('offer', 'evidence')),
        ('award_acceptance', {'offer': OBJECT, 'delivery': OBJECT}, ('offer', 'delivery')),
        ('prepare_award', {'offer': OBJECT, 'delivery': OBJECT,
            'acceptance': OBJECT, 'approvals': records, **height},
            ('offer', 'delivery', 'acceptance', 'approvals', *height)),
        ('prepare_refund', {'quote': OBJECT, 'refunds': records, 'case': HASH,
            'chain': HASH, 'current_height': INT, 'native_fee_cap': INT},
            ('quote', 'refunds', 'case', 'chain', 'current_height', 'native_fee_cap')),
    ])


def instructions():
    return {'version': b.VERSION,
        'journey': [
            'Owner installs exact signed applications and adopts the sponsor-signed programme.',
            'Quote only the selected call objects and performers; review total service and native fee caps.',
            'Every required account signs the exact quote assent_payload; the tool never signs.',
            'Perform the separately authorised work; each performer signs its delivery payload.',
            'Payer checks the delivered outputs and signs the exact acceptance payload.',
            'Prepare settlement; collect the separate native approval payload signatures.',
            'Owner submits ECON_CLEAR on the adopted chain with the quoted native fee cap.',
            'Retain the actual certified ledger receipt; preparation is not payment.',
        ],
        'awards': 'BOUNTY and MAINTENANCE are exact one-time milestones; no indefinite support promise.',
        'disputes': 'prepare_refund creates a separate proposal requiring refunding accounts and payer approvals.',
        'privacy': 'No automatic publication. Keep calls, outputs, private evidence and programme terms in owner custody.',
        'layers': 'Signed application parent/dependency composition; no inherited rollup or settlement security.',
        'funding': 'Quotes and award declarations do not reserve balances; use separately adopted funded escrow or reward campaigns when required.',
        'governance': 'New releases/terms require fresh explicit adoption; token holdings grant no unrelated authority.',
        'execution_authorized': False}


def layers(registry, application):
    registry.check(application)
    closure = a.resolve(application, [row['manifest'] for row in registry.entries.values()])
    rows = []
    for ref in closure['applications']:
        manifest = registry.check(ref)['manifest']
        rows.append({'application': ref, 'name': manifest['name'], 'release': manifest['release'],
            'publisher': manifest['publisher'], 'level': closure['levels'][ref],
            'parent': manifest['parent'], 'dependencies': deepcopy(manifest['dependencies']),
            'economics': manifest['economics'], 'security': deepcopy(manifest['security']),
            'automatic_dependency_fee': False})
    return {'application': application, 'closure': closure['closure'], 'layers': rows,
        'security_inherited': False, 'execution_authorized': False}


def call(exchange, action, parameters):
    if action == 'spec':
        return instructions()
    if action == 'draft':
        return {**b.programme_draft(**parameters), 'adopted': False}
    if action == 'inspect':
        programme = parameters['programme']
        return {'id': b.identifier(programme), 'programme': deepcopy(programme),
            'assent_payload': b.assent_payload(programme), 'adopted': False,
            'funding': 'NOT_RESERVED', 'execution_authorized': False}
    if action == 'layers':
        b.need(exchange.applications is not None, 'BUILDER_OWNER_APPLICATION_REGISTRY_REQUIRED')
        return layers(exchange.applications, **parameters)
    b.need(exchange.builders is not None, 'BUILDER_OWNER_REGISTRY_REQUIRED')
    if action == 'adopted':
        return exchange.builders.describe()
    b.need(action in {'quote', 'delivery', 'acceptance', 'prepare_settlement',
        'award_offer', 'award_delivery', 'award_acceptance', 'prepare_award', 'prepare_refund',
        'verify_call_opening'},
        'BUILDER_ACTION')
    values = dict(parameters)
    if 'programme_id' in values:
        values['programme'] = values.pop('programme_id')
    return getattr(exchange.builders, action)(**values)
