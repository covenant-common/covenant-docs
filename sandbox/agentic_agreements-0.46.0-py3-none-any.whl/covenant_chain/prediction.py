"""Opt-in funded prediction markets; procedure is not a guarantee of world truth.

Complete sets are fully collateralized. Interpretation, observation time, source
quorums, appeals and equal-share void payouts are fixed before the first trade.
No administrator may rewrite terms, confiscate escrow or declare an outcome.
"""
from copy import deepcopy
import math
import re
from .crypto import canonical, digest, exact, integer, key, need, sign, verify
from .prediction_audit import check_accounting_deltas

VERSION = 'covenant-prediction/0.1'
TABLES = ('prediction_markets', 'prediction_positions', 'prediction_orders', 'prediction_adoptions', 'prediction_held')
ACCEPT = 'COVENANT-PREDICTION-ACCEPT-0.1'
TRADE = 'COVENANT-PREDICTION-TRADE-0.1'
MAX = 2**53 - 1


def terms_id(terms):
    return digest('COVENANT-PREDICTION-TERMS-0.1', terms)


def _signed_integer(value):
    need(type(value) is int and abs(value) <= MAX, 'PREDICTION_NUMBER')


def _panel(panel):
    exact(panel, 'members threshold')
    members = panel['members']
    need(type(members) is list and 1 <= len(members) <= 8, 'PREDICTION_PANEL')
    for member in members:
        key(member)
    need(members == sorted(set(members)), 'PREDICTION_PANEL')
    integer(panel['threshold'], True)
    need(len(members)//2 < panel['threshold'] <= len(members), 'PREDICTION_QUORUM')


def validate_terms(t, height):
    canonical(t)
    exact(t, 'version question definition source_policy outcomes resource payout_per_unit '
          'close_height report_from report_by observation_at primary appeal '
          'challenge_blocks appeal_blocks rule void_policy')
    need(t['version'] == VERSION, 'PREDICTION_VERSION')
    need(type(t['question']) is str and 0 < len(t['question']) <= 4096, 'PREDICTION_QUESTION')
    for field in ('definition', 'source_policy'):
        key(t[field])
    outcomes = t['outcomes']
    need(type(outcomes) is list and 2 <= len(outcomes) <= 16, 'PREDICTION_OUTCOMES')
    for outcome in outcomes:
        need(type(outcome) is str and re.fullmatch('[A-Z][A-Z0-9_]{0,31}', outcome)
             and outcome not in {'VOID', 'UNKNOWN'}, 'PREDICTION_OUTCOME')
    need(len(set(outcomes)) == len(outcomes), 'PREDICTION_OUTCOMES')
    need(type(t['resource']) is str and 0 < len(t['resource']) <= 80, 'PREDICTION_RESOURCE')
    integer(t['payout_per_unit'], True)
    # Exact scalar and equal-outcome void payouts, with no beneficiary rounding dust.
    need(t['payout_per_unit'] % math.lcm(10000, len(outcomes)) == 0, 'PREDICTION_PRECISION')
    for field in ('close_height', 'report_from', 'report_by', 'observation_at',
                  'challenge_blocks', 'appeal_blocks'):
        integer(t[field], True)
    need(height < t['close_height'] <= t['report_from'] < t['report_by'], 'PREDICTION_TIMES')
    need(t['report_by'] - height <= 1000000 and
         max(t['challenge_blocks'], t['appeal_blocks']) <= 10000 and
         t['report_by'] + t['challenge_blocks'] + t['appeal_blocks'] <= MAX, 'PREDICTION_BOUNDS')
    from .security_round2 import rule_enabled
    allowed = {'EQUAL_OUTCOME_SHARES'}
    if rule_enabled('prediction_appeal_hold', height):
        allowed.add('HOLD_IF_APPEAL_SILENT')
    need(t['void_policy'] in allowed, 'PREDICTION_VOID_POLICY')
    _panel(t['primary']); _panel(t['appeal'])
    need(not set(t['primary']['members']) & set(t['appeal']['members']), 'PREDICTION_PANEL_SEPARATION')
    r = t['rule']
    need(type(r) is dict and type(r.get('mode')) is str, 'PREDICTION_RULE')
    if r['mode'] == 'JUDGMENT':
        exact(r, 'mode procedure'); key(r['procedure'])
    elif r['mode'] == 'THRESHOLD':
        exact(r, 'mode procedure unit operator threshold')
        key(r['procedure']); _signed_integer(r['threshold'])
        need(t['outcomes'] == ['YES', 'NO'], 'PREDICTION_THRESHOLD_OUTCOMES')
        need(type(r['operator']) is str and r['operator'] in {'GT', 'GE', 'LT', 'LE', 'EQ'}, 'PREDICTION_OPERATOR')
    elif r['mode'] == 'SCALAR':
        exact(r, 'mode procedure unit lower upper outside')
        key(r['procedure']); _signed_integer(r['lower']); _signed_integer(r['upper'])
        need(t['outcomes'] == ['LOW', 'HIGH'] and r['lower'] < r['upper'], 'PREDICTION_SCALAR_BOUNDS')
        need(r['outside'] == 'CLAMP', 'PREDICTION_SCALAR_OUTSIDE')
    else:
        raise ValueError('PREDICTION_RULE_UNSUPPORTED')
    if r['mode'] != 'JUDGMENT':
        need(type(r['unit']) is str and 0 < len(r['unit']) <= 128, 'PREDICTION_UNIT')
    return t


def acceptance(private, chain, creator, terms, entity, *, state=None):
    from .continuity import authority_epoch
    epochs = {'controller': state['controller_epochs'].get(entity, 0),
              'authority': authority_epoch(state, entity)} if state is not None else {'controller': 0, 'authority': 0}
    body = {'chain': chain, 'creator': creator, 'terms': terms_id(terms), 'entity': entity, 'epochs': epochs}
    return {'entity': entity, 'epochs': epochs, 'signature': sign(private, ACCEPT, body)}


def trade_approval(private, chain, terms, order, entity):
    body = {'chain': chain, 'terms': terms_id(terms), 'order': order}
    return {'entity': entity, 'signature': sign(private, TRADE, body)}


def position_id(market, owner):
    return digest('COVENANT-PREDICTION-POSITION-0.1', {'market': market, 'owner': owner})


def _position(s, market, owner):
    pid = position_id(market, owner)
    if pid not in s['prediction_positions']:
        s['prediction_positions'][pid] = {'market': market, 'owner': owner,
            'shares': {o: 0 for o in s['prediction_markets'][market]['terms']['outcomes']}}
    return s['prediction_positions'][pid]


def _members(t):
    return set(t['primary']['members']) | set(t['appeal']['members'])


def _approvals(s, rows, expected, label, body):
    from .app import controller
    need(type(rows) is list and len(rows) == len(expected), 'PREDICTION_ACCEPTANCES')
    seen = set()
    for row in rows:
        exact(row, 'entity signature'); key(row['entity'])
        need(row['entity'] in expected and row['entity'] not in seen, 'PREDICTION_ACCEPTANCES')
        seen.add(row['entity'])
        verify(controller(s, row['entity']), label, body, row['signature'])
    need(seen == expected, 'PREDICTION_ACCEPTANCES')


def _hold(s, owner, resource, quantity):
    from .app import add, amount
    integer(quantity, True)
    need(amount(s['authority_available'], owner, resource) >= quantity, 'PREDICTION_FUNDS')
    for table in ('balances', 'authority_available'):
        add(s[table], owner, resource, -quantity)
    s['prediction_held'][resource] = s['prediction_held'].get(resource, 0) + quantity


def _release(s, owner, resource, quantity):
    from .app import add
    integer(quantity)
    need(s['prediction_held'].get(resource, 0) >= quantity, 'PREDICTION_HELD')
    s['prediction_held'][resource] = s['prediction_held'].get(resource, 0) - quantity
    for table in ('balances', 'authority_available'):
        add(s[table], owner, resource, quantity)


def _result(t, value):
    exact(value, 'status value')
    status = value['status']
    need(type(status) is str and status in {'VALUE', 'VOID', 'UNKNOWN'}, 'PREDICTION_RESULT')
    if status != 'VALUE':
        need(value['value'] is None, 'PREDICTION_RESULT')
        return
    if t['rule']['mode'] == 'JUDGMENT':
        need(type(value['value']) is str and value['value'] in t['outcomes'], 'PREDICTION_RESULT')
    else:
        _signed_integer(value['value'])


def payouts(t, value):
    """Exact units paid per outcome token. UNKNOWN cannot silently settle."""
    _result(t, value)
    need(value['status'] != 'UNKNOWN', 'PREDICTION_UNRESOLVED')
    total = t['payout_per_unit']; outcomes = t['outcomes']
    if value['status'] == 'VOID':
        share = total // len(outcomes)
        # Floor-only shares would burn dust inside escrow and fail settlement.
        need(share * len(outcomes) == total, 'PREDICTION_DUST')
        return {o: share for o in outcomes}
    r = t['rule']; v = value['value']
    if r['mode'] == 'JUDGMENT':
        return {o: total if o == v else 0 for o in outcomes}
    if r['mode'] == 'THRESHOLD':
        threshold = r['threshold']
        win = {'GT': v > threshold, 'GE': v >= threshold, 'LT': v < threshold,
               'LE': v <= threshold, 'EQ': v == threshold}[r['operator']]
        return {'YES': total if win else 0, 'NO': 0 if win else total}
    v = max(r['lower'], min(r['upper'], v))
    high_bps = (v-r['lower']) * 10000 // (r['upper']-r['lower'])
    high = total//10000 * high_bps
    return {'LOW': total-high, 'HIGH': high}


def _live(s, market):
    key(market); need(market in s['prediction_markets'], 'PREDICTION_MISSING')
    m = s['prediction_markets'][market]
    need(m['status'] != 'FINAL', 'PREDICTION_FINAL')
    return m


def _trading(m, height):
    need(m['status'] == 'OPEN' and height < m['terms']['close_height'], 'PREDICTION_TRADING_CLOSED')


def _interested(s, market, actor):
    row = s['prediction_positions'].get(position_id(market, actor))
    return row is not None and any(row['shares'].values())


def apply(s, previous, op, p, actor, tid, height):
    if not op.startswith('PREDICTION_'):
        return None
    if op == 'PREDICTION_CREATE':
        from .app import controller
        from .continuity import authority_epoch
        exact(p, 'terms acceptances'); t = validate_terms(p['terms'], height)
        need(t['resource'] in s['resources'], 'PREDICTION_RESOURCE')
        need(actor not in _members(t), 'PREDICTION_CREATOR_CONFLICT')
        context = {'chain': s['chain'], 'creator': actor, 'terms': terms_id(t)}
        adoption = digest(ACCEPT, context)
        need(adoption not in s['prediction_adoptions'], 'PREDICTION_ADOPTION_REPLAY')
        rows = p['acceptances']; members = _members(t); seen = set()
        need(type(rows) is list and len(rows) == len(members), 'PREDICTION_ACCEPTANCES')
        for row in rows:
            exact(row, 'entity epochs signature'); key(row['entity'])
            who = row['entity']; need(who in members and who not in seen, 'PREDICTION_ACCEPTANCES'); seen.add(who)
            exact(row['epochs'], 'controller authority')
            integer(row['epochs']['controller']); integer(row['epochs']['authority'])
            need(row['epochs'] == {'controller': s['controller_epochs'].get(who, 0),
                 'authority': authority_epoch(s, who)}, 'PREDICTION_ACCEPTANCE_EPOCH')
            verify(controller(s, who), ACCEPT, {**context, 'entity': who, 'epochs': row['epochs']}, row['signature'])
        s['prediction_adoptions'][adoption] = {'market': tid}
        s['prediction_markets'][tid] = {'terms': deepcopy(t), 'terms_id': terms_id(t),
            'creator': actor, 'status': 'OPEN', 'escrow': 0, 'complete_sets': 0,
            'supply': {o: 0 for o in t['outcomes']}, 'reports': {'PRIMARY': {}, 'APPEAL': {}},
            'primary': None, 'decision': None, 'challenge': None, 'challenge_until': None,
            'appeal_until': None, 'settled': None}
        return []
    if op in {'PREDICTION_MINT', 'PREDICTION_MERGE'}:
        exact(p, 'market quantity'); m = _live(s, p['market']); _trading(m, height)
        need(actor not in _members(m['terms']), 'PREDICTION_REPORTER_TRADING')
        integer(p['quantity'], True); qty = p['quantity']; t = m['terms']
        cost = qty * t['payout_per_unit']; integer(cost, True)
        row = _position(s, p['market'], actor)
        if op == 'PREDICTION_MINT':
            _hold(s, actor, t['resource'], cost)
            m['escrow'] += cost; m['complete_sets'] += qty
            for outcome in t['outcomes']:
                row['shares'][outcome] += qty; m['supply'][outcome] += qty
        else:
            need(all(v >= qty for v in row['shares'].values()), 'PREDICTION_COMPLETE_SET')
            for outcome in t['outcomes']:
                row['shares'][outcome] -= qty; m['supply'][outcome] -= qty
            m['escrow'] -= cost; m['complete_sets'] -= qty
            _release(s, actor, t['resource'], cost)
        return [p['market']]
    if op == 'PREDICTION_TRADE':
        from .app import add, amount, controller
        from .continuity import authority_epoch
        exact(p, 'order approvals'); o = p['order']
        exact(o, 'market outcome seller buyer quantity price expiry salt epochs')
        m = _live(s, o['market']); _trading(m, height); t = m['terms']
        key(o['seller']); key(o['buyer']); key(o['salt'])
        need(o['seller'] != o['buyer'] and not {o['seller'], o['buyer']} & _members(t), 'PREDICTION_TRADE_PARTIES')
        need(type(o['outcome']) is str and o['outcome'] in t['outcomes'], 'PREDICTION_OUTCOME')
        integer(o['quantity'], True); integer(o['price']); integer(o['expiry'])
        need(o['price'] <= t['payout_per_unit'] and height <= o['expiry'] < t['close_height'], 'PREDICTION_ORDER_BOUNDS')
        need(type(o['epochs']) is dict and set(o['epochs']) == {o['seller'], o['buyer']}, 'PREDICTION_ORDER_EPOCH')
        for who in (o['seller'], o['buyer']):
            exact(o['epochs'][who], 'controller authority')
            integer(o['epochs'][who]['controller']); integer(o['epochs'][who]['authority'])
            need(o['epochs'][who] == {'controller': s['controller_epochs'].get(who, 0),
                 'authority': authority_epoch(s, who)}, 'PREDICTION_ORDER_EPOCH')
        order_id = digest(TRADE, {'chain': s['chain'], 'terms': m['terms_id'], 'order': o})
        need(order_id not in s['prediction_orders'], 'PREDICTION_ORDER_REPLAY')
        _approvals(s, p['approvals'], {o['seller'], o['buyer']}, TRADE,
                   {'chain': s['chain'], 'terms': m['terms_id'], 'order': o})
        seller = _position(s, o['market'], o['seller']); buyer = _position(s, o['market'], o['buyer'])
        need(seller['shares'][o['outcome']] >= o['quantity'], 'PREDICTION_SHARES')
        cost = o['quantity'] * o['price']; integer(cost)
        need(amount(s['authority_available'], o['buyer'], t['resource']) >= cost, 'PREDICTION_FUNDS')
        for table in ('balances', 'authority_available'):
            add(s[table], o['buyer'], t['resource'], -cost); add(s[table], o['seller'], t['resource'], cost)
        seller['shares'][o['outcome']] -= o['quantity']; buyer['shares'][o['outcome']] += o['quantity']
        s['prediction_orders'][order_id] = {'event': tid, 'market': o['market']}
        return [o['market']]
    if op == 'PREDICTION_REPORT':
        exact(p, 'market phase result as_of evidence reasons'); m = _live(s, p['market']); t = m['terms']
        need(type(p['phase']) is str and p['phase'] in {'PRIMARY', 'APPEAL'}, 'PREDICTION_PHASE')
        phase = p['phase']; panel = t['primary'] if phase == 'PRIMARY' else t['appeal']
        need(actor in panel['members'], 'PREDICTION_REPORTER')
        if phase == 'PRIMARY':
            need(m['status'] == 'OPEN' and t['report_from'] <= height <= t['report_by'], 'PREDICTION_REPORT_WINDOW')
        else:
            need(m['status'] == 'CHALLENGED' and height <= m['appeal_until'], 'PREDICTION_APPEAL_WINDOW')
        integer(p['as_of'], True); need(p['as_of'] == t['observation_at'], 'PREDICTION_OBSERVATION')
        _result(t, p['result']); key(p['reasons'])
        refs = p['evidence']
        need(type(refs) is list and 1 <= len(refs) <= 16, 'PREDICTION_EVIDENCE')
        for ref in refs: key(ref)
        need(refs == sorted(set(refs)), 'PREDICTION_EVIDENCE')
        reports = m['reports'][phase]
        need(actor not in reports, 'PREDICTION_DUPLICATE_REPORT')
        reports[actor] = {**deepcopy(p), 'event': tid}
        matching = [r for r in reports.values() if r['result'] == p['result']]
        # Inconclusive observations remain inconclusive, never an implicit NO.
        if p['result']['status'] != 'UNKNOWN' and len(matching) >= panel['threshold']:
            d = {'result': deepcopy(p['result']), 'reports': sorted(r['event'] for r in matching), 'event': tid}
            m['decision'] = d
            if phase == 'PRIMARY':
                m['primary'] = deepcopy(d); m['status'] = 'PROVISIONAL'
                m['challenge_until'] = height + t['challenge_blocks']
            else:
                m['status'] = 'READY'
        return [p['market']]
    if op == 'PREDICTION_CHALLENGE':
        exact(p, 'market evidence reasons'); m = _live(s, p['market'])
        need(m['status'] == 'PROVISIONAL' and height <= m['challenge_until'], 'PREDICTION_CHALLENGE_WINDOW')
        need(_interested(s, p['market'], actor), 'PREDICTION_CHALLENGER')
        key(p['evidence']); key(p['reasons'])
        m['challenge'] = {'actor': actor, 'event': tid, **deepcopy(p)}
        m['status'] = 'CHALLENGED'; m['appeal_until'] = height + m['terms']['appeal_blocks']
        return [p['market'], m['primary']['event']]
    if op == 'PREDICTION_FINALIZE':
        exact(p, 'market'); m = _live(s, p['market']); t = m['terms']
        if m['status'] == 'READY':
            result = m['decision']['result']; basis = 'APPEAL_QUORUM'
        elif m['status'] == 'PROVISIONAL':
            need(height > m['challenge_until'], 'PREDICTION_CHALLENGE_OPEN')
            result = m['decision']['result']; basis = 'UNCHALLENGED_PRIMARY_QUORUM'
        else:
            deadline = m['appeal_until'] if m['status'] == 'CHALLENGED' else t['report_by']
            need(height > deadline, 'PREDICTION_RESOLUTION_OPEN')
            # Withholding an appeal must not rewrite a provisional result into VOID
            # once a market has adopted the isolated hold policy. Default markets
            # still use EQUAL_OUTCOME_SHARES and settle exactly as before.
            if m['status'] == 'CHALLENGED' and t['void_policy'] == 'HOLD_IF_APPEAL_SILENT':
                raise ValueError('PREDICTION_APPEAL_REQUIRED')
            result = {'status': 'VOID', 'value': None}; basis = 'UNRESOLVED_FALLBACK'
        m['status'] = 'FINAL'
        m['settled'] = {'result': deepcopy(result), 'payouts': payouts(t, result), 'basis': basis,
                        'event': tid, 'height': height, 'world_truth': 'NOT_ESTABLISHED'}
        return [p['market']] + ([m['decision']['event']] if m['decision'] else [])
    if op == 'PREDICTION_REDEEM':
        exact(p, 'market'); key(p['market'])
        need(p['market'] in s['prediction_markets'], 'PREDICTION_MISSING')
        m = s['prediction_markets'][p['market']]
        need(m['status'] == 'FINAL', 'PREDICTION_NOT_FINAL')
        row = _position(s, p['market'], actor)
        need(any(row['shares'].values()), 'PREDICTION_NO_POSITION')
        quantity = sum(row['shares'][o] * m['settled']['payouts'][o] for o in row['shares'])
        for outcome, qty in row['shares'].items():
            m['supply'][outcome] -= qty; row['shares'][outcome] = 0
        m['escrow'] -= quantity; _release(s, actor, m['terms']['resource'], quantity)
        return [p['market'], m['settled']['event']]
    raise ValueError('PREDICTION_OPERATION')


def market_view(state, market):
    """Local-state projection; obtain certified history separately for reliance."""
    key(market); need(market in state['prediction_markets'], 'PREDICTION_MISSING')
    m = deepcopy(state['prediction_markets'][market])
    return {'market': market, **m, 'binding_scope': 'ADOPTED_CHAIN_PROFILE',
            'source_independence': 'NOT_ESTABLISHED', 'world_truth': 'NOT_ESTABLISHED',
            'privacy': 'PUBLIC_MARKET_METADATA_AND_POSITIONS'}


def verify_materials(terms, documents):
    """Check actual bytes of three pinned policy documents, never their truth."""
    import hashlib
    refs = {terms['definition'], terms['source_policy'], terms['rule']['procedure']}
    need(type(documents) is dict and set(documents) == refs, 'PREDICTION_MATERIALS')
    size = 0
    for ref, raw in documents.items():
        need(type(raw) is bytes and len(raw) <= 4*1024*1024, 'PREDICTION_MATERIAL_SIZE')
        size += len(raw)
        need(hashlib.sha256(raw).hexdigest() == ref, 'PREDICTION_MATERIAL_HASH')
    return {'terms': terms_id(terms), 'documents': sorted(refs), 'bytes': size,
            'meaning_or_truth_verified': False}


def verified_market(genesis, history, expected_chain, minimum_height, market):
    """Certified replay using production reducer; not an independent interpreter."""
    from .proofs import verify_history
    from .app import PREDICTION_VERSION, UPGRADE_VERSION, MIGRATION_VERSION
    need(genesis['protocol'] in {PREDICTION_VERSION, UPGRADE_VERSION,MIGRATION_VERSION}, 'PREDICTION_PROFILE')
    report = verify_history(genesis, history, expected_chain, minimum_height)
    view = market_view(report['state'], market)
    return {**view, 'chain': expected_chain, 'verified_height': report['height'],
            'state_root': report['state_root'], 'assurance': 'COMMITTEE_CERTIFIED_APPLICATION_REPLAY',
            'freshness': 'RECIPIENT_HEIGHT_FLOOR_ONLY'}
