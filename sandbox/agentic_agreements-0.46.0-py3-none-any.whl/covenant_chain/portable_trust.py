"""Experimental owner-adopted off-chain trust records, without native authority.

This is AAP's own 0.1 application profile, not KERI/UCAN/CT wire conformance.
Keys, witnesses, clock, root authority, receipt contacts and resource meanings
come from the owner. Signed aliases and descriptions do not prove outside
namespace control. Full-prefix Merkle consistency is not a succinct proof.
No function here transmits, installs, spends or establishes globally latest state.
"""
from copy import deepcopy

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify
from .scale.merkle import commit
from .voting import target

VERSION = 'covenant-portable-trust/0.1'
LABEL = 'COVENANT-PORTABLE-TRUST-0.1'
MAX_HISTORY = 256
MAX_BYTES = 262144
FIELDS = {
    'INCEPTION': 'controller next_commitment nonce',
    'ROTATION': 'identity sequence previous controller reveal_nonce next_commitment',
    'ALIAS': 'identity identity_head controller namespace value issued_at expires nonce',
    'CHECKPOINT': 'log sequence previous size root issued_at',
    'MANDATE': 'root issuer recipient parent actions resources audience per_request_limits not_before expires may_delegate nonce',
    'REVOCATIONS': 'root sequence previous revoked issued_at expires',
    'OUTCOME': 'agreement context subject parties outcome evidence mode resolver issued_at nonce',
    'DESCRIPTOR': 'identity identity_head controller capabilities endpoints source_claims issued_at expires nonce',
    'INTRODUCTION': 'issuer descriptor context sources issued_at expires nonce',
}


def _bounded(value, limit=MAX_BYTES):
    # Bound before cryptography/serialization: shared subobjects count each time.
    stack = [(value, 0)]; nodes = 0; size = 0
    while stack:
        item, depth = stack.pop(); nodes += 1
        need(depth <= 32 and nodes <= 16384, 'TRUST_COMPLEXITY')
        if type(item) is str:
            try: size += len(item.encode('utf-8')) + 2
            except UnicodeError: raise ValueError('TRUST_UNICODE') from None
        elif type(item) in (int, bool) or item is None:
            size += 24
        elif type(item) in (list, dict):
            need(len(item) <= 4096, 'TRUST_COMPLEXITY'); size += len(item) + 2
            if type(item) is dict:
                for name, child in item.items():
                    need(type(name) is str, 'TRUST_FIELDS'); stack.append((name, depth + 1)); stack.append((child, depth + 1))
            else: stack.extend((child, depth + 1) for child in item)
        else: raise ValueError('TRUST_JSON_TYPE')
        need(size <= limit, 'TRUST_SIZE')
    need(len(canonical(value)) <= limit, 'TRUST_SIZE')


def _text(value, maximum=512):
    need(type(value) is str and 0 < len(value.encode('utf-8')) <= maximum, 'TRUST_TEXT')


def _key(value):
    need(type(value) is str, 'TRUST_ED25519_ONLY'); verification_key(value)


def _keys(values, maximum=32, minimum=1):
    need(type(values) is list and minimum <= len(values) <= maximum, 'TRUST_KEYS')
    for value in values: _key(value)
    need(len(set(values)) == len(values), 'TRUST_DUPLICATE_KEY')


def _hashes(values, maximum=4096):
    need(type(values) is list and len(values) <= maximum, 'TRUST_HASHES')
    for value in values: key(value)
    need(len(set(values)) == len(values), 'TRUST_DUPLICATE_ENTRY')


def _window(start, end):
    integer(start); integer(end); need(end > start, 'TRUST_WINDOW')


def _scope(values):
    need(type(values) is list and 1 <= len(values) <= 32, 'TRUST_SCOPE')
    for value in values: _text(value, 256)
    need(values == sorted(set(values)), 'TRUST_SCOPE_ORDER')


def _validate(body):
    _bounded(body)
    need(type(body) is dict and type(body.get('kind')) is str and body['kind'] in FIELDS, 'TRUST_KIND')
    exact(body, 'version kind ' + FIELDS[body['kind']]); need(body['version'] == VERSION, 'TRUST_PROFILE')
    kind = body['kind']
    if kind == 'INCEPTION':
        _key(body['controller']); key(body['next_commitment']); key(body['nonce'])
    elif kind == 'ROTATION':
        for name in ('identity', 'previous', 'reveal_nonce', 'next_commitment'): key(body[name])
        integer(body['sequence'], True); _key(body['controller'])
    elif kind in {'ALIAS', 'DESCRIPTOR'}:
        key(body['identity']); key(body['identity_head']); _key(body['controller']); key(body['nonce'])
        _window(body['issued_at'], body['expires'])
        if kind == 'ALIAS': _text(body['namespace'], 80)
        else:
            need(type(body['capabilities']) is dict and type(body['endpoints']) is list and
                 len(body['endpoints']) <= 32 and type(body['source_claims']) is list and
                 len(body['source_claims']) <= 32, 'TRUST_DESCRIPTOR')
    elif kind == 'CHECKPOINT':
        _key(body['log']); integer(body['sequence']); integer(body['size']); integer(body['issued_at']); key(body['root'])
        need(body['size'] <= 4096, 'TRUST_LOG_SIZE')
        need((body['sequence'] == 0) == (body['previous'] is None), 'TRUST_PREVIOUS')
        if body['previous'] is not None: key(body['previous'])
    elif kind == 'MANDATE':
        for name in ('root', 'issuer', 'recipient'): _key(body[name])
        if body['parent'] is not None: key(body['parent'])
        _scope(body['actions']); _scope(body['resources']); _text(body['audience'], 256)
        limits = body['per_request_limits']
        need(type(limits) is dict and len(limits) <= 16, 'TRUST_LIMITS')
        for unit, amount in limits.items(): _text(unit, 80); integer(amount)
        _window(body['not_before'], body['expires']); key(body['nonce'])
        need(type(body['may_delegate']) is bool and body['issuer'] != body['recipient'], 'TRUST_DELEGATION')
        if body['parent'] is None: need(body['issuer'] == body['root'], 'TRUST_ROOT_ISSUER')
    elif kind == 'REVOCATIONS':
        _key(body['root']); integer(body['sequence']); _hashes(body['revoked']); _window(body['issued_at'], body['expires'])
        need(body['revoked'] == sorted(body['revoked']), 'TRUST_REVOKED_ORDER')
        need((body['sequence'] == 0) == (body['previous'] is None), 'TRUST_PREVIOUS')
        if body['previous'] is not None: key(body['previous'])
    elif kind == 'OUTCOME':
        key(body['agreement']); _text(body['context'], 256); target(body['subject']); _keys(body['parties'], 16, 2)
        need(body['parties'] == sorted(body['parties']), 'TRUST_PARTY_ORDER'); _hashes(body['evidence'], 32)
        need(type(body['outcome']) is str and body['outcome'] in {'FULFILLED', 'FAILED', 'DISPUTED', 'UNKNOWN'}, 'TRUST_OUTCOME')
        need(body['mode'] in ('BILATERAL', 'RESOLVER'), 'TRUST_OUTCOME_MODE')
        if body['mode'] == 'RESOLVER': _key(body['resolver'])
        else: need(body['resolver'] is None, 'TRUST_OUTCOME_MODE')
        integer(body['issued_at']); key(body['nonce'])
    elif kind == 'INTRODUCTION':
        _key(body['issuer']); key(body['descriptor']); _text(body['context'], 256)
        need(type(body['sources']) is list and len(body['sources']) <= 32, 'TRUST_SOURCES')
        _window(body['issued_at'], body['expires']); key(body['nonce'])
    return body


def record_id(body):
    _validate(body)
    return digest(LABEL, body)


def _required(body):
    kind = body['kind']
    if kind in ('INCEPTION', 'ROTATION', 'ALIAS', 'DESCRIPTOR'): return [body['controller']]
    if kind == 'CHECKPOINT': return [body['log']]
    if kind in ('MANDATE', 'INTRODUCTION'): return [body['issuer']]
    if kind == 'REVOCATIONS': return [body['root']]
    return body['parties'] if body['mode'] == 'BILATERAL' else [body['resolver']]


def _prepare(kind, **fields):
    body = {'version': VERSION, 'kind': kind, **deepcopy(fields)}
    return {'id': record_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': _required(body), 'signature_created': False, 'execution_authorized': False}


def sign_record(body, private_keys):
    """Explicit local owner action. Not exposed as a tool; no permission inferred."""
    _validate(body); need(type(private_keys) is list and 1 <= len(private_keys) <= 33, 'TRUST_SIGNERS')
    signers = [public_key(secret) for secret in private_keys]; _keys(signers, 33)
    return {'body': deepcopy(body), 'signatures': [{'signer': signer, 'signature': sign(secret, LABEL, body)}
            for signer, secret in zip(signers, private_keys)]}


def _record(record, kind, expected_id=None, additional_signers=()):
    _bounded(record); exact(record, 'body signatures'); body = _validate(record['body'])
    need(body['kind'] == kind, 'TRUST_RECORD_KIND'); ref = record_id(body)
    if expected_id is not None: key(expected_id); need(ref == expected_id, 'TRUST_EXPECTED_RECORD')
    signatures = record['signatures']; need(type(signatures) is list and 1 <= len(signatures) <= 33, 'TRUST_SIGNATURES')
    signers = set(); allowed = set(_required(body)) | set(additional_signers)
    for row in signatures:
        exact(row, 'signer signature'); _key(row['signer'])
        need(row['signer'] in allowed and row['signer'] not in signers, 'TRUST_UNEXPECTED_SIGNER')
        verify(row['signer'], LABEL, body, row['signature']); signers.add(row['signer'])
    need(set(_required(body)) <= signers, 'TRUST_REQUIRED_SIGNATURES')
    return body, ref, signers


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'ed25519_only': True,
            'history_window': MAX_HISTORY, 'record_bytes': MAX_BYTES, 'merkle': 'EXISTING_SCALE_MERKLE_COMMITMENT_WITH_SIGNED_SIZE',
            'consistency': 'FULL_PREFIX_CHECK_NOT_SUCCINCT_PROOF', 'clock': 'OWNER_SUPPLIED_ASSERTION',
            'privacy': 'PLAINTEXT_METADATA_UNLESS_SEPARATELY_ENCRYPTED', 'global_uniqueness': False,
            'global_latest': 'UNKNOWN', 'operator_independence': 'NOT_ESTABLISHED',
            'cumulative_budget_enforced': False,
            'scoped_successor': 'covenant-scoped-mandate/0.1 (verb scopes; rolling windows enforced by covenant-spend-windows/0.1)',
            'native_authority_created': False, 'execution_authorized': False}


def key_commitment(controller, nonce):
    _key(controller); key(nonce)
    return digest('COVENANT-KEY-PRECOMMITMENT-0.1', {'controller': controller, 'nonce': nonce})


def inception(controller, next_commitment, nonce):
    return _prepare('INCEPTION', controller=controller, next_commitment=next_commitment, nonce=nonce)


def verify_identity(events, expected_identity, expected_head=None):
    need(type(events) is list and 1 <= len(events) <= MAX_HISTORY, 'TRUST_IDENTITY_HISTORY'); key(expected_identity)
    _bounded(events)
    identity = None; head = None; previous = None
    for sequence, event in enumerate(events):
        body, ref, _ = _record(event, 'INCEPTION' if sequence == 0 else 'ROTATION')
        if sequence == 0:
            identity = ref; need(identity == expected_identity, 'TRUST_IDENTITY_PIN')
        else:
            need(body['identity'] == identity and body['sequence'] == sequence and body['previous'] == head, 'TRUST_IDENTITY_CHAIN')
            need(key_commitment(body['controller'], body['reveal_nonce']) == previous['next_commitment'], 'TRUST_PRECOMMITTED_KEY')
        head, previous = ref, body
    if expected_head is not None: key(expected_head); need(expected_head == head, 'TRUST_IDENTITY_HEAD_PIN')
    return {'identity': identity, 'identifier': 'urn:aap:key:' + identity, 'head': head,
            'controller': previous['controller'], 'sequence': len(events) - 1,
            'currentness': 'OWNER_RETAINED_HEAD_MATCHED_NOT_GLOBAL_LATEST' if expected_head is not None else 'UNKNOWN_NO_CURRENT_HEAD_PIN',
            'external_identity_verified': False, 'execution_authorized': False}


def rotation(events, expected_identity, next_controller, reveal_nonce, next_commitment):
    checked = verify_identity(events, expected_identity)
    need(key_commitment(next_controller, reveal_nonce) == events[-1]['body']['next_commitment'], 'TRUST_PRECOMMITTED_KEY')
    return _prepare('ROTATION', identity=expected_identity, sequence=checked['sequence'] + 1,
                    previous=checked['head'], controller=next_controller, reveal_nonce=reveal_nonce,
                    next_commitment=next_commitment)


def alias(identity, identity_head, controller, namespace, value, issued_at, expires, nonce):
    return _prepare('ALIAS', identity=identity, identity_head=identity_head, controller=controller,
                    namespace=namespace, value=value, issued_at=issued_at, expires=expires, nonce=nonce)


def _identity_claim(record, kind, events, expected_identity, expected_id, now, expected_identity_head=None):
    checked = verify_identity(events, expected_identity, expected_identity_head); integer(now)
    body, ref, _ = _record(record, kind, expected_id)
    need(body['identity'] == expected_identity and body['identity_head'] == checked['head'] and
         body['controller'] == checked['controller'], 'TRUST_CLAIM_CONTROLLER')
    need(body['issued_at'] <= now < body['expires'], 'TRUST_CLAIM_TIME')
    return body, ref, checked


def verify_alias(record, events, expected_identity, expected_id, now, expected_identity_head=None):
    body, ref, checked = _identity_claim(record, 'ALIAS', events, expected_identity, expected_id, now, expected_identity_head)
    return {'id': ref, 'identity': expected_identity, 'namespace': body['namespace'], 'value': deepcopy(body['value']),
            'assertion': 'CONTROLLER_SIGNED_ALIAS_CLAIM_ONLY', 'external_namespace_control': 'UNKNOWN',
            'currentness': checked['currentness'], 'execution_authorized': False}


def checkpoint(log, entry_ids, sequence, issued_at, previous=None):
    _hashes(entry_ids); root, _ = commit([{'record': ref} for ref in entry_ids])
    return _prepare('CHECKPOINT', log=log, sequence=sequence, previous=previous,
                    size=len(entry_ids), root=root, issued_at=issued_at)


def verify_witness(entry_ids, record, expected_id, expected_log, witness_keys, quorum, now, max_age,
                   previous_record=None, previous_entry_ids=None):
    _hashes(entry_ids); _key(expected_log); _keys(witness_keys); integer(quorum, True); integer(now); integer(max_age, True)
    need(expected_log not in witness_keys and quorum <= len(witness_keys), 'TRUST_WITNESS_POLICY')
    body, ref, signed = _record(record, 'CHECKPOINT', expected_id, witness_keys)
    need(body['log'] == expected_log, 'TRUST_LOG_PIN')
    need(len(signed & set(witness_keys)) >= quorum, 'TRUST_WITNESS_QUORUM')
    root, _ = commit([{'record': item} for item in entry_ids])
    need(body['size'] == len(entry_ids) and body['root'] == root, 'TRUST_LOG_ROOT')
    fresh = body['issued_at'] <= now and now - body['issued_at'] <= max_age
    consistency = 'GENESIS_FULL_PREFIX' if body['sequence'] == 0 else 'UNKNOWN_NO_RETAINED_PREFIX'
    if previous_record is not None:
        old, old_id, old_signed = _record(previous_record, 'CHECKPOINT', additional_signers=witness_keys)
        need(old['log'] == expected_log and len(old_signed & set(witness_keys)) >= quorum, 'TRUST_WITNESS_PREVIOUS')
        need(body['sequence'] == old['sequence'] + 1 and body['previous'] == old_id and
             body['issued_at'] >= old['issued_at'] and body['size'] >= old['size'], 'TRUST_CHECKPOINT_CHAIN')
        need(previous_entry_ids is not None, 'TRUST_FULL_PREFIX_REQUIRED'); _hashes(previous_entry_ids)
        old_root, _ = commit([{'record': item} for item in previous_entry_ids])
        need(len(previous_entry_ids) == old['size'] and old_root == old['root'], 'TRUST_PREVIOUS_ROOT')
        need(entry_ids[:old['size']] == previous_entry_ids, 'TRUST_LOG_FORK')
        consistency = 'FULL_PREFIX_CONSISTENT'
    else: need(previous_entry_ids is None, 'TRUST_PREVIOUS_CHECKPOINT_REQUIRED')
    return {'checkpoint': ref, 'log': expected_log, 'size': body['size'], 'witnesses': sorted(signed & set(witness_keys)),
            'consistency': consistency, 'currentness': 'FRESH_OWNER_ADOPTED_WITNESSED_SNAPSHOT_NOT_GLOBAL_LATEST' if fresh else 'STALE_OR_FUTURE',
            'fresh': fresh, 'global_latest': 'UNKNOWN', 'operator_independence': 'NOT_ESTABLISHED', 'execution_authorized': False}


def compare_checkpoints(left, right, expected_log, witness_keys, quorum):
    _key(expected_log); _keys(witness_keys); integer(quorum, True)
    need(expected_log not in witness_keys and quorum <= len(witness_keys), 'TRUST_WITNESS_POLICY')
    rows = []
    for record in (left, right):
        body, ref, signers = _record(record, 'CHECKPOINT', additional_signers=witness_keys)
        need(body['log'] == expected_log and len(signers & set(witness_keys)) >= quorum, 'TRUST_WITNESS_QUORUM')
        rows.append((body, ref))
    a, b = rows[0][0], rows[1][0]
    fork = (a['sequence'] == b['sequence'] and rows[0][1] != rows[1][1]) or (a['size'] == b['size'] and a['root'] != b['root'])
    return {'status': 'SIGNED_EQUIVOCATION_DETECTED' if fork else 'NO_EQUIVOCATION_PROVEN_BY_THIS_PAIR',
            'records': [row[1] for row in rows], 'append_only_proven': False, 'execution_authorized': False}


def mandate(issuer, recipient, actions, resources, audience, per_request_limits, not_before, expires, nonce, may_delegate=False):
    return _prepare('MANDATE', root=issuer, issuer=issuer, recipient=recipient, parent=None, actions=actions,
                    resources=resources, audience=audience, per_request_limits=per_request_limits,
                    not_before=not_before, expires=expires, may_delegate=may_delegate, nonce=nonce)


def _attenuation(parent, child, parent_id):
    need(parent['may_delegate'] is True and child['parent'] == parent_id and child['issuer'] == parent['recipient'] and
         child['root'] == parent['root'], 'TRUST_DELEGATION_CHAIN')
    need(set(child['actions']) <= set(parent['actions']) and set(child['resources']) <= set(parent['resources']) and
         child['audience'] == parent['audience'], 'TRUST_SCOPE_ESCALATION')
    need(parent['not_before'] <= child['not_before'] < child['expires'] <= parent['expires'], 'TRUST_TIME_ESCALATION')
    need(set(child['per_request_limits']) == set(parent['per_request_limits']) and all(
        amount <= parent['per_request_limits'][unit] for unit, amount in child['per_request_limits'].items()), 'TRUST_LIMIT_ESCALATION')


def delegate(parent, expected_parent_id, recipient, actions, resources, per_request_limits,
             not_before, expires, nonce, may_delegate=False):
    body, ref, _ = _record(parent, 'MANDATE', expected_parent_id)
    prepared = _prepare('MANDATE', root=body['root'], issuer=body['recipient'], recipient=recipient, parent=ref,
                        actions=actions, resources=resources, audience=body['audience'], per_request_limits=per_request_limits,
                        not_before=not_before, expires=expires, nonce=nonce, may_delegate=may_delegate)
    _attenuation(body, prepared['body'], ref)
    return prepared


def revocations(root, revoked, issued_at, expires, previous=None):
    _hashes(revoked)
    if previous is None: sequence, parent = 0, None
    else:
        old, parent, _ = _record(previous, 'REVOCATIONS'); need(old['root'] == root, 'TRUST_REVOCATION_ROOT')
        need(set(old['revoked']) <= set(revoked) and issued_at >= old['issued_at'], 'TRUST_REVOCATION_ROLLBACK')
        sequence = old['sequence'] + 1
    return _prepare('REVOCATIONS', root=root, sequence=sequence, previous=parent,
                    revoked=revoked, issued_at=issued_at, expires=expires)


def _revocation_history(history, root, now, minimum_sequence):
    need(type(history) is list and 1 <= len(history) <= MAX_HISTORY, 'TRUST_REVOCATION_HISTORY')
    _bounded(history)
    integer(minimum_sequence); prior = None; last_id = None
    for sequence, record in enumerate(history):
        body, ref, _ = _record(record, 'REVOCATIONS')
        need(body['root'] == root and body['sequence'] == sequence and body['previous'] == last_id, 'TRUST_REVOCATION_CHAIN')
        if prior is not None:
            need(set(prior['revoked']) <= set(body['revoked']) and body['issued_at'] >= prior['issued_at'], 'TRUST_REVOCATION_ROLLBACK')
        prior, last_id = body, ref
    need(prior['sequence'] >= minimum_sequence, 'TRUST_REVOCATION_MINIMUM')
    need(prior['issued_at'] <= now < prior['expires'], 'TRUST_REVOCATION_TIME')
    return prior, last_id


def verify_revocations(history, root, now, minimum_sequence=0):
    """A root's signed, append-only revocation snapshots. Currentness stays unknown."""
    _key(root); integer(now)
    body, ref = _revocation_history(history, root, now, minimum_sequence)
    return {'root': root, 'head': ref, 'sequence': body['sequence'], 'revoked': list(body['revoked']),
            'issued_at': body['issued_at'], 'expires': body['expires'],
            'currentness': 'SIGNED_LIST_ONLY_CURRENTNESS_UNKNOWN', 'global_latest': 'UNKNOWN',
            'execution_authorized': False}


def revocation_status(ids, root_key, now, revocation_history=None, witness=None, minimum_revocation_sequence=0):
    """(status, revoked) of record ids under a root's signed snapshots and an optional witnessed checkpoint.

    Only a fresh owner-adopted witnessed snapshot that lists none of the ids is
    NOT_REVOKED; a signed list alone leaves currentness unknown.
    """
    revocation = 'UNKNOWN_NO_FRESH_WITNESSED_REVOCATION_SNAPSHOT'; revoked = False
    if revocation_history is not None:
        rev, ref = _revocation_history(revocation_history, root_key, now, minimum_revocation_sequence)
        revoked = bool(set(ids) & set(rev['revoked']))
        revocation = 'REVOKED_BY_SIGNED_ROOT' if revoked else 'SIGNED_LIST_ONLY_CURRENTNESS_UNKNOWN'
        if witness is not None:
            need(type(witness) is dict, 'TRUST_WITNESS_INPUT')
            required = {'entry_ids', 'record', 'expected_id', 'expected_log', 'witness_keys', 'quorum', 'now', 'max_age'}
            optional = {'previous_record', 'previous_entry_ids'}
            need(required <= set(witness) <= required | optional, 'TRUST_WITNESS_INPUT'); _bounded(witness)
            need(witness['now'] == now, 'TRUST_WITNESS_CLOCK')
            checked = verify_witness(**witness)
            need(ref in witness['entry_ids'], 'TRUST_REVOCATION_NOT_WITNESSED')
            need(rev['issued_at'] <= witness['record']['body']['issued_at'], 'TRUST_REVOCATION_AFTER_CHECKPOINT')
            if checked['fresh'] and not revoked: revocation = 'NOT_REVOKED_IN_FRESH_OWNER_ADOPTED_WITNESSED_SNAPSHOT'
    else: need(witness is None, 'TRUST_REVOCATION_REQUIRED')
    return revocation, revoked


def check_capability(records, root_key, recipient, action, resource, audience, usage, now,
                     revocation_history=None, witness=None, minimum_revocation_sequence=0,
                     root_events=None, expected_identity=None, expected_identity_head=None):
    need(type(records) is list and 1 <= len(records) <= 16, 'TRUST_CAPABILITY_DEPTH')
    _bounded(records)
    _key(root_key); _key(recipient); _text(action, 256); _text(resource, 256); _text(audience, 256); integer(now)
    if root_events is not None:
        identity = verify_identity(root_events, expected_identity, expected_identity_head)
        need(identity['controller'] == root_key, 'TRUST_ROOT_CONTROLLER')
    else: need(expected_identity is None and expected_identity_head is None, 'TRUST_IDENTITY_HISTORY_REQUIRED')
    need(type(usage) is dict, 'TRUST_USAGE'); _bounded(usage)
    ids = []; previous = None; previous_id = None
    for index, record in enumerate(records):
        body, ref, _ = _record(record, 'MANDATE')
        need(body['root'] == root_key, 'TRUST_ROOT_PIN')
        if index == 0: need(body['parent'] is None and body['issuer'] == root_key, 'TRUST_ROOT_ISSUER')
        else: _attenuation(previous, body, previous_id)
        need(body['not_before'] <= now < body['expires'], 'TRUST_CAPABILITY_TIME')
        ids.append(ref); previous, previous_id = body, ref
    need(previous['recipient'] == recipient and previous['audience'] == audience and
         action in previous['actions'] and resource in previous['resources'], 'TRUST_REQUEST_SCOPE')
    need(set(usage) == set(previous['per_request_limits']), 'TRUST_USAGE_UNITS')
    for unit, amount in usage.items(): integer(amount); need(amount <= previous['per_request_limits'][unit], 'TRUST_REQUEST_LIMIT')
    revocation, revoked = revocation_status(ids, root_key, now, revocation_history, witness, minimum_revocation_sequence)
    return {'capability': ids[-1], 'chain': ids, 'root': root_key, 'scope_and_signatures_verified': True,
            'revocation': revocation, 'revoked': revoked,
            'eligible_in_supplied_scope': revocation == 'NOT_REVOKED_IN_FRESH_OWNER_ADOPTED_WITNESSED_SNAPSHOT',
            'limits': 'PER_REQUEST_ONLY_CUMULATIVE_CONSUMPTION_NOT_ENFORCED', 'global_latest': 'UNKNOWN',
            'owner_resource_authority': 'OWNER_MUST_ADOPT_ROOT_FOR_THIS_RESOURCE', 'execution_authorized': False}


def outcome(agreement, context, subject, parties, outcome, evidence, issued_at, nonce, mode='BILATERAL', resolver=None):
    return _prepare('OUTCOME', agreement=agreement, context=context, subject=subject, parties=parties,
                    outcome=outcome, evidence=evidence, mode=mode, resolver=resolver, issued_at=issued_at, nonce=nonce)


def verify_outcome(record, expected_id, agreement, context, subject, adopted_resolvers=None):
    body, ref, signers = _record(record, 'OUTCOME', expected_id)
    key(agreement); _text(context, 256); target(subject)
    need(body['agreement'] == agreement and body['context'] == context and body['subject'] == subject, 'TRUST_OUTCOME_SCOPE')
    if body['mode'] == 'RESOLVER':
        need(type(adopted_resolvers) is dict and adopted_resolvers.get(agreement) == body['resolver'], 'TRUST_RESOLVER_NOT_ADOPTED')
    return {'id': ref, 'agreement': agreement, 'subject': deepcopy(subject), 'context': context,
            'signers': sorted(signers), 'outcome': body['outcome'], 'basis': 'SIGNED_OUTCOME_ASSERTION_NOT_PAYMENT_OR_WORLD_TRUTH',
            'settlement_verified': False, 'execution_authorized': False}


def local_reputation(receipts, subject, context, trusted_contacts, now, max_age, adopted_resolvers=None):
    need(type(receipts) is list and len(receipts) <= 256, 'TRUST_RECEIPT_WINDOW'); target(subject); _text(context, 256)
    _bounded(receipts)
    integer(now); integer(max_age, True); need(type(trusted_contacts) is dict and 1 <= len(trusted_contacts) <= 64, 'TRUST_CONTACTS')
    for contact, weight in trusted_contacts.items():
        _key(contact); integer(weight, True); need(weight <= 10000, 'TRUST_CONTACT_WEIGHT')
    groups = {}; excluded = []; seen = set()
    for record in receipts:
        try:
            body, ref, signers = _record(record, 'OUTCOME')
            checked = verify_outcome(record, ref, body['agreement'], context, subject, adopted_resolvers)
            if ref in seen: continue
            seen.add(ref)
            need(body['issued_at'] <= now and now - body['issued_at'] <= max_age, 'TRUST_RECEIPT_TIME')
            weight = max((trusted_contacts[s] for s in signers if s in trusted_contacts), default=0)
            need(weight > 0, 'TRUST_NO_TRUSTED_CONTACT')
            groups.setdefault(body['agreement'], []).append((checked['id'], body['outcome'], weight))
        except ValueError as error:
            excluded.append({'status': 'EXCLUDED', 'reason': str(error)})
    support = failure = disputed = 0; rows = []
    for agreement, values in sorted(groups.items()):
        outcomes = {row[1] for row in values}; weight = max(row[2] for row in values)
        status = next(iter(outcomes)) if len(outcomes) == 1 else 'CONFLICT'
        if status == 'FULFILLED': support += weight
        elif status == 'FAILED': failure += weight
        else: disputed += weight
        rows.append({'agreement': agreement, 'receipts': sorted(row[0] for row in values), 'status': status, 'weight': weight})
    return {'subject': deepcopy(subject), 'context': context, 'basis': 'OWNER_TRUSTED_CONTACTS_AND_EXACT_CONTEXT_ONLY',
            'support_weight': support, 'failure_weight': failure, 'disputed_or_unknown_weight': disputed,
            'contextual_support_bps': 10000 * support // (support + failure) if support + failure else None,
            'agreements': rows, 'excluded': excluded, 'global_score': False, 'contact_independence': 'NOT_ESTABLISHED',
            'world_truth_verified': False, 'execution_authorized': False}


def descriptor(identity, identity_head, controller, capabilities, endpoints, source_claims, issued_at, expires, nonce):
    return _prepare('DESCRIPTOR', identity=identity, identity_head=identity_head, controller=controller,
                    capabilities=capabilities, endpoints=endpoints, source_claims=source_claims,
                    issued_at=issued_at, expires=expires, nonce=nonce)


def verify_descriptor(record, events, expected_identity, expected_id, now, expected_identity_head=None):
    body, ref, checked = _identity_claim(record, 'DESCRIPTOR', events, expected_identity, expected_id, now, expected_identity_head)
    return {'id': ref, 'identity': expected_identity, 'claims': deepcopy(body), 'currentness': checked['currentness'],
            'assurance': 'CONTROLLER_SIGNED_SELF_DESCRIPTION_NOT_CAPABILITY_OR_EXTERNAL_IDENTITY_VERIFICATION',
            'network_accessed': False, 'installed': False, 'execution_authorized': False}


def introduction(issuer, descriptor, context, sources, issued_at, expires, nonce):
    return _prepare('INTRODUCTION', issuer=issuer, descriptor=descriptor, context=context, sources=sources,
                    issued_at=issued_at, expires=expires, nonce=nonce)


def verify_introduction(record, expected_id, trusted_introducers, context, now):
    _keys(trusted_introducers, 64); _text(context, 256); integer(now)
    body, ref, _ = _record(record, 'INTRODUCTION', expected_id)
    need(body['issuer'] in trusted_introducers and body['context'] == context, 'TRUST_INTRODUCER_NOT_ADOPTED')
    need(body['issued_at'] <= now < body['expires'], 'TRUST_CLAIM_TIME')
    return {'id': ref, 'descriptor': body['descriptor'], 'introducer': body['issuer'], 'sources': deepcopy(body['sources']),
            'assurance': 'ADOPTED_CONTACT_SIGNED_INTRODUCTION_ONLY', 'descriptor_verified': False,
            'source_control_verified': False, 'network_accessed': False, 'installed': False, 'execution_authorized': False}
