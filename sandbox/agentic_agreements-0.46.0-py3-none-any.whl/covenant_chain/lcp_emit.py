"""Optional LCP discovery document and per-agreement ATR.

Maturity: experimental. Off unless the host passes ``enabled=True`` (host flag
``lcp_emit``). Serves no ledger op and is not reachable from
``apply_transaction``. The ATR is the exact bytes a counterparty fetches;
``atrHash`` is SHA-256 of those bytes (covenant_chain.atr). Party slots keep the
bytes they are given. A private scope drops fields before those bytes are
written, and a private link stops resolving when it expires. Ledger output is
the hash and a record id only.

The fixed-order ATR, the refusal codes and the discovery member order follow the
Apache-2.0 Legal Context Protocol and ``@integraledger/lcp`` 0.4.2 (Copyright
Integra Ledger and contributors; see NOTICE). ``assemble`` returns the same bytes
and refusals as the vendored reference core on its vectors and on a differential
corpus. Discovery documents validate against the vendored Draft 2020-12 schema;
members outside the LCP table are refused rather than dropped.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re

from .atr import ATR_MAX_BYTES, HASH_TEXT, hash_bytes, is_https_link
from .crypto import digest, need

WELL_KNOWN_LEGAL_CONTEXT = '/.well-known/legal-context.json'
ATR_VERSION = '1'
DISCOVERY_MAX_BYTES = 65536
PRIVATE_LINK_TTL = 900
PRIVATE_LINK_CAPACITY = 1024
MAX_PARTY_SLOTS = 64
MAX_JSON_DEPTH = 64
ASSENT_LABEL = 'COVENANT-ASSENT-BYTES-0.1'
SLOT_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z')
CLAUSE_ID = re.compile(r'sha256:0x[0-9a-fA-F]{64}\Z')
# RFC 3986 section 3 absolute URI: scheme, then only unreserved, reserved or pct-encoded characters.
URI = re.compile(r"[A-Za-z][A-Za-z0-9+.\-]*:(?:[A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=]|%[0-9A-Fa-f]{2})*\Z")
SAFE = 2 ** 53 - 1
INDEX_KEY = re.compile(r'(?:0|[1-9][0-9]{0,9})\Z')

DOCUMENT = (
    ('terms', 'terms'),
    ('termsFormat', 'string'),
    ('atrHash', 'hash'),
    ('acceptanceRequired', 'boolean'),
    ('disputeResolution', 'dispute'),
    ('returns', 'uri'),
    ('contact', 'contact'),
    ('api', 'uri'),
)
DISPUTE = (
    ('method', 'string'),
    ('jurisdiction', 'string'),
    ('contact', 'string'),
    ('clauseId', 'clause'),
    ('source', 'uri'),
    ('catalog', 'uri'),
)
CONTACT = (('legal', 'string'), ('technical', 'string'))


def _refuse(code):
    return {'refused': True, 'code': code}


def _joined(value):
    """Combine UTF-16 surrogate pairs, as a JavaScript string holds them."""
    return value.encode('utf-16-le', 'surrogatepass').decode('utf-16-le', 'surrogatepass')


def _js_string(value, *, escape_lone=False):
    """JSON.stringify of a string. Lone surrogates are refused, or escaped as JSON.stringify does."""
    if type(value) is not str:
        return None
    value = _joined(value)
    out = ['"']
    for ch in value:
        code = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\b':
            out.append('\\b')
        elif ch == '\f':
            out.append('\\f')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif ch == '\t':
            out.append('\\t')
        elif code < 0x20:
            out.append('\\u%04x' % code)
        elif 0xD800 <= code <= 0xDFFF:
            if not escape_lone:
                return None
            out.append('\\u%04x' % code)
        else:
            out.append(ch)
    out.append('"')
    return ''.join(out)


def _js_keys(value):
    """Object.keys order: array-index keys ascending, then the rest in insertion order."""
    indexed = sorted((k for k in value if INDEX_KEY.fullmatch(k) and int(k) < 2 ** 32 - 1), key=int)
    chosen = set(indexed)
    return indexed + [k for k in value if k not in chosen]


def write_json(value, depth=0):
    """The core's writeJson for binding values: JSON.stringify bytes, safe integers only, depth 64.

    ``None`` means the value is not one this package writes: a float, an integer
    outside the safe range, a lone surrogate, a non-string key or deeper nesting.
    """
    if value is None or type(value) is bool:
        return json.dumps(value)
    if type(value) is str:
        return _js_string(value)
    if type(value) is int:
        return str(value) if -SAFE <= value <= SAFE else None
    if type(value) is float:
        # A JavaScript number: only a safe integer is written, 7.0 as 7.
        return str(int(value)) if value.is_integer() and -SAFE <= value <= SAFE else None
    if type(value) not in (dict, list) or depth >= MAX_JSON_DEPTH:
        return None
    if type(value) is list:
        parts = []
        for item in value:
            written = write_json(item, depth + 1)
            if written is None:
                return None
            parts.append(written)
        return '[' + ','.join(parts) + ']'
    if any(type(name) is not str for name in value):
        return None
    parts = []
    for name in _js_keys(value):
        encoded = _js_string(name)
        written = write_json(value[name], depth + 1)
        if encoded is None or written is None:
            return None
        parts.append(encoded + ':' + written)
    return '{' + ','.join(parts) + '}'


def _deep(value):
    """True when arrays and objects nest more than 64 levels."""
    pending = [(value, 1)]
    while pending:
        item, level = pending.pop()
        if type(item) in (list, dict):
            if level > MAX_JSON_DEPTH:
                return True
            children = item if type(item) is list else item.values()
            pending.extend((child, level + 1) for child in children)
    return False


def _number(_text):
    return 0


def _constant(_text):
    raise ValueError('NOT_JSON')


_DECODER = json.JSONDecoder(parse_int=_number, parse_float=_number, parse_constant=_constant, strict=True)


def _pairs(items):
    out = {}
    for name, value in items:
        need(name not in out, 'DUPLICATE_KEY')
        out[name] = value
    return out


def _float(_text):
    raise ValueError('NONINTEGER_NUMBER')


def strict_loads(raw, limit=ATR_MAX_BYTES):
    """UTF-8 JSON with exact integers, no duplicate keys and nesting at most 64. ValueError otherwise."""
    need(type(raw) is bytes and len(raw) <= limit and not raw.startswith(b'\xef\xbb\xbf'), 'JSON_BYTES')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=_pairs, parse_float=_float, parse_constant=_constant)
    except (UnicodeError, RecursionError):
        raise ValueError('JSON_BYTES') from None
    need(not _deep(value), 'JSON_DEPTH')
    return value


def one_json(raw):
    """isOneJsonValue: UTF-8 without a BOM, exactly one RFC 8259 value, nesting at most 64."""
    if type(raw) is not bytes or raw.startswith(b'\xef\xbb\xbf'):
        return False
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        return False
    start = len(text) - len(text.lstrip(' \t\r\n'))
    try:
        parsed, end = _DECODER.raw_decode(text, start)
    except (ValueError, RecursionError):
        return False
    if text[end:].strip(' \t\r\n') != '':
        return False
    return not _deep(parsed)


def assemble(atr_id, binding, content, *, enabled=False, max_bytes=None):
    """Write one ATR. Same inputs always give the same bytes; refusals follow the core, in its order."""
    if not enabled:
        return _refuse('plugin/disabled')
    limit_in = ATR_MAX_BYTES if max_bytes is None else max_bytes
    if type(limit_in) is not int or not 0 <= limit_in <= SAFE:
        return _refuse('core/too-large')
    limit = min(limit_in, ATR_MAX_BYTES)
    if type(atr_id) is not str:
        return _refuse('core/binding-not-json')
    if type(binding) is not list or len(binding) != 2:
        return _refuse('core/slot-name')
    if type(content) is not list:
        return _refuse('core/content-not-json')
    slot, value = binding
    if type(slot) is not str or SLOT_NAME.fullmatch(slot) is None:
        return _refuse('core/slot-name')
    if slot in {'atrVersion', 'id'}:
        return _refuse('core/slot-reserved')
    if len(content) > MAX_PARTY_SLOTS:
        return _refuse('core/too-large')
    names = []
    parts = []
    seen = set()
    for entry in content:
        if type(entry) is not list or len(entry) != 2:
            return _refuse('core/slot-name')
        name, raw = entry
        if type(name) is not str or SLOT_NAME.fullmatch(name) is None:
            return _refuse('core/slot-name')
        if name in {'atrVersion', 'id', slot}:
            return _refuse('core/slot-reserved')
        if name in seen:
            return _refuse('core/slot-duplicate')
        seen.add(name)
        if type(raw) is not bytes:
            return _refuse('core/content-not-json')
        names.append((',' + _js_string(name) + ':').encode('utf-8'))
        parts.append(raw)
    written = write_json(value)
    if written is None:
        return _refuse('core/binding-not-json')
    head = ('{"atrVersion":"%s","id":%s,%s:%s' % (
        ATR_VERSION, _js_string(atr_id, escape_lone=True), _js_string(slot), written)).encode('utf-8')
    total = len(head) + 1 + sum(len(name) + len(raw) for name, raw in zip(names, parts))
    if total > limit:
        return _refuse('core/too-large')
    for raw in parts:
        if not one_json(raw):
            return _refuse('core/content-not-json')
    out = bytearray(head)
    for name, raw in zip(names, parts):
        out.extend(name)
        out.extend(raw)
    out.append(0x7D)
    raw = bytes(out)
    return {'refused': False, 'bytes': raw, 'atrHash': hash_bytes(raw)}


def _text(value):
    return type(value) is str and 0 < len(value) <= 4096 and _js_string(value) is not None


def _check_member(value, kind):
    if kind == 'string':
        return _text(value)
    if kind == 'terms':
        return is_https_link(value)
    if kind == 'uri':
        return type(value) is str and len(value) <= 2048 and URI.fullmatch(value) is not None
    if kind == 'hash':
        return type(value) is str and HASH_TEXT.fullmatch(value) is not None
    if kind == 'clause':
        return type(value) is str and CLAUSE_ID.fullmatch(value) is not None
    if kind == 'boolean':
        return type(value) is bool
    return False


def _check_object(value, table, path):
    """Typed copy of one discovery object, or a refusal code naming the member."""
    if type(value) is not dict:
        return 'discovery/member-malformed/' + path
    known = {name for name, _kind in table}
    for name in value:
        if name not in known:
            return 'discovery/member-unknown'
    out = {}
    for name, kind in table:
        if name not in value:
            continue
        item = value[name]
        if kind in {'dispute', 'contact'}:
            inner = _check_object(item, DISPUTE if kind == 'dispute' else CONTACT, name)
            if type(inner) is str:
                return inner
            out[name] = inner
        elif not _check_member(item, kind):
            return 'discovery/member-malformed/' + name
        else:
            out[name] = '0x' + item[2:].lower() if kind == 'hash' else item
    return out


def _write_table(value, table):
    parts = []
    for name, kind in table:
        if name not in value:
            continue
        item = value[name]
        if kind in {'dispute', 'contact'}:
            encoded = _write_table(item, DISPUTE if kind == 'dispute' else CONTACT)
        else:
            encoded = write_json(item)
        parts.append(_js_string(name) + ':' + encoded)
    return '{' + ','.join(parts) + '}'


def emit_discovery(document, *, enabled=False):
    """``/.well-known/legal-context.json`` bytes in LCP table order, no whitespace."""
    if not enabled:
        return _refuse('plugin/disabled')
    if type(document) is not dict or 'terms' not in document:
        return _refuse('discovery/member-malformed/terms')
    checked = _check_object(document, DOCUMENT, 'document')
    if type(checked) is str:
        return _refuse(checked)
    raw = _write_table(checked, DOCUMENT).encode('utf-8')
    if len(raw) > DISCOVERY_MAX_BYTES:
        return _refuse('discovery/too-large')
    return {'refused': False, 'bytes': raw, 'document': checked, 'execution_authorized': False}


def check_discovery(raw):
    """Bytes a host may serve: exactly what ``emit_discovery`` writes for them. LEGAL_CONTEXT_BYTES otherwise."""
    need(type(raw) is bytes and 0 < len(raw) <= DISCOVERY_MAX_BYTES, 'LEGAL_CONTEXT_BYTES')
    try:
        document = strict_loads(raw, DISCOVERY_MAX_BYTES)
    except ValueError:
        raise ValueError('LEGAL_CONTEXT_BYTES') from None
    emitted = emit_discovery(document, enabled=True)
    need(not emitted['refused'] and emitted['bytes'] == raw, 'LEGAL_CONTEXT_BYTES')
    return raw


def discovery_for_atr(terms_url, atr, *, enabled=False, acceptance_required=False, dispute=None, contact=None,
                      terms_format='json'):
    """Discovery document naming one ATR hash."""
    if not enabled:
        return _refuse('plugin/disabled')
    if type(atr) is not dict or atr.get('refused') is not False:
        return atr if type(atr) is dict and atr.get('refused') else _refuse('discovery/member-malformed/atrHash')
    document = {'terms': terms_url, 'termsFormat': terms_format, 'atrHash': atr['atrHash'],
                'acceptanceRequired': acceptance_required}
    if dispute is not None:
        document['disputeResolution'] = dispute
    if contact is not None:
        document['contact'] = contact
    return emit_discovery(document, enabled=True)


def record_digest(raw):
    """Domain-separated id of the assented bytes. Stored beside ``atrHash``, never instead of it."""
    need(type(raw) is bytes, 'ATR_BYTES')
    return digest(ASSENT_LABEL, {'sha256': hashlib.sha256(raw).hexdigest()})


def _scope_fields(fields):
    need(type(fields) is list and 0 < len(fields) <= 32 and len(set(fields)) == len(fields), 'ATR_SCOPE_FIELDS')
    for path in fields:
        need(type(path) is str and 1 < len(path) <= 256 and path.startswith('/'), 'ATR_SCOPE_FIELDS')


def canonical_terms(value):
    """Deterministic UTF-8 JSON of agreed terms: sorted keys, compact, non-ASCII escaped."""
    from covenant_language.mechanism_plans import canonical
    return canonical(value)


def project_fields(document, fields):
    """The scoped fields only, written before any ATR byte exists (privacy_scopes.project)."""
    _scope_fields(fields)
    from .privacy_scopes import project
    return canonical_terms(project(document, fields))


def from_bytes(raw, atr_id, binding, *, enabled=False, scope_fields=None, document=None):
    """Assemble an ATR whose ``terms`` slot is exact bytes, or only the scoped fields of them.

    When the binding value is an object without ``record``, the record id of the
    slot bytes is added to it, so the ATR names the bytes the parties assented to.
    """
    if not enabled:
        return _refuse('plugin/disabled')
    if type(raw) is not bytes or len(raw) > ATR_MAX_BYTES:
        return _refuse('core/content-not-json' if type(raw) is not bytes else 'core/too-large')
    if scope_fields is not None:
        try:
            raw = project_fields(strict_loads(raw) if document is None else document, scope_fields)
        except ValueError:
            return _refuse('core/content-not-json')
    if type(binding) is list and len(binding) == 2 and type(binding[1]) is dict and 'record' not in binding[1]:
        binding = [binding[0], {**binding[1], 'record': record_digest(raw)}]
    result = assemble(atr_id, binding, [['terms', raw]], enabled=True)
    if not result['refused']:
        result['record'] = record_digest(raw)
        result['scoped'] = scope_fields is not None
        result['ledger'] = {'atrHash': result['atrHash'], 'record': result['record']}
        result['execution_authorized'] = False
    return result


def from_terms(terms, atr_id, binding, *, enabled=False, scope_fields=None):
    """ATR of canonical terms (``canonical_terms``)."""
    if not enabled:
        return _refuse('plugin/disabled')
    try:
        raw = canonical_terms(terms)
    except ValueError:
        return _refuse('core/content-not-json')
    return from_bytes(raw, atr_id, binding, enabled=True, scope_fields=scope_fields,
                      document=terms if scope_fields is not None else None)


class PrivateLinkDesk:
    """Expiring https links to private ATR bytes, held in memory. The link is not authority; the hash is."""

    def __init__(self, secret, *, ttl=PRIVATE_LINK_TTL, base='https://atr.invalid/p', capacity=PRIVATE_LINK_CAPACITY):
        need(type(secret) is bytes and 32 <= len(secret) <= 1024, 'PRIVATE_LINK_SECRET')
        need(type(base) is str and is_https_link(base) and '?' not in base and '#' not in base, 'link-not-https')
        need(type(ttl) is int and 1 <= ttl <= 86400, 'PRIVATE_LINK_TTL')
        need(type(capacity) is int and 1 <= capacity <= 65536, 'PRIVATE_LINK_CAPACITY')
        self.secret = secret
        self.ttl = ttl
        self.base = base.rstrip('/')
        self.capacity = capacity
        self.rows = {}

    def _expire(self, now):
        self.rows = {token: row for token, row in self.rows.items() if now < row[1]}

    def issue(self, atr_bytes, now):
        need(type(atr_bytes) is bytes and 0 < len(atr_bytes), 'ATR_BYTES')
        need(len(atr_bytes) <= ATR_MAX_BYTES, 'atr-too-large')
        need(type(now) is int and 0 <= now <= SAFE - self.ttl, 'PRIVATE_LINK_TIME')
        self._expire(now)
        need(len(self.rows) < self.capacity, 'PRIVATE_LINK_CAPACITY')
        expires = now + self.ttl
        digest_hex = hashlib.sha256(atr_bytes).hexdigest()
        token = hmac.new(self.secret, digest_hex.encode('ascii') + expires.to_bytes(8, 'big'), hashlib.sha256).hexdigest()
        self.rows[token] = (atr_bytes, expires)
        return {'url': self.base + '/' + token, 'expires': expires, 'atrHash': '0x' + digest_hex,
                'execution_authorized': False}

    def fetch(self, url, now):
        if not is_https_link(url):
            return _refuse('link-not-https')
        if type(now) is not int or not url.startswith(self.base + '/'):
            return _refuse('atr-unfetchable')
        self._expire(now)
        row = self.rows.get(url[len(self.base) + 1:])
        if row is None:
            return _refuse('atr-unfetchable')
        return {'refused': False, 'bytes': row[0], 'atrHash': hash_bytes(row[0]), 'execution_authorized': False}


def _vector_failures(document):
    """Replay the vendored core vectors this module implements. Returns failing row names."""
    failed = []
    rows = {row['name']: row for row in document['vectors']}
    for row in document['vectors']:
        if 'binding' in row:
            content = [[name, bytes.fromhex(hx)] for name, hx in row['content']]
            got = assemble(row['id'], row['binding'], content, enabled=True)
            if got['refused'] or got['bytes'].hex() != row['expectBytesHex'] or got['atrHash'] != row['expectHash']:
                failed.append(row['name'])
        elif 'bytesHex' in row:
            got = hash_bytes(bytes.fromhex(row['bytesHex']))
            other = rows.get(row.get('mustNotEqual'), {}).get('expectHash')
            if got != row['expectHash'] or got == other:
                failed.append(row['name'])
    for row in document['links']['rows']:
        if is_https_link(row['link'], max_units=None) is not row['accept']:
            failed.append(row['name'])
    for row in document['jsonDepth']['rows']:
        if one_json(row['text'].encode('utf-8')) is not row['accept']:
            failed.append(row['name'])
    for row in document['jsonNumbers']['rows']:
        if not one_json(row['text'].encode('utf-8')):
            failed.append(row['name'])
    return failed


def main(argv=None):
    import argparse
    import pathlib
    import sys
    parser = argparse.ArgumentParser(description='LCP discovery and ATR emitter. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    parser.add_argument('--check-vectors', action='store_true', help='Replay the vendored LCP core vectors.')
    args = parser.parse_args(argv)
    status = {'plugin': 'lcp_emit', 'enabled': bool(args.enabled), 'maturity': 'experimental',
              'execution_authorized': False}
    if not args.enabled or not args.check_vectors:
        print(json.dumps(status, sort_keys=True))
        return 0
    path = pathlib.Path(__file__).resolve().parents[1] / 'third_party' / 'integraledger-lcp' / 'vectors' / 'core-vectors.json'
    if not path.is_file():
        print(json.dumps({'status': 'UNAVAILABLE', 'code': 'LCP_VECTORS_MISSING'}), file=sys.stderr)
        return 2
    failed = _vector_failures(json.loads(path.read_text(encoding='utf-8')))
    if failed:
        print(json.dumps({'status': 'FAIL', 'vectors': failed}), file=sys.stderr)
        return 1
    print(json.dumps({**status, 'status': 'PASS'}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
