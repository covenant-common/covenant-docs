"""Optional, explicitly adopted decision/formality/prose-mapping companion.

This new profile never reinterprets a historical signed agreement. Its assent
binds only the exact companion, including its agreement/context and byte/model
pins. Reference checking proves bytes and JSON pointers, not translation
correctness, current authority, external formalities or legal effect.
"""
from copy import deepcopy
import hashlib
import re

from .crypto import need, verification_key, verify
from covenant_language.agentic import canonical

VERSION = 'covenant-agreement-profile/0.1'
RESULT = 'covenant-agreement-profile-review/0.1'
LABEL = 'COVENANT-AGREEMENT-PROFILE-0.1'
DOMAIN = b'COVENANT-AGREEMENT-PROFILE-0.1\0'
MAX_DOCUMENT_BYTES = 262144
MAX_TOTAL_DOCUMENT_BYTES = 1048576
MODES = {'ORAL', 'HANDSHAKE', 'MESSAGE', 'DOCUMENTED', 'E_SIGNED', 'WITNESSED', 'NOTARIAL', 'CUSTOM'}
PRECEDENCE = {'PROSE', 'MODEL', 'JOINT_INTERPRETATION', 'UNRESOLVED'}


def _fields(value, names):
    need(type(value) is dict and set(value) == set(names.split()), 'AGREEMENT_PROFILE_FIELDS')


def _text(value, maximum=2048):
    need(type(value) is str and 0 < len(value.encode('utf-8')) <= maximum, 'AGREEMENT_PROFILE_TEXT')


def _name(value):
    need(type(value) is str and re.fullmatch(r'[A-Za-z][A-Za-z0-9_.:-]{0,79}', value), 'AGREEMENT_PROFILE_NAME')


def _hash(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'AGREEMENT_PROFILE_REFERENCE')


def _time(value):
    need(type(value) is int and 0 <= value <= 2**53-1, 'AGREEMENT_PROFILE_TIME')


def _rows(value, maximum=64):
    need(type(value) is list and len(value) <= maximum, 'AGREEMENT_PROFILE_LIMIT')


def _unique(rows):
    seen = set()
    for row in rows:
        need(type(row) is dict and 'id' in row, 'AGREEMENT_PROFILE_ROW')
        _name(row['id'])
        need(row['id'] not in seen, 'AGREEMENT_PROFILE_DUPLICATE')
        seen.add(row['id'])


def _role(value, parties):
    need(type(value) is str and value in parties, 'AGREEMENT_PROFILE_PARTY')


def _references(value):
    _rows(value)
    for ref in value:
        _hash(ref)
    need(len(set(value)) == len(value), 'AGREEMENT_PROFILE_DUPLICATE')


def _check_rows(rows, parties):
    _rows(rows)
    _unique(rows)
    for row in rows:
        _fields(row, 'id question status reviewer as_of evidence')
        _text(row['question'])
        need(row['status'] in ('UNCHECKED', 'REPORTED', 'REVIEWED'), 'AGREEMENT_PROFILE_CHECK_STATUS')
        if row['reviewer'] is not None:
            _role(row['reviewer'], parties)
        need(row['status'] == 'UNCHECKED' or row['reviewer'] is not None, 'AGREEMENT_PROFILE_REVIEWER')
        _time(row['as_of'])
        _references(row['evidence'])


def validate(profile):
    """Check only this bounded version; no historical acceptance rule changes."""
    canonical(profile)
    _fields(profile, 'version agreement parties decisions relationships formality mappings')
    need(profile['version'] == VERSION, 'AGREEMENT_PROFILE_VERSION')
    target = profile['agreement']
    _fields(target, 'profile id context')
    _text(target['profile'], 256)
    _text(target['id'], 256)
    need(re.fullmatch(r'[A-Za-z0-9:._/-]{1,256}', target['profile']) and
         re.fullmatch(r'[A-Za-z0-9:._/-]{1,256}', target['id']), 'AGREEMENT_PROFILE_AGREEMENT_REFERENCE')
    _hash(target['context'])
    parties = profile['parties']
    need(type(parties) is dict and 1 <= len(parties) <= 32, 'AGREEMENT_PROFILE_PARTIES')
    for role, identity in parties.items():
        _name(role)
        # This companion deliberately supports only offline Ed25519 role keys.
        need(type(identity) is str, 'AGREEMENT_PROFILE_KEY_SUITE_UNSUPPORTED')
        verification_key(identity)
    need(len(set(parties.values())) == len(parties), 'AGREEMENT_PROFILE_DISTINCT_PARTY_KEYS')
    for section in ('decisions', 'relationships', 'mappings'):
        _rows(profile[section])
        _unique(profile[section])
    for row in profile['decisions']:
        _fields(row, 'id term state question decision_maker scope deadline time_basis standard reasons_required appeal procedure')
        _text(row['term'])
        need(row['state'] in ('DELIBERATELY_OPEN', 'INTERPRETIVE_QUESTION'), 'AGREEMENT_PROFILE_OPEN_TERM')
        for field in ('question', 'scope', 'time_basis', 'standard'):
            _text(row[field])
        _role(row['decision_maker'], parties)
        _time(row['deadline'])
        need(type(row['reasons_required']) is bool, 'AGREEMENT_PROFILE_REASONS')
        _hash(row['procedure'])
        if row['appeal'] is not None:
            appeal = row['appeal']
            _fields(appeal, 'decision_maker deadline standard procedure')
            _role(appeal['decision_maker'], parties)
            _time(appeal['deadline'])
            need(appeal['deadline'] >= row['deadline'], 'AGREEMENT_PROFILE_APPEAL_WINDOW')
            _text(appeal['standard'])
            _hash(appeal['procedure'])
    for row in profile['relationships']:
        _fields(row, 'id kind parties scope terms authority')
        need(row['kind'] in ('GUARANTEE', 'CAP', 'DELEGATION', 'SUBSTITUTION'), 'AGREEMENT_PROFILE_RELATIONSHIP')
        _rows(row['parties'], 32)
        need(len(row['parties']) >= (1 if row['kind'] == 'CAP' else 2), 'AGREEMENT_PROFILE_RELATIONSHIP_PARTIES')
        need(all(type(p) is str for p in row['parties']) and len(set(row['parties'])) == len(row['parties']), 'AGREEMENT_PROFILE_RELATIONSHIP_PARTIES')
        for role in row['parties']:
            _role(role, parties)
        _text(row['scope'])
        _hash(row['terms'])
        _rows(row['authority'], 32)
        seen = set()
        for grant in row['authority']:
            _fields(grant, 'party reference as_of valid_until')
            _role(grant['party'], parties)
            need(grant['party'] in row['parties'] and grant['party'] not in seen, 'AGREEMENT_PROFILE_RELATIONSHIP_AUTHORITY')
            seen.add(grant['party'])
            _hash(grant['reference'])
            _time(grant['as_of'])
            _time(grant['valid_until'])
            need(grant['as_of'] <= grant['valid_until'], 'AGREEMENT_PROFILE_AUTHORITY_WINDOW')
        need(seen == set(row['parties']), 'AGREEMENT_PROFILE_RELATIONSHIP_AUTHORITY')
    form = profile['formality']
    _fields(form, 'modes mode_details applicable_law seat as_of capacity_checks authority_checks formalities mandatory_rules evidence')
    _rows(form['modes'], len(MODES))
    need(bool(form['modes']) and all(type(mode) is str and mode in MODES for mode in form['modes']) and len(set(form['modes'])) == len(form['modes']), 'AGREEMENT_PROFILE_FORMALITY_MODE')
    _text(form['mode_details'])
    _text(form['applicable_law'])
    _text(form['seat'])
    _time(form['as_of'])
    for field in ('capacity_checks', 'authority_checks', 'formalities', 'mandatory_rules'):
        _check_rows(form[field], parties)
    _references(form['evidence'])
    for row in profile['mappings']:
        _fields(row, 'id source model precedence transformation claim')
        source = row['source']
        _fields(source, 'document start end span_hash')
        _hash(source['document'])
        _hash(source['span_hash'])
        need(type(source['start']) is int and type(source['end']) is int and 0 <= source['start'] < source['end'] <= MAX_DOCUMENT_BYTES, 'AGREEMENT_PROFILE_SPAN')
        model = row['model']
        _fields(model, 'document format semantics rule_paths')
        _hash(model['document'])
        _hash(model['semantics'])
        _text(model['format'], 256)
        _rows(model['rule_paths'])
        need(bool(model['rule_paths']) and all(type(path) is str and len(path) <= 1024 and path.startswith('/') and re.search(r'~(?![01])', path) is None for path in model['rule_paths']), 'AGREEMENT_PROFILE_JSON_POINTER')
        need(len(set(model['rule_paths'])) == len(model['rule_paths']), 'AGREEMENT_PROFILE_DUPLICATE')
        need(type(row['precedence']) is str and row['precedence'] in PRECEDENCE, 'AGREEMENT_PROFILE_PRECEDENCE')
        need(row['transformation'] in ('EXACT_COPY', 'TRANSLATION', 'SUMMARY', 'FORMALIZATION'), 'AGREEMENT_PROFILE_TRANSFORMATION')
        _text(row['claim'])
    return True


def identifier(profile):
    validate(profile)
    return hashlib.sha256(DOMAIN + canonical(profile)).hexdigest()


def source_hash(text):
    need(type(text) is str, 'AGREEMENT_PROFILE_SOURCE_TEXT')
    raw = text.encode('utf-8')
    need(len(raw) <= MAX_DOCUMENT_BYTES, 'AGREEMENT_PROFILE_DOCUMENT_LIMIT')
    return hashlib.sha256(raw).hexdigest()


def model_hash(value):
    raw = canonical(value)
    need(len(raw) <= MAX_DOCUMENT_BYTES, 'AGREEMENT_PROFILE_DOCUMENT_LIMIT')
    return hashlib.sha256(raw).hexdigest()


def draft(agreement, parties, as_of, decisions=None, relationships=None, formality=None, mappings=None):
    """Start with caller identities/pins and explicit unknown evidence assumptions."""
    value = {'version': VERSION, 'agreement': deepcopy(agreement), 'parties': deepcopy(parties),
             'decisions': deepcopy([] if decisions is None else decisions),
             'relationships': deepcopy([] if relationships is None else relationships),
             'formality': deepcopy(formality) if formality is not None else {
                 'modes': ['CUSTOM'], 'mode_details': 'UNSELECTED; no underlying evidence mode adopted',
                 'applicable_law': 'UNDETERMINED', 'seat': 'UNDETERMINED', 'as_of': as_of,
                 'capacity_checks': [], 'authority_checks': [], 'formalities': [], 'mandatory_rules': [], 'evidence': []},
             'mappings': deepcopy([] if mappings is None else mappings)}
    _time(as_of)
    ref = identifier(value)
    return {'profile': value, 'id': ref, 'status': 'UNSIGNED_COMPANION_PROPOSAL',
            'assent_payload': assent_payload(value), 'automatic_assent': False, 'execution_authorized': False}


def describe():
    """Discover complete typed shapes before constructing this optional profile."""
    text = {'type': 'string', 'minLength': 1, 'maxLength': 2048}
    pin = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
    name = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,79}$'}
    when = {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1}
    def obj(fields):
        return {'type': 'object', 'properties': fields, 'required': list(fields), 'additionalProperties': False}
    def rows(item, maximum=64, minimum=0, unique=False):
        return {'type': 'array', 'items': item, 'minItems': minimum, 'maxItems': maximum, **({'uniqueItems': True} if unique else {})}
    refs = rows(pin, unique=True)
    check = obj({'id': name, 'question': text, 'status': {'enum': ['UNCHECKED', 'REPORTED', 'REVIEWED']},
                 'reviewer': {'anyOf': [name, {'type': 'null'}]}, 'as_of': when, 'evidence': refs})
    agreement = obj({'profile': {'type': 'string', 'pattern': '^[A-Za-z0-9:._/-]{1,256}$'},
                     'id': {'type': 'string', 'pattern': '^[A-Za-z0-9:._/-]{1,256}$'}, 'context': pin})
    parties = {'type': 'object', 'minProperties': 1, 'maxProperties': 32, 'propertyNames': name, 'additionalProperties': pin}
    appeal = obj({'decision_maker': name, 'deadline': when, 'standard': text, 'procedure': pin})
    decision = obj({'id': name, 'term': text, 'state': {'enum': ['DELIBERATELY_OPEN', 'INTERPRETIVE_QUESTION']},
                    'question': text, 'decision_maker': name, 'scope': text, 'deadline': when, 'time_basis': text,
                    'standard': text, 'reasons_required': {'type': 'boolean'},
                    'appeal': {'anyOf': [appeal, {'type': 'null'}]}, 'procedure': pin})
    grant = obj({'party': name, 'reference': pin, 'as_of': when, 'valid_until': when})
    relationship = obj({'id': name, 'kind': {'enum': ['GUARANTEE', 'CAP', 'DELEGATION', 'SUBSTITUTION']},
                        'parties': rows(name, 32, 1, True), 'scope': text, 'terms': pin, 'authority': rows(grant, 32)})
    formality = obj({'modes': rows({'enum': sorted(MODES)}, len(MODES), 1, True), 'mode_details': text,
                     'applicable_law': text, 'seat': text, 'as_of': when, 'capacity_checks': rows(check),
                     'authority_checks': rows(check), 'formalities': rows(check), 'mandatory_rules': rows(check), 'evidence': refs})
    source = obj({'document': pin, 'start': {'type': 'integer', 'minimum': 0, 'maximum': MAX_DOCUMENT_BYTES-1},
                  'end': {'type': 'integer', 'minimum': 1, 'maximum': MAX_DOCUMENT_BYTES}, 'span_hash': pin})
    model = obj({'document': pin, 'format': {**text, 'maxLength': 256}, 'semantics': pin,
                 'rule_paths': rows({'type': 'string', 'maxLength': 1024, 'pattern': '^/(?:[^~]|~[01])*$'}, 64, 1, True)})
    mapping = obj({'id': name, 'source': source, 'model': model, 'precedence': {'enum': sorted(PRECEDENCE)},
                   'transformation': {'enum': ['EXACT_COPY', 'TRANSLATION', 'SUMMARY', 'FORMALIZATION']}, 'claim': text})
    schema = obj({'version': {'const': VERSION}, 'agreement': agreement, 'parties': parties,
                  'decisions': rows(decision), 'relationships': rows(relationship), 'formality': formality,
                  'mappings': rows(mapping)})
    schema['$schema'] = 'https://json-schema.org/draft/2020-12/schema'
    return {'version': VERSION, 'schema': schema,
            'draft_parameters': obj({'agreement': agreement, 'parties': parties, 'as_of': when}),
            'entry': 'draft(agreement, parties, as_of); then add decisions, relationships, formality or mappings explicitly',
            'runtime_checks': ['UTF-8 byte-length limits', 'valid distinct Ed25519 party keys', 'role membership and unique ids',
                               'each relationship party has its own authority row', 'appeal and authority time ordering',
                               'exact source/model hashes and UTF-8 span boundaries', 'per-role companion signatures'],
            'scope': 'OPTIONAL_COMPANION; NO_INHERITED_AGREEMENT_ASSENT_LEGAL_EFFECT_OR_EXECUTION',
            'schema_limit': 'JSON_SCHEMA_SHAPE_ONLY; RUNTIME_CHECKS_REMAIN_REQUIRED', 'execution_authorized': False}


def assent_payload(profile):
    """Prepare exact bodies for owner-controlled signing; never creates a proof."""
    ref = identifier(profile)
    target = profile['agreement']
    body = {'profile': ref, 'agreement': target['id'], 'agreement_profile': target['profile'], 'context': target['context']}
    return {'label': LABEL, 'body': body,
            'required_assents': [{'party': party, 'identity': identity, 'body': {**body, 'party': party}}
                                 for party, identity in sorted(profile['parties'].items())],
            'scope': 'THIS_EXACT_COMPANION_ONLY; NO_INHERITED_AGREEMENT_ASSENT',
            'execution_authorized': False}


def _assents(profile, approvals):
    payload = assent_payload(profile)
    _rows(approvals, 32)
    supplied = {}
    for proof in approvals:
        _fields(proof, 'party signature')
        _role(proof['party'], profile['parties'])
        need(proof['party'] not in supplied, 'AGREEMENT_PROFILE_DUPLICATE_ASSENT')
        supplied[proof['party']] = proof['signature']
    rows = []
    for role in payload['required_assents']:
        status = 'MISSING_ROLE_SIGNATURE'
        if role['party'] in supplied:
            try:
                verify(role['identity'], payload['label'], role['body'], supplied[role['party']])
                status = 'VALID_ROLE_SIGNATURE'
            except (ValueError, TypeError):
                status = 'INVALID_ROLE_SIGNATURE'
        rows.append({'party': role['party'], 'status': status})
    complete = all(row['status'] == 'VALID_ROLE_SIGNATURE' for row in rows)
    return {'status': 'VERIFIED_COMPANION_ASSENT' if complete else 'PARTIAL_ASSENT' if any(row['status'] == 'VALID_ROLE_SIGNATURE' for row in rows) else 'PROPOSED',
            'roles': rows, 'scope': payload['scope'], 'agreement_assent': 'NOT_CHECKED',
            'current_authority': 'NOT_CHECKED; SIGNATURES_DO_NOT_ESTABLISH_CURRENT_AUTHORITY'}


def _pointer(value, pointer):
    for token in pointer.split('/')[1:]:
        token = token.replace('~1', '/').replace('~0', '~')
        if type(value) is dict:
            if token not in value:
                return False
            value = value[token]
        elif type(value) is list:
            if re.fullmatch(r'0|[1-9][0-9]*', token) is None or len(token) > 6 or int(token) >= len(value):
                return False
            value = value[int(token)]
        else:
            return False
    return True


def review(profile, expected_id, sources=None, models=None, approvals=None, reviewed_at=None):
    """Read-only review of exact adopted companion and optionally supplied bytes.

    ``sources`` rows are {document: raw-UTF8-SHA256, text: str}; ``models`` rows
    are {document: canonical-JSON-SHA256, value: JSON}. No I/O or execution.
    Missing references remain NOT_CHECKED; wrong supplied pins are refused.
    ``reviewed_at`` is a caller clock assumption, never trusted time evidence.
    """
    ref = identifier(profile)
    _hash(expected_id)
    need(ref == expected_id, 'AGREEMENT_PROFILE_EXPECTED_ID')
    if reviewed_at is not None:
        _time(reviewed_at)
    sources = [] if sources is None else sources
    models = [] if models is None else models
    _rows(sources)
    _rows(models)
    source_map, model_map = {}, {}
    total = 0
    for row in sources:
        _fields(row, 'document text')
        _hash(row['document'])
        need(row['document'] not in source_map, 'AGREEMENT_PROFILE_DUPLICATE_DOCUMENT')
        need(source_hash(row['text']) == row['document'], 'AGREEMENT_PROFILE_SOURCE_HASH')
        source_map[row['document']] = row['text'].encode('utf-8')
        total += len(source_map[row['document']])
    for row in models:
        _fields(row, 'document value')
        _hash(row['document'])
        need(row['document'] not in model_map, 'AGREEMENT_PROFILE_DUPLICATE_DOCUMENT')
        need(model_hash(row['value']) == row['document'], 'AGREEMENT_PROFILE_MODEL_HASH')
        model_map[row['document']] = row['value']
        total += len(canonical(row['value']))
    need(total <= MAX_TOTAL_DOCUMENT_BYTES, 'AGREEMENT_PROFILE_DOCUMENT_LIMIT')
    mappings = []
    for row in profile['mappings']:
        source, model = row['source'], row['model']
        raw = source_map.get(source['document'])
        source_status = 'NOT_CHECKED; SOURCE_BYTES_NOT_SUPPLIED'
        if raw is not None:
            need(source['end'] <= len(raw), 'AGREEMENT_PROFILE_SPAN')
            span = raw[source['start']:source['end']]
            try:
                raw[:source['start']].decode('utf-8')
                span.decode('utf-8')
            except UnicodeError:
                raise ValueError('AGREEMENT_PROFILE_SPAN_UTF8_BOUNDARY') from None
            source_status = 'VERIFIED_EXACT_UTF8_SPAN' if hashlib.sha256(span).hexdigest() == source['span_hash'] else 'SPAN_HASH_MISMATCH'
        present = model['document'] in model_map
        paths = [{'path': path, 'status': ('PRESENT' if _pointer(model_map[model['document']], path) else 'MISSING') if present else 'NOT_CHECKED'} for path in model['rule_paths']]
        mappings.append({'id': row['id'], 'source': deepcopy(source), 'source_status': source_status,
                         'model': deepcopy(model), 'rule_paths': paths, 'precedence': row['precedence'],
                         'transformation': row['transformation'], 'declared_claim': row['claim'],
                         'translation_correctness': 'NOT_CHECKED; BYTE_AND_REFERENCE_CHECKING_ONLY',
                         'factual_premises': 'NOT_CHECKED', 'execution_authorized': False})
    decisions = [{**deepcopy(row), 'allocation': 'PROPOSED_UNTIL_COMPANION_ASSENT',
                  'deadline_status': 'NOT_CHECKED' if reviewed_at is None else 'PAST_DECLARED_DEADLINE' if reviewed_at > row['deadline'] else 'WITHIN_DECLARED_WINDOW',
                  'decision': 'OPEN; NO_DECISION_RECORDED', 'current_authority': 'NOT_CHECKED'} for row in profile['decisions']]
    assent = _assents(profile, [] if approvals is None else approvals)
    if assent['status'] == 'VERIFIED_COMPANION_ASSENT':
        for row in decisions:
            row['allocation'] = 'EXACT_COMPANION_ALLOCATION_SIGNED; CURRENT_AUTHORITY_NOT_CHECKED'
    relationships = []
    for row in profile['relationships']:
        authorities = [{**deepcopy(grant), 'status': 'NOT_CHECKED' if reviewed_at is None else
                       'OUTSIDE_DECLARED_AUTHORITY_WINDOW' if not grant['as_of'] <= reviewed_at <= grant['valid_until'] else
                       'WITHIN_DECLARED_WINDOW; CURRENT_AUTHORITY_NOT_CHECKED'} for grant in row['authority']]
        relationships.append({**deepcopy(row), 'authority': authorities,
                              'effect': 'NO_NATIVE_AUTHORITY_COLLATERAL_SUBSTITUTION_OR_CAP_ENFORCEMENT'})
    return {'version': RESULT, 'profile': ref, 'agreement': deepcopy(profile['agreement']),
            'assent': assent, 'decisions': decisions, 'relationships': relationships,
            'formality': {**deepcopy(profile['formality']), 'legal_effect': 'NOT_DETERMINED',
                          'evidence_modes_equivalent': False, 'external_formality_performance': 'NOT_CHECKED',
                          'mandatory_rules_displaced': False,
                          'reported_oral_agreement': 'ATTRIBUTED_REPORT_ONLY; NO_FABRICATED_COUNTERPARTY_ASSENT'},
            'mappings': mappings, 'reviewed_at': reviewed_at,
            'clock_basis': 'CALLER_ASSUMPTION; NOT_VERIFIED_TIME_EVIDENCE',
            'current_authority': 'NOT_CHECKED', 'execution_authorized': False,
            'historical_profiles_reinterpreted': False}
