"""Agentic Arbitration Protocol adapter: strict messages, JWS and custody chains.

GRAFT. This binds, unchanged, to the Agentic Arbitration Protocol repository
(github.com/vbkotecha/agentic-arbitration-protocol, commit a38a4f3: JSON
Schema draft-07 files of draft -02, RFC 001-003; Apache-2.0, Consulate, Inc.).
That project also abbreviates itself "AAP", so this module always uses its
full name. ``RULES`` transcribes the constraint keywords of its schemas; the
tests compare them with the vendored originals. Hashes follow RFC 002 and
RFC 003 exactly: ECMAScript ``JSON.stringify`` of the listed fields, which
``stringify`` reproduces, including key order and number formatting.

Messages, custody events and awards read here are evidence. Keys come from
the caller's pins, never from a message. Nothing here signs for a party,
fetches anything, contacts a service, pays or releases escrow. AAP's own
signed terms and ladder decide any effect.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import base64
import binascii
import hashlib
import json
import math
import re

from cryptography.exceptions import InvalidSignature, UnsupportedAlgorithm
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature, encode_dss_signature

from .crypto import need

PROFILE = 'urn:aap:agentic-arbitration-adapter:0.1'
UPSTREAM = {
    'name': 'Agentic Arbitration Protocol',
    'repository': 'https://github.com/vbkotecha/agentic-arbitration-protocol',
    'commit': 'a38a4f3de016a48a45661f47c0db7ad28d852583',
    'schemas': 'spec/json-schema/*.json (JSON Schema draft-07; matches draft -02)',
    'specifications': ['rfcs/rfc.001.agentic-arbitration-protocol.md', 'rfcs/rfc.002.chain-of-custody.md',
                       'rfcs/rfc.003.dual-format-awards.md', 'draft/draft-kotecha-agentic-arbitration-protocol-02.xml'],
    'context': 'https://w3id.org/aap/v1',
    'license': 'Apache-2.0',
}
CONTEXT = UPSTREAM['context']
MAX_BYTES = 1_048_576
MAX_TEXT = 65_536
MAX_DEPTH = 32
MAX_NODES = 20_000
MAX_EVENTS = 1024
MAX_PDF = 16_777_216
MAX_JWS = 2 * MAX_BYTES
LIMITS = {'message_bytes': MAX_BYTES, 'string_bytes': MAX_TEXT, 'depth': MAX_DEPTH, 'nodes': MAX_NODES,
          'custody_events': MAX_EVENTS, 'pdf_bytes': MAX_PDF, 'integer': 2**53 - 1}
FLAGS = {'authority': 'EVIDENCE_ONLY', 'execution_authorized': False, 'network_accessed': False}

REMEDIATION = {
    'AGENTIC_ARBITRATION_JSON': 'Send exactly one UTF-8 JSON value without a byte-order mark or trailing data.',
    'AGENTIC_ARBITRATION_SIZE': 'Keep each message under 1 MiB; reference large evidence by hash.',
    'AGENTIC_ARBITRATION_DUPLICATE_KEY': 'Remove the repeated member name; parsers disagree about duplicates.',
    'AGENTIC_ARBITRATION_NUMBER': 'Use finite numbers; integers must stay within 2^53-1 so ECMAScript reads them exactly.',
    'AGENTIC_ARBITRATION_UNICODE': 'Use well-formed Unicode; lone surrogates cannot be hashed as UTF-8.',
    'AGENTIC_ARBITRATION_COMPLEXITY': 'Flatten or shorten the value: depth 32, 20000 nodes, 64 KiB per string.',
    'AGENTIC_ARBITRATION_JSON_TYPE': 'Use JSON objects, arrays, strings, numbers, booleans or null.',
    'AGENTIC_ARBITRATION_TYPE': 'Use one of the supported @type values or name the kind explicitly.',
    'AGENTIC_ARBITRATION_SCHEMA': 'Correct the member at the reported path to match the pinned upstream schema.',
    'AGENTIC_ARBITRATION_SCHEMA_KEYWORD': 'Internal rule error: an unsupported schema keyword was used; report it.',
    'AGENTIC_ARBITRATION_PAYLOAD': 'Messages must carry a payload object even though the upstream base schema omits it.',
    'AGENTIC_ARBITRATION_KEY': 'Pass a PEM SubjectPublicKeyInfo P-256 or P-384 key obtained independently of the message.',
    'AGENTIC_ARBITRATION_JWS': 'Pass a compact JWS: three canonical base64url segments with a JSON protected header.',
    'AGENTIC_ARBITRATION_JWS_ALGORITHM': 'Use ES256 or ES384 (RFC 7518 section 3.4); none, HMAC and other algorithms are refused.',
    'AGENTIC_ARBITRATION_JWS_CURVE': 'The pinned key is on a different curve from the JWS alg: ES256 needs P-256, ES384 needs P-384.',
    'AGENTIC_ARBITRATION_JWS_CRITICAL': 'Remove crit and b64; no JWS extensions are supported.',
    'AGENTIC_ARBITRATION_JWS_SIGNATURE': 'The signature does not verify under the pinned key; obtain an unmodified message.',
    'AGENTIC_ARBITRATION_SIGNER': 'Pass an EllipticCurvePrivateKey on P-256 or P-384 held by the caller.',
    'CUSTODY_EMPTY': 'Supply at least one custody event in chain order.',
    'CUSTODY_LIMIT': 'Verify at most 1024 events at once; resume with anchor set to the last verified head.',
    'CUSTODY_CASE': 'Every event must name the same caseId as the case you expected.',
    'CUSTODY_DUPLICATE_EVENT': 'Each eventId may appear once; obtain an unmodified export.',
    'CUSTODY_CONTENT_HASH': 'The event changed after hashing, or was hashed differently from RFC 002; obtain the original.',
    'CUSTODY_CHAIN_BREAK': 'An event is missing, reordered or replaced; obtain the complete chain in order.',
    'CUSTODY_ANCHOR': 'Pass anchor as the sha256:<hex> head you verified earlier, or omit it for a chain from genesis.',
    'CUSTODY_TIME_ORDER': 'Timestamps must not decrease along the chain; the export was reordered or backdated.',
    'CUSTODY_KEY_MISMATCH': 'The event carries a different key from your pin for that actor; do not re-pin to force a pass.',
    'CUSTODY_KEY_UNPINNED': 'Pin the actor or service key independently (keys/service_keys), or ask only for allow_unpinned linkage.',
    'CUSTODY_SIGNATURE': 'An event signature fails under every pinned key; the event or chain was altered.',
    'CUSTODY_SIGNATURE_BINDING': 'The JWS verifies but signs something other than this event or its contentHash.',
    'EXTERNAL_AWARD_PANEL': 'Panel judgeIds must be unique and every signature must name a panel member once.',
    'EXTERNAL_AWARD_JSON_HASH': 'formats.json.contentHash does not match the award as received (RFC 003); obtain the original.',
    'EXTERNAL_AWARD_PDF_HASH': 'The PDF bytes do not match formats.pdf.contentHash; obtain the signed original.',
    'EXTERNAL_AWARD_PDF_SIZE': 'Pass the PDF as bytes of at most 16 MiB.',
    'EXTERNAL_AWARD_SIGNATURE': 'A JWS on the award fails under the pinned keys; the award was altered or keys are wrong.',
    'EXTERNAL_AWARD_JUDGE_UNPINNED': 'Pin every panel member key independently, or verify with require_all_judges false.',
    'EXTERNAL_AWARD_PANEL_SIGNATURES': 'Every panel member must sign (RFC 003); obtain the missing signatures.',
}


# Bounded strict JSON ---------------------------------------------------------

def bounded(value, limit=MAX_BYTES, most=MAX_NODES):
    """Refuse values a peer could use to exhaust memory or confuse two parsers."""
    stack = [(value, 0)]; nodes = 0; size = 0
    while stack:
        item, depth = stack.pop(); nodes += 1
        need(depth <= MAX_DEPTH and nodes <= most, 'AGENTIC_ARBITRATION_COMPLEXITY')
        kind = type(item)
        if kind is str:
            try: length = len(item.encode('utf-8'))
            except UnicodeError: raise ValueError('AGENTIC_ARBITRATION_UNICODE') from None
            size += length
            need(length <= MAX_TEXT and size <= limit, 'AGENTIC_ARBITRATION_COMPLEXITY')
        elif kind is int:
            need(abs(item) <= 2**53 - 1, 'AGENTIC_ARBITRATION_NUMBER')
        elif kind is float:
            need(math.isfinite(item), 'AGENTIC_ARBITRATION_NUMBER')
        elif kind is list:
            stack.extend((child, depth + 1) for child in item)
        elif kind is dict:
            for name, child in item.items():
                need(type(name) is str, 'AGENTIC_ARBITRATION_JSON_TYPE')
                stack.append((name, depth + 1)); stack.append((child, depth + 1))
        else:
            need(item is None or kind is bool, 'AGENTIC_ARBITRATION_JSON_TYPE')
    return value


def parse(raw, limit=MAX_BYTES, most=MAX_NODES):
    """One strict JSON value: UTF-8, no BOM, unique names, finite numbers, bounded."""
    need(type(raw) in (bytes, str), 'AGENTIC_ARBITRATION_JSON')
    if type(raw) is str:
        try: raw = raw.encode('utf-8')
        except UnicodeError: raise ValueError('AGENTIC_ARBITRATION_UNICODE') from None
    need(0 < len(raw) <= limit, 'AGENTIC_ARBITRATION_SIZE')
    need(not raw.startswith(b'\xef\xbb\xbf'), 'AGENTIC_ARBITRATION_JSON')

    def pairs(items):
        out = {}
        for name, item in items:
            need(name not in out, 'AGENTIC_ARBITRATION_DUPLICATE_KEY'); out[name] = item
        return out

    def constant(_):
        raise ValueError('AGENTIC_ARBITRATION_NUMBER')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_constant=constant)
    except (UnicodeError, RecursionError) as exc:
        raise ValueError('AGENTIC_ARBITRATION_JSON') from exc
    except ValueError as exc:
        if str(exc).startswith('AGENTIC_ARBITRATION_'): raise
        raise ValueError('AGENTIC_ARBITRATION_JSON') from exc
    return bounded(value, limit, most)


# ECMAScript JSON.stringify, the hash input RFC 002 and RFC 003 define ---------

_INDEX = re.compile(r'(?:0|[1-9][0-9]{0,9})\Z', re.ASCII)
_ESCAPES = {'"': '\\"', '\\': '\\\\', '\b': '\\b', '\f': '\\f', '\n': '\\n', '\r': '\\r', '\t': '\\t'}


def _keys(value):
    # OrdinaryOwnPropertyKeys: array-index names ascending, then insertion order.
    index = sorted((name for name in value if _INDEX.match(name) and int(name) < 2**32 - 1), key=int)
    chosen = set(index)
    return index + [name for name in value if name not in chosen]


def _string(text):
    out = []
    for char in text:
        code = ord(char)
        if char in _ESCAPES: out.append(_ESCAPES[char])
        elif code < 0x20 or 0xD800 <= code <= 0xDFFF: out.append('\\u%04x' % code)
        else: out.append(char)
    return '"' + ''.join(out) + '"'


def _number(value):
    # Number::toString (ECMA-262 section 6.1.6.1.20) from the shortest round-trip digits.
    if type(value) is int and abs(value) <= 2**53 - 1:
        return str(value)
    value = float(value)
    if value == 0:
        return '0'
    mantissa, _, exponent = repr(abs(value)).partition('e')
    digits = mantissa.replace('.', '')
    point = mantissa.index('.') if '.' in mantissa else len(mantissa)
    significant = digits.lstrip('0')
    n = point + (int(exponent) if exponent else 0) - (len(digits) - len(significant))
    digits = significant.rstrip('0')
    k = len(digits)
    if k <= n <= 21: text = digits + '0' * (n - k)
    elif 0 < n <= 21: text = digits[:n] + '.' + digits[n:]
    elif -6 < n <= 0: text = '0.' + '0' * -n + digits
    else:
        text = digits[0] + ('.' + digits[1:] if k > 1 else '') + 'e' + ('+' if n - 1 >= 0 else '-') + str(abs(n - 1))
    return ('-' if value < 0 else '') + text


def _stringify(value):
    if value is None: return 'null'
    if value is True: return 'true'
    if value is False: return 'false'
    if type(value) in (int, float): return _number(value)
    if type(value) is str: return _string(value)
    if type(value) is list: return '[' + ','.join(_stringify(item) for item in value) + ']'
    return '{' + ','.join(_string(name) + ':' + _stringify(value[name]) for name in _keys(value)) + '}'


def stringify(value):
    """Exactly what ECMAScript JSON.stringify(value) returns for parsed JSON."""
    return _stringify(bounded(value))


def digest_text(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


# Schema rules transcribed from the pinned upstream files ------------------------

MESSAGE_TYPES = ['DisputeFiling', 'DisputeResponse', 'EvidenceSubmission', 'ArbitrationAward', 'CustodyEvent', 'DisputeNotification']
EVIDENCE_TYPES = ['SYSTEM_LOGS', 'CONTRACTS', 'COMMUNICATIONS', 'FINANCIAL', 'EXPERT']
METHODS = ['EXPERT_DETERMINATION', 'BINDING_ARBITRATION', 'MEDIATION', 'HYBRID']
OUTCOMES = ['CLAIMANT_PREVAILS', 'RESPONDENT_PREVAILS', 'SPLIT_DECISION', 'DISMISSED']
LIABILITY = ['CLAIMANT_LIABLE', 'RESPONDENT_LIABLE', 'BOTH_LIABLE', 'NEITHER_LIABLE']
CLAIM_TYPES = ['SLA_BREACH', 'BREACH_OF_CONTRACT', 'PAYMENT_DISPUTE', 'SERVICE_FAILURE', 'QUALITY_DISPUTE', 'OTHER']
COUNTER_TYPES = ['BREACH_OF_CONTRACT', 'PAYMENT_DISPUTE', 'SERVICE_FAILURE', 'OTHER']
EVENT_TYPES = ['DISPUTE_FILED', 'DISPUTE_NOTIFICATION_SENT', 'RESPONSE_SUBMITTED', 'EVIDENCE_SUBMITTED', 'PANEL_ASSIGNED',
               'DELIBERATION_STARTED', 'DELIBERATION_COMPLETED', 'AWARD_ISSUED', 'AWARD_DELIVERED', 'COMPLIANCE_VERIFIED']
ACTOR_TYPES = ['CLAIMANT_AGENT', 'RESPONDENT_AGENT', 'ARBITRATION_SERVICE', 'ARBITRATOR', 'SYSTEM']


def _object(required=(), **properties):
    rule = {'type': 'object', 'properties': properties}
    if required: rule['required'] = list(required)
    return rule


STRING = {'type': 'string'}
NUMBER = {'type': 'number'}
URI = {'type': 'string', 'format': 'uri'}
WHEN = {'type': 'string', 'format': 'date-time'}
SHA = {'type': 'string', 'pattern': '^sha256:[a-f0-9]{64}$'}
AGENT = {'type': 'string', 'format': 'uri', 'pattern': '^agent://'}
ORG = {'type': 'string', 'format': 'uri', 'pattern': '^org://'}
CURRENCY = {'type': 'string', 'pattern': '^[A-Z]{3}$'}
MONEY = _object(('value', 'currency'), value={'type': 'number', 'minimum': 0}, currency=CURRENCY)
TEXTS = {'type': 'array', 'items': STRING}
EVIDENCE_ITEM = _object(('evidenceId', 'evidenceType', 'contentHash', 'storageUri'), evidenceId=STRING,
                        evidenceType={'type': 'string', 'enum': EVIDENCE_TYPES}, contentHash=SHA, storageUri=URI,
                        description=STRING)


def _message(kind, payload):
    return _object(('@context', '@type', 'messageId', 'timestamp', 'sender', 'recipient', 'signature'), **{
        '@context': {'type': 'string', 'const': CONTEXT},
        '@type': {'type': 'string', 'enum': MESSAGE_TYPES, **({'const': kind} if kind != 'DisputeNotification' else {})},
        'messageId': {'type': 'string', 'format': 'uuid'}, 'timestamp': WHEN,
        'sender': AGENT, 'recipient': URI,
        'signature': {'type': 'string', 'pattern': '^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$'},
        'payload': payload})


RULES = {
    'DisputeFiling': _message('DisputeFiling', _object(
        ('claimant', 'respondent', 'claim', 'arbitrationAgreement'),
        claimant=_object(('agentId', 'organizationId'), agentId=AGENT, organizationId=ORG, publicKey=STRING),
        respondent=_object(('agentId', 'organizationId'), agentId=AGENT, organizationId=ORG),
        claim=_object(('claimType', 'claimAmount'), claimType={'type': 'string', 'enum': CLAIM_TYPES}, claimAmount=MONEY,
                      contractReference=URI, breachDetails=STRING, breachDate=WHEN),
        evidence={'type': 'array', 'items': EVIDENCE_ITEM},
        arbitrationAgreement=_object(('agreementId', 'rulesVersion', 'resolutionMethod', 'signatureDate'),
                                     agreementId=STRING, rulesVersion=STRING,
                                     resolutionMethod={'type': 'string', 'enum': METHODS},
                                     signatureDate=WHEN, agreementUri=URI))),
    'DisputeResponse': _message('DisputeResponse', _object(
        ('caseId', 'respondent', 'response'), caseId=STRING,
        respondent=_object(('agentId', 'organizationId'), agentId=AGENT, organizationId=ORG, publicKey=STRING),
        response=_object(admissions=TEXTS, denials=TEXTS, affirmativeDefenses=TEXTS,
                         counterClaim=_object(claimType={'type': 'string', 'enum': COUNTER_TYPES}, claimAmount=MONEY,
                                              details=STRING),
                         narrative=STRING),
        evidence={'type': 'array', 'items': EVIDENCE_ITEM})),
    'EvidenceSubmission': _message('EvidenceSubmission', _object(
        ('caseId', 'submittedBy', 'evidence'), caseId=STRING,
        submittedBy={'type': 'string', 'enum': ['claimant', 'respondent']},
        evidence=_object(('evidenceId', 'evidenceType', 'contentHash', 'storageUri', 'signature'),
                         evidenceId=STRING, evidenceType={'type': 'string', 'enum': EVIDENCE_TYPES}, description=STRING,
                         dateRange=_object(start=WHEN, end=WHEN), contentHash=SHA, storageUri=URI,
                         metadata=_object(logSource=STRING, recordCount=NUMBER, validator=URI), signature=STRING,
                         timestampProof=_object(timestamp=WHEN, timestampAuthority=STRING, proof=STRING)))),
    'ArbitrationAward': _message('ArbitrationAward', _object(
        ('awardId', 'caseId', 'issuedAt', 'resolutionMethod', 'panel', 'decision', 'formats', 'signatures'),
        awardId=STRING, caseId=STRING, issuedAt=WHEN, resolutionMethod={'type': 'string', 'enum': METHODS},
        panel={'type': 'array', 'minItems': 1, 'items': _object(('judgeId', 'judgeType'), judgeId=STRING,
                                                                  judgeType={'type': 'string', 'enum': ['AI', 'HUMAN']},
                                                                  name=STRING)},
        decision=_object(('outcome', 'liability', 'findings', 'reasoning', 'remedy'),
                         outcome={'type': 'string', 'enum': OUTCOMES}, liability={'type': 'string', 'enum': LIABILITY},
                         damages=_object(value={'type': 'number', 'minimum': 0}, currency=CURRENCY),
                         findings=STRING, reasoning=STRING, remedy=STRING),
        enforcement=_object(complianceDeadline=WHEN,
                            enforcementMechanism={'type': 'string', 'enum': ['SMART_CONTRACT', 'MANUAL', 'ESCROW', 'PAYMENT_PROCESSOR']},
                            smartContractAddress=STRING),
        formats=_object(('json', 'pdf'), json=_object(('contentHash', 'signature'), contentHash=SHA, signature=STRING),
                        pdf=_object(('documentUri', 'contentHash', 'signature'), documentUri=URI, contentHash=SHA,
                                    signature=STRING, pdfSignature=STRING)),
        signatures={'type': 'array', 'items': _object(('judgeId', 'signature'), judgeId=STRING, signature=STRING, timestamp=WHEN)},
        publicationStatus={'type': 'string', 'enum': ['PUBLIC', 'CONFIDENTIAL', 'REDACTED']},
        precedentialValue={'type': 'string', 'enum': ['BINDING', 'PERSUASIVE', 'NONE']})),
    'DisputeNotification': _message('DisputeNotification', {'type': 'object'}),
    'CustodyEvent': _object(
        ('@type', 'eventId', 'caseId', 'eventType', 'timestamp', 'actor', 'action', 'integrity'),
        **{'@type': {'type': 'string', 'const': 'CustodyEvent'}, 'eventId': STRING, 'caseId': STRING,
           'eventType': {'type': 'string', 'enum': EVENT_TYPES}, 'timestamp': WHEN,
           'actor': _object(('actorId', 'actorType'), actorId=URI, actorType={'type': 'string', 'enum': ACTOR_TYPES},
                            publicKey=STRING),
           'action': _object(('description',), description=STRING, targetResource=URI, actionData={'type': 'object'}),
           'integrity': _object(('contentHash', 'previousEventHash', 'signature'), contentHash=SHA,
                                previousEventHash={'type': ['string', 'null'], 'pattern': '^sha256:[a-f0-9]{64}$'},
                                signature=STRING,
                                timestamp=_object(rfc3161=STRING, blockchain=_object(
                                    chain={'type': 'string', 'enum': ['ethereum', 'bitcoin', 'polygon']},
                                    transactionHash=STRING, blockNumber=NUMBER)))}),
    'ArbitratorManifest': _object(
        ('arbitratorId', 'type', 'qualifications', 'availability', 'publicKey'),
        arbitratorId=STRING, name=STRING, type={'type': 'string', 'enum': ['HUMAN', 'AI']},
        qualifications=_object(certifications=TEXTS,
                               jurisdictions={'type': 'array', 'items': {'type': 'string', 'pattern': '^[A-Z]{2}(-[A-Z]{2})?$'}},
                               specializations=TEXTS, yearsExperience={'type': 'number', 'minimum': 0},
                               casesCompleted={'type': 'number', 'minimum': 0}, model=STRING, version=STRING,
                               trainingData=STRING),
        availability=_object(('status',), status={'type': 'string', 'enum': ['AVAILABLE', 'BUSY', 'UNAVAILABLE']},
                             nextAvailable=WHEN, maxCaseload=NUMBER, currentCaseload=NUMBER, responseTime=STRING),
        publicKey=STRING,
        biasAudit=_object(lastAuditDate={'type': 'string', 'format': 'date'}, auditResults=URI,
                          fairnessScore={'type': 'number', 'minimum': 0, 'maximum': 1},
                          biasMetrics=_object(genderBias={'type': 'number', 'minimum': 0, 'maximum': 1},
                                              organizationSizeBias={'type': 'number', 'minimum': 0, 'maximum': 1},
                                              claimAmountBias={'type': 'number', 'minimum': 0, 'maximum': 1})),
        performanceMetrics=_object(averageResolutionTime=STRING,
                                   satisfactionScore={'type': 'number', 'minimum': 0, 'maximum': 5},
                                   appealRate={'type': 'number', 'minimum': 0, 'maximum': 1}),
        pricing=_object(feeStructure={'type': 'string', 'enum': ['HOURLY', 'PER_CASE', 'PERCENTAGE', 'FREE']},
                        amount=_object(value={'type': 'number', 'minimum': 0}, currency=CURRENCY))),
}
SCHEMA_FILES = {'DisputeFiling': 'schema.dispute-filing.json', 'DisputeResponse': 'schema.dispute-response.json',
                'EvidenceSubmission': 'schema.evidence-submission.json', 'ArbitrationAward': 'schema.arbitration-award.json',
                'DisputeNotification': 'schema.base-message.json', 'CustodyEvent': 'schema.custody-event.json',
                'ArbitratorManifest': 'schema.arbitrator-manifest.json'}

_KEYWORDS = {'type', 'required', 'properties', 'items', 'enum', 'const', 'pattern', 'minimum', 'maximum', 'minItems', 'format'}
_PATTERNS = {}
_UUID = re.compile(r'(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\Z', re.ASCII | re.IGNORECASE)
_URI = re.compile(r"[A-Za-z][A-Za-z0-9+.-]*:(?:[A-Za-z0-9\-._~!$&'()*+,;=:@/?#\[\]]|%[0-9A-Fa-f]{2})*\Z", re.ASCII)
_DATE = re.compile(r'([0-9]{4})-([0-9]{2})-([0-9]{2})\Z', re.ASCII)
_DATE_TIME = re.compile(r'([0-9]{4})-([0-9]{2})-([0-9]{2})[Tt]([0-9]{2}):([0-9]{2}):([0-9]{2})(\.[0-9]{1,9})?'
                        r'(?:([Zz])|([+-])([0-9]{2}):([0-9]{2}))\Z', re.ASCII)


def _pattern(text):
    # ECMA-262 without the u flag: ASCII classes, and $ only at the very end.
    if text not in _PATTERNS:
        _PATTERNS[text] = re.compile(text[:-1] + r'\Z' if text.endswith('$') else text, re.ASCII)
    return _PATTERNS[text]


def _calendar(year, month, day):
    if not (1 <= month <= 12 and year >= 1): return False
    days = [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return 1 <= day <= days[month - 1]


def instant(text):
    """RFC 3339 section 5.6 date-time to exact UTC (seconds, nanoseconds); None when invalid."""
    match = _DATE_TIME.match(text) if type(text) is str else None
    if not match: return None
    year, month, day, hour, minute, second = (int(match.group(i)) for i in range(1, 7))
    if not (_calendar(year, month, day) and hour <= 23 and minute <= 59 and second <= 59): return None
    offset = 0
    if match.group(9):
        oh, om = int(match.group(10)), int(match.group(11))
        if oh > 23 or om > 59: return None
        offset = (oh * 60 + om) * (1 if match.group(9) == '+' else -1)
    moment = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc) - timedelta(minutes=offset)
    epoch = (moment - datetime(1970, 1, 1, tzinfo=timezone.utc)) // timedelta(seconds=1)
    fraction = (match.group(7) or '.')[1:]
    return epoch, int((fraction + '000000000')[:9])


def valid_uri(text):
    """RFC 3986 characters with a scheme, as the schemas' format uri requires."""
    return type(text) is str and len(text) <= MAX_TEXT and _URI.match(text) is not None


def ni_uri(sha256_hex):
    """RFC 6920 section 3 name for bytes with this SHA-256: ni:///sha-256;<base64url>."""
    need(type(sha256_hex) is str and re.fullmatch('[0-9a-f]{64}', sha256_hex) is not None, 'AGENTIC_ARBITRATION_SCHEMA:ni')
    return 'ni:///sha-256;' + _b64(bytes.fromhex(sha256_hex))


def _format(name, text):
    if name == 'uuid': return _UUID.match(text) is not None
    if name == 'uri': return _URI.match(text) is not None
    if name == 'date-time': return instant(text) is not None
    if name == 'date':
        match = _DATE.match(text)
        return bool(match) and _calendar(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    raise ValueError('AGENTIC_ARBITRATION_SCHEMA_KEYWORD')


def _is(kind, value):
    if kind == 'string': return type(value) is str
    if kind == 'number': return type(value) in (int, float)
    if kind == 'integer': return type(value) is int or (type(value) is float and value.is_integer())
    if kind == 'object': return type(value) is dict
    if kind == 'array': return type(value) is list
    if kind == 'boolean': return type(value) is bool
    if kind == 'null': return value is None
    raise ValueError('AGENTIC_ARBITRATION_SCHEMA_KEYWORD')


def check(rule, value, path='$'):
    """A JSON Schema draft-07 subset; an unsupported keyword is an error, never ignored."""
    need(not set(rule) - _KEYWORDS, 'AGENTIC_ARBITRATION_SCHEMA_KEYWORD')
    code = 'AGENTIC_ARBITRATION_SCHEMA:' + path
    if 'type' in rule:
        kinds = rule['type'] if type(rule['type']) is list else [rule['type']]
        need(any(_is(kind, value) for kind in kinds), code)
    if 'const' in rule: need(type(value) is type(rule['const']) and value == rule['const'], code)
    if 'enum' in rule: need(any(type(value) is type(item) and value == item for item in rule['enum']), code)
    if type(value) is str:
        if 'pattern' in rule: need(_pattern(rule['pattern']).search(value) is not None, code)
        if 'format' in rule: need(_format(rule['format'], value), code)
    if type(value) in (int, float):
        if 'minimum' in rule: need(value >= rule['minimum'], code)
        if 'maximum' in rule: need(value <= rule['maximum'], code)
    if type(value) is list:
        need(len(value) >= rule.get('minItems', 0), code)
        if 'items' in rule:
            for index, item in enumerate(value): check(rule['items'], item, '%s[%d]' % (path, index))
    if type(value) is dict:
        for name in rule.get('required', ()): need(name in value, code + '.' + name)
        for name, child in rule.get('properties', {}).items():
            if name in value: check(child, value[name], path + '.' + name)
    return True


def validate(document, kind=None):
    """Validate against the transcribed upstream rules; returns the kind."""
    bounded(document)
    if kind is None:
        kind = document.get('@type') if type(document) is dict else None
    need(type(kind) is str and kind in RULES, 'AGENTIC_ARBITRATION_TYPE')
    check(RULES[kind], document)
    if kind not in ('CustodyEvent', 'ArbitratorManifest'):
        need(type(document.get('payload')) is dict, 'AGENTIC_ARBITRATION_PAYLOAD')
    return kind


def read(raw, kind=None):
    """Parse and validate one received message, keeping the exact bytes' digest."""
    document = parse(raw)
    kind = validate(document, kind)
    data = raw if type(raw) is bytes else raw.encode('utf-8')
    return {'kind': kind, 'document': document, 'sha256': hashlib.sha256(data).hexdigest(),
            'schema': UPSTREAM['commit'], **FLAGS}


# JWS: RFC 7515 compact serialization, RFC 7518 section 3.4 ES256/ES384 --------

ALGORITHMS = {'ES256': (ec.SECP256R1, hashes.SHA256, 32), 'ES384': (ec.SECP384R1, hashes.SHA384, 48)}
_B64 = re.compile(r'[A-Za-z0-9_-]+\Z', re.ASCII)


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _unb64(text, limit):
    need(type(text) is str and 0 < len(text) <= limit and _B64.match(text) is not None, 'AGENTIC_ARBITRATION_JWS')
    try:
        raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    except binascii.Error:
        raise ValueError('AGENTIC_ARBITRATION_JWS') from None
    need(_b64(raw) == text, 'AGENTIC_ARBITRATION_JWS')
    return raw


def public_key(pem):
    """Load a caller-pinned PEM SubjectPublicKeyInfo key; return (key, SHA-256 of the DER SPKI)."""
    need(type(pem) is str and 0 < len(pem) <= 4096 and pem.isascii(), 'AGENTIC_ARBITRATION_KEY')
    try:
        loaded = serialization.load_pem_public_key(pem.encode('ascii'))
    except (ValueError, TypeError, UnsupportedAlgorithm) as exc:
        raise ValueError('AGENTIC_ARBITRATION_KEY') from exc
    need(isinstance(loaded, ec.EllipticCurvePublicKey) and type(loaded.curve) in (ec.SECP256R1, ec.SECP384R1),
         'AGENTIC_ARBITRATION_KEY')
    der = loaded.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return loaded, hashlib.sha256(der).hexdigest()


def key_pin(pem):
    """The SHA-256 of a key's DER SubjectPublicKeyInfo, the pin AAP terms carry."""
    return public_key(pem)[1]


def public_pem(private_key):
    need(isinstance(private_key, ec.EllipticCurvePrivateKey), 'AGENTIC_ARBITRATION_SIGNER')
    return private_key.public_key().public_bytes(serialization.Encoding.PEM,
                                                 serialization.PublicFormat.SubjectPublicKeyInfo).decode('ascii')


def jws_sign(private_key, payload, kid=None):
    """Explicit caller action: a compact JWS over exact payload bytes (RFC 6979 nonces)."""
    need(isinstance(private_key, ec.EllipticCurvePrivateKey) and type(payload) is bytes and len(payload) <= MAX_BYTES,
         'AGENTIC_ARBITRATION_SIGNER')
    alg = next((name for name, (curve, _, _) in ALGORITHMS.items() if type(private_key.curve) is curve), None)
    need(alg is not None, 'AGENTIC_ARBITRATION_SIGNER')
    header = {'alg': alg}
    if kid is not None:
        need(type(kid) is str and 0 < len(kid) <= 256 and kid.isascii(), 'AGENTIC_ARBITRATION_SIGNER'); header['kid'] = kid
    _, digest, size = ALGORITHMS[alg]
    head = _b64(json.dumps(header, separators=(',', ':'), sort_keys=True).encode('ascii'))
    body = _b64(payload)
    der = private_key.sign((head + '.' + body).encode('ascii'), ec.ECDSA(digest(), deterministic_signing=True))
    r, s = decode_dss_signature(der)
    return head + '.' + body + '.' + _b64(r.to_bytes(size, 'big') + s.to_bytes(size, 'big'))


def jws_open(token, pem, candidates):
    """Verify a compact JWS under one pinned key; name which candidate bytes it signs.

    ``candidates`` is a list of (name, bytes). A valid signature over anything
    else returns binding None: the caller decides, nothing is assumed.
    """
    need(type(token) is str and len(token) <= MAX_JWS, 'AGENTIC_ARBITRATION_JWS')
    parts = token.split('.')
    need(len(parts) == 3, 'AGENTIC_ARBITRATION_JWS')
    header = parse(_unb64(parts[0], 4096))
    need(type(header) is dict and type(header.get('alg')) is str, 'AGENTIC_ARBITRATION_JWS')
    need(header['alg'] in ALGORITHMS, 'AGENTIC_ARBITRATION_JWS_ALGORITHM')
    need('crit' not in header and 'b64' not in header, 'AGENTIC_ARBITRATION_JWS_CRITICAL')
    payload = _unb64(parts[1], MAX_JWS)
    signature = _unb64(parts[2], 256)
    key, pin = public_key(pem)
    curve, digest, size = ALGORITHMS[header['alg']]
    need(type(key.curve) is curve, 'AGENTIC_ARBITRATION_JWS_CURVE')
    need(len(signature) == 2 * size, 'AGENTIC_ARBITRATION_JWS_SIGNATURE')
    r, s = int.from_bytes(signature[:size], 'big'), int.from_bytes(signature[size:], 'big')
    need(r > 0 and s > 0, 'AGENTIC_ARBITRATION_JWS_SIGNATURE')
    try:
        key.verify(encode_dss_signature(r, s), (parts[0] + '.' + parts[1]).encode('ascii'), ec.ECDSA(digest()))
    except InvalidSignature:
        raise ValueError('AGENTIC_ARBITRATION_JWS_SIGNATURE') from None
    binding = next((name for name, expected in candidates if expected == payload), None)
    kid = header.get('kid') if type(header.get('kid')) is str else None
    return {'alg': header['alg'], 'kid': kid, 'signer': pin, 'binding': binding}


def _try(token, keys, candidates):
    """First pinned key whose signature verifies; (result, tried_any)."""
    for pem in keys:
        try:
            return jws_open(token, pem, candidates), True
        except ValueError as exc:
            if str(exc) not in ('AGENTIC_ARBITRATION_JWS_SIGNATURE', 'AGENTIC_ARBITRATION_JWS_CURVE'): raise
    return None, bool(keys)


def seal(message, private_key, kid=None):
    """Explicit caller action: add ``signature`` as a JWS over JSON.stringify of the
    message without it (AAP's reading of 'JWS signature of the message')."""
    body = {name: deepcopy(item) for name, item in message.items() if name != 'signature'}
    signed = {**body, 'signature': jws_sign(private_key, stringify(body).encode('utf-8'), kid)}
    validate(signed)
    return signed


def message_signature(message, keys):
    """Report the top-level signature against pinned keys. Unknown stays unknown."""
    body = {name: item for name, item in message.items() if name != 'signature'}
    candidates = [('MESSAGE', stringify(body).encode('utf-8'))]
    if type(message.get('payload')) is dict:
        candidates.append(('PAYLOAD', stringify(message['payload']).encode('utf-8')))
    result, tried = _try(message['signature'], list(keys), candidates)
    if result is None:
        return {'status': 'NO_PINNED_KEY' if not tried else 'INVALID_UNDER_PINNED_KEYS', 'signer': None, 'binding': None}
    return {'status': 'VERIFIED' if result['binding'] else 'SIGNATURE_VALID_BINDING_UNKNOWN',
            'signer': result['signer'], 'binding': result['binding']}


# Custody chains: RFC 002 "Merkle Chain Linking" and "Verification Procedures" --

def custody_canonical(event):
    """RFC 002 'Hash Computation' bytes: the listed fields, signature and hash excluded."""
    return stringify({'@type': event['@type'], 'eventId': event['eventId'], 'caseId': event['caseId'],
                      'eventType': event['eventType'], 'timestamp': event['timestamp'], 'actor': event['actor'],
                      'action': event['action'],
                      'integrity': {'previousEventHash': event['integrity']['previousEventHash']}}).encode('utf-8')


def custody_hash(event):
    return digest_text(custody_canonical(event))


def custody_event(private_key, *, case, event_id, event_type, timestamp, actor_id, actor_type, description,
                  previous, target=None, data=None, include_key=True):
    """Explicit caller action: build and sign one event; the JWS signs its RFC 002 bytes."""
    actor = {'actorId': actor_id, 'actorType': actor_type}
    if include_key: actor['publicKey'] = public_pem(private_key)
    action = {'description': description}
    if target is not None: action['targetResource'] = target
    if data is not None: action['actionData'] = deepcopy(data)
    event = {'@type': 'CustodyEvent', 'eventId': event_id, 'caseId': case, 'eventType': event_type,
             'timestamp': timestamp, 'actor': actor, 'action': action,
             'integrity': {'contentHash': 'sha256:' + '0' * 64, 'previousEventHash': previous, 'signature': 'x'}}
    raw = custody_canonical(event)
    event['integrity'] = {'contentHash': digest_text(raw), 'previousEventHash': previous,
                          'signature': jws_sign(private_key, raw)}
    validate(event, 'CustodyEvent')
    return event


def custody_events(raw):
    """Read an export: a JSON array, a retrieval response with events, or JSON Lines (RFC 002)."""
    need(type(raw) in (bytes, str), 'AGENTIC_ARBITRATION_JSON')
    data = raw.encode('utf-8') if type(raw) is str else raw
    need(len(data) <= 4 * MAX_BYTES, 'CUSTODY_LIMIT')
    data = data.strip()
    try:
        document = parse(data, 4 * MAX_BYTES, 64 * MAX_EVENTS)
    except ValueError as exc:
        if str(exc) != 'AGENTIC_ARBITRATION_JSON' or b'\n' not in data: raise
        lines = [line for line in data.split(b'\n') if line.strip()]
        need(len(lines) <= MAX_EVENTS, 'CUSTODY_LIMIT')
        document = [parse(line) for line in lines]
    if type(document) is dict:
        document = document.get('events')
    need(type(document) is list, 'AGENTIC_ARBITRATION_JSON')
    return document


def verify_custody(events, *, keys=None, service_keys=(), case=None, anchor=None, allow_unpinned=False, tsa=None):
    """Verify a custody chain in the supplied order (no re-sorting, unlike RFC 002's sample).

    ``keys`` maps actorId to a PEM the caller pinned; ``service_keys`` are
    pinned arbitration-service keys, which draft -01 section 6.3 also lets
    sign. Without a pin a signature is never counted as verified;
    ``allow_unpinned`` only reports linkage under self-asserted keys.
    ``tsa`` lists owner-adopted time-stamp authorities (timestamp_tokens.adopt):
    an event's base64 RFC 3161 token over its RFC 002 bytes is then verified,
    reported per event, and never alters the signature checks.
    """
    if type(events) in (bytes, str):
        events = custody_events(events)
    need(type(events) is list and len(events) >= 1, 'CUSTODY_EMPTY')
    need(len(events) <= MAX_EVENTS, 'CUSTODY_LIMIT')
    keys = {} if keys is None else keys
    need(type(keys) is dict and len(keys) <= 64 and all(type(k) is str for k in keys), 'AGENTIC_ARBITRATION_KEY')
    service_keys = list(service_keys)
    need(len(service_keys) <= 16, 'AGENTIC_ARBITRATION_KEY')
    pins = {actor: key_pin(pem) for actor, pem in keys.items()}
    for pem in service_keys: key_pin(pem)
    if anchor is not None:
        need(type(anchor) is str and _pattern('^sha256:[a-f0-9]{64}$').search(anchor) is not None, 'CUSTODY_ANCHOR')
    expected_case = case
    previous_hash, previous_time = anchor, None
    seen, signers, types = set(), [], []
    self_asserted = False
    for index, event in enumerate(events):
        check(RULES['CustodyEvent'], bounded(event), '$[%d]' % index)
        if expected_case is None: expected_case = event['caseId']
        need(event['caseId'] == expected_case, 'CUSTODY_CASE')
        need(event['eventId'] not in seen, 'CUSTODY_DUPLICATE_EVENT'); seen.add(event['eventId'])
        raw = custody_canonical(event)
        content = digest_text(raw)
        need(content == event['integrity']['contentHash'], 'CUSTODY_CONTENT_HASH')
        need(event['integrity']['previousEventHash'] == previous_hash, 'CUSTODY_CHAIN_BREAK')
        moment = instant(event['timestamp'])
        need(previous_time is None or moment >= previous_time, 'CUSTODY_TIME_ORDER')
        actor = event['actor']['actorId']
        embedded = event['actor'].get('publicKey')
        if actor in keys and embedded is not None:
            try: same = key_pin(embedded) == pins[actor]
            except ValueError: same = False
            need(same, 'CUSTODY_KEY_MISMATCH')
        candidates = [('EVENT', raw), ('CONTENT_HASH', content.encode('ascii'))]
        pinned = ([keys[actor]] if actor in keys else []) + service_keys
        result, tried = _try(event['integrity']['signature'], pinned, candidates)
        by = None
        if result is not None:
            by = 'ACTOR' if actor in keys and result['signer'] == pins[actor] else 'SERVICE'
        elif tried:
            raise ValueError('CUSTODY_SIGNATURE')
        elif allow_unpinned and embedded is not None:
            result, _ = _try(event['integrity']['signature'], [embedded], candidates)
            need(result is not None, 'CUSTODY_SIGNATURE')
            by = 'SELF_ASSERTED_KEY'; self_asserted = True
        else:
            raise ValueError('CUSTODY_KEY_UNPINNED')
        need(result['binding'] is not None, 'CUSTODY_SIGNATURE_BINDING')
        signers.append({'event': event['eventId'], 'by': by, 'key': result['signer'], 'binding': result['binding'],
                        'timestamp_token': _timestamp_token(event, raw, moment, tsa)})
        types.append(event['eventType'])
        previous_hash, previous_time = content, moment
    return {'profile': PROFILE, 'case': expected_case, 'events': len(events), 'anchor': anchor,
            'first': events[0]['integrity']['contentHash'], 'head': previous_hash, 'event_types': types,
            'signers': signers, 'status': 'LINKED_SELF_ASSERTED_KEYS' if self_asserted else 'VERIFIED',
            'canonicalization': 'RFC002_JSON_STRINGIFY', 'order': 'AS_SUPPLIED_NONDECREASING_TIMESTAMPS',
            'timestamps': 'SIGNED_CLAIMS; RFC3161_TOKENS_AND_CHAIN_ANCHORS_NOT_VERIFIED' if tsa is None else
                          'SIGNED_CLAIMS; RFC3161_TOKENS_CHECKED_AGAINST_OWNER_ADOPTED_TSA; CHAIN_ANCHORS_NOT_VERIFIED',
            'completeness': 'PREFIX_ONLY; LATER_OR_WITHHELD_EVENTS_ARE_NOT_EXCLUDED', **FLAGS}


def _timestamp_token(event, raw, moment, tsa):
    if 'timestamp' not in event['integrity']:
        return None
    token = event['integrity']['timestamp'].get('rfc3161')
    if tsa is None or token is None:
        return 'PRESENT_NOT_VERIFIED'
    from . import timestamp_tokens
    try:
        checked = timestamp_tokens.verify(token, adopted=tsa, data=raw)
    except ValueError as error:
        return {'status': 'REFUSED', 'code': str(error), 'fix': timestamp_tokens.remediation(str(error))}
    return {'status': 'VERIFIED', 'tsa': checked['tsa'], 'gen_time': checked['gen_time'], 'not_after': checked['not_after'],
            'qualified': checked['qualified'],
            'claimed_time': 'CONSISTENT' if tuple(moment) <= (checked['not_after'], 0) else 'CLAIMED_AFTER_TOKEN_UPPER_BOUND'}


# Dual-format awards as received: RFC 003 "JSON Integrity" and "PDF Integrity" ---

def award_canonical(payload):
    """RFC 003 'Hash Computation': JSON.stringify of the award without formats."""
    return stringify({name: item for name, item in payload.items() if name != 'formats'}).encode('utf-8')


def award_hash(payload):
    return digest_text(award_canonical(payload))


def panel_canonical(payload):
    """What AAP's reading has each judge sign: the award without formats or signatures."""
    return stringify({name: item for name, item in payload.items() if name not in ('formats', 'signatures')}).encode('utf-8')


def seal_award(payload, *, judges, service_key, pdf, document_uri):
    """Explicit caller action: complete RFC 003 formats and panel signatures.

    ``payload`` has no ``formats`` or ``signatures``; ``judges`` maps judgeId to
    a caller-held key. Judges sign ``panel_canonical``; the JSON hash then
    covers their signatures; the service signs that hash and the PDF hash.
    """
    need(type(pdf) is bytes and 0 < len(pdf) <= MAX_PDF, 'EXTERNAL_AWARD_PDF_SIZE')
    body = deepcopy(payload)
    need(type(body) is dict and 'formats' not in body and 'signatures' not in body, 'EXTERNAL_AWARD_PANEL')
    need(type(judges) is dict and type(body.get('panel')) is list and
         all(type(row) is dict and row.get('judgeId') in judges for row in body['panel']), 'EXTERNAL_AWARD_PANEL')
    unsigned = panel_canonical(body)
    body['signatures'] = [{'judgeId': judge, 'signature': jws_sign(judges[judge], unsigned)}
                          for judge in [row['judgeId'] for row in body['panel']]]
    json_hash = award_hash(body)
    pdf_hash = digest_text(pdf)
    body['formats'] = {'json': {'contentHash': json_hash, 'signature': jws_sign(service_key, json_hash.encode('ascii'))},
                       'pdf': {'documentUri': document_uri, 'contentHash': pdf_hash,
                               'signature': jws_sign(service_key, pdf_hash.encode('ascii'))}}
    return body


def verify_award(message, *, judges=None, service_keys=(), pdf=None, require_all_judges=True):
    """Check RFC 003 hashes and every JWS against caller-pinned keys.

    Tampering refuses. A signature whose key is not pinned, or that signs
    something RFC 003 does not define, is reported and never counted.
    """
    validate(message, 'ArbitrationAward')
    payload = message['payload']
    judges = {} if judges is None else judges
    need(type(judges) is dict and len(judges) <= 32, 'AGENTIC_ARBITRATION_KEY')
    service_keys = list(service_keys)
    panel = [row['judgeId'] for row in payload['panel']]
    need(len(set(panel)) == len(panel), 'EXTERNAL_AWARD_PANEL')
    json_hash = payload['formats']['json']['contentHash']
    need(award_hash(payload) == json_hash, 'EXTERNAL_AWARD_JSON_HASH')
    pdf_hash = payload['formats']['pdf']['contentHash']
    pdf_status = 'NOT_SUPPLIED'
    if pdf is not None:
        need(type(pdf) is bytes and 0 < len(pdf) <= MAX_PDF, 'EXTERNAL_AWARD_PDF_SIZE')
        need(digest_text(pdf) == pdf_hash, 'EXTERNAL_AWARD_PDF_HASH')
        pdf_status = 'MATCHED'
    everyone = service_keys + [judges[name] for name in sorted(judges)]

    def outer(token, candidates):
        # AAP's reading: the service signs both hashes. With a pinned service key a
        # failure is a refusal; without one, a valid judge signature may still count.
        result, tried = _try(token, everyone, candidates)
        if result is None:
            need(not service_keys, 'EXTERNAL_AWARD_SIGNATURE')
            return {'status': 'UNVERIFIED' if tried else 'NO_PINNED_KEY', 'signer': None, 'binding': None}
        return {'status': 'VERIFIED' if result['binding'] else 'SIGNATURE_VALID_BINDING_UNKNOWN',
                'signer': result['signer'], 'binding': result['binding']}
    json_signature = outer(payload['formats']['json']['signature'],
                           [('CONTENT_HASH', json_hash.encode('ascii')), ('AWARD_JSON', award_canonical(payload))])
    pdf_signature = outer(payload['formats']['pdf']['signature'], [('PDF_HASH', pdf_hash.encode('ascii'))])
    unsigned = panel_canonical(payload)
    verified, unbound, unpinned, seen = [], [], [], set()
    for row in payload['signatures']:
        judge = row['judgeId']
        need(judge in panel and judge not in seen, 'EXTERNAL_AWARD_PANEL'); seen.add(judge)
        if judge not in judges:
            need(not require_all_judges, 'EXTERNAL_AWARD_JUDGE_UNPINNED'); unpinned.append(judge); continue
        try:
            result = jws_open(row['signature'], judges[judge], [('AWARD_UNSIGNED', unsigned)])
        except ValueError as exc:
            if str(exc) in ('AGENTIC_ARBITRATION_JWS_SIGNATURE', 'AGENTIC_ARBITRATION_JWS_CURVE'):
                raise ValueError('EXTERNAL_AWARD_SIGNATURE') from None
            raise
        (verified if result['binding'] else unbound).append(judge)
    missing = [judge for judge in panel if judge not in seen]
    if require_all_judges:
        need(not missing and not unbound, 'EXTERNAL_AWARD_PANEL_SIGNATURES')
    complete = not missing and not unbound and not unpinned
    return {'profile': PROFILE, 'award': payload['awardId'], 'case': payload['caseId'], 'json_hash': json_hash,
            'pdf_hash': pdf_hash, 'pdf': pdf_status, 'json_signature': json_signature, 'pdf_signature': pdf_signature,
            'pdf_embedded_signature': 'PRESENT_NOT_VERIFIED' if 'pdfSignature' in payload['formats']['pdf'] else None,
            'judges_verified': sorted(verified), 'judges_unbound': sorted(unbound), 'judges_unpinned': sorted(unpinned),
            'judges_missing': missing,
            'assurance': 'PANEL_SIGNATURES_VERIFIED' if complete else 'HASHES_VERIFIED_PANEL_INCOMPLETE',
            'message_signature': message_signature(message, everyone),
            'resolution_method': payload['resolutionMethod'], 'decision': deepcopy(payload['decision']),
            'pdf_content_parity': 'NOT_CHECKED; PDF_TEXT_IS_NOT_PARSED',
            'escrow_effect': 'DECIDED_BY_AAP_SIGNED_TERMS_AND_LADDER', **FLAGS}


def describe():
    return {'profile': PROFILE, 'upstream': deepcopy(UPSTREAM), 'decision': 'GRAFT',
            'message_types': sorted(RULES), 'limits': deepcopy(LIMITS),
            'hashes': {'custody': 'RFC 002 Hash Computation: sha256 of ECMAScript JSON.stringify of the listed fields',
                       'award_json': 'RFC 003 Hash Computation: JSON.stringify of the payload without formats',
                       'award_pdf': 'RFC 003 PDF Integrity: sha256 of the whole file'},
            'signatures': 'Compact JWS ES256/ES384 (RFC 7515, RFC 7518 section 3.4) under caller-pinned PEM keys only',
            'adopted_readings': ['Message signature binds JSON.stringify of the message without signature',
                                 'Judges sign the award without formats and signatures; the service signs both hashes',
                                 'Custody signatures bind the RFC 002 bytes or the contentHash string'],
            'not_verified': ['RFC 3161 tokens unless owner-adopted TSAs are passed (covenant_chain.timestamp_tokens)',
                             'blockchain anchors', 'PAdES/PKCS#7 embedded PDF signatures',
                             'PDF/A conformance', 'PDF text parity', 'transport, OAuth and service identity'],
            'remediation': deepcopy(REMEDIATION), **FLAGS}
