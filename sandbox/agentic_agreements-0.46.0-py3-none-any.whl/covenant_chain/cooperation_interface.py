"""Cost-bounded, recoverable cooperation tools above unchanged native semantics."""
from copy import deepcopy
from covenant_language.agentic import object_id
from covenant_language.capsules import capsule_id,compute,validate as validate_capsule
from covenant_language.unit_economics import assess as assess_economics
from .agent_tools import _fields,preview,validate_json
from .crypto import digest,integer,key,need
from .cooperation import _meaning
from .economics import policy_at

VERSION='covenant-cooperation-interface/0.1'
HASH={'type':'string','pattern':'^[0-9a-f]{64}$'}
INT={'type':'integer','minimum':0,'maximum':2**53-1}
TEXT={'type':'string','minLength':1,'maxLength':128}
OBJECT={'type':'object'}


def schema(properties,required=()):
    return {'type':'object','properties':properties,'required':list(required),'additionalProperties':False}


CREATE=schema({'request':{'type':'string','pattern':'^[A-Za-z0-9._:-]{1,96}$'},'template':TEXT,
    'agreement':{'type':['string','object']},'adapter':HASH,'conversation':{'type':'string','maxLength':16384},
    'unit_price':INT,'units':{'type':'integer','minimum':1},'deadline':{'type':'integer','minimum':1},
    'condition':OBJECT,'dependencies':{'type':'array','maxItems':32,'items':OBJECT},'request_hash':HASH},
    ('request','template','agreement','adapter'))

RESUME={'type':'object','oneOf':[
    schema({'task_id':HASH,'action':{'const':'observe'}},('task_id',)),
    schema({'task_id':HASH,'action':{'const':'bind'},'approvals':{'type':'array','maxItems':64,'items':OBJECT}},('task_id','action')),
    schema({'task_id':HASH,'action':{'const':'execute'},'request':{},'output_approval':OBJECT},('task_id','action','request')),
    schema({'task_id':HASH,'action':{'const':'decide'},'outcome':{'enum':['SUPPORTED','REFUTED','INDETERMINATE']},
            'units':INT,'evidence':HASH,'approvals':OBJECT,'appeal':{'type':'boolean'}},('task_id','action','outcome','units','evidence')),
    schema({'task_id':HASH,'action':{'enum':['settle','timeout']}},('task_id','action'))]}


def tool(name,description,inputs,*,readonly=False,idempotent=False):
    return {'name':name,'title':name.replace('_',' ').title(),'description':description,'inputSchema':inputs,
            'outputSchema':{'type':'object'},'annotations':{'readOnlyHint':readonly,'destructiveHint':not readonly,
                'idempotentHint':idempotent,'openWorldHint':False}}


class CooperationInterface:
    def __init__(self,runtime,*,quote_blocks=8,library=None,adoptions=None):
        integer(quote_blocks,True);need(quote_blocks<=1000,'COOPERATION_QUOTE_WINDOW')
        self.runtime=runtime;self.quote_blocks=quote_blocks;self.library=library;self.adoptions=dict(adoptions or {})
        for ref,name in self.adoptions.items():
            key(ref);need(runtime is not None and library is not None and name in runtime.templates,'COOPERATION_ADOPTION')
            library.graph(ref)

    def tools(self):
        out=[]
        preview=tool('preview_cooperation','Preview exact work, its maximum native fee exposure and missing approvals. No signing, reservations or custody writes.',
            schema({'input':CREATE,'fee_limit':INT,'procedure':HASH},('input',)),readonly=True,idempotent=True)
        if self.runtime:
            out=[preview,
                tool('commit_cooperation','Accept one exact preview and request its adopted booking approvals. Repeating the same preview recovers the same task.',
                schema({'preview':OBJECT,'preview_id':HASH,'approvals':{'type':'array','maxItems':64,'items':OBJECT}},('preview','preview_id')),idempotent=True),
                tool('inspect_cooperation','Read one existing task or list unfinished work. Separately reports authority, reservation, effect and settlement; no journal writes.',
                schema({'task_id':HASH}),readonly=True,idempotent=True),
                tool('resume_cooperation','Reconcile an existing task. Observation is the default; a new effect or settlement requires an explicit action and the existing approvals.',
                RESUME)]
        else:
            out=[preview]
        from .reliance_tools import definition
        from .provider_tools import definition as provider_definition
        out += [provider_definition()]
        out += [definition(), tool('covenant_economics','Assess exact integer/basis-point business scenarios. Assertions are never treated as verified revenue, collateral or permission.',schema({'plan':OBJECT},('plan',)),readonly=True,idempotent=True),
                tool('covenant_compute','Inspect a portable language capsule, evaluate the installed bounded exact-expression profile, or export its held Wolfram subset. Never executes arbitrary code.',
                     schema({'capsule':OBJECT,'bindings':OBJECT,'mode':{'type':'string','enum':['inspect','evaluate','wolfram_export']}},('capsule',)),readonly=True,idempotent=True)]
        if self.library:
            out += [tool('covenant_procedures','Search reusable procedures, inspect their dependency closure or export a portable bundle. A match is not adoption or trust.',
                schema({'action':{'type':'string','enum':['search','inspect','export']},'tags':{'type':'array','maxItems':32,'items':TEXT},'id':HASH},('action',)),readonly=True,idempotent=True),
                tool('covenant_publish_procedure','Store a procedure or import a validated bundle in the local library. Never publishes externally or adopts authority.',
                     {'type':'object','oneOf':[schema({'capsule':OBJECT},('capsule',)),schema({'bundle':OBJECT},('bundle',))]},idempotent=True)]
        return out

    def _input(self,value):
        _fields(value,CREATE['required'],set(CREATE['properties'])-set(CREATE['required']))
        need(type(value['agreement']) in (str,dict),'AGENT_AGREEMENT')
        return deepcopy(value)

    def preview(self,input,fee_limit=None,procedure=None):
        r=self.runtime;need(r is not None and r.task_fee_budget is not None,'COOPERATION_COST_POLICY_REQUIRED')
        p=self._input(input)
        if procedure is not None:
            need(procedure in self.adoptions and self.adoptions[procedure]==p['template'],'COOPERATION_PROCEDURE_NOT_ADOPTED')
            _,requirements=self.library.graph(procedure)
            available={'workflow.execute'}|{m['capability'] for m in r.adapters.describe().values()}
            need(set(requirements)<=available,'COOPERATION_PROCEDURE_UNSUPPORTED')
        limit=r.task_fee_budget if fee_limit is None else fee_limit
        integer(limit);need(limit<=r.task_fee_budget,'WORKFLOW_TASK_FEE_LIMIT')
        unsigned=r.preview_task(**p);snap=r.read_snapshot()
        need(unsigned['head']==snap.head,'COOPERATION_PREVIEW_STALE')
        policy=policy_at(snap.state,snap.head['height']+1)
        m=_meaning(unsigned['proposal']);price=m['offer']['unit_price']*m['book']['units'];integer(price)
        cost={'provider_price':{'unit':m['offer']['settlement_resource'],'amount':price},
              'maximum_native_fees':{'unit':policy['body']['resource'],'amount':limit},
              'maximum_per_native_request':r.max_fee,'fee_policy_as_of':policy['id'],
              'review_and_retention':'ONLY_AS_EXPLICITLY_INCLUDED_IN_SIGNED_AGREEMENT',
              'funding':'NOT_RESERVED_BY_PREVIEW','fee_policy_may_change_within_adopted_caps':True}
        quote={'version':VERSION,'input':p,'proposal':unsigned['proposal'],'head':snap.head,
               'expires_height':snap.head['height']+self.quote_blocks,'template_hash':object_id(r.templates[p['template']]),
               'adapter':deepcopy(r.adapters.get(p['adapter']).manifest),'procedure':procedure,
               'fee_limit':limit,'cost':cost}
        return {'version':VERSION,'status':'PREVIEW','preview':quote,'preview_id':digest('COVENANT-COOPERATION-PREVIEW-0.1',quote),
                'terms':preview(unsigned['proposal']),'draft_check':unsigned['draft_check'],
                'next_actions':['Review exact terms and caps, then commit this preview and obtain the returned exact approvals.'],
                'execution_authorized':False,'automatic_assent':False}

    def commit(self,preview,preview_id,approvals=None):
        key(preview_id);need(digest('COVENANT-COOPERATION-PREVIEW-0.1',preview)==preview_id,'COOPERATION_PREVIEW_CHANGED')
        _fields(preview,('version','input','proposal','head','expires_height','template_hash','adapter','procedure','fee_limit','cost'))
        need(preview['version']==VERSION,'COOPERATION_INTERFACE_VERSION')
        r=self.runtime;p=self._input(preview['input'])
        need(p['template'] in r.templates,'WORKFLOW_TEMPLATE_NOT_ADOPTED')
        from .workflow_store import identifier
        tid=identifier('COVENANT-WORKFLOW-TASK-0.1',dict(chain=r.chain,submitter=r.templates[p['template']]['submitter'],request=p['request']))
        prior=r.store.tasks().get(tid)
        if prior is not None:
            need(prior.get('accepted_preview')==preview_id,'COOPERATION_REQUEST_ALREADY_USED')
            need(object_id(prior['proposal'])==object_id(preview['proposal']),'COOPERATION_PREVIEW_CHANGED')
        else:
            current=self.preview(p,preview['fee_limit'],preview['procedure'])['preview']
            # A harmless new block may keep the terms stable. The accepted quote
            # must still match all cost/configuration and policy observations.
            snap=r.read_snapshot();need(snap.head['height']<=preview['expires_height'],'COOPERATION_PREVIEW_EXPIRED')
            for field in ('input','proposal','template_hash','adapter','procedure','fee_limit','cost'):
                need(current[field]==preview[field],'COOPERATION_PREVIEW_STALE')
            from .conditions import Snapshot
            integer(preview['head']['height'])
            need(preview['head']['height']<=snap.head['height'],'COOPERATION_PREVIEW_STALE')
            ancestor=Snapshot(r.genesis,snap.history[:preview['head']['height']],r.chain,preview['head']['height'])
            need(preview['head']==ancestor.head,'COOPERATION_PREVIEW_STALE')
            need(current['expires_height']-self.quote_blocks==snap.head['height'],'COOPERATION_PREVIEW_STALE')
            need(preview['expires_height']==preview['head']['height']+self.quote_blocks,'COOPERATION_PREVIEW_CHANGED')
            r.create(**p,expected_proposal=object_id(preview['proposal']),fee_limit=preview['fee_limit'],accepted_preview=preview_id)
        result=r.bind(tid,approvals)
        return {'version':VERSION,'task':self.inspect(tid),'approval_request':result.get('approval_request'),
                'automatic_assent':False,'execution_authorized':False}

    def inspect(self,task_id=None):
        r=self.runtime
        if task_id is None:
            return {'version':VERSION,'tasks':[{'id':t['id'],'status':t['status']} for t in r.store.tasks().values()],
                    'execution_authorized':False}
        key(task_id);task=r.store.get(task_id);snap=r.read_snapshot();job=snap.state.get('service_jobs',{}).get(task['job']) if task['job'] else None
        m=_meaning(task['proposal']);receipt=None
        if task['effect']:receipt=r.adapters.get(m['terms']['effect']['adapter']).observe(task['effect'])
        assessment=None
        if job is not None:assessment=r._assessment(task,snap,'WORK')
        effect_status='NOT_REQUESTED' if task['effect'] is None else 'OBSERVED' if receipt and receipt['status']=='OBSERVED' else 'OUTCOME_UNKNOWN'
        native=job['state'] if job else 'UNBOOKED'
        next_action='REVIEW_TERMS_AND_BIND' if job is None else 'RECONCILE_EXISTING_EFFECT' if effect_status=='OUTCOME_UNKNOWN' else 'INSPECT_FINAL_EVIDENCE' if native in {'SETTLED','TIMED_OUT'} else 'REQUEST_AUTHORIZED_NEXT_ACTION'
        prefix=task_id+':'
        paid=[];uncertain=[]
        for (request,) in r.journal.db.execute('SELECT id FROM requests ORDER BY id'):
            if not request.startswith(prefix):continue
            row=r.journal.request(request);fee=snap.state.get('fee_receipts',{}).get(row['transaction'])
            if fee:paid.append({'request':request,'transaction':row['transaction'],'resource':fee['resource'],'amount':fee['amount'],'allocations':fee['allocations']})
            elif row['status'] in {'PREPARED','SENT'}:uncertain.append(row['transaction'])
        return {'version':VERSION,'task_id':task_id,'status':task['status'],'certified_as_of':snap.head,'latest_head_known':False,
                'agreement':{'proposal':object_id(task['proposal']),'status':'BOUND' if job else 'PROPOSED'},
                'authority':{'status':'PREREQUISITES_PASS_AT_HEAD' if assessment and assessment['native']['ready_for_stage'] else 'NOT_ESTABLISHED_FOR_NEW_EFFECT',
                             'recheck_before_new_effect':True},
                'reservation':{'status':'CERTIFIED_AT_HEAD' if job and native not in {'SETTLED','TIMED_OUT'} else 'RELEASED_OR_SETTLED' if job else 'ABSENT','job':task['job']},
                'effect':{'status':effect_status,'receipt':receipt},'settlement':{'status':native},
                'assessment':assessment,'economics':{'fee_cap':task.get('fee_limit',r.task_fee_budget),'confirmed_fees':paid,
                    'uncertain_submissions':uncertain,'local_fee_exposure':r.store.budget('taskfees:'+task_id),
                    'provider_price':{'unit':m['offer']['settlement_resource'],'amount':m['offer']['unit_price']*m['book']['units']},
                    'revenue_or_profit':'NOT_INFERRED_FROM_MOVING_COLLATERAL'},
                'next_action':next_action,'automatic_new_task':False,'execution_authorized':False}

    def resume(self,task_id,action='observe',**p):
        key(task_id);r=self.runtime
        if action=='observe':_fields(p,());result=r.reconcile(task_id)
        elif action=='bind':_fields(p,(),('approvals',));result=r.bind(task_id,**p)
        elif action=='execute':_fields(p,('request',),('output_approval',));result=r.execute(task_id,**p)
        elif action=='decide':_fields(p,('outcome','units','evidence'),('approvals','appeal'));result=r.decide(task_id,**p)
        elif action in {'settle','timeout'}:_fields(p,());result=r.finish(task_id,timeout=action=='timeout')
        else:raise ValueError('COOPERATION_ACTION')
        return {'version':VERSION,'result':result,'task':self.inspect(task_id),'execution_authorized':False}

    def call(self,name,arguments):
        validate_json(arguments)
        if name=='covenant_provider':
            from .provider_tools import call
            return call(arguments)
        if name=='covenant_reliance':
            from .reliance_tools import call
            return call(arguments)
        if name=='preview_cooperation':
            _fields(arguments,('input',),('fee_limit','procedure'))
            if self.runtime is None:
                from .surface import not_committed
                return not_committed('COOPERATION_COST_POLICY_REQUIRED')
            return self.preview(**arguments)
        if name=='commit_cooperation':_fields(arguments,('preview','preview_id'),('approvals',));return self.commit(**arguments)
        if name=='inspect_cooperation':_fields(arguments,(),('task_id',));return self.inspect(**arguments)
        if name=='resume_cooperation':_fields(arguments,('task_id',),('action','request','output_approval','approvals','outcome','units','evidence','appeal'));return self.resume(**arguments)
        if name=='covenant_economics':
            _fields(arguments,('plan',))
            if arguments['plan'] == {}:
                from .surface import not_committed
                return not_committed('ECONOMICS_FIELDS')
            return assess_economics(arguments['plan'])
        if name=='covenant_compute':
            _fields(arguments,('capsule',),('bindings','mode'))
            if arguments['capsule'] == {}:
                from .surface import not_committed
                return not_committed('CAPSULE_FIELDS')
            c=arguments['capsule'];raw=validate_capsule(c);mode=arguments.get('mode','inspect')
            if mode=='inspect':return {'id':capsule_id(c),'language':c['language'],'semantics':c['semantics'],'source_bytes':len(raw),'executed':False,'authority':'NONE'}
            need(mode in {'evaluate','wolfram_export'},'COOPERATION_COMPUTE_MODE')
            return compute(c,arguments.get('bindings',{}),wolfram=mode=='wolfram_export')
        if name=='covenant_publish_procedure':
            need(self.library is not None,'LIBRARY_NOT_CONFIGURED');need(('capsule' in arguments)!=('bundle' in arguments),'LIBRARY_ONE_SOURCE')
            if 'capsule' in arguments:_fields(arguments,('capsule',));return self.library.publish(arguments['capsule'])
            _fields(arguments,('bundle',));return self.library.import_bundle(arguments['bundle'])
        need(name=='covenant_procedures' and self.library is not None,'AGENT_UNKNOWN_TOOL')
        _fields(arguments,('action',),('tags','id'));action=arguments['action']
        if action=='search':
            _fields(arguments,('action',),('tags',));capabilities={'workflow.execute'} if self.runtime else set()
            if self.runtime:capabilities.update(m['capability'] for m in self.runtime.adapters.describe().values())
            result=self.library.search(arguments.get('tags',[]),capabilities)
            for entry in result['procedures']:entry['adopted']=entry['id'] in self.adoptions
            return result
        _fields(arguments,('action','id'))
        need(action in {'inspect','export'},'LIBRARY_ACTION')
        result=self.library.export(arguments['id'])
        result['adopted_template']=self.adoptions.get(arguments['id'])
        if action=='export':result.pop('adopted_template')
        return result
