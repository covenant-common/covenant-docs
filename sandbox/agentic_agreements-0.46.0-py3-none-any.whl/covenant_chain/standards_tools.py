"""Pure standards planning tools; installed effect workflow retains authority."""
import base64
from copy import deepcopy
import ipaddress
from urllib.parse import urlsplit
from covenant_language import standards_bindings as s
from .cooperation_interface import HASH, OBJECT, TEXT


def spec():
    source = {"type": "string", "minLength": 2, "maxLength": s.MAX_SOURCE}
    standard = {"type": "string", "enum": list(s.STANDARDS)}
    return ("covenant_standards", "Bind exact selected external-standard source bytes and agreed scope, inspect declarations, export optional A2A references and PROV/Linked Data, or prepare an already owner-installed connector request. No credential/proof verification, remote context fetching, network calls, signing, publication or payment.", True, [
        ("blueprints", {}, ()),
        ("draft", {"standard": standard, "source_json": source, "scope": OBJECT,
                   "selections": {"type": "array", "maxItems": 32, "items": {"type": "string", "maxLength": 512}},
                   "verifier": {"type": ["object", "null"]}, "version": TEXT},
         ("standard", "source_json", "scope")),
        ("inspect", {"binding": OBJECT, "source_json": source, "expected_scope": OBJECT,
                     "expected_id": HASH}, ("binding", "source_json", "expected_scope", "expected_id")),
        ("inspect_source", {"standard": standard, "source_json": source, "version": TEXT}, ("standard", "source_json")),
        ("a2a_extension", {"binding": OBJECT, "agent_card_json": source}, ("binding",)),
        ("inspect_a2a", {"metadata": OBJECT, "expected_id": HASH, "expected_scope": OBJECT,
                         "binding": OBJECT, "source_json": source}, ("metadata", "expected_id", "expected_scope")),
        ("linked_data", {"binding": OBJECT}, ("binding",)),
        ("prepare_connector", {"binding": OBJECT, "adapter": HASH, "request": OBJECT},
         ("binding", "adapter", "request")),
        ("prepare_solid_read", {"binding": OBJECT, "source_json": source, "adapter": HASH,
                                "operation": TEXT, "allow_insecure_loopback": {"type": "boolean"}},
         ("binding", "source_json", "adapter", "operation")),
    ])


def prepare_connector(binding, request, harness):
    """Bind exact metadata to an installed HTTP/MCP request without executing.

    Generic HTTP owner installation must fix the A2A activation/version headers.
    This does not relax the historical extension-free A2AConnector profile.
    Credentials stay in the installed route and are never copied into results.
    """
    from .connector_harness import ConnectorHarness
    s.need(type(harness) is ConnectorHarness, "STANDARDS_GENERIC_OWNER_CONNECTOR_REQUIRED")
    checked = harness.validate_request(request)
    reference = s.a2a_extension(binding)["metadata"]
    if request["protocol"] == "HTTP":
        route = harness.routes[request["operation"]]
        headers = route["headers"]
        s.need(type(headers) is dict and all(type(name) is str for name in headers),
               "STANDARDS_FIXED_OWNER_HEADERS_REQUIRED")
        selected_names = [name.lower() for name in headers
                          if name.lower() in ("a2a-version", "a2a-extensions", "content-type")]
        s.need(len(selected_names) == len(set(selected_names)), "STANDARDS_A2A_DUPLICATE_HEADERS")
        selected = {name.lower(): value for name, value in headers.items()
                    if name.lower() in ("a2a-version", "a2a-extensions", "content-type")}
        s.need(selected == {"a2a-version": "1.0", "a2a-extensions": s.A2A_URI,
                            "content-type": "application/json"},
               "STANDARDS_A2A_ACTIVATION_HEADERS")
        s.need(request["parameters"].get("method") == "POST", "STANDARDS_A2A_POST_REQUIRED")
        raw = request["parameters"].get("body_base64")
        s.need(type(raw) is str, "STANDARDS_A2A_BODY_REQUIRED")
        try:
            body = base64.b64decode(raw, validate=True).decode("utf-8")
        except (ValueError, UnicodeError):
            raise ValueError("STANDARDS_A2A_BODY") from None
        source = s._json(body)
        s._fields(source, "jsonrpc id method params")
        s.need(source["jsonrpc"] == "2.0" and source["method"] == "SendMessage",
               "STANDARDS_A2A_METHOD")
        s._text(source["id"], 1024)
        params = source["params"]
        s.need(type(params) is dict and "message" in params, "STANDARDS_A2A_MESSAGE")
        s.need(params.get("metadata") == reference, "STANDARDS_CONNECTOR_REFERENCE_MISMATCH")
        # The historical message shape checker is pure and does not adopt the
        # new extension, make a request, or change its connector's profile.
        from .a2a_connector import _message
        _message(params["message"], "ROLE_USER")
    elif request["protocol"] == "MCP":
        arguments = request["parameters"]["arguments"]
        s.need(arguments.get(s.A2A_URI) == reference[s.A2A_URI],
               "STANDARDS_CONNECTOR_REFERENCE_MISMATCH")
    else:
        raise ValueError("STANDARDS_CONNECTOR_PROTOCOL_UNSUPPORTED")
    return {"adapter": harness.ref, "request": deepcopy(request),
            "binding_id": s.identifier(binding), "scope_sha256": s.scope_id(binding["scope"]),
            "request_binding": {"kind": "FIXED", "hash": checked["request_hash"]},
            "next": "ADOPT_EXACT_REQUEST_IN_EXISTING_EFFECT_WORKFLOW_WITH_APPROVALS",
            "semantic_equivalence_verified": False, **s.LIMITS}


def prepare_solid_read(binding, source_json, harness, operation, allow_insecure_loopback=False):
    """Prepare one selected resource read; a grant reference is not permission.

    The exact source identifies resource/grant/grantee/modes. Its URI can select
    only an already installed origin and route prefix. Credentials/refresh and
    actual Pod ACL enforcement stay with that owner transport. No grant document
    or remote context is fetched here, and no entitlement is inferred.
    """
    from .connector_harness import ConnectorHarness
    s.need(type(harness) is ConnectorHarness, "STANDARDS_GENERIC_OWNER_CONNECTOR_REQUIRED")
    s.need(type(allow_insecure_loopback) is bool, "STANDARDS_LOOPBACK_OPTION")
    info = s.inspect(binding, source_json)
    s.need(binding["standard"] in ("SOLID", "SOLID_INTEROP"), "STANDARDS_SOLID_BINDING_REQUIRED")
    source = s._json(source_json)
    s.need("Read" in source["modes"], "STANDARDS_SOLID_READ_MODE_REQUIRED")
    s._text(operation, 64)
    s.need(operation in harness.routes, "STANDARDS_SOLID_ROUTE_NOT_INSTALLED")
    try:
        parsed = urlsplit(source["resource"])
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
    except ValueError:
        raise ValueError("STANDARDS_SOLID_RESOURCE_URL") from None
    s.need(parsed.hostname is not None and parsed.username is None and parsed.password is None
           and not parsed.fragment, "STANDARDS_SOLID_RESOURCE_URL")
    if parsed.scheme == "http":
        try:
            loopback = ipaddress.ip_address(parsed.hostname).is_loopback
        except ValueError:
            loopback = False
        s.need(allow_insecure_loopback and loopback, "STANDARDS_SOLID_HTTPS_REQUIRED")
    else:
        s.need(parsed.scheme == "https", "STANDARDS_SOLID_HTTPS_REQUIRED")
    route = harness.routes[operation]
    s.need((parsed.scheme, parsed.hostname.lower(), port) ==
           (route["scheme"], route["host"], route["port"]), "STANDARDS_SOLID_ORIGIN_SCOPE")
    path = (parsed.path or "/") + (("?" + parsed.query) if parsed.query else "")
    request = {"protocol": "HTTP", "operation": operation,
               "parameters": {"path": path, "method": "GET"}}
    checked = harness.validate_request(request)
    return {"adapter": harness.ref, "request": request, "binding_id": info["id"],
            "scope_sha256": info["scope_sha256"],
            "request_binding": {"kind": "FIXED", "hash": checked["request_hash"]},
            "access_grant_verified": False, "pod_authorization_modified": False,
            "transport_security": "TLS" if parsed.scheme == "https" else "EXPLICIT_LOOPBACK_TEST_HTTP",
            "next": "ADOPT_EXACT_READ_IN_EXISTING_EFFECT_WORKFLOW_WITH_APPROVALS_POD_MUST_AUTHORIZE",
            **s.LIMITS}


def call(exchange, action, parameters):
    if action in ("prepare_connector", "prepare_solid_read"):
        s.need(exchange.workflow is not None, "STANDARDS_OWNER_WORKFLOW_REQUIRED")
        values = dict(parameters)
        adapter = values.pop("adapter")
        harness = exchange.workflow.adapters.get(adapter)
        return globals()[action](harness=harness, **values)
    s.need(action in ("blueprints", "draft", "inspect", "inspect_source", "a2a_extension", "inspect_a2a", "linked_data"),
           "STANDARDS_ACTION")
    return getattr(s, action)(**parameters)
