"""Sign in with Covenant: an owner-hosted OpenID Connect provider for did:aap accounts.

A website or app (the relying party) sends the user here with an OAuth 2.0
authorization request. The user proves control of a did:aap account with its
Ed25519 key or with a passkey that the account registered, over the exact
consent shown. The provider then returns an authorization code. The relying
party redeems it with PKCE (S256) for an ID token signed by this host (RS256),
whose ``sub`` is the did:aap identifier, plus a short-lived access token.

RFC 8693 token exchange turns that access token into a GIVE mandate draft, but
only for a ``give:<resource>:<limit>`` scope the user consented to. The draft is
unsigned. It becomes a native GIVE only when the account key signs and submits
it. The provider never holds account keys.

Deployment: loopback by default (``serve``). Owner-hosted only. This repository
ships no public deployment, client registration portal or key rotation service.
Rotation is manual: pass the other key's public half as ``published_keys`` so the
JWKS carries both kids during the overlap (docs/IDENTITY_AND_ACCOUNTS.md).

State: pass ``store`` (an owner directory) to keep pending requests, codes,
access tokens and passkey registrations across restarts
(covenant-identity-store/0.1). Without it they are in memory only, and a
restart forgets which codes were used.

What an ID token from here proves to a relying party that pins this issuer:
the account key (or a passkey the account key registered) approved this exact
client, redirect URI, scope, nonce and PKCE challenge at ``auth_time``. It does
not prove a legal identity, personhood, that the account holds any balance, or
that a GIVE was ever submitted.

References: OpenID Connect Core 1.0 and Discovery 1.0; RFC 6749; RFC 7636 (PKCE);
RFC 8693 (token exchange); RFC 8176 (amr values); W3C WebAuthn Level 3.
"""
from copy import deepcopy
import base64
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import threading
from functools import wraps
from urllib.parse import parse_qs, unquote_plus, urlencode, urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa

from .crypto import canonical, digest, integer, key, need, verification_key, verify
from .scale.identity import did, resolve_did
from .json_bounds import validate_json

VERSION = 'covenant-signin-oidc/0.1'
CONSENT_LABEL = 'COVENANT-SIGNIN-CONSENT-0.1'
PASSKEY_LABEL = 'COVENANT-SIGNIN-PASSKEY-0.1'
EXCHANGE_GRANT = 'urn:ietf:params:oauth:grant-type:token-exchange'
CODE_GRANT = 'authorization_code'
ACCESS_TOKEN_TYPE = 'urn:ietf:params:oauth:token-type:access_token'
GIVE_TOKEN_TYPE = 'urn:aap:params:oauth:token-type:give-mandate-draft'
CODE_TTL = 60
REQUEST_TTL = 300
ID_TOKEN_TTL = 300
ACCESS_TOKEN_TTL = 600
MAX_PENDING = 1024
MAX_CODES = 1024
MAX_ACCESS = 1024
STORE_KIND = 'covenant-signin-oidc-state/0.1'
PROMPTS = ('none', 'login', 'consent', 'select_account')
VERIFIER = re.compile(r'[A-Za-z0-9._~-]{43,128}\Z')
B64URL = re.compile(r'[A-Za-z0-9_-]+\Z')
GIVE_SCOPE = re.compile(r'give:([A-Za-z0-9._-]{1,80}):([1-9][0-9]{0,15})\Z')
SCOPE_TOKEN = re.compile(r'[\x21\x23-\x5b\x5d-\x7e]{1,128}\Z')
EFFECTS = ('AUTHORIZE', 'CONSUME', 'TRANSFER')

PROVES = ['the did:aap account key, or a passkey that key registered, approved this exact client, redirect, scope, nonce and PKCE challenge',
          'the ID token was signed by this owner-hosted issuer key',
          'a give scope in the exchange result is one the account consented to, with the exact resource, limit, holder and expiry']
DOES_NOT_PROVE = ['legal identity, personhood or KYB; use identity evidence or hidden credentials for those',
                  'that the account holds any balance or that a GIVE was submitted; the exchange returns an unsigned draft',
                  'anything to a relying party that does not pin this issuer and its JWKS',
                  'freshness of passkey hardware: authenticator sign counters and attestation are not checked']


class OIDCError(ValueError):
    """An OAuth/OIDC protocol error with its registered ``error`` code.

    ``redirect`` is set once the client's redirect URI is trusted: the HTTP layer
    then sends the error to the client as query parameters (RFC 6749 4.1.2.1).
    """

    def __init__(self, error, description, status=400, *, redirect=None, headers=None):
        super().__init__(error)
        self.error = error
        self.description = description
        self.status = status
        self.redirect = redirect
        self.headers = dict(headers or {})

    def body(self):
        return {'error': self.error, 'error_description': self.description}


def _fail(ok, error, description, status=400):
    if not ok:
        raise OIDCError(error, description, status)


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _unb64(text, maximum=8192):
    need(type(text) is str and 0 < len(text) <= maximum and bool(B64URL.fullmatch(text)), 'SIGNIN_ENCODING')
    try:
        return base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    except (ValueError, TypeError):
        raise ValueError('SIGNIN_ENCODING') from None


def _wire(value):
    validate_json(value)
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def _read_json(raw):
    def pairs(items):
        result = {}
        for name, value in items:
            need(name not in result, 'SIGNIN_DUPLICATE_JSON_KEY')
            result[name] = value
        return result
    def number(_):
        raise ValueError('SIGNIN_JSON_NUMBER')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                           parse_float=number, parse_constant=number)
        validate_json(value)
        return value
    except (UnicodeError, ValueError, RecursionError):
        raise ValueError('SIGNIN_JSON') from None


def _serialized(method):
    @wraps(method)
    def invoke(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return invoke


def _text(value, maximum=512):
    return type(value) is str and 0 < len(value) <= maximum and value.isascii() and value.isprintable()


def pkce_challenge(verifier):
    """RFC 7636 S256: BASE64URL(SHA256(ASCII(code_verifier)))."""
    need(type(verifier) is str and bool(VERIFIER.fullmatch(verifier)), 'SIGNIN_PKCE_VERIFIER')
    return _b64(hashlib.sha256(verifier.encode('ascii')).digest())


def _issuer(value):
    need(_text(value, 256), 'SIGNIN_ISSUER')
    parts = urlsplit(value)
    need(parts.scheme in {'https', 'http'} and parts.hostname and not parts.query and not parts.fragment
         and not parts.username and not value.endswith('/'), 'SIGNIN_ISSUER')
    if parts.scheme == 'http':
        need(_loopback(parts.hostname), 'SIGNIN_ISSUER_HTTP_LOOPBACK_ONLY')
    return value


def _loopback(host):
    if host == 'localhost':
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _with_query(uri, query):
    return uri + ('&' if urlsplit(uri).query else '?') + urlencode(query)


def _redirect(value):
    need(_text(value, 512), 'SIGNIN_REDIRECT_URI')
    parts = urlsplit(value)
    need(parts.scheme in {'https', 'http'} and parts.hostname and not parts.fragment and not parts.username,
         'SIGNIN_REDIRECT_URI')
    if parts.scheme == 'http':
        need(_loopback(parts.hostname), 'SIGNIN_REDIRECT_URI')
    return value


def register_client(client_id, *, redirect_uris, scopes, agent=None, give=None, secret_sha256=None):
    """One relying party, registered by the owner.

    ``give`` = {'resource': max_limit} caps the GIVE scopes this client may ask for,
    with ``agent`` the key that would hold the grant, plus 'expiry_blocks',
    'effects' and 'profiles' fixed by the owner. A public client (no secret) must use
    PKCE. Every client must use PKCE S256.
    """
    need(_text(client_id, 128) and ' ' not in client_id, 'SIGNIN_CLIENT_ID')
    need(type(redirect_uris) is list and 1 <= len(redirect_uris) <= 8 and len(set(redirect_uris)) == len(redirect_uris),
         'SIGNIN_REDIRECT_URI')
    for uri in redirect_uris:
        _redirect(uri)
    need(type(scopes) is list and 'openid' in scopes and len(scopes) <= 16
         and all(type(s) is str and SCOPE_TOKEN.fullmatch(s) and not s.startswith('give:') for s in scopes),
         'SIGNIN_CLIENT_SCOPES')
    if secret_sha256 is not None:
        key(secret_sha256)
    mandate = None
    if give is not None:
        need(agent is not None, 'SIGNIN_GIVE_HOLDER')
        verification_key(agent)
        need(type(give) is dict and set(give) == {'limits', 'expiry_blocks', 'effects', 'profiles'}, 'SIGNIN_GIVE_POLICY')
        need(type(give['limits']) is dict and 1 <= len(give['limits']) <= 8, 'SIGNIN_GIVE_POLICY')
        for resource, limit in give['limits'].items():
            need(type(resource) is str and GIVE_SCOPE.fullmatch('give:' + resource + ':1'), 'SIGNIN_GIVE_POLICY')
            integer(limit, True)
        integer(give['expiry_blocks'], True)
        need(give['expiry_blocks'] <= 100000, 'SIGNIN_GIVE_POLICY')
        for field in ('effects', 'profiles'):
            value = give[field]
            need(type(value) is list and value and value == sorted(set(value)), 'SIGNIN_GIVE_POLICY')
        need(set(give['effects']) <= set(EFFECTS), 'SIGNIN_GIVE_POLICY')
        need(all(type(p) is str and 0 < len(p) <= 80 for p in give['profiles']), 'SIGNIN_GIVE_POLICY')
        mandate = deepcopy(give)
    else:
        need(agent is None, 'SIGNIN_GIVE_HOLDER')
    return {'client_id': client_id, 'redirect_uris': list(redirect_uris), 'scopes': sorted(set(scopes)),
            'agent': agent, 'give': mandate, 'secret_sha256': secret_sha256}


def passkey_registration(account, chain, credential_id, public_key, rp_id):
    """The body an account key signs to register one passkey for sign-in."""
    key(account)
    key(chain)
    need(_text(credential_id, 256) and B64URL.fullmatch(credential_id), 'SIGNIN_PASSKEY_CREDENTIAL')
    need(type(public_key) is str and len(public_key) == 130 and public_key.startswith('04')
         and all(c in '0123456789abcdef' for c in public_key), 'SIGNIN_PASSKEY_KEY')
    try:
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), bytes.fromhex(public_key))
    except ValueError:
        raise ValueError('SIGNIN_PASSKEY_KEY') from None
    need(_text(rp_id, 253), 'SIGNIN_RP_ID')
    return {'version': VERSION, 'account': account, 'chain': chain, 'credential_id': credential_id,
            'public_key': public_key, 'rp_id': rp_id}


def passkey_challenge(consent):
    """The WebAuthn challenge for a consent: SHA-256 of its canonical bytes, base64url."""
    return _b64(hashlib.sha256(canonical(consent)).digest())


def verify_passkey_assertion(consent, assertion, registration, *, origin, require_user_verification=False):
    """WebAuthn get() assertion over the exact consent. Checks type, challenge, origin, rpIdHash, UP and signature."""
    need(type(assertion) is dict and set(assertion) == {'credential_id', 'client_data_json', 'authenticator_data',
                                                         'signature'}, 'SIGNIN_PASSKEY_FIELDS')
    need(assertion['credential_id'] == registration['credential_id'], 'SIGNIN_PASSKEY_CREDENTIAL')
    client_bytes = _unb64(assertion['client_data_json'], 4096)
    auth_data = _unb64(assertion['authenticator_data'], 4096)
    signature = _unb64(assertion['signature'], 256)
    need(len(auth_data) >= 37, 'SIGNIN_PASSKEY_AUTH_DATA')
    need(hmac.compare_digest(auth_data[:32], hashlib.sha256(registration['rp_id'].encode('ascii')).digest()),
         'SIGNIN_PASSKEY_RP_ID')
    need(auth_data[32] & 0x01, 'SIGNIN_PASSKEY_USER_PRESENT')
    if require_user_verification:
        need(auth_data[32] & 0x04, 'SIGNIN_PASSKEY_USER_VERIFIED')
    try:
        client = _read_json(client_bytes)
    except (UnicodeError, ValueError):
        raise ValueError('SIGNIN_PASSKEY_CLIENT_DATA') from None
    need(type(client) is dict and client.get('type') == 'webauthn.get', 'SIGNIN_PASSKEY_TYPE')
    need(client.get('challenge') == passkey_challenge(consent), 'SIGNIN_PASSKEY_CHALLENGE')
    need(client.get('origin') == origin and ('crossOrigin' not in client or client['crossOrigin'] is False),
         'SIGNIN_PASSKEY_ORIGIN')
    public = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), bytes.fromhex(registration['public_key']))
    try:
        public.verify(signature, auth_data + hashlib.sha256(client_bytes).digest(), ec.ECDSA(hashes.SHA256()))
    except InvalidSignature:
        raise ValueError('SIGNIN_PASSKEY_SIGNATURE') from None
    return {'user_verified': bool(auth_data[32] & 0x04)}


def give_payload(consent, scope):
    """Map one consented give scope to the exact native GIVE payload. Unsigned; not authority."""
    match = GIVE_SCOPE.fullmatch(scope)
    need(match is not None, 'SIGNIN_GIVE_SCOPE')
    grant = next((row for row in consent['give'] if row['scope'] == scope), None)
    need(grant is not None, 'SIGNIN_GIVE_NOT_CONSENTED')
    return {'parent': None, 'holder': grant['holder'], 'resource': grant['resource'], 'limit': grant['limit'],
            'expiry': grant['expiry'], 'effects': list(grant['effects']), 'profiles': list(grant['profiles']),
            'delegate': False}


def _rsa_jwk(public):
    numbers = public.public_numbers()
    jwk = {'kty': 'RSA', 'use': 'sig', 'alg': 'RS256',
           'n': _b64(numbers.n.to_bytes((numbers.n.bit_length() + 7) // 8, 'big')),
           'e': _b64(numbers.e.to_bytes((numbers.e.bit_length() + 7) // 8, 'big'))}
    jwk['kid'] = _b64(hashlib.sha256(_wire(jwk)).digest())[:16]
    return jwk


def _basic(header):
    """RFC 6749 2.3.1: client_id and secret, each form-urlencoded, in HTTP Basic."""
    scheme, _, value = header.partition(' ')
    _fail(scheme.lower() == 'basic' and value, 'invalid_client', 'Use HTTP Basic client authentication.', 401)
    try:
        raw = base64.b64decode(value.strip(), validate=True).decode('ascii')
    except (ValueError, UnicodeError):
        raise OIDCError('invalid_client', 'Malformed Basic credentials.', 401) from None
    name, colon, secret = raw.partition(':')
    _fail(colon == ':', 'invalid_client', 'Malformed Basic credentials.', 401)
    return unquote_plus(name), unquote_plus(secret)


class SignInProvider:
    """OIDC provider state. ``handle`` is the HTTP-shaped entry point.

    ``signing_key`` is an RSA private key the owner keeps (RS256 is the algorithm
    every OIDC relying party must support). ``published_keys`` are RSA public keys
    that the JWKS also lists, for a key rotation overlap; they never sign.
    ``clock`` returns Unix seconds and ``height`` returns the current chain height
    used to fix GIVE expiry. ``store`` is an owner directory for durable state.
    ``userinfo=True`` serves a UserInfo endpoint that returns only ``sub``.
    """

    def __init__(self, issuer, chain, signing_key, *, clients, clock, height, kid=None, origin=None,
                 published_keys=(), store=None, userinfo=False):
        self._lock = threading.RLock()
        self.issuer = _issuer(issuer)
        key(chain)
        need(isinstance(signing_key, rsa.RSAPrivateKey) and signing_key.key_size >= 2048, 'SIGNIN_SIGNING_KEY')
        need(callable(clock) and callable(height), 'SIGNIN_CLOCK')
        need(type(clients) is list and 1 <= len(clients) <= 64, 'SIGNIN_CLIENTS')
        need(type(userinfo) is bool, 'SIGNIN_USERINFO')
        self.chain = chain
        self._key = signing_key
        self._jwk = _rsa_jwk(signing_key.public_key())
        if kid is not None:
            self._jwk['kid'] = kid
        self.kid = self._jwk['kid']
        need(type(published_keys) in (list, tuple) and len(published_keys) <= 3, 'SIGNIN_PUBLISHED_KEYS')
        self._published = []
        for public in published_keys:
            need(isinstance(public, rsa.RSAPublicKey) and public.key_size >= 2048, 'SIGNIN_PUBLISHED_KEYS')
            jwk = _rsa_jwk(public)
            need(jwk['n'] != self._jwk['n'] and jwk['kid'] not in {self.kid, *(k['kid'] for k in self._published)},
                 'SIGNIN_PUBLISHED_KEYS')
            self._published.append(jwk)
        self.clients = {}
        for row in clients:
            checked = register_client(row['client_id'], redirect_uris=row['redirect_uris'], scopes=row['scopes'],
                                      agent=row.get('agent'), give=row.get('give'),
                                      secret_sha256=row.get('secret_sha256'))
            need(checked['client_id'] not in self.clients, 'SIGNIN_CLIENT_DUPLICATE')
            self.clients[checked['client_id']] = checked
        self._clock = clock
        self._height = height
        self.origin = origin or self.issuer
        self.userinfo_enabled = userinfo
        self._lock = threading.RLock()
        self.passkeys = {}
        self._pending = {}
        self._codes = {}
        self._used_codes = {}
        self._access = {}
        self._store = None
        if store is not None:
            from .identity_store import StateFile
            self._store = StateFile(store, 'signin', kind=STORE_KIND, context={'issuer': self.issuer, 'chain': chain})
            try:
                self._restore(self._store.load())
            except BaseException:
                self._store.close()
                raise

    def __repr__(self):
        return f'SignInProvider({self.issuer!r}, clients={sorted(self.clients)!r})'

    def close(self):
        """Release the state directory lock. The provider must not be used afterwards."""
        if self._store is not None:
            self._store.close()

    def _now(self):
        now = self._clock()
        integer(now)
        return now

    # --- durable state ---------------------------------------------------

    def _restore(self, state):
        if state is None:
            return
        need(set(state) == {'passkeys', 'pending', 'codes', 'used_codes', 'access'}, 'SIGNIN_STORE_STATE')
        for name in state:
            need(type(state[name]) is dict, 'SIGNIN_STORE_STATE')
        for credential, registration in state['passkeys'].items():
            need(registration == passkey_registration(registration['account'], registration['chain'],
                                                      registration['credential_id'], registration['public_key'],
                                                      registration['rp_id'])
                 and credential == registration['credential_id'] and registration['chain'] == self.chain,
                 'SIGNIN_STORE_STATE')
        for table in ('pending', 'codes', 'used_codes', 'access'):
            need(all(re.fullmatch('[0-9a-f]{64}', ref) for ref in state[table]), 'SIGNIN_STORE_STATE')
        self.passkeys = state['passkeys']
        self._pending = state['pending']
        self._codes = state['codes']
        self._used_codes = state['used_codes']
        self._access = state['access']
        self._expire(self._now())

    def _save(self):
        if self._store is None:
            return
        try:
            self._store.save({'passkeys': self.passkeys, 'pending': self._pending, 'codes': self._codes,
                              'used_codes': self._used_codes, 'access': self._access})
        except OSError:
            raise OIDCError('server_error', 'The provider could not record its state.', 500) from None

    # --- metadata --------------------------------------------------------

    def discovery(self):
        """OpenID Provider Metadata (Discovery 1.0 section 3)."""
        scopes = sorted({s for c in self.clients.values() for s in c['scopes']} | {'openid'})
        out = {'issuer': self.issuer, 'authorization_endpoint': self.issuer + '/oidc/authorize',
               'token_endpoint': self.issuer + '/oidc/token', 'jwks_uri': self.issuer + '/oidc/jwks',
               'response_types_supported': ['code'], 'response_modes_supported': ['query'],
               'grant_types_supported': [CODE_GRANT, EXCHANGE_GRANT], 'subject_types_supported': ['public'],
               'id_token_signing_alg_values_supported': ['RS256'], 'scopes_supported': scopes,
               'token_endpoint_auth_methods_supported': ['none', 'client_secret_basic', 'client_secret_post'],
               'code_challenge_methods_supported': ['S256'],
               'claims_supported': ['iss', 'sub', 'aud', 'exp', 'iat', 'auth_time', 'nonce', 'amr', 'acr'],
               'prompt_values_supported': list(PROMPTS),
               'authorization_response_iss_parameter_supported': True,
               'request_parameter_supported': False, 'request_uri_parameter_supported': False,
               'aap_subject_format': 'did:aap:<chain>:<account>', 'aap_version': VERSION,
               'aap_give_token_type': GIVE_TOKEN_TYPE}
        if self.userinfo_enabled:
            out['userinfo_endpoint'] = self.issuer + '/oidc/userinfo'
        return out

    def jwks(self):
        """The signing key first, then any keys published for a rotation overlap."""
        return {'keys': [deepcopy(self._jwk)] + deepcopy(self._published)}

    # --- passkeys --------------------------------------------------------

    @_serialized
    def register_passkey(self, registration, signature):
        """The account key signs a passkey registration. Later logins may use that passkey."""
        need(type(registration) is dict, 'SIGNIN_PASSKEY_FIELDS')
        checked = passkey_registration(registration.get('account', ''), registration.get('chain', ''),
                                       registration.get('credential_id', ''), registration.get('public_key', ''),
                                       registration.get('rp_id', ''))
        need(checked == registration and registration['chain'] == self.chain, 'SIGNIN_PASSKEY_FIELDS')
        verify(registration['account'], PASSKEY_LABEL, registration, signature)
        with self._lock:
            need(registration['credential_id'] not in self.passkeys, 'SIGNIN_PASSKEY_DUPLICATE')
            need(len(self.passkeys) < 4096, 'SIGNIN_PASSKEY_LIMIT')
            self.passkeys[registration['credential_id']] = deepcopy(registration)
            try:
                self._save()
            except OIDCError:
                del self.passkeys[registration['credential_id']]
                raise
        return {'registered': True, 'credential_id': registration['credential_id'],
                'subject': did(registration['account'], self.chain), 'execution_authorized': False}

    # --- authorization endpoint -----------------------------------------

    @_serialized
    def authorize(self, params):
        """Validate an authorization request and return the consent the user must sign.

        Errors before the client and redirect URI are trusted go to the user agent
        and are never redirected. Later errors carry ``redirect``: the client's
        redirect URI with ``error``, ``error_description``, ``state`` and ``iss``.
        """
        _fail(type(params) is dict and all(type(v) is str for v in params.values()), 'invalid_request',
              'Parameters must be single strings.')
        client = self.clients.get(params.get('client_id'))
        _fail(client is not None, 'unauthorized_client', 'Unknown client_id.')
        redirect = params.get('redirect_uri')
        _fail(redirect in client['redirect_uris'], 'invalid_request', 'redirect_uri is not registered for this client.')
        state = params.get('state')
        try:
            return self._authorize(params, client, redirect, state)
        except OIDCError as exc:
            if exc.redirect is None:
                exc.redirect = self._error_redirect(redirect, state, exc.error, exc.description)
            raise

    def _error_redirect(self, redirect, state, error, description):
        query = {'error': error, 'error_description': description[:200], 'iss': self.issuer}
        if state is not None and _text(state, 512):
            query['state'] = state
        return _with_query(redirect, query)

    def _authorize(self, params, client, redirect, state):
        # RFC 6749 3.1: unrecognised parameters are ignored. They never reach the consent.
        _fail('request' not in params, 'request_not_supported', 'Request objects are not supported.')
        _fail('request_uri' not in params, 'request_uri_not_supported', 'request_uri is not supported.')
        _fail('registration' not in params, 'registration_not_supported', 'Dynamic registration is not supported.')
        _fail(params.get('response_mode', 'query') == 'query', 'invalid_request', 'Only response_mode=query.')
        _fail(state is None or _text(state, 512), 'invalid_request', 'state must be printable ASCII.')
        _fail(params.get('response_type') == 'code', 'unsupported_response_type', 'Only response_type=code.')
        _fail(params.get('code_challenge_method') == 'S256', 'invalid_request', 'PKCE S256 is required.')
        challenge = params.get('code_challenge', '')
        _fail(len(challenge) == 43 and B64URL.fullmatch(challenge) is not None, 'invalid_request',
              'code_challenge must be a base64url SHA-256.')
        nonce = params.get('nonce', '')
        _fail(_text(nonce, 256) and len(nonce) >= 16, 'invalid_request', 'A nonce of at least 16 characters is required.')
        prompt = params.get('prompt', 'consent').split(' ')
        _fail(set(prompt) <= set(PROMPTS) and len(prompt) == len(set(prompt)) and ('none' not in prompt or prompt == ['none']),
              'invalid_request', 'prompt must be none alone, or login, consent and select_account.')
        # Every login here needs the account key or a passkey over this exact consent.
        _fail(prompt != ['none'], 'login_required', 'This provider always needs the account to approve.')
        scopes = (params.get('scope') or '').split(' ')
        _fail(len(scopes) == len(set(scopes)) and 'openid' in scopes and len(scopes) <= 16, 'invalid_scope',
              'scope must include openid, without repeats.')
        give = []
        for scope in scopes:
            match = GIVE_SCOPE.fullmatch(scope)
            if match is None:
                _fail(scope in client['scopes'], 'invalid_scope', 'Scope not registered for this client: ' + scope[:64])
                continue
            policy = client['give']
            _fail(policy is not None, 'invalid_scope', 'This client may not request a GIVE mandate.')
            resource, limit = match.group(1), int(match.group(2))
            _fail(resource in policy['limits'] and limit <= policy['limits'][resource], 'invalid_scope',
                  'GIVE scope exceeds the owner-registered limit.')
            _fail(all(row['resource'] != resource for row in give), 'invalid_scope', 'One GIVE scope per resource.')
            give.append({'scope': scope, 'holder': client['agent'], 'resource': resource, 'limit': limit,
                         'expiry': self._height() + policy['expiry_blocks'], 'effects': list(policy['effects']),
                         'profiles': list(policy['profiles'])})
        now = self._now()
        request_id = secrets.token_hex(32)
        consent = {'version': VERSION, 'issuer': self.issuer, 'chain': self.chain, 'request': request_id,
                   'client_id': client['client_id'], 'redirect_uri': redirect, 'scope': ' '.join(scopes),
                   'nonce': nonce, 'code_challenge': challenge, 'give': give, 'expires': now + REQUEST_TTL}
        with self._lock:
            self._expire(now)
            _fail(len(self._pending) < MAX_PENDING, 'temporarily_unavailable', 'Too many pending requests.', 503)
            self._pending[request_id] = {'consent': consent, 'state': state}
            try:
                self._save()
            except OIDCError:
                del self._pending[request_id]
                raise
        return {'request': request_id, 'consent': deepcopy(consent), 'passkey_challenge': passkey_challenge(consent),
                'sign_label': CONSENT_LABEL, 'execution_authorized': False}

    @_serialized
    def approve(self, request_id, *, account, method, proof):
        """The user approves with the account key (``method='key'``) or a registered passkey.

        A refused proof is answered to the user agent, not redirected, so the user
        can retry until the request expires. ``deny`` ends the request instead.
        """
        with self._lock:
            now = self._now()
            self._expire(now)
            _fail(type(request_id) is str and request_id in self._pending, 'invalid_request',
                  'Unknown or expired request.')
            pending = self._pending[request_id]
            consent = pending['consent']
            _fail(type(account) is str and re.fullmatch('[0-9a-f]{64}', account) is not None, 'invalid_request',
                  'account must be a 64-hex key.')
            if method == 'key':
                _fail(type(proof) is str and re.fullmatch('[0-9a-f]{128}', proof) is not None, 'invalid_request',
                      'proof must be a 128-hex Ed25519 signature.')
                try:
                    verify(account, CONSENT_LABEL, consent, proof)
                except ValueError:
                    raise OIDCError('access_denied', 'The account signature does not cover this consent.', 403) from None
                amr = ['pop']
            elif method == 'passkey':
                _fail(type(proof) is dict, 'invalid_request', 'A passkey assertion object is required.')
                _fail(type(proof.get('credential_id')) is str, 'invalid_request', 'Passkey credential id must be text.')
                registration = self.passkeys.get(proof.get('credential_id'))
                _fail(registration is not None and registration['account'] == account, 'access_denied',
                      'The passkey is not registered to this account.', 403)
                try:
                    checked = verify_passkey_assertion(consent, proof, registration, origin=self.origin)
                except ValueError as exc:
                    raise OIDCError('access_denied', 'Passkey assertion refused: ' + str(exc), 403) from None
                amr = ['urn:aap:amr:passkey-signature', 'user'] + (['urn:aap:amr:user-verification-flag'] if checked['user_verified'] else [])
            else:
                raise OIDCError('invalid_request', 'method must be key or passkey.')
            if len(self._codes) >= MAX_CODES:
                raise OIDCError('temporarily_unavailable', 'Too many unredeemed codes.', 503,
                                redirect=self._error_redirect(consent['redirect_uri'], pending['state'],
                                                              'temporarily_unavailable', 'Too many unredeemed codes.'))
            code = secrets.token_urlsafe(32)
            hashed = hashlib.sha256(code.encode('ascii')).hexdigest()
            del self._pending[request_id]
            self._codes[hashed] = {'consent': consent, 'account': account, 'auth_time': now, 'amr': amr,
                                   'expires': now + CODE_TTL}
            try:
                self._save()
            except OIDCError:
                del self._codes[hashed]
                self._pending[request_id] = pending
                raise
        query = {'code': code, 'iss': self.issuer}
        if pending['state'] is not None:
            query['state'] = pending['state']
        return {'redirect': _with_query(consent['redirect_uri'], query), 'execution_authorized': False}

    def deny(self, request_id):
        """The user declines. The request ends and the client gets ``error=access_denied``."""
        with self._lock:
            self._expire(self._now())
            _fail(type(request_id) is str and request_id in self._pending, 'invalid_request',
                  'Unknown or expired request.')
            pending = self._pending.pop(request_id)
            try:
                self._save()
            except OIDCError:
                self._pending[request_id] = pending
                raise
        consent = pending['consent']
        return {'redirect': self._error_redirect(consent['redirect_uri'], pending['state'], 'access_denied',
                                                 'The user declined.'),
                'error': 'access_denied', 'execution_authorized': False}

    # --- token endpoint --------------------------------------------------

    @_serialized
    def token(self, form, *, authorization=''):
        """Token endpoint; authentication is separate from caller-controlled form data."""
        _fail(type(form) is dict and all(type(v) is str for v in form.values()), 'invalid_request',
              'Form fields must be single strings.')
        self._expire(self._now())
        grant = form.get('grant_type')
        client = self._client_auth(form, authorization)
        with self._lock:
            if grant == CODE_GRANT:
                return self._code(form, client)
            if grant == EXCHANGE_GRANT:
                return self._exchange(form, client)
        raise OIDCError('unsupported_grant_type', 'Use authorization_code or token-exchange.')

    def _client_auth(self, form, authorization=''):
        _fail(type(authorization) is str, 'invalid_request', 'Authorization must be a string.')
        challenge = {'WWW-Authenticate': 'Basic realm="' + self.issuer + '"'}
        if authorization:
            try:
                client_id, secret = _basic(authorization)
            except OIDCError as exc:
                exc.headers.update(challenge)
                raise
            _fail('client_secret' not in form and form.get('client_id', client_id) == client_id, 'invalid_request',
                  'Use one client authentication method.')
        else:
            client_id, secret = form.get('client_id'), form.get('client_secret')
        client = self.clients.get(client_id)
        if client is None or (client['secret_sha256'] is None) != (secret is None):
            headers = challenge if authorization else {}
            if client is None:
                raise OIDCError('invalid_client', 'Unknown client.', 401, headers=headers)
            raise OIDCError('invalid_client', 'Public clients send no secret.' if client['secret_sha256'] is None
                            else 'Client authentication failed.', 401, headers=headers)
        if client['secret_sha256'] is not None:
            ok = hmac.compare_digest(hashlib.sha256(secret.encode('utf-8')).hexdigest(), client['secret_sha256'])
            if not ok:
                raise OIDCError('invalid_client', 'Client authentication failed.', 401,
                                headers=challenge if authorization else {})
        return client

    def _code(self, form, client):
        _fail(set(form) <= {'grant_type', 'code', 'redirect_uri', 'client_id', 'client_secret', 'code_verifier'},
              'invalid_request', 'Unsupported parameter.')
        now = self._now()
        self._expire(now)
        code = form.get('code', '')
        hashed = hashlib.sha256(code.encode('utf-8')).hexdigest()
        if hashed in self._used_codes:
            # RFC 6749 section 4.1.2: a reused code revokes what it issued.
            for token in self._used_codes[hashed]['tokens']:
                self._access.pop(token, None)
            self._save()
            raise OIDCError('invalid_grant', 'Authorization code already used; its tokens are revoked.')
        row = self._codes.get(hashed)
        _fail(row is not None and now < row['expires'], 'invalid_grant', 'Unknown or expired code.')
        consent = row['consent']
        _fail(consent['client_id'] == client['client_id'], 'invalid_grant', 'Code was issued to another client.')
        _fail(form.get('redirect_uri') == consent['redirect_uri'], 'invalid_grant', 'redirect_uri does not match.')
        try:
            challenge = pkce_challenge(form.get('code_verifier', ''))
        except ValueError:
            raise OIDCError('invalid_grant', 'code_verifier is malformed.') from None
        _fail(hmac.compare_digest(challenge, consent['code_challenge']), 'invalid_grant', 'PKCE verification failed.')
        _fail(len(self._access) < MAX_ACCESS, 'temporarily_unavailable', 'Too many live access tokens.', 503)
        subject = did(row['account'], self.chain)
        claims = {'iss': self.issuer, 'sub': subject, 'aud': client['client_id'], 'iat': now,
                  'exp': now + ID_TOKEN_TTL, 'auth_time': row['auth_time'], 'nonce': consent['nonce'],
                  'amr': row['amr'], 'acr': 'urn:aap:acr:' + (
                      'passkey-signature' if 'urn:aap:amr:passkey-signature' in row['amr'] else 'account-key')}
        id_token = self._sign({'alg': 'RS256', 'kid': self.kid, 'typ': 'JWT'}, claims)
        access = secrets.token_urlsafe(32)
        access_hash = hashlib.sha256(access.encode('ascii')).hexdigest()
        # A code is spent once its use is on disk; until then nothing is returned.
        del self._codes[hashed]
        self._access[access_hash] = {'account': row['account'], 'client_id': client['client_id'], 'consent': consent,
                                     'expires': now + ACCESS_TOKEN_TTL}
        self._used_codes[hashed] = {'tokens': [access_hash], 'expires': now + ACCESS_TOKEN_TTL}
        try:
            self._save()
        except OIDCError:
            self._codes[hashed] = row
            del self._access[access_hash], self._used_codes[hashed]
            raise
        # readiness: issued-to-holder RFC6749 token response goes only to the authenticated PKCE client; persistent records retain hashes.
        return {'access_token': access, 'token_type': 'Bearer', 'expires_in': ACCESS_TOKEN_TTL,
                'id_token': id_token, 'scope': consent['scope']}

    def _exchange(self, form, client):
        _fail(set(form) <= {'grant_type', 'client_id', 'client_secret', 'subject_token', 'subject_token_type',
                            'requested_token_type', 'scope', 'audience'}, 'invalid_request', 'Unsupported parameter.')
        _fail(form.get('subject_token_type') == ACCESS_TOKEN_TYPE, 'invalid_request',
              'subject_token_type must be an access token.')
        _fail(form.get('requested_token_type') == GIVE_TOKEN_TYPE, 'invalid_request',
              'requested_token_type must be ' + GIVE_TOKEN_TYPE)
        now = self._now()
        row = self._access.get(hashlib.sha256(form.get('subject_token', '').encode('utf-8')).hexdigest())
        _fail(row is not None and now < row['expires'], 'invalid_grant', 'Unknown or expired subject token.')
        _fail(row['client_id'] == client['client_id'], 'invalid_grant', 'Subject token belongs to another client.')
        scope = form.get('scope', '')
        _fail(GIVE_SCOPE.fullmatch(scope) is not None, 'invalid_scope', 'Request exactly one give:<resource>:<limit>.')
        consent = row['consent']
        _fail(scope in consent['scope'].split(' '), 'invalid_scope', 'That GIVE scope was not consented.')
        if 'audience' in form:
            _fail(form['audience'] == self.chain, 'invalid_target', 'audience must be this chain id.')
        payload = give_payload(consent, scope)
        _fail(payload['expiry'] >= self._height(), 'invalid_grant', 'The consented GIVE expiry has passed.')
        draft = {'version': VERSION, 'chain': self.chain, 'principal': row['account'], 'op': 'GIVE',
                 'payload': payload, 'consent': digest(CONSENT_LABEL, consent), 'client_id': client['client_id'],
                 'signed': False, 'submitted': False}
        token = self._sign({'alg': 'RS256', 'kid': self.kid, 'typ': 'JWT'},
                           {'iss': self.issuer, 'sub': did(row['account'], self.chain), 'aud': client['client_id'],
                            'iat': now, 'exp': now + ACCESS_TOKEN_TTL, 'aap_give_draft': draft})
        # readiness: issued-to-holder RFC 8693 section 2.2 token exchange response to the authenticated client
        return {'access_token': token, 'issued_token_type': GIVE_TOKEN_TYPE, 'token_type': 'N_A',
                'expires_in': ACCESS_TOKEN_TTL, 'scope': scope, 'give': draft, 'execution_authorized': False}

    # --- userinfo endpoint -----------------------------------------------

    def userinfo(self, authorization):
        """OIDC Core 5.3: the Bearer access token's subject, and nothing else."""
        challenge = {'WWW-Authenticate': 'Bearer error="invalid_token"'}
        _fail(self.userinfo_enabled, 'invalid_request', 'Unknown endpoint.', 404)
        scheme, _, token = (authorization or '').partition(' ')
        if scheme.lower() != 'bearer' or not token:
            raise OIDCError('invalid_request', 'Send the access token as a Bearer Authorization header.', 401,
                            headers={'WWW-Authenticate': 'Bearer realm="' + self.issuer + '"'})
        with self._lock:
            now = self._now()
            row = self._access.get(hashlib.sha256(token.strip().encode('utf-8')).hexdigest())
            if row is None or now >= row['expires']:
                raise OIDCError('invalid_token', 'Unknown or expired access token.', 401, headers=challenge)
        return {'sub': did(row['account'], self.chain)}

    def _sign(self, header, claims):
        signing = _b64(_wire(header)) + '.' + _b64(_wire(claims))
        signature = self._key.sign(signing.encode('ascii'), padding.PKCS1v15(), hashes.SHA256())
        return signing + '.' + _b64(signature)

    def _expire(self, now):
        for table in (self._pending,):
            for ref in [ref for ref, row in table.items() if row['consent']['expires'] <= now]:
                del table[ref]
        for table in (self._codes, self._access, self._used_codes):
            for ref in [ref for ref, row in table.items() if row['expires'] <= now]:
                del table[ref]

    # --- HTTP-shaped entry ----------------------------------------------

    def handle(self, method, path, query='', body=b'', content_type='', authorization=''):
        """Return (status, headers, JSON body). Used by ``serve`` and by tests without sockets."""
        try:
            name = ENDPOINTS.get(path)
            _fail(name is not None, 'invalid_request', 'Unknown endpoint.', 404)
            want, handler = name
            _fail(method in want, 'invalid_request', 'Use ' + ' or '.join(want) + '.', 405)
            if method == 'GET':
                params = _single(parse_qs(query, keep_blank_values=True, strict_parsing=False, max_num_fields=32))
            else:
                _fail(len(body) <= 65536, 'invalid_request', 'Body too large.', 413)
                if content_type.split(';')[0].strip() == 'application/json':
                    try:
                        params = _read_json(body)
                    except (UnicodeError, ValueError):
                        raise OIDCError('invalid_request', 'Body is not JSON.') from None
                    _fail(type(params) is dict, 'invalid_request', 'Body must be an object.')
                elif not body and path == '/oidc/userinfo':
                    params = {}
                else:
                    _fail(content_type.split(';')[0].strip() == 'application/x-www-form-urlencoded', 'invalid_request',
                          'Use application/x-www-form-urlencoded.', 415)
                    try:
                        params = _single(parse_qs(body.decode('ascii'), keep_blank_values=True, max_num_fields=32))
                    except UnicodeError:
                        raise OIDCError('invalid_request', 'Body is not ASCII.') from None
            result = handler(self, params, authorization)
            if 'redirect' in result:
                return 302, {'Location': result['redirect'], 'Cache-Control': 'no-store'}, result
            return 200, {'Cache-Control': 'no-store', 'Pragma': 'no-cache'}, result
        except OIDCError as exc:
            if exc.redirect is not None:
                return 302, {'Location': exc.redirect, 'Cache-Control': 'no-store'}, exc.body()
            return exc.status, {'Cache-Control': 'no-store', **exc.headers}, exc.body()
        except ValueError as exc:
            return 400, {'Cache-Control': 'no-store'}, {'error': 'invalid_request', 'error_description': str(exc)[:120]}


def _single(parsed):
    for name, values in parsed.items():
        _fail(len(values) == 1, 'invalid_request', 'Repeated parameter: ' + name[:40])
    return {name: values[0] for name, values in parsed.items()}


def _approve(provider, params, authorization):
    _fail(set(params) == {'request', 'account', 'method', 'proof'}, 'invalid_request',
          'approve needs request, account, method and proof.')
    return provider.approve(params['request'], account=params['account'], method=params['method'],
                            proof=params['proof'])


def _deny(provider, params, authorization):
    _fail(set(params) == {'request'}, 'invalid_request', 'deny needs request.')
    return provider.deny(params['request'])


def _userinfo(provider, params, authorization):
    _fail(not params, 'invalid_request', 'Send the access token in the Authorization header only.')
    return provider.userinfo(authorization)


ENDPOINTS = {
    '/.well-known/openid-configuration': (('GET',), lambda provider, params, authorization: provider.discovery()),
    '/oidc/jwks': (('GET',), lambda provider, params, authorization: provider.jwks()),
    '/oidc/authorize': (('GET',), lambda provider, params, authorization: provider.authorize(params)),
    '/oidc/approve': (('POST',), _approve),
    '/oidc/deny': (('POST',), _deny),
    '/oidc/token': (('POST',), lambda provider, params, authorization: provider.token(params,
                                                                                      authorization=authorization)),
    '/oidc/userinfo': (('GET', 'POST'), _userinfo),
}


def serve(provider, *, host='127.0.0.1', port=0, allow_non_loopback=False):
    """Start a bounded reference HTTP server for ``provider`` on loopback only.

    A separately qualified owner TLS service may proxy this local backend.
    allow_non_loopback is retained for caller compatibility but cannot lift
    the loopback restriction. No public authentication deployment is shipped.
    """
    from http.server import BaseHTTPRequestHandler
    from .http_limits import BoundedHTTPServer
    need(isinstance(provider, SignInProvider), 'SIGNIN_PROVIDER')
    need(_loopback(host), 'SIGNIN_LOOPBACK_ONLY')
    need(type(port) is int and 0 <= port <= 65535, 'SIGNIN_PORT')

    class Handler(BaseHTTPRequestHandler):
        server_version = 'covenant-signin/0.1'

        def log_message(self, *args):
            return

        def _reply(self, method):
            self.close_connection = True
            parts = urlsplit(self.path)
            lengths = self.headers.get_all('Content-Length', [])
            framing = (not self.headers.get_all('Transfer-Encoding') and not self.headers.get_all('Expect')
                       and len(lengths) <= 1 and (not lengths or re.fullmatch(r'0|[1-9][0-9]{0,5}', lengths[0])))
            length = int(lengths[0]) if framing and lengths else 0
            origins = self.headers.get_all('Origin', [])
            allowed_origin = not origins or (len(origins) == 1 and origins[0] == provider.origin)
            if not framing or length > 65536 or (method == 'GET' and length) or not allowed_origin:
                self.send_error(400 if framing and allowed_origin else 403)
                return
            body = self.rfile.read(length) if method == 'POST' else b''
            status, headers, value = provider.handle(method, parts.path, parts.query, body,
                                                     self.headers.get('Content-Type', ''),
                                                     self.headers.get('Authorization', ''))
            raw = _wire(value)
            self.send_response(status)
            for name, header in headers.items():
                self.send_header(name, header)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            self._reply('GET')

        def do_POST(self):
            self._reply('POST')

    return BoundedHTTPServer((host, port), Handler, max_connections=8, connection_seconds=3)


def profile():
    return {'version': VERSION, 'protocol': 'OpenID Connect 1.0 authorization code flow with PKCE S256',
            'id_token_alg': 'RS256', 'subject': 'did:aap:<chain>:<account>',
            'login_methods': ['ACCOUNT_KEY_SIGNATURE', 'REGISTERED_PASSKEY'],
            'token_exchange': {'grant_type': EXCHANGE_GRANT, 'subject_token_type': ACCESS_TOKEN_TYPE,
                               'requested_token_type': GIVE_TOKEN_TYPE, 'result': 'UNSIGNED_GIVE_DRAFT'},
            'endpoints': sorted(ENDPOINTS), 'deployment': 'EXPLICIT_LOOPBACK_REFERENCE_ONLY; NO_PUBLIC_HOSTING_QUALIFICATION',
            'userinfo': 'OPTIONAL_SUB_ONLY', 'authorization_errors': 'REDIRECTED_ONCE_REDIRECT_URI_TRUSTED',
            'state': 'OWNER_DIRECTORY_STORE_OPTIONAL', 'key_rotation': 'MANUAL_TWO_KIDS_DURING_OVERLAP',
            'holds_account_keys': False, 'proves': list(PROVES), 'does_not_prove': list(DOES_NOT_PROVE),
            'consensus_change': None, 'execution_authorized': False}


def relying_party_check(id_token, *, issuer, client_id, jwks, nonce, now):
    """Relying-party verification with the repository's pinned-JWKS RS256 verifier."""
    from .oidc_identity import OIDCVerifier
    claims = OIDCVerifier(issuer, client_id, jwks).verify(id_token, nonce=nonce, now=now)
    chain, account = resolve_did(claims['sub'])
    return {'subject': claims['sub'], 'chain': chain, 'account': account, 'claims': claims,
            'nonce_checked': True, 'audience_checked': True, 'execution_authorized': False}
