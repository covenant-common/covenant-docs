"""Versioned portable offline trades, encrypted custody and explicit evidence states.

This profile records agreements and claims. It neither spends money nor proves
global single use. Owner-installed verifiers supply their own narrow evidence
checks; received descriptions never install code, trust or signing authority.

Successor covenant-offline-trade/0.2 keeps every 0.1 field, label and event
rule and adds two things: signed risk terms whose plain words both parties
assent to, and unsigned evidence attachments (status snapshots, reservation
proof, issuance co-signatures, device heads, provider collection records) that
each carry their own signature or hash pin. A 0.1 record keeps its exact bytes
and meaning and never becomes 0.2. offline_trade_freshness, offline_trade_backing,
offline_trade_conflicts and offline_trade_recovery read 0.2 records.
"""
from copy import deepcopy
import re
import time

from . import crypto as c, offline as transport
from .offline_store import OfflineStore

VERSION = 'covenant-offline-trade/0.1'
TERMS = 'covenant-offline-trade-terms/0.1'
ASSENT = 'COVENANT-OFFLINE-TRADE-ASSENT-0.1'
EVENT = 'COVENANT-OFFLINE-TRADE-EVENT-0.1'
MAX_BYTES = 32768
MAX_EVENTS = 32
ZERO = '0' * 64
MODES = ('RECORD_ONLY', 'PREALLOCATED_CLAIM', 'ISSUER_CREDIT', 'LOCAL_QUORUM')
KINDS = ('RECIPIENT_RETAINED', 'DELIVERY_CLAIMED', 'DELIVERY_ACCEPTED',
         'DISPUTED', 'DECISION_RECORDED', 'PAYMENT_SUBMITTED', 'PAYMENT_OBSERVED')
VERSION_0_2 = 'covenant-offline-trade/0.2'
TERMS_0_2 = 'covenant-offline-trade-terms/0.2'
# A 0.2 record with its attachments still fits one sealed offline packet
# (base64 inside the 49,152-byte offline payload). The signed core keeps the
# 0.1 bound; a ledger proof too large for the rest travels in its own packet.
MAX_BYTES_0_2 = 36000
MAX_ATTACHMENTS = 24
ATTACHMENT_LIMITS = {'AGREEMENT': 1, 'PRESENTATION': 4, 'AUTHORITY': 4, 'RESERVATION': 1,
                     'CREDIT_LINE': 1, 'INSTRUCTION': 2, 'COSIGN': 16, 'TIME_EVIDENCE': 1,
                     'HEAD': 1, 'PROVIDER_COLLECTION': 2}
BACKINGS = ('OFFLINE_VALUE', 'OWNER_VERIFIED')
LEDGER_KINDS = ('VOUCHER', 'ALLOWANCE')
LOSS_RULES = {
    'HOLDER_BEARS_DEFAULT': 'if the issuer cannot pay, the holder of the note bears the loss',
    'HOLDERS_SHARE_PRO_RATA': 'if the issuer cannot pay in full, holders share what it pays in proportion to their notes',
    'BUYER_REMAINS_LIABLE': 'if the issuer cannot pay, the buyer still owes the supplier',
}
_COUNTER = re.compile(r'(0|[1-9][0-9]{0,15})\Z')

# Fix text for each refusal code raised here: what happened, then what to do next.
# tools/build_lead_docs.py copies it into the error catalogue every agent host reads.
REMEDIATION = {
    'TRADE_FIELDS':
        'The trade record does not have exactly the fields this version defines. Pass the bundle, terms or '
        'event exactly as the parties signed or exported it.',
    'TRADE_TEXT':
        'A text field is empty, too long or not plain printable ASCII (the description takes up to 4096 '
        'characters, the delivery check and dispute text up to 2048, names up to 256, the revision up to 64).'
        ' Shorten it and use plain printable characters.',
    'TRADE_VERSION':
        'The trade is not version covenant-offline-trade/0.1 with terms covenant-offline-trade-terms/0.1. Use'
        ' a record of this version; another version needs its own reader.',
    'TRADE_ED25519_ONLY':
        'A party is not given as an Ed25519 public key in text form. Name each party by its 64-character hex '
        'public key.',
    'TRADE_DISTINCT_PARTIES':
        'The buyer, supplier and reviewer are not different keys. Use a different key for each role.',
    'TRADE_WINDOWS':
        'The time windows are out of order; a trade needs issued_at < spend_until <= redeem_until. Set the '
        'windows in that order.',
    'TRADE_MODE':
        'The mode is not RECORD_ONLY, PREALLOCATED_CLAIM, ISSUER_CREDIT or LOCAL_QUORUM. Choose one of those '
        'modes.',
    'TRADE_CREDENTIAL_POLICY':
        'A credential policy and a credential reference come together, and one of them is missing. Pass both,'
        ' or leave both out.',
    'TRADE_STATUS_AGE': 'The maximum status age is longer than 30 days. Choose a shorter age.',
    'TRADE_RESERVATION_BENEFICIARY':
        "The reserved claim is not payable to the supplier. Use a claim whose beneficiary is the supplier's "
        'key.',
    'TRADE_RESERVATION_WINDOW_OR_AMOUNT':
        'The reserved claim is smaller than the quantity, or expires before the redemption window ends. Use a'
        ' claim that covers the full quantity until redeem_until.',
    'TRADE_RESERVATION_MODE':
        'A reserved claim and mode PREALLOCATED_CLAIM come together, and one of them is missing. Use that '
        'mode with a claim, or neither.',
    'TRADE_DELIVERY_TIME': 'The delivery is due before the trade was issued. Set a due time at or after issued_at.',
    'TRADE_TERMS_SIZE':
        'The trade terms are larger than 16384 bytes. Shorten the description and checks, and carry long '
        'documents as hashes.',
    'TRADE_NOT_PARTY':
        "The signing key is not one of the trade's parties. Sign with the buyer's, supplier's or reviewer's "
        'own key.',
    'TRADE_ASSENT_CONFLICT':
        'This party already signed the trade with a different signature. Keep the first signature; a '
        'conflicting second one is refused.',
    'TRADE_EVENT_KIND':
        'The event kind is not one this version records (RECIPIENT_RETAINED, DELIVERY_CLAIMED, '
        'DELIVERY_ACCEPTED, DISPUTED, DECISION_RECORDED, PAYMENT_SUBMITTED or PAYMENT_OBSERVED). Use one of '
        'those kinds.',
    'TRADE_PAYMENT_OUTCOME':
        'The observed payment outcome is not SETTLED, FAILED, REFUNDED or DISPUTED. Record one of those '
        'outcomes.',
    'TRADE_EVENT_LIMIT':
        'The trade already holds the most events allowed (32), or its events are not a list. Start a '
        'follow-up trade for further steps.',
    'TRADE_UNSIGNED_EVENTS':
        'The trade has events, but not every party has signed it. Collect all signatures first; events come '
        'after the deal exists.',
    'TRADE_EVENT_CHAIN':
        'An event does not follow the one before it (wrong trade, sequence, previous hash or actor). Send the'
        ' events exactly as recorded, in order.',
    'TRADE_EVENT_CLOCK':
        'An event is dated earlier than the event before it or the trade itself. Record events in time order.',
    'TRADE_RETENTION_ROLE_OR_REPEAT':
        'A retention event came from someone other than the supplier, or was recorded twice. Only the '
        'supplier records retention, once.',
    'TRADE_RETENTION_RECORD':
        'The retention event names another record than the trade as it stood before this event. Point it at '
        'the record ID of the trade just before this event.',
    'TRADE_DELIVERY_ROLE_OR_CLOSED':
        'A delivery claim came from someone other than the supplier, or after the buyer accepted delivery. '
        'Only the supplier claims delivery, before acceptance.',
    'TRADE_ACCEPTANCE':
        'The acceptance is not from the buyer, does not name the latest delivery claim, or repeats an earlier'
        ' acceptance. The buyer accepts once, naming the event ID of the delivery claim.',
    'TRADE_DISPUTE_ROLE':
        'A dispute came from someone other than the buyer or the supplier. Only the buyer or the supplier '
        'opens a dispute.',
    'TRADE_REVIEWER':
        'A decision came from someone other than the named reviewer, or before any dispute. Only the reviewer'
        ' named in the terms records a decision, after a dispute.',
    'TRADE_PAYMENT_ROLE':
        'A payment submission came from someone other than the buyer. Only the buyer submits payment.',
    'TRADE_SPEND_WINDOW': 'The payment was submitted at or after spend_until. Agree a new trade with a later window.',
    'TRADE_EFFECT_REUSED':
        'That payment effect ID was already submitted in this trade. Use a new effect ID for a new payment.',
    'TRADE_OBSERVATION_CONTEXT':
        'A payment observation came from someone other than the buyer or the supplier, or names an effect '
        'that was never submitted. Observe only a submitted effect, as the buyer or the supplier.',
    'TRADE_VERIFIER_NOT_INSTALLED':
        'The verifier given is not a function. The owner installs a verifier function, or leaves it out.',
    'TRADE_VERIFIER_RESULT':
        'The installed verifier returned something other than true or false. Fix the verifier so it returns a'
        ' boolean.',
    'TRADE_CREDENTIAL_ROLE': 'The role is not buyer, supplier or reviewer. Pass one of those roles.',
    'TRADE_CREDENTIAL_REFERENCE':
        'The trade pins another credential policy or credential than the one presented. Present the '
        'credential and policy the trade names.',
    'TRADE_CREDENTIAL_SUBJECT':
        "The credential names another subject, or its holder key is not this role's key. Present a credential"
        ' issued to this party.',
    'TRADE_CREDENTIAL_STALE':
        "The credential's status snapshot is older than the trade allows. Get a fresh snapshot from the "
        'issuer.',
    'TRADE_PIN':
        'The trade terms do not hash to the expected trade ID. Check that you have the exact trade you meant;'
        ' never accept a substitute.',
    'TRADE_SIZE':
        'The trade record is larger than 32768 bytes. Carry large documents as hashes and keep events short.',
    'TRADE_ASSENTS': 'The signatures are not a list of at most three. Send each party signature once.',
    'TRADE_ASSENT_PARTY':
        'A signature is from someone who is not a party, or a party signed twice. Keep one signature per '
        'party.',
    'TRADE_EVENT_FUTURE':
        'The last event is dated after the time given for the check. Pass the current time, or check again '
        'after the event time.',
    'TRADE_MISSING_ASSENTS':
        'The trade is not signed by every party yet, so events cannot be added. Collect every signature '
        'first.',
    'TRADE_RECORD_PIN':
        'The imported record is not the record you expected. Check that you have the exact record ID and the '
        'exact packet.',
    'TRADE_COURIER_PARTY':
        'The sender or the recipient of the packet is not a party to the trade. Send trade packets only '
        'between its parties.',
    'TRADE_COURIER_KIND':
        'The packet does not hold trade data. Seal the trade with seal_bundle and send that packet.',
    'TRADE_ALLOWANCE_CHANGED':
        'An allowance with the same issuer, reference, asset and unit was already adopted with another limit.'
        ' Use a new reference for a new limit.',
    'TRADE_STORE_NOT_PARTY':
        "The owner of this store is not a party to the trade. Save a trade only in a party's own store.",
    'TRADE_HISTORY_FORK':
        'This trade history differs from the copy already saved, so the two have split. Keep both copies as '
        'proof and settle which one the parties signed.',
    'TRADE_INBOX_LIMIT':
        'The store already holds its limit of 16 trades. Keep this store as a record and open a new store '
        'directory for further trades.',
    'TRADE_SERIAL_CONFLICT':
        'The reserved claim serial is already used by another trade. Use a claim that is not reserved '
        'elsewhere.',
    'TRADE_ALLOWANCE_NOT_ADOPTED':
        'The buyer has not adopted an allowance for this claim issuer, reference, asset and unit. The owner '
        'adopts the allowance first, with adopt_allowance.',
    'TRADE_AGGREGATE_ALLOWANCE':
        'This reserved claim would take the total past the adopted allowance limit. Have the owner review the'
        ' allowance; a retry cannot raise it.',
    'TRADE_MISSING': 'No trade with that ID is saved in this store. Check the trade ID, or save the trade first.',
    'TRADE_RISK_TERMS':
        'The declared risk is missing a parameter its mode needs, names an unknown backing or loss rule, or '
        'has a time before issue. Give the parameters the mode needs (see the risk table) with times on or '
        'after issue.',
    'TRADE_RISK_WORDS':
        'The risk words in the record are not exactly the text generated from its risk terms. Regenerate the '
        'record with offline_trade.declare_risk; never edit the words by hand.',
    'TRADE_RISK_DRAFT_ONLY':
        'The risk can be declared only on an unsigned 0.1 draft, and this trade is signed, has events or has '
        'another version. State the risk on the unsigned 0.1 draft, before anyone assents.',
    'TRADE_ATTACHMENTS':
        'The attachments are not a list, or there are more than the documented maximum. Carry at most the '
        'documented number of attachments in a list.',
    'TRADE_ATTACHMENT_KIND':
        'An attachment has an unknown kind, or its value is not an object or a list. Use one of the '
        'documented attachment kinds with an object or list value.',
    'TRADE_ATTACHMENT_COUNT':
        'There are more attachments of one kind than that kind allows. Remove extra attachments of that '
        'kind; each kind has its own bound.',
    'TRADE_ATTACHMENT_ORDER':
        'The attachments repeat or are not in canonical order. Rebuild the attachments with '
        'offline_trade.attach so they stay unique and in canonical order.',
    'TRADE_ATTACHMENTS_0_2_ONLY':
        'This record is not version covenant-offline-trade/0.2, and only 0.2 records carry attachments. Make '
        'the trade as a 0.2 record; a 0.1 record keeps its exact shape.',
}



def _exact(value, fields):
    c.need(type(value) is dict and set(value) == set(fields.split()), 'TRADE_FIELDS')


def _text(value, maximum=1024):
    c.need(type(value) is str and 0 < len(value) <= maximum and
           all(32 <= ord(ch) <= 126 for ch in value), 'TRADE_TEXT')


def _optional_ref(value):
    if value is not None:
        c.key(value)


def _terms(value):
    successor = type(value) is dict and value.get('version') == TERMS_0_2
    _exact(value, 'version agreement revision description parties resource windows policy delivery dispute nonce'
           + (' risk' if successor else ''))
    c.need(value['version'] == (TERMS_0_2 if successor else TERMS), 'TRADE_VERSION')
    c.key(value['agreement']); c.key(value['nonce'])
    _text(value['revision'], 64); _text(value['description'], 4096)
    parties = value['parties']; _exact(parties, 'buyer supplier reviewer')
    for name in ('buyer', 'supplier'):
        c.need(type(parties[name]) is str, 'TRADE_ED25519_ONLY')
        c.verification_key(parties[name])
    c.need(parties['buyer'] != parties['supplier'], 'TRADE_DISTINCT_PARTIES')
    if parties['reviewer'] is not None:
        c.need(type(parties['reviewer']) is str, 'TRADE_ED25519_ONLY')
        c.verification_key(parties['reviewer'])
        c.need(parties['reviewer'] not in (parties['buyer'], parties['supplier']), 'TRADE_DISTINCT_PARTIES')
    r = value['resource']; _exact(r, 'asset quantity unit rail')
    for name in ('asset', 'unit', 'rail'):
        _text(r[name], 256)
    c.integer(r['quantity'], True)
    w = value['windows']; _exact(w, 'issued_at spend_until redeem_until')
    for x in w.values(): c.integer(x)
    c.need(w['issued_at'] < w['spend_until'] <= w['redeem_until'], 'TRADE_WINDOWS')
    p = value['policy']
    _exact(p, 'mode authority_reference credential_policy credential_reference maximum_status_age reservation')
    c.need(type(p['mode']) is str and p['mode'] in MODES, 'TRADE_MODE')
    for name in ('authority_reference', 'credential_policy', 'credential_reference'):
        _optional_ref(p[name])
    c.need((p['credential_policy'] is None) == (p['credential_reference'] is None), 'TRADE_CREDENTIAL_POLICY')
    c.integer(p['maximum_status_age'])
    c.need(p['maximum_status_age'] <= 30 * 86400, 'TRADE_STATUS_AGE')
    if p['reservation'] is not None:
        claim = p['reservation']
        _exact(claim, 'issuer reference serial beneficiary amount expires')
        c.verification_key(claim['issuer']); c.key(claim['reference']); _text(claim['serial'], 128)
        c.need(claim['beneficiary'] == parties['supplier'], 'TRADE_RESERVATION_BENEFICIARY')
        c.integer(claim['amount'], True); c.integer(claim['expires'])
        c.need(claim['amount'] >= r['quantity'] and claim['expires'] >= w['redeem_until'],
               'TRADE_RESERVATION_WINDOW_OR_AMOUNT')
    c.need((p['mode'] == 'PREALLOCATED_CLAIM') == (p['reservation'] is not None), 'TRADE_RESERVATION_MODE')
    d = value['delivery']; _exact(d, 'check due')
    _text(d['check'], 2048); c.integer(d['due'])
    c.need(d['due'] >= w['issued_at'], 'TRADE_DELIVERY_TIME')
    _text(value['dispute'], 2048)
    if successor:
        _risk(value)
    c.need(len(c.canonical(value)) <= 16384, 'TRADE_TERMS_SIZE')
    return c.digest('COVENANT-OFFLINE-TRADE-TERMS-0.2' if successor else 'COVENANT-OFFLINE-TRADE-TERMS-0.1', value)


def _when(at):
    # Numeric UTC only: the rendering is part of signed 0.2 bytes and must not
    # depend on locale or platform time zone data.
    if not 0 <= at <= 253402300799:
        return 'time %d' % at
    t = time.gmtime(at)
    return '%04d-%02d-%02d %02d:%02d UTC' % (t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min)


def _risk_terms(value):
    """Mode-specific 0.2 risk parameters; the words are checked separately."""
    risk = value['risk']; _exact(risk, 'terms words')
    t, p, w, parties = risk['terms'], value['policy'], value['windows'], value['parties']
    mode = p['mode']
    if mode == 'RECORD_ONLY':
        _exact(t, 'pay_by method'); c.integer(t['pay_by']); _text(t['method'], 256)
        c.need(t['pay_by'] >= w['issued_at'], 'TRADE_RISK_TERMS')
    elif mode == 'PREALLOCATED_CLAIM':
        _exact(t, 'backing chain kind')
        c.need(type(t['backing']) is str and t['backing'] in BACKINGS, 'TRADE_RISK_TERMS')
        if t['backing'] == 'OFFLINE_VALUE':
            c.key(t['chain'])
            c.need(type(t['kind']) is str and t['kind'] in LEDGER_KINDS and
                   _COUNTER.match(p['reservation']['serial']) is not None, 'TRADE_RISK_TERMS')
        else:
            c.need(t['chain'] is None and t['kind'] is None, 'TRADE_RISK_TERMS')
    elif mode == 'ISSUER_CREDIT':
        _exact(t, 'issuer line serial matures_at redeem loss')
        c.need(type(t['issuer']) is str, 'TRADE_ED25519_ONLY'); c.verification_key(t['issuer'])
        c.key(t['line']); _text(t['serial'], 128); _text(t['redeem'], 256); c.integer(t['matures_at'])
        c.need(t['issuer'] != parties['buyer'] and t['matures_at'] >= w['issued_at'] and
               type(t['loss']) is str and t['loss'] in LOSS_RULES, 'TRADE_RISK_TERMS')
    else:
        _exact(t, 'group members threshold serial')
        c.key(t['group']); _text(t['serial'], 128); c.integer(t['members'], True); c.integer(t['threshold'], True)
        c.need(t['members'] <= 32 and t['threshold'] <= t['members'] and 2 * t['threshold'] > t['members'],
               'TRADE_RISK_TERMS')
    return t


def _render(value):
    t, p, w, r = value['risk']['terms'], value['policy'], value['windows'], value['resource']
    amount = '%d %s (%s)' % (r['quantity'], r['unit'], r['asset'])
    mode = p['mode']
    if mode == 'RECORD_ONLY':
        text = ('Record only, pay later: no value moves now. The buyer promises to pay %s by %s (%s). '
                'The supplier carries the risk that the buyer does not pay.' % (amount, _when(t['pay_by']), t['method']))
    elif mode == 'PREALLOCATED_CLAIM' and t['backing'] == 'OFFLINE_VALUE':
        claim = p['reservation']
        text = ('Preallocated allowance: %s is claimed from escrow book %s on ledger %s, serial %s. It is paid '
                'when the supplier reconciles, if no other note with this serial was reconciled first. If the '
                "buyer's device signs this serial twice the book is slashed: the losing payee is paid from what "
                'remains, the rest is burned, and unreconciled notes from the book can no longer be redeemed. '
                'Copied device keys cannot be prevented, only bounded by the escrow and attributed.'
                % (amount, claim['reference'][:16], t['chain'][:16], claim['serial']))
    elif mode == 'PREALLOCATED_CLAIM':
        claim = p['reservation']
        text = ('Preallocated allowance: %s is claimed against reservation %s from %s, serial %s, held until %s. '
                "Its backing is only what the supplier's own verifier accepts. The same reservation can be shown "
                'to several disconnected payees, so every claim on it is counted together.'
                % (amount, claim['reference'][:16], claim['issuer'][:16], claim['serial'], _when(claim['expires'])))
    elif mode == 'ISSUER_CREDIT':
        text = ('Local issuer credit: issuer %s promises to pay the holder %s from %s at %s (credit line %s, '
                'serial %s). The supplier carries the risk that the issuer cannot pay; %s. Each supplier sets '
                'its own acceptance limit for this issuer.'
                % (t['issuer'][:16], amount, _when(t['matures_at']), t['redeem'], t['line'][:16], t['serial'],
                   LOSS_RULES[t['loss']]))
    else:
        text = ('Connected local quorum: %d of %d members of group %s must confirm serial %s while they can reach '
                'each other. This is local confirmation, not global finality: members cut off from the group, or '
                'a quorum that lies, can still disagree, and reconciliation decides.'
                % (t['threshold'], t['members'], t['group'][:16], t['serial']))
    return text + (' The note may be spent until %s and presented until %s; a late note needs independent proof '
                   'that it was issued in time.' % (_when(w['spend_until']), _when(w['redeem_until'])))


def _risk(value):
    _risk_terms(value)
    words = value['risk']['words']
    c.need(type(words) is str and words == _render(value), 'TRADE_RISK_WORDS')


def risk_words(bundle):
    """The exact plain words a 0.2 record states and both parties sign; None for 0.1."""
    terms_id(bundle)
    return bundle['terms']['risk']['words'] if bundle['version'] == VERSION_0_2 else None


def declare_risk(bundle, **parameters):
    """Turn an unsigned 0.1 draft into a 0.2 draft that states its risk in plain words.

    Parameters by mode: RECORD_ONLY pay_by, method; PREALLOCATED_CLAIM backing,
    chain, kind; ISSUER_CREDIT issuer, line, serial, matures_at, redeem, loss;
    LOCAL_QUORUM group, members, threshold, serial. Nothing here signs or spends.
    """
    terms_id(bundle)
    c.need(bundle['version'] == VERSION and not bundle['assents'] and not bundle['events'], 'TRADE_RISK_DRAFT_ONLY')
    value = deepcopy(bundle['terms'])
    value['version'] = TERMS_0_2
    value['risk'] = {'terms': deepcopy(parameters), 'words': ''}
    _risk_terms(value)
    value['risk']['words'] = _render(value)
    _terms(value)
    return dict(version=VERSION_0_2, terms=value, assents=[], events=[], attachments=[])


def slot_id(bundle):
    """The spend slot two disconnected payees could both be shown, or None for a promise without one."""
    terms_id(bundle)
    t = bundle['terms']; p = t['policy']; mode = p['mode']
    if p['reservation'] is not None:
        claim = p['reservation']
        # The same digest TradeStore already uses for local serial conflicts.
        return c.digest('COVENANT-TRADE-SERIAL-0.1', {k: claim[k] for k in ('issuer', 'reference', 'serial')})
    if bundle['version'] != VERSION_0_2 or mode == 'RECORD_ONLY':
        return None
    risk = t['risk']['terms']
    if mode == 'ISSUER_CREDIT':
        return c.digest('COVENANT-OFFLINE-TRADE-SLOT-0.2', {'mode': mode, 'issuer': risk['issuer'],
                                                           'line': risk['line'], 'serial': risk['serial']})
    return c.digest('COVENANT-OFFLINE-TRADE-SLOT-0.2', {'mode': mode, 'group': risk['group'],
                                                       'buyer': t['parties']['buyer'], 'serial': risk['serial']})


def _attachments(rows):
    c.need(type(rows) is list and len(rows) <= MAX_ATTACHMENTS, 'TRADE_ATTACHMENTS')
    counts = {}
    for row in rows:
        _exact(row, 'kind value')
        c.need(type(row['kind']) is str and row['kind'] in ATTACHMENT_LIMITS and
               type(row['value']) in (dict, list), 'TRADE_ATTACHMENT_KIND')
        counts[row['kind']] = counts.get(row['kind'], 0) + 1
        c.need(counts[row['kind']] <= ATTACHMENT_LIMITS[row['kind']], 'TRADE_ATTACHMENT_COUNT')
    encoded = [c.canonical(row) for row in rows]
    c.need(encoded == sorted(set(encoded)), 'TRADE_ATTACHMENT_ORDER')


def attach(bundle, kind, value):
    """Add unsigned evidence to a 0.2 record. Each kind is checked by its own verifier.

    An attachment never grants authority: a missing, stale or forged one only
    leaves its check unmet. Exact duplicates are ignored, so retries are harmless.
    """
    terms_id(bundle)
    c.need(bundle['version'] == VERSION_0_2, 'TRADE_ATTACHMENTS_0_2_ONLY')
    c.need(type(kind) is str and kind in ATTACHMENT_LIMITS and type(value) in (dict, list), 'TRADE_ATTACHMENT_KIND')
    out = deepcopy(bundle)
    row = {'kind': kind, 'value': deepcopy(value)}
    if row not in out['attachments']:
        out['attachments'].append(row)
        out['attachments'].sort(key=c.canonical)
    terms_id(out)
    c.need(len(c.canonical(out)) <= MAX_BYTES_0_2, 'TRADE_SIZE')
    return out


def attached(bundle, kind):
    """Copies of one kind of evidence carried by a 0.2 record; always empty for 0.1."""
    terms_id(bundle)
    if bundle['version'] != VERSION_0_2:
        return []
    return [deepcopy(row['value']) for row in bundle['attachments'] if row['kind'] == kind]


def draft(*, agreement, buyer, supplier, description, quantity, unit='USD_CENTS',
          asset='USD', rail='OWNER_SELECTED_LATER', issued_at, spend_until,
          redeem_until, delivery_check, delivery_due, dispute='Return to the parties for review.',
          reviewer=None, revision='1', nonce, mode='RECORD_ONLY', reservation=None,
          authority_reference=None, credential_policy=None, credential_reference=None,
          maximum_status_age=300):
    """Keyless draft; all strings are inert terms, never executable connectors."""
    terms = dict(version=TERMS, agreement=agreement, revision=revision,
        description=description, parties=dict(buyer=buyer, supplier=supplier, reviewer=reviewer),
        resource=dict(asset=asset, quantity=quantity, unit=unit, rail=rail),
        windows=dict(issued_at=issued_at, spend_until=spend_until, redeem_until=redeem_until),
        policy=dict(mode=mode, authority_reference=authority_reference,
                    credential_policy=credential_policy, credential_reference=credential_reference,
                    maximum_status_age=maximum_status_age, reservation=deepcopy(reservation)),
        delivery=dict(check=delivery_check, due=delivery_due), dispute=dispute, nonce=nonce)
    _terms(terms)
    return dict(version=VERSION, terms=terms, assents=[], events=[])


def terms_id(bundle):
    successor = type(bundle) is dict and bundle.get('version') == VERSION_0_2
    _exact(bundle, 'version terms assents events' + (' attachments' if successor else ''))
    c.need(bundle['version'] in (VERSION, VERSION_0_2), 'TRADE_VERSION')
    ref = _terms(bundle['terms'])
    c.need((bundle['terms']['version'] == TERMS_0_2) == successor, 'TRADE_VERSION')
    if successor:
        _attachments(bundle['attachments'])
    return ref


def _parties(bundle):
    return sorted(x for x in bundle['terms']['parties'].values() if x is not None)


def signing_payload(bundle):
    return {'label': ASSENT, 'body': {'trade': terms_id(bundle)}}


def assent(bundle, signing_key):
    """Owner signing only. Possession of a key does not prove current authority."""
    inspect(bundle, expected_id=terms_id(bundle), now=_latest_time(bundle))
    who = c.public_key(signing_key)
    c.need(who in _parties(bundle), 'TRADE_NOT_PARTY')
    out = deepcopy(bundle)
    signed = {'party': who, 'signature': c.sign(signing_key, ASSENT, {'trade': terms_id(bundle)})}
    previous = next((x for x in out['assents'] if x['party'] == who), None)
    c.need(previous is None or previous == signed, 'TRADE_ASSENT_CONFLICT')
    if previous is None: out['assents'].append(signed)
    out['assents'].sort(key=lambda x: x['party'])
    return out


def event_id(value):
    return c.digest('COVENANT-OFFLINE-TRADE-EVENT-ID-0.1', value)


def _event_data(kind, data):
    c.need(type(kind) is str and kind in KINDS, 'TRADE_EVENT_KIND')
    if kind == 'RECIPIENT_RETAINED': _exact(data, 'record'); c.key(data['record'])
    elif kind == 'DELIVERY_CLAIMED': _exact(data, 'evidence'); c.key(data['evidence'])
    elif kind == 'DELIVERY_ACCEPTED': _exact(data, 'delivery'); c.key(data['delivery'])
    elif kind in ('DISPUTED', 'DECISION_RECORDED'):
        _exact(data, 'reason evidence'); _text(data['reason'], 2048); c.key(data['evidence'])
    elif kind == 'PAYMENT_SUBMITTED':
        _exact(data, 'effect instruction'); c.key(data['effect']); c.key(data['instruction'])
    elif kind == 'PAYMENT_OBSERVED':
        _exact(data, 'effect receipt outcome')
        c.key(data['effect']); c.key(data['receipt'])
        c.need(type(data['outcome']) is str and data['outcome'] in
               ('SETTLED', 'FAILED', 'REFUNDED', 'DISPUTED'), 'TRADE_PAYMENT_OUTCOME')


def _replay(bundle, complete):
    events = bundle['events']
    c.need(type(events) is list and len(events) <= MAX_EVENTS, 'TRADE_EVENT_LIMIT')
    parties = bundle['terms']['parties']; w = bundle['terms']['windows']
    state = dict(retained=False, delivery=None, accepted=None, disputed=False,
                 decision=None, submissions={}, observation=None, head=ZERO)
    previous_at = w['issued_at']
    ref = terms_id(bundle)
    for index, event in enumerate(events):
        c.need(complete, 'TRADE_UNSIGNED_EVENTS')
        _exact(event, 'body signature')
        body = event['body']; _exact(body, 'trade sequence previous actor kind data at')
        c.integer(body['sequence'], True); c.integer(body['at'])
        c.need(body['trade'] == ref and body['sequence'] == index+1 and
               body['previous'] == state['head'] and body['actor'] in _parties(bundle),
               'TRADE_EVENT_CHAIN')
        c.need(body['at'] >= previous_at, 'TRADE_EVENT_CLOCK')
        _event_data(body['kind'], body['data'])
        c.verify(body['actor'], EVENT, body, event['signature'])
        kind, data, actor = body['kind'], body['data'], body['actor']
        if kind == 'RECIPIENT_RETAINED':
            c.need(actor == parties['supplier'] and not state['retained'], 'TRADE_RETENTION_ROLE_OR_REPEAT')
            c.need(data['record'] == record_id({**bundle, 'events':events[:index]}), 'TRADE_RETENTION_RECORD')
            state['retained'] = True
        elif kind == 'DELIVERY_CLAIMED':
            c.need(actor == parties['supplier'] and state['accepted'] is None, 'TRADE_DELIVERY_ROLE_OR_CLOSED')
            state['delivery'] = event_id(event)
        elif kind == 'DELIVERY_ACCEPTED':
            c.need(actor == parties['buyer'] and state['delivery'] == data['delivery'] and
                   state['accepted'] is None, 'TRADE_ACCEPTANCE')
            state['accepted'] = event_id(event); state['disputed'] = False
        elif kind == 'DISPUTED':
            c.need(actor in (parties['buyer'], parties['supplier']), 'TRADE_DISPUTE_ROLE')
            state['disputed'] = True
        elif kind == 'DECISION_RECORDED':
            c.need(parties['reviewer'] is not None and actor == parties['reviewer'] and
                   state['disputed'], 'TRADE_REVIEWER')
            state['decision'] = event_id(event)
        elif kind == 'PAYMENT_SUBMITTED':
            c.need(actor == parties['buyer'], 'TRADE_PAYMENT_ROLE')
            c.need(body['at'] < w['spend_until'], 'TRADE_SPEND_WINDOW')
            old = state['submissions'].get(data['effect'])
            c.need(old is None, 'TRADE_EFFECT_REUSED')
            state['submissions'][data['effect']] = data['instruction']
        else:
            c.need(actor in (parties['buyer'], parties['supplier']) and
                   data['effect'] in state['submissions'], 'TRADE_OBSERVATION_CONTEXT')
            state['observation'] = event
        state['head'] = event_id(event); previous_at = body['at']
    return state


def _verified(callback, payload):
    if callback is None: return None
    c.need(callable(callback), 'TRADE_VERIFIER_NOT_INSTALLED')
    result = callback(deepcopy(payload))
    c.need(type(result) is bool, 'TRADE_VERIFIER_RESULT')
    return result


def accreditation_verifier(presentation, accepted_policy, *, expected_subject, role='supplier'):
    """Read-only owner adapter for the portable accreditation profile.

    All policy/trust inputs must be adopted by the owner. This deliberately
    does not consume a challenge on every historical display; effect admission
    separately uses agent_accreditation.verify_presentation and its durable store.
    """
    from . import agent_accreditation as accreditation
    _text(expected_subject, 1024)
    c.need(type(role) is str and role in ('buyer', 'supplier', 'reviewer'), 'TRADE_CREDENTIAL_ROLE')
    packet, policy = deepcopy(presentation), deepcopy(accepted_policy)
    adopted = accreditation.policy_id(policy)
    reference = accreditation.credential_id(packet['credential'])

    def check(context):
        try:
            terms, now = context['terms'], context['now']
            c.need(terms['policy']['credential_policy'] == adopted and
                   terms['policy']['credential_reference'] == reference, 'TRADE_CREDENTIAL_REFERENCE')
            credential = packet['credential']['credential']
            c.need(credential['subject'] == expected_subject and
                   credential['holder_key'] == terms['parties'][role], 'TRADE_CREDENTIAL_SUBJECT')
            result = accreditation.inspect_presentation(packet, policy,
                nonce=context['trade'], now=now, offline=True)
            c.need(now-result['status_as_of'] <= terms['policy']['maximum_status_age'], 'TRADE_CREDENTIAL_STALE')
            return result['accepted'] is True
        except (ValueError, KeyError, TypeError):
            return False
    return check


def inspect(bundle, *, expected_id, now, credential_verifier=None,
            authority_verifier=None, reservation_verifier=None, payment_verifier=None):
    ref = terms_id(bundle); c.key(expected_id); c.integer(now)
    c.need(ref == expected_id, 'TRADE_PIN')
    successor = bundle['version'] == VERSION_0_2
    c.need(len(c.canonical(_core(bundle))) <= MAX_BYTES and
           len(c.canonical(bundle)) <= (MAX_BYTES_0_2 if successor else MAX_BYTES), 'TRADE_SIZE')
    assents = bundle['assents']; c.need(type(assents) is list and len(assents) <= 3, 'TRADE_ASSENTS')
    seen = set()
    for row in assents:
        _exact(row, 'party signature')
        c.need(type(row['party']) is str and row['party'] in _parties(bundle) and row['party'] not in seen,
               'TRADE_ASSENT_PARTY')
        c.verify(row['party'], ASSENT, {'trade': ref}, row['signature']); seen.add(row['party'])
    complete = seen == set(_parties(bundle)); state = _replay(bundle, complete)
    c.need(not bundle['events'] or bundle['events'][-1]['body']['at'] <= now, 'TRADE_EVENT_FUTURE')
    p = bundle['terms']['policy']; w = bundle['terms']['windows']
    context = dict(trade=ref, terms=deepcopy(bundle['terms']), now=now)
    credentials = None if p['credential_reference'] is None else _verified(credential_verifier, context)
    authority = None if p['authority_reference'] is None else _verified(authority_verifier, context)
    reservation = None if p['reservation'] is None else _verified(reservation_verifier, context)
    payment = None if state['observation'] is None else _verified(payment_verifier,
        {**context, 'event': state['observation']})
    observed = state['observation']['body']['data']['outcome'] if state['observation'] else None
    requirements = []
    if p['credential_reference'] is not None and credentials is not True: requirements.append('CREDENTIAL_CHECK_REQUIRED')
    if p['authority_reference'] is not None and authority is not True: requirements.append('AUTHORITY_CHECK_REQUIRED')
    if p['reservation'] is not None and reservation is not True: requirements.append('RESERVATION_CHECK_REQUIRED')
    outstanding = []
    if not complete: outstanding.append('OBTAIN_MISSING_ASSENTS')
    if state['accepted'] is None: outstanding.append('DELIVERY_CHECK_REMAINS')
    if not (payment is True and observed == 'SETTLED'): outstanding.append('PAYMENT_NOT_CONFIRMED_SETTLED')
    if state['disputed']: outstanding.append('DISPUTE_REMAINS_OPEN')
    return dict(version=VERSION, trade=ref, record=record_id(bundle),
        agreement_state='AGREED' if complete else 'AWAITING_ASSENTS',
        missing_signers=sorted(set(_parties(bundle))-seen),
        retention='RECIPIENT_RETAINED_CLAIM' if state['retained'] else 'NOT_RECORDED',
        delivery='ACCEPTED_BY_BUYER' if state['accepted'] else 'CLAIMED_BY_SUPPLIER' if state['delivery'] else 'NOT_RECORDED',
        payment='PROVIDER_OBSERVED_'+observed if payment is True else 'PARTY_REPORTED_'+observed if observed else
                'SUBMITTED_CLAIM' if state['submissions'] else 'NOT_OBSERVED',
        payment_verified=payment is True and observed == 'SETTLED',
        performance_verified=False, current_authority_verified=authority is True,
        credential_policy_satisfied=credentials, reservation_evidence_accepted=reservation,
        credential_current_global_status='UNKNOWN', exclusive_spend_verified=False,
        within_spending_window=w['issued_at'] <= now < w['spend_until'],
        within_redemption_window=w['issued_at'] <= now <= w['redeem_until'],
        sender_timestamp_proves_timely_spend=False, ledger_confirmed=False,
        execution_authorized=False, requirements=requirements, outstanding=outstanding,
        external_backing='UNESTABLISHED' if reservation is not True else 'ACCEPTED_UNDER_OWNER_VERIFIER_POLICY',
        history_head=state['head'], dispute_open=state['disputed'], decision=state['decision'],
        profile_version=bundle['version'], slot=slot_id(bundle),
        risk_words=bundle['terms']['risk']['words'] if successor else None,
        attachments=len(bundle['attachments']) if successor else 0)


def _latest_time(bundle):
    return max(bundle['terms']['windows']['issued_at'], bundle['events'][-1]['body']['at'] if bundle['events'] else 0)


def _core(bundle):
    """The signed record without unsigned 0.2 attachments; a 0.1 record is all core."""
    if type(bundle) is dict and bundle.get('version') == VERSION_0_2:
        return {k: v for k, v in bundle.items() if k != 'attachments'}
    return bundle


def record_id(bundle):
    if type(bundle) is dict and bundle.get('version') == VERSION_0_2:
        # Attachments are excluded: adding evidence later never changes the retained record.
        return c.digest('COVENANT-OFFLINE-TRADE-RECORD-0.2', _core(bundle))
    return c.digest('COVENANT-OFFLINE-TRADE-RECORD-0.1', bundle)


def append_event(bundle, signing_key, kind, data, *, at):
    ref = terms_id(bundle)
    c.integer(at)
    info = inspect(bundle, expected_id=ref, now=max(at, _latest_time(bundle)))
    c.need(info['agreement_state'] == 'AGREED', 'TRADE_MISSING_ASSENTS')
    # Exact retry is harmless, including after a process restart.
    actor = c.public_key(signing_key)
    for old in bundle['events']:
        b = old['body']
        if b['actor'] == actor and b['kind'] == kind and c.canonical(b['data']) == c.canonical(data) and b['at'] == at:
            return deepcopy(bundle)
    body = dict(trade=ref, sequence=len(bundle['events'])+1, previous=info['history_head'],
                actor=actor, kind=kind, data=deepcopy(data), at=at)
    out = deepcopy(bundle); out['events'].append(dict(body=body, signature=c.sign(signing_key, EVENT, body)))
    inspect(out, expected_id=ref, now=at)
    return out


def export_bundle(bundle):
    inspect(bundle, expected_id=terms_id(bundle), now=_latest_time(bundle))
    return c.canonical(bundle)


def import_bundle(raw, *, expected_id, expected_record=None, now):
    # A 0.1 record keeps its original byte bound and refusal code (OFFLINE_SIZE from
    # transport.exact_load): only canonical 0.2 bytes, whose last key is the version,
    # may use the larger bound.
    larger = type(raw) is bytes and raw.endswith(b',"version":"' + VERSION_0_2.encode() + b'"}')
    bundle = transport.exact_load(raw, MAX_BYTES_0_2 if larger else MAX_BYTES)
    inspect(bundle, expected_id=expected_id, now=now)
    if expected_record is not None:
        c.key(expected_record); c.need(record_id(bundle) == expected_record, 'TRADE_RECORD_PIN')
    return bundle


def seal_bundle(bundle, *, signing_key, recipient, shared_key, scope, created, expires):
    c.need(c.public_key(signing_key) in _parties(bundle) and recipient in _parties(bundle), 'TRADE_COURIER_PARTY')
    return transport.seal('DATA', dict(profile=bundle['version'], bytes=transport.b64(export_bundle(bundle))),
        signing_key=signing_key, recipient=recipient, shared_key=shared_key, scope=scope,
        created=created, expires=expires)


def receive_bundle(packet, *, recipient, shared_key, scope, allowed_senders, expected_id, now,
                   expected_record=None):
    payload = transport.open_packet(packet, recipient=recipient, shared_key=shared_key,
        scope=scope, allowed_senders=allowed_senders, now=now)
    _exact(payload, 'kind value'); c.need(payload['kind'] == 'DATA', 'TRADE_COURIER_KIND')
    _exact(payload['value'], 'profile bytes')
    profile = payload['value']['profile']
    c.need(profile in (VERSION, VERSION_0_2), 'TRADE_VERSION')
    value = import_bundle(transport.unb64(payload['value']['bytes'], MAX_BYTES_0_2 if profile == VERSION_0_2 else MAX_BYTES),
                          expected_id=expected_id, expected_record=expected_record, now=now)
    c.need(value['version'] == profile, 'TRADE_VERSION')
    c.need(recipient in _parties(value) and packet['header']['sender'] in _parties(value), 'TRADE_COURIER_PARTY')
    return value


class TradeStore:
    """Encrypted bounded inbox and aggregate local allocation accounting.

    The storage key and independently retained checkpoint belong to the owner.
    No local accounting can stop copies being spent at disconnected peers.
    """
    def __init__(self, directory, *, owner, scope, storage_key, retained_head=None):
        self.owner = owner
        self.vault = OfflineStore(directory, owner=owner, scope=scope,
                                  storage_key=storage_key, retained_head=retained_head)
        try:
            with self.vault._locked(): self._state()
        except BaseException:
            self.vault.close(); raise

    def _state(self):
        state = self.vault._records().get('trade-state', dict(bundles={}, allowances={}, reservations={}))
        _exact(state, 'bundles allowances reservations')
        for ref, value in state['bundles'].items():
            inspect(value, expected_id=ref, now=_latest_time(value))
        return deepcopy(state)

    def checkpoint(self): return self.vault.checkpoint()

    def adopt_allowance(self, *, issuer, reference, asset, limit, now, unit='USD_CENTS'):
        """Owner configuration of a local cap; does not establish issuer backing."""
        c.verification_key(issuer); c.key(reference); _text(asset, 256); _text(unit, 256); c.integer(limit, True)
        allowance = dict(issuer=issuer, reference=reference, asset=asset, unit=unit, limit=limit)
        token = c.digest('COVENANT-TRADE-ALLOWANCE-0.1', dict(issuer=issuer, reference=reference, asset=asset, unit=unit))
        with self.vault._locked():
            state = self._state(); self.vault._clock(now, self.vault._records())
            c.need(token not in state['allowances'] or state['allowances'][token] == allowance,
                   'TRADE_ALLOWANCE_CHANGED')
            state['allowances'][token] = allowance
            self.vault._put('trade-state', state)
        return token

    def save(self, bundle, *, expected_id, now):
        info = inspect(bundle, expected_id=expected_id, now=now)
        c.need(self.owner in _parties(bundle), 'TRADE_STORE_NOT_PARTY')
        with self.vault._locked():
            state = self._state(); self.vault._clock(now, self.vault._records())
            old = state['bundles'].get(expected_id); value = deepcopy(bundle)
            if old is not None:
                a, b = old['events'], value['events']
                c.need(c.canonical(a[:min(len(a),len(b))]) == c.canonical(b[:min(len(a),len(b))]), 'TRADE_HISTORY_FORK')
                if len(a) > len(b): value['events'] = deepcopy(a)
                signed = {r['party']: r for r in old['assents']}
                for row in value['assents']:
                    c.need(row['party'] not in signed or signed[row['party']] == row, 'TRADE_ASSENT_CONFLICT')
                    signed[row['party']] = row
                value['assents'] = [signed[k] for k in sorted(signed)]
                if value['version'] == VERSION_0_2:
                    # Same terms ID, same version: keep every distinct piece of retained evidence.
                    rows = {c.canonical(r): r for r in old['attachments'] + value['attachments']}
                    value['attachments'] = [rows[k] for k in sorted(rows)]
                info = inspect(value, expected_id=expected_id, now=now)
            c.need(expected_id in state['bundles'] or len(state['bundles']) < 16, 'TRADE_INBOX_LIMIT')
            claim = value['terms']['policy']['reservation']
            if claim is not None and info['agreement_state'] == 'AGREED':
                serial = c.digest('COVENANT-TRADE-SERIAL-0.1', {k: claim[k] for k in ('issuer','reference','serial')})
                existing = state['reservations'].get(serial)
                c.need(existing is None or existing['trade'] == expected_id, 'TRADE_SERIAL_CONFLICT')
                row = dict(trade=expected_id, amount=value['terms']['resource']['quantity'], issuer=claim['issuer'],
                           reference=claim['reference'], asset=value['terms']['resource']['asset'], unit=value['terms']['resource']['unit'])
                if self.owner == value['terms']['parties']['buyer']:
                    token = c.digest('COVENANT-TRADE-ALLOWANCE-0.1', {k: row[k] for k in ('issuer','reference','asset','unit')})
                    c.need(token in state['allowances'], 'TRADE_ALLOWANCE_NOT_ADOPTED')
                    used = sum(r['amount'] for s,r in state['reservations'].items() if s != serial and
                               all(r[k] == row[k] for k in ('issuer','reference','asset','unit')))
                    c.need(used+row['amount'] <= state['allowances'][token]['limit'], 'TRADE_AGGREGATE_ALLOWANCE')
                state['reservations'][serial] = row
            state['bundles'][expected_id] = value
            if old != value: self.vault._put('trade-state', state)
        return inspect(value, expected_id=expected_id, now=now)

    def get(self, reference):
        c.key(reference)
        with self.vault._locked():
            state = self._state(); c.need(reference in state['bundles'], 'TRADE_MISSING')
            return deepcopy(state['bundles'][reference])

    def inbox(self, *, now):
        with self.vault._locked():
            state = self._state(); self.vault._clock(now, self.vault._records())
        return [inspect(v, expected_id=k, now=now) for k,v in sorted(state['bundles'].items())]

    def close(self): self.vault.close()


def profile():
    return dict(version=VERSION, terms=TERMS, modes=list(MODES), events=list(KINDS),
        maximum_record_bytes=MAX_BYTES, maximum_events=MAX_EVENTS, maximum_inbox_trades=16,
        owner_signing_required=True, encrypted_custody=True, automatic_network_calls=False,
        external_payment_implemented=False, global_single_spend=False, current_global_revocation=False,
        historical_profiles_changed=False, successor=VERSION_0_2, successor_terms=TERMS_0_2,
        successor_record_bytes=MAX_BYTES_0_2, attachment_kinds=sorted(ATTACHMENT_LIMITS),
        loss_rules=sorted(LOSS_RULES))


def describe():
    return {**profile(), 'workflow': ['draft', 'assent', 'inspect', 'seal_bundle', 'receive_bundle',
        'TradeStore.save', 'append_event', 'export_bundle', 'import_bundle'],
        'guide': 'docs/OFFLINE_TRADE.html', 'demo': 'python -m covenant_chain.offline_trade',
        'disconnected_demo': 'python -m covenant_chain.offline_trade demo',
        'successor_workflow': ['draft', 'declare_risk', 'assent', 'attach', 'offline_trade_recovery.RecoveryInbox'],
        'execution_authorized': False}


def demo():
    import tempfile
    import secrets
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    buyer, supplier = Ed25519PrivateKey.generate(), Ed25519PrivateKey.generate()
    value = draft(agreement='1'*64, buyer=c.public_key(buyer), supplier=c.public_key(supplier),
        description='One page chart for 25 test dollars. Synthetic example; no money moves.',
        quantity=2500, issued_at=100, spend_until=200, redeem_until=400, nonce='2'*64,
        delivery_check='Buyer can reopen the supplied chart and its evidence.', delivery_due=300)
    for key in (buyer, supplier): value = assent(value, key)
    ref = terms_id(value)
    shared_key, storage_key = secrets.token_bytes(32), secrets.token_bytes(32)
    packet = seal_bundle(value, signing_key=buyer, recipient=c.public_key(supplier),
        shared_key=shared_key, scope='3'*64, created=110, expires=400)
    received = receive_bundle(packet, recipient=c.public_key(supplier), shared_key=shared_key,
        scope='3'*64, allowed_senders={c.public_key(buyer)}, expected_id=ref, now=120)
    with tempfile.TemporaryDirectory() as directory:
        store = TradeStore(directory, owner=c.public_key(supplier), scope='3'*64, storage_key=storage_key)
        store.save(received, expected_id=ref, now=120)
        received = append_event(received, supplier, 'RECIPIENT_RETAINED', {'record':record_id(received)}, at=121)
        received = append_event(received, supplier, 'DELIVERY_CLAIMED', {'evidence':'4'*64}, at=150)
        received = append_event(received, buyer, 'PAYMENT_SUBMITTED', {'effect':'5'*64,'instruction':'6'*64}, at=160)
        received = append_event(received, buyer, 'DELIVERY_ACCEPTED', {'delivery':event_id(received['events'][1])}, at=170)
        store.save(received, expected_id=ref, now=170); head = store.checkpoint(); store.close()
        store = TradeStore(directory, owner=c.public_key(supplier), scope='3'*64, storage_key=storage_key, retained_head=head)
        result = store.inbox(now=300)[0]; store.close()
    return dict(scenario='SYNTHETIC_OFFLINE_TRADE', roundtrip_same_terms=terms_id(received)==ref,
                encrypted_restart_recovered=True, final=result, real_payment=False)


if __name__ == '__main__':
    import json
    import sys
    if sys.argv[1:2] == ['demo']:
        # The disconnected journey: carriers, a conflicting spend, reconnection and reconciliation.
        from covenant_chain.offline_trade_demo import main
        raise SystemExit(main(sys.argv[2:]))
    print(json.dumps(demo(), indent=2))
