"""Arbitration clause for a drafting template.

The agent-native drafting profile can import this module and merge
``clause_for`` into a template. This branch does not edit that profile's
files. Both parties still sign the clause inside the covenant terms.
"""

PARAMETER = {
    'name': 'arbitration',
    'type': 'arbitration',
    'required': False,
    'default': None,
    'help': 'Optional panel. Both parties sign the same clause. Build it with covenant_chain.arbitration_clause.clause_for.',
}


def clause_for(mode, *, threshold, remedies, arbitrators=(), seats=None, third=None,
               third_blocks=0, category=None, min_reputation=0, strikes=(), strikes_each=0,
               body=None, evidence=('hash', 'show'), evidence_blocks=1, deliberation_blocks=1,
               vote_blocks=1, payer='split', amount=0, resource='payment', confidentiality='public',
               penalty_cap=0, appeal=None):
    """Return the ``terms['panel']`` object. It does not contact a chain."""
    from .arbitration import validate_panel
    if mode in {'named', 'tahkim'}:
        seats = len(arbitrators)
    elif mode == 'zabla':
        seats = 3
    elif seats is None:
        raise ValueError('PANEL_SEATS')
    panel = {
        'v': 'covenant-panel/1',
        'mode': mode,
        'threshold': threshold,
        'scope': {'remedies': sorted(set(remedies)), 'penalty_cap': penalty_cap},
        'evidence': {'formats': sorted(set(evidence))},
        'stages': {'evidence_blocks': evidence_blocks, 'deliberation_blocks': deliberation_blocks,
                   'vote_blocks': vote_blocks},
        'fees': {'payer': payer, 'amount': amount, 'resource': resource},
        'confidentiality': confidentiality,
        'on_miss': 'silent_refund',
        'appeal': appeal,
        'selection': {
            'arbitrators': sorted(arbitrators), 'third': third, 'third_blocks': third_blocks,
            'category': category, 'min_reputation': min_reputation, 'strikes': sorted(strikes),
            'strikes_each': strikes_each, 'body': body, 'seats': seats,
        },
    }
    return validate_panel(panel)
