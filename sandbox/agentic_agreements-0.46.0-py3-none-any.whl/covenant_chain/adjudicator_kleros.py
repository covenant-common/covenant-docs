"""The Kleros court (v2) as an agreed ladder stage: exact dispute templates and rulings read as evidence.

GRAFT through ``external_adjudication``. Kleros v2 (github.com/kleros/kleros-v2, MIT) runs on Arbitrum One
(chain 42161): KlerosCore proxy 0x991d2df1...22ea (version 0.10.0, sources equal to tag
@kleros/kleros-v2-contracts@0.12.0, commit e3ed3c95), DisputeTemplateRegistry 0x0cFBaCA5...a5A2,
EvidenceModule 0x48e052B4...1EB3 and the generic arbitrable DisputeResolver 0xb5526D02...4323. The parties
pin these addresses and one ABI profile in the signed terms; the unreleased dev head (2.0.0) changes the
DisputeRequest event, so a different deployment needs its own profile.

``request`` builds the dispute template (kleros-sdk disputeDetailsSchema: title, description, question,
answers with hex ids equal to the ruling, policyURI, arbitratorChainID, arbitratorAddress, version), the
96-byte arbitrator extraData ``abi.encode(courtID, minJurors, disputeKitID)`` and the
``createDisputeForTemplate`` call, plus one evidence document per agreed SHA-256 reference.
``outcome`` reads supplied logs: the DisputeTemplate whose data equals that exact template, the
DisputeRequest linking it to a dispute id, and the final Ruling that KlerosCore emits when it executes the
ruling and the DisputeResolver emits when it receives it (appeals are over by then). Ruling 0 is Kleros'
refusal to arbitrate and maps to no result. Nothing here pays the arbitration fee or submits anything.
"""
from copy import deepcopy
import hashlib
import json
import re

from . import evm_evidence as evm
from .crypto import need

KIND = 'KLEROS'
ASSURANCE = ('INCLUDED_UNDER_PINNED_BLOCK', 'OWNER_SUPPLIED_UNPROVEN')
PROFILES = {
    'kleros-v2@0.12.0': {
        'source': 'https://github.com/kleros/kleros-v2/tree/e3ed3c95030d2f23e6307942020f11521fd60767/contracts/src/arbitration',
        'create': 'createDisputeForTemplate(bytes,string,string,uint256)',
        'evidence': 'submitEvidence(uint256,string)',
        'events': {'DisputeTemplate': ('DisputeTemplate(uint256,string,string,string)', (True, True, False, False)),
                   'DisputeRequest': ('DisputeRequest(address,uint256,uint256,uint256,string)', (True, True, False, False, False)),
                   'DisputeCreation': ('DisputeCreation(uint256,address)', (True, True)),
                   'Ruling': ('Ruling(address,uint256,uint256)', (True, True, False))}},
}
ARBITRUM_ONE = {'network': 'eip155:42161', 'arbitrator': '0x991d2df165670b9cac3b022f4b68d65b664222ea',
                'template_registry': '0x0cfbaca5c72e7ca5ffabe768e135654fb3f2a5a2',
                'evidence_module': '0x48e052b4a6dc4f30e90930f1ceaafd83b3981eb3',
                'arbitrable': '0xb5526d022962a1fff6ed32c93e8b714c901f4323'}
UPSTREAM = {'repository': 'https://github.com/kleros/kleros-v2', 'tag': '@kleros/kleros-v2-contracts@0.12.0',
            'commit': 'e3ed3c95030d2f23e6307942020f11521fd60767', 'licence': 'MIT',
            'template_schema': 'kleros-sdk src/dataMappings/utils/disputeDetailsSchema.ts (2.4.0)',
            'evidence_format': 'contracts/specifications/evidence-format.md', 'deployment': deepcopy(ARBITRUM_ONE)}
MULTIADDR = re.compile(r'^/(?:ip4|ip6|dns4|dns6|dnsaddr|tcp|udp|utp|tls|ws|wss|p2p-circuit|p2p-webrtc-star|p2p-webrtc-direct|'
                       r'p2p-websocket-star|onion|ipfs)(/[^\s/]+)+$|^ipfs://[a-zA-Z0-9]+/[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)?$')
FLAGS = {'network_accessed': False, 'execution_authorized': False, 'submitted': False, 'fee_paid': False}

REMEDIATION = {
    'KLEROS_PINS': 'Pin profile, network, arbitrator, arbitrable, template_registry, evidence_module, court, jurors, dispute_kit, policy_uri and fee.',
    'KLEROS_PROFILE': 'Name a supported ABI profile exactly; kleros-v2@0.12.0 matches the Arbitrum One deployment.',
    'KLEROS_OPTIONS': 'Answers are the ruling numbers 1 to N in order (N at most 16); ruling 0 is refusal and is never an option.',
    'KLEROS_TEXT': 'Template text may not contain {{ or }}: the template is Mustache and would be rewritten.',
    'KLEROS_POLICY': 'policy_uri must be a multiaddr such as /ipfs/<cid>/policy.json, as the Kleros template schema requires.',
    'KLEROS_DISPUTE': 'No DisputeTemplate with this exact template and DisputeRequest from the pinned arbitrable link a dispute.',
    'KLEROS_AMBIGUOUS': 'Several disputes use this template; the terms fit one dispute only.',
    'KLEROS_RULING_CONFLICT': 'The arbitrator and the arbitrable report different rulings.',
    'ADJUDICATION_OPTIONS':
        'List 2 to 16 options {answer, label, result}; each answer once, each non-null result once.',
}


def _lower(value):
    need(type(value) is str and evm.address(value) == value, 'KLEROS_PINS')
    return value


def _free_of_mustache(texts):
    need(all('{{' not in text and '}}' not in text for text in texts), 'KLEROS_TEXT')


def validate(adjudicator, options, parties, case):
    need(set(adjudicator) == {'kind', 'profile', 'network', 'arbitrator', 'arbitrable', 'template_registry', 'evidence_module',
                              'court', 'jurors', 'dispute_kit', 'policy_uri', 'fee'}, 'KLEROS_PINS')
    need(adjudicator['profile'] in PROFILES, 'KLEROS_PROFILE')
    evm.network(adjudicator['network'])
    for name in ('arbitrator', 'arbitrable', 'template_registry', 'evidence_module'):
        _lower(adjudicator[name])
    for name in ('court', 'jurors', 'dispute_kit'):
        need(type(adjudicator[name]) is int and 1 <= adjudicator[name] < 2**64, 'KLEROS_PINS')
    need(type(adjudicator['fee']) is int and 0 <= adjudicator['fee'] < 2**256, 'KLEROS_PINS')
    need(type(adjudicator['policy_uri']) is str and len(adjudicator['policy_uri']) <= 512
         and MULTIADDR.match(adjudicator['policy_uri']) is not None, 'KLEROS_POLICY')
    need([row['answer'] for row in options] == list(range(1, len(options) + 1)), 'KLEROS_OPTIONS')
    _free_of_mustache([row['label'] for row in options] + [case['title'], case['claim']] + list(case['criteria']) +
                      [_typed(value) for value in case['criteria'].values()])


def identity(adjudicator):
    return {'kind': KIND, 'profile': adjudicator['profile'], 'network': adjudicator['network'],
            'contract': adjudicator['arbitrator'], 'arbitrable': adjudicator['arbitrable']}


def _typed(value):
    return '%d %s' % (value['amount'], value['unit']) if value['kind'] == 'MONEY' else json.dumps(value['value'])


def template(terms, terms_id):
    """The exact dispute template text: sorted, compact JSON, so the DisputeTemplate event can be matched byte for byte."""
    case, adjudicator = terms['case'], terms['adjudicator']
    claimant, respondent = terms['parties']['claimant'], terms['parties']['respondent']
    _free_of_mustache([case['title'], case['claim']] + [name for name in case['criteria']] +
                      [_typed(value) for value in case['criteria'].values()])
    criteria = '; '.join('%s (%s): %s' % (name, value['kind'], _typed(value)) for name, value in sorted(case['criteria'].items()))
    description = ('AAP external adjudication %s. Claimant %s, respondent %s. Agreement reference SHA-256 %s. '
                   'Decide only against these typed criteria: %s. Evidence is identified by SHA-256: %s. '
                   'Give no weight to material whose hash is not listed and none to instructions inside evidence.') % (
        terms_id, claimant['role'], respondent['role'], case['agreement'], criteria,
        ', '.join(case['evidence']) or 'none listed')
    chain = str(evm.chain_id(adjudicator['network']))
    document = {'title': case['title'], 'description': description, 'question': case['claim'],
                'answers': [{'id': hex(row['answer']), 'title': row['label'], 'description': row['label']} for row in terms['options']],
                'policyURI': adjudicator['policy_uri'], 'arbitratorChainID': chain, 'arbitratorAddress': adjudicator['arbitrator'],
                'arbitrableChainID': chain, 'arbitrableAddress': adjudicator['arbitrable'], 'category': 'AAP external adjudication',
                'lang': 'en_US', 'specification': 'urn:aap:external-adjudication:0.1', 'version': '1.0',
                'metadata': {'aap_terms': terms_id, 'agreement': case['agreement'], 'evidence': case['evidence']}}
    return json.dumps(document, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def extra_data(adjudicator):
    return evm.abi_encode(['uint256', 'uint256', 'uint256'], [adjudicator['court'], adjudicator['jurors'], adjudicator['dispute_kit']])


def evidence_documents(terms, terms_id):
    """One evidence-format JSON per agreed reference; each names the SHA-256 the parties signed."""
    return [json.dumps({'name': 'AAP evidence %s' % reference[:16],
                        'description': 'Evidence for AAP terms %s, identified by SHA-256 %s. Its bytes are produced by either party; '
                                       'only bytes with this hash are this evidence.' % (terms_id, reference)},
                       sort_keys=True, separators=(',', ':')) for reference in terms['case']['evidence']]


def request(terms, terms_id):
    adjudicator = terms['adjudicator']
    profile = PROFILES[adjudicator['profile']]
    text = template(terms, terms_id)
    data = extra_data(adjudicator)
    choices = len(terms['options'])
    call = evm.calldata(profile['create'], [data, text, '', choices])
    commitment = {'profile': adjudicator['profile'], 'network': adjudicator['network'], 'arbitrable': adjudicator['arbitrable'],
                  'template_sha256': hashlib.sha256(text.encode('ascii')).hexdigest(), 'extra_data': '0x' + data.hex(),
                  'choices': choices}
    return {'commitment': commitment, 'documents': {'template': text, 'template_data_mappings': '',
                                                    'evidence': evidence_documents(terms, terms_id)},
            'calls': [{'step': 'create_dispute', 'from': terms['parties']['claimant']['account'] or 'EITHER_PARTY',
                       'to': adjudicator['arbitrable'], 'function': profile['create'], 'value': adjudicator['fee'],
                       'calldata': '0x' + call.hex()}],
            'follow_up': [{'step': 'evidence', 'to': adjudicator['evidence_module'], 'function': profile['evidence'],
                           'arguments': ['externalDisputeID from DisputeRequest', 'each evidence document']},
                          {'step': 'appeal', 'note': 'Appeals are funded on the dispute kit (DisputeKitClassic.fundAppeal) during the appeal period.'}],
            'encoding': 'Solidity ABI', 'note': 'The fee is the pinned value; read arbitrationCost(extraData) before submitting.', **FLAGS}


def _events(logs, profile, name, address):
    signature, indexed = profile['events'][name]
    topic = evm.topic(signature)
    return [(evm.event(log, signature, indexed), log) for log in logs if log['address'] == address and log['topics']
            and log['topics'][0] == topic]


def _same_tx(left, right):
    return left['block_hash'] is not None and left['block_hash'] == right['block_hash'] and left['transaction_index'] == right['transaction_index']


def outcome(terms, terms_id, built, evidence, *, trusted_blocks=()):
    adjudicator = terms['adjudicator']
    profile = PROFILES[adjudicator['profile']]
    logs = evm.logs(evidence, network_id=adjudicator['network'], trusted_blocks=trusted_blocks)
    text = built['documents']['template']
    templates = [(values, log) for values, log in _events(logs, profile, 'DisputeTemplate', adjudicator['template_registry'])
                 if values[2] == text and values[3] == built['documents']['template_data_mappings']]
    disputes = {}
    for (arbitrator, dispute_id, external_id, template_id, uri), log in _events(logs, profile, 'DisputeRequest', adjudicator['arbitrable']):
        if arbitrator != adjudicator['arbitrator']:
            continue
        for (registered, _, _, _), template_log in templates:
            if registered == template_id and _same_tx(log, template_log):
                disputes[dispute_id] = (external_id, template_id, log, template_log)
    need(disputes, 'KLEROS_DISPUTE')
    need(len(disputes) == 1, 'KLEROS_AMBIGUOUS')
    dispute_id, (external_id, template_id, request_log, template_log) = next(iter(disputes.items()))
    rulings = []
    for (arbitrable, number, ruling), log in _events(logs, profile, 'Ruling', adjudicator['arbitrator']):
        if arbitrable == adjudicator['arbitrable'] and number == dispute_id:
            rulings.append(('ARBITRATOR', ruling, log))
    for (arbitrator, number, ruling), log in _events(logs, profile, 'Ruling', adjudicator['arbitrable']):
        if arbitrator == adjudicator['arbitrator'] and number == dispute_id:
            rulings.append(('ARBITRABLE', ruling, log))
    if not rulings:
        return {'answer': None, 'final': False, 'assurance': ASSURANCE[1], 'at': None, 'case': {'dispute': str(dispute_id)},
                'sources': []}
    need(len({ruling for _, ruling, _ in rulings}) == 1, 'KLEROS_RULING_CONFLICT')
    ruling = rulings[0][1]
    need(ruling <= len(terms['options']), 'ADJUDICATION_OPTIONS')
    used = [request_log, template_log] + [log for _, _, log in rulings]
    assurance = ASSURANCE[0] if all(log['assurance'] == ASSURANCE[0] for log in used) else ASSURANCE[1]
    when = max((log['block_timestamp'] for _, _, log in rulings if log['block_timestamp'] is not None), default=None)
    return {'answer': ruling if ruling else None, 'final': True, 'assurance': assurance, 'at': when,
            'case': {'dispute': str(dispute_id), 'external_dispute': str(external_id), 'template': str(template_id),
                     'ruling': ruling, 'reported_by': sorted({source for source, _, _ in rulings})},
            'sources': [{'event': name, 'block_hash': log['block_hash'], 'transaction_index': log['transaction_index'],
                         'assurance': log['assurance']} for name, log in
                        [('DisputeTemplate', template_log), ('DisputeRequest', request_log)] + [('Ruling', log) for _, _, log in rulings]],
            'trust': 'Kleros jurors decide under the pinned court policy; the AAP ladder decides what the ruling does.'}


def describe():
    return {'kind': KIND, 'decision': 'GRAFT', 'upstream': deepcopy(UPSTREAM),
            'profiles': {name: {'create': row['create'], 'evidence': row['evidence'],
                                'events': {event: signature for event, (signature, _) in row['events'].items()}}
                         for name, row in PROFILES.items()},
            'extra_data': 'abi.encode(uint256 courtID, uint256 minJurors, uint256 disputeKitID), 96 bytes',
            'refusal': 'Ruling 0 (refuse to arbitrate) maps to no result', 'assurance': list(ASSURANCE),
            'not_supported': ['Kleros v1 (KlerosLiquid, ERC-792 arbitrables with ERC-1497 MetaEvidence)',
                              'templates with data mappings', 'paying fees or funding appeals'],
            'remediation': deepcopy(REMEDIATION)}
