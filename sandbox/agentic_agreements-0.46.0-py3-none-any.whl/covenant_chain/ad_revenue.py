"""Protocol-side hook for a separate ads agent.

This module does not rank discovery, score bids, or run an auction. The ads
agent prices the campaign. When a covenant is honoured it can ask this hook
how the cost-per-action splits, and which leg is the protocol fee subsidy.
The subsidy leg is the only amount this profile will accept on chain.
"""
from .crypto import exact, integer, key, need
from .kept_promises import honoured, honoured_rows
from .tokenomics_config import AD_SHARE_VERSION, apportion

DEFAULT_SPLIT = {'owner_bps': 3000, 'integrator_bps': 2500, 'subsidy_bps': 1000, 'exchange_bps': 3500}
PARTIES = ('owner', 'integrator', 'subsidy', 'exchange')


def split_cpa(amount, shares=None):
    """Illustrative default: owner 30, integrator 25, fee subsidy 10, exchange 35."""
    integer(amount)
    shares = dict(DEFAULT_SPLIT if shares is None else shares)
    weights = []
    for name in PARTIES:
        value = shares[name + '_bps']
        integer(value)
        need(value <= 10000, 'AD_SPLIT')
        weights.append(value)
    need(sum(weights) == 10000, 'AD_SPLIT')
    parts = apportion(amount, weights) if amount else [0, 0, 0, 0]
    split = {name: value for name, value in zip(PARTIES, parts)}
    split.update(amount=amount, version=AD_SHARE_VERSION, fee_rebate_pool=split['subsidy'],
                 auction='NOT_IMPLEMENTED_INTERFACE_ONLY', execution_authorized=False,
                 paid_ranking='NOT_THIS_INTERFACE')
    return split


def assess_conversion(state, receipt, shares=None, min_counterparties=2):
    """Refuse the subsidy unless the covenant was kept and the owner has real counterparties."""
    exact(receipt, 'version ad_id covenant advertiser owner integrator exchange amount resource height')
    need(receipt['version'] == AD_SHARE_VERSION, 'AD_SHARE_VERSION')
    for field in ('ad_id', 'covenant', 'advertiser', 'owner', 'integrator', 'exchange'):
        key(receipt[field])
    need(type(receipt['resource']) is str and 0 < len(receipt['resource']) <= 80, 'AD_RESOURCE')
    integer(receipt['amount'], True)
    integer(receipt['height'])
    integer(min_counterparties, True)
    agreement = state['agreements'][receipt['covenant']]
    need(honoured(agreement), 'AD_COVENANT_NOT_HONOURED')
    terms = agreement['terms']
    need(terms['principal'] != terms['counterparty'] and terms['agent'] != terms['counterparty'], 'AD_SELF_DEAL')
    need(receipt['owner'] in {terms['principal'], terms['agent']}, 'AD_OWNER')
    rows = [row for row in honoured_rows(state, receipt['height'])
            if receipt['owner'] in {row['principal'], row['agent']}]
    distinct = {row['counterparty'] for row in rows if row['counterparty'] != receipt['owner']}
    need(len(distinct) >= min_counterparties, 'AD_DIVERSITY')
    split = split_cpa(receipt['amount'], shares)
    split.update(covenant=receipt['covenant'], owner=receipt['owner'], integrator=receipt['integrator'],
                 exchange=receipt['exchange'], advertiser=receipt['advertiser'],
                 subsidy_purpose='FEE_REBATE', distinct_counterparties=len(distinct))
    return split
