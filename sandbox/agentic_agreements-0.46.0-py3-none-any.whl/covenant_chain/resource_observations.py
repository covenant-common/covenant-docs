"""Adopted sensor/API observations bound to exact resources and queries.

Connectors are owner-installed Python objects, never a URL/import from an agent.
Observations can support an agreed predicate; their signer still supplies the
measurement and does not thereby establish legal title or physical truth.
"""
from copy import deepcopy
import hashlib,json,time
from covenant_language.agentic import canonical as content
from covenant_language.market_blueprints import validate_asset
from .crypto import canonical,digest,exact,key,integer,need,public_key,sign,verify
from .adapters import RecordAdapter,manifest_id
VERSION='covenant-resource-observation/0.1'
LABEL='COVENANT-RESOURCE-OBSERVATION-0.1'

def resource_id(asset):validate_asset(asset);return hashlib.sha256(b'COVENANT-RESOURCE-0.1\0'+content(asset)).hexdigest()
def query_id(query):need(type(query) is dict,'RESOURCE_QUERY');return hashlib.sha256(b'COVENANT-RESOURCE-QUERY-0.1\0'+content(query)).hexdigest()

def verify_observation(envelope,expected_asset,expected_query,expected_context,expected_source,expected_key,now,max_age,predicate=None):
    exact(envelope,'body signature');b=envelope['body'];exact(b,'version source context asset query observed_at reported_at source_key payload')
    need(b['version']==VERSION,'RESOURCE_OBSERVATION_VERSION');key(expected_context);key(expected_source)
    need(b['source']==expected_source and b['context']==expected_context and b['asset']==resource_id(expected_asset) and b['query']==query_id(expected_query)
        and canonical(b['source_key'])==canonical(expected_key),'RESOURCE_EXPECTATION_MISMATCH')
    verify(expected_key,LABEL,b,envelope['signature']);integer(now);integer(max_age);integer(b['observed_at']);integer(b['reported_at'])
    need(type(b['payload']) is str and len(b['payload'])<=16384,'RESOURCE_OBSERVATION_SIZE')
    try:raw=bytes.fromhex(b['payload']);value=json.loads(raw)
    except (ValueError,UnicodeError):raise ValueError('RESOURCE_OBSERVATION_ENCODING') from None
    need(content(value)==raw,'RESOURCE_OBSERVATION_ENCODING');exact(value,'status claim evidence')
    need(value['status'] in {'VALUE','UNKNOWN'} and type(value['claim']) is dict and type(value['evidence']) is list and len(value['evidence'])<=32,'RESOURCE_OBSERVATION_SCHEMA')
    for e in value['evidence']:key(e)
    fresh=b['observed_at']<=b['reported_at']<=now and now-b['observed_at']<=max_age
    status='UNKNOWN' if not fresh or value['status']=='UNKNOWN' else 'OBSERVED'
    if predicate is not None:
        exact(predicate,'field operator value');need(type(predicate['field']) is str and predicate['operator'] in {'EQ','GE','GT','LE','LT'},'RESOURCE_PREDICATE')
        v=value['claim'].get(predicate['field']);expected=predicate['value']
        need(type(expected) is int and abs(expected)<=2**53-1,'RESOURCE_PREDICATE_INTEGER')
        if status=='OBSERVED' and type(v) is int:
            status='SATISFIED' if {'EQ':v==expected,'GE':v>=expected,'GT':v>expected,'LE':v<=expected,'LT':v<expected}[predicate['operator']] else 'UNSATISFIED'
        else:status='UNKNOWN'
    return {'status':status,'observation':digest(LABEL,b),'source_signature_verified':True,'resource':b['asset'],'claim':value['claim'],
        'fresh_at_asserted_time':fresh,'time_assurance':'RECIPIENT_SUPPLIED_TIME_AND_FRESHNESS_POLICY','source_measurement_truth':'NOT_INDEPENDENTLY_ESTABLISHED',
        'legal_title_or_custody':'ONLY_WHERE_EXPLICITLY_CLAIMED_AND_SEPARATELY_ADOPTED','execution_authorized':False}

class ResourceObservationAdapter:
    """Concrete connector harness recording one signed result per effect ID.

    Callback takes exact resource/query and effect ID, returns status, claim,
    evidence and observed_at. It owns real API authentication, source policy,
    timeouts and acquisition idempotence. After a recorded reply, retries only
    observe. An interruption before recording can repeat read acquisition.
    """
    def __init__(self,directory,source_manifest,private_key,callback,clock=None,max_bytes=65536):
        need(type(source_manifest) is dict and callable(callback),'RESOURCE_CONNECTOR')
        self.source_manifest=deepcopy(source_manifest);self.source=digest('COVENANT-RESOURCE-SOURCE-0.1',source_manifest)
        self.key=private_key;self.callback=callback;self.clock=clock or (lambda:int(time.time()))
        self.record=RecordAdapter(directory,'resource-observations',max_bytes)
        self.manifest=deepcopy(self.record.manifest);self.manifest.update(name='resource-observation-connector',capability='resource.observe',effect='SIGNED_SOURCE_OBSERVATION_LOCAL_RECORD')
        self.manifest['requirements']['source']=self.source;self.manifest['requirements']['source_key']=public_key(private_key)
    def execute(self,effect_id,request,*,crash=None):
        exact(request,'asset query context');key(request['context']);resource=resource_id(request['asset']);query=query_id(request['query'])
        raw=content(request);need(len(raw)<=self.manifest['max_bytes'],'ADAPTER_INPUT_SIZE');intent=hashlib.sha256(raw).hexdigest()
        old=self.observe(effect_id)
        if old['status']=='OBSERVED':need(old['value']['intent']==intent,'RESOURCE_REQUEST_CHANGED');return old
        reading=dict(self.callback(deepcopy(request['asset']),deepcopy(request['query']),effect_id))
        exact(reading,'status claim evidence observed_at');integer(reading['observed_at'])
        need(reading['status'] in {'VALUE','UNKNOWN'} and type(reading['claim']) is dict and type(reading['evidence']) is list and len(reading['evidence'])<=32,'RESOURCE_OBSERVATION_SCHEMA')
        from .geo_fix import normalize_claim
        reading['claim']=normalize_claim(reading['claim'])
        for e in reading['evidence']:key(e)
        payload=content({k:v for k,v in reading.items() if k!='observed_at'});need(len(payload)<=8192,'RESOURCE_OBSERVATION_SIZE')
        reported=self.clock();integer(reported);need(reading['observed_at']<=reported,'RESOURCE_FUTURE_OBSERVATION')
        body={'version':VERSION,'source':self.source,'context':request['context'],'asset':resource,'query':query,'observed_at':reading['observed_at'],
            'reported_at':reported,'source_key':public_key(self.key),'payload':payload.hex()}
        value={'intent':intent,'observation':{'body':body,'signature':sign(self.key,LABEL,body)},'source_manifest':deepcopy(self.source_manifest)}
        self.record.execute(effect_id,value,crash=crash);return self.observe(effect_id)
    def observe(self,effect_id):
        value=self.record.observe(effect_id)
        if value['status']=='OBSERVED':value['assurance']='SIGNED_ADOPTED_SOURCE_CLAIM_NOT_INDEPENDENT_PHYSICAL_TRUTH'
        return value
    def close(self):self.record.close()


def sla_event(policy,observations,now,signing_key,*,enabled=False):
    """Host-signed SLA view of verified observation envelopes (sla_view.evaluate). Experimental, off by default."""
    from .sla_view import evaluate
    return evaluate(policy,observations,now,signing_key,enabled=enabled)
_PAID = frozenset({'released', 'paid', 'Paid', 'PAID', 'RELEASED'})
_CLOSED = frozenset({'refunded', 'disputed', 'Refunded', 'Disputed', 'REFUNDED', 'DISPUTED'})


def settlement_paid(claim):
    """Whether a decoded settlement claim counts as paid.

    Released or paid counts. Refunded or disputed does not (REFUNDED_OR_DISPUTED).
    UNKNOWN, or a claim still inside its reorg depth, stays UNKNOWN. Anything else
    is UNPAID. A signed observation of the claim is still the source's statement.
    """
    need(type(claim) is dict, 'SETTLEMENT_CLAIM')
    status = claim.get('status') if type(claim.get('status')) is str else None
    if status in _CLOSED:
        paid, reason = False, 'REFUNDED_OR_DISPUTED'
    elif status == 'UNKNOWN' or claim.get('reorg') is True:
        paid, reason = False, 'UNKNOWN'
    elif status in _PAID:
        paid, reason = True, 'PAID'
    else:
        paid, reason = False, 'UNPAID'
    return {'paid': paid, 'reason': reason, 'status': status, 'execution_authorized': False}
