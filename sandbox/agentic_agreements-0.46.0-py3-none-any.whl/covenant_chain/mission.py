"""Explicitly adopted native 0.6: two-sided capacity commitments and recurring leases.

Scarce capacity means ledger units, not proof of physical availability. Signatures
establish assent to an exact procedure. Practice references do not execute code.
"""
from .profile import MIGRATION_VERSION
from copy import deepcopy
from .crypto import exact,need,key,integer
from .ecosystem import governed,authorized,move,role_path
TABLES=('service_offers','service_jobs','practice_anchors')

def _asset(s,r):need(type(r) is str and r in s['resources'],'SERVICE_RESOURCE')
def _quantity(q,positive=False):integer(q,positive)
def _finish(s,j,units,tid):
    from .app import add
    paid=units*j['unit_price'];refund=j['quantity']-paid
    if paid:move(s,j['payment_escrow'],j['provider'],j['settlement_resource'],paid)
    if refund:move(s,j['payment_escrow'],j['world'],j['settlement_resource'],refund)
    consumed=units if j['capacity_mode']=='CONSUME_DELIVERED' else 0
    if consumed:
        for table in ('balances','authority_available'):add(s[table],j['capacity_escrow'],j['capacity_resource'],-consumed)
        s['consumed'][j['capacity_resource']]+=consumed
    if j['units']>consumed:move(s,j['capacity_escrow'],j['provider'],j['capacity_resource'],j['units']-consumed)
    j.update(state='SETTLED',delivered=units,settlement=tid)

def apply(s,old,op,p,actor,tid,height):
    # Canonical JSON admits structured values; reject them before hash-table
    # lookup so malformed signed inputs produce bounded validation failures.
    reference_fields={
        'WORLD_FAILOVER':('role',),'WORLD_MERGE':('world','other','target'),
        'PRACTICE_ANCHOR':('reference','scope'),
        'SERVICE_OFFER':('capacity_resource','settlement_resource','capacity_mode'),
        'SERVICE_BOOK':('offer','uncertainty'),
        'SERVICE_DECIDE':('job','outcome'),'SERVICE_APPEAL':('job','outcome'),
        'SERVICE_CHALLENGE':('job',),'SERVICE_SETTLE':('job',),
        'SERVICE_TIMEOUT':('job',),'SERVICE_DISCHARGE':('job',),
        'WORLD_RECOVERY_LEASE':('resource',),'WORLD_RECOVER':('role',)}
    for field in reference_fields.get(op,()):
        if field in p:need(type(p[field]) is str,'REFERENCE_TYPE')
    if op=='PRACTICE_ANCHOR' and p.get('parent') is not None:need(type(p['parent']) is str,'REFERENCE_TYPE')
    if op=='SERVICE_OFFER' and p.get('practice') is not None:need(type(p['practice']) is str,'REFERENCE_TYPE')
    if op in {'WORLD_HIRE','WORLD_RESOLVE','WORLD_TIMEOUT'}:
        from .world_migration import is_migrated
        if op=='WORLD_HIRE' or not is_migrated(s,p.get('job')):
            raise ValueError('SERVICE_PROFILE_REQUIRED')
    if op=='WORLD_FAILOVER' and type(p.get('role')) is str and p['role'] in s['world_roles']:
        need('successors' not in s['world_roles'][p['role']],'USE_WORLD_RECOVER')
    if op=='WORLD_MERGE':
        sources={p.get('world'),p.get('other')}
        need(all(j['world'] not in sources or j['state'] in {'SETTLED','TIMED_OUT'} for j in s['service_jobs'].values()),'WORLD_OPEN_LIABILITIES')
    if op=='PRACTICE_ANCHOR':
        exact(p,'reference parent scope');from covenant_language.agentic import _hash
        _hash(p['reference']);_hash(p['scope'])
        if p['parent'] is not None:need(p['parent'] in s['practice_anchors'],'PRACTICE_PARENT')
        need(p['reference'] not in s['practice_anchors'],'PRACTICE_EXISTS')
        s['practice_anchors'][p['reference']]={**deepcopy(p),'publisher':actor,'event':tid}
        return [] if p['parent'] is None else [s['practice_anchors'][p['parent']]['event']]
    if op=='SERVICE_OFFER':
        exact(p,'capability capacity_resource capacity_mode settlement_resource unit_price expiry terms practice')
        need(type(p['capability']) is str and 0<len(p['capability'])<=80,'SERVICE_CAPABILITY')
        _asset(s,p['capacity_resource']);_asset(s,p['settlement_resource']);_quantity(p['unit_price']);_quantity(p['expiry'],True);key(p['terms'])
        need(p['capacity_resource']!=p['settlement_resource'] and height<p['expiry'],'SERVICE_SCOPE')
        need(p['capacity_mode'] in {'RELEASE','CONSUME_DELIVERED'},'CAPACITY_MODE')
        if p['practice'] is not None:need(p['practice'] in s['practice_anchors'],'PRACTICE_MISSING')
        s['service_offers'][tid]={**deepcopy(p),'provider':actor};return []
    if op=='SERVICE_BOOK':
        exact(p,'world revision approvals offer units resolver appeal_resolver deadline challenge_blocks appeal_blocks uncertainty')
        w=governed(s,p,op);need(p['offer'] in s['service_offers'],'SERVICE_OFFER_MISSING');o=s['service_offers'][p['offer']]
        _quantity(p['units'],True);_quantity(p['deadline'],True);_quantity(p['challenge_blocks']);_quantity(p['appeal_blocks'],True)
        need(p['challenge_blocks']<=10000 and p['appeal_blocks']<=10000 and height<p['deadline']<=o['expiry'],'SERVICE_DEADLINE')
        from .governance import admission_paused
        need(not admission_paused(s,'SERVICE_BOOK'),'NEW_AGREEMENTS_PAUSED')
        allowed={'REFUND','HOLD','WAIT_FOREVER'} if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} else {'REFUND','HOLD'}
        key(p['resolver']);need(p['uncertainty'] in allowed,'UNCERTAINTY_POLICY')
        forbidden={o['provider'],p['world']}|set(w['seed']['governors']);need(p['resolver'] not in forbidden,'SERVICE_RESOLVER_CONFLICT')
        required=[o['provider'],p['resolver']]
        if p['challenge_blocks']:
            key(p['appeal_resolver']);need(p['appeal_resolver'] not in forbidden|{p['resolver']},'SERVICE_APPEAL_CONFLICT');required.append(p['appeal_resolver'])
        else:need(p['appeal_resolver'] is None,'SERVICE_APPEAL_POLICY')
        # The provider and every appointed adjudicator accept the same exact job,
        # revision and procedure as the customer's governing quorum.
        authorized(s,required,len(required),p['approvals'],op,p)
        from .crypto import digest
        pay=digest('COVENANT-SERVICE-PAYMENT-0.6',tid);cap=digest('COVENANT-SERVICE-CAPACITY-0.6',tid)
        quantity=p['units']*o['unit_price'];_quantity(quantity)
        if quantity:move(s,p['world'],pay,o['settlement_resource'],quantity)
        move(s,o['provider'],cap,o['capacity_resource'],p['units'])
        s['service_jobs'][tid]={**deepcopy(p),**{k:deepcopy(o[k]) for k in ('provider','capacity_resource','capacity_mode','settlement_resource','unit_price','terms','practice')},'approvals':deepcopy(p['approvals']),'quantity':quantity,'payment_escrow':pay,'capacity_escrow':cap,'state':'BOOKED','decision':None,'delivered':None,'settlement':None,'standing':sorted(set(w['members'])|{o['provider']})}
        from .governance import pin_rules
        pin_rules(s,s['service_jobs'][tid])
        w['revision']+=1;return [p['world'],p['offer']]
    if op in {'SERVICE_DECIDE','SERVICE_APPEAL'}:
        exact(p,'job outcome units evidence');need(p['job'] in s['service_jobs'],'SERVICE_JOB');j=s['service_jobs'][p['job']]
        appeal=op=='SERVICE_APPEAL'
        need(actor==j['appeal_resolver' if appeal else 'resolver'],'SERVICE_JUDGE')
        need(j['state']==('DISPUTED' if appeal else 'BOOKED'),'SERVICE_STATE')
        need(height<=j['appeal_deadline' if appeal else 'deadline'],'SERVICE_LATE_DECISION')
        need(p['outcome'] in {'SUPPORTED','REFUTED','INDETERMINATE'},'SERVICE_OUTCOME');_quantity(p['units']);key(p['evidence'])
        need(p['units']<=j['units'] and (p['outcome']=='SUPPORTED' or p['units']==0),'SERVICE_METER')
        j['decision']={**deepcopy(p),'actor':actor,'height':height,'event':tid};j['state']='APPEALED' if appeal else 'PROVISIONAL';j['final_after']=height if appeal else height+j['challenge_blocks']
        return [p['job']]
    if op=='SERVICE_CHALLENGE':
        exact(p,'job evidence');need(p['job'] in s['service_jobs'],'SERVICE_JOB');j=s['service_jobs'][p['job']];key(p['evidence'])
        need(j['state']=='PROVISIONAL' and j['challenge_blocks']>0 and height<=j['final_after'],'SERVICE_CHALLENGE_WINDOW')
        need(actor in j['standing'],'SERVICE_CHALLENGE_STANDING');j.update(state='DISPUTED',challenge={'actor':actor,'evidence':p['evidence'],'event':tid},appeal_deadline=height+j['appeal_blocks'])
        return [p['job'],j['decision']['event']]
    if op=='SERVICE_SETTLE':
        exact(p,'job');need(p['job'] in s['service_jobs'],'SERVICE_JOB');j=s['service_jobs'][p['job']]
        need(j['state'] in {'PROVISIONAL','APPEALED'} and height>j['final_after'],'SERVICE_NOT_FINAL')
        need(j['decision']['outcome']!='INDETERMINATE' or j['uncertainty']=='REFUND','SERVICE_UNCERTAINTY_HELD')
        _finish(s,j,j['decision']['units'],tid);return [p['job'],j['decision']['event']]
    if op=='SERVICE_DISCHARGE':
        exact(p,'job revision units approvals');integer(p['revision']);need(p['job'] in s['service_jobs'],'SERVICE_JOB');j=s['service_jobs'][p['job']]
        need(j['state'] not in {'SETTLED','TIMED_OUT'},'SERVICE_STATE');_quantity(p['units']);need(p['units']<=j['units'],'SERVICE_METER')
        # Release an unresolved or deliberately held job only through fresh
        # customer governance and provider assent to the exact division.
        w=s['worlds'][j['world']];need(w['status']=='ACTIVE','WORLD_INACTIVE');need(p['revision']==w['revision'],'WORLD_REVISION')
        authorized(s,w['seed']['governors'],w['seed']['threshold'],p['approvals'],op,p)
        authorized(s,[j['provider']],1,p['approvals'],op,p)
        _finish(s,j,p['units'],tid);w['revision']+=1;j['discharge']=deepcopy(p);return [p['job']]
    if op=='SERVICE_TIMEOUT':
        exact(p,'job');need(p['job'] in s['service_jobs'],'SERVICE_JOB');j=s['service_jobs'][p['job']]
        if j['uncertainty']=='WAIT_FOREVER':need(False,'SERVICE_WAIT_FOREVER')
        need((j['state']=='BOOKED' and height>j['deadline']) or (j['state']=='DISPUTED' and height>j['appeal_deadline']),'SERVICE_TIMEOUT')
        if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and j['state']=='DISPUTED' and j.get('decision') and j['decision'].get('outcome')!='INDETERMINATE':
            _finish(s,j,j['decision']['units'],tid)
            j['appeal_basis']='FIRST_INSTANCE_STANDS'
            j['silent_judges']=[j['appeal_resolver']]
            j['judge_record']=[{'judge':j['appeal_resolver'],'reputation':'LOST','bond':'FORFEIT_RECORDED','event':tid}]
            return [p['job'],j['decision']['event']]
        from .governance import obligation_active
        disputed_hold=j['state']=='DISPUTED' and j['uncertainty']=='HOLD' and obligation_active(j,'silent_referee_release')
        if disputed_hold:
            need(height>j['appeal_deadline']+j['challenge_blocks'],'SERVICE_TIMEOUT')
        else:
            need(j['state']!='DISPUTED' or j['uncertainty']=='REFUND','SERVICE_UNCERTAINTY_HELD')
        _finish(s,j,0,tid);j['state']='TIMED_OUT';return [p['job']]
    if op=='WORLD_RECOVERY_LEASE':
        exact(p,'world revision approvals holder resource limit expiry delegate heartbeat successors')
        w=governed(s,p,op);key(p['holder']);_asset(s,p['resource']);integer(p['limit'],True);integer(p['expiry'],True);integer(p['heartbeat'],True)
        need(type(p['delegate']) is bool and height<p['expiry'],'WORLD_ROLE_SCOPE')
        successors=p['successors'];need(type(successors) is list and 1<=len(successors)<=16,'RECOVERY_SUCCESSORS')
        for who in successors:key(who)
        need(len(set(successors+[p['holder']]))==len(successors)+1,'RECOVERY_SUCCESSORS')
        need({p['holder'],*successors}<=set(w['members']),'WORLD_MEMBERSHIP')
        authorized(s,[p['holder']]+successors,len(successors)+1,p['approvals'],op,p)
        s['world_roles'][tid]={k:deepcopy(p[k]) for k in ('world','holder','resource','limit','expiry','delegate','heartbeat')}
        s['world_roles'][tid].update(parent=None,spent=0,revoked=False,epoch=w['role_epoch'],successors=deepcopy(successors),backup=successors[0],last_seen=height,origin=tid)
        w['revision']+=1;return [p['world']]
    if op=='WORLD_RECOVER':
        exact(p,'role');need(p['role'] in s['world_roles'],'WORLD_ROLE');r=s['world_roles'][p['role']]
        need('successors' in r and 'heartbeat' in r and r['parent'] is None and not r['revoked'] and r['successors'] and actor==r['successors'][0] and r['last_seen']+r['heartbeat']<height<r['expiry'],'WORLD_RECOVERY')
        w=s['worlds'][r['world']];need(w['status']=='ACTIVE' and r['epoch']==w['role_epoch'] and actor in w['members'],'WORLD_ROLE_EPOCH')
        tail=r['successors'][1:];new={**deepcopy(r),'holder':actor,'successors':tail,'backup':tail[0] if tail else None,'last_seen':height}
        r['revoked']=True;s['world_roles'][tid]=new;return [p['role']]
    return None
