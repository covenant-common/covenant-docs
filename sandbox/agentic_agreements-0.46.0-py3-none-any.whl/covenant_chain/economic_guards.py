"""Host-side refusals for value exploits that frozen consensus rules still pay.

Draft PR 128 reproduced five defects in frozen consensus code (economics.py,
scale_fees.py and federation.py, and the helpers they call). Main keeps paying
them until a steward adopts a successor at a new native version; see
reports/STEWARD_PACKET_ECONOMICS_2026_10_29.html. Nothing here changes a
consensus rule, a reducer or a signed meaning. A host runs these checks before
it builds or signs a transaction (``world_sdk.WorldClient.prepare`` does), an
issuer before it funds a pool or a reward root, and a verifier before it relies
on a bridge credit:

1. Sponsored fees carry no referral or integrator cut, fund no ring-internal
   EXECUTE and request no first-agreement sponsorship before any settlement
   (``transaction``, ``sponsor_audit``).
2. Points earned only inside a closed ring are not claimed (``closed_rings``,
   ``ring_points``, ``transaction``).
3. Every leaf of an APPROVED reward root names an honoured agreement its
   recipient was party to (``approved_manifest``).
4. A pool that can pay first BINDs lists one key per verified credential,
   never a credential sponsored before under another key
   (``first_agreement_pool``, ``passkey_bindings``).
5. A burned bridge export is imported only where this chain itself accepted
   it (``transaction``, ``import_assurance``).

They keep honest hosts from being the instrument of an exploit and let an
issuer stop funding one. They cannot stop a party that signs its own
transactions; only the successor rules can.
"""
from collections.abc import Mapping
from copy import deepcopy

from .crypto import digest, integer, key, need
from .kept_promises import honoured, honoured_rows, score_rows, tokens_for
from .tokenomics_config import live_meter, live_policy

VERSION = 'covenant-economic-guards/0.1'
CREDENTIAL_LABEL = 'COVENANT-ECONOMIC-GUARD-CREDENTIAL-0.1'
PACKET = 'reports/STEWARD_PACKET_ECONOMICS_2026_10_29.html'
SCALE_PROFILES = ('covenant-native/0.15', 'covenant-native/0.16')
MAX_ROWS = 65536
REMEDIATION = {
    'GUARD_BOOK': 'The sponsorship book is malformed or full. Start from new_book() and keep the book each call returns.',
    'GUARD_BRIDGE_UNACCEPTED': 'This chain never accepted that export, yet its proof shows a burned ticket: a genesis '
                               'clone of the destination would be credited again. Import only on the chain whose '
                               'BRIDGE_ACCEPT the source burned against.',
    'GUARD_CREDENTIAL_REQUIRED': 'Each key a first-agreement pool lists needs a credential the issuer verified (for '
                                 'example a registered passkey). Bind the key first, then list it.',
    'GUARD_CREDENTIAL_REUSED': 'That credential was already sponsored under another key; a fresh key does not make a '
                               'new person. List the original key or none.',
    'GUARD_FIRST_AGREEMENT_USED': 'That key already had its first agreement or a sponsored first agreement. Do not list '
                                  'it in a first-agreement pool again.',
    'GUARD_INPUT': 'The guard input is malformed: pass a ledger state (or a record reader), a transaction body with op, '
                   'actor and payload, and integer heights.',
    'GUARD_LEDGER_SIZE': 'The ledger holds more rows than this host check reads (65,536). Run the check on a pruned '
                         'certified snapshot, or wait for the steward successor that enforces it in consensus.',
    'GUARD_RECORD': 'A record the check needs (sponsor pool, agreement, scale meter, campaign or bridge source) is missing '
                    'or unreadable, so the transaction cannot be shown safe. Read it from a certified state and retry.',
    'GUARD_REWARD_PARTY': 'An APPROVED leaf pays someone who was not principal, agent or counterparty of its agreement, '
                          'or an agreement whose counterparty is its own principal or agent. Remove the leaf.',
    'GUARD_REWARD_REUSED': 'An APPROVED root names one agreement twice for the same recipient. Pay each settled '
                           'agreement once.',
    'GUARD_REWARD_UNSETTLED': 'An APPROVED leaf names no honoured agreement on this ledger (none, unknown, unsettled '
                              'or overturned), and main would still pay it. Remove the leaf or wait for settlement.',
    'GUARD_RING_POINTS': 'This claim exceeds the points earned outside closed rings; main still pays ring points. '
                         'Claim only what agreements with counterparties outside the ring earned.',
    'GUARD_SPONSOR_RING': 'The pool would fund an EXECUTE whose counterparty is itself a listed actor: a ring settling '
                          'with the sponsor\'s money. Pay this fee yourself.',
    'GUARD_SPONSOR_SCOPE': 'A pool that sponsors EXECUTE pays referral and integrator cuts out of your escrow on main. '
                           'Sponsor BIND or other operations, or wait for the steward successor.',
    'GUARD_SPONSOR_UNSETTLED': 'Main pays the first-agreement sponsorship at BIND, before any settlement, once per key. '
                               'Pay this BIND yourself; the successor pays after settlement, once per credential.',
    'GUARD_SPONSORED_CUT': 'A sponsored fee would pay a referral or integrator cut out of the sponsor\'s escrow. Drop '
                           'the referrer and integrator, or pay the fee yourself.',
}


class RecordReader:
    """A ledger view over a ``read(table, key)`` lookup, for a host that has records but no full state."""

    def __init__(self, read):
        need(callable(read), 'GUARD_INPUT')
        self._read = read

    def record(self, table, name):
        return self._read(table, name)


def _need_profile(body):
    need(isinstance(body, dict) and type(body.get('op')) is str and isinstance(body.get('payload'), dict), 'GUARD_INPUT')
    key(body.get('actor'))
    fee = body.get('fee')
    need(fee is None or isinstance(fee, dict), 'GUARD_INPUT')
    return body.get('v'), fee or {}


def _record(ledger, table, name):
    """One stored row, copied. ``ledger`` is a state or an object with ``record(table, key)``."""
    if not isinstance(ledger, Mapping):
        need(callable(getattr(ledger, 'record', None)), 'GUARD_INPUT')
        try:
            return deepcopy(ledger.record(table, name))
        except (ValueError, KeyError, TypeError, OSError, RuntimeError):
            raise ValueError('GUARD_RECORD') from None
    rows = ledger.get(table)
    if rows is None:
        return None
    if hasattr(rows, 'get_raw'):
        # A state Table: read without caching the row into its dirty set.
        return deepcopy(rows.dirty[name] if name in rows.dirty else rows.get_raw(name))
    need(isinstance(rows, Mapping), 'GUARD_INPUT')
    return deepcopy(rows.get(name))


def _rows(state, table):
    """Every row of one table as (key, copy), bounded, without caching rows into a state Table."""
    rows = state.get(table)
    if rows is None:
        return []
    need(isinstance(rows, Mapping), 'GUARD_INPUT')
    names = list(rows)
    need(len(names) <= MAX_ROWS, 'GUARD_LEDGER_SIZE')
    return [(name, _record(state, table, name)) for name in names]


def _sponsored(ledger, body, fee):
    sponsor = fee.get('sponsor')
    if sponsor is None:
        return 'NOT_SPONSORED'
    key(sponsor)
    need(not fee.get('referrer') and not fee.get('integrator'), 'GUARD_SPONSORED_CUT')
    need(fee.get('sponsor_program') is None, 'GUARD_SPONSOR_UNSETTLED')
    if body['op'] != 'EXECUTE':
        return 'SPONSORED_WITHOUT_CUTS'
    agreement_id = body['payload'].get('agreement')
    key(agreement_id)
    pool = _record(ledger, 'sponsor_pools', sponsor)
    agreement = _record(ledger, 'agreements', agreement_id)
    meter = _record(ledger, 'economic_policy', 'scale')
    need(isinstance(pool, dict) and type(pool.get('actors')) is list and isinstance(agreement, dict)
         and isinstance(agreement.get('terms'), dict) and isinstance(meter, dict), 'GUARD_RECORD')
    need(agreement_id not in (meter.get('integrators') or {}), 'GUARD_SPONSORED_CUT')
    need(agreement['terms'].get('counterparty') not in pool['actors'], 'GUARD_SPONSOR_RING')
    return 'SPONSORED_EXECUTE_OUTSIDE_THE_POOL'


def _bridge_import(ledger, payload):
    source = payload.get('source')
    export = payload.get('export')
    key(source)
    key(export)
    policy = _record(ledger, 'bridge_sources', source)
    need(isinstance(policy, dict) and isinstance(policy.get('genesis'), dict), 'GUARD_RECORD')
    if policy['genesis'].get('protocol') not in SCALE_PROFILES:
        # Sources before 0.15 retire on export; their tickets have no acceptance step.
        return 'RETIRED_TICKET_NO_ACCEPTANCE_STEP'
    iid = digest('COVENANT-BRIDGE-IMPORT-0.7', {'source': source, 'export': export})
    accepted = _record(ledger, 'bridge_acceptances', iid)
    need(isinstance(accepted, dict) and accepted.get('state') == 'ACCEPTED_LOCKED'
         and accepted.get('source') == source and accepted.get('export') == export, 'GUARD_BRIDGE_UNACCEPTED')
    return 'ACCEPTED_HERE_BEFORE_IMPORT'


def _claimed(state, account, eligibility):
    total = 0
    for _name, claim in _rows(state, 'reward_claims'):
        if not isinstance(claim, dict) or claim.get('recipient') != account:
            continue
        campaign = _record(state, 'reward_campaigns', claim.get('campaign')) or {}
        if campaign.get('eligibility') == eligibility:
            total += claim.get('unlocked', 0) + claim.get('held_total', claim.get('amount', 0))
    return total


def _points_claim(ledger, body, height):
    if not isinstance(ledger, Mapping) or height is None:
        # Ring detection reads every honoured agreement; a record reader cannot list them.
        return 'UNCHECKED_RING_POINTS_NEEDS_A_FULL_LEDGER_AND_HEIGHT'
    key(body['payload'].get('campaign'))
    campaign = _record(ledger, 'reward_campaigns', body['payload']['campaign'])
    need(isinstance(campaign, dict), 'GUARD_RECORD')
    if campaign.get('eligibility') != 'POINTS_SEASON':
        return 'NOT_A_POINTS_CLAIM'
    grant = body['payload'].get('grant')
    need(isinstance(grant, dict), 'GUARD_INPUT')
    integer(grant.get('amount'), True)
    view = ring_points(ledger, height)
    account = view['accounts'].get(body['actor'], {'outside_ring_tokens': 0})
    room = account['outside_ring_tokens'] - _claimed(ledger, body['actor'], 'POINTS_SEASON')
    need(grant['amount'] <= max(0, room), 'GUARD_RING_POINTS')
    return 'POINTS_EARNED_OUTSIDE_RINGS'


def transaction(ledger, body, *, height=None):
    """Refuse an unsigned transaction a known consensus defect would pay; otherwise list the checks run.

    ``ledger`` is a ledger state or an object with ``record(table, key)`` (an
    advisory record reader). ``body`` holds v, op, actor, payload and fee.
    Points claims are checked only against a full state at a known ``height``.
    """
    profile, fee = _need_profile(body)
    checks = []
    if height is not None:
        integer(height)
    if profile in SCALE_PROFILES:
        checks.append(('sponsored_fee', _sponsored(ledger, body, fee)))
        if body['op'] == 'ECON_SPONSOR_CREATE':
            operations = body['payload'].get('operations')
            need(type(operations) is list, 'GUARD_INPUT')
            need('EXECUTE' not in operations, 'GUARD_SPONSOR_SCOPE')
            checks.append(('sponsor_scope', 'NO_SPONSORED_EXECUTE'))
        if body['op'] == 'ECON_REWARD_CLAIM':
            checks.append(('points_claim', _points_claim(ledger, body, height)))
        if body['op'] == 'BRIDGE_IMPORT':
            checks.append(('bridge_import', _bridge_import(ledger, body['payload'])))
    return {'version': VERSION, 'op': body['op'], 'profile': profile, 'checks': [list(row) for row in checks],
            'decision': 'NO_KNOWN_DEFECT_TRIGGERED', 'consensus_rule_changed': False, 'execution_authorized': False}


def closed_rings(rows):
    """Directed rings among honoured agreements: strongly connected sets of two or more accounts.

    Edges run principal to counterparty. Iterative Tarjan, bounded at
    MAX_ROWS rows, so a long ring cannot exhaust the recursion limit.
    """
    need(type(rows) is list and len(rows) <= MAX_ROWS, 'GUARD_LEDGER_SIZE')
    graph = {}
    for row in rows:
        need(isinstance(row, dict), 'GUARD_INPUT')
        key(row.get('principal'))
        key(row.get('counterparty'))
        graph.setdefault(row['principal'], set()).add(row['counterparty'])
        graph.setdefault(row['counterparty'], set())
    index, low, on_stack, stack, rings, counter = {}, {}, set(), [], [], 0
    for start in sorted(graph):
        if start in index:
            continue
        work = [(start, iter(sorted(graph[start])))]
        index[start] = low[start] = counter
        counter += 1
        stack.append(start)
        on_stack.add(start)
        while work:
            node, children = work[-1]
            advanced = False
            for child in children:
                if child not in index:
                    index[child] = low[child] = counter
                    counter += 1
                    stack.append(child)
                    on_stack.add(child)
                    work.append((child, iter(sorted(graph[child]))))
                    advanced = True
                    break
                if child in on_stack:
                    low[node] = min(low[node], index[child])
            if advanced:
                continue
            work.pop()
            if work:
                parent = work[-1][0]
                low[parent] = min(low[parent], low[node])
            if low[node] == index[node]:
                members = []
                while True:
                    member = stack.pop()
                    on_stack.discard(member)
                    members.append(member)
                    if member == node:
                        break
                if len(members) >= 2:
                    rings.append(sorted(members))
    rings.sort()
    ring_of = {member: position for position, ring in enumerate(rings) for member in ring}
    inside = [row for row in rows if row['principal'] in ring_of and ring_of[row['principal']] == ring_of.get(row['counterparty'])]
    return {'rings': rings, 'ring_rows': inside, 'walk': 'ITERATIVE_TARJAN', 'max_rows': MAX_ROWS}


def ring_points(state, height):
    """Main's points beside the points earned outside closed rings, scored by main's own rule."""
    need(isinstance(state, Mapping), 'GUARD_INPUT')
    integer(height)
    policy = live_policy(state)
    need(policy is not None, 'GUARD_RECORD')
    need(len(state.get('agreements') or {}) <= MAX_ROWS, 'GUARD_LEDGER_SIZE')
    rows = honoured_rows(state, height)
    found = closed_rings(rows)
    inside = {row['agreement'] for row in found['ring_rows']}
    outside = [row for row in rows if row['agreement'] not in inside]
    scale = policy['scale']
    bonds = (live_meter(state) or {}).get('bonds') or {}
    main = score_rows(rows, height, scale['points'], bonds, scale['integrator'])['accounts']
    honest = score_rows(outside, height, scale['points'], bonds, scale['integrator'])['accounts']
    accounts = {}
    for account in sorted(set(main) | set(honest)):
        points = main.get(account, {}).get('points', 0)
        kept = honest.get(account, {}).get('points', 0)
        accounts[account] = {'main_points': points, 'outside_ring_points': kept,
                             'main_tokens': tokens_for(points, bonds.get(account, 0), scale['points']),
                             'outside_ring_tokens': tokens_for(kept, bonds.get(account, 0), scale['points'])}
    return {'version': VERSION, 'height': height, 'rings': found['rings'], 'ring_agreements': sorted(inside),
            'accounts': accounts, 'consensus_points_changed': False, 'execution_authorized': False}


def approved_manifest(state, grants):
    """Before an issuer signs an APPROVED root: each leaf pays a party of one honoured agreement, once."""
    need(isinstance(state, Mapping) and type(grants) is list and 0 < len(grants) <= MAX_ROWS, 'GUARD_INPUT')
    seen = set()
    for grant in grants:
        need(isinstance(grant, dict), 'GUARD_INPUT')
        recipient, receipt = grant.get('recipient'), grant.get('receipt')
        key(recipient)
        need(type(receipt) is str and len(receipt) == 64, 'GUARD_REWARD_UNSETTLED')
        key(receipt)
        agreement = _record(state, 'agreements', receipt)
        need(honoured(agreement), 'GUARD_REWARD_UNSETTLED')
        terms = agreement['terms']
        need(recipient in {terms['principal'], terms['agent'], terms['counterparty']}
             and terms['counterparty'] not in {terms['principal'], terms['agent']}, 'GUARD_REWARD_PARTY')
        need((receipt, recipient) not in seen, 'GUARD_REWARD_REUSED')
        seen.add((receipt, recipient))
    return {'version': VERSION, 'decision': 'EVERY_LEAF_BOUND_TO_AN_HONOURED_AGREEMENT', 'leaves': len(grants),
            'execution_authorized': False}


def new_book():
    """An issuer's record of which verified credential each first-agreement sponsorship went to."""
    return {'version': VERSION, 'credentials': {}, 'actors': {}}


def _book(book):
    need(isinstance(book, dict) and set(book) == {'version', 'credentials', 'actors'} and book['version'] == VERSION
         and isinstance(book['credentials'], dict) and isinstance(book['actors'], dict)
         and len(book['credentials']) == len(book['actors']) <= MAX_ROWS, 'GUARD_BOOK')
    for credential, actor in book['credentials'].items():
        need(book['actors'].get(actor) == credential, 'GUARD_BOOK')
    return deepcopy(book)


def credential_digest(credential_id):
    """The digest a book keeps for one verified credential id (never the credential itself)."""
    need(type(credential_id) is str and 0 < len(credential_id) <= 1366, 'GUARD_INPUT')
    return digest(CREDENTIAL_LABEL, credential_id)


def passkey_bindings(desk):
    """Invitee key to credential digest for every invite an InviteDesk accepted with a registered passkey."""
    need(isinstance(getattr(desk, 'credentials', None), dict) and isinstance(getattr(desk, 'rows', None), dict), 'GUARD_INPUT')
    bindings = {}
    for credential, invite in sorted(desk.credentials.items()):
        row = desk.rows.get(invite) or {}
        if row.get('invitee') is not None:
            bindings[row['invitee']] = credential_digest(credential)
    return bindings


def first_agreement_pool(state, payload, bindings, book):
    """Before an issuer signs an ECON_SPONSOR_CREATE that can pay BIND: one listed key per verified credential.

    ``economics.charge`` keys the first-agreement sponsorship by key
    (``human_incentives.claim_first_agreement``), so fresh keys collect it
    again. ``bindings`` maps each listed key to the digest of a credential the
    issuer verified (``passkey_bindings``, ``credential_digest``); a key with
    an earlier agreement or first-agreement sponsorship is refused. Returns
    the new book; the old one is not changed.
    """
    need(isinstance(state, Mapping) and isinstance(payload, dict) and type(payload.get('actors')) is list
         and type(payload.get('operations')) is list and isinstance(bindings, dict), 'GUARD_INPUT')
    out = _book(book)
    if 'BIND' not in payload['operations']:
        return {'version': VERSION, 'decision': 'POOL_CANNOT_PAY_A_BIND', 'book': out, 'execution_authorized': False}
    used = set((live_meter(state) or {}).get('first_agreements') or {})
    principals = {(row.get('terms') or {}).get('principal') for _name, row in _rows(state, 'agreements')
                  if isinstance(row, dict)}
    listed = set()
    for actor in payload['actors']:
        key(actor)
        credential = bindings.get(actor)
        need(credential is not None, 'GUARD_CREDENTIAL_REQUIRED')
        key(credential)
        need(credential not in listed and out['credentials'].get(credential, actor) == actor, 'GUARD_CREDENTIAL_REUSED')
        need(actor not in used and actor not in principals and out['actors'].get(actor, credential) == credential,
             'GUARD_FIRST_AGREEMENT_USED')
        listed.add(credential)
        out['credentials'][credential] = actor
        out['actors'][actor] = credential
    need(len(out['credentials']) <= MAX_ROWS, 'GUARD_BOOK')
    return {'version': VERSION, 'decision': 'ONE_KEY_PER_VERIFIED_CREDENTIAL', 'book': out, 'execution_authorized': False}


def sponsor_audit(state, sponsor):
    """What a pool paid that the successor would not: referral and integrator cuts. Proposes closing it."""
    need(isinstance(state, Mapping), 'GUARD_INPUT')
    key(sponsor)
    pool = _record(state, 'sponsor_pools', sponsor)
    need(isinstance(pool, dict), 'GUARD_RECORD')
    fees = paid = cuts = programme = 0
    recipients = {}
    for _name, receipt in _rows(state, 'fee_receipts'):
        if not isinstance(receipt, dict) or receipt.get('sponsor') != sponsor:
            continue
        fees += 1
        paid += receipt.get('amount', 0)
        scale = receipt.get('scale') or {}
        for cut, who in (('referral_cut', 'referrer'), ('integrator_cut', 'integrator')):
            if scale.get(cut):
                cuts += scale[cut]
                recipients[scale.get(who) or ''] = recipients.get(scale.get(who) or '', 0) + scale[cut]
        if scale.get('sponsor_program'):
            programme += 1
    close = None
    if cuts and not pool.get('closed'):
        close = {'operation': 'ECON_SPONSOR_CLOSE', 'payload': {'sponsor': sponsor}, 'signer': pool.get('issuer'),
                 'returns': pool.get('remaining', 0), 'submitted': False}
    return {'version': VERSION, 'sponsor': sponsor, 'issuer': pool.get('issuer'), 'remaining': pool.get('remaining'),
            'sponsored_fees': fees, 'paid_from_escrow': paid, 'cuts_paid_from_escrow': cuts,
            'cut_recipients': recipients, 'first_agreement_fees': programme, 'close': close,
            'execution_authorized': False}


def import_assurance(state, source, export):
    """For a verifier: whether an import credited here followed this chain's own acceptance of the export."""
    need(isinstance(state, Mapping), 'GUARD_INPUT')
    key(source)
    key(export)
    iid = digest('COVENANT-BRIDGE-IMPORT-0.7', {'source': source, 'export': export})
    imported = _record(state, 'bridge_imports', iid)
    accepted = _record(state, 'bridge_acceptances', iid)
    policy = _record(state, 'bridge_sources', source) or {}
    if imported is None:
        status = 'NOT_IMPORTED'
    elif (state.get('protocol') not in SCALE_PROFILES
          or (policy.get('genesis') or {}).get('protocol') not in SCALE_PROFILES):
        # A source before 0.15 retires on export; there is no acceptance step to check.
        status = 'RETIRED_TICKET_NO_ACCEPTANCE_STEP'
    elif isinstance(accepted, dict) and accepted.get('state') == 'IMPORTED':
        status = 'ACCEPTED_HERE_THEN_IMPORTED'
    else:
        status = 'IMPORTED_WITHOUT_LOCAL_ACCEPTANCE'
    return {'version': VERSION, 'import': iid, 'status': status,
            'relied_on': status in {'ACCEPTED_HERE_THEN_IMPORTED', 'RETIRED_TICKET_NO_ACCEPTANCE_STEP'},
            'execution_authorized': False}


def describe():
    """The five defects, where each guard runs, and every refusal."""
    return {'version': VERSION, 'packet': PACKET, 'profiles': list(SCALE_PROFILES),
            'guards': {'sponsored_fee': 'transaction (WorldClient.prepare)', 'sponsor_scope': 'transaction',
                       'points_claim': 'transaction with a full ledger, ring_points',
                       'approved_root': 'approved_manifest', 'first_agreement_pool': 'first_agreement_pool',
                       'bridge_import': 'transaction (WorldClient.prepare), import_assurance',
                       'sponsor_monitor': 'sponsor_audit'},
            'consensus_rule_changed': False, 'stops_a_party_signing_its_own_transactions': False,
            'refusals': dict(REMEDIATION), 'execution_authorized': False}
