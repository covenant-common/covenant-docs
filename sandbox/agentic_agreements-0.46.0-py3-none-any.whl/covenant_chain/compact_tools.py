"""Keep an MCP tool catalogue and a tool reply inside an agent context budget.

A catalogue that already fits is returned unchanged, with no cursor. A reply
whose JSON already fits keeps its text. Larger replies keep the structured
document and put a short summary in the text channel. A requested tool
description keeps its exact schema in the text channel up to a larger bound,
because clients that read only text could not otherwise use it.
"""
import json

PAGE_BUDGET = 18000
TEXT_BUDGET = 12000
STRUCTURED_BUDGET = 20000
# Reply format -> text budget. Only formats an agent asks for by name.
TEXT_BUDGET_BY_FORMAT = {'covenant-tool-description/0.1': 131072}


def _dumps(value, sort_keys):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':'), sort_keys=sort_keys)


def page_tools(tools, cursor, *, sort_keys=False):
    """Return one page, or None when the cursor is not a page of this list."""
    encoded = [_dumps(tool, sort_keys) for tool in tools]
    total = 2 + sum(len(blob) + 1 for blob in encoded)
    if total <= PAGE_BUDGET:
        if cursor is not None:
            return None
        return {'tools': list(tools)}
    if cursor is None:
        start = 0
    elif type(cursor) is str and cursor.isdigit():
        start = int(cursor)
    else:
        return None
    if start < 0 or start >= len(tools):
        return None
    page = []
    size = 2
    index = start
    while index < len(tools):
        blob = encoded[index]
        if page and size + len(blob) + 1 > PAGE_BUDGET:
            break
        page.append(tools[index])
        size += len(blob) + 1
        index += 1
    result = {'tools': page}
    if index < len(tools):
        result['nextCursor'] = str(index)
    return result


def _brief(value):
    if type(value) is not dict:
        return {'summary': True, 'execution_authorized': False}
    return {
        'summary': True,
        'keys': list(value)[:24],
        'detail': True,
        'execution_authorized': value.get('execution_authorized') is True,
    }


def _fit_structured(value, sort_keys):
    """Return a size-bounded preview. Never use it in place of a reply's
    structured content: omitted fields cannot be recovered by the caller."""
    if type(value) is not dict or len(_dumps(value, sort_keys)) <= STRUCTURED_BUDGET:
        return value
    shrunk = dict(value)
    ranked = sorted(
        ((len(_dumps(item, sort_keys)), key) for key, item in value.items() if type(item) in (dict, list)),
        reverse=True,
    )
    for _size, key in ranked:
        item = shrunk[key]
        if type(item) is dict:
            shrunk[key] = {'omitted': True, 'keys': list(item)[:8]}
        else:
            shrunk[key] = {'omitted': True, 'length': len(item)}
        shrunk['detail'] = True
        if len(_dumps(shrunk, sort_keys)) <= STRUCTURED_BUDGET:
            break
    return shrunk


def call_result(value, *, error=False, sort_keys=False):
    """Text plus structured content. Small values keep the full text.

    The structured document is never altered: a later call may need every byte
    of it (an encrypted delivery, a signed envelope). Only the text channel is
    shortened to a summary when the reply is large.
    """
    structured = value
    full = _dumps(structured, sort_keys)
    budget = TEXT_BUDGET
    if type(structured) is dict and type(structured.get('format')) is str:
        budget = max(budget, TEXT_BUDGET_BY_FORMAT.get(structured['format'], 0))
    text = full if error or len(full) <= budget else _dumps(_brief(structured), sort_keys)
    return {
        'content': [{'type': 'text', 'text': text}],
        'structuredContent': structured,
        'isError': error,
    }
