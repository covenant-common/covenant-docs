"""Explicitly adopted, funded economics for native 0.9.

Fees and rewards move existing ledger units. They do not establish bank backing,
physical performance, human uniqueness, anonymous claims or monetary stability.
Private allocation manifests stay off chain; individual claims are PUBLIC.
"""
from .profile import MIGRATION_VERSION
from copy import deepcopy
from .balances import add, amount as unit_balance, move
from .crypto import canonical, digest, exact, integer, key, need
from .state import Table

VERSION = 'covenant-economics/0.1'
MARKET_VERSION = 'covenant-economics/0.2'
TABLES = ('economic_policy', 'fee_receipts', 'sponsor_pools', 'reward_campaigns',
          'reward_domains', 'reward_claims', 'reward_services', 'clearing_sets')


def label(value):
    need(type(value) is str and 0 < len(value) <= 80 and
         all(32 <= ord(c) <= 126 for c in value), 'ECONOMIC_LABEL')


def validate_policy(policy, resources):
    # 0.3 is a new genesis profile. 0.1 and 0.2 keep the checks below unchanged.
    if type(policy) is dict and policy.get('version') == 'covenant-economics/0.3':
        from .scale_fees import validate_scale_policy
        return validate_scale_policy(policy, resources)
    exact(policy, 'version resource base_fee per_kib work_fees beneficiaries governors threshold change_delay')
    need(policy['version'] in {VERSION, MARKET_VERSION}, 'ECONOMIC_VERSION')
    label(policy['resource']); need(policy['resource'] in resources, 'FEE_RESOURCE')
    integer(policy['base_fee']); integer(policy['per_kib'])
    work = policy['work_fees']
    need(type(work) is dict and len(work) <= 64, 'FEE_WORK_LIMIT')
    for op, amount in work.items(): label(op); integer(amount)
    rows = policy['beneficiaries']
    need(type(rows) is list and 1 <= len(rows) <= 16, 'FEE_BENEFICIARIES')
    accounts = set()
    for row in rows:
        exact(row, 'account bps purpose'); key(row['account']); integer(row['bps'], True); label(row['purpose'])
        route=(row['account'],row['purpose']) if policy['version']==MARKET_VERSION else row['account']
        need(route not in accounts and row['bps'] <= 10000, 'FEE_BENEFICIARIES')
        accounts.add(route)
    need(sum(r['bps'] for r in rows) == 10000, 'FEE_SHARES')
    governors = policy['governors']
    need(type(governors) is list and 1 <= len(governors) <= 32, 'FEE_GOVERNORS')
    for who in governors: key(who)
    need(governors == sorted(set(governors)), 'FEE_GOVERNORS')
    integer(policy['threshold'], True); need(policy['threshold'] <= len(governors), 'FEE_THRESHOLD')
    integer(policy['change_delay'], True); need(policy['change_delay'] >= 2, 'FEE_NOTICE')
    canonical(policy)
    return policy


def policy_id(policy):
    if policy.get('version') == MARKET_VERSION:
        policy = {k:v for k,v in policy.items() if k != '_market_rates'}
    elif policy.get('version') == 'covenant-economics/0.3':
        policy = {k: v for k, v in policy.items() if not k.startswith('_')}
    return digest('COVENANT-ECONOMIC-POLICY-0.1', policy)


def initialize(state, genesis):
    exact(genesis['economics'], 'fee_policy')
    p = validate_policy(genesis['economics']['fee_policy'], state['resources'])
    from .profile import SCALE_VERSION
    if p['version'] == 'covenant-economics/0.3':
        # New native behaviour. A 0.9–0.14 chain cannot boot this profile.
        need(genesis['protocol'] in {SCALE_VERSION,MIGRATION_VERSION}, 'SCALE_PROFILE_PROTOCOL')
    elif genesis['protocol'] in {SCALE_VERSION,MIGRATION_VERSION}:
        # 0.15 also boots the 0.2 market profile so scale records can sit on it.
        need(p['version'] == MARKET_VERSION, 'ECONOMIC_PROFILE')
    else:
        need(p['version'] == (MARKET_VERSION if genesis['protocol'] in {'covenant-native/0.12','covenant-native/0.13','covenant-native/0.14'} else VERSION), 'ECONOMIC_PROFILE')
    for table in TABLES: state[table] = Table()
    state['economic_policy']['active'] = {'body': deepcopy(p), 'id': policy_id(p), 'effective': 1}
    state['economic_policy']['pending'] = None
    if p['version'] == 'covenant-economics/0.3':
        from .scale_fees import init_meter
        init_meter(state)


def policy_at(state, height):
    integer(height, True)
    pending = state['economic_policy'].get('pending')
    chosen = pending if pending is not None and height >= pending['effective'] else state['economic_policy']['active']
    if chosen['body'].get('version') == 'covenant-economics/0.3':
        from .scale_fees import scale_view
        chosen = deepcopy(chosen)
        chosen['body']['_scale'] = scale_view(state, height, chosen['body']['scale'])
        return chosen
    from .profile import MARKET_VERSION as NATIVE_MARKET, PREDICTION_VERSION as NATIVE_PREDICTION, REVIEW_VERSION as NATIVE_REVIEW, SCALE_VERSION as NATIVE_SCALE
    if state.get('protocol') in {NATIVE_MARKET, NATIVE_REVIEW, NATIVE_PREDICTION} or (state.get('protocol') in {NATIVE_SCALE,MIGRATION_VERSION} and 'market_meter' in state):
        from .market_meter import price_view
        chosen = deepcopy(chosen)
        chosen['body']['_market_rates'] = price_view(state,height)
        return chosen
    return chosen


def activate(state, height):
    chosen = policy_at(state, height)
    if chosen['id'] != state['economic_policy']['active']['id']:
        clean = deepcopy(chosen); clean['body'].pop('_market_rates',None); clean['body'].pop('_scale', None)
        state['economic_policy']['active'] = clean
        state['economic_policy']['pending'] = None
    return deepcopy(chosen)


def validate_fee_envelope(fee):
    exact(fee, 'policy max_amount sponsor'); key(fee['policy']); integer(fee['max_amount'])
    need(fee['sponsor'] is None or type(fee['sponsor']) is str, 'FEE_SPONSOR')
    if fee['sponsor'] is not None: key(fee['sponsor'])


def validate_scale_fee_envelope(fee):
    """0.3 envelope. `asset`, `integrator`, `referrer` and `sponsor_program` are optional.

    A three-field envelope still validates. 0.1 charge uses `validate_fee_envelope`,
    so any extra key there fails with FIELDS.
    """
    need(type(fee) is dict, 'FIELDS')
    allowed = {'policy', 'max_amount', 'sponsor', 'asset', 'integrator', 'referrer', 'sponsor_program'}
    need(set(fee) <= allowed and {'policy', 'max_amount', 'sponsor'} <= set(fee), 'FIELDS')
    key(fee['policy'])
    integer(fee['max_amount'])
    need(fee['sponsor'] is None or type(fee['sponsor']) is str, 'FEE_SPONSOR')
    if fee['sponsor'] is not None:
        key(fee['sponsor'])
    if 'asset' in fee:
        asset = fee['asset']
        need(asset is None or (type(asset) is str and 0 < len(asset) <= 80), 'FEE_ASSET')
    for name in ('integrator', 'referrer'):
        if name in fee and fee[name] is not None:
            key(fee[name])
    if 'sponsor_program' in fee and fee['sponsor_program'] is not None:
        from .human_incentives import PROGRAM
        need(fee['sponsor_program'] == PROGRAM, 'SPONSOR_PROGRAM')


def quote(policy, transaction):
    """Exact wire bytes, including the signature; no floating point or FX oracle."""
    size = len(canonical(transaction))
    private = transaction['body'].get('v') in {'covenant-native/0.10','covenant-native/0.11','covenant-native/0.12','covenant-native/0.13','covenant-native/0.14','covenant-native/0.15',MIGRATION_VERSION} and transaction['body']['op'] in {'CONFIDENTIAL_CLAIM','CONFIDENTIAL_TRANSFER'}
    if private: need(size <= 8192, 'CONFIDENTIAL_WIRE_LIMIT')
    cost = fee_cost(policy,transaction['body']['op'],8 if private else (size+1023)//1024,transaction)
    integer(cost)
    return {'policy': policy_id(policy), 'resource': policy['resource'], 'amount': cost,
            'wire_bytes': size, 'binding': False}

def fee_cost(policy,op,kib,transaction=None):
    if policy.get('version') == 'covenant-economics/0.3':
        from .scale_fees import enforced_amount
        return enforced_amount(policy, kib * policy['per_kib'], policy['work_fees'].get(op, 0), transaction)
    work=policy['base_fee']+policy['work_fees'].get(op,0)
    data=kib*policy['per_kib']
    if policy['version']==MARKET_VERSION:
        rates=policy.get('_market_rates');need(type(rates) is dict,'MARKET_PRICE_VIEW_REQUIRED')
        work=(work*rates['work_bps']+9999)//10000
        data=(data*rates['kib_bps']+9999)//10000
    cost=work+data;integer(cost);return cost


def apportion_bps(amount, bps_rows):
    """Largest-remainder split. The shares sum to ``amount``; dust is not minted."""
    shares = [amount * bps // 10000 for bps in bps_rows]
    rest = amount - sum(shares)
    order = sorted(range(len(bps_rows)), key=lambda i: (-(amount * bps_rows[i] % 10000), i))
    for i in order[:rest]:
        shares[i] += 1
    return shares


def charge(state, previous, tx, chosen, tid, height):
    from .ecosystem import move
    fee = tx['body']['fee']
    if chosen['body'].get('version') == 'covenant-economics/0.3':
        validate_scale_fee_envelope(fee)
        if fee.get('sponsor_program') is not None:
            from .human_incentives import claim_first_agreement
            need(fee['sponsor'] is not None, 'FIRST_AGREEMENT_SPONSOR')
            need(tx['body']['op'] == 'BIND', 'FIRST_AGREEMENT_OP')
            from .ledger_base import agreement_id
            claim_first_agreement(state['economic_policy']['scale'], state.get('agreements') or {},
                                  tx['body']['actor'], agreement_id(tx['body']['payload']['terms']))
    else:
        validate_fee_envelope(fee)
    need(fee['policy'] == chosen['id'], 'FEE_POLICY_STALE')
    q = quote(chosen['body'], tx); amount = q['amount']; rid = q['resource']
    need(amount <= fee['max_amount'], 'FEE_CAP')
    actor = tx['body']['actor']; payer = actor
    if fee['sponsor'] is not None:
        sid = fee['sponsor']; need(sid in previous['sponsor_pools'], 'FEE_SPONSOR_MISSING')
        pool = state['sponsor_pools'][sid]
        need(not pool['closed'] and height <= pool['expiry'] and pool['resource'] == rid, 'FEE_SPONSOR_INACTIVE')
        need(actor in pool['actors'] and tx['body']['op'] in pool['operations'], 'FEE_SPONSOR_SCOPE')
        spent = pool['spent'].get(actor, 0)
        need(amount <= pool['remaining'] and spent + amount <= pool['per_actor_cap'], 'FEE_SPONSOR_BUDGET')
        pool['remaining'] -= amount; pool['spent'][actor] = spent + amount; payer = pool['escrow']
    if chosen['body'].get('version') == 'covenant-economics/0.3':
        from .scale_fees import settle_fee
        parts = settle_fee(state, tx, chosen, tid, height, payer, q)
        # The only chain debit for a fee. Beneficiary rows, including FOUNDER, already sum to 10,000 bps.
        if amount:
            escrow = digest('COVENANT-FEE-ESCROW-0.1', tid)
            move(state, payer, escrow, rid, amount)
            for row in parts['allocations']:
                move(state, escrow, row['account'], rid, row['amount'])
        return
    allocations = []
    # Largest-remainder apportionment gives exact conservation and avoids a
    # permanent rounding subsidy to the first route. Ties use adopted order.
    routes = chosen['body']['beneficiaries']
    shares = apportion_bps(amount, [r['bps'] for r in routes])
    private = tx['body'].get('v') in {'covenant-native/0.10','covenant-native/0.11','covenant-native/0.12','covenant-native/0.13','covenant-native/0.14','covenant-native/0.15',MIGRATION_VERSION} and tx['body']['op'] in {'CONFIDENTIAL_CLAIM','CONFIDENTIAL_TRANSFER'}
    market = tx['body'].get('v') in {'covenant-native/0.12','covenant-native/0.13','covenant-native/0.14','covenant-native/0.15',MIGRATION_VERSION}
    if private:
        need(fee['sponsor'] is None and tx['body']['payload']['pool'] == rid, 'CONFIDENTIAL_FEE_RESOURCE')
        need(state['shielded_escrow'][rid] >= amount, 'CONFIDENTIAL_ESCROW')
        state['shielded_escrow'][rid] -= amount
        for row, value in zip(routes, shares):
            if market:
                from .fee_credit import allocation
                allocation(state,row['account'],rid,value,row['purpose'])
            elif value:
                add(state['balances'], row['account'], rid, value)
                add(state['authority_available'], row['account'], rid, value)
            allocations.append({'account': row['account'], 'amount': value, 'purpose': row['purpose']})
        payer = None
    elif amount and market:
        from .fee_credit import allocation
        need(unit_balance(state['authority_available'],payer,rid)>=amount,'MARKET_FEE_FUNDS')
        for table in ('balances','authority_available'):add(state[table],payer,rid,-amount)
        for row,value in zip(routes,shares):
            allocation(state,row['account'],rid,value,row['purpose'])
            allocations.append({'account':row['account'],'amount':value,'purpose':row['purpose']})
    elif amount:
        escrow = digest('COVENANT-FEE-ESCROW-0.1', tid)
        move(state, payer, escrow, rid, amount)
        for row, value in zip(routes, shares):
            if value: move(state, escrow, row['account'], rid, value)
            allocations.append({'account': row['account'], 'amount': value, 'purpose': row['purpose']})
    state['fee_receipts'][tid] = {**q, 'binding': True, 'finality': 'VERIFY_CERTIFICATE', 'height': height, 'actor': actor, 'payer': payer,
                                'sponsor': fee['sponsor'], 'allocations': allocations}


def sum_node(left, right):
    for node in (left, right):
        exact(node, 'hash amount'); key(node['hash']); integer(node['amount'], True)
    a, b = sorted((left, right), key=lambda n: (n['hash'], n['amount']))
    total = a['amount'] + b['amount']; integer(total, True)
    return {'hash': digest('COVENANT-REWARD-NODE-0.1', {'left': a, 'right': b}), 'amount': total}


def grant_node(chain, grant):
    exact(grant, 'domain recipient amount unlock receipt purpose salt')
    for field in ('domain', 'recipient', 'purpose', 'salt'): key(grant[field])
    integer(grant['amount'], True); integer(grant['unlock'])
    need(grant['receipt'] is None or type(grant['receipt']) is str, 'REWARD_RECEIPT')
    if grant['receipt'] is not None: key(grant['receipt'])
    return {'hash': digest('COVENANT-REWARD-LEAF-0.1', {'chain': chain, 'grant': grant}), 'amount': grant['amount']}


def allocation_manifest(chain, domain, grants):
    """PRIVATE result. Publish only root/budget, give each recipient its opening.

    Caller supplies 32-byte random salts. No automatic identity scoring, reward
    entitlement or claim anonymity is implied by this builder.
    """
    key(chain); key(domain)
    need(type(grants) is list and 1 <= len(grants) <= 4096, 'REWARD_MANIFEST_LIMIT')
    nodes = [grant_node(chain, g) for g in grants]
    need(all(g['domain'] == domain for g in grants), 'REWARD_DOMAIN')
    need(len({g['salt'] for g in grants}) == len(grants), 'REWARD_SALT_REUSE')
    openings = [{'grant': deepcopy(g), 'proof': []} for g in grants]
    level = [(n, [i]) for i, n in enumerate(nodes)]
    while len(level) > 1:
        next_level = []
        for i in range(0, len(level), 2):
            if i + 1 == len(level): next_level.append(level[i]); continue
            left, li = level[i]; right, ri = level[i + 1]
            for j in li: openings[j]['proof'].append(deepcopy(right))
            for j in ri: openings[j]['proof'].append(deepcopy(left))
            next_level.append((sum_node(left, right), li + ri))
        level = next_level
    return {'chain': chain, 'domain': domain, 'root': level[0][0], 'openings': openings,
            'confidentiality': 'PRIVATE_MANIFEST_PUBLIC_INDIVIDUAL_CLAIMS'}


def clearing_net(transfers):
    need(type(transfers) is list and 1 <= len(transfers) <= 128, 'CLEARING_LIMIT')
    net = {}
    for row in transfers:
        exact(row, 'source destination amount'); key(row['source']); key(row['destination']); integer(row['amount'], True)
        need(row['source'] != row['destination'], 'CLEARING_SELF_TRANSFER')
        for who in (row['source'], row['destination']): net.setdefault(who, 0)
        net[row['source']] -= row['amount']; net[row['destination']] += row['amount']
        need(all(abs(x) <= 2**53 - 1 for x in net.values()), 'CLEARING_AMOUNT')
    return net


def apply(state, previous, op, p, actor, tid, height):
    if op in {'STAKE_APY', 'LIQUID_STAKE'}:
        from .tokenomics_config import live_policy
        if live_policy(state) is None:
            return None
        raise ValueError('OSSIFIED_FORBIDDEN')
    if not op.startswith('ECON_'): return None
    from .approval import authorized
    if op == 'ECON_FEE_SCHEDULE':
        exact(p, 'previous policy effective approvals'); key(p['previous']); integer(p['effective'], True)
        active = state['economic_policy']['active']
        need(p['previous'] == active['id'] and state['economic_policy'].get('pending') is None, 'FEE_SCHEDULE_STATE')
        validate_policy(p['policy'], state['resources'])
        if active['body'].get('version') == 'covenant-economics/0.3':
            from .scale_fees import accept_schedule
            accept_schedule(state, active['body'], p['policy'], height, p['effective'])
        else:
            need(p['policy']['version']==VERSION,'ECONOMIC_PROFILE')
            from .core_invariants import enforce_schedule
            enforce_schedule(state, active['body'], p['policy'], height)
        need(policy_id(p['policy']) != active['id'], 'FEE_UNCHANGED')
        need(p['effective'] >= height + active['body']['change_delay'], 'FEE_NOTICE')
        authorized(state, active['body']['governors'], active['body']['threshold'], p['approvals'], op, p)
        # New controllers consent before they acquire responsibility.
        authorized(state, p['policy']['governors'], p['policy']['threshold'], p['approvals'], op, p)
        state['economic_policy']['pending'] = {'body': deepcopy(p['policy']), 'id': policy_id(p['policy']), 'effective': p['effective'], 'event': tid}
    elif op == 'ECON_SPONSOR_CREATE':
        exact(p, 'resource budget actors operations per_actor_cap expiry')
        label(p['resource']); need(p['resource'] in state['resources'], 'FEE_RESOURCE')
        integer(p['budget'], True); integer(p['per_actor_cap'], True); integer(p['expiry'], True)
        need(height < p['expiry'], 'SPONSOR_EXPIRY')
        for field, limit in (('actors', 256), ('operations', 64)):
            values = p[field]
            need(type(values) is list and 1 <= len(values) <= limit and all(type(v) is str for v in values), 'SPONSOR_SCOPE')
            need(values == sorted(set(values)), 'SPONSOR_SCOPE')
            for value in values: key(value) if field == 'actors' else label(value)
        escrow = digest('COVENANT-SPONSOR-ESCROW-0.1', tid)
        move(state, actor, escrow, p['resource'], p['budget'])
        state['sponsor_pools'][tid] = {**deepcopy(p), 'issuer': actor, 'escrow': escrow,
                                     'remaining': p['budget'], 'spent': {}, 'closed': False}
    elif op == 'ECON_SPONSOR_CLOSE':
        exact(p, 'sponsor'); key(p['sponsor']); need(p['sponsor'] in state['sponsor_pools'], 'SPONSOR_MISSING')
        pool = state['sponsor_pools'][p['sponsor']]
        need(actor == pool['issuer'] and not pool['closed'], 'SPONSOR_CLOSE_AUTHORITY')
        if pool['remaining']: move(state, pool['escrow'], actor, pool['resource'], pool['remaining'])
        pool['returned'] = pool['remaining']; pool['remaining'] = 0; pool['closed'] = True
    elif op == 'ECON_REWARD_CREATE':
        exact(p, 'domain resource root expiry eligibility')
        key(p['domain']); label(p['resource']); integer(p['expiry'], True)
        exact(p['root'], 'hash amount'); key(p['root']['hash']); integer(p['root']['amount'], True)
        need(p['resource'] in state['resources'] and height < p['expiry'], 'REWARD_SCOPE')
        need(p['domain'] not in state['reward_domains'], 'REWARD_DOMAIN_REUSE')
        allowed = {'APPROVED', 'SETTLED_SERVICE'}
        from .tokenomics_config import live_policy
        if live_policy(state) is not None:
            allowed |= {'PLEDGE_COVENANT', 'POINTS_SEASON', 'INTEGRATOR_RETRO'}
        need(type(p['eligibility']) is str and p['eligibility'] in allowed, 'REWARD_ELIGIBILITY')
        escrow = digest('COVENANT-REWARD-ESCROW-0.1', tid)
        move(state, actor, escrow, p['resource'], p['root']['amount'])
        record = {**deepcopy(p), 'issuer': actor, 'escrow': escrow,
                  'remaining': p['root']['amount'], 'claimed': 0, 'closed': False}
        if p['eligibility'] in {'PLEDGE_COVENANT', 'POINTS_SEASON', 'INTEGRATOR_RETRO'}:
            record['held'] = 0
        state['reward_campaigns'][tid] = record
        state['reward_domains'][p['domain']] = tid
    elif op == 'ECON_REWARD_CLAIM':
        exact(p, 'campaign grant proof'); key(p['campaign'])
        need(p['campaign'] in state['reward_campaigns'], 'REWARD_CAMPAIGN')
        c = state['reward_campaigns'][p['campaign']]; g = p['grant']; node = grant_node(state['chain'], g)
        need(type(p['proof']) is list and len(p['proof']) <= 16, 'REWARD_PROOF_LIMIT')
        for sibling in p['proof']: node = sum_node(node, sibling)
        need(node == c['root'] and g['domain'] == c['domain'], 'REWARD_PROOF')
        need(actor == g['recipient'], 'REWARD_RECIPIENT')
        need(not c['closed'] and g['unlock'] <= height <= c['expiry'], 'REWARD_WINDOW')
        cid = digest('COVENANT-REWARD-CLAIM-0.1', {'campaign': p['campaign'], 'leaf': grant_node(state['chain'], g)['hash']})
        need(cid not in state['reward_claims'], 'REWARD_ALREADY_CLAIMED')
        if c['eligibility'] == 'SETTLED_SERVICE':
            need(g['receipt'] is not None and g['receipt'] in state['service_jobs'], 'REWARD_SERVICE_MISSING')
            job = state['service_jobs'][g['receipt']]
            need(job['state'] == 'SETTLED' and job['provider'] == actor and job['delivered'] > 0, 'REWARD_SERVICE_UNQUALIFIED')
            if g['receipt'] in state.get('review_jobs',{}):
                from .review_status import performance_confirmed
                need(performance_confirmed(state,g['receipt']),'REWARD_REVIEW_PERFORMANCE_UNCONFIRMED')
            sid = digest('COVENANT-REWARD-SERVICE-0.1', {'campaign': p['campaign'], 'receipt': g['receipt']})
            need(sid not in state['reward_services'], 'REWARD_SERVICE_REUSED'); state['reward_services'][sid] = tid
        need(g['amount'] <= c['remaining'], 'REWARD_BUDGET')
        pay, held, pledge = g['amount'], 0, None
        if c['eligibility'] in {'PLEDGE_COVENANT', 'POINTS_SEASON', 'INTEGRATOR_RETRO'}:
            from .pledge_drop import prepare_claim
            from .tokenomics_config import live_policy
            prepared = prepare_claim(state, c, g, actor, height, live_policy(state)['scale'])
            pay, held, pledge = prepared['pay'], prepared['held'], prepared['pledge']
        need(pay + held == g['amount'], 'REWARD_VESTING')
        if pay:
            move(state, c['escrow'], actor, c['resource'], pay)
        c['remaining'] -= g['amount']
        if held:
            c['held'] = c.get('held', 0) + held
        c['claimed'] += pay
        record = {'campaign': p['campaign'], 'recipient': actor, 'amount': g['amount'], 'purpose': g['purpose'], 'receipt': g['receipt'], 'event': tid}
        if c['eligibility'] in {'PLEDGE_COVENANT', 'POINTS_SEASON', 'INTEGRATOR_RETRO'}:
            record.update(unlocked=pay, held_total=held, held_remaining=held, released=0, height=height, clawed=False, recovered=0, shortfall=0)
            if pledge:
                meter = state['economic_policy']['scale']
                used = list(meter.get('pledges_used') or [])
                need(pledge not in used and len(used) < 4096, 'PLEDGE_REUSED')
                used.append(pledge)
                meter['pledges_used'] = used
                state['economic_policy']['scale'] = meter
        state['reward_claims'][cid] = record
        return [p['campaign']]
    elif op == 'ECON_REWARD_RECLAIM':
        exact(p, 'campaign'); key(p['campaign']); need(p['campaign'] in state['reward_campaigns'], 'REWARD_CAMPAIGN')
        c = state['reward_campaigns'][p['campaign']]
        need(actor == c['issuer'] and height > c['expiry'] and not c['closed'], 'REWARD_RECLAIM')
        if c['remaining']: move(state, c['escrow'], actor, c['resource'], c['remaining'])
        c['returned'] = c['remaining']; c['remaining'] = 0; c['closed'] = True
    elif op == 'ECON_CLEAR':
        exact(p, 'clearing resource transfers approvals'); key(p['clearing']); label(p['resource'])
        need(p['resource'] in state['resources'] and p['clearing'] not in state['clearing_sets'], 'CLEARING_CONTEXT')
        net = clearing_net(p['transfers'])
        authorized(state, sorted(net), len(net), p['approvals'], op, p)
        need(all(v >= 0 or unit_balance(state['authority_available'], who, p['resource']) >= -v for who, v in net.items()), 'CLEARING_FUNDS')
        for who, value in net.items():
            for table in ('balances', 'authority_available'): add(state[table], who, p['resource'], value)
        state['clearing_sets'][p['clearing']] = {'resource': p['resource'], 'transfers': deepcopy(p['transfers']), 'net': net, 'event': tid}
    elif op in {'ECON_LOTTERY', 'ECON_RAFFLE', 'ECON_MINT', 'STAKE_APY', 'LIQUID_STAKE',
                'ECON_REHYPOTHECATE', 'ECON_LIQUID_STAKE'}:
        from .tokenomics_config import live_policy
        if live_policy(state) is None:
            raise ValueError('UNKNOWN_ECONOMIC_OPERATION')
        raise ValueError('OSSIFIED_FORBIDDEN')
    elif op in {'ECON_BOND_LOCK', 'ECON_BOND_RELEASE', 'ECON_REWARD_CLAWBACK', 'ECON_REWARD_VEST',
                'ECON_REBATE_CLAIM', 'ECON_INTEGRATOR_NOTE', 'ECON_INTEGRATOR_PAY', 'ECON_INTEGRATOR_SWEEP',
                'ECON_AD_SUBSIDY', 'ECON_STAKE_LOCK', 'ECON_STAKE_DELEGATE', 'ECON_STAKE_UNBOND',
                'ECON_STAKE_WITHDRAW', 'ECON_STAKE_WORK', 'ECON_STAKE_SLASH', 'ECON_STAKE_CLAIM',
                'ECON_FOUNDER_PAYOUTS', 'ECON_FOUNDER_FORFEIT', 'ECON_UPGRADE_VOTE', 'ECON_UPGRADE_ACTIVATE',
                'ECON_TREASURY_INCOME', 'ECON_TREASURY_SPEND', 'ECON_COST_REPORT',
                'ECON_ENDOWMENT_RELEASE', 'ECON_SERVE_SETTLE', 'ECON_SERVE_VEST', 'ECON_SERVE_FORFEIT',
                'ECON_LIGHT_FETCH', 'ECON_RELAY_FETCH', 'ECON_OFFLINE_ALLOWANCE', 'ECON_OFFLINE_SPEND',
                'ECON_OFFLINE_EQUIVOCATION'}:
        from .tokenomics_config import live_policy
        if live_policy(state) is None:
            # Same error a pre-0.3 node raises, so a 0.1 network does not fork on the error path.
            raise ValueError('UNKNOWN_ECONOMIC_OPERATION')
        from .scale_fees import apply_scale
        for src, dst, resource, qty in apply_scale(state, op, p, actor, tid, height):
            move(state, src, dst, resource, qty)
        return []
    else:
        raise ValueError('UNKNOWN_ECONOMIC_OPERATION')
    return []
