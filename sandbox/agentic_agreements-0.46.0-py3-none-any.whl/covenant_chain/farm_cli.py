"""covenant sync, ble, nfc, gps, pair, and reconcile.

`sync` reads offline packets and applies them to a local reducer view from the
genesis named by `--genesis`. It does not submit to validators or verify a
certificate. A repeated packet is
idempotent. `ble`, `nfc` and `gps` move the same bytes over a platform adapter.
`pair` signs an offline card (keys, alias, chain, genesis) and its NDEF
carrier. The simulator is the default. BlueZ and Linux NFC are named adapters.
GPS has no hardware adapter: the simulator carries the card bytes and a fix.
`reconcile` queues the deal inside one carried `covenant-offline-pair/0.2` card
once. `--state` is a SQLite file that keeps reconciled serials between runs, so
a second transaction under the same account and serial is refused even in a
later run. Queued is not confirmed: `ledger_confirmed` stays false. The gps and
reconcile commands are experimental.
"""

import argparse
import json
import os
import sqlite3
import stat
import sys
from pathlib import Path

from covenant_language.safe_io import atomic_write

from covenant_chain.crypto import load_private, loads, public_key
from covenant_chain.scale.farm import genesis_digest, sync_packets
from covenant_chain.scale.identity import carriers, issue
from covenant_chain.scale.radio import open_adapter


def _read(path, limit=2_000_000):
    with Path(path).open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('CLI_INPUT_SIZE')
    return raw


def _json(path):
    return loads(_read(path))


def _print(payload, code=0):
    print(json.dumps(payload, sort_keys=True))
    return code


def _sync(args):
    genesis = _json(args.genesis)
    packets = [_json(path) for path in args.packet]
    keys = {}
    for item in args.key or []:
        name, path = item.split('=', 1)
        private = load_private(_read(path).decode('ascii'))
        keys[public_key(private) if name == 'auto' else name] = private
    from covenant_chain.app import SCALE_VERSION, MIGRATION_VERSION, genesis_state
    if genesis.get('protocol') not in {SCALE_VERSION, MIGRATION_VERSION}:
        raise ValueError('OFFLINE_CHAIN')
    state = genesis_state(genesis)
    result = sync_packets(state, packets, keys, 1, genesis, settle=args.settle)
    public = []
    for row in result['results']:
        public.append({key: row[key] for key in row if key != 'state'})
    return _print({
        'chain': genesis_digest(genesis), 'height': result['height'], 'results': public,
        'ledger_confirmed': False, 'payment_verified': False,
        'local_applied': all(row['local_applied'] for row in result['results']) if result['results'] else False,
        'assurance': 'LOCAL_REDUCER_NOT_CONSENSUS',
    })


def _bus(path):
    if path is None:
        return {}
    file = Path(path)
    if not file.exists():
        return {}
    loaded = loads(file.read_bytes())
    need_bus = type(loaded) is dict
    if not need_bus:
        raise ValueError('RADIO_BUS')
    return {name: [bytes.fromhex(item) for item in frames] for name, frames in loaded.items()}


def _store(path, bus):
    if path is None:
        return
    payload = {name: [frame.hex() for frame in frames] for name, frames in bus.items()}
    atomic_write(path, json.dumps(payload, sort_keys=True))


def _ble(args):
    bus = _bus(args.bus)
    adapter = open_adapter('ble', args.adapter, bus, args.me)
    if args.ble_command == 'send':
        blob = _read(args.note)
        result = adapter.send(args.peer, blob)
        _store(args.bus, bus)
        return _print(result)
    blob = adapter.recv()
    _store(args.bus, bus)
    if args.out:
        atomic_write(args.out, blob)
    return _print({'adapter': adapter.name, 'bytes': len(blob), 'ledger_confirmed': False})


def _nfc(args):
    bus = _bus(args.bus)
    adapter = open_adapter('nfc', args.adapter, bus, args.me)
    if args.nfc_command == 'write':
        result = adapter.write_tag(args.tag, _read(args.note), phone=args.phone)
        _store(args.bus, bus)
        return _print(result)
    blob = adapter.read_tag(args.tag)
    _store(args.bus, bus)
    if args.out:
        atomic_write(args.out, blob)
    return _print({'adapter': adapter.name, 'bytes': len(blob), 'ledger_confirmed': False})


def _gps(args):
    bus = _bus(args.bus)
    adapter = open_adapter('gps', args.adapter, bus, args.me)
    if args.gps_command == 'send':
        blob = _read(args.note)
        result = adapter.send(args.peer, blob, lat=args.lat, lon=args.lon)
        _store(args.bus, bus)
        return _print(result)
    blob = adapter.recv()
    _store(args.bus, bus)
    if args.out:
        atomic_write(args.out, blob)
    return _print({'adapter': adapter.name, 'bytes': len(blob), 'ledger_confirmed': False})


RECONCILE_STATE_VERSION = 'covenant-offline-reconcile/0.1'
MAX_RECONCILED = 100_000


def _book(path):
    """Owner-private SQLite file and sidecars in a private directory."""
    path = Path(path)
    try:
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError:
        raise ValueError('OFFLINE_STATE_FILE') from None
    db = None
    try:
        info = os.fstat(directory)
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
            raise ValueError('OFFLINE_STATE_FILE')
        fd = os.open(path.name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK,
                     0o600, dir_fd=directory)
        try:
            before = os.fstat(fd)
        finally:
            os.close(fd)
        for name in (path.name, path.name + '-wal', path.name + '-shm', path.name + '-journal'):
            try:
                info = os.stat(name, dir_fd=directory, follow_symlinks=False)
            except FileNotFoundError:
                continue
            if not (stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                    and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0):
                raise ValueError('OFFLINE_STATE_FILE')
        db = sqlite3.connect(path, isolation_level=None, timeout=10)
        after = os.stat(path.name, dir_fd=directory, follow_symlinks=False)
        if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
            raise ValueError('OFFLINE_STATE_FILE')
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA synchronous=FULL')
        return db
    except (OSError, sqlite3.Error, ValueError):
        if db is not None:
            db.close()
        raise ValueError('OFFLINE_STATE_FILE') from None
    finally:
        os.close(directory)


def _reconcile(args):
    from covenant_chain.crypto import key, need
    from covenant_chain.scale.identity import MAX_CARRIED, reconcile
    key(args.chain)
    blob = _read(args.note, MAX_CARRIED)
    queued = []
    db = _book(args.state)
    try:
        # One transaction per run: a concurrent run waits, a crash leaves the old rows.
        db.execute('BEGIN IMMEDIATE')
        db.execute('CREATE TABLE IF NOT EXISTS meta(v TEXT NOT NULL, chain TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS deals(account TEXT NOT NULL, serial INTEGER NOT NULL, '
                   'tx TEXT NOT NULL, PRIMARY KEY(account, serial))')
        rows = db.execute('SELECT v, chain FROM meta').fetchall()
        if not rows:
            db.execute('INSERT INTO meta VALUES (?, ?)', (RECONCILE_STATE_VERSION, args.chain))
        else:
            need(len(rows) == 1 and rows[0][0] == RECONCILE_STATE_VERSION, 'OFFLINE_STATE_VERSION')
            need(rows[0][1] == args.chain, 'OFFLINE_STATE_CHAIN')
        serials = {(account, serial): tx for account, serial, tx in db.execute('SELECT account, serial, tx FROM deals')}
        seen = set(serials.values())
        result = reconcile(blob, args.chain, queued.append, seen, serials)
        if queued:
            need(len(serials) <= MAX_RECONCILED, 'OFFLINE_STATE_FULL')
            db.execute('INSERT INTO deals VALUES (?, ?, ?)', (result['account'], result['serial'], result['tx']))
        db.execute('COMMIT')
    except sqlite3.Error:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise ValueError('OFFLINE_STATE_FILE') from None
    except BaseException:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise
    finally:
        db.close()
    result['queued'] = queued
    return _print(result)


def _pair(args):
    genesis = _json(args.genesis)
    private = load_private(_read(args.key).decode('ascii'))
    chain = genesis_digest(genesis)
    card = issue(private, args.alias, chain, chain)
    carried = carriers(card)
    if args.out:
        atomic_write(args.out, carried['qr'])
    if args.ndef:
        atomic_write(args.ndef, carried['nfc'])
    return _print({
        'did': card['did'], 'alias': card['alias'], 'chain': card['chain'], 'genesis': card['genesis'],
        'keys': len(card['keys']), 'qr_bytes': len(carried['qr']), 'ble_frames': len(carried['ble']),
        'nfc_bytes': len(carried['nfc']), 'ledger_confirmed': False,
    })


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    sync = commands.add_parser('sync', help='Apply offline packets to a local reducer view; no consensus confirmation.')
    sync.add_argument('--genesis', required=True)
    sync.add_argument('--packet', action='append', required=True)
    sync.add_argument('--key', action='append', help='actor-public-key=path, or auto=path')
    sync.add_argument('--settle', action='store_true', help='Decide and execute once evidence is on the agreement.')
    ble = commands.add_parser('ble', help='Send or receive a note over BLE.')
    ble_commands = ble.add_subparsers(dest='ble_command', required=True)
    send = ble_commands.add_parser('send')
    recv = ble_commands.add_parser('recv')
    for sub in (send, recv):
        sub.add_argument('--adapter', default='simulator', choices=('simulator', 'bluez'))
        sub.add_argument('--me', default='device')
        sub.add_argument('--bus')
        sub.add_argument('--out')
    send.add_argument('--peer', required=True)
    send.add_argument('--note', required=True)
    nfc = commands.add_parser('nfc', help='Write or read an NFC tag.')
    nfc_commands = nfc.add_subparsers(dest='nfc_command', required=True)
    write = nfc_commands.add_parser('write')
    read = nfc_commands.add_parser('read')
    for sub in (write, read):
        sub.add_argument('--adapter', default='simulator', choices=('simulator', 'linux'))
        sub.add_argument('--me', default='device')
        sub.add_argument('--bus')
        sub.add_argument('--tag', required=True)
        sub.add_argument('--out')
    write.add_argument('--note', required=True)
    write.add_argument('--phone', action='store_true')
    pair = commands.add_parser('pair', help='Sign an offline pairing card and its NDEF carrier.')
    pair.add_argument('--genesis', required=True)
    pair.add_argument('--key', required=True)
    pair.add_argument('--alias', required=True)
    pair.add_argument('--out', help='QR/BLE canonical bytes')
    pair.add_argument('--ndef', help='NFC NDEF message')
    gps = commands.add_parser('gps', help='Carry a pairing card with a GPS fix over the simulator. The bytes are the card.')
    gps_commands = gps.add_subparsers(dest='gps_command', required=True)
    gps_send = gps_commands.add_parser('send')
    gps_recv = gps_commands.add_parser('recv')
    for sub in (gps_send, gps_recv):
        sub.add_argument('--adapter', default='simulator', choices=('simulator',))
        sub.add_argument('--me', default='device')
        sub.add_argument('--bus')
        sub.add_argument('--out')
    gps_send.add_argument('--peer', required=True)
    gps_send.add_argument('--note', required=True)
    gps_send.add_argument('--lat', required=True, help='Decimal degrees, for example 51.5')
    gps_send.add_argument('--lon', required=True, help='Decimal degrees, for example -0.12')
    reconciled = commands.add_parser('reconcile', help='Queue the deal in one carried pairing card once; not a ledger confirmation.')
    reconciled.add_argument('--chain', required=True, help='Genesis digest the card must name.')
    reconciled.add_argument('--note', required=True, help='Card bytes (QR, BLE or GPS) or an NFC NDEF message.')
    reconciled.add_argument('--state', required=True, help='SQLite file that keeps reconciled serials between runs.')
    args = parser.parse_args(argv)
    try:
        if args.command == 'sync':
            return _sync(args)
        if args.command == 'ble':
            return _ble(args)
        if args.command == 'pair':
            return _pair(args)
        if args.command == 'gps':
            return _gps(args)
        if args.command == 'reconcile':
            return _reconcile(args)
        return _nfc(args)
    except (ValueError, TypeError, KeyError, OSError, RecursionError) as exc:
        print(json.dumps({'status': 'INVALID', 'reason': str(exc)[:256]}), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
