"""Named ledger rules for covenant-native/0.15.

These checks sit beside the 0.14 reducer. They do not replace it and they do
not add a reputation balance. A schedule this set rejects is not adopted.
Arbiter pay and availability bonds stay in the fuzzy-arbitration spec.
"""
from .crypto import exact, integer, key, need

PROTOCOL = 'covenant-native/0.15'
RULE_SET = 'COVENANT-NATIVE-INCENTIVE-RULES-0.15'
MAX_TAKE_BPS = 30
ARBITER_PAY = 'DEFERRED_TO_FUZZY_ARBITRATION_SPEC'
_FIELDS = ('protocol rule_set max_take_bps founder_bps storefront_bps parity_clause '
           'self_preference rank_for_sale notice')


def take_bps(policy):
    _check(policy)
    return policy['max_take_bps']


def _check(policy):
    exact(policy, _FIELDS)
    need(policy['protocol'] == PROTOCOL, 'INCENTIVE_PROTOCOL')
    need(policy['rule_set'] == RULE_SET, 'INCENTIVE_RULE_SET')
    integer(policy['max_take_bps'])
    need(policy['max_take_bps'] <= MAX_TAKE_BPS, 'INCENTIVE_TAKE_CAP')
    integer(policy['founder_bps'])
    need(policy['founder_bps'] <= policy['max_take_bps'], 'INCENTIVE_FOUNDER_INSIDE_TAKE')
    integer(policy['storefront_bps'])
    need(policy['storefront_bps'] <= 10000, 'INCENTIVE_STOREFRONT')
    need(policy['parity_clause'] is False, 'INCENTIVE_PARITY')
    need(policy['self_preference'] is False, 'INCENTIVE_SELF_PREFERENCE')
    need(policy['rank_for_sale'] is False, 'INCENTIVE_RANK_FOR_SALE')
    integer(policy['notice'], True)
    need(policy['notice'] >= 2, 'INCENTIVE_NOTICE')


def launch_policy(founder, storefront_bps=0):
    """The launch cap is 30 bps. The founder share sits inside it."""
    key(founder)
    policy = {'protocol': PROTOCOL, 'rule_set': RULE_SET, 'max_take_bps': MAX_TAKE_BPS,
              'founder_bps': 0, 'storefront_bps': storefront_bps, 'parity_clause': False,
              'self_preference': False, 'rank_for_sale': False, 'notice': 2}
    _check(policy)
    return {'policy': policy, 'founder': founder, 'arbiter_pay': ARBITER_PAY,
            'execution_authorized': False}


def enforce_schedule(previous, proposed):
    """The take cap can hold or fall. It cannot rise. The founder share stays inside it."""
    _check(previous)
    _check(proposed)
    need(proposed['max_take_bps'] <= previous['max_take_bps'], 'INCENTIVE_TAKE_ROSE')
    need(proposed['founder_bps'] <= proposed['max_take_bps'], 'INCENTIVE_FOUNDER_INSIDE_TAKE')
    return {'accepted': True, 'previous_take_bps': previous['max_take_bps'],
            'take_bps': proposed['max_take_bps'], 'founder_bps': proposed['founder_bps'],
            'founder_inside_take': True, 'take_rose': False, 'parity_clause': False,
            'self_preference': False, 'rank_for_sale': False,
            'storefront_bps': proposed['storefront_bps'], 'storefront_declared': True,
            'notice': proposed['notice'], 'protocol': PROTOCOL, 'rule_set': RULE_SET,
            'arbiter_pay': ARBITER_PAY, 'execution_authorized': False}
