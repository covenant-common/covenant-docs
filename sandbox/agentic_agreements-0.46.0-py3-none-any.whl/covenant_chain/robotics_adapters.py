"""Replaceable owner-installed robot drivers. No auto-discovery or key custody.

ROS bridge uses one authenticated persistent connection; VDA uses an owner MQTT
publisher and a separately authenticated, freshness-checked state source. These
callbacks are not installed by mission text. Neither protocol supplies Covenant
consensus, operator authentication, global fencing or safety certification.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import re

from .robotics import binding, bounded, text
from .crypto import exact, integer, need

FLOAT = re.compile(r'-?(?:0|[1-9][0-9]{0,8})(?:\.[0-9]{1,9})?\Z')
ROS_NAME = re.compile(r'/(?:[a-zA-Z_][a-zA-Z0-9_]*)(?:/[a-zA-Z_][a-zA-Z0-9_]*)*\Z')
ROS_TYPE = re.compile(r'[a-zA-Z_][a-zA-Z0-9_]*/action/[a-zA-Z_][a-zA-Z0-9_]*\Z')


def decode_numbers(value):
    """Exact agreed decimal token -> bounded IEEE-754 binary64 at robot boundary.

    The signed value remains a decimal string; this named codec is part of the
    pinned binding. No implicit unit conversion or coordinate transformation.
    """
    if type(value) is dict:
        if '$f64' in value:
            exact(value, '$f64')
            need(type(value['$f64']) is str and FLOAT.fullmatch(value['$f64']), 'ROBOT_FLOAT64_TOKEN')
            return float(value['$f64'])
        return {k: decode_numbers(v) for k, v in value.items()}
    if type(value) is list:
        return [decode_numbers(v) for v in value]
    return value


def wire_bytes(value):
    def check(v, depth=0):
        need(depth <= 24, 'ROBOT_WIRE_DEPTH')
        if type(v) is float:
            need(math.isfinite(v) and abs(v) <= 1e12, 'ROBOT_WIRE_NUMBER')
        elif type(v) is int:
            need(abs(v) <= 2**53-1, 'ROBOT_WIRE_NUMBER')
        elif v is None or type(v) is bool:
            pass
        elif type(v) is str:
            need(len(v) <= 16384 and v.isascii() and all(ord(c) >= 32 for c in v), 'ROBOT_WIRE_STRING')
        elif type(v) is dict:
            need(len(v) <= 128 and all(type(k) is str and len(k) <= 128 for k in v), 'ROBOT_WIRE_OBJECT')
            for k, x in v.items(): check(k, depth+1); check(x, depth+1)
        elif type(v) is list:
            need(len(v) <= 1024, 'ROBOT_WIRE_ARRAY')
            for x in v: check(x, depth+1)
        else:
            raise ValueError('ROBOT_WIRE_TYPE')
    check(value)
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                     allow_nan=False).encode('ascii')
    need(len(raw) <= 65536, 'ROBOT_WIRE_SIZE')
    return raw


def wire_loads(raw):
    """Bounded robot JSON parser; keep this boundary separate from exact JSON."""
    need(type(raw) in (bytes, str) and len(raw) <= 65536, 'ROBOT_WIRE_SIZE')
    def pairs(items):
        value = {}
        for k, v in items:
            need(k not in value, 'ROBOT_WIRE_DUPLICATE_KEY')
            value[k] = v
        return value
    def bad(_): raise ValueError('ROBOT_WIRE_NUMBER')
    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)
    except (RecursionError, UnicodeError) as exc:
        raise ValueError('ROBOT_WIRE_JSON') from exc
    wire_bytes(value)
    return value


def report(ref, sequence, status, wire):
    return {'mission': ref, 'sequence': sequence, 'status': status,
            'evidence': {'wire_sha256': hashlib.sha256(wire_bytes(wire)).hexdigest(),
                         'source': 'owner-authenticated-controller-report', 'world_truth_verified': False}}


class RosbridgeAction:
    """rosbridge 2.0/2.1 JSON action subset. send(dict); receive(goal_id)->dict/None.

    The owner supplies one authenticated connection and bounded callbacks. Keep
    that same connection for cancellation; after reconnect, observe/reconcile
    through the controller rather than reissuing a goal. No ROS installation is
    bundled. Goal argument schemas and workspace limits belong to owner policy.
    """
    def __init__(self, *, robot, action, action_type, semantics, session, implementation,
                 send, receive):
        need(type(action) is str and ROS_NAME.fullmatch(action), 'ROBOT_ROS_ACTION')
        need(type(action_type) is str and ROS_TYPE.fullmatch(action_type), 'ROBOT_ROS_TYPE')
        need(callable(send) and callable(receive), 'ROBOT_TRANSPORT_REQUIRED')
        text(session); bounded(semantics)
        self.action, self.action_type, self.send, self.receive = action, action_type, send, receive
        self.binding = binding(robot, 'rosbridge-action/2.0',
            {'action': action, 'action_type': action_type, 'semantics': deepcopy(semantics),
             'session': session, 'number_codec': 'covenant-decimal-binary64/0.1'}, implementation)

    def validate(self, mission):
        need(mission['capability'] == 'ros.action', 'ROBOT_CAPABILITY')
        bounded(mission['arguments']); wire_bytes(decode_numbers(mission['arguments']))

    def submit(self, ref, mission):
        self.validate(mission)
        self.send({'op': 'send_action_goal', 'id': ref, 'action': self.action,
                   'action_type': self.action_type, 'args': decode_numbers(mission['arguments']), 'feedback': True})

    def cancel(self, ref, mission):
        self.send({'op': 'cancel_action_goal', 'id': ref, 'action': self.action})

    def observe(self, ref, mission, previous=None):
        value = self.receive(ref)
        if value is None: return None
        wire_bytes(value)
        need(type(value) is dict and value.get('id') == ref and value.get('action') == self.action,
             'ROBOT_ROS_CORRELATION')
        op = value.get('op')
        if op == 'action_feedback':
            need(type(value.get('values')) is dict, 'ROBOT_ROS_FEEDBACK')
            status = 'EXECUTING'
        else:
            need(op == 'action_result' and type(value.get('status')) is int and
                 value['status'] in (0, 4, 5, 6) and type(value.get('result')) is bool, 'ROBOT_ROS_RESULT')
            # rosbridge's pinned implementation sets result=True when it can
            # return a structured ROS result, including canceled/aborted goals.
            # GoalStatus, rather than that transport flag, determines outcome.
            need(value['status'] != 4 or value['result'] is True, 'ROBOT_ROS_RESULT')
            need(value['status'] != 0 or value['result'] is False, 'ROBOT_ROS_RESULT')
            need(not value['result'] or type(value.get('values')) is dict, 'ROBOT_ROS_RESULT')
            status = {0: 'UNKNOWN', 4: 'REPORTED_SUCCEEDED', 5: 'REPORTED_CANCELED', 6: 'REPORTED_FAILED'}[value['status']]
        # ROS has no wire sequence/freshness. Retained receive order is only a
        # custody counter, not an anti-replay credential. Preserve it on restart.
        value = report(ref, 0 if previous is None else previous['sequence']+1, status, value)
        if previous is not None and value['evidence'] == previous['evidence']:
            return deepcopy(previous)
        return value



class VDA5050Order:
    """VDA 5050 3.0.0 finite released-route subset, no order extensions.

    publish(topic, bytes, qos=0, retain=False) can be paho.Client.publish.
    receive(order_id)->(topic, dict) is the owner's bounded authenticated queue.
    State timestamp/identity/header/order correlation are checked here. Empty
    state queues mean unknown, never completion. Configure broker ACL/TLS and
    one fleet-control writer separately. MQTT delivery is not execution.
    """
    def __init__(self, *, robot, manufacturer, serial, interface, semantics, implementation,
                 publish, receive, clock, max_state_age=5):
        for v in (manufacturer, serial, interface):
            text(v)
            need(not any(c in v for c in '/+#$'), 'ROBOT_MQTT_TOPIC')
        need(all(callable(f) for f in (publish, receive, clock)), 'ROBOT_TRANSPORT_REQUIRED')
        integer(max_state_age, positive=True); need(max_state_age <= 60, 'ROBOT_FRESHNESS_LIMIT')
        self.manufacturer, self.serial = manufacturer, serial
        self.prefix = f'{interface}/v3/{manufacturer}/{serial}/'
        self.publish, self.receive, self.clock, self.max_state_age = publish, receive, clock, max_state_age
        self.header = 0
        self.binding = binding(robot, 'vda5050-order/3.0.0',
            {'topic_prefix': self.prefix, 'semantics': deepcopy(semantics),
             'subset': 'released-route-no-updates', 'number_codec': 'covenant-decimal-binary64/0.1',
             'max_state_age': max_state_age}, implementation)

    def validate(self, mission):
        need(mission['capability'] == 'vda.order', 'ROBOT_CAPABILITY')
        args = mission['arguments']; exact(args, 'nodes edges')
        nodes, edges = args['nodes'], args['edges']
        need(type(nodes) is list and 1 <= len(nodes) <= 32 and type(edges) is list and
             len(edges) == len(nodes)-1, 'ROBOT_VDA_ROUTE')
        for i, n in enumerate(nodes):
            need(type(n) is dict and n.get('released') is True and type(n.get('sequenceId')) is int and
                 n['sequenceId'] == i*2, 'ROBOT_VDA_RELEASED_ROUTE')
            text(n.get('nodeId')); need(type(n.get('actions')) is list and not n['actions'], 'ROBOT_VDA_ACTIONS_UNSUPPORTED')
            need(set(n) <= {'nodeId', 'sequenceId', 'released', 'actions', 'nodePosition'}, 'ROBOT_VDA_NODE')
            if 'nodePosition' in n:
                position = decode_numbers(n['nodePosition'])
                need(type(position) is dict and {'x', 'y', 'mapId'} <= position.keys() and
                     set(position) <= {'x', 'y', 'mapId', 'theta'}, 'ROBOT_VDA_POSITION')
                text(position['mapId'])
                for f in set(position)-{'mapId'}:
                    need(type(position[f]) in (int, float) and abs(position[f]) <= 1e9, 'ROBOT_VDA_POSITION')
        for i, e in enumerate(edges):
            exact(e, 'edgeId sequenceId released startNodeId endNodeId actions')
            text(e['edgeId'])
            need(type(e['sequenceId']) is int and e['sequenceId'] == i*2+1 and e['released'] is True and
                 e['startNodeId'] == nodes[i]['nodeId'] and e['endNodeId'] == nodes[i+1]['nodeId'] and
                 e['actions'] == [] and type(e['actions']) is list, 'ROBOT_VDA_EDGE')
        wire_bytes(decode_numbers(args))

    def _header(self):
        now = self.clock(); integer(now)
        self.header = (self.header + 1) % (2**32)
        return {'headerId': self.header,
                'timestamp': datetime.fromtimestamp(now, timezone.utc).isoformat().replace('+00:00', 'Z'),
                'version': '3.0.0', 'manufacturer': self.manufacturer, 'serialNumber': self.serial}

    def submit(self, ref, mission):
        self.validate(mission)
        payload = self._header() | {'orderId': ref, 'orderUpdateId': 0} | decode_numbers(mission['arguments'])
        self.publish(self.prefix+'order', wire_bytes(payload), qos=0, retain=False)

    def cancel(self, ref, mission):
        # cancelOrder cancels the robot's current order, not a named order. Do not
        # emit it unless fresh state still identifies this exact outstanding one.
        observed = self._state(ref)
        need(observed is not None, 'ROBOT_VDA_CANCEL_NEEDS_CURRENT_STATE')
        payload = self._header() | {'actions': [{'actionId': 'cancel-'+ref,
                   'actionType': 'cancelOrder', 'blockingType': 'NONE'}]}
        self.publish(self.prefix+'instantActions', wire_bytes(payload), qos=0, retain=False)

    def _state(self, ref):
        received = self.receive(ref)
        if received is None: return None
        need(type(received) in (tuple, list) and len(received) == 2, 'ROBOT_VDA_STATE')
        topic, s = received
        wire_bytes(s)
        need(topic == self.prefix+'state' and type(s) is dict and
             s.get('version') == '3.0.0' and s.get('manufacturer') == self.manufacturer and
             s.get('serialNumber') == self.serial and s.get('orderId') == ref and
             type(s.get('orderUpdateId')) is int and s['orderUpdateId'] == 0, 'ROBOT_VDA_CORRELATION')
        integer(s.get('headerId')); need(s['headerId'] < 2**32, 'ROBOT_VDA_HEADER')
        now = self.clock(); integer(now)
        timestamp = s.get('timestamp'); text(timestamp)
        need(timestamp.endswith('Z'), 'ROBOT_VDA_TIME')
        try: observed = datetime.fromisoformat(timestamp[:-1]+'+00:00').timestamp()
        except (ValueError, OverflowError): raise ValueError('ROBOT_VDA_TIME') from None
        need(observed <= now and now-observed <= self.max_state_age, 'ROBOT_VDA_STALE_STATE')
        for field in ('nodeStates', 'edgeStates', 'actionStates', 'instantActionStates', 'errors'):
            need(type(s.get(field)) is list, 'ROBOT_VDA_STATE')
        need(type(s.get('driving')) is bool, 'ROBOT_VDA_STATE')
        return s

    def observe(self, ref, mission, previous=None):
        s = self._state(ref)
        if s is None: return None
        need(type(s.get('lastNodeSequenceId')) is int, 'ROBOT_VDA_STATE')
        integer(s['lastNodeSequenceId']); text(s.get('lastNodeId'))
        need(type(s.get('safetyState')) is dict and
             s['safetyState'].get('activeEmergencyStop') in ('MANUAL', 'REMOTE', 'NONE') and
             type(s['safetyState'].get('fieldViolation')) is bool, 'ROBOT_VDA_STATE')
        # This subset's mission is an actionless route, not cargo fulfillment.
        # Correlated final-node exhaustion is only a controller success report.
        end = mission['arguments']['nodes'][-1]
        exhausted = not s['nodeStates'] and not s['edgeStates'] and not s['driving']
        status = ('REPORTED_SUCCEEDED' if exhausted and
                  s.get('lastNodeId') == end['nodeId'] and
                  type(s.get('lastNodeSequenceId')) is int and
                  s['lastNodeSequenceId'] == end['sequenceId'] and
                  s.get('paused', False) is False and s.get('operatingMode') == 'AUTOMATIC' and
                  s['safetyState']['activeEmergencyStop'] == 'NONE' and
                  not s['safetyState']['fieldViolation'] else 'EXECUTING')
        cancel_id = 'cancel-'+ref
        for a in s['instantActionStates']:
            if a.get('actionId') == cancel_id and a.get('actionStatus') == 'FINISHED':
                status = 'REPORTED_CANCELED'
        if s['errors']:
            status = 'UNKNOWN'  # error need not mean stopped or terminal failure
        value = report(ref, s['headerId'], status, s)
        value['evidence']['route_exhausted'] = exhausted
        return value


class AdoptedRobotDriver:
    """Owner callback interface for Open-RMF, native ROS/DDS or future protocols.

    This is an extension boundary, not a bundled implementation of those stacks.
    validate is pure; submit/cancel are bounded side effects; observe is read-only
    and returns the robotics report schema (or None). Pin protocol semantics and
    code, authenticate endpoints and enforce fencing outside the signed text.
    """
    def __init__(self, *, robot, protocol, interface, implementation, validate,
                 submit, observe, cancel):
        need(all(callable(f) for f in (validate, submit, observe, cancel)), 'ROBOT_DRIVER_CALLBACKS')
        self.binding = binding(robot, protocol, interface, implementation)
        self.validate, self.submit, self.observe, self.cancel = validate, submit, observe, cancel


def massrobotics_status(raw, *, expected_robot, expected_datum, now, max_age=5):
    """Read-only MassRobotics status subset, not identity proof or command API."""
    import uuid
    integer(now); integer(max_age, positive=True)
    need(max_age <= 60 and type(raw) is str and len(raw) <= 65536, 'ROBOT_STATUS_SIZE')
    value = wire_loads(raw)
    for identity in (expected_robot, expected_datum):
        need(type(identity) is str and str(uuid.UUID(identity)) == identity, 'ROBOT_STATUS_UUID')
    need(type(value) is dict and value.get('uuid') == expected_robot, 'ROBOT_STATUS_IDENTITY')
    location = value.get('location')
    need(type(location) is dict and location.get('planarDatum') == expected_datum,
         'ROBOT_STATUS_FRAME')
    need(value.get('operationalState') in ('navigating', 'idle', 'disabled', 'offline', 'charging',
         'waitingHumanEvent', 'waitingExternalEvent', 'waitingInternalEvent', 'manualOverride'),
         'ROBOT_STATUS_STATE')
    for f in ('x', 'y'):
        need(type(location.get(f)) in (int, float), 'ROBOT_STATUS_LOCATION')
    angle = location.get('angle')
    exact(angle, 'x y z w')
    need(all(type(v) in (int, float) for v in angle.values()) and
         abs(sum(v*v for v in angle.values())-1) <= 0.000001, 'ROBOT_STATUS_QUATERNION')
    stamp = value.get('timestamp'); text(stamp)
    need(stamp.endswith('Z'), 'ROBOT_STATUS_TIME')
    when = datetime.fromisoformat(stamp[:-1]+'+00:00').timestamp()
    need(when <= now and now-when <= max_age, 'ROBOT_STATUS_STALE')
    return {'robot': expected_robot, 'datum': expected_datum,
            'reported_state': value['operationalState'], 'reported_at': stamp,
            'wire_sha256': hashlib.sha256(raw.encode('ascii')).hexdigest(),
            'identity_verified': False, 'execution_authorized': False,
            'physical_delivery_verified': False, 'payment_verified': False}
