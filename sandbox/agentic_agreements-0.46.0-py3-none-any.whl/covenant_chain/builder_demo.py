"""Run a disposable, from-scratch builder journey with real local settlement.

    python -m covenant_chain.builder_demo

Fresh keys and imaginary COV exist only in this process. It does not contact a
network, reserve real funds, publish private inputs, or certify independence.
The reconstruction exercise uses retained objects, not a durable database.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from covenant_language import builder_programme as builders
from covenant_language import developer_apps, developer_economics, mechanism_plans
from . import app
from .builder_programme_runtime import BuilderProgrammeRegistry
from .crypto import digest, sign
from .developer_runtime import ApplicationRegistry, native_fee_policy
from .economics import policy_at
from .ecosystem import approve
from .fixtures import economy_fixture
from .mechanism_runtime import MechanismRegistry, invoke_local


def _invoice(context, arguments):
    if type(arguments) is not dict or set(arguments) != {'hours', 'rate', 'customer'}:
        raise ValueError('DEMO_INVOICE_FIELDS')
    if any(type(arguments[key]) is not int or not 0 <= arguments[key] <= 10000
           for key in ('hours', 'rate')):
        raise ValueError('DEMO_INVOICE_INTEGER')
    if type(arguments['customer']) is not str or len(arguments['customer']) > 1024:
        raise ValueError('DEMO_PRIVATE_CUSTOMER')
    return {'invoice_amount': arguments['hours'] * arguments['rate'],
            'customer_record': digest('BUILDER-DEMO-CUSTOMER-0.1', arguments['customer'])}


class BuilderDemo:
    """Synthetic owner harness, deliberately separate from keyless agent tools."""
    def __init__(self):
        self.keys, self.accounts, genesis = economy_fixture()
        genesis['resources']['COV'] = {'unit': 'disposable-builder-demo-smallest-unit'}
        genesis['accounts'][self.accounts['owner']]['COV'] = 1_000_000
        genesis['economics']['fee_policy'] = native_fee_policy(
            'COV', 3, 1,
            [{'account': self.accounts['v0'], 'bps': 10000, 'purpose': 'OPERATORS'}],
            [self.accounts['owner']], 1, 5)['policy']
        self.state = app.genesis_state(genesis)
        self.height = 0
        self.account_names = {value: name for name, value in self.accounts.items()}
        self.context = digest('BUILDER-DEMO-CONTEXT-0.1', 'one privately prepared invoice')
        self.nonce = digest('BUILDER-DEMO-NONCE-0.1', 'one order')
        self.private_customer = 'Synthetic private customer input retained only by this owner'
        self._ran = False
        self.manifest = mechanism_plans.manifest(
            'Owner invoice implementation', 'compute',
            digest('BUILDER-DEMO-INTERFACE-0.1', 'bounded invoice fields'),
            hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            {'invoice': {'mode': 'LOCAL', 'description': 'Calculate an exact local invoice'}}
        )['manifest']
        self.base_policy = developer_economics.draft(
            'Optional separate helper service', 'COV', 25,
            [{'account': self.accounts['agent'], 'bps': 10000, 'purpose': 'HELPER_SERVICE'}])
        self.app_policy = developer_economics.draft(
            'Builder invoice service', 'COV', 80,
            [{'account': self.accounts['worker'], 'bps': 8000, 'purpose': 'BUILDER'},
             {'account': self.accounts['agent'], 'bps': 1000, 'purpose': 'EXPLICIT_DEPENDENCY_SHARE'},
             {'account': self.accounts['v1'], 'bps': 1000, 'purpose': 'COMMONS'}])
        self.mechanisms, self.applications = self._empty_application_registry()
        route = {'invoice': {'mechanism': mechanism_plans.mechanism_id(self.manifest),
                             'operation': 'invoice', 'mode': 'LOCAL',
                             'interface': self.manifest['semantics']}}
        base = developer_apps.draft('InvoiceFoundation', '1', self.accounts['agent'],
                                     route, self.base_policy['id'])
        self.applications.install(base['manifest'], self._sign('agent', base['assent_payload']))
        release = developer_apps.draft('FreelanceInvoices', '1', self.accounts['worker'],
                                        route, self.app_policy['id'], parent=base['id'],
                                        dependencies=[base['id']])
        self.applications.install(release['manifest'], self._sign('worker', release['assent_payload']))
        self.application = release['id']
        self.dependency = base['id']
        self.exports = [self.applications.export(base['id']),
                        self.applications.export(release['id'])]
        self.awards = [
            {'name': 'InitialAdapter', 'kind': 'BOUNTY',
             'recipient': self.accounts['worker'], 'amount': 20,
             'deliverable': digest('BUILDER-DEMO-DELIVERABLE-0.1', 'adapter initial milestone'),
             'acceptors': sorted([self.accounts['owner'], self.accounts['resolver']])},
            {'name': 'MaintainedAdapter', 'kind': 'MAINTENANCE',
             'recipient': self.accounts['worker'], 'amount': 30,
             'deliverable': digest('BUILDER-DEMO-DELIVERABLE-0.1', 'agreed maintenance interval'),
             'acceptors': sorted([self.accounts['owner'], self.accounts['resolver']])}]
        self.programme = builders.programme_draft(
            'Builder owner demonstration', self.accounts['owner'], 'COV',
            'integer smallest native COV balance unit', [self.application],
            coordination_fee=10,
            shares=[{'account': self.accounts['v3'], 'bps': 5000, 'purpose': 'FOUNDING_SERVICE'},
                    {'account': self.accounts['v1'], 'bps': 5000, 'purpose': 'ECOSYSTEM_SERVICE'}],
            awards=self.awards,
            terms='One exact service; separate one-time bounty and maintenance acceptance; '
                  'refunds require a separate all-account native approval.')
        self.programme_signature = self._sign('owner', self.programme['assent_payload'])
        self.registry = BuilderProgrammeRegistry(self.applications,
                                                  {account: account for account in self.accounts.values()})
        self.registry.adopt(self.programme['programme'], self.programme_signature)

    def _empty_application_registry(self):
        mechanisms = MechanismRegistry()
        mechanisms.register(self.manifest, {'invoice': _invoice})
        applications = ApplicationRegistry(
            mechanisms, {self.accounts[name]: self.accounts[name] for name in ('worker', 'agent')},
            [self.app_policy['policy'], self.base_policy['policy']])
        return mechanisms, applications

    def _sign(self, name, payload):
        return sign(self.keys[name], payload['label'], payload['body'])

    def _native_execute(self, plan):
        payload = deepcopy(plan['payload'])
        payload['approvals'] = [approve(self.keys[self.account_names[actor]], self.state['chain'],
                                         plan['operation'], payload)
                                for actor in plan['required_accounts']]
        owner = self.accounts['owner']
        transaction = app.make_transaction(
            self.keys['owner'], self.state['chain'], self.state['nonces'].get(owner, 0),
            plan['operation'], payload, app.ECONOMIC_VERSION,
            fee={'policy': policy_at(self.state, self.height + 1)['id'],
                 **plan['native_fee_envelope']})
        state = app.apply_transaction(self.state, transaction, self.height + 1)
        app.invariant(state)
        self.state = state
        self.height += 1
        return app.transaction_id(transaction)

    def _award(self, award):
        offered = self.registry.award_offer(
            self.programme['id'], award['name'], self.state['chain'], self.context,
            0, 100, award['amount'] + 10, 10)
        delivered = self.registry.award_delivery(
            offered['offer'], [digest('BUILDER-DEMO-AWARD-EVIDENCE-0.1', award['name'])])
        signed_delivery = {'delivery': delivered['delivery'],
                           'signature': self._sign('worker', delivered['assent_payload'])}
        acceptance = self.registry.award_acceptance(offered['offer'], signed_delivery)
        approvals = [{'account': actor,
                      'signature': self._sign(self.account_names[actor], acceptance['assent_payload'])}
                     for actor in award['acceptors']]
        plan = self.registry.prepare_award(
            offered['offer'], signed_delivery, acceptance['acceptance'], approvals,
            self.state['chain'], self.height + 1, 'COV')
        return {'award': award['name'], 'kind': award['kind'], 'amount': award['amount'],
                'offer': offered['id'], 'acceptance': acceptance['id'],
                'clearing': plan['payload']['clearing'], 'event': self._native_execute(plan)}

    def _reconstruct(self, quote, approvals, delivery, acceptance):
        mechanisms, applications = self._empty_application_registry()
        for exported in self.exports:
            applications.install(exported['manifest'], exported['publisher_signature'])
        registry = BuilderProgrammeRegistry(applications,
                                             {account: account for account in self.accounts.values()})
        registry.adopt(self.programme['programme'], self.programme_signature)
        return registry.prepare_settlement(quote, approvals, [delivery], acceptance,
                                            self.state['chain'], self.height + 1, 'COV')

    def run(self):
        if self._ran:
            raise ValueError('DEMO_ALREADY_RUN')
        self._ran = True
        ready = self.applications.prepare(
            self.application, 'invoice', {'hours': 3, 'rate': 30, 'customer': self.private_customer},
            self.context, [self.accounts['owner']])
        quoted = self.registry.quote(
            self.programme['id'], [{'call': ready['call'], 'performer': self.accounts['worker']}],
            self.accounts['owner'], self.state['chain'], self.context, self.nonce,
            0, 100, 100, 10)
        quote_approvals = [{'account': actor,
                            'signature': self._sign(self.account_names[actor], quoted['assent_payload'])}
                           for actor in quoted['required_signers']]
        observation = invoke_local(
            self.mechanisms, plan=ready['plan'],
            approvals=[{'controller': self.accounts['owner'],
                        'signature': self._sign('owner', ready['assent_payload'])}],
            expected_id=ready['id'], expected_controllers=[self.accounts['owner']],
            step='call', binding=0, payload=ready['call'])
        delivered = self.registry.delivery(
            quoted['quote'], ready['request'],
            [digest('BUILDER-DEMO-OUTPUT-0.1', observation['result'])])
        signed_delivery = {'delivery': delivered['delivery'],
                           'signature': self._sign('worker', delivered['assent_payload'])}
        accepted = self.registry.acceptance(quoted['quote'], [signed_delivery])
        signed_acceptance = {'acceptance': accepted['acceptance'],
                             'signature': self._sign('owner', accepted['assent_payload'])}
        plan = self.registry.prepare_settlement(
            quoted['quote'], quote_approvals, [signed_delivery], signed_acceptance,
            self.state['chain'], self.height + 1, 'COV')
        rebuilt = self._reconstruct(quoted['quote'], quote_approvals,
                                     signed_delivery, signed_acceptance)
        if rebuilt['payload'] != plan['payload']:
            raise ValueError('DEMO_RECONSTRUCTION_CHANGED')
        event = self._native_execute(plan)
        before_replay = app.state_hash(self.state)
        try:
            self._native_execute(rebuilt)
        except ValueError as error:
            replay_refusal = str(error)
        else:
            raise ValueError('DEMO_REPLAY_NOT_REFUSED')
        if replay_refusal != 'CLEARING_CONTEXT' or app.state_hash(self.state) != before_replay:
            raise ValueError('DEMO_REPLAY_NOT_ATOMIC')
        award_receipts = [self._award(award) for award in self.awards]
        refund = self.registry.prepare_refund(
            quoted['quote'], [{'account': self.accounts['worker'], 'amount': 10}],
            digest('BUILDER-DEMO-DISPUTE-0.1', 'agreed ten-unit remediation'),
            self.state['chain'], self.height + 1, 10)
        refund_event = self._native_execute(refund)
        public = {'profile': builders.VERSION, 'status': 'LOCAL_SYNTHETIC_JOURNEY_COMPLETED',
                  'chain': self.state['chain'], 'programme': self.programme['id'],
                  'application': self.application, 'dependency': self.dependency,
                  'application_levels': developer_apps.resolve(
                      self.application, [x['manifest'] for x in self.exports])['levels'],
                  'quote': quoted['id'], 'service_amount': quoted['quote']['service_amount'],
                  'maximum_total': quoted['quote']['maximum_total'],
                  'native_fee_cap_per_transaction': 10,
                  'selected_service_count': len(quoted['quote']['services']),
                  'unselected_dependency_price_not_added': self.base_policy['policy']['unit_price'],
                  'delivery': delivered['id'], 'acceptance': accepted['id'],
                  'clearing': plan['payload']['clearing'], 'event': event,
                  'local_invoice_result': observation['result']['invoice_amount'],
                  'opening_verified': self.registry.verify_call_opening(
                      quoted['quote'], ready['call'])['opening_verified'],
                  'reconstruction_same_native_payload': rebuilt['payload'] == plan['payload'],
                  'replay_refusal': replay_refusal, 'replay_atomic': True,
                  'awards': award_receipts,
                  'agreed_refund': {'amount': 10, 'case': refund['case'],
                                   'clearing': refund['payload']['clearing'], 'event': refund_event},
                  'native_transactions': self.height,
                  'balances': {name: self.state['balances'].get(account, {}).get('COV', 0)
                               for name, account in self.accounts.items()},
                  'total_COV_supply': self.state['supply']['COV'],
                  'measured_native_fees': self.state['balances'].get(self.accounts['v0'], {}).get('COV', 0),
                  'limits': ['All keys, identities, customer inputs and balances are synthetic.',
                             'Local reconstruction is not crash-safe persistent storage or cross-host replication.',
                             'Programme budgets are unreserved; actual native funds and all-account approval were required.',
                             'Dependency lineage inherits no rollup or consensus security.',
                             'Signed delivery and reviewer attestations do not establish independent truth or independence.',
                             'Call arguments were withheld; public request hashes are not encryption or dictionary-resistant hiding.',
                             'Native consensus enforces native approvals, funds, fee envelope and clearing replay; not business quote expiry.',
                             'No external demand, token appreciation, adoption or earned grant entitlement is demonstrated.']}
        if self.private_customer in json.dumps(public):
            raise ValueError('DEMO_PRIVATE_INPUT_EXPOSED')
        return public


def run_demo():
    return BuilderDemo().run()


def main():
    print(json.dumps(run_demo(), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
