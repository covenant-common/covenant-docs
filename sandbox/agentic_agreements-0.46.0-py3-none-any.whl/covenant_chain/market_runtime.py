"""Bounded autonomous market operations, using the existing native 0.14 ledger.

The installed host controls keys and budgets. This does not turn a local budget
into an on-chain mandate, guarantee liquidity, or change historical VOID rules.
"""
from copy import deepcopy
from dataclasses import dataclass,asdict

from . import app,prediction
from .crypto import integer,key,need,verify
from .workflow_store import identifier
from .cooperation import _meaning


@dataclass(frozen=True)
class MarketPolicy:
    creator: str
    resource: str
    source_policies: tuple
    primary_members: tuple
    appeal_members: tuple
    max_markets: int=8
    lifetime_collateral: int=100000
    lifetime_purchase_cost: int=100000
    allow_public_metadata: bool=False
    accept_unanswered_appeal_void: bool=False
    require_funded_oracle_services: bool=True

    def __post_init__(self):
        key(self.creator)
        need(type(self.resource) is str and 0<len(self.resource)<=80,'MARKET_AUTONOMY_POLICY')
        for values in (self.source_policies,self.primary_members,self.appeal_members):
            need(type(values) is tuple and 0<len(values)<=64 and len(set(values))==len(values),'MARKET_AUTONOMY_POLICY')
            for value in values:key(value)
        for n in (self.max_markets,self.lifetime_collateral,self.lifetime_purchase_cost):integer(n,True)
        for v in (self.allow_public_metadata,self.accept_unanswered_appeal_void,self.require_funded_oracle_services):
            need(type(v) is bool,'MARKET_AUTONOMY_POLICY')


class MarketRuntime:
    def __init__(self,workflow,policy):
        need(type(policy) is MarketPolicy and workflow.genesis['protocol'] in {app.PREDICTION_VERSION, app.SCALE_VERSION, app.MIGRATION_VERSION},'MARKET_AUTONOMY_PROFILE')
        self.workflow=workflow;self.policy=policy
        body=asdict(policy)
        for k in ('source_policies','primary_members','appeal_members'):body[k]=list(body[k])
        self.policy_id=identifier('COVENANT-MARKET-AUTONOMY-POLICY-0.1',body)
        # A different policy must use a separately adopted custody context.
        stored=[e['body']['value'] for e in workflow.store.events() if e['body']['kind']=='MARKET_POLICY']
        need(not stored or stored[0]==body,'MARKET_AUTONOMY_POLICY_CHANGED')
        if not stored:workflow.store.append('MARKET_POLICY',self.policy_id,body)

    def _request(self,request):
        from .workflow import REQUEST
        need(type(request) is str and REQUEST.fullmatch(request),'MARKET_AUTONOMY_REQUEST')

    def _records(self):
        result={}
        for e in self.workflow.store.events():
            if e['body']['kind']=='MARKET':result[e['body']['task']]=e['body']['value']
        return result

    def _adopted(self,market,snap):
        key(market);need(market in snap.state['prediction_markets'],'PREDICTION_MISSING')
        records=self._records()
        known=any(v.get('market')==market for v in records.values())
        # A pending creation's deterministic transaction ID becomes adopted only
        # once this history proves that exact creation actually finalized.
        known=known or any(v.get('transaction')==market and market in snap.state['events'] for v in records.values())
        need(known,'MARKET_NOT_ADOPTED_BY_RUNTIME')
        return snap.state['prediction_markets'][market]

    def create(self,request,terms,documents,acceptances=None,oracle_tasks=()):
        from .workflow import REQUEST
        need(type(request) is str and REQUEST.fullmatch(request),'MARKET_AUTONOMY_REQUEST')
        w=self.workflow;p=self.policy
        with w.store.exclusive():
            snap=w.snapshot()
            prediction.validate_terms(terms,0)
            prediction.verify_materials(terms,documents)
            need(p.allow_public_metadata,'MARKET_PUBLIC_METADATA_NOT_ADOPTED')
            need(p.accept_unanswered_appeal_void,'MARKET_UNANSWERED_APPEAL_VOID_NOT_ADOPTED')
            need(terms['resource']==p.resource and terms['source_policy'] in p.source_policies,'MARKET_AUTONOMY_SCOPE')
            need(set(terms['primary']['members'])<=set(p.primary_members) and
                 set(terms['appeal']['members'])<=set(p.appeal_members),'MARKET_UNADOPTED_PANEL')
            label=identifier('COVENANT-AUTONOMOUS-MARKET-0.1',dict(policy=self.policy_id,request=request))
            intent=prediction.terms_id(terms);old=self._records().get(label)
            if old is not None:
                need(old['terms']==intent and old['oracle_tasks']==list(oracle_tasks),'MARKET_REQUEST_CHANGED')
                if old.get('market') in snap.state['prediction_markets']:return self.inspect(old['market'])
            else:
                need(len(self._records())<p.max_markets,'MARKET_COUNT_BUDGET')
            prediction.validate_terms(terms,snap.head['height'])
            need(type(oracle_tasks) in (tuple,list) and len(oracle_tasks)<=32 and len(set(oracle_tasks))==len(oracle_tasks),'MARKET_ORACLE_TASKS')
            assigned={e['body']['task']:e['body']['value'] for e in w.store.events() if e['body']['kind']=='ORACLE_ASSIGNMENT'}
            provided=set()
            for task in oracle_tasks:
                record=w.store.get(task);job=snap.state.get('service_jobs',{}).get(record.get('job'))
                need(job is not None and job['state']=='BOOKED' and job['quantity']>0 and
                     snap.state['balances'].get(job['payment_escrow'],{}).get(job['settlement_resource'],0)==job['quantity'],
                     'MARKET_ORACLE_SERVICE_NOT_FUNDED')
                if p.require_funded_oracle_services:
                    agreement=_meaning(record['proposal'])['terms']['agreement']
                    need(type(agreement) is dict and agreement.get('market_oracle')==dict(terms=intent,member=job['provider']),
                         'MARKET_ORACLE_TERMS_NOT_BOUND')
                    need(task not in assigned or assigned[task]==label,'MARKET_ORACLE_ALREADY_ASSIGNED')
                provided.add(job['provider'])
            if p.require_funded_oracle_services:
                need(set(terms['primary']['members']+terms['appeal']['members'])<=provided,'MARKET_ORACLE_SERVICES_REQUIRED')
            if acceptances is None and w.broker is not None:
                acceptances=w.broker('PREDICTION_APPOINT',dict(creator=p.creator,terms=deepcopy(terms)),None,snap)
            if acceptances is None:return dict(status='PANEL_ACCEPTANCES_REQUIRED',terms=intent,execution_authorized=False)
            payload=dict(terms=deepcopy(terms),acceptances=deepcopy(acceptances))
            if old and old.get('payload') is not None:
                # Signatures can be randomized. Retries retain the original ones.
                payload=old['payload']
            if p.require_funded_oracle_services:
                for task in oracle_tasks:
                    if task not in assigned:w.store.append('ORACLE_ASSIGNMENT',task,label)
            record=dict(terms=intent,request=request,market=None,oracle_tasks=list(oracle_tasks),payload=payload)
            w.store.append('MARKET',label,record)
            tx,_=w._send('market:'+label+':create',p.creator,'PREDICTION_CREATE',payload)
            record.update(transaction=tx['transaction'],market=tx['transaction'] if tx['status']=='CERTIFIED' else None)
            w.store.append('MARKET',label,record)
            return self.inspect(record['market']) if record['market'] else dict(status='CREATION_PENDING',transaction=tx['transaction'])

    def fund(self,request,market,quantity):
        self._request(request);integer(quantity,True);w=self.workflow;p=self.policy
        with w.store.exclusive():
            snap=w.snapshot();m=self._adopted(market,snap);cost=quantity*m['terms']['payout_per_unit'];integer(cost,True)
            ref='market-fund:'+identifier('COVENANT-MARKET-FUND-0.1',dict(policy=self.policy_id,request=request))
            old=w.journal.request(ref)
            if old is not None:need(old['envelope']['body']['payload']==dict(market=market,quantity=quantity),'MARKET_REQUEST_CHANGED')
            w.store.reserve('market-collateral:'+self.policy_id,ref,cost,p.lifetime_collateral)
            record,_=w._send(ref,p.creator,'PREDICTION_MINT',dict(market=market,quantity=quantity))
            return dict(transaction=record['transaction'],status=record['status'],market=market,
                        collateral_resource=p.resource,collateral_reserved_by_request=cost)

    def trade(self,request,order,approvals):
        self._request(request);w=self.workflow;p=self.policy
        with w.store.exclusive():
            snap=w.snapshot();m=self._adopted(order['market'],snap)
            need(p.creator in {order['seller'],order['buyer']},'MARKET_TRADER_NOT_ADOPTED')
            integer(order['quantity'],True);integer(order['price']);cost=order['quantity']*order['price'];integer(cost)
            ref='market-trade:'+identifier('COVENANT-MARKET-TRADE-REQUEST-0.1',dict(policy=self.policy_id,request=request))
            old=w.journal.request(ref)
            payload=dict(order=deepcopy(order),approvals=deepcopy(approvals))
            if old is not None:
                need(old['envelope']['body']['payload']['order']==order,'MARKET_REQUEST_CHANGED')
                payload=old['envelope']['body']['payload']
            if order['buyer']==p.creator:w.store.reserve('market-purchases:'+self.policy_id,ref,cost,p.lifetime_purchase_cost)
            record,_=w._send(ref,p.creator,'PREDICTION_TRADE',payload)
            return dict(transaction=record['transaction'],status=record['status'],market=order['market'])

    def resolve(self,request,market,action,**values):
        """Report only through adopted panel custody; no outcome override."""
        self._request(request);w=self.workflow;p=self.policy
        with w.store.exclusive():
            snap=w.snapshot();m=self._adopted(market,snap)
            need(action in {'report','challenge','finalize','redeem','merge'},'MARKET_ACTION')
            actor=p.creator;op={'report':'PREDICTION_REPORT','challenge':'PREDICTION_CHALLENGE',
                'finalize':'PREDICTION_FINALIZE','redeem':'PREDICTION_REDEEM','merge':'PREDICTION_MERGE'}[action]
            if action=='report':
                actor=values.pop('reporter')
                panel=m['terms']['primary' if values.get('phase')=='PRIMARY' else 'appeal']['members']
                need(actor in panel,'MARKET_REPORTER_NOT_ADOPTED')
                approval=values.pop('report_approval',None)
                body=dict(chain=w.chain,market=market,reporter=actor,report=deepcopy(values))
                reviewed=w.broker is not None and w.broker('PREDICTION_REPORT',deepcopy(body),None,snap) is True
                if not reviewed and approval is not None:
                    verify(app.controller(snap.state,actor),'COVENANT-MARKET-REPORT-APPROVAL-0.1',body,approval)
                    reviewed=True
                if not reviewed:return dict(status='REPORT_APPROVAL_REQUIRED',label='COVENANT-MARKET-REPORT-APPROVAL-0.1',
                                             body=body,execution_authorized=False)
            payload=dict(market=market,**deepcopy(values))
            ref='market-action:'+identifier('COVENANT-MARKET-ACTION-REQUEST-0.1',dict(policy=self.policy_id,request=request))
            record,_=w._send(ref,actor,op,payload)
            return dict(transaction=record['transaction'],status=record['status'],market=market)

    def inspect(self,market):
        snap=self.workflow.snapshot();m=self._adopted(market,snap)
        fees=[r for r in snap.state['fee_receipts'].values() if r.get('actor')==self.policy.creator]
        return dict(market=market,record=deepcopy(m),certified_as_of=snap.head,
                    creator_fee_allocations_all_operations=[deepcopy(r['allocations']) for r in fees],
                    price_is_probability=False,world_truth='NOT_ESTABLISHED',latest_head_known=False,
                    custody_policy='OPERATOR_LOCAL_SIGNER_AND_LIFETIME_BUDGET',
                    oracle_payment='SEPARATE_FUNDED_SERVICE_COVENANTS' if self.policy.require_funded_oracle_services else 'NOT_REQUIRED_BY_THIS_LOCAL_POLICY')
