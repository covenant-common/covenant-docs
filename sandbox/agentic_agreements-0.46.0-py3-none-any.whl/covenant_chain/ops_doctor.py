"""covenant-doctor: check an AAP service's configuration before it starts.

    covenant-doctor node --genesis g.json --peers p.json --member v0 --key k --db d --port 9180
    covenant-doctor gateway --config /etc/covenant/rpc-gateway.json --listener rpc
    covenant-doctor --plan plan.json     every service of one host in one report
    covenant-doctor --list               the services it knows

The doctor takes the service's own arguments, parses them with that service's
own parser and runs that service's own validators. It never starts a listener,
writes a store, creates a key or contacts a network; SQLite stores are read
through snapshots. Each finding carries a stable code and a remediation.
Exit 0: no FAIL. Exit 1: at least one FAIL. A PASS is a configuration check,
not proof that a peer, payment or agreement is valid.

A plan file is ``{"v": "covenant-doctor-plan/1", "services": [{"service": "node",
"args": ["--genesis", ...]}, ...]}``.
"""
import errno
import importlib
import json
import os
from pathlib import Path
import re
import socket
import sqlite3
import stat
import sys
import tempfile

from . import backup
from .observability import refusal_code

PLAN_VERSION = 'covenant-doctor-plan/1'
# covenant_chain.node.main's empty-block wait when COVENANT_EMPTY_BLOCK_INTERVAL is unset.
NODE_CLI_EMPTY_BLOCK_WAIT = 5.0
MAX_PLAN = 1024 * 1024
SERVICES = {
    'node': ('covenant_chain.node', 'validator node (covenant-chain)'),
    'gateway': ('covenant_chain.network_gateway', 'TLS peer or RPC gateway (covenant-gateway)'),
    'agent-server': ('covenant_chain.agent_server', 'MCP stdio host (covenant-agent)'),
    'agent-native': ('covenant_agent.server', 'agent-native MCP stdio host and settlement ledger (covenant-agent-native)'),
    'agent-gateway': ('covenant_chain.agent_gateway_host', 'verified agent gateway host'),
    'public-web': ('covenant_chain.public_web', 'public web origin (covenant-public-web serve)'),
    'welcome': ('covenant_chain.welcome_app', 'welcome application (covenant-welcome)'),
    'handoff': ('covenant_chain.owner_handoff_app', 'owner handoff application (covenant-handoff)'),
    'replica': ('covenant_chain.provider_replica_node', 'provider replica'),
    'private-replica': ('covenant_chain.private_provider_node', 'private provider replica'),
    'agent-connector': ('covenant_chain.agent_connector', 'MCP HTTP connector'),
}

REMEDIATION = {
    # doctor and environment
    'ARGUMENTS': 'The arguments do not parse. Run the service with --help and pass the same arguments here.',
    'PYTHON_VERSION': 'Use Python 3.11 or newer.',
    'PLATFORM_UNSUPPORTED': 'Run AAP services on Linux or macOS; Windows is not qualified for these services.',
    'UNAPPROVED_CRYPTOGRAPHY_BACKEND': 'Install cryptography >=50.0.2,<51 from requirements/runtime.lock and retest.',
    'UNAPPROVED_OPENSSL_BACKEND': 'Update the OpenSSL that cryptography links to the adopted floor and retest.',
    'UNAPPROVED_TLS_BACKEND': 'Update the Python ssl/OpenSSL runtime to the adopted floor and retest.',
    'AIOHTTP_REQUIRED': 'Install the network extra: pip install --require-hashes -r requirements/network.lock.',
    'UNAPPROVED_GATEWAY_BACKEND': 'Install aiohttp >=3.14.4,<3.15 from requirements/network.lock.',
    'FILE_MISSING': 'The named file does not exist. Create it or correct the path.',
    'FILE_PERMISSION': 'The service user cannot read the named file. Fix ownership or mode.',
    'FILE_NOT_REGULAR': 'The path must be a regular file, not a directory, link or device.',
    'JSON_INVALID': 'The file is not valid JSON. Restore it from the adopted copy.',
    'OS_ERROR': 'The operating system refused the operation. Check the path, permissions and free space.',
    'CHECK_FAILED': 'An unexpected error stopped this check. Rerun with the same arguments and report only the code.',
    'PORT_RANGE': 'Use a TCP port from 1 to 65535 (0 picks a free port where the service allows it).',
    'PORT_IN_USE': 'Another process holds this port. If it is this service already running, this is expected.',
    'BIND_ADDRESS_UNAVAILABLE': 'This host has no interface with that address. Use an address the host owns.',
    'PORT_PRIVILEGED': 'Ports below 1024 need privileges. Use a higher port behind the host firewall or proxy.',
    'OPS_PORT_CONFLICT': 'The operator port must differ from the service port.',
    'SERVICE_RUNNING': 'The store lock is held: the service is running. Stop it before restore or migration.',
    'RESTORE_PENDING': 'A restore was interrupted. Run covenant-backup recover PATH before starting the service.',
    'STORE_INTEGRITY': 'A database failed PRAGMA integrity_check. Stop the service and restore a verified backup.',
    'STORE_PRIVATE_DIRECTORY': 'The store directory must be owned by the service user with mode 0700.',
    'STORE_PRIVATE_FILE': 'The store file must be a single-linked regular file owned by the service user with mode 0600.',
    'STORE_MISSING': 'The store does not exist yet. The service creates it on first start, or restore a backup.',
    # node
    'NODE_GENESIS': 'The genesis file does not parse or does not open a genesis state. Use the adopted genesis bytes.',
    'NODE_SINGLE_PARTY_SETUP': 'Genesis has single-party zero-knowledge pools. Use a verified ceremony, or pass --allow-single-operator-setup for a local experiment that holds no value.',
    'NODE_VALUE_BEARING_SINGLE_PARTY_SETUP': 'Genesis gives value-bearing pools a single-party setup. Replace it with a verified multi-party ceremony output.',
    'NODE_KEY_FORMAT': 'The signing key file does not hold one Ed25519 private key in the adopted encoding.',
    'NODE_MEMBER_NOT_VALIDATOR': 'This member is not in the genesis committee; the node will run as a non-signing observer.',
    'LAUNCH_VALIDATOR_KEY_MISMATCH': 'The key does not match this member in the committee. Use the member\'s adopted key.',
    'NODE_JOURNAL_CHAIN_MISMATCH': 'The journal belongs to another chain than this genesis. Use this chain\'s journal or a new --db.',
    'NODE_JOURNAL_MEMBER_MISMATCH': 'The journal was written by another member. Use this member\'s journal.',
    'NODE_STORAGE_DIRECTORY_MISSING': 'The --db parent directory does not exist; the node creates it with mode 0700 on start.',
    'NODE_BASE_TIMEOUT': 'Use a --base-timeout above 0 and at most 60 seconds.',
    'EMPTY_BLOCK_INTERVAL': 'COVENANT_EMPTY_BLOCK_INTERVAL must be a number of seconds from 0 to 3600.',
    'NODE_TIMEOUT_BELOW_PACING': 'The empty-block wait (COVENANT_EMPTY_BLOCK_INTERVAL, 5 seconds when unset) is not '
                                 'shorter than --base-timeout, so an idle height times out before its proposer may '
                                 'propose and needs extra rounds. Use --base-timeout of the wait plus 2 seconds '
                                 '(7 for the default wait), as the testnet kit and the mainnet validator unit do.',
    'NODE_BOOTSTRAP_HISTORY': 'The bootstrap history does not verify against this genesis. Obtain certified history again.',
    'NODE_FEEDBACK_OWNER': 'The feedback owner file must hold the pinned founder public key or descriptor.',
    'NODE_FEEDBACK_REPORTERS': 'The feedback reporters file must be a JSON list of signing keys.',
    'LAUNCH_KEY_FILE': 'The key or config file cannot be opened without following links. Check the path.',
    'LAUNCH_KEY_REGULAR': 'The key or config path must be a regular file.',
    'LAUNCH_KEY_OWNER': 'The key or config file must be owned by the service user.',
    'LAUNCH_KEY_PERMISSIONS': 'Run chmod 600 on the key or config file.',
    'LAUNCH_KEY_LINKS': 'The key or config file must have exactly one hard link.',
    'LAUNCH_KEY_SIZE': 'The key or config file is empty or larger than 32 KiB.',
    'LAUNCH_KEY_ENCODING': 'The key or config file must be ASCII.',
    'LAUNCH_PEERS': 'peers.json must map 1 to 64 member names to endpoints.',
    'LAUNCH_PEER_NAME': 'Peer names must be 1 to 80 characters.',
    'LAUNCH_PEER_URL': 'Peer URLs must be printable ASCII up to 256 characters.',
    'LAUNCH_PEER_LOOPBACK': 'Without --peer-tls-config, peers must be http://127.0.0.1:PORT (or another literal loopback).',
    'LAUNCH_STORAGE_REGULAR': 'A journal file or sidecar is not a regular file. Inspect the --db directory.',
    'LAUNCH_STORAGE_OWNER': 'Journal files must be owned by the service user.',
    'LAUNCH_STORAGE_PERMISSIONS': 'Run chmod 600 on the journal files (.sqlite3, -wal, -shm, .lock).',
    'LAUNCH_STORAGE_LINKS': 'Journal files must have exactly one hard link.',
    # transport and gateway
    'TLS_PEERS': 'HTTPS peers must map 1 to 64 member names to endpoints.',
    'TLS_MEMBER': 'Member names must be printable ASCII of 1 to 80 characters.',
    'TLS_ENDPOINT': 'Endpoints must be printable ASCII up to 256 characters.',
    'TLS_LITERAL_IP': 'Use a literal IP address in HTTPS peer URLs; DNS names are not accepted.',
    'TLS_IP_ZONE': 'Remove the IPv6 zone identifier from the address.',
    'TLS_IP_MAPPED': 'Use the IPv4 address itself, not an IPv4-mapped IPv6 address.',
    'TLS_IP_CANONICAL': 'Write the address in its canonical form.',
    'TLS_IP_RANGE': 'Multicast and unspecified addresses cannot be peers.',
    'TLS_PEER_URL': 'HTTPS peer URLs must be https://IP:PORT with no path, query or credentials.',
    'TLS_PINS': 'The TLS config needs 1 to 64 members with certificate pins.',
    'TLS_PIN_MEMBERS': 'Every peer member needs pins, and every pinned member must be a peer.',
    'TLS_PIN_ROTATION': 'Each member has one or two distinct pins (current and next).',
    'TLS_PIN_ENCODING': 'Pins are lowercase hex SHA-256 digests of the DER certificate.',
    'TLS_PIN_SHARED_IDENTITY': 'Two members share a certificate pin. Give each member its own certificate.',
    'TLS_CONFIG_LIMIT': 'The TLS config file is larger than 64 KiB.',
    'TLS_FILE_PATH': 'TLS file paths in the config must be absolute.',
    'FIELDS': 'A configuration object has missing or unexpected fields. Compare it with the template in deploy/.',
    'GATEWAY_BACKEND_IPV4_LOOPBACK': 'The gateway backend must be http://127.0.0.1:PORT, the validator\'s loopback listener.',
    'GATEWAY_BIND_IP': 'Listener hosts must be literal IP addresses.',
    'GATEWAY_PORT': 'Listener ports must be integers from 1 to 65535.',
    'GATEWAY_CONFIG_PATH': 'The listener tls_config path must be absolute.',
    'GATEWAY_LISTENER_COLLISION': 'The peer and RPC listeners need different host:port pairs.',
    'GATEWAY_TOKEN_LIMIT': 'Configure at most 512 RPC token hashes.',
    'GATEWAY_TOKEN_HASH': 'RPC tokens are configured by their lowercase SHA-256 hex digest, never the secret.',
    'GATEWAY_TOKEN_IDENTITY': 'Each RPC token needs a distinct identity of 1 to 80 characters.',
    'GATEWAY_TOKEN_NOT_CHAIN_KEY': 'A 64-hex identity looks like a chain key; use a plain admission label.',
    'GATEWAY_SCOPE': 'Token scopes are a sorted, distinct subset of proof, read and submit.',
    'GATEWAY_TOKEN_RATE': 'Token rates and bursts are integers from 0 to 1000.',
    'GATEWAY_PRICE': 'The admission price is a non-negative integer.',
    'GATEWAY_TLS_CONFIG_REQUIRED': 'The selected listener needs its tls_config.',
    # agent hosts
    'AGENT_TOOL_FILTER_REQUIRES_LIST': '--tool needs --list-tools.',
    'LOCAL_KEY_REQUIRES_HOST': '--local-key-dir needs --keyless or --workflow-config.',
    'AGENT_STATELESS_REQUIRES_KEYLESS_WITHOUT_LOCAL_KEY': '--stateless works only with --keyless and without --local-key-dir.',
    'AGENT_HOME_PRIVATE': 'The agent home ($COVENANT_HOME or ~/.covenant) must be a directory owned by the user.',
    'AGENT_HOME_PERMISSIONS': 'Run chmod 700 on the agent home; the server tightens it on start.',
    'AGENT_FORUM_KEY_FORMAT': 'forum.key must hold 64 lowercase hex characters. Move the damaged file aside; a new disposable key is made on start.',
    'AGENT_CONFIG_JSON': 'The host config does not decode. Restore the owner-installed copy.',
    'RUNTIME_HOST_VERSION': 'A --workflow-config must have version covenant-runtime-host/0.1.',
    'HOST_PRIVATE_KEY_FILE': 'Key files named in the host config must be regular files with mode 0600.',
    'HOST_PRIVATE_KEY_SIZE': 'A key file named in the host config is too large.',
    'HOST_VERSION': 'The agent-native config version is not supported by this release.',
    'KEY_FILE_MODE': 'A config holding a seed must be mode 0600: chmod 600 FILE.',
    'SETTLEMENT_NOT_INITIALIZED': 'The settlement ledger file does not exist. Initialize it explicitly or restore it.',
    'SETTLEMENT_STORAGE': 'The settlement ledger must be a single-linked 0600 SQLite file with a covenant-reference-settlement record.',
    'GATEWAY_HOST_VERSION': 'The gateway host config needs version covenant-agent-gateway-host/0.1.',
    'GATEWAY_HOST_CONFIG': 'The gateway host config has missing or unknown keys.',
    'GATEWAY_HOST_UPSTREAM': 'upstream needs url and optionally headers_file and allow_insecure_loopback.',
    'GATEWAY_HOST_PORT': 'The gateway host port must be an integer from 0 to 65535.',
    # public web, welcome, handoff
    'WEB_ORIGIN': 'Use an https:// origin without path, query or credentials (http://127.0.0.1 for a local preview).',
    'WEB_DB_SYMLINK': 'The publication database must not be a symbolic link.',
    'WEB_DB_ORIGIN': 'The database was created for another origin. Use that origin or a new database.',
    'WEB_BIND': 'Use a literal IP address for --bind.',
    'WEB_BIND_NOT_LOOPBACK': 'The origin listens beyond loopback. Put an HTTPS reverse proxy in front and firewall the port.',
    'HOME_IN_USE': 'Another process holds this home. Stop it, or use another --home.',
    'HOME_STORAGE_JSON': 'The saved state file does not parse. Restore the home from a verified backup.',
    # replicas and connector
    'REPLICA_PRIVATE_CONFIGURATION': 'Replica config, key and token files must be regular files with mode 0600.',
    'REPLICA_SIGNER': 'The member must be in the spec and its key must match the spec\'s validator key.',
    'REPLICA_PRIVATE_DIRECTORY': 'The replica directory must be mode 0700 and not a link.',
    'REPLICA_STORAGE_IDENTITY': 'identity.json does not match this spec and member. Use this replica\'s own directory.',
    'REPLICA_SAFETY_STORAGE_MISSING': 'identity.json exists without consensus.sqlite3: signing storage was lost. Do not reinitialize; recover it or rotate the key.',
    'REPLICA_LOOPBACK_PEERS': 'Replica peers must be http://127.0.0.1:PORT endpoints of members in the spec.',
    'PRIVATE_PROVIDER_KEY': 'privacy_key_file must hold 32 bytes as 64 hex characters.',
    'CONNECTOR_POLICY_VERSION': 'The connector policy version is not supported; regenerate it with --init-directory.',
    'CONNECTOR_GRANTS': 'The policy needs 1 to 64 grants.',
    'CONNECTOR_DUPLICATE_GRANT': 'Two grants share one token digest.',
}


class Note(Exception):
    """A WARN or INFO outcome with a stable code; failures raise ValueError/OSError."""

    def __init__(self, status, code):
        super().__init__(code)
        self.status, self.code = status, code


def _fail(code):
    raise ValueError(code)


def _warn(code):
    raise Note('WARN', code)


def _info(code):
    raise Note('INFO', code)


def code_of(exc):
    """The stable code an exception carries; OS errors map to a short class code."""
    if isinstance(exc, backup.BackupError):
        return exc.code
    if isinstance(exc, json.JSONDecodeError):
        return 'JSON_INVALID'
    if isinstance(exc, FileNotFoundError):
        return 'FILE_MISSING'
    if isinstance(exc, PermissionError):
        return 'FILE_PERMISSION'
    if isinstance(exc, (IsADirectoryError, NotADirectoryError)):
        return 'FILE_NOT_REGULAR'
    code = refusal_code(exc)
    if code != 'UNCLASSIFIED':
        return code
    if isinstance(exc, OSError):
        return 'OS_ERROR'
    if isinstance(exc, sqlite3.Error):
        return 'STORE_INTEGRITY'
    if isinstance(exc, SystemExit):
        return 'ARGUMENTS'
    return 'CHECK_FAILED'


def remediation(code):
    return REMEDIATION.get(code, 'See the service runbook in docs/OPERATIONS.html for this code.')


class Doctor:
    def __init__(self, service):
        self.service = service
        self.rows = []

    def check(self, name, fn):
        """Run one check. Returns fn's value, or None after recording a FAIL/WARN/INFO."""
        try:
            value = fn()
        except Note as note:
            self.rows.append({'check': name, 'status': note.status, 'code': note.code,
                              'remediation': remediation(note.code)})
            return None
        except Exception as exc:  # Every failure becomes a stable code; a doctor never crashes on bad input.
            code = code_of(exc)
            self.rows.append({'check': name, 'status': 'FAIL', 'code': code, 'remediation': remediation(code)})
            return None
        self.rows.append({'check': name, 'status': 'PASS', 'code': None, 'remediation': None})
        return value

    def report(self):
        statuses = {row['status'] for row in self.rows}
        status = 'FAIL' if 'FAIL' in statuses else 'WARN' if 'WARN' in statuses else 'PASS'
        return {'service': self.service, 'status': status, 'checks': self.rows,
                'started_service': False, 'network_contacted': False}


# ------------------------------------------------------------------ shared checks
def _python_ok():
    return sys.version_info >= (3, 11)


def _posix():
    return os.name == 'posix'


def _environment(doctor):
    doctor.check('python', lambda: _python_ok() or _fail('PYTHON_VERSION'))
    doctor.check('platform', lambda: _posix() or _fail('PLATFORM_UNSUPPORTED'))

    def backend():
        from .security import require_patched_backend
        require_patched_backend()
    doctor.check('cryptography_backend', backend)


def _port(host, port, *, running=False, allow_zero=True):
    if type(port) is not int or not (0 if allow_zero else 1) <= port <= 65535:
        _fail('PORT_RANGE')
    if port == 0:
        return
    family = socket.AF_INET6 if ':' in host else socket.AF_INET
    with socket.socket(family, socket.SOCK_STREAM) as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            probe.bind((host, port))
        except OSError as exc:
            if exc.errno == errno.EADDRINUSE:
                raise Note('INFO' if running else 'WARN', 'SERVICE_RUNNING' if running else 'PORT_IN_USE') from None
            if exc.errno == errno.EADDRNOTAVAIL:
                _fail('BIND_ADDRESS_UNAVAILABLE')
            if exc.errno == errno.EACCES:
                _fail('PORT_PRIVILEGED')
            raise


def _ops_port(doctor, args, service_port=None):
    port = getattr(args, 'ops_port', None)
    if port is None:
        return

    def check():
        if service_port and port == service_port:
            _fail('OPS_PORT_CONFLICT')
        _port('127.0.0.1', port)
    doctor.check('operator_listener', check)


def _restore(doctor, path):
    doctor.check('restore_pending', lambda: backup.refuse_pending_restore(path))


def _lock_held(path):
    """True when a lifetime flock is held by another process; False when free or absent."""
    path = Path(path)
    if not path.exists():
        return False
    import fcntl
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except OSError:
            return True
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    finally:
        os.close(fd)


def _private_directory(path, code='STORE_PRIVATE_DIRECTORY'):
    info = os.lstat(path)
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
        _fail(code)


def _private_file(path, code='STORE_PRIVATE_FILE'):
    info = os.lstat(path)
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077
            or info.st_nlink != 1):
        _fail(code)


def _store_facts(kind, path):
    """Identity and state of a live store, read through SQLite snapshots in a scratch directory."""
    scratch = tempfile.mkdtemp(prefix='covenant-doctor-')
    try:
        view = backup._live_view(backup.KINDS[kind], path, scratch)
        return backup._facts(backup.KINDS[kind], view)
    finally:
        import shutil
        shutil.rmtree(scratch, ignore_errors=True)


def _sqlite_ok(path):
    """PRAGMA integrity_check on a snapshot; the live file is never opened for writing by the doctor."""
    if not Path(path).exists():
        raise Note('INFO', 'STORE_MISSING')
    scratch = tempfile.mkdtemp(prefix='covenant-doctor-')
    try:
        copy = Path(scratch) / 'check.sqlite'
        backup.snapshot(path, copy)
        if not backup.integrity(copy):
            _fail('STORE_INTEGRITY')
    except backup.BackupError:
        _fail('STORE_INTEGRITY')
    finally:
        import shutil
        shutil.rmtree(scratch, ignore_errors=True)


def _read_json(path, code):
    from .crypto import loads
    try:
        return loads(Path(path).read_text())
    except (UnicodeError, ValueError) as exc:
        found = code_of(exc)
        raise ValueError(found if found not in ('CHECK_FAILED', 'JSON_INVALID') else code) from None


# ------------------------------------------------------------------ services
def _node(doctor, args):
    from . import crypto
    from .launch_security import check_storage_paths, read_signing_key, validate_peers
    _environment(doctor)

    def genesis_check():
        from .app import genesis_state
        genesis = _read_json(args.genesis, 'NODE_GENESIS')
        try:
            genesis_state(genesis)
        except (ValueError, KeyError, TypeError):
            _fail('NODE_GENESIS')
        return genesis
    genesis = doctor.check('genesis', genesis_check)
    chain = crypto.genesis_id(genesis) if genesis is not None else None

    if genesis is not None:
        def setup():
            from .shielded import sandbox_pools, value_bearing_sandbox
            if value_bearing_sandbox(genesis):
                _fail('NODE_VALUE_BEARING_SINGLE_PARTY_SETUP')
            if sandbox_pools(genesis):
                if not args.allow_single_operator_setup:
                    _fail('NODE_SINGLE_PARTY_SETUP')
                raise Note('WARN', 'NODE_SINGLE_PARTY_SETUP')
        doctor.check('zero_knowledge_setup', setup)

    def peers_check():
        peers = _read_json(args.peers, 'LAUNCH_PEERS')
        if args.peer_tls_config:
            from .transport import read_config, validate_https_peers, validate_pins
            validate_https_peers(peers)
            config = read_config(args.peer_tls_config)
            validate_pins(config['pins'])
        else:
            validate_peers(peers)
    doctor.check('peers', peers_check)

    def key_check():
        key = crypto.load_private(read_signing_key(args.key))
        if genesis is None:
            return
        validators = genesis.get('validators') or {}
        if args.member not in validators:
            raise Note('WARN', 'NODE_MEMBER_NOT_VALIDATOR')
        if crypto.public_key(key) != validators[args.member]:
            _fail('LAUNCH_VALIDATOR_KEY_MISMATCH')

    def guarded_key():
        try:
            return key_check()
        except (ValueError, TypeError) as exc:
            code = code_of(exc)
            raise ValueError(code if code.startswith(('LAUNCH_', 'NODE_')) else 'NODE_KEY_FORMAT') from None
    doctor.check('signing_key', guarded_key)

    base = str(args.db)
    doctor.check('storage_files', lambda: check_storage_paths(base, causal=args.causal_receipts,
                                                              feedback=args.feedback_owner is not None))
    doctor.check('storage_directory', lambda: Path(base).parent.is_dir() or _warn('NODE_STORAGE_DIRECTORY_MISSING'))
    _restore(doctor, base)
    running = _lock_held(base + '.lock')

    def journal():
        if not Path(base + '.sqlite3').exists():
            raise Note('INFO', 'STORE_MISSING')
        _sqlite_ok(base + '.sqlite3')
        identity, _state = _store_facts('node', base)
        if identity.get('member') != args.member:
            _fail('NODE_JOURNAL_MEMBER_MISMATCH')
        if genesis is not None and not backup.journal_matches(identity, genesis):
            _fail('NODE_JOURNAL_CHAIN_MISMATCH')
    doctor.check('journal', journal)

    def timing():
        import math
        if not (type(args.base_timeout) in (int, float) and math.isfinite(args.base_timeout) and 0 < args.base_timeout <= 60):
            _fail('NODE_BASE_TIMEOUT')
        raw = os.environ.get('COVENANT_EMPTY_BLOCK_INTERVAL')
        # The node's own reading: unset means the command line's wait; set but empty means no wait.
        wait = NODE_CLI_EMPTY_BLOCK_WAIT if raw is None else 0.0
        if raw:
            try:
                value = float(raw)
            except ValueError:
                _fail('EMPTY_BLOCK_INTERVAL')
            if not 0 <= value <= 3600:
                _fail('EMPTY_BLOCK_INTERVAL')
            wait = value
        # A round-0 proposer must be allowed to propose before the round-0 timeout; otherwise
        # every idle height spends rounds that cannot succeed (consensus.Engine._duration).
        if wait > 0 and args.base_timeout <= wait:
            _warn('NODE_TIMEOUT_BELOW_PACING')
    doctor.check('timing', timing)

    if args.bootstrap and genesis is not None:
        def bootstrap():
            from .proofs import verify_history
            history = _read_json(args.bootstrap, 'NODE_BOOTSTRAP_HISTORY')
            try:
                verify_history(genesis, history, chain)
            except (ValueError, KeyError, TypeError):
                _fail('NODE_BOOTSTRAP_HISTORY')
        doctor.check('bootstrap', bootstrap)
    if args.feedback_owner:
        doctor.check('feedback_owner', lambda: Path(args.feedback_owner).read_text().strip() or _fail('NODE_FEEDBACK_OWNER'))
    if args.feedback_reporters:
        doctor.check('feedback_reporters', lambda: type(_read_json(args.feedback_reporters, 'NODE_FEEDBACK_REPORTERS')) is list
                     or _fail('NODE_FEEDBACK_REPORTERS'))
    doctor.check('listener', lambda: _port('127.0.0.1', args.port, running=running))
    if running:
        doctor.check('service', lambda: _info('SERVICE_RUNNING'))
    _ops_port(doctor, args, args.port)


def _gateway(doctor, args):
    from . import crypto
    from . import network_gateway as gateway
    from .launch_security import read_signing_key
    _environment(doctor)

    def library():
        status = gateway.gateway_backend_status()
        if not status['acceptable']:
            _fail('UNAPPROVED_GATEWAY_BACKEND')
        from .transport import require_tls_backend
        require_tls_backend()
    doctor.check('gateway_backend', library)
    config = doctor.check('config', lambda: gateway.validate_gateway(crypto.loads(read_signing_key(args.config))))
    if config is None:
        return
    settings = config[args.listener]

    def tls():
        from .transport import read_config, validate_pins
        loaded = read_config(settings['tls_config'])
        if args.listener == 'peer':
            validate_pins(loaded['pins'])
        for name in ('ca_file', 'cert_file', 'key_file'):
            if name in loaded and not Path(loaded[name]).is_file():
                _fail('FILE_MISSING')
    doctor.check('tls', tls)
    doctor.check('listener', lambda: _port(settings['host'], settings['port'], allow_zero=False))
    _ops_port(doctor, args, settings['port'])


def _agent_home(doctor, home):
    _restore(doctor, home)

    def home_check():
        if not os.path.lexists(home):
            raise Note('INFO', 'STORE_MISSING')
        info = os.lstat(home)
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
            _fail('AGENT_HOME_PRIVATE')
        if info.st_mode & 0o077:
            raise Note('WARN', 'AGENT_HOME_PERMISSIONS')
    doctor.check('home', home_check)

    def forum():
        path = Path(home) / 'forum.key'
        if not path.exists():
            raise Note('INFO', 'STORE_MISSING')
        _private_file(path)
        if re.fullmatch(r'[0-9a-f]{64}', path.read_text().strip()) is None:
            _fail('AGENT_FORUM_KEY_FORMAT')
    doctor.check('forum_key', forum)
    for name in ('a2a/workflow.sqlite', 'requests/requests.sqlite'):
        doctor.check('store:' + name, lambda name=name: _sqlite_ok(Path(home) / name))


def _agent_server(doctor, args):
    _environment(doctor)

    def mode():
        if args.tool and not args.list_tools:
            _fail('AGENT_TOOL_FILTER_REQUIRES_LIST')
        keyless = args.keyless or not (args.config or args.workflow_config)
        if args.local_key_dir and not (keyless or args.workflow_config):
            _fail('LOCAL_KEY_REQUIRES_HOST')
        if args.stateless and (not keyless or args.local_key_dir):
            _fail('AGENT_STATELESS_REQUIRES_KEYLESS_WITHOUT_LOCAL_KEY')
        return keyless
    keyless = doctor.check('mode', mode)
    if keyless and not args.stateless:
        _agent_home(doctor, os.environ.get('COVENANT_HOME', str(Path.home() / '.covenant')))
    if args.config or args.workflow_config:
        def config():
            from .agent_tools import decode
            with open(args.workflow_config or args.config, 'rb') as stream:
                raw = stream.read(16_000_001)
            try:
                value = decode(raw)
            except (ValueError, TypeError):
                _fail('AGENT_CONFIG_JSON')
            if args.workflow_config and (type(value) is not dict or value.get('version') != 'covenant-runtime-host/0.1'):
                _fail('RUNTIME_HOST_VERSION')
            return value
        value = doctor.check('config', config)
        if args.workflow_config and type(value) is dict:
            from .runtime_host import private_text
            for section, field in (('validator', 'key_file'), ('network', 'key_file'), ('directory_board', 'key_file')):
                path = (value.get(section) or {}).get(field) if type(value.get(section)) is dict else None
                if path:
                    doctor.check(f'{section}.{field}', lambda path=path: private_text(path) and None)
            for section, field in (('local_keys', 'directory'), ('requests', 'directory'), ('workflow', 'directory'),
                                   ('a2a', 'directory'), ('network', 'directory')):
                path = (value.get(section) or {}).get(field) if type(value.get(section)) is dict else None
                if path and os.path.lexists(path):
                    doctor.check(f'{section}.{field}', lambda path=path: _private_directory(path))
    if args.local_key_dir and os.path.lexists(args.local_key_dir):
        doctor.check('local_key_dir', lambda: _private_directory(args.local_key_dir))


def _agent_native(doctor, args):
    _environment(doctor)
    if args.keyless:
        return
    from covenant_agent.mcp import HOST_VERSION
    from covenant_agent.server import load_config

    def config():
        try:
            value = load_config(args.config)
        except Exception as exc:
            code = getattr(exc, 'code', None) or code_of(exc)
            raise ValueError(code if re.fullmatch(r'[A-Z][A-Z0-9_]{2,63}', str(code)) else 'AGENT_CONFIG_JSON') from None
        if type(value) is not dict or value.get('version', HOST_VERSION) != HOST_VERSION:
            _fail('HOST_VERSION')
        return value
    value = doctor.check('config', config)
    path = value.get('settlement_db') if type(value) is dict else None
    if path:
        _restore(doctor, path)

        def ledger():
            if not Path(path).exists():
                _fail('SETTLEMENT_NOT_INITIALIZED')
            _private_file(path, 'SETTLEMENT_STORAGE')
            _sqlite_ok(path)
            _store_facts('settlement', path)
        doctor.check('settlement_ledger', ledger)


def _agent_gateway(doctor, args):
    _environment(doctor)
    if args.token_digest:
        return
    from . import crypto
    from .agent_gateway_host import HOST_VERSION
    from .runtime_host import private_text

    def config():
        with open(args.config, 'rb') as handle:
            value = crypto.loads(handle.read())
        if type(value) is not dict or value.get('version') != HOST_VERSION:
            _fail('GATEWAY_HOST_VERSION')
        required = {'version', 'directory', 'policy', 'log_key_file', 'card'}
        optional = {'upstream', 'public_url', 'hosts', 'auditor_token_sha256', 'records_rpc', 'port', 'timeout', 'mark_seconds'}
        if not required <= set(value) <= required | optional:
            _fail('GATEWAY_HOST_CONFIG')
        upstream = value.get('upstream')
        if not (type(upstream) is dict and 'url' in upstream and set(upstream) <= {'url', 'headers_file', 'allow_insecure_loopback'}):
            _fail('GATEWAY_HOST_UPSTREAM')
        return value
    value = doctor.check('config', config)
    if value is None:
        return
    doctor.check('log_key_file', lambda: crypto.load_private(private_text(value['log_key_file'])) and None)
    if 'headers_file' in value['upstream']:
        doctor.check('upstream_headers', lambda: private_text(value['upstream']['headers_file']) and None)
    _restore(doctor, value['directory'])
    if os.path.lexists(value['directory']):
        doctor.check('decision_log', lambda: (_private_directory(value['directory']),
                                              _sqlite_ok(Path(value['directory']) / 'workflow.sqlite')) and None)
    port = value.get('port', 8740)
    doctor.check('listener', lambda: _port('127.0.0.1', port) if type(port) is int else _fail('GATEWAY_HOST_PORT'))
    _ops_port(doctor, args, port)


def _public_web(doctor, args):
    import ipaddress
    from . import public_web
    _environment(doctor)
    if args.action != 'serve':
        _fail('ARGUMENTS')
    doctor.check('origin', lambda: public_web.origin_url(args.origin) and None)
    _restore(doctor, args.db)

    def database():
        path = Path(args.db)
        if not os.path.lexists(path):
            raise Note('INFO', 'STORE_MISSING')
        if path.is_symlink():
            _fail('WEB_DB_SYMLINK')
        _private_file(path)
        _sqlite_ok(path)
        identity, _state = _store_facts('public-web', path)
        if identity['origin'] != public_web.origin_url(args.origin):
            _fail('WEB_DB_ORIGIN')
    doctor.check('database', database)

    def bind():
        try:
            address = ipaddress.ip_address(args.bind)
        except ValueError:
            _fail('WEB_BIND')
        _port(args.bind, args.port)
        if not address.is_loopback:
            raise Note('WARN', 'WEB_BIND_NOT_LOOPBACK')
    doctor.check('listener', bind)
    _ops_port(doctor, args, args.port)


def _home(doctor, args, *, lock, record, keys):
    _environment(doctor)
    home = Path(args.home).expanduser()
    _restore(doctor, home)
    if not os.path.lexists(home):
        doctor.check('home', lambda: _info('STORE_MISSING'))
    else:
        doctor.check('home', lambda: _private_directory(home))
        doctor.check('lock', lambda: _lock_held(home / lock) and _info('HOME_IN_USE'))

        def state():
            path = home / record
            if path.exists():
                _private_file(path)
                try:
                    backup._strict_json(path.read_bytes(), 'HOME_STORAGE_JSON')
                except backup.BackupError:
                    _fail('HOME_STORAGE_JSON')
        doctor.check('state', state)
        for name in keys:
            if (home / name).exists():
                doctor.check('key:' + name, lambda name=name: _private_file(home / name))
    doctor.check('listener', lambda: _port('127.0.0.1', args.port))
    _ops_port(doctor, args, args.port)


def _replica(doctor, args, *, private):
    from . import crypto
    from .agent_tools import decode
    from .provider_replica_node import private_file
    from .provider_replication import cluster_id, validate_spec
    _environment(doctor)
    fields = ('spec member key_file privacy_key_file token_file directory port peers account_tokens minimum_checkpoint'
              if private else 'spec member key_file token_file directory port peers')

    def config():
        value = decode(private_file(args.config))
        crypto.exact(value, fields)
        validate_spec(value['spec'])
        if value['member'] not in value['spec']['validators']:
            _fail('REPLICA_SIGNER')
        return value
    value = doctor.check('config', config)
    if value is None:
        return

    def signer():
        key = crypto.load_private(private_file(value['key_file']))
        if crypto.public_key(key) != value['spec']['validators'][value['member']]:
            _fail('REPLICA_SIGNER')
    doctor.check('signing_key', signer)
    doctor.check('token_file', lambda: private_file(value['token_file']).strip() or _fail('REPLICA_PRIVATE_CONFIGURATION'))
    if private:
        doctor.check('privacy_key', lambda: len(bytes.fromhex(private_file(value['privacy_key_file']).strip())) == 32
                     or _fail('PRIVATE_PROVIDER_KEY'))

    def peers():
        import ipaddress
        from urllib.parse import urlsplit
        if not (type(value['peers']) is dict and set(value['peers']) <= set(value['spec']['validators'])):
            _fail('REPLICA_LOOPBACK_PEERS')
        for endpoint in value['peers'].values():
            parts = urlsplit(endpoint)
            if parts.scheme != 'http' or not ipaddress.ip_address(parts.hostname or '').is_loopback:
                _fail('REPLICA_LOOPBACK_PEERS')
    doctor.check('peers', peers)
    directory = Path(value['directory'])
    _restore(doctor, directory)
    running = False
    if os.path.lexists(directory):
        doctor.check('directory', lambda: _private_directory(directory, 'REPLICA_PRIVATE_DIRECTORY'))
        running = _lock_held(directory / 'owner.lock')

        def storage():
            marker, journal = directory / 'identity.json', directory / 'consensus.sqlite3'
            if not journal.exists():
                if marker.exists():
                    _fail('REPLICA_SAFETY_STORAGE_MISSING')
                raise Note('INFO', 'STORE_MISSING')
            _sqlite_ok(journal)
            identity, _state = _store_facts('replica', directory)
            if identity != {'cluster': cluster_id(value['spec']), 'member': value['member']}:
                _fail('REPLICA_STORAGE_IDENTITY')
        doctor.check('signing_storage', storage)
    doctor.check('listener', lambda: _port('127.0.0.1', value['port'], running=running))
    _ops_port(doctor, args, value['port'])


def _agent_connector(doctor, args):
    _environment(doctor)
    if not args.policy:
        return
    from .agent_connector import VERSION
    from .agent_tools import decode
    from .runtime_host import private_text

    def policy():
        value = decode(private_text(args.policy))
        if type(value) is not dict or value.get('version') != VERSION:
            _fail('CONNECTOR_POLICY_VERSION')
        grants = value.get('grants')
        if type(grants) is not list or not 1 <= len(grants) <= 64:
            _fail('CONNECTOR_GRANTS')
        digests = [grant.get('token_sha256') for grant in grants if type(grant) is dict]
        if len(digests) != len(set(digests)):
            _fail('CONNECTOR_DUPLICATE_GRANT')
    doctor.check('policy', policy)
    doctor.check('listener', lambda: _port('127.0.0.1', args.port))
    _ops_port(doctor, args, args.port)


CHECKS = {
    'node': _node, 'gateway': _gateway, 'agent-server': _agent_server, 'agent-native': _agent_native,
    'agent-gateway': _agent_gateway, 'public-web': _public_web,
    'welcome': lambda d, a: _home(d, a, lock='.welcome.lock', record='preferences.json',
                                  keys=('keys/identity.hex', 'keys/identity.enc.json')),
    'handoff': lambda d, a: _home(d, a, lock='.handoff.lock', record='handoff.json', keys=('identity.hex',)),
    'replica': lambda d, a: _replica(d, a, private=False),
    'private-replica': lambda d, a: _replica(d, a, private=True),
    'agent-connector': _agent_connector,
}


def _parser(service):
    module = importlib.import_module(SERVICES[service][0])
    parser = module.arguments()
    parsers = [parser]
    for action in parser._actions:
        if hasattr(action, 'choices') and isinstance(action.choices, dict):
            parsers.extend(action.choices.values())

    def refuse(*_args, **_kwargs):
        # argparse would print usage and exit; the doctor reports one stable code instead.
        raise ValueError('ARGUMENTS')
    for item in parsers:
        item.error = refuse
        item.exit = refuse
    return parser


def diagnose(service, argv=None, *, args=None):
    """Report for one service; ``args`` reuses an already-parsed namespace (stdio --health)."""
    if service not in SERVICES:
        return {'service': service, 'status': 'FAIL', 'started_service': False, 'network_contacted': False,
                'checks': [{'check': 'service', 'status': 'FAIL', 'code': 'ARGUMENTS',
                            'remediation': 'Run covenant-doctor --list for the known services.'}]}
    doctor = Doctor(service)
    if args is None:
        args = doctor.check('arguments', lambda: _parser(service).parse_args(list(argv or [])))
    if args is not None:
        try:
            CHECKS[service](doctor, args)
        except (ValueError, OSError) as exc:
            code = code_of(exc)
            doctor.rows.append({'check': 'configuration', 'status': 'FAIL', 'code': code, 'remediation': remediation(code)})
    return doctor.report()


def health_main(service, args, stream=None):
    """Readiness for a stdio service: the doctor's checks as {name: ok|CODE}; exit 0 only when ready."""
    report = diagnose(service, args=args)
    checks = {row['check']: ('ok' if row['status'] in ('PASS', 'INFO') else row['code']) for row in report['checks']}
    ready = report['status'] != 'FAIL'
    (stream or sys.stdout).write(json.dumps({'service': service, 'status': 'ready' if ready else 'not_ready',
                                             'checks': checks}, sort_keys=True) + '\n')
    return 0 if ready else 1


def plan(path):
    raw = Path(path).read_bytes()
    if len(raw) > MAX_PLAN:
        _fail('ARGUMENTS')
    document = backup._strict_json(raw, 'ARGUMENTS')
    if (type(document) is not dict or set(document) != {'v', 'services'} or document['v'] != PLAN_VERSION
            or type(document['services']) is not list or not 1 <= len(document['services']) <= 64):
        _fail('ARGUMENTS')
    reports = []
    for entry in document['services']:
        if (type(entry) is not dict or set(entry) != {'service', 'args'} or type(entry['args']) is not list
                or not all(type(item) is str and len(item) <= 4096 for item in entry['args'])):
            _fail('ARGUMENTS')
        reports.append(diagnose(entry['service'], entry['args']))
    statuses = {report['status'] for report in reports}
    return {'status': 'FAIL' if 'FAIL' in statuses else 'WARN' if 'WARN' in statuses else 'PASS', 'services': reports}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] in (['-h'], ['--help']):
        print(__doc__.strip())
        return 0
    if not argv:
        print(json.dumps({'status': 'FAIL', 'code': 'ARGUMENTS', 'remediation': remediation('ARGUMENTS')}, sort_keys=True))
        return 2
    if argv[0] == '--list':
        print(json.dumps({name: summary for name, (_module, summary) in SERVICES.items()}, indent=2, sort_keys=True))
        return 0
    try:
        result = plan(argv[1]) if argv[0] == '--plan' and len(argv) == 2 else diagnose(argv[0], argv[1:])
    except (ValueError, OSError) as exc:
        code = code_of(exc)
        result = {'status': 'FAIL', 'code': code, 'remediation': remediation(code)}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 1 if result['status'] == 'FAIL' else 0


if __name__ == '__main__':
    sys.exit(main())
