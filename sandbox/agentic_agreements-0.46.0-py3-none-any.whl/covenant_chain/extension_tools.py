"""Versioned optional reader/application extensions; no implicit activation."""
import base64
import hashlib
from .cooperation_interface import HASH, OBJECT, schema


def specs(index_enabled=False):
    from . import service_workflows, channel_successor
    from covenant_language import service_relationships
    integer={'type':'integer','minimum':0,'maximum':2**53-1}
    text={'type':'string','minLength':1,'maxLength':4096}
    def array(item,maximum):return {'type':'array','items':item,'maxItems':maximum}
    def rec(props):return schema(props,tuple(props))
    actions=[('describe',{},()),('directory_describe',{},()),
        ('directory_prepare',{'context':HASH,'publisher':HASH,'subject':rec({'kind':{'type':'string','minLength':1,'maxLength':80},'id':HASH}),
             'title':{**text,'maxLength':256},'summary':{**text,'maxLength':2048},'tags':array(text,16),'endpoints':array(text,8),'metadata':OBJECT,
             'revision':integer,'previous':array(HASH,16),'issued_at':integer,'expires':integer,
             'visibility':{'enum':['PUBLIC','OWNER_PRIVATE','WITHDRAWN']}},('context','publisher','subject','title','summary')),
        ('directory_verify',{'record':OBJECT,'context':HASH,'trusted_publishers':array(HASH,256),'now':integer},('record','context','trusted_publishers','now')),
        ('directory_search',{'records':array(OBJECT,256),'query':{'type':'string','maxLength':512},'context':HASH,
             'trusted_publishers':array(HASH,256),'now':integer,'limit':{'type':'integer','minimum':1,'maximum':100}},('records','query','context','trusted_publishers','now')),
        ('directory_rank',{'nodes':array(HASH,100000),'edges':array({'type':'array','items':HASH,'minItems':2,'maxItems':2},100000),
             'seeds':{'type':'object','maxProperties':256,'additionalProperties':{'type':'integer','minimum':1,'maximum':2**53-1}},
             'damping_bps':{'type':'integer','minimum':0,'maximum':9500},'iterations':{'type':'integer','minimum':1,'maximum':100},
             'edge_budget':{'type':'integer','minimum':1,'maximum':500000},'limit':{'type':'integer','minimum':1,'maximum':1000},'offset':integer},('nodes','edges','seeds')),
        ('timed_describe',{},()),('timed_independent_describe',{},()),('timed_verify',{'genesis':OBJECT,'bundle':OBJECT,'expected_chain':HASH,'minimum_height':integer,
             'expected_table':text,'expected_key':text,'expected_protocol':text,'expected_head':HASH,'minimum_time':integer,'expected_genesis':HASH},
             ('genesis','bundle','expected_chain','minimum_height','expected_table','expected_key')),
        ('channel_describe',{},()),('channel_proposal',{},()),
        ('channel_preview',{'native_input':OBJECT,'context':HASH,'expected_native_root':HASH,'height':integer},('native_input','context','expected_native_root')),
        ('channel_prepare',{'engine':OBJECT,'expected_head':HASH,'left':HASH,'right':HASH,'resource':text,'left_deposit':integer,
             'right_deposit':integer,'nonce':HASH,'challenge_blocks':integer,'funding_deadline':integer},
             ('engine','expected_head','left','right','resource','left_deposit','right_deposit','nonce','challenge_blocks','funding_deadline')),
        ('channel_state',{'terms':OBJECT,'left_balance':integer,'right_balance':integer,'sequence':integer},('terms','left_balance','right_balance','sequence')),
        ('channel_transaction',{'engine':OBJECT,'expected_head':HASH,'actor':HASH,'action':{'enum':list(channel_successor.ACTIONS)},
             'payload':OBJECT,'height':integer,'maximum_fee':integer},('engine','expected_head','actor','action','payload','height','maximum_fee')),
        ('channel_apply',{'engine':OBJECT,'expected_head':HASH,'transaction':OBJECT,'height':integer},('engine','expected_head','transaction','height')),
        ('channel_audit',{'engine':OBJECT,'expected_head':HASH},('engine','expected_head')),
        ('service_describe',{},())]
    for prefix,shapes in (('service_',service_workflows.schemas()['actions']),('terms_',service_relationships.schemas()['actions'])):
        for name,shape in shapes.items():actions.append((prefix+name,shape['properties'],tuple(shape.get('required',()))))
    timed=next(a for a in actions if a[0]=='timed_verify')
    actions.append(('timed_independent_verify',{**timed[1],'expected_verifier':HASH},(*timed[2],'expected_verifier')))
    out=[('covenant_extensions','Inspect optional timed proofs, escrow-channel successor previews, scalable signed discovery and reusable service workflows. Exact schemas on demand; no signing, activation or execution authority.',True,actions)]
    if index_enabled:
        out.append(('covenant_index','Owner-installed private discovery index. Ingest signed metadata or search public-only snapshots; no remote fetching, publication, signing or authority.',False,[
            ('describe',{},()),('head',{},()),('ingest',{'record':OBJECT},('record',)),
            ('search',{'query':{'type':'string','maxLength':512},'limit':{'type':'integer','minimum':1,'maximum':100},'cursor':OBJECT},('query',))]))
    return out


def _transport(value):
    if type(value) is bytes:return {'encoding':'base64','base64':base64.b64encode(value).decode('ascii'),'sha256':hashlib.sha256(value).hexdigest()}
    if type(value) is list:return [_transport(x) for x in value]
    if type(value) is dict:return {k:_transport(v) for k,v in value.items()}
    return value


def _channel_result(carrier):
    return {'snapshot':carrier,'head':carrier['engine']['head'],
            'activation':'NOT_INSTALLED_IN_HISTORICAL_REDUCER','execution_authorized':False}


def call(host,tool,action,parameters):
    from . import scalable_discovery as index, timed_light, channel_successor as channel, service_workflows as service
    from covenant_language import service_relationships as terms
    if tool=='covenant_index':
        desk=host.discovery_index
        if desk is None:raise ValueError('INDEX_NOT_OWNER_INSTALLED')
        if action=='describe':return {**index.describe(),'owner_installed':True,'tool_reads':'PUBLIC_METADATA_ONLY'}
        if action=='head':return {'head':desk.head(),**index.FLAGS}
        if action=='ingest':return desk.ingest(parameters['record'],now=desk.now())
        if action=='search':
            args=dict(parameters);now=desk.now();cursor=args.get('cursor')
            if cursor is not None:
                prior=cursor.get('as_of');index.need(type(prior) is int and 0<=now-prior<=300,'INDEX_CURSOR_CLOCK');now=prior
            return desk.search(now=now,public_only=True,**args)
        raise ValueError('EXTENSION_ACTION')
    if tool!='covenant_extensions':raise ValueError('EXTENSION_TOOL')
    if action=='describe':
        return {'status':'DESCRIBED','tool':tool,'guide':'docs/VALUABLE_EXTENSIONS.html',
            'actions':[a[0] for a in specs()[0][3]],'schema_lookup':'covenant_explain action; id=tool:covenant_extensions.<action>',
            'boundaries':{'timed':'SEPARATE_LIGHT_0.2; COMMITTEE_ASSUMPTION_NOT_APPLICATION_REPLAY',
                'channel':'EXECUTABLE_SUCCESSOR_PREVIEW; NOT_INSTALLED_IN_HISTORICAL_REDUCER',
                'directory':'LOCAL_INDEX_AND_SPARSE_RANK; NO_DHT_OR_GLOBAL_REPUTATION',
                'services':'EXACT_DRAFTS_AND_LOCAL_ALLOCATIONS; OWNER_ASSENT_AND_EXTERNAL_EXECUTION_SEPARATE'},'execution_authorized':False}
    directory={'directory_describe':index.describe,'directory_prepare':index.prepare,'directory_verify':index.verify_record,
               'directory_search':index.search_preview,'directory_rank':index.sparse_rank}
    if action in directory:return directory[action](**parameters)
    if action in ('timed_independent_describe','timed_independent_verify'):
        from . import timed_light_backend
        return timed_light_backend.describe() if action.endswith('describe') else timed_light_backend.verify(**parameters)
    if action=='timed_describe':return timed_light.describe()
    if action=='timed_verify':return timed_light.verify_light_bundle(**parameters)
    if action=='channel_describe':return channel.describe()
    if action=='channel_proposal':return channel.proposal()
    if action=='channel_preview':return _channel_result(channel.preview_snapshot(**parameters))
    if action=='channel_state':return {**channel.state_payload(**parameters),'execution_authorized':False}
    if action in ('channel_prepare','channel_transaction','channel_apply','channel_audit'):
        args=dict(parameters);carrier=args.pop('engine');pin=args.pop('expected_head');engine=channel.restore_snapshot(carrier,expected_head=pin)
        if action=='channel_prepare':return channel.prepare(engine,**args)
        if action=='channel_transaction':return {**channel.transaction_payload(engine,**args),'execution_authorized':False}
        if action=='channel_apply':return _channel_result(channel.snapshot(channel.apply(engine,expected_head=pin,**args)))
        return {'status':'AUDITED_SIMULATED_STATE','head':engine['head'],'audit':channel.audit(engine),'activation':channel.BOUNDARY,'execution_authorized':False}
    if action=='service_describe':
        result=service.describe();result.pop('schemas',None);result.get('terms',{}).pop('schemas',None)
        return result
    if action.startswith('service_') and action[8:] in service.schemas()['actions']:
        return _transport(getattr(service,action[8:])(**parameters))
    if action.startswith('terms_') and action[6:] in terms.schemas()['actions']:
        return _transport(getattr(terms,action[6:])(**parameters))
    raise ValueError('EXTENSION_ACTION')
