"""Bounded authenticated loopback binding for the required agreement profile.

The middleware gate is reusable without HTTP. This listener is an owner-side
reference backend, not a public TLS service, authentication provider or sandbox
for the owner-installed execution callback. No request body or token is logged.
"""
from copy import deepcopy
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler
import re
import socket
import threading
from urllib.parse import urlsplit

from . import crypto as c
from .provider_replica_rpc import _BoundedServer, MAX_CONNECTION_SECONDS


def token_digest(token):
    c.need(type(token) is str and 32 <= len(token) <= 256 and
           all(33 <= ord(ch) <= 126 for ch in token), 'AGREEMENT_HTTP_TOKEN')
    return hashlib.sha256(token.encode('ascii')).hexdigest()


class AgreementService:
    """Explicit token-to-caller/tenant binding; public metadata grants nothing.

    The caller's credential and the independently adopted agreement/grant are
    checked separately. Owner code can revoke credentials; the HTTP interface
    cannot install credentials, change grants, sign, or replace an execution
    callback. Backends bind literal IPv4 loopback only.
    """
    def __init__(self, gate, *, credentials, hosts=(), max_request_bytes=262144,
                 max_response_bytes=1048576, calls_per_minute=120, public_url=None):
        from .a2a_agreement_gate import AgreementGate
        c.need(isinstance(gate, AgreementGate), 'AGREEMENT_HTTP_GATE')
        c.need(type(credentials) is dict and 1 <= len(credentials) <= 128,
               'AGREEMENT_HTTP_CREDENTIALS')
        self._credentials = {}
        for ref, scope in credentials.items():
            c.key(ref)
            c.exact(scope, 'caller tenant')
            c.key(scope['caller'])
            c.need(type(scope['tenant']) is str and
                   0 < len(scope['tenant']) <= 128 and scope['tenant'].isascii() and
                   all(33 <= ord(ch) <= 126 for ch in scope['tenant']),
                   'AGREEMENT_HTTP_TENANT')
            self._credentials[ref] = deepcopy(scope)
        c.need(type(hosts) in (list, tuple) and len(hosts) <= 16 and all(
            type(host) is str and 0 < len(host) <= 256 and host == host.lower() and
            re.fullmatch(r'[a-z0-9.:-]+', host) for host in hosts), 'AGREEMENT_HTTP_HOSTS')
        for value, minimum, maximum in ((max_request_bytes, 1024, 1000000),
                (max_response_bytes, 1024, 4000000), (calls_per_minute, 1, 10000)):
            c.need(type(value) is int and minimum <= value <= maximum,
                   'AGREEMENT_HTTP_LIMIT')
        self.gate, self.hosts = gate, frozenset(hosts)
        self.max_request_bytes, self.max_response_bytes = max_request_bytes, max_response_bytes
        self.calls_per_minute = calls_per_minute
        if public_url is not None:
            c.need(type(public_url) is str, 'AGREEMENT_HTTP_PUBLIC_URL')
            url = urlsplit(public_url)
            c.need(url.scheme == 'https' and url.hostname and url.path == '/rpc' and
                   not url.username and not url.password and not url.query and not url.fragment,
                   'AGREEMENT_HTTP_PUBLIC_URL')
        self.public_url = public_url
        self._lock = threading.Lock()
        self._windows = {}

    def revoke(self, token_sha256):
        """Owner-only; affects subsequent authorization checks, not past assent."""
        c.key(token_sha256)
        with self._lock:
            self._credentials.pop(token_sha256, None)
            self._windows.pop(token_sha256, None)

    def _authorize(self, value):
        import time
        if type(value) is not str or not value.startswith('Bearer '):
            return None
        try:
            candidate = token_digest(value[7:])
        except ValueError:
            return None
        with self._lock:
            for ref, scope in self._credentials.items():
                if hmac.compare_digest(candidate, ref):
                    current = time.monotonic()
                    start, count = self._windows.get(ref, (current, 0))
                    if current - start >= 60:
                        start, count = current, 0
                    self._windows[ref] = (start, min(count + 1, self.calls_per_minute + 1))
                    c.need(count < self.calls_per_minute, 'AGREEMENT_HTTP_RATE')
                    return deepcopy(scope)
        return None

    def server(self, port=0, *, host='127.0.0.1'):
        c.need(host == '127.0.0.1' and type(port) is int and 0 <= port <= 65535,
               'AGREEMENT_HTTP_LOOPBACK')
        service = self

        class Handler(BaseHTTPRequestHandler):
            server_version = 'CovenantAgreement'
            sys_version = ''

            def setup(self):
                self.request.settimeout(2)
                super().setup()
                self._deadline = threading.Timer(MAX_CONNECTION_SECONDS, self.expire)
                self._deadline.daemon = True
                self._deadline.start()

            def expire(self):
                try:
                    self.request.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            def finish(self):
                try:
                    super().finish()
                finally:
                    self._deadline.cancel()

            def log_message(self, *args):
                pass

            def reply(self, status, value, *, activated=False):
                from covenant_agent.errors import shaped  # one refusal shape across the agent boundary
                raw = c.canonical(shaped(value))
                if len(raw) > service.max_response_bytes:
                    status, raw = 413, c.canonical(shaped({'error': 'AGREEMENT_HTTP_RESULT_LIMIT'}))
                    activated = False
                try:
                    self.send_response(status)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(raw)))
                    self.send_header('Cache-Control', 'no-store')
                    self.send_header('X-Content-Type-Options', 'nosniff')
                    self.send_header('Connection', 'close')
                    if activated:
                        from .a2a_agreement_gate import EXTENSION_URI
                        self.send_header('A2A-Extensions', EXTENSION_URI)
                    self.end_headers()
                    if self.command != 'HEAD':
                        self.wfile.write(raw)
                except OSError:
                    pass  # Lost reply does not roll back or retry a callback.
                self.close_connection = True

            def access(self):
                hosts = service.hosts or {'127.0.0.1:' + str(self.server.server_port)}
                received = self.headers.get_all('Host', [])
                c.need(len(received) == 1 and received[0].lower() in hosts,
                       'AGREEMENT_HTTP_HOST')
                c.need(not any(self.headers.get(name) is not None for name in
                       ('Origin', 'Transfer-Encoding', 'Expect')), 'AGREEMENT_HTTP_HEADERS')
                auth = self.headers.get_all('Authorization', [])
                scope = service._authorize(auth[0]) if len(auth) == 1 else None
                c.need(scope is not None, 'AGREEMENT_HTTP_UNAUTHORIZED')
                return scope

            def failure(self, error, request_id=None):
                code = str(error)
                safe = code if re.fullmatch(r'(AGREEMENT|A2A_GATE)_[A-Z0-9_]{1,90}', code) else 'AGREEMENT_REQUEST_REFUSED'
                status = 401 if code == 'AGREEMENT_HTTP_UNAUTHORIZED' else (
                    429 if code == 'AGREEMENT_HTTP_RATE' else 400)
                rpc_code = -32000
                if code in ('AGREEMENT_HTTP_EXTENSION', 'A2A_GATE_EXTENSION_REQUIRED'):
                    rpc_code = -32008
                elif code == 'A2A_GATE_METHOD_UNSUPPORTED':
                    rpc_code = -32004
                elif code == 'AGREEMENT_HTTP_VERSION':
                    rpc_code = -32009
                elif code == 'A2A_GATE_TASK_NOT_AVAILABLE':
                    rpc_code = -32001
                if code.startswith('A2A_GATE_') or rpc_code != -32000:
                    status = 200
                self.reply(status, {'jsonrpc': '2.0', 'id': request_id,
                    'error': {'code': rpc_code, 'message': safe}})

            def do_GET(self):
                try:
                    scope = self.access()
                    c.need(self.path == '/.well-known/agent-card.json', 'AGREEMENT_HTTP_PATH')
                    from .a2a_agreement_gate import EXTENSION_URI, VERSION
                    # A generic declaration contains no per-agreement identifiers,
                    # parties, resources, keys, payloads or private terms.
                    self.reply(200, {'name': 'Covenant agreement service',
                        'description': 'Execute only independently adopted, explicitly signed exact agreements.',
                        'version': VERSION,
                        'supportedInterfaces': [{'url': service.public_url or ('http://127.0.0.1:' + str(self.server.server_port) + '/rpc'),
                            'protocolBinding': 'JSONRPC', 'protocolVersion': '1.0', 'tenant': scope['tenant']}],
                        'capabilities': {'extensions': [{'uri': EXTENSION_URI,
                            'description': 'Verified agreement and scoped authority required before execution.',
                            'required': True, 'params': {'profile': VERSION}}]},
                        'securitySchemes': {'ownerBearer': {'httpAuthSecurityScheme': {'scheme': 'Bearer'}}},
                        'securityRequirements': [{'schemes': {'ownerBearer': {'list': []}}}],
                        'defaultInputModes': ['application/json'],
                        'defaultOutputModes': ['application/json'], 'skills': []})
                except (ValueError, TypeError, KeyError):
                    self.reply(403, {'error': 'AGREEMENT_HTTP_CARD_REFUSED'})

            def do_POST(self):
                request_id = None
                try:
                    scope = self.access()
                    c.need(self.path == '/rpc', 'AGREEMENT_HTTP_PATH')
                    c.need(self.headers.get_all('Content-Type', []) == ['application/json'],
                           'AGREEMENT_HTTP_TYPE')
                    lengths = self.headers.get_all('Content-Length', [])
                    c.need(len(lengths) == 1 and re.fullmatch(r'[0-9]{1,7}', lengths[0]) and
                           0 < int(lengths[0]) <= service.max_request_bytes, 'AGREEMENT_HTTP_LENGTH')
                    raw = self.rfile.read(int(lengths[0]))
                    c.need(len(raw) == int(lengths[0]), 'AGREEMENT_HTTP_INCOMPLETE')
                    body = c.loads(raw)
                    c.exact(body, 'jsonrpc id method params')
                    c.need(body['jsonrpc'] == '2.0' and type(body['id']) is str and
                           0 < len(body['id']) <= 256 and type(body['method']) is str and
                           type(body['params']) is dict, 'AGREEMENT_HTTP_RPC')
                    request_id = body['id']
                    c.need(self.headers.get_all('A2A-Version', []) == ['1.0'], 'AGREEMENT_HTTP_VERSION')
                    extensions = self.headers.get_all('A2A-Extensions', [])
                    c.need(len(extensions) == 1 and len(extensions[0]) <= 4096,
                           'AGREEMENT_HTTP_EXTENSION')
                    active = [value.strip() for value in extensions[0].split(',')]
                    c.need(len(active) <= 16 and all(active) and len(active) == len(set(active)),
                           'AGREEMENT_HTTP_EXTENSION')
                    c.need(body['params'].get('tenant') == scope['tenant'], 'AGREEMENT_HTTP_TENANT')
                    result = service.gate.dispatch(body['method'], body['params'],
                        caller=scope['caller'], active_extensions=active)
                    self.reply(200, {'jsonrpc': '2.0', 'id': request_id, 'result': result}, activated=True)
                except (ValueError, TypeError, KeyError, UnicodeError, RecursionError, OverflowError) as error:
                    self.failure(error, request_id)
                except Exception:
                    self.reply(503, {'jsonrpc': '2.0', 'id': request_id,
                        'error': {'code': -32603, 'message': 'AGREEMENT_LOCAL_UNAVAILABLE'}})

            def do_HEAD(self):
                self.reply(405, {'error': 'AGREEMENT_HTTP_METHOD'})

            do_PUT = do_HEAD
            do_DELETE = do_HEAD
            do_OPTIONS = do_HEAD
            do_PATCH = do_HEAD

        return _BoundedServer((host, port), Handler)
