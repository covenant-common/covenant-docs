"""Recovery inbox: hold offline trades, accept them on checked evidence, reconcile once.

A supplier's inbox keeps every trade it was handed, the evidence checks it made
before accepting, and one settlement record per spend slot. On reconnection
reconcile() calls the owner's settlement leg at most once per slot: it writes
the request ID first, so a crash or lost reply leaves an UNKNOWN attempt that
is retried with the same ID, never a second payment. merge() takes trades
retained by peers and finds conflicting spends and cloned device state.

DeviceLog is the buyer device's side: a monotonic sequence and hash-chained
head per issued trade, signed so peers can retain it. After losing its newest
checkpoint the device refuses to issue until recover() has seen the heads
peers retained.

Storage is one private SQLite file per store (WAL, synchronous=FULL, a
hash-chained append-only journal). A whole-store rollback is detectable only
against a checkpoint retained elsewhere. Nothing here moves value; the
settlement leg the owner installs decides what reconciliation means.
"""
from contextlib import contextmanager
from copy import deepcopy
import json
import logging
import os
from pathlib import Path
import sqlite3
import stat
import threading

from . import crypto as c, offline as transport, offline_trade as trade
from . import offline_trade_backing as backing, offline_trade_conflicts as conflicts
from . import offline_trade_freshness as fresh
from .offline_trade_freshness import TradeError, need

INBOX_VERSION = 'covenant-offline-trade-inbox/0.1'
DEVICE_VERSION = 'covenant-offline-trade-device/0.1'
SCHEMA = 1
JOURNAL_LABEL = 'COVENANT-OFFLINE-TRADE-JOURNAL-0.1'
REQUEST_LABEL = 'COVENANT-OFFLINE-TRADE-REQUEST-0.1'
MAX_TRADES = 4096
MAX_FINDINGS = 4096
MAX_HEADS = 4096
FINAL = ('RECORDED_PAY_LATER', 'CLAIM_LODGED', 'APPLIED_LOCALLY', 'LEDGER_CONFIRMED', 'CONFLICT', 'REFUSED',
         'SLASHED_LOCALLY')
LEG_STATUSES = FINAL + ('UNKNOWN',)
LOG = logging.getLogger('covenant.offline_trade')


def _log(event, **fields):
    # Structured JSON line; identifiers only, never keys, terms or evidence bytes.
    LOG.info(json.dumps({'event': event, **fields}, sort_keys=True, separators=(',', ':')))


def _open(directory, name):
    path = Path(directory)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        need(stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_uid == os.getuid(), 'TRADE_INBOX_STORAGE')
        handle = os.open(name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=fd)
        info = os.fstat(handle); os.close(handle)
        need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_nlink == 1,
             'TRADE_INBOX_STORAGE')
        os.fsync(fd)
    finally:
        os.close(fd)
    db = sqlite3.connect(path / name, isolation_level=None, timeout=10, check_same_thread=False)
    db.execute('PRAGMA journal_mode=WAL'); db.execute('PRAGMA synchronous=FULL')
    return db


def _text(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


class _Store:
    """A private SQLite file with a schema pin and a hash-chained append-only journal."""
    TABLES = ()

    def __init__(self, directory, name, context, retained):
        self.lock = threading.RLock()
        self.db = _open(directory, name)
        self.closed = False
        try:
            self.db.execute('CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS journal(seq INTEGER PRIMARY KEY, previous TEXT NOT NULL, '
                            'id TEXT UNIQUE NOT NULL, kind TEXT NOT NULL, body TEXT NOT NULL)')
            for action in ('UPDATE', 'DELETE'):
                self.db.execute(f'CREATE TRIGGER IF NOT EXISTS journal_{action.lower()} BEFORE {action} ON journal '
                                "BEGIN SELECT RAISE(ABORT, 'TRADE_INBOX_HISTORY'); END")
            for statement in self.TABLES:
                self.db.execute(statement)
            with self._write():
                pin = c.digest('COVENANT-OFFLINE-TRADE-STORE-0.1', context)
                rows = dict(self.db.execute('SELECT key, value FROM meta').fetchall())
                if not rows:
                    self.db.execute("INSERT INTO meta VALUES ('schema', ?), ('context', ?), ('clock', '0')",
                                    (str(SCHEMA), pin))
                else:
                    need(rows.get('schema') == str(SCHEMA), 'TRADE_INBOX_SCHEMA')
                    need(rows.get('context') == pin, 'TRADE_INBOX_OWNER')
            self._verify_journal(retained)
        except BaseException:
            self.db.close()
            raise

    @contextmanager
    def _write(self):
        need(not self.closed, 'TRADE_INBOX_CLOSED')
        with self.lock:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                yield
            except BaseException:
                self.db.execute('ROLLBACK')
                raise
            self.db.execute('COMMIT')

    def _verify_journal(self, retained):
        if retained is not None:
            need(type(retained) is dict and set(retained) == {'sequence', 'head'} and
                 type(retained['sequence']) is int and type(retained['head']) is str, 'TRADE_INBOX_ROLLED_BACK')
        previous, sequence = trade.ZERO, 0
        found = retained is None or retained == {'sequence': 0, 'head': trade.ZERO}
        for seq, prior, ref, kind, body in self.db.execute('SELECT seq, previous, id, kind, body FROM journal ORDER BY seq'):
            expected = c.digest(JOURNAL_LABEL, {'seq': seq, 'previous': prior, 'kind': kind, 'body': json.loads(body)})
            need(seq == sequence + 1 and prior == previous and ref == expected, 'TRADE_INBOX_HISTORY')
            sequence, previous = seq, ref
            if retained is not None and seq == retained['sequence']:
                found = ref == retained['head']
        need(found, 'TRADE_INBOX_ROLLED_BACK')

    def _append(self, kind, body):
        row = self.db.execute('SELECT seq, id FROM journal ORDER BY seq DESC LIMIT 1').fetchone()
        seq, previous = (row[0] + 1, row[1]) if row else (1, trade.ZERO)
        ref = c.digest(JOURNAL_LABEL, {'seq': seq, 'previous': previous, 'kind': kind, 'body': body})
        self.db.execute('INSERT INTO journal VALUES (?, ?, ?, ?, ?)', (seq, previous, ref, kind, _text(body)))
        return ref

    def _clock(self, now):
        c.integer(now)
        last = int(self.db.execute("SELECT value FROM meta WHERE key='clock'").fetchone()[0])
        need(now >= last, 'TRADE_CLOCK_ROLLBACK')
        self.db.execute("UPDATE meta SET value=? WHERE key='clock'", (str(now),))

    def checkpoint(self):
        """Retain this outside the device: it detects a store replaced by an older copy."""
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            row = self.db.execute('SELECT seq, id FROM journal ORDER BY seq DESC LIMIT 1').fetchone()
            return {'sequence': row[0], 'head': row[1]} if row else {'sequence': 0, 'head': trade.ZERO}

    def backup(self, path):
        """A consistent private copy (SQLite online backup) at a new path."""
        target = Path(path)
        need(target.parent.is_dir() and not target.exists() and not target.is_symlink(), 'TRADE_BACKUP_PATH')
        handle = os.open(target, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        os.close(handle)
        copy = sqlite3.connect(target, timeout=10)
        try:
            with self.lock:
                self.db.backup(copy)
            copy.execute('PRAGMA journal_mode=DELETE'); copy.execute('PRAGMA synchronous=FULL')
        finally:
            copy.close()
        return self.checkpoint()

    def close(self):
        with self.lock:
            if not self.closed:
                self.closed = True
                self.db.close()


def restore(backup_path, directory, name='inbox.sqlite'):
    """Place a backup as the store file of a new private directory; open it with a checkpoint to judge its age."""
    source = Path(backup_path)
    need(source.is_file() and not source.is_symlink(), 'TRADE_BACKUP_PATH')
    target = Path(directory)
    need(not target.exists(), 'TRADE_BACKUP_PATH')
    target.mkdir(mode=0o700, parents=True)
    copy = sqlite3.connect(target / name, timeout=10)
    original = sqlite3.connect(source, timeout=10)
    try:
        original.backup(copy)
        copy.execute('PRAGMA journal_mode=WAL'); copy.execute('PRAGMA synchronous=FULL')
    finally:
        original.close(); copy.close()
    os.chmod(target / name, 0o600)
    return target / name


class RecoveryInbox(_Store):
    """One owner's offline trades, evidence checks and exactly-once settlement records."""
    TABLES = (
        'CREATE TABLE IF NOT EXISTS trades(id TEXT PRIMARY KEY, record TEXT NOT NULL, slot TEXT, buyer TEXT NOT NULL, '
        'version TEXT NOT NULL, raw BLOB NOT NULL, role TEXT NOT NULL, received_at INTEGER NOT NULL, '
        'state TEXT NOT NULL, assessment TEXT)',
        'CREATE TABLE IF NOT EXISTS slots(slot TEXT PRIMARY KEY, trade TEXT NOT NULL)',
        'CREATE TABLE IF NOT EXISTS settlements(item TEXT PRIMARY KEY, trade TEXT NOT NULL, request TEXT NOT NULL, '
        'action TEXT NOT NULL, status TEXT NOT NULL, outcome TEXT, attempts INTEGER NOT NULL, at INTEGER NOT NULL)',
        'CREATE TABLE IF NOT EXISTS heads(device TEXT NOT NULL, sequence INTEGER NOT NULL, head TEXT NOT NULL, '
        'record TEXT NOT NULL, PRIMARY KEY(device, sequence))',
        'CREATE TABLE IF NOT EXISTS floors(name TEXT PRIMARY KEY, sequence INTEGER NOT NULL)',
        'CREATE TABLE IF NOT EXISTS exposure(bucket TEXT NOT NULL, trade TEXT NOT NULL, amount INTEGER NOT NULL, '
        'stale INTEGER NOT NULL, buyer TEXT NOT NULL, issuer TEXT, PRIMARY KEY(bucket, trade))',
        'CREATE TABLE IF NOT EXISTS findings(id TEXT PRIMARY KEY, kind TEXT NOT NULL, record TEXT NOT NULL, '
        'at INTEGER NOT NULL)',
        'CREATE TABLE IF NOT EXISTS cosigns(trade TEXT NOT NULL, signer TEXT NOT NULL, record TEXT NOT NULL, '
        'PRIMARY KEY(trade, signer))',
    )

    def __init__(self, directory, *, owner, retained=None):
        c.verification_key(owner)
        self.owner = owner
        super().__init__(directory, 'inbox.sqlite', {'version': INBOX_VERSION, 'owner': owner}, retained)

    # Receiving -------------------------------------------------------------
    def _load(self, value):
        if type(value) is bytes:
            need(len(value) <= trade.MAX_BYTES_0_2, 'TRADE_CHECK_FAILED')
            value = transport.exact_load(value, trade.MAX_BYTES_0_2)
        return value

    def _merge(self, old, new):
        a, b = old['events'], new['events']
        need(c.canonical(a[:min(len(a), len(b))]) == c.canonical(b[:min(len(a), len(b))]), 'TRADE_HISTORY_FORK')
        merged = deepcopy(new)
        if len(a) > len(b):
            merged['events'] = deepcopy(a)
        signed = {r['party']: r for r in old['assents']}
        for row in new['assents']:
            need(row['party'] not in signed or signed[row['party']] == row, 'TRADE_HISTORY_FORK')
            signed[row['party']] = row
        merged['assents'] = [signed[k] for k in sorted(signed)]
        if merged['version'] == trade.VERSION_0_2:
            # Keep retained evidence first; add new pieces only while every bound still holds.
            rows = list(old['attachments'])
            for row in new['attachments']:
                if row in rows:
                    continue
                candidate = sorted(rows + [row], key=c.canonical)
                trial = {**merged, 'attachments': candidate}
                try:
                    trade.terms_id(trial)
                except ValueError:
                    continue
                if len(c.canonical(trial)) <= trade.MAX_BYTES_0_2:
                    rows = candidate
            merged['attachments'] = sorted(rows, key=c.canonical)
        return merged

    def _finding(self, kind, record, now):
        ref = c.digest('COVENANT-OFFLINE-TRADE-FINDING-0.1', {'kind': kind, 'record': record})
        if self.db.execute('SELECT 1 FROM findings WHERE id=?', (ref,)).fetchone() is None:
            need(self.db.execute('SELECT count(*) FROM findings').fetchone()[0] < MAX_FINDINGS, 'TRADE_INBOX_FULL')
            self.db.execute('INSERT INTO findings VALUES (?, ?, ?, ?)', (ref, kind, _text(record), now))
            self._append('FINDING', {'id': ref, 'kind': kind})
            _log('finding', kind=kind, id=ref[:16])
        return {'id': ref, 'kind': kind, **record}

    def _heads(self, bundle, now):
        found = []
        buyer, ref = bundle['terms']['parties']['buyer'], trade.terms_id(bundle)
        for record in trade.attached(bundle, 'HEAD'):
            try:
                body = conflicts.check_head(record)
            except TradeError:
                continue
            if body['device'] != buyer or body['trade'] != ref:
                continue
            row = self.db.execute('SELECT record, head FROM heads WHERE device=? AND sequence=?',
                                  (body['device'], body['sequence'])).fetchone()
            if row is None:
                need(self.db.execute('SELECT count(*) FROM heads').fetchone()[0] < MAX_HEADS, 'TRADE_INBOX_FULL')
                self.db.execute('INSERT INTO heads VALUES (?, ?, ?, ?)',
                                (body['device'], body['sequence'], body['head'], _text(record)))
            elif row[1] != body['head']:
                found.append(self._finding('CLONED_STATE', {'device': body['device'], 'sequence': body['sequence'],
                                           'statements': sorted([json.loads(row[0]), record], key=c.canonical)}, now))
        return found

    def receive(self, value, *, now, expected_id=None, role='PARTY'):
        """Retain a trade handed over by a carrier or a peer. Retaining is not accepting.

        The trade must verify (signatures, events, bounds). A second trade for a
        spend slot already held is kept as evidence and reported, never accepted.
        """
        need(role in ('PARTY', 'PEER'), 'TRADE_CHECK_FAILED')
        bundle = self._load(value)
        ref = trade.terms_id(bundle)
        trade.inspect(bundle, expected_id=ref if expected_id is None else expected_id, now=now)
        need(role == 'PEER' or self.owner in (bundle['terms']['parties']['buyer'], bundle['terms']['parties']['supplier']),
             'TRADE_NOT_PAYEE')
        slot = trade.slot_id(bundle)
        with self._write():
            self._clock(now)
            old = self.db.execute('SELECT raw, state FROM trades WHERE id=?', (ref,)).fetchone()
            findings = []
            if old is not None:
                merged = self._merge(transport.exact_load(old[0], trade.MAX_BYTES_0_2), bundle)
                trade.inspect(merged, expected_id=ref, now=now)
                raw = trade.export_bundle(merged)
                status = 'DUPLICATE' if raw == old[0] else 'UPDATED'
                if status == 'UPDATED':
                    self.db.execute('UPDATE trades SET raw=?, record=? WHERE id=?', (raw, trade.record_id(merged), ref))
                bundle = merged
            else:
                need(self.db.execute('SELECT count(*) FROM trades').fetchone()[0] < MAX_TRADES, 'TRADE_INBOX_FULL')
                raw = trade.export_bundle(bundle); status = 'NEW'
                self.db.execute('INSERT INTO trades VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)',
                                (ref, trade.record_id(bundle), slot, bundle['terms']['parties']['buyer'],
                                 bundle['version'], raw, role, now, 'HELD'))
            if slot is not None:
                first = self.db.execute('SELECT trade FROM slots WHERE slot=?', (slot,)).fetchone()
                if first is None:
                    self.db.execute('INSERT INTO slots VALUES (?, ?)', (slot, ref))
                elif first[0] != ref:
                    findings.append(self._finding('CONFLICTING_SPEND', {'slot': slot, 'trades': sorted([first[0], ref]),
                                                  'buyer': bundle['terms']['parties']['buyer']}, now))
            findings += self._heads(bundle, now)
            if status != 'DUPLICATE' or findings:
                self._append('RECEIVED', {'trade': ref, 'record': trade.record_id(bundle), 'status': status,
                                          'role': role, 'slot': slot})
        _log('received', trade=ref[:16], status=status, role=role)
        return {'trade': ref, 'record': trade.record_id(bundle), 'slot': slot, 'status': status,
                'findings': findings, 'accepted': False, 'payment_verified': False}

    def get(self, ref):
        c.key(ref)
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            row = self.db.execute('SELECT raw FROM trades WHERE id=?', (ref,)).fetchone()
        need(row is not None, 'TRADE_UNKNOWN')
        return transport.exact_load(row[0], trade.MAX_BYTES_0_2)

    # Checking and accepting -------------------------------------------------
    def _exposure(self, bucket=None, buyer=None, issuer=None, stale=None):
        query, args = 'SELECT coalesce(sum(amount), 0) FROM exposure WHERE 1=1', []
        for column, value in (('bucket', bucket), ('buyer', buyer), ('issuer', issuer), ('stale', stale)):
            if value is not None:
                query += ' AND %s=?' % column; args.append(value)
        return self.db.execute(query, args).fetchone()[0]

    def _backing(self, bundle, *, now, policy, chains, reservation_verifier, minimum_height, ref):
        terms = bundle['terms']; mode = terms['policy']['mode']; quantity = terms['resource']['quantity']
        collateral = backing.collateral(bundle)
        held = 0 if collateral is None else self._exposure(bucket=collateral['bucket'])
        if mode == 'RECORD_ONLY':
            return {'backing': 'NONE', 'words': 'no value is reserved; the supplier relies on the buyer to pay later'}
        if mode == 'PREALLOCATED_CLAIM':
            successor = bundle['version'] == trade.VERSION_0_2
            if successor and terms['risk']['terms']['backing'] == 'OFFLINE_VALUE':
                chain = terms['risk']['terms']['chain']
                need(type(chains) is dict and chain in chains, 'TRADE_CHAIN_NOT_ADOPTED')
                result = backing.ledger_backing(bundle, genesis=chains[chain], minimum_height=minimum_height)
                backing.check_instruction(bundle)
                need(held + quantity <= result['remaining'], 'TRADE_COLLATERAL_EXCEEDED')
                return result
            need(reservation_verifier is not None, 'TRADE_BACKING_PROOF')
            info = trade.inspect(bundle, expected_id=ref, now=now, reservation_verifier=reservation_verifier)
            need(info['reservation_evidence_accepted'] is True, 'TRADE_BACKING_PROOF')
            need(held + quantity <= terms['policy']['reservation']['amount'], 'TRADE_COLLATERAL_EXCEEDED')
            return {'backing': 'OWNER_VERIFIED', 'words': 'reservation accepted by your own verifier; every claim on it '
                    'is counted together', 'reservation': terms['policy']['reservation']['reference']}
        need(bundle['version'] == trade.VERSION_0_2, 'TRADE_SUCCESSOR_REQUIRED')
        if mode == 'ISSUER_CREDIT':
            result = backing.check_credit(bundle, now=now)
            limit = policy['issuer_limits'].get(result['issuer'])
            need(limit is not None, 'TRADE_ISSUER_NOT_ADOPTED')
            need(held + quantity <= result['limit'] and self._exposure(issuer=result['issuer']) + quantity <= limit,
                 'TRADE_CREDIT_LIMIT')
            return result
        return backing.check_quorum(bundle, groups=policy['groups'])

    def check(self, ref, *, now, policy, arrived_at=None, chains=None, accreditation=None, authority_roots=(),
              readers=None, time_policies=(), reservation_verifier=None, minimum_height=1):
        """Everything the supplier checks before accepting, in plain words. Nothing is signed or stored."""
        fresh.check_policy(policy)
        need(policy['owner'] == self.owner, 'TRADE_POLICY')
        bundle = self.get(ref)
        terms = bundle['terms']
        need(terms['parties']['supplier'] == self.owner, 'TRADE_NOT_PAYEE')
        slot = trade.slot_id(bundle)
        with self.lock:
            if slot is not None:
                first = self.db.execute('SELECT trade FROM slots WHERE slot=?', (slot,)).fetchone()
                need(first is not None and first[0] == ref, 'TRADE_SLOT_TAKEN')
            received = self.db.execute('SELECT received_at FROM trades WHERE id=?', (ref,)).fetchone()[0]
            floors = dict(self.db.execute('SELECT name, sequence FROM floors').fetchall())
            stale_held = self._exposure(buyer=terms['parties']['buyer'], stale=1)
            # Timing first: a note presented after its grace period is refused whatever else it carries.
            proof = fresh.issued_by(bundle, groups=list(policy['groups'].values()), time_policies=time_policies)
            timing = fresh.presentation(bundle, at=received if arrived_at is None else arrived_at,
                                        existed_by=proof['existed_by'], skew=policy['skew'])
            evidence = fresh.assess(bundle, now=now, policy=policy, accreditation=accreditation,
                                    authority_roots=authority_roots, readers=readers, floors=floors)
            decision = fresh.decide(evidence, amount=terms['resource']['quantity'], policy=policy,
                                    stale_exposure=stale_held)
            backed = self._backing(bundle, now=now, policy=policy, chains=chains,
                                   reservation_verifier=reservation_verifier, minimum_height=minimum_height, ref=ref)
        words = [w for w in (trade.risk_words(bundle), evidence['summary'], timing['words'], backed.get('words'),
                             decision['words']) if w]
        return {'trade': ref, 'slot': slot, 'decision': decision['decision'], 'freshness': evidence,
                'issued_by': proof, 'timing': timing, 'backing': backed, 'words': words,
                'risk_words_signed': bundle['version'] == trade.VERSION_0_2, 'payment_verified': False,
                'exclusive_spend_verified': False, 'execution_authorized': False}

    def accept(self, ref, signing_key, *, now, policy, **checks):
        """Check, then sign the supplier's assent and count the trade against its collateral.

        The assent covers the exact terms, including the plain risk words of a
        0.2 record. Accepting again returns the stored result unchanged.
        """
        need(c.public_key(signing_key) == self.owner, 'TRADE_NOT_PAYEE')
        with self.lock:
            row = self.db.execute('SELECT state, assessment FROM trades WHERE id=?', (ref,)).fetchone()
            need(row is not None, 'TRADE_UNKNOWN')
            if row[0] == 'ACCEPTED':
                return {**json.loads(row[1]), 'repeat': True, 'bundle': self.get(ref)}
            try:
                # One write transaction: collateral counted by a concurrent accept is seen here.
                with self._write():
                    self._clock(now)
                    result = self.check(ref, now=now, policy=policy, **checks)
                    bundle = trade.assent(self.get(ref), signing_key)
                    stale = 0 if result['decision'] == 'ACCEPT' else 1
                    held = backing.collateral(bundle)
                    self.db.execute("UPDATE trades SET raw=?, record=?, state='ACCEPTED', assessment=? WHERE id=?",
                                    (trade.export_bundle(bundle), trade.record_id(bundle), _text(result), ref))
                    bucket = held['bucket'] if held else c.digest('COVENANT-OFFLINE-TRADE-COLLATERAL-0.1', {'trade': ref})
                    self.db.execute('INSERT OR IGNORE INTO exposure VALUES (?, ?, ?, ?, ?, ?)',
                                    (bucket, ref, bundle['terms']['resource']['quantity'], stale,
                                     bundle['terms']['parties']['buyer'], held.get('issuer') if held else None))
                    for label in result['freshness']['labels']:
                        if label['dated'] is not None:
                            name = '%s %s' % (label['profile'], label['issuer'])
                            self.db.execute('INSERT INTO floors VALUES (?, ?) ON CONFLICT(name) DO UPDATE SET '
                                            'sequence=max(sequence, excluded.sequence)', (name, label['sequence']))
                    self._append('ACCEPTED', {'trade': ref, 'record': trade.record_id(bundle),
                                              'decision': result['decision']})
            except TradeError as error:
                with self._write():
                    self._clock(now)
                    self.db.execute("UPDATE trades SET state='REFUSED', assessment=? WHERE id=? AND state='HELD'",
                                    (_text({'refused': error.code}), ref))
                    self._append('REFUSED', {'trade': ref, 'code': error.code})
                _log('refused', trade=ref[:16], code=error.code)
                raise
        _log('accepted', trade=ref[:16], decision=result['decision'])
        return {**result, 'repeat': False, 'bundle': bundle}

    # Quorum member or witness role -------------------------------------------
    def cosign(self, value, signing_key, *, now):
        """Co-sign the first trade seen for its slot; refuse a different trade for the same slot."""
        need(c.public_key(signing_key) == self.owner, 'TRADE_COSIGN')
        result = self.receive(value, now=now, role='PEER')
        ref, slot = result['trade'], result['slot']
        with self._write():
            self._clock(now)
            if slot is not None:
                first = self.db.execute('SELECT trade FROM slots WHERE slot=?', (slot,)).fetchone()
                need(first[0] == ref, 'TRADE_SLOT_TAKEN')
            row = self.db.execute('SELECT record FROM cosigns WHERE trade=? AND signer=?', (ref, self.owner)).fetchone()
            if row is not None:
                return json.loads(row[0])
            record = fresh.cosign(signing_key, trade_id=ref, slot=slot, seen_at=now)
            self.db.execute('INSERT INTO cosigns VALUES (?, ?, ?)', (ref, self.owner, _text(record)))
            self._append('COSIGNED', {'trade': ref, 'slot': slot})
        return record

    # Reconnection -------------------------------------------------------------
    def _request(self, bundle, action, item):
        terms = bundle['terms']; ref = trade.terms_id(bundle)
        mode = terms['policy']['mode']
        kind = terms['risk']['terms'].get('backing') if (bundle['version'] == trade.VERSION_0_2 and
                                                          mode == 'PREALLOCATED_CLAIM') else None
        instruction = None
        if kind == 'OFFLINE_VALUE':
            instruction = backing.check_instruction(bundle)
        request = c.digest(REQUEST_LABEL, {'owner': self.owner, 'item': item, 'trade': ref, 'action': action})
        return {'request': request, 'action': action, 'trade': ref, 'slot': trade.slot_id(bundle), 'mode': mode,
                'backing': kind, 'amount': terms['resource']['quantity'], 'unit': terms['resource']['unit'],
                'payer': terms['parties']['buyer'], 'payee': terms['parties']['supplier'],
                'instruction': instruction, 'provider': trade.attached(bundle, 'PROVIDER_COLLECTION')}

    def _settle_one(self, settle, bundle, action, item, now):
        request = self._request(bundle, action, item)
        with self._write():
            self._clock(now)
            row = self.db.execute('SELECT status, outcome, attempts FROM settlements WHERE item=?', (item,)).fetchone()
            if row is not None and row[0] in FINAL:
                return {'item': item, 'trade': request['trade'], 'request': request['request'], 'action': action,
                        'status': row[0], 'repeat': True, 'outcome': json.loads(row[1])}
            attempts = (row[2] if row else 0) + 1
            # Record the request ID before any effect: a lost reply is retried with the same ID.
            self.db.execute('INSERT INTO settlements VALUES (?, ?, ?, ?, ?, NULL, ?, ?) ON CONFLICT(item) DO UPDATE '
                            "SET status='IN_FLIGHT', attempts=excluded.attempts, at=excluded.at",
                            (item, request['trade'], request['request'], action, 'IN_FLIGHT', attempts, now))
            self._append('SETTLEMENT_INTENT', {'item': item, 'request': request['request'], 'attempt': attempts})
        try:
            outcome = settle(deepcopy(request))
        except Exception as error:
            outcome = {'status': 'UNKNOWN', 'error': type(error).__name__}
        if type(outcome) is not dict or outcome.get('status') not in LEG_STATUSES:
            outcome = {'status': 'UNKNOWN', 'error': 'UNRECOGNISED_LEG_REPLY'}
        status = outcome['status']
        try:
            c.canonical(outcome)
        except ValueError:
            outcome = {'status': status}
        with self._write():
            self._clock(now)
            self.db.execute('UPDATE settlements SET status=?, outcome=?, at=? WHERE item=?',
                            ('IN_FLIGHT' if status == 'UNKNOWN' else status, _text(outcome), now, item))
            self._append('SETTLEMENT_OUTCOME', {'item': item, 'request': request['request'], 'status': status})
        _log('settlement', item=item[:16], action=action, status=status)
        return {'item': item, 'trade': request['trade'], 'request': request['request'], 'action': action,
                'status': status, 'repeat': False, 'outcome': outcome}

    def reconcile(self, settle, *, now, limit=16):
        """Call the owner's settlement leg at most once per spend slot; UNKNOWN is retried, never assumed.

        settle(request) must be idempotent for request['request'] and return
        {'status': one of FINAL or UNKNOWN, ...}; an exception is UNKNOWN. A slot
        the ledger already gave to another note becomes CONFLICT; for an
        offline_value note that is followed by a SLASH request for this note.
        """
        need(callable(settle), 'TRADE_SETTLEMENT_LEG')
        need(type(limit) is int and 1 <= limit <= 256, 'TRADE_SETTLEMENT_LEG')
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            rows = self.db.execute("SELECT id, slot FROM trades WHERE state='ACCEPTED' ORDER BY received_at, id").fetchall()
        results = []
        for ref, slot in rows:
            if len(results) >= limit:
                break
            bundle = self.get(ref)
            result = self._settle_one(settle, bundle, 'SETTLE', slot or ref, now)
            results.append(result)
            if result['status'] == 'CONFLICT' and result['outcome'] is not None:
                if request_backing(bundle) == 'OFFLINE_VALUE':
                    results.append(self._settle_one(settle, bundle, 'SLASH', 'slash:' + (slot or ref), now))
                with self._write():
                    self._clock(now)
                    self._finding('CONFLICTING_SPEND', {'slot': slot, 'trades': [ref], 'buyer':
                                  bundle['terms']['parties']['buyer'], 'seen': 'AT_SETTLEMENT'}, now)
        return {'results': results, 'exactly_once': 'PER_SPEND_SLOT', 'unknown_is_success': False,
                'payment_verified': False}

    def merge(self, peer_trades, *, now):
        """Take trades a peer retained; report conflicting spends and cloned device heads."""
        need(type(peer_trades) is list and len(peer_trades) <= 256, 'TRADE_CHECK_FAILED')
        found, refused, merged = [], [], 0
        for value in peer_trades:
            try:
                found += self.receive(value, now=now, role='PEER')['findings']
                merged += 1
            except ValueError as error:
                # A peer's bad record is reported, never retained; the rest still merge.
                refused.append(str(error)[:96])
        return {'findings': found, 'merged': merged, 'refused': refused}

    def disputes(self, signing_key, *, now, reason='Two notes for one slot, or one device state used twice.'):
        """Signed dispute records for open findings that no ledger rule resolves."""
        need(c.public_key(signing_key) == self.owner, 'TRADE_DISPUTE')
        records = []
        for finding in self.findings():
            if finding['kind'] == 'CLONED_STATE':
                first, second = finding['statements']
                records.append(conflicts.dispute(signing_key, kind='CLONED_STATE', first=first, second=second,
                                                 reason=reason, at=now))
            elif finding['kind'] == 'CONFLICTING_SPEND' and len(finding['trades']) == 2:
                first, second = (self.get(ref) for ref in finding['trades'])
                if request_backing(first) != 'OFFLINE_VALUE':
                    records.append(conflicts.dispute(signing_key, kind='CONFLICTING_SPEND', first=first,
                                                     second=second, reason=reason, at=now))
        return records

    def findings(self):
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            rows = self.db.execute('SELECT id, kind, record FROM findings ORDER BY at, id').fetchall()
        return [{'id': ref, 'kind': kind, **json.loads(record)} for ref, kind, record in rows]

    def retained_heads(self):
        """The newest head statement per device: what peers give a device that lost its checkpoint."""
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            rows = self.db.execute('SELECT record FROM heads h WHERE sequence=(SELECT max(sequence) FROM heads '
                                   'WHERE device=h.device) ORDER BY device').fetchall()
        return [json.loads(row[0]) for row in rows]

    def trades_from(self, device):
        """Raw trades this inbox holds from one buyer device, for that device's recovery."""
        c.verification_key(device)
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            return [row[0] for row in self.db.execute('SELECT raw FROM trades WHERE buyer=? ORDER BY id', (device,))]

    def settlements(self):
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            rows = self.db.execute('SELECT item, trade, request, action, status, attempts FROM settlements '
                                   'ORDER BY item').fetchall()
        return [dict(zip(('item', 'trade', 'request', 'action', 'status', 'attempts'), row)) for row in rows]

    def metrics(self):
        """Prometheus text exposition (version 0.0.4) for this inbox; counts only."""
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            trades = self.db.execute('SELECT state, count(*) FROM trades GROUP BY state ORDER BY state').fetchall()
            settled = self.db.execute('SELECT status, count(*) FROM settlements GROUP BY status ORDER BY status').fetchall()
            found = self.db.execute('SELECT kind, count(*) FROM findings GROUP BY kind ORDER BY kind').fetchall()
            events = self.db.execute('SELECT count(*) FROM journal').fetchone()[0]
        lines = ['# HELP aap_offline_trade_trades Trades held in this inbox by state.',
                 '# TYPE aap_offline_trade_trades gauge']
        lines += ['aap_offline_trade_trades{state="%s"} %d' % row for row in trades]
        lines += ['# HELP aap_offline_trade_settlements Settlement records by status.',
                  '# TYPE aap_offline_trade_settlements gauge']
        lines += ['aap_offline_trade_settlements{status="%s"} %d' % row for row in settled]
        lines += ['# HELP aap_offline_trade_findings Conflicting spends and cloned state found.',
                  '# TYPE aap_offline_trade_findings gauge']
        lines += ['aap_offline_trade_findings{kind="%s"} %d' % row for row in found]
        lines += ['# HELP aap_offline_trade_journal_events Journal events retained.',
                  '# TYPE aap_offline_trade_journal_events counter', 'aap_offline_trade_journal_events %d' % events]
        return '\n'.join(lines) + '\n'


def request_backing(bundle):
    if bundle['version'] == trade.VERSION_0_2 and bundle['terms']['policy']['mode'] == 'PREALLOCATED_CLAIM':
        return bundle['terms']['risk']['terms']['backing']
    return None


class DeviceLog(_Store):
    """The buyer device's monotonic sequence and signed heads, with recovery from peers."""
    TABLES = (
        'CREATE TABLE IF NOT EXISTS issued(sequence INTEGER PRIMARY KEY, trade TEXT NOT NULL, head TEXT NOT NULL, '
        'slot TEXT, statement TEXT NOT NULL, source TEXT NOT NULL)',
    )

    def __init__(self, directory, *, device, retained=None):
        """retained is a position this device reported earlier (checkpoint()), kept elsewhere."""
        c.verification_key(device)
        self.device = device
        super().__init__(directory, 'device.sqlite', {'version': DEVICE_VERSION, 'device': device}, None)
        if retained is None:
            return
        try:
            need(type(retained) is dict and set(retained) == {'sequence', 'head'} and
                 type(retained['sequence']) is int and retained['sequence'] >= 0, 'TRADE_DEVICE_ROLLED_BACK')
            c.key(retained['head'])
        except ValueError:
            self.close()
            raise TradeError('TRADE_DEVICE_ROLLED_BACK') from None
        position = self.position()
        row = self.db.execute('SELECT head FROM issued WHERE sequence=?', (retained['sequence'],)).fetchone()
        behind = retained['sequence'] > position['sequence'] or (row is not None and row[0] != retained['head'])
        if behind:
            # Open anyway, but refuse to issue until peers have shown how far this device went.
            with self._write():
                self.db.execute("INSERT OR REPLACE INTO meta VALUES ('recovery', ?)", (str(retained['sequence']),))
                self._append('ROLLED_BACK', {'retained': retained})

    def checkpoint(self):
        """The issued position peers see: retain it elsewhere to detect a restored older copy."""
        position = self.position()
        return {'sequence': position['sequence'], 'head': position['head']}

    def position(self):
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            row = self.db.execute('SELECT sequence, head FROM issued ORDER BY sequence DESC LIMIT 1').fetchone()
            pending = self.db.execute("SELECT value FROM meta WHERE key='recovery'").fetchone()
        return {'sequence': row[0] if row else 0, 'head': row[1] if row else trade.ZERO,
                'recovery_required': pending is not None}

    def mark_restored(self):
        """Explicit owner statement that this state came from a backup of unknown age."""
        with self._write():
            self.db.execute("INSERT OR REPLACE INTO meta VALUES ('recovery', '0')")
            self._append('RESTORED', {'device': self.device})

    def record(self, signing_key, bundle, *, now):
        """Issue the next head for a trade this device signed; attach the result as HEAD."""
        need(c.public_key(signing_key) == self.device, 'TRADE_DEVICE_KEY')
        ref = trade.terms_id(bundle)
        need(bundle['terms']['parties']['buyer'] == self.device, 'TRADE_DEVICE_KEY')
        slot = trade.slot_id(bundle)
        with self._write():
            self._clock(now)
            need(self.db.execute("SELECT 1 FROM meta WHERE key='recovery'").fetchone() is None,
                 'TRADE_DEVICE_RECOVERY_REQUIRED')
            existing = self.db.execute('SELECT statement FROM issued WHERE trade=?', (ref,)).fetchone()
            if existing is not None:
                return json.loads(existing[0])
            if slot is not None:
                need(self.db.execute('SELECT 1 FROM issued WHERE slot=?', (slot,)).fetchone() is None, 'TRADE_SLOT_TAKEN')
            row = self.db.execute('SELECT sequence, head FROM issued ORDER BY sequence DESC LIMIT 1').fetchone()
            sequence, previous = (row[0] + 1, row[1]) if row else (1, trade.ZERO)
            statement = conflicts.head_statement(signing_key, sequence=sequence, previous=previous, trade_id=ref, at=now)
            self.db.execute('INSERT INTO issued VALUES (?, ?, ?, ?, ?, ?)',
                            (sequence, ref, statement['body']['head'], slot, _text(statement), 'LOCAL'))
            self._append('ISSUED', {'sequence': sequence, 'trade': ref})
        return statement

    def recover(self, statements, *, now, trades=()):
        """Adopt the newest head peers retained, and every slot their trades show was used.

        Only statements signed by this device count. If a retained checkpoint was
        given, recovery must reach it; otherwise the newest head peers hold is the
        best knowledge available, and a peer still offline may hold a newer one.
        """
        need(type(statements) is list and len(statements) <= MAX_HEADS and type(trades) in (list, tuple), 'TRADE_HEAD')
        bodies = []
        for record in statements:
            body = conflicts.check_head(record)
            need(body['device'] == self.device, 'TRADE_HEAD')
            bodies.append((body, record))
        slots = set()
        for raw in trades:
            bundle = transport.exact_load(raw, trade.MAX_BYTES_0_2) if type(raw) is bytes else raw
            trade.terms_id(bundle)
            if bundle['terms']['parties']['buyer'] == self.device and trade.slot_id(bundle) is not None:
                slots.add((trade.terms_id(bundle), trade.slot_id(bundle)))
        with self._write():
            self._clock(now)
            for body, record in sorted(bodies, key=lambda pair: pair[0]['sequence']):
                row = self.db.execute('SELECT head FROM issued WHERE sequence=?', (body['sequence'],)).fetchone()
                if row is None:
                    slot = next((s for t, s in slots if t == body['trade']), None)
                    self.db.execute('INSERT INTO issued VALUES (?, ?, ?, ?, ?, ?)',
                                    (body['sequence'], body['trade'], body['head'], slot, _text(record), 'PEER'))
            for ref, slot in slots:
                if self.db.execute('SELECT 1 FROM issued WHERE slot=?', (slot,)).fetchone() is None:
                    top = self.db.execute('SELECT coalesce(max(sequence), 0) FROM issued').fetchone()[0]
                    # A used slot without a known head still must never be reused.
                    self.db.execute('INSERT INTO issued VALUES (?, ?, ?, ?, ?, ?)',
                                    (top + 1, ref, trade.ZERO, slot, _text({'recovered_slot': slot}), 'PEER_SLOT'))
            top = self.db.execute('SELECT coalesce(max(sequence), 0) FROM issued').fetchone()[0]
            pending = self.db.execute("SELECT value FROM meta WHERE key='recovery'").fetchone()
            if pending is not None and top >= int(pending[0]):
                self.db.execute("DELETE FROM meta WHERE key='recovery'")
            self._append('RECOVERED', {'sequence': top, 'statements': len(bodies), 'slots': len(slots)})
        return {**self.position(), 'residual_risk': 'A_PEER_STILL_OFFLINE_MAY_HOLD_A_NEWER_HEAD'}

    def audit(self, statements):
        """Statements signed by this device that its own log did not issue: cloned state or a copied key."""
        need(type(statements) is list and len(statements) <= MAX_HEADS, 'TRADE_HEAD')
        foreign = []
        with self.lock:
            need(not self.closed, 'TRADE_INBOX_CLOSED')
            for record in statements:
                body = conflicts.check_head(record)
                if body['device'] != self.device:
                    continue
                row = self.db.execute('SELECT head FROM issued WHERE sequence=?', (body['sequence'],)).fetchone()
                if row is not None and row[0] != body['head']:
                    foreign.append(record)
        return {'cloned': bool(foreign), 'statements': foreign,
                'meaning': 'ANOTHER_COPY_OF_THIS_DEVICE_STATE_OR_KEY_SIGNED_THESE' if foreign else 'NONE_FOUND'}


def describe():
    return {'inbox': INBOX_VERSION, 'device': DEVICE_VERSION, 'schema': SCHEMA, 'storage': 'SQLITE_WAL_SYNCHRONOUS_FULL',
            'journal': 'HASH_CHAINED_APPEND_ONLY', 'exactly_once': 'ONE_SETTLEMENT_RECORD_PER_SPEND_SLOT',
            'unknown_outcome': 'RETRIED_WITH_THE_SAME_REQUEST_ID', 'limits': {'trades': MAX_TRADES,
            'findings': MAX_FINDINGS, 'heads': MAX_HEADS, 'record_bytes': trade.MAX_BYTES_0_2},
            'metrics': 'PROMETHEUS_TEXT_0_0_4', 'logs': 'JSON_LINES_IDS_ONLY', 'rollback_detection':
            'ONLY_AGAINST_A_CHECKPOINT_RETAINED_ELSEWHERE', 'execution_authorized': False}
