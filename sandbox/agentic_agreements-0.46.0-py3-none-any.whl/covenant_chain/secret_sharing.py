"""Threshold sharing of a 256-bit key: Shamir shares, Feldman commitments, HPKE-sealed per holder.

* Shamir, "How to share a secret", CACM 22(11), 1979: a random polynomial f of
  degree k-1 over Z_n, n the P-256 group order, with f(0) the secret. Holder i
  receives f(i). Any k shares rebuild f(0) by Lagrange interpolation; any k-1
  shares are consistent with every possible secret.
* Feldman, "A practical scheme for non-interactive verifiable secret sharing",
  FOCS 1987: commitments C_j = a_j*G on P-256 (FIPS 186-5; NIST SP 800-186
  section 3.2.1.3) let a holder check s_i*G = sum_j i^j*C_j. A dealer cannot hand
  out inconsistent shares unnoticed, and a bad released share is attributable to
  whoever released it. C_0 = secret*G is public, so secrecy against fewer than k
  holders rests on the discrete logarithm problem on P-256.
* Each share is sealed to its holder's X25519 key with HPKE base mode, single
  shot (RFC 9180 sections 5.1 and 6.1): DHKEM(X25519, HKDF-SHA256), HKDF-SHA256,
  AES-128-GCM (KEM 0x0020, KDF 0x0001, AEAD 0x0001), from the pinned cryptography
  package. ``info`` binds the deal context, the holder index and the holder key.

OpenSSL multiplies every secret scalar (secret*G, a_j*G, s_i*G); the variable
time arithmetic of weierstrass.py only combines public commitments. Lagrange
interpolation of released shares runs in Python integers on the combining host.
"""
import base64
import secrets

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hpke
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey

from .crypto import HEX, canonical, digest, key, need
from .weierstrass import P256

VERSION = 'covenant-threshold-deal/0.1'
LABEL = 'COVENANT-THRESHOLD-DEAL-0.1'
SHARE_INFO = b'AAP-THRESHOLD-SHARE-0.1'
SUITE = 'HPKE-BASE-DHKEM-X25519-HKDF-SHA256-AES-128-GCM'
MAX_HOLDERS = 16
MAX_SEALED = 4096
_SUITE = hpke.Suite(hpke.KEM.X25519, hpke.KDF.HKDF_SHA256, hpke.AEAD.AES_128_GCM)

REMEDIATION = {
    'SHARING_THRESHOLD': 'Use a threshold k with 2 <= k <= n and at most 16 holders.',
    'SHARING_HOLDERS': 'Name each holder by a distinct, valid X25519 public key (64 hex).',
    'SHARING_RECORD': 'Use the exact deal fields from describe() with one commitment per threshold step and one sealed share per holder.',
    'SHARING_INDEX': 'Use a holder index from 1 to the number of holders.',
    'SHARING_SEALED': 'The sealed share does not open under this holder key and context; it is not yours or was altered.',
    'SHARING_SHARE_INVALID': 'The share fails the Feldman check against the published commitments.',
    'SHARING_THRESHOLD_UNMET': 'Collect at least k distinct valid shares before combining.',
    'SHARING_SECRET': 'Use a secret from 1 to the P-256 group order minus 1.',
    'SHARING_CONTEXT': 'Bind the deal to a 64-hex context chosen by the dealer.',
    'SHARING_INFO': 'Pass HPKE info as at most 1024 bytes.',
    'SHARING_ENCODING': 'Use unpadded base64url for sealed shares.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Inspect the module description and supply the exact documented shape.')


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _unb64(text, maximum=MAX_SEALED):
    need(type(text) is str and 0 < len(text) <= maximum and all(c.isalnum() or c in '-_' for c in text), 'SHARING_ENCODING')
    try:
        raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    except ValueError:
        raise ValueError('SHARING_ENCODING') from None
    need(_b64(raw) == text, 'SHARING_ENCODING')
    return raw


def x25519_public(private):
    need(isinstance(private, X25519PrivateKey), 'SHARING_HOLDERS')
    return private.public_key().public_bytes_raw().hex()


def _holder(value):
    key(value)
    try:
        return X25519PublicKey.from_public_bytes(bytes.fromhex(value))
    except ValueError:
        raise ValueError('SHARING_HOLDERS') from None


def seal(holder, plaintext, info):
    """HPKE base-mode single-shot seal to an X25519 public key (64 hex); returns enc || ciphertext, base64url."""
    need(type(plaintext) is bytes and len(plaintext) <= 1024, 'SHARING_RECORD')
    need(type(info) is bytes and len(info) <= 1024, 'SHARING_INFO')
    return _b64(_SUITE.encrypt(plaintext, _holder(holder), info=info))


def unseal(private, sealed, info):
    """Open what ``seal`` made for this private key and info, or SHARING_SEALED."""
    need(isinstance(private, X25519PrivateKey), 'SHARING_HOLDERS')
    need(type(info) is bytes and len(info) <= 1024, 'SHARING_INFO')
    raw = _unb64(sealed)
    try:
        return _SUITE.decrypt(raw, private, info=info)
    except (InvalidTag, ValueError):
        raise ValueError('SHARING_SEALED') from None


def _context(value):
    need(type(value) is str and HEX.fullmatch(value) is not None, 'SHARING_CONTEXT')
    return value


def _share_info(context, index, holder):
    return SHARE_INFO + b'\0' + canonical({'context': context, 'index': index, 'holder': holder})


def _polynomial(secret, threshold):
    return [secret] + [secrets.randbelow(P256.n - 1) + 1 for _ in range(threshold - 1)]


def _evaluate(coefficients, x):
    value = 0
    for coefficient in reversed(coefficients):
        value = (value * x + coefficient) % P256.n
    return value


def deal(threshold, holders, *, context, secret=None):
    """(public deal record, secret) for ``holders`` (X25519 public keys, index = position + 1).

    The record carries Feldman commitments and one sealed share per holder. The
    secret is returned to the dealer alone; derive keys from it and discard it.
    """
    need(type(holders) is list and 2 <= len(holders) <= MAX_HOLDERS and len(set(holders)) == len(holders),
         'SHARING_HOLDERS')
    for holder in holders:
        _holder(holder)
    need(type(threshold) is int and 2 <= threshold <= len(holders), 'SHARING_THRESHOLD')
    _context(context)
    if secret is None:
        secret = secrets.randbelow(P256.n - 1) + 1
    need(type(secret) is int and 0 < secret < P256.n, 'SHARING_SECRET')
    while True:
        coefficients = _polynomial(secret, threshold)
        shares = [_evaluate(coefficients, index) for index in range(1, len(holders) + 1)]
        if all(shares):
            break  # a zero share has probability about 2**-256; deal again rather than publish it
    commitments = [P256.encode(P256.base_mul(coefficient)).hex() for coefficient in coefficients]
    sealed = [seal(holder, share.to_bytes(32, 'big'), _share_info(context, index, holder))
              for index, (holder, share) in enumerate(zip(holders, shares), start=1)]
    record = {'version': VERSION, 'suite': SUITE, 'context': context, 'threshold': threshold,
              'holders': list(holders), 'commitments': commitments, 'sealed': sealed}
    return record, secret


def validate(record):
    need(type(record) is dict and set(record) == {'version', 'suite', 'context', 'threshold', 'holders',
                                                  'commitments', 'sealed'}, 'SHARING_RECORD')
    need(record['version'] == VERSION and record['suite'] == SUITE, 'SHARING_RECORD')
    _context(record['context'])
    holders = record['holders']
    need(type(holders) is list and 2 <= len(holders) <= MAX_HOLDERS and len(set(holders)) == len(holders),
         'SHARING_HOLDERS')
    for holder in holders:
        _holder(holder)
    need(type(record['threshold']) is int and 2 <= record['threshold'] <= len(holders), 'SHARING_THRESHOLD')
    commitments = record['commitments']
    need(type(commitments) is list and len(commitments) == record['threshold']
         and all(type(item) is str and len(item) == 66 for item in commitments), 'SHARING_RECORD')
    try:
        points = [P256.decode(bytes.fromhex(item)) for item in commitments]
    except ValueError:
        raise ValueError('SHARING_RECORD') from None
    need(type(record['sealed']) is list and len(record['sealed']) == len(holders), 'SHARING_RECORD')
    for item in record['sealed']:
        _unb64(item)
    canonical(record)
    return points


def deal_id(record):
    validate(record)
    return digest(LABEL, record)


def check_share(record, index, share):
    """Feldman: share*G must equal sum_j index^j * C_j. True, or SHARING_SHARE_INVALID."""
    points = validate(record)
    need(type(index) is int and 1 <= index <= len(record['holders']), 'SHARING_INDEX')
    need(type(share) is int and 0 < share < P256.n, 'SHARING_SHARE_INVALID')
    expected = None
    for point in reversed(points):  # Horner: ((C_{k-1})*i + C_{k-2})*i + ... + C_0
        expected = P256.add(P256.mul(index, expected) if expected is not None else None, point)
    need(expected is not None and P256.base_mul(share) == expected, 'SHARING_SHARE_INVALID')
    return True


def open_share(record, index, private):
    """A holder opens its own sealed share and checks it against the commitments."""
    validate(record)
    need(type(index) is int and 1 <= index <= len(record['holders']), 'SHARING_INDEX')
    holder = record['holders'][index - 1]
    need(x25519_public(private) == holder, 'SHARING_HOLDERS')
    raw = unseal(private, record['sealed'][index - 1], _share_info(record['context'], index, holder))
    need(len(raw) == 32, 'SHARING_SEALED')
    share = int.from_bytes(raw, 'big')
    check_share(record, index, share)
    return share


def combine(record, shares):
    """The secret from at least k shares ({index: share}); every share must pass the Feldman check first."""
    points = validate(record)
    need(type(shares) is dict and len(shares) <= len(record['holders']), 'SHARING_THRESHOLD_UNMET')
    for index, share in shares.items():
        check_share(record, index, share)
    need(len(shares) >= record['threshold'], 'SHARING_THRESHOLD_UNMET')
    chosen = sorted(shares.items())[:record['threshold']]
    n, secret = P256.n, 0
    for i, share in chosen:
        numerator = denominator = 1
        for j, _ in chosen:
            if j != i:
                numerator = numerator * j % n
                denominator = denominator * (j - i) % n
        secret = (secret + share * numerator * pow(denominator, -1, n)) % n
    need(0 < secret < n and P256.base_mul(secret) == points[0], 'SHARING_SHARE_INVALID')
    return secret


def describe():
    return {'version': VERSION, 'label': LABEL, 'status': 'EXPERIMENTAL_PRIMITIVE',
            'sharing': 'SHAMIR_1979_OVER_P256_ORDER', 'verifiable': 'FELDMAN_1987_COMMITMENTS_ON_P256',
            'sealing': SUITE + ' (RFC 9180, pinned cryptography package)',
            'hiding': 'SHARES_INFORMATION_THEORETIC; COMMITMENT_C0_COMPUTATIONAL_DLOG_P256',
            'limits': {'holders': MAX_HOLDERS, 'threshold': 'TWO_TO_HOLDERS'},
            'not_implemented': ['publicly verifiable sharing (anyone checks every sealed share)',
                                'hybrid ML-KEM-768 + X25519 HPKE (draft-ietf-hpke-pq): not adopted until confirmed',
                                'proactive share refresh and holder replacement'],
            'remediation': dict(REMEDIATION), 'execution_authorized': False}
