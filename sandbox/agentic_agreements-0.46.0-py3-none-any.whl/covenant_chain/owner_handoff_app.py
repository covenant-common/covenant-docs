"""Owner-operated, loopback-only agreement signing and portable handoff UI.

The local operating-system account and private home are the trust boundary.
This is not public or multi-user authentication and exposes no agent signing API.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import secrets

from .crypto import need
from .http_limits import BoundedHTTPServer
from . import portable_agreements as portable
from .welcome_app import WelcomeHandler
from . import observability
from .backup import refuse_pending_restore

COOKIE = 'covenant_owner_handoff'
# Only the HTTP envelope gets additional space. Native package limits remain
# enforced by portable_agreements; no signed profile or package limit changes.
MAX_REQUEST_BYTES = portable.MAX_BYTES + 4096
ROUTES = {
    '/api/create-identity': 'create_identity', '/api/draft': 'draft',
    '/api/receive': 'receive', '/api/review-sign': 'review_sign',
    '/api/sign': 'sign', '/api/merge': 'merge', '/api/export': 'export',
    '/api/open-source': 'open_source', '/api/open-object': 'open_object',
    '/api/open-context': 'open_context',
}


def describe():
    """Static discovery only; no private home, key or listener is opened."""
    return {'interface': 'covenant-owner-handoff-ui/0.1',
            'launch': 'python -m covenant_chain.owner_handoff_app --home PATH --port 0',
            'trust_boundary': 'OWNER_LOCAL_OS_AND_LOOPBACK_ONLY',
            'bind': '127.0.0.1', 'browser_required': True,
            'agent_signing_interface': False, 'external_calls': False,
            'identity_creation': 'EXPLICIT_OWNER_ACTION',
            'signing': 'EXPLICIT_OWNER_REVIEW_AND_CONFIRMATION',
            'portable_maximum_bytes': portable.MAX_BYTES,
            'request_maximum_bytes': MAX_REQUEST_BYTES,
            'plaintext_export_confirmation_required': True,
            'independent_incoming_fingerprint_required': True,
            'automatic_mutation_replay': False, 'execution_authorized': False}


def _wire(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('ascii')


def _json(raw):
    """Strict bounded envelope parser, preserving native package validation."""
    need(0 < len(raw) <= MAX_REQUEST_BYTES, 'HANDOFF_SIZE')
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('HANDOFF_JSON') from None
    depth = 0
    quoted = escaped = False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in '[{':
            depth += 1
            need(depth <= portable.MAX_DEPTH + 2, 'HANDOFF_COMPLEXITY')
        elif char in ']}':
            depth -= 1

    def pairs(items):
        result = {}
        for name, value in items:
            need(name not in result, 'HANDOFF_DUPLICATE_FIELD')
            result[name] = value
        return result

    def integer(value):
        need(len(value.lstrip('-')) <= 16, 'HANDOFF_INTEGER')
        result = int(value)
        need(abs(result) <= 2**53 - 1, 'HANDOFF_INTEGER')
        return result

    def noninteger(_):
        raise ValueError('HANDOFF_NUMBER')

    try:
        value = json.loads(text, object_pairs_hook=pairs, parse_int=integer,
                           parse_float=noninteger, parse_constant=noninteger)
    except (json.JSONDecodeError, RecursionError):
        raise ValueError('HANDOFF_JSON') from None
    need(type(value) is dict, 'HANDOFF_FIELDS')
    return value


class HandoffHTTPServer(BoundedHTTPServer):
    allow_reuse_address = True
    allow_reuse_port = False

    def __init__(self, session, port=0, *, max_connections=8, connection_seconds=3):
        need(type(port) is int and 0 <= port <= 65535, 'HANDOFF_PORT')
        self.session = session
        self.csrf = secrets.token_hex(32)
        self.cookie = secrets.token_hex(32)
        super().__init__(('127.0.0.1', port), HandoffHandler,
                         max_connections=max_connections, connection_seconds=connection_seconds)
        self.origin = 'http://127.0.0.1:' + str(self.server_address[1])
        self.cookie_name = COOKIE + '_' + str(self.server_address[1])
        self.ops = observability.Ops('handoff', routes={'/', '/style.css', '/app.js', '/api/state'} | set(ROUTES))
        self.ops.health.add('session', lambda: not session._closed or 'HANDOFF_CLOSED')
        self.ops.health.add('home', observability.writable_directory(str(session.home)))


class HandoffHandler(WelcomeHandler):
    """Reuse the established exact Host/Origin/session and response policy."""
    server_version = 'AAPOwnerHandoff'

    def _error(self, code, status=400):
        if code.startswith('WELCOME_'):
            code = 'HANDOFF_' + code[len('WELCOME_'):]
        self._response(status, _wire({'error': {'code': code}}))

    def do_GET(self, head=False):
        try:
            self._same_origin()
            need(self.headers.get('Transfer-Encoding') is None
                 and self.headers.get('Expect') is None
                 and self.headers.get('Content-Length') in (None, '0'), 'HANDOFF_FRAMING')
            from .owner_handoff_ui import index_html, stylesheet, script
            assets = {'/': (lambda: index_html(self.server.csrf), 'text/html; charset=utf-8'),
                      '/style.css': (stylesheet, 'text/css; charset=utf-8'),
                      '/app.js': (script, 'application/javascript; charset=utf-8')}
            if self.path in assets:
                render, media = assets[self.path]
                self._response(200, render(), media, cookie=self.path == '/', head=head)
            elif self.path == '/api/state':
                self._authenticated()
                self._response(200, _wire(self.server.session.state()), head=head)
            else:
                self._error('HANDOFF_NOT_FOUND', 404)
        except (ValueError, OSError) as exc:
            self._failure(exc)

    def do_POST(self):
        try:
            self._same_origin()
            need(self.headers.get_all('Origin') == [self.server.origin], 'HANDOFF_ORIGIN')
            self._authenticated()
            need(self.headers.get_all('X-Covenant-CSRF') == [self.server.csrf], 'HANDOFF_CSRF')
            need(self.headers.get_all('Content-Type') == ['application/json'], 'HANDOFF_CONTENT_TYPE')
            need(self.headers.get('Transfer-Encoding') is None and self.headers.get('Expect') is None,
                 'HANDOFF_FRAMING')
            lengths = self.headers.get_all('Content-Length')
            need(lengths is not None and len(lengths) == 1 and lengths[0].isascii()
                 and lengths[0].isdigit() and len(lengths[0]) <= 7, 'HANDOFF_LENGTH')
            length = int(lengths[0])
            need(0 < length <= MAX_REQUEST_BYTES, 'HANDOFF_SIZE')
            method = ROUTES.get(self.path)
            need(method is not None, 'HANDOFF_NOT_FOUND')
            raw = self.rfile.read(length)
            need(len(raw) == length, 'HANDOFF_LENGTH')
            payload = _json(raw)
            result = getattr(self.server.session, method)(payload)
            self._response(200, _wire(result))
        except (ValueError, TypeError, OSError, RecursionError, OverflowError) as exc:
            self._failure(exc)

    def _failure(self, exc):
        code = str(exc)
        if code.startswith('WELCOME_'):
            code = 'HANDOFF_' + code[len('WELCOME_'):]
        # Never return exception details containing filenames, source, or keys.
        if not (code.isascii() and code.isupper()
                and code.replace('_', '').isalnum() and len(code) <= 100):
            code = 'HANDOFF_INVALID_INPUT'
        status = 404 if code == 'HANDOFF_NOT_FOUND' else 409 if (
            'CHANGED' in code or 'STALE' in code or 'EXPIRED' in code) else 400
        self._error(code, status)


def arguments():
    """The handoff command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home', type=Path, default=Path(os.environ.get(
        'COVENANT_HOME', str(Path.home() / '.covenant'))) / 'owner-handoff',
        help='Owner-private storage; identity creation is an explicit browser action.')
    parser.add_argument('--port', type=int, default=0, help='Loopback port; 0 selects a free port.')
    parser.add_argument('--describe', action='store_true', help='Print static interface metadata without opening storage or a listener.')
    observability.add_arguments(parser)
    return parser


def main(argv=None):
    args = arguments().parse_args(argv)
    if args.describe:
        print(json.dumps(describe(), sort_keys=True))
        return
    from .owner_handoff import HandoffSession
    refuse_pending_restore(args.home)
    session = HandoffSession(args.home)
    try:
        server = HandoffHTTPServer(session, args.port)
        observability.start(server.ops, args)
        print(json.dumps({'url': server.origin, 'local_only': True,
                          'execution_authorized': False}), flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
            server.ops.close()
    finally:
        session.close()


if __name__ == '__main__':
    main()
