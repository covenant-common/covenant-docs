"""Shared file of signed directory documents.

A keyless host signs with a disposable forum key, or accepts a profile the
caller already signed. Search reads the file, so another process is visible.
The forum key is not a principal seed and it does not submit a BIND.
"""
import fcntl
import json
import os
import stat
from pathlib import Path

from covenant_language.safe_io import append_record, lock_file

from .crypto import need
from .directory_network import document_id, open_document, sign_document

CHAIN = 'a' * 64
MAX_BOARD_BYTES = 64 * 1024 * 1024
MAX_ROW_BYTES = 1024 * 1024


class DirectoryBoard:
    def __init__(self, path, signer=None, chain=CHAIN):
        self.path = Path(path)
        self.signer = signer
        self.chain = chain
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        parent = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            need(stat.S_IMODE(os.fstat(parent).st_mode) & 0o077 == 0, 'DIRECTORY_PRIVATE_PARENT')
            fd = os.open(self.path.name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600, dir_fd=parent)
            try:
                self._check_file(fd)
            finally:
                os.close(fd)
        finally:
            os.close(parent)

    @staticmethod
    def _check_file(fd):
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1
             and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'DIRECTORY_PRIVATE_FILE')
        need(info.st_size <= MAX_BOARD_BYTES, 'DIRECTORY_STORAGE_LIMIT')

    def _lock(self, shared):
        parent = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            need(stat.S_IMODE(os.fstat(parent).st_mode) & 0o077 == 0, 'DIRECTORY_PRIVATE_PARENT')
            fd = os.open(self.path.name, os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        finally:
            os.close(parent)
        try:
            self._check_file(fd)
            lock_file(fd, shared=shared)
            self._check_file(fd)
            return fd
        except BaseException:
            os.close(fd)
            raise

    def _unlock(self, fd):
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)

    def _read(self, fd):
        os.lseek(fd, 0, os.SEEK_SET)
        rows = []
        with os.fdopen(os.dup(fd), 'rb') as handle:
            while line := handle.readline(MAX_ROW_BYTES + 1):
                need(len(line) <= MAX_ROW_BYTES, 'DIRECTORY_ROW_LIMIT')
                if not line.endswith(b'\n'):
                    break  # A torn append from a crash; append_record cuts it back.
                if line.strip():
                    rows.append(json.loads(line))
        return rows

    def documents(self):
        fd = self._lock(True)
        try:
            rows = self._read(fd)
        finally:
            self._unlock(fd)
        for envelope in rows:
            open_document(envelope)
        return rows

    def page(self, cursor=None, limit=100, kind=None):
        """Explicit pages preserve history beyond the bounded ranking input limit."""
        need(type(limit) is int and 1 <= limit <= 256, 'DIRECTORY_PAGE_LIMIT')
        need(cursor is None or (type(cursor) is str and cursor.isascii() and cursor.isdigit()
                               and len(cursor) <= 12), 'DIRECTORY_PAGE_CURSOR')
        offset = 0 if cursor is None else int(cursor)
        rows = self.documents()
        if kind is not None:
            rows = [r for r in rows if r['body']['kind'] == kind]
        need(offset <= len(rows), 'DIRECTORY_PAGE_CURSOR')
        end = min(len(rows), offset + limit)
        return {'records': rows[offset:end], 'next_cursor': str(end) if end < len(rows) else None,
                'total': len(rows), 'scope': 'LOCAL_SIGNED_HISTORY_PAGE_NOT_CURRENTNESS_OR_WORLD_TRUTH',
                'execution_authorized': False, 'publicly_published': False}

    def accept(self, envelope):
        """Store one already-signed document. A bad signature is refused."""
        opened = open_document(envelope)
        need(opened['body']['chain'] == self.chain, 'DIRECTORY_CHAIN')
        fd = self._lock(False)
        try:
            rows = self._read(fd)
            if opened['id'] in {document_id(row) for row in rows}:
                return {'id': opened['id'], 'stored': False, 'signed_by': 'caller'}
            raw = (json.dumps(envelope, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')
            need(len(raw) <= MAX_ROW_BYTES and os.fstat(fd).st_size + len(raw) <= MAX_BOARD_BYTES, 'DIRECTORY_STORAGE_LIMIT')
            append_record(fd, raw)
        finally:
            self._unlock(fd)
        return {'id': opened['id'], 'stored': True, 'signed_by': 'caller'}

    def sign(self, kind, revision, payload):
        """Sign with the disposable forum key and store the envelope."""
        need(self.signer is not None, 'DIRECTORY_NETWORK')
        envelope = sign_document(self.signer, self.chain, kind, revision, payload)
        stored = self.accept(envelope)
        stored['signed_by'] = 'forum'
        stored['envelope'] = envelope
        return stored
