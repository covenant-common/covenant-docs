"""Atomic SQLite safety state plus indexed immutable certified history.

FULL synchronization is required. A signature is not released until its safety
record commits. Finalized history and the new safety floor commit together.
"""
from covenant_language.platform_support import require_posix
require_posix("covenant_chain/storage")
import json
import os
import sqlite3
from pathlib import Path

class CommitLog:
    def __init__(self,journal):self.journal=journal;self.pending=[]
    def __len__(self):return self.journal.db.execute('SELECT COALESCE(MAX(height),0) FROM commits').fetchone()[0]+len(self.pending)
    def __getitem__(self,i):
        size=len(self)
        if i<0:i+=size
        if not 0<=i<size:raise IndexError(i)
        base=size-len(self.pending)
        if i>=base:return self.pending[i-base]
        return json.loads(self.journal.db.execute('SELECT body FROM commits WHERE height=?',(i+1,)).fetchone()[0])
    def append(self,value):self.pending.append(value)
    def read(self,start=1,limit=None):
        sql='SELECT body FROM commits WHERE height>=? ORDER BY height'
        params=[start]
        if limit is not None:sql+=' LIMIT ?';params.append(limit)
        return [json.loads(row[0]) for row in self.journal.db.execute(sql,params)]

class Journal:
    def __init__(self,path):
        self.path=Path(str(path)+'.sqlite3')
        self.db=sqlite3.connect(self.path,isolation_level=None,check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS safety (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS commits (height INTEGER PRIMARY KEY, body TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS transactions (id TEXT PRIMARY KEY, height INTEGER NOT NULL)')
        self.log=CommitLog(self)
        fd=os.open(self.path.parent,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
    def close(self):
        self.db.close()

    def transaction(self,tid):
        row=self.db.execute('SELECT height FROM transactions WHERE id=?',(tid,)).fetchone()
        return {'id':tid,'status':'committed','height':row[0]} if row else None
    def load(self):
        row=self.db.execute('SELECT body FROM safety WHERE id=1').fetchone()
        if row is None:return None
        state=json.loads(row[0]);state['commits']=self.log;return state
    def save(self,state):
        encoded=json.dumps({k:v for k,v in state.items() if k!='commits'},sort_keys=True,separators=(',',':'))
        entries=state['commits'].pending
        self.db.execute('BEGIN IMMEDIATE')
        try:
            for entry in entries:
                self.db.execute('INSERT INTO commits(height,body) VALUES (?,?)',(entry['block']['height'],json.dumps(entry,separators=(',',':'))))
                from .app import transaction_id
                for tx in entry['block'].get('txs',[]):
                    if type(tx) is dict and type(tx.get('body')) is dict:
                        self.db.execute('INSERT INTO transactions VALUES (?,?)',(transaction_id(tx),entry['block']['height']))
            self.db.execute('INSERT INTO safety VALUES (1,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body',(encoded,))
            self.db.execute('COMMIT')
        except BaseException:
            if self.db.in_transaction:self.db.execute('ROLLBACK')
            raise
        entries.clear()


def seal_host_blob(provider, payload, *, aad=b''):
    """Seal one host blob with an owner KeyProvider (covenant_chain.key_provider).

    Journal.save never calls this: consensus bytes keep their own path. The
    provider binds its version and key id into the AEAD associated data.
    """
    seal=getattr(provider,'seal',None)
    if not callable(seal):raise ValueError('KEY_PROVIDER_SEAL')
    return seal(payload,aad=aad)
