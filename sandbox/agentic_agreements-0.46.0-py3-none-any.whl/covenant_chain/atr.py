"""ATR hash: SHA-256 of the exact bytes of an Agentic Transaction Record.

Maturity: experimental. One shared helper for every module that writes,
compares or places an ATR hash: the LCP emitter and buyer gate, rail binding,
and the ATR checks of other optional plugins. Nothing here parses or interprets
the record. A matching hash says the bytes are the ones the hash names; it is
not assent, authority, payment or legal effect.

The rules follow the Apache-2.0 Legal Context Protocol and the vendored
``@integraledger/lcp`` 0.4.2 core (Copyright Integra Ledger and contributors;
see NOTICE and third_party/integraledger-lcp/LICENSE): the hash is written as
``0x`` and 64 lowercase hex digits and compared on the decoded 32 bytes in
either case (LCP section 2.5); the string placement is ``lcp:sha256:0x...``
(section 8.1); and a link is the one https rule of ``isHttpsLink``. Python
reaches the same answers as that core on its vectors and on a differential
corpus (tests/test_legal_evidence.py).
"""
import hashlib
import hmac
import re

from .crypto import key, need

ATR_MAX_BYTES = 1048576
HASH_TEXT = re.compile(r'0x[0-9a-fA-F]{64}\Z')
LCP_PREFIX = 'lcp:sha256:'
MAX_LINK_UNITS = 2048

# isHttpsLink: Unicode White_Space, every Cc control and the backslash.
LINK_FORBIDDEN = re.compile('[\u0000- \u007f-   -     　\\\\]')
HTTPS_AUTHORITY = re.compile(r'https://([^/?#]*)', re.IGNORECASE)
_LABEL = '[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?'
HOST_PORT = re.compile(r'(?:\[[0-9A-Fa-f:.]+\]|' + _LABEL + r'(?:\.' + _LABEL + r')*\.?)(?::([0-9]{0,5}))?\Z')
MAX_DNS_NAME = 253
MAX_AUTHORITY = MAX_DNS_NAME + 1 + 6


def hash_bytes(raw):
    """``0x`` and lowercase hex of SHA-256 over the bytes as given."""
    need(type(raw) is bytes, 'ATR_BYTES')
    return '0x' + hashlib.sha256(raw).hexdigest()


def atr_hash(raw, *, limit=ATR_MAX_BYTES):
    """The ATR hash of 1..limit bytes from an untrusted source."""
    need(type(limit) is int and 1 <= limit <= ATR_MAX_BYTES, 'ATR_LIMIT')
    need(type(raw) is bytes and 0 < len(raw) <= limit, 'ATR_SIZE')
    return hash_bytes(raw)


def decode(value):
    """The 32 bytes of ``0x`` and 64 hex digits in either case, or ``None``."""
    if type(value) is not str or HASH_TEXT.fullmatch(value) is None:
        return None
    return bytes.fromhex(value[2:])


def normalize(value):
    """The one written form: ``0x`` and lowercase hex. ATR_HASH otherwise."""
    raw = decode(value)
    need(raw is not None, 'ATR_HASH')
    return '0x' + raw.hex()


def hash_equals(left, right):
    """Constant-time compare of two hashes; anything malformed is unequal."""
    a, b = decode(left), decode(right)
    if a is None or b is None:
        return False
    return hmac.compare_digest(a, b)


def matches(raw, claimed, *, limit=ATR_MAX_BYTES):
    """True when bounded bytes hash to the claimed ATR hash."""
    return hash_equals(claimed, atr_hash(raw, limit=limit))


def to_key(value):
    """The bare 64 lowercase hex digits, for fields checked with ``crypto.key``."""
    return normalize(value)[2:]


def from_key(value):
    key(value)
    return '0x' + value


def to_lcp_string(value):
    """LCP section 8.1 string form."""
    return LCP_PREFIX + normalize(value)


def from_lcp_string(text):
    """The lowercase hash of ``lcp:sha256:0x...``, or ``None``."""
    if type(text) is not str or not text.startswith(LCP_PREFIX):
        return None
    raw = decode(text[len(LCP_PREFIX):])
    return None if raw is None else '0x' + raw.hex()


def _well_formed(text):
    return all(not 0xD800 <= ord(ch) <= 0xDFFF for ch in text)


def _units(text):
    """String length in UTF-16 code units, as JavaScript counts it."""
    return len(text) + sum(1 for ch in text if ord(ch) > 0xFFFF)


def _ipv4_number(part):
    """WHATWG IPv4 number parser: the value, or None for failure."""
    if part == '':
        return None
    radix = 10
    if len(part) >= 2 and part[:2] in ('0x', '0X'):
        part, radix = part[2:], 16
    elif len(part) >= 2 and part[0] == '0':
        part, radix = part[1:], 8
    if part == '':
        return 0
    digits = '0123456789abcdefABCDEF'[:22 if radix == 16 else radix]
    if any(ch not in digits for ch in part):
        return None
    return int(part, radix)


def _ends_in_number(host):
    parts = host.split('.')
    if parts[-1] == '':
        if len(parts) == 1:
            return False
        parts = parts[:-1]
    last = parts[-1]
    if last and all('0' <= ch <= '9' for ch in last):
        return True
    return _ipv4_number(last) is not None


def _ipv4(host):
    parts = host.split('.')
    if parts[-1] == '' and len(parts) > 1:
        parts = parts[:-1]
    if len(parts) > 4:
        return False
    numbers = [_ipv4_number(part) for part in parts]
    if any(number is None for number in numbers):
        return False
    if any(number > 255 for number in numbers[:-1]):
        return False
    return numbers[-1] < 256 ** (5 - len(numbers))


def _ipv6(text):
    """WHATWG IPv6 parser, success or failure only."""
    pieces = [0] * 8
    index = 0
    compress = None
    at = 0
    end = len(text)

    def char(position):
        return text[position] if position < end else None

    hexdigits = '0123456789abcdefABCDEF'
    if char(at) == ':':
        if char(at + 1) != ':':
            return False
        at += 2
        index += 1
        compress = index
    while char(at) is not None:
        if index == 8:
            return False
        if char(at) == ':':
            if compress is not None:
                return False
            at += 1
            index += 1
            compress = index
            continue
        value = length = 0
        while length < 4 and char(at) is not None and char(at) in hexdigits:
            value = value * 16 + int(char(at), 16)
            at += 1
            length += 1
        if char(at) == '.':
            if length == 0:
                return False
            at -= length
            if index > 6:
                return False
            seen = 0
            while char(at) is not None:
                piece = None
                if seen > 0:
                    if char(at) == '.' and seen < 4:
                        at += 1
                    else:
                        return False
                if char(at) is None or not '0' <= char(at) <= '9':
                    return False
                while char(at) is not None and '0' <= char(at) <= '9':
                    number = int(char(at))
                    if piece is None:
                        piece = number
                    elif piece == 0:
                        return False
                    else:
                        piece = piece * 10 + number
                    if piece > 255:
                        return False
                    at += 1
                pieces[index] = pieces[index] * 256 + piece
                seen += 1
                if seen in (2, 4):
                    index += 1
            if seen != 4:
                return False
            break
        if char(at) == ':':
            at += 1
            if char(at) is None:
                return False
        elif char(at) is not None:
            return False
        pieces[index] = value
        index += 1
    if compress is None and index != 8:
        return False
    return True


def is_https_link(value, *, max_units=MAX_LINK_UNITS):
    """The LCP https-link rule (``isHttpsLink``), plus a length bound.

    The string holds no whitespace, control character or backslash; it parses as
    an absolute WHATWG URL with scheme https in either case; its authority has a
    host, a DNS name of RFC 1123 labels or an IP literal, and no userinfo.
    ``max_units`` bounds untrusted input in UTF-16 code units; ``None`` applies
    the bare rule.
    """
    if type(value) is not str or not _well_formed(value):
        return False
    if max_units is not None and _units(value) > max_units:
        return False
    if LINK_FORBIDDEN.search(value):
        return False
    found = HTTPS_AUTHORITY.match(value)
    if found is None:
        return False
    authority = found.group(1)
    if len(authority) > MAX_AUTHORITY or '@' in authority:
        return False
    host_port = HOST_PORT.match(authority)
    if host_port is None:
        return False
    port = host_port.group(1)
    host = authority if port is None else authority[:len(authority) - len(port) - 1]
    if not host.startswith('[') and len(host[:-1] if host.endswith('.') else host) > MAX_DNS_NAME:
        return False
    if port and int(port) > 65535:
        return False
    if host.startswith('['):
        return _ipv6(host[1:-1])
    lowered = host.lower()
    if _ends_in_number(lowered):
        return _ipv4(lowered)
    return True
