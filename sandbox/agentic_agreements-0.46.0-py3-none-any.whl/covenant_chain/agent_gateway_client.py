"""Calling side of the verified agent gateway: read the card, sign, send.

An agent that calls another company's gateway signs each A2A SendMessage with
its own key. The signed request travels in message.metadata under
covenant-agent-gateway-request/0.1. The payload it signs is the params without
that entry (see split_params). A refusal comes back as a JSON-RPC error whose
data names the decision and every refusal code.

Reading a card checks the trust mark's signature only. It does not replay the
operator's log; an auditor does that with the export. HTTPS is required except
for literal loopback when the caller allows it. No proxy, no redirect.
"""
from copy import deepcopy
import secrets
import time
import urllib.error
import urllib.request

from . import crypto as c
from .agent_gateway import (EXTENSION_URI, IDENTITY_VERSION, REQUEST_VERSION, sign_request,
                            verify_trust_mark)

DECISION_HEADER = "Covenant-Gateway-Decision"


def split_params(params):
    """Return (request, identity, payload). The payload is what the caller signs."""
    c.need(type(params) is dict and type(params.get("message")) is dict, "GATEWAY_HOST_PARAMS")
    payload = deepcopy(params)
    message = payload["message"]
    request = identity = None
    if "metadata" in message:
        c.need(type(message["metadata"]) is dict, "GATEWAY_HOST_PARAMS")
        request = message["metadata"].pop(REQUEST_VERSION, None)
        identity = message["metadata"].pop(IDENTITY_VERSION, None)
        if not message["metadata"]:
            del message["metadata"]
    return request, identity, payload


def check_url(url, allow_insecure_loopback=False):
    from .a2a_connector import _endpoint
    try:
        _endpoint(url, allow_insecure_loopback)
    except ValueError as exc:
        raise ValueError("GATEWAY_HOST_URL") from exc
    return url


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)


def exchange(url, value=None, *, headers=None, timeout=10.0, max_bytes=1048576):
    """One bounded GET (value None) or POST. Returns (status, lower-cased headers, body)."""
    headers = dict(headers or {})
    data = None
    if value is not None:
        data = c.canonical(value)
        headers.update({"Content-Type": "application/json", "A2A-Version": "1.0"})
    headers["Accept"] = "application/json"
    request = urllib.request.Request(url, data=data, method="GET" if data is None else "POST",
                                     headers=headers)
    try:
        response = _OPENER.open(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        body = response.read(max_bytes + 1)
        c.need(len(body) <= max_bytes, "GATEWAY_HOST_RESPONSE_LIMIT")
        return response.status, {k.lower(): v for k, v in response.headers.items()}, body


def gateway_of(card, *, expected_log_signer=None):
    """Find the gateway extension on an A2A card and check its trust mark."""
    c.need(type(card) is dict and type(card.get("capabilities")) is dict, "GATEWAY_CARD")
    found = [ext for ext in card["capabilities"].get("extensions") or []
             if type(ext) is dict and ext.get("uri") == EXTENSION_URI]
    c.need(len(found) == 1 and type(found[0].get("params")) is dict, "GATEWAY_CARD")
    params = found[0]["params"]
    c.need(params.get("requestVersion") == REQUEST_VERSION, "GATEWAY_CARD")
    summary = verify_trust_mark(params.get("trustMark"),
                                expected_log_signer=expected_log_signer or params.get("logSigner"))
    mark = params["trustMark"]["body"]
    c.need(params.get("service") == summary["service"] and
           params.get("policyHash") == mark["policy_hash"] and
           params.get("logSigner") == mark["log_signer"], "GATEWAY_CARD")
    urls = [entry.get("url") for entry in card.get("supportedInterfaces") or []
            if type(entry) is dict and entry.get("protocolBinding") == "JSONRPC"]
    return {"service": summary["service"], "company": summary["company"],
            "log_signer": mark["log_signer"], "policy_hash": mark["policy_hash"],
            "rules": deepcopy(mark["policy"]["inbound"]), "urls": urls, "mark": summary}


def fetch_card(card_url, *, expected_log_signer=None, allow_insecure_loopback=False, timeout=10.0):
    check_url(card_url, allow_insecure_loopback)
    status, headers, raw = exchange(card_url, timeout=timeout)
    c.need(status == 200, "GATEWAY_CARD_HTTP")
    return gateway_of(c.loads(raw), expected_log_signer=expected_log_signer)


def attach_request(private_key, params, *, service, operation, nonce=None, issued_at=None,
                   identity=None):
    """Sign params for one call and put the request (and identity) in message.metadata."""
    _, _, payload = split_params(params)
    envelope = sign_request(private_key, service=service, operation=operation, payload=payload,
                            nonce=secrets.token_hex(32) if nonce is None else nonce,
                            issued_at=int(time.time()) if issued_at is None else issued_at)
    signed = deepcopy(payload)
    metadata = signed["message"].setdefault("metadata", {})
    metadata[REQUEST_VERSION] = envelope
    if identity is not None:
        metadata[IDENTITY_VERSION] = deepcopy(identity)
    return signed


def send(url, params, *, request_id=None, agreement=False, headers=None, timeout=10.0,
         allow_insecure_loopback=False, max_bytes=1048576):
    """POST one SendMessage. Returns the HTTP status, the decision id and the JSON-RPC reply."""
    check_url(url, allow_insecure_loopback)
    request_id = secrets.token_hex(16) if request_id is None else request_id
    active = EXTENSION_URI
    if agreement:
        from .a2a_agreement_gate import EXTENSION_URI as GATE
        active += ", " + GATE
    status, received, raw = exchange(
        url, {"jsonrpc": "2.0", "id": request_id, "method": "SendMessage", "params": params},
        headers={**(headers or {}), "A2A-Extensions": active}, timeout=timeout, max_bytes=max_bytes)
    reply = c.loads(raw)
    if type(reply) is dict and "jsonrpc" in reply:
        c.need(reply.get("id") in (request_id, None), "GATEWAY_RESPONSE_CORRELATION")
    return {"http_status": status, "decision": received.get(DECISION_HEADER.lower()),
            "reply": reply}


def call(url, private_key, params, *, service, operation, identity=None, agreement=False,
         nonce=None, issued_at=None, **options):
    """attach_request then send."""
    signed = attach_request(private_key, params, service=service, operation=operation,
                            nonce=nonce, issued_at=issued_at, identity=identity)
    return send(url, signed, agreement=agreement, **options)
