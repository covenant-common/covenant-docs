"""Fill-once, holder-controlled application dossier with staged, consented release.

The holder (a business or its agent) fills each field once. A field is either
SELF_DECLARED, signed by the holder at release, or ISSUER_ATTESTED: an SD-JWT
VC (RFC 9901 sections 4.2.1, 4.3 and 7.3; draft-ietf-oauth-sd-jwt-vc-22 typ
``dc+sd-jwt`` and ``vct``) issued to the holder's key, so one release discloses
only the claims its stage allows. The JWS and disclosure primitives are the
pinned ones in hidden_credentials; this module adds a dossier credential type.

Every release names one recipient, one request digest and one disclosure stage
and carries the holder's signed consent receipt: who receives it, which fields,
the purpose, the retention limit and the expiry. A revocation is a signed record.
It stops later releases and tells the recipient to delete; it cannot erase a
copy already delivered. Nothing here sends anything over a network, and nothing
here signs, pays or grants authority to anyone.
"""
from copy import deepcopy
from functools import wraps
import hashlib
import os
import re

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify
from .hidden_credentials import (KB_MAX_AGE, KB_TYP, SD_ALG, TYP, _b64, _disclosure_digest, _jwk, _jwk_public,
                                 _json, _jws, _open_jws, _unb64, _wire)

VERSION = 'urn:aap:exchange-dossier:0.1'
VCT = 'urn:aap:vct:business-dossier:0.1'
CONSENT_LABEL = 'AAP-EXCHANGE-CONSENT-0.1'
REVOKE_LABEL = 'AAP-EXCHANGE-CONSENT-REVOKED-0.1'
RELEASE_LABEL = 'AAP-EXCHANGE-RELEASE-0.1'
NONCE_LABEL = 'AAP-EXCHANGE-RELEASE-NONCE-0.1'
STAGES = ('PUBLIC_TEASER', 'ELIGIBLE', 'SHORTLIST', 'AWARD')
SOURCES = ('SELF_DECLARED', 'ISSUER_ATTESTED')
PURPOSES = ('CREDIT_DECISION', 'UNDERWRITING', 'CLOSING', 'WORK_QUOTE', 'WORK_DELIVERY')
CREDIT_FIELDS = ('business_identity', 'kyb_attestation', 'financial_statements', 'bank_cash_flow',
                 'ownership', 'use_of_funds', 'collateral')
NAME = re.compile(r'[a-z][a-z0-9_]{0,63}\Z')
MAX_FIELDS = 32
MAX_FIELD_BYTES = 8192
MAX_PRESENTATION = 65536
MAX_LIFETIME = 90 * 86400
MAX_RETENTION = 3 * 366 * 86400
SLOTS = 40
FLAGS = {'network': False, 'execution_authorized': False, 'authority_granted': False}
PROVES = ['the pinned issuer signed each disclosed attested claim for the holder key',
          'the presenter holds that key now (KB-JWT over the release nonce and recipient audience)',
          'the holder signed the self-declared values and the consent receipt for this recipient and stage']
DOES_NOT_PROVE = ['that a self-declared value is true', 'that an issuer checked its evidence honestly',
                  'that a recipient deletes data when consent ends; deletion is a promise, not a mechanism',
                  'any authority to sign, lend, pay or bind']


def _coded(code):
    """Public verifiers fail closed: a malformed untrusted shape becomes a refusal code, never a traceback."""
    def wrap(function):
        @wraps(function)
        def checked(*args, **kwargs):
            try:
                return function(*args, **kwargs)
            except (TypeError, KeyError, AttributeError, IndexError):
                raise ValueError(code) from None
        return checked
    return wrap


def _name(value):
    need(type(value) is str and NAME.fullmatch(value) is not None, 'DOSSIER_FIELD')
    return value


def _names(value, minimum=0):
    need(type(value) is list and minimum <= len(value) <= MAX_FIELDS, 'DOSSIER_FIELD')
    for item in value:
        _name(item)
    need(value == sorted(set(value)), 'DOSSIER_FIELD')
    return value


def _value(value):
    need(len(canonical(value)) <= MAX_FIELD_BYTES, 'DOSSIER_FIELD')
    return value


@_coded('DOSSIER_PLAN')
def validate_plan(plan):
    """Four cumulative stages; each later stage keeps every earlier field."""
    need(type(plan) is dict and set(plan) == set(STAGES), 'DOSSIER_PLAN')
    previous = []
    for stage in STAGES:
        names = _names(plan[stage])
        need(set(previous) <= set(names), 'DOSSIER_PLAN')
        previous = names
    return plan


def stage_fields(plan, stage):
    validate_plan(plan)
    need(stage in STAGES, 'DOSSIER_STAGE')
    return list(plan[stage])


def release_nonce(request, recipient, stage):
    """KB-JWT nonce that binds an attested presentation to one request, recipient and stage."""
    key(request)
    verification_key(recipient)
    need(stage in STAGES, 'DOSSIER_STAGE')
    return digest(NONCE_LABEL, {'request': request, 'recipient': recipient, 'stage': stage})


def audience(recipient):
    verification_key(recipient)
    return 'urn:aap:exchange-recipient:' + recipient


# --- issuer side: one SD-JWT VC per attested field set ------------------------

def attest(issuer_id, issuer_key, holder, claims, *, now, lifetime=7 * 86400):
    """Issuer signs salted digests of named claims for one holder key. No claim is disclosed here."""
    need(type(issuer_id) is str and 0 < len(issuer_id) <= 256 and issuer_id.isascii() and issuer_id.isprintable(),
         'DOSSIER_ISSUER')
    need(isinstance(issuer_key, Ed25519PrivateKey), 'DOSSIER_ISSUER')
    verification_key(holder)
    integer(now)
    integer(lifetime, True)
    need(lifetime <= MAX_LIFETIME, 'DOSSIER_ISSUER')
    need(type(claims) is dict and 1 <= len(claims) <= MAX_FIELDS, 'DOSSIER_FIELD')
    disclosures = []
    for name in sorted(claims):
        _name(name)
        _value(claims[name])
        disclosures.append(_b64(_wire([_b64(os.urandom(16)), name, deepcopy(claims[name])])))
    digests = [_disclosure_digest(item) for item in disclosures]
    # Decoys (RFC 9901 section 4.2.5) hide how many fields this credential carries.
    digests += [_b64(hashlib.sha256(os.urandom(32)).digest()) for _ in range(SLOTS - len(digests))]
    payload = {'iss': issuer_id, 'iat': now, 'exp': now + lifetime, 'vct': VCT, 'cnf': {'jwk': _jwk(holder)},
               '_sd': sorted(digests), '_sd_alg': SD_ALG}
    token = _jws(issuer_key, {'alg': 'EdDSA', 'typ': TYP}, payload)
    return {'version': VERSION, 'issuer': issuer_id, 'issuer_key': public_key(issuer_key), 'holder_key': holder,
            'claims': sorted(claims), 'sd_jwt': token, 'disclosures': disclosures, 'expires': now + lifetime, **FLAGS}


@_coded('DOSSIER_CREDENTIAL')
def present(credential, holder_private, names, *, audience, nonce, now):
    """Holder discloses exactly ``names`` from one credential, bound to the verifier nonce and audience."""
    need(type(credential) is dict and {'holder_key', 'sd_jwt', 'disclosures'} <= set(credential), 'DOSSIER_CREDENTIAL')
    need(public_key(holder_private) == credential['holder_key'], 'DOSSIER_CREDENTIAL')
    _names(names, 1)
    need(type(audience) is str and 0 < len(audience) <= 256 and audience.isascii(), 'DOSSIER_CREDENTIAL')
    key(nonce)
    integer(now)
    chosen = []
    for item in credential['disclosures']:
        row = _json(_unb64(item, MAX_PRESENTATION))
        need(type(row) is list and len(row) == 3, 'DOSSIER_CREDENTIAL')
        if row[1] in names:
            chosen.append(item)
    need(len(chosen) == len(names), 'DOSSIER_CREDENTIAL')
    issued = credential['sd_jwt'] + '~' + ''.join(item + '~' for item in chosen)
    sd_hash = _b64(hashlib.sha256(issued.encode('ascii')).digest())
    kb = _jws(holder_private, {'alg': 'EdDSA', 'typ': KB_TYP}, {'iat': now, 'aud': audience, 'nonce': nonce, 'sd_hash': sd_hash})
    presentation = issued + kb
    need(len(presentation) <= MAX_PRESENTATION, 'DOSSIER_CREDENTIAL')
    return presentation


@_coded('DOSSIER_ATTESTATION')
def verify_attested(presentation, issuers, *, audience, nonce, now, clock_skew=30):
    """Verifier check (RFC 9901 section 7.3): pinned issuer, digests, key binding, freshness."""
    need(type(issuers) is dict and 1 <= len(issuers) <= 16, 'DOSSIER_ISSUER')
    for name, value in issuers.items():
        need(type(name) is str and 0 < len(name) <= 256 and name.isascii(), 'DOSSIER_ISSUER')
        verification_key(value)
    integer(now)
    integer(clock_skew)
    need(clock_skew <= 120, 'DOSSIER_ISSUER')
    key(nonce)
    need(type(presentation) is str and 0 < len(presentation) <= MAX_PRESENTATION and presentation.isascii(),
         'DOSSIER_ATTESTATION')
    parts = presentation.split('~')
    need(len(parts) >= 3 and parts[-1] != '' and all(parts[:-1]), 'DOSSIER_ATTESTATION')
    issuer_jwt, disclosures, kb_jwt = parts[0], parts[1:-1], parts[-1]
    try:
        unverified = _json(_unb64(issuer_jwt.split('.')[1], MAX_PRESENTATION))
        need(type(unverified) is dict and unverified.get('iss') in issuers, 'DOSSIER_ISSUER_NOT_PINNED')
        payload = _open_jws(issuer_jwt, issuers[unverified['iss']], TYP)
        need(set(payload) == {'iss', 'iat', 'exp', 'vct', 'cnf', '_sd', '_sd_alg'} and payload['vct'] == VCT
             and payload['_sd_alg'] == SD_ALG, 'DOSSIER_ATTESTATION')
        for field in ('iat', 'exp'):
            integer(payload[field])
        need(payload['iat'] <= now + clock_skew and now < payload['exp'] + clock_skew, 'DOSSIER_ATTESTATION')
        need(0 < payload['exp'] - payload['iat'] <= MAX_LIFETIME, 'DOSSIER_ISSUER')
        need(type(payload['cnf']) is dict and set(payload['cnf']) == {'jwk'}, 'DOSSIER_ATTESTATION')
        holder = _jwk_public(payload['cnf']['jwk'])
        sd = payload['_sd']
        need(type(sd) is list and len(sd) == SLOTS and len(set(sd)) == SLOTS and all(type(v) is str for v in sd),
             'DOSSIER_ATTESTATION')
        issued = issuer_jwt + '~' + ''.join(item + '~' for item in disclosures)
        kb = _open_jws(kb_jwt, holder, KB_TYP)
        need(set(kb) == {'iat', 'aud', 'nonce', 'sd_hash'} and kb['aud'] == audience and kb['nonce'] == nonce,
             'DOSSIER_KEY_BINDING')
        integer(kb['iat'])
        need(now - KB_MAX_AGE - clock_skew <= kb['iat'] <= now + clock_skew, 'DOSSIER_KEY_BINDING')
        need(kb['sd_hash'] == _b64(hashlib.sha256(issued.encode('ascii')).digest()), 'DOSSIER_KEY_BINDING')
        claims = {}
        for item in disclosures:
            hashed = _disclosure_digest(item)
            need(hashed in sd, 'DOSSIER_ATTESTATION')
            row = _json(_unb64(item, MAX_PRESENTATION))
            need(type(row) is list and len(row) == 3 and type(row[0]) is str and len(row[0]) >= 22, 'DOSSIER_ATTESTATION')
            _name(row[1])
            need(row[1] not in claims, 'DOSSIER_ATTESTATION')
            claims[row[1]] = _value(row[2])
    except ValueError as exc:
        code = str(exc)
        raise ValueError(code if code.startswith('DOSSIER_') else 'DOSSIER_ATTESTATION') from None
    need(bool(claims), 'DOSSIER_ATTESTATION')
    return {'version': VERSION, 'issuer': payload['iss'], 'holder': holder, 'claims': claims,
            'issued_at': payload['iat'], 'expires': payload['exp'], 'proves': list(PROVES),
            'does_not_prove': list(DOES_NOT_PROVE), **FLAGS}


# --- consent, revocation and release ------------------------------------------

def _consent_body(body):
    exact(body, 'version kind holder recipient request stage fields purpose retention_until expires created_at nonce')
    need(body['version'] == VERSION and body['kind'] == 'CONSENT', 'DOSSIER_CONSENT')
    verification_key(body['holder'])
    verification_key(body['recipient'])
    need(body['holder'] != body['recipient'], 'DOSSIER_CONSENT')
    key(body['request'])
    key(body['nonce'])
    need(body['stage'] in STAGES and body['purpose'] in PURPOSES, 'DOSSIER_CONSENT')
    _names(body['fields'], 1)
    for field in ('retention_until', 'expires', 'created_at'):
        integer(body[field])
    need(body['created_at'] < body['expires'] <= body['retention_until'] <= body['created_at'] + MAX_RETENTION,
         'DOSSIER_CONSENT')
    return body


def consent_id(body):
    _consent_body(body)
    return digest(CONSENT_LABEL, body)


def consent(holder, recipient, request, stage, fields, purpose, *, retention_until, expires, created_at, nonce):
    """The exact consent receipt the holder signs: who, which fields, purpose, retention and expiry."""
    body = {'version': VERSION, 'kind': 'CONSENT', 'holder': holder, 'recipient': recipient, 'request': request,
            'stage': stage, 'fields': list(fields), 'purpose': purpose, 'retention_until': retention_until,
            'expires': expires, 'created_at': created_at, 'nonce': nonce}
    return {'label': CONSENT_LABEL, 'body': body, 'id': consent_id(body), 'signature_created': False, **FLAGS}


@_coded('DOSSIER_CONSENT')
def verify_consent(record):
    exact(record, 'body signature')
    body = _consent_body(record['body'])
    try:
        verify(body['holder'], CONSENT_LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('DOSSIER_CONSENT_SIGNATURE') from None
    return body, digest(CONSENT_LABEL, body)


def revocation(holder, consent_ref, created_at):
    body = {'version': VERSION, 'kind': 'CONSENT_REVOKED', 'holder': holder, 'consent': consent_ref,
            'created_at': created_at}
    _revocation_body(body)
    return {'label': REVOKE_LABEL, 'body': body, 'signature_created': False, **FLAGS}


def _revocation_body(body):
    exact(body, 'version kind holder consent created_at')
    need(body['version'] == VERSION and body['kind'] == 'CONSENT_REVOKED', 'DOSSIER_REVOCATION')
    verification_key(body['holder'])
    key(body['consent'])
    integer(body['created_at'])
    return body


@_coded('DOSSIER_REVOCATION')
def verify_revocation(record):
    exact(record, 'body signature')
    body = _revocation_body(record['body'])
    try:
        verify(body['holder'], REVOKE_LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('DOSSIER_REVOCATION') from None
    return body


def _release_body(body):
    exact(body, 'version kind holder recipient request stage consent fields self_declared created_at')
    need(body['version'] == VERSION and body['kind'] == 'RELEASE' and body['stage'] in STAGES, 'DOSSIER_RELEASE')
    verification_key(body['holder'])
    verification_key(body['recipient'])
    key(body['request'])
    key(body['consent'])
    integer(body['created_at'])
    _names(body['fields'], 1)
    need(type(body['self_declared']) is dict and set(body['self_declared']) <= set(body['fields']), 'DOSSIER_RELEASE')
    for name, value in body['self_declared'].items():
        _name(name)
        _value(value)
    return body


class Dossier:
    """Holder-side packet. Filled once; released per recipient and stage. Holds no network handle."""

    def __init__(self, holder_private):
        need(isinstance(holder_private, Ed25519PrivateKey), 'DOSSIER_CREDENTIAL')
        self._key = holder_private
        self.holder = public_key(holder_private)
        self.fields = {}
        self.credentials = []

    def __repr__(self):
        return f'Dossier(holder={self.holder!r}, fields={sorted(self.fields)!r})'

    def fill(self, name, value):
        _name(name)
        need(name not in self.fields, 'DOSSIER_FIELD_FILLED')
        need(len(self.fields) < MAX_FIELDS, 'DOSSIER_FIELD')
        self.fields[name] = {'source': 'SELF_DECLARED', 'value': deepcopy(_value(value))}
        return self.describe()

    def attach(self, credential):
        """Adopt an issuer credential; its claims become ISSUER_ATTESTED fields. The issuer is checked by recipients."""
        need(type(credential) is dict and credential.get('holder_key') == self.holder, 'DOSSIER_CREDENTIAL')
        names = _names(credential['claims'], 1)
        need(not set(names) & set(self.fields), 'DOSSIER_FIELD_FILLED')
        need(len(self.fields) + len(names) <= MAX_FIELDS, 'DOSSIER_FIELD')
        index = len(self.credentials)
        self.credentials.append(deepcopy(credential))
        for name in names:
            self.fields[name] = {'source': 'ISSUER_ATTESTED', 'credential': index, 'issuer': credential['issuer']}
        return self.describe()

    def describe(self):
        """Names and sources only; values stay with the holder until a consented release."""
        return {'version': VERSION, 'holder': self.holder,
                'fields': {name: row['source'] for name, row in sorted(self.fields.items())}, **FLAGS}

    def release(self, recipient, request, stage, names, purpose, *, plan, retention_until, expires, now, nonce):
        """Consent receipt plus the minimum release for one recipient and stage. Nothing is transmitted."""
        allowed = stage_fields(plan, stage)
        _names(names, 1)
        need(set(names) <= set(allowed), 'DOSSIER_BEYOND_CONSENT')
        need(set(names) <= set(self.fields), 'DOSSIER_FIELD_MISSING')
        prepared = consent(self.holder, recipient, request, stage, names, purpose,
                           retention_until=retention_until, expires=expires, created_at=now, nonce=nonce)
        signed_consent = {'body': prepared['body'], 'signature': sign(self._key, CONSENT_LABEL, prepared['body'])}
        own = {name: deepcopy(self.fields[name]['value']) for name in names if self.fields[name]['source'] == 'SELF_DECLARED'}
        body = {'version': VERSION, 'kind': 'RELEASE', 'holder': self.holder, 'recipient': recipient, 'request': request,
                'stage': stage, 'consent': prepared['id'], 'fields': list(names), 'self_declared': own, 'created_at': now}
        _release_body(body)
        bound = release_nonce(request, recipient, stage)
        attested = []
        for index, credential in enumerate(self.credentials):
            chosen = [name for name in names if self.fields[name].get('credential') == index]
            if chosen:
                attested.append(present(credential, self._key, chosen, audience=audience(recipient), nonce=bound, now=now))
        record = {'body': body, 'signature': sign(self._key, RELEASE_LABEL, body), 'attested': attested}
        return {'consent': signed_consent, 'release': record, 'transmitted': False, **FLAGS}

    def revoke(self, consent_record, now):
        body, ref = verify_consent(consent_record)
        need(body['holder'] == self.holder, 'DOSSIER_CONSENT')
        prepared = revocation(self.holder, ref, now)
        return {'body': prepared['body'], 'signature': sign(self._key, REVOKE_LABEL, prepared['body'])}


@_coded('DOSSIER_RELEASE')
def verify_release(release, consent_record, *, plan, issuers, now, revocations=()):
    """Recipient-side check: holder signatures, consent scope, stage plan, issuer pins and freshness."""
    exact(release, 'body signature attested')
    body = _release_body(release['body'])
    try:
        verify(body['holder'], RELEASE_LABEL, body, release['signature'])
    except ValueError:
        raise ValueError('DOSSIER_RELEASE') from None
    terms, ref = verify_consent(consent_record)
    need(ref == body['consent'] and terms['holder'] == body['holder'] and terms['recipient'] == body['recipient']
         and terms['request'] == body['request'] and terms['stage'] == body['stage'], 'DOSSIER_RELEASE')
    integer(now)
    need(terms['created_at'] <= now < terms['expires'], 'DOSSIER_CONSENT_EXPIRED')
    need(type(revocations) in (list, tuple) and len(revocations) <= 256, 'DOSSIER_REVOCATION')
    for record in revocations:
        revoked = verify_revocation(record)
        need(not (revoked['consent'] == ref and revoked['holder'] == body['holder'] and revoked['created_at'] <= now),
             'DOSSIER_CONSENT_REVOKED')
    allowed = stage_fields(plan, body['stage'])
    need(set(body['fields']) <= set(terms['fields']) and set(body['fields']) <= set(allowed), 'DOSSIER_BEYOND_CONSENT')
    need(type(release['attested']) is list and len(release['attested']) <= 8, 'DOSSIER_RELEASE')
    values = {name: {'source': 'SELF_DECLARED', 'value': deepcopy(value)} for name, value in body['self_declared'].items()}
    bound = release_nonce(body['request'], body['recipient'], body['stage'])
    for presentation in release['attested']:
        checked = verify_attested(presentation, issuers, audience=audience(body['recipient']), nonce=bound, now=body['created_at'])
        need(checked['holder'] == body['holder'], 'DOSSIER_RELEASE')
        for name, value in checked['claims'].items():
            need(name in body['fields'], 'DOSSIER_BEYOND_CONSENT')
            need(name not in values, 'DOSSIER_ATTESTATION')
            values[name] = {'source': 'ISSUER_ATTESTED', 'issuer': checked['issuer'], 'value': value}
    need(set(values) == set(body['fields']), 'DOSSIER_RELEASE')
    return {'version': VERSION, 'consent': ref, 'stage': body['stage'], 'recipient': body['recipient'],
            'fields': values, 'purpose': terms['purpose'], 'retention_until': terms['retention_until'],
            'delete_after': terms['retention_until'], 'retention': 'RECIPIENT_PROMISE_NOT_ENFORCED_BY_CODE',
            'proves': list(PROVES), 'does_not_prove': list(DOES_NOT_PROVE), **FLAGS}


def describe():
    return {'version': VERSION, 'vct': VCT, 'typ': TYP, 'stages': list(STAGES), 'sources': list(SOURCES),
            'purposes': list(PURPOSES), 'credit_fields': list(CREDIT_FIELDS),
            'format': 'SD-JWT VC with Key Binding JWT (RFC 9901; draft-ietf-oauth-sd-jwt-vc-22)',
            'limits': {'fields': MAX_FIELDS, 'field_bytes': MAX_FIELD_BYTES, 'presentation': MAX_PRESENTATION,
                       'credential_lifetime': MAX_LIFETIME, 'retention': MAX_RETENTION},
            'proves': list(PROVES), 'does_not_prove': list(DOES_NOT_PROVE), **FLAGS}
