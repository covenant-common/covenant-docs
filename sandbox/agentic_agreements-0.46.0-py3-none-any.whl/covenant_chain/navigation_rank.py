"""Owner-adopted, contextual route PageRank beside the structural taxonomy.

Signed outcome/use traces are explicit input. No telemetry, marketing tracking,
signing keys or automatic publication. Recommendations cannot change agreement
semantics, installed capabilities, authority, payment or the four entry tools.
"""
from copy import deepcopy
import hashlib
import json
import threading
from functools import wraps

from . import aap_levels, feature_use_rank, onboarding
from .crypto import digest, integer, need, verification_key, verify
from .workflow_store import WorkflowStore

PROFILE = 'covenant-navigation-rank/0.1'
LABEL = 'COVENANT-NAVIGATION-ADOPTION-0.1'


def _serialized(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return guarded


def _pin(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=True, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode('ascii')).hexdigest()


def route_feature(route):
    return 'extension:route:' + route


def _catalog():
    catalog = onboarding.task_catalog()
    return {r['id']: r for r in catalog['routes']}, _pin(catalog)


def describe():
    return {'profile': PROFILE, 'structural_taxonomy': aap_levels.PROFILE,
            'ranking': 'CONTEXTUAL_INTEGER_PAGERANK_FROM_EXPLICIT_DUAL_SIGNED_OUTCOME_USE_TRACES',
            'owner_adoption': 'SIGNED_EXACT_CATALOG_TAXONOMY_CONTEXT_SNAPSHOT',
            'trace_features': 'extension:route:<maintained-task-id> plus the actual tools used',
            'privacy': 'LOCAL_PRIVATE_PLAINTEXT; NO_TELEMETRY_OR_AUTOMATIC_PUBLICATION',
            'routing': 'ADVISORY_BY_DEFAULT; OWNER_CAN_RERANK_LEXICALLY_ELIGIBLE_MATCHES',
            'execution_authorized': False, 'signed_meaning_changed': False}


def rank_routes(records, *, owner, context, contacts, now, max_age, per_cluster_cap=4, edges=None):
    routes, catalog_pin = _catalog()
    # Unrelated installed extensions must not exhaust a bounded query. Include
    # only the maintained routes and actually referenced, verified features.
    installed = feature_use_rank.default_registry()
    features = {route_feature(name): {'level': 'ORGANON', 'core': False} for name in routes}
    feature_use_rank.rank([], features, owner=owner, context=context, contacts=contacts,
                          now=now, max_age=max_age, per_cluster_cap=per_cluster_cap)
    need(type(records) is list and len(records) <= feature_use_rank.MAX_RECORDS, 'USE_RECORDS')
    feature_use_rank.portable_trust._bounded(records, feature_use_rank.MAX_BYTES)
    needed = set()
    for record in records:
        try:
            outcome, trace, _ = feature_use_rank._trace(record)
            if (outcome['context'] != context or owner not in outcome['parties'] or
                    not outcome['issued_at'] <= now or now - outcome['issued_at'] > max_age):
                continue
            peer = next(k for k in outcome['parties'] if k != owner)
            if peer not in contacts or contacts[peer] == 'owner':
                continue
            needed.update(node for node in trace['features'] if node in installed)
        except (ValueError, KeyError, TypeError, StopIteration):
            continue
    need(len(features) + len(needed) <= feature_use_rank.MAX_FEATURES, 'NAVIGATION_QUERY_CAPACITY_SCOPE_EVIDENCE')
    features.update({node: installed[node] for node in sorted(needed)})
    edges = [] if edges is None else edges
    need(type(edges) is list and len(edges) <= 4096, 'NAVIGATION_EDGES')
    dependencies = []
    for edge in edges:
        need(type(edge) is list and len(edge) == 2 and all(type(v) is str and v in routes for v in edge),
             'NAVIGATION_EDGE_ROUTE')
        dependencies.append([route_feature(v) for v in edge])
    ranked = feature_use_rank.rank(records, features, owner=owner, context=context, contacts=contacts,
        now=now, max_age=max_age, per_cluster_cap=per_cluster_cap, dependencies=dependencies)
    by_id = {r['feature']: r for r in ranked['levels']['ORGANON']}
    rows = [{'route': name, 'tool': routes[name]['native_tool'], 'action': routes[name]['action'],
             'structural_level': aap_levels.tool_level(routes[name]['native_tool']),
             'rank_ppb': by_id[route_feature(name)]['rank_ppb'],
             'supported_agreements': by_id[route_feature(name)]['supported_agreements']}
            for name in routes]
    rows.sort(key=lambda r: (-r['rank_ppb'], r['route']))
    return {'profile': PROFILE, 'context': context, 'owner': owner, 'created_at': now,
            'catalog_sha256': catalog_pin, 'taxonomy_sha256': aap_levels.summary()['registry_sha256'],
            'routes': rows, 'accepted_agreements': ranked['accepted_agreements'],
            'rejected': ranked['rejected'], 'assurance': ranked['assurance'],
            'private': True, 'telemetry': False, 'features_removed': False, 'authority_changed': False,
            'execution_authorized': False, 'marketing_publication_authorized': False}


class RouteAdvisor:
    """One owner/context per private journal; model arguments cannot adopt ranks."""
    def __init__(self, directory, *, owner, context, contacts, clock, max_age=86400,
                 lifetime=3600, mode='ADVISORY', per_cluster_cap=4, expected_head=None):
        verification_key(owner)
        need(type(owner) is str, 'NAVIGATION_OWNER_KEY')
        feature_use_rank._text(context, 'NAVIGATION_CONTEXT')
        need(callable(clock) and mode in ('ADVISORY', 'RERANK_MATCHES'), 'NAVIGATION_OWNER_CONFIG')
        integer(max_age, True); integer(lifetime, True)
        need(lifetime <= max_age and type(contacts) is dict, 'NAVIGATION_OWNER_CONFIG')
        # Run admission even for empty evidence; clusters never come from a model.
        rank_routes([], owner=owner, context=context, contacts=contacts, now=clock(), max_age=max_age,
                    per_cluster_cap=per_cluster_cap)
        self._lock = threading.RLock()
        self.owner = owner; self.context = context; self.contacts = deepcopy(contacts); self.clock = clock
        self.max_age = max_age; self.lifetime = lifetime; self.mode = mode; self.cap = per_cluster_cap
        self.config = _pin(self._configuration())
        self.store = WorkflowStore(directory, self.config, check_same_thread=False)
        if expected_head is not None:
            if self._head() != expected_head:
                self.store.close()
                raise ValueError('NAVIGATION_JOURNAL_HEAD_CHANGED')

    def _configuration(self):
        return {'owner': self.owner, 'context': self.context, 'contacts': self.contacts,
                'max_age': self.max_age, 'lifetime': self.lifetime, 'mode': self.mode, 'cap': self.cap}

    def _unchanged(self):
        need(_pin(self._configuration()) == self.config, 'NAVIGATION_OWNER_CONFIGURATION_CHANGED')

    def _head(self):
        rows = self.store.events()
        return rows[-1]['id'] if rows else '0' * 64

    @_serialized
    def prepare(self, records, *, edges=None):
        self._unchanged()
        now = self.clock(); integer(now)
        ranked = rank_routes(records, owner=self.owner, context=self.context, contacts=self.contacts,
                             now=now, max_age=self.max_age, per_cluster_cap=self.cap, edges=edges)
        body = {'profile': PROFILE, 'configuration': self.config, 'previous_head': self._head(),
                'expires': now + self.lifetime, 'ranking': ranked}
        return {'body': body, 'label': LABEL, 'id': digest(LABEL, body),
                'owner_signature_required': True, 'adopted': False, 'execution_authorized': False}

    def _validate(self, body):
        feature_use_rank.portable_trust._bounded(body, 2097152)
        need(type(body) is dict and set(body) == {'profile', 'configuration', 'previous_head', 'expires', 'ranking'}
             and body['profile'] == PROFILE and body['configuration'] == self.config, 'NAVIGATION_ADOPTION_FIELDS')
        ranked = body['ranking']; routes, catalog_pin = _catalog()
        need(type(ranked) is dict and set(ranked) == {'profile', 'context', 'owner', 'created_at',
             'catalog_sha256', 'taxonomy_sha256', 'routes', 'accepted_agreements', 'rejected', 'assurance',
             'private', 'telemetry', 'features_removed', 'authority_changed', 'execution_authorized',
             'marketing_publication_authorized'}, 'NAVIGATION_RANKING_FIELDS')
        need(type(ranked) is dict and ranked.get('profile') == PROFILE and ranked.get('owner') == self.owner and
             ranked.get('context') == self.context and ranked.get('catalog_sha256') == catalog_pin and
             ranked.get('taxonomy_sha256') == aap_levels.summary()['registry_sha256'], 'NAVIGATION_SNAPSHOT_CHANGED')
        integer(ranked['created_at']); integer(body['expires'])
        need(body['expires'] == ranked['created_at'] + self.lifetime, 'NAVIGATION_LIFETIME')
        rows = ranked['routes']
        need(type(rows) is list and len(rows) == len(routes), 'NAVIGATION_ROUTE_SET')
        names = []
        for row in rows:
            need(type(row) is dict and set(row) == {'route', 'tool', 'action', 'structural_level',
                                                  'rank_ppb', 'supported_agreements'} and
                 row['route'] in routes, 'NAVIGATION_ROUTE_SET')
            route = routes[row['route']]
            need(row['tool'] == route['native_tool'] and row['action'] == route['action'] and
                 row['structural_level'] == aap_levels.tool_level(route['native_tool']), 'NAVIGATION_ROUTE_MEANING_CHANGED')
            integer(row['rank_ppb']); integer(row['supported_agreements'])
            need(row['rank_ppb'] <= 1000000000 and row['supported_agreements'] <= 256, 'NAVIGATION_RANKING_BOUNDS')
            names.append(row['route'])
        need(set(names) == set(routes), 'NAVIGATION_ROUTE_SET')
        need(0 < sum(r['rank_ppb'] for r in rows) <= 1000000000, 'NAVIGATION_RANKING_MASS')
        need(ranked.get('execution_authorized') is False and ranked.get('authority_changed') is False and
             ranked.get('features_removed') is False and ranked.get('marketing_publication_authorized') is False,
             'NAVIGATION_AUTHORITY_FIELDS')
        need(ranked.get('private') is True and ranked.get('telemetry') is False and
             ranked.get('assurance') == feature_use_rank.ASSURANCE, 'NAVIGATION_PRIVACY_FIELDS')

    @_serialized
    def adopt(self, proposal, expected_id, signature):
        """Explicit owner SDK action, deliberately absent from agent tool arguments."""
        self._unchanged(); body = proposal['body']
        self._validate(body)
        need(digest(LABEL, body) == expected_id, 'NAVIGATION_ADOPTION_PIN')
        verify(self.owner, LABEL, body, signature)
        with self.store.exclusive():
            rows = self.store.events()
            prior = next((r for r in rows if r['body']['task'] == expected_id), None)
            if prior is not None:
                return {'id': expected_id, 'head': prior['id'], 'replayed': True, 'execution_authorized': False}
            now = self.clock(); integer(now)
            need(body['ranking']['created_at'] <= now < body['expires'], 'NAVIGATION_ADOPTION_STALE')
            need(body['previous_head'] == (rows[-1]['id'] if rows else '0' * 64), 'NAVIGATION_JOURNAL_HEAD_CHANGED')
            head = self.store.append('NAVIGATION_ADOPT', expected_id,
                                     {'body': body, 'signature': signature})
        return {'id': expected_id, 'head': head, 'replayed': False, 'execution_authorized': False}

    @_serialized
    def guide(self, parameters):
        """Keep explicit task choices; ranked matches still use exact schema validation."""
        self._unchanged()
        original = onboarding.task_guide(**parameters)
        try:
            rows = self.store.events()
        except ValueError:
            return {**original, 'navigation': {'status': 'JOURNAL_INVALID_STATIC_FALLBACK', 'automatic_execution': False}}
        if not rows:
            return {**original, 'navigation': {'status': 'NO_OWNER_ADOPTED_RANKING', 'automatic_execution': False}}
        value = rows[-1]['body']['value']; body = value['body']
        try:
            self._validate(body)
            verify(self.owner, LABEL, body, value['signature'])
            now = self.clock(); integer(now)
            need(body['ranking']['created_at'] <= now < body['expires'], 'NAVIGATION_ADOPTION_STALE')
        except (ValueError, KeyError, TypeError):
            return {**original, 'navigation': {'status': 'STALE_OR_CHANGED_SNAPSHOT_STATIC_FALLBACK',
                                             'automatic_execution': False}}
        eligible = onboarding.task_matches(parameters.get('query', ''), limit=256)
        ranks = {r['route']: r for r in body['ranking']['routes']}
        candidates = sorted(eligible, key=lambda r: (-ranks[r['id']]['rank_ppb'], -r['score'], r['id']))
        if self.mode == 'RERANK_MATCHES' and parameters.get('task') is None and candidates:
            chosen = {**parameters, 'task': candidates[0]['id']}
            result = onboarding.task_guide(**chosen)
        else:
            result = original
        result['navigation'] = {'status': 'OWNER_ADOPTED_CONTEXTUAL_RANKING', 'mode': self.mode,
            'snapshot_id': digest(LABEL, body), 'journal_head': rows[-1]['id'],
            'taxonomy_sha256': body['ranking']['taxonomy_sha256'],
            'catalog_sha256': body['ranking']['catalog_sha256'], 'context': self.context,
            'recommended_candidates': candidates[:5], 'private': True,
            'authority_changed': False, 'automatic_execution': False, 'marketing_publication_authorized': False}
        return result

    @_serialized
    def close(self):
        self.store.close()
