"""Typed evidence envelope ``covenant-evidence/0.1``.

The digest of the envelope is what a native SHOW stores as ``content_hash``.
SHOW itself is unchanged. Bytes stay off the ledger: a small blob can be packed
with ``external_drafts``, and anything else is a hash.

A self-written model answer is not reported as ``true``. That matches the
toolkit rule (PR #20): an oracle answer the writer produced is not TRUE.
``covenant-expr/0.2`` FACT (PR #31) reads a value only. Source and confidence
stay beside that value and are not folded into it. A self-written oracle is
omitted from the facts dict, so FACT stays UNKNOWN.

Confidence becomes a recommended ``release_bps`` in ``aggregation``. The
single-source and model caps are drafting defaults. They are not a gate.
"""
from copy import deepcopy
import hashlib
from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verify
from .proof_facility import merkle_leaf, merkle_node

VERSION = 'covenant-evidence/0.1'
LABEL = 'COVENANT-EVIDENCE-0.1'
ENVELOPE_MAX = 8192
BYTES_PROFILE = 'covenant-evidence-bytes/0.1'
MAX_COMMITTED = 4096
SOURCE_CLASSES = {'IMAGE', 'VIDEO', 'DOCUMENT', 'SENSOR', 'GPS', 'WEB', 'API', 'EMAIL', 'CHAT', 'WITNESS', 'COVENANT', 'AI_MODEL', 'IOT'}
METHODS = {'C2PA', 'DEVICE_ATTESTATION', 'TLSNOTARY', 'ZKTLS', 'DKIM', 'SIGNED_SOURCE', 'HUMAN_ATTESTATION', 'CHAIN_PROOF', 'MODEL_ATTESTATION', 'SELF_REPORTED'}
INDEPENDENT = {'C2PA', 'DEVICE_ATTESTATION', 'TLSNOTARY', 'ZKTLS', 'DKIM', 'SIGNED_SOURCE', 'CHAIN_PROOF'}
MODES = {'HASH_ONLY', 'SALTED', 'SCOPED', 'PUBLIC'}


def _text(value, limit):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), 'EVIDENCE_TEXT')


def source_class(value):
    if value in SOURCE_CLASSES:
        return
    need(type(value) is str and value.startswith('CUSTOM:') and 8 <= len(value) <= 80, 'EVIDENCE_SOURCE_CLASS')
    _text(value, 80)


def _bps(value):
    integer(value)
    need(value <= 10000, 'EVIDENCE_BPS')


def blob_descriptor(media_type, *, raw=None, sha256=None, nbytes=None, capsule=None):
    """Hash raw bytes, or adopt a hash when the bytes stay outside the envelope."""
    _text(media_type, 256)
    if raw is not None:
        need(sha256 is None and nbytes is None and type(raw) is bytes and 1 <= len(raw) <= 8_388_608, 'EVIDENCE_BLOB')
        sha256 = hashlib.sha256(raw).hexdigest()
        nbytes = len(raw)
    key(sha256)
    integer(nbytes, True)
    if capsule is not None:
        key(capsule)
    return {'sha256': sha256, 'bytes': nbytes, 'media_type': media_type, 'capsule': capsule}


def _body(agreement, context, adapter, source_class_name, blob, claim, observed_at, reported_at, provenance, confidence_bps, disclosure, carrier=None, fix=None):
    key(agreement)
    key(context)
    key(adapter)
    source_class(source_class_name)
    exact(blob, 'sha256 bytes media_type capsule')
    key(blob['sha256'])
    integer(blob['bytes'], True)
    _text(blob['media_type'], 256)
    if blob['capsule'] is not None:
        key(blob['capsule'])
    exact(claim, 'field value')
    _text(claim['field'], 64)
    need(type(claim['value']) in (bool, int, str), 'EVIDENCE_CLAIM')
    if type(claim['value']) is int:
        need(abs(claim['value']) <= 2**53 - 1, 'EVIDENCE_CLAIM')
    if type(claim['value']) is str:
        _text(claim['value'], 256)
    integer(observed_at)
    integer(reported_at)
    need(observed_at <= reported_at, 'EVIDENCE_TIME')
    need(type(provenance) is list and len(provenance) <= 8, 'EVIDENCE_PROVENANCE')
    seen = set()
    for item in provenance:
        exact(item, 'method proof verifier')
        need(item['method'] in METHODS, 'EVIDENCE_METHOD')
        if item['proof'] is not None:
            key(item['proof'])
        if item['verifier'] is not None:
            key(item['verifier'])
        need((item['proof'] is None) == (item['verifier'] is None), 'EVIDENCE_PROVENANCE')
        mark = (item['method'], item['proof'], item['verifier'])
        need(mark not in seen, 'EVIDENCE_PROVENANCE')
        seen.add(mark)
    _bps(confidence_bps)
    exact(disclosure, 'mode commitment recipients')
    need(disclosure['mode'] in MODES, 'EVIDENCE_DISCLOSURE')
    if disclosure['commitment'] is not None:
        key(disclosure['commitment'])
    need(type(disclosure['recipients']) is list and len(disclosure['recipients']) <= 16, 'EVIDENCE_RECIPIENTS')
    for recipient in disclosure['recipients']:
        _text(recipient, 128)
    need(len(disclosure['recipients']) == len(set(disclosure['recipients'])), 'EVIDENCE_RECIPIENTS')
    if disclosure['mode'] == 'HASH_ONLY':
        need(disclosure['commitment'] is None and disclosure['recipients'] == [], 'EVIDENCE_DISCLOSURE')
    elif disclosure['mode'] == 'SALTED':
        need(disclosure['commitment'] is not None, 'EVIDENCE_DISCLOSURE')
    elif disclosure['mode'] == 'SCOPED':
        need(len(disclosure['recipients']) >= 1, 'EVIDENCE_DISCLOSURE')
    carrier = _carrier(carrier)
    fix = _fix(fix)
    return {'version': VERSION, 'agreement': agreement, 'context': context, 'adapter': adapter,
            'source_class': source_class_name, 'blob': deepcopy(blob), 'claim': deepcopy(claim),
            'observed_at': observed_at, 'reported_at': reported_at, 'provenance': deepcopy(provenance),
            'confidence_bps': confidence_bps, 'disclosure': deepcopy(disclosure), 'carrier': carrier, 'fix': fix}


def _carrier(value):
    """Hash reference only. Photo bytes are not a field of this object."""
    if value is None:
        value = {'profile': BYTES_PROFILE, 'placement': 'HASH_ONLY', 'manifest': None, 'thumbnail': None}
    exact(value, 'profile placement manifest thumbnail')
    need(value['profile'] == BYTES_PROFILE and value['placement'] in {'HASH_ONLY', 'ERASURE'}, 'EVIDENCE_CARRIER')
    thumb = value['thumbnail']
    if thumb is not None:
        exact(thumb, 'sha256 bytes media_type')
        key(thumb['sha256'])
        integer(thumb['bytes'], True)
        need(thumb['bytes'] <= 32768, 'EVIDENCE_THUMBNAIL')
        _text(thumb['media_type'], 256)
    if value['placement'] == 'HASH_ONLY':
        need(value['manifest'] is None, 'EVIDENCE_CARRIER')
    else:
        key(value['manifest'])
    return deepcopy(value)


def _fix(value):
    if value is None:
        return None
    from .geo_fix import SCALE, SOURCES, VERSION as geo_version
    exact(value, 'version lat_microdeg lon_microdeg scale source')
    need(value['version'] == geo_version and value['scale'] == SCALE and value['source'] in SOURCES, 'EVIDENCE_FIX')
    need(type(value['lat_microdeg']) is int and abs(value['lat_microdeg']) <= 90 * SCALE, 'EVIDENCE_FIX')
    need(type(value['lon_microdeg']) is int and abs(value['lon_microdeg']) <= 180 * SCALE, 'EVIDENCE_FIX')
    return deepcopy(value)


def seal(private_key, agreement, context, adapter, source_class_name, blob, claim, observed_at, reported_at, provenance, confidence_bps, disclosure, carrier=None, fix=None):
    body = _body(agreement, context, adapter, source_class_name, blob, claim, observed_at, reported_at, provenance, confidence_bps, disclosure, carrier, fix)
    envelope = {**body, 'signature': {'signer': public_key(private_key), 'sig': sign(private_key, LABEL, body)}}
    authenticate(envelope)
    return {'version': VERSION, 'envelope': envelope, 'content_hash': content_hash(envelope),
            'show_fields': ('agreement', 'content_hash', 'description'), 'ledger_op_changed': False,
            'bytes_in_envelope': False, 'execution_authorized': False}


def authenticate(envelope):
    need(type(envelope) is dict and set(envelope) == set(_FIELDS), 'EVIDENCE_FIELDS')
    need(len(canonical(envelope)) <= ENVELOPE_MAX, 'EVIDENCE_ENVELOPE_SIZE')
    body = {name: envelope[name] for name in _FIELDS if name != 'signature'}
    need(body['version'] == VERSION, 'EVIDENCE_VERSION')
    _body(body['agreement'], body['context'], body['adapter'], body['source_class'], body['blob'], body['claim'],
          body['observed_at'], body['reported_at'], body['provenance'], body['confidence_bps'], body['disclosure'],
          body['carrier'], body['fix'])
    exact(envelope['signature'], 'signer sig')
    verify(envelope['signature']['signer'], LABEL, body, envelope['signature']['sig'])
    return True


_FIELDS = ('version', 'agreement', 'context', 'adapter', 'source_class', 'blob', 'claim', 'observed_at',
           'reported_at', 'provenance', 'confidence_bps', 'disclosure', 'carrier', 'fix', 'signature')


def content_hash(envelope):
    """The value a party puts in SHOW ``content_hash``. SHOW is not modified."""
    authenticate(envelope)
    return digest(LABEL, envelope)


def show_payload(envelope, description='EVIDENCE'):
    authenticate(envelope)
    _text(description, 256)
    return {'agreement': envelope['agreement'], 'content_hash': content_hash(envelope), 'description': description}


def self_written_oracle(envelope):
    """Model evidence with no independent provenance. A file the party reports is not this."""
    methods = {item['method'] for item in envelope['provenance']}
    model = envelope['source_class'] == 'AI_MODEL' or 'MODEL_ATTESTATION' in methods
    return model and not (methods & INDEPENDENT)


def effective_confidence(envelope, manifest=None, *, provenance_verified, fresh):
    cap = 10000
    if manifest is not None:
        need(type(manifest) is dict, 'EVIDENCE_MANIFEST')
        if 'max_confidence_bps' in manifest:
            _bps(manifest['max_confidence_bps'])
            cap = manifest['max_confidence_bps']
    need(type(provenance_verified) is list and len(provenance_verified) == len(envelope['provenance']), 'EVIDENCE_PROVENANCE')
    eff = min(cap, envelope['confidence_bps'])
    for verified in provenance_verified:
        need(type(verified) is bool, 'EVIDENCE_PROVENANCE')
        eff = eff * (10000 if verified else 5000) // 10000
    if not fresh:
        eff = eff * 5000 // 10000
    return eff


def fact_binding(envelope, *, manifest=None, provenance_verified=None, fresh=True, policy=None):
    """A FACT for ``covenant-expr/0.2`` plus the source and confidence beside it.

    The expression evaluator reads ``value`` only. A self-written oracle is not
    given a boolean True: ``true`` stays false and ``facts_dict`` omits it, so
    the FACT is UNKNOWN. Admitting the value for release does not change that.
    """
    authenticate(envelope)
    policy = {} if policy is None else policy
    verified = [True] * len(envelope['provenance']) if provenance_verified is None else provenance_verified
    oracle = self_written_oracle(envelope)
    value = envelope['claim']['value']
    return {'name': envelope['claim']['field'], 'value': None if oracle else value,
            'source': envelope['adapter'], 'confidence_bps': effective_confidence(envelope, manifest, provenance_verified=verified, fresh=fresh),
            'true': False if oracle else value is True, 'self_written_oracle': oracle,
            'accept_self_written': policy.get('accept_self_written', 'ABSENT'),
            'expr': 'covenant-expr/0.2', 'fact': 'VALUE_ONLY_SOURCE_AND_CONFIDENCE_ARE_METADATA',
            'world_truth': 'NOT_ESTABLISHED', 'execution_authorized': False}


def facts_dict(bindings):
    """Values a 0.2 FACT environment can store. Self-written oracles are left out."""
    out = {}
    for row in bindings:
        need(type(row) is dict and 'name' in row, 'EVIDENCE_FACT')
        if row.get('self_written_oracle'):
            continue
        if row.get('value') is not None and row['name'] not in out:
            out[row['name']] = deepcopy(row['value'])
    return out


def toolkit_supports(envelope):
    """PR #20 toolkit check: a self-written oracle answer is not support True."""
    authenticate(envelope)
    if self_written_oracle(envelope):
        return False
    return None


def merkle_commit(records):
    """Commit up to 4,096 opened records. Evaluation still spot-checks at most 32."""
    need(type(records) is list and 1 <= len(records) <= MAX_COMMITTED, 'EVIDENCE_MERKLE')
    level = [[index] for index in range(len(records))]
    hashes = [merkle_leaf(canonical(record)) for record in records]
    paths = [[] for _ in records]
    while len(hashes) > 1:
        nxt_hashes = []
        nxt_level = []
        index = 0
        while index < len(hashes):
            if index + 1 == len(hashes):
                nxt_hashes.append(hashes[index])
                nxt_level.append(level[index])
                index += 1
                continue
            parent = merkle_node(hashes[index], hashes[index + 1])
            for leaf in level[index]:
                paths[leaf].append({'side': 'RIGHT', 'hash': hashes[index + 1]})
            for leaf in level[index + 1]:
                paths[leaf].append({'side': 'LEFT', 'hash': hashes[index]})
            nxt_hashes.append(parent)
            nxt_level.append(level[index] + level[index + 1])
            index += 2
        hashes, level = nxt_hashes, nxt_level
    return {'root': hashes[0], 'count': len(records), 'paths': paths, 'population_read': False,
            'execution_authorized': False}


def merkle_member(root, record, path):
    key(root)
    need(type(path) is list and len(path) <= 64, 'EVIDENCE_MERKLE')
    value = merkle_leaf(canonical(record))
    for step in path:
        exact(step, 'side hash')
        key(step['hash'])
        need(step['side'] in {'LEFT', 'RIGHT'}, 'EVIDENCE_MERKLE')
        value = merkle_node(step['hash'], value) if step['side'] == 'LEFT' else merkle_node(value, step['hash'])
    return value == root

