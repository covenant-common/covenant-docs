"""Contextual practice retrieval; one origin is not many independent trials."""
from copy import deepcopy
from covenant_language.agentic import object_id,canonical
from .conditions import Snapshot
from .crypto import need,key


def query(store,practice,context,*,sources=None,require_certified_origin=True):
    need(type(context) is dict and len(canonical(context))<=8192,'EXPERIENCE_QUERY_CONTEXT')
    need(type(require_certified_origin) is bool,'EXPERIENCE_QUERY_POLICY')
    sources={} if sources is None else sources
    need(type(sources) is dict and all(type(s) is Snapshot for s in sources.values()),'EXPERIENCE_QUERY_SOURCES')
    view=store.inspect(practice);groups={};excluded=[]
    reports=view['experiences']
    # Only an author's own explicit corrections supersede that attribution.
    superseded={(e['object']['supersedes'],object_id(e['signer'])) for e in reports if e['object']['supersedes']}
    for env in reports:
        obj=env['object'];ref=object_id(obj)
        if (ref,object_id(env['signer'])) in superseded:continue
        if not all(k in obj['context'] and obj['context'][k]==v for k,v in context.items()):continue
        origin=obj['extensions'].get('origin');verified=False
        if type(origin) is dict and set(origin)=={'chain','event'}:
            key(origin['chain']);key(origin['event'])
            verified=any(s.head['chain']==origin['chain'] and origin['event'] in s.state['events'] for s in sources.values())
        else:origin=None
        if require_certified_origin and not verified:
            excluded.append(dict(report=ref,reason='NO_CERTIFIED_ORIGIN'));continue
        identity=object_id(origin) if origin is not None else ref
        group=groups.setdefault(identity,dict(origin=deepcopy(origin),origin_certified=verified,reports=[],outcomes={}))
        group['reports'].append(dict(id=ref,signer=deepcopy(env['signer'])))
        group['outcomes'][object_id(obj['outcome'])]=deepcopy(obj['outcome'])
    result=[]
    for identity,g in sorted(groups.items()):
        outcomes=list(g.pop('outcomes').values())
        result.append(dict(id=identity,**g,status='CONFLICT' if len(outcomes)>1 else 'REPORTED',outcomes=outcomes))
    return dict(practice=practice,context=deepcopy(context),origins=result,origin_count=len(result),
                excluded=excluded,challenges=view['challenges'],successors=view['successors'],
                contexts_and_outcomes='SIGNER_REPORTED_NOT_WORLD_TRUTH',independent_observations='NOT_ESTABLISHED',
                automatic_adoption=False,universal_score=None)


def bounded_add(store,envelope,max_reports=10000,max_bytes=64*1024*1024):
    """Admission for the optional local tool host, including prepared byte cost."""
    from covenant_language.practices import verify_report
    ref=verify_report(envelope);author=object_id(envelope['signer']);raw=canonical(envelope)
    db=store.db;db.execute('BEGIN IMMEDIATE')
    try:
        old=db.execute('SELECT 1 FROM reports WHERE id=? AND author=?',(ref,author)).fetchone()
        if old is None:
            count,size=db.execute('SELECT count(*),coalesce(sum(length(envelope)),0) FROM reports').fetchone()
            need(count<max_reports and size+len(raw)<=max_bytes,'PRACTICE_TOOL_CAPACITY')
        result=store.add(envelope);db.commit();return result
    except BaseException:db.rollback();raise
