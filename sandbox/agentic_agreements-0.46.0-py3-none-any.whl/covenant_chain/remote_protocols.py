"""Bounded JSON-response MCP and A2A clients over owner-pinned HTTP custody.

No URL, credentials or code are supplied by a model/counterparty. The existing
connector journals every attempt before transmission. Unknown attempts are not
blindly repeated. OAuth, SSE, streaming and automatic payment are out of scope.
"""
import base64
from copy import deepcopy
import hashlib
from pathlib import Path
import secrets
import threading

from covenant_agent.tool_client import _extra_meta, _json, _loads, sha256, MODERN_VERSION
from covenant_agent.signed_cards import verify_card
from .connector_harness import ConnectorHarness
from .crypto import need

PROFILE = 'covenant-remote-protocols/0.1'
IMPLEMENTATION = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


class _OwnerHTTP:
    def __init__(self, directory, origin, path, *, headers=None, timeout=5, maximum=262144):
        need(headers is None or callable(headers), 'REMOTE_OWNER_HEADERS')
        self.path = path; self.lock = threading.RLock(); self.method = None
        self._headers = headers
        self.harness = ConnectorHarness(directory, http_routes={'peer': {'origin': origin,
            'path_prefix': path, 'methods': ['POST'], 'headers': self.headers,
            'response_headers': ['content-type']}}, timeout=timeout,
            max_request_bytes=1000000, max_response_bytes=maximum)
        self._adopted_headers = headers
        self._configuration_pin = sha256(self._configuration())

    def _configuration(self):
        return {'path': self.path, 'connector': self.harness.ref, 'manifest': self.harness.manifest,
                'policy': self.harness.policy_pin, 'timeout': self.harness.timeout,
                'max_request_bytes': self.harness.max_request_bytes, 'max_response_bytes': self.harness.max_response_bytes,
                'routes': {alias: {k: deepcopy(v) for k, v in route.items() if k != 'headers'}
                           for alias, route in self.harness.routes.items()}}

    def _unchanged(self):
        need(self._headers is self._adopted_headers and sha256(self._configuration()) == self._configuration_pin and
             set(self.harness.routes) == {'peer'} and self.harness.routes['peer']['headers'] == self.headers,
             'REMOTE_OWNER_CONFIGURATION_CHANGED')

    def headers(self):
        extra = {} if self._headers is None else self._headers()
        self._unchanged()
        need(type(extra) is dict and not {k.lower() for k in extra} &
             {'content-type', 'accept', 'mcp-protocol-version', 'mcp-method'}, 'REMOTE_RESERVED_HEADERS')
        return {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream',
                **extra, **({'MCP-Protocol-Version': MODERN_VERSION, 'Mcp-Method': self.method}
                           if self.method is not None else {})}

    def request(self, effect, value, *, modern=False):
        with self.lock:
            self._unchanged()
            self.method = value['method'] if modern else None
            try:
                receipt = self.harness.execute(effect, {'protocol': 'HTTP', 'operation': 'peer',
                    'parameters': {'path': self.path, 'method': 'POST',
                        'body_base64': base64.b64encode(_json(value)).decode('ascii')}})
            finally:
                self.method = None
        need(receipt['status'] == 'OBSERVED', 'TOOL_REMOTE_OUTCOME_UNKNOWN')
        response = receipt['value']['response']
        need(response['status'] == 200, 'TOOL_REMOTE_HTTP_STATUS')
        need(response['headers'].get('content-type', '').split(';')[0].strip().lower() == 'application/json',
             'TOOL_REMOTE_JSON_REQUIRED_STREAMING_UNSUPPORTED')
        return _loads(base64.b64decode(response['body_base64'], validate=True))

    def close(self):
        self.harness.close()


class MCPHTTPFactory:
    """Install into ToolClient(transports={alias: factory}) with its exact pin."""
    def __init__(self, directory, origin, path='/mcp', *, headers=None, timeout=5):
        self.http = _OwnerHTTP(directory, origin, path, headers=headers, timeout=timeout)
        self.manifest = {'profile': PROFILE, 'kind': 'MCP_HTTP_JSON_2026_07_28',
                         'implementation': IMPLEMENTATION, 'connector': self.http.harness.ref, 'path': path}
        self._http = self.http; self._manifest_pin = sha256(self.manifest)

    def _unchanged(self):
        need(self.http is self._http and sha256(self.manifest) == self._manifest_pin and
             self.manifest['path'] == self.http.path and self.manifest['connector'] == self.http.harness.ref,
             'REMOTE_OWNER_CONFIGURATION_CHANGED')
        self.http._unchanged()

    def __call__(self):
        self._unchanged()
        return _MCPSession(self)

    def close(self):
        self.http.close()


class _MCPSession:
    def __init__(self, factory):
        self.factory = factory; self.nonce = secrets.token_hex(32); self.ident = 0
        self.closed = False
        discovered = self.request('server/discover', {})
        need(type(discovered.get('supportedVersions')) is list and MODERN_VERSION in discovered['supportedVersions'] and
             type(discovered.get('capabilities')) is dict, 'TOOL_DISCOVER')

    def request(self, method, params, extra_meta=None):
        self.factory._unchanged()
        need(not self.closed and type(params) is dict and '_meta' not in params, 'TOOL_REMOTE_REQUEST')
        need(method in ('server/discover', 'tools/list', 'tools/call'), 'TOOL_REMOTE_METHOD')
        need(extra_meta is None or method == 'tools/call', 'TOOL_REMOTE_REQUEST')
        self.ident += 1
        message = {'jsonrpc': '2.0', 'id': self.ident, 'method': method, 'params': {**deepcopy(params),
            '_meta': {**_extra_meta(extra_meta),
                      'io.modelcontextprotocol/protocolVersion': MODERN_VERSION,
                      'io.modelcontextprotocol/clientCapabilities': {},
                      'io.modelcontextprotocol/clientInfo': {'name': 'aap', 'version': '0.1'}}}}
        response = self.factory.http.request(sha256({'session': self.nonce, 'id': self.ident}), message, modern=True)
        need(type(response) is dict and response.get('jsonrpc') == '2.0' and
             type(response.get('id')) is int and response['id'] == self.ident and
             ('result' in response) != ('error' in response), 'TOOL_REMOTE_RESPONSE')
        need('error' not in response, 'TOOL_RPC_ERROR')
        result = response['result']; need(type(result) is dict and result.get('resultType') == 'complete', 'TOOL_RESULT_TYPE_UNSUPPORTED')
        meta = result.get('_meta'); info = meta.get('io.modelcontextprotocol/serverInfo') if type(meta) is dict else None
        need(type(info) is dict and type(info.get('name')) is str and type(info.get('version')) is str, 'TOOL_SERVER_INFO')
        return result

    def close(self):
        self.closed = True


class A2AHTTPClient:
    """Owner-adopted signed card and endpoint; task RPC is not an agreement.

    Caller provides exact signed required-extension payloads where needed.
    Observing a task does not verify its business outcome or payment.
    """
    def __init__(self, directory, origin, path, card, trusted_keys, now, expected_card,
                 *, headers=None, timeout=5):
        checked = verify_card(card, trusted_keys, now, expected_card)
        need(any(type(v) is dict and v.get('url') == origin.rstrip('/') + path and
                 v.get('protocolBinding') == 'JSONRPC' and v.get('protocolVersion') == '1.0'
                 for v in card.get('supportedInterfaces', [])), 'A2A_OWNER_ENDPOINT_CARD_MISMATCH')
        self.card = checked['id']; self.http = _OwnerHTTP(directory, origin, path, headers=headers, timeout=timeout)
        self._card_pin = self.card; self._http = self.http

    def call(self, method, params, request_id):
        need(self.http is self._http and self.card == self._card_pin, 'REMOTE_OWNER_CONFIGURATION_CHANGED')
        self.http._unchanged()
        need(method in ('SendMessage', 'GetTask', 'CancelTask') and type(params) is dict and
             type(request_id) is str and 8 <= len(request_id) <= 128, 'A2A_REMOTE_REQUEST')
        message = {'jsonrpc': '2.0', 'id': request_id, 'method': method, 'params': deepcopy(params)}
        response = self.http.request(sha256({'card': self.card, 'request': request_id}), message)
        need(type(response) is dict and response.get('jsonrpc') == '2.0' and response.get('id') == request_id and
             ('result' in response) != ('error' in response), 'A2A_REMOTE_RESPONSE')
        return {'response': response, 'card': self.card, 'payment_verified': False,
                'business_outcome_verified': False, 'execution_authorized': False}

    def close(self):
        self.http.close()
