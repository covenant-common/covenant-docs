"""Exact capability negotiation; unknown operative requirements fail closed."""
from copy import deepcopy
from covenant_language.agentic import canonical,object_id
from .crypto import need

VERSION='covenant-compatibility/0.1'
FIELDS={'semantics','adapters','domains','judgment','privacy','reversibility'}


def negotiate(requirements,offers):
    need(type(requirements) is dict and type(offers) is list and 0<len(offers)<=64,'COMPATIBILITY_SHAPE')
    canonical(requirements);canonical(offers)
    for name,values in requirements.items():
        need(type(values) is list and len(values)<=64 and all(type(x) is str for x in values),'COMPATIBILITY_REQUIREMENT')
    candidates=[]
    for offer in offers:
        need(type(offer) is dict and set(offer)=={'id','capabilities','irreversible'},'COMPATIBILITY_OFFER')
        need(type(offer['id']) is str and type(offer['capabilities']) is dict
             and type(offer['irreversible']) is bool,'COMPATIBILITY_OFFER')
        for values in offer['capabilities'].values():
            need(type(values) is list and all(type(x) is str for x in values),'COMPATIBILITY_OFFER')
        missing={name:list(values) if name not in FIELDS else sorted(set(values)-set(offer['capabilities'].get(name,[])))
                 for name,values in requirements.items()}
        missing={k:v for k,v in missing.items() if v or k not in FIELDS}
        candidates.append(dict(offer=offer['id'],compatible=not missing,missing=missing,
                               capabilities=deepcopy(offer['capabilities']),irreversible=offer['irreversible']))
    return dict(version=VERSION,requirements=object_id(requirements),candidates=candidates,
                compatible=[c['offer'] for c in candidates if c['compatible']],
                automatic_selection=False,trust_changed=False,automatic_assent=False,execution_authorized=False)
