"""Exact pre-origination borrowing costs under an adopted local rail policy.

This pure helper neither originates credit nor reads a loan, balance or receipt.
It uses the installed rail's declared pure credit-assent and fee interfaces.
Future fees, funding, repayment, collateral and calendar time are not inferred.
"""
from copy import deepcopy

from covenant_language import market_blueprints
from covenant_language.agentic import canonical
from .adapters import manifest_id
from .crypto import digest, need
from .payment_rails import quote_fee, validate_fees

VERSION = "covenant-credit-cost-preview/0.1"
MAX = 2**53 - 1


def _integer(value, *, positive=False):
    need(type(value) is int and (1 if positive else 0) <= value <= MAX,
         "CREDIT_PREVIEW_EXACT_INTEGER")


def _total(values):
    value = sum(values)
    _integer(value)
    return value


def timing(spec, height=None):
    """Describe the existing height term without inventing a calendar or clock."""
    info = market_blueprints.inspect(spec)
    need(info["spec"]["kind"] == "TERM_CREDIT", "CREDIT_KIND")
    if height is not None:
        _integer(height)
    due = info["spec"]["rules"]["due_height"]
    return {
        "due_height": due,
        "meaning": "Height under the adopted clock; no calendar mapping or source established.",
        "calendar_due_date": None,
        "clock_source": "NOT_ESTABLISHED_BY_THIS_PREVIEW",
        "calendar_conversion": "NOT_PERFORMED",
        "supplied_height": height,
        "supplied_height_assurance": "CALLER_ASSERTION_NOT_CERTIFIED" if height is not None else "NOT_SUPPLIED",
        "verified_current_height": False,
        "apr_or_term_duration": "NOT_INFERRED",
    }


def preview(adapter, spec, repayments=None):
    """Preview a known rail's unsecured single-asset credit before a loan exists.

    A compatible owner adapter must expose the same pinned fee-policy/unit and
    pure credit_assent(spec, maximum_fee) contract as DemoPaymentRail. Installing
    that owner code is a separate trust boundary; this is not its sandbox.
    """
    need(callable(getattr(adapter, "credit_assent", None)) and
         type(getattr(adapter, "policy", None)) is dict and
         type(getattr(adapter, "unit", None)) is str and
         type(getattr(adapter, "manifest", None)) is dict,
         "CREDIT_PREVIEW_UNSUPPORTED_FEE_INTERFACE")
    policy = deepcopy(adapter.policy)
    validate_fees(policy)
    adapter_ref = manifest_id(adapter.manifest)
    unit = adapter.unit
    policy_ref = digest("COVENANT-NETWORK-FEE-0.1", policy)
    need(adapter.manifest.get("capability") == "payment.transfer" and
         type(adapter.manifest.get("requirements")) is dict and
         adapter.manifest["requirements"].get("fee_policy") == policy_ref,
         "CREDIT_PREVIEW_FEE_POLICY_PIN")
    need(policy["unit"] == adapter.unit, "PAYMENT_UNIT_NO_AUTOMATIC_FX")
    info = market_blueprints.inspect(spec)
    need(info["spec"]["kind"] == "TERM_CREDIT", "CREDIT_KIND")
    flows = info["cashflows"]
    principal, debt = flows["principal_advanced"], flows["total_due"]
    lender_fee = quote_fee(policy, principal, adapter.unit)
    # This existing pure interface verifies the exact asset, adapter, parties,
    # collateral limitations and fee-cap signing body. It does not read a loan.
    assent = adapter.credit_assent(deepcopy(info["spec"]), lender_fee["amount"])
    need(type(assent) is dict and assent.get("execution_authorized") is False and
         type(assent.get("body")) is dict and assent["body"].get("rail") == adapter_ref and
         type(assent.get("cashflows")) is dict and
         canonical(assent["cashflows"]) == canonical(flows), "CREDIT_PREVIEW_ASSENT_INTERFACE")
    need(manifest_id(adapter.manifest) == adapter_ref and adapter.unit == unit and
         digest("COVENANT-NETWORK-FEE-0.1", adapter.policy) == policy_ref,
         "CREDIT_PREVIEW_ADAPTER_CHANGED")
    default_plan = repayments is None
    planned = [debt] if default_plan else deepcopy(repayments)
    need(type(planned) is list and 1 <= len(planned) <= 128,
         "CREDIT_PREVIEW_REPAYMENT_PLAN")
    for amount in planned:
        _integer(amount, positive=True)
    need(_total(planned) == debt, "CREDIT_PREVIEW_REPAYMENTS_MUST_SUM_TO_DEBT")
    repayment_quotes = []
    for index, amount in enumerate(planned):
        fee = quote_fee(policy, amount, adapter.unit)
        repayment_quotes.append({"index": index, "debt_repayment": amount,
                                 "network_fee_paid_by_borrower": fee["amount"],
                                 "borrower_outflow": _total([amount, fee["amount"]]),
                                 "fee_policy": fee["policy"]})
    repayment_fees = _total([item["network_fee_paid_by_borrower"] for item in repayment_quotes])
    all_in = _total([debt, repayment_fees])
    return {
        "version": VERSION,
        "spec_id": info["id"],
        "adapter": adapter_ref,
        "fee_policy": policy_ref,
        "unit": adapter.unit,
        "principal_advanced_to_borrower": principal,
        "interest": flows["interest"],
        "origination_fee_due_at_maturity": flows["origination_fee_due_at_maturity"],
        "total_debt": debt,
        "lender_origination_network_fee": lender_fee["amount"],
        "lender_initial_outflow": _total([principal, lender_fee["amount"]]),
        "borrower_origination_network_fee": 0,
        "planned_repayments": repayment_quotes,
        "borrower_repayment_network_fees": repayment_fees,
        "borrower_all_in_outflow": all_in,
        "borrower_cost_above_advance": all_in - principal,
        "repayment_plan_assumption": "ONE_FULL_REPAYMENT" if default_plan else "CALLER_CHOSEN_SPLIT_SUMS_TO_EXACT_DEBT",
        "repayment_dates_or_heights": "NOT_ASSIGNED_BY_THIS_PREVIEW",
        "fee_assumption": "CURRENT_PINNED_POLICY_FOR_ORIGINATION_AND_ALL_PLANNED_REPAYMENTS; FUTURE_ADOPTED_POLICY_MAY_CHANGE",
        "interest_convention": flows["interest_convention"],
        "timing": timing(info["spec"]),
        "collateral": "UNSECURED_NO_AUTOMATIC_RECOVERY",
        "repayment_guarantee": False,
        "funding": "NOT_RESERVED_OR_ESTABLISHED",
        "loan_lookup_performed": False,
        "loan_created": False,
        "execution_authorized": False,
    }


def assignment_quote(*, face, price, variant, rail, profile=None, service_fee=0, interest_bps=0, escrow=False,
                     scale=None):
    """Preview the sale of a payment claim. No loan is created and nothing moves.

    Escrow stays optional and the rail is whatever the parties name. Under
    islamic_commercial_review only a sale at par is accepted; a discount, a fee
    or interest raises RIBA_DISCOUNT_REFUSED. That is a host profile gate, not a
    religious ruling. See covenant_chain.receivable_assignment.
    """
    from .receivable_assignment import quote
    return quote(face=face, price=price, variant=variant, rail=rail, profile=profile,
                 service_fee=service_fee, interest_bps=interest_bps, escrow=escrow, scale=scale)
