"""Deterministic CBOR for the DTN carriers. RFC 8949 section 4.2.1; standard library only.

encode() writes the core deterministic encoding: the shortest argument for
every integer and length, definite lengths only, and map keys ordered by
their encoded bytes. decode() refuses every other spelling of a value, so an
accepted item re-encodes to exactly the bytes received. Tags, floating point,
undefined and the other simple values are refused; BPv7 and BPSec use none.

RFC 9171 section 4.1 wraps each bundle in one indefinite-length array.
dtn_bundle reads that container itself with decode_prefix(); everywhere else
an indefinite length is CBOR_INDEFINITE.
"""
from .crypto import need

MAX_DEPTH = 16
MAX_ITEMS = 4096
LIMIT = 1 << 64


def _head(major, value):
    if value < 24:
        return bytes([major << 5 | value])
    for info, size in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if value < 1 << 8 * size:
            return bytes([major << 5 | info]) + value.to_bytes(size, 'big')
    raise ValueError('CBOR_INTEGER_RANGE')


def _encode(value, out, depth):
    need(depth <= MAX_DEPTH, 'CBOR_DEPTH')
    if value is False or value is True or value is None:
        out += {False: b'\xf4', True: b'\xf5', None: b'\xf6'}[value]
    elif type(value) is int:
        need(-LIMIT <= value < LIMIT, 'CBOR_INTEGER_RANGE')
        out += _head(0, value) if value >= 0 else _head(1, -1 - value)
    elif type(value) is bytes:
        out += _head(2, len(value)) + value
    elif type(value) is str:
        try:
            raw = value.encode('utf-8')
        except UnicodeError:
            raise ValueError('CBOR_UTF8') from None
        out += _head(3, len(raw)) + raw
    elif type(value) in (list, tuple):
        need(len(value) <= MAX_ITEMS, 'CBOR_ITEMS')
        out += _head(4, len(value))
        for item in value:
            _encode(item, out, depth + 1)
    elif type(value) is dict:
        need(len(value) <= MAX_ITEMS, 'CBOR_ITEMS')
        pairs = []
        for name, item in value.items():
            need(type(name) in (int, str, bytes), 'CBOR_MAP_KEY')
            pairs.append((encode(name), item))
        pairs.sort(key=lambda pair: pair[0])
        out += _head(5, len(pairs))
        for name, item in pairs:
            out += name
            _encode(item, out, depth + 1)
    else:
        raise ValueError('CBOR_TYPE')


def encode(value):
    out = bytearray()
    _encode(value, out, 0)
    return bytes(out)


def _argument(raw, offset, info):
    if info < 24:
        return info, offset
    need(info != 31, 'CBOR_INDEFINITE')
    need(info <= 27, 'CBOR_RESERVED')
    size = 1 << info - 24
    need(offset + size <= len(raw), 'CBOR_TRUNCATED')
    value = int.from_bytes(raw[offset:offset + size], 'big')
    need(value >= (24 if size == 1 else 1 << 4 * size), 'CBOR_NOT_SHORTEST')
    return value, offset + size


def _item(raw, offset, depth):
    need(depth <= MAX_DEPTH, 'CBOR_DEPTH')
    need(offset < len(raw), 'CBOR_TRUNCATED')
    major, info = raw[offset] >> 5, raw[offset] & 0x1f
    offset += 1
    if major == 7:
        need(info in (20, 21, 22), 'CBOR_BREAK' if info == 31 else
             'CBOR_FLOAT' if 25 <= info <= 27 else 'CBOR_SIMPLE')
        return (False, True, None)[info - 20], offset
    need(major != 6, 'CBOR_TAG')
    value, offset = _argument(raw, offset, info)
    if major == 0:
        return value, offset
    if major == 1:
        return -1 - value, offset
    if major in (2, 3):
        need(value <= len(raw) - offset, 'CBOR_TRUNCATED')
        data = raw[offset:offset + value]
        if major == 2:
            return data, offset + value
        try:
            return data.decode('utf-8'), offset + value
        except UnicodeError:
            raise ValueError('CBOR_UTF8') from None
    need(value <= MAX_ITEMS, 'CBOR_ITEMS')
    if major == 4:
        items = []
        for _ in range(value):
            item, offset = _item(raw, offset, depth + 1)
            items.append(item)
        return items, offset
    result, previous = {}, None
    for _ in range(value):
        start = offset
        name, offset = _item(raw, offset, depth + 1)
        need(type(name) in (int, str, bytes), 'CBOR_MAP_KEY')
        # Bytewise order of the encoded keys; strictly rising also refuses duplicates.
        need(previous is None or raw[start:offset] > previous, 'CBOR_MAP_ORDER')
        previous = raw[start:offset]
        result[name], offset = _item(raw, offset, depth + 1)
    return result, offset


def decode_prefix(raw, offset=0):
    """One complete item at ``offset``. Returns ``(value, end)``."""
    need(type(raw) is bytes and type(offset) is int and 0 <= offset, 'CBOR_INPUT')
    return _item(raw, offset, 0)


def decode(raw):
    """Exactly one deterministic item, with no trailing bytes."""
    value, end = decode_prefix(raw)
    need(end == len(raw), 'CBOR_TRAILING')
    return value


def decode_sequence(raw, limit=MAX_ITEMS):
    """An RFC 8742 CBOR sequence: zero or more items, back to back."""
    need(type(raw) is bytes, 'CBOR_INPUT')
    items, offset = [], 0
    while offset < len(raw):
        need(len(items) < limit, 'CBOR_ITEMS')
        item, offset = _item(raw, offset, 0)
        items.append(item)
    return items
