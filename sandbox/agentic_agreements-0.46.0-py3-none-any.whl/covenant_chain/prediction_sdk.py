"""Prediction-market helpers; RPC records are advisory, not finality proofs."""
from copy import deepcopy
import math
import secrets
from . import app, prediction
from .world_sdk import WorldClient


def market_terms(*, question, definition, source_policy, outcomes, resource,
                 close_height, report_by, observation_at, primary, appeal, rule,
                 report_from=None, payout_per_unit=None, challenge_blocks=10,
                 appeal_blocks=20):
    t = dict(version=prediction.VERSION, question=question, definition=definition,
             source_policy=source_policy, outcomes=deepcopy(outcomes), resource=resource,
             payout_per_unit=math.lcm(10000, len(outcomes)) if payout_per_unit is None else payout_per_unit,
             close_height=close_height, report_from=close_height if report_from is None else report_from,
             report_by=report_by, observation_at=observation_at, primary=deepcopy(primary),
             appeal=deepcopy(appeal), rule=deepcopy(rule), challenge_blocks=challenge_blocks,
             appeal_blocks=appeal_blocks, void_policy='EQUAL_OUTCOME_SHARES')
    prediction.validate_terms(t, 0)
    return t


def make_order(state, market, outcome, seller, buyer, quantity, price, expiry, *, salt=None):
    """Inspect and sign exact order separately; this helper does not reserve funds."""
    from .continuity import authority_epoch
    return dict(market=market, outcome=outcome, seller=seller, buyer=buyer,
                quantity=quantity, price=price, expiry=expiry, salt=salt or secrets.token_hex(32),
                epochs={who: {'controller': state['controller_epochs'].get(who, 0),
                              'authority': authority_epoch(state, who)} for who in (seller, buyer)})


class PredictionClient(WorldClient):
    def __init__(self, client, private_key, chain, *, fee_policy, max_fee, actor=None, sponsor=None):
        super().__init__(client, private_key, chain, actor=actor, protocol=app.PREDICTION_VERSION,
                         fee_policy=fee_policy, max_fee=max_fee, sponsor=sponsor)

    def create(self, terms, acceptances):
        return self.submit('PREDICTION_CREATE', dict(terms=terms, acceptances=acceptances))

    def mint(self, market, quantity):
        return self.submit('PREDICTION_MINT', dict(market=market, quantity=quantity))

    def merge(self, market, quantity):
        return self.submit('PREDICTION_MERGE', dict(market=market, quantity=quantity))

    def trade(self, order, approvals):
        return self.submit('PREDICTION_TRADE', dict(order=order, approvals=approvals))

    def report(self, market, phase, result, as_of, evidence, reasons):
        return self.submit('PREDICTION_REPORT', dict(market=market, phase=phase, result=result,
                                                  as_of=as_of, evidence=evidence, reasons=reasons))

    def challenge(self, market, evidence, reasons):
        return self.submit('PREDICTION_CHALLENGE', dict(market=market, evidence=evidence, reasons=reasons))

    def finalize(self, market):
        return self.submit('PREDICTION_FINALIZE', dict(market=market))

    def redeem(self, market):
        return self.submit('PREDICTION_REDEEM', dict(market=market))

    def inspect(self, market):
        self._advisory_context()
        return self._advisory_record('prediction_markets', market)


from .world_sdk import bind_agent_methods
bind_agent_methods(PredictionClient)
