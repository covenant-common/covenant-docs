"""View-layer matching for the agent network.

This is not a consensus rule and it does not gate EXECUTE. Nothing here is a
native reputation balance, a second marketplace ledger, or a paid rank.

The named rule set is ``network-match/0.15``. It is the view policy intended
to sit beside the combined ``covenant-native/0.15`` line. Callers opt in by
passing that rule set. Historical discovery defaults (relevance 60, PageRank
40, reputation 0) are unchanged in ``desire_discovery``.

Items 1–4 of the incentives note (profile view, ENDORSE commit payload,
L0–L4 roles, ``ECON_REWARD`` campaigns) belong to the agent-network branch
(bc-1bcb53a2). This module does not edit ``desire_discovery``,
``discovery_rank``, ``agent_network``, ``economics``, or ``tools/incentives.py``.
If that branch later exports ``wilson_lb_bps``, ``quality_weight`` is still
local because the reward campaign itself stays on the economics ops.

Scores are recomputed from receipts the caller already holds.
"""
from __future__ import annotations

import hashlib
import math
from copy import deepcopy
from math import isqrt

from covenant_language import contract_design as charters
from covenant_language import marketplace as market
from covenant_language.contract_sources import source, term

RULE_SET = 'network-match/0.15'
TAKE_BPS = 30  # illustrative cap from the incentives note; a view, not a schedule
SCORE_SCALE = 1_000_000
EXPLORATION_PERIOD = 8
AMBIGUOUS = {
    'UNFINALIZED_DRAFTING_PROMPTS',
    'TOPIC_NOT_ADDRESSED',
    'OPEN_INTERPRETIVE_QUESTION',
    'PRECEDENCE_SCOPE_OVERLAP_UNKNOWN',
    'SOURCE_RULE_DIVERGENCE',
}

# Levers kept after the seeded 228-agent ablation. Rejected, and not in this
# set: naive-lb (sybil deals rose), saved-search (no material gain once search
# was structured), rfq (no change once requirements matched), anti-concentration
# (precision fell, Gini did not).
ENABLED = frozenset({
    'structured', 'trust-lb', 'exploration', 'rate-limit',
    'draft-template', 'commit-reveal', 'portable',
})


def _rule(rule_set):
    if rule_set != RULE_SET:
        raise ValueError('MATCH_RULE_SET')


def wilson_lb_bps(k, n):
    """Floor of the Wilson lower bound in basis points. z = 1.96.

    Integer k and n. Returns 0 when there is no positive evidence. Matches the
    published table (99/100 → 9455, 3/3 → 4384, 30/30 → 8864) by truncation.
    """
    if type(k) is not int or type(n) is not int:
        raise ValueError('WILSON_TYPE')
    if n <= 0 or k <= 0 or k > n:
        return 0
    z2 = 38416  # z^2 * 10000 with z = 196/100
    # inside = k*(n-k)/n + z^2/4 = num/den
    num = 4 * 10000 * k * (n - k) + n * z2
    den = 4 * 10000 * n
    scale = 10 ** 18
    root = isqrt(num * scale // den)  # ≈ sqrt(inside) * 1e9
    # centre = k + z^2/2 - z*sqrt(inside); lb = centre / (n + z^2)
    # Work in millionths of a count so the subtraction stays integral.
    million = 10 ** 6
    # root ≈ sqrt(inside) * 1e9, so z*sqrt in millionths is 196*root/1e5.
    centre = k * million + (z2 * million) // 20000 - (196 * root) // 100_000
    denom = n * million + (z2 * million) // 10000
    if centre <= 0 or denom <= 0:
        return 0
    return centre * 10000 // denom


def wilson_lb_bps_half(kept, late, n):
    """KEPT counts 1 and KEPT_LATE counts 1/2, then the same lower bound."""
    if type(kept) is not int or type(late) is not int or type(n) is not int:
        raise ValueError('WILSON_TYPE')
    if n <= 0 or kept < 0 or late < 0 or kept + late > n:
        return 0
    # Evaluate at k = kept + late/2 by doubling the table formula's inputs
    # through the integer bound on 2k/2n and correcting with a one-step
    # interpolation between floor(k) and ceil(k). Both ends are integer.
    twice = kept * 2 + late
    if twice <= 0:
        return 0
    low = twice // 2
    if twice % 2 == 0:
        return wilson_lb_bps(low, n)
    # Half step: average the two integer bounds. Still within 1 bp of the
    # real half-count on the checked range; the average is truncated.
    high = low + 1
    if high > n:
        return wilson_lb_bps(low, n)
    return (wilson_lb_bps(low, n) + wilson_lb_bps(high, n)) // 2


def log2_q8(value):
    """floor(log2(1+value) * 256). value is a non-negative integer."""
    if type(value) is not int or value < 0:
        raise ValueError('LOG_VALUE')
    n = 1 + value
    il = n.bit_length() - 1
    if il >= 60:
        mant = n >> (il - 60)
    else:
        mant = n << (60 - il)
    base = 1 << 60
    frac = 0
    x = mant
    for _ in range(8):
        x = x * x // base
        if x >= 2 * base:
            frac = (frac << 1) | 1
            x //= 2
        else:
            frac <<= 1
    return (il << 8) + frac


def trust_neff(weights):
    """Inverse Simpson index, floored. Zero-trust weights contribute nothing."""
    clean = [w for w in weights if type(w) is int and w > 0]
    total = sum(clean)
    if total <= 0:
        return 0
    squares = sum(w * w for w in clean)
    if squares <= 0:
        return 0
    return total * total // squares


def quality_weight(deals, kept, late, n, repeat_num, repeat_den):
    """Log value × min(N_eff, 20) × outcome LB × (1 + repeat/2).

    Each deal is ``{value, trust_bps, counterparty}``. ``trust_bps`` is
    min(1, tau/tau*) in basis points. Zero trust adds neither value nor
    diversity, which is what drives a sybil ring to 0. Counterparties are
    grouped before N_eff, so a wash pair cannot look like a crowd.
    ``repeat_num/repeat_den`` is the repeat-binding rate. The result is an
    integer view, not an ``ECON_REWARD`` campaign.
    """
    if type(repeat_num) is not int or type(repeat_den) is not int or repeat_den <= 0:
        raise ValueError('REPEAT')
    if repeat_num < 0 or repeat_num > repeat_den:
        raise ValueError('REPEAT')
    logs = 0
    grouped = {}
    for deal in deals:
        trust = deal['trust_bps']
        value = deal['value']
        if type(trust) is not int or type(value) is not int or trust <= 0 or value < 0:
            continue
        logs += log2_q8(value)
        weight = value * min(trust, 10000) // 10000
        if weight <= 0:
            continue
        party = deal['counterparty']
        grouped[party] = grouped.get(party, 0) + weight
    neff = min(trust_neff(list(grouped.values())), 20)
    lb = wilson_lb_bps_half(kept, late, n)
    bonus_num = 2 * repeat_den + repeat_num
    bonus_den = 2 * repeat_den
    return logs * neff * lb * bonus_num // (10000 * bonus_den)


def blend_scores(rows, lower_bounds, weights=(50, 20, 30)):
    """Re-rank discover() rows. Relevance and PageRank are kept; the third
    component is the outcome lower bound, not the opinion score and not a fee.
    """
    rel_w, rank_w, lb_w = weights
    if rel_w + rank_w + lb_w <= 0:
        raise ValueError('MATCH_WEIGHTS')
    ranked = []
    for row in rows:
        parts = row['components_ppm']
        bound = lower_bounds.get(_target_id(row), 0)
        lb_ppm = SCORE_SCALE * bound // 10000
        score = (parts['relevance'] * rel_w + parts['pagerank'] * rank_w + lb_ppm * lb_w) // (rel_w + rank_w + lb_w)
        ranked.append({
            'target': deepcopy(row['target']),
            'score_ppm': score,
            'components_ppm': {
                'relevance': parts['relevance'],
                'pagerank': parts['pagerank'],
                'outcome_lb': lb_ppm,
            },
            'payment_ignored': True,
        })
    ranked.sort(key=lambda row: (-row['score_ppm'], _target_id(row)))
    return ranked


def _target_id(row):
    return row['target']['id']


def _beta_sample(k, n, seed, agent):
    """Deterministic Thompson draw from Beta(k+1, n-k+1), shapes ≥ 1."""
    def uniform(i):
        raw = hashlib.sha256(('beta:%s:%s:%s' % (seed, agent, i)).encode()).digest()
        return (int.from_bytes(raw[:8], 'big') + 1) / float(2 ** 64 + 1)

    def normal(i):
        u1 = uniform(i)
        u2 = uniform(i + 1)
        return math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)

    def gamma(shape, salt):
        # Marsaglia-Tsang, shape ≥ 1.
        d = shape - 1.0 / 3.0
        c = 1.0 / math.sqrt(9.0 * d)
        step = 0
        while True:
            x = normal(salt + step)
            v = (1.0 + c * x) ** 3
            step += 2
            if v <= 0:
                continue
            u = uniform(salt + step)
            step += 1
            if math.log(u) < 0.5 * x * x + d * (1.0 - v + math.log(v)):
                return d * v
            if step > 80:
                return d

    a = k + 1
    b = max(n - k, 0) + 1
    left = gamma(a, 0)
    right = gamma(b, 100)
    total = left + right
    if total <= 0:
        return 0.0
    return left / total


def clean_newcomer(trusted_settled, untrusted_deals, defaults):
    """Exploration is for a short, clean trust-weighted record.

    A ring that already has several zero-trust or wash deals is not a
    newcomer, even when those deals are ignored by the lower bound.
    """
    if defaults > 0 or untrusted_deals >= 3:
        return False
    return trusted_settled <= 3


def exploration_choice(candidates, seed):
    """Deterministic Thompson pick. The seed makes the draw auditable."""
    if not candidates:
        return None
    return max(candidates, key=lambda row: (_beta_sample(row['k'], row['n'], seed, row['id']), row['id']))


def reserve_exploration(ranked_ids, candidates, seed, period=EXPLORATION_PERIOD):
    """Put one clean newcomer in every 8th result slot.

    ``candidates`` is a list of ``{id, k, n}`` whose outcomes so far are clean
    and who are still L0/L1 (caller-defined). The chosen id is the greatest
    Thompson sample. The choice depends on the seed, not on a payment.
    """
    if period < 2:
        raise ValueError('EXPLORATION_PERIOD')
    ordered = list(ranked_ids)
    winner = exploration_choice(candidates, seed)
    if winner is None:
        return ordered
    picked = winner['id']
    ordered = [item for item in ordered if item != picked]
    if not ordered:
        return [picked]
    inserted = []
    cursor = 0
    for index in range(len(ordered) + 1):
        if (index + 1) % period == 0:
            inserted.append(picked)
        if cursor < len(ordered):
            inserted.append(ordered[cursor])
            cursor += 1
    if picked not in inserted:
        inserted.append(picked)
    return inserted


def admission_quota(settled, lower_bound_bps, defaults):
    """Quality-weighted listing quota. Newcomers get one listing, not zero.

    A provider who already defaulted, or whose lower bound is poor after a
    real sample, does not get to fill the 256-object catalog.
    """
    # One default cuts the quota to a single listing. It does not erase the
    # agent: a zero quota pushes buyers onto whoever is left, including rings.
    if settled <= 0 and defaults <= 0:
        return 1
    if defaults > 0 or (settled >= 3 and lower_bound_bps < 5000):
        return 1
    return 3


def admit_listings(listings, quota_of, limit=256):
    """Keep at most ``limit`` listings, highest quota first, then recency.

    ``listings`` items are ``{id, actor, recency}``. ``quota_of(actor)`` is
    the remaining quota. Stable and deterministic.
    """
    grouped = {}
    for row in sorted(listings, key=lambda item: (-item['recency'], item['id'])):
        grouped.setdefault(row['actor'], []).append(row)
    kept = []
    for actor in sorted(grouped):
        allowed = quota_of(actor)
        kept.extend(grouped[actor][:max(0, allowed)])
    kept.sort(key=lambda item: (-item['recency'], item['id']))
    return kept[:limit]


def diversify(ranked_ids, deal_counts, cap_bps=1500):
    """Push providers who already hold more than ``cap_bps`` of this epoch's
    deals below the providers who are under the cap. Order inside each band
    stays as ranked. A view, not a penalty on price elsewhere.
    """
    total = sum(deal_counts.values())
    if total <= 0:
        return list(ranked_ids)
    under, over = [], []
    for agent in ranked_ids:
        share = 10000 * deal_counts.get(agent, 0) // total
        (over if share > cap_bps else under).append(agent)
    return under + over


def commit_review(subject, rater, result, salt):
    """Hidden review. The digest does not contain the result in the clear."""
    if result not in {'POSITIVE', 'NEGATIVE', 'UNKNOWN'}:
        raise ValueError('REVIEW_RESULT')
    body = '%s|%s|%s|%s' % (salt, subject, rater, result)
    return hashlib.sha256(body.encode()).hexdigest()


def reveal_review(commitments, subject, left, right, epoch, deadline):
    """Reveal only after both commits exist or the window has closed.

    Returns the revealed pair, or None while the review must stay hidden.
    A revealed result is whatever was committed; this function does not
    rewrite it.
    """
    pair = (commitments.get((subject, left)), commitments.get((subject, right)))
    if pair[0] is None or pair[1] is None:
        if epoch < deadline:
            return None
    revealed = []
    for rater, row in ((left, pair[0]), (right, pair[1])):
        if row is None:
            continue
        check = commit_review(subject, rater, row['result'], row['salt'])
        if check != row['digest']:
            raise ValueError('REVIEW_COMMIT_MISMATCH')
        revealed.append({'rater': rater, 'result': row['result']})
    return revealed


def protocol_fee(value, rule_set=RULE_SET):
    _rule(rule_set)
    if type(value) is not int or value < 0:
        raise ValueError('FEE_VALUE')
    return value * TAKE_BPS // 10000


def draft_from_match(title, context, agreement, parties, price, skill, sources_extra=None, graded=True):
    """Operative charter for a match: every core topic, an example, a grade scale.

    External information sources (a delivery receipt, an oracle) are passed
    through ``sources_extra`` and stay references. Signing this charter is
    not execution.
    """
    note = source(
        'COMMERCIAL',
        'Sandbox match note for %s' % skill,
        '2026',
        'https://example.invalid/match-note',
    )
    note['digest'] = hashlib.sha256(note['citation'].encode()).hexdigest()
    sources = {'match_note': note}
    if sources_extra:
        for alias, row in sources_extra.items():
            sources[alias] = deepcopy(row)
    source_names = tuple(sources)
    example = 'Example: a %s delivery that meets the written checks is grade A.' % skill
    grades = (
        'Grade A pays 100 percent of %s. Grade B pays 80 percent. '
        'Grade C is reworked once or released. A missed receipt is not grade A.'
        % price
    )
    topics = {
        'formation': 'The buyer and the provider assent to this exact charter and the referenced agreement. No other message is assent.',
        'subject': 'The work is %s. Quantity and the finished artifact are the ones named in the match.' % skill,
        'performance': 'Deliver by the agreed deadline. %s %s' % (example, grades if graded else ''),
        'economics': 'The price is %s units. The view-layer take, when the rule set is on, is separate and declared before assent. This charter moves no funds.' % price,
        'disclosure': 'Each party states material limits of the work before assent. A signature is not a warranty of unstated quality.',
        'interpretation': 'Ordinary meaning, then this grade scale, then the named external sources. Ambiguity is resolved by the named arbiter, not by silence.',
        'evidence': 'Settlement uses the named sources. A delivery confirmation or oracle value counts only for the fact it states.',
        'remedies': 'Notice, one correction window, then the grade scale. A lost dispute refunds the unpaid grade gap.',
        'procedure': 'Either party may challenge within one epoch. The arbiter sees both reveals and writes a reason.',
        'privacy': 'Values in public views are bands. Confidential sources stay confidential unless that party opted in.',
    }
    terms = {}
    for topic, meaning in topics.items():
        terms['op.' + topic] = term(topic, meaning, *source_names, kind='OPERATIVE_RULE')
    features = {name: 'NOT_APPLICABLE' for name in charters.FEATURES}
    return charters.draft(
        title, context, agreement, parties,
        sources=sources, terms=terms, features=features,
    )


def ambiguous_codes(review):
    return [issue['code'] for issue in review['issues'] if issue['code'] in AMBIGUOUS]


def prepare_quote(listing_record, buyer, context):
    """Real marketplace quote. Assent and payment stay on their own gates."""
    return market.quote(listing_record, buyer, context)


def counter_price(quoted, new_amount):
    """One counter on the payment leg. Fresh assent is still required."""
    give = deepcopy(quoted['order']['data']['give'])
    if not give:
        raise ValueError('MATCH_NO_PRICE_LEG')
    give[0] = deepcopy(give[0])
    give[0]['amount'] = new_amount
    return market.counter(quoted['order'], {'give': give})
