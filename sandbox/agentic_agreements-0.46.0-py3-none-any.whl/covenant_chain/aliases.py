"""Console-script names kept from historical docs.

Each name answers ``--help`` and refuses an unknown flag with ``ARGUMENTS``.
They do not start a node. ``covenant-peer`` remains the documented name of the
gateway, ``covenant-validator`` of the chain process, and ``covenant-verify``
of the language checker.
"""
import sys

NAMES = (
    'covenant-peer',
    'covenant-validator',
    'covenant-verify',
    'covenant-state',
    'covenant-py',
    'covenant-common-language',
)


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] in ('-h', '--help'):
        sys.stdout.write('ALIAS\n')
        return 0
    sys.stderr.write('ARGUMENTS\n')
    return 2


def peer():
    raise SystemExit(main())


def validator():
    raise SystemExit(main())


def verify():
    raise SystemExit(main())


def state():
    raise SystemExit(main())


def py():
    raise SystemExit(main())


def common_language():
    raise SystemExit(main())


if __name__ == '__main__':
    raise SystemExit(main())
