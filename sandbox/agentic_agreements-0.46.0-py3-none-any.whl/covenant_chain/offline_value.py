"""Offline spending limits backed by an existing bond. No second stake ledger.

covenant-native/0.15 has no market profile, so the bond is `ECON_BOND_LOCK`
into `bond_escrow`. `market.py` `STAKE_OPEN` stays on the market profile.
A spend inside the allowance moves nothing. The excess, and a double-spend,
are paid from that bond by `economics.apply`.
"""
from .crypto import integer, need

LABEL = 'COVENANT-OFFLINE-SPEND-0.1'
PARAMETERS = {'bond_operation': 'ECON_BOND_LOCK', 'market_stake_on_0_15': False, 'limit_at_most_bond': True}


def excess(amount, remaining):
    integer(amount)
    integer(remaining)
    if amount <= remaining:
        return 0
    return amount - remaining


def slash_amount(bond):
    """The losing payee is paid first, up to the bond still locked."""
    integer(bond)
    return bond


def conflicts(first, second):
    need(type(first) is dict and type(second) is dict, 'OFFLINE_STATEMENT')
    return (first.get('device') == second.get('device') and first.get('serial') == second.get('serial')
            and first != second)
