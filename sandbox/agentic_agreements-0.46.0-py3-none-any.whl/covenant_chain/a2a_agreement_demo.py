"""Disposable from-scratch agreement, execution, recovery and evidence review.

No external connection, real resource transfer, payment or adjudication occurs.
Run the comparison tool for actual authenticated local HTTP/official SDK checks.
"""
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from . import a2a_agreement_gate as g
from .agent_exchange_tools import ExchangeTools


def run():
    tools = ExchangeTools()

    def tool(action, **parameters):
        return tools.call('covenant_a2a_agreement', {'action': action, 'parameters': parameters})

    customer, contractor = Ed25519PrivateKey.generate(), Ed25519PrivateKey.generate()
    caller = g.public_key(customer)
    now = int(time.time())
    prepared = tool('prepare_request', params={'tenant': 'synthetic-shop', 'message': {
        'messageId': 'one-stock-report', 'role': 'ROLE_USER', 'parts': [{'data': {
            'operation': 'stock.report', 'payload': {'need': 'A small shop needs one stock report.'},
            'resources': [{'resource': 'DEMO_CREDIT', 'quantity': 20, 'unit': 'atomic'}]}}]}})
    grant = {'version': g.GRANT_VERSION, 'service': 'shop-reports', 'policy': 'shop-policy-1',
        'tenant': 'synthetic-shop', 'caller': caller, 'operations': ['stock.report'],
        'requests': [prepared['request']], 'resources': prepared['resources'],
        'valid_from': now, 'valid_until': now + 600, 'revoked': False}
    grant_ref = g.grant_id(grant)
    drafted = tool('draft', params=prepared['params'], service='shop-reports', policy_id='shop-policy-1',
        caller=caller, grant=grant_ref, required_signers=sorted([caller, g.public_key(contractor)]),
        valid_from=now, valid_until=now+600, nonce='6'*64,
        terms='One stock report. Customer acceptance and 20 demo credits remain separate obligations. '
              'Retain the case for a separately authorized dispute procedure.')
    # Each party separately reviews and explicitly signs in its own custody.
    # The drafting tools never receive either private key.
    assents = [g.assent(drafted['agreement'], key) for key in (customer, contractor)]
    attached = tool('attach', params=drafted['params'], agreement=drafted['agreement'], assents=assents)
    state = {'revision': 1, 'now': now, 'agreements': {
        drafted['agreement_id']: deepcopy(drafted['agreement'])},
        'grants': {grant_ref: grant}, 'revoked_agreements': []}
    effects = []

    def owner_state():
        snapshot = deepcopy(state)
        snapshot['now'] = int(time.time())
        return snapshot

    def execute(verified):
        effects.append(verified['request'])
        return {'delivery': 'SYNTHETIC_REPORT', 'acceptance': 'AWAITING_CUSTOMER',
                'payment': 'NOT_EXECUTED', 'remaining': ['customer acceptance', '20 demo credits']}

    with TemporaryDirectory() as temporary:
        directory = Path(temporary)/'private-custody'
        kwargs = {'service': 'shop-reports', 'policy_id': 'shop-policy-1',
                  'owner_state': owner_state, 'execute': execute, 'receipt_key': contractor}
        gate = g.AgreementGate(directory, **kwargs)
        try:
            first = gate.dispatch('SendMessage', attached['params'], caller=caller,
                                 active_extensions=[g.EXTENSION_URI])
            case = gate.export_evidence(first['task']['id'], caller=caller,
                tenant='synthetic-shop', active_extensions=[g.EXTENSION_URI])
        finally:
            gate.close()
        recovered = g.AgreementGate(directory, **kwargs)
        try:
            replay = recovered.dispatch('SendMessage', attached['params'], caller=caller,
                                        active_extensions=[g.EXTENSION_URI])
        finally:
            recovered.close()
    review = tool('verify_evidence', evidence=case, expected_agreement=drafted['agreement'],
                  expected_receipt_signer=g.public_key(contractor))
    assert first == replay and len(effects) == 1
    assert not review['payment_verified'] and not review['external_truth_verified']
    return {'passed': True, 'scope': 'DISPOSABLE_LOCAL_OWNER_DEMO_NO_NETWORK_OR_FUNDS',
        'human_need': 'A small shop wants one report, an exact promise and recovery without duplicate work.',
        'agreement': drafted['agreement_id'], 'request': prepared['request'],
        'all_required_parties_explicitly_signed': True, 'executions_across_restart': len(effects),
        'same_result_after_restart': first == replay, 'independent_offline_review': review,
        'remaining_obligations': ['customer acceptance', '20 demo credits'],
        'payment_executed': False, 'actual_arbitration_exercised': False,
        'private_keys_exported_or_received_by_tools': False}


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True, indent=2))
