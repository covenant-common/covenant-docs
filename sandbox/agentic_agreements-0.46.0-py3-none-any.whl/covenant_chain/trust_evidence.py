"""External trust evidence bound to a did:aap key only by that key's own signature.

AAP application profile ``covenant-evidence-binding/0.1`` and the shared parts of the
trust-evidence adapters (web_bot_auth, kya_tokens, ack_identity, agent_pay and the ANS
and Kleros readers):

* Each adapter verifies one external artefact against keys or issuers the owner adopted
  and returns EVIDENCE: a labelled, content-addressed statement by that issuer. Nothing
  is fetched, clocks are the caller's, and an artefact never nominates its own verifier.
* Evidence concerns a did:aap account only through that account's own signature.
  SIGNED_BY_AAP_KEY: the artefact itself is signed by the account's Ed25519 key (an RFC
  9421 request signature by the agent key; an ACK-ID credential whose subject is the
  did:key of that key). AAP_BINDING_SIGNATURE: the account key signed a BINDING that
  names the artefact's kind, issuer, subject and SHA-256 inside a window. A binding that
  names another holder key (an HTTP signing key, an agent DID key) also carries that
  key's possession signature over the same bytes, so a public artefact cannot be claimed
  by another account.
* Compact JWS (RFC 7515 section 7.1) under owner-adopted JWKs for the JWT-shaped
  artefacts: EdDSA (RFC 8037 section 3.1), ES256 and ES384 (RFC 7518 section 3.4), RS256
  (3.3), PS512 (3.5) and ES256K (RFC 8812 section 3.2). ``jku``, ``x5u``, ``x5c`` and
  ``jwk`` never select a key, and ``crit`` is refused.
* Evidence never grants authority, pays, releases or assents: ``authority_granted`` and
  ``execution_authorized`` are always false. AAP's own signed terms and ladder decide.
"""
from copy import deepcopy
import hashlib
import json
import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from .crypto import canonical, digest, integer, key, need, public_key, sign, verify
from . import http_signatures as httpsig
from . import interop_codec as codec

VERSION = 'covenant-evidence-binding/0.1'
LABEL = 'COVENANT-EVIDENCE-BINDING-0.1'
EVIDENCE = 'urn:aap:trust-evidence:0.1'
EVIDENCE_LABEL = b'AAP-TRUST-EVIDENCE-0.1\x00'
FIELDS = 'version did key kind issuer subject evidence_sha256 holder audience issued_at expires nonce'
KINDS = ('HTTP_SIGNATURE_KEY', 'KYA_TOKEN', 'ACK_ID_CREDENTIAL', 'AGENT_PAY_SIGNAL', 'AGENTIC_TOKEN_REFERENCE',
         'ANS_REGISTRATION')
JOSE = {'EdDSA': 'ed25519', 'ES256': 'ecdsa-p256-sha256', 'ES384': 'ecdsa-p384-sha384', 'RS256': 'rsa-v1_5-sha256',
        'PS512': 'rsa-pss-sha512', 'ES256K': 'ES256K'}
IGNORED_HEADER_KEYS = ('jku', 'x5u', 'x5c', 'jwk')
MAX_TOKEN = 16384
MAX_BINDINGS = 16
TEXT = re.compile(r'[ -~]{1,512}\Z')

REMEDIATION = {
    'EVIDENCE_BINDING_FIELDS': 'Use the exact binding fields from describe().',
    'EVIDENCE_BINDING_PROFILE': 'Use version covenant-evidence-binding/0.1 and a kind from describe().kinds.',
    'EVIDENCE_BINDING_DID': 'Name the did:aap (or did:covenant) of the same account key that signs the binding.',
    'EVIDENCE_BINDING_TEXT': 'issuer, subject and audience are printable ASCII of 1 to 512 characters.',
    'EVIDENCE_BINDING_WINDOW': 'Use integer times with issued_at before expires, and present the binding inside them.',
    'EVIDENCE_BINDING_SIGNATURE': 'The binding must be signed by the AAP key it names.',
    'EVIDENCE_BINDING_POSSESSION': 'A binding naming a holder key needs {alg, jwk, signature} by that key over the binding bytes.',
    'EVIDENCE_BINDING_MISMATCH': 'The binding names another artefact, kind, issuer, subject or audience.',
    'EVIDENCE_CLAIMS': 'Evidence claims are a bounded JSON object chosen by the adapter.',
    'JWS_FORMAT': 'Supply one compact JWS (three base64url parts) of at most 16 KiB with a JSON header and payload.',
    'JWS_HEADER': 'The JWS header needs alg (and kid when several keys are adopted); crit is refused.',
    'JWS_ALGORITHM': 'Use an algorithm this verifier accepts for the adopted key.',
    'JWS_KEY': 'The kid names no adopted key; adopt the issuer keys yourself, a token cannot nominate them.',
    'JWS_SIGNATURE': 'The JWS signature does not verify under the adopted key.',
    'HTTPSIG_KEY':
        'Adopt public JWKs (OKP Ed25519, EC P-256/P-384, RSA 2048-8192) or 64-hex AAP keys; no private '
        'members.',
}


def remediation(code):
    return REMEDIATION.get(code, httpsig.remediation(code))


def _text(value, code='EVIDENCE_BINDING_TEXT'):
    need(type(value) is str and TEXT.fullmatch(value) is not None, code)
    return value


def did_key(aap_key):
    """The did:key of an Ed25519 AAP key (W3C did:key, Multikey 0xed01), as ACK-ID and ANP name agents."""
    return codec.did_key(aap_key)


DID_PREFIXES = ('aap', 'covenant')  # As covenant_chain.scale.identity: both spellings name one account.


def aap_did(account, chain):
    """``did:aap:<chain>:<account>`` when the caller names its chain; None otherwise."""
    if chain is None:
        return None
    key(account); key(chain)
    return 'did:aap:' + chain + ':' + account


def resolve_did(identifier):
    """(chain, account) of did:aap or did:covenant, read here so this L0 module needs no L4 import."""
    parts = identifier.split(':') if type(identifier) is str else []
    need(len(parts) == 4 and parts[0] == 'did' and parts[1] in DID_PREFIXES, 'EVIDENCE_BINDING_DID')
    key(parts[2]); key(parts[3])
    return parts[2], parts[3]


# The binding record.

def _validate(body):
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'EVIDENCE_BINDING_FIELDS')
    need(body['version'] == VERSION and body['kind'] in KINDS, 'EVIDENCE_BINDING_PROFILE')
    try:
        _, account = resolve_did(body['did'])
    except ValueError:
        raise ValueError('EVIDENCE_BINDING_DID') from None
    need(account == body['key'], 'EVIDENCE_BINDING_DID')
    _text(body['issuer']); _text(body['subject']); _text(body['audience'])
    key(body['evidence_sha256']); key(body['nonce'])
    need(body['holder'] is None or (type(body['holder']) is str and re.fullmatch(r'[A-Za-z0-9_-]{43}', body['holder'])),
         'EVIDENCE_BINDING_FIELDS')
    integer(body['issued_at']); integer(body['expires'])
    need(body['issued_at'] < body['expires'], 'EVIDENCE_BINDING_WINDOW')
    return body


def binding_id(body):
    return digest(LABEL, _validate(body))


def binding(did, kind, issuer, subject, evidence_sha256, audience, issued_at, expires, nonce, holder=None):
    """Prepare an unsigned binding; the AAP key named by ``did`` signs it, and a named holder key co-signs."""
    try:
        account = resolve_did(did)[1]
    except ValueError:
        raise ValueError('EVIDENCE_BINDING_DID') from None
    body = {'version': VERSION, 'did': did, 'key': account, 'kind': kind, 'issuer': issuer, 'subject': subject,
            'evidence_sha256': evidence_sha256, 'holder': holder, 'audience': audience, 'issued_at': issued_at,
            'expires': expires, 'nonce': nonce}
    return {'id': binding_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'possession_payload': possession_payload(body).hex() if holder is not None else None,
            'required_signers': [account], 'signature_created': False, 'execution_authorized': False}


def possession_payload(body):
    """Bytes a holder key signs: the same domain-separated message the AAP key signs."""
    return LABEL.encode('ascii') + b'\0' + canonical(_validate(body))


def sign_binding(body, private_key):
    """Explicit local owner action with the AAP key. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body['key'], 'EVIDENCE_BINDING_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}


def _possession(body, proof):
    need(type(proof) is dict and set(proof) == {'alg', 'jwk', 'signature'} and type(proof['alg']) is str,
         'EVIDENCE_BINDING_POSSESSION')
    try:
        rows = httpsig.adopt_keys([proof['jwk']])
        need(len(rows) == 1 and rows[0]['thumbprint'] == body['holder'], 'EVIDENCE_BINDING_POSSESSION')
        need(JOSE.get(proof['alg']) == rows[0]['algorithm'], 'EVIDENCE_BINDING_POSSESSION')
        httpsig.verify_raw(rows[0]['algorithm'], rows[0], possession_payload(body),
                           codec.b64url_decode(proof['signature'], 1024))
    except ValueError:
        raise ValueError('EVIDENCE_BINDING_POSSESSION') from None


def open_binding(record, now=None):
    """Check the AAP signature (and a named holder's possession signature); returns the binding id and body."""
    need(type(record) is dict and set(record) in ({'body', 'signature'}, {'body', 'signature', 'possession'}),
         'EVIDENCE_BINDING_FIELDS')
    body = _validate(record['body'])
    try:
        verify(body['key'], LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('EVIDENCE_BINDING_SIGNATURE') from None
    if body['holder'] is not None:
        _possession(body, record.get('possession'))
    else:
        need('possession' not in record, 'EVIDENCE_BINDING_FIELDS')
    if now is not None:
        integer(now)
        need(body['issued_at'] <= now < body['expires'], 'EVIDENCE_BINDING_WINDOW')
    return {'id': digest(LABEL, body), 'body': deepcopy(body)}


# Compact JWS.

def jws(token, keys, algorithms, *, max_payload=8192):
    """Verify a compact JWS under one owner-adopted key; returns (header, payload, signing-input SHA-256, key row).

    The key is selected by ``kid`` among the adopted keys (or is the only one); header members that
    would name a key (jku, x5u, x5c, jwk) are ignored for selection, and ``crit`` is refused.
    """
    need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.count('.') == 2 and token.isascii(), 'JWS_FORMAT')
    head, body, signature = token.split('.')
    try:
        header = codec.parse(codec.b64url_decode(head, 2048), 2048, 4, 64)
        payload = codec.parse(codec.b64url_decode(body, max_payload), max_payload, 12, 2048)
        raw = codec.b64url_decode(signature, 1024)
    except ValueError:
        raise ValueError('JWS_FORMAT') from None
    need(type(header) is dict and type(payload) is dict, 'JWS_FORMAT')
    need(type(header.get('alg')) is str and 'crit' not in header and header.get('b64', True) is True, 'JWS_HEADER')
    need(header['alg'] in algorithms and header['alg'] in JOSE, 'JWS_ALGORITHM')
    rows = _jws_keys(keys)
    kid = header.get('kid')
    need(kid is None or type(kid) is str, 'JWS_HEADER')
    matches = [row for row in rows if (kid is None and len(rows) == 1) or (kid is not None and row['kid'] == kid)]
    need(len(matches) == 1, 'JWS_KEY')
    row = matches[0]
    need(row['algorithm'] == JOSE[header['alg']], 'JWS_ALGORITHM')
    message = (head + '.' + body).encode('ascii')
    try:
        if row['algorithm'] == 'ES256K':
            need(len(raw) == 64, 'JWS_SIGNATURE')
            der = encode_dss_signature(int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:], 'big'))
            row['secp256k1'].verify(der, message, ec.ECDSA(hashes.SHA256()))
        else:
            httpsig.verify_raw(row['algorithm'], row, message, raw)
    except (InvalidSignature, ValueError):
        raise ValueError('JWS_SIGNATURE') from None
    return header, payload, hashlib.sha256(message).hexdigest(), {k: v for k, v in row.items() if k != 'secp256k1'}


def _secp256k1(jwk):
    need(not httpsig.PRIVATE_MEMBERS & set(jwk), 'HTTPSIG_KEY')
    try:
        x, y = codec.b64url_decode(jwk.get('x'), 32), codec.b64url_decode(jwk.get('y'), 32)
        need(len(x) == 32 and len(y) == 32, 'HTTPSIG_KEY')
        public = ec.EllipticCurvePublicNumbers(int.from_bytes(x, 'big'), int.from_bytes(y, 'big'), ec.SECP256K1()).public_key()
    except ValueError:
        raise ValueError('HTTPSIG_KEY') from None
    members = {'crv': 'secp256k1', 'kty': 'EC', 'x': jwk['x'], 'y': jwk['y']}
    return {'kid': jwk.get('kid'), 'thumbprint': codec.b64url(hashlib.sha256(codec.jcs(members)).digest()),
            'jwk': members, 'algorithm': 'ES256K', 'aap_key': None, 'secp256k1': public}


def _jws_keys(keys):
    rows = keys.get('keys') if type(keys) is dict else keys
    need(type(rows) in (list, tuple) and 0 < len(rows) <= httpsig.MAX_KEYS, 'JWS_KEY')
    plain = [row for row in rows if not (type(row) is dict and row.get('crv') == 'secp256k1')]
    out = httpsig.adopt_keys(plain) if plain else []
    out += [_secp256k1(row) for row in rows if type(row) is dict and row.get('crv') == 'secp256k1']
    return out


# Evidence.

def _claims(value):
    try:
        raw = codec.jcs(value)
    except ValueError:
        raise ValueError('EVIDENCE_CLAIMS') from None
    need(type(value) is dict and len(raw) <= 16384, 'EVIDENCE_CLAIMS')
    return json.loads(raw)


def evidence(kind, source, issuer, subject, artefact_sha256, claims, checks, *, signed_by=None, chain=None,
             bindings=(), audience=None, now=None, key_bound=False):
    """A content-addressed evidence record and the did:aap accounts it is bound to by their own signatures.

    A binding names the same issuer and subject. For an artefact it names the artefact's SHA-256 and kind;
    with ``key_bound`` (a signature by an HTTP key, whose thumbprint is the subject) it is an
    HTTP_SIGNATURE_KEY binding whose holder is that key, so every message the key signs is attributed.
    """
    need(kind in KINDS + ('HTTP_SIGNATURE',), 'EVIDENCE_BINDING_PROFILE')
    _text(source); _text(issuer); _text(subject); key(artefact_sha256)
    record = {'profile': EVIDENCE, 'kind': kind, 'source': source, 'issuer': issuer, 'subject': subject,
              'artefact_sha256': artefact_sha256, 'claims': _claims(claims), 'checks': _claims(checks)}
    ident = hashlib.sha256(EVIDENCE_LABEL + codec.jcs(record)).hexdigest()
    bound, excluded = [], []
    if signed_by is not None:
        key(signed_by)
        bound.append({'key': signed_by, 'did': aap_did(signed_by, chain), 'basis': 'SIGNED_BY_AAP_KEY'})
    need(type(bindings) in (list, tuple) and len(bindings) <= MAX_BINDINGS, 'EVIDENCE_BINDING_FIELDS')
    for index, item in enumerate(bindings):
        try:
            opened = open_binding(item, now)
            body = opened['body']
            same = body['evidence_sha256'] == artefact_sha256 and body['kind'] == kind
            if key_bound:
                same = body['kind'] == 'HTTP_SIGNATURE_KEY' and body['holder'] == subject
            need(same and body['issuer'] == issuer and body['subject'] == subject
                 and (audience is None or body['audience'] == audience), 'EVIDENCE_BINDING_MISMATCH')
            if all(row['key'] != body['key'] for row in bound):
                bound.append({'key': body['key'], 'did': body['did'], 'basis': 'AAP_BINDING_SIGNATURE',
                              'binding': opened['id'], 'holder': body['holder']})
        except ValueError as error:
            code = str(error)
            excluded.append({'index': index, 'status': 'EXCLUDED',
                             'reason': code if code in REMEDIATION or code.startswith('HTTPSIG_') else 'EVIDENCE_BINDING_FIELDS'})
    # One artefact names one account: two accounts claiming it is surfaced, never resolved by order.
    status = 'CONFLICT' if len({row['key'] for row in bound}) > 1 else ('BOUND' if bound else 'NOT_BOUND')
    return {'id': ident, 'record': record, 'bound': bound, 'excluded': excluded,
            'status': status, 'weight': 'LABELLED_EVIDENCE_NOT_AUTHORITY',
            'world_truth': 'ISSUER_STATEMENT_NOT_VERIFIED_FACT', 'authority_granted': False, 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL, 'evidence': EVIDENCE,
            'binding_fields': FIELDS.split(), 'kinds': list(KINDS), 'jws_algorithms': list(JOSE),
            'bases': ['SIGNED_BY_AAP_KEY', 'AAP_BINDING_SIGNATURE'],
            'rule': 'EVIDENCE_CONCERNS_A_DID_AAP_ACCOUNT_ONLY_THROUGH_THAT_ACCOUNT_KEY_SIGNATURE',
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'authority_granted': False,
            'execution_authorized': False}
