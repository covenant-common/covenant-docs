"""Owner launch entry point: python -m covenant_chain.provider_replica_node.

Private config contains spec/member/key_file/token_file/directory/port/peers.
--initialize is only for a never-used validator key, never lost-storage recovery.
"""
import argparse
import os
from pathlib import Path
import signal
import threading
import time

from . import observability
from .agent_tools import decode
from .backup import refuse_pending_restore
from .crypto import exact, load_private, need
from .provider_replication import ProviderReplica
from .provider_replica_rpc import ReplicaService, fetch_peer_histories


def private_file(path):
    path = Path(path)
    need(not path.is_symlink() and path.is_file() and path.stat().st_mode & 0o077 == 0,'REPLICA_PRIVATE_CONFIGURATION')
    return path.read_text()


def arguments():
    """The replica's command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True); parser.add_argument('--initialize',action='store_true')
    observability.add_arguments(parser)
    return parser


def main():
    args = arguments().parse_args(); cfg = decode(private_file(args.config))
    exact(cfg,'spec member key_file token_file directory port peers')
    refuse_pending_restore(cfg['directory'])
    key = load_private(private_file(cfg['key_file'])); token = private_file(cfg['token_file']).strip()
    histories = []
    if args.initialize and not Path(cfg['directory'],'consensus.sqlite3').exists():
        histories = fetch_peer_histories(cfg['spec'],cfg['peers'],token)
        print('replica initialize: advisory peer scan cannot establish an unused key; latest intact signing storage remains required for recovery',flush=True)
    replica = ProviderReplica(cfg['directory'],cfg['spec'],cfg['member'],key,clock=lambda:int(time.time()),
                              initialize=args.initialize,base_timeout=.25,peer_histories=histories)
    service = None; stopping = threading.Event()
    def stop(*_): stopping.set()
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    try:
        service = ReplicaService(replica,peers=cfg['peers'],token=token,port=cfg['port']).start()
        observability.start(service.ops, args)
        print('replica ready '+cfg['member'],flush=True)
        stopping.wait()
    finally:
        if service is not None: service.close()
        replica.close()


if __name__ == '__main__': main()
