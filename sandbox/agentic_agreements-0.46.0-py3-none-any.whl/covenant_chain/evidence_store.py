"""Content-addressed bytes for a photo or video.

The envelope stores a hash. The bytes live here, in ordered chunks with one
XOR parity shard per stripe, so one missing shard in a stripe can be rebuilt.
This is not a network placement and it does not raise the inline draft,
private-evidence, or offline-seal caps: those objects never receive the file.
"""
import hashlib
import os
import stat
from pathlib import Path

from covenant_language.safe_io import atomic_write

from .crypto import canonical, digest, key, loads, need

VERSION = 'covenant-evidence-bytes/0.1'
LABEL = 'COVENANT-EVIDENCE-BYTES-0.1'
CHUNK = 65536
STRIPE = 8
CODE = 'XOR_PARITY_ONE_LOSS'
MAX_MEDIA = 512 * 1024 * 1024
MAX_THUMBNAIL = 32768


def _private(directory):
    directory = Path(directory)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(directory, 0o700)
    info = directory.stat()
    need(stat.S_ISDIR(info.st_mode) and not directory.is_symlink() and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'EVIDENCE_STORE_DIRECTORY')
    return directory


def _write(directory, name, raw):
    path = directory / name
    if path.exists():
        found = path.read_bytes()
        need(found == raw, 'EVIDENCE_SHARD')
        return
    atomic_write(path, raw, mode=0o600, exclusive=True, follow_symlinks=False)


def _read_exact(directory, name, nbytes, digest_hex):
    path = directory / name
    need(path.is_file() and not path.is_symlink(), 'EVIDENCE_SHARD')
    handle = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        raw = os.read(handle, nbytes + 1)
    finally:
        os.close(handle)
    need(len(raw) == nbytes and hashlib.sha256(raw).hexdigest() == digest_hex, 'EVIDENCE_SHARD')
    key(digest_hex)
    return raw


def _xor(parts):
    width = len(parts[0])
    out = bytearray(width)
    for part in parts:
        need(len(part) == width, 'EVIDENCE_SHARD')
        for index, byte in enumerate(part):
            out[index] ^= byte
    return bytes(out)


def _pad(raw, width):
    need(len(raw) <= width, 'EVIDENCE_SHARD')
    return raw + bytes(width - len(raw))


class EvidenceStore:
    def __init__(self, directory):
        self.directory = _private(directory)
        self.shards = _private(self.directory / 'shards')
        self.manifests = _private(self.directory / 'manifests')

    def put_file(self, path, media_type, thumbnail=None):
        source = Path(path)
        need(source.is_file() and not source.is_symlink(), 'EVIDENCE_MEDIA')
        handle = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            raw = os.read(handle, MAX_MEDIA + 1)
        finally:
            os.close(handle)
        need(len(raw) <= MAX_MEDIA, 'EVIDENCE_MEDIA_SIZE')
        return self.put_bytes(raw, media_type, thumbnail)

    def put_bytes(self, raw, media_type, thumbnail=None):
        need(type(raw) is bytes and 1 <= len(raw) <= MAX_MEDIA, 'EVIDENCE_MEDIA_SIZE')
        need(type(media_type) is str and 0 < len(media_type) <= 256 and all(32 <= ord(c) <= 126 for c in media_type), 'EVIDENCE_TEXT')
        chunks = [raw[index:index + CHUNK] for index in range(0, len(raw), CHUNK)]
        records = []
        for stripe, start in enumerate(range(0, len(chunks), STRIPE)):
            group = chunks[start:start + STRIPE]
            width = max(len(part) for part in group)
            padded = [_pad(part, width) for part in group]
            parity = _xor(padded)
            for offset, part in enumerate(group):
                digest_hex = hashlib.sha256(part).hexdigest()
                _write(self.shards, digest_hex, part)
                records.append({'index': start + offset, 'stripe': stripe, 'role': 'DATA', 'sha256': digest_hex, 'bytes': len(part)})
            parity_hash = hashlib.sha256(parity).hexdigest()
            _write(self.shards, parity_hash, parity)
            records.append({'index': start + len(group), 'stripe': stripe, 'role': 'PARITY', 'sha256': parity_hash, 'bytes': len(parity)})
        thumb = None
        if thumbnail is not None:
            need(type(thumbnail) is bytes and 1 <= len(thumbnail) <= MAX_THUMBNAIL, 'EVIDENCE_THUMBNAIL')
            digest_hex = hashlib.sha256(thumbnail).hexdigest()
            _write(self.shards, digest_hex, thumbnail)
            thumb = {'sha256': digest_hex, 'bytes': len(thumbnail), 'media_type': 'image/jpeg'}
        body = {'version': VERSION, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'media_type': media_type,
                'chunk_bytes': CHUNK, 'stripe': STRIPE, 'code': CODE, 'shards': records, 'thumbnail': thumb}
        canonical(body)
        manifest_id = digest(LABEL, body)
        _write(self.manifests, manifest_id, canonical(body))
        return {'manifest': manifest_id, 'sha256': body['sha256'], 'bytes': len(raw), 'media_type': media_type,
                'placement': 'ERASURE', 'thumbnail': thumb, 'envelope_bytes': False, 'execution_authorized': False}

    def manifest(self, manifest_id):
        key(manifest_id)
        path = self.manifests / manifest_id
        need(path.is_file() and not path.is_symlink(), 'EVIDENCE_MANIFEST')
        handle = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            raw = os.read(handle, 1_000_000)
        finally:
            os.close(handle)
        body = loads(raw)
        need(digest(LABEL, body) == manifest_id and body['version'] == VERSION and body['code'] == CODE, 'EVIDENCE_MANIFEST')
        return body

    def read(self, manifest_id):
        body = self.manifest(manifest_id)
        by_stripe = {}
        for row in body['shards']:
            by_stripe.setdefault(row['stripe'], []).append(row)
        parts = []
        for stripe in sorted(by_stripe):
            rows = by_stripe[stripe]
            data = [row for row in rows if row['role'] == 'DATA']
            parity = next(row for row in rows if row['role'] == 'PARITY')
            loaded = []
            missing = None
            for row in data:
                path = self.shards / row['sha256']
                if path.is_file():
                    loaded.append(_read_exact(self.shards, row['sha256'], row['bytes'], row['sha256']))
                else:
                    need(missing is None, 'EVIDENCE_SHARDS_MISSING')
                    missing = row
                    loaded.append(None)
            if missing is None:
                parts.extend(loaded)
                continue
            width = parity['bytes']
            parity_bytes = _read_exact(self.shards, parity['sha256'], parity['bytes'], parity['sha256'])
            present = [_pad(part, width) for part in loaded if part is not None]
            rebuilt = _xor([parity_bytes, *present])[:missing['bytes']]
            need(hashlib.sha256(rebuilt).hexdigest() == missing['sha256'], 'EVIDENCE_SHARD')
            _write(self.shards, missing['sha256'], rebuilt)
            for row, part in zip(data, loaded):
                parts.append(rebuilt if row is missing else part)
        raw = b''.join(parts)
        need(len(raw) == body['bytes'] and hashlib.sha256(raw).hexdigest() == body['sha256'], 'EVIDENCE_MEDIA')
        return raw

    def thumbnail(self, manifest_id):
        body = self.manifest(manifest_id)
        thumb = body['thumbnail']
        if thumb is None:
            return None
        return _read_exact(self.shards, thumb['sha256'], thumb['bytes'], thumb['sha256'])
