"""Offline metadata discovery above existing desire ranking.

This module interprets explicitly selected metadata formats. It does not query a
registry, fetch an Agent Card, install a package, run a tool, or adopt authority.
Records are a caller-selected query window, not the entirety of durable history.
Object dictionaries are pinned as canonical JSON; ``record_json`` preserves the
SHA256 of exact supplied UTF-8 bytes. Format support is normalization, not full
external-schema conformance or proof that any advertised service exists.
"""
from copy import deepcopy
import hashlib
import json
from urllib.parse import urlsplit

from covenant_language.agentic import canonical
from .crypto import key, need
from .desire_discovery import discover
from .voting import target, target_id

VERSION = 'covenant-request-discovery/0.1'
FORMATS = ('GENERIC', 'MCP_SERVER_JSON', 'MCP_REGISTRY_ENTRY', 'A2A_CARD', 'DIRECTORY_PROFILE')
MCP_SCHEMAS = (
    'https://static.modelcontextprotocol.io/schemas/2025-09-29/server.schema.json',
    'https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json',
)
MAX_RECORDS = 256
MAX_RECORD_BYTES = 65536
MAX_TOTAL_BYTES = 1000000
DEFAULT_WEIGHTS = {'relevance': 50, 'pagerank': 25, 'reputation': 25}


def _text(value, maximum, empty=False):
    need(type(value) is str and len(value.encode('utf-8')) <= maximum
         and (empty or bool(value)) and not any(ord(c) < 32 and c not in '\n\r\t' for c in value),
         'REQUEST_DISCOVERY_TEXT')
    return value


def _fields(value, allowed, required=()):
    need(type(value) is dict and set(required) <= set(value) <= set(allowed),
         'REQUEST_DISCOVERY_FIELDS')


def _hash(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + canonical(value)).hexdigest()


def _url(value):
    _text(value, 2048)
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        raise ValueError('REQUEST_DISCOVERY_URL') from None
    need(parsed.scheme in ('https', 'http') and parsed.hostname is not None
         and not parsed.username and not parsed.password and not parsed.fragment
         and not parsed.query and '\\' not in value and not any(c.isspace() for c in value)
         and (port is None or 1 <= port <= 65535), 'REQUEST_DISCOVERY_URL')
    return value


def _no_duplicate_keys(pairs):
    result = {}
    for name, value in pairs:
        need(name not in result, 'REQUEST_DISCOVERY_DUPLICATE_JSON_KEY')
        result[name] = value
    return result


def _input(wrapper, source, freshness):
    if type(wrapper) is dict and 'target' in wrapper:
        wrapper = {'format': 'GENERIC', 'record': wrapper}
    _fields(wrapper, ('format', 'record', 'record_json', 'source', 'freshness', 'expected_sha256'), ('format',))
    need(wrapper['format'] in FORMATS, 'REQUEST_DISCOVERY_FORMAT')
    need(('record' in wrapper) != ('record_json' in wrapper), 'REQUEST_DISCOVERY_RECORD')
    if 'record_json' in wrapper:
        raw = wrapper['record_json']
        need(type(raw) is str and len(raw.encode('utf-8')) <= MAX_RECORD_BYTES,
             'REQUEST_DISCOVERY_RECORD_SIZE')
        try:
            record = json.loads(raw, object_pairs_hook=_no_duplicate_keys,
                                parse_constant=lambda _: (_ for _ in ()).throw(ValueError('REQUEST_DISCOVERY_JSON')))
        except (json.JSONDecodeError, RecursionError, UnicodeError):
            raise ValueError('REQUEST_DISCOVERY_JSON') from None
        encoded = raw.encode('utf-8')
        basis = 'EXACT_SUPPLIED_UTF8_BYTES'
        canonical(record)
    else:
        record = deepcopy(wrapper['record'])
        encoded = canonical(record)
        basis = 'CANONICAL_JSON_OF_SUPPLIED_OBJECT'
    need(type(record) is dict and len(encoded) <= MAX_RECORD_BYTES, 'REQUEST_DISCOVERY_RECORD_SIZE')
    sha256 = hashlib.sha256(encoded).hexdigest()
    if 'expected_sha256' in wrapper:
        key(wrapper['expected_sha256'])
        need(wrapper['expected_sha256'] == sha256, 'REQUEST_DISCOVERY_SOURCE_PIN')
    return record, {
        'format': wrapper['format'], 'source_sha256': sha256, 'hash_basis': basis,
        'source': _text(wrapper.get('source', source), 256),
        'freshness': _text(wrapper.get('freshness', freshness), 256),
        'source_and_freshness': 'CALLER_ASSERTIONS_NOT_INDEPENDENTLY_CHECKED',
        'metadata_assurance': 'SELF_ASSERTED_NOT_PERFORMANCE_OR_AUTHORITY',
        'signature_verified': False,
    }, len(encoded)


def _generic(record):
    _fields(record, ('target', 'title', 'description', 'attributes', 'links'),
            ('target', 'title', 'description', 'attributes', 'links'))
    target(record['target'])
    _text(record['title'], 512)
    _text(record['description'], 4096, empty=True)
    need(type(record['attributes']) is dict and len(record['attributes']) <= 32,
         'REQUEST_DISCOVERY_ATTRIBUTES')
    need(type(record['links']) is list and len(record['links']) <= 64,
         'REQUEST_DISCOVERY_LINKS')
    for link in record['links']:
        target(link)
    return deepcopy(record)


def _mcp(record, entry):
    if entry:
        _fields(record, ('server', '_meta'), ('server',))
        need('_meta' not in record or type(record['_meta']) is dict, 'REQUEST_DISCOVERY_MCP_META')
        record = record['server']
    need(type(record) is dict and record.get('$schema') in MCP_SCHEMAS,
         'REQUEST_DISCOVERY_MCP_SCHEMA')
    for field in ('name', 'description', 'version'):
        _text(record.get(field), 4096 if field == 'description' else 256)
    _text(record.get('title', record['name']), 512)
    packages, remotes = record.get('packages', []), record.get('remotes', [])
    need(type(packages) is list and len(packages) <= 32 and type(remotes) is list
         and len(remotes) <= 32 and bool(packages or remotes), 'REQUEST_DISCOVERY_MCP_DISTRIBUTION')
    transports = set()
    for remote in remotes:
        need(type(remote) is dict and remote.get('type') in ('streamable-http', 'sse'),
             'REQUEST_DISCOVERY_MCP_REMOTE')
        _url(remote.get('url'))
        transports.add(remote['type'])
    for package in packages:
        need(type(package) is dict, 'REQUEST_DISCOVERY_MCP_PACKAGE')
        _text(package.get('registryType'), 80)
        _text(package.get('identifier'), 512)
        transport = package.get('transport')
        need(type(transport) is dict and transport.get('type') in ('stdio', 'streamable-http', 'sse'),
             'REQUEST_DISCOVERY_MCP_TRANSPORT')
        transports.add(transport['type'])
    return {'target': {'kind': 'mcp-server', 'id': _hash('COVENANT-MCP-METADATA-NAME-0.1', record['name'])},
            'title': record.get('title', record['name']), 'description': record['description'],
            'attributes': {'protocol': 'MCP', 'supports_mcp': True, 'family': 'tool', 'name': record['name'],
                           'release': record['version'], 'transports': sorted(transports)}, 'links': []}


def _a2a(record):
    from .a2a_connector import inspect_card
    info = inspect_card(canonical(record).decode('ascii'))
    # Existing inspection supports the A2A 1.0 supportedInterfaces card variant.
    # Unknown/required extensions are reported, never silently adopted.
    interfaces = record['supportedInterfaces']
    need(bool(interfaces), 'REQUEST_DISCOVERY_A2A_INTERFACES')
    urls = sorted({_url(row['url']) for row in interfaces})
    skills = record.get('skills', [])
    names = []
    for skill in skills:
        need(type(skill) is dict, 'REQUEST_DISCOVERY_A2A_SKILL')
        if 'name' in skill:
            names.append(_text(skill['name'], 256))
    description = record['description'] + (' ' + ' '.join(names) if names else '')
    need(len(description.encode('utf-8')) <= 4096, 'REQUEST_DISCOVERY_TEXT')
    return {'target': {'kind': 'a2a-agent', 'id': _hash('COVENANT-A2A-METADATA-ENDPOINTS-0.1', urls)},
            'title': _text(record['name'], 512), 'description': description,
            'attributes': {'protocol': 'A2A', 'supports_a2a': True, 'family': 'agent', 'release': record['version'],
                           'compatible': info['compatible'],
                           'required_extensions': info['unsupported_required_extensions']}, 'links': []}


def _directory(record, provenance):
    from .directory_network import open_document
    opened = open_document(record)
    need(opened['body']['kind'] == 'PROFILE', 'REQUEST_DISCOVERY_DIRECTORY_PROFILE')
    value = opened['body']['payload']
    protocols = (['MCP'] if value['mcp'] is not None else []) + (['A2A'] if value['a2a'] is not None else [])
    attributes = {'family': 'agent', 'capabilities': value['capabilities'], 'domain': value['domain'],
                  'availability': value['availability'], 'protocols': protocols,
                  'supports_mcp': value['mcp'] is not None, 'supports_a2a': value['a2a'] is not None}
    if len(protocols) == 1:
        attributes['protocol'] = protocols[0]
    provenance.update(signature_verified=True, signer=opened['body']['signer'],
                      signed_document_id=opened['id'], signature_meaning='AUTHORSHIP_NOT_PERFORMANCE_OR_AUTHORITY')
    return {'target': {'kind': 'agent', 'id': value['identity']}, 'title': value['name'],
            'description': ' '.join([value['summary'], *value['capabilities'],
                                     *[s['name'] for s in value['skills']]]),
            'attributes': attributes, 'links': []}


def describe():
    return {'version': VERSION, 'formats': list(FORMATS), 'supported_mcp_schemas': list(MCP_SCHEMAS),
            'external_schema_conformance': 'SUPPORTED_METADATA_PROJECTION_ONLY',
            'limits': {'records_per_query': MAX_RECORDS, 'bytes_per_record': MAX_RECORD_BYTES,
                       'total_source_bytes': MAX_TOTAL_BYTES},
            'history': 'CALLER_SELECTS_EXPLICIT_QUERY_WINDOW_NO_IMPLICIT_HISTORY_TRUNCATION',
            'record_shape': {'format': 'MCP_SERVER_JSON', 'record': 'EXACT_METADATA_OBJECT',
                             'source': 'CALLER_SELECTED_LABEL', 'freshness': 'CALLER_ASSERTED_UNCHECKED'},
            'exact_bytes': 'Use record_json instead of record; expected_sha256 optionally pins source bytes.',
            'reputation': 'EXISTING_OWNER_ADOPTED_NETWORK_AND_EXPLICIT_CONTEXT_ONLY',
            'default_weights': dict(DEFAULT_WEIGHTS),
            'default_reputation_component': 'CONTEXTUAL_AUTHENTICATED_OPINIONS_NOT_SETTLEMENT_OUTCOMES',
            'missing_reputation': 'EXISTING_RANKER_NEUTRAL_UNKNOWN_NOT_POSITIVE_PERFORMANCE',
            'conflicts': 'SAME_TARGET_DIFFERENT_SOURCE_BYTES_EXCLUDED_UNLESS_EXACT_PIN_SELECTED',
            'network_accessed': False, 'installed': False, 'execution_authorized': False,
            'blockchain_required': False, 'assent_created': False}


def from_directory(documents, *, source='OWNER_SELECTED_DIRECTORY_PAGE',
                   freshness='LOCAL_REPLICA_FRESHNESS_NOT_ESTABLISHED'):
    """Wrap one explicit document page, retaining every supplied PROFILE revision.

    Historical selection and pagination belong to the caller. This helper does
    not silently choose a latest revision, discard a fork, or invoke the legacy
    256-document collect admission rule. Every envelope is still verified here.
    """
    from .directory_network import open_document
    need(type(documents) is list and len(documents) <= MAX_RECORDS,
         'REQUEST_DISCOVERY_QUERY_WINDOW')
    _text(source, 256)
    _text(freshness, 256)
    records = []
    total = 0
    for envelope in documents:
        encoded = canonical(envelope)
        total += len(encoded)
        need(total <= MAX_TOTAL_BYTES, 'REQUEST_DISCOVERY_TOTAL_SIZE')
        opened = open_document(envelope)
        if opened['body']['kind'] == 'PROFILE':
            records.append({'format': 'DIRECTORY_PROFILE', 'record': deepcopy(envelope),
                            'source': source, 'freshness': freshness})
    return records


def catalog(records, *, source='CALLER_SUPPLIED', freshness='CALLER_ASSERTED_UNCHECKED',
            selected_pins=None, adopt_links=False):
    """Normalize an explicit bounded window; never discard older history silently."""
    need(type(records) is list and len(records) <= MAX_RECORDS, 'REQUEST_DISCOVERY_QUERY_WINDOW')
    need(type(adopt_links) is bool, 'REQUEST_DISCOVERY_ADOPT_LINKS')
    selected_pins = [] if selected_pins is None else selected_pins
    need(type(selected_pins) is list and len(selected_pins) <= MAX_RECORDS
         and all(type(pin) is str for pin in selected_pins)
         and len(selected_pins) == len(set(selected_pins)), 'REQUEST_DISCOVERY_SELECTED_PINS')
    for pin in selected_pins:
        key(pin)
    total, seen, order = 0, {}, []
    for wrapper in records:
        record, provenance, size = _input(wrapper, source, freshness)
        total += size
        need(total <= MAX_TOTAL_BYTES, 'REQUEST_DISCOVERY_TOTAL_SIZE')
        kind = provenance['format']
        if kind == 'GENERIC':
            obj = _generic(record)
        elif kind.startswith('MCP_'):
            obj = _mcp(record, kind == 'MCP_REGISTRY_ENTRY')
        elif kind == 'A2A_CARD':
            obj = _a2a(record)
        else:
            obj = _directory(record, provenance)
        # An unauthenticated numeric claim must not enter the existing ranker's
        # receipt-derived default outcome component. It remains source-pinned.
        omitted = []
        if 'outcome_lb_bps' in obj['attributes']:
            obj['attributes'].pop('outcome_lb_bps')
            omitted.append('outcome_lb_bps')
        if not adopt_links and obj['links']:
            omitted.append('links')
            obj['links'] = []
        provenance['not_adopted_for_ranking'] = omitted
        record_id = _hash('COVENANT-REQUEST-DISCOVERY-RECORD-0.1',
                          {'format': kind, 'source_sha256': provenance['source_sha256'], 'target': obj['target']})
        if record_id not in seen:
            seen[record_id] = {'record_id': record_id, 'object': obj, 'provenance': []}
            order.append(record_id)
        if provenance not in seen[record_id]['provenance']:
            seen[record_id]['provenance'].append(provenance)
    need(set(selected_pins) <= set(seen), 'REQUEST_DISCOVERY_UNKNOWN_PIN')
    groups = {}
    for item in seen.values():
        groups.setdefault(target_id(item['object']['target']), []).append(item)
    objects, candidates, conflicts = [], [], []
    for sid in sorted(groups):
        variants = sorted(groups[sid], key=lambda row: row['record_id'])
        chosen = [row for row in variants if row['record_id'] in selected_pins]
        need(len(chosen) <= 1, 'REQUEST_DISCOVERY_CONFLICTING_PINS')
        eligible = chosen if chosen else variants if len(variants) == 1 else []
        if len(variants) > 1:
            conflicts.append({'target': variants[0]['object']['target'],
                              'record_ids': [row['record_id'] for row in variants],
                              'selected': chosen[0]['record_id'] if chosen else None})
        for row in variants:
            row['status'] = 'SELECTED_METADATA' if row in eligible else 'CONFLICT_NOT_SELECTED'
            candidates.append(row)
        objects.extend(row['object'] for row in eligible)
    return {'version': VERSION, 'objects': objects, 'candidates': candidates, 'conflicts': conflicts,
            'input_records': len(records), 'unique_records': len(seen), 'source_bytes': total,
            'truncated': False, 'history_complete': False,
            'history_scope': 'EXACT_CALLER_SELECTED_QUERY_WINDOW', 'network_accessed': False,
            'execution_authorized': False, 'blockchain_required': False}


def search(goal, records, *, requirements=None, context=None, strict_requirements=False,
           network=None, group=None, trust_seeds=None, edges=None, seeds=None, weights=None,
           sponsored=None, opinion_events=None, selected_pins=None, adopt_links=False,
           source='CALLER_SUPPLIED', freshness='CALLER_ASSERTED_UNCHECKED'):
    """Rank metadata for a goal, with authority and effects remaining separate.

    Opinion events must already belong to the owner-adopted validated network;
    this argument is a checked reference list, never a route for new admission.
    The ranker uses that network's complete contextual snapshot, which is shown
    explicitly in the result. Sponsorship is displayed separately and never
    contributes graph edges, trust seeds, requirements, or organic scores.
    """
    _text(goal, 256, empty=True)
    selected = catalog(records, source=source, freshness=freshness,
                       selected_pins=selected_pins, adopt_links=adopt_links)
    opinion_events = [] if opinion_events is None else opinion_events
    need(type(opinion_events) is list and len(opinion_events) <= 256, 'REQUEST_DISCOVERY_OPINIONS')
    if opinion_events:
        need(network is not None, 'REQUEST_DISCOVERY_OPINION_NETWORK_REQUIRED')
        known = network.events()
        known_bytes = {canonical(event) for event in known.values()}
        for event in opinion_events:
            need(canonical(event) in known_bytes, 'REQUEST_DISCOVERY_OPINION_NOT_ADOPTED')
    desire = {'query': goal, 'context': context, 'requirements': {} if requirements is None else requirements,
              'strict_requirements': strict_requirements}
    # This is a new application selection policy, not a change to the existing
    # desire profile. Its 50/25/25 weighting intentionally selects the existing
    # ranker's authenticated-opinion path. No receipt-derived outcome lower
    # bound is imported or fabricated from external metadata.
    desire['weights'] = dict(DEFAULT_WEIGHTS) if weights is None else weights
    if trust_seeds:
        need(network is not None, 'REQUEST_DISCOVERY_TRUST_NETWORK_REQUIRED')
        desire['trust_seeds'] = trust_seeds
    elif trust_seeds is not None:
        need(type(trust_seeds) is list, 'REQUEST_DISCOVERY_TRUST_SEEDS')
    ranked = discover(selected['objects'], desire, edges=edges, seeds=seeds, network=network, group=group)
    candidates = {target_id(row['object']['target']): row for row in selected['candidates']
                  if row['status'] == 'SELECTED_METADATA'}
    for row in ranked['ranking'] + ranked['excluded']:
        metadata = candidates[target_id(row['target'])]
        row['record_id'] = metadata['record_id']
        row['provenance'] = deepcopy(metadata['provenance'])
        row['attributes_basis'] = 'METADATA_CLAIMS_NOT_INDEPENDENTLY_VERIFIED'
        row['lexical_match'] = row['components_ppm']['relevance'] > 0
    sponsored = [] if sponsored is None else sponsored
    need(type(sponsored) is list and len(sponsored) <= 16, 'REQUEST_DISCOVERY_SPONSORED')
    ads = []
    for ad in sponsored:
        _fields(ad, ('record_id', 'label'), ('record_id', 'label'))
        need(ad['record_id'] in {row['record_id'] for row in selected['candidates']},
             'REQUEST_DISCOVERY_SPONSORED_PIN')
        ads.append({'record_id': ad['record_id'], 'label': _text(ad['label'], 256),
                    'sponsored': True, 'organic_weight': 0})
    for row in ranked['ranking']:
        row['next_action'] = 'INSPECT_PINNED_METADATA_THEN_OWNER_ADOPT_CONNECTOR_AND_EXACT_AGREEMENT'
    selection = _hash('COVENANT-REQUEST-DISCOVERY-SELECTION-0.1', {
        'ranking_selection': ranked['selection'],
        'selected_record_ids': sorted(row['record_id'] for row in selected['candidates']
                                      if row['status'] == 'SELECTED_METADATA'),
        'conflicts': selected['conflicts'],
    })
    return {'version': VERSION, 'goal': goal, 'ranking': ranked['ranking'], 'excluded': ranked['excluded'],
            'selection': selection, 'ranking_selection': ranked['selection'],
            'status': ranked['status'], 'graph': ranked['graph'],
            'reputation_provenance': ranked['provenance'], 'conflicts': selected['conflicts'],
            'candidates': selected['candidates'], 'sponsored': ads,
            'sponsorship_affects_organic_ranking': False,
            'lexical_matching_candidates': sum(row['lexical_match'] for row in ranked['ranking']),
            'rank_policy': {'weights': ranked['desire']['weights'],
                            'reputation_component': ('NO_INDEPENDENT_RECEIPT_VIEW_IMPORTED'
                                if ranked['desire']['weights'] == {'relevance': 50, 'pagerank': 20, 'reputation': 30}
                                else 'CONTEXTUAL_AUTHENTICATED_OPINIONS_NOT_SETTLEMENT_OUTCOMES'),
                            'unknown_reputation': 'NEUTRAL_NOT_POSITIVE_PERFORMANCE',
                            'existing_desire_profile_changed': False},
            'opinion_scope': 'COMPLETE_OWNER_ADOPTED_NETWORK_SNAPSHOT_NOT_JUST_SUPPLIED_REFERENCES',
            'input_opinion_references_checked': len(opinion_events),
            'truncated': False, 'history_complete': False,
            'search_scope': 'SUPPLIED_OR_OWNER_CACHED_METADATA_NOT_AN_EXHAUSTIVE_INTERNET_SEARCH',
            'next_action': ('REVIEW_RANKED_METADATA' if ranked['ranking'] else
                            'REFINE_REQUIREMENTS_OR_IMPORT_AN_OWNER_SELECTED_METADATA_PAGE'),
            'network_accessed': False, 'execution_authorized': False, 'installed': False,
            'assent_created': False, 'blockchain_required': False}
