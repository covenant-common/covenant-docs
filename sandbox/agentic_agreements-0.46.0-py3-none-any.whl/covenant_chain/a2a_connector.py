"""Pinned A2A 1.0 JSON-RPC client behind the existing owner effect harness.

This is a bounded client subset, not an A2A server or a remote-agent sandbox.
Discovery never installs routes, fetches keys/files, adopts an extension, signs
an agreement or supplies credentials. All calls, including GETs, are effects.
Exact external JSON is carried as text/bytes; native signed JSON stays unchanged.
"""
from copy import deepcopy
from decimal import Decimal
import base64
import hashlib
import ipaddress
import json
import math
from pathlib import Path
from urllib.parse import urlsplit

from .connector_harness import ConnectorHarness, _alias, _url_path
from .crypto import exact, need
from .workflow_store import canonical as wire

VERSION = "covenant-a2a-connector/0.1"
PROTOCOL_VERSION = "1.0"
SPECIFICATION = "https://github.com/a2aproject/A2A/blob/v1.0.1/specification/a2a.proto"
IMPLEMENTATION = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
METHODS = ("Discover", "SendMessage", "GetTask", "CancelTask")
STATES = frozenset("TASK_STATE_" + s for s in (
    "UNSPECIFIED", "SUBMITTED", "WORKING", "COMPLETED", "FAILED", "CANCELED",
    "INPUT_REQUIRED", "REJECTED", "AUTH_REQUIRED"))


def _fields(value, required=(), optional=()):
    need(type(value) is dict and set(required) <= set(value)
         and set(value) <= set(required) | set(optional), "A2A_FIELDS")


def _text(value, maximum=1024, empty=False):
    need(type(value) is str and (empty or bool(value)), "A2A_TEXT")
    try:
        need(len(value.encode("utf-8")) <= maximum, "A2A_TEXT")
    except UnicodeError:
        raise ValueError("A2A_TEXT") from None


def _list(value, maximum=64):
    need(type(value) is list and len(value) <= maximum, "A2A_LIST")


def _history(value):
    need(type(value) is int and 0 <= value <= 100, "A2A_HISTORY_LENGTH")


def _json(raw, maximum=262144):
    _text(raw, maximum)
    def pairs(items):
        result = {}
        for name, value in items:
            need(name not in result, "A2A_DUPLICATE_KEY")
            result[name] = value
        return result
    def nonfinite(_):
        raise ValueError("A2A_NONFINITE_NUMBER")
    try:
        result = json.loads(raw, object_pairs_hook=pairs, parse_float=Decimal,
                            parse_constant=nonfinite)
    except (json.JSONDecodeError, RecursionError, UnicodeError):
        raise ValueError("A2A_JSON") from None
    pending, nodes = [(result, 0)], 0
    while pending:
        value, depth = pending.pop()
        nodes += 1
        need(depth <= 32 and nodes <= 10000, "A2A_JSON_COMPLEXITY")
        if type(value) is dict:
            need(all(type(k) is str and len(k.encode("utf-8")) <= 256 for k in value), "A2A_JSON_KEY")
            pending.extend((v, depth + 1) for v in value.values())
        elif type(value) is list:
            pending.extend((v, depth + 1) for v in value)
        elif type(value) is str:
            _text(value, maximum, empty=True)
        elif type(value) in (Decimal, int):
            try:
                finite = math.isfinite(float(value))
            except OverflowError:
                finite = False
            need(finite, "A2A_NONFINITE_NUMBER")
    return result


def _parts(parts):
    _list(parts)
    need(bool(parts), "A2A_PARTS")
    for part in parts:
        _fields(part, (), ("text", "data", "raw", "url", "metadata", "filename", "mediaType"))
        choices = set(part) & {"text", "data", "raw", "url"}
        need(len(choices) == 1, "A2A_PART_ONEOF")
        for name in ("text", "url", "filename", "mediaType"):
            if name in part:
                _text(part[name], 262144 if name == "text" else 8192, empty=name == "text")
        if "raw" in part:
            _text(part["raw"], 262144, empty=True)
            try:
                decoded = base64.b64decode(part["raw"], validate=True)
            except ValueError:
                raise ValueError("A2A_RAW_BASE64") from None
            need(base64.b64encode(decoded).decode("ascii") == part["raw"], "A2A_RAW_BASE64")
        if "metadata" in part:
            need(type(part["metadata"]) is dict, "A2A_METADATA")


def _message(message, role=None):
    _fields(message, ("messageId", "role", "parts"),
            ("contextId", "taskId", "metadata", "extensions", "referenceTaskIds"))
    _text(message["messageId"])
    need(message["role"] in ("ROLE_USER", "ROLE_AGENT")
         and (role is None or message["role"] == role), "A2A_ROLE")
    _parts(message["parts"])
    for name in ("contextId", "taskId"):
        if name in message:
            _text(message[name])
    if message["role"] == "ROLE_AGENT":
        need(bool(message.get("contextId")), "A2A_AGENT_CONTEXT")
    if "metadata" in message:
        need(type(message["metadata"]) is dict, "A2A_METADATA")
    for name in ("extensions", "referenceTaskIds"):
        if name in message:
            _list(message[name])
            for value in message[name]:
                _text(value)
    # No extension semantics are installed by this initial client subset.
    need(not message.get("extensions"), "A2A_EXTENSION_NOT_ADOPTED")


def _params(method, params, tenant):
    if method == "Discover":
        exact(params, "")
        return
    if method == "SendMessage":
        _fields(params, ("message",), ("tenant", "configuration", "metadata"))
        _message(params["message"], "ROLE_USER")
        if "configuration" in params:
            c = params["configuration"]
            _fields(c, (), ("acceptedOutputModes", "historyLength", "returnImmediately"))
            if "acceptedOutputModes" in c:
                _list(c["acceptedOutputModes"])
                for mode in c["acceptedOutputModes"]:
                    _text(mode, 256)
            if "historyLength" in c:
                _history(c["historyLength"])
            if "returnImmediately" in c:
                need(type(c["returnImmediately"]) is bool, "A2A_RETURN_IMMEDIATELY")
    elif method == "GetTask":
        _fields(params, ("id",), ("tenant", "historyLength"))
        _text(params["id"])
        if "historyLength" in params:
            _history(params["historyLength"])
    else:
        need(method == "CancelTask", "A2A_METHOD")
        _fields(params, ("id",), ("tenant", "metadata"))
        _text(params["id"])
    need(params.get("tenant") == tenant, "A2A_TENANT_SCOPE")
    if "metadata" in params:
        need(type(params["metadata"]) is dict, "A2A_METADATA")


def _task(task, expected_task=None, expected_context=None):
    _fields(task, ("id", "status"), ("contextId", "artifacts", "history", "metadata"))
    _text(task["id"])
    need(expected_task is None or task["id"] == expected_task, "A2A_TASK_MISMATCH")
    if "contextId" in task:
        _text(task["contextId"])
    need(expected_context is None or task.get("contextId") == expected_context, "A2A_CONTEXT_MISMATCH")
    status = task["status"]
    _fields(status, ("state",), ("message", "timestamp"))
    need(type(status["state"]) is str and status["state"] in STATES, "A2A_TASK_STATE")
    if "message" in status:
        _message(status["message"], "ROLE_AGENT")
    if "timestamp" in status:
        _text(status["timestamp"], 128)
    for field in ("artifacts", "history"):
        if field in task:
            _list(task[field], 100)
    for message in task.get("history", []):
        _message(message)
    for message in ([status["message"]] if "message" in status else []) + task.get("history", []):
        for field, target in (("taskId", task["id"]), ("contextId", task.get("contextId"))):
            need(field not in message or target is None or message[field] == target, "A2A_CONTEXT_MISMATCH")
    for artifact in task.get("artifacts", []):
        _fields(artifact, ("artifactId", "parts"), ("name", "description", "metadata", "extensions"))
        _text(artifact["artifactId"])
        _parts(artifact["parts"])
        for field in ("name", "description"):
            if field in artifact:
                _text(artifact[field], 8192, empty=True)
        if "metadata" in artifact:
            need(type(artifact["metadata"]) is dict, "A2A_METADATA")
        need(not artifact.get("extensions"), "A2A_EXTENSION_NOT_ADOPTED")
    if "metadata" in task:
        need(type(task["metadata"]) is dict, "A2A_METADATA")
    return {"task_id": task["id"], "context_id": task.get("contextId"), "task_state": status["state"]}


def covenant_offer_task(task):
    """Check a locally built covenant offer. Does not fetch a URL or adopt an extension.

    Artifact metadata carries the covenant id, accepted profiles and verifier.
    Message and artifact extensions stay refused by this client subset.
    """
    summary = _task(task)
    artifacts = task.get("artifacts", [])
    for artifact in artifacts:
        meta = artifact.get("metadata") or {}
        need(type(meta.get("covenant_id")) is str and type(meta.get("verifier")) is str, "A2A_METADATA")
        need(type(meta.get("acceptedProfiles")) is list and meta["acceptedProfiles"], "A2A_METADATA")
    return {"profile": VERSION, "summary": summary, "artifact_count": len(artifacts),
            "fetched": False, "extension_adopted": False, "execution_authorized": False,
            "advertisement_is_authority": False}


def inspect_card(card_json, *, expected_url=None):
    """Inspect untrusted advertised capabilities. Does not verify JWS or WebID."""
    card = _json(card_json)
    required = {"name", "description", "version", "supportedInterfaces", "capabilities",
                "defaultInputModes", "defaultOutputModes"}
    need(type(card) is dict and required <= set(card), "A2A_CARD_FIELDS")
    for field in ("name", "description", "version"):
        _text(card[field], 8192)
    _list(card["supportedInterfaces"])
    # An empty repeated field is omitted by the official ProtoJSON serializer.
    # This is capability inspection, not complete Agent Card schema validation.
    _list(card.get("skills", []))
    for field in ("defaultInputModes", "defaultOutputModes"):
        _list(card[field])
        for mode in card[field]:
            _text(mode, 256)
    need(type(card["capabilities"]) is dict, "A2A_CARD_CAPABILITIES")
    extensions = card["capabilities"].get("extensions", [])
    _list(extensions)
    required_extensions = []
    for ext in extensions:
        need(type(ext) is dict and type(ext.get("uri")) is str, "A2A_CARD_EXTENSION")
        if "required" in ext:
            need(type(ext["required"]) is bool, "A2A_CARD_EXTENSION")
        if ext.get("required"):
            required_extensions.append(ext["uri"])
    interfaces = []
    for entry in card["supportedInterfaces"]:
        _fields(entry, ("url", "protocolBinding", "protocolVersion"), ("tenant",))
        for field in entry:
            _text(entry[field], 8192)
        if (entry["protocolBinding"] == "JSONRPC" and entry["protocolVersion"] == PROTOCOL_VERSION
                and (expected_url is None or entry["url"] == expected_url)):
            interfaces.append(deepcopy(entry))
    return {"profile": VERSION, "card_sha256": hashlib.sha256(card_json.encode("utf-8")).hexdigest(),
            "name": card["name"], "agent_version": card["version"],
            "compatible_interfaces": interfaces, "unsupported_required_extensions": required_extensions,
            "compatible": bool(interfaces) and not required_extensions,
            "signature_verified": False, "advertisement_is_authority": False,
            "execution_authorized": False, "automatic_installation": False}


def _endpoint(url, insecure):
    _text(url, 8192)
    need(url.isascii() and "\\" not in url, "A2A_OWNER_URL")
    try:
        p = urlsplit(url)
        port = p.port
    except ValueError:
        raise ValueError("A2A_OWNER_URL") from None
    need(p.hostname and not p.username and not p.password and not p.query and not p.fragment,
         "A2A_OWNER_URL")
    if p.scheme != "https":
        try:
            loopback = ipaddress.ip_address(p.hostname).is_loopback
        except ValueError:
            loopback = False
        need(p.scheme == "http" and insecure and loopback, "A2A_HTTPS_REQUIRED")
    path = p.path or "/"
    _url_path(path)
    host = "[" + p.hostname + "]" if ":" in p.hostname else p.hostname
    return p.scheme + "://" + host + ((":" + str(port)) if port is not None else ""), path


def _headers(owner):
    def installed():
        headers = owner() if callable(owner) else deepcopy(owner)
        need(type(headers) is dict and all(type(k) is str for k in headers), "A2A_OWNER_HEADERS")
        need(not ({k.lower() for k in headers} &
                  {"content-type", "accept", "a2a-version", "a2a-extensions"}), "A2A_OWNER_HEADERS")
        return {**headers, "Content-Type": "application/json", "Accept": "application/json",
                "A2A-Version": PROTOCOL_VERSION}
    if not callable(owner):
        installed()
    return installed


def default_adapter(directory):
    """Loopback alias installed with the keyless host. Construction does not dial."""
    return A2AConnector(directory, agents={'local': {'url': 'http://127.0.0.1:9/a2a'}},
                        allow_insecure_loopback=True)


class A2AConnector(ConnectorHarness):
    """Owner installs exact aliases, endpoints, credentials and tenant scope.

    Native profile, signatures and settlement rules are not changed. The base
    harness retains intent before a call and will not blindly repeat an unknown
    outcome. Message/request IDs are correlation, not remote idempotency claims.
    """
    def __init__(self, directory, *, agents, allow_insecure_loopback=False, timeout=3.0,
                 max_request_bytes=65536, max_wire_bytes=32768, observer=None):
        need(type(agents) is dict and 0 < len(agents) <= 16, "A2A_OWNER_AGENTS")
        need(type(allow_insecure_loopback) is bool, "A2A_OWNER_CONFIGURATION")
        need(type(max_wire_bytes) is int and 1024 <= max_wire_bytes <= 128000, "A2A_OWNER_LIMIT")
        self.max_wire_bytes = max_wire_bytes
        self._agents = {}
        routes, custom = {}, {}
        for alias, entry in agents.items():
            _alias(alias)
            need(len(alias) <= 48, "A2A_OWNER_ALIAS")
            _fields(entry, ("url",), ("card_url", "headers", "card_headers", "tenant"))
            origin, path = _endpoint(entry["url"], allow_insecure_loopback)
            card_url = entry.get("card_url", origin + "/.well-known/agent-card.json")
            card_origin, card_path = _endpoint(card_url, allow_insecure_loopback)
            tenant = entry.get("tenant")
            if tenant is not None:
                _text(tenant)
            self._agents[alias] = {"url": entry["url"], "rpc": path, "card": card_path, "tenant": tenant}
            for suffix, host, prefix, credentials in (
                ("rpc", origin, path, entry.get("headers", {})),
                ("card", card_origin, card_path, entry.get("card_headers", {}))):
                routes[alias + "-" + suffix] = {"origin": host, "path_prefix": prefix,
                    "methods": ["GET"] if suffix == "card" else ["POST"],
                    "headers": _headers(credentials)}
            policy = {"implementation": IMPLEMENTATION, "profile": VERSION, "wire": PROTOCOL_VERSION,
                      "endpoint": self._agents[alias], "max_wire_bytes": max_wire_bytes}
            custom[alias] = {"protocol": "A2A", "implementation": hashlib.sha256(wire(policy)).hexdigest(),
                             "call": lambda parameters, a=alias: self._call(a, parameters)}
        super().__init__(directory, http_routes=routes, custom_protocols=custom, timeout=timeout,
                         max_request_bytes=max_request_bytes, max_response_bytes=4 * max_wire_bytes + 16384,
                         observer=observer)

    def describe_requests(self):
        return {"profile": VERSION, "adapter": self.ref, "protocol": "A2A", "protocol_version": PROTOCOL_VERSION,
                "binding": "JSONRPC", "specification": SPECIFICATION,
                "agents": {alias: {"methods": list(METHODS), "tenant_required": entry["tenant"] is not None}
                           for alias, entry in self._agents.items()},
                "operations": [{"protocol": "A2A", "operation": alias,
                                "parameters": {"required": ["method", "request_id", "params_json"],
                                               "methods": list(METHODS)}} for alias in self._agents],
                "max_wire_bytes": self.max_wire_bytes, "max_transport_bytes": self.max_response_bytes,
                "max_request_bytes": self.max_request_bytes,
                "recovery": "OBSERVE_ONLY_NO_REMOTE_IDEMPOTENCY_ASSUMPTION", "credentials": "OWNER_CUSTODY",
                "streaming": False, "push_notifications": False, "execution_authorized": False,
                "all_calls": "SEPARATE_WORKFLOW_APPROVAL_REQUIRED"}

    def validate_request(self, request):
        checked = super().validate_request(request)
        need(request["protocol"] == "A2A" and request["operation"] in self._agents, "A2A_AGENT_NOT_INSTALLED")
        p = request["parameters"]
        exact(p, "method request_id params_json")
        need(type(p["method"]) is str and p["method"] in METHODS, "A2A_METHOD")
        _text(p["request_id"])
        params = _json(p["params_json"], self.max_request_bytes)
        _params(p["method"], params, self._agents[request["operation"]]["tenant"])
        if p["method"] != "Discover":
            need(len(self._body(p)) <= self.max_request_bytes, "A2A_WIRE_REQUEST_LIMIT")
        return checked

    def prepare(self, agent, method, *, request_id, params_json="{}"):
        request = {"protocol": "A2A", "operation": agent,
                   "parameters": {"method": method, "request_id": request_id, "params_json": params_json}}
        checked = self.validate_request(request)
        return {"adapter": self.ref, "request": request,
                "request_binding": {"kind": "FIXED", "hash": checked["request_hash"]},
                "next": "ADOPT_EXACT_WORKFLOW_BOOKING_AND_PROVIDER_OUTPUT_APPROVALS", "execution_authorized": False}

    @staticmethod
    def _body(p):
        return ("{\"jsonrpc\":\"2.0\",\"id\":" + json.dumps(p["request_id"]) +
                ",\"method\":" + json.dumps(p["method"]) + ",\"params\":" + p["params_json"] + "}").encode("utf-8")

    def _call(self, alias, p):
        discovery = p["method"] == "Discover"
        route = self._agents[alias]
        parameters = {"path": route["card" if discovery else "rpc"], "method": "GET" if discovery else "POST"}
        if not discovery:
            body = self._body(p)
            parameters["body_base64"] = base64.b64encode(body).decode("ascii")
        http = self._http(alias + ("-card" if discovery else "-rpc"), parameters)
        raw = base64.b64decode(http["body_base64"], validate=True)
        need(len(raw) <= self.max_wire_bytes, "A2A_WIRE_RESPONSE_LIMIT")
        result = {"profile": VERSION, "method": p["method"], "request_id": p["request_id"],
                  "http_status": http["status"], "body_base64": http["body_base64"],
                  "body_sha256": hashlib.sha256(raw).hexdigest(), "protocol_status": "INVALID_RESPONSE",
                  "assurance": "REMOTE_STATEMENT_NOT_AGREEMENT_ASSENT_OR_PAYMENT_OR_WORLD_TRUTH"}
        if not 200 <= http["status"] < 300:
            return {**result, "protocol_status": "HTTP_ERROR"}
        try:
            content_type = http["headers"].get("content-type", "").split(";", 1)[0].strip().lower()
            need(content_type == "application/json", "A2A_CONTENT_TYPE")
            text = raw.decode("utf-8")
            if discovery:
                info = inspect_card(text, expected_url=route["url"])
                # Keep exact card bytes in custody; inspection never installs it.
                compatible = info["compatible"] and any(i.get("tenant") == route["tenant"]
                    for i in info["compatible_interfaces"])
                result.update(protocol_status="AGENT_CARD", compatible=compatible,
                              card_sha256=info["card_sha256"], signature_verified=False)
                return result
            reply = _json(text, self.max_wire_bytes)
            _fields(reply, ("jsonrpc", "id"), ("result", "error"))
            need(reply["jsonrpc"] == "2.0" and type(reply["id"]) is str
                 and reply["id"] == p["request_id"], "A2A_RESPONSE_CORRELATION")
            need(("result" in reply) != ("error" in reply), "A2A_RESPONSE_ONEOF")
            if "error" in reply:
                error = reply["error"]
                _fields(error, ("code", "message"), ("data",))
                need(type(error["code"]) is int and abs(error["code"]) <= 2**31 - 1, "A2A_ERROR_CODE")
                _text(error["message"], 8192)
                return {**result, "protocol_status": "RPC_ERROR", "rpc_error_code": error["code"]}
            params = _json(p["params_json"], self.max_request_bytes)
            payload = reply["result"]
            if p["method"] == "SendMessage":
                _fields(payload, (), ("task", "message"))
                need(len(payload) == 1, "A2A_RESULT_ONEOF")
                source = params["message"]
                if "message" in payload:
                    message = payload["message"]
                    _message(message, "ROLE_AGENT")
                    for field in ("taskId", "contextId"):
                        need(field not in source or message.get(field) == source[field], "A2A_CONTEXT_MISMATCH")
                    result.update(message_id=message["messageId"], context_id=message["contextId"])
                else:
                    result.update(_task(payload["task"], source.get("taskId"), source.get("contextId")))
            else:
                result.update(_task(payload, params["id"]))
            return {**result, "protocol_status": "RESULT"}
        except (ValueError, TypeError, KeyError, UnicodeError):
            # A reply was observed even when its protocol payload is invalid.
            # Preserve the bounded exact bytes, without declaring task success.
            return result
