"""Covenant native chain: experimental certified-committee commitment ledger."""
from covenant_language._version import __version__
