"""Explicit quorum escrow in an owner-installed disposable-credit ledger.

This is local custody, not an external chain multisig or a public consensus.
Every funding participant adopts the exact policy. Release requires its exact
controller quorum over effect, policy and complete payout allocation.
"""
from copy import deepcopy
import json,hashlib
from covenant_language.agentic import canonical as portable
from .adapters import manifest,_instance,manifest_id
from .workflow_store import WorkflowStore
from .crypto import need,key,integer,exact,digest,canonical,verify
from covenant_language import marketplace as p
FUND='COVENANT-DISPOSABLE-ESCROW-FUND-0.1'
PAYOUT='COVENANT-DISPOSABLE-ESCROW-PAYOUT-0.1'

class DemoEscrowDesk:
    def __init__(self,directory,unit,balances):
        need(type(unit) is str and 0<len(unit)<=128 and type(balances) is dict and len(balances)<=64,'ESCROW_CONFIG')
        for actor,amount in balances.items():key(actor);integer(amount)
        integer(sum(balances.values()))
        self.initial_balances=deepcopy(balances)
        self.unit=unit;self.manifest=manifest('disposable-quorum-escrow-0.1','payment.escrow',effect='LOCAL_DISPOSABLE_QUORUM_ESCROW',instance=_instance(directory))
        self.manifest['requirements']['authority']='EXACT_ALL_PARTICIPANT_FUND_ASSENT_THEN_ADOPTED_PAYOUT_QUORUM'
        self.manifest['requirements']['resources']='LOCAL_DISPOSABLE_BALANCES_ONLY'
        self.ref=manifest_id(self.manifest);self.store=WorkflowStore(directory,{'adapter':self.manifest,'unit':unit,'balances':balances});self.db=self.store.db
        with self.store.exclusive():
            self.db.execute('CREATE TABLE IF NOT EXISTS escrow_balances(actor TEXT PRIMARY KEY,amount INTEGER NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS escrow_contracts(id TEXT PRIMARY KEY,body BLOB NOT NULL,amount INTEGER NOT NULL,status TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS escrow_receipts(id TEXT PRIMARY KEY,intent TEXT NOT NULL,body BLOB NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS escrow_journal(sequence INTEGER PRIMARY KEY,previous TEXT NOT NULL,id TEXT UNIQUE NOT NULL,entry BLOB NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS escrow_initialized(id INTEGER PRIMARY KEY CHECK(id=1))')
            for table in ('escrow_receipts','escrow_journal'):
                for op in ('UPDATE','DELETE'):self.db.execute(f"CREATE TRIGGER IF NOT EXISTS {table}_no_{op.lower()} BEFORE {op} ON {table} BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RECEIPT'); END")
                # REPLACE can bypass DELETE triggers when recursive_triggers is
                # disabled. Refuse the conflicting insert itself, including
                # either unique key of the journal, on every connection.
                conflict='id=NEW.id'+(' OR sequence=NEW.sequence' if table=='escrow_journal' else '')
                self.db.execute(f"CREATE TRIGGER IF NOT EXISTS {table}_no_replace BEFORE INSERT ON {table} WHEN EXISTS(SELECT 1 FROM {table} WHERE {conflict}) BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RECEIPT'); END")
            if not self.db.execute('SELECT count(*) FROM escrow_initialized').fetchone()[0]:
                self.db.execute('BEGIN IMMEDIATE')
                try:
                    self.db.execute('INSERT INTO escrow_initialized VALUES(1)')
                    self.db.executemany('INSERT INTO escrow_balances VALUES(?,?)',list(balances.items()));self.db.execute('COMMIT')
                except BaseException:self.db.execute('ROLLBACK');raise
        self.audit()
    def _policy(self,policy):
        p.validate(policy);need(policy['kind']=='ESCROW_POLICY','ESCROW_POLICY');d=policy['data'];a=d['asset']
        need(d['connector']==self.ref and a['adapter']==self.ref and a['namespace']=='covenant-disposable' and a['identifier']==self.unit and a['unit']==self.unit,'ESCROW_ASSET_OR_CONNECTOR')
        need(d['payer'] in d['controllers'] and d['payee'] in d['controllers'] and d['threshold']>=2,'ESCROW_EXPLICIT_QUORUM')
        exact(d['release'],'mode');exact(d['refund'],'mode')
        need(d['release'].get('mode')=='EXACT_QUORUM' and d['refund'].get('mode')=='EXACT_QUORUM','ESCROW_UNSUPPORTED_AUTOMATIC_RULES')
        return d
    def assent_payload(self,effect_id,request):
        key(effect_id);need(len(portable(request))<=self.manifest['max_bytes'],'ESCROW_INPUT_SIZE');need(type(request) is dict and request.get('action') in ('FUND','PAYOUT'),'ESCROW_ACTION')
        if request['action']=='FUND':
            exact(request,'action policy');d=self._policy(request['policy']);required=sorted(set([d['payer'],d['payee'],*d['controllers']]))
            label=FUND
        else:
            exact(request,'action escrow payouts');key(request['escrow']);need(type(request['payouts']) is dict and 1<=len(request['payouts'])<=2,'ESCROW_PAYOUTS')
            row=self.db.execute('SELECT body FROM escrow_contracts WHERE id=?',(request['escrow'],)).fetchone();need(row is not None,'ESCROW_UNKNOWN')
            policy=json.loads(row[0]);d=self._policy(policy)
            for actor,amount in request['payouts'].items():key(actor);integer(amount);need(actor in {d['payer'],d['payee']},'ESCROW_PAYOUT_PARTY')
            need(sum(request['payouts'].values())==d['amount'],'ESCROW_ALLOCATION_NOT_CONSERVED');required=d['controllers'];label=PAYOUT
        return {'label':label,'body':{'adapter':self.ref,'effect':effect_id,'request_hash':hashlib.sha256(portable(request)).hexdigest()},'request':deepcopy(request),'eligible_signers':required,'threshold':len(required) if request['action']=='FUND' else d['threshold'],'signature_or_funding_created':False,'execution_authorized':False}
    def execute(self,effect_id,request,*,crash=None):
        need(len(portable(request))<=self.manifest['max_bytes'],'ESCROW_INPUT_SIZE')
        exact(request,'action policy approvals' if request.get('action')=='FUND' else 'action escrow payouts approvals')
        raw={k:v for k,v in request.items() if k!='approvals'};payload=self.assent_payload(effect_id,raw)
        approvals=request['approvals'];need(type(approvals) is list and payload['threshold']<=len(approvals)<=len(payload['eligible_signers']),'ESCROW_QUORUM');seen=set()
        for a in approvals:
            exact(a,'party signature');need(a['party'] in payload['eligible_signers'] and a['party'] not in seen,'ESCROW_SIGNER');verify(a['party'],payload['label'],payload['body'],a['signature']);seen.add(a['party'])
        intent=hashlib.sha256(b'COVENANT-DISPOSABLE-ESCROW-INTENT-0.1\0'+portable(request)).hexdigest()
        with self.store.exclusive():
            self._audit()
            self.db.execute('BEGIN IMMEDIATE')
            try:
                old=self.db.execute('SELECT intent,body FROM escrow_receipts WHERE id=?',(effect_id,)).fetchone()
                if old:
                    need(old[0]==intent,'ESCROW_RETRY_CHANGED');receipt=json.loads(old[1])
                elif raw['action']=='FUND':
                    d=self._policy(raw['policy']);ref=p.identifier(raw['policy']);need(not self.db.execute('SELECT 1 FROM escrow_contracts WHERE id=?',(ref,)).fetchone(),'ESCROW_ALREADY_FUNDED')
                    row=self.db.execute('SELECT amount FROM escrow_balances WHERE actor=?',(d['payer'],)).fetchone();need(row is not None and row[0]>=d['amount'],'ESCROW_INSUFFICIENT_BALANCE')
                    self.db.execute('UPDATE escrow_balances SET amount=amount-? WHERE actor=?',(d['amount'],d['payer']))
                    self.db.execute('INSERT INTO escrow_contracts VALUES(?,?,?,?)',(ref,portable(raw['policy']),d['amount'],'LOCKED'))
                    receipt={'effect':effect_id,'escrow':ref,'action':'FUND','amount':d['amount'],'state':'LOCKED','scope':'LOCAL_DISPOSABLE_CUSTODY'}
                else:
                    ref=raw['escrow'];row=self.db.execute('SELECT amount,status FROM escrow_contracts WHERE id=?',(ref,)).fetchone();need(row is not None and row[1]=='LOCKED','ESCROW_NOT_LOCKED')
                    for actor,amount in raw['payouts'].items():
                        current=self.db.execute('SELECT amount FROM escrow_balances WHERE actor=?',(actor,)).fetchone();integer((current[0] if current else 0)+amount)
                        self.db.execute('INSERT INTO escrow_balances VALUES(?,?) ON CONFLICT(actor) DO UPDATE SET amount=amount+excluded.amount',(actor,amount))
                    self.db.execute('UPDATE escrow_contracts SET status=? WHERE id=?',('SETTLED',ref))
                    receipt={'effect':effect_id,'escrow':ref,'action':'PAYOUT','payouts':deepcopy(raw['payouts']),'state':'SETTLED','scope':'LOCAL_DISPOSABLE_CUSTODY'}
                if not old:
                    need(self.db.execute('SELECT count(*) FROM escrow_journal').fetchone()[0]<4096 and self.db.execute('SELECT coalesce(sum(length(entry)),0) FROM escrow_journal').fetchone()[0]+len(portable(request))<64*1024*1024,'ESCROW_JOURNAL_QUOTA')
                    self.db.execute('INSERT INTO escrow_receipts VALUES(?,?,?)',(effect_id,intent,portable(receipt)))
                    last=self.db.execute('SELECT sequence,id FROM escrow_journal ORDER BY sequence DESC LIMIT 1').fetchone()
                    sequence=last[0]+1 if last else 1;previous=last[1] if last else '0'*64
                    entry={'effect':effect_id,'intent':intent,'authorization':deepcopy(request),'receipt':receipt}
                    need(self.db.execute('SELECT coalesce(sum(length(entry)),0) FROM escrow_journal').fetchone()[0]+len(portable(entry))<=64*1024*1024,'ESCROW_JOURNAL_QUOTA')
                    identifier=hashlib.sha256(b'COVENANT-ESCROW-JOURNAL-0.1\0'+portable({'sequence':sequence,'previous':previous,'entry':entry})).hexdigest()
                    self.db.execute('INSERT INTO escrow_journal VALUES(?,?,?,?)',(sequence,previous,identifier,portable(entry)))
                self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise
        if crash=='after_effect':
            from covenant_language.handoff import InjectedCrash
            raise InjectedCrash('after_effect')
        return self.observe(effect_id)
    def observe(self,effect_id):
        key(effect_id)
        with self.store.exclusive():
            self.db.execute('BEGIN')
            try:
                self._audit()
                row=self.db.execute('SELECT body FROM escrow_receipts WHERE id=?',(effect_id,)).fetchone()
                self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise
        if row is None:return {'status':'NOT_OBSERVED','output_hash':None,'assurance':'LOCAL_DISPOSABLE_CUSTODY'}
        return {'status':'OBSERVED','output_hash':hashlib.sha256(row[0]).hexdigest(),'value':json.loads(row[0]),
                'assurance':'LOCAL_DISPOSABLE_CUSTODY','external_delivery_or_world_truth':'NOT_ESTABLISHED'}
    def _audit(self,expected_head=None):
        if expected_head is not None:key(expected_head)
        rows=self.db.execute('SELECT sequence,previous,id,entry FROM escrow_journal ORDER BY sequence').fetchall()
        previous='0'*64;balances=deepcopy(self.initial_balances);contracts={};seen=set();receipts={}
        for seq,prior,ref,encoded in rows:
            entry=json.loads(encoded);exact(entry,'effect intent authorization receipt');need(portable(entry)==encoded,'ESCROW_JOURNAL_ENCODING');need(seq==len(seen)+1 and prior==previous,'ESCROW_JOURNAL_CHAIN')
            need(ref==hashlib.sha256(b'COVENANT-ESCROW-JOURNAL-0.1\0'+portable({'sequence':seq,'previous':prior,'entry':entry})).hexdigest(),'ESCROW_JOURNAL_HASH')
            effect=entry['effect'];need(effect not in seen,'ESCROW_JOURNAL_DUPLICATE');seen.add(effect);request=entry['authorization'];raw={k:v for k,v in request.items() if k!='approvals'}
            intent=hashlib.sha256(b'COVENANT-DISPOSABLE-ESCROW-INTENT-0.1\0'+portable(request)).hexdigest();need(intent==entry['intent'],'ESCROW_JOURNAL_INTENT')
            if raw['action']=='FUND':
                exact(raw,'action policy');policy=raw['policy'];d=self._policy(policy);escrow=p.identifier(policy);need(escrow not in contracts,'ESCROW_JOURNAL_DOUBLE_FUND')
                need(balances.get(d['payer'],0)>=d['amount'],'ESCROW_JOURNAL_BALANCE');balances[d['payer']]-=d['amount'];contracts[escrow]=(policy,'LOCKED')
                expected={'effect':effect,'escrow':escrow,'action':'FUND','amount':d['amount'],'state':'LOCKED','scope':'LOCAL_DISPOSABLE_CUSTODY'};label=FUND;eligible=sorted(set([d['payer'],d['payee'],*d['controllers']]));threshold=len(eligible)
            else:
                exact(raw,'action escrow payouts');need(raw['action']=='PAYOUT' and raw['escrow'] in contracts and contracts[raw['escrow']][1]=='LOCKED','ESCROW_JOURNAL_RELEASE')
                policy=contracts[raw['escrow']][0];d=self._policy(policy);need(type(raw['payouts']) is dict and 1<=len(raw['payouts'])<=2 and sum(raw['payouts'].values())==d['amount'],'ESCROW_JOURNAL_ALLOCATION')
                for actor,amount in raw['payouts'].items():
                    integer(amount);need(actor in {d['payer'],d['payee']},'ESCROW_JOURNAL_PARTY');balances[actor]=balances.get(actor,0)+amount;integer(balances[actor])
                contracts[raw['escrow']]=(policy,'SETTLED');expected={'effect':effect,'escrow':raw['escrow'],'action':'PAYOUT','payouts':raw['payouts'],'state':'SETTLED','scope':'LOCAL_DISPOSABLE_CUSTODY'};label=PAYOUT;eligible=d['controllers'];threshold=d['threshold']
            approvals=request['approvals'];need(type(approvals) is list and threshold<=len(approvals)<=len(eligible),'ESCROW_JOURNAL_QUORUM');signed=set();body={'adapter':self.ref,'effect':effect,'request_hash':hashlib.sha256(portable(raw)).hexdigest()}
            for a in approvals:
                exact(a,'party signature');need(a['party'] in eligible and a['party'] not in signed,'ESCROW_JOURNAL_SIGNER');verify(a['party'],label,body,a['signature']);signed.add(a['party'])
            need(portable(expected)==portable(entry['receipt']),'ESCROW_JOURNAL_RECEIPT');receipts[effect]=(intent,portable(expected));previous=ref
        actual_receipts={ref:(intent,bytes(body)) for ref,intent,body in self.db.execute('SELECT id,intent,body FROM escrow_receipts')}
        need(receipts==actual_receipts,'ESCROW_RECEIPTS_CHANGED');need(balances==dict(self.db.execute('SELECT actor,amount FROM escrow_balances')),'ESCROW_BALANCES_CHANGED')
        actual={ref:(json.loads(body),status,amount) for ref,body,amount,status in self.db.execute('SELECT id,body,amount,status FROM escrow_contracts')}
        need(set(actual)==set(contracts) and all(portable(actual[k][0])==portable(v[0]) and actual[k][1]==v[1] and actual[k][2]==v[0]['data']['amount'] for k,v in contracts.items()),'ESCROW_CONTRACTS_CHANGED')
        if expected_head is not None:need(previous==expected_head,'ESCROW_EXPECTED_HEAD')
        return {'head':previous,'events':len(rows),'signatures_reverified':True,'balances_and_reserves_reconciled':True,'rollback_boundary':'RETAIN_EXPECTED_HEAD_OUTSIDE_THIS_HOST','global_freshness':'NOT_ESTABLISHED'}
    def audit(self,expected_head=None):
        with self.store.exclusive():
            self.db.execute('BEGIN')
            try:
                result=self._audit(expected_head);self.db.execute('COMMIT');return result
            except BaseException:self.db.execute('ROLLBACK');raise
    def escrow_policy(self,title,author,amount,payer,payee,controllers,threshold,context):
        """The exact quorum escrow policy this desk funds: its own asset and connector. Builds data only."""
        asset=p.asset('covenant-disposable',self.unit,self.unit,self.ref)
        return p.escrow_policy(title,author,asset,amount,payer,payee,controllers,threshold,context,
                               release={'mode':'EXACT_QUORUM'},refund={'mode':'EXACT_QUORUM'},connector=self.ref)['record']
    def contract(self,escrow_id):
        """Read-only current state of one escrow: policy, amount and LOCKED or SETTLED. Moves nothing."""
        key(escrow_id)
        with self.store.exclusive():
            self.db.execute('BEGIN')
            try:
                self._audit()
                row=self.db.execute('SELECT body,amount,status FROM escrow_contracts WHERE id=?',(escrow_id,)).fetchone()
                self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise
        if row is None:return {'escrow':escrow_id,'status':'NOT_OBSERVED','assurance':'LOCAL_DISPOSABLE_CUSTODY'}
        return {'escrow':escrow_id,'status':row[2],'amount':row[1],'policy':json.loads(row[0]),
                'assurance':'LOCAL_DISPOSABLE_CUSTODY','external_delivery_or_world_truth':'NOT_ESTABLISHED'}
    def snapshot(self):
        with self.store.exclusive():
            audit=self._audit()
            balances=dict(self.db.execute('SELECT actor,amount FROM escrow_balances'));locked=self.db.execute("SELECT coalesce(sum(amount),0) FROM escrow_contracts WHERE status='LOCKED'").fetchone()[0]
        return {'balances':balances,'locked':locked,'conserved_total':sum(balances.values())+locked,'scope':'LOCAL_DISPOSABLE_CUSTODY','audit':audit}
    def close(self):self.store.close()
