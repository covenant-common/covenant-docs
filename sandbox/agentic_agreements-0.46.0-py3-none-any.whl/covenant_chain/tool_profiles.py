"""Progressive tool disclosure for the local stdio MCP host.

The default entry profile is the first-contact list: covenant_onboard,
covenant_find, covenant_explain and covenant_call, a typed route to every
installed action. covenant_call shows the visible verbs of the seven jobs, not
the installed tool names: a verb with a kind names exactly one installed action
(covenant_agent.action_jobs), and every old tool name keeps working as
{tool, arguments}. Every other installed tool stays callable by its exact name.
covenant_explain (and covenant_tool_catalog describe) return any installed
tool's exact schema on demand, and covenant_call hands the same name and the
same arguments to the same dispatcher, so validation, refusals and results do
not change. The full profile lists every installed tool in bounded pages.

A listing or a description is metadata. It grants no authority, installs
nothing and executes nothing. The profile is fixed when the process starts, so
every stateless request sees the same list and cursors stay self-contained.
"""
from copy import deepcopy
import json
import re

from .crypto import need
from .tool_input import validate_schema

DESCRIPTION_FORMAT = 'covenant-tool-description/0.1'
INDEX_FORMAT = 'covenant-tool-index/0.1'
# "core" is not a listing profile: AAP Core names a scope of tools, not the
# first-contact list.
PROFILES = ('entry', 'full')
# Listed in this order when installed. One string keeps each tool's declaring
# file as its coverage-catalogue home.
ENTRY = tuple('covenant_onboard covenant_find covenant_explain covenant_call'.split())
ROUTER = 'covenant_call'
CATALOG = 'covenant_tool_catalog'
ENTRY_TOOL_LIMIT = 9
ENTRY_LIST_BUDGET = 20000
# The experience model's first-contact bound: the entry tools/list reply, on the wire.
FIRST_CONTACT_BUDGET = 12000
DESCRIBE_BUDGET = 32768
INDEX_BUDGET = 12000
SUMMARY_LIMIT = 200
_TOOL = re.compile(r'[a-z][a-z0-9_]{0,79}\Z')
_ACTION = re.compile(r'[A-Za-z][A-Za-z0-9_]{0,79}\Z')
_CURSOR = re.compile(r'(?:0|[1-9][0-9]{0,5})\Z')

TOOL_NAME = {'type': 'string', 'minLength': 1, 'maxLength': 80, 'pattern': '^[a-z][a-z0-9_]*$'}
ACTION_NAME = {'type': 'string', 'minLength': 1, 'maxLength': 80, 'pattern': '^[A-Za-z][A-Za-z0-9_]*$'}
CURSOR = {'type': 'string', 'minLength': 1, 'maxLength': 6, 'pattern': '^(0|[1-9][0-9]*)$'}


def _object(properties, required=()):
    return {'type': 'object', 'properties': properties, 'required': list(required),
            'additionalProperties': False}


def _size(value):
    return len(json.dumps(value, ensure_ascii=True, separators=(',', ':')))


def catalog_branches():
    """Exact list and describe shapes for covenant_tool_catalog."""
    return [
        _object({'action': {'const': 'list'}, 'parameters': _object(
            {'summaries': {'type': 'boolean'}, 'cursor': CURSOR})}, ('action', 'parameters')),
        _object({'action': {'const': 'describe'}, 'parameters': _object(
            {'name': TOOL_NAME, 'action': ACTION_NAME}, ('name',))}, ('action', 'parameters')),
    ]


def _hints(row):
    """MCP annotation defaults: not read-only, destructive, open world."""
    hints = row.get('annotations') or {}
    read_only = hints.get('readOnlyHint', False) is True
    return {'read_only': read_only,
            'destructive': not read_only and hints.get('destructiveHint', True) is not False,
            'idempotent': hints.get('idempotentHint', False) is True,
            'open_world': hints.get('openWorldHint', True) is not False}


def router_descriptor(listed):
    """covenant_call: a visible verb with a kind, or any installed tool by its old name, never itself.

    The schema shows verbs, not the installed names, so it stays the same
    when tools are added. The annotations are the most cautious of the tools
    it can reach.
    """
    from covenant_agent.action_jobs import callable_verbs
    targets = [row for row in listed if row['name'] != ROUTER]
    hints = [_hints(row) for row in targets]
    return {
        'name': 'covenant_call',
        'title': 'Call a Verb or Any Installed Tool',
        'description': ('A deal is a promise both sides sign. Proof shows it was kept. If it wasn\'t, there is a fair '
                        'way to fix it. Call a verb (propose, accept, settle first) with a kind and its parameters; '
                        'covenant_explain with a verb lists its kinds by job. Every old tool name keeps working as '
                        '{tool, arguments}, for example next_call from covenant_onboard guide. Validation, refusals '
                        'and results are the named action\'s own. Routing grants no authority.'),
        'inputSchema': {'type': 'object', 'additionalProperties': False,
            'properties': {
                'verb': {'type': 'string', 'enum': callable_verbs()},
                'kind': {'type': 'string', 'minLength': 1, 'maxLength': 80, 'pattern': '^[A-Za-z][A-Za-z0-9_.]*$'},
                'parameters': {'type': 'object', 'description': 'Exactly the parameters the chosen kind takes.'},
                'tool': {'type': 'string', 'minLength': 1, 'maxLength': 80, 'pattern': '^[a-z][a-z0-9_]*$'},
                'arguments': {'type': 'object', 'description': 'Exactly the arguments the named tool takes.'}},
            # anyOf, not oneOf: in these schemas oneOf lists one branch per action.
            'anyOf': [{'required': ['verb', 'parameters']}, {'required': ['tool', 'arguments']}]},
        'annotations': {'readOnlyHint': all(h['read_only'] for h in hints),
                        'destructiveHint': any(h['destructive'] for h in hints),
                        'idempotentHint': all(h['idempotent'] for h in hints),
                        'openWorldHint': any(h['open_world'] for h in hints)}}


def installed_targets(listed):
    """Action id -> (installed tool, action or None) for everything the router can reach here."""
    found = {}
    for row in listed:
        if row['name'] == ROUTER:
            continue
        actions = _actions(row['inputSchema'])
        for action in actions:
            found['tool:' + row['name'] + '.' + action] = (row['name'], action)
        if not actions:
            found['tool:' + row['name']] = (row['name'], None)
        # The catalogue's agent: family names whole installed tools.
        found['agent:' + row['name']] = (row['name'], None)
    return found


def _actions(schema):
    """Action name -> exact branch, in listed order. None means the whole schema."""
    found = {}
    for branch in schema.get('oneOf') or ():
        if type(branch) is not dict:
            continue
        selector = (branch.get('properties') or {}).get('action') or {}
        if type(selector.get('const')) is str:
            found.setdefault(selector['const'], branch)
        for value in selector.get('enum') or ():
            if type(value) is str:
                found.setdefault(value, branch)
    if not found:
        selector = (schema.get('properties') or {}).get('action') or {}
        for value in selector.get('enum') or ():
            if type(value) is str:
                found.setdefault(value, None)
    return found


def _branch_action(branch):
    selector = ((branch.get('properties') or {}).get('action') or {}) if type(branch) is dict else {}
    return selector.get('const')


def _required(schema, branch):
    if branch is None:
        return sorted(schema.get('required') or [])
    parameters = (branch.get('properties') or {}).get('parameters') or {}
    return sorted(parameters.get('required') or [])


def _call_shape(name, action):
    arguments = {} if action is None else {'action': action, 'parameters': {}}
    return {'direct_call': {'name': name, 'arguments': arguments},
            'router_call': {'name': ROUTER, 'arguments': {'tool': name, 'arguments': deepcopy(arguments)}}}


def describe(listed, name, action=None):
    """Exact installed schema for one tool, or for one of its actions.

    A whole schema larger than DESCRIBE_BUDGET returns its action index; the
    exact whole schema is the oneOf of those action schemas in that order.
    """
    by_name = {row['name']: row for row in listed}
    need(type(name) is str and _TOOL.fullmatch(name) is not None and name in by_name,
         'TOOL_CATALOG_UNKNOWN_TOOL')
    need(action is None or (type(action) is str and _ACTION.fullmatch(action) is not None),
         'TOOL_CATALOG_UNKNOWN_ACTION')
    row = by_name[name]
    schema = row['inputSchema']
    actions = _actions(schema)
    def entry(key):
        branch = actions[key]
        return {'action': key, 'required': _required(schema, branch),
                'schema_bytes': _size(branch if branch is not None else schema)}
    result = {'format': DESCRIPTION_FORMAT, 'tool': name, 'title': row.get('title', name),
              'description': row.get('description', ''), 'annotations': deepcopy(row.get('annotations') or {}),
              'schema_bytes': _size(schema), 'listed_by_default': name in ENTRY,
              'validation': 'SAME_AS_DIRECT_CALL', 'execution_authorized': False, 'automatic_assent': False}
    if action is None:
        result['actions'] = [entry(key) for key in actions]
        frame = {key: value for key, value in schema.items() if key != 'oneOf'}
        # The index is exact only when each branch is one distinct action.
        exact = [actions.get(_branch_action(branch)) is branch for branch in schema.get('oneOf') or ()]
        if result['schema_bytes'] <= DESCRIBE_BUDGET or not exact or not all(exact):
            result.update(status='DESCRIBED', inputSchema=deepcopy(schema),
                          **_call_shape(name, next(iter(actions)) if actions else None))
        else:
            result.update(status='SELECT_ACTION', schema_frame=deepcopy(frame), next_action=(
                'Describe one action with parameters {"name": tool, "action": action}. The exact inputSchema is '
                'schema_frame plus "oneOf": [each action_schema in the order listed].'))
        return result
    need(action in actions, 'TOOL_CATALOG_UNKNOWN_ACTION')
    branch = actions[action]
    result.update(status='DESCRIBED', action=action, actions=[entry(action)], actions_installed=len(actions),
                  per_action_schema=branch is not None,
                  action_schema=deepcopy(branch if branch is not None else schema), **_call_shape(name, action))
    return result


def _summary(row):
    text = ' '.join((row.get('description') or '').split())
    first = text.split('. ')[0].rstrip('.')
    if len(first) > SUMMARY_LIMIT:
        first = first[:SUMMARY_LIMIT - 3].rstrip() + '...'
    return {'name': row['name'], 'summary': first + ('.' if first and not first.endswith('...') else ''),
            'actions': list(_actions(row['inputSchema']))[:64], 'read_only': _hints(row)['read_only'],
            'schema_bytes': _size(row['inputSchema'])}


def index(listed, cursor=None):
    """One bounded page of one-line tool summaries; next_cursor continues it."""
    need(cursor is None or (type(cursor) is str and _CURSOR.fullmatch(cursor) is not None), 'TOOL_CATALOG_CURSOR')
    start = 0 if cursor is None else int(cursor)
    need(start == 0 or start < len(listed), 'TOOL_CATALOG_CURSOR')
    rows, size, end = [], 2, start
    while end < len(listed):
        row = _summary(listed[end])
        if rows and size + _size(row) + 1 > INDEX_BUDGET:
            break
        rows.append(row)
        size += _size(row) + 1
        end += 1
    page = {'format': INDEX_FORMAT, 'tools': rows, 'installed': len(listed),
            'execution_authorized': False}
    if end < len(listed):
        page['next_cursor'] = str(end)
    return page


def catalog_call(listed, arguments, schema):
    """covenant_tool_catalog. A bare list keeps its original names-only reply."""
    validate_schema(arguments, schema)
    parameters = arguments['parameters']
    if arguments['action'] == 'describe':
        return describe(listed, parameters['name'], parameters.get('action'))
    if parameters.get('summaries') is True:
        return index(listed, parameters.get('cursor'))
    need('cursor' not in parameters, 'TOOL_CATALOG_CURSOR')
    return {'tools': [row['name'] for row in listed], 'execution_authorized': False}


def route(call, listed, arguments):
    """covenant_call: the same dispatcher, the same name, the same arguments.

    A verb with a kind resolves to exactly one installed action through the
    job map and is called with exactly the given parameters. The reply is that
    action's own reply plus where it was routed and what usually comes next.
    Without a kind the verb's first data default installed here is used; use
    history never chooses. An old name in {tool, arguments} routes unchanged.
    """
    need(type(arguments) is dict, 'TOOL_ROUTER_FIELDS')
    if 'verb' in arguments:
        return _route_verb(call, listed, arguments)
    need(set(arguments) == {'tool', 'arguments'}, 'TOOL_ROUTER_FIELDS')
    target, inner = arguments['tool'], arguments['arguments']
    need(type(target) is str and _TOOL.fullmatch(target) is not None and type(inner) is dict,
         'TOOL_ROUTER_FIELDS')
    need(target != ROUTER, 'TOOL_ROUTER_RECURSION')
    need(target in {row['name'] for row in listed}, 'TOOL_ROUTER_UNKNOWN_TOOL')
    return call(target, inner)


def _route_verb(call, listed, arguments):
    from covenant_agent import action_jobs
    from covenant_agent.action_rank import suggest_next
    need(set(arguments) <= {'verb', 'kind', 'parameters'} and {'verb', 'parameters'} <= set(arguments),
         'TOOL_ROUTER_FIELDS')
    verb, kind, parameters = arguments['verb'], arguments.get('kind'), arguments['parameters']
    need(type(verb) is str and type(parameters) is dict and (kind is None or type(kind) is str), 'TOOL_ROUTER_FIELDS')
    targets = installed_targets(listed)
    ident = action_jobs.resolve(verb, kind, runnable=lambda candidate: candidate in targets)
    tool, action = targets[ident]
    result = call(tool, parameters if action is None else {'action': action, 'parameters': parameters})
    routed = {'verb': verb, 'kind': action_jobs.kind_of(ident), 'id': ident, 'tool': tool, 'action': action,
              'job': action_jobs.placement(ident)['job'], 'grants_authority': False}
    follow = [dict(row, here=row['id'] in targets) for row in suggest_next(ident)]
    if type(result) is dict:
        return {**result, 'routing': routed, 'suggested_next': follow}
    return {'result': result, 'routing': routed, 'suggested_next': follow}


def _explain_target(listed, arguments):
    """(tool, action or None) when an explain id names an installed tool or action.

    A verb with a kind (propose:marketplace.quick_trade) names the action its kind selects.
    """
    parameters = arguments.get('parameters') if type(arguments) is dict else None
    ident = parameters.get('id') if type(parameters) is dict and arguments.get('action') == 'action' else None
    if type(ident) is not str:
        return None
    from covenant_agent import action_jobs
    try:
        verb = action_jobs.split(ident)
        if verb is not None and verb[1] is not None:
            ident = action_jobs.resolve(*verb)
    except ValueError:
        return None
    family, _, rest = ident.rpartition(':')
    name, _, action = rest.partition('.')
    by_name = {row['name']: row for row in listed}
    if family not in ('', 'tool', 'agent') or name not in by_name:
        return None
    if action and action not in _actions(by_name[name]['inputSchema']):
        return None
    return name, action or None


def explain(listed, arguments, catalogue):
    """covenant_explain with the exact installed schema for an installed tool id.

    catalogue() is the unchanged explain call, so validation and every other
    reply stay as they were. An installed tool or action the catalogue does not
    know (a workflow tool, for example) is described instead of ACTION_UNKNOWN.
    """
    target = _explain_target(listed, arguments)
    try:
        row = catalogue()
    except ValueError as exc:
        if target is None or getattr(exc, 'code', None) != 'ACTION_UNKNOWN':
            raise
        qualified = target[0] + ('.' + target[1] if target[1] else '')
        row = {'id': 'tool:' + qualified, 'name': qualified, 'family': 'tool'}
    if target is None and type(row) is dict and type(row.get('verb')) is str and type(row.get('kinds')) is list:
        # A verb card: say which kinds this host can call, and the exact call for the first one.
        from covenant_agent.action_jobs import kinds as verb_kinds
        reachable = installed_targets(listed)
        names = verb_kinds(row['verb'])
        here = [kind for kind in row['kinds'] if names.get(kind) in reachable]
        return {**row, 'kinds_here': here, 'call': {'tool': ROUTER, 'arguments': {
            'verb': row['verb'], 'kind': here[0] if here else row['kinds'][0], 'parameters': {}}}}
    if target is None or type(row) is not dict:
        return row
    if row.get('ambiguous'):
        # An exact installed tool name is not an ambiguous action shorthand.
        # Keep unrelated catalogue ambiguities unchanged when no exact target exists.
        qualified = target[0] + ('.' + target[1] if target[1] else '')
        row = {'id': 'tool:' + qualified, 'name': qualified, 'family': 'tool'}
    return {**row, **describe(listed, *target), 'installed': True}


def select(listed, profile):
    """The tools a profile lists, in listing order. Calls are never narrowed."""
    need(profile in PROFILES, 'AGENT_TOOL_PROFILE')
    if profile == 'full':
        return list(listed)
    by_name = {row['name']: row for row in listed}
    return [by_name[name] for name in ENTRY if name in by_name]


def list_page(tools, profile, cursor):
    """One MCP tools/list page, or None for a cursor this profile never issued."""
    from .compact_tools import page_tools
    need(profile in PROFILES, 'AGENT_TOOL_PROFILE')
    chooser = getattr(tools, 'profile_tools', None)
    return page_tools(chooser(profile) if chooser is not None else tools.list_tools(), cursor)
