"""Host flags and owner configuration for the optional legal-evidence plugins.

Maturity: experimental. Every flag is off by default. A flag is a host decision,
never an agent argument, and none of these plugins is reachable from
``apply_transaction`` (tests/test_plugin_hot_path.py). ``HostPlugins`` is the one
object an owner passes to ``ExchangeTools(plugins=...)``: the flags, the host
keys the SLA and git tools sign with, an owner-adopted buyer mandate, the forum
registry and a clock. Tool arguments cannot supply any of them.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847). Tool names are built
with ``constants.tool``; signature labels stay literal in each plugin module.
"""
import time

from .constants import tool
from .crypto import need, public_key

DEFAULTS = {
    'lcp_emit': False,
    'lcp_buyer': False,
    'atr_binding': False,
    'acceptance_test': False,
    'git_anchors': False,
    'forum_arbiter': False,
    'sla_telemetry': False,
}
# One agent tool per flag. Suffixes go through constants.tool, the one place
# the wire prefix is spelled.
TOOLS = {
    'lcp_emit': tool('lcp'),
    'lcp_buyer': tool('lcp_buyer'),
    'atr_binding': tool('atr_rail'),
    'acceptance_test': tool('acceptance_test'),
    'forum_arbiter': tool('dispute_forum'),
    'sla_telemetry': tool('sla_event'),
    'git_anchors': tool('git_anchor'),
}
KEYS = ('sla', 'git')


def validate(flags):
    """A flags mapping names known plugins with boolean values. ``None`` is all off."""
    if flags is None:
        return {}
    need(type(flags) is dict and len(flags) <= len(DEFAULTS), 'PLUGIN_FLAGS')
    for name, value in flags.items():
        need(name in DEFAULTS, 'PLUGIN_UNKNOWN')
        need(type(value) is bool, 'PLUGIN_FLAGS')
    return dict(flags)


def enabled(flags, name):
    need(name in DEFAULTS, 'PLUGIN_UNKNOWN')
    return validate(flags).get(name, False) is True


def require(flags, name):
    need(enabled(flags, name), 'PLUGIN_DISABLED')
    return True


def plugin_tools():
    """Every plugin tool name, whether or not its flag is on."""
    return set(TOOLS.values())


def enabled_tools(flags):
    """Tool names whose flags are on."""
    return {TOOLS[name] for name, on in validate(flags).items() if on}


def flag_of(name):
    """The flag that owns a tool name, or PLUGIN_UNKNOWN."""
    for flag, tool_name in TOOLS.items():
        if tool_name == name:
            return flag
    raise ValueError('PLUGIN_UNKNOWN')


class HostPlugins:
    """Owner configuration. Constructed by the host, never from tool arguments.

    ``keys`` holds the host signing keys of the SLA and git tools; their output is
    the host's own statement. ``mandate`` is ``{'policy': signed reliance policy,
    'annex': signed buyer annex}`` and is verified here, once, against the policy's
    principal. ``forums`` is an owner-filled ``forum_arbiter.ArbiterRegistry``.
    ``clock`` returns integer seconds; the default is the host wall clock.
    """

    def __init__(self, flags=None, *, keys=None, mandate=None, forums=None, clock=None):
        self.flags = validate(flags)
        keys = {} if keys is None else keys
        need(type(keys) is dict and set(keys) <= set(KEYS), 'PLUGIN_KEYS')
        for value in keys.values():
            try:
                public_key(value)
            except (AttributeError, TypeError, ValueError):
                raise ValueError('PLUGIN_KEYS') from None
        self.keys = dict(keys)
        self.mandate = None
        if mandate is not None:
            from .lcp_buyer import adopt_mandate
            self.mandate = adopt_mandate(mandate)
        if forums is not None:
            from .forum_arbiter import ArbiterRegistry
            need(isinstance(forums, ArbiterRegistry), 'PLUGIN_FORUMS')
        self.forums = forums
        need(clock is None or callable(clock), 'PLUGIN_CLOCK')
        self._clock = clock

    def enabled(self, name):
        return enabled(self.flags, name)

    def require(self, name):
        return require(self.flags, name)

    def tools(self):
        return enabled_tools(self.flags)

    def key(self, name):
        need(name in KEYS, 'PLUGIN_KEYS')
        signer = self.keys.get(name)
        need(signer is not None, 'SLA_SIGNER' if name == 'sla' else 'GIT_SIGNER')
        return signer

    def now(self):
        value = int(time.time()) if self._clock is None else self._clock()
        need(type(value) is int and 0 <= value <= 2**53 - 1, 'PLUGIN_CLOCK')
        return value


def host_plugins(value):
    """Accept ``HostPlugins``, a bare flags mapping, or ``None``."""
    if value is None or isinstance(value, HostPlugins):
        return value
    return HostPlugins(value)
