"""Schema and dispatch for read-only review and existing-profile handoffs."""
from .cooperation_interface import HASH,INT,OBJECT,schema

TEXT={'type':'string','minLength':1,'maxLength':256}
ARRAY={'type':'array','maxItems':64,'items':OBJECT}
HEADS={'type':'array','maxItems':65,'items':HASH}
PARTIES={'type':'array','minItems':2,'maxItems':16,'items':HASH,'description':'Sorted unique identity hashes. This is an exact expectation against the actual signed native party set, not a new party proposal.'}
def rows(properties,required=('id',),description=''):
    # Case carriers historically preserve arbitrary nested rows for independent
    # per-item review. Advertise their exact usable shape without tightening
    # that carrier API or assigning validity to unverified caller fields.
    return {'type':'array','maxItems':64,'items':{**OBJECT,'description':description+' Expected fields: '+', '.join(properties)+'. Required for semantic review: '+', '.join(required)+'.','x-review-item-shape':schema(properties,required)}}

def spec():
    case={**OBJECT,'description':'Exact coordination case. Use start or case to construct it. Case0.4 adds explicit nonmonetary performance assertions; supplying performance selects it. Explicit case0.3 also admits BILATERAL rows with {id,kind,envelope,expected_id}, where expected_id is the exact envelope CID. Historical kinds retain their original hashes/approvals. Bilateral receipt claims are not observed funds; no automatic native mapping. links refer to section-local IDs. Unknown links confer no authority.'}
    sections={name:ARRAY for name in ('obligations','payments','evidence','grants','policies','bindings','links','decisions','recoveries','disputes')}
    performance_evidence=schema({'kind':{'enum':['DELIVERY','PROOF','REFERENCE']},'id':TEXT,'expected_hash':HASH},('kind','id','expected_hash'))
    assertion=schema({'agreement':TEXT,'obligation':TEXT,'role':TEXT,'identity':{},'status':{'enum':['OPEN','FULFILLED','DISPUTED','UNKNOWN']},'evidence':{'type':'array','maxItems':64,'items':performance_evidence}},('agreement','obligation','role','identity','status','evidence'))
    sections['performance']=rows({'id':TEXT,'agreement':TEXT,'label':TEXT,'responsible_role':TEXT,'required_roles':{'type':'array','minItems':1,'maxItems':16,'uniqueItems':True,'items':TEXT},'assertions':{'type':'array','maxItems':64,'items':assertion}},('id','agreement','label','responsible_role','required_roles','assertions'),'Case0.4. Explicit nonmonetary duty, pinned to a verified exact agreement hash or bilateral CID. Claims repeat the exact obligation ID and agreement pin; role and identity must match. Required roles are caller-selected coverage, not a signed discharge policy. Assertions are caller reported, not authenticated. Evidence DELIVERY uses content_cid/content_hash; PROOF uses case evidence id/SHA256(canonical evidence row); REFERENCE is always unverified. Payments never complete duties; unlisted duties remain unknown.')
    sections['obligations']=rows({'id':TEXT,'agreement':HASH,'payer':HASH,'payee':HASH,'asset':OBJECT,'amount':INT,'label':TEXT,'context':HASH},('id','agreement','payer','payee','asset','amount'),'Declared obligation; exact source bindings are optional and separate.')
    sections['payments']=rows({'id':TEXT,'adapter':HASH,'effect_id':HASH,'obligation':TEXT,'expected_context':HASH,'expected_head':HASH,'expected_output_hash':HASH,'authorization':schema({'label':TEXT,'body':OBJECT,'signature':{'type':'string'}},('label','body','signature')),'authorization_agreement':HASH,'expected_authorization_domain':HASH},('id','adapter','effect_id'),'Actual owner-observed effect. Optional exact payer-signed trial authorization selects case0.2 and never edits the receipt.')
    sections['bindings']=rows({'id':TEXT,'agreement':HASH,'document':TEXT,'path':{'type':'string','maxLength':1024},'expected':{}},('id','agreement','path','expected'))
    sections['links']=rows({'from':TEXT,'to':TEXT,'relation':{**TEXT,'description':'Checked literal relations: amount, payer, payee, asset to obligation; evidence_root to evidence; case_reference and finding_reference from a signed binding to dispute. decision_adoption joins agreement to exact decision snapshot. Other caller-defined relation labels are declared associations only.'},'document':TEXT},('from','to','relation'))
    sections['decisions']=rows({'id':TEXT,'parameters':{**OBJECT,'description':'Actual covenant_review.decision parameters, including proposal and exact causal heads. Flat row proposal/heads are not this carrier.'}},('id','parameters'))
    sections['recoveries']=rows({'id':TEXT,'parameters':OBJECT,'policy_reference':{'type':'string','maxLength':1024}},('id','parameters'))
    sections['disputes']=rows({'id':TEXT,'case_event':HASH,'finding_event':HASH,'agreement':HASH,'settlement_agreement':HASH,'obligation':TEXT,'group':HASH,'required_parties':PARTIES,'designated_arbitrator':HASH,'excluded_obligations':{'type':'array','maxItems':64,'items':TEXT},'expected_scope':{'type':'string','maxLength':4096},'expected_heads':HEADS,'expected_target':HASH},('id','case_event'),'Case0.2. Actual native adoption/finding checks; associations and exclusions remain declared unless explicit signed-field links verify exact references.')
    sections.update(notes={'type':'array','maxItems':64,'items':{'type':'string','minLength':1,'maxLength':4096}},primary=TEXT,group=HASH,expected_heads=HEADS)
    return ('covenant_review','One read-only review linking exact agreements, authority, evidence, payments, obligations and disputes. case returns a RAW case: pass it directly to review. start and amend_case return wrappers: use result.case; start also has result.prepared. render returns result.html. Call spec for exact response_shapes, bilateral case0.3, performance case0.4 and the versioned independent carrier checker. Never signs, emits, installs, revokes, funds or executes. Literal source bindings do not interpret legal prose.',True,[
        ('spec',{},()),
        ('case',{'title':TEXT,'version':{'enum':['covenant-coordination-case/0.1','covenant-coordination-case/0.2','covenant-coordination-case/0.3','covenant-coordination-case/0.4'],'description':'Case0.3 or0.4 adoption is required for BILATERAL verification. Supplying performance selects0.4. Otherwise omission preserves the historical0.1/0.2 constructor selection.'},'agreements':ARRAY,**sections},('title',)),
        ('amend_case',{'before':case,'changes':{**OBJECT,'description':'Replace chosen whole sections/title/primary/group/heads in a new case; old case and agreement bytes are preserved unless explicitly replaced. A new case pin is required.'}},('before','changes')),
        ('start',{'title':TEXT,'parties':OBJECT,'context_value':{},'terms':{'type':'string','minLength':1,'maxLength':16384},'source_base64':{'type':'string','maxLength':349528},'media_type':TEXT,'language':TEXT,'meaning':{'type':'string','minLength':1,'maxLength':4096},'previous':OBJECT},('title','parties','context_value')),
        ('review',{'case':case,'expected_id':HASH},('case',)),
        ('render',{'case':case,'expected_id':HASH,'source_documents':{'type':'array','maxItems':8,'items':schema({'agreement':TEXT,'document':TEXT},('agreement',))},'source_objects':{'type':'array','maxItems':8,'items':schema({'agreement':TEXT,'path':{'type':'string','maxLength':1024}},('agreement',))}},('case',)),
        ('open_source',{'case':case,'agreement':TEXT,'document':{**TEXT,'description':'Named external byte document alias, e.g. terms. For typed CONCEPT/ORDER/LEGAL values use open_object instead.'},'expected_id':HASH,'encoding':{'enum':['UTF8','BASE64']}},('case','agreement')),
        ('open_object',{'case':case,'agreement':TEXT,'path':{'type':'string','maxLength':1024,'description':'Optional exact JSON pointer into the typed root, e.g. /extensions/settlement. Empty opens the selected whole typed root; external byte documents remain separate.'},'expected_id':HASH},('case','agreement')),
        ('authorization_scopes',{'case':case,'authorization':OBJECT,'expected_id':HASH,'expected_domain':HASH},('case','authorization')),
        ('permissions',{'group':HASH,'actor':HASH,'expected_heads':HEADS},('group',)),
        ('dispute',{'case_event':HASH,'finding_event':HASH,'expected_group':HASH,'expected_parties':PARTIES,'expected_arbitrator':HASH,'expected_heads':HEADS},('case_event',)),
        ('compare',{'before':case,'after':case},('before','after')),
        ('preflight',{'adapter':HASH,'spec':OBJECT,'request':OBJECT},('adapter',)),
        ('cashflow',{'adapter':HASH,'actor':HASH,'requests':ARRAY,'expected_balance':INT},('adapter','actor','requests')),
        ('milestones',{'name':TEXT,'payer':HASH,'payee':HASH,'asset':OBJECT,'amounts':{'type':'array','minItems':1,'maxItems':32,'items':{'type':'integer','minimum':1,'maximum':2**53-1}},'controllers':{'type':'array','minItems':2,'maxItems':8,'items':HASH},'threshold':{'type':'integer','minimum':2,'maximum':8},'context':HASH,'adapter':HASH,'labels':{'type':'array','maxItems':32,'items':TEXT}},('name','payer','payee','asset','amounts','controllers','threshold','context','adapter')),
        ('authority',{'agreements':ARRAY,'grants':ARRAY,'group':HASH,'expected_heads':HEADS,'policies':ARRAY},('agreements',)),
        ('evidence',{'items':ARRAY,'agreement_ids':{'type':'array','maxItems':64,'items':HASH}},('items','agreement_ids')),
        ('private_copy',{'plan':OBJECT,'step':TEXT,'recipients':{**OBJECT,'description':'Name to adopted recipient descriptor. Built-in: {name: {"ML-KEM-768": lowercase_public_hex}}, 1184 bytes / 2368 hex characters. Empty map and empty fields explicitly withhold a successor. Other owner-installed methods keep their own descriptor.'},'value':{},'fields':{'type':'array','maxItems':32,'items':{'type':'string','maxLength':1024}},'salts':OBJECT,'previous_approvals':ARRAY,'expected_previous':HASH},('plan','step','recipients','value','fields','salts')),
        ('decision',{'proposal':HASH,'heads':HEADS,'desire':OBJECT,'objects':{'type':'array','maxItems':256,'items':OBJECT},'edges':{'type':'array','maxItems':4096,'items':OBJECT},'seeds':{'type':'array','maxItems':256,'items':OBJECT},'expected_result':OBJECT,'title':TEXT,'parties':OBJECT},('proposal','heads')),
        ('recovery',{'bundles':{'type':'array','minItems':1,'maxItems':16,'items':OBJECT},'expected_heads':HEADS,'expected_agreement':OBJECT,'proposed':OBJECT},('bundles',)),
        ('changed_heads',{'proposed':OBJECT,'expected_heads':HEADS},('proposed',))])

def call(tools,action,parameters):
    from . import coordination_review as review,coordination_finance as finance
    from . import coordination_privacy as privacy,coordination_collective as collective
    if action in ('spec','case','compare','amend_case'):return getattr(review,action)(**parameters)
    if action in ('start','review','render','open_source','open_object','authorization_scopes'):return getattr(review,action)(tools,**parameters)
    if action in ('permissions','dispute'):
        from . import coordination_disputes
        return getattr(coordination_disputes,action)(tools,**parameters)
    if action in ('preflight','cashflow','milestones'):return getattr(finance,action)(tools,**parameters)
    if action in ('authority','evidence','private_copy'):return getattr(privacy,action)(tools,**parameters)
    return getattr(collective,action)(tools,**parameters)
