"""Fixed accounting adapters for already adopted native profiles.

The order and validation errors preserve native 0.1--0.14 semantics. New
applications cannot register pools remotely or bypass their internal audits.
"""
from .crypto import need

POOLS=(('bridge_retired',None,None),('bridge_locked',None,None),('shielded_escrow',None,None),
       ('continuity_held','CONTINUITY_HELD',None),
       ('market_held','MARKET_HELD','market'),
       ('prediction_held','PREDICTION_HELD','prediction'),
       ('upgrade_deposits','UPGRADE_DEPOSIT',None),
       ('arbitrator_stake','ARBITRATOR_STAKE',None),
       ('arbitration_held','ARBITRATION_HELD',None))


def partitions(state):
    return [state[name] for name,_,_ in POOLS if name in state]


def add_deltas(state,resources):
    for name,error,audit in POOLS:
        if name not in state:continue
        if audit=='market':
            from .market_audit import check_accounting_deltas
            check_accounting_deltas(state)
        elif audit=='prediction':
            from .prediction_audit import check_accounting_deltas
            check_accounting_deltas(state)
        for resource,old,new in state[name].changes():
            if error:need(type(new) is int and new>=0,error)
            resources[resource]+=new-(old or 0)
