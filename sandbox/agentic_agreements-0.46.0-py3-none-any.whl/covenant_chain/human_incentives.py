"""Human-user incentives collected by economics.charge. Nothing here moves a balance.

Token discount and token cashback use `token_preference`. The discount comes
out of surplus, so the price stays at least the measured cost. Cashback cannot
exceed the rebate row the fee already funded. First-agreement sponsorship
spends an existing sponsor escrow once. It does not mint a waiver.
"""
from .crypto import integer, need
from .token_preference import cashback, discount_bps

PROGRAM = 'first_agreement'
PARAMETERS = {'program': PROGRAM, 'launch_discount_bps': 3000, 'lock_bonus_clipped_to_giveback': True}


def paying_in_token(policy, transaction):
    if not transaction:
        return False
    fee = (transaction.get('body') or {}).get('fee') or {}
    asset = fee.get('asset')
    return bool(asset) and asset == policy['scale']['supply']['resource']


def stake_locked(view, actor):
    row = (view.get('positions') or {}).get(actor) if actor else None
    if not row or row.get('unbonding'):
        return False
    height = view.get('height') or 0
    return row.get('locked_at', height) < height


def surplus_discount(price, unit_cost, qualified_volume, in_token, lock_cut):
    """Launch discount plus any warmed-lock discount, capped by the surplus."""
    integer(price)
    integer(unit_cost)
    integer(qualified_volume)
    integer(lock_cut)
    if price <= unit_cost:
        return 0
    margin = price - unit_cost
    launch = price * discount_bps(qualified_volume) // 10000 if in_token else 0
    return min(margin, launch + lock_cut)


def token_cashback(giveback, locked, in_token):
    """Receipt figure only. The lock bonus cannot exceed the funded rebate."""
    integer(giveback)
    if not in_token or giveback <= 0:
        return 0
    quoted = cashback(giveback, 1 if locked else 0)
    return min(giveback, quoted['token'])


def claim_first_agreement(meter, agreements, actor, current_id):
    """One sponsored first agreement per actor. The agreement just bound does not count."""
    used = dict(meter.get('first_agreements') or {})
    need(actor not in used, 'FIRST_AGREEMENT_USED')
    for agreement_id, agreement in agreements.items():
        if agreement_id == current_id:
            continue
        terms = agreement.get('terms') or {}
        if terms.get('principal') == actor:
            raise ValueError('FIRST_AGREEMENT_USED')
    used[actor] = True
    need(len(used) <= 4096, 'FIRST_AGREEMENT_LIMIT')
    meter['first_agreements'] = used
    return used
