"""Opt-in native 0.11 authority continuity. Existing native profiles are unchanged.

An operational signature AND an adopted hash-signature quorum protect every
new exercise by this principal. Recovery is guardian-authorized, delayed and
cannot be cancelled using the compromised operational key. Underlying ledger
hashes, consensus keys, private-note custody and outside adapters are not upgraded.
"""
from copy import deepcopy
import hashlib
from .crypto import canonical, exact, need, integer, key, sign, verify, public_key, verification_key, digest
from .defense import HASH, backend, fingerprints, _hex
from .state import Table

from .guarded import LABEL, SIGNATURE, _message, verify_guarded, verify_hash
VERSION='covenant-authority-continuity/0.1'
NATIVE='covenant-native/0.11'

def policy_id(policy):
    return hashlib.sha512(b'COVENANT-CONTINUITY-POLICY-0.1\0'+canonical(policy)).hexdigest()

def validate_policy(p,entity):
    exact(p,'version entity generation previous guardians threshold delay authorities commitments batches')
    need(p['version']==VERSION and p['entity']==entity,'CONTINUITY_POLICY_CONTEXT');key(entity)
    integer(p['generation']);integer(p['threshold'],True);integer(p['delay'],True)
    need(type(p['guardians']) is dict and 1<=len(p['guardians'])<=3,'CONTINUITY_GUARDIANS')
    need(p['threshold']<=min(2,len(p['guardians'])) and p['delay']<=10000,'CONTINUITY_BOUNDS')
    need((p['generation']==0 and p['previous'] is None) or
         (p['generation']>0 and type(p['previous']) is str and len(p['previous'])==128 and
          all(c in '0123456789abcdef' for c in p['previous'])),'CONTINUITY_LINEAGE')
    seen=set()
    for name,pk in p['guardians'].items():
        need(type(name) is str and 1<=len(name)<=80,'CONTINUITY_GUARDIAN_NAME')
        exact(pk,'suite key');need(pk['suite']==HASH,'CONTINUITY_HASH_SUITE')
        _hex(pk['key'],backend(HASH).PUBLIC_KEY_SIZE)
        need(pk['key'] not in seen,'CONTINUITY_GUARDIAN_ALIAS');seen.add(pk['key'])
    need(p['authorities'] in {'KEEP_BOUNDED','REVOKE_NATIVE'} and p['commitments']=='PRESERVE',
         'CONTINUITY_OUTSTANDING_POLICY')
    need(p['batches'] in {'CANCEL_AND_REFUND','PRESERVE_EXACT'},'CONTINUITY_BATCH_POLICY')
    return p

def make_policy(entity,guardians,*,generation=0,previous=None,threshold=1,delay=3,
                authorities='REVOKE_NATIVE',batches='CANCEL_AND_REFUND'):
    p={'version':VERSION,'entity':entity,'generation':generation,'previous':previous,
       'guardians':deepcopy(guardians),'threshold':threshold,'delay':delay,
       'authorities':authorities,'commitments':'PRESERVE','batches':batches}
    validate_policy(p,entity);return p

def initialize(s,g):
    exact(g['continuity'],'version policies');need(g['continuity']['version']==VERSION,'CONTINUITY_VERSION')
    policies=g['continuity']['policies'];need(type(policies) is dict and len(policies)<=64,'CONTINUITY_INITIAL_POLICIES')
    for table in ['continuity_policies','continuity_pending','continuity_batches','continuity_spends']:
        s[table]=Table()
    s['continuity_held']=Table({rid:0 for rid in s['resources']})
    for entity,p in policies.items():
        validate_policy(p,entity);need(p['generation']==0,'CONTINUITY_INITIAL_GENERATION')
        s['continuity_policies'][entity]={'body':deepcopy(p),'id':policy_id(p),'event':None,'authority_epoch':0}

def authority_epoch(s,entity):
    return s.get('continuity_policies',{}).get(entity,{}).get('authority_epoch',0)

def descriptor(s,entity,ordinary):
    r=s.get('continuity_policies',{}).get(entity)
    if r is None:return ordinary
    return {'suite':SIGNATURE,'chain':s['chain'],'entity':entity,'policy':r['id'],
            'generation':r['body']['generation'],'controller_epoch':s['controller_epochs'].get(entity,0),
            'policy_fingerprints':fingerprints(canonical(r['body'])),
            'controller':ordinary,'guardians':r['body']['guardians'],'threshold':r['body']['threshold'],
            'paused':s['continuity_pending'].get(entity) is not None}

def hash_approvals(policy,label,body,secrets):
    need(type(secrets) is dict,'CONTINUITY_SECRETS')
    for member,secret in sorted(secrets.items()):
        need(member in policy['guardians'],'CONTINUITY_SIGNER')
        need(type(secret) is bytes and len(secret)==backend(HASH).SECRET_KEY_SIZE,'CONTINUITY_SECRET_SIZE')
    need(len(secrets)>=policy['threshold'],'CONTINUITY_HASH_QUORUM')
    message=label.encode('ascii')+b'\0'+canonical(body);proofs=[]
    # Carry exactly a quorum, even when the demo caller holds backup keys too.
    # Independent deployed guardians assemble the same bounded proof format.
    for member,secret in sorted(secrets.items())[:policy['threshold']]:
        proofs.append({'member':member,'signature':backend(HASH).sign(secret,message).hex()})
    return proofs

class GuardianShare:
    """One guardian secret. It cannot assemble a quorum by itself when threshold exceeds one."""
    def __init__(self,member,secret):
        need(type(member) is str and 1<=len(member)<=80,'CONTINUITY_GUARDIAN_NAME')
        need(type(secret) is bytes and len(secret)==backend(HASH).SECRET_KEY_SIZE,'CONTINUITY_SECRET_SIZE')
        self.member=member;self.secret=secret
    def approval(self,policy,label,body):
        need(type(policy) is dict and self.member in policy['guardians'],'CONTINUITY_SIGNER')
        message=label.encode('ascii')+b'\0'+canonical(body)
        return {'member':self.member,'signature':backend(HASH).sign(self.secret,message).hex()}

class GuardedSigner:
    """Operational signer. Guardian secrets stay in a separate loader.

    Passing ``guardian_secrets`` keeps both halves in this process and requires
    ``colocate=True``. A compromised process that holds both defeats the split.
    Production hosts should pass ``guardian_loader`` so the guardian bytes exist
    only for the duration of one signature.
    """
    def __init__(self,state,entity,operational_key,guardian_secrets=None,*,colocate=False,guardian_loader=None):
        if guardian_loader is not None and guardian_secrets is not None:
            raise ValueError('CONTINUITY_GUARDIAN_CHANNEL')
        if guardian_secrets is not None and colocate is not True:
            raise ValueError('CONTINUITY_SECRETS_COLOCATED')
        if guardian_loader is not None and not callable(guardian_loader):
            raise ValueError('CONTINUITY_GUARDIAN_CHANNEL')
        r=state.get('continuity_policies',{}).get(entity);need(r is not None,'CONTINUITY_UNPROTECTED')
        ordinary=state['controllers'].get(entity,entity)
        need(public_key(operational_key)==ordinary,'CONTINUITY_CONTROLLER_KEY')
        self.descriptor=entity;self.policy=deepcopy(r['body']);self.view=descriptor(state,entity,ordinary)
        self.operational=operational_key
        self._secrets=guardian_secrets
        self._loader=guardian_loader
    def _pack(self,label,body,secrets):
        return {'version':SIGNATURE,'policy':self.view['policy'],'generation':self.view['generation'],
                'controller_epoch':self.view['controller_epoch'],'operational':sign(self.operational,label,body),
                'guardians':hash_approvals(self.policy,LABEL,_message(self.view,label,body),secrets)}
    def sign_native(self,label,body,guardian_proofs=None):
        if guardian_proofs is not None:
            need(type(guardian_proofs) is list,'CONTINUITY_HASH_QUORUM')
            threshold=self.policy['threshold']
            need(len(guardian_proofs)>=threshold,'CONTINUITY_HASH_QUORUM')
            for proof in guardian_proofs:need(type(proof) is dict and type(proof.get('member')) is str,'CONTINUITY_SIGNER')
            proofs=sorted(guardian_proofs,key=lambda proof:proof['member'])[:threshold]
            return {'version':SIGNATURE,'policy':self.view['policy'],'generation':self.view['generation'],
                    'controller_epoch':self.view['controller_epoch'],'operational':sign(self.operational,label,body),
                    'guardians':proofs}
        if self._loader is not None:
            secrets=self._loader()
            try:
                return self._pack(label,body,secrets)
            finally:
                if type(secrets) is dict:
                    secrets.clear()
        need(self._secrets is not None,'CONTINUITY_GUARDIAN_CHANNEL')
        return self._pack(label,body,self._secrets)

class LocalQuorum:
    """Explicit rehearsal composer. A process that only holds ``GuardedSigner`` cannot meet quorum."""
    def __init__(self,signer,shares):
        need(type(signer) is GuardedSigner and type(shares) is tuple and shares,'CONTINUITY_SECRETS')
        self.signer=signer;self.shares=shares
        self.descriptor=signer.descriptor;self.view=signer.view
    def sign_native(self,label,body):
        message=_message(self.view,label,body)
        ordered=sorted(self.shares,key=lambda share:share.member)[:self.signer.policy['threshold']]
        proofs=[share.approval(self.signer.policy,LABEL,message) for share in ordered]
        return self.signer.sign_native(label,body,proofs)

def local_quorum(state,entity,operational_key,guardian_secrets):
    """Compose an operational signer with separately constructed guardian shares.

    This is a local rehearsal helper. Deployed guardians should return proofs
    without placing every secret in the operational process.
    """
    need(type(guardian_secrets) is dict and guardian_secrets,'CONTINUITY_SECRETS')
    shares=tuple(GuardianShare(member,secret) for member,secret in guardian_secrets.items())
    return LocalQuorum(GuardedSigner(state,entity,operational_key),shares)

def preflight(s,op,p,actor):
    protected=s['continuity_policies']
    if actor in protected and op in {'ROTATE','SET_CONTROLLER_SUITE','SET_RECOVERY','CANCEL_RECOVERY'}:
        raise ValueError('USE_CONTINUITY_CONTROL_PATH')
    if op in {'REQUEST_RECOVERY','RECOVER'} and type(p.get('entity')) is str and p['entity'] in protected:
        raise ValueError('USE_CONTINUITY_RECOVERY_PATH')

def acceptance_body(s,policy,source_root,successor=None):
    return {'chain':s['chain'],'policy':policy,'source_root':source_root,'successor':successor}

def recovery_body(s,entity,successor):
    r=s['continuity_policies'][entity]
    return {'chain':s['chain'],'entity':entity,'policy':r['id'],
            'generation':r['body']['generation'],'successor':successor}

def _adopt(s,entity,p,event,successor=None):
    old=s['continuity_policies'].get(entity);epoch=old['authority_epoch'] if old else 0
    if p['authorities']=='REVOKE_NATIVE':epoch+=1
    s['continuity_policies'][entity]={'body':deepcopy(p),'id':policy_id(p),'event':event,'authority_epoch':epoch}
    if successor is not None:
        s['controllers'][entity]=deepcopy(successor)
        s['controller_epochs'][entity]=s['controller_epochs'].get(entity,0)+1
    # Superseded legacy requests cannot regain authority later.
    s['recovery_requests'][entity]=None;s['continuity_pending'][entity]=None

def apply(s,previous,op,p,actor,tid,height):
    from .balances import amount, add
    from .roots import state_hash
    if op in {'CONTINUITY_INSTALL','CONTINUITY_RENEW'}:
        fields='policy source_root acceptances'+(' successor possession' if op.endswith('RENEW') else '')
        exact(p,fields);validate_policy(p['policy'],actor)
        need(p['source_root']==state_hash(previous),'CONTINUITY_SOURCE_ROOT')
        old=s['continuity_policies'].get(actor);new=p['policy']
        if op.endswith('INSTALL'):need(old is None and new['generation']==0,'CONTINUITY_ALREADY_PROTECTED')
        else:
            need(old is not None and new['generation']==old['body']['generation']+1 and new['previous']==old['id'],
                 'CONTINUITY_SUCCESSION')
            verification_key(p['successor'])
        body=acceptance_body(s,new,p['source_root'],p.get('successor'))
        verify_hash(new,'COVENANT-CONTINUITY-ACCEPT-0.1',body,p['acceptances'])
        if 'successor' in p:verify(p['successor'],'COVENANT-CONTINUITY-POSSESSION-0.1',body,p['possession'])
        _adopt(s,actor,new,tid,p.get('successor'));return [old['event']] if old and old['event'] else []
    if op=='CONTINUITY_RECOVERY_REQUEST':
        exact(p,'entity successor policy generation approvals possession');entity=p['entity'];key(entity)
        need(entity in s['continuity_policies'],'CONTINUITY_UNPROTECTED');r=s['continuity_policies'][entity]
        verification_key(p['successor']);body=recovery_body(s,entity,p['successor'])
        need(p['policy']==body['policy'] and p['generation']==body['generation'],'CONTINUITY_RECOVERY_CONTEXT')
        need(s['continuity_pending'].get(entity) is None,'CONTINUITY_RECOVERY_PENDING')
        verify_hash(r['body'],'COVENANT-CONTINUITY-RECOVER-0.1',body,p['approvals'])
        verify(p['successor'],'COVENANT-CONTINUITY-RECOVER-POSSESSION-0.1',body,p['possession'])
        s['continuity_pending'][entity]={'body':body,'id':tid,'ready':height+r['body']['delay']}
        return [r['event']] if r['event'] else []
    if op=='CONTINUITY_RECOVERY_CANCEL':
        exact(p,'entity request approvals');entity=p['entity'];key(entity);r=s['continuity_pending'].get(entity)
        need(r and r['id']==p['request'],'CONTINUITY_RECOVERY_REQUEST')
        body={'chain':s['chain'],'entity':entity,'request':p['request'],'policy':r['body']['policy']}
        verify_hash(s['continuity_policies'][entity]['body'],'COVENANT-CONTINUITY-CANCEL-0.1',body,p['approvals'])
        s['continuity_pending'][entity]=None;return [r['id']]
    if op=='CONTINUITY_RECOVER':
        exact(p,'entity request');entity=p['entity'];key(entity);r=s['continuity_pending'].get(entity)
        need(r and r['id']==p['request'],'CONTINUITY_RECOVERY_REQUEST');need(height>=r['ready'],'CONTINUITY_RECOVERY_DELAY')
        old=s['continuity_policies'][entity]
        need(r['body']['policy']==old['id'] and r['body']['generation']==old['body']['generation'],'CONTINUITY_STALE_RECOVERY')
        new=deepcopy(old['body']);new['previous']=old['id'];new['generation']+=1
        _adopt(s,entity,new,tid,r['body']['successor']);return [r['id']]
    if op=='CONTINUITY_BATCH':
        exact(p,'instructions expiry cancellable');need(actor in s['continuity_policies'],'CONTINUITY_UNPROTECTED')
        integer(p['expiry'],True);need(height<=p['expiry']<=height+10000 and type(p['cancellable']) is bool,'CONTINUITY_BATCH_BOUNDS')
        rows=p['instructions'];need(type(rows) is list and 1<=len(rows)<=32,'CONTINUITY_BATCH_COUNT')
        totals={}
        for row in rows:
            exact(row,'resource recipient quantity');key(row['recipient']);integer(row['quantity'],True)
            need(type(row['resource']) is str and row['resource'] in s['resources'],'RESOURCE');totals[row['resource']]=totals.get(row['resource'],0)+row['quantity']
            integer(totals[row['resource']])
        for rid,qty in totals.items():
            need(amount(s['balances'],actor,rid)>=qty and amount(s['authority_available'],actor,rid)>=qty,'CONTINUITY_BATCH_BACKING')
            add(s['balances'],actor,rid,-qty);add(s['authority_available'],actor,rid,-qty)
            s['continuity_held'][rid]=s['continuity_held'].get(rid,0)+qty
        r=s['continuity_policies'][actor]
        s['continuity_batches'][tid]={'issuer':actor,'policy':r['id'],'on_renewal':r['body']['batches'],
            'instructions':deepcopy(rows),'expiry':p['expiry'],'cancellable':p['cancellable'],
            'remaining':totals,'closed':False}
        return [r['event']] if r['event'] else []
    if op in {'CONTINUITY_BATCH_EXECUTE','CONTINUITY_BATCH_CLOSE'}:
        exact(p,'batch index' if op.endswith('EXECUTE') else 'batch reason');key(p['batch'])
        need(p['batch'] in s['continuity_batches'],'CONTINUITY_BATCH_MISSING');b=s['continuity_batches'][p['batch']]
        need(not b['closed'],'CONTINUITY_BATCH_CLOSED')
        changed=s['continuity_policies'][b['issuer']]['id']!=b['policy']
        if op.endswith('EXECUTE'):
            integer(p['index']);need(p['index']<len(b['instructions']),'CONTINUITY_BATCH_INDEX')
            need(s['continuity_pending'].get(b['issuer']) is None,'CONTINUITY_RECOVERY_PENDING')
            need(height<=b['expiry'] and (not changed or b['on_renewal']=='PRESERVE_EXACT'),'CONTINUITY_BATCH_STALE')
            sid=digest('COVENANT-CONTINUITY-SPEND-0.1',{'batch':p['batch'],'index':p['index']})
            need(sid not in s['continuity_spends'],'CONTINUITY_BATCH_REPLAY');row=b['instructions'][p['index']]
            rid,qty=row['resource'],row['quantity'];b['remaining'][rid]-=qty;s['continuity_held'][rid]-=qty
            add(s['balances'],row['recipient'],rid,qty);add(s['authority_available'],row['recipient'],rid,qty)
            s['continuity_spends'][sid]=tid
        else:
            reason=p['reason']
            need((reason=='EXPIRED' and height>b['expiry']) or
                 (reason=='RENEWED' and changed and b['on_renewal']=='CANCEL_AND_REFUND') or
                 (reason=='ISSUER_CANCEL' and actor==b['issuer'] and b['cancellable']), 'CONTINUITY_BATCH_CLOSE_AUTHORITY')
            for rid,qty in b['remaining'].items():
                s['continuity_held'][rid]-=qty;add(s['balances'],b['issuer'],rid,qty);add(s['authority_available'],b['issuer'],rid,qty)
                b['remaining'][rid]=0
            b['closed']=True
        return [p['batch']]
    return None

def inventory(state,entity,limit=10000):
    """Read-only control map. Explicitly reports boundaries it cannot establish."""
    key(entity);integer(limit,True);need(limit<=10000,'CONTINUITY_INVENTORY_LIMIT')
    r=state.get('continuity_policies',{}).get(entity);rows=[];count=0;truncated=False
    for table,field in [('grants','principal'),('permissions','issuer'),('continuity_batches','issuer')]:
        for rid,row in state.get(table,{}).items():
            count+=1
            if count>limit:truncated=True;break
            if row.get(field)==entity:rows.append({'table':table,'id':rid,'value':deepcopy(row)})
        if truncated:break
    commitments=[]
    for cid,a in state.get('agreements',{}).items():
        count+=1
        if count>limit:truncated=True;break
        if a['terms']['principal']==entity and a['held']:commitments.append(cid)
    return {'entity':entity,'protocol':state.get('protocol'),'protected':r is not None,
            'policy':deepcopy(r),'pending':deepcopy(state.get('continuity_pending',{}).get(entity)),
            'control_paths':['transactions','bilateral assent','mutual discharge','institution governor approvals',
                             'fee-policy approvals','controller renewal','guardian recovery'],
            'standing_native_authorities':rows,'preserved_bound_commitments':commitments,
            'complete_within_scanned_tables':not truncated,
            'unknown_or_separate':['existing private-note spending secrets','third-party execution adapters',
              'pre-existing world roles and service contracts','fee sponsorship already authorized',
              'validator quorum and ledger hash security','outside legal authority'],
            'assurance':'ADOPTED_NATIVE_CONTROL_POLICY_ONLY' if r else 'UNPROTECTED'}

def rehearse(state,transactions,height,expected_source_root):
    """Pure native simulation pinned to an independently chosen certified state."""
    from .app import apply_transaction
    from .roots import state_hash
    need(state_hash(state)==expected_source_root,'CONTINUITY_SOURCE_ROOT')
    need(type(transactions) is list and 1<=len(transactions)<=32,'CONTINUITY_REHEARSAL_COUNT')
    trial=deepcopy(state)
    for offset,tx in enumerate(transactions):trial=apply_transaction(trial,tx,height+offset)
    return {'source_root':expected_source_root,'result_root':state_hash(trial),
            'transactions':[digest('COVENANT-TX-ID-0.1',t['body']) for t in transactions],
            'state':trial,'external_effects_performed':False}
