"""Separate facets and ``eligible(presentations, requirement)`` (covenant-eligibility/0.1).

A counterparty is eligible for a purpose only when every facet the relying party
requires is MET by evidence of that facet:

* identity: an adopted issuer's selective-disclosure claims (``hidden_credentials``);
* qualifications: ``covenant-agent-accreditation`` presentations, plain /0.1 or
  selective /sd, under the relying party's adopted policy, with market type
  matching (``market_accreditation``) and the status snapshot's age stated;
* spending authority: an owner-rooted capability chain with a fresh witnessed
  revocation snapshot (``portable_trust``), or an owner-installed checker;
* financial backing: holder-signed stake attestations from adopted holders for
  this agreement (``anchored_reputation`` STAKE records), each counted once;
* reputation: outcome receipts weighed by the relying party's own trusted
  contacts in one context (``portable_trust.local_reputation``).

Each facet is reported on its own, with source, issuer, freshness and limits.
Nothing is blended into a score, and eligibility is decided before any ranking:
a ranking may order only eligible counterparties. UNKNOWN is never MET. High-risk
checks need fresh qualification status, or a value within an explicitly agreed
limited exposure. Presentations, records and checker results are data: none can
grant authority, and none is executed.
"""
from copy import deepcopy
import json

from . import accreditation_disclosure as disclosure
from . import accreditation_status as status_lists_check
from . import accreditation_trust as rotation
from . import agent_accreditation as accreditation
from . import anchored_reputation as anchored
from . import hidden_credentials as hidden
from . import market_accreditation as market
from . import portable_trust as trust
from .crypto import integer, key, need, verification_key
from .json_bounds import validate_json

VERSION = 'covenant-eligibility/0.1'
FACETS = ('identity', 'qualifications', 'spending_authority', 'financial_backing', 'reputation')
STATUSES = ('MET', 'UNMET', 'UNKNOWN', 'NOT_REQUIRED')
RISKS = ('NORMAL', 'HIGH')
MAX_ITEMS = 16
MAX_ENTRIES = 8
MAX_INPUT = 4_000_000
UNKNOWN_CODES = frozenset(('ACCREDITATION_STATUS_STALE', 'ACCREDITATION_STATUS_UNKNOWN'))

ERRORS = {
    'ELIGIBILITY_REQUIREMENT': ('The requirement is malformed.',
                                'Build it with eligibility.requirement(); every facet fragment has a documented shape.', False),
    'ELIGIBILITY_PRESENTATIONS': ('The presentations are not {facet: [items]} with known facets and bounded items.',
                                  'Group evidence by facet name; at most 16 items per facet.', False),
    'ELIGIBILITY_SIZE': ('The input is larger than the bound.', 'Keep presentations and requirement under 4 MB.', False),
    'ELIGIBILITY_CHECKER': ('An owner-installed checker returned a result outside the plain interface.',
                            'Return {status, source, issuer, freshness, limits, reasons} with status MET, UNMET or '
                            'UNKNOWN and no authority.', False),
    # Reasons reported inside a facet; they refuse nothing by themselves.
    'ELIGIBILITY_NO_EVIDENCE': ('No evidence was presented for a required facet.', 'Ask the counterparty for it.', True),
    'ELIGIBILITY_SUBJECT_MISMATCH': ('The evidence is about another key than the counterparty.',
                                     'Ask for evidence bound to the counterparty\'s key.', False),
    'ELIGIBILITY_FRESH_STATUS_REQUIRED': ('A high-risk check needs a fresher status snapshot than the one supplied.',
                                          'Obtain fresh status, or agree a limited exposure covering this value.', True),
    'ELIGIBILITY_BACKING_STALE': ('A stake attestation is older than the maximum age the relying party accepts.',
                                  'Ask the holder for a fresh attestation.', True),
    'ELIGIBILITY_BACKING_SHORT': ('Adopted holders attest less than the required amount for this agreement.',
                                  'Ask for more backing from an adopted holder, or reduce the requirement.', False),
    'ELIGIBILITY_REPUTATION_SHORT': ('Receipts from trusted contacts do not reach the required support, or exceed the '
                                     'tolerated failures.', 'Proceed only with other evidence, or decline.', False),
    'ELIGIBILITY_CAPABILITY_NOT_CURRENT': ('The capability verified, but no fresh witnessed revocation snapshot shows it '
                                           'unrevoked.', 'Supply a fresh witnessed revocation snapshot.', True),
}

# What happened, then what to do, for each code raised here (the shared verifier-store code in
# agent_accreditation's words): the plain-text form tools/production_readiness.py reads.
# ERRORS keeps the retry hints.
REMEDIATION = {
    'ELIGIBILITY_SIZE': 'The input is larger than the bound. Keep presentations and requirement under 4 MB.',
    'ELIGIBILITY_REQUIREMENT':
        'The requirement is malformed. Build it with eligibility.requirement(); every facet fragment has a '
        'documented shape.',
    'ELIGIBILITY_PRESENTATIONS':
        'The presentations are not {facet: [items]} with known facets and bounded items. Group evidence by '
        'facet name; at most 16 items per facet.',
    'ELIGIBILITY_CHECKER':
        'An owner-installed checker returned a result outside the plain interface. Return {status, source, '
        'issuer, freshness, limits, reasons} with status MET, UNMET or UNKNOWN and no authority.',
    'ACCREDITATION_VERIFIER_STORE_REQUIRED':
        'This check needs an owner verifier store to stop replays and rollbacks. Open a VerifierStore and '
        'pass it as store.',
}


def explain(code):
    if code not in ERRORS:
        if code in rotation.ERRORS:
            return rotation.explain(code)
        return market.explain(code) if code.startswith('MARKET_') else disclosure.explain(code)
    happened, fix, retry = ERRORS[code]
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/AGENT_ACCREDITATION.html#' + code}


def _bounded(value):
    try:
        validate_json(value)
    except ValueError:
        raise ValueError('ELIGIBILITY_SIZE') from None
    need(len(json.dumps(value, separators=(',', ':'))) <= MAX_INPUT, 'ELIGIBILITY_SIZE')


def _money(value):
    need(type(value) is dict and set(value) == {'amount', 'unit'} and type(value['amount']) is int
         and 0 < value['amount'] <= 2**53 - 1 and type(value['unit']) is str and 0 < len(value['unit']) <= 32,
         'ELIGIBILITY_REQUIREMENT')
    return value


def _fragment(value, fields, required):
    need(type(value) is dict and set(required) <= set(value) <= set(fields), 'ELIGIBILITY_REQUIREMENT')
    return value


def requirement(*, purpose, subject, now, identity=None, qualifications=(), spending_authority=None,
                financial_backing=None, reputation=None, risk='NORMAL', value=None, high_risk=None):
    """What the relying party needs, facet by facet. ``subject`` is the counterparty's key."""
    need(type(purpose) is str and 0 < len(purpose) <= 160 and purpose.isprintable(), 'ELIGIBILITY_REQUIREMENT')
    verification_key(subject); integer(now)
    need(risk in RISKS, 'ELIGIBILITY_REQUIREMENT')
    if value is not None:
        _money(value)
    if identity is not None:
        _fragment(identity, ('policy', 'nonce', 'bound'), ('policy', 'nonce'))
        hidden.check_policy(identity['policy'])
        need(type(identity.get('bound', False)) is bool, 'ELIGIBILITY_REQUIREMENT')
    need(type(qualifications) in (list, tuple) and len(qualifications) <= MAX_ENTRIES, 'ELIGIBILITY_REQUIREMENT')
    for entry in qualifications:
        _fragment(entry, ('policy', 'nonce', 'market', 'require', 'accept_test'), ('policy', 'nonce'))
        accreditation._policy(entry['policy']); accreditation._text(entry['nonce'], 256)
        if entry.get('market') is not None:
            market.check_want(entry['market'])
            need(entry['market']['qualification'] == entry['policy']['qualification'], 'ELIGIBILITY_REQUIREMENT')
        need(entry.get('require') is None or (type(entry['require']) in (list, tuple) and len(entry['require']) <= 32),
             'ELIGIBILITY_REQUIREMENT')
        need(type(entry.get('accept_test', False)) is bool, 'ELIGIBILITY_REQUIREMENT')
    if spending_authority is not None:
        _fragment(spending_authority, ('root_key', 'action', 'resource', 'audience', 'usage',
                                       'minimum_revocation_sequence'), ('root_key', 'action', 'resource', 'audience', 'usage'))
        verification_key(spending_authority['root_key'])
        for name in ('action', 'resource', 'audience'):
            need(type(spending_authority[name]) is str and 0 < len(spending_authority[name]) <= 256, 'ELIGIBILITY_REQUIREMENT')
        need(type(spending_authority['usage']) is dict and len(spending_authority['usage']) <= 16, 'ELIGIBILITY_REQUIREMENT')
        integer(spending_authority.get('minimum_revocation_sequence', 0))
    if financial_backing is not None:
        _fragment(financial_backing, ('holders', 'agreement', 'amount', 'unit', 'max_age'),
                  ('holders', 'agreement', 'amount', 'unit', 'max_age'))
        need(type(financial_backing['holders']) is list and 0 < len(financial_backing['holders']) <= 64,
             'ELIGIBILITY_REQUIREMENT')
        for holder in financial_backing['holders']:
            verification_key(holder)
        key(financial_backing['agreement']); integer(financial_backing['amount'], True); integer(financial_backing['max_age'], True)
    if reputation is not None:
        _fragment(reputation, ('subject', 'context', 'trusted_contacts', 'max_age', 'minimum_support_weight',
                               'maximum_failure_weight', 'adopted_resolvers'),
                  ('subject', 'context', 'trusted_contacts', 'max_age', 'minimum_support_weight'))
        need(type(reputation['subject']) is dict and set(reputation['subject']) == {'kind', 'id'}
             and type(reputation['context']) is str and 0 < len(reputation['context']) <= 256
             and type(reputation['trusted_contacts']) is dict and 0 < len(reputation['trusted_contacts']) <= 64,
             'ELIGIBILITY_REQUIREMENT')
        key(reputation['subject']['id']); integer(reputation['max_age'], True); integer(reputation['minimum_support_weight'])
        integer(reputation.get('maximum_failure_weight', 0))
        need(reputation.get('adopted_resolvers') is None or type(reputation['adopted_resolvers']) is dict,
             'ELIGIBILITY_REQUIREMENT')
    if high_risk is not None:
        _fragment(high_risk, ('maximum_status_age', 'limited_exposure'), ('maximum_status_age',))
        integer(high_risk['maximum_status_age'], True)
        if high_risk.get('limited_exposure') is not None:
            exposure = high_risk['limited_exposure']
            need(type(exposure) is dict and set(exposure) == {'amount', 'unit', 'agreement'}, 'ELIGIBILITY_REQUIREMENT')
            _money({'amount': exposure['amount'], 'unit': exposure['unit']}); key(exposure['agreement'])
    need(risk == 'NORMAL' or high_risk is not None, 'ELIGIBILITY_REQUIREMENT')
    out = {'version': VERSION, 'purpose': purpose, 'subject': subject, 'now': now, 'risk': risk, 'value': deepcopy(value),
           'high_risk': deepcopy(high_risk), 'identity': deepcopy(identity), 'qualifications': deepcopy(list(qualifications)),
           'spending_authority': deepcopy(spending_authority), 'financial_backing': deepcopy(financial_backing),
           'reputation': deepcopy(reputation)}
    _bounded(out)
    return out


def check_requirement(value):
    """A requirement exactly as requirement() builds it, so a hand-made dict cannot skip validation."""
    fields = ('version', 'purpose', 'subject', 'now', 'risk', 'value', 'high_risk', 'identity', 'qualifications',
              'spending_authority', 'financial_backing', 'reputation')
    need(type(value) is dict and set(value) == set(fields) and value['version'] == VERSION, 'ELIGIBILITY_REQUIREMENT')
    rebuilt = requirement(purpose=value['purpose'], subject=value['subject'], now=value['now'], identity=value['identity'],
                          qualifications=value['qualifications'], spending_authority=value['spending_authority'],
                          financial_backing=value['financial_backing'], reputation=value['reputation'], risk=value['risk'],
                          value=value['value'], high_risk=value['high_risk'])
    need(rebuilt == value, 'ELIGIBILITY_REQUIREMENT')
    return value


def _report(facet, required, status, *, source, issuers=(), freshness=(), limits=None, reasons=(), evidence=()):
    return {'facet': facet, 'required': required, 'status': status, 'source': source, 'issuers': sorted(set(issuers)),
            'freshness': list(freshness), 'limits': deepcopy(limits or {}), 'reasons': sorted(set(reasons)),
            'evidence': list(evidence), 'execution_authorized': False}


def _items(presentations, facet):
    rows = presentations.get(facet, [])
    need(type(rows) is list and len(rows) <= MAX_ITEMS and all(type(row) is dict for row in rows), 'ELIGIBILITY_PRESENTATIONS')
    return rows


def _identity(rows, fragment, subject, now):
    if fragment is None:
        return _report('identity', False, 'NOT_REQUIRED', source=None)
    reasons, issuers, evidence = [], [], []
    for row in rows:
        try:
            need(set(row) == {'presentation'}, 'ELIGIBILITY_PRESENTATIONS')
            result = hidden.verify_presentation(row['presentation'], fragment['policy'], nonce=fragment['nonce'], now=now)
        except ValueError as error:
            reasons.append(str(error)); continue
        if fragment.get('bound') and result['claims'].get('account', '').split(':')[-1] != subject:
            reasons.append('ELIGIBILITY_SUBJECT_MISMATCH'); continue
        issuers.append(result['issuer'])
        evidence.append({'issuer': result['issuer'], 'claims': sorted(result['claims']), 'nullifier': result['nullifier'],
                         'identity_revealed': result['identity_revealed']})
    met = bool(evidence)
    return _report('identity', True, 'MET' if met else 'UNMET', source=hidden.VERSION, issuers=issuers,
                   freshness=['issuer statement at issuance; revocation is expiry only'],
                   limits={'binding': 'ACCOUNT_DISCLOSED' if fragment.get('bound') else 'HOLDER_KEY_ONLY'},
                   reasons=[] if met else (reasons or ['ELIGIBILITY_NO_EVIDENCE']), evidence=evidence)


def _snapshot_label(row, policy, now):
    """A best-effort label for a status snapshot that refused, so stale evidence is still dated."""
    try:
        evidence = row['presentation']['snapshot'] if row.get('form') == 'plain' else row['status']
        if type(evidence) is dict and set(evidence) == {'status', 'signature'}:
            accreditation.status_id(evidence)
            return accreditation.status_label(evidence['status']['issued_at'], now)
        opened = status_lists_check.open_snapshot(evidence, policy)
        return accreditation.status_label(opened['issued_at'], now)
    except (ValueError, KeyError, TypeError):
        return None


def _one_qualification(row, entry, now, store):
    policy, nonce = entry['policy'], entry['nonce']
    form = row.get('form')
    need(form in ('plain', 'sd'), 'ELIGIBILITY_PRESENTATIONS')
    if form == 'plain':
        need(set(row) == {'form', 'presentation'}, 'ELIGIBILITY_PRESENTATIONS')
        check = accreditation.verify_presentation if store is not None else accreditation.inspect_presentation
        options = {'store': store} if store is not None else {}
        result = check(row['presentation'], policy, nonce=nonce, now=now, offline=True, **options)
        claims = {'qualification': result['qualification'], 'profile': result['profile']}
    else:
        need(set(row) == {'form', 'presentation', 'status'}, 'ELIGIBILITY_PRESENTATIONS')
        check = disclosure.verify_presentation if store is not None else disclosure.inspect_presentation
        options = {'store': store} if store is not None else {}
        result = check(row['presentation'], policy, nonce=nonce, now=now, status=row['status'], offline=True,
                       require=list(entry.get('require') or ()), accept_test=entry.get('accept_test', False), **options)
        claims = {'qualification': result['qualification'], 'profile': result['profile'], **result['claims']}
    return result, claims


def _qualifications(rows, entries, requirement_value, now, store, high_risk, risk, subject):
    if not entries:
        return _report('qualifications', False, 'NOT_REQUIRED', source=None)
    outcomes, issuers, labels, reasons, evidence = [], [], [], [], []
    for entry in entries:
        found, tried = None, []
        for row in rows:
            try:
                result, claims = _one_qualification(row, entry, now, store)
            except ValueError as error:
                tried.append(str(error))
                label = _snapshot_label(row, entry['policy'], now)
                if label is not None:
                    labels.append(label)
                continue
            labels.append(result['status_label'])
            local = []
            if result['holder_key'] != subject:
                local.append('ELIGIBILITY_SUBJECT_MISMATCH')
            if entry.get('market') is not None:
                local += market.match(claims, entry['market'], now=now)
            if risk == 'HIGH' and now - result['status_as_of'] > high_risk['maximum_status_age']:
                exposure = high_risk.get('limited_exposure')
                within = (exposure is not None and requirement_value is not None
                          and requirement_value['unit'] == exposure['unit'] and requirement_value['amount'] <= exposure['amount'])
                if not within:
                    local.append('ELIGIBILITY_FRESH_STATUS_REQUIRED')
                else:
                    evidence.append({'qualification': entry['policy']['qualification'], 'limited_exposure': deepcopy(exposure)})
            if local:
                tried += local
                continue
            found = result
            break
        if found is None:
            unknown = tried and all(code in UNKNOWN_CODES or code == 'ELIGIBILITY_FRESH_STATUS_REQUIRED' for code in tried)
            outcomes.append('UNKNOWN' if unknown else 'UNMET')
            reasons += tried or ['ELIGIBILITY_NO_EVIDENCE']
            continue
        outcomes.append('MET')
        issuers.append(found['issuer'])
        evidence.append({'qualification': found['qualification'], 'issuer': found['issuer'], 'credential': found['credential'],
                         'form': found.get('form', 'PLAIN'), 'status_label': found['status_label'],
                         'replay_checked': found['replay_checked']})
    status = 'UNMET' if 'UNMET' in outcomes else 'UNKNOWN' if 'UNKNOWN' in outcomes else 'MET'
    return _report('qualifications', True, status, source=accreditation.VERSION + ' and ' + disclosure.VERSION,
                   issuers=issuers, freshness=sorted(set(labels)),
                   limits={'policy': 'OWNER_ADOPTED_ISSUERS_SCOPE_AND_MAXIMUM_STATUS_AGE',
                           'current_global_status': 'NOT_ESTABLISHED'},
                   reasons=reasons if status != 'MET' else (), evidence=evidence)


def _spending(rows, fragment, subject, now, checker):
    if fragment is None:
        return _report('spending_authority', False, 'NOT_REQUIRED', source=None)
    if checker is not None:
        return _checked('spending_authority', checker(deepcopy(rows), deepcopy(fragment), now))
    reasons, evidence, outcome = [], [], 'UNMET'
    for row in rows:
        try:
            need(set(row) <= {'records', 'revocation_history', 'witness'} and 'records' in row, 'ELIGIBILITY_PRESENTATIONS')
            result = trust.check_capability(row['records'], fragment['root_key'], subject, fragment['action'],
                                            fragment['resource'], fragment['audience'], fragment['usage'], now,
                                            revocation_history=row.get('revocation_history'), witness=row.get('witness'),
                                            minimum_revocation_sequence=fragment.get('minimum_revocation_sequence', 0))
        except ValueError as error:
            reasons.append(str(error)); continue
        evidence.append({'capability': result['capability'], 'revocation': result['revocation']})
        if result['eligible_in_supplied_scope']:
            outcome = 'MET'
            break
        outcome = 'UNKNOWN'
        reasons.append('ELIGIBILITY_CAPABILITY_NOT_CURRENT')
    return _report('spending_authority', True, outcome, source=trust.VERSION, issuers=[fragment['root_key']],
                   freshness=['revocation per supplied witnessed snapshot'],
                   limits={'limits': 'PER_REQUEST_ONLY_CUMULATIVE_CONSUMPTION_NOT_ENFORCED',
                           'resource_authority': 'OWNER_MUST_ADOPT_ROOT_FOR_THIS_RESOURCE'},
                   reasons=[] if outcome == 'MET' else (reasons or ['ELIGIBILITY_NO_EVIDENCE']), evidence=evidence)


def _checked(facet, value):
    """The plain interface for an owner-installed checker: data in, one bounded facet answer out."""
    try:
        validate_json(value)
    except ValueError:
        raise ValueError('ELIGIBILITY_CHECKER') from None
    need(type(value) is dict and set(value) <= {'status', 'source', 'issuer', 'freshness', 'limits', 'reasons'}
         and value.get('status') in ('MET', 'UNMET', 'UNKNOWN') and len(json.dumps(value)) <= 16384, 'ELIGIBILITY_CHECKER')
    need('"execution_authorized":true' not in json.dumps(value, separators=(',', ':')), 'ELIGIBILITY_CHECKER')
    return _report(facet, True, value['status'], source=value.get('source', 'OWNER_INSTALLED_CHECKER'),
                   issuers=[value['issuer']] if type(value.get('issuer')) is str else [],
                   freshness=[value['freshness']] if type(value.get('freshness')) is str else [],
                   limits=value.get('limits') if type(value.get('limits')) is dict else {},
                   reasons=[r for r in value.get('reasons', []) if type(r) is str][:16])


def _backing(rows, fragment, subject, now):
    if fragment is None:
        return _report('financial_backing', False, 'NOT_REQUIRED', source=None)
    holders, total, seen, reasons, labels, evidence = set(fragment['holders']), 0, set(), [], [], []
    for row in rows:
        try:
            need(set(row) == {'record'}, 'ELIGIBILITY_PRESENTATIONS')
            opened = anchored.open_record(row['record'], 'STAKE')
        except ValueError as error:
            reasons.append(str(error)); continue
        body = opened['body']
        if opened['id'] in seen:
            continue
        seen.add(opened['id'])
        if body['holder'] not in holders:
            reasons.append('REPUTATION_HOLDER_NOT_ADOPTED'); continue
        if body['agreement'] != fragment['agreement'] or body['party'] != subject or body['unit'] != fragment['unit']:
            reasons.append('ELIGIBILITY_SUBJECT_MISMATCH'); continue
        if body['held_at'] > now or now - body['held_at'] > fragment['max_age']:
            reasons.append('REPUTATION_FUTURE_EVIDENCE' if body['held_at'] > now else 'ELIGIBILITY_BACKING_STALE'); continue
        total += body['amount']
        labels.append('held as attested at ' + accreditation.status_label(body['held_at'], now)
                      .removeprefix('checked against the snapshot dated '))
        evidence.append({'stake': opened['id'], 'holder': body['holder'], 'amount': body['amount']})
    met = total >= fragment['amount']
    return _report('financial_backing', True, 'MET' if met else 'UNMET', source=anchored.VERSION + ' STAKE',
                   issuers=[row['holder'] for row in evidence], freshness=labels,
                   limits={'attested': {'amount': total, 'unit': fragment['unit']},
                           'required': {'amount': fragment['amount'], 'unit': fragment['unit']},
                           'observation': 'HOLDER_ATTESTATION_NOT_LIVE_CUSTODY_OBSERVATION',
                           'counting': 'EACH_RECORD_ONCE_FOR_THIS_AGREEMENT_ONLY'},
                   reasons=[] if met else reasons + ['ELIGIBILITY_BACKING_SHORT'], evidence=evidence)


def _reputation(rows, fragment, now):
    if fragment is None:
        return _report('reputation', False, 'NOT_REQUIRED', source=None)
    receipts = []
    for row in rows:
        need(set(row) == {'receipts'} and type(row['receipts']) is list, 'ELIGIBILITY_PRESENTATIONS')
        receipts += row['receipts']
    try:
        view = trust.local_reputation(receipts[:256], fragment['subject'], fragment['context'], fragment['trusted_contacts'],
                                      now, fragment['max_age'], fragment.get('adopted_resolvers'))
    except ValueError as error:
        return _report('reputation', True, 'UNMET', source=trust.VERSION, reasons=[str(error)])
    met = (view['support_weight'] >= fragment['minimum_support_weight'] and
           view['failure_weight'] <= fragment.get('maximum_failure_weight', 2**53 - 1))
    return _report('reputation', True, 'MET' if met else 'UNMET', source=trust.VERSION + ' local_reputation',
                   issuers=sorted(fragment['trusted_contacts']), freshness=['receipts at most %d seconds old' % fragment['max_age']],
                   limits={'support_weight': view['support_weight'], 'failure_weight': view['failure_weight'],
                           'disputed_or_unknown_weight': view['disputed_or_unknown_weight'],
                           'contextual_support_bps': view['contextual_support_bps'], 'basis': view['basis'],
                           'contact_independence': view['contact_independence'], 'global_score': False},
                   reasons=[] if met else ['ELIGIBILITY_REPUTATION_SHORT'],
                   evidence=[{'excluded': len(view['excluded']), 'agreements': len(view['agreements'])}])


def facets(presentations, requirement_value, *, store=None, checkers=None):
    """Every facet, evaluated on its own evidence and reported separately."""
    need(type(presentations) is dict and set(presentations) <= set(FACETS), 'ELIGIBILITY_PRESENTATIONS')
    _bounded(presentations); _bounded(requirement_value)
    check_requirement(requirement_value)
    need(checkers is None or (type(checkers) is dict and set(checkers) <= {'spending_authority'}
                              and all(callable(value) for value in checkers.values())), 'ELIGIBILITY_CHECKER')
    if store is not None:
        need(isinstance(store, accreditation.VerifierStore), 'ACCREDITATION_VERIFIER_STORE_REQUIRED')
    r, now, subject = requirement_value, requirement_value['now'], requirement_value['subject']
    return {
        'identity': _identity(_items(presentations, 'identity'), r['identity'], subject, now),
        'qualifications': _qualifications(_items(presentations, 'qualifications'), r['qualifications'], r['value'], now,
                                          store, r['high_risk'], r['risk'], subject),
        'spending_authority': _spending(_items(presentations, 'spending_authority'), r['spending_authority'], subject, now,
                                        (checkers or {}).get('spending_authority')),
        'financial_backing': _backing(_items(presentations, 'financial_backing'), r['financial_backing'], subject, now),
        'reputation': _reputation(_items(presentations, 'reputation'), r['reputation'], now),
    }


def eligible(presentations, requirement_value, *, store=None, checkers=None):
    """True only when every required facet is MET. The plain callable the demand exchange plugs in."""
    found = facets(presentations, requirement_value, store=store, checkers=checkers)
    required = [name for name in FACETS if found[name]['required']]
    unmet = [name for name in required if found[name]['status'] != 'MET']
    labels = sorted({label for name in FACETS for label in found[name]['freshness'] if label.startswith('checked against')})
    return {'version': VERSION, 'eligible': bool(required) and not unmet, 'purpose': requirement_value['purpose'],
            'subject': requirement_value['subject'], 'facets': found, 'required': required, 'unmet': unmet,
            'status_labels': labels, 'blended_score': None,
            'ranking': 'ELIGIBILITY_DECIDED_BEFORE_ANY_RANKING; FACETS_NEVER_BLENDED',
            'clock': 'CALLER_SUPPLIED', 'authority_granted': False, 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'facets': list(FACETS), 'statuses': list(STATUSES),
            'sources': {'identity': hidden.VERSION, 'qualifications': [accreditation.VERSION, disclosure.VERSION],
                        'spending_authority': trust.VERSION + ' capability chain, or an owner-installed checker',
                        'financial_backing': anchored.VERSION + ' STAKE attestations by adopted holders',
                        'reputation': trust.VERSION + ' local_reputation over trusted contacts'},
            'market_roles': sorted(market.ROLES), 'rules': [
                'every required facet must be MET; UNKNOWN is never MET',
                'facets are reported separately with source, issuer, freshness and limits; no blended score',
                'eligibility is decided before any ranking',
                'high risk needs fresh qualification status or an agreed limited exposure covering the value'],
            'checker_interface': 'callable(items, fragment, now) -> {status, source, issuer, freshness, limits, reasons}',
            'limits': {'items_per_facet': MAX_ITEMS, 'qualification_entries': MAX_ENTRIES, 'input_bytes': MAX_INPUT},
            'network_accessed': False, 'execution_authorized': False}
