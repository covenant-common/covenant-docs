"""Read-only local dispute adoption and current native permission review.

Every view starts with one owner-locked AgentNetwork.events() read, which
replays the existing signatures and native causal policy. The resulting map is
never emitted, imported, signed, or used to authorize a payment. Historical
findings retain the meaning and authorization they had in their signed causal
past, independently of the designated arbitrator's current local permissions.
"""
from copy import deepcopy
import hashlib
import re

from .agent_network import permissions as native_permissions, role_view, unpack
from .crypto import need
from .workflow_store import canonical


VERSION = 'covenant-coordination-dispute-review/0.1'
NATIVE_PERMISSIONS = ('arbitrate', 'govern', 'moderate', 'organize', 'post')
_REFERENCE = re.compile(r'[0-9a-f]{64}\Z')
_POST_KINDS = ('DISPUTE', 'LINK', 'POST', 'PROPOSAL', 'SIGNAL')

# These are descriptions of the unchanged AgentNetwork._validate rules, not a
# second interpreter or a permissive policy table used to execute anything.
NATIVE_PERMISSION_ACTIONS = {
    'arbitrate': {
        'event_kinds': ['RESOLVE'],
        'conditions': {
            'RESOLVE': 'The caller must be the case-designated arbitrator and every actual case party must have accepted that exact case in the event causal past.'}},
    'govern': {
        'event_kinds': ['ROLE_ACCEPT', 'ROLE_PROPOSE', 'ROLE_REVOKE'],
        'conditions': {
            'ROLE_PROPOSE': 'The proposal author requires govern.',
            'ROLE_ACCEPT': 'The caller must be the proposed holder; the original proposal author must have govern in the acceptance event causal past. The holder does not need govern.',
            'ROLE_REVOKE': 'A governor may revoke another holder only when the adopted role is revocable. A holder can revoke its own role without govern.'}},
    'moderate': {
        'event_kinds': ['MODERATE'],
        'conditions': {'MODERATE': 'The caller requires moderate and an exact same-group POST or CORRECT target; the action is HIDE or RESTORE.'}},
    'organize': {
        'event_kinds': [],
        'conditions': {},
        'status': 'NOT_CONSULTED_BY_CURRENT_NATIVE_EVENT_RULES'},
    'post': {
        'event_kinds': list(_POST_KINDS),
        'conditions': {kind: 'Requires open_posting OR post, plus admitted authorship and the unchanged event-specific schema and target rules.' for kind in _POST_KINDS}},
}

_OTHER_RULES = {
    'GROUP': 'An admitted author can create a group; no existing group permission is consulted.',
    'CORRECT': 'Only the original POST or CORRECT author may correct it; current post or organize is not required.',
    'DISPUTE_ACCEPT': 'Only a named actual party may accept that exact case; current post or organize is not required.',
    'ROLE_ACCEPT': 'Only the proposed holder may accept; the proposal author must still have govern in the acceptance causal past.',
    'ROLE_REVOKE': 'The holder may exit; otherwise the caller needs govern and the adopted role must be revocable.',
    'ENDORSE': 'No group permission label is consulted; admitted authorship and native endorsement constraints remain required.',
    'BALLOT': 'The author must belong to the exact proposal electorate; post or organize is not required.',
}


def _ref(value, code):
    # Reject oversized or recursive direct inputs before formatting or copying.
    need(type(value) is str and len(value) == 64 and _REFERENCE.fullmatch(value) is not None, code)
    return value


def _refs(values, code, minimum=0, maximum=64):
    need(type(values) is list and minimum <= len(values) <= maximum, code)
    for value in values:
        _ref(value, code)
    need(values == sorted(set(values)), code)
    return values


def _hash(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + canonical(value)).hexdigest()


def _field_hash(value):
    return _hash('COVENANT-DISPUTE-SOURCE-FIELD-0.1', value)


def _handoff(reference):
    return {'tool': 'covenant_forum_read',
            'arguments': {'action': 'event', 'parameters': {'reference': reference, 'compact': True}}}


def _capture(tools, expected_heads):
    if expected_heads is not None:
        _refs(expected_heads, 'REVIEW_EXPECTED_HEADS', maximum=65)
    network = getattr(tools, 'network', None)
    need(network is not None, 'REVIEW_NETWORK_REQUIRED')
    # There is exactly one validating event read. No network.view(), preflight,
    # or later helper read can quietly mix a newer owner state into this view.
    with network.store.exclusive():
        events = deepcopy(network.events())
        captured = {'domain': network.domain, 'caller': network.actor,
                    'peers': sorted(network.peers), 'events': events}
    heads = sorted(set(events) - {p for event in events.values() for p in event['body']['parents']})
    need(expected_heads is None or expected_heads == heads, 'REVIEW_LOCAL_HEADS_CHANGED_REVIEW_AGAIN')
    captured['heads'] = heads
    captured['snapshot'] = {
        'network_domain': captured['domain'], 'local_actor': captured['caller'],
        'admitted_peers_sha256': _hash('COVENANT-DISPUTE-ADMITTED-PEERS-0.1', captured['peers']),
        'validated_event_ids_sha256': _hash('COVENANT-DISPUTE-EVENT-IDS-0.1', sorted(events)),
        'validated_event_count': len(events), 'observed_local_heads': heads,
        'expected_heads_match': None if expected_heads is None else True,
        'freshness': 'CURRENT_CAPTURED_LOCAL_REPLICA_ONLY; NOT_GLOBAL_CURRENTNESS_OR_FINALITY'}
    captured['snapshot_id'] = _hash('COVENANT-DISPUTE-LOCAL-SNAPSHOT-0.1', captured['snapshot'])
    return captured


def _group(captured, group):
    events = captured['events']
    need(group in events and events[group]['body']['kind'] == 'GROUP', 'REVIEW_PERMISSION_GROUP')
    return unpack(events[group]['body'])


def _roles(events, group):
    rows = []
    for role in role_view(events, group):
        labels = sorted(set(role['permissions']))
        rows.append({'holder': role['holder'], 'name_sha256': _field_hash(role['name']),
                     'heads': deepcopy(role['heads']), 'status': role['status'],
                     'permissions': labels,
                     'native_permissions': sorted(set(labels) & set(NATIVE_PERMISSIONS)),
                     'custom_permission_labels': sorted(set(labels) - set(NATIVE_PERMISSIONS)),
                     'source_handoffs': [_handoff(ref) for ref in role['heads']],
                     'authority': 'GROUP_LOCAL_ONLY; NO_NATIVE_RESOURCE_OR_PAYMENT_AUTHORITY'})
    return rows


def _actor(captured, group, actor, group_content):
    labels = native_permissions(captured['events'], group, actor)
    native = sorted(labels & set(NATIVE_PERMISSIONS))
    custom = sorted(labels - set(NATIVE_PERMISSIONS))
    admitted = actor in captured['peers']
    posting = admitted and (group_content['open_posting'] or 'post' in labels)
    return {'actor': actor, 'admitted': admitted,
            'is_group_founder': captured['events'][group]['body']['actor'] == actor,
            'effective_permissions': sorted(labels), 'effective_native_permissions': native,
            'custom_permission_labels': custom,
            'custom_labels_grant_native_permissions': False,
            'open_posting': group_content['open_posting'],
            'posting_permission_gate_satisfied': posting,
            'posting_event_kinds': list(_POST_KINDS),
            'posting_gate_basis': 'ADMITTED_AUTHOR_AND_OPEN_POSTING_OR_EXACT_LOWERCASE_POST; EVENT_SPECIFIC_RULES_STILL_REQUIRED',
            'organize_permission_controls_posting_or_proposals': False,
            'full_content_or_target_validation_performed': False}


def _scope(captured):
    return {'snapshot_id': captured['snapshot_id'], 'snapshot': deepcopy(captured['snapshot']),
            'observed_local_heads': deepcopy(captured['heads']),
            'source_validation': 'ACTUAL_AGENT_NETWORK_EVENTS_SIGNATURE_AND_CAUSAL_POLICY_REPLAY',
            'freshness': 'CURRENT_CAPTURED_LOCAL_REPLICA_ONLY; NOT_GLOBAL_CURRENTNESS_OR_FINALITY',
            'source_handoff_scope': 'EXPLICIT_FOLLOWUP_CAN_DISCLOSE_RAW_SIGNED_CONTENT; NO_FOLLOWUP_READ_PERFORMED',
            'world_truth': 'NOT_ESTABLISHED', 'legal_effect': 'NOT_DETERMINED',
            'payment_authority': 'NONE', 'native_resource_authority': 'NONE',
            'owner_store_written': False, 'signature_created': False,
            'event_created': False, 'execution_authorized': False}


def permissions(tools, group, actor=None, expected_heads=None):
    """Review current local roles and the exact installed native permission gates.

    Permission labels are explicit metadata; raw role names/terms and signed
    envelopes are omitted. Unknown labels remain visible as custom metadata and
    are never lowercased or silently turned into native permissions.
    """
    _ref(group, 'REVIEW_PERMISSION_GROUP')
    if actor is not None:
        _ref(actor, 'REVIEW_PERMISSION_ACTOR')
    captured = _capture(tools, expected_heads)
    content = _group(captured, group)
    selected = captured['caller'] if actor is None else actor
    return {'version': VERSION, 'kind': 'PERMISSION_REVIEW', 'group': group,
            'status': 'LOCAL_SIGNATURES_AND_CAUSAL_POLICY_VERIFIED',
            'caller': captured['caller'], 'founder': captured['events'][group]['body']['actor'],
            'actor': selected, 'actor_permissions': _actor(captured, group, selected, content),
            'roles': _roles(captured['events'], group),
            'native_permission_vocabulary': list(NATIVE_PERMISSIONS),
            'native_permission_actions': deepcopy(NATIVE_PERMISSION_ACTIONS),
            'other_native_action_rules': deepcopy(_OTHER_RULES),
            'revocation_scope': 'CURRENT_CAPTURED_LOCAL_ROLE_PROJECTION; HISTORICAL_EVENT_AUTHORIZATION_UNCHANGED',
            'group_source_handoff': _handoff(group), **_scope(captured)}


def dispute(tools, case_event, finding_event=None, expected_group=None,
            expected_parties=None, expected_arbitrator=None, expected_heads=None):
    """Review actual case adoption, all historical findings and current readiness.

    An explicit finding reference must be a validated RESOLVE for this exact
    case and group. It selects a displayed reference, never an operative winner.
    The installed native event rules validate attribution and causal adoption;
    this helper does not interpret or certify arbitrary procedure prose.
    """
    _ref(case_event, 'REVIEW_DISPUTE_CASE_REFERENCE')
    if finding_event is not None:
        _ref(finding_event, 'REVIEW_DISPUTE_FINDING_REFERENCE')
    if expected_group is not None:
        _ref(expected_group, 'REVIEW_DISPUTE_EXPECTED_GROUP')
    if expected_parties is not None:
        _refs(expected_parties, 'REVIEW_DISPUTE_EXPECTED_PARTIES', minimum=2, maximum=16)
    if expected_arbitrator is not None:
        _ref(expected_arbitrator, 'REVIEW_DISPUTE_EXPECTED_ARBITRATOR')
    captured = _capture(tools, expected_heads)
    events = captured['events']
    need(case_event in events, 'REVIEW_DISPUTE_CASE_NOT_FOUND')
    case_body = events[case_event]['body']
    need(case_body['kind'] == 'DISPUTE', 'REVIEW_DISPUTE_CASE_KIND')
    group = case_body['group']
    content = _group(captured, group)
    case = unpack(case_body)
    need(expected_group is None or expected_group == group, 'REVIEW_DISPUTE_EXPECTED_GROUP')
    need(expected_parties is None or expected_parties == case['parties'], 'REVIEW_DISPUTE_EXPECTED_PARTIES')
    need(expected_arbitrator is None or expected_arbitrator == case['arbitrator'], 'REVIEW_DISPUTE_EXPECTED_ARBITRATOR')

    acceptances = []
    findings = []
    for reference, envelope in sorted(events.items()):
        body = envelope['body']
        if body['group'] != group or body['kind'] not in ('DISPUTE_ACCEPT', 'RESOLVE'):
            continue
        source = unpack(body)
        if source['case'] != case_event:
            continue
        if body['kind'] == 'DISPUTE_ACCEPT':
            acceptances.append({'event': reference, 'party': body['actor'],
                                'source_handoff': _handoff(reference)})
        else:
            findings.append({'finding_event': reference, 'case_event': case_event,
                             'group': group, 'arbitrator': body['actor'],
                             'outcome': source['outcome'],
                             'reasons_sha256': _field_hash(source['reasons']),
                             'evidence_sha256': _field_hash(source['evidence']),
                             'historical_authorization': 'VALIDATED_SIGNATURE_AND_NATIVE_CAUSAL_POLICY_AT_EVENT',
                             'current_role_revocation_rewrites_history': False,
                             'transfer_authority': 'NOT_GRANTED',
                             'source_handoff': _handoff(reference)})
    selected = None
    if finding_event is not None:
        need(finding_event in events, 'REVIEW_DISPUTE_FINDING_NOT_FOUND')
        selected_body = events[finding_event]['body']
        need(selected_body['kind'] == 'RESOLVE', 'REVIEW_DISPUTE_FINDING_KIND')
        need(selected_body['group'] == group and unpack(selected_body)['case'] == case_event,
             'REVIEW_DISPUTE_FINDING_CASE')
        selected = next(row for row in findings if row['finding_event'] == finding_event)

    accepted = sorted({row['party'] for row in acceptances})
    missing = sorted(set(case['parties']) - set(accepted))
    arbitrator = _actor(captured, group, case['arbitrator'], content)
    designated = captured['caller'] == case['arbitrator']
    has_permission = 'arbitrate' in arbitrator['effective_native_permissions']
    blockers = []
    if missing:
        blockers.append('MISSING_PARTY_ACCEPTANCES')
    if not arbitrator['admitted']:
        blockers.append('DESIGNATED_ARBITRATOR_NOT_ADMITTED')
    if not has_permission:
        blockers.append('DESIGNATED_ARBITRATOR_MISSING_NATIVE_ARBITRATE')
    if not designated:
        blockers.append('CALLER_NOT_DESIGNATED_ARBITRATOR')
    readiness = {
        'status': 'READY_FOR_EXPLICIT_RESOLVE_REVIEW' if not blockers else 'NOT_READY_FOR_CALLER_RESOLVE',
        'blockers': blockers, 'missing_parties': missing,
        'designated_arbitrator_admitted': arbitrator['admitted'],
        'required_native_permission': 'arbitrate',
        'designated_arbitrator_has_required_permission': has_permission,
        'caller_is_designated_arbitrator': designated,
        'native_resolution_prerequisites_satisfied': not missing and arbitrator['admitted'] and has_permission,
        'caller_native_permission_gate_satisfied': not blockers,
        'scope': 'CURRENT_CAPTURED_LOCAL_NATIVE_GATES_ONLY; NOT_CONTENT_MERITS_OR_CUSTOM_PROCEDURE_COMPLIANCE',
        'procedure_interpreted_or_completed': False,
        'publication_or_payment_authorized': False}
    status = ('FINDINGS_RECORDED_LOCALLY' if findings else
              'AWAITING_PARTY_ACCEPTANCE' if missing else 'ALL_PARTIES_ACCEPTED_LOCALLY')
    return {'version': VERSION, 'kind': 'DISPUTE_REVIEW', 'status': status,
            'case_event': case_event, 'group': group, 'target_event': case['target'],
            'claimant': case_body['actor'], 'parties': deepcopy(case['parties']),
            'designated_arbitrator': case['arbitrator'],
            'claim_sha256': _field_hash(case['claim']), 'procedure_sha256': _field_hash(case['procedure']),
            'acceptance_events': acceptances, 'accepted_parties': accepted, 'missing_parties': missing,
            'finding_events': [row['finding_event'] for row in findings], 'findings': findings,
            'selected_finding_event': finding_event, 'selected_finding': deepcopy(selected),
            'finding_selection': 'CALLER_REFERENCE_ONLY; NO_OPERATIVE_WINNER_SELECTED_OR_CONFLICT_RESOLVED',
            'operative_finding': None, 'historical_findings_retained': True,
            'current_arbitrator_permissions': arbitrator,
            'caller': captured['caller'], 'caller_is_designated_arbitrator': designated,
            'readiness': readiness, 'case_source_handoff': _handoff(case_event),
            'custom_procedure_compliance': 'NOT_INTERPRETED; READ_EXACT_SOURCE_AND_ADOPT_NECESSARY_FOLLOWUP',
            'transfer_authority': 'NOT_GRANTED', **_scope(captured)}
