"""Durable rolling-window spend limits per mandate and per counterparty.

covenant-spend-windows/0.1 closes the gap the roadmap recorded for off-chain
mandates: a per-request cap does not stop many small requests. The ledger
verifies the signed covenant-scoped-mandate/0.1 chain itself, so every window
comes from a signature, never from the caller. Before an action it charges
every window of every mandate in the chain: a MANDATE window across all
counterparties and a COUNTERPARTY window for the named counterparty alone, so a
delegate's spending also counts against each ancestor's windows.

A window sums the charges dated within its last ``window`` seconds of the owner
clock. A charge counts from its reservation: RESERVED and UNKNOWN count,
COMMITTED counts at its final amount, and only RELEASED stops counting. Release
is the owner's statement that nothing was sent; an unknown outcome never frees
budget. The owner clock may not run backwards. A request id is idempotent while
the ledger holds it, at least as long as the longest window.

The file is owner-private SQLite (WAL, synchronous FULL), one transaction per
change, and every change appends a leaf to an RFC 6962 journal
(covenant_chain.witness_journal) in that same transaction. Keep the journal
head (journal_head) apart from the file: a copy restored from before it is
refused when opened with that head. One file is one custody domain; two hosts
with two files do not share a window. Amounts are owner-attested exposure, not
bank balances, and a reservation is not a payment.
"""
from contextlib import contextmanager
from copy import deepcopy
import math
import os
from pathlib import Path
import re
import sqlite3
import stat
import threading

from covenant_language.safe_io import durable_sqlite

from . import scoped_mandates, witness_journal
from .crypto import canonical, digest, key, loads, need, verification_key

FORMAT_VERSION = 'covenant-spend-windows/0.1'
CHARGE_VERSION = 'covenant-spend-charge/0.1'
CHARGE_LABEL = 'COVENANT-SPEND-CHARGE-0.1'
BUCKET_LABEL = 'COVENANT-SPEND-BUCKET-0.1'
REQUEST_LABEL = 'COVENANT-SPEND-REQUEST-0.1'
JOURNAL = 'journal'
STATES = ('RESERVED', 'UNKNOWN', 'COMMITTED', 'RELEASED')
TRANSITIONS = {'RESERVED': ('UNKNOWN', 'COMMITTED', 'RELEASED'), 'UNKNOWN': ('COMMITTED', 'RELEASED'),
               'COMMITTED': (), 'RELEASED': ()}
CURRENTNESS = ('WITNESSED', 'SIGNED_LIST')
MAX_CHARGES = 250000
MAX_JOURNAL = 2000000
REQUEST = re.compile(r'[A-Za-z0-9_.:-]{8,128}\Z')
REMEDIATION = {
    'SPEND_CONFIG': 'The owner installs the ledger with one root key, an audience, a clock and WITNESSED or SIGNED_LIST currentness.',
    'SPEND_STORAGE': 'Keep the ledger as an owner-only regular file (mode 0600) in a directory others cannot write, and restore it from a backup if it was replaced.',
    'SPEND_FORMAT': 'This file is not a covenant-spend-windows/0.1 ledger. Open the right file; never edit the format row.',
    'SPEND_CONTEXT_CHANGED': 'This ledger belongs to another root or audience. Open the ledger the owner adopted for this mandate root.',
    'SPEND_RETAINED_HEAD': 'The ledger is older than, or differs from, the journal head you retained. Restore the newest copy; a rolled-back ledger forgets spending.',
    'SPEND_CLOCK': 'The owner clock must return a non-negative integer number of seconds.',
    'SPEND_CLOCK_ROLLBACK': 'The owner clock ran backwards. Fix the clock; windows cannot be judged against an earlier time.',
    'SPEND_REQUEST': 'Use a request id of 8 to 128 characters from letters, digits, ".", "_", ":" and "-".',
    'SPEND_RECORDS': 'Present the signed mandate chain, root first, as 1 to 16 records.',
    'SPEND_USAGE': 'Give usage as at most 16 printable units with integer amounts.',
    'SPEND_REQUEST_REUSED': 'This request id was used for a different charge. Use a new id for a new action, or repeat the original call exactly.',
    'SPEND_MANDATE_REVOKED': 'A mandate in this chain is revoked. Obtain a new mandate from its root.',
    'SPEND_REVOCATION_UNKNOWN': 'Supply the root\'s current signed revocation snapshot (and, under WITNESSED, a fresh witnessed checkpoint that includes it).',
    'SPEND_WINDOW_EXCEEDED': 'A rolling window of this mandate chain is spent. Wait until earlier charges leave the window, or ask the root for a larger window.',
    'SPEND_LEDGER_FULL': 'The ledger reached its bound. Settle open charges, or start a new ledger after the longest window has passed.',
    'SPEND_REQUEST_UNKNOWN': 'No charge has this request id. Reserve it first.',
    'SPEND_OUTCOME': 'Settle with UNKNOWN, COMMITTED or RELEASED.',
    'SPEND_STATE': 'This settlement is not allowed from the charge\'s current state. COMMITTED and RELEASED are final.',
    'SPEND_SETTLE_USAGE': 'Only a COMMITTED settlement may lower amounts, and only for reserved units.',
    'SPEND_BACKUP': 'Choose a new backup path in an existing directory; a backup never overwrites a file.',
}


def _private(path):
    path = Path(os.path.abspath(os.fspath(path)))
    try:
        parent = os.stat(path.parent)
    except OSError:
        raise ValueError('SPEND_STORAGE') from None
    need(stat.S_ISDIR(parent.st_mode) and parent.st_uid == os.getuid() and
         stat.S_IMODE(parent.st_mode) & 0o022 == 0 and not path.is_symlink(), 'SPEND_STORAGE')
    try:
        fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    except OSError:
        raise ValueError('SPEND_STORAGE') from None
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid() and
             stat.S_IMODE(info.st_mode) & 0o077 == 0, 'SPEND_STORAGE')
        return path, (info.st_dev, info.st_ino)
    finally:
        os.close(fd)


def _units(value, code):
    need(type(value) is dict and len(value) <= scoped_mandates.MAX_UNITS, code)
    for unit, amount in value.items():
        need(type(unit) is str and scoped_mandates.UNIT.fullmatch(unit) is not None and type(amount) is int and
             0 <= amount <= 2**53 - 1, code)


class SpendLedger:
    """Owner-installed charging gate for one mandate root and audience. Caller input never adds a window."""

    def __init__(self, path, *, root_key, audience, clock, currentness='WITNESSED', retained=None, observer=None):
        need(type(root_key) is str and type(audience) is str and 0 < len(audience) <= 256 and audience.isascii() and
             audience.isprintable() and callable(clock) and currentness in CURRENTNESS and
             (observer is None or callable(observer)), 'SPEND_CONFIG')
        verification_key(root_key)
        self.root_key, self.audience, self.clock = root_key, audience, clock
        self.currentness, self.observer = currentness, observer
        self.path, self._inode = _private(path)
        self._lock = threading.RLock()
        self.db = sqlite3.connect(self.path, isolation_level=None, timeout=15, check_same_thread=False)
        try:
            self.db.execute('PRAGMA busy_timeout=15000')
            durable_sqlite(self.db)
            with self._write() as db:
                db.execute('CREATE TABLE IF NOT EXISTS spend_meta (name TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT')
                db.execute('CREATE TABLE IF NOT EXISTS spend_charges (request TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, '
                           'state TEXT NOT NULL, at INTEGER NOT NULL, body TEXT NOT NULL, settled TEXT, '
                           'settled_at INTEGER) STRICT')
                db.execute('CREATE TABLE IF NOT EXISTS spend_usage (bucket TEXT NOT NULL, request TEXT NOT NULL, '
                           'unit TEXT NOT NULL, at INTEGER NOT NULL, amount INTEGER NOT NULL, '
                           'PRIMARY KEY (bucket, request)) STRICT')
                db.execute('CREATE INDEX IF NOT EXISTS spend_usage_window ON spend_usage(bucket, at)')
                db.execute('CREATE INDEX IF NOT EXISTS spend_usage_request ON spend_usage(request)')
                db.execute('CREATE TABLE IF NOT EXISTS spend_clock (id INTEGER PRIMARY KEY CHECK (id = 0), '
                           'high INTEGER NOT NULL) STRICT')
                context = canonical({'root': root_key, 'audience': audience}).decode('ascii')
                for name, value in (('format', FORMAT_VERSION), ('context', context)):
                    db.execute('INSERT OR IGNORE INTO spend_meta VALUES (?, ?)', (name, value))
                    found = db.execute('SELECT value FROM spend_meta WHERE name=?', (name,)).fetchone()[0]
                    need(found == value, 'SPEND_FORMAT' if name == 'format' else 'SPEND_CONTEXT_CHANGED')
                self.journal = witness_journal.Journal(db, JOURNAL, create=True)
            if retained is not None:
                need(type(retained) is dict and set(retained) == {'size', 'root'} and type(retained['size']) is int and
                     0 <= retained['size'], 'SPEND_RETAINED_HEAD')
                key(retained['root'])
                need(retained['size'] <= self.journal.size() and
                     self.journal.root(retained['size']) == retained['root'], 'SPEND_RETAINED_HEAD')
        except BaseException:
            self.db.close()
            raise

    def close(self):
        self.db.close()

    @contextmanager
    def _write(self):
        try:
            info = os.stat(self.path, follow_symlinks=False)
        except OSError:
            raise ValueError('SPEND_STORAGE') from None
        need((info.st_dev, info.st_ino) == self._inode and stat.S_ISREG(info.st_mode), 'SPEND_STORAGE')
        try:
            self.db.execute('BEGIN IMMEDIATE')
        except sqlite3.Error:
            raise ValueError('SPEND_STORAGE') from None
        try:
            yield self.db
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
        try:
            self.db.execute('COMMIT')
        except sqlite3.Error:
            raise ValueError('SPEND_STORAGE') from None

    def _now(self, db):
        value = self.clock()
        need(type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 2**53 - 1, 'SPEND_CLOCK')
        now = int(value)
        row = db.execute('SELECT high FROM spend_clock WHERE id=0').fetchone()
        need(row is None or now >= row[0], 'SPEND_CLOCK_ROLLBACK')
        db.execute('INSERT INTO spend_clock VALUES (0, ?) ON CONFLICT(id) DO UPDATE SET high=excluded.high', (now,))
        return now

    @staticmethod
    def _bucket(window, counterparty):
        return digest(BUCKET_LABEL, {'mandate': window['mandate'], 'per': window['per'], 'unit': window['unit'],
                                     'window': window['window'],
                                     'counterparty': counterparty if window['per'] == 'COUNTERPARTY' else None})

    def _used(self, db, bucket, window, now):
        return db.execute('SELECT coalesce(sum(amount), 0) FROM spend_usage WHERE bucket=? AND at>?',
                          (bucket, now - window)).fetchone()[0]

    def _entry(self, db, kind, request, now, detail):
        size = self.journal.size()
        need(size < MAX_JOURNAL, 'SPEND_LEDGER_FULL')
        entry = {'version': CHARGE_VERSION, 'kind': kind, 'sequence': size,
                 'previous': self.journal.entry(size - 1) if size else None, 'at': now, 'request': request,
                 'detail': detail}
        reference = digest(CHARGE_LABEL, entry)
        self.journal.append(reference, canonical(entry), request)
        return reference

    def reserve(self, request, records, *, recipient, scope, usage, counterparty=None, revocation_history=None,
                witness=None, minimum_revocation_sequence=0):
        """Verify the chain, then charge every window of every mandate in it, or refuse with nothing charged."""
        need(type(request) is str and REQUEST.fullmatch(request) is not None, 'SPEND_REQUEST')
        need(type(records) is list and 1 <= len(records) <= scoped_mandates.MAX_CHAIN and
             all(type(record) is dict and 'body' in record for record in records), 'SPEND_RECORDS')
        _units(usage, 'SPEND_USAGE')
        fingerprint = digest(REQUEST_LABEL, {'request': request, 'recipient': recipient, 'scope': scope,
                                             'usage': usage, 'counterparty': counterparty,
                                             'chain': [scoped_mandates.mandate_id(record['body']) for record in records]})
        with self._lock, self._write() as db:
            now = self._now(db)
            row = db.execute('SELECT fingerprint, state, body FROM spend_charges WHERE request=?', (request,)).fetchone()
            if row is not None:
                need(row[0] == fingerprint, 'SPEND_REQUEST_REUSED')
                body = loads(row[2])
                return {'request': request, 'state': row[1], 'mandate': body['mandate'], 'replayed': True,
                        'windows': self._report(db, body, now), 'execution_authorized': False}
            checked = scoped_mandates.check(records, self.root_key, recipient, scope, self.audience, usage, now,
                                            counterparty=counterparty, revocation_history=revocation_history,
                                            witness=witness, minimum_revocation_sequence=minimum_revocation_sequence)
            need(not checked['revoked'], 'SPEND_MANDATE_REVOKED')
            current = ('NOT_REVOKED_IN_FRESH_OWNER_ADOPTED_WITNESSED_SNAPSHOT',) + (
                ('SIGNED_LIST_ONLY_CURRENTNESS_UNKNOWN',) if self.currentness == 'SIGNED_LIST' else ())
            need(checked['revocation'] in current, 'SPEND_REVOCATION_UNKNOWN')
            for window in checked['windows']:
                used = self._used(db, self._bucket(window, counterparty), window['window'], now)
                need(used + usage[window['unit']] <= window['amount'], 'SPEND_WINDOW_EXCEEDED')
            db.execute('DELETE FROM spend_usage WHERE at<=?', (now - scoped_mandates.MAX_WINDOW,))
            db.execute("DELETE FROM spend_charges WHERE at<=? AND state IN ('COMMITTED','RELEASED')",
                       (now - scoped_mandates.MAX_WINDOW,))
            need(db.execute('SELECT count(*) FROM spend_charges').fetchone()[0] < MAX_CHARGES, 'SPEND_LEDGER_FULL')
            body = {'request': request, 'mandate': checked['mandate'], 'chain': checked['chain'], 'recipient': recipient,
                    'scope': scope, 'grant': checked['grant'], 'counterparty': counterparty, 'usage': deepcopy(usage),
                    'windows': checked['windows'], 'revocation': checked['revocation']}
            if self.observer is not None:
                # Owner-installed (for example a watchdog); a refusal here leaves nothing charged.
                self.observer({'kind': 'SPEND', 'request': request, 'recipient': recipient, 'scope': scope,
                               'counterparty': counterparty, 'usage': deepcopy(usage), 'mandate': checked['mandate']})
            db.execute('INSERT INTO spend_charges VALUES (?, ?, ?, ?, ?, NULL, NULL)',
                       (request, fingerprint, 'RESERVED', now, canonical(body).decode('ascii')))
            for window in checked['windows']:
                db.execute('INSERT OR IGNORE INTO spend_usage VALUES (?, ?, ?, ?, ?)',
                           (self._bucket(window, counterparty), request, window['unit'], now, usage[window['unit']]))
            self._entry(db, 'RESERVE', request, now, body)
            return {'request': request, 'state': 'RESERVED', 'mandate': checked['mandate'], 'replayed': False,
                    'windows': self._report(db, body, now), 'within_mandate_and_windows': True,
                    'payment_made': False, 'execution_authorized': False}

    def _report(self, db, body, now):
        rows = []
        for window in body['windows']:
            used = self._used(db, self._bucket(window, body['counterparty']), window['window'], now)
            rows.append({**deepcopy(window), 'used': used, 'remaining': max(0, window['amount'] - used)})
        return rows

    def settle(self, request, outcome, *, usage=None):
        """UNKNOWN keeps counting; COMMITTED may lower amounts; RELEASED (nothing was sent) stops counting."""
        need(type(request) is str and REQUEST.fullmatch(request) is not None, 'SPEND_REQUEST')
        need(outcome in STATES[1:], 'SPEND_OUTCOME')
        if usage is not None:
            _units(usage, 'SPEND_SETTLE_USAGE')
        with self._lock, self._write() as db:
            now = self._now(db)
            row = db.execute('SELECT state, body, settled FROM spend_charges WHERE request=?', (request,)).fetchone()
            need(row is not None, 'SPEND_REQUEST_UNKNOWN')
            state, body = row[0], loads(row[1])
            if state == outcome:
                need(usage is None or canonical(usage).decode('ascii') == row[2], 'SPEND_STATE')
                return {'request': request, 'state': state, 'replayed': True, 'execution_authorized': False}
            need(outcome in TRANSITIONS[state], 'SPEND_STATE')
            need(usage is None or (outcome == 'COMMITTED' and set(usage) <= set(body['usage']) and
                                   all(amount <= body['usage'][unit] for unit, amount in usage.items())),
                 'SPEND_SETTLE_USAGE')
            if outcome == 'RELEASED':
                db.execute('DELETE FROM spend_usage WHERE request=?', (request,))
            for unit, amount in (usage or {}).items():
                db.execute('UPDATE spend_usage SET amount=? WHERE request=? AND unit=?', (amount, request, unit))
            settled = None if usage is None else canonical(usage).decode('ascii')
            db.execute('UPDATE spend_charges SET state=?, settled=?, settled_at=? WHERE request=?',
                       (outcome, settled, now, request))
            self._entry(db, 'SETTLE', request, now, {'from': state, 'to': outcome, 'usage': deepcopy(usage)})
            return {'request': request, 'state': outcome, 'replayed': False, 'payment_made': False,
                    'execution_authorized': False}

    def used(self, window, counterparty=None):
        """Current use of one window row from a check or reservation, at the owner clock."""
        need(type(window) is dict and {'mandate', 'per', 'unit', 'window', 'amount'} <= set(window), 'SPEND_RECORDS')
        with self._lock, self._write() as db:
            now = self._now(db)
            spent = self._used(db, self._bucket(window, counterparty), window['window'], now)
        return {'used': spent, 'remaining': max(0, window['amount'] - spent), 'at': now}

    def journal_head(self):
        """Retain this apart from the file; reopening with it refuses an older or different copy."""
        with self._lock:
            size = self.journal.size()
            return {'size': size, 'root': self.journal.root(size)}

    def status(self):
        with self._lock:
            counts = {name: 0 for name in STATES}
            for name, count in self.db.execute('SELECT state, count(*) FROM spend_charges GROUP BY state'):
                counts[name] = count
            row = self.db.execute('SELECT high FROM spend_clock WHERE id=0').fetchone()
            return {'format': FORMAT_VERSION, 'root': self.root_key, 'audience': self.audience, 'counts': counts,
                    'journal': self.journal_head(), 'clock': None if row is None else row[0],
                    'currentness': self.currentness, 'execution_authorized': False}

    def backup(self, destination):
        """Online SQLite backup into a new owner-private file; never overwrites."""
        target = Path(os.path.abspath(os.fspath(destination)))
        need(target.parent.is_dir() and not os.path.lexists(target), 'SPEND_BACKUP')
        os.close(os.open(target, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600))
        copy = sqlite3.connect(target)
        try:
            with self._lock:
                self.db.backup(copy)
        finally:
            copy.close()
        return str(target)


def prometheus(status):
    lines = ['# HELP covenant_spend_charges Charges in the spend-window ledger by state.',
             '# TYPE covenant_spend_charges gauge']
    for name in STATES:
        lines.append('covenant_spend_charges{state="%s"} %d' % (name, status['counts'].get(name, 0)))
    lines += ['# HELP covenant_spend_journal_size Journal leaves recorded by the spend-window ledger.',
              '# TYPE covenant_spend_journal_size gauge', 'covenant_spend_journal_size %d' % status['journal']['size']]
    return '\n'.join(lines) + '\n'


def describe():
    return {'format': FORMAT_VERSION, 'mandates': scoped_mandates.VERSION, 'states': list(STATES),
            'counting': 'RESERVED_UNKNOWN_AND_COMMITTED_COUNT; ONLY_RELEASED_STOPS',
            'window': 'CHARGES_DATED_WITHIN_THE_LAST_WINDOW_SECONDS_OF_THE_OWNER_CLOCK',
            'chain': 'EVERY_WINDOW_OF_EVERY_MANDATE_IN_THE_CHAIN', 'clock': 'OWNER_SUPPLIED_NEVER_BACKWARDS',
            'journal': 'RFC6962_LEAF_PER_CHANGE; RETAIN_JOURNAL_HEAD_TO_DETECT_ROLLBACK',
            'custody': 'ONE_FILE_ONE_DOMAIN', 'limits': {'charges': MAX_CHARGES, 'journal_leaves': MAX_JOURNAL},
            'payment_made': False, 'execution_authorized': False}
