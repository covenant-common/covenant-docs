"""Standard status lists for portable agent qualifications, judged under the owner's adopted policy.

This extends ``covenant-agent-accreditation/0.1``; it adds no new trust. An
issuer that also signs its status as an IETF Token Status List or a W3C
Bitstring Status List pair (``status_lists``) is checked exactly as
``agent_accreditation`` checks its map snapshots:

* the snapshot's issuer name and key version must be adopted in the relying
  party's policy (covenant-agent-accreditation-policy/0.2, or /0.1 unchanged);
* it must be issued no later than the supplied clock, unexpired and at most
  ``maximum_status_age`` old, or it is ACCREDITATION_STATUS_STALE;
* 0x00 is ACTIVE, 0x01 (INVALID) is REVOKED, 0x02 is SUSPENDED and any other
  value is UNKNOWN; an index outside the list refuses the credential (Token
  Status List section 8.3, step 6);
* a credential signed by a key version the snapshot lists as withdrawn refuses.

``assess`` never refuses on status: it returns a labelled answer ("checked
against the snapshot dated ... (age ...)") for offline review and eligibility
reports. ``check`` refuses as the map profile does. Durable use goes through the
owner's existing ``VerifierStore``: each issuer list is one status stream with
its high-water sequence, equivocation, issue-time and clock checks, and every
revoked entry is remembered so a newer list cannot resurrect it. A next
sequence must also name the retained snapshot as its predecessor.
"""
from copy import deepcopy
import hashlib

from . import agent_accreditation as accreditation
from .agent_accreditation import REMEDIATION as ACCREDITATION_REMEDIATION  # the shared ACCREDITATION_* codes
from . import status_lists as lists
from .crypto import digest, integer, need

STREAM_PREFIX = 'status-list:'
REVOKED_LABEL = 'AAP-STATUS-LIST-REVOKED-ENTRY-0.1'
NAMES = {lists.VALID: 'ACTIVE', lists.INVALID: 'REVOKED', lists.SUSPENDED: 'SUSPENDED'}
FRESHNESS = ('FRESH', 'STALE', 'EXPIRED', 'FUTURE')

ERRORS = {
    'ACCREDITATION_STATUS_EVIDENCE': ('The status evidence is neither a Status List Token nor a W3C revocation and '
                                      'suspension pair.',
                                      'Send the token string, or {"revocation": credential, "suspension": credential}.',
                                      False),
    'ACCREDITATION_STATUS_LIST': ('The snapshot describes another list than the credential\'s status reference.',
                                  'Use the snapshot of the exact list the credential names.', False),
    'ACCREDITATION_STATUS_CHAIN': ('The next snapshot does not name the retained snapshot as its predecessor.',
                                   'Treat the issuer history as forked; obtain an explanation before relying on it.',
                                   False),
    'ACCREDITATION_KEY_VERSION_WITHDRAWN': ('The issuer withdrew the key version that signed this credential.',
                                            'Ask the holder for a credential re-issued under a current key.', False),
}

# What happened, then what to do, for each code raised here that agent_accreditation.REMEDIATION does not
# explain: the plain-text form tools/production_readiness.py reads. ERRORS keeps the retry hints.
REMEDIATION = {
    'ACCREDITATION_STATUS_EVIDENCE':
        'The status evidence is neither a Status List Token nor a W3C revocation and suspension pair. Send '
        'the token string, or {"revocation": credential, "suspension": credential}.',
    'STATUS_CREDENTIAL_PAIR':
        'The revocation and suspension credentials do not describe one snapshot. Supply both credentials '
        'from the same issuer, list and sequence.',
    'ACCREDITATION_STATUS_LIST':
        "The snapshot describes another list than the credential's status reference. Use the snapshot of the "
        'exact list the credential names.',
    'ACCREDITATION_STATUS_CHAIN':
        'The next snapshot does not name the retained snapshot as its predecessor. Treat the issuer history '
        'as forked; obtain an explanation before relying on it.',
    'ACCREDITATION_KEY_VERSION_WITHDRAWN':
        'The issuer withdrew the key version that signed this credential. Ask the holder for a credential '
        're-issued under a current key.',
}


def explain(code):
    row = ERRORS.get(code)
    if row is None:
        return lists.explain(code) if code.startswith('STATUS_') else accreditation.explain(code)
    happened, fix, retry = row
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/AGENT_ACCREDITATION.html#' + code}


def stream(issuer, list_uri):
    """The VerifierStore key for one issuer list (printable, at most 160 characters)."""
    return STREAM_PREFIX + hashlib.sha256((lists.issuer_name(issuer) + '\n' + lists.uri(list_uri)).encode('ascii')).hexdigest()


def revoked_reference(issuer, list_uri, index):
    """The remembered-revocation reference for one list entry."""
    integer(index)
    return digest(REVOKED_LABEL, {'issuer': issuer, 'list': list_uri, 'index': index})


def _adopted_key(accepted, issuer, version):
    issuers = accepted['issuers']
    need(issuer in issuers and version in issuers[issuer], 'ACCREDITATION_ISSUER_NOT_ADOPTED')
    return issuers[issuer][version]


def open_snapshot(evidence, accepted, *, list_uri=None):
    """Verify a Token Status List or W3C pair under the policy's pinned key for its key version."""
    accreditation._policy(accepted)
    if type(evidence) is str:
        seen = lists.peek_token(evidence)
        opened = lists.open_status_token(evidence, _adopted_key(accepted, seen['issuer'], seen['key_version']))
    else:
        need(type(evidence) is dict and set(evidence) == {'revocation', 'suspension'}, 'ACCREDITATION_STATUS_EVIDENCE')
        seen = [lists.peek_credential(evidence[name]) for name in lists.PURPOSES]
        need(seen[0]['issuer'] == seen[1]['issuer'] and seen[0]['key_version'] == seen[1]['key_version'],
             'STATUS_CREDENTIAL_PAIR')
        public = _adopted_key(accepted, seen[0]['issuer'], seen[0]['key_version'])
        opened = lists.open_status_credentials(evidence['revocation'], evidence['suspension'], public)
    need(list_uri is None or opened['list'] == list_uri, 'ACCREDITATION_STATUS_LIST')
    return opened


def _freshness(opened, accepted, now):
    if opened['issued_at'] > now:
        return 'FUTURE'
    if now >= opened['expires']:
        return 'EXPIRED'
    if now - opened['issued_at'] > accepted['maximum_status_age']:
        return 'STALE'
    return 'FRESH'


def assess(opened, index, accepted, *, now, credential_key_version=None, known_revoked=()):
    """A labelled answer, never upgraded: ACTIVE only from a FRESH snapshot; REVOKED at any age."""
    integer(now)
    listed = opened['statuses'].get(index)
    freshness = _freshness(opened, accepted, now)
    remembered = revoked_reference(opened['issuer'], opened['list'], index) in set(known_revoked)
    snapshot = opened['snapshot']
    withdrawn = credential_key_version is not None and credential_key_version in snapshot['withdrawn_key_versions']
    if listed == lists.INVALID or remembered:
        status = 'REVOKED'
    elif withdrawn:
        status = 'KEY_VERSION_WITHDRAWN'
    elif freshness != 'FRESH':
        status = 'UNKNOWN'
    else:
        status = NAMES.get(listed, 'UNKNOWN')
    return {'status': status, 'listed': NAMES.get(listed, 'APPLICATION_SPECIFIC'), 'freshness': freshness,
            'label': accreditation.status_label(opened['issued_at'], now), 'age_seconds': now - opened['issued_at'],
            'maximum_status_age': accepted['maximum_status_age'], 'refresh_due': now >= opened['issued_at'] + opened['ttl'],
            'index': index, 'issuer': opened['issuer'], 'list': opened['list'], 'format': opened['format'],
            'snapshot': {'id': opened['id'], 'sequence': snapshot['sequence'], 'previous': snapshot['previous'],
                         'issued_at': opened['issued_at'], 'expires': opened['expires'], 'ttl': opened['ttl'],
                         'key_version': snapshot['key_version']},
            'withdrawn_key_versions': list(snapshot['withdrawn_key_versions']), 'remembered_revocation': remembered,
            'current_global_status': 'NOT_ESTABLISHED', 'clock': 'CALLER_SUPPLIED', 'execution_authorized': False}


def adopt(opened, accepted, *, now, store):
    """Retain a fresh adopted list snapshot in the owner's VerifierStore, as adopt_status does for map snapshots."""
    need(isinstance(store, accreditation.VerifierStore), 'ACCREDITATION_VERIFIER_STORE_REQUIRED')
    accreditation._policy(accepted); integer(now)
    need(store.audience == accepted['audience'], 'ACCREDITATION_STORE_AUDIENCE')
    need(_freshness(opened, accepted, now) == 'FRESH', 'ACCREDITATION_STATUS_STALE')
    key = stream(opened['issuer'], opened['list'])
    snapshot = opened['snapshot']
    entries = {revoked_reference(opened['issuer'], opened['list'], index): 'REVOKED'
               for index in lists.indexes(opened['statuses'], lists.INVALID)}
    body = {'issuer': key, 'sequence': snapshot['sequence'], 'issued_at': opened['issued_at'], 'entries': entries}
    with store._lock:
        need(not store._closed, 'ACCREDITATION_STORE_CLOSED')
        old = store._state['snapshots'].get(key)
        if old is not None and snapshot['sequence'] == old['sequence'] + 1:
            need(snapshot['previous'] == old['id'], 'ACCREDITATION_STATUS_CHAIN')
        revoked = store._observe(body, opened['id'], now)
    return {'stream': key, 'status_snapshot': opened['id'], 'known_revocations': len(revoked),
            'revoked': revoked, 'verifier_checkpoint': store.checkpoint(), 'current_global_status': 'NOT_ESTABLISHED'}


def check(evidence, accepted, *, index, list_uri, now, store=None, credential_key_version=None,
          credential_issued_at=None):
    """Refuse unless the entry is ACTIVE in a fresh adopted snapshot; with ``store``, retain it first."""
    opened = open_snapshot(evidence, accepted, list_uri=list_uri)
    known = ()
    if store is not None:
        known = adopt(opened, accepted, now=now, store=store)['revoked']
    result = assess(opened, index, accepted, now=now, credential_key_version=credential_key_version, known_revoked=known)
    if credential_issued_at is not None:
        need(opened['issued_at'] >= credential_issued_at, 'ACCREDITATION_STATUS_PREDATES_CREDENTIAL')
    need(result['status'] != 'REVOKED', 'ACCREDITATION_STATUS_REVOKED')
    need(result['status'] != 'KEY_VERSION_WITHDRAWN', 'ACCREDITATION_KEY_VERSION_WITHDRAWN')
    need(result['freshness'] == 'FRESH', 'ACCREDITATION_STATUS_STALE')
    need(result['status'] == 'ACTIVE', 'ACCREDITATION_STATUS_' + result['status'])
    return {**result, 'rollback_protection': 'OWNER_VERIFIER_STORE' if store is not None else 'NOT_CHECKED_USE_OWNER_VERIFIER_STORE'}


def describe():
    return {'extends': accreditation.VERSION, 'snapshot_profile': lists.SNAPSHOT_VERSION,
            'encodings': ['IETF Token Status List (draft-ietf-oauth-status-list-21), 2 bits per entry',
                          'W3C Bitstring Status List v1.0 revocation and suspension pair'],
            'statuses': {'0x00': 'ACTIVE', '0x01': 'REVOKED', '0x02': 'SUSPENDED', 'other': 'UNKNOWN'},
            'freshness': list(FRESHNESS), 'label': 'checked against the snapshot dated <UTC time> (age <age>)',
            'rules': ['ACTIVE only from a FRESH snapshot; REVOKED at any age',
                      'stale, expired or future snapshots refuse as ACCREDITATION_STATUS_STALE',
                      'a withdrawn issuer key version refuses the credentials it signed',
                      'an index outside the list refuses the credential'],
            'store': 'agent_accreditation.VerifierStore: one stream per issuer list; revoked entries remembered',
            'limits': deepcopy(lists.describe()['limits']), 'network_accessed': False, 'execution_authorized': False}
