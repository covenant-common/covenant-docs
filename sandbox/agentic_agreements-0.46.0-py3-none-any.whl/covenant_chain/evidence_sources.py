"""Five evidence sources on the registries that already exist.

Image: a C2PA manifest hash checked by a ProofRegistry verifier. This checks a
signed hash bound to the blob. It does not parse a JUMBF box.
GPS: a ResourceObservationAdapter reading, signed by the source key.
URL: a TLSNotary-shaped signature over the response hash. It is not a TLS proof.
Email: DKIM verified against the key the parties pinned for that domain. DNS is not queried when the pin matches.
File: a self-reported blob. No corroboration is added. Parties may still use it.

None of these decide a covenant. None of them are installed by an agent URL.
"""
from copy import deepcopy
import base64
import hashlib
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .adapters import AdapterRegistry, manifest
from .crypto import digest, public_key, sign
from .evidence import blob_descriptor, seal
from .proof_facility import ProofRegistry, _signature, inspect as proof_inspect, pack
from .resource_observations import ResourceObservationAdapter
from covenant_language.market_blueprints import asset

NOTES = {
    'image': 'C2PA_MANIFEST_HASH_NOT_A_JUMBF_PARSER',
    'url': 'TLSNOTARY_SIGNATURE_OF_STATEMENT_NOT_A_PROOF',
    'email': 'DKIM_PINNED_KEY',
    'file': 'SELF_REPORTED_NO_CORROBORATION',
    'gps': 'SIGNED_SOURCE_OBSERVATION_NOT_PHYSICAL_TRUTH',
}


def _proof(registry, system, scope, callback):
    semantics = digest('COVENANT-EVIDENCE-VERIFIER-0.1', {'system': system, 'scope': scope})
    implementation = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return registry.register({'system': system, 'semantics': semantics, 'implementation': implementation,
                              'scope': scope, 'trust': 'LOCAL_INSTALLED_EXAMPLE_NOT_A_NETWORK_CALL'}, callback)


def _signed_proof(key, system, message, context):
    statement = {'public': public_key(key), 'message': message}
    body = {'context': context, 'message': message}
    proof = base64.b64encode(bytes.fromhex(sign(key, 'COVENANT-PROOF-STATEMENT-0.1', body))).decode('ascii')
    return pack(system, statement, proof, context)['envelope']


def _guard(check):
    def verifier(envelope):
        try:
            return bool(check(envelope)) and _signature(envelope)
        except Exception:
            return False
    return verifier


class SelfReportedFile:
    """A file the party names. No second source is attached."""

    def __init__(self):
        instance = digest('COVENANT-EVIDENCE-SOURCE-0.1', {'name': 'self-reported-file'})
        self.manifest = manifest('self-reported-file', 'evidence.file', effect='HASH_ONLY_NO_CORROBORATION',
                                 instance=instance, recovery='OBSERVE_ONLY')
        self.manifest['requirements'].update(evidence_profile='covenant-evidence-adapter/0.1', source_class='DOCUMENT',
                                              provenance_methods=['SELF_REPORTED'], max_confidence_bps=4000,
                                              independence_key='self-reported-file')

    def execute(self, effect_id, request, *, crash=None):
        return self.observe(effect_id)

    def observe(self, effect_id):
        return {'status': 'OBSERVED', 'output_hash': None, 'assurance': NOTES['file']}


def install_verifiers(registry=None):
    registry = ProofRegistry() if registry is None else registry

    def image(envelope):
        message = envelope['statement']['message']
        return message.get('manifest_hash') == message.get('blob_sha256') and type(message.get('media_type')) is str and message['media_type'].startswith('image/')

    def url(envelope):
        message = envelope['statement']['message']
        return type(message.get('url')) is str and message.get('response_sha256') == message.get('blob_sha256')

    def email(envelope):
        message = envelope['statement']['message']
        return (type(message.get('domain')) is str and type(message.get('selector')) is str
                and message.get('body_sha256') == message.get('blob_sha256')
                and message.get('pinned_key') == envelope['statement'].get('public'))

    return {'image': _proof(registry, 'c2pa-manifest-hash/0.1', NOTES['image'], _guard(image)),
            'url': _proof(registry, 'tlsnotary/stub-0.1', NOTES['url'], _guard(url)),
            'email': _proof(registry, 'dkim-pinned-key/0.1', NOTES['email'], _guard(email)),
            'registry': registry}


def install_gps(directory, private_key, claim, *, observed_at=1_000, clock=None):
    def callback(asset_value, query, effect_id):
        return {'status': 'VALUE', 'claim': deepcopy(claim), 'evidence': [], 'observed_at': observed_at}

    adapter = ResourceObservationAdapter(directory, {'name': 'gps-reading', 'endpoint_policy': 'owner-pinned'},
                                         private_key, callback, clock=clock or (lambda: observed_at))
    adapter.manifest['requirements'].update(evidence_profile='covenant-evidence-adapter/0.1', source_class='GPS',
                                             provenance_methods=['SIGNED_SOURCE'], max_confidence_bps=9000,
                                             independence_key='gps-receiver')
    return adapter


def model_answer(private_key, agreement, context, adapter):
    """An AI judgement with no second source. The toolkit must not call it true."""
    blob = blob_descriptor('text/plain', raw=b'model says the crate is ripe')
    return seal(private_key, agreement, context, adapter, 'AI_MODEL', blob,
                {'field': 'ripe', 'value': True}, 1_000, 1_000, [], 8000,
                {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []})


def example_set(directory, agreement=None, context=None):
    """Build the five sources and the envelopes a condition can read."""
    agreement = digest('COVENANT-EVIDENCE-EXAMPLE-AGREEMENT', {'example': 'sources'}) if agreement is None else agreement
    context = digest('COVENANT-EVIDENCE-EXAMPLE-CONTEXT', {'example': 'sources'}) if context is None else context
    device = Ed25519PrivateKey.generate()
    party = Ed25519PrivateKey.generate()
    verifiers = install_verifiers()
    proofs = verifiers['registry']
    photo = b'\xff\xd8\xff\xd9example-jpeg'
    photo_sha = hashlib.sha256(photo).hexdigest()
    image_message = {'blob_sha256': photo_sha, 'manifest_hash': photo_sha, 'media_type': 'image/jpeg'}
    image_proof = _signed_proof(device, 'c2pa-manifest-hash/0.1', image_message, context)
    image_proof_id = proof_inspect(image_proof)['id']
    image = seal(device, agreement, context, verifiers['image'], 'IMAGE',
                 blob_descriptor('image/jpeg', sha256=photo_sha, nbytes=len(photo)),
                 {'field': 'delivered_at_door', 'value': True}, 1_000, 1_000,
                 [{'method': 'C2PA', 'proof': image_proof_id, 'verifier': verifiers['image']}], 8000,
                 {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []})
    page = b'{"status":"delivered"}'
    page_sha = hashlib.sha256(page).hexdigest()
    url_message = {'url': 'https://example.test/delivery', 'blob_sha256': page_sha, 'response_sha256': page_sha}
    url_proof = _signed_proof(device, 'tlsnotary/stub-0.1', url_message, context)
    url_proof_id = proof_inspect(url_proof)['id']
    url = seal(device, agreement, context, verifiers['url'], 'WEB',
               blob_descriptor('application/json', sha256=page_sha, nbytes=len(page)),
               {'field': 'status', 'value': 'delivered'}, 1_000, 1_000,
               [{'method': 'TLSNOTARY', 'proof': url_proof_id, 'verifier': verifiers['url']}], 7000,
               {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []})
    letter = b'From: dock@example.test\r\n\r\ncrate received\r\n'
    letter_sha = hashlib.sha256(letter).hexdigest()
    email_message = {'domain': 'example.test', 'selector': 'covenant', 'blob_sha256': letter_sha, 'body_sha256': letter_sha,
                     'pinned_key': public_key(device)}
    email_proof = _signed_proof(device, 'dkim-pinned-key/0.1', email_message, context)
    email_proof_id = proof_inspect(email_proof)['id']
    email = seal(device, agreement, context, verifiers['email'], 'EMAIL',
                 blob_descriptor('message/rfc822', sha256=letter_sha, nbytes=len(letter)),
                 {'field': 'received', 'value': True}, 1_000, 1_000,
                 [{'method': 'DKIM', 'proof': email_proof_id, 'verifier': verifiers['email']}], 7500,
                 {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []})
    note = b'I left the crate at the door.'
    from covenant_language.external_drafts import pack as pack_bytes
    packed = pack_bytes(base64.b64encode(note).decode('ascii'), title='Door note', media_type='text/plain')
    file_adapter = SelfReportedFile()
    adapters = AdapterRegistry()
    file_id = adapters.register(file_adapter)
    gps_claim = {'lat_e7': 515071000, 'lon_e7': -1403000}
    gps = install_gps(Path(directory) / 'gps', device, gps_claim)
    gps_id = adapters.register(gps)
    gps_asset = asset('sensor', 'door-gps', 'e7', adapter=gps_id, transfer_terms={'title': 'reading is not title'})
    gps_query = {'field': 'lat_e7'}
    gps_effect = digest('COVENANT-EVIDENCE-GPS-EFFECT', {'agreement': agreement})
    observed = gps.execute(gps_effect, {'asset': gps_asset, 'query': gps_query, 'context': context})
    gps.close()
    file_env = seal(party, agreement, context, file_id, 'DOCUMENT',
                    blob_descriptor('text/plain', raw=note, capsule=packed['id']),
                    {'field': 'left_at_door', 'value': True}, 1_000, 1_000, [], 3000,
                    {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []})
    return {'agreement': agreement, 'context': context, 'device': device, 'party': party, 'proofs': proofs,
            'adapters': adapters, 'notes': dict(NOTES), 'image': {**image, 'proof': image_proof, 'verifier': verifiers['image']},
            'url': {**url, 'proof': url_proof, 'verifier': verifiers['url']},
            'email': {**email, 'proof': email_proof, 'verifier': verifiers['email']},
            'file': {**file_env, 'adapter': file_id, 'capsule': packed['id']},
            'gps': {'adapter': gps_id, 'adapter_object': gps, 'asset': gps_asset, 'query': gps_query,
                    'observation': observed['value']['observation'], 'source': gps.source, 'key': public_key(device),
                    'claim': gps_claim}}
