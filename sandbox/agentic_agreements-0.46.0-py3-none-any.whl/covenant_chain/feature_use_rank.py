"""Experimental local feature order from dual-signed, fulfilled outcome assertions.

This new host profile does not reinterpret portable-trust receipts. A separate
trace, signed by both receipt parties, binds the receipt id and ordered feature
ids. Only the owner's adopted counterparty clusters contribute; repeated or
conflicting agreements, self-control clusters, unknown and unfulfilled outcomes
do not create support. No calls, clicks, installs, telemetry or payments count.
Ranks stay inside each declared level. Core, meaning, authority and availability
are unchanged. Fulfilment is the parties' signed assertion, not world truth.
"""
from copy import deepcopy
import argparse
import json
from pathlib import Path

from .crypto import canonical, digest, exact, integer, need, public_key, sign, verification_key, verify
from .discovery_rank import allocate, SCALE
from . import portable_trust

VERSION = 'covenant-feature-use-trace/0.1'
LABEL = 'COVENANT-FEATURE-USE-TRACE-0.1'
MAX_RECORDS = 256
MAX_FEATURES = 256
MAX_TRACE = 16
MAX_BYTES = 2097152
LEVELS = ('L0', 'L1', 'L2', 'L3', 'L4', 'ORGANON')
ASSURANCE = 'DUAL_SIGNED_FULFILLED_ASSERTION_NOT_WORLD_TRUTH_OR_PAYMENT'


def _text(value, code, limit=256):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _features(values):
    need(type(values) is list and 1 <= len(values) <= MAX_TRACE, 'USE_TRACE_FEATURES')
    for value in values:
        _text(value, 'USE_FEATURE')
        need(value.startswith(('tool:', 'profile:', 'extension:')), 'USE_FEATURE')
    # Repeated calls do not create extra weight. Order of first use is retained.
    return list(dict.fromkeys(values))


def default_registry():
    """All mapped tools remain available, including those with no outcome evidence."""
    from .aap_levels import registry
    return {'tool:' + name: {'level': row['level'], 'core': row['core']}
            for name, row in registry()['tools'].items()}


def _outcome(record):
    need(type(record) is dict and type(record.get('body')) is dict, 'USE_OUTCOME')
    body = record['body']
    ref = portable_trust.record_id(body)
    checked = portable_trust.verify_outcome(record, ref, body['agreement'], body['context'], body['subject'])
    need(body['mode'] == 'BILATERAL' and len(body['parties']) == 2, 'USE_BILATERAL')
    need(body['subject']['kind'] == 'agent' and body['subject']['id'] in body['parties'], 'USE_SUBJECT')
    return body, checked['id']


def prepare_trace(outcome, features):
    """Prepare a new exact trace for the two parties' explicit local signatures."""
    body, ref = _outcome(outcome)
    value = {'version': VERSION, 'outcome': ref, 'agreement': body['agreement'], 'context': body['context'],
             'parties': body['parties'], 'features': _features(features)}
    return {'body': value, 'label': LABEL, 'id': digest(LABEL, value),
            'required_signers': list(body['parties']), 'execution_authorized': False}


def sign_trace(prepared, keys):
    """Owner-side helper only. A trace alone never grants signing authority."""
    need(type(keys) is list and len(keys) == 2, 'USE_SIGNERS')
    body = prepared['body']
    parties = [public_key(key) for key in keys]
    need(sorted(parties) == body['parties'], 'USE_SIGNERS')
    return {'body': deepcopy(body), 'signatures': [{'signer': public_key(key), 'signature': sign(key, LABEL, body)}
                                                for key in keys]}


def _trace(row):
    exact(row, 'outcome trace')
    portable_trust._bounded(row)
    source, ref = _outcome(row['outcome'])
    record = row['trace']
    exact(record, 'body signatures')
    body = record['body']
    exact(body, 'version outcome agreement context parties features')
    need(body['version'] == VERSION and body['outcome'] == ref and body['agreement'] == source['agreement']
         and body['context'] == source['context'] and body['parties'] == source['parties'], 'USE_BINDING')
    need(body['features'] == _features(body['features']), 'USE_TRACE_FEATURES')
    signatures = record['signatures']
    need(type(signatures) is list and len(signatures) == 2, 'USE_SIGNATURES')
    signers = []
    for item in signatures:
        exact(item, 'signer signature')
        need(type(item['signer']) is str and item['signer'] in body['parties'], 'USE_SIGNER')
        verify(item['signer'], LABEL, body, item['signature'])
        signers.append(item['signer'])
    need(sorted(signers) == body['parties'], 'USE_SIGNATURES')
    return source, body, digest(LABEL, body)


def _registry(features):
    need(type(features) is dict and 1 <= len(features) <= MAX_FEATURES, 'USE_REGISTRY')
    for name, row in features.items():
        _features([name])
        exact(row, 'level core')
        need(row['level'] in LEVELS and type(row['core']) is bool, 'USE_REGISTRY')


def _walk(nodes, adjacency, seeds, damping_bps, iterations):
    """Integer weighted PageRank, reusing discovery_rank's exact mass allocator."""
    mass = allocate(SCALE, seeds)
    mass = {node: mass.get(node, 0) for node in nodes}
    for _ in range(iterations):
        nxt = {node: 0 for node in nodes}
        for node in nodes:
            continuation = mass[node] * damping_bps // 10000
            for target, amount in allocate(continuation, adjacency[node] or seeds).items():
                nxt[target] += amount
            for target, amount in allocate(mass[node] - continuation, seeds).items():
                nxt[target] += amount
        need(sum(nxt.values()) == SCALE, 'USE_MASS')
        mass = nxt
    return mass


def rank(records, features, *, owner, context, contacts, now, max_age, owner_cluster='owner',
         per_cluster_cap=4, dependencies=None, seeds=None, damping_bps=8500, iterations=40):
    """Inspect all features; only verified, scoped, adopted evidence contributes.

    ``contacts`` maps owner-adopted counterparty keys to owner-assigned control
    clusters, not claimed clusters from a receipt. A key in ``owner_cluster`` is
    self-control and excluded. One cluster supports at most ``per_cluster_cap``
    distinct agreements. No claim of general Sybil resistance is made.
    """
    _registry(features)
    verification_key(owner)
    _text(context, 'USE_CONTEXT')
    _text(owner_cluster, 'USE_CLUSTER')
    integer(now); integer(max_age)
    need(type(per_cluster_cap) is int and 1 <= per_cluster_cap <= 16, 'USE_CLUSTER_CAP')
    need(type(damping_bps) is int and 0 <= damping_bps <= 9500, 'USE_DAMPING')
    need(type(iterations) is int and 1 <= iterations <= 100, 'USE_ITERATIONS')
    need(type(contacts) is dict and len(contacts) <= 256, 'USE_CONTACTS')
    for key, cluster in contacts.items():
        verification_key(key); _text(cluster, 'USE_CLUSTER')
    need(type(records) is list and len(records) <= MAX_RECORDS, 'USE_RECORDS')
    portable_trust._bounded(records, MAX_BYTES)
    dependencies = [] if dependencies is None else dependencies
    need(type(dependencies) is list and len(dependencies) <= 4096, 'USE_DEPENDENCIES')
    for edge in dependencies:
        need(type(edge) is list and len(edge) == 2 and all(type(v) is str and v in features for v in edge), 'USE_DEPENDENCY')
    seeds = {} if seeds is None else seeds
    need(type(seeds) is dict and set(seeds) <= set(features), 'USE_SEEDS')
    for amount in seeds.values():integer(amount, True)
    rejected = {}
    groups = {}
    def reject(reason):rejected[reason] = rejected.get(reason, 0) + 1
    for record in records:
        try:
            source, trace, ident = _trace(record)
            need(source['context'] == context, 'USE_CONTEXT')
            need(source['issued_at'] <= now and now - source['issued_at'] <= max_age, 'USE_STALE')
            need(owner in source['parties'], 'USE_OWNER')
            counterparty = next(key for key in source['parties'] if key != owner)
            need(counterparty in contacts, 'USE_CONTACT_NOT_ADOPTED')
            cluster = contacts[counterparty]
            need(cluster != owner_cluster and counterparty != owner, 'USE_SELF_CONTROL')
            need(set(trace['features']) <= set(features), 'USE_FEATURE_NOT_INSTALLED')
        except (ValueError, KeyError, TypeError, StopIteration) as exc:
            reject(str(exc) if isinstance(exc, ValueError) else 'USE_MALFORMED')
            continue
        groups.setdefault(source['agreement'], {})[ident] = (source, trace, cluster)
    accepted = []
    by_cluster = {}
    for agreement, entries in sorted(groups.items()):
        if len(entries) != 1 or any(row[0]['outcome'] != 'FULFILLED' for row in entries.values()):
            reject('USE_CONFLICT_OR_UNFULFILLED');continue
        source, trace, cluster = next(iter(entries.values()))
        rows = by_cluster.setdefault(cluster, [])
        if len(rows) >= per_cluster_cap:
            reject('USE_CLUSTER_CAP');continue
        rows.append(agreement);accepted.append((agreement, trace))
    edges = {}
    support = {name: 0 for name in features}
    for agreement, trace in accepted:
        seen = trace['features']
        for name in seen:support[name] += 1
        # Co-occurrence is bidirectional; consecutive use adds one directed unit.
        for a in seen:
            for b in seen:
                if a != b:edges[a,b] = edges.get((a,b),0) + 1
        for a,b in zip(seen,seen[1:]):edges[a,b] = edges.get((a,b),0) + 1
    for a,b in set(map(tuple,dependencies)):
        if a != b:edges[a,b] = edges.get((a,b),0) + 1
    levels = {}
    for level in LEVELS:
        nodes = sorted(name for name, row in features.items() if row['level'] == level)
        if not nodes:continue
        adjacency = {name:{} for name in nodes}
        for (a,b),weight in sorted(edges.items()):
            if a in adjacency and b in adjacency:adjacency[a][b] = weight
        personal = {name:seeds[name] for name in nodes if name in seeds} or {name:1+support[name] for name in nodes}
        mass = _walk(nodes,adjacency,personal,damping_bps,iterations)
        ordered = sorted(nodes,key=lambda name:(not features[name]['core'],
                         0 if features[name]['core'] else -mass[name],name))
        levels[level] = [{'feature':name,'rank_ppb':mass[name],'core':features[name]['core'],
                          'supported_agreements':support[name],'dormant':support[name] == 0} for name in ordered]
    return {'profile':VERSION,'maturity':'experimental','context':context,'levels':levels,
            'accepted_agreements':[agreement for agreement,_trace in accepted], 'rejected':dict(sorted(rejected.items())),
            'counterparty_clusters':len(by_cluster),'per_cluster_cap':per_cluster_cap,'assurance':ASSURANCE,
            'sybil_resistance':'OWNER_ADOPTED_CONTROL_CLUSTERS_AND_CAP_NOT_A_PROOF',
            'authority_changed':False,'core_changed':False,'features_removed':False,'telemetry':False,
            'execution_authorized':False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='Owner-local JSON rank arguments, at most 2 MiB; never fetched.')
    args = parser.parse_args(argv)
    if args.input is None:
        result = {'profile':VERSION,'maturity':'experimental','assurance':ASSURANCE,'telemetry':False,
                  'execution_authorized':False}
    else:
        with args.input.open('rb') as stream:raw = stream.read(MAX_BYTES+1)
        need(len(raw) <= MAX_BYTES, 'USE_SIZE')
        from .crypto import loads
        result = rank(**loads(raw))
    print(json.dumps(result,indent=2,sort_keys=True))
    return 0


if __name__ == '__main__':raise SystemExit(main())
