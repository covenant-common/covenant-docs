"""Keyless, pure publication previews. Owner custody stays in the local CLI."""
from .cooperation_interface import HASH, OBJECT, schema


def read_spec():
    return ('covenant_public_web',
            'Inspect the opt-in public web profile or prepare an exact field projection and signing payload. '
            'Private by default. All derived principals must separately assent to selected fields and public '
            'metadata, website origin, indexing choice and revision. No key, storage, network request or '
            'publication. Source records are private inputs to this host; do not send private sources to '
            'an untrusted remote preview service.', True, [
                ('spec', {}, ()),
                ('verify', {'envelope':OBJECT}, ('envelope',)),
                ('inspect_source', {
                    'kind': {'enum':['marketplace','social','profile','ledger']},
                    'source': OBJECT,
                }, ('kind','source')),
                ('prepare', {
                    'origin': {'type':'string','minLength':1,'maxLength':240},
                    'kind': {'enum':['marketplace','social','profile','ledger']},
                    'source': OBJECT,
                    'fields': {'type':'array','minItems':1,'maxItems':32,'uniqueItems':True,
                               'items':{'type':'string','minLength':1,'maxLength':64}},
                    'visibility': {'enum':['PRIVATE','UNLISTED','INDEXED']},
                    'links': {'type':'array','maxItems':32,'uniqueItems':True,'items':HASH},
                    'sequence': {'type':'integer','minimum':1,'maximum':2**53-1},
                    'previous': {'anyOf':[HASH,{'type':'null'}]},
                    'expires': {'anyOf':[{'type':'integer','minimum':1,'maximum':2**53-1},{'type':'null'}]},
                }, ('origin','kind','source','fields')),
            ])


def call(action, parameters):
    from . import public_web
    if action == 'spec': return public_web.spec()
    if action == 'inspect_source': return public_web.inspect_source(**parameters)
    if action == 'verify': return public_web.verify_publication(**parameters)
    return public_web.prepare(**parameters)
