"""The AAP chain as one witness in a k-of-n witness policy, and as an anchor for release metadata. Maturity: experimental.

A CHAIN mode beside the C2SP cosigning witnesses of witness_journal. The log's
operator anchors a checkpoint (origin, size, root) with the existing native
operation PRACTICE_ANCHOR (native 0.6 and later; no consensus change): the
reference names the slot (origin, size), the scope binds the root and the parent
names the slot anchored before it. Consensus keeps at most one anchor per
reference, so one chain shows every verifier the same root for an anchored size.

Evidence is a committee-certified light bundle for the anchor record
(covenant-native-light/0.1, or /0.2 for timed native 0.15/0.16 blocks),
exported at the block that includes the anchoring transaction. Any full node
can export it; anyone holding the genesis pin verifies it offline. The anchor
is fresh when its signed block time is within the policy's max_age (timed
chains) or when its height reaches the verifier's own floor (untimed chains).

The same slot scheme anchors The Update Framework snapshot metadata: origin
aap-release/<repository>, size the snapshot version, root the SHA-256 of the
exact snapshot bytes. A verifier then knows every client of that chain saw the
same snapshot for that version.

A different root under the pinned publisher is signed evidence of equivocation
(REFUSED). A missing, foreign, malformed or stale anchor only fails to count
(UNKNOWN): it never becomes VERIFIED, and a chain anchor never grants authority.

witness_journal defines the policy /0.2 shape and the quorum; this module is
the light-client side it never imports: evaluate, verify_proof, verify_extension,
ChainGate and verify_receipt_proof count the chain with evidence the verifier
fetched itself.
"""
from copy import deepcopy
import base64
from functools import partial
import hashlib
import re

from covenant_language.agentic import object_id

from . import witness_journal
from .crypto import canonical, genesis_id, integer, need

EVIDENCE = 'urn:aap:chain-witness-evidence:0.1'
SLOT = 'urn:aap:chain-witness-slot:0.1'
BINDING = 'urn:aap:chain-witness-checkpoint:0.1'
RELEASE_PREFIX = 'aap-release/'
OPERATION = 'PRACTICE_ANCHOR'
TABLE = 'practice_anchors'
PROFILES = ('covenant-native-light/0.1', 'covenant-native-light/0.2')
MAX_EVIDENCE = 4_000_000
FUTURE_SKEW = 60
VERIFIED, UNKNOWN, REFUSED = 'VERIFIED', 'UNKNOWN', 'REFUSED'
NAME = re.compile(r'[!-*,-~]{1,255}\Z')  # C2SP signed-note names: printable ASCII, no space or plus sign

REMEDIATION = {
    'CHAIN_WITNESS_SPEC': 'Adopt {name, chain, publishers}: a note-style name, the 64-hex genesis id and 1 to 8 sorted chain accounts allowed to anchor.',
    'CHAIN_WITNESS_CHECKPOINT': 'Pass the checkpoint origin (C2SP name), tree size and 64-hex RFC 6962 root.',
    'CHAIN_WITNESS_NOT_ANCHORED': 'No block in the supplied history anchors this slot; submit the PRACTICE_ANCHOR transaction first.',
    'CHAIN_WITNESS_RELEASE': 'Pass a repository name and the exact TUF snapshot metadata bytes verified by update_trust.',
    'WITNESS_CHAIN_EVIDENCE': 'The chain evidence is malformed, for another chain or slot, or its light proof does not verify; fetch it again from a node.',
    'WITNESS_CHAIN_PUBLISHER': 'The slot was anchored by an account the policy does not pin; it does not count. Anchor the next size from a pinned account.',
    'WITNESS_CHAIN_CONFLICT': 'The pinned publisher anchored a different root for this size: keep both as equivocation evidence and stop relying on the log.',
    'WITNESS_CHAIN_ANCHOR_HEIGHT': 'Export the light bundle at the block that includes the anchoring transaction.',
    'WITNESS_CHAIN_FUTURE': 'The anchoring block time is ahead of the owner clock; check the clock before relying on it.',
    'WITNESS_CHAIN_STALE': 'The anchor is older than max_age, or below the owner height floor for an untimed chain; anchor a newer checkpoint.',
    'WITNESS_CHAIN_MISSING': 'No evidence was supplied for this chain witness; obtain it from any node of the pinned chain.',
    'WITNESS_CHAIN_UNKNOWN': 'At least one chain witness could not be counted; see its verdict codes.',
    'WITNESS_CHAIN_INPUT': 'Pass chain evidence and height floors only under a covenant-witness-policy/0.2, keyed by adopted chain witness names.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the input against the documented chain witness profile.')


def _checkpoint(origin, size, root):
    need(type(origin) is str and NAME.fullmatch(origin) is not None, 'CHAIN_WITNESS_CHECKPOINT')
    need(type(size) is int and 0 <= size <= 2 ** 53 - 1, 'CHAIN_WITNESS_CHECKPOINT')
    if root is not None:
        need(type(root) is str and re.fullmatch('[0-9a-f]{64}', root) is not None, 'CHAIN_WITNESS_CHECKPOINT')


def slot(origin, size):
    """The PRACTICE_ANCHOR reference for one (origin, size): at most one anchor per chain."""
    _checkpoint(origin, size, None)
    return object_id({'type': SLOT, 'origin': origin, 'size': size})


def binding(origin, size, root):
    """The PRACTICE_ANCHOR scope binding the root to its slot."""
    _checkpoint(origin, size, root)
    return object_id({'type': BINDING, 'origin': origin, 'size': size, 'root': root})


def anchor_payload(origin, size, root, previous_size=None):
    """The exact PRACTICE_ANCHOR payload; previous_size links the slot anchored before this one."""
    need(previous_size is None or (type(previous_size) is int and 0 <= previous_size < size), 'CHAIN_WITNESS_CHECKPOINT')
    return {'reference': slot(origin, size), 'parent': None if previous_size is None else slot(origin, previous_size),
            'scope': binding(origin, size, root)}


def anchor_operation(origin, size, root, previous_size=None):
    """{op, payload} for the owner's chain client (world_sdk.anchor_practice or app.make_transaction). Not submitted."""
    return {'op': OPERATION, 'payload': anchor_payload(origin, size, root, previous_size), 'submitted': False,
            'execution_authorized': False}


def spec(name, chain, publishers):
    """A chain witness the owner adopts into a covenant-witness-policy/0.2."""
    value = {'name': name, 'chain': chain, 'publishers': publishers}
    check_spec(value)
    return value


def check_spec(value):
    """The policy row shape, as witness_journal.chain_spec checks it inside a policy."""
    return witness_journal.chain_spec(value, 'CHAIN_WITNESS_SPEC')


def _anchoring_height(entries, reference):
    for index, entry in enumerate(entries):
        for tx in entry['block']['txs']:
            body = tx.get('body') if type(tx) is dict else None
            if type(body) is dict and body.get('op') == OPERATION and type(body.get('payload')) is dict \
                    and body['payload'].get('reference') == reference:
                return index + 1
    raise ValueError('CHAIN_WITNESS_NOT_ANCHORED')


def export_evidence(genesis, entries, origin, size):
    """Producer side (any full node): a light bundle for the anchor record at the block that includes it."""
    from . import app, light
    reference = slot(origin, size)
    height = _anchoring_height(entries, reference)
    prefix = entries[:height]
    if any('time' in entry['block'] for entry in prefix):
        # Timed blocks: replay the node's own validated history; the bundle pins the head's state root.
        from . import timed_light
        from .state import prove_record
        state, transitions = app.genesis_state(genesis), []
        for entry in prefix:
            epoch = state['domain']['active']['epoch']
            state = app.begin_block(state, entry['block']['height'])
            for tx in entry['block']['txs']:
                state = app.apply_transaction(state, tx, entry['block']['height'])
            if state['domain']['active']['epoch'] != epoch:
                transitions.append({'proof': prove_record(state, 'domain', 'active'), 'checkpoint': deepcopy(entry)})
        bundle = timed_light.export_checkpoint_bundle(genesis, state, prefix[-1], transitions, TABLE, reference)
    else:
        bundle = light.export_light_bundle(genesis, prefix, TABLE, reference)
    return {'version': EVIDENCE, 'genesis': deepcopy(genesis), 'origin': origin, 'size': size, 'bundle': bundle}


def _verdict(status, codes, name, **detail):
    return {'status': status, 'codes': codes, 'name': name, 'counted': status == VERIFIED, **detail,
            'currentness': 'ANCHORED_SNAPSHOT_NOT_GLOBAL_LATEST', 'execution_authorized': False}


def verify_evidence(evidence, chain_spec, *, origin, size, root, now, max_age, fresh_height=None, light_client=None):
    """VERIFIED when a certified, fresh anchor by a pinned publisher binds exactly this root; REFUSED on a conflicting root."""
    from . import app, light, timed_light
    check_spec(chain_spec)
    _checkpoint(origin, size, root)
    integer(now)
    integer(max_age, True)
    need(fresh_height is None or (type(fresh_height) is int and fresh_height >= 1), 'CHAIN_WITNESS_SPEC')
    name, reference = chain_spec['name'], slot(origin, size)
    try:
        need(type(evidence) is dict and set(evidence) == {'version', 'genesis', 'origin', 'size', 'bundle'}
             and evidence['version'] == EVIDENCE and evidence['origin'] == origin and evidence['size'] == size, 'WITNESS_CHAIN_EVIDENCE')
        need(len(canonical(evidence)) <= MAX_EVIDENCE, 'WITNESS_CHAIN_EVIDENCE')
        genesis, bundle = evidence['genesis'], evidence['bundle']
        need(type(genesis) is dict and genesis_id(genesis) == chain_spec['chain'] and type(bundle) is dict
             and bundle.get('profile') in PROFILES, 'WITNESS_CHAIN_EVIDENCE')
        floor = 1 if fresh_height is None else fresh_height
        if bundle['profile'] == PROFILES[1]:
            report = timed_light.verify_light_bundle(genesis, bundle, chain_spec['chain'], 1, TABLE, reference)
        elif light_client is not None:
            need(getattr(light_client, 'chain', None) == chain_spec['chain'], 'WITNESS_CHAIN_EVIDENCE')
            report = light_client.assess(bundle, 1, TABLE, reference)
        else:
            report = light.verify_light_bundle(genesis, bundle, chain_spec['chain'], 1, TABLE, reference)
        value = report['value']
        need(type(value) is dict and set(value) == {'reference', 'parent', 'scope', 'publisher', 'event'}
             and value['reference'] == reference, 'WITNESS_CHAIN_EVIDENCE')
        block = bundle['record']['checkpoint']['block']
        matches = [tx for tx in block['txs'] if type(tx) is dict and type(tx.get('body')) is dict
                   and app.transaction_id(tx) == value['event']]
    except (ValueError, KeyError, TypeError, IndexError, AttributeError):
        return _verdict(UNKNOWN, ['WITNESS_CHAIN_EVIDENCE'], name)
    detail = {'height': report['height'], 'time': block.get('time'), 'publisher': value['publisher'], 'event': value['event'],
              'parent': value['parent'], 'chain': chain_spec['chain'], 'head': report['head']}
    if value['publisher'] not in chain_spec['publishers']:
        return _verdict(UNKNOWN, ['WITNESS_CHAIN_PUBLISHER'], name, **detail)
    if value['scope'] != binding(origin, size, root):
        return _verdict(REFUSED, ['WITNESS_CHAIN_CONFLICT'], name, **detail, anchored_scope=value['scope'])
    anchored = len(matches) == 1 and matches[0]['body'].get('op') == OPERATION and matches[0]['body'].get('actor') == value['publisher'] \
        and matches[0]['body'].get('payload') == {'reference': value['reference'], 'parent': value['parent'], 'scope': value['scope']}
    if not anchored:
        return _verdict(UNKNOWN, ['WITNESS_CHAIN_ANCHOR_HEIGHT'], name, **detail)
    if 'time' in block:
        fresh = 0 <= now - block['time'] <= max_age or 0 <= block['time'] - now <= FUTURE_SKEW
        if not fresh:
            return _verdict(UNKNOWN, ['WITNESS_CHAIN_FUTURE' if block['time'] > now else 'WITNESS_CHAIN_STALE'], name, **detail)
        basis = 'SIGNED_BLOCK_TIME_WITHIN_MAX_AGE'
    else:
        if fresh_height is None or report['height'] < floor:
            return _verdict(UNKNOWN, ['WITNESS_CHAIN_STALE'], name, **detail)
        basis = 'ANCHOR_HEIGHT_AT_OR_ABOVE_VERIFIER_FLOOR'
    return _verdict(VERIFIED, [], name, **detail, freshness=basis, assurance=report['assurance'])


# Counting the chain inside a covenant-witness-policy/0.2 ---------------------------

def _inputs(policy_body, chain, chain_floor):
    """The policy's rules; evidence and floors only for adopted chain witnesses of a /0.2 policy."""
    rules = witness_journal._rules(policy_body)
    adopted = set(rules['chain'])
    need(chain is None or (type(chain) is dict and adopted and set(chain) <= adopted), 'WITNESS_CHAIN_INPUT')
    need(chain_floor is None or (type(chain_floor) is dict and adopted and set(chain_floor) <= adopted and
                                 all(type(floor) is int and floor >= 1 for floor in chain_floor.values())), 'WITNESS_CHAIN_INPUT')
    return rules


def _checker(chain, chain_floor):
    """witness_journal's chain_check over evidence the verifier fetched itself; no evidence is missing."""
    def check(name, chain_spec, *, origin, size, root, now, max_age):
        evidence = (chain or {}).get(name)
        if evidence is None:
            return _verdict(UNKNOWN, ['WITNESS_CHAIN_MISSING'], name)
        return verify_evidence(evidence, chain_spec, origin=origin, size=size, root=root, now=now, max_age=max_age,
                               fresh_height=(chain_floor or {}).get(name))
    return check


def evaluate(note, policy_body, now, *, chain=None, chain_floor=None):
    """witness_journal.evaluate, counting each adopted chain witness whose evidence verifies.

    chain maps adopted chain witness names to evidence for this checkpoint, fetched from any node;
    chain_floor maps them to the verifier's own height floor for untimed chains.
    """
    rules = _inputs(policy_body, chain, chain_floor)
    return witness_journal._evaluate(note, rules, now, _checker(chain, chain_floor))


def verify_proof(bundle, policy_body, now, *, entry=None, chain=None, chain_floor=None):
    """witness_journal.verify_proof with chain evidence for the bundle's checkpoint; the bundle format is unchanged."""
    rules = _inputs(policy_body, chain, chain_floor)
    return witness_journal._verify_proof(bundle, rules, now, entry, _checker(chain, chain_floor))


def verify_extension(retained, bundle, policy_body, now, *, chain=None, chain_floor=None):
    """witness_journal.verify_extension with chain evidence for the newer checkpoint."""
    rules = _inputs(policy_body, chain, chain_floor)
    return witness_journal._verify_extension(retained, bundle, rules, now, _checker(chain, chain_floor))


def verify_receipt_proof(bundle, policy_body, now, *, chain=None, chain_floor=None):
    """settlement_ledger_v2.verify_receipt_proof with chain evidence the counterparty fetched itself."""
    from covenant_agent import settlement_ledger_v2
    rules, check = _inputs(policy_body, chain, chain_floor), _checker(chain, chain_floor)
    return settlement_ledger_v2._verify_receipt_proof(
        bundle, rules, now, lambda proof, policy, when, *, entry: witness_journal._verify_proof(proof, policy, when, entry, check))


class ChainGate(witness_journal.Gate):
    """witness_journal.Gate that also counts adopted AAP chain witnesses (covenant-witness-policy/0.2).

    chain_witnesses maps adopted chain witness names to owner-installed clients with
    anchor(operation) -> status, which submit the PRACTICE_ANCHOR through the owner's own chain
    client, and evidence(origin, size) -> evidence or None. chain_floor holds the owner's height
    floors for untimed chains. A failing client leaves its witness uncounted.
    """

    def __init__(self, journal, policy_body, *, log_key, clock, witnesses=None, retained=None, chain_witnesses=None,
                 chain_floor=None):
        super().__init__(journal, policy_body, log_key=log_key, clock=clock, witnesses=witnesses, retained=retained)
        chain_witnesses = witness_journal._transports(chain_witnesses, self.rules['chain'])
        _inputs(self.rules, None, chain_floor)
        self.chain_witnesses = dict(chain_witnesses)
        self.chain_floor = None if chain_floor is None else dict(chain_floor)

    def _asks(self):
        return bool(self.witnesses or self.chain_witnesses)

    def collect(self):
        """One round: cosigning witnesses, then each chain client anchors the same checkpoint."""
        result = super().collect()
        size = self.journal.size()
        for name, client in sorted(self.chain_witnesses.items()):
            result[name] = self._anchor(client, size)
        return result

    def _anchor(self, client, size):
        operation = anchor_operation(self.rules['origin'], size, self.journal.root(size))
        try:
            status = client.anchor(operation)
        except Exception:  # readiness: unknown-outcome An owner-installed chain client exception is UNAVAILABLE, never an anchor.
            return 'UNAVAILABLE'
        return 'ANCHOR_SUBMITTED' if status in (True, 'SUBMITTED', 'ANCHORED') else 'UNAVAILABLE'

    def _evidence(self, size):
        found = {}
        for name, client in sorted(self.chain_witnesses.items()):
            try:
                evidence = client.evidence(self.rules['origin'], size)
            except Exception:  # readiness: unknown-outcome A failed chain read leaves that witness uncounted, never verified.
                continue
            if evidence is not None:
                found[name] = evidence
        return found

    def _evaluate(self, size, now):
        return witness_journal._evaluate(self.note(size), self.rules, now, _checker(self._evidence(size), self.chain_floor))


def gate_factory(chain_witnesses, chain_floor=None):
    """The 'gate' option of SharedSettlementLedger(witness=...): a ChainGate with these owner chain clients."""
    need(type(chain_witnesses) is dict and chain_witnesses and (chain_floor is None or type(chain_floor) is dict),
         'WITNESS_CHAIN_INPUT')
    return partial(ChainGate, chain_witnesses=dict(chain_witnesses), chain_floor=None if chain_floor is None else dict(chain_floor))


# The Update Framework release metadata ---------------------------------------------

def release_origin(repository):
    need(type(repository) is str and NAME.fullmatch(RELEASE_PREFIX + repository) is not None and repository, 'CHAIN_WITNESS_RELEASE')
    return RELEASE_PREFIX + repository


def release_anchor(repository, snapshot_raw, previous_version=None):
    """Anchor exact TUF snapshot metadata bytes: slot = (aap-release/<repository>, version), root = SHA-256(bytes)."""
    from . import update_trust
    need(type(snapshot_raw) is bytes, 'CHAIN_WITNESS_RELEASE')
    try:
        meta = update_trust.load_metadata(snapshot_raw, 'snapshot', update_trust.MAX_SNAPSHOT_BYTES)
    except ValueError:
        raise ValueError('CHAIN_WITNESS_RELEASE') from None
    version = meta['version']
    return {**anchor_operation(release_origin(repository), version, hashlib.sha256(snapshot_raw).hexdigest(), previous_version),
            'snapshot_version': version}


def verify_release(state, bundle, evidence, chain_spec, *, repository, now, max_age, fresh_height=None, time_evidence=None):
    """update_trust verification plus the chain anchor of the exact snapshot it verified. Installs nothing."""
    from . import update_trust
    origin = release_origin(repository)
    new_state, report, _staged = update_trust.apply_bundle(state, bundle, now=now, time_evidence=time_evidence)
    snapshot_raw = base64.b64decode(new_state['snapshot'])
    digest = hashlib.sha256(snapshot_raw).hexdigest()
    chain = verify_evidence(evidence, chain_spec, origin=origin, size=report['snapshot_version'], root=digest, now=now,
                            max_age=max_age, fresh_height=fresh_height)
    status = VERIFIED if report['status'] == 'VERIFIED' and chain['status'] == VERIFIED else \
        REFUSED if chain['status'] == REFUSED else UNKNOWN
    return {'status': status, 'update': report['status'], 'snapshot_version': report['snapshot_version'], 'snapshot_sha256': digest,
            'release_witness': chain, 'installed': False, 'network_contacted': False, 'execution_authorized': False}


def describe():
    return {'evidence': EVIDENCE, 'slot': SLOT, 'binding': BINDING, 'operation': OPERATION, 'table': TABLE,
            'light_profiles': list(PROFILES), 'policy': witness_journal.CHAIN_POLICY_VERSION + ' chain_witnesses',
            'release_origin': RELEASE_PREFIX + '<repository>', 'statuses': [VERIFIED, UNKNOWN, REFUSED],
            'consensus_change': False, 'network_contacted': False, 'execution_authorized': False}
