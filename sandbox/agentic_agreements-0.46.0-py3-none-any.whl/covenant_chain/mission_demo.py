"""Four actual local validator processes; capacity-backed service and practice lineage.

Scripted parties, not independent operators or autonomous model counterparties.
"""
import argparse,json,socket,subprocess,sys,tempfile,hashlib
from pathlib import Path
from covenant_language.safe_io import atomic_write
from .app import MISSION_VERSION,make_transaction,transaction_id
from .fixtures import fresh_fixture
from .crypto import canonical,digest,sign
from .ecosystem import seed,approve
from .client import Client
from .demo import eventually,read_record,nonce_of
from .proofs import verify_history,assess_service
from .gate import FileGate,LABEL
from covenant_language.practices import PracticeStore,practice,experience,challenge,publish,object_id
ROOT=Path(__file__).resolve().parents[1]

def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);checks=[]
    def check(name,ok=True):
        if not ok:raise AssertionError(name)
        checks.append({'check':name,'passed':True})
    keys,p,g=fresh_fixture(MISSION_VERSION);g['shielded']={};chain=digest('COVENANT-GENESIS',g);procs=[];logs=[]
    with tempfile.TemporaryDirectory(prefix='covenant-mission-') as td:
        d=Path(td);(d/'genesis.json').write_bytes(canonical(g));socks=[socket.socket() for _ in range(4)]
        for sock in socks:sock.bind(('127.0.0.1',0))
        ports=[sock.getsockname()[1] for sock in socks]
        for sock in socks:sock.close()
        peers={f'v{i}':f'http://127.0.0.1:{ports[i]}' for i in range(4)};(d/'peers.json').write_bytes(canonical(peers))
        clients=[Client(peers[f'v{i}']) for i in range(4)]
        memory=PracticeStore(d/'memory.db',[p['owner'],p['worker']])
        try:
            for i in range(4):
                k=d/f'v{i}.key';k.write_text(keys[f'v{i}'].private_bytes_raw().hex());k.chmod(0o600)
                log=open(out/f'validator_{i}.log','wb');logs.append(log)
                procs.append(subprocess.Popen([sys.executable,'-m','covenant_chain.node','--genesis',str(d/'genesis.json'),'--peers',str(d/'peers.json'),'--member',f'v{i}','--key',str(k),'--db',str(d/f'v{i}.journal'),'--port',str(ports[i]),'--base-timeout','0.8'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT))
            eventually(lambda:all(c.status()['consensus_running'] for c in clients), processes=[(f'v{i}', procs[i], logs[i].name) for i in range(4)]);check('four native 0.6 validators started')
            def submit(who,op,payload):
                tx=make_transaction(keys[who],chain,nonce_of(clients[0],p[who]),op,payload,protocol=MISSION_VERSION)
                clients[0].submit(tx);tid=transaction_id(tx);clients[0].wait(tid,45);return tid
            def signed(op,payload,names):
                payload['approvals']=[approve(keys[n],chain,op,payload) for n in names];return payload
            w=submit('owner','WORLD_CREATE',signed('WORLD_CREATE',dict(seed=seed('materials-consortium',[p['owner']],1,'a'*64),approvals=[]),['owner']))
            submit('owner','WORLD_FUND',dict(world=w,resource='compute',quantity=30))
            scope={'service':'material-assay','unit':'sample','environment':'sandbox'}
            base=practice('sampling-v1',scope,{'sampling':'one aliquot','resolution':'appointed independent judge'})
            ref=memory.add(publish(keys['owner'],base));submit('owner','PRACTICE_ANCHOR',dict(reference=ref,parent=None,scope=object_id(scope)))
            cap=submit('worker','REGISTER_RESOURCE',dict(unit='assay-slot',quantity=2))
            offer=submit('worker','SERVICE_OFFER',dict(capability='assay',capacity_resource=cap,capacity_mode='CONSUME_DELIVERED',settlement_resource='compute',unit_price=3,expiry=10000,terms='b'*64,practice=ref))
            payload=dict(world=w,revision=read_record(clients[0],'worlds',w)['revision'],offer=offer,units=2,resolver=p['resolver'],appeal_resolver=p['appeal'],deadline=10000,challenge_blocks=3,appeal_blocks=10,uncertainty='REFUND',approvals=[])
            job=submit('owner','SERVICE_BOOK',signed('SERVICE_BOOK',payload,['owner','worker','resolver','appeal']))
            check('both parties and judges accepted and two capacities reserved',read_record(clients[0],'balances',p['worker'])[cap]==0)
            submit('resolver','SERVICE_DECIDE',dict(job=job,outcome='SUPPORTED',units=2,evidence='c'*64))
            submit('owner','SERVICE_CHALLENGE',dict(job=job,evidence='d'*64))
            submit('appeal','SERVICE_APPEAL',dict(job=job,outcome='SUPPORTED',units=1,evidence='e'*64))
            submit('stranger','SERVICE_SETTLE',dict(job=job))
            check('one sample paid and consumed, remainder refunded',read_record(clients[0],'balances',w)['compute']==27 and read_record(clients[0],'consumed',cap)==1 and read_record(clients[0],'balances',p['worker'])[cap]==1)
            reported=memory.add(publish(keys['owner'],experience(ref,{'accepted':1,'rejected':1},{'lesson':'sampling missed contamination'},evidence=[{'profile':MISSION_VERSION,'id':job}])))
            improved=practice('sampling-v2-bespoke',scope,{'sampling':'three aliquots','resolution':'appointed independent judge'},parents=[ref],constraints={'applicability':'volatile materials only'})
            successor=memory.add(publish(keys['worker'],improved));memory.add(publish(keys['owner'],challenge(reported,'single-source outcome; reproduce independently',proposed_successor=successor)))
            submit('worker','PRACTICE_ANCHOR',dict(reference=successor,parent=ref,scope=object_id(scope)))
            check('learning preserves original adopted job version',read_record(clients[0],'service_jobs',job)['practice']==ref)
            replica=PracticeStore(d/'replica.db',[p['owner'],p['worker']]);replica.import_packet(memory.export());check('shared memory reconstructs without registry owner',replica.export()==memory.export());replica.close()
            def history():
                height=clients[0].status()['applied_height'];entries=[]
                while len(entries)<height:entries.extend(clients[0].blocks(len(entries)+1))
                return entries[:height]
            content=b'Capacity-backed archival artifact\n';content_hash=hashlib.sha256(content).hexdigest()
            fileoffer=submit('worker','SERVICE_OFFER',dict(capability='file.publish',capacity_resource=cap,capacity_mode='RELEASE',settlement_resource='compute',unit_price=1,expiry=10000,terms=content_hash,practice=successor))
            payload=dict(world=w,revision=read_record(clients[0],'worlds',w)['revision'],offer=fileoffer,units=1,resolver=p['resolver'],appeal_resolver=None,deadline=10000,challenge_blocks=0,appeal_blocks=10,uncertainty='REFUND',approvals=[])
            filejob=submit('owner','SERVICE_BOOK',signed('SERVICE_BOOK',payload,['owner','worker','resolver']))
            fh=history();assessment=assess_service(filejob,verify_history(g,fh,chain,len(fh)))
            check('portable assessment separates ledger capacity from world fact',assessment['capacity_reserved']==1 and assessment['physical_capacity']=='NOT_ESTABLISHED')
            gate=FileGate(d/'files',g,chain,len(fh));signature=sign(keys['worker'],LABEL,{'chain':chain,'job':filejob,'content':content_hash})
            try:
                receipt=gate.execute(fh,filejob,content,signature)
                again=gate.execute(fh,filejob,content,signature)
                check('native 0.6 file gate produces one idempotent artifact',again['result']=='ALREADY_DONE')
                try:gate.execute(fh,filejob,b'changed',signature)
                except ValueError:check('native 0.6 file gate refuses changed content')
                else:raise AssertionError('gate accepted changed content')
            finally:gate.close()
            submit('resolver','SERVICE_DECIDE',dict(job=filejob,outcome='SUPPORTED',units=1,evidence=receipt['content']))
            submit('stranger','SERVICE_SETTLE',dict(job=filejob))
            height=clients[0].status()['applied_height'];entries=[]
            while len(entries)<height:entries.extend(clients[0].blocks(len(entries)+1))
            entries=entries[:height];verified=verify_history(g,entries,chain,height)
            check('independent certified replay reconstructs service and lineage',verified['state']['service_jobs'][job]['practice']==ref)
            atomic_write(out/'genesis.json',canonical(g));atomic_write(out/'history.json',canonical(entries));atomic_write(out/'shared-memory.json',canonical(memory.export()))
            result={'protocol':MISSION_VERSION,'validators':4,'party_kind':'scripted clients with fresh keys','checks':checks,'height':height,'state_root':verified['state_root'],'limits':'One local host; reported physical outcomes; no Internet operator diversity.'}
            atomic_write(out/'results.json',json.dumps(result,indent=2));return result
        finally:
            memory.close()
            for proc in procs:proc.terminate()
            for proc in procs:
                try:proc.wait(timeout=5)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
            for log in logs:log.close()
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='reports/mission_0_14');args=parser.parse_args();print(json.dumps(run(args.out),indent=2))
