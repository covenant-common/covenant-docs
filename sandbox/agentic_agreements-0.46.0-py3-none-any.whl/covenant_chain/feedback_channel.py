"""Agent-callable feedback to one operator-adopted inbox, never arbitrary mail."""
from .crypto import need,loads,canonical
from .workflow_store import identifier
from .feedback import report,owner_id,validate
from .workflow import REQUEST


class FeedbackChannel:
    def __init__(self,desk,reporter,recipient=None):
        self.desk,self.reporter,self.recipient=desk,reporter,recipient
        desk.db.execute('CREATE TABLE IF NOT EXISTS channel_requests(id TEXT PRIMARY KEY,input TEXT NOT NULL,envelope BLOB NOT NULL)')
        desk.db.commit()
    def describe(self):
        return dict(domain=self.desk.domain,owner=owner_id(self.desk.owner),
                    destination='LOCAL_OWNER_INBOX',content='CONFIDENTIAL' if self.recipient else 'LOCAL_PLAINTEXT',
                    automatic_governance=False,automatic_reward=False)
    def send(self,request,category,scope,content,related=()):
        need(type(request) is str and REQUEST.fullmatch(request),'FEEDBACK_REQUEST')
        nonce=identifier('COVENANT-FEEDBACK-REQUEST-0.1',dict(domain=self.desk.domain,
                         owner=owner_id(self.desk.owner),request=request))
        value=dict(category=category,scope=scope,content=content,related=list(related))
        input_hash=identifier('COVENANT-FEEDBACK-INPUT-0.1',value)
        db=self.desk.db;db.execute('BEGIN IMMEDIATE')
        try:
            row=db.execute('SELECT input,envelope FROM channel_requests WHERE id=?',(nonce,)).fetchone()
            if row:
                need(row[0]==input_hash,'FEEDBACK_REQUEST_CHANGED');envelope=loads(row[1])
            else:
                count,size=db.execute('SELECT count(*),coalesce(sum(length(envelope)),0) FROM channel_requests').fetchone()
                need(count<self.desk.max_events,'FEEDBACK_CAPACITY')
                envelope=report(self.reporter,self.desk.domain,self.desk.owner,category,scope,content,related,self.recipient,nonce)
                validate(envelope,self.desk.domain,self.desk.owner)
                raw=canonical(envelope)
                need(size+len(raw)<=self.desk.max_bytes,'FEEDBACK_BYTE_CAPACITY')
                # Bind retries privately; never publish a guessable input hash.
                db.execute('INSERT INTO channel_requests VALUES (?,?,?)',(nonce,input_hash,raw))
            db.commit()
        except BaseException:db.rollback();raise
        result=self.desk.append(envelope)
        return dict(**result,status='STORED_IN_LOCAL_OWNER_INBOX',externally_delivered=False)
