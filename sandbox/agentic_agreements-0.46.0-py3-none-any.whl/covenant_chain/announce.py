"""ANNOUNCE_ENDPOINT for covenant-native/0.15.

A host signs a peer record and submits it as a transaction. The record expires
at a block height, and each account may publish only a few times per window.
Older profiles raise UNKNOWN_OPERATION, the same rejection they already use
for an unrecognised op. Validators may publish literal IPs only.
"""
from __future__ import annotations

from .crypto import exact, integer, need
from .discovery import verify_record

WINDOW = 120
LIMIT = 4
MAX_EXPIRE = 43_200


def apply_announce(state, payload, actor, height):
    exact(payload, 'record expire_height')
    integer(height, True)
    integer(payload['expire_height'], True)
    need(height < payload['expire_height'] <= height + MAX_EXPIRE, 'ANNOUNCE_EXPIRY')
    envelope = payload['record']
    body = verify_record(envelope, _record_now(envelope))
    need(body['consensus_key'] == actor, 'ANNOUNCE_SIGNER')
    if actor in state['validator_keys']:
        need(all(item['kind'] == 'ip' for item in body['endpoints']), 'ANNOUNCE_VALIDATOR_IP')
    window = [item for item in state['announce_window'].get(actor, []) if item > height - WINDOW]
    need(len(window) < LIMIT, 'ANNOUNCE_RATE')
    current = state['host_directory'].get(actor)
    if current is not None and body['sequence'] <= current['sequence']:
        raise ValueError('ANNOUNCE_STALE')
    state['announce_window'][actor] = window + [height]
    state['host_directory'][actor] = {
        'record': envelope,
        'expire_height': payload['expire_height'],
        'sequence': body['sequence'],
        'member': body['member'],
    }
    return body['member']


def _record_now(envelope):
    """The record's own expiry is the clock. Consensus does not read the wall time."""
    expiry = envelope['body']['expiry']
    integer(expiry, True)
    return expiry - 1


def live_directory(state, height):
    integer(height, True)
    chosen = {}
    for actor, row in state['host_directory'].items():
        if row['expire_height'] > height:
            chosen[actor] = row
    return chosen
