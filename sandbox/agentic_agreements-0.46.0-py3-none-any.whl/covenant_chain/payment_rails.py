"""Replaceable rail contracts and actual disposable-credit settlement with fees.

The demo rail is local test-credit custody, not a bank, external chain bridge,
token sale, peg or claim that an arbitrary payment receipt is true.
"""
from copy import deepcopy
import hashlib,json
from .crypto import canonical,digest,exact,integer,key,need,verify
from .workflow_store import WorkflowStore
from .adapters import manifest,_instance

FEE_VERSION='covenant-network-fee/0.1'
TOKEN_VERSION='covenant-token-utility/0.1'


def validate_fees(policy):
    exact(policy,'version unit fixed bps minimum maximum beneficiary token')
    need(policy['version']==FEE_VERSION and type(policy['unit']) is str and 0<len(policy['unit'])<=80,'PAYMENT_FEE_POLICY')
    for field in ('fixed','bps','minimum','maximum'):integer(policy[field])
    need(policy['bps']<=10000 and policy['minimum']<=policy['maximum'],'PAYMENT_FEE_POLICY');key(policy['beneficiary'])
    token=policy['token'];exact(token,'version resource discount_bps credit_prices')
    need(token['version']==TOKEN_VERSION and type(token['resource']) is str and 0<len(token['resource'])<=80,'TOKEN_POLICY')
    integer(token['discount_bps']);need(token['discount_bps']<=10000,'TOKEN_POLICY')
    need(type(token['credit_prices']) is dict and len(token['credit_prices'])<=32,'TOKEN_CREDITS')
    for service,price in token['credit_prices'].items():
        need(type(service) is str and 0<len(service)<=80,'TOKEN_CREDITS');integer(price,True)
    canonical(policy);return True


def quote_fee(policy,amount,unit):
    validate_fees(policy);integer(amount)
    need(unit==policy['unit'],'PAYMENT_UNIT_NO_AUTOMATIC_FX')
    base=min(policy['maximum'],max(policy['minimum'],policy['fixed']+(amount*policy['bps']+9999)//10000))
    discount=policy['token']['discount_bps'] if unit==policy['token']['resource'] else 0
    charged=max(policy['minimum'],(base*(10000-discount)+9999)//10000)
    # x402/AP2 settle here. The founder line is the economics.py FOUNDER beneficiary row, not a second fee.
    return {'policy':digest('COVENANT-NETWORK-FEE-0.1',policy),'unit':unit,'amount':charged,'undiscounted':base,
            'token_discount_bps':discount,'beneficiary':policy['beneficiary'],'funding_or_profit':'NOT_ESTABLISHED',
            'holder_yield_or_price_support':'NONE','binding':False,
            'founder_on_principal': 0, 'founder_on_fee': 0,
            'founder_route': 'ECONOMICS_BENEFICIARY_ROW', 'rail': 'REGISTRY'}


def token_benefits(policy):
    validate_fees(policy)
    return {'version':TOKEN_VERSION,'resource':policy['token']['resource'],
            'payment_discount_bps':policy['token']['discount_bps'],
            'discount_scope':'THIS_ADOPTED_POSTED_FEE_SCHEDULE_WHEN_ITS_UNIT_IS_THE_TOKEN',
            'minimum_collected_fee':policy['minimum'],'service_credit_prices':deepcopy(policy['token']['credit_prices']),
            'service_bonding':'EXISTING_NATIVE_FUNDED_SERVICE_BOND_PROFILE_REQUIRES_EXPLICIT_ADOPTION',
            'earnings':'ONLY_ACTUAL_ADOPTED_SERVICE_PAYMENTS_NO_PROMISED_APR',
            'general_access_requires_token':False,'redemption':'LIMITED_BY_ACTUAL_ADAPTER_INVENTORY_AND_EXACT_AUTHORITY',
            'investment_return_or_redemption_peg':'NOT_PROMISED'}


class RailRegistry:
    """Python installation by the owner, never tool-selected imports or URLs."""
    def __init__(self):self.entries={}
    def register(self,adapter):
        ref=digest('COVENANT-RAIL-MANIFEST-0.1',adapter.manifest)
        need(ref not in self.entries and callable(adapter.execute) and callable(adapter.observe),'PAYMENT_RAIL')
        self.entries[ref]=adapter;return ref
    def get(self,ref):
        need(ref in self.entries,'PAYMENT_RAIL_NOT_INSTALLED');adapter=self.entries[ref]
        need(digest('COVENANT-RAIL-MANIFEST-0.1',adapter.manifest)==ref,'PAYMENT_RAIL_CHANGED');return adapter
    def describe(self):return {ref:deepcopy(adapter.manifest) for ref,adapter in self.entries.items()}


class DemoPaymentRail:
    """Exact local balances, fee collection and limited service-credit reservation.

    Install only with owner-specified disposable initial balances/inventory. A
    binding service task must approve the exact payment input or its adopted
    reviewer; the adapter itself does not infer permission from social roles.
    """
    def __init__(self,directory,unit,balances,fee_policy,inventory=None,max_bytes=65536):
        validate_fees(fee_policy);need(fee_policy['unit']==unit,'PAYMENT_UNIT_NO_AUTOMATIC_FX')
        need(type(balances) is dict and len(balances)<=64,'PAYMENT_BALANCES')
        for account,value in balances.items():key(account);integer(value)
        inventory=deepcopy(inventory or {})
        need(type(inventory) is dict and len(inventory)<=32,'PAYMENT_INVENTORY')
        for service,units in inventory.items():
            need(service in fee_policy['token']['credit_prices'],'PAYMENT_INVENTORY');integer(units)
        self.unit=unit;self.policy=deepcopy(fee_policy)
        self.manifest=manifest('disposable-credit-payment-0.1','payment.transfer',effect='LOCAL_DISPOSABLE_CREDIT_LEDGER',
            instance=_instance(directory),max_bytes=max_bytes)
        self.manifest['requirements']['resources']='LOCAL_DISPOSABLE_BALANCES_AND_POSTED_SERVICE_INVENTORY'
        self.manifest['requirements']['fee_policy']=digest('COVENANT-NETWORK-FEE-0.1',fee_policy)
        self.store=WorkflowStore(directory,{'rail':self.manifest,'unit':unit,'initial_balances':balances,'inventory':inventory,'fee_policy':fee_policy})
        self.db=self.store.db
        self.db.execute('CREATE TABLE IF NOT EXISTS rail_balances(account TEXT PRIMARY KEY,amount INTEGER NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS rail_inventory(service TEXT PRIMARY KEY,units INTEGER NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS rail_loans(id TEXT PRIMARY KEY,body BLOB NOT NULL,remaining INTEGER NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS rail_receipts(id TEXT PRIMARY KEY,intent TEXT NOT NULL,body BLOB NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS rail_initialized(id INTEGER PRIMARY KEY CHECK(id=1))')
        for operation in ('UPDATE','DELETE'):
            self.db.execute(f"CREATE TRIGGER IF NOT EXISTS rail_receipts_no_{operation.lower()} BEFORE {operation} ON rail_receipts BEGIN SELECT RAISE(ABORT,'IMMUTABLE_RECEIPT'); END")
        initialized=self.db.execute("SELECT count(*) FROM rail_initialized").fetchone()[0]
        if not initialized:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                self.db.execute('INSERT INTO rail_initialized VALUES (1)')
                for account,amount in balances.items():self.db.execute('INSERT INTO rail_balances VALUES (?,?)',(account,amount))
                for service,units in inventory.items():self.db.execute('INSERT INTO rail_inventory VALUES (?,?)',(service,units))
                self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise

    def execute(self,effect_id,request,*,crash=None):
        need(len(canonical(request))<=self.manifest['max_bytes'],'ADAPTER_INPUT_SIZE')
        key(effect_id);need(type(request) is dict and request.get('action') in {'TRANSFER','REDEEM_CREDIT','OPEN_CREDIT','REPAY_CREDIT'},'PAYMENT_ACTION')
        if request['action']=='TRANSFER':exact(request,'action payer recipient unit amount maximum_fee')
        elif request['action']=='REDEEM_CREDIT':exact(request,'action payer unit service units maximum_fee')
        elif request['action']=='OPEN_CREDIT':exact(request,'action payer unit spec approvals maximum_fee')
        else:exact(request,'action payer unit loan amount maximum_fee')
        key(request['payer']);need(request['unit']==self.unit,'PAYMENT_UNIT_NO_AUTOMATIC_FX');integer(request['maximum_fee'])
        if request['action']=='TRANSFER':
            key(request['recipient']);integer(request['amount'],True);amount=request['amount'];recipient=request['recipient']
        elif request['action']=='OPEN_CREDIT':
            from covenant_language.market_blueprints import inspect as inspect_market
            info=inspect_market(request['spec']);spec=info['spec'];need(spec['kind']=='TERM_CREDIT','CREDIT_KIND')
            need(len(spec['assets'])==1 and not spec['rules']['collateral'],'CREDIT_DEMO_UNSECURED_SINGLE_ASSET_ONLY')
            from .adapters import manifest_id
            asset=spec['assets'][0]
            need(asset['namespace']=='covenant-disposable' and asset['identifier']==self.unit and asset['unit']==self.unit and asset['adapter']==manifest_id(self.manifest),'CREDIT_ASSET_NOT_THIS_RAIL')
            terms=spec['rules'];need(request['payer']==terms['lender'],'CREDIT_LENDER')
            key(terms['lender']);key(terms['borrower'])
            need(type(request['approvals']) is list and len(request['approvals'])==2,'CREDIT_EXACT_PARTY_ASSENT')
            approved=set();body={'rail':manifest_id(self.manifest),'request':{k:v for k,v in request.items() if k!='approvals'}}
            for approval in request['approvals']:
                exact(approval,'party signature');need(approval['party'] in {terms['lender'],terms['borrower']} and approval['party'] not in approved,'CREDIT_EXACT_PARTY_ASSENT')
                verify(approval['party'],'COVENANT-CREDIT-ASSENT-0.1',body,approval['signature']);approved.add(approval['party'])
            amount=terms['principal'];recipient=terms['borrower'];loan_id=info['id'];total_due=info['cashflows']['total_due']
        elif request['action']=='REPAY_CREDIT':
            key(request['loan']);integer(request['amount'],True)
            row=self.db.execute('SELECT body,remaining FROM rail_loans WHERE id=?',(request['loan'],)).fetchone()
            need(row is not None,'CREDIT_LOAN_UNKNOWN');terms=json.loads(row[0])['rules']
            need(request['payer']==terms['borrower'],'CREDIT_BORROWER')
            amount=request['amount'];recipient=terms['lender']
        else:
            integer(request['units'],True);need(request['unit']==self.policy['token']['resource'],'TOKEN_REDEMPTION_UNIT')
            need(request['service'] in self.policy['token']['credit_prices'],'TOKEN_CREDIT_UNKNOWN')
            amount=request['units']*self.policy['token']['credit_prices'][request['service']];integer(amount,True)
            recipient=self.policy['beneficiary']
        fee=quote_fee(self.policy,amount,self.unit);integer(amount+fee['amount']);need(fee['amount']<=request['maximum_fee'],'PAYMENT_FEE_CAP')
        intent=digest('COVENANT-PAYMENT-INTENT-0.1',request)
        with self.store.exclusive():
            self.db.execute('BEGIN IMMEDIATE')
            try:
                old=self.db.execute('SELECT intent FROM rail_receipts WHERE id=?',(effect_id,)).fetchone()
                if old:need(old[0]==intent,'PAYMENT_RETRY_CHANGED')
                else:
                    if request['action']=='OPEN_CREDIT':
                        need(self.db.execute('SELECT id FROM rail_loans WHERE id=?',(loan_id,)).fetchone() is None,'CREDIT_ALREADY_ORIGINATED')
                        self.db.execute('INSERT INTO rail_loans VALUES (?,?,?)',(loan_id,canonical(spec),total_due))
                    elif request['action']=='REPAY_CREDIT':
                        remaining=self.db.execute('SELECT remaining FROM rail_loans WHERE id=?',(request['loan'],)).fetchone()[0]
                        need(amount<=remaining,'CREDIT_OVERPAYMENT')
                        self.db.execute('UPDATE rail_loans SET remaining=remaining-? WHERE id=?',(amount,request['loan']))
                    rows=dict(self.db.execute('SELECT account,amount FROM rail_balances'));before=sum(rows.values())
                    need(rows.get(request['payer'],0)>=amount+fee['amount'],'PAYMENT_FUNDS')
                    rows[request['payer']]-=amount+fee['amount'];rows[recipient]=rows.get(recipient,0)+amount
                    beneficiary=fee['beneficiary'];rows[beneficiary]=rows.get(beneficiary,0)+fee['amount']
                    need(sum(rows.values())==before,'PAYMENT_CONSERVATION')
                    for account,value in rows.items():
                        integer(value);self.db.execute('INSERT INTO rail_balances VALUES (?,?) ON CONFLICT(account) DO UPDATE SET amount=excluded.amount',(account,value))
                    if request['action']=='REDEEM_CREDIT':
                        remaining=self.db.execute('SELECT units FROM rail_inventory WHERE service=?',(request['service'],)).fetchone()
                        need(remaining is not None and remaining[0]>=request['units'],'TOKEN_SERVICE_INVENTORY')
                        self.db.execute('UPDATE rail_inventory SET units=units-? WHERE service=?',(request['units'],request['service']))
                    receipt={'effect':effect_id,'intent':intent,'unit':self.unit,'amount':amount,'network_fee':fee,
                        'payer':request['payer'],'recipient':recipient,'action':request['action'],
                        'loan':loan_id if request['action']=='OPEN_CREDIT' else request.get('loan'),
                        'service_reservation':{'service':request['service'],'units':request['units'],'fulfilled':False} if request['action']=='REDEEM_CREDIT' else None,
                        'assurance':'LOCAL_DISPOSABLE_CREDIT_LEDGER_NOT_EXTERNAL_PAYMENT'}
                    self.db.execute('INSERT INTO rail_receipts VALUES (?,?,?)',(effect_id,intent,canonical(receipt)))
                self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise
        if crash=='after_effect':
            from covenant_language.handoff import InjectedCrash
            raise InjectedCrash('after_effect')
        return self.observe(effect_id)

    def observe(self,effect_id):
        key(effect_id);row=self.db.execute('SELECT body FROM rail_receipts WHERE id=?',(effect_id,)).fetchone()
        if row is None:return {'status':'NOT_OBSERVED','output_hash':None,'assurance':'LOCAL_DISPOSABLE_CREDIT_LEDGER'}
        return {'status':'OBSERVED','output_hash':hashlib.sha256(row[0]).hexdigest(),'value':json.loads(row[0]),'assurance':'LOCAL_DISPOSABLE_CREDIT_LEDGER_NOT_EXTERNAL_PAYMENT'}
    def credit_assent(self,spec,maximum_fee):
        from covenant_language.market_blueprints import inspect as inspect_market
        from .adapters import manifest_id
        integer(maximum_fee);info=inspect_market(spec);need(spec['kind']=='TERM_CREDIT','CREDIT_KIND')
        need(len(spec['assets'])==1 and not spec['rules']['collateral'],'CREDIT_DEMO_UNSECURED_SINGLE_ASSET_ONLY')
        a=spec['assets'][0]
        need(a['namespace']=='covenant-disposable' and a['identifier']==self.unit and a['unit']==self.unit and a['adapter']==manifest_id(self.manifest),'CREDIT_ASSET_NOT_THIS_RAIL')
        key(spec['rules']['lender']);key(spec['rules']['borrower'])
        request={'action':'OPEN_CREDIT','payer':spec['rules']['lender'],'unit':self.unit,'spec':deepcopy(spec),'maximum_fee':maximum_fee,'approvals':[]}
        return {'label':'COVENANT-CREDIT-ASSENT-0.1','body':{'rail':manifest_id(self.manifest),'request':{k:v for k,v in request.items() if k!='approvals'}},
                'required_parties':[spec['rules']['lender'],spec['rules']['borrower']], 'request':request,
                'cashflows':info['cashflows'],'execution_authorized':False}
    def preview(self,request):
        need(len(canonical(request))<=self.manifest['max_bytes'],'ADAPTER_INPUT_SIZE')
        need(type(request) is dict and request.get('unit')==self.unit,'PAYMENT_UNIT_NO_AUTOMATIC_FX')
        key(request['payer']);integer(request['maximum_fee'])
        action=request['action'];cashflows=None;remaining=None;inventory=None
        if action=='OPEN_CREDIT':
            assent=self.credit_assent(request['spec'],request['maximum_fee']);cashflows=assent['cashflows']
            need(request['payer']==request['spec']['rules']['lender'],'CREDIT_LENDER');amount=cashflows['principal_advanced']
        elif action=='REPAY_CREDIT':
            debt=self.credit(request['loan']);need(request['payer']==debt['spec']['rules']['borrower'],'CREDIT_BORROWER')
            integer(request['amount'],True);amount=request['amount'];remaining=debt['remaining'];need(amount<=remaining,'CREDIT_OVERPAYMENT')
        elif action=='TRANSFER':
            integer(request['amount'],True);key(request['recipient']);amount=request['amount']
        elif action=='REDEEM_CREDIT':
            integer(request['units'],True);need(self.unit==self.policy['token']['resource'],'TOKEN_REDEMPTION_UNIT')
            need(request['service'] in self.policy['token']['credit_prices'],'TOKEN_CREDIT_UNKNOWN')
            amount=request['units']*self.policy['token']['credit_prices'][request['service']];integer(amount)
            row=self.db.execute('SELECT units FROM rail_inventory WHERE service=?',(request['service'],)).fetchone()
            inventory=row[0] if row else 0
        else:raise ValueError('PAYMENT_ACTION')
        fee=quote_fee(self.policy,amount,self.unit);integer(amount+fee['amount']);balance=dict(self.db.execute('SELECT account,amount FROM rail_balances')).get(request['payer'],0)
        return {'action':action,'unit':self.unit,'amount':amount,'network_fee':fee,'total_debit':amount+fee['amount'],
            'available_balance_at_local_read':balance,'sufficient_balance_at_local_read':balance>=amount+fee['amount'],
            'within_requested_fee_cap':fee['amount']<=request['maximum_fee'],'remaining_debt':remaining,'service_inventory_at_local_read':inventory,
            'credit_cashflows':cashflows,'funding':'NOT_RESERVED','execution_authorized':False}
    def credit(self,loan,height=None):
        key(loan)
        row=self.db.execute('SELECT body,remaining FROM rail_loans WHERE id=?',(loan,)).fetchone()
        need(row is not None,'CREDIT_LOAN_UNKNOWN')
        spec=json.loads(row[0]);remaining=row[1]
        if height is not None:integer(height)
        return {'loan':loan,'spec':spec,'remaining':remaining,'unit':self.unit,
                'status':'REPAID' if remaining==0 else 'PAST_DUE_AT_ASSERTED_HEIGHT' if height is not None and height>=spec['rules']['due_height'] else 'OUTSTANDING',
                'height_assurance':'CALLER_ASSERTION_NOT_CERTIFIED','collateral':'UNSECURED','execution_authorized':False}
    def close(self):self.store.close()
