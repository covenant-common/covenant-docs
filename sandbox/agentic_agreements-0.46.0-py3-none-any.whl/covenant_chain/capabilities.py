"""Signed host capability descriptors and client-side mode negotiation.

A descriptor extends a covenant-peer-record/1. The host key is that record's
consensus key, the endpoint kinds and the 30-day expiry are the same, and the
signature covers the canonical body under COVENANT-HOST-CAPABILITIES.

This module does not add a consensus operation and does not open a socket.
A validator role still requires a literal-IP endpoint on the linked peer
record. transport.validate_https_peers is unchanged.
"""
from __future__ import annotations

import re

from . import compatibility, discovery
from .crypto import canonical, digest, exact, integer, key, need, sign, verify

VERSION = 'covenant-host-capabilities/1'
LABEL = 'COVENANT-HOST-CAPABILITIES'
MODES = {'HOSTED', 'FEDERATED', 'PEER', 'HYBRID'}
TRANSPORTS = {'https', 'wss', 'quic', 'webrtc', 'onion', 'i2p', 'ble', 'nfc', 'lora'}
NATIVE = {f'covenant-native/0.{i}' for i in range(1, 15)}
LIGHT = {'covenant-native-light/0.1'}
ARCHIVE = {'covenant-native-archive/0.1'}
COURIER = {'covenant-courier/0.1'}
COMMON = {'covenant-common/0.1'}
COMPACT = {'covenant-compact/1'}
RETENTION = {'FULL', 'PARTIAL', 'NONE'}
ERASURE = {'10-of-30', 'NONE'}
KYC = {'NONE', 'OPTIONAL', 'REQUIRED'}
KYC_RANK = {'NONE': 0, 'OPTIONAL': 1, 'REQUIRED': 2}
OPERATIVE = {'export', 'client_verification', 'literal_ip_validators', 'no_plaintext'}
REQUIRED_OPERATIVE = {'export', 'client_verification'}
ROLES = ('gateway', 'validator', 'light_proofs', 'archive', 'relay', 'dht', 'bootstrap', 'arbitration_desk')
COUNTRY = re.compile(r'[A-Z]{2}\Z')
BODY_FIELDS = (
    'v host_key peer_record sequence expiry modes roles protocols transports chains '
    'limits privacy jurisdiction export fees operative'
)
NEED_FIELDS = 'chain native roles transports privacy jurisdiction max_fee_bps operative existing_operators'


def _text_list(values, allowed, code, *, empty_ok, limit):
    need(type(values) is list and (0 if empty_ok else 1) <= len(values) <= limit, code)
    need(all(type(item) is str for item in values), code)
    cleaned = sorted(set(values))
    need(cleaned == values, code)
    for item in cleaned:
        need(item in allowed, code)
    return cleaned


def _country(value, code):
    need(type(value) is str and COUNTRY.fullmatch(value) is not None, code)
    return value


def _roles(roles):
    exact(roles, 'gateway validator light_proofs archive relay dht bootstrap arbitration_desk rails')
    for name in ('gateway', 'validator', 'light_proofs', 'dht', 'bootstrap', 'arbitration_desk'):
        need(type(roles[name]) is bool, 'CAPABILITY_ROLE')
    archive = roles['archive']
    exact(archive, 'retention erasure por')
    need(archive['retention'] in RETENTION and archive['erasure'] in ERASURE, 'CAPABILITY_ARCHIVE')
    need(type(archive['por']) is bool, 'CAPABILITY_ARCHIVE')
    relay = roles['relay']
    exact(relay, 'onion circuit_v2')
    need(type(relay['onion']) is bool and type(relay['circuit_v2']) is bool, 'CAPABILITY_RELAY')
    rails = roles['rails']
    need(type(rails) is list and len(rails) <= 8, 'CAPABILITY_RAILS')
    for item in rails:
        key(item)
    need(len(rails) == len(set(rails)) and rails == sorted(rails), 'CAPABILITY_RAILS')
    return {
        'gateway': roles['gateway'], 'validator': roles['validator'], 'light_proofs': roles['light_proofs'],
        'archive': {'retention': archive['retention'], 'erasure': archive['erasure'], 'por': archive['por']},
        'relay': {'onion': relay['onion'], 'circuit_v2': relay['circuit_v2']},
        'dht': roles['dht'], 'bootstrap': roles['bootstrap'], 'arbitration_desk': roles['arbitration_desk'],
        'rails': list(rails),
    }


def _protocols(protocols):
    exact(protocols, 'native light archive courier common compact')
    return {
        'native': _text_list(protocols['native'], NATIVE, 'CAPABILITY_PROTOCOL', empty_ok=False, limit=14),
        'light': _text_list(protocols['light'], LIGHT, 'CAPABILITY_PROTOCOL', empty_ok=True, limit=4),
        'archive': _text_list(protocols['archive'], ARCHIVE, 'CAPABILITY_PROTOCOL', empty_ok=True, limit=4),
        'courier': _text_list(protocols['courier'], COURIER, 'CAPABILITY_PROTOCOL', empty_ok=True, limit=4),
        'common': _text_list(protocols['common'], COMMON, 'CAPABILITY_PROTOCOL', empty_ok=True, limit=4),
        'compact': _text_list(protocols['compact'], COMPACT, 'CAPABILITY_PROTOCOL', empty_ok=True, limit=4),
    }


def capability_body(host_key, peer_record, sequence, expiry, modes, roles, protocols, transports, chains,
                    limits, privacy, jurisdiction, export, fees, operative):
    key(host_key)
    key(peer_record)
    integer(sequence)
    integer(expiry, True)
    cleaned_modes = _text_list(modes, MODES, 'CAPABILITY_MODE', empty_ok=False, limit=4)
    cleaned_roles = _roles(roles)
    cleaned_protocols = _protocols(protocols)
    cleaned_transports = _text_list(transports, TRANSPORTS, 'CAPABILITY_TRANSPORT', empty_ok=False, limit=len(TRANSPORTS))
    need(type(chains) is list and 1 <= len(chains) <= 8, 'CAPABILITY_CHAIN')
    for chain in chains:
        key(chain)
    need(chains == sorted(set(chains)), 'CAPABILITY_CHAIN')
    exact(limits, 'msg_per_s bytes_per_s max_tx_bytes')
    integer(limits['msg_per_s'], True)
    integer(limits['bytes_per_s'], True)
    integer(limits['max_tx_bytes'], True)
    need(limits['msg_per_s'] <= 4096 and limits['bytes_per_s'] <= 16_777_216 and limits['max_tx_bytes'] <= 1_048_576, 'CAPABILITY_LIMIT')
    exact(privacy, 'sees_plaintext logs_ip_days e2e_required')
    need(type(privacy['sees_plaintext']) is bool and type(privacy['e2e_required']) is bool, 'CAPABILITY_PRIVACY')
    integer(privacy['logs_ip_days'])
    need(privacy['logs_ip_days'] <= 3650, 'CAPABILITY_PRIVACY')
    exact(jurisdiction, 'country kyc data_residency')
    need(jurisdiction['kyc'] in KYC, 'CAPABILITY_JURISDICTION')
    exact(export, 'bundle endpoint')
    need(export['bundle'] == 'covenant-portable-bundle/1' and export['endpoint'] == '/export', 'CAPABILITY_EXPORT')
    exact(fees, 'service_fee_bps protocol_fee')
    integer(fees['service_fee_bps'])
    need(fees['service_fee_bps'] <= 10000 and fees['protocol_fee'] == 'economics.charge', 'CAPABILITY_FEE')
    cleaned_operative = _text_list(operative, OPERATIVE, 'CAPABILITY_OPERATIVE', empty_ok=False, limit=len(OPERATIVE))
    need(REQUIRED_OPERATIVE <= set(cleaned_operative), 'CAPABILITY_EXPORT')
    if 'literal_ip_validators' in cleaned_operative:
        need(cleaned_roles['validator'] is True, 'CAPABILITY_OPERATIVE')
    if 'no_plaintext' in cleaned_operative:
        need(privacy['sees_plaintext'] is False and privacy['e2e_required'] is True, 'CAPABILITY_PRIVACY')
    body = {
        'v': VERSION,
        'host_key': host_key,
        'peer_record': peer_record,
        'sequence': sequence,
        'expiry': expiry,
        'modes': cleaned_modes,
        'roles': cleaned_roles,
        'protocols': cleaned_protocols,
        'transports': cleaned_transports,
        'chains': list(chains),
        'limits': {
            'msg_per_s': limits['msg_per_s'],
            'bytes_per_s': limits['bytes_per_s'],
            'max_tx_bytes': limits['max_tx_bytes'],
        },
        'privacy': {
            'sees_plaintext': privacy['sees_plaintext'],
            'logs_ip_days': privacy['logs_ip_days'],
            'e2e_required': privacy['e2e_required'],
        },
        'jurisdiction': {
            'country': _country(jurisdiction['country'], 'CAPABILITY_JURISDICTION'),
            'kyc': jurisdiction['kyc'],
            'data_residency': _country(jurisdiction['data_residency'], 'CAPABILITY_JURISDICTION'),
        },
        'export': {'bundle': export['bundle'], 'endpoint': export['endpoint']},
        'fees': {'service_fee_bps': fees['service_fee_bps'], 'protocol_fee': fees['protocol_fee']},
        'operative': cleaned_operative,
    }
    canonical(body)
    return body


def sign_capability(private_key, body, peer_envelope):
    from .crypto import public_key
    exact(body, BODY_FIELDS)
    exact(peer_envelope, 'body signature')
    need(public_key(private_key) == body['host_key'], 'CAPABILITY_SIGNER')
    need(peer_envelope['body']['consensus_key'] == body['host_key'], 'CAPABILITY_HOST_KEY')
    need(discovery.record_id(peer_envelope['body']) == body['peer_record'], 'CAPABILITY_PEER')
    return {'body': body, 'signature': sign(private_key, LABEL, body), 'peer': peer_envelope}


def descriptor_id(body):
    exact(body, BODY_FIELDS)
    need(body['v'] == VERSION, 'CAPABILITY_VERSION')
    return digest(LABEL, body)


def verify_capability(envelope, now):
    exact(envelope, 'body signature peer')
    peer = discovery.verify_record(envelope['peer'], now)
    body = envelope['body']
    exact(body, BODY_FIELDS)
    need(body['v'] == VERSION, 'CAPABILITY_VERSION')
    cleaned = capability_body(
        body['host_key'], body['peer_record'], body['sequence'], body['expiry'], body['modes'], body['roles'],
        body['protocols'], body['transports'], body['chains'], body['limits'], body['privacy'], body['jurisdiction'],
        body['export'], body['fees'], body['operative'],
    )
    need(cleaned == body, 'CAPABILITY_CANONICAL')
    need(body['host_key'] == peer['consensus_key'], 'CAPABILITY_HOST_KEY')
    need(body['peer_record'] == discovery.record_id(peer), 'CAPABILITY_PEER')
    need(body['expiry'] == peer['expiry'], 'CAPABILITY_EXPIRY')
    if body['roles']['validator'] and not any(item['kind'] == 'ip' for item in peer['endpoints']):
        raise ValueError('VALIDATOR_LITERAL_IP')
    verify(body['host_key'], LABEL, body, envelope['signature'])
    return body


def _role_offered(roles, name):
    if name == 'archive':
        return roles['archive']['retention'] != 'NONE'
    if name == 'relay':
        return roles['relay']['onion'] or roles['relay']['circuit_v2']
    return roles[name] is True


def host_score(roles_matched, transports_matched, serving_rep_bps, service_fee_bps, same_operator):
    """Illustrative integer from the hosting spec. Higher is a better carrier."""
    integer(roles_matched)
    integer(transports_matched)
    integer(serving_rep_bps)
    integer(service_fee_bps)
    need(same_operator in (0, 1), 'CAPABILITY_SCORE')
    need(serving_rep_bps <= 10000 and service_fee_bps <= 10000, 'CAPABILITY_SCORE')
    return 4 * roles_matched + 2 * transports_matched + serving_rep_bps // 1000 - service_fee_bps // 100 - 8 * same_operator


def _need(need_doc):
    exact(need_doc, NEED_FIELDS)
    key(need_doc['chain'])
    need(need_doc['native'] in NATIVE, 'CAPABILITY_PROTOCOL')
    roles = _text_list(need_doc['roles'], set(ROLES), 'CAPABILITY_ROLE', empty_ok=True, limit=len(ROLES))
    transports = _text_list(need_doc['transports'], TRANSPORTS, 'CAPABILITY_TRANSPORT', empty_ok=False, limit=len(TRANSPORTS))
    exact(need_doc['privacy'], 'e2e_required')
    need(type(need_doc['privacy']['e2e_required']) is bool, 'CAPABILITY_PRIVACY')
    exact(need_doc['jurisdiction'], 'countries kyc_max')
    countries = need_doc['jurisdiction']['countries']
    need(type(countries) is list and len(countries) <= 32, 'CAPABILITY_JURISDICTION')
    for country in countries:
        _country(country, 'CAPABILITY_JURISDICTION')
    need(countries == sorted(set(countries)), 'CAPABILITY_JURISDICTION')
    need(need_doc['jurisdiction']['kyc_max'] in KYC, 'CAPABILITY_JURISDICTION')
    integer(need_doc['max_fee_bps'])
    need(need_doc['max_fee_bps'] <= 10000, 'CAPABILITY_FEE')
    operative = need_doc['operative']
    need(type(operative) is list and len(operative) <= len(OPERATIVE) + 4 and all(type(item) is str and 1 <= len(item) <= 64 for item in operative), 'CAPABILITY_OPERATIVE')
    need(operative == sorted(set(operative)), 'CAPABILITY_OPERATIVE')
    existing = need_doc['existing_operators']
    need(type(existing) is list and len(existing) <= 64, 'CAPABILITY_OPERATOR')
    for operator in existing:
        need(type(operator) is str and 1 <= len(operator) <= 80 and all(33 <= ord(c) <= 126 for c in operator), 'CAPABILITY_OPERATOR')
    need(len(existing) == len(set(existing)), 'CAPABILITY_OPERATOR')
    return need_doc


def _unknown_operative(names):
    """Unknown operative requirements fail closed, same rule as compatibility.negotiate."""
    unknown = [name for name in names if name not in OPERATIVE]
    if not unknown:
        return []
    report = compatibility.negotiate(
        {name: ['required'] for name in unknown},
        [{'id': 'probe', 'capabilities': {}, 'irreversible': False}],
    )
    candidate = report['candidates'][0]
    if candidate['compatible'] or report['automatic_selection'] or report['execution_authorized']:
        raise ValueError('NEGOTIATION_FAIL_OPEN')
    return sorted(candidate['missing'])


def negotiate(need_doc, offers, now):
    """Rank verified descriptors. Selection stays with the client."""
    cleaned_need = _need(need_doc)
    need(type(offers) is list and 1 <= len(offers) <= 32, 'CAPABILITY_OFFERS')
    unknown = _unknown_operative(cleaned_need['operative'])
    rows = []
    for offer in offers:
        exact(offer, 'envelope operator serving_rep_bps')
        operator = offer['operator']
        need(type(operator) is str and 1 <= len(operator) <= 80 and all(33 <= ord(c) <= 126 for c in operator), 'CAPABILITY_OPERATOR')
        integer(offer['serving_rep_bps'])
        need(offer['serving_rep_bps'] <= 10000, 'CAPABILITY_SCORE')
        try:
            body = verify_capability(offer['envelope'], now)
        except (discovery.DiscoveryError, ValueError) as exc:
            rows.append({'host_key': None, 'operator': operator, 'compatible': False, 'reasons': [str(exc)], 'score': None})
            continue
        reasons = []
        if unknown:
            reasons.append('UNKNOWN_OPERATIVE')
        if cleaned_need['chain'] not in body['chains']:
            reasons.append('CHAIN')
        if cleaned_need['native'] not in body['protocols']['native']:
            reasons.append('NATIVE')
        missing = [name for name in cleaned_need['operative'] if name not in body['operative'] or name not in OPERATIVE]
        if missing:
            reasons.append('OPERATIVE')
        if cleaned_need['privacy']['e2e_required'] and body['privacy']['sees_plaintext']:
            reasons.append('PRIVACY_FLOOR')
        countries = cleaned_need['jurisdiction']['countries']
        if countries and body['jurisdiction']['country'] not in countries:
            reasons.append('JURISDICTION')
        if KYC_RANK[body['jurisdiction']['kyc']] > KYC_RANK[cleaned_need['jurisdiction']['kyc_max']]:
            reasons.append('JURISDICTION')
        if body['fees']['service_fee_bps'] > cleaned_need['max_fee_bps']:
            reasons.append('FEE')
        roles_matched = sum(1 for name in cleaned_need['roles'] if _role_offered(body['roles'], name))
        transports_matched = sum(1 for name in cleaned_need['transports'] if name in body['transports'])
        same = 1 if operator in cleaned_need['existing_operators'] else 0
        scored = host_score(roles_matched, transports_matched, offer['serving_rep_bps'], body['fees']['service_fee_bps'], same)
        rows.append({
            'host_key': body['host_key'],
            'operator': operator,
            'compatible': not reasons,
            'reasons': reasons,
            'score': scored,
            'roles_matched': roles_matched,
            'transports_matched': transports_matched,
            'same_operator': same,
        })
    ranked = sorted((row for row in rows if row['compatible']), key=lambda row: (-row['score'], row['host_key']))
    return {
        'version': VERSION,
        'ranked': ranked,
        'rejected': [row for row in rows if not row['compatible']],
        'compatible': [row['host_key'] for row in ranked],
        'automatic_selection': False,
        'trust_changed': False,
        'execution_authorized': False,
        'cross_check': cross_check(ranked),
    }


def cross_check(ranked):
    """A read that matters uses two hosts whose operators differ."""
    need(type(ranked) is list, 'CAPABILITY_OFFERS')
    operators = []
    hosts = []
    for row in ranked:
        exact(row, 'host_key operator compatible reasons score roles_matched transports_matched same_operator')
        if not row['compatible'] or row['operator'] in operators:
            continue
        operators.append(row['operator'])
        hosts.append(row['host_key'])
        if len(hosts) == 2:
            break
    return {'ok': len(hosts) >= 2, 'hosts': hosts, 'operators': len(set(operators)), 'automatic_selection': False}
