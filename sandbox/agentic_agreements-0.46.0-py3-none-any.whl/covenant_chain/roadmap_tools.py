"""Keyless inspection of explicitly versioned open interoperability profiles."""
from .cooperation_interface import HASH, OBJECT, TEXT, INT


def spec():
    return ('covenant_interoperate',
        'Draft an explicit open-rail /0.3 work order, inspect supplied assents, bind a proposed payment leg, resolve pinned URN aliases, or verify a signed card against caller-selected keys. No signing, execution, payment, fetching, installation or publication. Caller trust pins are inputs, not independently authenticated authority.', True, [
        ('catalog', {}, ()),
        ('resolve', {'identifier': TEXT, 'expected_registry': HASH}, ('identifier', 'expected_registry')),
        ('rail', {'identifier': TEXT, 'network': TEXT, 'asset': TEXT, 'unit': TEXT, 'payee': TEXT,
                  'adapter': HASH, 'instructions': {}}, ('identifier', 'network', 'asset', 'unit', 'payee')),
        ('draft', {'task': {'type': 'string', 'minLength': 1, 'maxLength': 16000}, 'customer': HASH,
                   'provider': HASH, 'quantity': INT, 'payment': OBJECT, 'nonce': HASH,
                   'deadline': INT, 'context': {}}, ('task', 'customer', 'provider', 'quantity', 'payment', 'nonce', 'deadline')),
        ('inspect', {'order': OBJECT, 'expected_id': HASH}, ('order', 'expected_id')),
        ('payment_link', {'order': OBJECT, 'expected_id': HASH, 'mechanism': TEXT, 'external_body': {}},
                        ('order', 'expected_id', 'mechanism', 'external_body')),
        ('verify_card', {'card': OBJECT, 'trusted_keys': OBJECT, 'now': INT, 'expected_id': HASH}, ('card', 'trusted_keys', 'now')),
        ('server_card', {'name': TEXT, 'version': TEXT, 'endpoints': {'type': 'array', 'maxItems': 16, 'items': TEXT},
                         'tools_pin': HASH, 'protocols': {'type': 'array', 'maxItems': 16, 'items': TEXT}},
                        ('name', 'version', 'endpoints', 'tools_pin'))])


def call(action, parameters):
    from covenant_agent import open_work, signed_cards, protocol_identifiers
    actions = {'catalog': protocol_identifiers.catalog, 'resolve': protocol_identifiers.resolve,
               'rail': open_work.rail, 'draft': open_work.draft, 'inspect': open_work.inspect,
               'payment_link': open_work.payment_link, 'verify_card': signed_cards.verify_card,
               'server_card': signed_cards.mcp_server_card}
    if action not in actions:
        raise ValueError('INTEROPERATE_ACTION')
    return actions[action](**parameters)
