"""A2A agent cards as carriers of AAP signed-discovery descriptors.

An A2A 1.0 AgentCard (a2aproject/A2A v1.0.1, specification section 4.4) can
carry an AAP descriptor in one ``capabilities.extensions`` entry whose ``uri``
is :data:`EXTENSION_URI`:

* carrier form: ``params`` holds ``descriptor`` (the body) and ``signature``
  (the AAP Ed25519 signature); the descriptor signature counts, the card adds
  availability only, exactly like any other carrier.
* signed-card form: ``params`` holds only ``descriptor`` and the card itself is
  signed (specification section 8.4) with a JWS (RFC 7515) whose ``alg`` is
  ``EdDSA`` (RFC 8037 section 3.1) by the very key the descriptor names. The
  payload is the RFC 8785 canonical form of the card without ``signatures``
  (section 8.4.1); the JWS is detached (RFC 7515 Appendix F). A card signature by
  any other key is transport metadata and authenticates nothing.

Cards with empty strings, lists or objects are refused for signing and for
signed-card verification: section 8.4.1 removes default values before
canonicalisation and implementations disagree on which (A2A issue 2122), so an
AAP card never contains one. Nothing is fetched; cards and keys are data.
"""
from copy import deepcopy

from .crypto import need
from . import interop_codec as codec
from . import signed_discovery as discovery

VERSION = 'covenant-a2a-discovery/0.1'
EXTENSION_URI = ('https://github.com/covenant-common/covenant/blob/release/0.15-rc/docs/'
                 'IDENTITY_DISCOVERY.html#covenant-signed-discovery-0.1')
PROTOCOL_VERSION = '1.0'
WELL_KNOWN_PATH = '/.well-known/agent-card.json'
KID_PREFIX = 'urn:ietf:params:oauth:jwk-thumbprint:sha-256:'
MAX_CARD = 65536
MAX_SIGNATURES = 8
HEADER_NAMES = {'alg', 'kid', 'typ', 'jku'}

REMEDIATION = {
    'A2A_DISCOVERY_CARD': 'Supply one A2A AgentCard JSON object within 64 KiB.',
    'A2A_DISCOVERY_EXTENSION': 'Carry the descriptor in one capabilities.extensions entry with the AAP uri and params.descriptor.',
    'A2A_DISCOVERY_NORMALIZATION': 'Omit empty strings, lists and objects; signed cards are canonicalised without defaults.',
    'A2A_DISCOVERY_JWS': 'Sign the card with a JWS whose protected header has alg EdDSA, kid and typ JOSE.',
    'A2A_DISCOVERY_SIGNATURE': 'No card signature verifies under the key the descriptor names.',
    'A2A_DISCOVERY_INTERFACE': 'The descriptor needs at least one a2a endpoint to publish a card.',
    'DISCOVERY_SOURCE': 'The A2A discovery source is not {source, card} with an optional https origin and nothing else. Pass the agent card text in card.',
    'DISCOVERY_SIZE': 'The agent card is not text or is longer than 65536 characters. Pass the card JSON as text within that size.',
}


def remediation(code):
    return REMEDIATION.get(code, discovery.remediation(code))


def _normalized(value):
    pending = [value]
    while pending:
        item = pending.pop()
        if type(item) in (str, list, dict):
            need(len(item) > 0, 'A2A_DISCOVERY_NORMALIZATION')
        if type(item) is dict:
            pending.extend(item.values())
        elif type(item) is list:
            pending.extend(item)


def payload(card):
    """RFC 8785 bytes of the card without ``signatures`` (A2A section 8.4.1)."""
    need(type(card) is dict, 'A2A_DISCOVERY_CARD')
    unsigned = {name: value for name, value in card.items() if name != 'signatures'}
    _normalized(unsigned)
    return codec.jcs(unsigned, MAX_CARD)


def kid(public_hex):
    """RFC 9278 JWK Thumbprint URI of the AAP key (RFC 7638 SHA-256 thumbprint of its OKP JWK)."""
    return KID_PREFIX + codec.jwk_thumbprint(public_hex)


def protected_header(public_hex):
    return codec.b64url(codec.jcs({'alg': 'EdDSA', 'kid': kid(public_hex), 'typ': 'JOSE'}))


def signing_input(card, public_hex):
    """The exact ASCII bytes the key signs: BASE64URL(header) '.' BASE64URL(payload)."""
    return (protected_header(public_hex) + '.' + codec.b64url(payload(card))).encode('ascii')


def sign_card(card, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    public_hex = codec.owner_key(private_key)
    need('signatures' not in card, 'A2A_DISCOVERY_JWS')
    signature = private_key.sign(signing_input(card, public_hex))
    return {**deepcopy(card), 'signatures': [{'protected': protected_header(public_hex), 'signature': codec.b64url(signature)}]}


def verify_card(card, public_hex):
    """Index of the first card signature made by ``public_hex`` with EdDSA; refuses otherwise."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    rows = card.get('signatures') if type(card) is dict else None
    need(type(rows) is list and 0 < len(rows) <= MAX_SIGNATURES, 'A2A_DISCOVERY_JWS')
    body = codec.b64url(payload(card))
    verifier = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex))
    for index, row in enumerate(rows):
        if type(row) is not dict or not {'protected', 'signature'} <= set(row) <= {'protected', 'signature', 'header'}:
            continue
        try:
            header = codec.parse(codec.b64url_decode(row['protected'], 2048), 2048, 4, 32)
            signature = codec.b64url_decode(row['signature'], 128)
        except ValueError:
            continue
        if type(header) is not dict or header.get('alg') != 'EdDSA' or not set(header) <= HEADER_NAMES \
                or type(header.get('kid')) is not str or header.get('typ', 'JOSE') not in ('JOSE', 'JWT') or len(signature) != 64:
            continue
        try:
            verifier.verify(signature, (row['protected'] + '.' + body).encode('ascii'))
        except InvalidSignature:
            continue
        return index
    raise ValueError('A2A_DISCOVERY_SIGNATURE')


def _extensions(card):
    capabilities = card.get('capabilities')
    need(type(capabilities) is dict, 'A2A_DISCOVERY_CARD')
    rows = capabilities.get('extensions', [])
    need(type(rows) is list and len(rows) <= 64, 'A2A_DISCOVERY_CARD')
    return [row for row in rows if type(row) is dict and row.get('uri') == EXTENSION_URI]


def extract(card):
    """Descriptor items carried by one parsed card: envelopes, or bodies its own JWS authenticates."""
    need(type(card) is dict and type(card.get('name')) is str, 'A2A_DISCOVERY_CARD')
    rows = _extensions(card)
    need(len(rows) == 1 and type(rows[0].get('params')) is dict and type(rows[0]['params'].get('descriptor')) is dict
         and set(rows[0]['params']) <= {'descriptor', 'signature'}, 'A2A_DISCOVERY_EXTENSION')
    params = rows[0]['params']
    body = codec.integral(params['descriptor'])
    if 'signature' in params:
        return [{'body': body, 'signature': params['signature']}]
    need(type(body.get('key')) is str and len(body['key']) == 64, 'A2A_DISCOVERY_EXTENSION')
    verify_card(card, body['key'])
    return [discovery.attested(body, 'A2A_CARD_JWS_EDDSA', body['key'])]


def source(item):
    """Signed-discovery adapter for {'source': 'A2A_CARD', 'card': text[, 'origin': https origin]}."""
    need(type(item) is dict and {'source', 'card'} <= set(item) <= {'source', 'card', 'origin'}, 'DISCOVERY_SOURCE')
    need(type(item['card']) is str and len(item['card']) <= MAX_CARD, 'DISCOVERY_SIZE')
    try:
        card = codec.parse(item['card'], MAX_CARD, 24, 8192)
    except ValueError:
        raise ValueError('A2A_DISCOVERY_CARD') from None
    locator = (discovery._origin(item['origin']) + WELL_KNOWN_PATH) if 'origin' in item else 'a2a-card'
    return extract(card), {'locator': locator}, [], []


def card(envelope, *, signed=True, provider=None, documentation_url=None):
    """An A2A 1.0 AgentCard advertising an AAP descriptor.

    ``signed`` True keeps only the descriptor body in the extension, so the card
    must then be signed by the descriptor key (``signing_input``); False carries
    the AAP envelope and needs no card signature.
    """
    opened = discovery.open_descriptor(envelope)
    body = opened['body']
    interfaces = [{'url': row['uri'], 'protocolBinding': 'JSONRPC', 'protocolVersion': PROTOCOL_VERSION}
                  for row in body['endpoints'] if row['transport'] == 'a2a']
    need(bool(interfaces), 'A2A_DISCOVERY_INTERFACE')
    params = {'descriptor': deepcopy(body)} if signed else {'descriptor': deepcopy(body), 'signature': envelope['signature']}
    result = {
        'name': body['name'], 'description': body['summary'] or body['name'], 'supportedInterfaces': interfaces,
        'version': str(body['sequence']),
        'capabilities': {'extensions': [{'uri': EXTENSION_URI, 'required': False, 'params': params,
                                         'description': 'AAP covenant-signed-discovery/0.1 descriptor signed by the agent key'}]},
        'defaultInputModes': ['application/json'], 'defaultOutputModes': ['application/json'],
        'skills': [{'id': name, 'name': name, 'description': 'AAP task class ' + name, 'tags': [name]}
                   for name in body['task_classes']],
    }
    if provider is not None:
        need(type(provider) is dict and set(provider) == {'organization', 'url'}, 'A2A_DISCOVERY_CARD')
        result['provider'] = deepcopy(provider)
    if documentation_url is not None:
        result['documentationUrl'] = documentation_url
    payload(result)
    return {'card': result, 'descriptor': opened['id'], 'mode': 'SIGNED_CARD' if signed else 'CARRIER',
            'protected': protected_header(body['key']) if signed else None,
            'signing_input': signing_input(result, body['key']).decode('ascii') if signed else None,
            'required_signers': [body['key']] if signed else [], 'signature_created': False,
            'well_known_path': WELL_KNOWN_PATH, 'publication': 'OWNER_PUBLISHES', 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_ADAPTER', 'extension_uri': EXTENSION_URI,
            'a2a': 'A2A 1.0 AgentCard, specification sections 4.4 and 8.4', 'jws': 'RFC7515_DETACHED_RFC8037_EDDSA',
            'canonical': 'RFC8785_WITHOUT_SIGNATURES_NO_EMPTY_VALUES', 'kid': 'RFC9278_JWK_THUMBPRINT_URI',
            'forms': ['CARRIER', 'SIGNED_CARD'], 'only_the_descriptor_key_counts': True,
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
