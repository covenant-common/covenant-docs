"""Content-addressed publishing of evidence, documentation pages and forum posts.

An owner-adopted option beside today's paths (the private evidence store, the
owner's public web host, the forum DAG). The same bytes are also published as
IPFS objects computed locally, listed in a manifest the publisher's AAP key
signs, and read back by CID from any source: an IPFS gateway, a peer, a CAR file
on a USB stick or one of AAP's offline carriers. Every block is checked against
its CID before use. Sources add availability, never trust.

Profile ``unixfs-v1-2025`` (IPIP-0499, ipfs/specs src/ipips/ipip-0499.md): CIDv1,
sha2-256, fixed 1 MiB chunks, the balanced layout, at most 1024 links per node,
raw leaves, Links-first dag-pb, no mode or mtime. A file of one chunk or less is
one raw block; a larger file is a tree of dag-pb UnixFS File nodes (ipfs/specs
src/unixfs.md). A directory is one dag-pb UnixFS Directory node with links in
byte order of their names; one that would exceed 256 KiB, where the profile
switches to a HAMT, is refused rather than written differently. Other chunk
sizes and widths are accepted for matching an existing DAG.

The manifest is a DAG-CBOR object {body, signature}. The body's item CIDs and
``previous`` are IPLD links, so pinning the manifest CID pins everything it
lists. The AAP signature covers the canonical JSON of the same body with each
link written as CID text (label COVENANT-CONTENT-MANIFEST-0.1).

Nothing here fetches, pins, announces or publishes; sources are owner-installed.
"""
from collections.abc import Mapping
from copy import deepcopy
import hashlib
import re

from .crypto import canonical, digest, integer, key, loads, need, public_key, sign, verification_key, verify
from . import ipld_codecs as ipld

VERSION = 'covenant-content-manifest/0.1'
LABEL = 'COVENANT-CONTENT-MANIFEST-0.1'
PROFILE = 'unixfs-v1-2025'
CHUNK = 1024 * 1024
WIDTH = 1024
DIRECTORY_LIMIT = 256 * 1024
MAX_FILE = 512 * 1024 * 1024
MAX_ITEMS = 256
MAX_BLOCKS = 1 << 20
MAX_DEPTH = 32
KINDS = ('EVIDENCE', 'DOCUMENT', 'DIRECTORY', 'FORUM_POST')
ITEM_FIELDS = 'kind name media_type cid bytes sha256 source'
MEDIA_TYPE = re.compile(r"[a-z0-9][a-z0-9!#$&^_.+-]{0,63}/[a-z0-9][a-z0-9!#$&^_.+-]{0,63}\Z")

REMEDIATION = {
    'PUBLISH_SIZE': 'Publish at most 512 MiB per file.',
    'PUBLISH_CHUNKING': 'Use a chunk size from 1 byte to 1 MiB and a width from 2 to 1024 links.',
    'PUBLISH_NAME': 'Use a UnixFS name of 1 to 255 UTF-8 bytes that is not ".", ".." and has no "/" or NUL.',
    'PUBLISH_DUPLICATE_NAME': 'Give each entry of a directory a distinct name.',
    'PUBLISH_DIRECTORY_TOO_LARGE': 'Split the directory: past 256 KiB the profile needs a HAMT, which is not written here.',
    'PUBLISH_PATH': 'Use relative POSIX paths without empty, "." or ".." segments.',
    'PUBLISH_ITEM': 'Use the exact item fields from describe() with a known kind and media type.',
    'PUBLISH_ITEMS': 'List 1 to 256 items with distinct names, sorted by name.',
    'PUBLISH_MEDIA_TYPE': 'Use a lower-case type/subtype media type such as text/html.',
    'PUBLISH_FORUM_POST': 'Publish a forum POST envelope whose actor signature verifies.',
    'MANIFEST_FIELDS': 'Use the exact manifest fields from describe().',
    'MANIFEST_PROFILE': 'Use version covenant-content-manifest/0.1 and profile unixfs-v1-2025.',
    'MANIFEST_SIGNATURE': 'The manifest must be signed by the publisher key it names.',
    'MANIFEST_PUBLISHER': 'The manifest is signed by a different publisher than the one you pinned.',
    'MANIFEST_BLOCK': 'Supply the DAG-CBOR manifest object {body, signature} exactly as published.',
    'MANIFEST_UNAVAILABLE': 'No source returned the manifest block; add another source and retry.',
    'CONTENT_UNIXFS': 'The DAG is not a UnixFS file or directory this reader supports (no HAMT or symlink).',
    'CONTENT_FILE_SIZES': 'The UnixFS blocksizes, filesize and children disagree; the DAG is malformed.',
    'CONTENT_LIMIT': 'The content exceeds the byte, block or depth bound given to the reader.',
    'CONTENT_PATH': 'The path names an entry that the directory does not have.',
    'CONTENT_SOURCES': 'Pass sources as mappings from CID text to bytes or as callables returning bytes or None.',
}


def remediation(code):
    return REMEDIATION.get(code, ipld.remediation(code))


def _unixfs_name(value):
    need(type(value) is str and value not in ('', '.', '..') and '/' not in value and '\x00' not in value, 'PUBLISH_NAME')
    try:
        raw = value.encode('utf-8')
    except UnicodeError:
        raise ValueError('PUBLISH_NAME') from None
    need(len(raw) <= ipld.MAX_NAME, 'PUBLISH_NAME')
    return raw


# UnixFS import.

def import_file(data, *, chunk_size=CHUNK, width=WIDTH):
    """The UnixFS DAG of ``data``: {'cid', 'bytes', 'tsize', 'blocks', 'profile'}.

    Leaves are raw blocks of ``chunk_size``; each level groups at most ``width``
    children, so every leaf sits at the same depth (the balanced layout).
    """
    need(type(data) is bytes and len(data) <= MAX_FILE, 'PUBLISH_SIZE')
    need(type(chunk_size) is int and 1 <= chunk_size <= CHUNK and type(width) is int and 2 <= width <= WIDTH,
         'PUBLISH_CHUNKING')
    blocks, level = {}, []
    for start in range(0, max(len(data), 1), chunk_size):
        chunk = data[start:start + chunk_size]
        binary = ipld.cid(ipld.RAW, chunk)
        blocks[ipld.cid_text(binary)] = chunk
        level.append({'hash': binary, 'size': len(chunk), 'tsize': len(chunk)})
    while len(level) > 1:
        parents = []
        for start in range(0, len(level), width):
            group = level[start:start + width]
            sizes = [child['size'] for child in group]
            node = ipld.dagpb_encode([{'hash': child['hash'], 'name': '', 'tsize': child['tsize']} for child in group],
                                     ipld.unixfs_encode(2, filesize=sum(sizes), blocksizes=sizes))
            binary = ipld.cid(ipld.DAG_PB, node)
            blocks[ipld.cid_text(binary)] = node
            parents.append({'hash': binary, 'size': sum(sizes), 'tsize': len(node) + sum(c['tsize'] for c in group)})
        level = parents
    root = level[0]
    profile = PROFILE if (chunk_size, width) == (CHUNK, WIDTH) else f'custom-chunk-{chunk_size}-width-{width}'
    return {'cid': ipld.cid_text(root['hash']), 'bytes': len(data), 'tsize': root['tsize'], 'blocks': blocks,
            'profile': profile}


def import_directory(entries):
    """One UnixFS Directory node. ``entries`` maps name to {'cid', 'tsize'}; links sort by name bytes."""
    need(type(entries) is dict and len(entries) <= ipld.MAX_LINKS, 'PUBLISH_ITEMS')
    rows = []
    for name, entry in entries.items():
        need(type(entry) is dict and set(entry) >= {'cid', 'tsize'}, 'PUBLISH_ITEM')
        integer(entry['tsize'])
        rows.append((_unixfs_name(name), name, ipld.parse_cid(entry['cid'])['binary'], entry['tsize']))
    rows.sort(key=lambda row: row[0])
    need(len({row[0] for row in rows}) == len(rows), 'PUBLISH_DUPLICATE_NAME')
    node = ipld.dagpb_encode([{'hash': binary, 'name': name, 'tsize': tsize} for _, name, binary, tsize in rows],
                             ipld.unixfs_encode(1))
    need(len(node) <= DIRECTORY_LIMIT, 'PUBLISH_DIRECTORY_TOO_LARGE')
    text = ipld.cid_text(ipld.cid(ipld.DAG_PB, node))
    return {'cid': text, 'tsize': len(node) + sum(row[3] for row in rows), 'blocks': {text: node}}


def import_tree(files):
    """Nested UnixFS directories from {relative/posix/path: bytes}: {'cid', 'tsize', 'blocks', 'files'}."""
    need(type(files) is dict and 1 <= len(files) <= ipld.MAX_LINKS, 'PUBLISH_ITEMS')
    tree, imported, blocks = {}, {}, {}
    for path, data in files.items():
        need(type(path) is str and 0 < len(path) <= 1024, 'PUBLISH_PATH')
        parts = path.split('/')
        need(len(parts) <= MAX_DEPTH, 'PUBLISH_PATH')
        for part in parts:
            _unixfs_name(part)
        node = tree
        for part in parts[:-1]:
            node = node.setdefault(part, {})
            need(type(node) is dict, 'PUBLISH_DUPLICATE_NAME')
        need(parts[-1] not in node, 'PUBLISH_DUPLICATE_NAME')
        made = import_file(data)
        blocks.update(made['blocks'])
        node[parts[-1]] = ('FILE', made['cid'], made['tsize'])
        imported[path] = {'cid': made['cid'], 'bytes': made['bytes'], 'sha256': hashlib.sha256(data).hexdigest()}

    def build(node):
        entries = {name: ({'cid': child[1], 'tsize': child[2]} if type(child) is tuple else build(child))
                   for name, child in node.items()}
        made = import_directory(entries)
        blocks.update(made['blocks'])
        return {'cid': made['cid'], 'tsize': made['tsize']}

    root = build(tree)
    return {'cid': root['cid'], 'tsize': root['tsize'], 'blocks': blocks, 'files': imported}


# Items and bundles: what a manifest lists, with the blocks that serve it.

def _media_type(value):
    need(type(value) is str and MEDIA_TYPE.fullmatch(value) is not None, 'PUBLISH_MEDIA_TYPE')
    return value


def _item(body):
    need(type(body) is dict and set(body) == set(ITEM_FIELDS.split()), 'PUBLISH_ITEM')
    need(body['kind'] in KINDS, 'PUBLISH_ITEM')
    need(type(body['name']) is str and 0 < len(body['name']) <= 256 and all(32 <= ord(c) <= 126 for c in body['name']),
         'PUBLISH_ITEM')
    _media_type(body['media_type'])
    need(ipld.cid_text(body['cid']) == body['cid'], 'PUBLISH_ITEM')
    if body['kind'] == 'DIRECTORY':
        need(body['media_type'] == 'inode/directory' and body['bytes'] is None and body['sha256'] is None, 'PUBLISH_ITEM')
        need(ipld.parse_cid(body['cid'])['codec'] == ipld.DAG_PB, 'PUBLISH_ITEM')
    else:
        integer(body['bytes']); key(body['sha256'])
    need(body['source'] is None or (type(body['source']) is str and 0 < len(body['source']) <= 256
                                    and all(32 <= ord(c) <= 126 for c in body['source'])), 'PUBLISH_ITEM')
    return body


def file_bundle(kind, name, data, media_type, *, source=None):
    """One file item and its blocks, built with the manifest's profile."""
    made = import_file(data)
    item = _item({'kind': kind, 'name': name, 'media_type': media_type, 'cid': made['cid'], 'bytes': len(data),
                  'sha256': hashlib.sha256(data).hexdigest(), 'source': source})
    return {'items': [item], 'blocks': made['blocks']}


def evidence_bundle(store, manifest_id):
    """Evidence bytes from an EvidenceStore, read through its own hash checks first."""
    body = store.manifest(manifest_id)
    raw = store.read(manifest_id)
    return file_bundle('EVIDENCE', 'evidence/' + manifest_id, raw, body['media_type'], source=manifest_id)


def forum_bundle(envelope):
    """A forum POST (covenant-agent-network/0.1) as its exact canonical signed bytes."""
    from .public_web import source_fields
    try:
        ref, _, _ = source_fields('social', envelope)
    except ValueError:
        raise ValueError('PUBLISH_FORUM_POST') from None
    return file_bundle('FORUM_POST', 'forum/' + ref['id'] + '.json', canonical(envelope), 'application/json',
                       source=ref['id'])


def documents_bundle(files, *, prefix='docs', media_types=None):
    """DOCUMENT items for each page plus one DIRECTORY item for the tree that holds them."""
    tree = import_tree(files)
    types = media_types or {}
    items = [_item({'kind': 'DIRECTORY', 'name': prefix + '/', 'media_type': 'inode/directory', 'cid': tree['cid'],
                    'bytes': None, 'sha256': None, 'source': None})]
    for path, made in sorted(tree['files'].items()):
        guessed = 'text/html' if path.endswith('.html') else 'text/markdown' if path.endswith('.md') else \
            'application/json' if path.endswith('.json') else 'application/octet-stream'
        items.append(_item({'kind': 'DOCUMENT', 'name': prefix + '/' + path, 'media_type': types.get(path, guessed),
                            'cid': made['cid'], 'bytes': made['bytes'], 'sha256': made['sha256'], 'source': path}))
    return {'items': items, 'blocks': tree['blocks']}


def merge(*bundles):
    items, blocks = [], {}
    for bundle in bundles:
        need(type(bundle) is dict and set(bundle) == {'items', 'blocks'}, 'PUBLISH_ITEMS')
        items += deepcopy(bundle['items'])
        blocks.update(bundle['blocks'])
    return {'items': items, 'blocks': blocks}


# The signed manifest.

def _validate(body):
    need(type(body) is dict and set(body) == {'version', 'publisher', 'sequence', 'previous', 'issued_at', 'profile',
                                              'items'}, 'MANIFEST_FIELDS')
    need(body['version'] == VERSION and body['profile'] == PROFILE, 'MANIFEST_PROFILE')
    need(type(body['publisher']) is str, 'MANIFEST_FIELDS'); verification_key(body['publisher'])
    integer(body['sequence']); integer(body['issued_at'])
    need(body['previous'] is None or ipld.cid_text(body['previous']) == body['previous'], 'MANIFEST_FIELDS')
    need(type(body['items']) is list and 1 <= len(body['items']) <= MAX_ITEMS, 'PUBLISH_ITEMS')
    for item in body['items']:
        _item(item)
    names = [item['name'] for item in body['items']]
    need(names == sorted(set(names)), 'PUBLISH_ITEMS')
    canonical(body)
    return body


def manifest(publisher, bundle, *, issued_at, sequence=0, previous=None):
    """The unsigned manifest body and its signing payload; no signature is made here."""
    need(type(bundle) is dict and type(bundle.get('items')) is list, 'PUBLISH_ITEMS')
    body = {'version': VERSION, 'publisher': publisher, 'sequence': sequence, 'previous': previous,
            'issued_at': issued_at, 'profile': PROFILE,
            'items': sorted(deepcopy(bundle['items']), key=lambda item: item['name'])}
    _validate(body)
    return {'id': digest(LABEL, body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [publisher], 'signature_created': False, 'execution_authorized': False}


def sign_manifest(body, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body['publisher'], 'MANIFEST_SIGNATURE')
    envelope = {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}
    text, block = manifest_block(envelope)
    return {'envelope': envelope, 'cid': text, 'block': block}


def _to_cbor(body):
    out = deepcopy(body)
    out['previous'] = None if body['previous'] is None else ipld.Link(body['previous'])
    for item in out['items']:
        item['cid'] = ipld.Link(item['cid'])
    return out


def _from_cbor(value):
    need(type(value) is dict and type(value.get('items')) is list, 'MANIFEST_BLOCK')
    out = dict(value)
    previous = value.get('previous')
    need(previous is None or type(previous) is ipld.Link, 'MANIFEST_BLOCK')
    out['previous'] = None if previous is None else previous.text
    items = []
    for item in value['items']:
        need(type(item) is dict and type(item.get('cid')) is ipld.Link, 'MANIFEST_BLOCK')
        items.append({**item, 'cid': item['cid'].text})
    out['items'] = items
    return out


def manifest_block(envelope):
    """(CID text, DAG-CBOR bytes) of a signed manifest; the signature is checked first."""
    open_envelope(envelope)
    block = ipld.dagcbor_encode({'body': _to_cbor(envelope['body']), 'signature': envelope['signature']})
    return ipld.cid_text(ipld.cid(ipld.DAG_CBOR, block)), block


def open_envelope(envelope, *, publisher=None):
    need(type(envelope) is dict and set(envelope) == {'body', 'signature'}, 'MANIFEST_FIELDS')
    body = _validate(envelope['body'])
    try:
        verify(body['publisher'], LABEL, body, envelope['signature'])
    except ValueError:
        raise ValueError('MANIFEST_SIGNATURE') from None
    if publisher is not None:
        need(body['publisher'] == publisher, 'MANIFEST_PUBLISHER')
    return {'id': digest(LABEL, body), 'body': deepcopy(body)}


# Retrieval from any source.

def car_source(raw):
    """A source over a CARv1 archive; every block in it is verified as it is read."""
    return dict(ipld.car_decode(raw)['blocks'])


def _sources(sources):
    need(type(sources) in (list, tuple) and 1 <= len(sources) <= 64
         and all(isinstance(source, Mapping) or callable(source) for source in sources), 'CONTENT_SOURCES')
    return sources


def fetch_block(cid_value, sources, attempts):
    """(bytes, source index) of the first source whose bytes hash to the CID, else (None, None).

    Each refusal is recorded in ``attempts``: MISSING, UNAVAILABLE (the source raised)
    or MISMATCH (bytes that do not hash to the CID, never used).
    """
    parsed = ipld.parse_cid(cid_value)
    for index, source in enumerate(_sources(sources)):
        try:
            data = source.get(parsed['text']) if isinstance(source, Mapping) else source(parsed['text'])
        except Exception:  # an owner-installed source that raises is UNAVAILABLE, never a verified block
            attempts.append({'cid': parsed['text'], 'source': index, 'status': 'UNAVAILABLE'})
            continue
        if data is None:
            attempts.append({'cid': parsed['text'], 'source': index, 'status': 'MISSING'})
            continue
        try:
            ipld.verify_block(parsed['binary'], data)
        except ValueError:
            attempts.append({'cid': parsed['text'], 'source': index, 'status': 'MISMATCH'})
            continue
        return data, index
    return None, None


class _Walk:
    def __init__(self, sources, max_bytes, max_blocks):
        integer(max_bytes, True); integer(max_blocks, True)
        need(max_bytes <= MAX_FILE and max_blocks <= MAX_BLOCKS, 'CONTENT_LIMIT')
        self.sources, self.max_bytes, self.max_blocks = _sources(sources), max_bytes, max_blocks
        self.attempts, self.served, self.blocks, self.missing = [], {}, 0, None

    def block(self, binary):
        need(self.blocks < self.max_blocks, 'CONTENT_LIMIT')
        data, index = fetch_block(binary, self.sources, self.attempts)
        if data is None:
            self.missing = ipld.cid_text(binary)
            return None
        self.blocks += 1
        self.served[index] = self.served.get(index, 0) + 1
        return data

    def file(self, binary, depth=0):
        """Bytes of a UnixFS file DAG, or None when a block is unavailable from every source."""
        need(depth <= MAX_DEPTH, 'CONTENT_LIMIT')
        parsed = ipld.parse_cid(binary)
        data = self.block(binary)
        if data is None:
            return None
        if parsed['codec'] == ipld.RAW:
            need(len(data) <= self.max_bytes, 'CONTENT_LIMIT')
            return data
        need(parsed['codec'] == ipld.DAG_PB, 'CONTENT_UNIXFS')
        node = ipld.dagpb_decode(data)
        need(node['data'] is not None, 'CONTENT_UNIXFS')
        meta = ipld.unixfs_decode(node['data'])
        need(meta['type_name'] in ('File', 'Raw'), 'CONTENT_UNIXFS')
        need(len(meta['blocksizes']) == len(node['links']), 'CONTENT_FILE_SIZES')
        need(all(link['name'] in (None, '') for link in node['links']), 'CONTENT_UNIXFS')
        out = [meta['data'] or b'']
        total = len(out[0])
        need(total <= self.max_bytes, 'CONTENT_LIMIT')
        for link, size in zip(node['links'], meta['blocksizes']):
            child = self.file(link['hash'], depth + 1)
            if child is None:
                return None
            need(len(child) == size, 'CONTENT_FILE_SIZES')
            total += size
            need(total <= self.max_bytes, 'CONTENT_LIMIT')
            out.append(child)
        need(meta['filesize'] in (None, total) and (meta['filesize'] is not None or total == 0), 'CONTENT_FILE_SIZES')
        return b''.join(out)

    def directory(self, binary):
        data = self.block(binary)
        if data is None:
            return None
        need(ipld.parse_cid(binary)['codec'] == ipld.DAG_PB, 'CONTENT_UNIXFS')
        node = ipld.dagpb_decode(data)
        need(node['data'] is not None and ipld.unixfs_decode(node['data'])['type_name'] == 'Directory', 'CONTENT_UNIXFS')
        entries = {}
        for link in node['links']:
            need(link['name'] is not None, 'CONTENT_UNIXFS')
            entries.setdefault(link['name'], ipld.cid_text(link['hash']))  # the first of a repeated name wins
        return entries

    def result(self, cid_text, **fields):
        status = 'VERIFIED' if self.missing is None else 'UNAVAILABLE'
        out = {'cid': cid_text, 'status': status, 'blocks': self.blocks, 'served_by': dict(sorted(self.served.items())),
               'refused_attempts': [row for row in self.attempts if row['status'] == 'MISMATCH'],
               'attempts': list(self.attempts), 'network_accessed': False, 'execution_authorized': False}
        if self.missing is not None:
            return {**out, 'missing': self.missing}
        return {**out, **fields}


def retrieve(cid_value, sources, *, max_bytes=MAX_FILE, max_blocks=MAX_BLOCKS):
    """Read a UnixFS file by CID: VERIFIED with its bytes, or UNAVAILABLE naming the missing block.

    A block from a source that does not hash to its CID is skipped and recorded;
    a DAG whose verified blocks contradict UnixFS is refused with a code.
    """
    walk = _Walk(sources, max_bytes, max_blocks)
    parsed = ipld.parse_cid(cid_value)
    data = walk.file(parsed['binary'])
    if data is None:
        return walk.result(parsed['text'])
    return walk.result(parsed['text'], data=data, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def list_directory(cid_value, sources):
    walk = _Walk(sources, MAX_FILE, MAX_BLOCKS)
    parsed = ipld.parse_cid(cid_value)
    entries = walk.directory(parsed['binary'])
    return walk.result(parsed['text']) if entries is None else walk.result(parsed['text'], entries=entries)


def resolve_path(root, path, sources):
    """The CID a UnixFS path names under ``root`` (ipfs/specs UnixFS Paths), or an UNAVAILABLE result."""
    need(type(path) is str and 0 < len(path) <= 1024, 'PUBLISH_PATH')
    parts = path.strip('/').split('/')
    need(all(part not in ('', '.', '..') for part in parts) and len(parts) <= MAX_DEPTH, 'PUBLISH_PATH')
    current = ipld.cid_text(root)
    for part in parts:
        listing = list_directory(current, sources)
        if listing['status'] != 'VERIFIED':
            return listing
        need(part in listing['entries'], 'CONTENT_PATH')
        current = listing['entries'][part]
    return {'cid': current, 'status': 'VERIFIED', 'execution_authorized': False}


def open_manifest(cid_value, sources, *, publisher=None):
    """Fetch, verify and open a published manifest: its CID, its DAG-CBOR form, then the AAP signature."""
    attempts = []
    parsed = ipld.parse_cid(cid_value)
    need(parsed['codec'] == ipld.DAG_CBOR, 'MANIFEST_BLOCK')
    data, index = fetch_block(parsed['binary'], sources, attempts)
    if data is None:
        return {'cid': parsed['text'], 'status': 'UNAVAILABLE', 'attempts': attempts, 'execution_authorized': False}
    try:
        value = ipld.dagcbor_decode(data)
    except ValueError:
        raise ValueError('MANIFEST_BLOCK') from None
    need(type(value) is dict and set(value) == {'body', 'signature'}, 'MANIFEST_BLOCK')
    opened = open_envelope({'body': _from_cbor(value['body']), 'signature': value['signature']}, publisher=publisher)
    need(manifest_block({'body': opened['body'], 'signature': value['signature']})[1] == data, 'MANIFEST_BLOCK')
    return {'cid': parsed['text'], 'status': 'VERIFIED', 'id': opened['id'], 'body': opened['body'],
            'served_by': index, 'attempts': attempts, 'publisher': opened['body']['publisher'],
            'signature': 'VERIFIED_PUBLISHER_KEY', 'execution_authorized': False}


def verify_publication(cid_value, sources, *, publisher=None):
    """Open a manifest and read every item back by CID; each item is VERIFIED, UNAVAILABLE or refused."""
    opened = open_manifest(cid_value, sources, publisher=publisher)
    if opened['status'] != 'VERIFIED':
        return {**opened, 'items': [], 'complete': False}
    rows = []
    for item in opened['body']['items']:
        if item['kind'] == 'DIRECTORY':
            found = list_directory(item['cid'], sources)
            rows.append({'name': item['name'], 'cid': item['cid'], 'status': found['status'],
                         'entries': sorted(found.get('entries', {}))})
            continue
        found = retrieve(item['cid'], sources)
        row = {'name': item['name'], 'cid': item['cid'], 'status': found['status']}
        if found['status'] == 'VERIFIED':
            need(found['bytes'] == item['bytes'] and found['sha256'] == item['sha256'], 'CONTENT_FILE_SIZES')
            if item['kind'] == 'FORUM_POST':
                from .public_web import source_fields
                ref, _, _ = source_fields('social', loads(found['data']))
                need(ref['id'] == item['source'], 'PUBLISH_FORUM_POST')
                row['aap_signature'] = 'VERIFIED_ACTOR_KEY'
        rows.append(row)
    complete = all(row['status'] == 'VERIFIED' for row in rows)
    return {**{k: v for k, v in opened.items() if k != 'body'}, 'publisher': opened['body']['publisher'],
            'sequence': opened['body']['sequence'], 'items': rows, 'complete': complete,
            'status': 'VERIFIED' if complete else 'UNKNOWN'}


def dag_blocks(root, blocks):
    """Blocks of the DAG under ``root`` in depth-first first-seen order (the deterministic CAR order)."""
    order, seen, stack = [], set(), [ipld.parse_cid(root)['text']]
    while stack:
        text = stack.pop()
        if text in seen:
            continue
        need(text in blocks, 'MANIFEST_UNAVAILABLE')
        seen.add(text)
        order.append(text)
        parsed = ipld.parse_cid(text)
        stack.extend(ipld.cid_text(child) for child in reversed(ipld.links_of(parsed['codec'], blocks[text])))
    return order


def export_car(signed, bundle):
    """A CARv1 archive rooted at the manifest: the manifest block, then each listed DAG in DFS order.

    The ``previous`` manifest is a link only; its blocks travel with its own archive.
    """
    need(type(signed) is dict and set(signed) == {'envelope', 'cid', 'block'}, 'MANIFEST_BLOCK')
    need(manifest_block(signed['envelope']) == (signed['cid'], signed['block']), 'MANIFEST_BLOCK')
    need(type(bundle) is dict and type(bundle.get('blocks')) is dict, 'PUBLISH_ITEMS')
    order, seen = [signed['cid']], {signed['cid']}
    for item in signed['envelope']['body']['items']:
        for text in dag_blocks(item['cid'], bundle['blocks']):
            if text not in seen:
                seen.add(text)
                order.append(text)
    blocks = {signed['cid']: signed['block'], **bundle['blocks']}
    return ipld.car_encode([signed['cid']], [(text, blocks[text]) for text in order])


def describe():
    return {'version': VERSION, 'label': LABEL, 'status': 'EXPERIMENTAL_OPTIONAL_PUBLICATION', 'profile': PROFILE,
            'profile_parameters': {'cid': 'CIDv1', 'hash': 'sha2-256', 'chunk_bytes': CHUNK, 'layout': 'balanced',
                                   'width': WIDTH, 'leaves': 'raw', 'pbnode_order': 'links-first',
                                   'directory_limit_bytes': DIRECTORY_LIMIT, 'hamt': 'REFUSED_NOT_WRITTEN'},
            'item_fields': ITEM_FIELDS.split(), 'kinds': list(KINDS),
            'manifest': 'DAG_CBOR_BODY_WITH_LINKS_AND_AAP_ED25519_SIGNATURE_OVER_CANONICAL_JSON',
            'sources': 'OWNER_INSTALLED_MAPPINGS_OR_CALLABLES_AVAILABILITY_NOT_TRUST',
            'outcomes': ['VERIFIED', 'UNAVAILABLE', 'UNKNOWN'], 'remediation': dict(REMEDIATION),
            'network_accessed': False, 'publication': 'OWNER_PINS_OR_UPLOADS_THE_CAR', 'execution_authorized': False}
