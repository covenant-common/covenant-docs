"""Decimal, EXIF, NMEA and geo: URI coordinates as fixed-point microdegrees.

The signed claim stores integers. A float never enters the canonical payload.
South and west are negative. The clock on an EXIF stamp is the picture's clock
read as UTC, which is not a timezone attestation. NMEA RMC and ZDA times are
the receiver's report of UTC: a claim that a spoofed or replayed signal can
move, never an authenticated time.
"""
from decimal import Decimal, ROUND_HALF_EVEN
from fractions import Fraction
import calendar
import datetime
import re

from .crypto import need

VERSION = 'covenant-geo-fix/0.1'
SCALE = 1_000_000
SOURCES = {'DECIMAL', 'EXIF', 'NMEA', 'GEO_URI'}
_DECIMAL = re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)\Z')
_STAMP = re.compile(r'[0-9]{4}:[0-9]{2}:[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\Z')
_GEO = re.compile(r'^geo:([+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)),([+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+))(?:,[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+))?(?:;(.*))?\Z', re.IGNORECASE)
GPS_KEYS = {'lat', 'lon', 'latitude', 'longitude', 'lat_microdeg', 'lon_microdeg', 'nmea', 'geo', 'geo_uri'}
_TYPE_SIZE = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8}
_NMEA_CLOCK = re.compile(r'([01][0-9]|2[0-3])([0-5][0-9])([0-5][0-9]|60)(?:\.([0-9]{1,6}))?\Z')
# RMC mode indicator (NMEA 2.3 and later): autonomous, differential, precise,
# RTK and float RTK. Estimated, manual, simulator and not-valid modes refuse.
RMC_TIME_MODES = {'A', 'D', 'P', 'R', 'F'}


def fix(lat_microdeg, lon_microdeg, source):
    need(source in SOURCES, 'GEO_SOURCE')
    need(type(lat_microdeg) is int and abs(lat_microdeg) <= 90 * SCALE, 'GEO_RANGE')
    need(type(lon_microdeg) is int and abs(lon_microdeg) <= 180 * SCALE, 'GEO_RANGE')
    return {'version': VERSION, 'lat_microdeg': lat_microdeg, 'lon_microdeg': lon_microdeg, 'scale': SCALE, 'source': source}


def _micro(value, limit_deg):
    if type(value) is bool:
        raise ValueError('GEO_DECIMAL')
    if type(value) is float:
        value = str(value)
    if type(value) is int:
        need(abs(value) <= limit_deg, 'GEO_RANGE')
        return value * SCALE
    if type(value) is Decimal:
        dec = value
    elif type(value) is str and _DECIMAL.fullmatch(value):
        dec = Decimal(value)
    else:
        raise ValueError('GEO_DECIMAL')
    micro = int((dec * SCALE).to_integral_value(ROUND_HALF_EVEN))
    need(abs(micro) <= limit_deg * SCALE, 'GEO_RANGE')
    return micro


def parse_decimal(lat, lon):
    return fix(_micro(lat, 90), _micro(lon, 180), 'DECIMAL')


def _nmea_angle(raw, hemisphere, limit):
    need(type(raw) is str and type(hemisphere) is str and '.' in raw, 'GEO_NMEA')
    dot = raw.index('.')
    need(dot >= 2 and raw[:dot].isdigit() and raw[dot + 1:].isdigit(), 'GEO_NMEA')
    minutes = Decimal(raw[dot - 2:])
    degrees = int(raw[:dot - 2] or '0')
    micro = degrees * SCALE + int((minutes * SCALE / 60).to_integral_value(ROUND_HALF_EVEN))
    if hemisphere in 'SW':
        micro = -micro
    elif hemisphere not in 'NE':
        raise ValueError('GEO_NMEA')
    need(abs(micro) <= limit * SCALE, 'GEO_RANGE')
    return micro


def _nmea_fields(sentence, kinds):
    need(type(sentence) is str and sentence.startswith('$') and '*' in sentence, 'GEO_NMEA')
    body, _, checksum = sentence[1:].partition('*')
    need(re.fullmatch(r'[0-9A-Fa-f]{2}', checksum) is not None, 'GEO_NMEA')
    acc = 0
    for char in body:
        acc ^= ord(char)
    need(acc == int(checksum, 16), 'GEO_NMEA')
    kind = body[:5]
    need(len(kind) == 5 and kind[2:] in kinds, 'GEO_NMEA')
    return kind, body.split(',')


def parse_nmea(sentence):
    kind, fields = _nmea_fields(sentence, {'GGA', 'RMC'})
    if kind[2:] == 'GGA':
        need(len(fields) >= 7, 'GEO_NMEA')
        lat, ns, lon, ew = fields[2], fields[3], fields[4], fields[5]
    else:
        need(len(fields) >= 7 and fields[2] == 'A', 'GEO_NMEA')
        lat, ns, lon, ew = fields[3], fields[4], fields[5], fields[6]
    return fix(_nmea_angle(lat, ns, 90), _nmea_angle(lon, ew, 180), 'NMEA')


def parse_nmea_time(sentence):
    """Receiver-reported UTC from one checked RMC or ZDA sentence, in Unix seconds.

    RMC needs status A and, when present, a fix mode in RMC_TIME_MODES; its
    two-digit year reads as 1980-2079. ZDA carries a four-digit year and its
    zone fields are display offsets only. ``fraction`` is true when the
    reported second has a nonzero fractional part.
    """
    kind, fields = _nmea_fields(sentence, {'RMC', 'ZDA'})
    if kind[2:] == 'RMC':
        need(len(fields) >= 10 and fields[2] == 'A', 'GEO_NMEA_TIME')
        need(len(fields) < 13 or fields[12][:1] in RMC_TIME_MODES, 'GEO_NMEA_TIME')
        need(re.fullmatch(r'[0-9]{6}', fields[9]) is not None, 'GEO_NMEA_TIME')
        day, month, short = int(fields[9][:2]), int(fields[9][2:4]), int(fields[9][4:])
        year = short + (1900 if short >= 80 else 2000)
    else:
        need(len(fields) >= 5 and re.fullmatch(r'[0-9]{2}', fields[2]) is not None and
             re.fullmatch(r'[0-9]{2}', fields[3]) is not None and re.fullmatch(r'[0-9]{4}', fields[4]) is not None,
             'GEO_NMEA_TIME')
        day, month, year = int(fields[2]), int(fields[3]), int(fields[4])
    clock = _NMEA_CLOCK.fullmatch(fields[1])
    need(clock is not None, 'GEO_NMEA_TIME')
    try:
        datetime.date(year, month, day)
    except ValueError:
        raise ValueError('GEO_NMEA_TIME') from None
    hour, minute, second = (int(clock.group(i)) for i in (1, 2, 3))
    return {'utc': calendar.timegm((year, month, day, hour, minute, second)),
            'fraction': (clock.group(4) or '0').strip('0') != '', 'sentence': kind[2:], 'talker': kind[:2]}


def parse_geo_uri(uri):
    need(type(uri) is str, 'GEO_URI')
    match = _GEO.fullmatch(uri)
    need(match is not None, 'GEO_URI')
    params = match.group(3) or ''
    for part in params.split(';'):
        if part.lower().startswith('crs='):
            need(part.split('=', 1)[1].lower() == 'wgs84', 'GEO_URI')
    return parse_decimal(match.group(1), match.group(2)) | {'source': 'GEO_URI'}


def _order(data):
    need(len(data) >= 8 and data[:2] in {b'II', b'MM'} and int.from_bytes(data[2:4], 'little' if data[:2] == b'II' else 'big') == 42, 'GEO_EXIF')
    return 'little' if data[:2] == b'II' else 'big'


def _slice(data, offset, size):
    need(0 <= offset and size >= 0 and offset + size <= len(data), 'GEO_EXIF')
    return data[offset:offset + size]


def _u16(data, offset, endian):
    return int.from_bytes(_slice(data, offset, 2), endian)


def _u32(data, offset, endian):
    return int.from_bytes(_slice(data, offset, 4), endian)


def _components(data, offset, endian, typ, count):
    size = _TYPE_SIZE.get(typ)
    need(size is not None and 0 < count <= 64, 'GEO_EXIF')
    nbytes = size * count
    start = offset if nbytes <= 4 else _u32(data, offset, endian)
    raw = _slice(data, start, nbytes)
    if typ == 2:
        return raw.split(b'\x00', 1)[0].decode('ascii')
    if typ == 5:
        return [(int.from_bytes(raw[i:i + 4], endian), int.from_bytes(raw[i + 4:i + 8], endian)) for i in range(0, nbytes, 8)]
    if typ == 4 and count == 1:
        return int.from_bytes(raw, endian)
    return raw


def _ifd(data, offset, endian, depth, seen):
    need(depth <= 4 and offset not in seen, 'GEO_EXIF')
    seen.add(offset)
    count = _u16(data, offset, endian)
    need(count <= 64, 'GEO_EXIF')
    entries = {}
    for index in range(count):
        at = offset + 2 + index * 12
        tag, typ, number = _u16(data, at, endian), _u16(data, at + 2, endian), _u32(data, at + 4, endian)
        entries[tag] = _components(data, at + 8, endian, typ, number)
    return entries


def _dms(values):
    need(type(values) is list and len(values) in {2, 3}, 'GEO_EXIF')
    degrees, minutes = values[0], values[1]
    seconds = values[2] if len(values) == 3 else (0, 1)
    for num, den in (degrees, minutes, seconds):
        need(den > 0, 'GEO_EXIF')
    value = Fraction(degrees[0], degrees[1]) + Fraction(minutes[0], minutes[1] * 60) + Fraction(seconds[0], seconds[1] * 3600)
    dec = Decimal(value.numerator) / Decimal(value.denominator)
    return int((dec * SCALE).to_integral_value(ROUND_HALF_EVEN))


def _stamp(text):
    need(type(text) is str and _STAMP.fullmatch(text) is not None, 'GEO_TIME')
    year, month, day = (int(part) for part in text[:10].split(':'))
    hour, minute, second = (int(part) for part in text[11:].split(':'))
    try:
        return calendar.timegm((year, month, day, hour, minute, second))
    except (OverflowError, ValueError):
        raise ValueError('GEO_TIME') from None


def exif_tiff(data):
    """Read a TIFF EXIF block. Returns the fix and an observed_at, or None."""
    need(type(data) is bytes and len(data) <= 2_000_000, 'GEO_EXIF')
    endian = _order(data)
    root = _ifd(data, _u32(data, 4, endian), endian, 0, set())
    sub = _ifd(data, root[0x8769], endian, 1, set()) if 0x8769 in root and type(root[0x8769]) is int else {}
    gps = _ifd(data, root[0x8825], endian, 1, set()) if 0x8825 in root and type(root[0x8825]) is int else None
    need(type(gps) is dict and 1 in gps and 2 in gps and 3 in gps and 4 in gps, 'GEO_EXIF')
    lat = _dms(gps[2])
    lon = _dms(gps[4])
    need(gps[1] in {'N', 'S'} and gps[3] in {'E', 'W'}, 'GEO_EXIF')
    if gps[1] == 'S':
        lat = -lat
    if gps[3] == 'W':
        lon = -lon
    stamp = sub.get(0x9003) or root.get(0x0132)
    observed = _stamp(stamp) if type(stamp) is str else None
    return fix(lat, lon, 'EXIF'), observed


def exif_jpeg(blob):
    need(type(blob) is bytes and len(blob) >= 4 and blob[:2] == b'\xff\xd8', 'GEO_EXIF')
    index = 2
    while index + 4 <= len(blob) and blob[index] == 0xFF:
        marker = blob[index + 1]
        if marker == 0xDA or marker == 0xD9:
            break
        if marker == 0x01 or 0xD0 <= marker <= 0xD9:
            index += 2
            continue
        length = int.from_bytes(blob[index + 2:index + 4], 'big')
        need(length >= 2 and index + 2 + length <= len(blob), 'GEO_EXIF')
        segment = blob[index + 4:index + 2 + length]
        if marker == 0xE1 and segment.startswith(b'Exif\x00\x00'):
            return exif_tiff(segment[6:])
        index += 2 + length
    raise ValueError('GEO_EXIF')


def parse_exif(blob):
    point, _observed = exif_jpeg(blob) if blob[:2] == b'\xff\xd8' else exif_tiff(blob)
    return point


def normalize_claim(claim):
    """Replace a phone-shaped GPS value with the fixed-point claim."""
    need(type(claim) is dict, 'GEO_CLAIM')
    if not (GPS_KEYS & set(claim)):
        return dict(claim)
    if 'nmea' in claim:
        point = parse_nmea(claim['nmea'])
    elif 'geo' in claim or 'geo_uri' in claim:
        point = parse_geo_uri(claim['geo'] if 'geo' in claim else claim['geo_uri'])
    elif 'lat' in claim or 'latitude' in claim or 'lon' in claim or 'longitude' in claim:
        lat = claim['lat'] if 'lat' in claim else claim.get('latitude')
        lon = claim['lon'] if 'lon' in claim else claim.get('longitude')
        need(lat is not None and lon is not None, 'GEO_PAIR')
        point = parse_decimal(lat, lon)
        if 'lat_microdeg' in claim or 'lon_microdeg' in claim:
            need(claim.get('lat_microdeg') == point['lat_microdeg'] and claim.get('lon_microdeg') == point['lon_microdeg'], 'GEO_MISMATCH')
    else:
        point = fix(claim['lat_microdeg'], claim['lon_microdeg'], 'DECIMAL')
    kept = {key: value for key, value in claim.items() if key not in GPS_KEYS}
    kept.update(lat_microdeg=point['lat_microdeg'], lon_microdeg=point['lon_microdeg'], geo_scale=SCALE, geo_source=point['source'])
    return kept
