"""Experimental fixed-committee replicated logical inventory, profile 0.1.

Reuse the native round-locking consensus engine, not a collection of independent
provider databases. Only durable certified commands create entitlements. Full,
bounded history proofs deliberately disclose command content to their recipient.
Intact non-cloned validator signing storage and <=f faulty keys are assumptions.
"""
from copy import deepcopy
import fcntl
import json
import os
from pathlib import Path
import re
import threading

from covenant_language.safe_io import atomic_write

from . import crypto as c
from . import resource_provider as p
from .agent_tools import decode
from .consensus import Engine
from .storage import Journal
from .workflow_store import canonical, identifier

VERSION = 'covenant-provider-replication/0.1'
RECEIPT = 'covenant-replicated-provider-receipt/0.1'
COMMAND_LABEL = 'COVENANT-REPLICATED-PROVIDER-COMMAND-0.1'
MAX_COMMITS = 128
MAX_HISTORY_BYTES = 400000
MAX_ENVELOPE_BYTES = 100000
CERTIFICATE_RESERVE = 100000  # upper bound for ten supported ML-DSA-65 votes


def validate_spec(spec):
    c.exact(spec, 'version provider validators faults max_clock_skew')
    c.need(spec['version'] == VERSION, 'REPLICA_VERSION')
    p.validate_spec(spec['provider'])
    validators = spec['validators']; f = spec['faults']
    c.need(type(f) is int and 1 <= f <= 3 and type(validators) is dict and len(validators) == 3*f+1,
           'REPLICA_COMMITTEE')
    for name, key in validators.items():
        c.need(type(name) is str and re.fullmatch('[a-z0-9_-]{1,32}', name), 'REPLICA_MEMBER')
        c.verification_key(key)
    c.need(len({identifier('REPLICA-KEY', k) for k in validators.values()}) == len(validators), 'REPLICA_DUPLICATE_KEY')
    c.need(type(spec['max_clock_skew']) is int and 0 <= spec['max_clock_skew'] <= 30, 'REPLICA_CLOCK_SKEW')
    canonical(spec)


def cluster_id(spec):
    validate_spec(spec)
    return identifier('COVENANT-PROVIDER-REPLICATION-0.1', spec)


def config(spec):
    return {'chain_id':cluster_id(spec), 'validators':deepcopy(spec['validators']), 'faults':spec['faults']}


def draft_command(spec, wallet, subject, epoch, operation, parameters, not_before, expires, nonce):
    draft = p.draft_command(p.provider_id(spec['provider']),wallet,subject,epoch,operation,parameters,not_before,expires,nonce)
    draft.update(cluster=cluster_id(spec),label=COMMAND_LABEL,
                 body={'cluster':cluster_id(spec),'command':draft['id'],'provider':draft['command']['provider']})
    return draft


def verify_command(envelope, spec=None):
    c.exact(envelope,'cluster command signature'); c.key(envelope['cluster'])
    command = envelope['command']; cid = p.command_id(command)
    if spec is not None:
        c.need(envelope['cluster'] == cluster_id(spec) and command['provider'] == p.provider_id(spec['provider']), 'REPLICA_COMMAND_CLUSTER')
    c.verify(command['subject'],COMMAND_LABEL,
             {'cluster':envelope['cluster'],'command':cid,'provider':command['provider']},envelope['signature'])
    return command


def encode_transaction(envelope, at):
    verify_command(envelope); c.integer(at)
    raw = canonical(envelope); c.need(len(raw) <= MAX_ENVELOPE_BYTES, 'REPLICA_COMMAND_SIZE')
    text = raw.hex()
    # Native consensus uses an ASCII wire profile. Preserve arbitrary provider
    # Unicode as canonical bytes, split below the native string-size bound.
    return {'at':at, 'payload':[text[i:i+32768] for i in range(0,len(text),32768)]}


def decode_transaction(tx):
    c.exact(tx, 'at payload'); c.integer(tx['at'])
    chunks = tx['payload']
    c.need(type(chunks) is list and 1 <= len(chunks) <= 7 and all(type(x) is str and
           0 < len(x) <= 32768 and len(x)%2 == 0 and re.fullmatch('[0-9a-f]+',x) for x in chunks), 'REPLICA_PAYLOAD')
    raw = bytes.fromhex(''.join(chunks)); c.need(len(raw) <= MAX_ENVELOPE_BYTES, 'REPLICA_COMMAND_SIZE')
    envelope = decode(raw)
    c.need(encode_transaction(envelope,tx['at']) == tx, 'REPLICA_NONCANONICAL_PAYLOAD')
    return envelope


def state_root(state):
    return identifier('COVENANT-REPLICATED-PROVIDER-STATE-0.1', state)


def verify_certificate(spec, entry):
    c.exact(entry, 'block certificate'); b = entry['block']; q = entry['certificate']
    c.exact(b, 'chain height parent txs state_root')
    c.exact(q, 'height round block_id votes')
    c.integer(b['height'],True); c.integer(q['height'],True); c.integer(q['round'])
    c.need(q['round'] < 2**31 and q['height'] == b['height'] and b['chain'] == cluster_id(spec), 'REPLICA_CERTIFICATE_CONTEXT')
    c.key(b['parent']); c.key(b['state_root'])
    bid = c.digest('COVENANT_CHAIN_BLOCK',b)
    c.need(q['block_id'] == bid, 'REPLICA_BLOCK_ID')
    votes = q['votes']; c.need(type(votes) is list and 2*spec['faults']+1 <= len(votes) <= len(spec['validators']), 'REPLICA_QUORUM')
    seen = set()
    for vote in votes:
        c.exact(vote, 'kind body signer signature')
        who = vote['signer']; c.need(type(who) is str and who in spec['validators'] and who not in seen, 'REPLICA_VOTER')
        seen.add(who)
        expected = dict(chain=b['chain'],height=b['height'],round=q['round'],block_id=bid)
        c.need(vote['kind'] == 'precommit' and type(vote['body']) is dict and
               c.canonical(vote['body']) == c.canonical(expected), 'REPLICA_VOTE_CONTEXT')
        c.verify(spec['validators'][who], 'COVENANT_CHAIN_PRECOMMIT', expected, vote['signature'])
    return bid


def apply_block(spec, state, block, height, parent):
    c.exact(block, 'chain height parent txs state_root')
    c.need(type(block['height']) is int and block['height'] == height and block['parent'] == parent and
           block['chain'] == cluster_id(spec), 'REPLICA_BLOCK_CONTEXT')
    c.need(type(block['txs']) is list and len(block['txs']) == 1, 'REPLICA_BLOCK_TRANSACTIONS')
    tx = block['txs'][0]; envelope = decode_transaction(tx); command = verify_command(envelope,spec)
    state, value = p.transition(spec['provider'], state, command, tx['at'], parent)
    c.need(block['state_root'] == state_root(state), 'REPLICA_STATE_ROOT')
    return state, value, command


def verify_history(spec, history, *, minimum_head=p.ZERO):
    """Independent certificate + deterministic replay, never trust a state dump."""
    validate_spec(spec); c.key(minimum_head)
    c.need(type(history) is list and len(history) <= MAX_COMMITS and len(canonical(history)) <= MAX_HISTORY_BYTES,
           'REPLICA_HISTORY_LIMIT')
    state = p.initial_state(spec['provider']); head = p.ZERO; found = minimum_head == p.ZERO; results = {}
    for height, entry in enumerate(history,1):
        bid = verify_certificate(spec,entry)
        state, value, command = apply_block(spec,state,entry['block'],height,head)
        cid = p.command_id(command)
        c.need(cid not in results, 'REPLICA_DUPLICATE_COMMAND')
        results[cid] = {'version':RECEIPT,'cluster':cluster_id(spec),'provider':p.provider_id(spec['provider']),
            'request':cid,'at':entry['block']['txs'][0]['at'],'height':height,'head':bid,'value':value,
            'proof_disclosure':'FULL_PROVIDER_COMMAND_HISTORY_ALL_ACCOUNTS','raw_records_disclosed':True}
        head = bid; found = found or head == minimum_head
    c.need(found, 'REPLICA_CHECKPOINT_MISSING')
    return {'state':state,'head':head,'height':len(history),'results':results}


def verify_receipt(envelope, command, *, spec, minimum_head=p.ZERO, now=None, max_age=None):
    """A historical proof is not a fresh authority claim. Supply fresh command
    nonce and independent now/max_age when freshness is required.
    """
    c.exact(envelope, 'receipt history'); p.validate_command(command)
    verified = verify_history(spec,envelope['history'],minimum_head=minimum_head)
    cid = p.command_id(command); expected = verified['results'].get(cid)
    c.need(expected is not None and canonical(envelope['receipt']) == canonical(expected), 'REPLICA_RECEIPT_MISMATCH')
    c.need(command['provider'] == p.provider_id(spec['provider']), 'REPLICA_PROVIDER_SCOPE')
    if now is not None or max_age is not None:
        c.integer(now); c.integer(max_age)
        c.need(now-max_age <= expected['at'] <= now+spec['max_clock_skew'], 'REPLICA_RECEIPT_STALE')
    return deepcopy(expected)


def _validate_safety(spec, member, safety, verified, protocol=None):
    """Check persisted signing state BEFORE Engine can rewrite or use it."""
    cfg = config if protocol is None else protocol.config
    cluster = cluster_id if protocol is None else protocol.cluster_id
    apply = apply_block if protocol is None else protocol.apply_block
    required = {'config','member','height','round','parent','stage','locked_round','locked_id','valid_round',
                'valid_id','valid_qc','blocks','votes','proposals','signed','round_evidence','commits'}
    c.need(type(safety) is dict and set(safety) == required, 'REPLICA_SAFETY_SHAPE')
    c.need(safety['config'] == c.digest('COVENANT_CHAIN_CONFIG',cfg(spec)) and safety['member'] == member,
           'REPLICA_STORAGE_IDENTITY')
    h,r = safety['height'],safety['round']
    c.need(type(h) is int and h == verified['height']+1 and safety['parent'] == verified['head'], 'REPLICA_SAFETY_HISTORY_MISMATCH')
    c.need(type(r) is int and 0 <= r < 2**31 and safety['stage'] in ('propose','prevote','precommit'), 'REPLICA_SAFETY_ROUND')
    for name in ('blocks','votes','proposals','signed','round_evidence'):
        c.need(type(safety[name]) is dict and len(safety[name]) <= 1000, 'REPLICA_SAFETY_MAP')
    blocks = safety['blocks']
    for bid,block in blocks.items():
        c.need(bid == c.digest('COVENANT_CHAIN_BLOCK',block), 'REPLICA_SAFETY_BLOCK')
        apply(spec,verified['state'],block,h,verified['head'])
    def message(m):
        c.exact(m,'kind body signer signature'); kind = m['kind']; b = m['body']; who = m['signer']
        c.need(kind in ('proposal','prevote','precommit') and type(who) is str and who in spec['validators'], 'REPLICA_SAFETY_MESSAGE')
        c.exact(b,'chain height round block_id block valid_qc' if kind == 'proposal' else 'chain height round block_id')
        c.need(b['chain'] == cluster(spec) and type(b['height']) is int and b['height'] == h and
               type(b['round']) is int and 0 <= b['round'] < 2**31, 'REPLICA_SAFETY_MESSAGE_CONTEXT')
        if b['block_id'] is not None: c.key(b['block_id'])
        c.verify(spec['validators'][who],'COVENANT_CHAIN_'+kind.upper(),b,m['signature'])
        if kind == 'proposal':
            c.need(who == sorted(spec['validators'])[(h-1+b['round'])%len(spec['validators'])] and
                   b['block_id'] == c.digest('COVENANT_CHAIN_BLOCK',b['block']), 'REPLICA_SAFETY_PROPOSER')
            apply(spec,verified['state'],b['block'],h,verified['head'])
            if b['valid_qc']: group(b['valid_qc'],'prevote',b['block_id'],before=b['round'])
            else: c.need(type(b['valid_qc']) is list,'REPLICA_SAFETY_QC')
        return b
    def group(votes,kind,bid,*,before=None,round_=None):
        c.need(type(votes) is list and 2*spec['faults']+1 <= len(votes) <= len(spec['validators']), 'REPLICA_SAFETY_QC')
        seen = set(); rounds = set()
        for v in votes:
            b = message(v)
            c.need(v['kind'] == kind and b['block_id'] == bid and v['signer'] not in seen, 'REPLICA_SAFETY_QC')
            seen.add(v['signer']); rounds.add(b['round'])
        c.need(len(rounds) == 1 and (before is None or next(iter(rounds)) < before) and
               (round_ is None or next(iter(rounds)) == round_), 'REPLICA_SAFETY_QC_ROUND')
    for slot,m in safety['signed'].items():
        b = message(m)
        c.need(m['signer'] == member and b['round'] <= r and slot == f"{h}:{b['round']}:{m['kind']}", 'REPLICA_SAFETY_SIGNED_SLOT')
    for slot,votes in safety['votes'].items():
        c.need(type(votes) is dict and len(votes) <= len(spec['validators']), 'REPLICA_SAFETY_VOTES')
        for who,m in votes.items():
            b = message(m)
            c.need(m['kind'] in ('prevote','precommit') and who == m['signer'] and slot == f"{b['round']}:{m['kind']}", 'REPLICA_SAFETY_VOTE_SLOT')
    for slot,m in safety['proposals'].items():
        b = message(m); c.need(m['kind'] == 'proposal' and slot == str(b['round']), 'REPLICA_SAFETY_PROPOSAL_SLOT')
    for who,m in safety['round_evidence'].items():
        b = message(m); c.need(who == m['signer'] and b['round'] > r, 'REPLICA_SAFETY_ROUND_EVIDENCE')
    for label in ('locked','valid'):
        round_,bid = safety[label+'_round'],safety[label+'_id']
        c.need(type(round_) is int and -1 <= round_ <= r and ((round_ == -1 and bid is None) or
               (round_ >= 0 and type(bid) is str and bid in blocks)), 'REPLICA_SAFETY_LOCK')
    if safety['valid_round'] >= 0:
        group(safety['valid_qc'],'prevote',safety['valid_id'],round_=safety['valid_round'])
    else: c.need(safety['valid_qc'] == [], 'REPLICA_SAFETY_QC')
    c.need(safety['valid_round'] >= safety['locked_round'] and
           (safety['valid_round'] != safety['locked_round'] or safety['valid_id'] == safety['locked_id']), 'REPLICA_SAFETY_LOCK_QUORUM')
    for m in safety['signed'].values():
        b = m['body']
        if m['kind'] == 'precommit' and b['block_id'] is not None:
            c.need(safety['locked_round'] >= b['round'] and
                   (safety['locked_round'] != b['round'] or safety['locked_id'] == b['block_id']), 'REPLICA_SAFETY_SIGNED_LOCK')


def refuse_prior_signing(spec,member,histories,protocol=None):
    """An authentic own vote proves prior use even in an invalid wrapper.

    Absence of such evidence does not prove an unused key. This is an owner
    mistake guard, never permission to reset missing signing storage.
    """
    cfg = config(spec) if protocol is None else protocol.config(spec)
    c.need(type(histories) in (list,tuple) and len(histories)<=len(cfg['validators']),'REPLICA_PEER_HISTORIES')
    for history in histories:
        c.need(type(history) in (list,tuple) and len(history)<=512,'REPLICA_PEER_HISTORIES')
        for entry in history:
            votes = entry.get('certificate',{}).get('votes',[]) if type(entry) is dict and type(entry.get('certificate')) is dict else []
            if type(votes) is not list: continue
            for vote in votes:
                try:
                    c.exact(vote,'kind body signer signature')
                    if vote['signer'] != member: continue
                    body = vote['body']; c.exact(body,'chain height round block_id')
                    c.need(vote['kind']=='precommit' and body['chain']==cfg['chain_id'],'REPLICA_PRIOR_VOTE_CONTEXT')
                    c.integer(body['height'],True); c.integer(body['round']); c.need(body['round']<2**31,'REPLICA_PRIOR_VOTE_CONTEXT')
                    if body['block_id'] is not None: c.key(body['block_id'])
                    c.verify(cfg['validators'][member],'COVENANT_CHAIN_PRECOMMIT',body,vote['signature'])
                except (ValueError,TypeError,KeyError): continue
                raise ValueError('REPLICA_KEY_PREVIOUSLY_SIGNED')


class ProviderReplica:
    """One fixed validator identity with a private, exclusively held journal.

    initialize=True is an explicit owner assertion that this key has NEVER
    signed with missing/replaced storage. It is not disaster recovery.
    No bootstrap or state-dump import can erase a validator's signing floor.
    """
    def __init__(self, directory, spec, member, key, *, clock, base_timeout=0.1,
                 minimum_head=p.ZERO, initialize=False, peer_histories=()):
        validate_spec(spec); c.key(minimum_head)
        c.need(member in spec['validators'] and c.public_key(key) == spec['validators'][member], 'REPLICA_SIGNER')
        c.need(callable(clock) and type(initialize) is bool, 'REPLICA_OWNER_CONFIGURATION')
        self.spec = deepcopy(spec); self.member = member; self.clock = clock
        self.lock = threading.RLock(); self.pending = {}; self.failed = False; self.engine = None
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        c.need(not self.directory.is_symlink() and self.directory.stat().st_mode & 0o077 == 0, 'REPLICA_PRIVATE_DIRECTORY')
        self.owner = None
        try:
            fd = os.open(self.directory/'owner.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
            self.owner = os.fdopen(fd,'r+b')
            try: fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as exc: raise ValueError('REPLICA_ALREADY_OPEN') from exc
            path = self.directory/'consensus'
            exists = Path(str(path)+'.sqlite3').exists()
            c.need(exists or initialize, 'REPLICA_SAFETY_STORAGE_REQUIRED')
            pin = {'cluster':cluster_id(spec),'member':member}
            marker = self.directory/'identity.json'
            if exists:
                c.need(marker.exists() and decode(marker.read_bytes()) == pin, 'REPLICA_STORAGE_IDENTITY')
            else:
                c.need(not marker.exists(), 'REPLICA_SAFETY_STORAGE_MISSING')
                refuse_prior_signing(spec,member,peer_histories)
                atomic_write(marker,canonical(pin),mode=0o600,exclusive=True,follow_symlinks=False)
            db = Path(str(path)+'.sqlite3')
            fd = os.open(db,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600); os.close(fd)
            c.need(db.stat().st_mode & 0o077 == 0, 'REPLICA_PRIVATE_DATABASE')
            self.state = p.initial_state(spec['provider']); self.head = p.ZERO; self.height = 0; self.results = {}
            if exists:
                journal = Journal(path)
                try:
                    stored = journal.load()
                    c.need(stored is not None, 'REPLICA_SAFETY_STORAGE_MISSING')
                    verified = verify_history(spec,journal.log.read(),minimum_head=minimum_head)
                    _validate_safety(spec,member,stored,verified)
                finally: journal.close()
            # Engine callbacks use this independently replayed state only after
            # construction. Startup does not sign or build a proposal.
            self.engine = Engine(path,member,key,config(spec),self._build,self._validate,
                                 base_timeout=base_timeout,proposal_admission=self._admit)
            self._refresh(minimum_head=minimum_head)
            s = self.engine.s
            c.need(type(s['height']) is int and s['height'] == self.height+1 and s['parent'] == self.head,
                   'REPLICA_SAFETY_HISTORY_MISMATCH')
        except BaseException:
            self.close(); raise

    def _healthy(self):
        c.need(not self.failed and self.engine is not None and not self.engine.failed, 'REPLICA_STORAGE_FAILED')

    def _refresh(self, *, minimum_head=p.ZERO):
        self._healthy()
        if self.height == len(self.engine.s['commits']) and minimum_head == p.ZERO: return
        v = verify_history(self.spec,self.engine.committed(),minimum_head=minimum_head)
        self.state,self.head,self.height,self.results = v['state'],v['head'],v['height'],v['results']
        for cid in list(self.pending):
            if cid in self.results: self.pending.pop(cid)

    def _admit(self, block, valid_qc):
        at = block['txs'][0]['at']; now = self.clock(); c.integer(now)
        # A verified earlier prevote quorum permits completion of an already
        # admitted value after a timeout; rechecking its age could deadlock locks.
        c.need(valid_qc or abs(at-now) <= self.spec['max_clock_skew'], 'REPLICA_PROPOSAL_TIME')

    def _validate(self, block, height, parent):
        self._healthy()
        c.need(height == self.height+1 and parent == self.head, 'REPLICA_APPLICATION_FLOOR')
        apply_block(self.spec,self.state,block,height,parent)
        c.need(height <= MAX_COMMITS and len(canonical(self.engine.committed())) + len(canonical(block)) + CERTIFICATE_RESERVE <= MAX_HISTORY_BYTES,
               'REPLICA_HISTORY_LIMIT')
        return True

    def _build(self, height, parent):
        for cid,envelope in list(self.pending.items()):
            now = self.clock(); c.integer(now)
            try:
                state,_ = p.transition(self.spec['provider'],self.state,envelope['command'],now,parent)
                b = dict(chain=cluster_id(self.spec),height=height,parent=parent,
                         txs=[encode_transaction(envelope,now)],state_root=state_root(state))
                self._validate(b,height,parent)
                return b
            except ValueError:
                self.pending.pop(cid,None)
        return None

    def submit(self, envelope):
        with self.lock:
            self._healthy(); envelope = deepcopy(envelope); command = verify_command(envelope,self.spec)
            cid = p.command_id(command)
            if cid in self.results: return self.receipt(command)
            now = self.clock(); c.integer(now)
            p.transition(self.spec['provider'],self.state,command,now,self.head)
            encode_transaction(envelope,now)
            c.need(self.height < MAX_COMMITS and len(canonical(self.engine.committed())) + CERTIFICATE_RESERVE + 2*len(canonical(envelope)) <= MAX_HISTORY_BYTES,
                   'REPLICA_HISTORY_LIMIT')
            c.need(cid in self.pending or len(self.pending) < 128, 'REPLICA_PENDING_LIMIT')
            self.pending[cid] = envelope
            return None

    def tick(self, now):
        with self.lock:
            self._healthy()
            try:
                out = self.engine.tick(now); self._refresh(); return out
            except BaseException:
                if self.engine.failed: self.failed = True
                raise

    def receive(self, message):
        with self.lock:
            self._healthy()
            try:
                out = self.engine.receive(message); self._refresh(); return out
            except BaseException:
                if self.engine.failed: self.failed = True
                raise

    def history(self, start=1):
        with self.lock:
            self._healthy(); c.integer(start,True)
            return deepcopy(self.engine.committed(start=start))

    def receipt(self, command):
        with self.lock:
            self._healthy(); cid = p.command_id(command)
            if cid not in self.results: return None
            # Receipt remains historical. A longer proof may include the client's
            # newer pinned floor; it does not turn the old value into a fresh read.
            r = self.results[cid]
            return {'receipt':deepcopy(r),'history':self.engine.committed()}

    def close(self):
        with self.lock:
            self.failed = True
            if getattr(self,'engine',None) is not None:
                self.engine.journal.close(); self.engine = None
            if getattr(self,'owner',None) is not None:
                self.owner.close(); self.owner = None
