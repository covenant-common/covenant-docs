"""Where every AAP tool and module belongs, ordered by nature.

The engineering order is inspired by Aristotle. Matter is what an agreement is made of, form is what
the agreement is, act is how the promise becomes performance, justice is how a
broken promise is made right, and the polis is how many agreements live
together. The organon holds the instruments beside them. Each level presupposes
the ones below it. AAP Core 1.0 is the organon's core tools plus levels 0 to 3;
level 4 holds the extensions.

Placement orders features for agents, documentation and release. It never
grants authority, never changes a signed meaning and never removes a feature:
every tool and module stays installed and reachable whatever its level.
"""
import argparse
from copy import deepcopy
import hashlib
import json
import re
from functools import lru_cache
from importlib.resources import files

from .crypto import need

PROFILE = 'urn:aap:levels:0.2'
HISTORICAL_PROFILE = 'urn:aap:levels:0.1'
HISTORICAL_REGISTRY_SHA256 = '20dbd77c0f59ac9be460cab0b6fbd799bbe12c24c250efcad6c19911bc262b06'
ORDER = ['ORGANON', 'L0', 'L1', 'L2', 'L3', 'L4']


def validate_registry(data):
    """Validate taxonomy data without interpreting it as authority or execution."""
    need(type(data) is dict and data.get('profile') in (PROFILE, HISTORICAL_PROFILE), 'LEVELS_PROFILE')
    required = {'profile', 'note', 'order', 'core_levels', 'levels', 'categories', 'species',
                'maturity', 'tools', 'module_rules'}
    allowed = required | ({'module_overrides'} if data['profile'] == PROFILE else set())
    need(required <= set(data) <= allowed, 'LEVELS_FIELDS')
    need(type(data['note']) is str and 0 < len(data['note']) <= 4096, 'LEVELS_NOTE')
    need(data['order'] == ORDER and data['core_levels'] == ORDER[:-1], 'LEVELS_ORDER')
    need(type(data['levels']) is list and all(type(r) is dict for r in data['levels']) and
         [r.get('id') for r in data['levels']] == ORDER, 'LEVELS_ORDER')
    for row in data['levels']:
        need(type(row) is dict and set(row) == {'id', 'name', 'cause', 'question', 'scope'} and
             all(type(v) is str and bool(v.strip()) for v in row.values()), 'LEVELS_LEVEL')
    for kind, fields in (('categories', {'id', 'meaning'}), ('species', {'id', 'differentia'})):
        rows = data[kind]
        need(type(rows) is list and 1 <= len(rows) <= 64, 'LEVELS_CATEGORIES')
        need(all(type(r) is dict and set(r) == fields and
                 all(type(v) is str and bool(v.strip()) for v in r.values()) for r in rows), 'LEVELS_CATEGORIES')
        need(len({r['id'] for r in rows}) == len(rows), 'LEVELS_DUPLICATE_CATEGORY')
    need(data['maturity'] == ['experimental', 'beta', 'stable'], 'LEVELS_MATURITY')
    species = {r['id'] for r in data['species']}
    need(type(data['tools']) is dict and len(data['tools']) <= 4096, 'LEVELS_TOOLS')
    for name, row in data['tools'].items():
        need(type(name) is str and re.fullmatch(r'[a-z][a-z0-9_]{0,127}', name) and type(row) is dict
             and set(row) == {'level', 'core', 'maturity', 'species'}, 'LEVELS_TOOL')
        need(row['level'] in ORDER and type(row['core']) is bool and
             row['maturity'] in data['maturity'] and
             (row['species'] is None or type(row['species']) is str and row['species'] in species), 'LEVELS_TOOL')
        need(not row['core'] or row['level'] in data['core_levels'], 'LEVELS_CORE_TOOL')
    need(type(data['module_rules']) is list and 1 <= len(data['module_rules']) <= 256, 'LEVELS_RULE')
    for rule in data['module_rules']:
        need(type(rule) is dict and set(rule) == {'level', 'pattern'} and rule['level'] in ORDER and
             type(rule['pattern']) is str and len(rule['pattern']) <= 8192, 'LEVELS_RULE')
        try:
            re.compile(rule['pattern'])
        except re.error:
            raise ValueError('LEVELS_RULE_PATTERN') from None
    overrides = data.get('module_overrides', {})
    need(type(overrides) is dict and len(overrides) <= 4096, 'LEVELS_OVERRIDES')
    for path, row in overrides.items():
        need(type(path) is str and re.fullmatch(r'[a-z0-9_/]+', path) and type(row) is dict and
             set(row) == {'level', 'reason'} and row['level'] in ORDER and
             type(row['reason']) is str and bool(row['reason'].strip()), 'LEVELS_OVERRIDE')
        need(row['level'] in [r['level'] for r in data['module_rules'] if re.search(r['pattern'], path)],
             'LEVELS_OVERRIDE_NO_MATCH')
    return True


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'LEVELS_DUPLICATE_FIELD')
        value[key] = item
    return value


@lru_cache(maxsize=2)
def _registry(version=PROFILE):
    need(version in (PROFILE, HISTORICAL_PROFILE), 'LEVELS_PROFILE')
    name = 'aap_levels.json' if version == PROFILE else 'aap_levels_0_1.json'
    raw = files(__package__).joinpath('data/' + name).read_bytes()
    need(len(raw) <= 2097152, 'LEVELS_SIZE')
    if version == HISTORICAL_PROFILE:
        need(hashlib.sha256(raw).hexdigest() == HISTORICAL_REGISTRY_SHA256, 'LEVELS_HISTORICAL_BYTES_CHANGED')
    data = json.loads(raw, object_pairs_hook=_unique_object)
    validate_registry(data)
    need(data['profile'] == version, 'LEVELS_PROFILE')
    return data, hashlib.sha256(raw).hexdigest()


def registry(version=PROFILE):
    # A caller must not poison subsequent classification through a cached dict.
    return deepcopy(_registry(version)[0])


@lru_cache(maxsize=1)
def _rules():
    return tuple((rule['level'], re.compile(rule['pattern'])) for rule in _registry()[0]['module_rules'])


def tool_level(name):
    row = _registry()[0]['tools'].get(name)
    return None if row is None else row['level']


def module_level(path):
    """A module path such as covenant_chain/app.py or covenant_chain.app."""
    need(type(path) is str and 0 < len(path) <= 256, 'LEVELS_MODULE')
    text = path[:-3] if path.endswith('.py') else path
    if '/' not in text:
        text = text.replace('.', '/')
    matches = [level for level, pattern in _rules() if pattern.search(text)]
    override = _registry()[0].get('module_overrides', {}).get(text)
    if override is not None:
        need(override['level'] in matches, 'LEVELS_OVERRIDE_NO_MATCH')
        return override['level']
    need(len(set(matches)) <= 1, 'LEVELS_AMBIGUOUS_MODULE: ' + text)
    return matches[0] if matches else None


def core_tools():
    return sorted(name for name, row in registry()['tools'].items() if row['core'])


def summary():
    data = registry()
    counts = {level: 0 for level in data['order']}
    for row in data['tools'].values():
        counts[row['level']] += 1
    return {'profile': PROFILE, 'order': data['order'], 'core_levels': data['core_levels'],
            'registry_sha256': _registry()[1], 'historical_profile': HISTORICAL_PROFILE,
            'explicit_cross_level_choices': len(data['module_overrides']),
            'categories': data['categories'], 'species': data['species'],
            'facets': ['who', 'what', 'which', 'where', 'when', 'why', 'how'],
            'adoption': 'CLASSIFICATION_IS_NOT_AUTHORITY_OR_INTERPRETATION',
            'tools_per_level': counts, 'core_tools': core_tools(),
            'levels': [{k: level[k] for k in ('id', 'name', 'cause', 'question')} for level in data['levels']],
            'note': data['note']}


def main(argv=None):
    parser = argparse.ArgumentParser(description='Show where an AAP tool or module belongs.')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--tool', help='An MCP tool name, for example covenant_draft.')
    group.add_argument('--module', help='A module path, for example covenant_chain/app.py.')
    args = parser.parse_args(argv)
    if args.tool:
        result = {'tool': args.tool, 'level': tool_level(args.tool)}
    elif args.module:
        result = {'module': args.module, 'level': module_level(args.module)}
    else:
        result = summary()
    print(json.dumps(result, indent=1, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
