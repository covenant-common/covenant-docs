"""Freshness labels, timely issuance and the refusal guide for offline trades.

A disconnected recipient checks evidence it was handed, against its own clock
and its own maximum accepted age. It can never learn a revocation it has not
received, so every label says when the status snapshot was dated and how old
it is. Large payments are refused on stale evidence; small ones are limited.

A note that arrives after its spending validity but inside its presentation
grace period needs independent proof that it existed in time: co-signatures
from a group the recipient adopted, or covenant-time-evidence/0.1. The
buyer's own timestamp is a claim, never that proof.

Every other offline_trade_* module raises through need() here, so each refusal
code has plain words, a next step and a reference entry (explain).
"""
from copy import deepcopy

from . import crypto as c, offline_trade as trade

POLICY_VERSION = 'covenant-offline-trade-recipient-policy/0.1'
GROUP_VERSION = 'covenant-offline-trade-group/0.1'
COSIGN_VERSION = 'covenant-offline-trade-cosign/0.1'
COSIGN_LABEL = 'COVENANT-OFFLINE-TRADE-COSIGN-0.1'
GUIDE = 'docs/OFFLINE_TRADE.html'
ROLES = ('PERMISSION', 'QUALIFICATION')
PORTABLE_TRUST = 'covenant-portable-trust/0.1'
MAX_GROUPS = 16
MAX_SKEW = 3600

# What to do next for every refusal the offline-trade extensions raise.
REMEDIATION = {
    'TRADE_CHECK_FAILED': 'Inspect the named check in the reference entry, fix the input and try again.',
    'TRADE_POLICY': 'Rebuild your recipient policy with recipient_policy(); ages, limits and groups must be bounded integers and adopted keys.',
    'TRADE_GROUP': 'Adopt a group with distinct member keys and a threshold between one and the number of members.',
    'TRADE_COSIGN': 'Ask the co-signer for a fresh co-signature over this exact trade ID and slot.',
    'TRADE_EVIDENCE_REVOKED': 'Do not deliver. The status snapshot says the permission or credential is revoked or suspended.',
    'TRADE_EVIDENCE_STALE': 'Ask for a newer status snapshot, or reduce the amount below your high-risk limit.',
    'TRADE_STALE_LIMIT': 'You already hold the most you accept on old evidence from this buyer. Wait for fresh status or reconnect.',
    'TRADE_SNAPSHOT_ROLLBACK': 'Refuse the older snapshot. You have already seen a newer one from the same issuer.',
    'TRADE_NOT_YET_VALID': "Check both clocks. The note says it was issued later than your clock allows.",
    'TRADE_TIMELY_ISSUANCE_UNPROVEN': 'The note arrived after its spending validity. Ask for co-signatures or time evidence that it existed in time.',
    'TRADE_ISSUED_TOO_LATE': 'Refuse the note. Its own evidence shows it was issued after its spending validity ended.',
    'TRADE_PRESENTATION_EXPIRED': 'Refuse the note. Its presentation grace period has ended; settle any claim through the dispute procedure.',
    'TRADE_SUCCESSOR_REQUIRED': 'Use a covenant-offline-trade/0.2 record (offline_trade.declare_risk) for this check.',
    'TRADE_RISK_WORDS': 'The risk words in the record are not exactly the text generated from its risk terms. Regenerate the record with offline_trade.declare_risk; never edit the words by hand.',
    'TRADE_RISK_TERMS': 'The declared risk is missing a parameter its mode needs, names an unknown backing or loss rule, or has a time before issue. Give the parameters the mode needs (see the risk table) with times on or after issue.',
    'TRADE_RISK_DRAFT_ONLY': 'The risk can be declared only on an unsigned 0.1 draft, and this trade is signed, has events or has another version. State the risk on the unsigned 0.1 draft, before anyone assents.',
    'TRADE_ATTACHMENTS': 'The attachments are not a list, or there are more than the documented maximum. Carry at most the documented number of attachments in a list.',
    'TRADE_ATTACHMENT_KIND': 'An attachment has an unknown kind, or its value is not an object or a list. Use one of the documented attachment kinds with an object or list value.',
    'TRADE_ATTACHMENT_COUNT': 'There are more attachments of one kind than that kind allows. Remove extra attachments of that kind; each kind has its own bound.',
    'TRADE_ATTACHMENT_ORDER': 'The attachments repeat or are not in canonical order. Rebuild the attachments with offline_trade.attach so they stay unique and in canonical order.',
    'TRADE_ATTACHMENTS_0_2_ONLY': 'This record is not version covenant-offline-trade/0.2, and only 0.2 records carry attachments. Make the trade as a 0.2 record; a 0.1 record keeps its exact shape.',
    'TRADE_BACKING_PROOF': 'Ask for a ledger proof certified by the committee of the chain you adopted.',
    'TRADE_BACKING_MISMATCH': 'The proof is for another escrow, device, resource or amount. Ask for the proof of the reserved book.',
    'TRADE_BACKING_CLOSED': 'The escrow book is not open. Treat the note as unpaid and use the dispute procedure.',
    'TRADE_CHAIN_NOT_ADOPTED': 'Adopt that chain by pinning its genesis before relying on its escrow.',
    'TRADE_INSTRUCTION': 'Ask the buyer for the signed spend instruction of this exact trade.',
    'TRADE_INSTRUCTION_SIGNATURE': 'The spend instruction is not signed by the reserved device. Refuse it.',
    'TRADE_COLLATERAL_EXCEEDED': 'You have accepted as much as this collateral backs. Refuse further notes on it until you reconcile.',
    'TRADE_CREDIT_LINE': "Ask for the issuer's signed credit line that the trade names.",
    'TRADE_CREDIT_LIMIT': "The note exceeds the issuer's line or your own acceptance limit for that issuer.",
    'TRADE_ISSUER_NOT_ADOPTED': 'Set an acceptance limit for this issuer in your policy before accepting its credit.',
    'TRADE_QUORUM_UNCONFIRMED': 'Collect co-signatures from the adopted quorum while its members can reach each other.',
    'TRADE_QUORUM_GROUP': "Adopt the quorum group the trade names; its size and threshold must match the signed terms.",
    'TRADE_PROVIDER_RECORD': 'Rebuild the provider collection record with the provider, reference, amount, currency and time.',
    'TRADE_PROVIDER_LIMIT': 'Above the provider offline maximum: collect online or split nothing; ask for another payment method.',
    'TRADE_PROVIDER_OUTCOME': 'Supply the provider outcome exactly as observed after reconnection.',
    'TRADE_HEAD': 'Ask the device for a head statement signed by its own key.',
    'TRADE_NOT_CONFLICTING': 'These records do not share a spend slot; nothing needs resolving.',
    'TRADE_NOT_BOND_BACKED': 'Only notes backed by an offline_value escrow can be slashed; open a dispute instead.',
    'TRADE_DISPUTE': 'Rebuild the dispute record with two distinct trades, a reason and a time.',
    'TRADE_INBOX_STORAGE': 'Use a new private directory owned by this user (mode 0700); do not point the inbox at a shared or linked path.',
    'TRADE_INBOX_OWNER': 'Open the inbox with the same owner key it was created with.',
    'TRADE_INBOX_SCHEMA': 'This inbox was written by another version. Open it with a matching release or restore a backup.',
    'TRADE_INBOX_FULL': 'Reconcile and archive settled trades, or open a new inbox for new trades.',
    'TRADE_INBOX_ROLLED_BACK': 'The inbox is older than your retained checkpoint. Restore the newest copy or recover from peers.',
    'TRADE_INBOX_HISTORY': 'The inbox history was altered. Restore a backup and compare it with your retained checkpoint.',
    'TRADE_INBOX_CLOSED': 'Open the inbox again before using it.',
    'TRADE_UNKNOWN': 'Receive the trade into this inbox first.',
    'TRADE_NOT_PAYEE': 'Only the supplier named in the trade can accept it in this inbox.',
    'TRADE_SLOT_TAKEN': 'Refuse the second note: another note already uses this spend slot. Raise a dispute if you were shown both.',
    'TRADE_HISTORY_FORK': 'This trade history differs from the copy already saved, so the two have split. Keep both copies as proof and settle which one the parties signed.',
    'TRADE_SETTLEMENT_LEG': 'Install an owner settlement callable that returns a status for one request.',
    'TRADE_DEVICE_RECOVERY_REQUIRED': 'Collect head statements from peers with recover() before this device issues again.',
    'TRADE_DEVICE_ROLLED_BACK': 'This device state is older than its retained checkpoint. Recover from peers before issuing.',
    'TRADE_DEVICE_KEY': 'Use the device key this log was created for.',
    'TRADE_BACKUP_PATH': 'Choose a new file path in an existing private directory.',
    'TRADE_CLOCK_ROLLBACK': 'Check the device clock; it is earlier than a time this store already recorded.',
}
# What happened, in plain words, for the same codes.
MEANING = {
    'TRADE_EVIDENCE_REVOKED': 'The permission or credential is revoked or suspended in the status snapshot.',
    'TRADE_EVIDENCE_STALE': 'The status snapshot is older than your maximum accepted age, and the amount is high risk.',
    'TRADE_STALE_LIMIT': 'Accepting this would exceed your limit for trades checked only against old status.',
    'TRADE_SNAPSHOT_ROLLBACK': 'An older status snapshot was shown after a newer one.',
    'TRADE_TIMELY_ISSUANCE_UNPROVEN': 'Only the sender says the note was issued in time.',
    'TRADE_ISSUED_TOO_LATE': 'The note was issued after its spending validity ended.',
    'TRADE_PRESENTATION_EXPIRED': 'The note arrived after its presentation grace period.',
    'TRADE_COLLATERAL_EXCEEDED': 'The notes you hold on this collateral would exceed what backs them.',
    'TRADE_SLOT_TAKEN': 'Two different notes claim the same spend slot.',
    'TRADE_INBOX_ROLLED_BACK': 'The newest local checkpoint is missing from this inbox.',
    'TRADE_DEVICE_RECOVERY_REQUIRED': 'The device may have issued notes it no longer remembers.',
}
# Codes where trying again later, unchanged, can succeed.
RETRY_HELPS = frozenset({'TRADE_EVIDENCE_STALE', 'TRADE_STALE_LIMIT', 'TRADE_QUORUM_UNCONFIRMED',
                         'TRADE_TIMELY_ISSUANCE_UNPROVEN', 'TRADE_COLLATERAL_EXCEEDED', 'TRADE_INBOX_FULL',
                         'TRADE_DEVICE_RECOVERY_REQUIRED'})


class TradeError(ValueError):
    """A refusal with a stable code; REMEDIATION holds its next step."""
    def __init__(self, code):
        super().__init__(code)
        self.code = code
        self.fix = REMEDIATION.get(code, REMEDIATION['TRADE_CHECK_FAILED'])


def need(ok, code):
    if not ok:
        raise TradeError(code)


def explain(code):
    """Code, what happened, what to do next, whether retrying helps and the reference entry."""
    need(type(code) is str and 0 < len(code) <= 96, 'TRADE_CHECK_FAILED')
    known = code in REMEDIATION
    return {'code': code,
            'happened': MEANING.get(code) or 'The input did not pass the check named %s.' % code,
            'fix': REMEDIATION.get(code, REMEDIATION['TRADE_CHECK_FAILED']),
            'retry_helps': code in RETRY_HELPS,
            'reference': GUIDE + '#' + code.lower().replace('_', '-') if known else GUIDE + '#refusals'}


def when(at):
    """Seconds since 1970 as numeric UTC text."""
    return trade._when(at)


def age_words(seconds):
    if seconds < 60:
        return '%d s' % seconds
    if seconds < 3600:
        return '%d min' % (seconds // 60)
    if seconds < 86400:
        minutes = seconds % 3600 // 60
        return '%d h' % (seconds // 3600) + (' %d min' % minutes if minutes else '')
    hours = seconds % 86400 // 3600
    return '%d d' % (seconds // 86400) + (' %d h' % hours if hours else '')


def _bounded(value, maximum):
    return type(value) is int and 0 <= value <= maximum


def group(name, members, threshold):
    """A co-signing group the recipient adopts: witnesses, or a local validator quorum."""
    value = {'version': GROUP_VERSION, 'name': name, 'members': sorted(members) if type(members) is list else members,
             'threshold': threshold}
    group_id(value)
    return value


def group_id(value):
    need(type(value) is dict and set(value) == {'version', 'name', 'members', 'threshold'} and
         value['version'] == GROUP_VERSION, 'TRADE_GROUP')
    need(type(value['name']) is str and 0 < len(value['name']) <= 64 and value['name'].isascii() and
         value['name'].isprintable(), 'TRADE_GROUP')
    members = value['members']
    need(type(members) is list and 1 <= len(members) <= 32 and members == sorted(set(members)), 'TRADE_GROUP')
    for member in members:
        need(type(member) is str and c.HEX.fullmatch(member) is not None, 'TRADE_GROUP')
        c.verification_key(member)
    need(type(value['threshold']) is int and 1 <= value['threshold'] <= len(members), 'TRADE_GROUP')
    return c.digest('COVENANT-OFFLINE-TRADE-GROUP-0.1', value)


def recipient_policy(*, owner, max_age, high_risk_amount, stale_limit, require=(), skew=300,
                     groups=(), issuer_limits=None):
    """The recipient's own acceptance rules; nothing in a received trade changes them."""
    value = {'version': POLICY_VERSION, 'owner': owner, 'max_age': deepcopy(max_age),
             'require': sorted(require), 'high_risk_amount': high_risk_amount, 'stale_limit': stale_limit,
             'skew': skew, 'groups': {group_id(g): deepcopy(g) for g in groups},
             'issuer_limits': deepcopy(issuer_limits or {})}
    check_policy(value)
    return value


def check_policy(value):
    need(type(value) is dict and set(value) == {'version', 'owner', 'max_age', 'require', 'high_risk_amount',
         'stale_limit', 'skew', 'groups', 'issuer_limits'} and value['version'] == POLICY_VERSION, 'TRADE_POLICY')
    need(type(value['owner']) is str and c.HEX.fullmatch(value['owner']) is not None, 'TRADE_POLICY')
    c.verification_key(value['owner'])
    ages = value['max_age']
    need(type(ages) is dict and set(ages) == set(ROLES) and
         all(_bounded(ages[r], 30 * 86400) for r in ROLES), 'TRADE_POLICY')
    need(type(value['require']) is list and set(value['require']) <= set(ROLES) and
         value['require'] == sorted(set(value['require'])), 'TRADE_POLICY')
    for name in ('high_risk_amount', 'stale_limit'):
        need(_bounded(value[name], 2**53 - 1), 'TRADE_POLICY')
    need(_bounded(value['skew'], MAX_SKEW), 'TRADE_POLICY')
    groups = value['groups']
    need(type(groups) is dict and len(groups) <= MAX_GROUPS and
         all(group_id(g) == ref for ref, g in groups.items()), 'TRADE_POLICY')
    limits = value['issuer_limits']
    need(type(limits) is dict and len(limits) <= 64, 'TRADE_POLICY')
    for issuer, limit in limits.items():
        need(type(issuer) is str and c.HEX.fullmatch(issuer) is not None and _bounded(limit, 2**53 - 1), 'TRADE_POLICY')
    return c.digest('COVENANT-OFFLINE-TRADE-RECIPIENT-POLICY-0.1', value)


# Status snapshots -------------------------------------------------------------

def _label(role, subject, status, issuer, sequence, dated, expires, now, limit, profile):
    age = max(0, now - dated) if dated is not None else None
    expired = expires is not None and now >= expires
    fresh = status in ('ACTIVE', 'NOT_REVOKED') and age is not None and age <= limit and not expired
    noun = 'permission' if role == 'PERMISSION' else 'credential'
    if dated is None:
        words = '%s checked at %s; no readable status snapshot; status unknown' % (noun, when(now))
    else:
        words = ('%s checked at %s; %s status snapshot dated %s (sequence %d); age %s; limit %s: %s'
                 % (noun, when(now), noun, when(dated), sequence, age_words(age), age_words(limit),
                    'status ' + status if status not in ('ACTIVE', 'NOT_REVOKED') else
                    'expired' if expired else 'fresh' if fresh else 'too old'))
    return {'role': role, 'subject': subject, 'profile': profile, 'status': status, 'issuer': issuer,
            'sequence': sequence, 'checked_at': now, 'dated': dated, 'age': age, 'limit': limit,
            'fresh': fresh, 'words': words}


def _qualification(bundle, now, limit, accepted):
    """Codex's agent-accreditation presentations, checked against the recipient's adopted policy."""
    from . import agent_accreditation as accreditation
    terms = bundle['terms']; reference = terms['policy']['credential_reference']
    rows = []
    for presentation in trade.attached(bundle, 'PRESENTATION'):
        if set(presentation) != {'credential', 'snapshot', 'holder', 'signature'}:
            continue
        try:
            accreditation.export_presentation(presentation)
        except ValueError:
            continue
        if accreditation.credential_id(presentation['credential']) != reference:
            continue
        snapshot = presentation['snapshot']['status']
        cid = reference
        status = snapshot['entries'].get(cid, 'UNKNOWN')
        if accepted is not None and accreditation.policy_id(accepted) != terms['policy']['credential_policy']:
            status = 'POLICY_MISMATCH'
        elif accepted is not None:
            relaxed = dict(accepted, maximum_status_age=30 * 86400, maximum_presentation_age=30 * 86400)
            try:
                checked = accreditation.inspect_presentation(presentation, relaxed, nonce=trade.terms_id(bundle),
                                                             now=now, offline=True)
                status = checked['status']
            except ValueError as error:
                code = str(error)
                status = (code.rsplit('_', 1)[-1] if code.startswith('ACCREDITATION_STATUS_') and
                          code.rsplit('_', 1)[-1] in ('SUSPENDED', 'REVOKED', 'UNKNOWN') else
                          'EXPIRED' if code == 'ACCREDITATION_STATUS_STALE' else 'UNVERIFIED')
        else:
            status = 'UNVERIFIED'
        rows.append(_label('QUALIFICATION', cid, status, snapshot['issuer'], snapshot['sequence'],
                           snapshot['issued_at'], snapshot['expires_at'], now, limit,
                           accreditation.STATUS_VERSION))
    return rows


def _permission(bundle, now, limit, roots):
    """A portable-trust mandate chain and its root's signed revocation history."""
    from . import portable_trust
    terms = bundle['terms']; reference = terms['policy']['authority_reference']
    rows = []
    for value in trade.attached(bundle, 'AUTHORITY'):
        if type(value) is not dict or value.get('profile') != PORTABLE_TRUST:
            continue
        if set(value) != {'profile', 'root', 'records', 'revocations', 'action', 'resource', 'audience', 'usage'}:
            continue
        root, history = value['root'], value['revocations']
        if root not in roots or type(history) is not list or not history:
            continue
        try:
            last = history[-1]['body']
            # Verify signatures and the append-only chain at the snapshot's own
            # time, then judge its age against the recipient's real clock.
            checked = portable_trust.check_capability(
                value['records'], root, terms['parties']['buyer'], value['action'], value['resource'],
                value['audience'], value['usage'], last['issued_at'], revocation_history=history)
        except (ValueError, KeyError, TypeError):
            continue
        unit, quantity = terms['resource']['unit'], terms['resource']['quantity']
        if checked['capability'] != reference or value['usage'] != {unit: quantity}:
            continue
        current = all(r['body']['not_before'] <= now < r['body']['expires'] for r in value['records'])
        status = 'REVOKED' if checked['revoked'] else 'NOT_REVOKED' if current else 'EXPIRED'
        rows.append(_label('PERMISSION', reference, status, root, last['sequence'], last['issued_at'],
                           last['expires'], now, limit, PORTABLE_TRUST))
    return rows


def _owner_read(bundle, now, policy, readers):
    rows = []
    for kind, role in (('AUTHORITY', 'PERMISSION'), ('PRESENTATION', 'QUALIFICATION')):
        for value in trade.attached(bundle, kind):
            profile = value.get('profile') if type(value) is dict else None
            if profile is None or profile == PORTABLE_TRUST or profile not in readers:
                continue
            try:
                read = readers[profile](deepcopy(value), {'trade': trade.terms_id(bundle), 'role': role, 'now': now})
            except (ValueError, KeyError, TypeError):
                read = None
            if type(read) is not dict or set(read) != {'subject', 'issuer', 'sequence', 'issued_at', 'expires_at', 'status'}:
                rows.append(_label(role, None, 'UNREADABLE', None, 0, None, None, now, policy['max_age'][role], profile))
                continue
            ok = (type(read['subject']) is str and type(read['issuer']) is str and
                  all(_bounded(read[k], 2**53 - 1) for k in ('sequence', 'issued_at', 'expires_at')) and
                  read['status'] in ('ACTIVE', 'NOT_REVOKED', 'SUSPENDED', 'REVOKED', 'UNKNOWN'))
            if not ok:
                rows.append(_label(role, None, 'UNREADABLE', None, 0, None, None, now, policy['max_age'][role], profile))
                continue
            rows.append(_label(role, read['subject'][:128], read['status'], read['issuer'][:128], read['sequence'],
                               read['issued_at'], read['expires_at'], now, policy['max_age'][role], profile))
    return rows


def assess(bundle, *, now, policy, accreditation=None, authority_roots=(), readers=None, floors=None):
    """Label every status snapshot carried by a trade, against the recipient's clock and age limit.

    accreditation is the recipient's adopted agent-accreditation policy;
    authority_roots are portable-trust roots it adopted; readers maps other
    snapshot profiles to owner-installed callables (a plain interface for status
    services built elsewhere). floors maps 'profile issuer' to the highest
    sequence already accepted and refuses a lower one.
    """
    check_policy(policy); c.integer(now); trade.terms_id(bundle)
    readers = readers or {}
    need(type(readers) is dict and all(callable(r) for r in readers.values()), 'TRADE_POLICY')
    need(type(authority_roots) in (list, tuple, set, frozenset), 'TRADE_POLICY')
    labels = []
    terms = bundle['terms']['policy']
    if terms['credential_reference'] is not None:
        labels += _qualification(bundle, now, policy['max_age']['QUALIFICATION'], accreditation)
    if terms['authority_reference'] is not None:
        labels += _permission(bundle, now, policy['max_age']['PERMISSION'], set(authority_roots))
    labels += _owner_read(bundle, now, policy, readers)
    floors = dict(floors or {})
    for row in labels:
        if row['dated'] is None:
            continue
        slot = '%s %s' % (row['profile'], row['issuer'])
        need(row['sequence'] >= floors.get(slot, 0), 'TRADE_SNAPSHOT_ROLLBACK')
        floors[slot] = max(floors.get(slot, 0), row['sequence'])
    # The recipient's own policy decides which roles it relies on; other carried
    # evidence is labelled for information, and a revocation in it still refuses.
    needed = set(policy['require'])
    missing = sorted(role for role in needed if not any(r['role'] == role and r['dated'] is not None for r in labels))
    for role in missing:
        labels.append(_label(role, None, 'MISSING', None, 0, None, None, now, policy['max_age'][role], None))
    revoked = any(r['status'] in ('REVOKED', 'SUSPENDED') for r in labels)
    fresh = all(r['fresh'] for r in labels if r['role'] in needed) and not missing
    state = 'REVOKED' if revoked else 'FRESH' if fresh else 'STALE'
    return {'state': state, 'labels': labels, 'summary': '; '.join(r['words'] for r in labels) or
            'no permission or credential evidence is required by this trade',
            'floors': floors, 'current_global_status': 'UNKNOWN',
            'limit': 'AN_ISOLATED_DEVICE_CANNOT_LEARN_A_REVOCATION_IT_HAS_NOT_RECEIVED'}


def decide(assessment, *, amount, policy, stale_exposure=0):
    """ACCEPT on fresh evidence; LIMITED below the high-risk amount; otherwise a refusal."""
    check_policy(policy); c.integer(amount); c.integer(stale_exposure)
    need(assessment['state'] != 'REVOKED', 'TRADE_EVIDENCE_REVOKED')
    if assessment['state'] == 'FRESH':
        return {'decision': 'ACCEPT', 'words': 'evidence is fresh'}
    need(amount < policy['high_risk_amount'], 'TRADE_EVIDENCE_STALE')
    need(stale_exposure + amount <= policy['stale_limit'], 'TRADE_STALE_LIMIT')
    return {'decision': 'LIMITED', 'words': 'evidence is not fresh; accepted only up to %d in total on old evidence'
            % policy['stale_limit']}


# Timely issuance ----------------------------------------------------------------

def cosign(signer_key, *, trade_id, slot, seen_at):
    """A witness or quorum member says it saw this trade, for this slot, by its own clock."""
    c.key(trade_id); c.integer(seen_at)
    body = {'version': COSIGN_VERSION, 'trade': trade_id, 'slot': trade.ZERO if slot is None else slot,
            'signer': c.public_key(signer_key), 'seen_at': seen_at}
    c.key(body['slot'])
    return {**body, 'signature': c.sign(signer_key, COSIGN_LABEL, body)}


def check_cosign(record):
    need(type(record) is dict and set(record) == {'version', 'trade', 'slot', 'signer', 'seen_at', 'signature'} and
         record['version'] == COSIGN_VERSION, 'TRADE_COSIGN')
    body = {k: v for k, v in record.items() if k != 'signature'}
    try:
        c.key(record['trade']); c.key(record['slot']); c.integer(record['seen_at'])
        c.verify(record['signer'], COSIGN_LABEL, body, record['signature'])
    except ValueError:
        raise TradeError('TRADE_COSIGN') from None
    return body


def confirmations(bundle, group_value):
    """Valid co-signatures by distinct members, excluding the trade's own parties."""
    gid = group_id(group_value); ref = trade.terms_id(bundle); slot = trade.slot_id(bundle) or trade.ZERO
    parties = set(x for x in bundle['terms']['parties'].values() if x is not None)
    seen = {}
    for record in trade.attached(bundle, 'COSIGN'):
        try:
            body = check_cosign(record)
        except TradeError:
            continue
        if (body['trade'] == ref and body['slot'] == slot and body['signer'] in group_value['members'] and
                body['signer'] not in parties):
            seen[body['signer']] = min(seen.get(body['signer'], body['seen_at']), body['seen_at'])
    return gid, dict(sorted(seen.items()))


def issued_by(bundle, *, groups=(), time_policies=()):
    """The earliest time the trade provably existed, from adopted co-signers or time evidence.

    With k required co-signers the bound is the k-th smallest of their times,
    so fewer than k members claiming an early time cannot move it.
    """
    candidates = []
    for value in groups:
        gid, seen = confirmations(bundle, value)
        times = sorted(seen.values())
        if len(times) >= value['threshold']:
            candidates.append((times[value['threshold'] - 1], 'COSIGNED', gid, sorted(seen)))
    if time_policies:
        from . import time_evidence
        for evidence in trade.attached(bundle, 'TIME_EVIDENCE'):
            for adopted in time_policies:
                if type(evidence) is not dict or evidence.get('subject') != trade.terms_id(bundle):
                    continue
                try:
                    if evidence.get('policy') != time_evidence.policy_id(adopted):
                        continue
                    result = time_evidence.assess(evidence, adopted)
                except ValueError:
                    continue
                if result['status'] == 'INTERVAL' and result['not_after'] is not None:
                    candidates.append((result['not_after'], 'TIME_EVIDENCE', result['policy'], result['agreeing']))
    if not candidates:
        return {'existed_by': None, 'basis': 'SENDER_CLAIM_ONLY', 'source': None, 'signers': [],
                'sender_timestamp_proves_timely_spend': False}
    at, basis, source, signers = min(candidates)
    return {'existed_by': at, 'basis': basis, 'source': source, 'signers': signers,
            'sender_timestamp_proves_timely_spend': False}


def presentation(bundle, *, at, existed_by, skew=300):
    """Spending validity is kept separate from the presentation grace period.

    Inside spending validity the note is on time. After it, and inside the grace
    period, it is accepted only with independent proof that it existed before
    spending validity ended. After the grace period it is refused.
    """
    trade.terms_id(bundle); c.integer(at); need(_bounded(skew, MAX_SKEW), 'TRADE_POLICY')
    w = bundle['terms']['windows']
    need(at + skew >= w['issued_at'], 'TRADE_NOT_YET_VALID')
    if at < w['spend_until']:
        return {'status': 'ON_TIME', 'words': 'arrived %s, inside its spending validity (until %s)'
                % (when(at), when(w['spend_until']))}
    need(at <= w['redeem_until'], 'TRADE_PRESENTATION_EXPIRED')
    need(existed_by is not None, 'TRADE_TIMELY_ISSUANCE_UNPROVEN')
    need(existed_by < w['spend_until'], 'TRADE_ISSUED_TOO_LATE')
    return {'status': 'LATE_WITHIN_GRACE',
            'words': 'arrived %s, after its spending validity (%s) but inside its presentation grace period '
                     '(until %s); independent proof shows it existed by %s'
                     % (when(at), when(w['spend_until']), when(w['redeem_until']), when(existed_by))}


def describe():
    return {'version': POLICY_VERSION, 'group': GROUP_VERSION, 'cosign': COSIGN_VERSION, 'roles': list(ROLES),
            'built_in_snapshots': ['covenant-agent-accreditation-status/0.1', PORTABLE_TRUST],
            'owner_readers': 'PLAIN_CALLABLE_PER_PROFILE', 'timely_issuance': ['COSIGNED', 'TIME_EVIDENCE'],
            'sender_timestamp_alone': 'NOT_PROOF', 'current_global_status': 'UNKNOWN',
            'refusal_codes': len(REMEDIATION), 'guide': GUIDE, 'execution_authorized': False}
