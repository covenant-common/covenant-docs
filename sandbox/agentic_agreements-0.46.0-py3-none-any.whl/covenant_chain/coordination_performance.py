"""Caller-maintained nonmonetary checklist; never a performance adjudicator.

This draft view pins assertions and evidence references. Naming an exact party
is not authentication, and even an adopted proof never establishes discharge.
"""
from copy import deepcopy


def review(rows, agreements, evidence_rows, evidence_review):
    from .coordination_review import _attempt, _fields, _name, _text, _hash, _digest, canonical
    from .crypto import need
    known={a['id']:a for a in agreements if a.get('status')=='VERIFIED'}
    sources={e['id']:e for e in evidence_rows}
    checked={e['id']:e for e in evidence_review.get('items',[])}

    def evidence(ref, agreement):
        _fields(ref,('kind','id','expected_hash'),('kind','id','expected_hash'))
        _text(ref['id']);_hash(ref['expected_hash'])
        need(ref['kind'] in ('DELIVERY','PROOF','REFERENCE'),'REVIEW_PERFORMANCE_EVIDENCE_KIND')
        out={**deepcopy(ref),'verified':False,'status':'UNKNOWN','world_truth':'NOT_ESTABLISHED'}
        if ref['kind']=='DELIVERY':
            deliveries=agreement.get('lifecycle',{}).get('deliveries',[])
            matches=[d for d in deliveries if d['content_cid']==ref['id']]
            if matches:
                out['status']='SIGNED_DELIVERY_REFERENCE_MATCH' if any(d['content_hash']==ref['expected_hash'] for d in matches) else 'EVIDENCE_PIN_MISMATCH'
                out['basis']='DELIVERY_SIGNATURE_CLAIM; CONTENT_NOT_FETCHED_OR_PERFORMANCE_VERIFIED'
        elif ref['kind']=='PROOF':
            source=sources.get(ref['id']);check=checked.get(ref['id'],{})
            if source is not None:
                if _digest(source)!=ref['expected_hash']:out['status']='EVIDENCE_PIN_MISMATCH'
                elif source.get('agreement')!=agreement['id']:out['status']='EVIDENCE_AGREEMENT_MISMATCH'
                elif check.get('verified') is True:out.update(status='ADOPTED_PROOF_VERIFIED',verified=True)
                else:out['status']='UNKNOWN; PROOF_NOT_VERIFIED'
            out['basis']='EXACT_PROOF_ROW_HASH; ADOPTED_VERIFIER_SCOPE_ONLY'
        else:out['basis']='CALLER_REFERENCE_ONLY; NOT_FETCHED_OR_VERIFIED'
        return out

    def item(row):
        _fields(row,('id','agreement','label','responsible_role','required_roles','assertions'),('id','agreement','label','responsible_role','required_roles','assertions'))
        _name(row['id']);_text(row['agreement']);_text(row['label']);_text(row['responsible_role'])
        need(type(row['assertions']) is list and len(row['assertions'])<=64,'REVIEW_PERFORMANCE_ASSERTIONS')
        agreement=known.get(row['agreement'])
        need(agreement is not None,'REVIEW_PERFORMANCE_AGREEMENT_NOT_VERIFIED')
        parties=agreement['parties'];roles=row['required_roles']
        need(type(roles) is list and 1<=len(roles)<=16 and all(type(r) is str and r in parties for r in roles) and len(set(roles))==len(roles),'REVIEW_PERFORMANCE_REQUIRED_ROLES')
        need(row['responsible_role'] in parties,'REVIEW_PERFORMANCE_RESPONSIBLE_ROLE')
        assertions=[];states=set();seen=set();invalid=False
        for assertion in row['assertions']:
            _fields(assertion,('agreement','obligation','role','identity','status','evidence'),('agreement','obligation','role','identity','status','evidence'))
            _text(assertion['role']);need(assertion['status'] in ('OPEN','FULFILLED','DISPUTED','UNKNOWN'),'REVIEW_PERFORMANCE_ASSERTION_STATUS')
            need(type(assertion['evidence']) is list and len(assertion['evidence'])<=64,'REVIEW_PERFORMANCE_EVIDENCE')
            # Check the claim's own target before attributing it to this duty.
            target=assertion['agreement']==row['agreement'] and assertion['obligation']==row['id']
            party=assertion['role'] in parties and canonical(assertion['identity'])==canonical(parties[assertion['role']])
            valid=target and party;invalid|=not valid
            if valid:states.add(assertion['status']);seen.add(assertion['role'])
            assertions.append({**deepcopy(assertion),'evidence':[evidence(ref,agreement) for ref in assertion['evidence']],
                'target_status':'EXACT_TARGET_MATCH' if target else 'ASSERTION_TARGET_MISMATCH',
                'party_status':'EXACT_AGREEMENT_ROLE_MATCH' if party else 'ASSERTION_PARTY_MISMATCH',
                'authentication':'CALLER_REPORTED_NOT_AUTHENTICATED','performance_verified':False})
        missing=sorted(set(roles)-seen)
        disputed='DISPUTED' in states or ('OPEN' in states and 'FULFILLED' in states)
        status='DISPUTED' if disputed else 'UNKNOWN' if invalid or not states or 'UNKNOWN' in states else 'REPORTED_OPEN' if 'OPEN' in states else 'UNKNOWN' if missing else 'REPORTED_FULFILLED'
        refs=[e for a in assertions for e in a['evidence']]
        evidence_status='CONFLICT' if any(e['status'].endswith('MISMATCH') for e in refs) else 'UNKNOWN' if not refs or any(e['status'].startswith('UNKNOWN') for e in refs) else 'SUPPLIED_REFERENCES_CHECKED; PERFORMANCE_NOT_VERIFIED'
        current_conflict=agreement.get('currentness',{}).get('matches') is False
        if invalid or evidence_status=='CONFLICT' or current_conflict:status='DISPUTED' if disputed else 'UNKNOWN'
        return {'id':row['id'],'agreement':row['agreement'],'label':row['label'],'responsible_role':row['responsible_role'],'required_roles':deepcopy(roles),'required_roles_basis':'CALLER_SELECTED; NOT_SIGNED_ACCEPTANCE_OR_DISCHARGE_POLICY',
            'status':status,'agreement_reference_status':'CURRENT_REFERENCE_CONFLICT' if current_conflict else 'EXACT_VERIFIED_AGREEMENT; GLOBAL_CURRENTNESS_UNKNOWN','assertions':assertions,'missing_party_assertions':missing,'evidence_status':evidence_status,
            'remaining_obligation':'REPORTED_OUTSTANDING' if status=='REPORTED_OPEN' else 'DISPUTED' if status=='DISPUTED' else 'UNKNOWN',
            'scope':'CALLER_DECLARED_DUTY_AND_ASSERTIONS; NO_PROSE_EXTRACTION_OR_AUTHENTICATED_PARTY_ATTESTATION',
            'performance_verified':False,'discharge_established':False,'execution_authorized':False}

    output=[]
    for row in rows:
        result=_attempt(item,row)
        output.append({'id':row['id'],**result})
    return {'items':output,'coverage':'ONLY_EXPLICITLY_LISTED_DUTIES; UNLISTED_OBLIGATIONS_UNKNOWN',
            'payment_independence':'PAYMENT_SETTLEMENT_AND_SIGNATURES_NEVER_COMPLETE_THESE_DUTIES',
            'remaining_obligations':'UNKNOWN' if not output else 'SEE_EACH_DECLARED_DUTY; GLOBAL_COMPLETION_UNKNOWN',
            'performance_verified':False,'discharge_established':False,'execution_authorized':False}
