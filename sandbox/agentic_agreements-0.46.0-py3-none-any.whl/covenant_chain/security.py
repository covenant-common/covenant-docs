"""Fail-closed runtime dependency floor; not a security certification.

The approved family must be reviewed whenever new advisories are published.
An acceptable version does not establish backend provenance or public readiness.
"""
import re
import ssl
import cryptography
from cryptography.hazmat.backends.openssl.backend import backend

MINIMUM = (50, 0, 2)

def dependency_status(version=None):
    version = cryptography.__version__ if version is None else version
    match = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)', version) if type(version) is str else None
    parts = tuple(map(int, match.groups())) if match else None
    return {'cryptography': version, 'approved_family': '>=50.0.2,<51',
            'acceptable': parts is not None and MINIMUM <= parts < (51, 0, 0)}

def openssl_status(version):
    """Current advisory floors for deliberately adopted backend branches.

    Neither a version string nor this gate proves provenance or complete security.
    Other backend branches require a new explicit qualification.
    """
    match = re.match(r'OpenSSL (\d+)\.(\d+)\.(\d+)(?: |$)', version) if type(version) is str else None
    parts = tuple(map(int, match.groups())) if match else None
    floors = {(3,0):(3,0,23), (3,5):(3,5,9), (3,6):(3,6,5), (4,0):(4,0,3)}
    floor = floors.get(parts[:2]) if parts else None
    return {'openssl':version, 'acceptable':floor is not None and parts >= floor,
            'accepted':'3.0.23+, 3.5.9+, 3.6.5+, 4.0.3+'}

def require_patched_backend():
    result = dependency_status()
    if not result['acceptable']:
        raise ValueError('UNAPPROVED_CRYPTOGRAPHY_BACKEND: require >=50.0.2,<51; upgrade and retest')
    ssl = openssl_status(backend.openssl_version_text())
    if not ssl['acceptable']:
        raise ValueError('UNAPPROVED_OPENSSL_BACKEND: update the adopted backend and retest')
    return dict(result, openssl=ssl['openssl'], openssl_floor_checked=True)

def readiness():
    result = dependency_status()
    return {'dependencies': dict(result, openssl=backend.openssl_version_text(), openssl_acceptable=openssl_status(backend.openssl_version_text())['acceptable']),
            'python_tls_backend':openssl_status(ssl.OPENSSL_VERSION),
            'authenticated_transport_candidate_implemented':True,
            'public_network_ready': False,
            'blockers': ['Independent implementation and cryptographic audit incomplete',
                         'Authenticated TLS gateway candidate implemented; patched runtime, independent review and public flood-defense qualification incomplete',
                         'Multi-host hostile-network and operational key-custody qualification incomplete',
                         'Independent funded custody, availability and signing-state recovery unqualified'],
            'optional_claims_not_qualified': ['General anonymous/post-quantum contracting', 'Production confidential rewards and hidden-fee privacy/security', 'Reciprocal/dynamic cross-domain adoption and long-range compromise recovery'],
            'scope': 'Known dependency/advisory floors and explicit deployment blockers only'}
