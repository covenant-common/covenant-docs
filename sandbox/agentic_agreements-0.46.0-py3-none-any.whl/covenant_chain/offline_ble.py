"""Covenant BLE GATT courier 0.1: small writes, encrypted durable reception.

A new carrier profile, not Bluetooth SIG Mesh or a BPv7 convergence layer. It
carries the existing signed/encrypted packet unchanged. Short fragment tags are
routing hints only; the complete SHA-256, canonical envelope signature, scope
and peer pins are checked before retention. Owner-selected BLE links are not
signing authority.
"""
import hashlib
import struct
import threading

from . import crypto as c, offline as o
from .offline_store import MAX_RECORD

VERSION = 'covenant-ble-courier/0.1'
SERVICE = 'bca5e000-9b92-4a64-9183-28f7e907a001'
RX = 'bca5e001-9b92-4a64-9183-28f7e907a001'
TX = 'bca5e002-9b92-4a64-9183-28f7e907a001'
HEADER = struct.Struct('!2sIHHB')
MAX_PARTS = 8192
WINDOW = 32
MAX_WINDOW = 64
MAX_RECEIPT = 4096


def frames(raw, *, mtu=20):
    c.need(type(raw) is bytes and 0 < len(raw) <= o.MAX_PACKET, 'BLE_PACKET_SIZE')
    c.need(type(mtu) is int and 20 <= mtu <= 244, 'BLE_MTU')
    h = hashlib.sha256(raw).digest()
    stream = h+struct.pack('!I', len(raw))+raw
    width = mtu-HEADER.size; count = (len(stream)+width-1)//width
    c.need(count <= MAX_PARTS, 'BLE_FRAME_COUNT')
    tag = int.from_bytes(h[:4], 'big')
    return [HEADER.pack(b'CB', tag, i, count, width)+stream[i*width:(i+1)*width] for i in range(count)]


def payload_of(parts):
    """Reassemble courier frames. The bytes inside the hash envelope are the payload."""
    c.need(type(parts) is list and parts, 'BLE_FRAME')
    parsed = [parse_frame(frame) for frame in parts]
    tag, (count, width), _, _ = parsed[0]
    c.need(len(parsed) == count, 'BLE_FRAME')
    chunks = {}
    for item_tag, shape, index, data in parsed:
        c.need(item_tag == tag and shape == (count, width) and index not in chunks, 'BLE_FRAME')
        chunks[index] = data
    c.need(set(chunks) == set(range(count)), 'BLE_FRAME')
    stream = b''.join(chunks[index] for index in range(count))
    c.need(len(stream) > 36, 'BLE_PACKET')
    digest, length, blob = stream[:32], int.from_bytes(stream[32:36], 'big'), stream[36:]
    c.need(length == len(blob) and hashlib.sha256(blob).digest() == digest, 'BLE_PACKET')
    return blob


def parse_frame(raw):
    c.need(type(raw) is bytes and HEADER.size < len(raw) <= 244, 'BLE_FRAME_SIZE')
    magic, tag, index, count, width = HEADER.unpack(raw[:HEADER.size])
    data = raw[HEADER.size:]
    c.need(magic == b'CB' and 9 <= width <= 233 and 1 <= count <= MAX_PARTS and index < count,
           'BLE_FRAME_HEADER')
    c.need(len(data) == width if index < count-1 else 1 <= len(data) <= width, 'BLE_FRAME_LENGTH')
    return f'{tag:08x}', (count, width), index, data


def _packed(parts):
    raw = b''.join(struct.pack('!HB', i, len(v))+v for i, v in sorted(parts.items()))
    encoded = o.b64(raw)
    return [encoded[i:i+16384] for i in range(0, len(encoded), 16384)]


def _unpacked(blocks, count, width):
    c.need(type(blocks) is list and len(blocks) <= 12 and
           all(type(v) is str and 0 < len(v) <= 16384 for v in blocks), 'BLE_SNAPSHOT')
    raw = o.unb64(''.join(blocks), 131072); result = {}; offset = 0
    while offset < len(raw):
        c.need(offset+3 <= len(raw), 'BLE_SNAPSHOT')
        index, size = struct.unpack('!HB', raw[offset:offset+3]); offset += 3
        c.need(index < count and index not in result and offset+size <= len(raw) and
               (size == width if index < count-1 else 1 <= size <= width), 'BLE_SNAPSHOT')
        result[index] = raw[offset:offset+size]; offset += size
    return result


class BleInbox:
    """Checkpoint windows in an existing encrypted OfflineStore.

    The owner selects a logical channel and allowed original signing peers.
    The channel label is not proof of Bluetooth identity. Uncheckpointed GATT
    writes may be lost; exact packet retransmission is safe. Complete fragments
    are saved before packet retention and removed only afterwards.
    """
    def __init__(self, vault, *, channel, allowed_senders, relay=False, shared_key=None,
                 max_packet=8192, max_sessions=2, lifetime=600):
        c.need(type(channel) is str and 0 < len(channel) <= 128, 'BLE_CHANNEL')
        c.need(type(allowed_senders) in (set, list, tuple) and 1 <= len(allowed_senders) <= 16,
               'BLE_ALLOWED_SENDERS')
        for peer in allowed_senders: c.verification_key(peer)
        c.need(type(relay) is bool and type(max_packet) is int and 512 <= max_packet <= o.MAX_PACKET and
               type(max_sessions) is int and 1 <= max_sessions <= 8 and
               max_packet*max_sessions <= o.MAX_PACKET and type(lifetime) is int and 1 <= lifetime <= 86400,
               'BLE_INBOX_POLICY')
        if not relay: o._key(shared_key)
        self.vault, self.allowed, self.relay, self.shared = vault, set(allowed_senders), relay, shared_key
        self.max_packet, self.max_sessions, self.lifetime = max_packet, max_sessions, lifetime
        self.key = 'ble:'+c.digest('COVENANT-BLE-CHANNEL-0.1', {'channel': channel})
        self.policy = dict(version=VERSION, channel=channel, max_packet=max_packet,
                           max_sessions=max_sessions, lifetime=lifetime, relay=relay,
                           key_id=None if relay else o.key_id(shared_key))
        self.lock = threading.RLock()

    def _load(self, value, now):
        if value is None: return {}
        c.exact(value, 'policy sessions')
        c.need(c.canonical(value['policy']) == c.canonical(self.policy), 'BLE_POLICY_CHANGED')
        c.need(type(value['sessions']) is list and len(value['sessions']) <= self.max_sessions, 'BLE_SNAPSHOT')
        states = {}
        for row in value['sessions']:
            c.exact(row, 'tag at count width blocks'); c.integer(row['at'])
            c.need(row['at'] <= now and type(row['tag']) is str and len(row['tag']) == 8 and
                   all(x in '0123456789abcdef' for x in row['tag']) and row['tag'] not in states and
                   type(row['count']) is int and 1 <= row['count'] <= MAX_PARTS and
                   type(row['width']) is int and 9 <= row['width'] <= 233 and
                   row['count']*row['width'] <= self.max_packet+36+row['width']-1, 'BLE_SNAPSHOT')
            if now >= row['at']+self.lifetime: continue
            states[row['tag']] = {'at': row['at'], 'count': row['count'], 'width': row['width'],
                                 'parts': _unpacked(row['blocks'], row['count'], row['width'])}
        return states

    def _save(self, states, previous):
        value = {'policy': self.policy, 'sessions': [
            dict(tag=tag, at=s['at'], count=s['count'], width=s['width'], blocks=_packed(s['parts']))
            for tag, s in sorted(states.items())]}
        c.need(len(c.canonical({'key': self.key, 'value': value})) <= MAX_RECORD, 'BLE_SNAPSHOT_SIZE')
        if value != previous: self.vault._put(self.key, value)

    def receive_window(self, incoming, *, now, only_tag=None):
        c.need(type(incoming) is list and len(incoming) <= MAX_WINDOW, 'BLE_WINDOW')
        c.need(only_tag is None or (type(only_tag) is str and len(only_tag) == 8 and
               all(x in '0123456789abcdef' for x in only_tag)), 'BLE_TAG')
        decoded = [parse_frame(v) for v in incoming]
        ready = []
        with self.lock:
            with self.vault._locked():
                records = self.vault._records(); self.vault._clock(now, records)
                old = records.get(self.key); states = self._load(old, now)
                for tag, (count, width), index, data in decoded:
                    c.need(count*width <= self.max_packet+36+width-1, 'BLE_RESERVATION_LIMIT')
                    if tag not in states:
                        c.need(len(states) < self.max_sessions, 'BLE_SESSION_LIMIT')
                        states[tag] = dict(at=now, count=count, width=width, parts={})
                    s = states[tag]
                    c.need((s['count'], s['width']) == (count, width), 'BLE_TAG_COLLISION_OR_CONFLICT')
                    c.need(index not in s['parts'] or s['parts'][index] == data, 'BLE_DUPLICATE_CONFLICT')
                    s['parts'][index] = data
                for tag, s in states.items():
                    if only_tag is not None and tag != only_tag: continue
                    if len(s['parts']) != s['count']: continue
                    stream = b''.join(s['parts'][i] for i in range(s['count']))
                    c.need(len(stream) > 36, 'BLE_STREAM_SIZE')
                    h, length, raw = stream[:32], struct.unpack('!I', stream[32:36])[0], stream[36:]
                    c.need(h[:4].hex() == tag and length == len(raw) and 0 < length <= self.max_packet and
                           hashlib.sha256(raw).digest() == h, 'BLE_STREAM_HASH')
                    packet = o.exact_load(raw)
                    o.inspect_packet(packet, scope=self.vault.scope, allowed_senders=self.allowed, now=now)
                    ready.append((tag, raw, packet))
                # Snapshot each checkpoint, not each tiny GATT write. No native
                # transport format or historical agreement meaning is changed.
                self._save(states, old)
            retained = []
            for tag, raw, packet in ready:
                ref = self.vault.retain(packet, allowed_senders=self.allowed, now=now,
                                        relay=self.relay, shared_key=self.shared)
                retained.append({'packet': ref, 'bytes_sha256': hashlib.sha256(raw).hexdigest()})
                with self.vault._locked():
                    previous = self.vault._records().get(self.key)
                    current = self._load(previous, now)
                    current.pop(tag, None)
                    self._save(current, previous)
            return {'retained': retained, 'partial_sessions': len(states)-len(ready),
                    'checkpointed': True, 'agreement_accepted': False, 'payment_verified': False}


class GattMailbox:
    """Reference peripheral callbacks; one adopted logical link per mailbox.

    RX: B+tag/count/width begin, CB frames, F checkpoint, S state,
    R+uint16 receipt-page request. Begin limits a mailbox to one packet stream;
    it never authorizes the short tag as identity. Callers verify the full receipt.
    TX: at most 20 bytes. P is partial custody; H+uint16 is receipt length.
    Neither the GATT write response nor P proves end-recipient custody.
    """
    def __init__(self, inbox, *, signing_key, clock):
        c.need(c.public_key(signing_key) == inbox.vault.owner and callable(clock), 'BLE_OWNER_KEY')
        self.inbox, self.signing_key, self.clock = inbox, signing_key, clock
        self.pending = []; self.response = b'E'; self.receipt = b''; self.lock = threading.RLock()
        self.stream = None

    def write(self, characteristic, value, **kwargs):
        c.need(str(characteristic.uuid).lower() == RX, 'BLE_CHARACTERISTIC')
        c.need(type(value) in (bytes, bytearray) and 0 < len(value) <= 244, 'BLE_WRITE_SIZE')
        value = bytes(value)
        with self.lock:
            if len(value) == 8 and value[:1] == b'B':
                tag, count, width = struct.unpack('!IHB', value[1:])
                c.need(1 <= count <= MAX_PARTS and 9 <= width <= 233, 'BLE_BEGIN')
                self.stream = (f'{tag:08x}', (count, width))
                self.pending = []; self.receipt = b''; self.response = b'P'
            elif value.startswith(b'CB'):
                tag, shape, _, _ = parse_frame(value)
                c.need(self.stream == (tag, shape), 'BLE_STREAM_NOT_BEGUN')
                # A restarted exact retransmission may complete against saved
                # suffixes before its last write. Keep that full signed receipt.
                if self.receipt: return
                c.need(len(self.pending) < MAX_WINDOW, 'BLE_WINDOW')
                self.pending.append(value); self.response = b'P'
            elif value == b'F':
                c.need(self.stream is not None, 'BLE_STREAM_NOT_BEGUN')
                if self.receipt: return
                result = self.inbox.receive_window(self.pending, now=self.clock(), only_tag=self.stream[0])
                self.pending = []
                if result['retained']:
                    c.need(len(result['retained']) == 1, 'BLE_ONE_PACKET_PER_CHECKPOINT')
                    from .offline_forwarding import hop_receipt
                    packet = self.inbox.vault.packet(result['retained'][0]['packet'])['packet']
                    self.receipt = c.canonical(hop_receipt(packet, self.signing_key, at=self.clock()))
                    c.need(len(self.receipt) <= MAX_RECEIPT, 'BLE_RECEIPT_SIZE')
                    self.response = b'H'+struct.pack('!H', len(self.receipt))
                else: self.response = b'P'
            elif value == b'S':
                self.response = b'H'+struct.pack('!H', len(self.receipt)) if self.receipt else b'P'
            elif len(value) == 3 and value[:1] == b'R':
                offset = struct.unpack('!H', value[1:])[0]*20
                c.need(self.receipt and offset < len(self.receipt), 'BLE_RECEIPT_PAGE')
                self.response = self.receipt[offset:offset+20]
            else: raise ValueError('BLE_COMMAND')

    def read(self, characteristic, **kwargs):
        c.need(str(characteristic.uuid).lower() == TX, 'BLE_CHARACTERISTIC')
        with self.lock: return bytearray(self.response)


async def send_ble(client, raw, *, expected_peer, clock, mtu=20, timeout=120):
    """Use an owner-connected BleakClient; no scan, pairing or auto-connect.

    Retries deliberately resend exact bytes. Window checkpoints survive restart;
    the last uncheckpointed window can be replayed. The signed hop receipt is a
    peer assertion of custody, not assent, final delivery, execution or payment.
    """
    import asyncio
    from .offline_forwarding import verify_hop_receipt
    c.need(type(timeout) is int and 1 <= timeout <= 3600 and callable(clock) and
           client.is_connected is True, 'BLE_CONNECTION_POLICY')
    started = clock(); c.integer(started)
    packet = o.exact_load(raw); o.packet_id(packet); c.verification_key(expected_peer)
    pieces = frames(raw, mtu=mtu)
    async with asyncio.timeout(timeout):
        service = client.services.get_service(SERVICE)
        c.need(service is not None, 'BLE_SERVICE')
        rx, tx = service.get_characteristic(RX), service.get_characteristic(TX)
        c.need(rx is not None and tx is not None and 'write' in rx.properties and 'read' in tx.properties,
               'BLE_CHARACTERISTIC')
        tag, (count, width), _, _ = parse_frame(pieces[0])
        await client.write_gatt_char(rx, b'B'+struct.pack('!IHB', int(tag, 16), count, width), response=True)
        for start in range(0, len(pieces), WINDOW):
            for piece in pieces[start:start+WINDOW]:
                await client.write_gatt_char(rx, piece, response=True)
            await client.write_gatt_char(rx, b'F', response=True)
            status = bytes(await client.read_gatt_char(tx, use_cached=False))
            c.need(status == b'P' or (len(status) == 3 and status[:1] == b'H'), 'BLE_STATUS')
        await client.write_gatt_char(rx, b'S', response=True)
        status = bytes(await client.read_gatt_char(tx, use_cached=False))
        c.need(len(status) == 3 and status[:1] == b'H', 'BLE_PEER_RETENTION_UNKNOWN')
        size = struct.unpack('!H', status[1:])[0]
        c.need(0 < size <= MAX_RECEIPT, 'BLE_RECEIPT_SIZE')
        chunks = []
        for index in range((size+19)//20):
            await client.write_gatt_char(rx, b'R'+struct.pack('!H', index), response=True)
            data = bytes(await client.read_gatt_char(tx, use_cached=False))
            c.need(len(data) == min(20, size-index*20), 'BLE_RECEIPT_PAGE')
            chunks.append(data)
        receipt = o.exact_load(b''.join(chunks), MAX_RECEIPT)
        finished = clock(); c.integer(finished)
        c.need(finished >= started, 'BLE_CLOCK_ROLLBACK')
        verify_hop_receipt(receipt, packet, expected_peer=expected_peer, now=finished)
        return receipt


async def configure_bless(server, mailbox):
    """Configure an owner-created Bless 0.3 server; owner explicitly starts it."""
    from bless import GATTCharacteristicProperties as P, GATTAttributePermissions as A
    await server.add_gatt({SERVICE: {
        RX: {'Properties': P.write, 'Permissions': A.writeable, 'Value': bytearray()},
        TX: {'Properties': P.read, 'Permissions': A.readable, 'Value': bytearray(b'E')}}})
    server.write_request_func = mailbox.write
    server.read_request_func = mailbox.read
    return {'service': SERVICE, 'rx': RX, 'tx': TX, 'advertising_started': False}


def describe_limits():
    """BLE courier bounds (salvaged Cursor PR 58). A frame is not a signature and not finality."""
    return {'version': VERSION, 'max_parts': MAX_PARTS, 'window': WINDOW, 'max_receipt': MAX_RECEIPT,
            'execution_authorized': False}
