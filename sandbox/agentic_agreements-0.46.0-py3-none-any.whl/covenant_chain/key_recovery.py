"""Key safety for ordinary users: guardian recovery, passkey-wrapped keys, an
encrypted keystore upgrade and an optional hosted (custodial) wallet.

Guardian recovery runs on native continuity (covenant_chain.continuity): the
account installs a policy naming up to three guardian hash keys, and a later
recovery is a guardian-approved, delayed controller change that any guardian
can cancel during the delay. This module only prepares and checks the exact
payloads; the reducer decides. It adds no consensus operation.

Trust boundaries, in one place:
- Guardian recovery: with threshold 1, any single guardian can start a recovery
  and any single guardian can cancel one. The delay is the defence, so someone
  must watch for pending recoveries (``watch``). While continuity is installed,
  every transaction of the account also carries a guardian co-signature.
- Passkey wrapping: the WebAuthn PRF output unlocks the key. The browser or
  platform computes it; the process that unwraps sees the PRF output and the
  key. Losing the passkey without another copy loses the key.
- Encrypted keystore: scrypt plus AES-256-GCM (covenant-encrypted-keystore/0.1).
  Overwriting the old plaintext file does not erase copies in backups, snapshots
  or copy-on-write storage.
- Hosted wallet: CUSTODIAL. The host can sign anything for an enrolled user. The
  policy and the passkey check are enforced only by the host's own code. The
  signed audit log lets a user or auditor detect a signature the user's passkey
  never approved; it cannot prevent one. Exit is export or a ROTATE to a key the
  user holds. Used passkey approvals are kept in the wallet directory
  (covenant-identity-store/0.1), so a restart does not let one be replayed.
"""
from copy import deepcopy
import base64
import hashlib
import os
import re
import stat
import fcntl
import threading
from functools import wraps
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from covenant_language.safe_io import append_record, atomic_write, complete_records, lock_file

from . import continuity
from .crypto import canonical, digest, integer, key, loads, need, public_key, sign, verification_key, verify

VERSION = 'covenant-recovery-kit/0.1'
PASSKEY_KEYSTORE_VERSION = 'covenant-passkey-keystore/0.1'
HOSTED_VERSION = 'covenant-hosted-wallet/0.1'
AUDIT_LABEL = 'COVENANT-HOSTED-WALLET-AUDIT-0.1'
ACCEPT_LABEL = 'COVENANT-CONTINUITY-ACCEPT-0.1'
RECOVER_LABEL = 'COVENANT-CONTINUITY-RECOVER-0.1'
RECOVER_POSSESSION_LABEL = 'COVENANT-CONTINUITY-RECOVER-POSSESSION-0.1'
CANCEL_LABEL = 'COVENANT-CONTINUITY-CANCEL-0.1'
ROTATE_LABEL = 'COVENANT-CONTROLLER-ACCEPT-0.2'
HOSTED_STORE_KIND = 'covenant-hosted-wallet-approvals/0.1'
USER_ID = re.compile(r'[a-z0-9][a-z0-9_-]{0,63}\Z')

GUARDIAN_BOUNDARY = [
    'any one guardian can start a recovery when threshold is 1; the delay is the only defence',
    'any guardian quorum can cancel a pending recovery during the delay',
    'continuity co-signs every transaction of the protected account with a guardian hash key',
    'guardians cannot spend for the account; a completed recovery moves control to the successor key',
    'outstanding authorities follow the adopted policy (REVOKE_NATIVE ends existing grants)',
]
HOSTED_BOUNDARY = [
    'CUSTODIAL: the host holds the user key and can sign anything for the user',
    'the spending policy and passkey check are enforced only by the host code',
    'the audit log proves host-recorded statements, not independent passkey approval or completeness',
    'the master key and storage are the host operator responsibility',
    'exit: export the key (the host had a copy) or ROTATE control to a user-held key',
]


def _wallet_locked(method):
    @wraps(method)
    def invoke(self, *args, **kwargs):
        with self._mutex:
            if self._depth:
                return method(self, *args, **kwargs)
            fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                lock_file(fd)
                self._depth = 1
                return method(self, *args, **kwargs)
            finally:
                self._depth = 0
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
    return invoke


# --- guardian recovery on native continuity --------------------------------

def guardian_kit(entity, guardians, *, delay=144, threshold=1, authorities='REVOKE_NATIVE'):
    """A continuity policy plus the plain-language card each person keeps.

    ``guardians`` maps a name to {'suite': SPHINCS+, 'key': hex}. A typical kit is
    one guardian on the user's own second device and one or two trusted contacts.
    """
    policy = continuity.make_policy(entity, guardians, threshold=threshold, delay=delay, authorities=authorities)
    return {'version': VERSION, 'policy': policy, 'policy_id': continuity.policy_id(policy),
            'delay_blocks': delay, 'threshold': threshold, 'guardians': sorted(guardians),
            'cards': {name: {'role': 'guardian', 'holds': 'one SPHINCS+ hash secret (continuity.GuardianShare)',
                             'can': ['co-sign the account transactions', 'approve or cancel a recovery'],
                             'cannot': ['spend alone', 'skip the delay']} for name in sorted(guardians)},
            'boundary': list(GUARDIAN_BOUNDARY), 'consensus_change': None, 'execution_authorized': False}


def install_request(state, policy):
    """What each guardian approves to install the policy on this exact state."""
    from .roots import state_hash
    continuity.validate_policy(policy, policy['entity'])
    root = state_hash(state)
    body = continuity.acceptance_body(state, policy, root)
    return {'op': 'CONTINUITY_INSTALL', 'label': ACCEPT_LABEL, 'body': body,
            'payload': {'policy': deepcopy(policy), 'source_root': root}, 'threshold': policy['threshold'],
            'execution_authorized': False}


def _quorum(policy, approvals):
    need(type(approvals) is list and len(approvals) >= policy['threshold'], 'RECOVERY_QUORUM')
    names = [row.get('member') if type(row) is dict else None for row in approvals]
    need(len(set(names)) == len(names) and all(name in policy['guardians'] for name in names), 'RECOVERY_SIGNER')
    return sorted(approvals, key=lambda row: row['member'])[:policy['threshold']]


def install_payload(request, approvals):
    policy = request['payload']['policy']
    return {**deepcopy(request['payload']), 'acceptances': _quorum(policy, approvals)}


def recovery_request(state, entity, successor):
    """Body for guardians (and the successor's possession signature) to recover ``entity``."""
    key(entity)
    verification_key(successor)
    record = state.get('continuity_policies', {}).get(entity)
    need(record is not None, 'RECOVERY_NOT_PROTECTED')
    need(state['continuity_pending'].get(entity) is None, 'RECOVERY_PENDING')
    body = continuity.recovery_body(state, entity, successor)
    return {'op': 'CONTINUITY_RECOVERY_REQUEST', 'guardian_label': RECOVER_LABEL,
            'possession_label': RECOVER_POSSESSION_LABEL, 'body': body, 'policy': deepcopy(record['body']),
            'delay_blocks': record['body']['delay'], 'execution_authorized': False}


def recovery_payload(request, approvals, possession):
    body = request['body']
    payload = {name: value for name, value in body.items() if name != 'chain'}
    payload.update(approvals=_quorum(request['policy'], approvals), possession=possession)
    return payload


def cancel_request(state, entity):
    key(entity)
    pending = state.get('continuity_pending', {}).get(entity)
    need(pending is not None, 'RECOVERY_NONE_PENDING')
    body = {'chain': state['chain'], 'entity': entity, 'request': pending['id'], 'policy': pending['body']['policy']}
    return {'op': 'CONTINUITY_RECOVERY_CANCEL', 'label': CANCEL_LABEL, 'body': body,
            'policy': deepcopy(state['continuity_policies'][entity]['body']), 'execution_authorized': False}


def cancel_payload(request, approvals):
    return {'entity': request['body']['entity'], 'request': request['body']['request'],
            'approvals': _quorum(request['policy'], approvals)}


def finish_payload(state, entity, height):
    key(entity)
    integer(height)
    pending = state.get('continuity_pending', {}).get(entity)
    need(pending is not None, 'RECOVERY_NONE_PENDING')
    need(height >= pending['ready'], 'RECOVERY_DELAY')
    return {'entity': entity, 'request': pending['id']}


def watch(state, entity, height):
    """Read-only status a user's device or guardian polls."""
    key(entity)
    integer(height)
    record = state.get('continuity_policies', {}).get(entity)
    pending = state.get('continuity_pending', {}).get(entity) if record else None
    out = {'entity': entity, 'protected': record is not None, 'pending': None, 'execution_authorized': False}
    if pending is not None:
        out['pending'] = {'request': pending['id'], 'successor': pending['body']['successor'],
                          'ready': pending['ready'], 'blocks_left': max(0, pending['ready'] - height)}
        out['advice'] = ('If you did not start this recovery, ask a guardian to cancel it before height '
                         + str(pending['ready']) + '.')
    return out


# --- passkey-wrapped keys (WebAuthn PRF) ------------------------------------

def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _hex(value, size, code):
    need(type(value) is str and len(value) == 2 * size and all(c in '0123456789abcdef' for c in value), code)
    return bytes.fromhex(value)


def _passkey_header(credential_id, rp_id, prf_salt):
    need(type(credential_id) is str and 0 < len(credential_id) <= 256 and re.fullmatch(r'[A-Za-z0-9_-]+', credential_id),
         'PASSKEY_KEYSTORE_CREDENTIAL')
    need(type(rp_id) is str and 0 < len(rp_id) <= 253 and rp_id.isascii() and rp_id.isprintable(), 'PASSKEY_KEYSTORE_RP_ID')
    _hex(prf_salt, 32, 'PASSKEY_KEYSTORE_FORMAT')
    return {'version': PASSKEY_KEYSTORE_VERSION, 'credential_id': credential_id, 'rp_id': rp_id,
            'prf_salt': prf_salt, 'kdf': 'HKDF-SHA256', 'cipher': 'AES-256-GCM'}


def _passkey_kek(prf_output, header):
    need(type(prf_output) is bytes and len(prf_output) == 32, 'PASSKEY_KEYSTORE_PRF')
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=bytes.fromhex(header['prf_salt']),
                info=b'COVENANT-PASSKEY-KEYSTORE-0.1\0' + canonical(header)).derive(prf_output)


def passkey_wrap(seed, prf_output, *, credential_id, rp_id, prf_salt=None):
    """Encrypt a 32-byte Ed25519 seed under a passkey's PRF output (WebAuthn prf extension)."""
    need(type(seed) is bytes and len(seed) == 32, 'PASSKEY_KEYSTORE_SEED')
    header = _passkey_header(credential_id, rp_id, prf_salt or os.urandom(32).hex())
    nonce = os.urandom(12)
    sealed = AESGCM(_passkey_kek(prf_output, header)).encrypt(nonce, seed, canonical(header))
    return {**header, 'nonce': nonce.hex(), 'ciphertext': sealed.hex(),
            'public': Ed25519PrivateKey.from_private_bytes(seed).public_key().public_bytes_raw().hex()}


def passkey_unwrap(document, prf_output):
    need(type(document) is dict and set(document) == {'version', 'credential_id', 'rp_id', 'prf_salt', 'kdf', 'cipher',
                                                      'nonce', 'ciphertext', 'public'}, 'PASSKEY_KEYSTORE_FORMAT')
    header = _passkey_header(document['credential_id'], document['rp_id'], document['prf_salt'])
    need(all(document[name] == value for name, value in header.items()), 'PASSKEY_KEYSTORE_FORMAT')
    nonce = _hex(document['nonce'], 12, 'PASSKEY_KEYSTORE_FORMAT')
    sealed = _hex(document['ciphertext'], 48, 'PASSKEY_KEYSTORE_FORMAT')
    try:
        seed = AESGCM(_passkey_kek(prf_output, header)).decrypt(nonce, sealed, canonical(header))
    except InvalidTag:
        raise ValueError('PASSKEY_KEYSTORE_UNLOCK') from None
    private = Ed25519PrivateKey.from_private_bytes(seed)
    need(public_key(private) == document['public'], 'PASSKEY_KEYSTORE_FORMAT')
    return private


def prf_request(document):
    """WebAuthn get() options fragment a browser needs to compute the PRF output."""
    header = _passkey_header(document['credential_id'], document['rp_id'], document['prf_salt'])
    return {'rpId': header['rp_id'], 'allowCredentials': [{'type': 'public-key', 'id': header['credential_id']}],
            'userVerification': 'required',
            'extensions': {'prf': {'eval': {'first': _b64(bytes.fromhex(header['prf_salt']))}}},
            'note': 'The PRF output is clientExtensionResults.prf.results.first (32 bytes).'}


# --- encrypted keystore upgrade --------------------------------------------

def encrypt_existing(directory, passphrase):
    """Move a plaintext identity.hex to covenant-encrypted-keystore/0.1 in place.

    The encrypted file is written and checked before the plaintext is overwritten
    and removed. Backups or snapshots of the old file are not reached.
    """
    from .onboarding import KEYSTORE_FILE, LocalKeyStore, open_identity, seal_identity
    store = LocalKeyStore(directory)
    need(store.format == 'plaintext', 'RECOVERY_KEYSTORE_NOT_PLAINTEXT')
    # Share the existing directory custody lock with ordinary key loading.
    with store._locked():
        return _encrypt_locked(store, directory, passphrase)


def _encrypt_locked(store, directory, passphrase):
    from .onboarding import KEYSTORE_FILE, open_identity, seal_identity
    private = store._load()
    raw = private.private_bytes_raw()
    document = seal_identity(raw, passphrase)
    need(open_identity(document, passphrase) == raw, 'RECOVERY_KEYSTORE_CHECK')
    target = Path(directory) / KEYSTORE_FILE
    # Durably retain the complete new name (file and directory fsync'd) before
    # touching the only plaintext key; a crash leaves no partial keystore.
    atomic_write(target, canonical(document), mode=0o600, exclusive=True, follow_symlinks=False)
    plain = store.path
    size = plain.stat().st_size
    # readiness: in-place zeroes the superseded plaintext key before unlink; the keystore above is already durable
    fd = os.open(plain, os.O_WRONLY | os.O_NOFOLLOW)
    try:
        os.write(fd, b'\0' * size)
        os.fsync(fd)
    finally:
        os.close(fd)
    plain.unlink()
    directory_fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)
    need(open_identity(loads(target.read_bytes()), passphrase) == raw, 'RECOVERY_KEYSTORE_CHECK')
    return {'format': 'encrypted', 'public': public_key(private), 'plaintext_removed': True,
            'residual_risk': 'Copies of identity.hex in backups, snapshots or synced folders are not erased. '
                             'Rotate the key if a plaintext copy may exist.', 'execution_authorized': False}


# --- hosted wallet (custodial, optional) ------------------------------------

def _wallet_dir(path):
    path = Path(path)
    need(path.is_dir() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode) & 0o077 == 0,
         'HOSTED_DIRECTORY')
    return path


def wallet_policy(*, ops, give_limits=None, require_user_verification=True):
    need(type(ops) is list and ops and ops == sorted(set(ops)), 'HOSTED_POLICY')
    need(all(type(op) is str and re.fullmatch(r'[A-Z][A-Z0-9_]{1,40}', op) for op in ops), 'HOSTED_POLICY')
    need(not {'ROTATE', 'SET_RECOVERY', 'SET_CONTROLLER_SUITE'} & set(ops), 'HOSTED_POLICY_CONTROL_OPS')
    limits = deepcopy(give_limits or {})
    need(type(limits) is dict and len(limits) <= 16, 'HOSTED_POLICY')
    for resource, amount in limits.items():
        need(type(resource) is str and 0 < len(resource) <= 80, 'HOSTED_POLICY')
        integer(amount, True)
    need('GIVE' not in ops or limits, 'HOSTED_POLICY_GIVE_LIMIT')
    need(type(require_user_verification) is bool, 'HOSTED_POLICY')
    return {'version': HOSTED_VERSION, 'ops': list(ops), 'give_limits': limits,
            'require_user_verification': require_user_verification}


class HostedWallet:
    """Optional custodial wallet for users who do not want to hold a key.

    ``master_key`` is 32 bytes from the operator's KMS or HSM; it is used only to
    wrap user keys at rest and is not stored here. ``audit_key`` is an Ed25519
    key that signs the hash-linked audit log. Each user registers one passkey at
    enrolment, over a channel the operator must trust. One process at a time may
    open a wallet directory; ``close`` releases it.
    """

    mode = 'CUSTODIAL'

    def __init__(self, directory, master_key, audit_key, *, policy, rp_id, origin, clock, experimental=False):
        need(experimental is True, 'HOSTED_EXPERIMENTAL_OWNER_API_ONLY')
        self._mutex = threading.RLock()
        self._depth = 0
        self.directory = _wallet_dir(directory)
        need(type(master_key) is bytes and len(master_key) == 32, 'HOSTED_MASTER_KEY')
        need(isinstance(audit_key, Ed25519PrivateKey), 'HOSTED_AUDIT_KEY')
        need(wallet_policy(ops=policy.get('ops'), give_limits=policy.get('give_limits'),
                           require_user_verification=policy.get('require_user_verification')) == policy,
             'HOSTED_POLICY')
        need(type(rp_id) is str and rp_id and type(origin) is str and origin, 'HOSTED_RP')
        need(callable(clock), 'HOSTED_CLOCK')
        self._master = AESGCM(master_key)
        self._audit = audit_key
        self.audit_public = public_key(audit_key)
        self.policy = deepcopy(policy)
        self.rp_id = rp_id
        self.origin = origin
        self._clock = clock
        self._log_path = self.directory / 'audit.jsonl'
        self._lock = threading.Lock()
        from .identity_store import StateFile
        # User files are <user>.json with no dot in <user>, so this name cannot collide.
        self._store = StateFile(self.directory, 'hosted-wallet', kind=HOSTED_STORE_KIND,
                                context={'version': HOSTED_VERSION})
        try:
            saved = self._store.load()
            need(saved is None or (set(saved) == {'used'} and type(saved['used']) is list), 'HOSTED_STORE_STATE')
            self._used = set(saved['used']) if saved else set()
            # A wallet made before the store existed: its audit log names every approval it used.
            for entry in self.audit_log():
                request = entry.get('body', {}).get('detail', {}).get('request')
                if request is not None:
                    self._used.add(request)
            for row in self._used:
                key(row)
        except BaseException:
            self._store.close()
            raise

    def __repr__(self):
        return f'HostedWallet({str(self.directory)!r}, mode={self.mode!r})'

    def close(self):
        """Release the wallet directory lock."""
        self._store.close()

    def _path(self, user):
        need(type(user) is str and USER_ID.fullmatch(user) is not None, 'HOSTED_USER')
        return self.directory / (user + '.json')

    def _read(self, user):
        path = self._path(user)
        need(path.is_file() and not path.is_symlink(), 'HOSTED_USER_UNKNOWN')
        return loads(self._private_read(path, 2 * 1024 * 1024))

    def _private_read(self, path, maximum):
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            info = os.fstat(fd)
            need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid()
                 and stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_size <= maximum, 'HOSTED_PRIVATE_FILE')
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                raw = stream.read(maximum + 1)
            need(len(raw) <= maximum, 'HOSTED_STORAGE_LIMIT')
            return raw
        finally:
            os.close(fd)

    def _write(self, user, record, *, new=False):
        path = self._path(user)
        raw = canonical(record)
        need(len(raw) <= 2 * 1024 * 1024, 'HOSTED_STORAGE_LIMIT')
        temporary = self.directory / ('.wallet-' + os.urandom(16).hex() + '.tmp')
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            if new:
                os.link(temporary, path, follow_symlinks=False)
            else:
                self._private_read(path, 2 * 1024 * 1024)
                os.replace(temporary, path)
            directory_fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    def _aad(self, user, public):
        return canonical({'version': HOSTED_VERSION, 'user': user, 'public': public})

    @_wallet_locked
    def enroll(self, user, passkey):
        """Create a user key held by the host. ``passkey`` = {'credential_id', 'public_key'} (P-256)."""
        from .signin import passkey_registration
        need(not self._path(user).exists(), 'HOSTED_USER_EXISTS')
        need(type(passkey) is dict and set(passkey) == {'credential_id', 'public_key'}, 'HOSTED_PASSKEY')
        private = Ed25519PrivateKey.generate()
        public = public_key(private)
        passkey_registration(public, '0' * 64, passkey['credential_id'], passkey['public_key'], self.rp_id)
        nonce = os.urandom(12)
        wrapped = self._master.encrypt(nonce, private.private_bytes_raw(), self._aad(user, public))
        record = {'version': HOSTED_VERSION, 'user': user, 'public': public, 'nonce': nonce.hex(),
                  'wrapped': wrapped.hex(), 'passkey': deepcopy(passkey), 'status': 'ACTIVE'}
        self._write(user, record, new=True)
        self._log('ENROLL', user, {'public': public, 'passkey': passkey['credential_id']})
        return {'user': user, 'public': public, 'mode': self.mode, 'boundary': list(HOSTED_BOUNDARY),
                'execution_authorized': False}

    def _key(self, record):
        try:
            seed = self._master.decrypt(bytes.fromhex(record['nonce']), bytes.fromhex(record['wrapped']),
                                        self._aad(record['user'], record['public']))
        except (InvalidTag, ValueError):
            raise ValueError('HOSTED_KEY_UNWRAP') from None
        private = Ed25519PrivateKey.from_private_bytes(seed)
        need(public_key(private) == record['public'], 'HOSTED_KEY_UNWRAP')
        return private

    def _approved(self, record, request, assertion):
        from .signin import verify_passkey_assertion
        registration = {'credential_id': record['passkey']['credential_id'],
                        'public_key': record['passkey']['public_key'], 'rp_id': self.rp_id}
        challenge = digest('COVENANT-HOSTED-WALLET-REQUEST-0.1', request)
        with self._lock:
            history = self.audit_log()
            verify_audit_log(history, self.audit_public)
            used = {row['body']['detail'].get('request') for row in history}
            need(challenge not in used and challenge not in self._used, 'HOSTED_APPROVAL_REPLAY')
            verify_passkey_assertion(request, assertion, registration, origin=self.origin,
                                     require_user_verification=self.policy['require_user_verification'])
            self._used.add(challenge)
            try:
                self._store.save({'used': sorted(self._used)})
            except OSError:
                self._used.discard(challenge)
                raise ValueError('HOSTED_STORE_WRITE') from None
        return challenge

    @_wallet_locked
    def signing_request(self, user, *, chain, nonce, op, payload, protocol, fee=None):
        """The exact request the user's passkey approves (WebAuthn challenge = signin.passkey_challenge)."""
        record = self._read(user)
        need(record['status'] == 'ACTIVE', 'HOSTED_USER_' + record['status'])
        need(op in self.policy['ops'], 'HOSTED_POLICY_OP')
        if op == 'GIVE':
            need(type(payload) is dict and payload.get('resource') in self.policy['give_limits'], 'HOSTED_POLICY_GIVE')
            integer(payload.get('limit'), True)
            need(payload['limit'] <= self.policy['give_limits'][payload['resource']], 'HOSTED_POLICY_GIVE_LIMIT')
        key(chain)
        integer(nonce)
        return {'version': HOSTED_VERSION, 'user': user, 'actor': record['public'], 'chain': chain, 'nonce': nonce,
                'op': op, 'payload': deepcopy(payload), 'protocol': protocol, 'fee': deepcopy(fee)}

    @_wallet_locked
    def sign(self, request, assertion):
        from .app import make_transaction
        need(type(request) is dict and request.get('version') == HOSTED_VERSION, 'HOSTED_REQUEST')
        again = self.signing_request(request['user'], chain=request['chain'], nonce=request['nonce'], op=request['op'],
                                     payload=request['payload'], protocol=request['protocol'], fee=request['fee'])
        need(again == request, 'HOSTED_REQUEST')
        record = self._read(request['user'])
        approval = self._approved(record, request, assertion)
        tx = make_transaction(self._key(record), request['chain'], request['nonce'], request['op'], request['payload'],
                              protocol=request['protocol'], actor=record['public'], fee=request['fee'])
        self._log('SIGN', request['user'], {'request': approval, 'op': request['op'], 'nonce': request['nonce'],
                                             'assertion': deepcopy(assertion)})
        self._used.add(approval)
        return tx

    @_wallet_locked
    def exit_rotation(self, user, *, chain, nonce, successor, possession, protocol, assertion, fee=None):
        """Stage ROTATE and retain the wrapped key until pinned certified confirmation."""
        from .app import make_transaction
        record = self._read(user)
        verification_key(successor)
        body = {'chain': chain, 'entity': record['public'], 'nonce': nonce, 'successor': successor}
        verify(successor, ROTATE_LABEL, body, possession)
        request = {'version': HOSTED_VERSION, 'user': user, 'action': 'EXIT_ROTATE', 'rotation': body,
                   'protocol': protocol, 'fee': deepcopy(fee)}
        if record['status'] == 'EXIT_PENDING':
            pending = record['pending_rotation']
            need(canonical(pending['request']) == canonical(request)
                 and pending['assertion'] == digest('HOSTED-PENDING-ASSERTION-0.1', assertion), 'HOSTED_PENDING_CHANGED')
            self._ensure_log('EXIT_ROTATE_PREPARED', user, {'request': pending['approval'], 'successor': successor})
            return deepcopy(pending['transaction'])
        need(record['status'] == 'ACTIVE', 'HOSTED_USER_' + record['status'])
        approval = self._approved(record, request, assertion)
        tx = make_transaction(self._key(record), chain, nonce, 'ROTATE',
                              {'successor': successor, 'possession': possession},
                              protocol=protocol, actor=record['public'], fee=fee)
        record.update(status='EXIT_PENDING', pending_rotation={'request': request, 'transaction': tx,
                      'assertion': digest('HOSTED-PENDING-ASSERTION-0.1', assertion), 'approval': approval})
        self._write(user, record)
        self._ensure_log('EXIT_ROTATE_PREPARED', user, {'request': approval, 'successor': successor})
        return tx

    @_wallet_locked
    def confirm_rotation(self, user, *, genesis, entries, expected_chain, minimum_height):
        """Clear retained custody only after independently pinned certified history."""
        from .proofs import verify_history
        record = self._read(user)
        need(record['status'] == 'EXIT_PENDING', 'HOSTED_NO_PENDING_ROTATION')
        pending = record['pending_rotation']
        need(type(entries) is list and len(entries) <= 512, 'HOSTED_HISTORY_LIMIT')
        integer(minimum_height, True)
        need(expected_chain == pending['request']['rotation']['chain'], 'HOSTED_ROTATION_CHAIN')
        observed = verify_history(genesis, entries, expected_chain, minimum_height=minimum_height)
        successor = pending['request']['rotation']['successor']
        need(observed['state'].get('controllers', {}).get(record['public']) == successor,
             'HOSTED_ROTATION_NOT_CONFIRMED')
        self._log('EXIT_ROTATE_CONFIRMED', user, {'request': pending['approval'], 'head': observed['head'],
                                               'height': observed['height'], 'successor': successor})
        record.update(status='ROTATED', nonce='', wrapped='')
        self._write(user, record)
        return {'user': user, 'status': 'ROTATED', 'height': observed['height'], 'head': observed['head'],
                'backup_erasure_verified': False, 'execution_authorized': False}

    @_wallet_locked
    def export(self, user, passphrase, assertion):
        """Stage an encrypted export; acknowledgement, not response generation, clears custody."""
        from .onboarding import seal_identity, open_identity
        record = self._read(user)
        request = {'version': HOSTED_VERSION, 'user': user, 'action': 'EXPORT', 'public': record['public']}
        if record['status'] == 'EXPORT_PENDING':
            pending = record['pending_export']
            need(pending['assertion'] == digest('HOSTED-PENDING-ASSERTION-0.1', assertion), 'HOSTED_PENDING_CHANGED')
            need(public_key(Ed25519PrivateKey.from_private_bytes(open_identity(pending['keystore'], passphrase)))
                 == record['public'], 'HOSTED_PENDING_CHANGED')
        else:
            need(record['status'] == 'ACTIVE', 'HOSTED_USER_' + record['status'])
            approval = self._approved(record, request, assertion)
            document = seal_identity(self._key(record).private_bytes_raw(), passphrase)
            receipt = digest('HOSTED-EXPORT-RECEIPT-0.1', {'user': user, 'public': record['public'], 'keystore': document})
            pending = {'keystore': document, 'receipt': receipt, 'approval': approval,
                       'assertion': digest('HOSTED-PENDING-ASSERTION-0.1', assertion)}
            record.update(status='EXPORT_PENDING', pending_export=pending)
            self._write(user, record)
        self._ensure_log('EXPORT_PREPARED', user, {'request': pending['approval'], 'receipt': pending['receipt']})
        return {'keystore': deepcopy(pending['keystore']), 'public': record['public'], 'receipt': pending['receipt'],
                'status': 'EXPORT_PENDING', 'custody_retained_until_acknowledgement': True,
                'note': 'The host held this key. Rotate to a new key if you do not trust the host. '
                        'Acknowledge the exact receipt only after retaining and decrypting this export.',
                'execution_authorized': False}

    @_wallet_locked
    def acknowledge_export(self, user, receipt, assertion):
        record = self._read(user)
        if record['status'] == 'EXPORTED':
            need(receipt == record.get('export_receipt'), 'HOSTED_PENDING_CHANGED')
            return {'user': user, 'receipt': receipt, 'status': 'EXPORTED', 'replayed': True,
                    'backup_erasure_verified': False, 'execution_authorized': False}
        need(record['status'] == 'EXPORT_PENDING' and receipt == record['pending_export']['receipt'], 'HOSTED_PENDING_CHANGED')
        request = {'version': HOSTED_VERSION, 'user': user, 'action': 'ACK_EXPORT', 'receipt': receipt,
                   'public': record['public']}
        if 'pending_ack' in record:
            pending = record['pending_ack']
            need(pending['assertion'] == digest('HOSTED-PENDING-ASSERTION-0.1', assertion), 'HOSTED_PENDING_CHANGED')
            approval = pending['approval']
        else:
            approval = self._approved(record, request, assertion)
            record['pending_ack'] = {'assertion': digest('HOSTED-PENDING-ASSERTION-0.1', assertion), 'approval': approval}
            self._write(user, record)
        self._ensure_log('EXPORT_ACKNOWLEDGED', user, {'request': approval, 'receipt': receipt})
        record.update(status='EXPORTED', nonce='', wrapped='', export_receipt=receipt)
        self._write(user, record)
        return {'user': user, 'receipt': receipt, 'status': 'EXPORTED', 'replayed': False,
                'backup_erasure_verified': False, 'execution_authorized': False}

    def _ensure_log(self, kind, user, detail):
        entries = self.audit_log()
        verify_audit_log(entries, self.audit_public)
        if not any(row['body']['kind'] == kind and row['body']['user'] == user
                   and canonical(row['body']['detail']) == canonical(detail) for row in entries):
            self._log(kind, user, detail)

    def _log(self, kind, user, detail):
        entries = self.audit_log()
        verify_audit_log(entries, self.audit_public)
        need(len(entries) < 4096, 'HOSTED_STORAGE_LIMIT')
        previous = entries[-1]['id'] if entries else None
        now = self._clock()
        integer(now)
        body = {'version': HOSTED_VERSION, 'sequence': len(entries), 'previous': previous, 'time': now,
                'kind': kind, 'user': user, 'detail': detail}
        entry = {'id': digest(AUDIT_LABEL, body), 'body': body, 'signature': sign(self._audit, AUDIT_LABEL, body)}
        fd = os.open(self._log_path, os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            info = os.fstat(fd)
            need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid()
                 and stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_size <= 32 * 1024 * 1024, 'HOSTED_PRIVATE_FILE')
            append_record(fd, canonical(entry) + b'\n')
        finally:
            os.close(fd)

    @_wallet_locked
    def audit_log(self):
        if not self._log_path.exists():
            return []
        return [loads(line) for line in complete_records(self._private_read(self._log_path, 32 * 1024 * 1024)) if line]


def verify_audit_log(entries, audit_public):
    """Check the hash chain and every signature. Returns per-user counts of SIGN entries."""
    verification_key(audit_public)
    need(type(entries) is list and len(entries) <= 4096, 'HOSTED_AUDIT')
    previous = None
    signed = {}
    for index, entry in enumerate(entries):
        need(type(entry) is dict and set(entry) == {'id', 'body', 'signature'}, 'HOSTED_AUDIT')
        body = entry['body']
        need(type(body) is dict and set(body) == {'version','sequence','previous','time','kind','user','detail'}, 'HOSTED_AUDIT')
        need(body['version'] == HOSTED_VERSION and type(body['sequence']) is int
             and body['sequence'] == index and body['previous'] == previous, 'HOSTED_AUDIT_CHAIN')
        integer(body['time'])
        need(type(body['detail']) is dict and type(body['user']) is str and USER_ID.fullmatch(body['user']) is not None,
             'HOSTED_AUDIT')
        need(entry['id'] == digest(AUDIT_LABEL, body), 'HOSTED_AUDIT_CHAIN')
        verify(audit_public, AUDIT_LABEL, body, entry['signature'])
        if body['kind'] == 'SIGN':
            signed[body['user']] = signed.get(body['user'], 0) + 1
        previous = entry['id']
    return {'entries': len(entries), 'head': previous, 'signatures_by_user': signed,
            'user_approval_verified': False, 'completeness_verified': False,
            'whole_file_rollback_prevented': False, 'execution_authorized': False}


def profile():
    return {'version': VERSION, 'guardian_recovery': {'base': continuity.VERSION, 'boundary': list(GUARDIAN_BOUNDARY)},
            'passkey_keystore': {'version': PASSKEY_KEYSTORE_VERSION, 'kdf': 'HKDF-SHA256 over WebAuthn PRF output',
                                 'cipher': 'AES-256-GCM'},
            'encrypted_keystore': 'covenant-encrypted-keystore/0.1 (scrypt + AES-256-GCM); encrypt_existing upgrades plaintext',
            'hosted_wallet': {'version': HOSTED_VERSION, 'mode': 'EXPERIMENTAL_CUSTODIAL_OWNER_API_ONLY',
                              'enabled_by_default': False, 'tool_exposed': False, 'boundary': list(HOSTED_BOUNDARY)},
            'consensus_change': None, 'execution_authorized': False}
