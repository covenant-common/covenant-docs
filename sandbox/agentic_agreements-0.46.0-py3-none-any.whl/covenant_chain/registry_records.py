"""Agent registry records read as untrusted pointers and carriers, and written for AAP agents.

Each format is parsed from bytes the caller holds; nothing is fetched or
submitted. A record adds availability, never trust: only a descriptor signature
by the agent's key (directly, or a foreign signature by that key) counts.

* DNS-AID, draft-mozleywilliams-dnsop-dnsaid-02 (27 May 2026), SVCB (RFC 9460)
  presentation records at the agent's own name, ``_agents`` aliases and the
  ``_index._agents`` organisation index (sections 2-3); SvcParamKeys ``alpn``,
  ``port``, address hints, ``mandatory`` (RFC 9460 section 7) and the draft's
  ``cap``, ``cap-sha256``, ``well-known``, ``bap``, ``policy`` and ``realm``
  (section 7.1). The draft defers key numbers to IANA; the private-use numbers of
  the dns-aid-core and ANS implementations (key65400-key65409) are read and,
  on request, written, labelled as a convention outside the draft. A fetched
  descriptor must match ``cap-sha256`` (section 6.1) or it is refused.
* ANS, draft-narajala-courtney-ansv2-02 (26 October 2026) with the ANS-3 DNS
  publication rules of agentnameservice/ans-registry (spec/ans-3-dns-publication.md
  and discovery-profiles/ans-txt.md 0.1.0, ans-dnsaid.md 0.1.0, commit f33c1aeb):
  ANSName ``ans://v<semver>.<host>`` (ANS-2 section 2); the opt-in ANS_TXT profile
  ``v=ans1; version=v<semver>; p=a2a|mcp|http-api; mode=direct; url=<endpoint>``;
  the default ANS_DNSAID profile as DNS-AID SVCB with the key65400-65409 numbers;
  the ``_ans-badge`` record ``v=ans-badge1; version=v<semver>; url=<badge URL>``. The
  -01 forms (mode card, url the agent card, highest version per protocol, section
  7.4.1) and the legacy ``_ra-badge``/``v=ra-badge1`` badge and bare version are
  still read. Records are pointers. A badge the caller supplies is checked by
  ans_transparency under log keys the owner adopted (never keys named in DNS), and
  then the sealed DNS records and agent card digest are compared with what was
  supplied; the descriptor signature still decides.
* Project NANDA AgentFacts (projnanda/agentfacts-format schema v1, MIT per its
  README) and the lean AgentAddr record (arXiv 2507.14263 section IV). An AAP
  descriptor travels in an ``aap`` member, signed by AAP or covered by a W3C
  eddsa-jcs-2022 proof with a self-certifying method for the descriptor key.
* AGNTCY OASF records (schema 1.1.0, 1.0.0, 0.8.0) and the Directory CID: CIDv1,
  codec 0x01, sha2-256 over Go encoding/json bytes (agntcy/dir
  api/core/v1/cid.go). An AAP agent publishes its signed A2A card in the
  ``integration/a2a`` module, or the envelope in the ``org.aap.descriptor``
  annotation.
"""
from copy import deepcopy
import hashlib
import ipaddress
import re
from urllib.parse import urlsplit

from .crypto import need
from . import interop_codec as codec
from . import signed_discovery as discovery

VERSION = 'covenant-registry-records/0.1'
DNSAID_DRAFT = 'draft-mozleywilliams-dnsop-dnsaid-02'
ANS_DRAFT = 'draft-narajala-courtney-ansv2-02'
ANS_SPEC = 'agentnameservice/ans-registry ANS-3 (f33c1aeb)'
ANS_PROTOCOLS = {'a2a': ('a2a', 'a2a'), 'mcp': ('mcp', 'mcp'), 'http-api': ('http-api', 'x-http')}
A2A_CARD_PATH = '/.well-known/agent-card.json'
SVCB_KEYS = ('mandatory', 'alpn', 'no-default-alpn', 'port', 'ipv4hint', 'ech', 'ipv6hint')
DNSAID_KEYS = ('cap', 'cap-sha256', 'bap', 'policy', 'realm', 'well-known')
PRIVATE_USE = {'key65400': 'cap', 'key65401': 'cap-sha256', 'key65402': 'bap', 'key65403': 'policy',
               'key65404': 'realm', 'key65409': 'well-known'}
NUMBERS = {name: number for number, name in PRIVATE_USE.items()}
OASF_VERSIONS = ('0.8.0', '1.0.0', '1.1.0')
OASF_A2A = {'1.1.0': ('integration/a2a', 203), '1.0.0': ('integration/a2a', 203), '0.8.0': ('integration/a2a', 203)}
OASF_ANNOTATION = 'org.aap.descriptor'
AGENTFACTS_REQUIRED = ('id', 'agent_name', 'label', 'description', 'version', 'provider', 'endpoints', 'capabilities', 'skills')
MAX_RECORDS = 32
MAX_RECORD = 4096
MAX_DOCUMENT = 65536
SEMVER = re.compile(r'(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\Z')
OWNER_LABEL = re.compile(r'[A-Za-z0-9_](?:[A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?\Z')
TOKEN = re.compile(r'[a-z0-9][a-z0-9.+/=-]{0,63}\Z')

REMEDIATION = {
    'DNSAID_RECORD': 'Supply one SVCB presentation record: owner [ttl] [IN] SVCB priority target key=value ...',
    'DNSAID_PARAM': 'Use each SvcParamKey once with a value of the documented form (RFC 9460 section 7, DNS-AID section 7.1).',
    'DNSAID_MANDATORY': 'The record lists a mandatory key this reader does not implement; RFC 9460 section 8 says skip it.',
    'DNSAID_CAP_DIGEST': 'The fetched descriptor does not match cap-sha256; DNS-AID section 6.1 says refuse it.',
    'ANS_NAME': 'Use an ANSName ans://v<major>.<minor>.<patch>.<host> of at most 400 octets.',
    'ANS_RECORD': 'Use a TXT tag-list v=ans1; version=v<semver>; p=<protocol>; url=<https url>; mode=card|direct.',
    'ANS_BADGE_HOST': 'A badge URL host must be the origin of a log you adopted (ANS-6 section 4.2), never one named in DNS.',
    'ANS_SEALED': 'The supplied ANS records or agent card differ from what the log sealed for this registration.',
    'ANS_PROFILE': 'Publish profiles ANS_DNSAID (default) and/or ANS_TXT with endpoints {protocol, url[, card_url, card_sha256]}.',
    'AGENTFACTS': 'Supply AgentFacts with id, agent_name, label, description, version, provider, endpoints, capabilities and skills.',
    'AGENTFACTS_AAP': 'Carry the descriptor in an aap member {descriptor[, signature]}; without signature add an eddsa-jcs-2022 proof.',
    'AGENTFACTS_PROOF': 'Sign the AgentFacts with a DataIntegrityProof (eddsa-jcs-2022) by the descriptor key.',
    'AGENTFACTS_ADDR': 'Supply an AgentAddr with agent_id and an https primary_facts_url (or facts_url).',
    'OASF_RECORD': 'Supply an OASF record with name, version, schema_version, description, authors, created_at and skills.',
    'OASF_VERSION': 'Use OASF schema_version 0.8.0, 1.0.0 or 1.1.0.',
    'OASF_AAP': 'Carry the descriptor in an integration/a2a module card or the org.aap.descriptor annotation.',
    'DISCOVERY_DOCUMENTS': 'A supplied document does not answer a pointer listed in the record (cap, well_known_url or url), or the record lists none. Pass only documents fetched from the record\'s own pointers.',
    'DISCOVERY_SOURCE': 'The registry source has missing or extra fields for its kind: DNS-AID takes source and records, ANS source, host and records, AgentFacts source and document (each with optional documents), OASF exactly source and record. Pass exactly those fields.',
    'DISCOVERY_SIZE': 'The AgentFacts document or OASF record is not text or is longer than 65536 characters. Pass the record as text within that size.',
}


def remediation(code):
    return REMEDIATION.get(code, discovery.remediation(code))


def _ascii(value, maximum, code, empty=False):
    need(type(value) is str and (empty or value) and len(value) <= maximum and value.isascii() and value.isprintable(), code)
    return value


def _owner(name):
    text = name[:-1] if name.endswith('.') else name
    need(0 < len(text) <= 253 and all(OWNER_LABEL.fullmatch(label) for label in text.split('.')), 'DNSAID_RECORD')
    return text.lower()


def _tokens(text):
    """RFC 1035 section 5.1 master-file tokens of one record: quotes, escapes, comments and parentheses."""
    tokens, current, quoted, escaped, started = [], [], False, False, False
    for char in text:
        if escaped:
            current.append('\\' + char); escaped = False; continue
        if char == '\\':
            escaped = True; started = True; continue
        if char == '"':
            quoted = not quoted; current.append('"'); started = True; continue
        if not quoted and char == ';':
            break
        if not quoted and char in ' \t\r\n()':
            if started:
                tokens.append(''.join(current)); current, started = [], False
            continue
        current.append(char); started = True
    need(not quoted and not escaped, 'DNSAID_RECORD')
    if started:
        tokens.append(''.join(current))
    return tokens


def _unescape(value):
    """A presentation char-string: optional quotes, \\X and \\DDD escapes (RFC 9460 appendix A)."""
    if len(value) >= 2 and value[0] == value[-1] == '"':
        value = value[1:-1]
    need('"' not in value.replace('\\"', ''), 'DNSAID_PARAM')
    out, index = [], 0
    while index < len(value):
        char = value[index]
        if char == '\\':
            if value[index + 1:index + 4].isdigit() and len(value[index + 1:index + 4]) == 3:
                code = int(value[index + 1:index + 4]); need(code <= 255, 'DNSAID_PARAM')
                out.append(chr(code)); index += 4; continue
            need(index + 1 < len(value), 'DNSAID_PARAM')
            out.append(value[index + 1]); index += 2; continue
        out.append(char); index += 1
    text = ''.join(out)
    need(text.isascii() and text.isprintable() and len(text) <= 2048, 'DNSAID_PARAM')
    return text


def _list(text):
    items = text.split(',')
    need(all(items) and len(items) <= 16, 'DNSAID_PARAM')
    return items


def parse_svcb(text):
    """One DNS-AID SVCB record in presentation format, with its SvcParams checked."""
    _ascii(text, MAX_RECORD, 'DNSAID_RECORD')
    tokens = _tokens(text)
    need(len(tokens) >= 4, 'DNSAID_RECORD')
    owner, rest = _owner(tokens[0]), tokens[1:]
    ttl = None
    while rest and rest[0].upper() != 'SVCB':
        head = rest.pop(0)
        if head.isdigit() and ttl is None and len(head) <= 10:
            ttl = int(head)
        else:
            need(head.upper() == 'IN', 'DNSAID_RECORD')
    need(len(rest) >= 3 and rest[1].isdigit() and len(rest[1]) <= 5 and int(rest[1]) <= 65535, 'DNSAID_RECORD')
    priority, target = int(rest[1]), rest[2]
    target = '.' if target == '.' else _owner(target)
    record = {'owner': owner, 'ttl': ttl, 'priority': priority, 'target': target,
              'mode': 'ALIAS' if priority == 0 else 'SERVICE', 'params': {}, 'unknown_keys': []}
    if priority == 0:
        return record  # RFC 9460 section 2.4.2: AliasMode SvcParams are ignored.
    for token in rest[3:]:
        name, sep, raw = token.partition('=')
        name = name.lower()
        need(re.fullmatch(r'[a-z0-9-]{1,63}', name) is not None, 'DNSAID_PARAM')
        name = PRIVATE_USE.get(name, name)
        need(name not in record['params'] and name not in record['unknown_keys'], 'DNSAID_PARAM')
        value = _unescape(raw) if sep else None
        if name in ('mandatory', 'alpn', 'bap', 'ipv4hint', 'ipv6hint'):
            need(value is not None, 'DNSAID_PARAM')
            items = _list(value)
            if name in ('ipv4hint', 'ipv6hint'):
                kind = ipaddress.IPv4Address if name == 'ipv4hint' else ipaddress.IPv6Address
                try:
                    [kind(item) for item in items]
                except ValueError:
                    raise ValueError('DNSAID_PARAM') from None
            elif name != 'mandatory':
                need(all(TOKEN.fullmatch(item) for item in items), 'DNSAID_PARAM')
            record['params'][name] = items
        elif name == 'port':
            need(value is not None and value.isdigit() and len(value) <= 5 and int(value) <= 65535, 'DNSAID_PARAM')
            record['params'][name] = int(value)
        elif name == 'no-default-alpn':
            need(value is None, 'DNSAID_PARAM'); record['params'][name] = True
        elif name == 'cap-sha256':
            need(value is not None, 'DNSAID_PARAM')
            try:
                need(len(codec.b64url_decode(value, 32)) == 32, 'DNSAID_PARAM')
            except ValueError:
                raise ValueError('DNSAID_PARAM') from None
            record['params'][name] = value
        elif name in ('cap', 'well-known', 'policy', 'realm', 'ech'):
            need(value is not None and value, 'DNSAID_PARAM')
            record['params'][name] = value
        else:
            record['unknown_keys'].append(name)
    for name in record['params'].get('mandatory', []):
        name = PRIVATE_USE.get(name, name)
        need(name not in ('mandatory',) and (name in record['params'] or name in record['unknown_keys']), 'DNSAID_PARAM')
        need(name in SVCB_KEYS + DNSAID_KEYS, 'DNSAID_MANDATORY')
    return record


def _well_known_url(record):
    known = record['params'].get('well-known')
    if known is None:
        return None
    host = record['owner'] if record['target'] == '.' else record['target']
    port = record['params'].get('port')
    authority = host + (':' + str(port) if port not in (None, 443) else '')
    return 'https://' + authority + (known if known.startswith('/') else '/.well-known/' + known)


def dns_aid_pointer(record):
    params = record['params']
    cap = params.get('cap')
    return {'kind': 'DNS_AID_SVCB', 'owner': record['owner'], 'mode': record['mode'], 'priority': record['priority'],
            'target': record['target'], 'alpn': params.get('alpn'), 'bap': params.get('bap'), 'port': params.get('port'),
            'cap': cap, 'cap_sha256': params.get('cap-sha256'), 'well_known_url': _well_known_url(record),
            'policy': params.get('policy'), 'realm': params.get('realm'),
            'index': record['owner'].startswith('_index._agents.'), 'assurance': 'UNSIGNED_POINTER_NO_CLAIMS'}


def _pointer_documents(pointers, fetched, digest_check):
    items, refused = [], []
    for url in sorted(fetched):
        matches = [p for p in pointers if url in (p.get('cap'), p.get('well_known_url'), p.get('url'))]
        need(bool(matches), 'DISCOVERY_DOCUMENTS')  # A supplied document must answer a listed pointer.
        body = fetched[url]
        try:
            if digest_check:
                for pointer in matches:
                    if pointer.get('cap') == url and pointer.get('cap_sha256') is not None:
                        need(codec.b64url(hashlib.sha256(body.encode('utf-8')).digest()) == pointer['cap_sha256'],
                             'DNSAID_CAP_DIGEST')
                        pointer['integrity'] = 'CAP_SHA256_MATCHED'
            found, meta = discovery.foreign_document(body)
            items.extend(found)
            for pointer in matches:
                pointer['fetched'] = meta['document']
        except ValueError as error:
            refused.append(str(error) if str(error).isupper() else 'DISCOVERY_FOREIGN_DOCUMENT')
    return items, refused


def _dns_aid_source(item):
    need({'source', 'records'} <= set(item) <= {'source', 'records', 'documents'}, 'DISCOVERY_SOURCE')
    need(type(item['records']) is list and 1 <= len(item['records']) <= MAX_RECORDS, 'DNSAID_RECORD')
    fetched = discovery.documents(item.get('documents'))
    pointers, refused = [], []
    for text in item['records']:
        try:
            pointers.append(dns_aid_pointer(parse_svcb(text)))
        except ValueError as error:
            refused.append(str(error) if str(error).isupper() else 'DNSAID_RECORD')
    items, more = _pointer_documents(pointers, fetched, True)
    owners = sorted({p['owner'] for p in pointers})
    return items, {'locator': 'dns-aid:' + ','.join(owners)[:256], 'draft': DNSAID_DRAFT}, pointers, refused + more


def dns_aid_records(envelope, owner, cap_url, *, target='.', port=443, ttl=3600, numeric=False):
    """SVCB records publishing an AAP agent under DNS-AID: one ServiceMode record per a2a/mcp endpoint transport.

    ``cap`` locates the AAP descriptor document (the canonical envelope bytes) and
    ``cap-sha256`` is its base64url SHA-256. ``numeric`` writes the private-use key
    numbers instead of the draft's names, which IANA has not assigned.
    """
    opened = discovery.open_descriptor(envelope)
    owner = _owner(owner); target = '.' if target == '.' else _owner(target)
    need(type(cap_url) is str and cap_url.startswith('https://') and len(cap_url) <= 2048 and cap_url.isascii(), 'DNSAID_PARAM')
    need(type(port) is int and 1 <= port <= 65535 and type(ttl) is int and 0 <= ttl <= 2**31 - 1, 'DNSAID_PARAM')
    raw = discovery.encode(envelope).encode('ascii')
    digest_text = codec.b64url(hashlib.sha256(raw).digest())
    protocols = sorted({row['transport'] for row in opened['body']['endpoints'] if row['transport'] in ('a2a', 'mcp')}) or ['a2a']
    name = (lambda key: NUMBERS[key]) if numeric else (lambda key: key)
    lines = []
    for protocol in protocols:
        params = ['alpn=' + protocol + ',h2', 'port=' + str(port), name('cap') + '="' + cap_url + '"',
                  name('cap-sha256') + '=' + digest_text, name('bap') + '=' + protocol, name('well-known') + '=aap-agent.json']
        lines.append(' '.join([owner + '.', str(ttl), 'IN', 'SVCB', '1', target if target == '.' else target + '.'] + params))
    for line in lines:
        parse_svcb(line)
    return {'records': lines, 'document': {'url': cap_url, 'body': raw.decode('ascii'), 'sha256_b64url': digest_text},
            'descriptor': opened['id'], 'key_numbers': 'PRIVATE_USE_CONVENTION_NOT_IN_DRAFT' if numeric else 'DRAFT_NAMES_UNASSIGNED',
            'dnssec': 'OWNER_SIGNS_THE_ZONE', 'publication': 'OWNER_PUBLISHES', 'execution_authorized': False}


def parse_ans_name(text):
    """ANSName of draft-narajala-courtney-ansv2-01 section 5.1: ans://v<major>.<minor>.<patch>.<agentHost>."""
    need(type(text) is str and text.isascii() and 0 < len(text) <= 400 and text.startswith('ans://v'), 'ANS_NAME')
    found = re.fullmatch(r'ans://v((?:0|[1-9][0-9]{0,8})\.(?:0|[1-9][0-9]{0,8})\.(?:0|[1-9][0-9]{0,8}))\.(.+)', text)
    need(found is not None, 'ANS_NAME')
    host = found.group(2)
    need(len(host) <= 253 and '.' in host and all(re.fullmatch(r'(?!-)[A-Za-z0-9-]{1,63}(?<!-)', label)
                                                  for label in host.split('.')), 'ANS_NAME')
    return {'name': text, 'version': found.group(1), 'host': host.lower()}


def _ans_tags(text):
    _ascii(text, MAX_RECORD, 'ANS_RECORD')
    tags = {}
    for part in text.split(';'):
        if not part.strip():
            continue
        name, sep, value = part.partition('=')
        name, value = name.strip(), value.strip()
        need(sep == '=' and re.fullmatch(r'[a-z][a-z0-9_-]{0,31}', name) and name not in tags and value, 'ANS_RECORD')
        tags[name] = value
    return tags


def _semver_key(text):
    found = SEMVER.fullmatch(text)
    need(found is not None, 'ANS_RECORD')
    return tuple(int(part) for part in found.groups())


def parse_ans_record(text, host):
    """One ``_ans`` TXT or ``_ans-badge`` (legacy ``_ra-badge``) record as a pointer (ANS-3 section 6, -01 7.4)."""
    tags = _ans_tags(text)
    need(tags.get('v') in ('ans1', 'ans-badge1', 'ra-badge1'), 'ANS_RECORD')
    badge = tags['v'] != 'ans1'
    raw_version = tags.get('version')
    need(raw_version is not None or badge, 'ANS_RECORD')
    version = None if raw_version is None else (raw_version[1:] if raw_version.startswith('v') else raw_version)
    if version is not None:
        _semver_key(version)
    url = tags.get('url')
    need(url is None or (url.startswith(('https://', 'wss://')) and len(url) <= 2048), 'ANS_RECORD')
    name = None if version is None else parse_ans_name('ans://v' + version + '.' + host)['name']
    if badge:
        need(url is not None and url.startswith('https://'), 'ANS_RECORD')
        return {'kind': 'ANS_BADGE', 'ans_name': name, 'version': version, 'url': url, 'ra': tags.get('ra'),
                'legacy': tags['v'] == 'ra-badge1', 'assurance': 'TRANSPARENCY_LOG_BADGE_NOT_VERIFIED'}
    mode = tags.get('mode', 'card')
    protocol = tags.get('p')
    need(mode in ('card', 'direct') and (protocol is None or TOKEN.fullmatch(protocol)), 'ANS_RECORD')
    need(url is not None or mode == 'direct', 'ANS_RECORD')
    # ANS-3: a direct A2A endpoint's card is at the A2A well-known path of the agent host.
    card = 'https://' + host + A2A_CARD_PATH if mode == 'direct' and protocol == 'a2a' else None
    return {'kind': 'ANS_TXT', 'ans_name': name, 'version': version, 'protocol': protocol, 'mode': mode,
            'url': url if mode == 'card' else None, 'endpoint': url if mode == 'direct' else None,
            'well_known_url': card, 'text': text, 'assurance': 'UNSIGNED_POINTER_NO_CLAIMS'}


def _ans_badges(pointers, fetched, logs, host):
    """Check supplied badges under adopted ANS log keys; compare sealed records and card digests with the supplied ones."""
    from . import ans_transparency
    lines = [row['line'] for row in logs if row.get('format') == 'ANS_TL']
    registrations, refused = [], []
    for pointer in [p for p in pointers if p['kind'] == 'ANS_BADGE' and p['url'] in fetched]:
        body = fetched.pop(pointer['url'])
        try:
            origin = urlsplit(pointer['url']).hostname
            need(any(line.split('+', 1)[0] == origin for line in lines), 'ANS_BADGE_HOST')
            found = ans_transparency.badge(body, lines)
            claims = found['record']['claims']
            need(claims['host'] == host and (pointer['version'] is None or claims['version'] == pointer['version']),
                 'ANS_SEALED')
            sealed = claims['sealed_records']
            for other in pointers:
                if other['kind'] == 'ANS_TXT' and other['version'] == claims['version']:
                    other['sealed'] = other.get('text') in sealed.get('_ans.' + host, [])
            pointer['assurance'] = 'BADGE_INCLUDED_IN_ADOPTED_LOG_STATUS_UNSIGNED'
            pointer['registration'] = found['id']
            registrations.append({'evidence': found['id'], 'log': claims['log'], 'tree_size': claims['tree_size'],
                                  'ans_name': claims['ans_name'], 'event_type': claims['event_type'],
                                  'metadata_hashes': claims['metadata_hashes'], 'status': found['record']['checks']['status']})
        except ValueError as error:
            refused.append(str(error) if str(error).isupper() else 'ANS_BADGE')
    for registration in registrations:
        sealed_card = registration['metadata_hashes'].get('A2A')
        for pointer in pointers:
            card = pointer.get('well_known_url') or pointer.get('url')
            if sealed_card and pointer['kind'] == 'ANS_TXT' and pointer.get('protocol') == 'a2a' and card in fetched:
                digest = hashlib.sha256(fetched[card].encode('utf-8')).hexdigest()
                if 'SHA256:' + digest != sealed_card.replace('sha256:', 'SHA256:'):
                    fetched.pop(card)
                    refused.append('ANS_SEALED')
                else:
                    pointer['integrity'] = 'SEALED_AGENT_CARD_DIGEST_MATCHED'
    return registrations, refused


def _ans_source(item, logs=()):
    need({'source', 'host', 'records'} <= set(item) <= {'source', 'host', 'records', 'documents'}, 'DISCOVERY_SOURCE')
    host = parse_ans_name('ans://v0.0.0.' + str(item['host']))['host']
    need(type(item['records']) is list and 1 <= len(item['records']) <= MAX_RECORDS, 'ANS_RECORD')
    fetched = discovery.documents(item.get('documents'))
    pointers, refused = [], []
    for text in item['records']:
        try:
            pointers.append(parse_ans_record(text, host))
        except ValueError as error:
            refused.append(str(error) if str(error).isupper() else 'ANS_RECORD')
    best = {}
    for pointer in pointers:  # -01 section 7.4.1: per protocol, the highest version (ANS-3 has no such rule).
        if pointer['kind'] == 'ANS_TXT':
            slot = pointer['protocol'] or '*'
            if slot not in best or _semver_key(pointer['version']) > _semver_key(best[slot]['version']):
                best[slot] = pointer
    for pointer in pointers:
        if pointer['kind'] == 'ANS_TXT':
            pointer['selected'] = best[pointer['protocol'] or '*'] is pointer
    registrations, checked = _ans_badges(pointers, fetched, logs, host)
    items, more = _pointer_documents(pointers, fetched, False)
    for pointer in pointers:
        pointer.pop('text', None)
    return items, {'locator': '_ans.' + host, 'draft': ANS_DRAFT, 'ans_registrations': registrations}, pointers, \
        refused + checked + more


def ans_records(host, version, card_url, protocol='a2a'):
    """``_ans`` TXT text and ANSName for an AAP agent whose signed A2A card is at ``card_url``."""
    name = parse_ans_name('ans://v' + str(version) + '.' + str(host))
    need(type(card_url) is str and card_url.startswith('https://') and len(card_url) <= 2048 and card_url.isascii(), 'ANS_RECORD')
    need(type(protocol) is str and TOKEN.fullmatch(protocol) is not None, 'ANS_RECORD')
    text = 'v=ans1; version=v' + name['version'] + '; p=' + protocol + '; url=' + card_url
    parse_ans_record(text, name['host'])
    return {'ans_name': name['name'], 'owner': '_ans.' + name['host'] + '.', 'txt': text,
            'badge': 'REGISTRATION_AUTHORITY_ISSUES_BADGE_NOT_AAP', 'publication': 'OWNER_PUBLISHES',
            'execution_authorized': False}


def ans_profile_records(host, version, endpoints, *, badge_url=None, profiles=('ANS_DNSAID',)):
    """ANS-3 records for an AAP agent: ANS_DNSAID SVCB rows (default), ANS_TXT rows, and the badge record.

    ``endpoints`` are {protocol (a2a, mcp or http-api), url[, card_url, card_sha256 (64 hex)]}; the signed
    A2A card at card_url carries the AAP descriptor. ``badge_url`` is the registration's log record, issued by
    the registration authority, so the badge row exists only once the owner has registered.
    """
    name = parse_ans_name('ans://v' + str(version) + '.' + str(host))
    need(type(profiles) in (list, tuple) and profiles and set(profiles) <= {'ANS_DNSAID', 'ANS_TXT'}, 'ANS_PROFILE')
    need(type(endpoints) is list and 0 < len(endpoints) <= 8, 'ANS_PROFILE')
    seen, txt, svcb = set(), [], []
    for row in endpoints:
        need(type(row) is dict and set(row) <= {'protocol', 'url', 'card_url', 'card_sha256'} and row.get('protocol')
             in ANS_PROTOCOLS and row['protocol'] not in seen, 'ANS_PROFILE')
        seen.add(row['protocol'])
        url = row.get('url')
        need(type(url) is str and url.startswith(('https://', 'wss://')) and len(url) <= 2048 and url.isascii()
             and url.isprintable() and _url_host(url) == name['host'], 'ANS_PROFILE')
        token, alpn = ANS_PROTOCOLS[row['protocol']]
        text = 'v=ans1; version=v' + name['version'] + '; p=' + token + '; mode=direct; url=' + url
        parse_ans_record(text, name['host'])
        txt.append(text)
        params = ['alpn=' + alpn, 'port=443']
        if row.get('card_url') is not None:
            need(type(row['card_url']) is str and row['card_url'].startswith('https://') and len(row['card_url']) <= 2048
                 and ' ' not in row['card_url'], 'ANS_PROFILE')
            params.append('key65400=' + row['card_url'])
            if row.get('card_sha256') is not None:
                need(type(row['card_sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['card_sha256']), 'ANS_PROFILE')
                params.append('key65401=' + codec.b64url(bytes.fromhex(row['card_sha256'])))
        params.append('key65402=' + token)
        line = name['host'] + '. 3600 IN SVCB 1 . ' + ' '.join(params)
        parse_svcb(line)
        svcb.append(line)
    out = {'ans_name': name['name'], 'profiles': list(profiles), 'records': []}
    if 'ANS_TXT' in profiles:
        out['records'] += ['_ans.' + name['host'] + '. 3600 IN TXT "' + text + '"' for text in txt]
        out['records'].append(name['host'] + '. 3600 IN HTTPS 1 . alpn=h2')
    if 'ANS_DNSAID' in profiles:
        out['records'] += svcb
    if badge_url is not None:
        need(type(badge_url) is str and badge_url.startswith('https://') and len(badge_url) <= 2048
             and badge_url.isascii() and badge_url.isprintable() and ' ' not in badge_url, 'ANS_PROFILE')
        badge = 'v=ans-badge1; version=v' + name['version'] + '; url=' + badge_url
        parse_ans_record(badge, name['host'])
        out['records'].append('_ans-badge.' + name['host'] + '. 3600 IN TXT "' + badge + '"')
    out.update(spec=ANS_SPEC, key_numbers='PRIVATE_USE_CONVENTION_OF_ANS_AND_DNS_AID_CORE',
               badge='ISSUED_BY_THE_REGISTRATION_AUTHORITY_LOG' if badge_url is None else 'LOG_RECORD_URL_SUPPLIED',
               dnssec='OWNER_SIGNS_THE_ZONE', publication='OWNER_PUBLISHES', execution_authorized=False)
    return out


def _url_host(url):
    try:
        return (urlsplit(url).hostname or '').lower()
    except ValueError:
        return ''


def ans_registration(envelope, host, version, card_url):
    """An ANSv2 registration request body (section 7.1.1) without CSRs; the owner adds keys and submits it."""
    opened = discovery.open_descriptor(envelope)
    body = opened['body']
    name = parse_ans_name('ans://v' + str(version) + '.' + str(host))
    endpoints = [{'protocol': row['transport'].upper(), 'agentUrl': row['uri'], 'metadataUrl': card_url,
                  'functions': [{'id': task, 'name': task, 'tags': [task]} for task in body['task_classes']]}
                 for row in body['endpoints'] if row['transport'] in ('a2a', 'mcp')]
    need(bool(endpoints), 'ANS_RECORD')
    return {'request': {'agentDisplayName': body['name'][:64], 'agentDescription': (body['summary'] or body['name'])[:150],
                        'version': name['version'], 'agentHost': name['host'], 'endpoints': endpoints},
            'ans_name': name['name'], 'csr': 'OWNER_GENERATES_IDENTITY_CSR_OUTSIDE_AAP', 'submitted': False,
            'execution_authorized': False}


def _aap_member(value, code):
    need(type(value) is dict and type(value.get('descriptor')) is dict and set(value) <= {'descriptor', 'signature'}, code)
    return codec.integral(value['descriptor']), value.get('signature')


def _self_signed(document, body, code):
    from .anp_discovery import self_certifying
    proof = document.get('proof')
    need(type(proof) is dict and proof.get('type') == codec.DI_TYPE and proof.get('cryptosuite') == codec.DI_SUITE
         and self_certifying(proof.get('verificationMethod'), body.get('key')), code)
    try:
        codec.di_verify(document, body['key'])
    except ValueError:
        raise ValueError(code) from None
    return [discovery.attested(body, 'W3C_EDDSA_JCS_2022', body['key'])]


def agentfacts_items(value):
    """Descriptor items one AgentFacts document carries."""
    need(type(value) is dict and all(name in value for name in AGENTFACTS_REQUIRED), 'AGENTFACTS')
    need(type(value['provider']) is dict and type(value['endpoints']) is dict and type(value['endpoints'].get('static')) is list
         and type(value['capabilities']) is dict and type(value['skills']) is list and value['skills'], 'AGENTFACTS')
    body, signature = _aap_member(value.get('aap'), 'AGENTFACTS_AAP')
    if signature is not None:
        return [{'body': body, 'signature': signature}]
    need(type(body.get('key')) is str and len(body['key']) == 64, 'AGENTFACTS_AAP')
    return _self_signed(value, body, 'AGENTFACTS_PROOF')


def agent_addr(value):
    """A NANDA AgentAddr lean record as a pointer; its index signature format is unspecified and unchecked."""
    need(type(value) is dict, 'AGENTFACTS_ADDR')
    url = value.get('primary_facts_url', value.get('facts_url'))
    need(type(value.get('agent_id')) is str and type(url) is str and url.startswith('https://') and len(url) <= 2048,
         'AGENTFACTS_ADDR')
    pointer = {'kind': 'NANDA_AGENT_ADDR', 'agent_id': value['agent_id'][:256], 'url': url,
               'agent_name': value.get('agent_name') if type(value.get('agent_name')) is str else None,
               'ttl': value.get('ttl') if type(value.get('ttl')) is int else None,
               'index_signature': 'FORMAT_UNSPECIFIED_NOT_VERIFIED', 'assurance': 'UNSIGNED_POINTER_NO_CLAIMS'}
    private = value.get('private_facts_url')
    if type(private) is str and private.startswith('https://'):
        pointer['private_facts_url'] = private
    return pointer


def _agentfacts_source(item):
    need({'source', 'document'} <= set(item) <= {'source', 'document', 'documents'}, 'DISCOVERY_SOURCE')
    need(type(item['document']) is str and len(item['document']) <= MAX_DOCUMENT, 'DISCOVERY_SIZE')
    fetched = discovery.documents(item.get('documents'))
    try:
        value = codec.parse(item['document'], MAX_DOCUMENT, 24, 8192)
    except ValueError:
        raise ValueError('AGENTFACTS') from None
    need(type(value) is dict, 'AGENTFACTS')
    if 'agent_id' in value:
        pointer = agent_addr(value)
        extra = [{'url': pointer['private_facts_url']}] if 'private_facts_url' in pointer else []
        items, refused = _pointer_documents([pointer] + extra, fetched, False)
        return items, {'locator': 'nanda:' + pointer['agent_id'][:200]}, [pointer], refused
    need(not fetched, 'DISCOVERY_DOCUMENTS')
    return agentfacts_items(value), {'locator': 'agentfacts:' + str(value.get('agent_name'))[:200]}, [], []


def agentfacts(envelope, provider, *, version=None, agent_name=None, signed=True):
    """NANDA AgentFacts (schema v1) for an AAP agent, with the descriptor in its ``aap`` member."""
    opened = discovery.open_descriptor(envelope)
    body = opened['body']
    need(type(provider) is dict and type(provider.get('name')) is str and type(provider.get('url')) is str
         and set(provider) <= {'name', 'url', 'did'}, 'AGENTFACTS')
    version = version if version is not None else str(body['sequence']) + '.0.0'
    need(type(version) is str and SEMVER.fullmatch(version) is not None, 'AGENTFACTS')
    identifier = codec.did_key(body['key']).split('#')[0]
    facts = {'id': identifier, 'agent_name': agent_name or 'urn:agent:aap:' + body['key'], 'label': body['name'],
             'description': body['summary'] or body['name'], 'version': version, 'provider': deepcopy(provider),
             'endpoints': {'static': [row['uri'] for row in body['endpoints'] if row['uri'].startswith('https://')]},
             'capabilities': {'modalities': ['text'], 'authentication': {'methods': ['aap-ed25519-signed-request']}},
             'skills': [{'id': task, 'description': 'AAP task class ' + task, 'inputModes': ['application/json'],
                         'outputModes': ['application/json']} for task in body['task_classes']],
             'aap': {'descriptor': deepcopy(body)} if signed else {'descriptor': deepcopy(body), 'signature': envelope['signature']}}
    prepared = codec.di_prepare(facts, codec.did_key(body['key'])) if signed else None
    return {'agentfacts': facts, 'descriptor': opened['id'], 'mode': 'SIGNED_AGENTFACTS' if signed else 'CARRIER',
            'proof_options': None if prepared is None else prepared['proof_options'],
            'hash_data': None if prepared is None else prepared['hash_data'],
            'required_signers': [body['key']] if signed else [], 'signature_created': False,
            'credential_status': 'NOT_A_VC_STATUS_LIST', 'publication': 'OWNER_PUBLISHES', 'execution_authorized': False}


def sign_agentfacts(prepared, private_key):
    """Explicit local owner action: attach the eddsa-jcs-2022 proof. Not exposed as a tool."""
    need(type(prepared) is dict and prepared.get('proof_options') is not None
         and codec.owner_key(private_key) == prepared['required_signers'][0], 'AGENTFACTS_PROOF')
    return codec.di_sign(prepared['agentfacts'], prepared['proof_options'], private_key)


def oasf_cid(record):
    """The AGNTCY Directory CID of a record: CIDv1, codec 0x01, sha2-256 of Go encoding/json bytes."""
    need(type(record) is dict, 'OASF_RECORD')
    return codec.cid_v1(codec.go_json(record))


def _oasf(value):
    need(type(value) is dict and all(name in value for name in ('name', 'version', 'schema_version', 'description',
                                                                 'authors', 'created_at', 'skills')), 'OASF_RECORD')
    need(value['schema_version'] in OASF_VERSIONS, 'OASF_VERSION')
    need(type(value['authors']) is list and value['authors'] and type(value['skills']) is list
         and all(type(skill) is dict and ('name' in skill or 'id' in skill) for skill in value['skills']), 'OASF_RECORD')
    modules = value.get('modules', [])
    need(type(modules) is list and len(modules) <= 64, 'OASF_RECORD')
    return modules


def oasf_items(value):
    """Descriptor items one OASF record carries: the integration/a2a card, or the AAP annotation."""
    modules = _oasf(value)
    name, _ = OASF_A2A[value['schema_version']]
    cards = [row['data']['card_data'] for row in modules if type(row) is dict and row.get('name') == name
             and type(row.get('data')) is dict and type(row['data'].get('card_data')) is dict]
    annotation = value.get('annotations', {}).get(OASF_ANNOTATION) if type(value.get('annotations')) is dict else None
    items = []
    if annotation is not None:
        items.extend(discovery._document(annotation))
    from .a2a_discovery import extract
    for card in cards:
        try:
            items.extend(extract(card))
        except ValueError:
            continue  # An ordinary A2A card without the AAP extension carries nothing for AAP.
    need(bool(items), 'OASF_AAP')
    return items


def _oasf_source(item):
    need(set(item) == {'source', 'record'}, 'DISCOVERY_SOURCE')
    need(type(item['record']) is str and len(item['record']) <= MAX_DOCUMENT, 'DISCOVERY_SIZE')
    try:
        value = codec.parse(item['record'], MAX_DOCUMENT, 24, 8192)
    except ValueError:
        raise ValueError('OASF_RECORD') from None
    items = oasf_items(value)
    cid = oasf_cid(value)
    return items, {'locator': 'oasf:' + cid, 'cid': cid, 'schema_version': value['schema_version']}, [], []


def oasf_record(envelope, card, *, skills, authors, version, created_at, schema_version='1.1.0'):
    """An OASF record for an AAP agent carrying its A2A card (a signed card keeps its JWS) and the envelope."""
    opened = discovery.open_descriptor(envelope)
    body = opened['body']
    need(schema_version in OASF_VERSIONS and type(card) is dict, 'OASF_VERSION')
    need(type(skills) is list and skills and all(type(row) is dict and set(row) <= {'name', 'id'} and row for row in skills)
         and type(authors) is list and authors and all(type(name) is str and name for name in authors), 'OASF_RECORD')
    codec.datetime_stamp(created_at)
    name, number = OASF_A2A[schema_version]
    record = {'name': body['name'], 'version': version, 'schema_version': schema_version,
              'description': body['summary'] or body['name'], 'authors': list(authors), 'created_at': created_at,
              'skills': deepcopy(skills), 'annotations': {OASF_ANNOTATION: discovery.encode(envelope)},
              'modules': [{'id': number, 'name': name, 'data': {'card_data': deepcopy(card), 'card_schema_version': 'v1.0.0'}}]}
    oasf_items(record)
    return {'record': record, 'cid': oasf_cid(record), 'descriptor': opened['id'],
            'directory_signature': 'OWNER_SIGNS_CID_WITH_DIRECTORY_TOOLS_OUTSIDE_AAP', 'publication': 'OWNER_PUBLISHES',
            'execution_authorized': False}


def source(item, logs=()):
    """Signed-discovery adapter for DNS_AID, ANS, AGENTFACTS and OASF sources; ANS badges use adopted ANS logs."""
    need(type(item) is dict, 'DISCOVERY_SOURCE')
    kind = item.get('source')
    if kind == 'DNS_AID':
        return _dns_aid_source(item)
    if kind == 'ANS':
        return _ans_source(item, logs)
    if kind == 'AGENTFACTS':
        return _agentfacts_source(item)
    need(kind == 'OASF', 'DISCOVERY_SOURCE')
    return _oasf_source(item)


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_ADAPTER',
            'dns_aid': {'draft': DNSAID_DRAFT, 'record': 'SVCB_RFC9460', 'keys': list(DNSAID_KEYS),
                        'private_use_convention': dict(PRIVATE_USE), 'integrity': 'CAP_SHA256_ELSE_REFUSE'},
            'ans': {'draft': ANS_DRAFT, 'spec': ANS_SPEC, 'name': 'ans://v<semver>.<host>',
                    'records': ['_ans', '_ans-badge', '_ra-badge (legacy)', 'ANS_DNSAID SVCB'],
                    'profiles': ['ANS_DNSAID', 'ANS_TXT'],
                    'badges': 'VERIFIED_UNDER_OWNER_ADOPTED_ANS_LOG_KEYS_STATUS_UNSIGNED'},
            'nanda': {'agentfacts': 'projnanda/agentfacts-format v1', 'aap_member': 'aap', 'agent_addr': 'POINTER_ONLY'},
            'oasf': {'versions': list(OASF_VERSIONS), 'cid': 'CIDV1_CODEC_0X01_SHA256_GO_JSON', 'annotation': OASF_ANNOTATION,
                     'module': 'integration/a2a'},
            'remediation': dict(REMEDIATION), 'records_add_trust': False, 'network_accessed': False,
            'execution_authorized': False}
