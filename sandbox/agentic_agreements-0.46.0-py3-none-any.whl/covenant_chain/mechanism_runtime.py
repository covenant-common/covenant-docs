"""Explicit installed interpretation, scoped disclosure and workflow-only effects.

Owner callbacks are a trust boundary. Tool arguments never install code, select
an endpoint/key file, grant a capability or interpret an unfamiliar system.
"""
from copy import deepcopy
import hashlib,json
from pathlib import Path
from covenant_language import mechanism_plans as p
from .crypto import need,exact
from .workflow_store import canonical as wire,WorkflowStore,identifier as custody_id
from .adapters import manifest,manifest_id,_instance
from .private_covenant import _seal_payload,_open_payload,LARGE_CONTENT_BYTES
DELIVERY='covenant-mechanism-delivery/0.1'
IMPLEMENTATION=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def call_context(context):
    return p._id('COVENANT-MECHANISM-CALL-CONTEXT-0.1',{k:context[k] for k in ('context','plan','step','binding')})
def _context(plan,step,index,parameters):
    return {'context':plan['context'],'plan':p.identifier(plan),'step':step['id'],'binding':index,'target':deepcopy(step['target']),'parameters':deepcopy(parameters),'recipients':deepcopy(step['recipients'])}
def delivery_id(delivery):return hashlib.sha256(b'COVENANT-MECHANISM-DELIVERY-0.1\0'+wire(delivery)).hexdigest()

class MechanismRegistry:
    def __init__(self,recipient_keys=None,proofs=None):
        self.entries={};self.keys={} if recipient_keys is None else dict(recipient_keys)
        built=p.manifest('Padded ML-KEM/AES field delivery','privacy',p._id('COVENANT-PRIVACY-MECHANISM-SEMANTICS-0.1',{'suite':'EXISTING_PADDED_ML_KEM_AES_GCM','scope':'EXACT_PLAN_STEP_ORDERED_LAYER_FIELDS'}),IMPLEMENTATION,
            {op:{'mode':'LOCAL','description':description} for op,description in [('seal','Protect selected fields for exact recipient descriptors.'),('open','Open selected fields using owner-held recipient custody.')]},
            assurances={'encryption':'EXISTING_ML_KEM_768_AES_GCM_PADDED','recipient_descriptor_key':'ML-KEM-768'},assumptions=['Trusted local host; optional pqcrypto runtime; recipients may retain plaintext.'])
        self.default_privacy=self.register(built['manifest'],{'seal':self._seal,'open':self._open})
        self.proof_mechanisms={}
        if proofs is not None:self.adopt_proofs(proofs)
    def register(self,manifest,handlers):
        p.validate_manifest(manifest);ref=p.mechanism_id(manifest);need(ref not in self.entries,'MECHANISM_ALREADY_INSTALLED');need(type(handlers) is dict and set(handlers)==set(manifest['operations']),'MECHANISM_HANDLERS')
        copied={}
        for name,op in manifest['operations'].items():
            handler=handlers[name]
            if op['mode']=='LOCAL':need(callable(handler),'MECHANISM_LOCAL_HANDLER');copied[name]=(handler,None)
            else:
                need(hasattr(handler,'manifest') and callable(handler.execute) and callable(handler.observe),'MECHANISM_EFFECT_ADAPTER');copied[name]=(handler,manifest_id(handler.manifest))
        self.entries[ref]=(deepcopy(manifest),copied);return ref
    def describe(self):
        return {ref:{'manifest':deepcopy(m),'operations':{name:{'mode':m['operations'][name]['mode'],'adapter':pin} for name,(_,pin) in handlers.items()}} for ref,(m,handlers) in self.entries.items()}
    def get(self,ref,operation,mode=None):
        need(ref in self.entries,'MECHANISM_NOT_INSTALLED');m,handlers=self.entries[ref]
        need(p.mechanism_id(m)==ref,'MECHANISM_MANIFEST_CHANGED');need(operation in handlers,'MECHANISM_OPERATION_NOT_INSTALLED')
        actual=m['operations'][operation]['mode'];need(mode is None or mode==actual,'MECHANISM_OPERATION_MODE')
        handler,pin=handlers[operation]
        if pin is not None:need(manifest_id(handler.manifest)==pin,'MECHANISM_EFFECT_ADAPTER_CHANGED')
        return m,handler,pin
    def local(self,ref,operation,context,payload):
        _,handler,_=self.get(ref,operation,'LOCAL')
        try:result=handler(deepcopy(context),deepcopy(payload));wire(result)
        except Exception as error:
            code='MECHANISM_PROTECTION_CAPACITY_EXCEEDED' if str(error) in ('PRIVATE_CONTENT_LIMIT','MECHANISM_PROTECTION_CAPACITY_EXCEEDED') else 'MECHANISM_LOCAL_CALL_FAILED'
            raise ValueError(code) from None
        return deepcopy(result)
    def _recipient_public(self,context):
        result=[]
        for name,descriptor in context['recipients'].items():
            raw=descriptor.get('ML-KEM-768');need(type(raw) is str,'MECHANISM_ML_KEM_DESCRIPTOR')
            try:public=bytes.fromhex(raw)
            except ValueError:raise ValueError('MECHANISM_ML_KEM_DESCRIPTOR') from None
            need(len(public)==1184 and public.hex()==raw,'MECHANISM_ML_KEM_DESCRIPTOR');result.append(public)
        return result
    def _seal(self,context,payload):
        parameters=context['parameters'];need(set(parameters)<={'padding'},'MECHANISM_PRIVACY_PARAMETERS')
        encoded=wire(payload).decode('ascii');padding=parameters.get('padding',LARGE_CONTENT_BYTES)
        need(type(padding) is int and padding in (16384,65536),'MECHANISM_PRIVACY_PARAMETERS');need(len(encoded)<=padding-4,'MECHANISM_PROTECTION_CAPACITY_EXCEEDED')
        return _seal_payload({'body_json':encoded},DELIVERY,recipient_public_keys=self._recipient_public(context),context={'chain':context['context'],'scope':'mechanism/'+call_context(context)},padding=parameters.get('padding',LARGE_CONTENT_BYTES))
    def _open(self,context,payload):
        exact(payload,'packet recipient');name=payload['recipient'];need(name in context['recipients'] and name in self.keys,'MECHANISM_RECIPIENT_NOT_CONFIGURED')
        record=self.keys[name];need(record['public'].hex()==context['recipients'][name].get('ML-KEM-768'),'MECHANISM_RECIPIENT_KEY')
        opened=_open_payload(payload['packet'],DELIVERY,recipient_secret_key=record['secret'],expected_context={'chain':context['context'],'scope':'mechanism/'+call_context(context)},expected_padding=context['parameters'].get('padding',LARGE_CONTENT_BYTES));exact(opened,'body_json')
        raw=opened['body_json'].encode('ascii');result=json.loads(raw);need(wire(result)==raw,'MECHANISM_DELIVERY_ENCODING');return result
    def adopt_proofs(self,proofs):
        for verifier,m in proofs.describe().items():
            record=p.manifest('Proof: '+m['system'],'proof',m['semantics'],m['implementation'],{'verify':{'mode':'LOCAL','description':'Verify the exact statement/context through the installed verifier.'}},assurances={'verifier':verifier,'scope':m['scope']},assumptions=[m['trust'],'Verification does not establish world truth or authority.'])
            def check(context,envelope,verifier=verifier):
                exact(context['parameters'],'statement');return proofs.verify(envelope,verifier,call_context(context),context['parameters']['statement'])['verified']
            self.proof_mechanisms[verifier]=self.register(record['manifest'],{'verify':check})
    def objects(self):
        return [{'target':{'kind':'mechanism','id':ref},'title':m['manifest']['name'],'description':m['manifest']['family']+' '+str(m['manifest']['assurances']),'attributes':{'family':m['manifest']['family'],'installed':True,'operations':sorted(m['operations']),'assurances':deepcopy(m['manifest']['assurances'])},'links':[{'kind':'connector','id':op['adapter']} for op in m['operations'].values() if op['adapter'] is not None]} for ref,m in self.describe().items()]

def _step(plan,name):
    p.validate(plan);found=[s for s in plan['steps'] if s['id']==name];need(len(found)==1,'MECHANISM_STEP_MISSING');return found[0]
def readiness(registry,plan):
    p.validate(plan);checks=[]
    for s in plan['steps']:
        for index,b in enumerate(s['mechanisms']):
            try:
                m,_,pin=registry.get(b['mechanism'],b['operation']);status='INSTALLED';mode=m['operations'][b['operation']]['mode']
                if any(g['binding']==index for g in s['gates']):need(mode=='LOCAL','MECHANISM_GATE_NEEDS_LOCAL_VERIFIER')
                if mode=='EFFECT':need(type(b['parameters'].get('request_commitment')) is str,'MECHANISM_EFFECT_REQUEST_COMMITMENT_REQUIRED');p.ref(b['parameters']['request_commitment'])
            except ValueError as e:status=str(e);mode=None;pin=None
            checks.append({'step':s['id'],'binding':index,'mechanism':b['mechanism'],'operation':b['operation'],'status':status,'mode':mode,'adapter':pin,'next':'EXACT_PLAN_ASSENT_THEN_EXPLICIT_CALL' if status=='INSTALLED' else 'OWNER_INSTALLS_EXACT_MANIFEST_IMPLEMENTATION'})
        for index,layer in enumerate(s['protection']):
            for op in ('seal','open'):
                try:registry.get(layer['mechanism'],layer[op],'LOCAL');status='INSTALLED'
                except ValueError as e:status=str(e)
                checks.append({'step':s['id'],'layer':index,'mechanism':layer['mechanism'],'operation':layer[op],'status':status,'next':'EXPLICIT_SCOPED_DELIVERY' if status=='INSTALLED' else 'OWNER_INSTALLS_EXACT_PRIVACY_IMPLEMENTATION'})
    return {'plan':p.identifier(plan),'checks':checks,'all_referenced_operations_installed':all(c['status']=='INSTALLED' for c in checks),'assent':'NOT_ESTABLISHED_BY_READINESS','authority':'SEPARATE_WORKFLOW_APPROVALS_FOR_EFFECTS','execution_authorized':False}

def _assent(plan,approvals,expected_id,expected_controllers,previous=None,expected_previous=None):
    result=p.verify_assents(plan,approvals,expected_id,expected_controllers)
    if plan['supersedes'] is not None:
        need(previous is not None and expected_previous is not None,'MECHANISM_TRANSITION_REQUIRED');p.verify_transition(previous,plan,approvals,expected_previous,expected_id)
    else:need(previous is None and expected_previous is None,'MECHANISM_UNEXPECTED_PREVIOUS')
    return result

def _gates(registry,plan,step,evidence):
    need(type(evidence) is dict,'MECHANISM_GATE_EVIDENCE');by_id={s['id']:s for s in plan['steps']};visited=set();used={};reports=[]
    def visit(s,dependency=False):
        if s['id'] in visited:return
        visited.add(s['id'])
        for name in s['depends_on']:visit(by_id[name],True)
        if dependency:need(bool(s['gates']),'MECHANISM_DEPENDENCY_EVIDENCE_REQUIRED')
        for gate in s['gates']:
            index=gate['binding'];key=str(index);provided=evidence.get(s['id'],{});need(type(provided) is dict and key in provided,'MECHANISM_GATE_EVIDENCE_REQUIRED')
            used.setdefault(s['id'],set()).add(key);b=s['mechanisms'][index];ctx=_context(plan,s,'mechanism/'+key,b['parameters']);result=registry.local(b['mechanism'],b['operation'],ctx,provided[key]);need(p.canonical(result)==p.canonical(gate['expected']),'MECHANISM_GATE_UNSATISFIED')
            reports.append({'step':s['id'],'binding':index,'verified_expected_result':True,'result_hash':hashlib.sha256(p.canonical(result)).hexdigest()})
    visit(step)
    need(set(evidence)==set(used) and all(type(evidence[k]) is dict and set(evidence[k])==v for k,v in used.items()),'MECHANISM_UNUSED_EVIDENCE')
    return reports

def invoke_local(registry,plan,step,binding,payload,approvals,expected_id,expected_controllers,evidence=None,previous=None,expected_previous=None):
    _assent(plan,approvals,expected_id,expected_controllers,previous,expected_previous);s=_step(plan,step);_gates(registry,plan,s,{} if evidence is None else evidence);need(type(binding) is int and 0<=binding<len(s['mechanisms']),'MECHANISM_BINDING_INDEX');b=s['mechanisms'][binding];ctx=_context(plan,s,'mechanism/'+str(binding),b['parameters']);result=registry.local(b['mechanism'],b['operation'],ctx,payload)
    return {'plan':expected_id,'step':step,'binding':binding,'call_context':call_context(ctx),'result':result,'interpretation':'OWNER_INSTALLED_EXACT_MECHANISM','world_truth':'NOT_ESTABLISHED','execution_authorized':False}

def protect(registry,plan,step,approvals,expected_id,expected_controllers,value=None,salts=None,evidence=None,previous=None,expected_previous=None):
    _assent(plan,approvals,expected_id,expected_controllers,previous,expected_previous);s=_step(plan,step);reports=_gates(registry,plan,s,{} if evidence is None else evidence)
    if s['visibility']=='WITHHELD':packet=None
    else:
        selected=p.select(value,s['fields']);need(p.commit_fields(value,s['fields'],salts,plan['context'],step)['commitments']==s['commitments'],'MECHANISM_FIELD_OPENING')
        packet={'plan':expected_id,'step':step,'selected':selected,'openings':deepcopy(salts)}
        for index,layer in enumerate(s['protection']):
            ctx=_context(plan,s,'protection/'+str(index),layer['parameters']);packet={'mechanism':layer['mechanism'],'packet':registry.local(layer['mechanism'],layer['seal'],ctx,packet)}
    delivery={'version':DELIVERY,'plan':expected_id,'step':step,'visibility':s['visibility'],'packet':packet}
    return {'delivery_id':delivery_id(delivery),'delivery':delivery,'controller_assent_verified':True,'gates':reports,'prior_plaintext_recall':False,'host_and_public_metadata':'NOT_HIDDEN_BY_DISPATCH','execution_authorized':False}

def open_delivery(registry,delivery,plan,step,approvals,expected_id,expected_controllers,expected_delivery,recipient=None):
    p.verify_assents(plan,approvals,expected_id,expected_controllers);s=_step(plan,step);exact(delivery,'version plan step visibility packet');need(delivery['version']==DELIVERY and delivery['plan']==expected_id and delivery['step']==step and delivery['visibility']==s['visibility'] and delivery_id(delivery)==expected_delivery,'MECHANISM_EXPECTED_DELIVERY')
    if s['visibility']=='WITHHELD':need(delivery['packet'] is None,'MECHANISM_WITHHELD_PACKET');return {'status':'WITHHELD','selected':{},'execution_authorized':False}
    packet=deepcopy(delivery['packet'])
    for index in reversed(range(len(s['protection']))):
        layer=s['protection'][index];exact(packet,'mechanism packet');need(packet['mechanism']==layer['mechanism'],'MECHANISM_LAYER_ORDER');ctx=_context(plan,s,'protection/'+str(index),layer['parameters']);packet=registry.local(layer['mechanism'],layer['open'],ctx,{'packet':packet['packet'],'recipient':recipient})
    exact(packet,'plan step selected openings');need(packet['plan']==expected_id and packet['step']==step and type(packet['selected']) is dict and set(packet['selected'])==set(s['fields']) and type(packet['openings']) is dict and set(packet['openings'])==set(s['fields']),'MECHANISM_DELIVERY_FIELDS')
    for path,value in packet['selected'].items():need(p.field_commitment(value,packet['openings'][path],plan['context'],step,path)==s['commitments'][path],'MECHANISM_FIELD_OPENING')
    return {'status':'OPENED','plan':expected_id,'step':step,'selected':packet['selected'],'field_openings_verified':True,'content_scope':'CONTROLLERS_ASSENTED_TO_EXACT_FIELD_COMMITMENTS_NOT_WORLD_TRUTH','release_conditions':'NOT_REESTABLISHED_BY_OPEN','recipient_may_retain_or_redisclose':True,'execution_authorized':False}

def prepare_effect(registry,adapter,plan,step,binding,payload,request_salt,approvals,expected_id,expected_controllers,evidence=None,previous=None,expected_previous=None):
    request=dict(plan=deepcopy(plan),step=step,binding=binding,payload=deepcopy(payload),request_salt=request_salt,approvals=deepcopy(approvals),expected_id=expected_id,expected_controllers=deepcopy(expected_controllers),evidence={} if evidence is None else deepcopy(evidence),previous=deepcopy(previous),expected_previous=expected_previous)
    _effect_route(registry,request)
    return {'adapter':adapter,'request':request,'request_binding':{'kind':'FIXED','hash':hashlib.sha256(wire(request)).hexdigest()},'next':'ADOPT_EXACT_WORKFLOW_BOOKING_AND_PROVIDER_OUTPUT_APPROVALS','execution_authorized':False}

def _effect_route(registry,request):
    exact(request,'plan step binding payload request_salt approvals expected_id expected_controllers evidence previous expected_previous');_assent(request['plan'],request['approvals'],request['expected_id'],request['expected_controllers'],request['previous'],request['expected_previous']);s=_step(request['plan'],request['step']);index=request['binding'];need(type(index) is int and 0<=index<len(s['mechanisms']),'MECHANISM_BINDING_INDEX');b=s['mechanisms'][index]
    _gates(registry,request['plan'],s,request['evidence']);_,adapter,pin=registry.get(b['mechanism'],b['operation'],'EFFECT')
    expected=b['parameters'].get('request_commitment');need(expected is not None,'MECHANISM_EFFECT_REQUEST_COMMITMENT_REQUIRED');p.ref(expected);actual=p.field_commitment(request['payload'],request['request_salt'],request['plan']['context'],s['id'],'/mechanisms/'+str(index)+'/request');need(expected==actual,'MECHANISM_EFFECT_REQUEST_COMMITMENT')
    return adapter,pin

class PlanEffectAdapter:
    """Owner-installed workflow bridge; no key/endpoint supplied by an agent.

    Backends retain their own identity, authority, budgets and recovery duties.
    No cross-system atomicity or irreversible-effect compensation is inferred.
    """
    def __init__(self,directory,registry):
        self.registry=registry;self.snapshot=registry.describe();self.manifest=manifest('adopted-mechanism-plan-0.1','mechanism.invoke',effect='EXPLICIT_OWNER_INSTALLED_BACKEND',instance=_instance(directory),max_bytes=1000000)
        self.manifest['requirements']['mechanisms']=sorted(self.snapshot);self.manifest['requirements']['authority']='NATIVE_WORKFLOW_PLUS_EXACT_PLAN_ASSENTS_AND_SALTED_REQUEST_PIN';self.manifest['recovery']='OBSERVE_ONLY' if any(registry.get(ref,op)[1].manifest.get('recovery')!='IDEMPOTENT_KEY' for ref,entry in self.snapshot.items() for op,definition in entry['operations'].items() if definition['mode']=='EFFECT') else 'IDEMPOTENT_KEY'
        self.ref=manifest_id(self.manifest);self.store=WorkflowStore(directory,{'adapter':self.ref,'mechanisms':self.snapshot})
        for action in ('UPDATE','DELETE'):self.store.db.execute(f"CREATE TRIGGER IF NOT EXISTS mechanism_no_{action.lower()} BEFORE {action} ON events BEGIN SELECT RAISE(ABORT,'MECHANISM_APPEND_ONLY'); END")
        self.store.db.execute("CREATE TRIGGER IF NOT EXISTS mechanism_no_replace BEFORE INSERT ON events WHEN EXISTS(SELECT 1 FROM events WHERE sequence=NEW.sequence OR id=NEW.id) BEGIN SELECT RAISE(ABORT,'MECHANISM_APPEND_ONLY'); END")
    def _history(self):
        need(self.registry.describe()==self.snapshot,'MECHANISM_REGISTRY_CHANGED');intents={};receipts={}
        for e in self.store.events():
            body=e['body'];kind=body['kind'];ref=body['task'];value=body['value']
            if kind=='MECHANISM_INTENT':need(ref not in intents,'MECHANISM_DUPLICATE_INTENT');intents[ref]=value
            elif kind=='MECHANISM_RECEIPT':need(ref in intents and ref not in receipts,'MECHANISM_RECEIPT_HISTORY');receipts[ref]=value
            else:raise ValueError('MECHANISM_HISTORY_KIND')
        return intents,receipts
    def _receipt(self,effect,request,result):
        need(type(result) is dict and result.get('status') in ('OBSERVED','NOT_OBSERVED'),'MECHANISM_BACKEND_OBSERVATION')
        if result['status']!='OBSERVED':return {'status':'NOT_OBSERVED','output_hash':None,'assurance':'BACKEND_NOT_OBSERVED_NOT_PROOF_OF_FAILURE'}
        p.ref(result.get('output_hash'));value={'effect':effect,'plan':request['expected_id'],'step':request['step'],'binding':request['binding'],'request_commitment':request['plan']['steps'][next(i for i,s in enumerate(request['plan']['steps']) if s['id']==request['step'])]['mechanisms'][request['binding']]['parameters']['request_commitment'],'backend':deepcopy(result)}
        return {'status':'OBSERVED','output_hash':hashlib.sha256(wire(value)).hexdigest(),'value':value,'assurance':'EXACT_ADOPTED_BACKEND_OBSERVATION_NOT_WORLD_TRUTH_OR_ATOMICITY'}
    def execute(self,effect_id,request,*,crash=None):
        p.ref(effect_id);need(len(wire(request))<=self.manifest['max_bytes'],'MECHANISM_REQUEST_SIZE');adapter,_=_effect_route(self.registry,request)
        with self.store.exclusive():
            intents,receipts=self._history()
            fresh=effect_id not in intents
            if not fresh:need(wire(intents[effect_id])==wire(request),'MECHANISM_RETRY_CHANGED')
            else:self.store.append('MECHANISM_INTENT',effect_id,request)
            if effect_id in receipts:return receipts[effect_id]
            observed=adapter.observe(effect_id)
            if observed.get('status')!='OBSERVED' and (fresh or adapter.manifest.get('recovery')=='IDEMPOTENT_KEY'):observed=adapter.execute(effect_id,deepcopy(request['payload']),crash=crash)
            receipt=self._receipt(effect_id,request,observed)
            if crash=='after_effect':
                from covenant_language.handoff import InjectedCrash
                raise InjectedCrash('after_effect')
            if receipt['status']=='OBSERVED':self.store.append('MECHANISM_RECEIPT',effect_id,receipt)
            return receipt
    def observe(self,effect_id):
        p.ref(effect_id)
        with self.store.exclusive():
            intents,receipts=self._history()
            if effect_id not in intents:return {'status':'NOT_OBSERVED','output_hash':None,'assurance':'NO_LOCAL_INTENT_NOT_PROOF_OF_EXTERNAL_FAILURE'}
            request=intents[effect_id];adapter,_=_effect_route(self.registry,request)
            return receipts[effect_id] if effect_id in receipts else self._receipt(effect_id,request,adapter.observe(effect_id))
    def close(self):self.store.close()

def templates(registry):
    return {'version':p.VERSION,'start':'prepare_step THEN plan THEN assent_payload; use readiness for missing adoption',
        'simple_public_example':{'tool':'covenant_mechanism','arguments':{'action':'prepare_step','parameters':{'id':'receipt','target':{'kind':'agreement','id':'REPLACE_WITH_EXACT_OR_SALTED_SUBJECT_ID'},'value':{'amount':10,'private_working_notes':'not selected'},'fields':['/amount'],'salts':{'/amount':'REPLACE_WITH_FRESH_RANDOM_BASE64_SALT'},'context':'REPLACE_WITH_FRESH_64_HEX_CONTEXT','visibility':'PUBLIC'}}},
        'salt_encoding':'FRESH_RANDOM_32_TO_64_BYTES_PER_FIELD_STANDARD_BASE64_KEEP_PRIVATE_UNTIL_SELECTED_DISCLOSURE',
        'root_selector':'Empty string selects the whole value; / selects an empty object key; numeric segments select array elements.',
        'private_example':{'visibility':'PRIVATE','recipients':{'Reader':{'ML-KEM-768':'REPLACE_WITH_RECIPIENT_PUBLIC_KEY_HEX'}},'protection':[p.protection(registry.default_privacy,parameters={'padding':16384}),p.protection(registry.default_privacy,parameters={'padding':65536})]},
        'protection_budgets':'Explicit padded layers support 16384 or 65536 bytes. Nesting increases size; capacity errors refuse without downgrading. Custom owner schemes may choose other encodings/budgets.',
        'withheld_example':{'fields':[],'commitments':{},'visibility':'WITHHELD','recipients':{},'protection':[]},
        'gates':'All current and transitive dependency gates need exact LOCAL-verifier results. Dependencies without verifier gates cannot authorize release. Evidence maps step IDs to binding-index strings and exact proof requests.',
        'effect_request_pin':'binding.parameters.request_commitment = field_commitment(payload, request_salt, context, step_id, /mechanisms/INDEX/request)',
        'scope_changes':'amend appends a successor; fresh all-controller assent and previous+expected_previous are required for delivery/calls.',
        'new_crypto_or_zk':'Name any manifest and carry any proof. Exact code, circuit/program, witness handling and verifier/prover must be installed and adopted; unknown systems never auto-verify.',
        'external_calls':'Owner registers EFFECT adapter then installs PlanEffectAdapter in the ordinary workflow. Read tools prepare exact requests; only separately approved native workflow executes.',
        'metadata':'Plans/descriptors may be kept private by protecting them as another step value. Tool calls and local custody still trust their host. No plan or delivery is automatically published.',
        'desire_discovery':'covenant_desire.search ranks mechanisms, connectors or any supplied typed objects against query/requirements/context and explicit seeds.',
        'prior_plaintext_recall':False,'automatic_assent':False,'execution_authorized':False}
