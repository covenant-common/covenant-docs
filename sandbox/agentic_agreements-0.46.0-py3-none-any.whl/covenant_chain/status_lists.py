"""Credential status lists in two published encodings, read under hard bounds.

One fact per issued credential (valid, revoked or suspended), carried two ways:

* IETF OAuth Token Status List, draft-ietf-oauth-status-list-21 (21 June 2026,
  submitted to the IESG). Section 4: ``{"bits": 1|2|4|8, "lst": ...}`` where
  ``lst`` is unpadded base64url of the byte array compressed with DEFLATE
  (RFC 1951) in the ZLIB format (RFC 1950). Section 4.1 packs index 0 into the
  least significant bits of byte 0. Section 7.1: 0x00 VALID, 0x01 INVALID,
  0x02 SUSPENDED, 0x03 and 0x0C-0x0F application specific. Section 5.1: the
  Status List Token is a JWT with ``typ`` ``statuslist+jwt`` carrying ``sub``,
  ``iat``, ``exp``, ``ttl`` and ``status_list``.
* W3C Bitstring Status List v1.0 (Recommendation, 15 May 2025). Section 2.2:
  ``encodedList`` is multibase base64url (prefix ``u``, no padding) of the
  GZIP-compressed bitstring; index 0 is the left-most bit. Sections 3.2 and
  6.1: at least 131,072 entries. The list travels in a
  ``BitstringStatusListCredential`` (W3C VC Data Model 2.0), secured here with
  ``eddsa-jcs-2022`` through ``interop_codec``.

These are standard encodings of the snapshots a ``covenant-agent-accreditation``
issuer already signs: the same issuer name, key version and sequence. An issuer
register signs one snapshot as both a 2-bit Token Status List and a pair of 1-bit
W3C lists (``revocation``, ``suspension``). Both carry the same
``covenant-agent-accreditation-status-list/0.1`` fields (sequence from 1, previous snapshot id, key
version, withdrawn key versions) and so share one format-neutral snapshot id.
A credential needs a list index to use them; the selective-disclosure form
(``accreditation_disclosure``) carries one. The original map snapshot of
``agent_accreditation`` remains the carrier for /0.1 credentials, which have none.

Decompression never trusts the input: one complete stream of the expected
format, no trailing bytes, a hard output cap. A zip bomb stops at the cap
(STATUS_LIST_TOO_LARGE). Nothing here fetches a list, trusts a key, reads a
clock or decides eligibility; ``credential_status`` judges a snapshot.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import re
import zlib

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .crypto import digest, integer, key, need, public_key, verification_key
from . import interop_codec as codec
from .hidden_credentials import _b64, _json, _jws, _unb64

SNAPSHOT_VERSION = 'covenant-agent-accreditation-status-list/0.1'
SNAPSHOT_LABEL = 'COVENANT-AGENT-ACCREDITATION-STATUS-LIST-0.1'
TOKEN_TYP = 'statuslist+jwt'
TOKEN_SOURCE = 'draft-ietf-oauth-status-list-21'
W3C_SOURCE = 'W3C Bitstring Status List v1.0 (Recommendation, 15 May 2025)'
VC_CONTEXT = 'https://www.w3.org/ns/credentials/v2'
W3C_TYPES = ['VerifiableCredential', 'BitstringStatusListCredential']
BITS = (1, 2, 4, 8)
VALID, INVALID, SUSPENDED = 0x00, 0x01, 0x02
NAMES = {VALID: 'VALID', INVALID: 'INVALID', SUSPENDED: 'SUSPENDED'}
PURPOSES = ('revocation', 'suspension')
W3C_PURPOSES = ('refresh', 'revocation', 'suspension', 'message')
AAP_BITS = 2
MIN_ENTRIES = 131072
MAX_ENTRIES = 1 << 22
MAX_LIST_BYTES = 1 << 20
MAX_COMPRESSED = 1 << 19
MAX_TOKEN = 720000
MAX_WITHDRAWN = 64
URI = re.compile(r'[a-z][a-z0-9+.-]{0,31}:[!-~]{1,2000}\Z')
LAST_SECOND = 253402300799
STAMP = re.compile(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})Z\Z')

# Every refusal: what happened, what to do, whether an unchanged retry can succeed.
ERRORS = {
    'STATUS_LIST_SHAPE': ('The status list object is not {"bits", "lst"} with an optional aggregation_uri.',
                          'Send the Status List exactly as section 4.2 of the Token Status List defines it.', False),
    'STATUS_LIST_BITS': ('bits is not 1, 2, 4 or 8.', 'Use one of the allowed widths; AAP snapshots use 2.', False),
    'STATUS_LIST_ENCODING': ('The list text is not canonical unpadded base64url (or multibase "u" for W3C).',
                             'Re-encode the compressed bytes without padding or extra characters.', False),
    'STATUS_LIST_COMPRESSION': ('The bytes are not one complete ZLIB (IETF) or GZIP (W3C) stream.',
                                'Compress the whole list once, in the format the specification names, with nothing after it.', False),
    'STATUS_LIST_TOO_LARGE': ('The list expands beyond the hard cap, or its compressed form is too large.',
                              'Split the issuer\'s credentials across several lists of at most 1 MiB uncompressed.', False),
    'STATUS_LIST_TOO_SMALL': ('A W3C list is shorter than 131,072 entries, the herd-privacy minimum.',
                              'Publish at least 16 KiB of bitstring, padding unused entries with zero.', False),
    'STATUS_LIST_SIZE': ('The entry count is not a positive multiple of 8 within the AAP maximum.',
                         'Choose a size that is a multiple of 8 between 131,072 and 4,194,304.', False),
    'STATUS_INDEX_RANGE': ('The credential\'s index lies outside this list.',
                           'The credential must be refused (section 8.3); obtain the list it actually names.', False),
    'STATUS_VALUE': ('A status value is outside what the list width can hold, or is not AAP\'s VALID/INVALID/SUSPENDED.',
                     'Use 0 (valid), 1 (revoked) or 2 (suspended).', False),
    'STATUS_TOKEN_FORMAT': ('The Status List Token is not a compact EdDSA JWS with typ statuslist+jwt.',
                            'Send the token exactly as the issuer signed it.', False),
    'STATUS_TOKEN_SIGNATURE': ('The snapshot signature does not verify under the pinned key for its key version.',
                               'Obtain the snapshot from the issuer again; do not edit it.', False),
    'STATUS_TOKEN_CLAIMS': ('The Status List Token claims are not exactly iss, sub, iat, exp, ttl, status_list and aap_snapshot.',
                            'Use a snapshot from an AAP issuer register; extra or missing claims are refused.', False),
    'STATUS_SNAPSHOT_FIELDS': ('The aap_snapshot object is malformed.',
                               'Snapshots carry profile, sequence, previous, key_version and withdrawn_key_versions.', False),
    'STATUS_SNAPSHOT_TIME': ('The snapshot times are not integers with iat before exp, or ttl is out of range.',
                             'Re-sign the snapshot with an issue time before its expiry and a ttl of at most its lifetime.', False),
    'STATUS_URI': ('A list identifier is not a bounded ASCII URI.', 'Use a URI such as urn:aap:status:<issuer-digest>:<list>.', False),
    'STATUS_ISSUER': ('The issuer name is not 1 to 160 printable ASCII characters, or contains ":" without being a URI.',
                      'Use the issuer name the relying party adopted in its accreditation policy.', False),
    'STATUS_CREDENTIAL_SHAPE': ('The BitstringStatusListCredential is not the W3C VC 2.0 shape AAP issues.',
                                'Send the credential exactly as the issuer signed it.', False),
    'STATUS_CREDENTIAL_PURPOSE': ('The W3C credential has another statusPurpose than the one requested.',
                                  'Pair the revocation and suspension credentials of one snapshot.', False),
    'STATUS_CREDENTIAL_PAIR': ('The revocation and suspension credentials do not describe one snapshot.',
                               'Supply both credentials from the same issuer, list and sequence.', False),
    'STATUS_CREDENTIAL_SIGNATURE': ('The W3C status credential proof does not verify under the pinned key.',
                                    'Obtain the credential from the issuer again; do not edit it.', False),
}


def explain(code):
    happened, fix, retry = ERRORS.get(code, ('Unrecognised refusal.', 'Read docs/AGENT_ACCREDITATION.html.', False))
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/AGENT_ACCREDITATION.html#' + code}


def remediation(code):
    return explain(code)['fix']


def stamp(seconds):
    """Integer seconds as an XML Schema dateTimeStamp in UTC (VC 2.0 section 4.9)."""
    need(type(seconds) is int and 0 <= seconds <= LAST_SECOND, 'STATUS_SNAPSHOT_TIME')
    return datetime.fromtimestamp(seconds, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def seconds(text, code='STATUS_SNAPSHOT_TIME'):
    found = STAMP.fullmatch(text) if type(text) is str else None
    need(found is not None, code)
    try:
        moment = datetime(*(int(part) for part in found.groups()), tzinfo=timezone.utc)
    except ValueError:
        raise ValueError(code) from None
    value = int(moment.timestamp())
    need(0 <= value <= LAST_SECOND and stamp(value) == text, code)
    return value


def uri(value, code='STATUS_URI'):
    need(type(value) is str and URI.fullmatch(value) is not None, code)
    return value


def _size(size):
    need(type(size) is int and MIN_ENTRIES <= size <= MAX_ENTRIES and size % 8 == 0, 'STATUS_LIST_SIZE')
    return size


def _bits(bits):
    need(type(bits) is int and bits in BITS, 'STATUS_LIST_BITS')
    return bits


def _inflate(raw, wbits, limit=MAX_LIST_BYTES):
    """One complete stream of the named format, expanding to at most ``limit`` bytes."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_COMPRESSED, 'STATUS_LIST_TOO_LARGE')
    stream = zlib.decompressobj(wbits)
    try:
        out = stream.decompress(raw, limit + 1)
    except zlib.error:
        raise ValueError('STATUS_LIST_COMPRESSION') from None
    need(len(out) <= limit and not stream.unconsumed_tail, 'STATUS_LIST_TOO_LARGE')
    need(stream.eof and not stream.unused_data, 'STATUS_LIST_COMPRESSION')
    return out


def _deflate(raw, wbits):
    stream = zlib.compressobj(9, zlib.DEFLATED, wbits, 9)
    return stream.compress(raw) + stream.flush()


def pack(statuses, size, bits):
    """Token Status List byte array: index 0 in the least significant bits of byte 0 (section 4.1)."""
    _bits(bits)
    need(type(size) is int and 0 < size <= MAX_ENTRIES and size * bits % 8 == 0, 'STATUS_LIST_SIZE')
    need(type(statuses) is dict and len(statuses) <= size, 'STATUS_VALUE')
    out = bytearray(size * bits // 8)
    per = 8 // bits
    for index, value in statuses.items():
        need(type(index) is int and 0 <= index < size, 'STATUS_INDEX_RANGE')
        need(type(value) is int and 0 <= value < 1 << bits, 'STATUS_VALUE')
        out[index // per] |= value << ((index % per) * bits)
    return bytes(out)


def token_list(statuses, size, bits=AAP_BITS):
    """The section 4.2 Status List object for ``statuses`` (index -> value; absent is VALID)."""
    return {'bits': bits, 'lst': _b64(_deflate(pack(statuses, size, bits), 15))}


class TokenList:
    """A decoded Token Status List. ``size`` is the number of entries the bytes hold."""

    def __init__(self, bits, raw):
        self.bits, self.raw = bits, raw
        self.size = len(raw) * 8 // bits

    def get(self, index):
        need(type(index) is int and 0 <= index < self.size, 'STATUS_INDEX_RANGE')
        per = 8 // self.bits
        return (self.raw[index // per] >> ((index % per) * self.bits)) & ((1 << self.bits) - 1)

    def digest(self):
        return hashlib.sha256(self.raw).hexdigest()


def read_token_list(value, limit=MAX_LIST_BYTES):
    """Decode section 4.2 under a hard output cap. ``aggregation_uri`` is kept inert, never followed."""
    need(type(value) is dict and {'bits', 'lst'} <= set(value) <= {'bits', 'lst', 'aggregation_uri'},
         'STATUS_LIST_SHAPE')
    bits = _bits(value['bits'])
    if 'aggregation_uri' in value:
        uri(value['aggregation_uri'], 'STATUS_LIST_SHAPE')
    text = value['lst']
    need(type(text) is str and 0 < len(text) <= MAX_COMPRESSED * 4 // 3 + 4, 'STATUS_LIST_TOO_LARGE')
    try:
        raw = _unb64(text, MAX_COMPRESSED * 4 // 3 + 4)
    except ValueError:
        raise ValueError('STATUS_LIST_ENCODING') from None
    out = _inflate(raw, 15, limit)
    need(len(out) > 0, 'STATUS_LIST_COMPRESSION')
    return TokenList(bits, out)


def bitstring(indexes, size):
    """W3C encodedList (statusSize 1): left-most bit is index 0, GZIP, multibase base64url."""
    _size(size)
    need(type(indexes) in (list, set, frozenset, tuple) and len(indexes) <= size, 'STATUS_VALUE')
    out = bytearray(size // 8)
    for index in indexes:
        need(type(index) is int and 0 <= index < size, 'STATUS_INDEX_RANGE')
        out[index // 8] |= 0x80 >> (index % 8)
    return 'u' + codec.b64url(_deflate(bytes(out), 31))


def read_bitstring(encoded, limit=MAX_LIST_BYTES):
    """Section 3.4 expansion under a hard cap; shorter than 16 KiB is refused (section 3.2)."""
    need(type(encoded) is str and 1 < len(encoded) <= MAX_COMPRESSED * 4 // 3 + 5, 'STATUS_LIST_TOO_LARGE')
    need(encoded[0] == 'u', 'STATUS_LIST_ENCODING')
    try:
        raw = codec.b64url_decode(encoded[1:], MAX_COMPRESSED)
    except ValueError:
        raise ValueError('STATUS_LIST_ENCODING') from None
    out = _inflate(raw, 31, limit)
    need(len(out) * 8 >= MIN_ENTRIES, 'STATUS_LIST_TOO_SMALL')
    return out


def bitstring_value(raw, index, status_size=1):
    """The ``status_size`` bits at ``index * status_size``, counted from the left-most bit (section 3.2)."""
    need(type(raw) is bytes and status_size in BITS, 'STATUS_LIST_BITS')
    need(type(index) is int and 0 <= index and (index + 1) * status_size <= len(raw) * 8, 'STATUS_INDEX_RANGE')
    position = index * status_size
    return (raw[position // 8] >> (8 - position % 8 - status_size)) & ((1 << status_size) - 1)


# Snapshots: one signed fact, two encodings, one id.
#
# Issuer names and key versions follow covenant-agent-accreditation/0.1: printable
# ASCII text the relying party pins in its adopted policy. A name containing ":"
# must be a URI, as the JWT "iss" claim requires (RFC 7519 section 2, StringOrURI).

def issuer_name(value, code='STATUS_ISSUER'):
    need(type(value) is str and 0 < len(value) <= 160 and all(32 <= ord(c) <= 126 for c in value)
         and (':' not in value or URI.fullmatch(value) is not None), code)
    return value


def key_version(value, code='STATUS_SNAPSHOT_FIELDS'):
    need(type(value) is str and 0 < len(value) <= 160 and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def issuer_url(issuer):
    """The URL a W3C credential needs for a plain-text issuer name (VC 2.0 section 4.7)."""
    return 'urn:aap:issuer:' + hashlib.sha256(issuer_name(issuer).encode('ascii')).hexdigest()


def _withdrawn(values):
    need(type(values) is list and len(values) <= MAX_WITHDRAWN and values == sorted(set(values)), 'STATUS_SNAPSHOT_FIELDS')
    for value in values:
        key_version(value)
    return values


def snapshot_fields(value):
    """Validate covenant-agent-accreditation-status-list/0.1: sequence from 1, the previous snapshot id, key version, withdrawals."""
    need(type(value) is dict and set(value) == {'profile', 'sequence', 'previous', 'key_version',
                                                'withdrawn_key_versions'}, 'STATUS_SNAPSHOT_FIELDS')
    need(value['profile'] == SNAPSHOT_VERSION, 'STATUS_SNAPSHOT_FIELDS')
    need(type(value['sequence']) is int and 1 <= value['sequence'] <= 2**53 - 1, 'STATUS_SNAPSHOT_FIELDS')
    need((value['sequence'] == 1) == (value['previous'] is None), 'STATUS_SNAPSHOT_FIELDS')
    if value['previous'] is not None:
        need(type(value['previous']) is str, 'STATUS_SNAPSHOT_FIELDS')
        key(value['previous'])
    key_version(value['key_version'])
    _withdrawn(value['withdrawn_key_versions'])
    need(value['key_version'] not in value['withdrawn_key_versions'], 'STATUS_SNAPSHOT_FIELDS')
    return value


def _times(issued_at, expires, ttl):
    need(all(type(value) is int for value in (issued_at, expires, ttl)) and 0 <= issued_at < expires <= LAST_SECOND
         and 0 < ttl <= expires - issued_at, 'STATUS_SNAPSHOT_TIME')


def _aap_statuses(statuses):
    """AAP snapshots carry only VALID, INVALID (revoked) and SUSPENDED; 0x03 is never written."""
    need(type(statuses) is dict and all(value in NAMES for value in statuses.values()), 'STATUS_VALUE')
    return statuses


def snapshot_id(issuer, list_uri, fields, issued_at, expires, statuses_digest):
    """Format-neutral id: the Token Status List and the W3C pair of one snapshot share it."""
    return digest(SNAPSHOT_LABEL, {'issuer': issuer, 'list': list_uri, 'snapshot': fields, 'issued_at': issued_at,
                                   'expires': expires, 'statuses': statuses_digest})


def fields(sequence, previous, key_version_text, withdrawn=()):
    return snapshot_fields({'profile': SNAPSHOT_VERSION, 'sequence': sequence, 'previous': previous,
                            'key_version': key_version_text, 'withdrawn_key_versions': sorted(withdrawn)})


def status_token(private_key, *, issuer, list_uri, statuses, size, issued_at, expires, ttl, sequence, previous,
                 key_version, withdrawn=()):
    """Explicit issuer action: a section 5.1 Status List Token (2 bits per entry) with AAP snapshot fields."""
    need(isinstance(private_key, Ed25519PrivateKey), 'STATUS_TOKEN_SIGNATURE')
    issuer_name(issuer); uri(list_uri); _size(size); _times(issued_at, expires, ttl)
    _aap_statuses(statuses)
    snapshot = fields(sequence, previous, key_version, list(withdrawn))
    payload = {'iss': issuer, 'sub': list_uri, 'iat': issued_at, 'exp': expires, 'ttl': ttl,
               'status_list': token_list(statuses, size, AAP_BITS), 'aap_snapshot': snapshot}
    return _jws(private_key, {'alg': 'EdDSA', 'typ': TOKEN_TYP}, payload)


def peek_token(token):
    """Unverified issuer, list and key version, only to choose the pinned key. Never a result."""
    need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.isascii() and token.count('.') == 2,
         'STATUS_TOKEN_FORMAT')
    try:
        payload = _json(_unb64(token.split('.')[1], MAX_TOKEN))
    except ValueError:
        raise ValueError('STATUS_TOKEN_FORMAT') from None
    need(type(payload) is dict and type(payload.get('aap_snapshot')) is dict, 'STATUS_TOKEN_FORMAT')
    version = payload['aap_snapshot'].get('key_version')
    need(type(payload.get('iss')) is str and type(payload.get('sub')) is str and type(version) is str,
         'STATUS_TOKEN_FORMAT')
    return {'issuer': payload['iss'], 'list': payload['sub'], 'key_version': version}


def open_status_token(token, public_hex):
    """Verify the signature, typ and exact claims; decode the list. Freshness is the caller's judgment."""
    verification_key(public_hex)
    need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.isascii() and token.count('.') == 2,
         'STATUS_TOKEN_FORMAT')
    head, body, signature = token.split('.')
    try:
        header = _json(_unb64(head, 512))
        raw = _unb64(signature, 128)
    except ValueError:
        raise ValueError('STATUS_TOKEN_FORMAT') from None
    need(header == {'alg': 'EdDSA', 'typ': TOKEN_TYP} and len(raw) == 64, 'STATUS_TOKEN_FORMAT')
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex)).verify(raw, (head + '.' + body).encode('ascii'))
    except InvalidSignature:
        raise ValueError('STATUS_TOKEN_SIGNATURE') from None
    try:
        payload = _json(_unb64(body, MAX_TOKEN))
    except ValueError:
        raise ValueError('STATUS_TOKEN_FORMAT') from None
    need(type(payload) is dict and set(payload) == {'iss', 'sub', 'iat', 'exp', 'ttl', 'status_list', 'aap_snapshot'},
         'STATUS_TOKEN_CLAIMS')
    issuer_name(payload['iss']); uri(payload['sub'])
    _times(payload['iat'], payload['exp'], payload['ttl'])
    snapshot = snapshot_fields(payload['aap_snapshot'])
    listed = read_token_list(payload['status_list'])
    need(listed.bits == AAP_BITS, 'STATUS_LIST_BITS')
    _size(listed.size)
    return {'format': 'IETF_TOKEN_STATUS_LIST', 'issuer': payload['iss'], 'list': payload['sub'],
            'issued_at': payload['iat'], 'expires': payload['exp'], 'ttl': payload['ttl'], 'snapshot': deepcopy(snapshot),
            'statuses': listed, 'id': snapshot_id(payload['iss'], payload['sub'], snapshot, payload['iat'],
                                                  payload['exp'], listed.digest())}


def _w3c_body(issuer, list_uri, purpose, encoded, issued_at, expires, ttl, snapshot):
    return {'@context': [VC_CONTEXT], 'id': list_uri + ':' + purpose, 'type': list(W3C_TYPES),
            'issuer': {'id': issuer_url(issuer), 'name': issuer},
            'validFrom': stamp(issued_at), 'validUntil': stamp(expires),
            'credentialSubject': {'id': list_uri + ':' + purpose + '#list', 'type': 'BitstringStatusList',
                                  'statusPurpose': purpose, 'encodedList': encoded, 'ttl': ttl * 1000},
            'aapSnapshot': {'profile': snapshot['profile'], 'sequence': snapshot['sequence'],
                            'previous': snapshot['previous'], 'keyVersion': snapshot['key_version'],
                            'withdrawnKeyVersions': list(snapshot['withdrawn_key_versions'])}}


def status_credentials(private_key, *, issuer, list_uri, statuses, size, issued_at, expires, ttl, sequence, previous,
                       key_version, withdrawn=()):
    """Explicit issuer action: the W3C pair (revocation, suspension) of one snapshot, eddsa-jcs-2022 secured."""
    need(isinstance(private_key, Ed25519PrivateKey), 'STATUS_CREDENTIAL_SIGNATURE')
    issuer_name(issuer); uri(list_uri); _size(size); _times(issued_at, expires, ttl)
    pack(_aap_statuses(statuses), size, AAP_BITS)
    snapshot = fields(sequence, previous, key_version, list(withdrawn))
    method = codec.did_key(public_key(private_key))
    out = {}
    for purpose, value in (('revocation', INVALID), ('suspension', SUSPENDED)):
        indexes = [index for index, status in statuses.items() if status == value]
        unsecured = _w3c_body(issuer, list_uri, purpose, bitstring(indexes, size), issued_at, expires, ttl, snapshot)
        out[purpose] = codec.di_sign(unsecured, codec.di_options(unsecured, method, created=stamp(issued_at)),
                                     private_key)
    return out


def peek_credential(document):
    """Unverified issuer, list and key version of a W3C status credential, only to choose the pinned key."""
    need(type(document) is dict and type(document.get('aapSnapshot')) is dict and type(document.get('id')) is str
         and type(document.get('issuer')) is dict, 'STATUS_CREDENTIAL_SHAPE')
    version = document['aapSnapshot'].get('keyVersion')
    need(type(document['issuer'].get('name')) is str and type(version) is str, 'STATUS_CREDENTIAL_SHAPE')
    base, _, purpose = document['id'].rpartition(':')
    need(purpose in PURPOSES and bool(base), 'STATUS_CREDENTIAL_SHAPE')
    return {'issuer': document['issuer']['name'], 'list': base, 'key_version': version, 'purpose': purpose}


def _open_w3c(document, public_hex, purpose):
    need(type(document) is dict and set(document) == {'@context', 'id', 'type', 'issuer', 'validFrom', 'validUntil',
                                                      'credentialSubject', 'aapSnapshot', 'proof'},
         'STATUS_CREDENTIAL_SHAPE')
    need(document['@context'] == [VC_CONTEXT] and document['type'] == W3C_TYPES, 'STATUS_CREDENTIAL_SHAPE')
    try:
        checked = codec.di_verify(document, public_hex)
    except ValueError:
        raise ValueError('STATUS_CREDENTIAL_SIGNATURE') from None
    need(checked['proof_purpose'] == 'assertionMethod' and checked['verification_method'] == codec.did_key(public_hex),
         'STATUS_CREDENTIAL_SIGNATURE')
    named = document['issuer']
    need(type(named) is dict and set(named) == {'id', 'name'}, 'STATUS_CREDENTIAL_SHAPE')
    issuer = issuer_name(named['name'])
    need(named['id'] == issuer_url(issuer), 'STATUS_CREDENTIAL_SHAPE')
    ident = uri(document['id'])
    need(ident.endswith(':' + purpose), 'STATUS_CREDENTIAL_PURPOSE')
    list_uri = uri(ident[:-len(purpose) - 1])
    subject = document['credentialSubject']
    need(type(subject) is dict and set(subject) == {'id', 'type', 'statusPurpose', 'encodedList', 'ttl'}
         and subject['id'] == ident + '#list' and subject['type'] == 'BitstringStatusList', 'STATUS_CREDENTIAL_SHAPE')
    need(subject['statusPurpose'] == purpose, 'STATUS_CREDENTIAL_PURPOSE')
    need(type(subject['ttl']) is int and subject['ttl'] % 1000 == 0, 'STATUS_SNAPSHOT_TIME')
    issued_at = seconds(document['validFrom']); expires = seconds(document['validUntil'])
    _times(issued_at, expires, subject['ttl'] // 1000)
    extra = document['aapSnapshot']
    need(type(extra) is dict and set(extra) == {'profile', 'sequence', 'previous', 'keyVersion', 'withdrawnKeyVersions'},
         'STATUS_SNAPSHOT_FIELDS')
    snapshot = snapshot_fields({'profile': extra['profile'], 'sequence': extra['sequence'], 'previous': extra['previous'],
                                'key_version': extra['keyVersion'], 'withdrawn_key_versions': extra['withdrawnKeyVersions']})
    raw = read_bitstring(subject['encodedList'])
    _size(len(raw) * 8)
    return {'issuer': issuer, 'list': list_uri, 'issued_at': issued_at, 'expires': expires,
            'ttl': subject['ttl'] // 1000, 'snapshot': snapshot, 'raw': raw}


def open_status_credentials(revocation, suspension, public_hex):
    """Verify a W3C pair and rebuild the 2-bit list, so its id equals the Token Status List snapshot's."""
    verification_key(public_hex)
    left, right = _open_w3c(revocation, public_hex, 'revocation'), _open_w3c(suspension, public_hex, 'suspension')
    need(all(left[name] == right[name] for name in ('issuer', 'list', 'issued_at', 'expires', 'ttl', 'snapshot'))
         and len(left['raw']) == len(right['raw']), 'STATUS_CREDENTIAL_PAIR')
    size = len(left['raw']) * 8
    statuses = {}
    for raw, value in ((right['raw'], SUSPENDED), (left['raw'], INVALID)):
        # Revocation is applied last: a revoked entry stays revoked whatever the suspension list says.
        for position, byte in enumerate(raw):
            if byte:
                for bit in range(8):
                    if byte & (0x80 >> bit):
                        statuses[position * 8 + bit] = value
    listed = TokenList(AAP_BITS, pack(statuses, size, AAP_BITS))
    return {'format': 'W3C_BITSTRING_STATUS_LIST', 'issuer': left['issuer'], 'list': left['list'],
            'issued_at': left['issued_at'], 'expires': left['expires'], 'ttl': left['ttl'],
            'snapshot': deepcopy(left['snapshot']), 'statuses': listed,
            'id': snapshot_id(left['issuer'], left['list'], left['snapshot'], left['issued_at'], left['expires'],
                              listed.digest())}


def indexes(listed, value):
    """Every index holding ``value`` in a decoded 2-bit list, without expanding the whole list."""
    need(isinstance(listed, TokenList) and listed.bits == AAP_BITS and value in NAMES, 'STATUS_VALUE')
    out = []
    for position, byte in enumerate(listed.raw):
        if byte:
            for slot in range(4):
                if (byte >> (slot * 2)) & 3 == value:
                    out.append(position * 4 + slot)
    return out


def describe():
    return {'profile': SNAPSHOT_VERSION, 'encodings': {
                'ietf': {'source': TOKEN_SOURCE, 'typ': TOKEN_TYP, 'bits': AAP_BITS, 'compression': 'ZLIB (RFC 1950) DEFLATE',
                         'bit_order': 'INDEX_0_IN_LEAST_SIGNIFICANT_BITS_OF_BYTE_0',
                         'values': {'0': 'VALID', '1': 'INVALID (revoked)', '2': 'SUSPENDED'}},
                'w3c': {'source': W3C_SOURCE, 'purposes': list(PURPOSES), 'compression': 'GZIP (RFC 1952)',
                        'encoding': 'multibase base64url, prefix u, no padding', 'bit_order': 'INDEX_0_IS_LEFT_MOST_BIT',
                        'securing': 'eddsa-jcs-2022 (W3C VC-DI-EdDSA 1.0 section 3.3)'}},
            'limits': {'minimum_entries': MIN_ENTRIES, 'maximum_entries': MAX_ENTRIES,
                       'maximum_uncompressed_bytes': MAX_LIST_BYTES, 'maximum_compressed_bytes': MAX_COMPRESSED,
                       'maximum_token_characters': MAX_TOKEN},
            'decompression': 'ONE_COMPLETE_STREAM_NO_TRAILING_BYTES_HARD_OUTPUT_CAP',
            'index_allocation': 'ISSUERS_ALLOCATE_RANDOMLY (W3C section 2.1, Token Status List section 12.5.1)',
            'issuer_names': 'covenant-agent-accreditation/0.1 issuer and key-version text; W3C issuer is {id: urn:aap:issuer:<sha256>, name}',
            'fetching': False, 'clock': None, 'execution_authorized': False}
