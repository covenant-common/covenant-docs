"""Actual local exact computation and append-only result publication."""
from copy import deepcopy
import hashlib
from covenant_language.capsules import compute,capsule_id,canonical
from .adapters import RecordAdapter,manifest
from .crypto import exact,need


class ExpressionRecordAdapter:
    def __init__(self,directory,max_bytes=65536):
        self.records=RecordAdapter(directory,namespace='exact-expression-0.1',max_bytes=max_bytes)
        self.manifest=manifest('exact-expression-0.1','compute.exact',effect='LOCAL_EXACT_EXPRESSION_RECORD',
                               instance=self.records.manifest['instance'],max_bytes=max_bytes)
    def execute(self,effect_id,request,*,crash=None):
        exact(request,'capsule bindings')
        need(len(canonical(request))<=self.manifest['max_bytes'],'ADAPTER_INPUT_SIZE')
        result=compute(request['capsule'],request['bindings'])
        record={'capsule':capsule_id(request['capsule']),
                'bindings_hash':hashlib.sha256(canonical(request['bindings'])).hexdigest(),'result':result}
        self.records.execute(effect_id,record,crash=crash)
        return self.observe(effect_id)
    def observe(self,effect_id):
        result=deepcopy(self.records.observe(effect_id));result['assurance']='LOCAL_EXACT_COMPUTATION_ON_ASSERTED_INPUTS'
        return result
    def close(self):self.records.close()
