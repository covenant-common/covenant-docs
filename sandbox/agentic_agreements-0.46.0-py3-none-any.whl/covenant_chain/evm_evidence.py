"""Ethereum chain evidence: strict RLP, block headers, receipt tries, event logs and the Solidity ABI.

GRAFT. The bytes follow the Ethereum Yellow Paper (Appendix B recursive length
prefix, Appendix D modified Merkle Patricia trie, section 4.3 block header,
section 4.4.1 transaction receipt), EIP-2718 typed receipts and the Solidity
contract ABI specification ("Formal Specification of the Encoding", "Events",
"Function Selector"). Hashing is Keccak-256 from covenant_chain.anchor, not
NIST SHA3-256.

An event log an owner hands over is a claim about a chain. A log read out of a
receipt whose trie root is the receiptsRoot of a block header whose Keccak-256
hash the owner pinned is included in that block, and nothing more: whether the
block is canonical and final is exactly as strong as the pin. Without a pin the
log stays OWNER_SUPPLIED_UNPROVEN; an unknown never becomes proven. Nothing
here fetches, signs, submits or pays. Adapters (Kleros, UMA, ERC-8183) use it
to read published outcomes as evidence for AAP's own signed terms.
"""
from copy import deepcopy
import re

from .anchor import keccak256
from .crypto import need

VERSION = 'urn:aap:evm-evidence:0.1'
MAX_RLP = 1_048_576
MAX_TOTAL = 16_777_216
MAX_DEPTH = 16
MAX_ITEMS = 65_536
MAX_PROOF = 64
MAX_RECEIPTS = 4096
MAX_LOGS = 4096
MAX_ABI = 1_048_576
MAX_ARRAY = 1024
EMPTY_TRIE = keccak256(b'\x80')
ADDRESS = re.compile(r'0x[0-9a-fA-F]{40}\Z')
NETWORK = re.compile(r'eip155:([1-9][0-9]{0,18})\Z')
HEX = re.compile(r'0x(?:[0-9a-fA-F]{2})*\Z')
ASSURANCE = ('INCLUDED_UNDER_PINNED_BLOCK', 'OWNER_SUPPLIED_UNPROVEN')
# Yellow Paper section 4.3 field order, then the fork additions in the order go-ethereum types.Header appends them.
HEADER = (('parentHash', 'hash'), ('sha3Uncles', 'hash'), ('miner', 'address'), ('stateRoot', 'hash'),
          ('transactionsRoot', 'hash'), ('receiptsRoot', 'hash'), ('logsBloom', 'bloom'), ('difficulty', 'uint'),
          ('number', 'uint'), ('gasLimit', 'uint'), ('gasUsed', 'uint'), ('timestamp', 'uint'), ('extraData', 'bytes'),
          ('mixHash', 'hash'), ('nonce', 'nonce'), ('baseFeePerGas', 'uint'), ('withdrawalsRoot', 'hash'),
          ('blobGasUsed', 'uint'), ('excessBlobGas', 'uint'), ('parentBeaconBlockRoot', 'hash'), ('requestsHash', 'hash'))
FLAGS = {'network_accessed': False, 'execution_authorized': False, 'submitted': False}

REMEDIATION = {
    'EVM_HEX': 'Give bytes as 0x followed by an even number of hex digits, within the stated size.',
    'EVM_ADDRESS': 'Use a 0x-prefixed 20-byte address; mixed case must be a valid EIP-55 checksum.',
    'EVM_NETWORK': 'Name the chain as a CAIP-2 eip155:<chain id> reference.',
    'EVM_RLP': 'The bytes are not one canonical RLP item (Yellow Paper Appendix B); obtain the exact encoding.',
    'EVM_HEADER': 'Pass the block header as its RLP bytes or as the JSON block object with every consensus field.',
    'EVM_HEADER_HASH': 'The header fields do not hash to the block hash it claims; obtain the unmodified block.',
    'EVM_BLOCK_UNPINNED': 'Pin this block hash yourself (from your own node or an adopted witness) or pass the logs unproven.',
    'EVM_PROOF': 'The trie proof is malformed or does not lead from the receiptsRoot to this receipt.',
    'EVM_PROOF_MISSING': 'A node the proof path needs is missing; pass every trie node from the root to the receipt.',
    'EVM_RECEIPTS_ROOT': 'The receipts do not rebuild the header receiptsRoot; pass every receipt of the block in order.',
    'EVM_RECEIPT': 'Pass the receipt as its EIP-2718 bytes or as the JSON receipt object of eth_getBlockReceipts.',
    'EVM_LOG': 'A log needs address, 0..4 32-byte topics and data; removed (reorganised) logs are refused.',
    'EVM_EVIDENCE': 'Pass a list of {kind: RECEIPT_PROOF | BLOCK_RECEIPTS | LOGS, network, ...} evidence entries.',
    'EVM_TRANSACTION': 'Pass transactions as their consensus bytes: legacy RLP or EIP-2718 types 1 to 4.',
    'EVM_TRANSACTIONS_ROOT': 'The transactions do not rebuild the header transactionsRoot; pass every transaction of the block in order.',
    'EVM_LIMIT': 'The evidence exceeds the bounds: 16 MiB, 4096 receipts or logs, 64 proof nodes.',
    'EVM_ABI_TYPE': 'Use canonical Solidity types: uintN, intN, address, bool, bytesN, bytes, string, T[], T[k], (T,...).',
    'EVM_ABI': 'The bytes are not the canonical Solidity ABI encoding of the stated types.',
    'EVM_ABI_VALUE': 'A value does not fit its Solidity type.',
    'EVM_EVENT': 'The log is not this event: wrong topic0, topic count or data.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Correct the input; nothing was fetched or submitted.')


# Primitive forms ----------------------------------------------------------------

def hex_bytes(text, maximum=MAX_RLP, code='EVM_HEX'):
    need(type(text) is str and len(text) <= 2 + 2 * maximum and HEX.fullmatch(text) is not None, code)
    return bytes.fromhex(text[2:])


def hex_word(text, code='EVM_HEX'):
    raw = hex_bytes(text, 32, code)
    need(len(raw) == 32, code)
    return raw


def address(value):
    """A 20-byte address in lowercase; mixed case must carry a valid EIP-55 checksum."""
    need(type(value) is str and ADDRESS.fullmatch(value) is not None, 'EVM_ADDRESS')
    body = value[2:]
    if body != body.lower() and body != body.upper():
        hashed = keccak256(body.lower().encode('ascii')).hex()
        need(all((char.upper() if int(hashed[i], 16) >= 8 else char.lower()) == char for i, char in enumerate(body)),
             'EVM_ADDRESS')
    return '0x' + body.lower()


def network(value):
    found = NETWORK.fullmatch(value) if type(value) is str else None
    need(found is not None, 'EVM_NETWORK')
    return value


def chain_id(value):
    return int(network(value).split(':')[1])


def selector(signature):
    return keccak256(signature.encode('ascii'))[:4]


def topic(signature):
    return '0x' + keccak256(signature.encode('ascii')).hex()


# RLP: Yellow Paper Appendix B, canonical only -------------------------------------

def _length(size, offset):
    if size < 56:
        return bytes([offset + size])
    raw = size.to_bytes((size.bit_length() + 7) // 8, 'big')
    return bytes([offset + 55 + len(raw)]) + raw


def rlp_encode(item):
    if type(item) is bytes:
        return item if len(item) == 1 and item[0] < 0x80 else _length(len(item), 0x80) + item
    need(type(item) is list, 'EVM_RLP')
    payload = b''.join(rlp_encode(child) for child in item)
    return _length(len(payload), 0xc0) + payload


def _long(raw, start, width, stop):
    begin = start + 1 + width
    need(begin <= stop and raw[start + 1] != 0, 'EVM_RLP')
    size = int.from_bytes(raw[start + 1:begin], 'big')
    need(size >= 56 and begin + size <= stop, 'EVM_RLP')
    return size, begin


def _item(raw, start, stop, depth, count):
    need(depth <= MAX_DEPTH and start < stop, 'EVM_RLP')
    count[0] += 1
    need(count[0] <= MAX_ITEMS, 'EVM_LIMIT')
    first = raw[start]
    if first < 0x80:
        return raw[start:start + 1], start + 1
    if first < 0xb8:
        size, begin = first - 0x80, start + 1
        need(begin + size <= stop and (size != 1 or raw[begin] >= 0x80), 'EVM_RLP')
        return raw[begin:begin + size], begin + size
    if first < 0xc0:
        size, begin = _long(raw, start, first - 0xb7, stop)
        return raw[begin:begin + size], begin + size
    if first < 0xf8:
        size, begin = first - 0xc0, start + 1
        need(begin + size <= stop, 'EVM_RLP')
    else:
        size, begin = _long(raw, start, first - 0xf7, stop)
    end, items, at = begin + size, [], begin
    while at < end:
        child, at = _item(raw, at, end, depth + 1, count)
        items.append(child)
    return items, end


def rlp_decode(raw, limit=MAX_RLP):
    """One canonical RLP item: no trailing bytes, minimal lengths, single bytes below 0x80 bare."""
    need(type(raw) is bytes and 0 < len(raw) <= limit, 'EVM_RLP')
    item, end = _item(raw, 0, len(raw), 0, [0])
    need(end == len(raw), 'EVM_RLP')
    return item


def _uint(raw, code='EVM_RLP'):
    need(type(raw) is bytes and len(raw) <= 32 and (not raw or raw[0] != 0), code)
    return int.from_bytes(raw, 'big')


def _int_bytes(value):
    need(type(value) is int and 0 <= value < 2**256, 'EVM_ABI_VALUE')
    return value.to_bytes((value.bit_length() + 7) // 8, 'big')


def _quantity(value, code):
    """A JSON-RPC QUANTITY: 0x and minimal hex digits (Ethereum execution API 'uint')."""
    need(type(value) is str and re.fullmatch(r'0x(?:0|[1-9a-fA-F][0-9a-fA-F]{0,63})', value) is not None, code)
    return int(value, 16)


# Block headers ------------------------------------------------------------------

def _header_json(value):
    need(type(value) is dict and len(value) <= 64, 'EVM_HEADER')
    names = [name for name, _ in HEADER]
    present = [name for name in names if name in value]
    need(present == names[:len(present)] and len(present) >= 15, 'EVM_HEADER')
    fields = []
    for name, kind in HEADER[:len(present)]:
        item = value[name]
        if kind == 'uint':
            fields.append(_int_bytes(_quantity(item, 'EVM_HEADER')))
        else:
            size = {'hash': 32, 'address': 20, 'bloom': 256, 'nonce': 8, 'bytes': 1024}[kind]
            raw = hex_bytes(item, size, 'EVM_HEADER')
            need(kind == 'bytes' or len(raw) == size, 'EVM_HEADER')
            fields.append(raw)
    raw = rlp_encode(fields)
    if 'hash' in value:
        need(hex_word(value['hash'], 'EVM_HEADER') == keccak256(raw), 'EVM_HEADER_HASH')
    return raw


def header(value):
    """A block header as RLP hex or JSON: its Keccak-256 hash and the fields evidence uses."""
    raw = _header_json(value) if type(value) is dict else hex_bytes(value, 65536, 'EVM_HEADER')
    try:
        fields = rlp_decode(raw, 65536)
    except ValueError:
        raise ValueError('EVM_HEADER') from None
    need(type(fields) is list and 15 <= len(fields) <= 32 and all(type(item) is bytes for item in fields), 'EVM_HEADER')
    need(all(len(fields[index]) == 32 for index in (0, 1, 3, 4, 5, 13)) and len(fields[2]) == 20
         and len(fields[6]) == 256 and len(fields[14]) == 8, 'EVM_HEADER')
    return {'hash': '0x' + keccak256(raw).hex(), 'parent': '0x' + fields[0].hex(),
            'transactions_root': '0x' + fields[4].hex(), 'receipts_root': '0x' + fields[5].hex(),
            'number': _uint(fields[8], 'EVM_HEADER'),
            'timestamp': _uint(fields[11], 'EVM_HEADER'), 'fields': len(fields)}


# Modified Merkle Patricia trie: Yellow Paper Appendix D -----------------------------

def _nibbles(raw):
    return [half for byte in raw for half in (byte >> 4, byte & 15)]


def _compact(path, leaf):
    """Hex-prefix encoding (Appendix C): flag 2 marks a leaf, an odd length shares the first byte."""
    flag = 2 if leaf else 0
    nibbles = [flag + 1] + path if len(path) % 2 else [flag, 0] + path
    return bytes(nibbles[i] << 4 | nibbles[i + 1] for i in range(0, len(nibbles), 2))


def _expand(raw):
    need(type(raw) is bytes and len(raw) >= 1 and raw[0] >> 4 <= 3, 'EVM_PROOF')
    odd, leaf = raw[0] >> 4 & 1, raw[0] >> 4 >= 2
    need(odd or raw[0] & 15 == 0, 'EVM_PROOF')
    return ([raw[0] & 15] if odd else []) + _nibbles(raw[1:]), leaf


def _reference(node, store):
    raw = rlp_encode(node)
    if len(raw) < 32:
        return node
    ref = keccak256(raw)
    store[ref] = raw
    return ref


def _build(pairs, depth, store):
    if len(pairs) == 1:
        path, value = pairs[0]
        return [_compact(path[depth:], True), value]
    common = 0
    shortest = min(len(path) for path, _ in pairs) - depth
    while common < shortest and len({path[depth + common] for path, _ in pairs}) == 1:
        common += 1
    if common:
        return [_compact(pairs[0][0][depth:depth + common], False), _reference(_build(pairs, depth + common, store), store)]
    branch = [b''] * 17
    for nibble in range(16):
        group = [pair for pair in pairs if len(pair[0]) > depth and pair[0][depth] == nibble]
        if group:
            branch[nibble] = _reference(_build(group, depth + 1, store), store)
    ended = [value for path, value in pairs if len(path) == depth]
    if ended:
        branch[16] = ended[0]
    return branch


def trie(items):
    """Root and node store of a trie over {key bytes: value bytes}; empty values are absent keys."""
    need(type(items) is dict and len(items) <= MAX_RECEIPTS * 4, 'EVM_LIMIT')
    pairs = sorted((_nibbles(k), v) for k, v in items.items() if v != b'')
    need(all(type(k) is bytes and type(v) is bytes for k, v in items.items()), 'EVM_PROOF')
    if not pairs:
        return EMPTY_TRIE, {EMPTY_TRIE: b'\x80'}
    store = {}
    raw = rlp_encode(_build(pairs, 0, store))
    root = keccak256(raw)
    store[root] = raw
    return root, store


def prove(items, key):
    """The trie nodes (root first) an owner passes to show ``key`` holds its value."""
    root, store = trie(items)
    nodes, ref, path = [], root, _nibbles(key)
    while True:
        if type(ref) is bytes:
            need(ref in store, 'EVM_PROOF_MISSING')
            nodes.append(store[ref])
            node = rlp_decode(store[ref])
        else:
            node = ref
        if len(node) == 17:
            if not path:
                return root, nodes
            ref, path = node[path[0]], path[1:]
            if ref == b'':
                return root, nodes
        else:
            prefix, leaf = _expand(node[0])
            if leaf or path[:len(prefix)] != prefix:
                return root, nodes
            ref, path = node[1], path[len(prefix):]


def trie_get(root, key, proof):
    """The value at ``key`` under ``root`` from the supplied nodes, or None when the proof shows absence."""
    need(type(root) is bytes and len(root) == 32 and type(key) is bytes, 'EVM_PROOF')
    need(type(proof) is list and len(proof) <= MAX_PROOF, 'EVM_LIMIT')
    store, total = {}, 0
    for node in proof:
        raw = hex_bytes(node, MAX_RLP, 'EVM_PROOF') if type(node) is str else node
        need(type(raw) is bytes and raw, 'EVM_PROOF')
        total += len(raw)
        need(total <= MAX_TOTAL, 'EVM_LIMIT')
        store[keccak256(raw)] = raw
    ref, path = root, _nibbles(key)
    for _ in range(2 * len(path) + 2):
        if type(ref) is bytes:
            if ref == b'':
                return None
            need(len(ref) == 32, 'EVM_PROOF')
            if ref == EMPTY_TRIE and ref == root:
                return None
            need(ref in store, 'EVM_PROOF_MISSING')
            node = rlp_decode(store[ref])
        else:
            node = ref
            need(len(rlp_encode(node)) < 32, 'EVM_PROOF')
        need(type(node) is list, 'EVM_PROOF')
        if len(node) == 17:
            if not path:
                need(type(node[16]) is bytes, 'EVM_PROOF')
                return node[16] or None
            ref, path = node[path[0]], path[1:]
            need(type(ref) is list or len(ref) in (0, 32), 'EVM_PROOF')
            continue
        need(len(node) == 2 and type(node[0]) is bytes, 'EVM_PROOF')
        prefix, leaf = _expand(node[0])
        if leaf:
            need(type(node[1]) is bytes and node[1] != b'', 'EVM_PROOF')
            return node[1] if path == prefix else None
        need(prefix and (type(node[1]) is list or len(node[1]) == 32), 'EVM_PROOF')
        if path[:len(prefix)] != prefix:
            return None
        ref, path = node[1], path[len(prefix):]
    raise ValueError('EVM_PROOF')


# Receipts and logs: Yellow Paper 4.4.1, EIP-2718 --------------------------------------

def _log_items(items):
    need(type(items) is list and len(items) <= MAX_LOGS, 'EVM_RECEIPT')
    out = []
    for item in items:
        need(type(item) is list and len(item) == 3 and type(item[0]) is bytes and len(item[0]) == 20
             and type(item[1]) is list and len(item[1]) <= 4 and type(item[2]) is bytes, 'EVM_RECEIPT')
        need(all(type(word) is bytes and len(word) == 32 for word in item[1]), 'EVM_RECEIPT')
        out.append({'address': '0x' + item[0].hex(), 'topics': ['0x' + word.hex() for word in item[1]],
                    'data': '0x' + item[2].hex()})
    return out


def receipt(raw):
    """A consensus receipt: legacy RLP list or EIP-2718 type byte then RLP payload."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_RLP, 'EVM_RECEIPT')
    kind, body = (0, raw) if raw[0] >= 0xc0 else (raw[0], raw[1:])
    need(kind == 0 or 1 <= kind <= 0x7f, 'EVM_RECEIPT')
    try:
        items = rlp_decode(body)
    except ValueError:
        raise ValueError('EVM_RECEIPT') from None
    # OP Stack deposit receipts (type 0x7e) append depositNonce and depositReceiptVersion.
    need(type(items) is list and (len(items) == 4 or (kind == 0x7e and len(items) in (5, 6))), 'EVM_RECEIPT')
    state, gas, bloom, logs = items[:4]
    need(type(state) is bytes and type(bloom) is bytes and len(bloom) == 256, 'EVM_RECEIPT')
    if len(state) == 32:
        status = None  # pre-Byzantium intermediate state root
    else:
        need(state in (b'', b'\x01'), 'EVM_RECEIPT')
        status = len(state)
    return {'type': kind, 'status': status, 'cumulative_gas': _uint(gas, 'EVM_RECEIPT'), 'logs': _log_items(logs)}


def encode_receipt(value):
    """The consensus bytes of a JSON receipt object (eth_getTransactionReceipt / eth_getBlockReceipts shape)."""
    need(type(value) is dict and len(value) <= 64, 'EVM_RECEIPT')
    kind = _quantity(value.get('type', '0x0'), 'EVM_RECEIPT')
    need(kind <= 0x7f, 'EVM_RECEIPT')
    if 'status' in value:
        status = _quantity(value['status'], 'EVM_RECEIPT')
        need(status in (0, 1), 'EVM_RECEIPT')
        state = b'\x01' if status else b''
    else:
        state = hex_word(value.get('root'), 'EVM_RECEIPT')
    bloom = hex_bytes(value.get('logsBloom'), 256, 'EVM_RECEIPT')
    need(len(bloom) == 256 and type(value.get('logs')) is list and len(value['logs']) <= MAX_LOGS, 'EVM_RECEIPT')
    logs = []
    for log in value['logs']:
        need(type(log) is dict and type(log.get('topics')) is list and len(log['topics']) <= 4, 'EVM_RECEIPT')
        need(log.get('removed') in (None, False), 'EVM_LOG')
        logs.append([bytes.fromhex(address(log.get('address'))[2:]), [hex_word(t, 'EVM_RECEIPT') for t in log['topics']],
                     hex_bytes(log.get('data'), MAX_RLP, 'EVM_RECEIPT')])
    items = [state, _int_bytes(_quantity(value.get('cumulativeGasUsed'), 'EVM_RECEIPT')), bloom, logs]
    if kind == 0x7e:
        for name in ('depositNonce', 'depositReceiptVersion'):
            if name in value:
                items.append(_int_bytes(_quantity(value[name], 'EVM_RECEIPT')))
    payload = rlp_encode(items)
    return payload if kind == 0 else bytes([kind]) + payload


def _receipt_bytes(value):
    return encode_receipt(value) if type(value) is dict else hex_bytes(value, MAX_RLP, 'EVM_RECEIPT')


def _pinned(head, trusted):
    need(head['hash'] in trusted, 'EVM_BLOCK_UNPINNED')


def _located(logs, head, index, net):
    return [{**log, 'network': net, 'block_hash': head['hash'], 'block_number': head['number'],
             'block_timestamp': head['timestamp'], 'transaction_index': index, 'log_index_in_receipt': position,
             'assurance': ASSURANCE[0]} for position, log in enumerate(logs)]


def _observed(log, net):
    need(type(log) is dict and len(log) <= 16 and type(log.get('topics')) is list and len(log['topics']) <= 4, 'EVM_LOG')
    need(log.get('removed') in (None, False), 'EVM_LOG')
    row = {'address': address(log.get('address')), 'topics': ['0x' + hex_word(t, 'EVM_LOG').hex() for t in log['topics']],
           'data': '0x' + hex_bytes(log.get('data'), MAX_RLP, 'EVM_LOG').hex(), 'network': net,
           'block_hash': None, 'block_number': None, 'block_timestamp': None, 'transaction_index': None,
           'log_index_in_receipt': None, 'assurance': ASSURANCE[1]}
    if log.get('blockHash') is not None:
        row['block_hash'] = '0x' + hex_word(log['blockHash'], 'EVM_LOG').hex()
    for name, field in (('blockNumber', 'block_number'), ('transactionIndex', 'transaction_index')):
        if log.get(name) is not None:
            row[field] = _quantity(log[name], 'EVM_LOG')
    return row


def logs(evidence, *, network_id, trusted_blocks=()):
    """Every log the evidence carries, each labelled with how it is known.

    RECEIPT_PROOF: header + transaction_index + trie nodes; BLOCK_RECEIPTS:
    header + every receipt of the block (the trie is rebuilt and must match);
    LOGS: owner-observed log objects, which stay unproven.
    """
    net = network(network_id)
    trusted = set()
    need(type(trusted_blocks) in (list, tuple) and len(trusted_blocks) <= 1024, 'EVM_EVIDENCE')
    for pin in trusted_blocks:
        trusted.add('0x' + hex_word(pin).hex())
    need(type(evidence) is list and 1 <= len(evidence) <= 64, 'EVM_EVIDENCE')
    out = []
    for entry in evidence:
        need(type(entry) is dict and entry.get('network') == net, 'EVM_EVIDENCE')
        kind = entry.get('kind')
        if kind == 'RECEIPT_PROOF':
            need(set(entry) == {'kind', 'network', 'header', 'transaction_index', 'proof'}, 'EVM_EVIDENCE')
            head = header(entry['header']); _pinned(head, trusted)
            index = entry['transaction_index']
            need(type(index) is int and 0 <= index < 2**32, 'EVM_EVIDENCE')
            raw = trie_get(bytes.fromhex(head['receipts_root'][2:]), rlp_encode(_int_bytes(index)), entry['proof'])
            need(raw is not None, 'EVM_PROOF')
            row = receipt(raw)
            need(row['status'] != 0, 'EVM_RECEIPT')
            out += _located(row['logs'], head, index, net)
        elif kind == 'BLOCK_RECEIPTS':
            need(set(entry) == {'kind', 'network', 'header', 'receipts'}, 'EVM_EVIDENCE')
            head = header(entry['header']); _pinned(head, trusted)
            need(type(entry['receipts']) is list and len(entry['receipts']) <= MAX_RECEIPTS, 'EVM_LIMIT')
            raws = [_receipt_bytes(item) for item in entry['receipts']]
            need(sum(map(len, raws)) <= MAX_TOTAL, 'EVM_LIMIT')
            root, _ = trie({rlp_encode(_int_bytes(i)): raw for i, raw in enumerate(raws)})
            need('0x' + root.hex() == head['receipts_root'], 'EVM_RECEIPTS_ROOT')
            for index, raw in enumerate(raws):
                row = receipt(raw)
                if row['status'] != 0:
                    out += _located(row['logs'], head, index, net)
        elif kind == 'LOGS':
            need(set(entry) == {'kind', 'network', 'logs'} and type(entry['logs']) is list, 'EVM_EVIDENCE')
            out += [_observed(log, net) for log in entry['logs']]
        else:
            raise ValueError('EVM_EVIDENCE')
        need(len(out) <= MAX_LOGS, 'EVM_LIMIT')
    return out


# Transactions: Yellow Paper 4.2, EIP-155, EIP-2718, EIP-2930, EIP-1559, EIP-4844, EIP-7702 ---------

# Item count, then the positions of chainId, to, value and data in each consensus encoding.
_TX = {0: (9, None, 3, 4, 5), 1: (11, 0, 4, 5, 6), 2: (12, 0, 5, 6, 7), 3: (14, 0, 5, 6, 7), 4: (13, 0, 5, 6, 7)}


def transaction(raw):
    """The fields evidence uses from one transaction's consensus bytes; its hash is Keccak-256 of them."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_RLP, 'EVM_TRANSACTION')
    kind, body = (0, raw) if raw[0] >= 0xc0 else (raw[0], raw[1:])
    need(kind in _TX, 'EVM_TRANSACTION')
    try:
        items = rlp_decode(body)
    except ValueError:
        raise ValueError('EVM_TRANSACTION') from None
    count, chain, to, value, data = _TX[kind]
    need(type(items) is list and len(items) == count, 'EVM_TRANSACTION')
    need(type(items[to]) is bytes and len(items[to]) in (0, 20) and type(items[data]) is bytes, 'EVM_TRANSACTION')
    need(kind not in (3, 4) or len(items[to]) == 20, 'EVM_TRANSACTION')
    if kind == 0:
        v = _uint(items[6], 'EVM_TRANSACTION')
        chain_value = (v - 35) // 2 if v >= 35 else None
    else:
        chain_value = _uint(items[chain], 'EVM_TRANSACTION')
    return {'type': kind, 'hash': '0x' + keccak256(raw).hex(), 'chain_id': chain_value,
            'to': '0x' + items[to].hex() if items[to] else None, 'value': _uint(items[value], 'EVM_TRANSACTION'),
            'data': '0x' + items[data].hex()}


def transactions(evidence, *, network_id, trusted_blocks=()):
    """Transactions the evidence carries: TRANSACTION_PROOF or BLOCK_TRANSACTIONS under a pinned block.

    Each is labelled with its block and index, so a log and the call that
    emitted it can be matched (same block, same index). Owner-described
    transactions without bytes are not accepted: their hash cannot be checked.
    """
    net = network(network_id)
    trusted = {'0x' + hex_word(pin).hex() for pin in trusted_blocks} if type(trusted_blocks) in (list, tuple) else None
    need(trusted is not None and len(trusted) <= 1024, 'EVM_EVIDENCE')
    need(type(evidence) is list and 1 <= len(evidence) <= 64, 'EVM_EVIDENCE')
    out = []
    for entry in evidence:
        need(type(entry) is dict and entry.get('network') == net, 'EVM_EVIDENCE')
        if entry.get('kind') == 'TRANSACTION_PROOF':
            need(set(entry) == {'kind', 'network', 'header', 'transaction_index', 'proof'}, 'EVM_EVIDENCE')
            head = header(entry['header']); _pinned(head, trusted)
            index = entry['transaction_index']
            need(type(index) is int and 0 <= index < 2**32, 'EVM_EVIDENCE')
            raw = trie_get(bytes.fromhex(head['transactions_root'][2:]), rlp_encode(_int_bytes(index)), entry['proof'])
            need(raw is not None, 'EVM_PROOF')
            rows = [(index, raw)]
        elif entry.get('kind') == 'BLOCK_TRANSACTIONS':
            need(set(entry) == {'kind', 'network', 'header', 'transactions'}, 'EVM_EVIDENCE')
            head = header(entry['header']); _pinned(head, trusted)
            need(type(entry['transactions']) is list and len(entry['transactions']) <= MAX_RECEIPTS, 'EVM_LIMIT')
            raws = [hex_bytes(item, MAX_RLP, 'EVM_TRANSACTION') for item in entry['transactions']]
            need(sum(map(len, raws)) <= MAX_TOTAL, 'EVM_LIMIT')
            root, _ = trie({rlp_encode(_int_bytes(i)): raw for i, raw in enumerate(raws)})
            need('0x' + root.hex() == head['transactions_root'], 'EVM_TRANSACTIONS_ROOT')
            rows = list(enumerate(raws))
        else:
            raise ValueError('EVM_EVIDENCE')
        for index, raw in rows:
            row = transaction(raw)
            need(row['chain_id'] in (None, chain_id(net)), 'EVM_TRANSACTION')
            out.append({**row, 'network': net, 'block_hash': head['hash'], 'block_number': head['number'],
                        'block_timestamp': head['timestamp'], 'transaction_index': index, 'assurance': ASSURANCE[0]})
        need(len(out) <= MAX_LOGS, 'EVM_LIMIT')
    return out


# Solidity ABI: "Formal Specification of the Encoding" ---------------------------------

_ELEMENTARY = re.compile(r'(uint|int)(8|16|24|32|40|48|56|64|72|80|88|96|104|112|120|128|136|144|152|160|168|176|184|192|200|'
                         r'208|216|224|232|240|248|256)\Z|address\Z|bool\Z|bytes([1-9]|[12][0-9]|3[0-2])?\Z|string\Z')


def _split(inner):
    parts, depth, start = [], 0, 0
    for index, char in enumerate(inner):
        depth += (char == '(') - (char == ')')
        need(depth >= 0, 'EVM_ABI_TYPE')
        if char == ',' and depth == 0:
            parts.append(inner[start:index]); start = index + 1
    need(depth == 0, 'EVM_ABI_TYPE')
    parts.append(inner[start:])
    return [] if parts == [''] else parts


def abi_type(text, depth=0):
    """Parse one canonical Solidity type into a node: ('tuple', [...]), ('array', node, k|None) or elementary."""
    need(type(text) is str and 0 < len(text) <= 1024 and depth <= 8, 'EVM_ABI_TYPE')
    if text.endswith(']'):
        at = text.rindex('[')
        size = text[at + 1:-1]
        need(size == '' or re.fullmatch(r'[1-9][0-9]{0,3}', size) is not None, 'EVM_ABI_TYPE')
        need(size == '' or int(size) <= MAX_ARRAY, 'EVM_ABI_TYPE')
        return ('array', abi_type(text[:at], depth + 1), int(size) if size else None)
    if text.startswith('('):
        need(text.endswith(')'), 'EVM_ABI_TYPE')
        return ('tuple', [abi_type(part, depth + 1) for part in _split(text[1:-1])])
    found = _ELEMENTARY.fullmatch(text)
    need(found is not None, 'EVM_ABI_TYPE')
    if found.group(1):
        return (found.group(1), int(found.group(2)))
    if text.startswith('bytes') and text != 'bytes':
        return ('fixed', int(text[5:]))
    return (text,)


def _dynamic(node):
    if node[0] in ('bytes', 'string'):
        return True
    if node[0] == 'array':
        return node[2] is None or _dynamic(node[1])
    if node[0] == 'tuple':
        return any(_dynamic(child) for child in node[1])
    return False


def _size(node):
    if node[0] == 'tuple':
        return sum(_size(child) for child in node[1])
    if node[0] == 'array':
        return node[2] * _size(node[1])
    return 32


def _word(value):
    return value.to_bytes(32, 'big')


def _padded(raw):
    return _word(len(raw)) + raw + b'\0' * (-len(raw) % 32)


def _encode(node, value):
    kind = node[0]
    if kind == 'tuple':
        need(type(value) in (list, tuple) and len(value) == len(node[1]), 'EVM_ABI_VALUE')
        return _sequence(node[1], value)
    if kind == 'array':
        need(type(value) in (list, tuple) and len(value) <= MAX_ARRAY and (node[2] is None or len(value) == node[2]), 'EVM_ABI_VALUE')
        body = _sequence([node[1]] * len(value), value)
        return body if node[2] is not None else _word(len(value)) + body
    if kind == 'uint':
        need(type(value) is int and 0 <= value < 2**node[1], 'EVM_ABI_VALUE')
        return _word(value)
    if kind == 'int':
        need(type(value) is int and -2**(node[1] - 1) <= value < 2**(node[1] - 1), 'EVM_ABI_VALUE')
        return _word(value % 2**256)
    if kind == 'address':
        return b'\0' * 12 + bytes.fromhex(address(value)[2:])
    if kind == 'bool':
        need(type(value) is bool, 'EVM_ABI_VALUE')
        return _word(int(value))
    if kind == 'fixed':
        need(type(value) is bytes and len(value) == node[1], 'EVM_ABI_VALUE')
        return value + b'\0' * (32 - node[1])
    if kind == 'bytes':
        need(type(value) is bytes and len(value) <= MAX_ABI, 'EVM_ABI_VALUE')
        return _padded(value)
    need(type(value) is str, 'EVM_ABI_VALUE')
    try:
        return _padded(value.encode('utf-8'))
    except UnicodeError:
        raise ValueError('EVM_ABI_VALUE') from None


def _sequence(nodes, values):
    heads, tails = [], b''
    offset = sum(32 if _dynamic(node) else _size(node) for node in nodes)
    for node, value in zip(nodes, values):
        if _dynamic(node):
            heads.append(_word(offset + len(tails)))
            tails += _encode(node, value)
        else:
            heads.append(_encode(node, value))
    return b''.join(heads) + tails


def _read(data, at):
    need(0 <= at and at + 32 <= len(data), 'EVM_ABI')
    return int.from_bytes(data[at:at + 32], 'big')


def _decode(node, data, at, depth):
    need(depth <= 16, 'EVM_ABI')
    kind = node[0]
    if kind == 'tuple':
        return _unsequence(node[1], data, at, depth)
    if kind == 'array':
        if node[2] is None:
            count = _read(data, at)
            need(count <= MAX_ARRAY and count * 32 <= len(data), 'EVM_ABI')
            return _unsequence([node[1]] * count, data, at + 32, depth)
        return _unsequence([node[1]] * node[2], data, at, depth)
    word = _read(data, at)
    if kind == 'uint':
        need(word < 2**node[1], 'EVM_ABI')
        return word
    if kind == 'int':
        value = word - 2**256 if word >= 2**255 else word
        need(-2**(node[1] - 1) <= value < 2**(node[1] - 1), 'EVM_ABI')
        return value
    if kind == 'address':
        need(word < 2**160, 'EVM_ABI')
        return '0x' + data[at + 12:at + 32].hex()
    if kind == 'bool':
        need(word in (0, 1), 'EVM_ABI')
        return bool(word)
    if kind == 'fixed':
        raw = data[at:at + 32]
        need(raw[node[1]:] == b'\0' * (32 - node[1]), 'EVM_ABI')
        return raw[:node[1]]
    need(word <= MAX_ABI and at + 32 + word <= len(data), 'EVM_ABI')
    raw = data[at + 32:at + 32 + word]
    if kind == 'bytes':
        return raw
    try:
        return raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('EVM_ABI') from None


def _unsequence(nodes, data, base, depth):
    out, head = [], base
    for node in nodes:
        if _dynamic(node):
            offset = _read(data, head)
            need(offset < len(data), 'EVM_ABI')
            out.append(_decode(node, data, base + offset, depth + 1)); head += 32
        else:
            out.append(_decode(node, data, head, depth + 1)); head += _size(node)
    return out


def abi_encode(types, values):
    nodes = [abi_type(text) for text in types]
    need(type(values) in (list, tuple) and len(values) == len(nodes), 'EVM_ABI_VALUE')
    return _sequence(nodes, values)


def abi_decode(types, data):
    """Strict decoding: the input must be the one canonical encoding of what it decodes to."""
    need(type(data) is bytes and len(data) <= MAX_ABI, 'EVM_ABI')
    nodes = [abi_type(text) for text in types]
    values = _unsequence(nodes, data, 0, 0)
    need(_sequence(nodes, values) == data, 'EVM_ABI')
    return values


def _signature(text):
    found = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]{0,63})\((.*)\)', text) if type(text) is str else None
    need(found is not None, 'EVM_ABI_TYPE')
    params = _split(found.group(2))
    for item in params:
        abi_type(item)
    return found.group(1), params


def calldata(signature, values):
    """Function selector then the ABI-encoded arguments. The caller submits these bytes, or does not."""
    _, params = _signature(signature)
    return selector(signature) + abi_encode(params, values)


def decode_calldata(signature, data):
    _, params = _signature(signature)
    need(type(data) is bytes and data[:4] == selector(signature), 'EVM_ABI')
    return abi_decode(params, data[4:])


def event(log, signature, indexed):
    """Decode one log as ``signature``: indexed parameters from topics (dynamic ones stay hashes)."""
    _, params = _signature(signature)
    need(type(indexed) in (list, tuple) and len(indexed) == len(params) and all(type(i) is bool for i in indexed), 'EVM_ABI_TYPE')
    need(type(log) is dict and type(log.get('topics')) is list, 'EVM_EVENT')
    topics = log['topics']
    need(len(topics) == 1 + sum(indexed) and topics[0] == topic(signature), 'EVM_EVENT')
    values, words = [None] * len(params), iter(topics[1:])
    for position, (kind, flag) in enumerate(zip(params, indexed)):
        if flag:
            word = hex_word(next(words), 'EVM_EVENT')
            node = abi_type(kind)
            values[position] = ('0x' + word.hex()) if _dynamic(node) or node[0] in ('tuple', 'array') else abi_decode([kind], word)[0]
    rest = [kind for kind, flag in zip(params, indexed) if not flag]
    try:
        decoded = iter(abi_decode(rest, hex_bytes(log.get('data'), MAX_ABI, 'EVM_EVENT')))
    except ValueError:
        raise ValueError('EVM_EVENT') from None
    for position, flag in enumerate(indexed):
        if not flag:
            values[position] = next(decoded)
    return values


def describe():
    return {'version': VERSION, 'decision': 'GRAFT',
            'specifications': ['Ethereum Yellow Paper Appendix B (RLP), Appendix C (hex-prefix), Appendix D (trie)',
                               'Yellow Paper section 4.3 (block header) and 4.4.1 (receipt)', 'EIP-2718 typed receipts',
                               'EIP-155, EIP-2930, EIP-1559, EIP-4844 and EIP-7702 transaction encodings',
                               'Solidity ABI specification: encoding, events, function selector', 'CAIP-2 eip155 chain ids'],
            'evidence_kinds': {'RECEIPT_PROOF': 'header + transaction_index + trie nodes; included under a pinned block',
                               'BLOCK_RECEIPTS': 'header + every receipt; the receipts trie is rebuilt and must match',
                               'LOGS': 'owner-observed logs; OWNER_SUPPLIED_UNPROVEN',
                               'TRANSACTION_PROOF': 'header + transaction_index + trie nodes under transactionsRoot',
                               'BLOCK_TRANSACTIONS': 'header + every transaction; the transactions trie is rebuilt and must match'},
            'assurance': list(ASSURANCE),
            'not_established': ['that a pinned block is canonical or final', 'contract source or behaviour', 'world truth'],
            'limits': {'rlp_bytes': MAX_RLP, 'total_bytes': MAX_TOTAL, 'proof_nodes': MAX_PROOF,
                       'receipts': MAX_RECEIPTS, 'logs': MAX_LOGS, 'abi_bytes': MAX_ABI, 'array': MAX_ARRAY},
            'remediation': deepcopy(REMEDIATION), **FLAGS}
