"""Explicit private working-copy download and bounded reopen; no filesystem I/O.

The export contains plaintext terms and salts. Its digest detects alteration
against a retained expected ID, not replacement with another valid export.
Saved current-reference observations never become a live currentness oracle.
"""
from copy import deepcopy
import base64
import hashlib
import json
from html import escape
from . import human_agreements as h
from .workflow_store import canonical

VERSION = 'covenant-human-private-copy/0.1'
MAX_BYTES = 1000000


def _id(body):
    return hashlib.sha256(b'COVENANT-HUMAN-PRIVATE-COPY-0.1\0'+canonical(body)).hexdigest()


def _value_html(value):
    if type(value) is dict:
        return '<dl>'+''.join('<dt>'+escape(k)+'</dt><dd>'+_value_html(v)+'</dd>' for k,v in value.items())+'</dl>' if value else '<p>Empty object {}</p>'
    if type(value) is list:
        return '<ol>'+''.join('<li>'+_value_html(v)+'</li>' for v in value)+'</ol>' if value else '<p>Empty list []</p>'
    if value is None:return '<p>Not specified (null)</p>'
    if type(value) is bool:return '<p>'+('true' if value else 'false')+'</p>'
    return '<p class="literal">'+escape(str(value))+'</p>'


def _review_html(packet,review):
    job=packet['terms']['job']
    sections=[('Parties and signing identities',packet['terms']['parties']),('Work and scope',job['scope']),
        ('Deliverables',job['deliverables']),('Acceptance checks',job['acceptance_checks']),
        ('Schedule',job['schedule']),('Price',review['summary']['price']),('Included revisions',job['revisions']),
        ('Payment and release terms',job['payment']),('Chosen identity or evidence',job['identity']),
        ('Privacy, readers and publication',job['privacy']),('Dispute procedure',job['dispute']),
        ('Additional agreed terms',job['extensions'])]
    content=''.join('<section><h2>'+title+'</h2>'+_value_html(value)+'</section>' for title,value in sections)
    return '<p>Private readable terms. The full exact structured terms below control what was committed; this page neither publishes them nor authorizes any action.</p>'+content+'<h2>Signatures and revision reference at copy creation</h2>'+_value_html({'assents':review['assents'],'currentness':review['currentness'],'proposed_defaults':review['proposed_defaults']})+'<details><summary>Exact complete structured terms</summary><pre>'+escape(json.dumps(packet['terms'],ensure_ascii=False,indent=2))+'</pre></details>'


def private_copy(packet, approvals=None, current_id=None, previous=None):
    approvals = [] if approvals is None else approvals
    review = h.review(packet, approvals, current_id, previous)
    body = {'version': VERSION, 'packet': deepcopy(packet), 'approvals': deepcopy(approvals),
            'previous': deepcopy(previous), 'observed_reference': current_id}
    wire = canonical(body);h.need(len(wire) <= MAX_BYTES, 'HUMAN_COPY_SIZE')
    ref = _id(body);filename = 'covenant-private-'+ref+'.json'
    encoded = base64.b64encode(wire).decode('ascii')
    html = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'"><title>Private agreement copy</title><style>body{font:16px/1.16 "Times New Roman",serif;color:#000;background:#fff;margin:1rem}main{max-width:65rem;margin:auto;border:1px solid #000;padding:1rem}h1,h2,button,pre,summary{font:inherit}h1,h2{font-weight:bold;margin:.618rem 0 .382rem}p{margin:.382rem 0 .618rem}button{color:#000;background:#fff;border:1px solid #000;padding:.382rem .618rem}code,pre{font:inherit;overflow-wrap:anywhere}pre,.literal{white-space:pre-wrap}dl{margin:.382rem 0 .618rem}dt{font-weight:bold}dd{margin:0 0 .382rem .618rem}details{margin:.618rem 0}</style><main><h1>Private agreement copy</h1><p>'+escape(review['title'])+' · '+escape(review['summary']['price'])+'</p><p>'+escape(review['assent_note'])+'</p><p>This download contains plaintext private terms, signatures and opening salts. Save it in your own private storage. It is not encrypted, published, or appended to a ledger.</p>'+_review_html(packet,review)+'<button id="save" type="button">Save private copy</button><p>Retain this expected copy ID separately: <code>'+ref+'</code></p><p>Reopen with covenant_agreement.reopen and this expected ID. Supply a fresh current-revision reference if you want a currentness assessment; a saved observation is historical.</p></main><script>document.getElementById("save").addEventListener("click",()=>{const bytes=Uint8Array.from(atob("'+encoded+'"),c=>c.charCodeAt(0));const url=URL.createObjectURL(new Blob([bytes],{type:"application/json"}));const link=document.createElement("a");link.href=url;link.download="'+filename+'";link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});</script></html>'
    return {'id': ref, 'filename': filename, 'media_type': 'application/json', 'content': wire.decode('ascii'),
            'html': html, 'status': 'READY_TO_SAVE_PRIVATELY', 'saved': False, 'recorded': False,
            'encrypted': False, 'execution_authorized': False}


def reopen(content, expected_id, current_id=None, owner_status=None):
    h.text(content, MAX_BYTES);h.p.ref(expected_id)
    def pairs(items):
        out = {}
        for name, value in items:
            h.need(name not in out, 'HUMAN_COPY_DUPLICATE_KEY');out[name] = value
        return out
    try:
        body = json.loads(content, object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('HUMAN_COPY_JSON')))
    except (TypeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValueError('HUMAN_COPY_JSON') from exc
    h.fields(body, ('version', 'packet', 'approvals', 'previous', 'observed_reference'))
    h.need(body['version'] == VERSION, 'HUMAN_COPY_VERSION')
    h.need(canonical(body).decode('ascii') == content and _id(body) == expected_id, 'HUMAN_COPY_EXPECTATION')
    if body['observed_reference'] is not None:h.p.ref(body['observed_reference'])
    review = h.review(body['packet'], body['approvals'], current_id, body['previous'], owner_status)
    return {'id': expected_id, 'packet': body['packet'], 'approvals': body['approvals'],
            'previous': body['previous'], 'historical_observed_reference': body['observed_reference'],
            'review': review, 'integrity': 'MATCHES_RETAINED_EXPECTED_COPY_ID',
            'recorded': False, 'encrypted': False, 'execution_authorized': False}
