"""Create a new, non-overwriting local developer starter, or verify an agent gateway audit."""
import argparse,json
from pathlib import Path
from .crypto import loads
from .developer_sdk import initialize
from .agent_gateway import verify_export,verify_trust_mark

def _read(path):
    return loads(Path(path).read_bytes())

def main():
    parser=argparse.ArgumentParser(description=__doc__);commands=parser.add_subparsers(dest='action',required=True)
    init=commands.add_parser('init');init.add_argument('--directory',required=True);init.add_argument('--name',required=True)
    init.add_argument('--kind',choices=('application','connector'),default='application')
    audit=commands.add_parser('gateway-verify',help='Replay an exported agent gateway log against its policies.')
    audit.add_argument('--export',required=True);audit.add_argument('--log-signer',required=True)
    audit.add_argument('--mark',action='append',default=[],help='A retained trust mark; the log must extend it.')
    mark=commands.add_parser('gateway-mark-verify',help='Check a published agent gateway trust mark.')
    mark.add_argument('--mark',required=True);mark.add_argument('--log-signer')
    mark.add_argument('--policy',help='The full policy, when the operator disclosed it.')
    args=parser.parse_args()
    try:
        if args.action=='init':result=initialize(args.directory,args.name,args.kind)
        elif args.action=='gateway-verify':
            result=verify_export(_read(args.export),expected_log_signer=args.log_signer,
                                 known_marks=[_read(path) for path in args.mark])
        else:
            result=verify_trust_mark(_read(args.mark),expected_log_signer=args.log_signer,
                                     policy=_read(args.policy) if args.policy else None)
    except (ValueError,OSError) as error:
        if args.action=='init':parser.exit(2,str(error)+'\n')
        code=str(error).splitlines()[0] if str(error) else type(error).__name__
        sequence=getattr(error,'sequence',None)
        parser.exit(2,json.dumps({'error':code,'sequence':sequence},sort_keys=True)+'\n')
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__':main()
