"""Bounded, offline transport of unchanged coordination cases.

The wrapper fingerprint pins a plaintext handoff, not its truth, currency,
authority, or legal effect. No owner configuration or executable payload is
accepted. Existing signed profiles retain their original verifiers and bytes.
"""
from copy import deepcopy
import argparse
import hashlib
import json
import re
import sys

from .crypto import need
from . import coordination_review as review
from covenant_language import capsules, external_drafts as external
from covenant_language import frame_concepts as concepts, legal_composition

VERSION = 'covenant-portable-agreement/0.1'
RESULT = 'covenant-portable-agreement-review/0.1'
DOMAIN = b'COVENANT-PORTABLE-AGREEMENT-0.1\0'
MAX_BYTES = 1_250_000
MAX_DEPTH = 40
MAX_NODES = 120_000
PLAINTEXT = 'PLAINTEXT; COMPLETE CARRIED INPUTS ARE DISCLOSED; NO ENCRYPTION OR SECRET FILTERING'


def canonical(value):
    """Wrapper canonicalization; never replaces a signed profile's encoding."""
    nodes = 0
    string_bytes = 0

    def count_string(item, limit, code):
        nonlocal string_bytes
        need(len(item) <= limit, code)
        try:
            size = len(item.encode('utf-8'))
        except UnicodeError:
            raise ValueError('PORTABLE_UNICODE') from None
        need(size <= limit, code)
        string_bytes += size
        need(string_bytes <= MAX_BYTES, 'PORTABLE_SIZE')

    def visit(item, depth=0):
        nonlocal nodes
        nodes += 1
        need(nodes <= MAX_NODES and depth <= MAX_DEPTH, 'PORTABLE_COMPLEXITY')
        if item is None or type(item) is bool:
            return
        if type(item) is int:
            need(abs(item) <= 2**53 - 1, 'PORTABLE_INTEGER')
            return
        if type(item) is str:
            count_string(item, 524288, 'PORTABLE_STRING')
            return
        if type(item) is list:
            need(len(item) <= 256, 'PORTABLE_ARRAY')
            for child in item:
                visit(child, depth + 1)
            return
        need(type(item) is dict and len(item) <= 256, 'PORTABLE_OBJECT')
        for key, child in item.items():
            need(type(key) is str, 'PORTABLE_KEY')
            count_string(key, 128, 'PORTABLE_KEY')
            visit(child, depth + 1)

    visit(value)
    chunks = []
    length = 0
    encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                               separators=(',', ':'), allow_nan=False)
    for chunk in encoder.iterencode(value):
        length += len(chunk)
        need(length <= MAX_BYTES, 'PORTABLE_SIZE')
        chunks.append(chunk)
    return ''.join(chunks).encode('ascii')


def loads(raw):
    """Parse bounded JSON before expensive hashing, copying, or verification."""
    need(type(raw) in (bytes, str), 'PORTABLE_JSON')
    need(len(raw) <= MAX_BYTES, 'PORTABLE_SIZE')
    if type(raw) is str:
        try:
            raw = raw.encode('utf-8')
        except UnicodeError:
            raise ValueError('PORTABLE_UNICODE') from None
        need(len(raw) <= MAX_BYTES, 'PORTABLE_SIZE')
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('PORTABLE_UNICODE') from None
    # Bound parser recursion before json.loads, respecting escaped strings.
    depth = 0
    quoted = escaped = False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in '[{':
            depth += 1
            need(depth <= MAX_DEPTH, 'PORTABLE_COMPLEXITY')
        elif char in ']}':
            depth -= 1

    def pairs(items):
        value = {}
        for key, item in items:
            need(key not in value, 'PORTABLE_DUPLICATE_KEY')
            value[key] = item
        return value

    def integer(value):
        need(len(value.lstrip('-')) <= 16, 'PORTABLE_INTEGER')
        result = int(value)
        need(abs(result) <= 2**53 - 1, 'PORTABLE_INTEGER')
        return result

    def noninteger(_):
        raise ValueError('PORTABLE_NUMBER')

    try:
        value = json.loads(text, object_pairs_hook=pairs, parse_int=integer,
                           parse_float=noninteger, parse_constant=noninteger)
    except (json.JSONDecodeError, RecursionError):
        raise ValueError('PORTABLE_JSON') from None
    canonical(value)
    return value


def _hash(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'PORTABLE_REFERENCE')


def _context(row):
    if row.get('kind') == 'ORDER':
        order = row.get('order')
        data = order.get('data') if type(order) is dict else None
        return data.get('context') if type(data) is dict else None
    return row.get('context') if row.get('kind') in ('EXTERNAL', 'CONCEPT', 'LEGAL') else None


def _validate(package):
    canonical(package)
    need(type(package) is dict and set(package) ==
         {'version', 'case', 'case_id', 'context_openings'}, 'PORTABLE_FIELDS')
    need(package['version'] == VERSION, 'PORTABLE_PROFILE')
    _hash(package['case_id'])
    need(review.identifier(package['case']) == package['case_id'], 'PORTABLE_CASE_ID')
    openings = package['context_openings']
    need(type(openings) is dict and len(openings) <= 64, 'PORTABLE_CONTEXT_OPENINGS')
    # Only the explicitly adopted external-draft context function opens hashes.
    contexts = {_context(row) for row in package['case']['agreements']
                if type(_context(row)) is str}
    for ref, value in openings.items():
        _hash(ref)
        need(ref in contexts, 'PORTABLE_CONTEXT_NOT_USED')
        need(external.context_reference(value)['id'] == ref, 'PORTABLE_CONTEXT_MISMATCH')


def identifier(package):
    _validate(package)
    return hashlib.sha256(DOMAIN + canonical(package)).hexdigest()


def decode(raw):
    value = loads(raw)
    _validate(value)
    return value


def _tools():
    from .agent_exchange_tools import ExchangeTools
    return ExchangeTools()


def _bundle_inventory(bundle):
    resolved = concepts.resolve(**bundle)
    need(resolved['status'] == 'RESOLVED', 'PORTABLE_CLOSURE_INCOMPLETE')
    used = {(a['kind'], a['id']) for a in resolved['manifest']['artifacts']}
    caps = {capsules.capsule_id(a['value']): a for a in bundle['artifacts']
            if a['kind'] == 'capsule'}
    documents = []
    for ref, artifact in caps.items():
        cap = artifact['value']
        if ('capsule', ref) not in used or cap['language'] != external.VERSION:
            continue
        # Validate exact bytes even for unsigned/partially signed drafts.
        document = {'version': external.VERSION, 'root': ref,
                    'artifacts': [caps[key] for key in sorted({ref, *cap['dependencies']})]}
        opened = external.inspect(document, ref)
        documents.append({'id': ref, 'bytes': opened['manifest']['bytes'],
                          'sha256': opened['manifest']['sha256']})
    return {'status': 'COMPLETE', 'id': resolved['closure'],
            'manifest': resolved['manifest'], 'byte_documents': documents,
            'capsules': [{'id': ref, 'language': a['value']['language'],
                          'semantics': a['value']['semantics'], 'execution': 'NO_CODE_LOADING',
                          'interpretation': 'NATIVE_FIXED_PROFILE_ONLY; CUSTOM_SOURCE_INERT'}
                         for ref, a in sorted(caps.items()) if ('capsule', ref) in used]}


def _agreements(case, openings):
    rows = []
    known = {r.get('expected_id') for r in case['agreements']
             if type(r.get('expected_id')) is str and r.get('kind') != 'REFERENCE'}
    legal = [r['module'] for r in case['agreements'] if r.get('kind') == 'LEGAL' and 'module' in r]
    for row in case['agreements']:
        checked, obj = review._agreement(row, case['version'])
        kind = row['kind']
        closure = {'status': 'ROOT_OBJECT_COMPLETE', 'scope': 'EXACT_NATIVE_SIGNED_ROOT'}
        if kind in ('EXTERNAL', 'CONCEPT'):
            closure = _bundle_inventory(row['bundle'])
            need(closure['id'] == row['expected_closure'], 'PORTABLE_CLOSURE_ID')
            if kind == 'EXTERNAL':
                need(bool(closure['byte_documents']), 'EXTERNAL_NO_DECLARED_DOCUMENTS')
        elif kind == 'ORDER':
            from covenant_language import marketplace
            closure = _bundle_inventory(marketplace.order_review(row['order'])['prepared']['bundle'])
            closure['scope'] = 'DETERMINISTIC_NATIVE_ORDER_SIGNING_CLOSURE'
        elif kind == 'LEGAL':
            composition = legal_composition.compose(row['expected_id'], legal)
            closure = {'status': 'ROOT_OBJECT_COMPLETE' if composition['status'] == 'STRUCTURALLY_RESOLVED'
                       else 'REFERENCES_UNRESOLVED', 'scope': 'EXACT_MODULE_AND_REFERENCES; NOT_CHILD_PARTY_ASSENTS',
                       'reference_traversal': composition}
        elif kind == 'REFERENCE':
            closure = {'status': 'NOT_CHECKABLE_REFERENCE_ONLY'}
        progress = deepcopy(checked.get('assent_progress', {}))
        status = checked['status']
        # A complete-set verifier correctly refuses incomplete assent. Present
        # an exact valid subset as progress, retaining that native result below.
        # Counts alone are insufficient: duplicate, foreign or extra proofs
        # must never be relabelled as an ordinary pending counter-signature.
        count = progress.get('valid_required', 0)
        proofs = row.get('approvals', [])
        roles = checked.get('required_assent', {}).get('required_assents')
        if roles is None:
            roles = [{'concept': None, 'party': party} for party in
                     checked.get('required_assent', {}).get('required_parties', {})]
        required_roles = {(r.get('concept'), r['party']) for r in roles}
        proof_roles = [(p.get('concept'), p.get('party')) for p in proofs if type(p) is dict]
        fields = {'party', 'signature'} if kind == 'LEGAL' else {'concept', 'party', 'signature'}
        if (status == 'REFUSED' and 0 < count < progress.get('required', 0)
                and checked.get('code') in ('CONCEPT_ALL_PARTY_ASSENTS', 'LEGAL_ALL_PARTY_ASSENTS')
                and len(proofs) == count
                and all(type(p) is str and (c is None or type(c) is str) for c, p in proof_roles)
                and len(set(proof_roles)) == count
                and all(type(p) is dict and set(p) == fields for p in proofs)
                and set(proof_roles) <= required_roles
                and all(r['status'] == 'MISSING_ROLE_SIGNATURE' for r in progress['missing_or_invalid'])):
            status = 'PARTIAL_ASSENT'
        if progress.get('required') == 0:
            status = 'NO_DECLARED_SIGNING_ROLES'
        if closure['status'] == 'REFERENCES_UNRESOLVED':
            status = 'REFERENCES_UNRESOLVED'
        previous = checked.get('supersedes')
        context = checked.get('context')
        rows.append({'item': row['id'], 'kind': kind, 'id': checked.get('id'),
                     'profile': (obj.get('version', obj.get('profile')) if obj is not None else None),
                     'status': status, 'native_assent_status': checked['status'],
                     'code': checked.get('code'), 'assent_progress': progress,
                     'assent_scope': 'ALL_REQUIRED_SIGNATURES; PARTIAL_ASSENT_IS_NOT_COMPLETE_AGREEMENT',
                     'closure': closure,
                     'predecessor': {'id': previous, 'status': 'NOT_DECLARED' if previous is None else
                                     'INCLUDED_AS_AGREEMENT' if previous in known else 'REFERENCED_NOT_INCLUDED',
                                     'authorization': 'NOT_ESTABLISHED_BY_SUCCESSOR_SIGNATURES'},
                     'context': {'id': context, 'status': 'NOT_APPLICABLE' if context is None else
                                 'PREIMAGE_MATCHED' if context in openings else 'HASH_ONLY_PREIMAGE_NOT_CARRIED',
                                 'basis': 'EXTERNAL_DRAFT_CONTEXT_HASH_ONLY; NOT_WORLD_CONTEXT_VERIFICATION'},
                     'currentness': {'receiver_status': 'UNKNOWN',
                                     'sender_reference': row.get('expected_current_id'),
                                     'matches_sender_reference': checked.get('currentness', {}).get('matches'),
                                     'basis': 'SENDER_CARRIED_REFERENCE_ONLY; NOT_INDEPENDENT_RECEIVER_TRUST'},
                     'execution_authorized': False})
    return rows


def _compact(package, ref):
    case = package['case']
    agreements = _agreements(case, package['context_openings'])
    result = review.review(_tools(), case, expected_id=package['case_id'])
    # Select a compact projection: never return the full case, signatures,
    # source text, context openings, or the required assent payload by default.
    overview = deepcopy(result['overview'])
    overview['verified_agreements'] = sum(a['status'] == 'VERIFIED' for a in agreements)
    overview['unverified_agreements'] = len(agreements) - overview['verified_agreements']
    overview['assent'] = [{'item': a['item'], 'status': a['status'], **deepcopy(a['assent_progress'])}
                          for a in agreements]
    selected = next((a for a in agreements if a['item'] == case.get('primary')), None)
    overview['selected_agreement'] = None if selected is None else {
        key: deepcopy(selected[key]) for key in ('item', 'id', 'status', 'assent_progress')}
    unverified = {a['id'] for a in agreements if a['status'] != 'VERIFIED'}
    for money in overview.get('money', []):
        if money.get('agreement') in unverified:
            money['remaining_in_supplied_scope'] = None
            money['status'] = 'PORTABLE_AGREEMENT_NOT_VERIFIED'
    actions = deepcopy(result['next_actions'])
    for row in agreements:
        if row['status'] == 'PARTIAL_ASSENT':
            actions = [a for a in actions if not (a.get('section') == 'agreements' and a.get('item') == row['item'])]
            actions.append({'section': 'agreements', 'item': row['item'], 'status': 'PARTIAL_ASSENT',
                            'action': 'The supplied role signatures are valid. Obtain the remaining explicit signatures; the native complete-set verifier still refuses incomplete assent.'})
        if row['status'] in ('NO_DECLARED_SIGNING_ROLES', 'REFERENCES_UNRESOLVED'):
            actions.append({'section': 'agreements', 'item': row['item'], 'status': row['status'],
                            'action': 'Review the absent signing roles or missing referenced modules before relying on this handoff.'})
    return {'version': RESULT, 'id': ref, 'case_id': package['case_id'],
            'status': 'OFFLINE_REVIEW', 'title': case['title'], 'primary': case.get('primary'),
            'agreements': agreements,
            'assent_summary': 'ALL_REQUIRED_ASSENTS_VERIFIED' if agreements and
             all(r['status'] == 'VERIFIED' for r in agreements) else 'NOT_ALL_REQUIRED_ASSENTS_VERIFIED',
            'overview': overview,
            'sections': {name: {'status': result[name].get('status', 'REVIEWED_IN_SUPPLIED_SCOPE'),
                                **({'code': result[name]['code']} if 'code' in result[name] else {})}
                         for name in ('authority', 'evidence', 'payments')},
            'next_actions': actions,
            'runtime': {'implementation': 'agentic-agreements Python', 'python': '>=3.11',
                        'core_dependency': 'cryptography>=50.0.2,<51',
                        'optional_signature_dependency': 'pqcrypto==0.4.0 for ML-DSA-65 identities',
                        'owners': 'NONE; CURRENT_AUTHORITY_AND_OWNER_OBSERVATIONS_UNAVAILABLE',
                        'network_retrieval': False, 'payload_execution': False,
                        'independent_js': 'EXISTING_CHECKERS_VERIFY_CARRIER_IDENTITIES_NOT_COMPLETE_ASSENTS'},
            'disclosure': PLAINTEXT,
            'presentation': 'COMPACT_SOURCE_OMISSION_IS_NOT_CONFIDENTIALITY; LABELS_IDENTITIES_AND_AMOUNTS_MAY_REMAIN',
            'current_authority': 'UNKNOWN', 'global_latest': 'UNKNOWN',
            'legal_effect': 'NOT_ESTABLISHED', 'world_truth': 'NOT_ESTABLISHED',
            'signature_created': False, 'recorded': False, 'execution_authorized': False}


def pack(case, context_openings=None):
    canonical(case)
    package = {'version': VERSION, 'case': case, 'case_id': review.identifier(case),
               'context_openings': {} if context_openings is None else context_openings}
    ref = identifier(package)
    summary = _compact(package, ref)
    return {'package': deepcopy(package), 'id': ref, 'case_id': package['case_id'],
            'review': summary, 'disclosure': PLAINTEXT, 'recorded': False}


def _pinned(package, expected_id):
    _hash(expected_id)
    ref = identifier(package)
    need(ref == expected_id, 'PORTABLE_EXPECTED_PACKAGE')
    return ref


def inspect(package, expected_id):
    return _compact(package, _pinned(package, expected_id))


def open_source(package, expected_id, agreement, document='terms', encoding='UTF8'):
    ref = _pinned(package, expected_id)
    rows = _agreements(package['case'], package['context_openings'])
    result = review.open_source(_tools(), package['case'], agreement, document,
                                expected_id=package['case_id'], encoding=encoding)
    return _opening(result, rows, agreement, ref)


def open_object(package, expected_id, agreement, path=''):
    ref = _pinned(package, expected_id)
    rows = _agreements(package['case'], package['context_openings'])
    result = review.open_object(_tools(), package['case'], agreement, path,
                                expected_id=package['case_id'])
    return _opening(result, rows, agreement, ref)


def _opening(result, rows, agreement, ref):
    selected = next(row for row in rows if row['item'] == agreement)
    return {**result, 'native_assent_status': result['assent_status'],
            'assent_status': selected['status'], 'closure': selected['closure'],
            'context': selected['context'], 'predecessor': selected['predecessor'],
            'currentness': selected['currentness'],
            'package_id': ref, 'package_disclosure': PLAINTEXT}


def spec():
    return {'version': VERSION, 'result': RESULT, 'maximum_bytes': MAX_BYTES,
            'maximum_depth': MAX_DEPTH, 'maximum_nodes': MAX_NODES,
            'package_fields': ['version', 'case', 'case_id', 'context_openings'],
            'identity': 'SHA256(COVENANT-PORTABLE-AGREEMENT-0.1 NUL canonical(package))',
            'canonicalization': 'SORTED_ASCII_JSON; NO_FLOATS; SAFE_INTEGERS; DUPLICATE_KEYS_REJECTED',
            'pin': 'INSPECT_AND_OPEN_REQUIRE_INDEPENDENTLY_OBTAINED_EXPECTED_PACKAGE_ID',
            'context_openings': 'HASH_TO_VALUE; EXTERNAL_DRAFT_CONTEXT_REFERENCE_HASHING_ONLY',
            'signed_profiles': 'UNCHANGED; NO_SIGNATURE_CONVERSION',
            'disclosure': PLAINTEXT, 'recorded': False, 'execution_authorized': False}


def _read(path):
    if path == '-':
        return loads(sys.stdin.buffer.read(MAX_BYTES + 1))
    with open(path, 'rb') as source:
        return loads(source.read(MAX_BYTES + 1))


def main(argv=None):
    parser = argparse.ArgumentParser(description='Inspect a plaintext agreement handoff offline; all output is stdout.')
    commands = parser.add_subparsers(dest='action', required=True)
    commands.add_parser('spec')
    packing = commands.add_parser('pack')
    packing.add_argument('input', nargs='?', default='-', help='Raw coordination case JSON file or - for stdin')
    packing.add_argument('--context-openings', help='Optional JSON object mapping external context hashes to preimages')
    for action in ('inspect', 'open-source', 'open-object'):
        command = commands.add_parser(action)
        command.add_argument('input', nargs='?', default='-', help='Raw package JSON file or - for stdin')
        command.add_argument('--expected-id', required=True, help='Independently retained package fingerprint')
        if action != 'inspect':
            command.add_argument('--agreement', required=True)
        if action == 'open-source':
            command.add_argument('--document', default='terms')
            command.add_argument('--encoding', choices=('UTF8', 'BASE64'), default='UTF8')
        if action == 'open-object':
            command.add_argument('--path', default='')
    args = parser.parse_args(argv)
    try:
        if args.action == 'spec':
            result = spec()
        elif args.action == 'pack':
            need(not (args.input == '-' and args.context_openings == '-'), 'PORTABLE_STDIN_USED_TWICE')
            result = pack(_read(args.input), _read(args.context_openings) if args.context_openings else None)
        else:
            parameters = {'package': _read(args.input), 'expected_id': args.expected_id}
            if args.action != 'inspect':
                parameters['agreement'] = args.agreement
            if args.action == 'open-source':
                parameters.update(document=args.document, encoding=args.encoding)
            if args.action == 'open-object':
                parameters['path'] = args.path
            result = {'inspect': inspect, 'open-source': open_source, 'open-object': open_object}[args.action](**parameters)
        print(json.dumps(result, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False))
        return 0
    except (ValueError, TypeError, KeyError, UnicodeError, OverflowError, OSError) as error:
        code = str(error)
        if re.fullmatch('[A-Z][A-Z0-9_]{0,95}', code) is None:
            code = 'PORTABLE_CHECK_FAILED'
        print(json.dumps({'status': 'REFUSED', 'code': code, 'recorded': False, 'execution_authorized': False}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
