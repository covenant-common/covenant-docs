"""Project agreed fields before invoking the frozen mechanism commitment profile.

The source uses the bounded agent JSON profile; selected values and their
path-preserving projection must still fit mechanism_plans' existing profile.
Unselected source content is neither committed nor returned. This helper does
not attest to the original document, discover a file, execute a connector, or
hide the source from the calling model/host. Array gaps are explicit None
placeholders, never claims about the corresponding unselected source values.
"""
from copy import deepcopy

from covenant_language import mechanism_plans as plans
from .agent_tools import validate_json

SCOPE = 'ONLY_SELECTED_VALUES_COMMITTED_NOT_ORIGINAL_FULL_DOCUMENT'
_OPTIONS = {'visibility', 'recipients', 'protection', 'mechanisms', 'gates',
            'depends_on', 'frame'}
# A preserved index requires an array at least index + 1 elements long. The
# frozen mechanism profile admits at most 256 elements, including placeholders.
_ARRAY_ITEMS = 256


def _selectors(fields):
    plans.need(type(fields) is list and len(fields) <= 32 and
               all(type(path) is str for path in fields), 'MECHANISM_SELECTORS')
    plans.need(len(set(fields)) == len(fields), 'MECHANISM_SELECTORS')
    trie = {'terminal': False, 'children': {}}
    for path in fields:
        plans._path(path)
        node = trie
        for token in ([] if path == '' else path[1:].split('/')):
            token = token.replace('~1', '/').replace('~0', '~')
            node = node['children'].setdefault(token, {'terminal': False, 'children': {}})
        node['terminal'] = True
    return trie


def _projection(source, node):
    if node['terminal']:
        # A selected parent includes its whole subtree. Its bounds, including
        # every child, will be checked by the unchanged commitment profile.
        return deepcopy(source)
    children = node['children']
    if not children:
        return {}
    if type(source) is dict:
        result = {}
        for token, branch in children.items():
            plans.need(token in source, 'MECHANISM_FIELD_MISSING')
            result[token] = _projection(source[token], branch)
        return result
    if type(source) is list:
        indexed = []
        for token, branch in children.items():
            plans.need(token == '0' or token.isascii() and token.isdecimal() and
                       not token.startswith('0'), 'MECHANISM_ARRAY_INDEX')
            index = int(token)
            plans.need(index < len(source), 'MECHANISM_FIELD_MISSING')
            plans.need(index < _ARRAY_ITEMS, 'SELECTED_INPUT_ARRAY_INDEX_LIMIT')
            indexed.append((index, branch))
        result = [None] * (max(index for index, _ in indexed) + 1)
        for index, branch in indexed:
            result[index] = _projection(source[index], branch)
        return result
    raise ValueError('MECHANISM_FIELD_MISSING')


def prepare_selected(id, target, value, fields, salts, context, **step_options):
    """Prepare the same field commitments from a bounded selective projection.

    JSON pointers retain their original paths. Selecting a parent and a child
    includes the complete parent while committing both requested selectors.
    The empty pointer selects the entire source and retains all frozen bounds.
    Empty fields are useful only with a separately valid WITHHELD step.
    """
    plans.need(set(step_options) <= _OPTIONS, 'SELECTED_INPUT_STEP_OPTIONS')
    selectors = _selectors(fields)
    # This is the broad agent input bound, not the narrower signed profile.
    # It validates types, exact integers, depth, node count and total bytes even
    # for excluded content, without invoking the frozen canonicalizer on it.
    validate_json({'id': id, 'target': target, 'value': value, 'fields': fields,
                   'salts': salts, 'context': context, 'options': step_options})
    projection = _projection(value, selectors)
    step = plans.prepare_step(id, target, projection, fields, salts, context,
                              **step_options)
    return {'step': step, 'value': projection, 'selected_paths': deepcopy(fields),
            'scope': SCOPE, 'execution_authorized': False}
