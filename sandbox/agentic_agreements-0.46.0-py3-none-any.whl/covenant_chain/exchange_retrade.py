"""Fairness at close for urn:aap:exchange:0.1: retrades, re-acceptance, declines and notices.

A retrade is a final agreement whose terms differ from the firm offer in a way
that is worse for the requester. Each changed term is compared field by field and
through the vertical's exact metrics; a change with no known direction counts as
against the requester. Closing on such terms needs the requester's signed
re-acceptance of the exact change, and the close is recorded as CLOSED_RETRADED
against the offeror. Changes only in the requester's favour close as
CLOSED_IMPROVED. A refused retrade goes to the request's declared dispute route.

Decline notices turn an offeror's signed structured reasons into an
adverse-action style notice (12 CFR 1002.9(a)(3) and (b)(2) shape); award
notices tell unsuccessful offerors their rank and what dossier data they must
delete. Both are records, not legal advice and not delivery of a notice.
"""
from copy import deepcopy
import re

from . import exchange_close as close
from . import exchange_profile as profile
from .crypto import digest
from .exchange_profile import ExchangeError, need, teaching

DIFF_LABEL = 'AAP-EXCHANGE-RETRADE-DIFF-0.1'
MAX_CHANGES = 64
REASON_TEXT = {
    'AMOUNT_OUT_OF_RANGE': 'The amount requested is outside what this lender offers.',
    'CASH_FLOW_INSUFFICIENT': 'Business cash flow is not sufficient for the requested payments.',
    'COLLATERAL_INSUFFICIENT': 'The collateral offered is not sufficient.',
    'CREDIT_HISTORY': 'Credit history of the business or guarantor does not meet the requirement.',
    'DEBT_LEVEL': 'Existing debt obligations are too high relative to income.',
    'INCOMPLETE_APPLICATION': 'The application was incomplete.',
    'INDUSTRY_EXCLUDED': 'The lender does not finance this industry.',
    'LENDER_CAPACITY': 'The lender has no capacity for this request now.',
    'OTHER_SPECIFIC': 'Another specific reason, stated in the referenced detail document.',
    'TIME_IN_BUSINESS': 'Time in business is shorter than required.',
    'VERIFICATION_FAILED': 'Information in the application could not be verified.',
    'BUDGET_TOO_LOW': 'The budget is below the cost of the work.',
    'DEADLINE_INFEASIBLE': 'The deadline cannot be met.',
    'OUTSIDE_EXPERTISE': 'The work is outside this provider\'s expertise.',
    'PROVIDER_CAPACITY': 'The provider has no capacity for this work now.',
    'SCOPE_UNCLEAR': 'The scope is not specific enough to quote.',
}


def _flatten(value, path=''):
    if type(value) is dict:
        out = {}
        for name in sorted(value):
            out.update(_flatten(value[name], path + '/' + name))
        return out
    if type(value) is list:
        out = {path + '/#': len(value)}
        for index, item in enumerate(value):
            out.update(_flatten(item, path + '/' + str(index)))
        return out
    return {path: value}


@teaching
def diff(pack, want, offered, final):
    """Field and metric changes from the firm offer to the final terms, each with its direction for the requester."""
    profile.validate_terms(pack, offered)
    profile.validate_terms(pack, final)
    before, after = _flatten(offered), _flatten(final)
    changes = []
    for path in sorted(set(before) | set(after)):
        if before.get(path, None) != after.get(path, None) or (path in before) != (path in after):
            changes.append({'path': path, 'offered': before.get(path), 'final': after.get(path), 'direction': 'UNKNOWN'})
    old = profile.normalise(pack, want, offered)['metrics']
    new = profile.normalise(pack, want, final)['metrics']
    metrics = []
    for name in sorted(old):
        if old[name] == new[name]:
            continue
        declared = pack['metrics'][name]['direction']
        if declared == 'UNKNOWN':
            direction = 'AGAINST_REQUESTER'
        elif (new[name] < old[name]) == (declared == 'LOWER'):
            direction = 'FOR_REQUESTER'
        else:
            direction = 'AGAINST_REQUESTER'
        metrics.append({'metric': name, 'offered': old[name], 'final': new[name], 'direction': direction})
    need(len(changes) <= MAX_CHANGES, 'EXCHANGE_SIZE')
    if not changes:
        outcome = 'NONE'
    elif metrics and all(row['direction'] == 'FOR_REQUESTER' for row in metrics) and _covered(changes, pack):
        outcome = 'IMPROVED'
    else:
        # A changed term that no metric explains has no known direction; it counts against the requester.
        outcome = 'RETRADED'
    core = {'offered': offered, 'final': final, 'changes': changes, 'metrics': metrics, 'outcome': outcome}
    return {'outcome': outcome, 'changes': changes, 'metrics': metrics, 'id': digest(DIFF_LABEL, core),
            'rule': 'ANY_CHANGE_WITHOUT_A_KNOWN_FAVOURABLE_DIRECTION_NEEDS_REQUESTER_RE_ACCEPTANCE'}


def _covered(changes, pack):
    """A field change is explained only when it is a numeric field the metrics read directly."""
    if pack['normaliser'] == profile.credit.NORMALISER:
        explained = {'/principal', '/rate/bps', '/rate/margin_bps', '/rate/index_bps', '/term_months'}
        explained |= {row['path'] for row in changes if re.fullmatch(r'/fees/[0-9]+/amount', row['path'])}
        return all(row['path'] in explained and row['path'] != '/term_months' for row in changes)
    fields = {'/' + row['field'] for row in pack['metrics'].values() if row['direction'] != 'UNKNOWN'}
    return all(row['path'] in fields for row in changes)


def final_terms(application):
    """The terms the parties finally signed: an award application (or its signed successor)."""
    return close.award_terms(application)['offer_terms']


@teaching
def reacceptance(award, final_application, change, created_at):
    """What the requester signs to accept a worse change explicitly; nothing else converts a retrade into a close."""
    terms = close.award_terms(award['application'])
    profile._hash(final_application)
    profile._hash(change['id'])
    body = {'version': profile.PROFILE, 'kind': 'REACCEPT', 'request': terms['request'], 'offer': terms['offer'],
            'award': terms['application'], 'final': final_application, 'change': change['id'],
            'requester': terms['parties']['requester'], 'created_at': created_at}
    _reaccept_body(body)
    return {'label': profile.LABELS['REACCEPT'], 'body': body, 'id': profile.record_id('REACCEPT', body),
            'required_signer': body['requester'], **profile.FLAGS}


def _reaccept_body(body):
    profile._exact(body, 'version kind request offer award final change requester created_at', 'EXCHANGE_REACCEPTANCE')
    for name in ('request', 'offer', 'award', 'final', 'change'):
        profile._hash(body[name], 'EXCHANGE_REACCEPTANCE')
    profile._key(body['requester'])
    profile._int(body['created_at'])


@teaching
def classify(pack, award, final_application, *, reacceptance_record=None):
    """CLOSED_ON_OFFERED_TERMS, CLOSED_IMPROVED or CLOSED_RETRADED, with the re-acceptance a retrade needs."""
    terms = close.award_terms(award['application'])
    final = close.award_terms(final_application)
    need(final['request'] == terms['request'] and final['offer'] == terms['offer']
         and final['parties'] == terms['parties'], 'EXCHANGE_CLOSE')
    change = diff(pack, terms['want'], terms['offer_terms'], final['offer_terms'])
    if change['outcome'] == 'NONE':
        need(final['amount'] == terms['amount'], 'EXCHANGE_CLOSE')
        return {'outcome': 'CLOSED_ON_OFFERED_TERMS', 'retrade': None, 'reacceptance': None, 'change': change}
    if change['outcome'] == 'IMPROVED':
        return {'outcome': 'CLOSED_IMPROVED', 'retrade': change['id'], 'reacceptance': None, 'change': change}
    need(reacceptance_record is not None, 'EXCHANGE_RETRADE_UNACCEPTED')
    body, ref = profile._signed('REACCEPT', reacceptance_record, 'requester')
    _reaccept_body(body)
    need(body['award'] == terms['application'] and body['final'] == final['application'] and body['change'] == change['id']
         and body['requester'] == terms['parties']['requester'], 'EXCHANGE_REACCEPTANCE')
    return {'outcome': 'CLOSED_RETRADED', 'retrade': change['id'], 'reacceptance': ref, 'change': change}


@teaching
def decline_notice(request_envelope, decline_envelope, *, packs=()):
    """Adverse-action style notice data from the offeror's signed reasons. Not legal advice; not delivered."""
    checked = profile.verify_request(request_envelope, packs=packs)
    body, _ = profile.verify_decline(decline_envelope, checked['body'], checked['id'], packs)
    return {'applicant': checked['body']['principal'], 'decided_by': body['offeror'], 'request': checked['id'],
            'action': 'DECLINED', 'decided_at': body['created_at'],
            'principal_reasons': [{'code': code, 'text': REASON_TEXT.get(code, code)} for code in body['reasons']],
            'detail_sha256': body['detail_sha256'],
            'shape': 'specific principal reasons (12 CFR 1002.9(b)(2)); business-credit timing depends on gross revenue '
                     '(12 CFR 1002.9(a)(3))',
            'legal_advice': False, 'delivered': False, **profile.FLAGS}


@teaching
def award_notice(comparison, offer_ref, offeror, created_at, *, consents=(), requester):
    """NOT_SELECTED notice for one unsuccessful offeror: its own rank and score only, and what to delete."""
    core = profile.comparison_core(comparison)
    profile._hash(offer_ref)
    profile._key(offeror)
    profile._key(requester)
    ranked = {row[0]: row for row in core['ranked']}
    excluded = {row[0]: row[1] for row in core['excluded']}
    need(offer_ref in ranked or offer_ref in excluded, 'EXCHANGE_NOTICE')
    need(type(consents) in (list, tuple) and len(consents) <= 16, 'EXCHANGE_NOTICE')
    deletion = []
    for record in consents:
        terms, ref = profile.dossier.verify_consent(record)
        need(terms['recipient'] == offeror and terms['request'] == core['request'], 'EXCHANGE_NOTICE')
        deletion.append({'consent': ref, 'fields': terms['fields'], 'delete_after': terms['retention_until']})
    position = ranked[offer_ref][1] if offer_ref in ranked else None
    body = {'version': profile.PROFILE, 'kind': 'NOTICE', 'request': core['request'], 'comparison': comparison['id'],
            'rule': core['rule'], 'offer': offer_ref, 'offeror': offeror, 'requester': requester, 'outcome': 'NOT_SELECTED',
            'rank': position, 'excluded_reasons': deepcopy(excluded.get(offer_ref, [])),
            'consents': sorted(deletion, key=lambda row: row['consent']), 'created_at': created_at}
    profile._int(created_at)
    profile.record_id('NOTICE', body)
    return {'label': profile.LABELS['NOTICE'], 'body': body, 'id': profile.record_id('NOTICE', body),
            'required_signer': requester, 'delete_after': max([row['delete_after'] for row in deletion], default=None),
            'retention': 'RECIPIENT_PROMISE_UNDER_CONSENT_NOT_ENFORCED_BY_CODE', **profile.FLAGS}


def dispute_route(application):
    """The procedure the request declared; a refused retrade goes there. No new dispute machinery is invented."""
    terms = close.award_terms(application)
    return {'procedure': terms['dispute']['procedure'], 'resolver': terms['dispute']['resolver'],
            'appeal': terms['dispute']['appeal'], 'ladder': 'docs/ARBITRATION_INTEROP.html',
            'opened': False, **profile.FLAGS}


def describe():
    return {'version': profile.PROFILE, 'outcomes': ['CLOSED_ON_OFFERED_TERMS', 'CLOSED_IMPROVED', 'CLOSED_RETRADED'],
            'unknown_direction': 'AGAINST_REQUESTER', 'reasons': sorted(REASON_TEXT), 'legal_advice': False, **profile.FLAGS}
