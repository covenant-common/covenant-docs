"""One private preparation packet for a plain-language working agreement.

This application helper composes existing mechanism plans without changing their
wire meaning. Whole terms are committed in a WITHHELD step. The packet contains
private terms and opening salts: it is not an encrypted delivery or a public
export. No signing, account connection, payment, escrow or publication occurs.

prepare/revise return {packet, review, execution_authorized}. Pass the contained
packet to review/revise. Job sections are explicit; arbitrary agreed concepts
can be carried in extensions. Owner readiness is a separate injected argument,
never a term that an agent can use to declare itself connected or authorized.
"""
from copy import deepcopy
import base64
import hashlib
import os
import re

from covenant_language import mechanism_plans as p
from .crypto import verification_key, verify

VERSION = 'covenant-human-agreement/0.1'
JOB_FIELDS = ('title', 'scope', 'deliverables', 'acceptance_checks', 'price',
              'payment', 'schedule', 'revisions', 'identity', 'privacy', 'dispute', 'extensions')
SECTIONS = {
    'payment': ('service', 'adapter', 'release_rule', 'escrow'),
    'schedule': ('delivery_deadline', 'review_window_hours', 'correction_window_hours', 'dispute_window_hours'),
    'revisions': ('included',),
    'identity': ('mode', 'provider', 'subject', 'requirements'),
    'privacy': ('readers', 'publication', 'recording', 'public_fields'),
    'dispute': ('required', 'reviewer', 'procedure'),
}
PRECISION = {'GBP': 2, 'USD': 2, 'EUR': 2, 'JPY': 0}


def need(ok, code):
    if not ok:
        raise ValueError(code)


def fields(value, names, *, partial=False):
    need(type(value) is dict and (set(value) <= set(names) if partial else set(value) == set(names)),
         'HUMAN_AGREEMENT_FIELDS')


def text(value, limit=4096, *, empty=False, nullable=False):
    if value is None and nullable:
        return
    need(type(value) is str and (empty or bool(value.strip())) and len(value.encode('utf-8')) <= limit,
         'HUMAN_AGREEMENT_TEXT')


def integer(value, *, nullable=False):
    if value is None and nullable:
        return
    need(type(value) is int and 0 <= value <= 2**53-1, 'HUMAN_AGREEMENT_INTEGER')


def same(left, right):
    return p.canonical(left) == p.canonical(right)


def _parties(parties):
    need(type(parties) is dict and 2 <= len(parties) <= 8, 'HUMAN_AGREEMENT_PARTIES')
    for role, controller in parties.items():
        text(role, 80)
        verification_key(controller)
    controllers = {p.canonical(value): value for value in parties.values()}
    need(len(controllers) >= 2, 'HUMAN_AGREEMENT_DISTINCT_PARTIES')
    return [deepcopy(controllers[key]) for key in sorted(controllers)]


def _base(parties, template):
    base = {
        'title': 'Working agreement', 'scope': '', 'deliverables': [], 'acceptance_checks': [],
        'price': None,
        'payment': {'service': None, 'adapter': None, 'release_rule': None, 'escrow': 'NOT_REQUESTED'},
        'schedule': {'delivery_deadline': None, 'review_window_hours': None,
                     'correction_window_hours': None, 'dispute_window_hours': None},
        'revisions': {'included': None},
        'identity': {'mode': 'NOT_REQUESTED', 'provider': None, 'subject': None, 'requirements': {}},
        'privacy': {'readers': sorted(parties), 'publication': 'NONE', 'recording': 'NONE', 'public_fields': []},
        'dispute': {'required': False, 'reviewer': None, 'procedure': None}, 'extensions': {},
    }
    need(template in (None, 'checkout_repair'), 'HUMAN_AGREEMENT_TEMPLATE')
    if template == 'checkout_repair':
        need({'client', 'freelancer'} <= set(parties), 'HUMAN_CHECKOUT_REQUIRES_CLIENT_AND_FREELANCER_ROLES')
        base.update(title='Checkout repair', scope='Repair checkout on staging using dummy orders only.',
            deliverables=['A reviewed checkout fix and a short test-results note.'],
            acceptance_checks=[
                'A successful dummy payment creates exactly one paid order and one receipt.',
                'A declined dummy payment never marks an order as paid.',
                'Repeating submit creates no duplicate order or charge in the chosen payment sandbox.'],
            price={'amount_minor': 30000, 'currency': 'GBP', 'minor_unit_digits': 2})
        base['payment']['release_rule'] = 'CLIENT_EXPLICIT_ACCEPTANCE_AFTER_AGREED_CHECKS'
        base['schedule'].update(review_window_hours=48, correction_window_hours=48, dispute_window_hours=72)
        base['revisions']['included'] = 1
        base['identity']['mode'] = 'ACCOUNT_CONTROL'
        base['dispute']['required'] = True
        base['extensions'] = {
            'data_access': 'Use dummy customer data and least-privilege staging access; no customer export or home address.',
            'window_meaning': 'Review starts on delivery notification; correction starts on a specific failure notice; dispute starts after an unresolved correction. Hours are elapsed hours. Silence never releases payment.'}
    return base


def _merge(base, changes):
    result = deepcopy(base)
    for name, value in changes.items():
        if type(value) is dict and type(result.get(name)) is dict:
            result[name] = _merge(result[name], value)
        else:
            result[name] = deepcopy(value)
    return result


def _defaults(base, supplied, prefix=''):
    rows = []
    for name, value in sorted(base.items()):
        path = prefix + name
        if name not in supplied:
            if value is not None and value not in ('', [], {}):
                rows.append({'field': path, 'value': deepcopy(value), 'status': 'PROPOSED_DEFAULT_REVIEW_BEFORE_ASSENT'})
        elif type(value) is dict and type(supplied[name]) is dict:
            rows.extend(_defaults(value, supplied[name], path+'.'))
    return rows


def _job(job, *, partial=False):
    fields(job, JOB_FIELDS, partial=partial)
    for name, value in job.items():
        if name in SECTIONS:
            fields(value, SECTIONS[name], partial=partial)
    if partial:
        if 'price' in job:
            need(job['price'] is None or type(job['price']) in (dict, str), 'HUMAN_PRICE_USE_EXACT_TEXT_OR_MINOR_UNIT_OBJECT')
        p.canonical(job)
        return
    text(job['title'], 256);text(job['scope'], empty=True)
    for name in ('deliverables', 'acceptance_checks'):
        need(type(job[name]) is list and len(job[name]) <= 32, 'HUMAN_AGREEMENT_LIST')
        for item in job[name]:
            text(item)
    price = job['price']
    if price is not None:
        fields(price, ('amount_minor', 'currency', 'minor_unit_digits'))
        integer(price['amount_minor']);text(price['currency'], 32)
        need(bool(re.fullmatch(r'[A-Z][A-Z0-9_]{0,31}', price['currency'])), 'HUMAN_AGREEMENT_CURRENCY')
        integer(price['minor_unit_digits']);need(price['minor_unit_digits'] <= 18, 'HUMAN_CURRENCY_PRECISION')
        need(price['currency'] not in PRECISION or price['minor_unit_digits'] == PRECISION[price['currency']],
             'HUMAN_CURRENCY_PRECISION')
    payment = job['payment']
    text(payment['service'], 256, nullable=True);text(payment['release_rule'], 1024, nullable=True)
    need(payment['escrow'] in ('NOT_REQUESTED', 'REQUESTED'), 'HUMAN_ESCROW_CHOICE')
    if payment['adapter'] is not None:
        p.ref(payment['adapter'])
    schedule = job['schedule']
    text(schedule['delivery_deadline'], 256, nullable=True)
    for name in ('review_window_hours', 'correction_window_hours', 'dispute_window_hours'):
        integer(schedule[name], nullable=True)
    integer(job['revisions']['included'], nullable=True)
    identity = job['identity'];text(identity['mode'], 128)
    if identity['provider'] is not None:
        p.ref(identity['provider'])
    need(type(identity['requirements']) is dict and len(identity['requirements']) <= 32,
         'HUMAN_IDENTITY_REQUIREMENTS')
    privacy = job['privacy']
    need(type(privacy['readers']) is list and 1 <= len(privacy['readers']) <= 16, 'HUMAN_PRIVACY_READERS')
    for reader in privacy['readers']:
        text(reader, 256)
    need(len(set(privacy['readers'])) == len(privacy['readers']), 'HUMAN_PRIVACY_READERS')
    need(privacy['publication'] in ('NONE', 'SELECTED', 'FULL') and privacy['recording'] in
         ('NONE', 'LOCAL_PRIVATE', 'PRIVATE_ENCRYPTED', 'PUBLIC_SELECTED', 'PUBLIC_FULL'), 'HUMAN_PRIVACY_CHOICE')
    need(type(privacy['public_fields']) is list and len(privacy['public_fields']) <= 32, 'HUMAN_PUBLIC_FIELDS')
    for item in privacy['public_fields']:
        text(item, 256)
    dispute = job['dispute']
    need(type(dispute['required']) is bool, 'HUMAN_DISPUTE_REQUIRED')
    if dispute['procedure'] is not None:
        p.ref(dispute['procedure'])
    need(type(job['extensions']) is dict, 'HUMAN_AGREEMENT_EXTENSIONS')
    p.canonical(job)


def _price_input(value):
    if value is None:return None
    if type(value) is dict:
        fields(value, ('amount_minor', 'currency', 'minor_unit_digits'), partial=True)
        if 'currency' in value:
            text(value['currency'], 32)
            need(bool(re.fullmatch(r'[A-Z][A-Z0-9_]{0,31}', value['currency'])), 'HUMAN_AGREEMENT_CURRENCY')
        for name in ('amount_minor', 'minor_unit_digits'):
            if name in value:integer(value[name])
        return deepcopy(value)
    need(type(value) is str and len(value) <= 80, 'HUMAN_PRICE_USE_EXACT_TEXT_OR_MINOR_UNIT_OBJECT')
    match = re.fullmatch(r'(?:(GBP|USD|EUR|JPY)\s*|([£€]))([0-9]+)(?:\.([0-9]+))?', value.strip())
    need(match is not None, 'HUMAN_PRICE_EXACT_TEXT_EXPECTED_NO_AMBIGUOUS_SYMBOL_OR_EXPONENT')
    code, symbol, whole, fraction = match.groups();code = code or {'£': 'GBP', '€': 'EUR'}[symbol]
    digits = PRECISION[code];fraction = fraction or ''
    need(len(fraction) <= digits, 'HUMAN_PRICE_TOO_MANY_DECIMAL_PLACES')
    amount = int(whole)*(10**digits)+(int(fraction.ljust(digits, '0')) if fraction else 0)
    integer(amount)
    return {'amount_minor': amount, 'currency': code, 'minor_unit_digits': digits}


def _packet(terms, context, target, plan=None):
    controllers = _parties(terms['parties'])
    salt = base64.b64encode(os.urandom(32)).decode('ascii')
    step = p.prepare_step('agreement', target, terms, [''], {'': salt}, context, visibility='WITHHELD')
    if plan is None:
        prepared = p.plan(context, target, controllers, [step], purpose='Exact working terms; no sharing or effects')
    else:
        prepared = p.amend(plan, {'steps': [step]})
    return {'version': VERSION, 'terms': deepcopy(terms), 'context': context,
            'target': deepcopy(target), 'plan': prepared['plan'], 'id': prepared['id'],
            'salts': {'': salt}, 'assent_payload': p.assent_payload(prepared['plan'])}


def validate(packet):
    fields(packet, ('version', 'terms', 'context', 'target', 'plan', 'id', 'salts', 'assent_payload'))
    need(packet['version'] == VERSION, 'HUMAN_AGREEMENT_VERSION');p.canonical(packet)
    terms = packet['terms'];fields(terms, ('parties', 'job', 'template', 'proposed_defaults'))
    controllers = _parties(terms['parties']);_job(terms['job'])
    need(terms['template'] in (None, 'checkout_repair'), 'HUMAN_AGREEMENT_TEMPLATE')
    need(type(terms['proposed_defaults']) is list and len(terms['proposed_defaults']) <= 128,
         'HUMAN_PROPOSED_DEFAULTS')
    for row in terms['proposed_defaults']:
        fields(row, ('field', 'value', 'status'));text(row['field'], 256)
        need(row['status'] == 'PROPOSED_DEFAULT_REVIEW_BEFORE_ASSENT', 'HUMAN_PROPOSED_DEFAULTS')
    p.validate(packet['plan']);plan = packet['plan'];p.ref(packet['context']);p.q.reference(packet['target'])
    need(plan['context'] == packet['context'] and same(plan['subject'], packet['target'])
         and same(plan['controllers'], controllers) and packet['id'] == p.identifier(plan), 'HUMAN_AGREEMENT_PLAN')
    need(len(plan['steps']) == 1, 'HUMAN_AGREEMENT_STEP')
    step = plan['steps'][0]
    need(step['id'] == 'agreement' and same(step['target'], packet['target']) and step['fields'] == ['']
         and step['visibility'] == 'WITHHELD' and not step['mechanisms'] and not step['gates']
         and not step['depends_on'], 'HUMAN_AGREEMENT_STEP')
    fields(packet['salts'], ('',))
    pins = p.commit_fields(terms, [''], packet['salts'], packet['context'], 'agreement')['commitments']
    need(same(pins, step['commitments']) and same(packet['assent_payload'], p.assent_payload(plan)),
         'HUMAN_AGREEMENT_TERMS_OR_SIGNING_PAYLOAD')
    return True


def prepare(parties, job, context=None, target=None, template=None):
    _parties(parties);_job(job, partial=True)
    supplied = deepcopy(job)
    if 'price' in supplied:supplied['price'] = _price_input(supplied['price'])
    base = _base(parties, template);normalized = _merge(base, supplied)
    if type(supplied.get('dispute')) is dict and 'required' not in supplied['dispute'] and any(
            supplied['dispute'].get(name) is not None for name in ('reviewer', 'procedure')):
        normalized['dispute']['required'] = True
    price_supplied = supplied.get('price')
    if normalized['price'] is not None and ('minor_unit_digits' not in normalized['price'] or
            type(price_supplied) is dict and 'currency' in price_supplied and 'minor_unit_digits' not in price_supplied):
        currency = normalized['price'].get('currency')
        need(currency in PRECISION, 'HUMAN_CURRENCY_PRECISION_REQUIRED')
        normalized['price']['minor_unit_digits'] = PRECISION[currency]
    _job(normalized)
    context = os.urandom(32).hex() if context is None else context;p.ref(context)
    target = {'kind': 'human-agreement', 'id': hashlib.sha256(b'COVENANT-HUMAN-AGREEMENT-SUBJECT-0.1\0'+
        p.canonical({'context': context, 'parties': parties})).hexdigest()} if target is None else deepcopy(target)
    p.q.reference(target)
    terms = {'parties': deepcopy(parties), 'job': normalized, 'template': template,
             'proposed_defaults': _defaults(normalized, supplied)}
    packet = _packet(terms, context, target)
    return {'packet': packet, 'review': review(packet), 'execution_authorized': False}


def _assents(packet, approvals):
    need(type(approvals) is list and len(approvals) <= 32, 'HUMAN_AGREEMENT_APPROVALS')
    required = {p.canonical(key): key for key in packet['plan']['controllers']}
    valid = set();seen = set();issues = []
    for index, approval in enumerate(approvals):
        try:
            fields(approval, ('controller', 'signature'));encoded = p.canonical(approval['controller'])
            need(encoded in required, 'UNRECOGNIZED_CONTROLLER')
            need(encoded not in seen, 'DUPLICATE_ASSENT');seen.add(encoded)
            verify(approval['controller'], packet['assent_payload']['label'],
                   packet['assent_payload']['body'], approval['signature'])
            valid.add(encoded)
        except Exception as error:
            code = str(error) if str(error) in ('UNRECOGNIZED_CONTROLLER', 'DUPLICATE_ASSENT') else 'INVALID_OR_MALFORMED_ASSENT'
            issues.append({'index': index, 'code': code})
    complete = valid == set(required) and not issues
    state = ('JOINTLY_ACCEPTED_EXACT_TERMS' if complete else 'INVALID_ASSENT_SET' if issues else
             'DRAFT' if not valid else 'ONE_SIDED_ASSENT' if len(valid) == 1 else 'PARTIAL_ASSENTS')
    return {'status': state, 'complete': complete, 'valid_count': len(valid),
            'required_count': len(required), 'issues': issues,
            'roles': [{'role': role, 'status': 'SIGNED' if p.canonical(controller) in valid else 'NEEDS_ASSENT'}
                      for role, controller in sorted(packet['terms']['parties'].items())],
            'missing_controllers': [required[key] for key in sorted(set(required)-valid)]}


def _owner(status):
    status = {} if status is None else status
    fields(status, ('payment_adapters', 'identity_providers', 'reviewer_acceptances'), partial=True)
    result = {**{'payment_adapters': {}, 'identity_providers': {}, 'reviewer_acceptances': []}, **deepcopy(status)}
    for category in ('payment_adapters', 'identity_providers'):
        need(type(result[category]) is dict and len(result[category]) <= 64, 'HUMAN_OWNER_STATUS')
        for ref, entry in result[category].items():
            p.ref(ref);fields(entry, ('name', 'capability', 'scope') if category == 'payment_adapters' else ('name', 'scope'))
            text(entry['name'], 256)
            if category == 'payment_adapters':
                text(entry['capability'], 128);need(entry['scope'] in ('OWNER_INSTALLED', 'LOCAL_DEMO_ONLY'), 'HUMAN_OWNER_STATUS')
            else:
                need(entry['scope'] == 'OFFLINE_VERIFIER_ONLY', 'HUMAN_OWNER_STATUS')
    need(type(result['reviewer_acceptances']) is list and len(result['reviewer_acceptances']) <= 64, 'HUMAN_OWNER_STATUS')
    for row in result['reviewer_acceptances']:
        fields(row, ('reviewer', 'procedure', 'context', 'evidence'))
        for name in ('procedure', 'context', 'evidence'):p.ref(row[name])
    p.canonical(result)
    return result


def _readiness(packet, owner_status):
    job = packet['terms']['job'];owner = _owner(owner_status);missing = [];optional_unknowns = []
    for path, value in [('scope', job['scope']), ('deliverables', job['deliverables']),
                        ('acceptance_checks', job['acceptance_checks']), ('price', job['price']),
                        ('schedule.delivery_deadline', job['schedule']['delivery_deadline'])]:
        if value is None or value == '' or value == []:
            missing.append(path)
    for path, value in [('schedule.review_window_hours', job['schedule']['review_window_hours']),
                        ('schedule.correction_window_hours', job['schedule']['correction_window_hours']),
                        ('schedule.dispute_window_hours', job['schedule']['dispute_window_hours']),
                        ('revisions.included', job['revisions']['included'])]:
        if value is None:
            required = (job['dispute']['required'] if path == 'schedule.dispute_window_hours'
                        else packet['terms']['template'] == 'checkout_repair')
            if required:missing.append(path)
            else:optional_unknowns.append({'field': path, 'status': 'OPTIONAL_NOT_SPECIFIED'})
    if job['price'] is not None and job['price']['amount_minor'] > 0:
        for name in ('service', 'release_rule'):
            if job['payment'][name] is None:missing.append('payment.'+name)
    if job['dispute']['required']:
        for name in ('reviewer', 'procedure'):
            if job['dispute'][name] is None:missing.append('dispute.'+name)
    payment = job['payment'];adapter = owner['payment_adapters'].get(payment['adapter'])
    payment_status = ('NOT_CONNECTED' if adapter is None or adapter['capability'] not in ('payment.transfer', 'payment.escrow') else 'LOCAL_DEMO_ONLY'
                      if adapter['scope'] == 'LOCAL_DEMO_ONLY' else 'ADAPTER_INSTALLED_SEPARATE_APPROVAL_REQUIRED')
    if job['price'] is not None and job['price']['amount_minor'] == 0 and payment['service'] is None and payment['adapter'] is None and payment['escrow'] == 'NOT_REQUESTED':
        payment_status = 'NOT_REQUESTED'
    identity = job['identity'];provider = owner['identity_providers'].get(identity['provider'])
    agreed_modes = {'DECLARATION', 'MUTUAL_TRUST', 'AGREED_EVIDENCE'}
    external_modes = {'ACCOUNT_CONTROL', 'VERIFIED_EMAIL', 'OIDC', 'SIGNED_ATTESTATION'}
    identity_status = ('NOT_REQUESTED' if identity['mode'] == 'NOT_REQUESTED' else
        'AGREED_RULE_ONLY_NO_EXTERNAL_VERIFICATION' if identity['mode'] in agreed_modes else
        'OFFLINE_VERIFIER_ONLY' if provider is not None else
        'NOT_CONNECTED' if identity['mode'] in external_modes else 'CUSTOM_METHOD_ADOPTION_UNKNOWN')
    if identity['mode'] in external_modes:
        if identity['provider'] is None:missing.append('identity.provider')
        if identity['subject'] is None:missing.append('identity.subject')
    elif identity['mode'] not in agreed_modes|{'NOT_REQUESTED'} and provider is None and not identity['requirements']:
        missing.append('identity.agreed_rule_or_provider')
    privacy = job['privacy']
    if (privacy['publication'] == 'SELECTED' or privacy['recording'] == 'PUBLIC_SELECTED') and not privacy['public_fields']:
        missing.append('privacy.public_fields')
    reviewer = 'UNKNOWN' if job['dispute']['required'] else 'NOT_REQUESTED'
    for row in owner['reviewer_acceptances']:
        if job['dispute']['required'] and job['dispute']['reviewer'] is not None and row['context'] == packet['context'] and row['procedure'] == job['dispute']['procedure'] and same(row['reviewer'], job['dispute']['reviewer']):
            reviewer = 'ACCEPTANCE_REFERENCE_VERIFIED_BY_OWNER'
    return {'state': 'CHOICES_MISSING' if missing else 'TERMS_PREPARED_EFFECTS_REQUIRE_SEPARATE_APPROVAL',
        'missing_choices': sorted(set(missing)), 'optional_unknowns': optional_unknowns,
        'payment': {'status': payment_status,
            'requested_service': payment['service'], 'adapter': payment['adapter'],
            'installed_adapter_name': adapter['name'] if adapter is not None else None,
            'funds_or_currency_support': 'NOT_ESTABLISHED', 'escrow': 'NOT_ESTABLISHED',
            'release_authorized': False},
        'identity': {'status': identity_status, 'live_login_authorized': False, 'account_control_verified': False},
        'reviewer_acceptance': reviewer,
        'privacy': {'status': 'Kept in this private working packet; no sharing or recording yet.',
            'encryption': 'ENCRYPTION_NOT_CONFIGURED' if privacy['recording'] == 'PRIVATE_ENCRYPTED' else 'NOT_APPLIED_BY_THIS_HELPER',
            'requested_publication': privacy['publication'], 'requested_recording': privacy['recording'],
            'disclosure_action': 'SEPARATE_EXPLICIT_DISCLOSURE_REQUIRED', 'reader_labels_grant_access': False},
        'money_action_authorized': False, 'recorded': False, 'published': False}


def _diff(before, after, prefix=''):
    if same(before, after):return []
    if type(before) is dict and type(after) is dict:
        result = []
        for name in sorted(set(before)|set(after)):
            if name not in before or name not in after:
                result.append({'field': prefix+name, 'before': deepcopy(before.get(name)),
                    'after': deepcopy(after.get(name)), 'before_present': name in before, 'after_present': name in after})
            else:
                result.extend(_diff(before[name], after[name], prefix+name+'.'))
        return result
    return [{'field': prefix.rstrip('.'), 'before': deepcopy(before), 'after': deepcopy(after)}]


def review(packet, approvals=None, current_id=None, previous=None, owner_status=None):
    validate(packet);approvals = [] if approvals is None else approvals
    assents = _assents(packet, approvals);lineage = 'ROOT_AGREEMENT';changes = []
    supersedes = packet['plan']['supersedes'];prior_assents = None
    if previous is not None:
        validate(previous)
        need(supersedes == previous['id'] and packet['context'] == previous['context']
             and same(packet['target'], previous['target']) and same(packet['plan']['controllers'], previous['plan']['controllers'])
             and same(packet['terms']['parties'], previous['terms']['parties']),
             'HUMAN_AGREEMENT_PREDECESSOR')
        lineage = 'EXACT_PREDECESSOR_VERIFIED';changes = _diff(previous['terms']['job'], packet['terms']['job'])
        prior_assents = _assents(previous, approvals)
        if prior_assents['complete'] and assents['valid_count'] == 0:
            assents['status'] = 'DRAFT'
            assents['issues'] = [{'code': 'PREDECESSOR_ASSENTS_DO_NOT_AUTHORIZE_SUCCESSOR', 'count': len(approvals)}]
            assents['historical_predecessor_assents'] = True
    elif supersedes is not None:
        lineage = 'PREDECESSOR_REQUIRED'
    if current_id is not None:p.ref(current_id)
    active = False
    if current_id is None:
        current_status = 'CURRENT_REVISION_NOT_DETERMINED'
    elif current_id == packet['id']:
        active = assents['complete'] and lineage != 'PREDECESSOR_REQUIRED'
        current_status = ('CALLER_ADOPTED_CURRENT_REFERENCE_WITH_ASSENTS' if active else
                          'CURRENT_REFERENCE_REQUIRES_ASSENTS_AND_PREDECESSOR')
    elif previous is not None and current_id == previous['id']:
        current_status = 'OLD_REFERENCE_REMAINS_PROPOSED_SUCCESSOR_NOT_ADOPTED'
    else:
        current_status = 'CURRENT_REFERENCE_POINTS_TO_OTHER_REVISION'
    job = packet['terms']['job'];price = job['price']
    price_text = 'Price not chosen'
    if price is not None:
        digits = price['minor_unit_digits'];scale = 10**digits;whole, fraction = divmod(price['amount_minor'], scale)
        price_text = price['currency']+' '+str(whole)+(('.'+str(fraction).zfill(digits)) if digits else '')
    readiness = _readiness(packet, owner_status)
    assent_note = ('All required parties signed these exact terms; current revision selection is separate.'
        if assents['complete'] else 'These signatures belong to the predecessor; nobody has signed this successor.'
        if assents.get('historical_predecessor_assents') else
        str(assents['valid_count'])+' of '+str(assents['required_count'])+' required parties signed these exact terms.')
    return {'id': packet['id'], 'title': job['title'], 'summary': {
        'parties': deepcopy(packet['terms']['parties']),
        'price': price_text, 'work': job['scope'], 'deliverables': deepcopy(job['deliverables']),
        'acceptance_checks': deepcopy(job['acceptance_checks']), 'schedule': deepcopy(job['schedule']),
        'included_revisions': job['revisions']['included'], 'evidence_choice': deepcopy(job['identity']),
        'readers': deepcopy(job['privacy']['readers']), 'record_choice': job['privacy']['recording'],
        'payment_service': job['payment']['service'], 'reviewer': deepcopy(job['dispute']['reviewer']),
        'additional_terms': deepcopy(job['extensions']), 'exact_price': deepcopy(job['price']),
        'payment_terms': deepcopy(job['payment']), 'dispute_terms': deepcopy(job['dispute']),
        'privacy_terms': deepcopy(job['privacy'])},
        'summary_completeness': 'Compact review with additional terms shown verbatim. Review every field in packet.terms.job before assent; this summary does not replace the exact committed terms.',
        'proposed_defaults': deepcopy(packet['terms']['proposed_defaults']), 'assents': assents,
        'assent_note': assent_note,
        'currentness': {'status': current_status, 'reference': current_id,
            'reference_source': 'CALLER_SUPPLIED_REFERENCE_NOT_GLOBAL_CURRENT' if current_id else 'NOT_SUPPLIED',
            'packet_active_under_reference': active,
            'previous_assents_verified': prior_assents['complete'] if prior_assents else False},
        'lineage': lineage, 'changes': changes, 'readiness': readiness,
        'signing_payload': deepcopy(packet['assent_payload']),
        'next_action': ('Resolve missing choices and review every proposed default before signing.' if readiness['missing_choices'] else
                        'Review exact terms, obtain missing assents, and explicitly adopt the intended current revision.'),
        'private_packet_warning': 'Contains private terms and opening salts. Do not publish this packet. Private working custody is not encrypted network delivery.',
        'execution_authorized': False}


def revise(packet, changes):
    validate(packet);_job(changes, partial=True);need(bool(changes), 'HUMAN_AGREEMENT_NO_CHANGES')
    normalized = deepcopy(changes)
    if 'price' in normalized:normalized['price'] = _price_input(normalized['price'])
    if type(normalized.get('price')) is dict and 'currency' in normalized['price']:
        old_price = packet['terms']['job']['price']
        if old_price is not None and normalized['price']['currency'] != old_price['currency']:
            need({'amount_minor', 'minor_unit_digits'} <= set(normalized['price']),
                 'HUMAN_CURRENCY_CHANGE_REQUIRES_EXACT_AMOUNT_AND_PRECISION_NO_CONVERSION')
    if type(normalized.get('dispute')) is dict and 'required' not in normalized['dispute'] and any(
            normalized['dispute'].get(name) is not None for name in ('reviewer', 'procedure')):
        normalized['dispute']['required'] = True
    job = _merge(packet['terms']['job'], normalized);_job(job)
    need(not same(job, packet['terms']['job']), 'HUMAN_AGREEMENT_NO_CHANGES')
    terms = deepcopy(packet['terms']);terms['job'] = job
    changed_paths = [row['field'] for row in _diff(packet['terms']['job'], job)]
    terms['proposed_defaults'] = [row for row in terms['proposed_defaults'] if not any(
        row['field'] == name or row['field'].startswith(name+'.') or name.startswith(row['field']+'.') for name in changed_paths)]
    successor = _packet(terms, packet['context'], packet['target'], packet['plan'])
    return {'packet': successor, 'review': review(successor, previous=packet),
            'changes': _diff(packet['terms']['job'], job), 'fresh_assents_required': True,
            'execution_authorized': False}


def atr(packet, atr_id, binding, *, enabled=False, scope_fields=None):
    """LCP ATR of the validated packet's terms; scoped fields are dropped before any byte is written.

    Experimental and off unless ``enabled`` (host flag ``lcp_emit``). The terms
    slot holds the packet's canonical terms bytes. Not assent or authority.
    """
    validate(packet)
    from .lcp_emit import from_terms
    return from_terms(packet['terms'], atr_id, binding, enabled=enabled, scope_fields=scope_fields)
