"""Bounds on JSON-like values accepted from agents, tools and stored records.

A leaf module: core modules (workflow_store, conditions) can bound their inputs
without importing agent_tools, which would pull agent tooling into the native
reducer's import graph. ``agent_tools`` re-exports both names.
"""
import json

from .crypto import need

MAX_INPUT = 16_000_000


def validate_json(value):
    """Bound direct Python calls as well as the byte-stream interface."""
    pending = [(value, 0)]
    nodes = 0
    while pending:
        v, depth = pending.pop()
        nodes += 1
        need(nodes <= 500000 and depth <= 64, 'AGENT_COMPLEXITY_LIMIT')
        if v is None or type(v) is bool:
            continue
        if type(v) is int:
            need(abs(v) <= 2**53-1, 'AGENT_INTEGER_RANGE')
        elif type(v) is str:
            need(len(v.encode('utf-8')) <= 1000000, 'AGENT_STRING_LIMIT')
        elif type(v) is list:
            need(len(v) <= 100000, 'AGENT_ARRAY_LIMIT')
            pending.extend((x, depth+1) for x in v)
        elif type(v) is dict:
            need(len(v) <= 20000 and all(type(k) is str and len(k) <= 256 for k in v), 'AGENT_MAP')
            pending.extend((x, depth+1) for x in v.values())
        else:
            raise ValueError('AGENT_JSON_TYPE')
    need(len(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')) <= MAX_INPUT,
         'AGENT_INPUT_SIZE')

