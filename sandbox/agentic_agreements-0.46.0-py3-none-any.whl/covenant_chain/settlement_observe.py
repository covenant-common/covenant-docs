"""Solana and EVM settlement readers. Maturity: experimental.

Clean-room: no wienerlabs or covenantagents source and no vendored IDL. The
fixture decoders read the public status shapes a caller supplies and never
open a socket; their manifests say DECODED_FIXTURE_NOT_A_NODE, because the
shapes are fixtures, not real program IDLs. A refunded, disputed or still
locked settlement is not paid. Fewer confirmations than the reorg depth
(32 Solana slots, 12 EVM blocks) is UNKNOWN, never paid.

Live reads are separate owner code and stay off by default. A host turns one
side on by setting both an https RPC URL (COVENANT_SOLANA_DEVNET_RPC or
COVENANT_EVM_BASE_SEPOLIA_RPC) and an account (COVENANT_SOLANA_JOB_ACCOUNT or
COVENANT_EVM_JOB_ACCOUNT). CI never calls them and the test suite never does.
Each read goes through launch_security.local_opener (no redirects, no
environment proxies) with a timeout and a response byte cap, and asks Solana
for no account data. A read returns the facts the RPC reported and the host
name, never the URL, which may carry an API key. Lamport and wei balances are
decimal strings, since they can exceed the 2^53 integer profile. Without an
IDL decode the verdict stays UNKNOWN. No covenant_settlement tool action
performs a live read.
"""
import http.client
import json
import os
import urllib.error
import urllib.request
from urllib.parse import urlparse

from .crypto import integer, need
from .resource_observations import settlement_paid

RAIL_SOLANA = 'solana-observe'
RAIL_EVM = 'evm-observe'
SOLANA_REORG_SLOTS = 32
EVM_REORG_BLOCKS = 12
ENV_SOLANA_RPC = 'COVENANT_SOLANA_DEVNET_RPC'
ENV_EVM_RPC = 'COVENANT_EVM_BASE_SEPOLIA_RPC'
ENV_SOLANA_ACCOUNT = 'COVENANT_SOLANA_JOB_ACCOUNT'
ENV_EVM_ACCOUNT = 'COVENANT_EVM_JOB_ACCOUNT'
MAX_RPC_BYTES = 262144
MAX_TIMEOUT = 30
DEFAULT_TIMEOUT = 8
MAX_INTEGER = 2**53 - 1
USER_AGENT = 'covenant-settlement-reader/0.1'


def _confirmations(head, seen, depth):
    integer(head)
    integer(seen)
    integer(depth, True)
    confirmations = head - seen
    return confirmations, confirmations < depth


def decode_solana(view, depth=SOLANA_REORG_SLOTS):
    """A supplied Solana job-escrow view. Released and deep is paid; anything else is not."""
    need(type(view) is dict and view.get('kind') == 'job_escrow', 'SOLANA_JOB')
    status = view.get('status')
    need(type(status) is str and status in {'locked', 'released', 'refunded', 'disputed'}, 'SOLANA_STATUS')
    integer(view.get('amount'))
    need(type(view.get('mint')) is str and 1 <= len(view['mint']) <= 80, 'SOLANA_MINT')
    confirmations, shallow = _confirmations(view.get('head_slot'), view.get('slot'), depth)
    claim = {
        'kind': 'job_escrow',
        'rail': RAIL_SOLANA,
        'status': 'UNKNOWN' if shallow else status,
        'chain_status': status,
        'amount': view['amount'],
        'mint': view['mint'],
        'slot': view['slot'],
        'confirmations': confirmations,
        'reorg': shallow,
    }
    return {'claim': claim, 'verdict': settlement_paid(claim), 'assurance': 'DECODED_FIXTURE_NOT_A_NODE',
            'execution_authorized': False}


def decode_evm(view, depth=EVM_REORG_BLOCKS):
    """A supplied EVM Paid, Refunded or Disputed event. Only a deep Paid counts."""
    need(type(view) is dict, 'EVM_EVENT')
    event = view.get('event')
    mapped = {'Paid': 'paid', 'Refunded': 'refunded', 'Disputed': 'disputed'}
    need(type(event) is str and event in mapped, 'EVM_EVENT')
    integer(view.get('amount'))
    need(type(view.get('token')) is str and 1 <= len(view['token']) <= 80, 'EVM_TOKEN')
    confirmations, shallow = _confirmations(view.get('head_block'), view.get('block'), depth)
    claim = {
        'kind': 'evm_settlement',
        'rail': RAIL_EVM,
        'status': 'UNKNOWN' if shallow else mapped[event],
        'event': event,
        'amount': view['amount'],
        'token': view['token'],
        'block': view['block'],
        'confirmations': confirmations,
        'reorg': shallow,
    }
    return {'claim': claim, 'verdict': settlement_paid(claim), 'assurance': 'DECODED_FIXTURE_NOT_A_NODE',
            'execution_authorized': False}


class _ObserveOnly:
    """A reader on RailRegistry: execute is refused, read decodes a supplied fixture once enabled."""

    def __init__(self, rail, depth, decode, enabled=False):
        need(type(enabled) is bool, 'PLUGIN_FLAG')
        integer(depth, True)
        self.enabled = enabled
        self.decode = decode
        self.depth = depth
        self.manifest = {
            'version': 'covenant-settlement-rail/0.1',
            'rail': rail,
            'observe_only': True,
            'external_broadcast': False,
            'network': False,
            'reorg_depth': depth,
            'escrow': 'OPTIONAL',
            'maturity': 'experimental',
            'assurance': 'DECODED_FIXTURE_NOT_A_NODE',
        }

    def execute(self, effect_id, request):
        raise ValueError('OBSERVE_ONLY')

    def observe(self, effect_id):
        need(self.enabled, 'PLUGIN_DISABLED')
        return {'status': 'NOT_OBSERVED', 'output_hash': None, 'assurance': 'PASS_A_DECODED_FIXTURE_TO_READ',
                'execution_authorized': False}

    def read(self, view):
        need(self.enabled, 'PLUGIN_DISABLED')
        return self.decode(view, self.depth)


class SolanaObserveRail(_ObserveOnly):
    def __init__(self, enabled=False, depth=SOLANA_REORG_SLOTS):
        super().__init__(RAIL_SOLANA, depth, decode_solana, enabled)


class EvmObserveRail(_ObserveOnly):
    def __init__(self, enabled=False, depth=EVM_REORG_BLOCKS):
        super().__init__(RAIL_EVM, depth, decode_evm, enabled)


def install(registry, flags=None, *, solana=True, evm=True):
    """Register the readers the host enabled. A disabled flag refuses before anything registers."""
    need(flags is not None, 'PLUGIN_DISABLED')
    if solana:
        flags.require('solana_observe')
    if evm:
        flags.require('evm_observe')
    installed = {}
    if solana:
        installed['solana'] = registry.register(SolanaObserveRail(enabled=True))
    if evm:
        installed['evm'] = registry.register(EvmObserveRail(enabled=True))
    installed['execution_authorized'] = False
    return installed


def _https(url):
    need(len(url) <= 512 and url.isascii() and url.isprintable() and ' ' not in url, 'LIVE_RPC')
    parsed = urlparse(url)
    need(parsed.scheme == 'https' and bool(parsed.hostname) and parsed.username is None
         and parsed.password is None and not parsed.fragment, 'LIVE_RPC')
    return url


def _optional_https(value):
    if value is None:
        return None
    need(type(value) is str, 'LIVE_RPC')
    value = value.strip()
    return _https(value) if value else None


def _account(value, code, low, high):
    if value is None:
        return None
    need(type(value) is str, code)
    value = value.strip()
    if not value:
        return None
    need(low <= len(value) <= high and value.isascii() and value.isalnum(), code)
    return value


def _evm_account(value):
    value = _account(value, 'EVM_ACCOUNT', 42, 42)
    if value is None:
        return None
    need(value[:2] in ('0x', '0X') and all(c in '0123456789abcdefABCDEF' for c in value[2:]), 'EVM_ACCOUNT')
    return '0x' + value[2:].lower()


def live_endpoints(environ=None):
    """Public RPC configuration. An unset variable leaves its side off. Nothing is contacted."""
    env = os.environ if environ is None else environ
    solana = _optional_https(env.get(ENV_SOLANA_RPC))
    evm = _optional_https(env.get(ENV_EVM_RPC))
    solana_account = _account(env.get(ENV_SOLANA_ACCOUNT), 'SOLANA_ACCOUNT', 32, 44)
    evm_account = _evm_account(env.get(ENV_EVM_ACCOUNT))
    return {
        'solana': solana,
        'evm': evm,
        'solana_account': solana_account,
        'evm_account': evm_account,
        'enabled': bool((solana and solana_account) or (evm and evm_account)),
        'execution_authorized': False,
    }


def smoke_allowed(environ=None):
    """CI never calls a public RPC. Outside CI a host does only when a URL and an account are both set."""
    env = os.environ if environ is None else environ
    if str(env.get('CI', '')).lower() in {'1', 'true', 'yes'}:
        return False
    return live_endpoints(env)['enabled']


def _timeout(value):
    need(type(value) in (int, float) and 0 < value <= MAX_TIMEOUT, 'RPC_TIMEOUT')
    return value


def _opener(opener):
    if opener is None:
        from .launch_security import local_opener
        return local_opener()
    need(callable(getattr(opener, 'open', None)), 'RPC_OPENER')
    return opener


def _post_json(url, method, params, opener, timeout, max_bytes=MAX_RPC_BYTES):
    """One JSON-RPC POST: no redirect, no proxy, a timeout and at most ``max_bytes`` read."""
    payload = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}).encode('ascii')
    request = urllib.request.Request(url, data=payload, method='POST', headers={
        'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': USER_AGENT})
    try:
        response = opener.open(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        exc.close()
        raise ValueError('RPC_REDIRECT_REFUSED' if 300 <= exc.code < 400 else 'RPC_UNREACHABLE') from None
    except (OSError, ValueError, http.client.HTTPException):
        raise ValueError('RPC_UNREACHABLE') from None
    with response:
        need(getattr(response, 'status', 200) == 200, 'RPC_UNREACHABLE')
        try:
            raw = response.read(max_bytes + 1)
        except (OSError, http.client.HTTPException):
            raise ValueError('RPC_UNREACHABLE') from None
    need(len(raw) <= max_bytes, 'RPC_RESPONSE_LIMIT')

    def pairs(items):
        out = {}
        for name, value in items:
            need(name not in out, 'RPC_RESULT')
            out[name] = value
        return out

    try:
        parsed = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)
    except (UnicodeError, ValueError, RecursionError):
        raise ValueError('RPC_RESULT') from None
    need(type(parsed) is dict and 'error' not in parsed and 'result' in parsed, 'RPC_RESULT')
    return parsed['result']


def _host(url):
    return urlparse(url).hostname


def _unknown(kind, rail):
    return settlement_paid({'kind': kind, 'rail': rail, 'status': 'UNKNOWN', 'reorg': True})


def read_live_solana(account=None, *, environ=None, opener=None, timeout=DEFAULT_TIMEOUT):
    """Read one Solana account from the configured devnet RPC. Paid stays false without an IDL decode."""
    ends = live_endpoints(environ)
    url = ends['solana']
    account = _account(ends['solana_account'] if account is None else account, 'SOLANA_ACCOUNT', 32, 44)
    if not url or not account:
        raise ValueError('LIVE_DISABLED')
    timeout = _timeout(timeout)
    opener = _opener(opener)
    info = _post_json(url, 'getAccountInfo', [account, {
        'encoding': 'base64', 'commitment': 'finalized', 'dataSlice': {'offset': 0, 'length': 0}}], opener, timeout)
    head = _post_json(url, 'getSlot', [{'commitment': 'finalized'}], opener, timeout)
    need(type(info) is dict and type(info.get('context')) is dict, 'RPC_RESULT')
    need(type(head) is int and 0 <= head <= MAX_INTEGER, 'RPC_RESULT')
    slot = info['context'].get('slot')
    need(type(slot) is int and 0 <= slot <= MAX_INTEGER, 'RPC_RESULT')
    value = info.get('value')
    exists = value is not None
    lamports = owner = data_len = executable = None
    if exists:
        need(type(value) is dict, 'RPC_RESULT')
        lamports = value.get('lamports')
        need(type(lamports) is int and 0 <= lamports < 2**64, 'RPC_RESULT')
        lamports = str(lamports)
        owner = value.get('owner')
        need(type(owner) is str and 32 <= len(owner) <= 44 and owner.isascii() and owner.isalnum(), 'RPC_RESULT')
        space = value.get('space')
        data_len = space if type(space) is int and 0 <= space <= 10_000_000 else None
        executable = value.get('executable') is True
    return {
        'network': 'solana-devnet',
        'host': _host(url),
        'account': account,
        'exists': exists,
        'lamports': lamports,
        'owner': owner,
        'data_len': data_len,
        'executable': executable,
        'slot': slot,
        'head_slot': head,
        'decoded': None,
        'verdict': _unknown('job_escrow', RAIL_SOLANA),
        'assurance': 'PUBLIC_RPC_ACCOUNT_NOT_AN_IDL_DECODE',
        'execution_authorized': False,
    }


def _hex_int(value, bits):
    need(type(value) is str and value.startswith('0x') and 3 <= len(value) <= 2 + bits // 4, 'EVM_QUANTITY')
    try:
        parsed = int(value[2:], 16)
    except ValueError:
        raise ValueError('EVM_QUANTITY') from None
    need(parsed.bit_length() <= bits, 'EVM_QUANTITY')
    return parsed


def read_live_evm(account=None, *, environ=None, opener=None, timeout=DEFAULT_TIMEOUT):
    """Read one Base Sepolia account. Code and balance come from the RPC. Paid stays false."""
    ends = live_endpoints(environ)
    url = ends['evm']
    account = _evm_account(ends['evm_account'] if account is None else account)
    if not url or not account:
        raise ValueError('LIVE_DISABLED')
    timeout = _timeout(timeout)
    opener = _opener(opener)
    code = _post_json(url, 'eth_getCode', [account, 'latest'], opener, timeout)
    balance = _post_json(url, 'eth_getBalance', [account, 'latest'], opener, timeout)
    block = _post_json(url, 'eth_blockNumber', [], opener, timeout)
    need(type(code) is str and code.startswith('0x') and len(code) % 2 == 0
         and all(c in '0123456789abcdefABCDEF' for c in code[2:]), 'RPC_RESULT')
    code_bytes = (len(code) - 2) // 2
    wei = _hex_int(balance, 256)
    head = _hex_int(block, 64)
    need(head <= MAX_INTEGER, 'RPC_RESULT')
    return {
        'network': 'base-sepolia',
        'host': _host(url),
        'account': account,
        'exists': code_bytes > 0 or wei > 0,
        'code_bytes': code_bytes,
        'balance_wei': str(wei),
        'block': head,
        'head_block': head,
        'decoded': None,
        'verdict': _unknown('evm_settlement', RAIL_EVM),
        'assurance': 'PUBLIC_RPC_ACCOUNT_NOT_AN_IDL_DECODE',
        'execution_authorized': False,
    }


def read_live(*, environ=None, opener=None, timeout=DEFAULT_TIMEOUT):
    """Read each configured public account. An unconfigured side is left out."""
    ends = live_endpoints(environ)
    if not ends['enabled']:
        raise ValueError('LIVE_DISABLED')
    found = []
    if ends['solana'] and ends['solana_account']:
        found.append(read_live_solana(environ=environ, opener=opener, timeout=timeout))
    if ends['evm'] and ends['evm_account']:
        found.append(read_live_evm(environ=environ, opener=opener, timeout=timeout))
    return {'accounts': found, 'execution_authorized': False}
