"""Static level-dependency inventory and a baseline that can only shrink.

Experimental engineering tool. Parses source without importing scanned modules.
All direct, relative and nested imports count, including TYPE_CHECKING blocks.
Literal dynamic imports are resolved; nonliteral dynamic imports are visible
unknowns and separately ratcheted. This is not a runtime architecture proof.
ORGANON stands beside the numbered levels; it is not a level above or below.
"""
import argparse
import ast
from importlib.util import resolve_name
import json
from pathlib import Path

from .crypto import need

VERSION = 'covenant-level-dependencies/0.1'
PACKAGES = ('covenant_chain','covenant_agent','covenant_language','covenant_x402','covenantbench')
ORDER = {f'L{i}':i for i in range(5)}
MAX_SOURCE = 2_000_000


def _name(path):
    return path[:-len('/__init__.py')].replace('/','.') if path.endswith('/__init__.py') else path[:-3].replace('/','.')


def _relative(name, package):
    try:return resolve_name(name,package) if name.startswith('.') else name
    except (ImportError,ValueError):raise ValueError('LEVEL_IMPORT') from None


def _imports(tree, module, is_package, modules):
    package = module if is_package else module.rpartition('.')[0]
    edges, unknown = set(),set()
    nodes=list(ast.walk(tree))
    aliases={'__import__','import_module'}
    for imp in nodes:
        if isinstance(imp,ast.ImportFrom) and imp.module == 'importlib':
            aliases.update(alias.asname or alias.name for alias in imp.names if alias.name == 'import_module')
        elif isinstance(imp,(ast.Assign,ast.AnnAssign)):
            value=imp.value
            if isinstance(value,ast.Attribute) and value.attr in ('import_module','__import__'):
                targets=imp.targets if isinstance(imp,ast.Assign) else [imp.target]
                aliases.update(target.id for target in targets if isinstance(target,ast.Name))
    for node in nodes:
        if isinstance(node,ast.Import):
            for alias in node.names:
                if alias.name in modules:edges.add(alias.name)
        elif isinstance(node,ast.ImportFrom):
            base = _relative('.'*node.level+(node.module or ''),package)
            specific = set()
            for alias in node.names:
                target = base+'.'+alias.name
                if target in modules:specific.add(target)
                elif base in modules:specific.add(base)
            edges.update(specific)
        elif isinstance(node,ast.Call):
            function = node.func
            dynamic = (isinstance(function,ast.Name) and function.id in aliases or
                       isinstance(function,ast.Attribute) and function.attr in ('import_module','__import__'))
            if not dynamic:continue
            if not node.args or not isinstance(node.args[0],ast.Constant) or type(node.args[0].value) is not str:
                unknown.add(ast.dump(node,include_attributes=False));continue
            value = node.args[0].value
            pkg = package
            package_arg=node.args[1] if len(node.args)>1 else next((k.value for k in node.keywords if k.arg=='package'),None)
            if value.startswith('.') and package_arg is not None:
                if isinstance(package_arg,ast.Constant) and type(package_arg.value) is str:
                    pkg=package_arg.value
                elif not (isinstance(package_arg,ast.Name) and package_arg.id=='__package__'):
                    unknown.add(ast.dump(node,include_attributes=False));continue
            target = _relative(value,pkg)
            if target in modules:edges.add(target)
    return edges,unknown


def scan(root, *, classify=None, packages=PACKAGES):
    """Return every static internal import, upward edge and unresolved dynamic call."""
    root=Path(root).resolve()
    if classify is None:
        from .aap_levels import module_level
        classify=module_level
    files={}
    for package in packages:
        for path in sorted((root/package).rglob('*.py')):
            relative=path.relative_to(root).as_posix()
            files[_name(relative)]=relative
    levels={module:classify(path) for module,path in files.items()}
    unplaced=sorted(path for module,path in files.items() if levels[module] not in {*ORDER,'ORGANON'})
    imports,upward,unknown=[],[],[]
    for module,path in sorted(files.items()):
        raw=(root/path).read_bytes();need(len(raw)<=MAX_SOURCE,'LEVEL_SOURCE_SIZE')
        tree=ast.parse(raw,filename=path)
        edges,dynamic=_imports(tree,module,path.endswith('/__init__.py'),files)
        for target in sorted(edges):
            row={'source':module,'target':target,'source_level':levels[module],'target_level':levels[target]}
            imports.append(row)
            if row['source_level'] in ORDER and row['target_level'] in ORDER and ORDER[row['source_level']]<ORDER[row['target_level']]:
                upward.append(row)
        for call in sorted(dynamic):unknown.append({'source':module,'expression':call})
    return {'version':VERSION,'scope':'STATIC_IMPORT_RATCHET_NOT_RUNTIME_DEPENDENCY_PROOF',
            'modules':len(files),'imports':len(imports),'upward_count':len(upward),'upward_edges':upward,
            'unclassified_modules':unplaced,'unresolved_dynamic_imports':unknown,
            'unresolved_dynamic_count':len(unknown),'organon_rule':'INSTRUMENTS_STAND_BESIDE_ALL_LEVELS',
            'authority_changed':False}


def _edge(row):return row['source']+' -> '+row['target']

def _dynamic(row):return row['source']+' :: '+row['expression']


def baseline(snapshot):
    need(not snapshot['unclassified_modules'],'LEVEL_UNCLASSIFIED')
    return {'version':VERSION,'scope':snapshot['scope'],'upward_edges':snapshot['upward_edges'],
            'unresolved_dynamic_imports':snapshot['unresolved_dynamic_imports'],
            'maximum_allowed_upward_edges':snapshot['upward_count'],
            'maximum_allowed_unresolved_dynamic_imports':snapshot['unresolved_dynamic_count'],
            'rule':'Existing upward imports and unresolved dynamic calls are debt; neither set may grow.'}


def _baseline_sets(recorded):
    need(type(recorded) is dict and recorded.get('version')==VERSION,'LEVEL_BASELINE')
    old={_edge(row) for row in recorded['upward_edges']}
    dynamic={_dynamic(row) for row in recorded['unresolved_dynamic_imports']}
    need(type(recorded.get('maximum_allowed_upward_edges')) is int and
         recorded['maximum_allowed_upward_edges']==len(old)==len(recorded['upward_edges']) and
         type(recorded.get('maximum_allowed_unresolved_dynamic_imports')) is int and
         recorded['maximum_allowed_unresolved_dynamic_imports']==len(dynamic)==len(recorded['unresolved_dynamic_imports']),
         'LEVEL_BASELINE')
    return old,dynamic


def check(snapshot, recorded, *, previous=None):
    old,old_dynamic=_baseline_sets(recorded)
    current={_edge(row) for row in snapshot['upward_edges']}
    current_dynamic={_dynamic(row) for row in snapshot['unresolved_dynamic_imports']}
    new=sorted(current-old);removed=sorted(old-current)
    new_dynamic=sorted(current_dynamic-old_dynamic);removed_dynamic=sorted(old_dynamic-current_dynamic)
    baseline_growth=[];dynamic_growth=[]
    if previous is not None:
        before,before_dynamic=_baseline_sets(previous)
        baseline_growth=sorted(old-before);dynamic_growth=sorted(old_dynamic-before_dynamic)
    ok=not (new or removed or new_dynamic or removed_dynamic or snapshot['unclassified_modules'] or
            baseline_growth or dynamic_growth)
    return {'version':VERSION,'status':'PASS' if ok else 'FAIL','existing_upward_edges':len(current),
            'existing_unresolved_dynamic_calls':len(current_dynamic),'new_upward_edges':new,'removed_upward_edges':removed,
            'new_unresolved_dynamic_calls':new_dynamic,'removed_unresolved_dynamic_calls':removed_dynamic,
            'baseline_expansions':baseline_growth,'baseline_dynamic_expansions':dynamic_growth,
            'baseline_history':'COMPARED_TO_PREVIOUS' if previous is not None else 'NOT_CHECKED',
            'unclassified_modules':snapshot['unclassified_modules'],
            'note':'A passing ratchet preserves known architectural debt; it does not establish zero violations.'}


def previous_baseline(root,path,ref):
    """Read the baseline from one verified local Git commit, without checkout or mutation."""
    from covenant_language.safe_io import run_subprocess
    root=Path(root).resolve();path=Path(path).resolve()
    try:relative=path.relative_to(root).as_posix()
    except ValueError:raise ValueError('LEVEL_BASELINE_PATH') from None
    need(type(ref) is str and 0<len(ref)<=256,'LEVEL_BASE_REF')
    done=run_subprocess(['git','rev-parse','--verify','--end-of-options',ref+'^{commit}'],cwd=root,
                        max_output=128,max_error=4096,timeout=30)
    need(done.returncode==0 and len(done.stdout)<=128,'LEVEL_BASE_REF')
    try:commit=done.stdout.decode('ascii').strip()
    except UnicodeError:raise ValueError('LEVEL_BASE_REF') from None
    found=run_subprocess(['git','show',commit+':'+relative],cwd=root,max_output=MAX_SOURCE,max_error=4096,timeout=30)
    need(len(found.stdout)<=MAX_SOURCE,'LEVEL_BASELINE_SIZE')
    if found.returncode:
        # Distinguish a genuinely absent baseline at a valid commit from other failures.
        tree=run_subprocess(['git','ls-tree','--name-only',commit,'--',relative],cwd=root,
                            max_output=4096,max_error=4096,timeout=30)
        need(tree.returncode==0 and not tree.stdout.strip(),'LEVEL_BASELINE_READ')
        return None,commit
    need(len(found.stdout)<=MAX_SOURCE,'LEVEL_BASELINE_SIZE')
    value=json.loads(found.stdout);_baseline_sets(value)
    return value,commit


def write_baseline(path,snapshot):
    """Create once, or shrink an existing baseline; this command refuses expansion."""
    path=Path(path)
    value=baseline(snapshot)
    if path.exists():
        previous=json.loads(path.read_text())
        delta=check(snapshot,previous)
        need(not delta['new_upward_edges'] and not delta['new_unresolved_dynamic_calls'],'LEVEL_BASELINE_EXPANSION')
    path.parent.mkdir(parents=True,exist_ok=True)
    # Explicit owner-selected output; atomic replacement prevents partial baselines.
    import os,tempfile
    fd,temp=tempfile.mkstemp(prefix='.levels-',dir=path.parent)
    try:
        with os.fdopen(fd,'w') as stream:
            stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)
    return value


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--baseline',type=Path,help='Check the committed ratchet baseline.')
    group.add_argument('--write-baseline',type=Path,help='Create the initial baseline or shrink it; never expand it.')
    parser.add_argument('--base-ref',help='For CI: compare the proposed baseline to this reviewed local Git commit.')
    args=parser.parse_args(argv)
    need(args.base_ref is None or args.baseline is not None,'LEVEL_BASE_REF_REQUIRES_BASELINE')
    snapshot=scan(args.root)
    if args.baseline:
        if not args.baseline.is_file():
            print(json.dumps({'status':'FAIL','code':'LEVEL_BASELINE_MISSING','snapshot':snapshot},indent=2));return 1
        previous,commit=(None,None) if args.base_ref is None else previous_baseline(args.root,args.baseline,args.base_ref)
        result=check(snapshot,json.loads(args.baseline.read_text()),previous=previous)
        if commit is not None:
            result['reviewed_base_commit']=commit
            if previous is None:result['baseline_history']='INITIAL_BASELINE_ABSENT_AT_VERIFIED_BASE'
    elif args.write_baseline:
        write_baseline(args.write_baseline,snapshot)
        result={'status':'BASELINE_WRITTEN','upward_edges':snapshot['upward_count'],
                'unresolved_dynamic_calls':snapshot['unresolved_dynamic_count']}
    else:result=snapshot
    print(json.dumps(result,indent=2,sort_keys=True))
    return 1 if result.get('status')=='FAIL' or snapshot['unclassified_modules'] else 0


if __name__=='__main__':raise SystemExit(main())
