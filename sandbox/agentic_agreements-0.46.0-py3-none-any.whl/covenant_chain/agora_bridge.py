"""Pure, pinned Agora envelope preparation; no transport or routine execution.

This is a deliberately bounded adapter for two identified upstream drafts, not
a complete Agora implementation. Documents and responses are untrusted data.
Local SHA-256 pins supplement the upstream SHA-1 interoperability identifier;
neither one installs code, establishes authority or interprets natural language.
"""
from copy import deepcopy
import hashlib
import json
import re


VERSION = "covenant-agora-bridge/0.1"
DOCUMENT = "covenant-agora-document/0.1"
CONVERSATION = "covenant-agora-conversation/0.1"
VARIANTS = {
    "AGORA_WORKING_2025": {
        "specification": "https://agoraprotocol.org/docs/protocol/specification",
        "discovery_path": "/wellknown",
    },
    "AGORA_PAPER_2024": {
        "specification": "https://arxiv.org/html/2410.11905v1#A2",
        "discovery_path": "/.wellknown",
    },
}
MAX_DOCUMENT_BYTES = 262144
MAX_JSON_BYTES = 1048576
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_SESSION = re.compile(r"[A-Za-z0-9_-]{1,256}\Z")


def _need(condition, code):
    if not condition:
        raise ValueError(code)


def _text(value, maximum=MAX_DOCUMENT_BYTES, empty=False):
    _need(type(value) is str and (empty or bool(value)), "AGORA_TEXT")
    try:
        raw = value.encode("utf-8")
    except UnicodeError:
        raise ValueError("AGORA_TEXT") from None
    _need(len(raw) <= maximum, "AGORA_TEXT_SIZE")
    return raw


def _wire(value):
    """Local bounded canonical JSON, never a parser/interpreter of document text.

    Exact integers, booleans and strings match the portable Covenant surface.
    Fractional external JSON can be carried as a body string without rewriting.
    """
    pending, nodes = [(value, 0)], 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        _need(depth <= 32 and nodes <= 10000, "AGORA_JSON_COMPLEXITY")
        if item is None or type(item) is bool:
            continue
        if type(item) is int:
            _need(abs(item) <= 2**53 - 1, "AGORA_INTEGER_RANGE")
        elif type(item) is str:
            _text(item, MAX_JSON_BYTES, empty=True)
        elif type(item) is list:
            _need(len(item) <= 4096, "AGORA_JSON_ARRAY")
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is dict:
            _need(len(item) <= 1024, "AGORA_JSON_MAP")
            for name, child in item.items():
                _text(name, 256, empty=True)
                pending.append((child, depth + 1))
        else:
            raise ValueError("AGORA_JSON_TYPE")
    raw = json.dumps(value, sort_keys=True, ensure_ascii=False,
                     separators=(",", ":"), allow_nan=False).encode("utf-8")
    _need(len(raw) <= MAX_JSON_BYTES, "AGORA_JSON_SIZE")
    return raw


def _fields(value, keys, code="AGORA_FIELDS"):
    _need(type(value) is dict and set(value) == set(keys.split()), code)


def _hash(value):
    _need(type(value) is str and _HASH.fullmatch(value), "AGORA_EXPECTED_PIN")


def _identifier(domain, value):
    return hashlib.sha256(domain.encode("ascii") + b"\0" + _wire(value)).hexdigest()


def _variant(value):
    _need(type(value) is str and value in VARIANTS, "AGORA_VARIANT")


def _time(value):
    _need(type(value) is int and 0 <= value <= 2**53 - 1, "AGORA_TIME")


def _body(value, variant):
    _need(type(value) is str or variant == "AGORA_WORKING_2025" and type(value) is dict,
          "AGORA_BODY")
    _wire(value)


def _inert():
    return {"execution_authorized": False, "network": False,
            "recorded_on_chain": False, "source_interpretation": "NOT_PERFORMED"}


def describe():
    return {"profile": VERSION, "document_profile": DOCUMENT,
            "conversation_profile": CONVERSATION, "variants": deepcopy(VARIANTS),
            "scope": "BOUNDED_DOCUMENT_PINS_AND_ENVELOPE_PREPARATION_NOT_FULL_CONFORMANCE",
            "document": "EXACT_UTF8_NO_NORMALIZATION; SHA256_LOCAL_PIN; SHA1_UPSTREAM_IDENTIFIER_ONLY",
            "adoption": "ADOPT_EXACT_DOCUMENT_BYTES_AND_MEANING_WITH_EXTERNAL_DRAFT_OR_CONCEPT_ROLE_ASSENTS",
            "transport": "OWNER_INSTALLED_CONNECTOR_ALIAS_ONLY; HTTPS_FOR_AGORA; NO_FETCH_OR_SEND_HERE",
            "routines": "PACK_SOURCE_AS_INERT_EXTERNAL_DRAFT; OWNER_REVIEW_AND_INSTALL_SEPARATELY",
            "json_subset": "STRING_OR_OBJECT_BODY; EXACT_INTEGER_JSON; FRACTIONAL_JSON_CAN_BE_OPAQUE_STRING",
            "conversation_ids": "ASCII_AZ_az_09_UNDERSCORE_HYPHEN_1_TO_256; FIXED_PROTOCOL_AND_EXPIRY",
            "sources": "EXPLICIT_CALLER_DISCLOSURE_ONLY; NEVER_FETCHED_OR_TRUSTED",
            "trust": "PINS_ARE_NOT_AUTHENTICATION_AUTHORITY_TRUTH_LEGAL_EFFECT_OR_PAYMENT",
            **_inert()}


def pack(document_text, variant="AGORA_WORKING_2025"):
    """Pin supplied source bytes without validating YAML or its claimed meaning."""
    _variant(variant)
    raw = _text(document_text)
    record = {"profile": DOCUMENT, "variant": variant, "document_text": document_text,
              "sha256": hashlib.sha256(raw).hexdigest(),
              # SHA-1 is mandated by upstream for identification, not security.
              "protocol_hash": hashlib.sha1(raw, usedforsecurity=False).hexdigest(),
              "bytes": len(raw)}
    return {"record": record, "id": _identifier(DOCUMENT, record),
            "discovery_path": VARIANTS[variant]["discovery_path"],
            "metadata_validated": False, **_inert()}


def inspect(record, expected_id=None):
    _wire(record)
    _fields(record, "profile variant document_text sha256 protocol_hash bytes", "AGORA_DOCUMENT_FIELDS")
    _need(record["profile"] == DOCUMENT, "AGORA_DOCUMENT_PROFILE")
    _variant(record["variant"])
    expected = pack(record["document_text"], record["variant"])["record"]
    _need(_wire(record) == _wire(expected), "AGORA_DOCUMENT_CHANGED")
    ref = _identifier(DOCUMENT, record)
    if expected_id is not None:
        _hash(expected_id)
        _need(ref == expected_id, "AGORA_DOCUMENT_PIN")
    return {"id": ref, "record": deepcopy(record),
            "caller_pin": "MATCHED" if expected_id is not None else "NOT_SUPPLIED",
            "discovery_path": VARIANTS[record["variant"]]["discovery_path"],
            "metadata_validated": False, **_inert()}


def _conversation(record, expected_id, now):
    _wire(record)
    _fields(record, "profile variant conversation_id started_at expires protocol_record_id protocol_hash initiating_request",
            "AGORA_CONVERSATION_FIELDS")
    _need(record["profile"] == CONVERSATION and record["variant"] == "AGORA_WORKING_2025",
          "AGORA_CONVERSATION_PROFILE")
    _need(type(record["conversation_id"]) is str and _SESSION.fullmatch(record["conversation_id"]),
          "AGORA_CONVERSATION_ID")
    _time(record["expires"])
    _time(record["started_at"])
    _time(now)
    _need(record["started_at"] <= now, "AGORA_CLOCK_REVERSED")
    _need(now < record["expires"], "AGORA_CONVERSATION_EXPIRED")
    _hash(record["initiating_request"])
    if record["protocol_record_id"] is None:
        _need(record["protocol_hash"] is None, "AGORA_CONVERSATION_PROTOCOL")
    else:
        _hash(record["protocol_record_id"])
        _need(type(record["protocol_hash"]) is str and
              re.fullmatch(r"[0-9a-f]{40}", record["protocol_hash"]), "AGORA_CONVERSATION_PROTOCOL")
    _hash(expected_id)
    _need(_identifier(CONVERSATION, record) == expected_id, "AGORA_CONVERSATION_PIN")
    return deepcopy(record)


def request(body, protocol=None, expected_protocol_id=None, conversation=None,
            expected_conversation_id=None, multiround=False, now=None,
            sources=None, variant="AGORA_WORKING_2025"):
    """Prepare a relative route/envelope. A retained caller pin is required.

    `sources` is optional explicit outgoing data. It never supplies a route,
    installed verifier, credential or authority; protocol text is not disclosed
    automatically. The owner independently configures the actual peer/transport.
    """
    _variant(variant)
    _need(type(multiround) is bool, "AGORA_MULTIROUND")
    _body(body, variant)
    if sources is not None:
        _need(type(sources) is list and len(sources) <= 16, "AGORA_SOURCES")
        for source in sources:
            _text(source)
        _wire(sources)
    if conversation is not None:
        _need(protocol is None and expected_protocol_id is None and sources is None
              and not multiround and variant == "AGORA_WORKING_2025", "AGORA_CONVERSATION_PROTOCOL_CHANGE")
        prior = _conversation(conversation, expected_conversation_id, now)
        envelope = {"body": deepcopy(body)}
        path = "/conversations/" + prior["conversation_id"]
        protocol_ref, protocol_hash = prior["protocol_record_id"], prior["protocol_hash"]
    else:
        _need(expected_conversation_id is None, "AGORA_CONVERSATION_MISSING")
        if now is not None:
            _time(now)
        _need(not multiround or variant == "AGORA_WORKING_2025", "AGORA_PAPER_MULTIROUND_UNSUPPORTED")
        prior, protocol_ref, protocol_hash = None, None, None
        if protocol is not None:
            _need(expected_protocol_id is not None, "AGORA_DOCUMENT_PIN_REQUIRED")
            checked = inspect(protocol, expected_protocol_id)
            _need(protocol["variant"] == variant, "AGORA_VARIANT_MISMATCH")
            protocol_ref, protocol_hash = checked["id"], protocol["protocol_hash"]
        else:
            _need(expected_protocol_id is None, "AGORA_DOCUMENT_MISSING")
            _need(not sources, "AGORA_SOURCES_WITHOUT_PROTOCOL")
        envelope = {"body": deepcopy(body), "protocolHash": protocol_hash}
        if variant == "AGORA_PAPER_2024":
            _need(protocol is None or bool(sources), "AGORA_PAPER_SOURCES_REQUIRED")
            envelope["protocolSources"] = deepcopy(sources or [])
        elif sources is not None:
            envelope["protocolSources"] = deepcopy(sources)
        if multiround:
            envelope["multiround"] = True
        path = ""
    prepared = {"profile": VERSION, "variant": variant, "method": "POST", "path": path,
                "envelope": envelope, "protocol_record_id": protocol_ref,
                "protocol_hash": protocol_hash, "conversation": prior,
                "conversation_pin": expected_conversation_id, "requested_at": now}
    return {"prepared": prepared, "id": _identifier(VERSION, prepared), **_inert()}


def _prepared(prepared, expected_id):
    _wire(prepared)
    _fields(prepared, "profile variant method path envelope protocol_record_id protocol_hash conversation conversation_pin requested_at",
            "AGORA_PREPARED_FIELDS")
    _hash(expected_id)
    _need(_identifier(VERSION, prepared) == expected_id, "AGORA_REQUEST_PIN")
    _need(prepared["profile"] == VERSION and prepared["method"] == "POST", "AGORA_REQUEST_PROFILE")
    _variant(prepared["variant"])
    _need(type(prepared["envelope"]) is dict and "body" in prepared["envelope"], "AGORA_REQUEST_ENVELOPE")
    _body(prepared["envelope"]["body"], prepared["variant"])
    if prepared["requested_at"] is not None:
        _time(prepared["requested_at"])
    if prepared["protocol_record_id"] is None:
        _need(prepared["protocol_hash"] is None, "AGORA_REQUEST_PROTOCOL")
    else:
        _hash(prepared["protocol_record_id"])
        _need(type(prepared["protocol_hash"]) is str and
              re.fullmatch(r"[0-9a-f]{40}", prepared["protocol_hash"]), "AGORA_REQUEST_PROTOCOL")
    envelope = prepared["envelope"]
    if prepared["conversation"] is None:
        _need(prepared["path"] == "" and prepared["conversation_pin"] is None,
              "AGORA_REQUEST_PATH")
        _need(set(envelope) <= {"body", "protocolHash", "protocolSources", "multiround"}
              and "protocolHash" in envelope and envelope["protocolHash"] == prepared["protocol_hash"],
              "AGORA_REQUEST_ENVELOPE")
        if "multiround" in envelope:
            _need(type(envelope["multiround"]) is bool and envelope["multiround"]
                  and prepared["variant"] == "AGORA_WORKING_2025", "AGORA_MULTIROUND")
        if "protocolSources" in envelope:
            sources = envelope["protocolSources"]
            _need(type(sources) is list and len(sources) <= 16, "AGORA_SOURCES")
            for source in sources:
                _text(source)
            _need(prepared["protocol_hash"] is not None or not sources, "AGORA_SOURCES_WITHOUT_PROTOCOL")
        if prepared["variant"] == "AGORA_PAPER_2024":
            _need("protocolSources" in envelope and (prepared["protocol_hash"] is None or
                  bool(envelope["protocolSources"])), "AGORA_PAPER_SOURCES_REQUIRED")
    else:
        prior = _conversation(prepared["conversation"], prepared["conversation_pin"], prepared["requested_at"])
        _need(prepared["variant"] == prior["variant"] and set(envelope) == {"body"}
              and prepared["path"] == "/conversations/" + prior["conversation_id"]
              and prepared["protocol_record_id"] == prior["protocol_record_id"]
              and prepared["protocol_hash"] == prior["protocol_hash"], "AGORA_REQUEST_CONVERSATION")


def observe(prepared, response, now=None, expected_request_id=None):
    """Assess supplied data, not a network response's authenticity or world fact.

    Transport HTTP status/authentication is checked by the independently adopted
    connector. Even an Agora `success` may contain a domain-level error in body.
    """
    _need(expected_request_id is not None, "AGORA_REQUEST_PIN_REQUIRED")
    _prepared(prepared, expected_request_id)
    _wire(response)
    _need(type(response) is dict and type(response.get("status")) is str, "AGORA_RESPONSE_STATUS")
    status = response["status"]
    allowed = {"success", "failure"}
    if prepared["variant"] == "AGORA_PAPER_2024":
        allowed.add("rejected")
    _need(status in allowed, "AGORA_RESPONSE_STATUS")
    prior = prepared["conversation"]
    if now is not None:
        _time(now)
    if prepared["requested_at"] is not None and now is not None:
        _need(now >= prepared["requested_at"], "AGORA_CLOCK_REVERSED")
    if prior is not None:
        _time(now)
        _need(now < prior["expires"], "AGORA_CONVERSATION_EXPIRED")
    conversation = None
    if status == "success":
        _need("body" in response and "error" not in response, "AGORA_RESPONSE_SUCCESS_FIELDS")
        _body(response["body"], prepared["variant"])
        multi = prepared["envelope"].get("multiround", False) or prior is not None
        if multi:
            _need("conversationId" in response and "conversationExpires" in response,
                  "AGORA_RESPONSE_CONVERSATION_REQUIRED")
            identifier, expires = response["conversationId"], response["conversationExpires"]
            _need(type(identifier) is str and _SESSION.fullmatch(identifier), "AGORA_CONVERSATION_ID")
            _time(expires)
            _time(now)
            _need(expires > now, "AGORA_CONVERSATION_EXPIRED")
            if prior is not None:
                _need(identifier == prior["conversation_id"] and expires == prior["expires"],
                      "AGORA_RESPONSE_CONVERSATION_CHANGED")
                conversation = deepcopy(prior)
            else:
                conversation = {"profile": CONVERSATION, "variant": prepared["variant"],
                                "conversation_id": identifier, "expires": expires,
                                "started_at": now,
                                "protocol_record_id": prepared["protocol_record_id"],
                                "protocol_hash": prepared["protocol_hash"],
                                "initiating_request": expected_request_id}
        else:
            _need("conversationId" not in response and "conversationExpires" not in response,
                  "AGORA_UNREQUESTED_CONVERSATION")
    elif status == "failure":
        _need("body" not in response and "error" in response and "conversationId" not in response
              and "conversationExpires" not in response, "AGORA_RESPONSE_FAILURE_FIELDS")
        _text(response["error"], 4096)
    else:
        _need(set(response) == {"status"}, "AGORA_PAPER_REJECTED_FIELDS")
    return {"profile": VERSION, "request_id": expected_request_id,
            "agora_status": status.upper(), "response": deepcopy(response),
            "response_id": _identifier("COVENANT-AGORA-RESPONSE-0.1", response),
            "conversation": conversation,
            "conversation_id": _identifier(CONVERSATION, conversation) if conversation is not None else None,
            "business_success": "NOT_ESTABLISHED; DOMAIN_BODY_CAN_CONTAIN_ERROR",
            "authentication": "NOT_CHECKED; SUPPLIED_RESPONSE_DATA_ONLY",
            "contract_assent": "NOT_ESTABLISHED", "payment": "NOT_ESTABLISHED", **_inert()}
