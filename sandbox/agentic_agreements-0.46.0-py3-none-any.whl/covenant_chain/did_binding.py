"""did:wba and did:web documents, supplied as bytes, bound to an AAP key only by its signature.

AAP resolves ``did:aap`` (and ``did:covenant``) locally through ``DID_PREFIXES``.
Beside them it reads two web DID methods whose documents the caller already
holds; nothing is fetched:

* ``did:wba`` (ANP-03 did:wba method, ANP 1.2, section 2.2 syntax and 2.5 operations):
  a domain, an optional ``%3A`` port and colon-separated path segments. New path
  DIDs end in ``e1_<RFC 7638 thumbprint of an Ed25519 key>`` and their document
  must carry a ``DataIntegrityProof`` (``eddsa-jcs-2022``) by that key.
* ``did:web`` (W3C CCG did:web, section 2.5.2 Read): the same URL transformation;
  no fingerprint and usually no proof.

A document can list any key. It binds an AAP key only through a signature by
that key: either the document's own Data Integrity proof by the key it lists
for assertion, or an AAP ``covenant-did-binding/0.1`` record the key signed over
the DID and the document hash while the document lists the key. A listed key
without its signature is reported as listed, never bound. Domain control is the
transport's claim about the bytes and is not verified here.
"""
from copy import deepcopy
import hashlib
import re

from .crypto import canonical, digest, integer, key, need, public_key, sign, verification_key, verify
from . import interop_codec as codec

VERSION = 'covenant-did-binding/0.1'
LABEL = 'COVENANT-DID-BINDING-0.1'
FIELDS = 'version key did document_sha256 verification_method issued_at expires nonce'
METHODS = ('wba', 'web')
DID_CONTEXT = 'https://www.w3.org/ns/did/v1'
WBA_CONTEXTS = [DID_CONTEXT, 'https://w3id.org/security/data-integrity/v2', 'https://w3id.org/security/multikey/v1']
ED25519_TYPES = ('Multikey', 'Ed25519VerificationKey2020', 'JsonWebKey2020', 'JsonWebKey')
MAX_DOCUMENT = 65536
MAX_METHODS = 32
MAX_SERVICES = 32
LABEL_RE = re.compile(r'(?!-)[A-Za-z0-9-]{1,63}(?<!-)\Z')
SEGMENT = re.compile(r'[A-Za-z0-9._-]{1,128}\Z')
FINGERPRINT = re.compile(r'e1_[A-Za-z0-9_-]{43}\Z')

REMEDIATION = {
    'DID_SYNTAX': 'Use did:wba or did:web with a DNS name, an optional %3A port and colon-separated path segments.',
    'DID_METHOD': 'Use did:wba or did:web here; did:aap and did:covenant resolve through DID_PREFIXES.',
    'DID_DOCUMENT': 'Supply the DID document bytes as one JSON object within 64 KiB.',
    'DID_DOCUMENT_ID': 'The document id must equal the DID exactly.',
    'DID_CONTEXT': 'Include https://www.w3.org/ns/did/v1 (and for e1_ DIDs the data-integrity and multikey contexts).',
    'DID_METHODS': 'List at most 32 verification methods with id, type, controller and one public key encoding.',
    'DID_REFERENCE': 'Reference verification methods by an id of this document (absolute, or #fragment).',
    'DID_SERVICES': 'List at most 32 services with id, type and serviceEndpoint.',
    'DID_PROOF_REQUIRED': 'An e1_ did:wba document must carry a DataIntegrityProof by its fingerprint key.',
    'DID_FINGERPRINT': 'The proof key thumbprint must equal the e1_ segment of the DID.',
    'DID_PROOF_METHOD': 'The proof must name an Ed25519 verification method listed for assertion in this document.',
    'DID_DEACTIVATED': 'The document says it is deactivated; follow its successor through a separately verified document.',
    'DID_BINDING_FIELDS': 'Use the exact binding fields from describe().',
    'DID_BINDING_PROFILE': 'Use version covenant-did-binding/0.1.',
    'DID_BINDING_WINDOW': 'Use integer times with issued_at strictly before expires.',
    'DID_BINDING_SIGNATURE': 'The binding must be signed by the AAP key it names.',
    'DID_BINDING_DOCUMENT': 'The binding names another DID, document hash or verification method.',
    'DID_KEY_NOT_LISTED': 'The document must list the AAP key for authentication or assertion.',
}


def remediation(code):
    return REMEDIATION.get(code, codec.remediation(code))


def _domain(text):
    host, _, port = text.partition('%3A')
    need(0 < len(host) <= 253 and '.' in host and all(LABEL_RE.fullmatch(label) for label in host.split('.')), 'DID_SYNTAX')
    need(not all(label.isdigit() for label in host.split('.')), 'DID_SYNTAX')  # IP addresses are not DID domains.
    need(not host.split('.')[-1].isdigit(), 'DID_SYNTAX')
    if port or '%3A' in text:
        need(port.isdigit() and not port.startswith('0') and 1 <= int(port) <= 65535, 'DID_SYNTAX')
    return host, int(port) if port else None


def parse_did(did):
    """ANP-03 section 2.2 and did:web section 2.3 syntax; returns the parts and the resolution URL."""
    need(type(did) is str and 0 < len(did) <= 2048 and did.isascii(), 'DID_SYNTAX')
    parts = did.split(':')
    need(len(parts) >= 3 and parts[0] == 'did', 'DID_SYNTAX')
    need(parts[1] in METHODS, 'DID_METHOD')
    host, port = _domain(parts[2])
    need('%' not in parts[2].replace('%3A', '', 1), 'DID_SYNTAX')
    path = parts[3:]
    need(all(SEGMENT.fullmatch(segment) and segment not in ('.', '..') for segment in path), 'DID_SYNTAX')
    fingerprint = path[-1] if parts[1] == 'wba' and path and FINGERPRINT.fullmatch(path[-1]) else None
    authority = host + (':' + str(port) if port else '')
    url = 'https://' + authority + ('/' + '/'.join(path) if path else '/.well-known') + '/did.json'
    return {'did': did, 'method': parts[1], 'host': host, 'port': port, 'path': path, 'fingerprint': fingerprint,
            'url': url, 'kind': 'ROOT' if not path else ('E1_PATH' if fingerprint else 'PATH')}


def _ref(value, did):
    need(type(value) is str and 0 < len(value) <= 2300, 'DID_REFERENCE')
    return did + value if value.startswith('#') else value


def _method_key(method):
    """Ed25519 key of a verification method, or None for another algorithm."""
    if method['type'] in ('Multikey', 'Ed25519VerificationKey2020') and 'publicKeyMultibase' in method:
        text = method['publicKeyMultibase']
        if type(text) is str and text.startswith('z6Mk'):
            return codec.from_multikey(text)
        return None
    if method['type'] in ('JsonWebKey2020', 'JsonWebKey') and type(method.get('publicKeyJwk')) is dict:
        jwk = method['publicKeyJwk']
        return codec.from_okp_jwk(jwk) if jwk.get('kty') == 'OKP' and jwk.get('crv') == 'Ed25519' else None
    return None


def verify_document(did, document):
    """Check supplied DID document bytes for ``did``: id, keys, relationships, services and any proof."""
    parsed = parse_did(did)
    try:
        doc = codec.parse(document, MAX_DOCUMENT, 16, 4096) if type(document) in (str, bytes) else None
    except ValueError:
        raise ValueError('DID_DOCUMENT') from None
    need(type(doc) is dict, 'DID_DOCUMENT')
    need(doc.get('id') == did, 'DID_DOCUMENT_ID')
    contexts = doc.get('@context')
    contexts = [contexts] if type(contexts) is str else contexts
    if parsed['fingerprint'] is not None or contexts is not None:
        need(type(contexts) is list and DID_CONTEXT in contexts, 'DID_CONTEXT')
    methods = doc.get('verificationMethod', [])
    need(type(methods) is list and len(methods) <= MAX_METHODS, 'DID_METHODS')
    keys, unsupported = {}, []
    for method in methods:
        need(type(method) is dict and type(method.get('type')) is str and type(method.get('controller')) is str, 'DID_METHODS')
        ident = _ref(method.get('id'), did)
        need(ident not in keys and ident not in unsupported, 'DID_METHODS')
        found = _method_key(method) if method['type'] in ED25519_TYPES else None
        if found is None:
            unsupported.append(ident)
        else:
            keys[ident] = found
    relations = {}
    for name in ('authentication', 'assertionMethod'):
        rows = doc.get(name, [])
        need(type(rows) is list and len(rows) <= MAX_METHODS, 'DID_REFERENCE')
        refs = []
        for row in rows:
            if type(row) is dict:  # An embedded verification method.
                ident = _ref(row.get('id'), did)
                found = _method_key(row) if row.get('type') in ED25519_TYPES else None
                if found is not None:
                    keys.setdefault(ident, found)
                refs.append(ident)
            else:
                refs.append(_ref(row, did))
        relations[name] = refs
    services = doc.get('service', [])
    need(type(services) is list and len(services) <= MAX_SERVICES, 'DID_SERVICES')
    descriptions = []
    for service in services:
        need(type(service) is dict and type(service.get('type')) in (str, list) and 'serviceEndpoint' in service, 'DID_SERVICES')
        types = [service['type']] if type(service['type']) is str else service['type']
        endpoint = service['serviceEndpoint']
        if 'AgentDescription' in types and type(endpoint) is str and endpoint.startswith('https://') and len(endpoint) <= 2048:
            descriptions.append(endpoint)
    also = [value for value in doc.get('alsoKnownAs', []) if type(value) is str] if type(doc.get('alsoKnownAs')) is list else []
    proof = None
    if 'proof' in doc:
        method = _ref(doc['proof'].get('verificationMethod') if type(doc['proof']) is dict else None, did)
        need(method in keys and method in relations['assertionMethod'], 'DID_PROOF_METHOD')
        if parsed['fingerprint'] is not None:
            need('e1_' + codec.jwk_thumbprint(keys[method]) == parsed['fingerprint'], 'DID_FINGERPRINT')
        checked = codec.di_verify(doc, keys[method])
        proof = {'verification_method': method, 'key': keys[method], 'proof_context': checked['proof_context'],
                 'created': doc['proof'].get('created')}
    elif parsed['fingerprint'] is not None:
        raise ValueError('DID_PROOF_REQUIRED')
    return {'did': did, 'method': parsed['method'], 'kind': parsed['kind'], 'url': parsed['url'],
            'document_sha256': hashlib.sha256(codec.jcs(doc)).hexdigest(), 'keys': keys,
            'authentication': relations['authentication'], 'assertion': relations['assertionMethod'],
            'unsupported_methods': unsupported, 'agent_descriptions': descriptions, 'also_known_as': also,
            'deactivated': doc.get('deactivated') is True, 'proof': proof,
            'document_transport': 'SUPPLIED_BYTES_DOMAIN_CONTROL_NOT_VERIFIED'}


def _validate(body):
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'DID_BINDING_FIELDS')
    need(body['version'] == VERSION, 'DID_BINDING_PROFILE')
    need(type(body['key']) is str, 'DID_BINDING_FIELDS'); verification_key(body['key'])
    parse_did(body['did']); key(body['document_sha256']); key(body['nonce'])
    need(type(body['verification_method']) is str and body['verification_method'].startswith(body['did'] + '#')
         and len(body['verification_method']) <= 2300, 'DID_BINDING_FIELDS')
    integer(body['issued_at']); integer(body['expires'])
    need(body['issued_at'] < body['expires'], 'DID_BINDING_WINDOW')
    return body


def binding_id(body):
    _validate(body)
    return digest(LABEL, body)


def binding(aap_key, did, document, verification_method, issued_at, expires, nonce):
    """Prepare the unsigned record by which an AAP key adopts a DID document that lists it."""
    checked = verify_document(did, document)
    method = _ref(verification_method, did)
    need(checked['keys'].get(method) == aap_key, 'DID_KEY_NOT_LISTED')
    body = {'version': VERSION, 'key': aap_key, 'did': did, 'document_sha256': checked['document_sha256'],
            'verification_method': method, 'issued_at': issued_at, 'expires': expires, 'nonce': nonce}
    return {'id': binding_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [aap_key], 'signature_created': False, 'execution_authorized': False}


def sign_binding(body, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body['key'], 'DID_BINDING_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}


def open_binding(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'DID_BINDING_FIELDS')
    body = _validate(record['body'])
    try:
        verify(body['key'], LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('DID_BINDING_SIGNATURE') from None
    return {'id': digest(LABEL, body), 'body': deepcopy(body)}


def _listed(checked, aap_key):
    return [method for method, value in sorted(checked['keys'].items()) if value == aap_key
            and (method in checked['authentication'] or method in checked['assertion'])]


def resolve(identifier, *, document=None, bindings=(), now=None):
    """Resolve a DID beside did:aap. did:aap/did:covenant name their account; did:wba/did:web keys
    count only when the document's own proof or an AAP binding record is signed by the key."""
    need(type(identifier) is str and identifier.startswith('did:'), 'DID_SYNTAX')
    method = identifier.split(':')[1] if identifier.count(':') >= 2 else ''
    from .scale.identity import DID_PREFIXES, resolve_did
    if method in DID_PREFIXES:
        chain, account = resolve_did(identifier)
        return {'did': identifier, 'method': method, 'bound_keys': [{'key': account, 'basis': 'NATIVE_AAP_IDENTIFIER'}],
                'chain': chain, 'network_accessed': False, 'execution_authorized': False}
    need(method in METHODS, 'DID_METHOD')
    checked = verify_document(identifier, document)
    if now is not None:
        integer(now)
    need(type(bindings) in (list, tuple) and len(bindings) <= 16, 'DID_BINDING_FIELDS')
    bound, rejected = [], []
    if not checked['deactivated']:
        if checked['proof'] is not None:
            basis = 'DOCUMENT_PROOF_SELF_CERTIFYING_E1' if checked['kind'] == 'E1_PATH' else 'DOCUMENT_PROOF'
            bound.append({'key': checked['proof']['key'], 'basis': basis,
                          'verification_method': checked['proof']['verification_method']})
        for record in bindings:
            try:
                opened = open_binding(record)
                body = opened['body']
                need(body['did'] == identifier and body['document_sha256'] == checked['document_sha256']
                     and checked['keys'].get(body['verification_method']) == body['key'], 'DID_BINDING_DOCUMENT')
                need(body['verification_method'] in checked['authentication'] + checked['assertion'], 'DID_KEY_NOT_LISTED')
                need(now is None or body['issued_at'] <= now < body['expires'], 'DID_BINDING_WINDOW')
                if all(row['key'] != body['key'] for row in bound):
                    bound.append({'key': body['key'], 'basis': 'AAP_BINDING_SIGNATURE', 'binding': opened['id'],
                                  'verification_method': body['verification_method']})
            except ValueError as error:
                rejected.append({'status': 'EXCLUDED', 'reason': str(error) if str(error).isupper() else 'DID_BINDING_FIELDS'})
    keys = {row['key'] for row in bound}
    listed = sorted({value for method_id, value in checked['keys'].items()
                     if value not in keys and method_id in checked['authentication'] + checked['assertion']})
    aap_dids = []
    for alias in checked['also_known_as']:
        if alias.split(':')[1:2] and alias.split(':')[1] in DID_PREFIXES:
            try:
                if resolve_did(alias)[1] in keys:
                    aap_dids.append(alias)
            except ValueError:
                continue
    return {'did': identifier, 'method': method, 'kind': checked['kind'], 'url': checked['url'],
            'document_sha256': checked['document_sha256'], 'bound_keys': bound,
            'listed_without_key_signature': listed, 'excluded': rejected, 'aap_dids': aap_dids,
            'agent_descriptions': checked['agent_descriptions'], 'deactivated': checked['deactivated'],
            'status': 'DEACTIVATED' if checked['deactivated'] else ('BOUND' if bound else 'NOT_BOUND'),
            'domain_control': 'NOT_VERIFIED_SUPPLIED_BYTES', 'only_signatures_bind': True,
            'network_accessed': False, 'execution_authorized': False}


def wba_did(aap_key, host, path=(), port=None):
    """The e1_ did:wba path DID of an AAP Ed25519 key (ANP-03 section 2.2.1-2.2.2)."""
    need(type(path) in (list, tuple) and 1 <= len(path) <= 8, 'DID_SYNTAX')
    authority = host + ('%3A' + str(port) if port is not None else '')
    did = 'did:wba:' + authority + ':' + ':'.join(path) + ':e1_' + codec.jwk_thumbprint(aap_key)
    parse_did(did)
    return did


def document(aap_key, did, *, agent_description=None, aap_did=None, created=None):
    """An unsigned did:wba (or did:web) document listing the AAP key as Multikey, with the proof input.

    The AAP key signs ``hash_data``; ``sign_document`` is the explicit local helper.
    """
    parsed = parse_did(did)
    if parsed['fingerprint'] is not None:
        need(parsed['fingerprint'] == 'e1_' + codec.jwk_thumbprint(aap_key), 'DID_FINGERPRINT')
    method = did + '#key-1'
    doc = {'@context': list(WBA_CONTEXTS), 'id': did,
           'verificationMethod': [{'id': method, 'type': 'Multikey', 'controller': did,
                                   'publicKeyMultibase': codec.multikey(aap_key)}],
           'authentication': [method], 'assertionMethod': [method]}
    if agent_description is not None:
        need(type(agent_description) is str and agent_description.startswith('https://') and len(agent_description) <= 2048,
             'DID_SERVICES')
        doc['service'] = [{'id': did + '#ad', 'type': 'AgentDescription', 'serviceEndpoint': agent_description}]
    if aap_did is not None:
        from .scale.identity import resolve_did
        need(resolve_did(aap_did)[1] == aap_key, 'DID_KEY_NOT_LISTED')
        doc['alsoKnownAs'] = [aap_did]
    prepared = codec.di_prepare(doc, method, created=created)
    return {'did': did, 'document': doc, 'proof_options': prepared['proof_options'], 'hash_data': prepared['hash_data'],
            'resolution_url': parsed['url'], 'required_signers': [aap_key], 'signature_created': False,
            'publication': 'OWNER_PUBLISHES_AT_RESOLUTION_URL', 'execution_authorized': False}


def sign_document(prepared, private_key):
    """Explicit local owner action: add the eddsa-jcs-2022 proof by the AAP key."""
    need(type(prepared) is dict and public_key(private_key) == prepared['required_signers'][0], 'DID_BINDING_SIGNATURE')
    return codec.di_sign(prepared['document'], prepared['proof_options'], private_key)


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL,
            'methods': ['did:wba (ANP-03, ANP 1.2)', 'did:web (W3C CCG)'], 'native': 'did:aap and did:covenant via DID_PREFIXES',
            'binding_fields': FIELDS.split(), 'keys': 'ED25519_MULTIKEY_OR_OKP_JWK_ONLY',
            'binding': 'DOCUMENT_PROOF_BY_THE_KEY_OR_AAP_BINDING_SIGNED_BY_THE_KEY_WHILE_THE_DOCUMENT_LISTS_IT',
            'resolution': 'CALLER_SUPPLIES_DOCUMENT_BYTES_NOTHING_FETCHED', 'domain_control': 'NOT_VERIFIED',
            'limits': {'document_bytes': MAX_DOCUMENT, 'methods': MAX_METHODS, 'services': MAX_SERVICES},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
