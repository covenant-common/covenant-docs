"""Static owner handoff UI: no external assets, browser storage or key material."""
from html import escape


def index_html(csrf):
    return _HTML.replace('__CSRF__', escape(csrf, quote=True)).encode('utf-8')


def stylesheet():
    return _CSS.encode('utf-8')


def script():
    return _JS.encode('utf-8')


_HTML = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="referrer" content="no-referrer">
<meta name="covenant-csrf" content="__CSRF__">
<title>Owner handoff · Agentic Agreements Protocol</title>
<link rel="stylesheet" href="/style.css"><script src="/app.js" defer></script></head>
<body><a class="skip" href="#main">Skip to owner handoff</a><main id="main">
<header><p>Agentic Agreements Protocol · owner-local handoff</p><h1>Review, sign and exchange an exact agreement.</h1>
<p>Each owner opens their own local home. Exchange public keys first, then send the package and its fingerprint separately.</p>
<p>This page trusts your local operating-system account. Saved keys and agreements are private files, not encrypted backups. It makes no external calls.</p></header>
<p id="loading" role="status">Loading saved local state…</p>
<div id="error" role="alert" tabindex="-1" hidden></div>
<p id="announcement" role="status" aria-live="polite"></p>
<button type="button" id="reconnect">Reconnect and recover saved state</button>
<p class="detail">Reconnect keeps unfinished fields, clears the signing review, and reads saved state. It never repeats an action.</p>
<div id="application" hidden>
<section aria-labelledby="identity-heading"><h2 id="identity-heading">1. Your local signing identity</h2>
<p id="identity-status"></p><p class="value" id="identity-public"></p><p id="identity-recovery" role="status" hidden></p>
<div id="identity-create"><label><input type="checkbox" id="identity-consent"> <span id="identity-consent-label">Create a signing key in this private local home.</span></label>
<button type="button" id="create-identity" disabled>Create my local identity</button></div>
<button type="button" id="copy-key" disabled>Copy my public key</button>
<p>A public key proves no real-world identity or current authority. Confirm the other owner’s key through a channel you trust. Never enter a private key here.</p></section>
<section aria-labelledby="start-heading"><h2 id="start-heading">2. Draft or receive</h2>
<details id="draft-panel"><summary>Write a new agreement with actual parties</summary>
<form id="draft-form" novalidate>
<label for="draft-title">Agreement title</label><input id="draft-title" type="text" maxlength="120" autocomplete="off">
<label for="draft-terms">Exact agreement prose</label><textarea id="draft-terms" rows="7" spellcheck="false"></textarea>
<p>Include promises, conditions, timing and remedies in your own words. These exact UTF-8 bytes will be carried in the agreement.</p>
<fieldset><legend>Signing roles and agreed public keys</legend><div id="party-rows"></div>
<button type="button" id="add-party">Add another role</button></fieldset>
<details><summary>Context carried with this agreement</summary>
<label for="draft-context">Exact context as JSON</label><textarea id="draft-context" rows="5" spellcheck="false">{}</textarea>
<p>The complete context is plaintext and travels with the exported package. Context hashes do not establish world truth. JSON uses bounded integers, not floating-point numbers.</p></details>
<label id="draft-revision-label" hidden><input type="checkbox" id="draft-revision"> Link this new draft as a revision of the selected saved agreement. Fresh signatures are required; export the previous package first to retain its full history.</label>
<label><input type="checkbox" id="draft-consent"> Save this as the active local package, replacing any active package. I have retained any previous package I need.</label>
<button type="submit" id="draft" disabled>Save unsigned draft</button></form></details>
<details id="receive-panel"><summary>Receive a package, or merge countersignatures</summary>
<label for="incoming-file">Choose portable JSON file</label><input id="incoming-file" type="file" accept="application/json,.json">
<label for="incoming-json">Or paste the exact portable package JSON</label><textarea id="incoming-json" rows="6" spellcheck="false"></textarea>
<label for="incoming-pin">Expected package fingerprint, received separately</label><input id="incoming-pin" type="text" maxlength="64" autocomplete="off" spellcheck="false">
<p>The expected fingerprint must come from your independently trusted handoff channel. This page never fills it from the package.</p>
<label><input type="checkbox" id="receive-consent"> Inspect and save this pinned incoming package as my active package, replacing the current one.</label>
<button type="button" id="receive" disabled>Inspect and receive package</button>
<label><input type="checkbox" id="merge-consent"> Merge verified proofs over the unchanged agreement and context in my active package.</label>
<button type="button" id="merge" disabled>Merge countersignatures</button>
<p>Use merge for a countersigned version of the same agreement. Receiving replaces the active package; merge rejects changed agreement contents.</p></details></section>
<section id="current-panel" aria-labelledby="current-heading" hidden><h2 id="current-heading">3. Inspect the saved package</h2>
<p id="package-title"></p><p>Current package fingerprint</p><p id="package-id" class="value"></p>
<button type="button" id="copy-pin">Copy current fingerprint separately</button>
<p id="assent-status"></p><div id="next-actions"></div><div id="work-overview"></div>
<label for="agreement">Choose the agreement to inspect and sign</label><select id="agreement"></select>
<div id="agreement-status"></div><div id="roles"></div>
<div class="actions"><button type="button" id="open-source">Open exact source</button>
<button type="button" id="open-object">Open exact root object</button>
<button type="button" id="open-context">Open carried context</button></div>
<details><summary>Source and object navigation</summary><label for="source-document">Document name</label>
<input id="source-document" type="text" value="terms"><label for="source-encoding">Source representation</label>
<select id="source-encoding"><option value="UTF8">UTF-8 text</option><option value="BASE64">Base64 bytes</option></select>
<label for="object-path">Object path (empty means root)</label><input id="object-path" type="text" value=""></details>
<section id="opening-panel" hidden><h3 id="opening-heading" tabindex="-1">Opened content</h3><div id="opening"></div></section>
<p>Select only the roles you intend to sign as your local public key. Other parties must sign in their own homes.</p>
<button type="button" id="prepare-review" disabled>Prepare my exact signing review</button></section>
<section id="review-panel" aria-labelledby="review-heading" hidden><h2 id="review-heading" tabindex="-1">4. Your final signing review</h2>
<p id="review-expiry"></p><div id="review-content"></div>
<p class="notice">A signature records assent to these exact bytes and roles. It does not prove real-world identity, current authority, payment, legal effect, world truth or the globally latest agreement. Imported source is inert text.</p>
<label><input type="checkbox" id="sign-consent"> I have reviewed the exact terms, context, closure, key, roles and assent bodies above, and choose to sign them.</label>
<button type="button" id="sign" disabled>Sign these exact roles</button></section>
<section id="share-panel" aria-labelledby="share-heading" hidden><h2 id="share-heading">5. Send the package and its fingerprint</h2>
<p id="last-signature"></p>
<p>The package is plaintext. Export discloses all carried agreement text, context, identities, proofs and other carried inputs. It does not filter secrets or encrypt anything.</p>
<label><input type="checkbox" id="export-consent"> I choose to export this complete plaintext package for disclosure.</label>
<button type="button" id="export" disabled>Download plaintext package</button>
<p>Send the JSON file to the other owner. Send the current fingerprint through the separately trusted channel. After countersigning, they export their new package and new fingerprint for you to receive or merge.</p>
<details><summary>Saved-state and recovery details</summary><p id="saved-state"></p>
<p>After interruption, reconnect to read the saved outcome. If no signature was saved, prepare a new review and explicitly sign again. Restarting rotates the browser session and invalidates pending reviews. Keep the private local home safe; this application does not provide a backup service.</p></details></section>
</div><footer><p>Local assent and offline inspection only. No payment, network submission or publication is performed.</p></footer>
</main></body></html>'''

_CSS = '''*{box-sizing:border-box}html{font:16px/1.16 "Times New Roman",Times,serif;color:#000;background:#fff}body{margin:1rem}main{max-width:58rem;margin:1rem auto;border:1px solid #000;padding:1rem}h1,h2,h3,p,ul,ol,pre,fieldset{font-size:1rem;margin:0 0 .618rem}h1,h2,h3{font-weight:bold}section,header,footer{margin:0 0 1rem}section+section,footer{border-top:1px solid #000;padding-top:.618rem}label{display:block;margin:.382rem 0 .236rem}input,textarea,select,button,summary{font:inherit;color:#000;background:#fff}input:not([type=checkbox]):not([type=file]),textarea,select{width:100%;border:1px solid #000;border-radius:0;padding:.382rem}textarea{resize:vertical}input[type=checkbox]{margin:0 .236rem 0 0}button{padding:.382rem .618rem;border:1px solid #000;border-radius:0;cursor:pointer;margin:.236rem .236rem .236rem 0}button:disabled{opacity:.45;cursor:default}button:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid #000;outline-offset:2px}details{margin:.618rem 0}summary{cursor:pointer;font-weight:bold;margin-bottom:.382rem}fieldset{border:1px solid #000;padding:.618rem}pre,.value{white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;font-family:inherit}pre{border-left:1px solid #000;padding-left:.618rem;max-height:32rem;overflow:auto}#error,.notice{border:1px solid #000;padding:.618rem}#error{margin:.618rem 0}.party-row{display:grid;grid-template-columns:1fr 2fr;gap:.382rem;margin:.382rem 0 .618rem}.party-row button{grid-column:auto}.role-row{border:1px solid #000;margin:.382rem 0;padding:.382rem}.detail{margin-bottom:.382rem}.skip{color:#000}a{color:#000}[hidden]{display:none!important}dl{margin:0 0 .618rem}dt{font-weight:bold}dd{margin:0 0 .382rem;overflow-wrap:anywhere}@media(max-width:40rem){body{margin:.382rem}main{margin:0;padding:.618rem}.party-row{display:block}}'''

_JS = r'''"use strict";
(() => {
const $ = (id) => document.getElementById(id);
let csrf = document.querySelector('meta[name="covenant-csrf"]').content;
let current = null, review = null, busy = false, dirty = false;
const parties = [];
const show = (id, visible) => { $(id).hidden = !visible; };
const text = (id, value) => { $(id).textContent = value == null ? "" : String(value); };
function node(tag, value) { const n = document.createElement(tag); if (value != null) n.textContent = String(value); return n; }
function block(parent, label, value) {
  parent.append(node("h3", label), node("pre", typeof value === "string" ? value : JSON.stringify(value, null, 2)));
}
function technical(parent, label, value, opened=false) {
  const details = node("details"); details.open = opened;
  details.append(node("summary", label), node("pre", typeof value === "string" ? value : JSON.stringify(value, null, 2)));
  parent.append(details);
}
function publicKey() { return current && (current.identity_public || current.expected_identity_public); }
function invalidate() {
  review = null; $("sign-consent").checked = false; show("review-panel", false); sync();
}
function selected() { return current && current.agreements.find((a) => a.item === $("agreement").value); }
function selectedRoles() {
  return Array.from($("roles").querySelectorAll("input")).filter((n) => n.checked)
    .map((n) => ({concept: n._role.concept, party: n._role.party}));
}
function sync() {
  $("application").setAttribute("aria-busy", busy ? "true" : "false");
  for (const n of document.querySelectorAll("button")) n.disabled = busy;
  $("create-identity").disabled = busy || !$("identity-consent").checked || !!publicKey();
  $("copy-key").disabled = busy || !publicKey();
  $("draft").disabled = busy || !$("draft-consent").checked;
  $("receive").disabled = busy || !$("receive-consent").checked;
  $("merge").disabled = busy || !$("merge-consent").checked || !(current && current.package_id);
  $("prepare-review").disabled = busy || !selected() || !selected().supported || !selectedRoles().length;
  $("sign").disabled = busy || !review || !$("sign-consent").checked;
  $("export").disabled = busy || !$("export-consent").checked || !(current && current.package_id);
}
function explain(error) {
  const code = error.code || "LOCAL_CONNECTION_INTERRUPTED";
  let hint = "Check the input and its independently received fingerprint. No failed action is automatically retried.";
  if (/SESSION|CSRF|CONNECTION/.test(code)) hint = "Reconnect to read the saved outcome while keeping your unfinished fields, then prepare a fresh signing review.";
  else if (/CHANGED|STALE|EXPIRED|REVIEW/.test(code)) hint = "The saved package or review changed. Reconnect, inspect the current package and prepare a fresh review.";
  else if (/SIZE|COMPLEXITY|ARRAY|STRING/.test(code)) hint = "The input exceeds the supported package or native profile limits. Use a smaller conforming package; do not remove signed content.";
  else if (/JSON|DUPLICATE|NUMBER|INTEGER|FIELDS/.test(code)) hint = "Use valid bounded JSON with unique field names and whole numbers. The original text remains in the form.";
  else if (/ROLE|IDENTITY|SIGNER/.test(code)) hint = "Check your local public key against the agreement roles. Only explicitly selected roles belonging to this key can be signed.";
  else if (/MERGE|CONTENT|IMMUTABLE/.test(code)) hint = "Merge requires unchanged agreement contents and context. Inspect the incoming version before choosing to receive it separately.";
  text("error", code + ". " + hint); show("error", true); $("error").focus();
}
async function api(path, payload, rawFields={}) {
  let body;
  if (payload !== undefined) {
    body = JSON.stringify(payload);
    for (const [name, raw] of Object.entries(rawFields)) {
      if (!raw.trim()) throw Object.assign(new Error("JSON input required"), {code:"HANDOFF_JSON_REQUIRED"});
      // Validate that the input is exactly one JSON value. Never use the parsed
      // result: the original bytes must reach the strict duplicate-key parser.
      // This blocks closing the value and injecting sibling owner options.
      try { JSON.parse(raw); }
      catch (_) { throw Object.assign(new Error("One complete JSON value required"), {code:"HANDOFF_JSON_VALUE_REQUIRED"}); }
      // Preserve the exact JSON text through transport: JSON.parse here would
      // silently erase duplicate keys before the server's strict parser saw it.
      body = body.slice(0, -1) + "," + JSON.stringify(name) + ":" + raw + "}";
    }
  }
  const response = await fetch("/api/" + path, {method: body === undefined ? "GET" : "POST",
    credentials:"same-origin", cache:"no-store", headers: body === undefined ? {} :
      {"Content-Type":"application/json", "X-Covenant-CSRF":csrf}, body});
  let result;
  try { result = await response.json(); }
  catch (_) { throw Object.assign(new Error("Unreadable local response"), {code:"LOCAL_CONNECTION_INTERRUPTED"}); }
  if (!response.ok) throw Object.assign(new Error("Local request refused"), {code:result.error && result.error.code || "HANDOFF_HTTP_REFUSED"});
  return result;
}
async function action(task) {
  if (busy) return;
  busy = true; show("error", false); text("announcement", "Working locally…"); sync();
  try { await task(); }
  catch (error) { invalidate(); explain(error); text("announcement", "Action not confirmed. Reconnect to inspect the saved outcome."); }
  finally { busy = false; sync(); }
}
function addParty(role="", key="") {
  const row = node("div"); row.className = "party-row";
  const roleLabel = node("label", "Role name"), keyLabel = node("label", "Agreed public key (64 hexadecimal characters)");
  const roleInput = node("input"), keyInput = node("input"); roleInput.type = keyInput.type = "text";
  roleInput.value = role; keyInput.value = key; keyInput.maxLength = 64; roleInput.maxLength = 64;
  roleInput.autocomplete = keyInput.autocomplete = "off"; keyInput.spellcheck = false;
  roleLabel.append(roleInput); keyLabel.append(keyInput);
  const own = node("button", "Use my public key for this role"), remove = node("button", "Remove this role");
  own.type = remove.type = "button";
  const entry = {row, roleInput, keyInput}; parties.push(entry);
  own.addEventListener("click", () => {
    if (!current || !current.identity_public) { explain({code:"HANDOFF_IDENTITY_REQUIRED"}); return; }
    keyInput.value = current.identity_public; dirty = true; invalidate();
  });
  remove.addEventListener("click", () => { parties.splice(parties.indexOf(entry),1); row.remove(); dirty = true; invalidate(); });
  row.append(roleLabel, keyLabel, own, remove); $("party-rows").append(row);
}
function renderAgreement() {
  invalidate(); $("roles").replaceChildren(); $("agreement-status").replaceChildren();
  const agreement = selected(); if (!agreement) { sync(); return; }
  const summary = current.review.agreements.find((a) => a.item === agreement.item);
  const panel = $("agreement-status");
  if (agreement.sample_identity_present) panel.append(node("p", "A known public sample identity appears here. Owner signing is disabled for this agreement. Draft with actual party public keys and obtain fresh assent; this imported copy remains available for inspection."));
  const waiting = agreement.roles.filter((r) => r.status !== "VALID_ROLE_SIGNATURE");
  const count = agreement.roles.length - waiting.length;
  panel.append(node("p", "Agreement: " + agreement.item + " · " + agreement.kind + " · " + count + " of " + agreement.roles.length + " required roles signed" +
      (waiting.length ? "; waiting for " + waiting.map((r) => r.party).join(", ") : ". All declared role signatures verified in this package.")),
    node("p", "Exact agreement identifier: " + agreement.id));
  if (summary) {
    panel.append(node("p", "Included source closure: " + summary.closure.status +
      ". Context: " + summary.context.status + ". Predecessor: " + summary.predecessor.status +
      ". Independently established currentness: " + summary.currentness.receiver_status + "."));
    technical(panel, "Technical proof details: closure, context, predecessor and currentness", {
      native_assent_status:summary.native_assent_status, portable_status:summary.status,
      interpretation:waiting.length ? "Partial assent: existing role proofs verified; the native complete-set verifier cannot approve the full agreement until all required roles sign." : "Required role proofs complete in this carried package.",
      closure:summary.closure, context:summary.context, predecessor:summary.predecessor, currentness:summary.currentness});
  }
  if (!agreement.supported) panel.append(node("p", "This agreement can be inspected and carried; this local signer does not support signing its native profile."));
  $("roles").append(node("h3", "Required signing roles and outstanding assents"));
  for (const role of agreement.roles) {
    const label = node("label"); label.className = "role-row";
    const check = node("input"); check.type = "checkbox"; check._role = role; check.disabled = !role.eligible;
    check.addEventListener("change", invalidate);
    const roleStatus = role.status === "VALID_ROLE_SIGNATURE" ? "already signed; signature verified" :
      role.eligible ? "awaiting signature · select to sign with your local key" : "awaiting signature by this role’s key";
    label.append(check, node("span", (role.concept ? role.concept + " / " : "") + role.party + " · " + roleStatus),
      node("p", typeof role.identity === "string" ? role.identity : JSON.stringify(role.identity)));
    $("roles").append(label);
  }
  if (!agreement.roles.length) $("roles").append(node("p", "No supported signing roles are declared."));
  sync();
}
function renderState(state) {
  const previous = $("agreement").value; current = state; invalidate();
  const unavailable = state.custody && state.custody.status === "UNAVAILABLE";
  const adopting = state.custody && state.custody.status === "AWAITING_EXPLICIT_ADOPTION";
  text("identity-status", unavailable ? "Existing signing identity · local key unavailable. The retained public key is shown below." : adopting ? "A local key exists after interrupted creation. Explicitly adopt it to enable signing." : state.identity_public ? "Local signing identity is available." : "No local identity exists. Creation is optional until you choose to sign.");
  text("identity-consent-label", adopting ? "Adopt the existing signing key in this private local home." : "Create a signing key in this private local home.");
  text("create-identity", adopting ? "Adopt my existing local identity" : "Create my local identity");
  text("identity-public", publicKey());
  text("identity-recovery", unavailable ? state.custody.code + ". Restore the original signing key and private-file permissions in this owner home, then reconnect. Existing agreement inspection and plaintext export remain available; signing requires restored custody." : "");
  show("identity-recovery", unavailable); show("identity-create", !publicKey() && !unavailable);
  for (const id of ["current-panel","share-panel"]) show(id, !!state.package_id);
  show("draft-revision-label", !!state.package_id);
  $("agreement").replaceChildren(); $("next-actions").replaceChildren(); show("opening-panel", false);
  if (state.package_id) {
    text("package-title", state.review.title); text("package-id", state.package_id);
    const allRoles = state.agreements.flatMap((a) => a.roles);
    const signedCount = allRoles.filter((r) => r.status === "VALID_ROLE_SIGNATURE").length;
    text("assent-status", signedCount + " of " + allRoles.length + " required role signatures verified across this package." +
      (signedCount === allRoles.length && allRoles.length ? " All declared roles have signed; authority and payment remain separate checks." : " Inspect the outstanding roles below."));
    for (const advice of state.next_actions || []) $("next-actions").append(node("p", typeof advice === "string" ? advice : JSON.stringify(advice)));
    const overview = state.review.overview || {}, work = $("work-overview"); work.replaceChildren();
    const money = overview.money || [], performance = overview.performance || {}, duties = performance.items || [];
    work.append(node("h3", "Declared amounts and remaining work"));
    if (!money.length && !duties.length) work.append(node("p", "No structured amounts or duties were supplied. Read the exact terms; signing does not establish performance or payment."));
    for (const item of money) work.append(node("p", (item.label || item.id) + ": declared " + JSON.stringify(item.declared_amount) + " " + JSON.stringify(item.unit) + "; remaining in supplied scope " + JSON.stringify(item.remaining_in_supplied_scope) + ". Status: " + item.status + "; source binding: " + item.source_binding_status + "."));
    for (const item of duties) {
      work.append(node("p", (item.label || item.id) + " · responsible role " + item.responsible_role + " · " + item.status + " · " + item.remaining_obligation + ". Evidence: " + item.evidence_status + ". Performance verified: " + item.performance_verified + "; discharge established: " + item.discharge_established + "."));
      for (const assertion of item.assertions || []) for (const evidence of assertion.evidence || [])
        work.append(node("p", "Supplied evidence reference " + evidence.id + ": " + evidence.status + "; " + evidence.basis + "."));
    }
    if (money.length || duties.length) work.append(node("p", "These are scoped supplied claims. Unlisted duties remain unknown; signature completion is not performance, payment or discharge."));
    technical(work, "Complete scoped case overview and provenance", overview);
    for (const agreement of state.agreements) {
      const option = node("option", (agreement.title || agreement.item) + " · " + agreement.kind);
      option.value = agreement.item; $("agreement").append(option);
    }
    $("agreement").value = state.agreements.some((a) => a.item === previous) ? previous : (state.agreements[0] || {}).item || "";
    text("last-signature", state.last_signature ? "Saved signing receipt: " + state.last_signature.agreement + " · package " + state.last_signature.package_id + " · " + state.last_signature.signed_at : "No signature has been saved by this local home.");
    text("saved-state", "Active package " + state.package_id + ". Local signing receipts survive a restart; pending signing reviews do not.");
    renderAgreement();
  }
  $("export-consent").checked = false; show("application", true); show("loading", false); sync();
}
function renderReview(value) {
  review = value; const target = $("review-content"); target.replaceChildren();
  text("review-expiry", "Review expires at " + (typeof value.expires_at === "number" ? new Date(value.expires_at * 1000).toISOString() : value.expires_at) + ". Any change requires a fresh review.");
  block(target, "Package fingerprint", value.package_id);
  block(target, "Selected agreement", value.agreement);
  block(target, "Your signing public key", value.identity_public);
  target.append(node("h3", "Selected signing roles"));
  for (const role of value.roles) target.append(node("p", (role.concept ? role.concept + " / " : "") + role.party));
  for (let index = 0; index < value.sources.length; index++) {
    const source = value.sources[index];
    if (typeof source.source === "string") block(target, "Exact source " + (index + 1) + " · " + source.encoding, source.source);
    technical(target, "Technical proof details: source identity and bytes " + (index + 1), source);
  }
  const closure = value.object.closure || {};
  target.append(node("p", "Signing closure: " + (closure.status || "See exact root below") + (closure.id ? " · " + closure.id : "") + ". This review covers the exact native root and the selected roles."));
  technical(target, "Exact root object, closure and provenance", value.object);
  technical(target, "Complete structured terms, including constituent concepts", value.structured_terms, !value.sources.length);
  block(target, "Complete carried context openings", value.context_openings);
  target.append(node("p", "Assent label: " + value.required_assent.label + " · " + value.required_assent.bodies.length + " exact signing bodies."));
  technical(target, "Exact assent bodies and native label to be signed", value.required_assent);
  target.append(node("p", value.disclosure));
  $("sign-consent").checked = false; show("review-panel", true); $("review-heading").focus(); sync();
}
async function copy(value, label) {
  if (!value) return;
  try { await navigator.clipboard.writeText(value); text("announcement", label + " copied. Share through your chosen trusted channel."); }
  catch (_) { text("announcement", "Clipboard unavailable. Select and copy the visible " + label.toLowerCase() + "."); }
}
$("identity-consent").addEventListener("change", sync);
$("create-identity").addEventListener("click", () => action(async () => {
  if (!$("identity-consent").checked) throw {code:"HANDOFF_CONFIRM_REQUIRED"};
  renderState(await api("create-identity", {confirm:true})); $("identity-consent").checked = false;
  text("announcement", "Local identity created or recovered. Copy the public key to your counterparty.");
}));
$("copy-key").addEventListener("click", () => copy(publicKey(), "Public key"));
$("copy-pin").addEventListener("click", () => copy(current.package_id, "Package fingerprint"));
$("add-party").addEventListener("click", () => { addParty(); dirty = true; });
$("draft-form").addEventListener("input", () => { dirty = true; invalidate(); });
$("draft-consent").addEventListener("change", sync);
$("draft-form").addEventListener("submit", (event) => { event.preventDefault(); action(async () => {
  if (!$("draft-consent").checked) throw {code:"HANDOFF_CONFIRM_REQUIRED"};
  const mapping = Object.create(null);
  for (const party of parties) {
    const name = party.roleInput.value.trim();
    if (!name || Object.prototype.hasOwnProperty.call(mapping,name)) throw {code:"HANDOFF_DUPLICATE_ROLE"};
    mapping[name] = party.keyInput.value.trim();
  }
  const request = {title:$("draft-title").value, terms:$("draft-terms").value,
    parties:mapping, expected_package_id:current.package_id};
  if ($("draft-revision").checked) request.previous_agreement = $("agreement").value;
  const state = await api("draft", request, {context:$("draft-context").value});
  renderState(state); dirty = false; $("draft-consent").checked = false;
  $("draft-revision").checked = false;
  text("announcement", "Unsigned draft saved. Inspect the exact source and choose your signing roles.");
}); });
for (const id of ["receive-consent","merge-consent","export-consent","sign-consent"]) $(id).addEventListener("change", sync);
for (const id of ["incoming-json","incoming-pin"]) $(id).addEventListener("input", () => { dirty = true; invalidate(); });
$("incoming-file").addEventListener("change", () => action(async () => {
  const file = $("incoming-file").files[0]; if (!file) return;
  if (file.size > 1250000) throw {code:"PORTABLE_SIZE"};
  $("incoming-json").value = await file.text(); dirty = true; invalidate();
  text("announcement", "Package file loaded. Enter the expected fingerprint received separately.");
}));
for (const mode of ["receive","merge"]) $(mode).addEventListener("click", () => action(async () => {
  if (!$(mode + "-consent").checked) throw {code:"HANDOFF_CONFIRM_REQUIRED"};
  const state = await api(mode, {expected_id:$("incoming-pin").value.trim(),
    expected_package_id:current.package_id, confirm:true}, {package:$("incoming-json").value});
  renderState(state); $(mode + "-consent").checked = false;
  text("announcement", mode === "merge" ? "Verified proofs merged into the unchanged agreement. Inspect remaining roles." : "Pinned package inspected and saved. Review its exact source before signing.");
}));
$("agreement").addEventListener("change", renderAgreement);
$("prepare-review").addEventListener("click", () => action(async () => {
  invalidate();
  renderReview(await api("review-sign", {expected_package_id:current.package_id,
    agreement:$("agreement").value, roles:selectedRoles()}));
  text("announcement", "Read the exact signing review, then make your explicit signing choice.");
}));
for (const kind of ["source","object","context"]) $("open-" + kind).addEventListener("click", () => action(async () => {
  const payload = {expected_package_id:current.package_id, agreement:$("agreement").value};
  if (kind === "source") { payload.document = $("source-document").value; payload.encoding = $("source-encoding").value; }
  else if (kind === "object") payload.path = $("object-path").value;
  const opening = await api("open-" + kind, payload); $("opening").replaceChildren();
  if (typeof opening.source === "string") block($("opening"), kind === "object" ? "Exact typed object · formatted JSON presentation" : "Exact source text",
    kind === "object" && opening.encoding === "CANONICAL_JSON" ? JSON.parse(opening.source) : opening.source);
  if (kind === "context") block($("opening"), opening.carried ? "Exact carried context value" : "Context is hash-only; no value was carried", opening.carried ? opening.value : opening.context);
  technical($("opening"), "Complete opened " + kind + " and provenance", opening);
  show("opening-panel", true); $("opening-heading").focus(); text("announcement", "Exact content opened as inert text.");
}));
$("sign").addEventListener("click", () => action(async () => {
  if (!review || !$("sign-consent").checked) throw {code:"HANDOFF_CONFIRM_REQUIRED"};
  const result = await api("sign", {review_id:review.review_id, confirm:true});
  renderState(result.state);
  text("announcement", result.status === "RECOVERED" ? "Recovered the previously saved signing result. Inspect the active package before exporting." : "Signature saved. Inspect outstanding roles, then explicitly export the plaintext package.");
  $("last-signature").setAttribute("tabindex", "-1"); $("last-signature").focus();
}));
$("export").addEventListener("click", () => action(async () => {
  if (!$("export-consent").checked) throw {code:"HANDOFF_CONFIRM_REQUIRED"};
  const result = await api("export", {expected_package_id:current.package_id, confirm:true});
  const blob = new Blob([JSON.stringify(result.package)], {type:"application/json"});
  const url = URL.createObjectURL(blob), link = node("a"); link.href = url;
  link.download = "agreement-" + result.id + ".json"; document.body.append(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000); $("export-consent").checked = false;
  text("announcement", "Plaintext download prepared. Copy and share the current fingerprint separately; browser download completion is not a delivery receipt.");
}));
$("reconnect").addEventListener("click", () => action(async () => {
  invalidate();
  const response = await fetch("/", {credentials:"same-origin", cache:"no-store"});
  if (!response.ok) throw {code:"LOCAL_CONNECTION_INTERRUPTED"};
  const html = await response.text(), match = html.match(/name="covenant-csrf" content="([a-f0-9]{64})"/);
  if (!match) throw {code:"HANDOFF_SESSION"};
  csrf = match[1]; renderState(await api("state"));
  text("announcement", "Reconnected. Saved state recovered; unfinished fields retained. No action was repeated. Prepare a new signing review when ready.");
}));
window.addEventListener("beforeunload", (event) => { if (dirty) { event.preventDefault(); event.returnValue = ""; } });
addParty(); addParty();
action(async () => { renderState(await api("state")); text("announcement", "Saved state loaded. Choose an explicit next action."); });
})();'''
