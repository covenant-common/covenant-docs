"""Make a fork worthless. Covenants, reputation, ads and positions bind to one genesis.

Replay onto another chain id fails closed. The light client, SDK and MCP server
compare that id with the 3-of-5 release manifest and warn on anything else.

This is not a fork-choice rule. LightClient.assess still applies the committee
certificate and the recipient height floor. Continuity delay, DOMAIN_SUCCESSION
and defense.py witnesses stay where they are.
"""
from covenant_chain.crypto import genesis_id
from .crypto import digest, exact, key, need, verify

RELEASE_LABEL = 'COVENANT-RELEASE-0.1'
OBJECT_LABEL = 'COVENANT-OBJECT-0.1'
RELEASE_SIGNERS = 5
RELEASE_QUORUM = 3
WARNING = 'NON_CANONICAL_NETWORK: covenants, reputation, staking, vesting, founder share and ad receipts on this genesis are not the canonical chain.'


def genesis_hash(genesis):
    return genesis_id(genesis)


def bind_object(chain, kind, body):
    """Every signed economics object carries the chain id. A copy does not verify elsewhere."""
    key(chain)
    need(type(kind) is str and 0 < len(kind) <= 64, 'FORK_KIND')
    need(type(body) is dict and body.get('chain', chain) == chain, 'FORK_REPLAY')
    bound = dict(body)
    bound['chain'] = chain
    bound['object'] = kind
    return bound


def require_chain(chain, obj):
    key(chain)
    need(type(obj) is dict and obj.get('chain') == chain, 'FORK_REPLAY')
    return True


def release_body(genesis, version, code_digest):
    key(genesis)
    key(code_digest)
    need(type(version) is str and 0 < len(version) <= 80, 'RELEASE_VERSION')
    return {'genesis': genesis, 'version': version, 'digest': code_digest}


def verify_release(manifest):
    """Three of five signatures over the pinned genesis. Fewer than three is not a release."""
    exact(manifest, 'genesis version digest signers signatures')
    body = release_body(manifest['genesis'], manifest['version'], manifest['digest'])
    signers = manifest['signers']
    need(type(signers) is list and len(signers) == RELEASE_SIGNERS and signers == sorted(set(signers)), 'RELEASE_SIGNERS')
    for signer in signers:
        key(signer)
    seen = set()
    good = 0
    for row in manifest['signatures']:
        exact(row, 'signer signature')
        need(row['signer'] in signers and row['signer'] not in seen, 'RELEASE_SIGNER')
        verify(row['signer'], RELEASE_LABEL, body, row['signature'])
        seen.add(row['signer'])
        good += 1
    need(good >= RELEASE_QUORUM, 'RELEASE_QUORUM')
    return {'genesis': manifest['genesis'], 'version': manifest['version'], 'quorum': good,
            'canonical_release': True}


def canonical_warning(actual_genesis, pinned_genesis, manifest=None):
    """Loud, structured warning. Callers surface the string; they do not hide it."""
    key(actual_genesis)
    key(pinned_genesis)
    release = None
    if manifest is not None:
        release = verify_release(manifest)
        need(release['genesis'] == pinned_genesis, 'RELEASE_GENESIS')
    canonical = actual_genesis == pinned_genesis and (manifest is None or release is not None)
    return {'actual': actual_genesis, 'pinned': pinned_genesis, 'canonical': canonical,
            'warning': None if canonical else WARNING, 'release': release,
            'reputation_portable': False, 'positions_portable': False, 'receipts_portable': False}


def mcp_advertisement(actual_genesis, pinned_genesis, manifest=None):
    """Pin the MCP server and SDKs advertise beside their tool list."""
    status = canonical_warning(actual_genesis, pinned_genesis, manifest)
    status['surface'] = 'MCP_AND_SDK'
    return status
