"""Agreements before the first remote call, and server-countersigned call receipts.

The strategy briefing gives remote MCP and A2A servers three tiers:

* Tier 0 is a one-sided owner policy (covenant_agent.provenance_policy).
* Tier 1: the server countersigns each call receipt (urn:aap:call-receipt:0.1):
  the agreement, request id, operation, the hash of the exact arguments, the
  hash of the exact result without its protocol metadata, the server's own
  call sequence and the charge. The caller checks it against the receipt its
  own durable ToolClient or A2A connector journal already holds.
* Tier 2: before the first call the caller and the server both sign one call
  agreement (urn:aap:call-agreement:0.1): the exact pinned tool descriptors or
  A2A card and methods, a price per accepted call, typed acceptance criteria, a
  call quota, a validity window and an escrow reservation that the caller's
  installed custody adapter must observe as locked. A call outside it is
  refused by both sides: the caller never sends it and the server never runs it.

Settlement allocates the escrow from countersigned, accepted calls through the
same custody adapter's quorum payout. Unknown outcomes count against the quota
and are never charged by this module. Agreement text, tool output and
counterparty data are data: nothing here signs, pays or releases without the
owner's installed key, custody adapter and approvals. Clock values are the
owner's assertions; they bound this host's own refusals, not world time.
"""
from contextlib import contextmanager
from copy import deepcopy
import json
import re
import threading

from covenant_agent.errors import NativeError
from covenant_agent.tool_client import AGREEMENT_META, _json as json_bytes, sha256 as json_sha256

from .crypto import canonical, digest, public_key, sign, verify
from .workflow_store import WorkflowStore

PROFILE = 'urn:aap:call-agreement:0.1'
RECEIPT = 'urn:aap:call-receipt:0.1'
ASSENT_LABEL = 'AAP-CALL-AGREEMENT-0.1'
ID_LABEL = 'AAP-CALL-AGREEMENT-ID-0.1'
RECEIPT_LABEL = 'AAP-CALL-RECEIPT-0.1'
SETTLEMENT_LABEL = 'AAP-CALL-SETTLEMENT-EFFECT-0.1'
URN = 'urn:aap:call-agreement:'
MCP_AGREEMENT = AGREEMENT_META
MCP_RECEIPT = 'io.github.covenant-common/call-receipt'
A2A_AGREEMENT = PROFILE
A2A_RECEIPT = RECEIPT
TRANSPORTS = ('MCP', 'A2A')
A2A_METHODS = ('CancelTask', 'GetTask', 'SendMessage')
A2A_FAILED = ('TASK_STATE_CANCELED', 'TASK_STATE_FAILED', 'TASK_STATE_REJECTED')
KINDS = ('MAX_RESULT_BYTES', 'NOT_ERROR', 'STRUCTURED_FIELDS', 'TASK_STATES')
FIELDS = 'profile caller server transport target price max_calls acceptance escrow not_before expires nonce'
MAX = 2**53 - 1
MAX_CALLS = 100000
MAX_BODY = 65536
HEX = re.compile(r'[0-9a-f]{64}\Z')
NAME = re.compile(r'[A-Za-z0-9_.:/+-]{1,128}\Z')
REQUEST = re.compile(r'[A-Za-z0-9_.:-]{8,128}\Z')
FLAGS = {'execution_authorized': False, 'payment_authorized': False, 'authority_granted': False}

HINTS = {
    'CALL_AGREEMENT_FIELDS': 'Use exactly: profile caller server transport target price max_calls acceptance escrow not_before expires nonce.',
    'CALL_AGREEMENT_PROFILE': 'Use profile urn:aap:call-agreement:0.1. Another version needs its own reviewed reader.',
    'CALL_AGREEMENT_KEY': 'Name the caller and the server by distinct 64-hex Ed25519 public keys.',
    'CALL_AGREEMENT_TARGET': 'MCP: pin 1 to 64 tools by descriptor SHA-256. A2A: the pinned card id and 1 to 3 of CancelTask, GetTask, SendMessage.',
    'CALL_AGREEMENT_PRICE': 'Set price to {amount, unit}: an integer from 0 to 2^53-1 per accepted call and a short ASCII unit.',
    'CALL_AGREEMENT_QUOTA': 'Set max_calls to an integer from 1 to 100000. Unknown outcomes count against it.',
    'CALL_AGREEMENT_CRITERIA': 'Use 1 to 4 distinct typed criteria: NOT_ERROR, STRUCTURED_FIELDS {fields}, MAX_RESULT_BYTES {value}, TASK_STATES {states} (A2A only).',
    'CALL_AGREEMENT_ESCROW': 'Name the custody adapter, escrow policy and funding effect in the price unit, covering price times max_calls.',
    'CALL_AGREEMENT_WINDOW': 'Set integer not_before < expires (seconds). They bound refusals on each side, not world time.',
    'CALL_AGREEMENT_NONCE': 'Use a fresh 64-hex nonce for a new agreement.',
    'CALL_AGREEMENT_SIZE': 'Keep the agreement within 65536 canonical bytes of printable ASCII.',
    'CALL_AGREEMENT_ID': 'Pass the 64-hex agreement id from draft or agreement_id.',
    'CALL_AGREEMENT_ASSENT': 'Collect exactly one signature from the caller and one from the server over the agreement id.',
    'CALL_AGREEMENT_ROLE': 'This host signs only as the server the agreement names. Install the right key; never re-sign another role.',
    'CALL_AGREEMENT_CHANGED': 'Another agreement already holds this id. Keep both and investigate; do not overwrite.',
    'CALL_AGREEMENT_NOT_ADOPTED': 'Adopt the agreement first: both signatures and, on the caller, the observed escrow.',
    'CALL_AGREEMENT_CUSTODY': 'Install the custody adapter the agreement names. Agreement text cannot install one.',
    'CALL_AGREEMENT_ESCROW_NOT_OBSERVED': 'The installed custody adapter does not show this escrow locked for the caller, the server and the agreed amount. Fund it, then adopt again.',
    'CALL_AGREEMENT_NOT_YET': 'The agreement window has not opened. Wait for not_before.',
    'CALL_AGREEMENT_EXPIRED': 'The agreement window has closed. Agree a new call agreement for further calls.',
    'CALL_AGREEMENT_SCOPE': 'This tool or method is outside the agreement. Agree a new one that names it.',
    'CALL_AGREEMENT_EXHAUSTED': 'Every agreed call is used; unknown outcomes count. Agree a new call agreement.',
    'CALL_AGREEMENT_CLOSED': 'The agreement is settled. Agree a new call agreement for further calls.',
    'CALL_AGREEMENT_PIN': 'The installed client pins another descriptor, card or transport than the agreement. Re-pin or agree again; never widen a pin.',
    'CALL_AGREEMENT_REQUIRED': 'This server only runs calls under an adopted call agreement. Send the agreement and request id in the call metadata.',
    'CALL_REQUEST_ID': 'Use a request id of 8 to 128 characters: letters, digits and _ . : -.',
    'CALL_REQUEST_REUSED': 'This request id already names another call under this agreement. Use a new request id; reuse only for an exact retry.',
    'CALL_ARGUMENTS': 'Pass the call arguments as a JSON object.',
    'CALL_RESULT': 'Pass the result as a JSON object exactly as received.',
    'CALL_RECEIPT': 'Pass the countersigned receipt exactly as returned: {body, signature}.',
    'CALL_RECEIPT_SIGNATURE': 'The receipt is not signed by the server key the agreement names. Keep it as evidence; it proves nothing.',
    'CALL_RECEIPT_SCOPE': 'The receipt names another agreement, request, operation, server or arguments. It does not belong to this call.',
    'CALL_RECEIPT_RESULT': 'The receipt does not hash the result you hold. Keep both and treat the call as disputed.',
    'CALL_RECEIPT_CHARGE': 'The receipt charges another amount or sequence than the agreement allows. Do not pay it; keep it as evidence.',
    'CALL_SERVER_OUTCOME_UNKNOWN': 'This request was admitted but its outcome was not recorded. It is not run again; reconcile out of band.',
    'CALL_HANDLER_RESULT': 'The installed handler must return a JSON object. The call stays admitted with an unknown outcome.',
    'CALL_CUSTODY_PAYOUT': 'The custody adapter did not record this payout. Check approvals and the escrow state, then retry the same settlement.',
    'CALL_SETTLEMENT_CHANGED': 'The custody adapter holds another payout for this settlement. Investigate before relying on either.',
    'CALL_TIME': 'Pass the owner-adopted time as an integer number of seconds.',
}


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS[code])


def _hex(value, code):
    need(type(value) is str and HEX.fullmatch(value) is not None, code)
    return value


def _int(value, low, high, code):
    need(type(value) is int and low <= value <= high, code)
    return value


def _text(value, limit, code):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _key(value):
    from covenant_language.key_validation import valid_ed25519_key
    need(type(value) is str and HEX.fullmatch(value) is not None and valid_ed25519_key(value), 'CALL_AGREEMENT_KEY')
    return value


def _criteria(rows, transport):
    need(type(rows) is list and 1 <= len(rows) <= len(KINDS), 'CALL_AGREEMENT_CRITERIA')
    seen = set()
    for row in rows:
        need(type(row) is dict and row.get('kind') in KINDS and row['kind'] not in seen, 'CALL_AGREEMENT_CRITERIA')
        seen.add(row['kind'])
        if row['kind'] == 'NOT_ERROR':
            need(set(row) == {'kind'}, 'CALL_AGREEMENT_CRITERIA')
        elif row['kind'] == 'MAX_RESULT_BYTES':
            need(set(row) == {'kind', 'value'}, 'CALL_AGREEMENT_CRITERIA')
            _int(row['value'], 1, 1048576, 'CALL_AGREEMENT_CRITERIA')
        elif row['kind'] == 'STRUCTURED_FIELDS':
            need(set(row) == {'kind', 'fields'} and type(row['fields']) is list and 1 <= len(row['fields']) <= 32
                 and row['fields'] == sorted(set(row['fields'])), 'CALL_AGREEMENT_CRITERIA')
            for name in row['fields']:
                _text(name, 64, 'CALL_AGREEMENT_CRITERIA')
        else:
            need(transport == 'A2A' and set(row) == {'kind', 'states'} and type(row['states']) is list
                 and 1 <= len(row['states']) <= 8 and row['states'] == sorted(set(row['states'])), 'CALL_AGREEMENT_CRITERIA')
            for name in row['states']:
                need(type(name) is str and re.fullmatch(r'TASK_STATE_[A-Z_]{1,32}', name) is not None, 'CALL_AGREEMENT_CRITERIA')


def validate(body):
    """Check an exact call agreement; it binds nothing until both parties sign it."""
    need(type(body) is dict, 'CALL_AGREEMENT_FIELDS')
    need(set(body) == set(FIELDS.split()), 'CALL_AGREEMENT_FIELDS')
    need(body['profile'] == PROFILE, 'CALL_AGREEMENT_PROFILE')
    _key(body['caller']); _key(body['server'])
    need(body['caller'] != body['server'], 'CALL_AGREEMENT_KEY')
    need(body['transport'] in TRANSPORTS, 'CALL_AGREEMENT_TARGET')
    target = body['target']
    if body['transport'] == 'MCP':
        need(type(target) is dict and set(target) == {'tools'} and type(target['tools']) is dict
             and 1 <= len(target['tools']) <= 64, 'CALL_AGREEMENT_TARGET')
        for name, pin in target['tools'].items():
            need(NAME.fullmatch(name) is not None, 'CALL_AGREEMENT_TARGET'); _hex(pin, 'CALL_AGREEMENT_TARGET')
    else:
        need(type(target) is dict and set(target) == {'card', 'methods'} and type(target['methods']) is list
             and 1 <= len(target['methods']) <= 3 and target['methods'] == sorted(set(target['methods']))
             and set(target['methods']) <= set(A2A_METHODS), 'CALL_AGREEMENT_TARGET')
        _hex(target['card'], 'CALL_AGREEMENT_TARGET')
    price = body['price']
    need(type(price) is dict and set(price) == {'amount', 'unit'}, 'CALL_AGREEMENT_PRICE')
    _int(price['amount'], 0, MAX, 'CALL_AGREEMENT_PRICE'); _text(price['unit'], 64, 'CALL_AGREEMENT_PRICE')
    _int(body['max_calls'], 1, MAX_CALLS, 'CALL_AGREEMENT_QUOTA')
    _criteria(body['acceptance'], body['transport'])
    escrow = body['escrow']
    need(type(escrow) is dict and set(escrow) == {'adapter', 'policy', 'fund_effect', 'amount', 'unit'}, 'CALL_AGREEMENT_ESCROW')
    for name in ('adapter', 'policy', 'fund_effect'):
        _hex(escrow[name], 'CALL_AGREEMENT_ESCROW')
    _int(escrow['amount'], 1, MAX, 'CALL_AGREEMENT_ESCROW')
    need(escrow['unit'] == price['unit'] and escrow['amount'] >= price['amount'] * body['max_calls'], 'CALL_AGREEMENT_ESCROW')
    _int(body['not_before'], 0, MAX, 'CALL_AGREEMENT_WINDOW'); _int(body['expires'], 0, MAX, 'CALL_AGREEMENT_WINDOW')
    need(body['not_before'] < body['expires'], 'CALL_AGREEMENT_WINDOW')
    _hex(body['nonce'], 'CALL_AGREEMENT_NONCE')
    try:
        raw = canonical(body)
    except ValueError:
        raise NativeError('CALL_AGREEMENT_SIZE', HINTS['CALL_AGREEMENT_SIZE']) from None
    need(len(raw) <= MAX_BODY, 'CALL_AGREEMENT_SIZE')
    return body


def agreement_id(body):
    return digest(ID_LABEL, validate(body))


def reference(agreement):
    """The agreement string a ToolClient receipt carries: urn:aap:call-agreement:<id>."""
    return URN + _hex(agreement, 'CALL_AGREEMENT_ID')


def draft(*, caller, server, transport, target, price, max_calls, acceptance, escrow, not_before, expires, nonce):
    body = {'profile': PROFILE, 'caller': caller, 'server': server, 'transport': transport,
            'target': deepcopy(target), 'price': deepcopy(price), 'max_calls': max_calls,
            'acceptance': deepcopy(acceptance), 'escrow': deepcopy(escrow), 'not_before': not_before,
            'expires': expires, 'nonce': nonce}
    pin = agreement_id(body)
    return {'agreement': body, 'id': pin, 'reference': reference(pin), 'required_signers': [caller, server],
            'signing_payload': {'label': ASSENT_LABEL, 'body': {'agreement': pin}},
            'signature_created': False, 'status': 'AWAITING_BOTH_SIGNATURES', **FLAGS}


def assent(body, private_key):
    """Explicit owner signing step; tools and agreement text never call it."""
    pin = agreement_id(body)
    signer = public_key(private_key)
    need(signer in (body['caller'], body['server']), 'CALL_AGREEMENT_ROLE')
    return {'signer': signer, 'signature': sign(private_key, ASSENT_LABEL, {'agreement': pin})}


def verify_assents(body, assents):
    pin = agreement_id(body)
    need(type(assents) is list and len(assents) == 2, 'CALL_AGREEMENT_ASSENT')
    signers = []
    for row in assents:
        need(type(row) is dict and set(row) == {'signer', 'signature'}, 'CALL_AGREEMENT_ASSENT')
        try:
            verify(row['signer'], ASSENT_LABEL, {'agreement': pin}, row['signature'])
        except ValueError:
            raise NativeError('CALL_AGREEMENT_ASSENT', HINTS['CALL_AGREEMENT_ASSENT']) from None
        signers.append(row['signer'])
    need(sorted(signers) == sorted([body['caller'], body['server']]), 'CALL_AGREEMENT_ASSENT')
    return pin


def _object(value, code):
    need(type(value) is dict, code)
    try:
        json_sha256(value)
    except ValueError:
        raise NativeError(code, HINTS[code]) from None
    return value


def arguments_hash(transport, value):
    """MCP: the ToolClient arguments_sha256. A2A: the params without the agreement member."""
    _object(value, 'CALL_ARGUMENTS')
    if transport == 'A2A':
        value = deepcopy(value)
        metadata = value.get('metadata')
        if type(metadata) is dict:
            metadata.pop(A2A_AGREEMENT, None)
            if not metadata:
                value.pop('metadata')
    return json_sha256(value)


def result_hash(transport, result):
    """The business result: MCP without _meta and resultType; A2A without metadata."""
    _object(result, 'CALL_RESULT')
    drop = ('_meta', 'resultType') if transport == 'MCP' else ('metadata',)
    return json_sha256({k: v for k, v in result.items() if k not in drop})


def receipt_body(*, agreement, server, request_id, operation, arguments_sha256, result_sha256, sequence, charge):
    return {'profile': RECEIPT, 'agreement': agreement, 'server': server, 'request_id': request_id,
            'operation': operation, 'arguments_sha256': arguments_sha256, 'result_sha256': result_sha256,
            'sequence': sequence, 'charge': deepcopy(charge)}


def _check_receipt_body(body):
    need(type(body) is dict and set(body) == {'profile', 'agreement', 'server', 'request_id', 'operation',
         'arguments_sha256', 'result_sha256', 'sequence', 'charge'} and body['profile'] == RECEIPT, 'CALL_RECEIPT')
    need(body['agreement'] is None or type(body['agreement']) is str and HEX.fullmatch(body['agreement']), 'CALL_RECEIPT')
    need(type(body['request_id']) is str and REQUEST.fullmatch(body['request_id']) is not None, 'CALL_RECEIPT')
    need(type(body['operation']) is str and NAME.fullmatch(body['operation']) is not None, 'CALL_RECEIPT')
    _hex(body['arguments_sha256'], 'CALL_RECEIPT'); _hex(body['result_sha256'], 'CALL_RECEIPT')
    _int(body['sequence'], 1, MAX, 'CALL_RECEIPT')
    charge = body['charge']
    need(charge is None or type(charge) is dict and set(charge) == {'amount', 'unit'} and type(charge['amount']) is int
         and 0 <= charge['amount'] <= MAX and type(charge['unit']) is str and 0 < len(charge['unit']) <= 64
         and all(32 <= ord(c) <= 126 for c in charge['unit']), 'CALL_RECEIPT')
    need(type(body['server']) is str and HEX.fullmatch(body['server']) is not None, 'CALL_RECEIPT')


def countersign(private_key, *, transport, agreement, request_id, operation, arguments_sha256, result, sequence, charge):
    """Tier 1: the server signs what it returned. agreement is None outside tier 2."""
    need(transport in TRANSPORTS, 'CALL_AGREEMENT_TARGET')
    body = receipt_body(agreement=agreement, server=public_key(private_key), request_id=request_id,
                        operation=operation, arguments_sha256=arguments_sha256,
                        result_sha256=result_hash(transport, result), sequence=sequence, charge=charge)
    _check_receipt_body(body)
    return {'body': body, 'signature': sign(private_key, RECEIPT_LABEL, body)}


def carry_receipt(transport, result, receipt):
    """Attach a receipt in the protocol's metadata member; the hashed result is unchanged."""
    value = deepcopy(_object(result, 'CALL_RESULT'))
    member, name = ('_meta', MCP_RECEIPT) if transport == 'MCP' else ('metadata', A2A_RECEIPT)
    holder = value.setdefault(member, {})
    need(type(holder) is dict, 'CALL_RESULT')
    holder[name] = deepcopy(receipt)
    return value


def read_receipt(transport, result):
    if type(result) is not dict:
        return None
    member, name = ('_meta', MCP_RECEIPT) if transport == 'MCP' else ('metadata', A2A_RECEIPT)
    holder = result.get(member)
    return deepcopy(holder.get(name)) if type(holder) is dict else None


def verify_receipt(receipt, *, transport, server, agreement, request_id, operation, arguments_sha256, result,
                   charge=None, max_sequence=None):
    """Check a countersigned receipt against independently held facts. Evidence, not authority."""
    need(type(receipt) is dict and set(receipt) == {'body', 'signature'}, 'CALL_RECEIPT')
    body = receipt['body']
    _check_receipt_body(body)
    need(body['server'] == server, 'CALL_RECEIPT_SIGNATURE')
    try:
        verify(server, RECEIPT_LABEL, body, receipt['signature'])
    except ValueError:
        raise NativeError('CALL_RECEIPT_SIGNATURE', HINTS['CALL_RECEIPT_SIGNATURE']) from None
    need(body['agreement'] == agreement and body['request_id'] == request_id and body['operation'] == operation
         and body['arguments_sha256'] == arguments_sha256, 'CALL_RECEIPT_SCOPE')
    need(body['result_sha256'] == result_hash(transport, result), 'CALL_RECEIPT_RESULT')
    need(canonical(body['charge']) == canonical(charge) and (max_sequence is None or body['sequence'] <= max_sequence),
         'CALL_RECEIPT_CHARGE')
    return {'receipt_signature_verified': True, 'agreement': agreement, 'sequence': body['sequence'],
            'charge': deepcopy(body['charge']), 'remote_effect_verified': False, **FLAGS}


def evaluate(acceptance, transport, result, *, rpc_error=False):
    """Typed criteria over the exact result. A pass is a mechanical check, not world truth."""
    results = []
    for row in acceptance:
        kind = row['kind']
        if kind == 'NOT_ERROR':
            if transport == 'MCP':
                met = not rpc_error and type(result) is dict and result.get('isError', False) is False
            else:
                met = not rpc_error and type(result) is dict and _task_state(result) not in A2A_FAILED
        elif kind == 'MAX_RESULT_BYTES':
            met = type(result) is dict and len(json_bytes(_strip(transport, result))) <= row['value']
        elif kind == 'STRUCTURED_FIELDS':
            met = all(_has_field(transport, result, name) for name in row['fields'])
        else:
            met = _task_state(result) in row['states']
        results.append({'kind': kind, 'met': bool(met)})
    return {'verdict': 'ACCEPTED' if all(r['met'] for r in results) else 'REJECTED', 'results': results,
            'basis': 'TYPED_CRITERIA_OVER_EXACT_RESULT; NOT_WORLD_TRUTH'}


def _strip(transport, result):
    drop = ('_meta', 'resultType') if transport == 'MCP' else ('metadata',)
    return {k: v for k, v in result.items() if k not in drop}


def _task_state(result):
    status = result.get('status') if type(result) is dict else None
    return status.get('state') if type(status) is dict else None


def _has_field(transport, result, name):
    if type(result) is not dict:
        return False
    if transport == 'MCP':
        return type(result.get('structuredContent')) is dict and name in result['structuredContent']
    artifacts = result.get('artifacts')
    for artifact in artifacts if type(artifacts) is list else []:
        parts = artifact.get('parts') if type(artifact) is dict else None
        for part in parts if type(parts) is list else []:
            if type(part) is dict and type(part.get('data')) is dict and name in part['data']:
                return True
    return False


def _request(request_id):
    need(type(request_id) is str and REQUEST.fullmatch(request_id) is not None, 'CALL_REQUEST_ID')
    return request_id


def _now(now):
    return _int(now, 0, MAX, 'CALL_TIME')


def _pin(text):
    """A carried agreement reference: urn:aap:call-agreement:<64 hex> or None."""
    if text is None:
        return None
    need(type(text) is str and text.startswith(URN), 'CALL_AGREEMENT_ID')
    return _hex(text[len(URN):], 'CALL_AGREEMENT_ID')


def _window(body, now):
    need(now >= body['not_before'], 'CALL_AGREEMENT_NOT_YET')
    need(now < body['expires'], 'CALL_AGREEMENT_EXPIRED')


def _scope(body, operation):
    allowed = body['target']['tools'] if body['transport'] == 'MCP' else body['target']['methods']
    need(operation in allowed, 'CALL_AGREEMENT_SCOPE')


def refusal(error):
    """Code, fix, whether retrying helps and the reference entry, for a refused call."""
    code = getattr(error, 'code', str(error))
    return {'code': code, 'fix': HINTS.get(code, getattr(error, 'remediation', 'Correct the input and retry.')),
            'retry_helps': code in ('CALL_AGREEMENT_NOT_YET',), 'reference': 'docs/CALL_AGREEMENTS.html#refusals'}


def _mcp_error(error):
    value = refusal(error)
    return {'content': [{'type': 'text', 'text': json.dumps(value, sort_keys=True)}],
            'structuredContent': value, 'isError': True}


def _handled(handler, operation, arguments, transport):
    """Run the installed handler; an exception or a non-object becomes a countersigned error result."""
    try:
        result = handler(operation, deepcopy(arguments))
        need(type(result) is dict, 'CALL_HANDLER_RESULT')
        _object(result, 'CALL_HANDLER_RESULT')
        return deepcopy(result)
    except Exception:
        if transport == 'MCP':
            return {'content': [{'type': 'text', 'text': 'CALL_HANDLER_FAILED'}], 'isError': True}
        return {'status': {'state': 'TASK_STATE_FAILED'}, 'kind': 'task'}


class _Ledger:
    """Events in an owner-private WorkflowStore; state is replayed from the hash chain.

    A server answers from several threads: one lock serializes the shared
    connection, and the store's file lock serializes other processes.
    """
    def __init__(self, directory, context):
        self.store = WorkflowStore(directory, context, check_same_thread=False)
        self.lock = threading.RLock()

    def close(self):
        with self.lock:
            self.store.close()

    @contextmanager
    def exclusive(self):
        with self.lock, self.store.exclusive():
            yield

    def state(self):
        with self.lock:
            events = self.store.events()
        agreements = {'tier1': {}}
        for event in events:
            body = event['body']; kind = body['kind']; pin = body['task']; value = body['value']
            if kind == 'CALL_TIER1':
                agreements['tier1'][value['request_id']] = value
                continue
            if kind == 'CALL_AGREEMENT':
                need(pin not in agreements, 'CALL_AGREEMENT_CHANGED')
                agreements[pin] = {'body': value['body'], 'assents': value['assents'], 'escrow': value.get('escrow'),
                                   'calls': {}, 'order': [], 'settled': None, 'head': event['id']}
                continue
            row = agreements[pin]
            if kind == 'CALL_INTENT':
                row['calls'][value['request_id']] = {**value, 'state': 'PENDING', 'outcome': None}
                row['order'].append(value['request_id'])
            elif kind == 'CALL_OUTCOME':
                row['calls'][value['request_id']]['outcome'] = value
                row['calls'][value['request_id']]['state'] = value['state']
            elif kind == 'CALL_SETTLED':
                row['settled'] = value
            row['head'] = event['id']
        return agreements

    def append(self, kind, agreement, value):
        with self.exclusive():
            return self.store.append(kind, agreement, value)


class CallMeter:
    """Server side of tiers 1 and 2: adopt, admit inside the agreement, then countersign.

    The private key is installed by the server's owner. A request is admitted
    durably before the handler runs; an admitted request whose outcome was not
    recorded is never run again. With require_agreement=False the meter also
    countersigns calls that name no agreement (tier 1 alone), uncharged.
    """
    def __init__(self, directory, private_key, *, require_agreement=True):
        need(type(require_agreement) is bool, 'CALL_AGREEMENT_REQUIRED')
        self.key = private_key; self.public = public_key(private_key)
        self.require_agreement = require_agreement
        self.ledger = _Ledger(directory, {'profile': PROFILE, 'role': 'SERVER', 'server': self.public})

    def close(self):
        self.ledger.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def adopt(self, body, assents):
        pin = verify_assents(body, assents)
        need(body['server'] == self.public, 'CALL_AGREEMENT_ROLE')
        current = self.ledger.state().get(pin)
        if current is not None:
            need(canonical(current['body']) == canonical(body), 'CALL_AGREEMENT_CHANGED')
            return {'agreement': pin, 'status': 'ADOPTED', 'replayed': True, **FLAGS}
        self.ledger.append('CALL_AGREEMENT', pin, {'body': deepcopy(body), 'assents': deepcopy(assents)})
        return {'agreement': pin, 'status': 'ADOPTED', 'replayed': False, **FLAGS}

    def admit(self, agreement, request_id, operation, arguments_sha256, now):
        """ADMITTED with a sequence, COMPLETED for an exact retry, or a refusal before any effect."""
        _request(request_id); _now(now); _hex(arguments_sha256, 'CALL_ARGUMENTS')
        pin = _hex(agreement, 'CALL_AGREEMENT_ID')
        with self.ledger.exclusive():
            state = self.ledger.state()
            need(pin in state, 'CALL_AGREEMENT_NOT_ADOPTED')
            row = state[pin]; body = row['body']
            old = row['calls'].get(request_id)
            if old is not None:
                need(old['operation'] == operation and old['arguments_sha256'] == arguments_sha256, 'CALL_REQUEST_REUSED')
                need(old['outcome'] is not None, 'CALL_SERVER_OUTCOME_UNKNOWN')
                return {'status': 'COMPLETED', 'receipt': deepcopy(old['outcome']['receipt']),
                        'result': deepcopy(old['outcome']['result']), 'replayed': True}
            need(row['settled'] is None, 'CALL_AGREEMENT_CLOSED')
            _window(body, now); _scope(body, operation)
            need(len(row['order']) < body['max_calls'], 'CALL_AGREEMENT_EXHAUSTED')
            sequence = len(row['order']) + 1
            self.ledger.store.append('CALL_INTENT', pin, {'request_id': request_id, 'operation': operation,
                                     'arguments_sha256': arguments_sha256, 'sequence': sequence, 'at': now})
        return {'status': 'ADMITTED', 'sequence': sequence, 'replayed': False}

    def complete(self, transport, agreement, request_id, result):
        """Countersign the exact result once and attach the receipt."""
        _object(result, 'CALL_RESULT')
        with self.ledger.exclusive():
            state = self.ledger.state()
            need(agreement in state and request_id in state[agreement]['calls'], 'CALL_AGREEMENT_NOT_ADOPTED')
            row = state[agreement]; call = row['calls'][request_id]
            if call['outcome'] is not None:
                return carry_receipt(transport, call['outcome']['result'], call['outcome']['receipt'])
            receipt = countersign(self.key, transport=transport, agreement=agreement, request_id=request_id,
                                  operation=call['operation'], arguments_sha256=call['arguments_sha256'],
                                  result=result, sequence=call['sequence'], charge=row['body']['price'])
            self.ledger.store.append('CALL_OUTCOME', agreement, {'request_id': request_id, 'state': 'COUNTERSIGNED',
                                     'receipt': receipt, 'result': deepcopy(result)})
        return carry_receipt(transport, result, receipt)

    def _tier1(self, transport, request_id, operation, arguments_sha256, run):
        """Countersign without an agreement. A caller request id makes an exact retry a replay."""
        need(not self.require_agreement, 'CALL_AGREEMENT_REQUIRED')
        with self.ledger.exclusive():
            held = self.ledger.state()['tier1']
            if request_id is not None:
                _request(request_id)
                old = held.get(request_id)
                if old is not None:
                    need(old['operation'] == operation and old['arguments_sha256'] == arguments_sha256, 'CALL_REQUEST_REUSED')
                    return carry_receipt(transport, old['result'], old['receipt'])
            sequence = len(held) + 1
            request_id = request_id or 'server-%08d' % sequence
            result = run()
            receipt = countersign(self.key, transport=transport, agreement=None, request_id=request_id,
                                  operation=operation, arguments_sha256=arguments_sha256, result=result,
                                  sequence=sequence, charge=None)
            self.ledger.store.append('CALL_TIER1', '0' * 64, {'request_id': request_id, 'operation': operation,
                                     'arguments_sha256': arguments_sha256, 'receipt': receipt, 'result': result})
        return carry_receipt(transport, result, receipt)

    @staticmethod
    def _carried(value):
        if value is None:
            return None, None
        need(type(value) is dict and set(value) == {'agreement', 'request_id'}, 'CALL_AGREEMENT_REQUIRED')
        return _pin(value['agreement']), _request(value['request_id'])

    def mcp(self, params, handler, now):
        """Run one MCP tools/call through handler(name, arguments) under the agreement in params._meta.

        Refusals return an MCP error result with code and fix, and no receipt.
        """
        try:
            need(type(params) is dict, 'CALL_ARGUMENTS')
            name, arguments, meta = params.get('name'), params.get('arguments', {}), params.get('_meta')
            need(type(name) is str and NAME.fullmatch(name) is not None, 'CALL_AGREEMENT_SCOPE')
            args_hash = arguments_hash('MCP', arguments)
            agreement, request_id = self._carried(meta.get(MCP_AGREEMENT) if type(meta) is dict else None)
            if agreement is None:
                return self._tier1('MCP', request_id, name, args_hash, lambda: _handled(handler, name, arguments, 'MCP'))
            admitted = self.admit(agreement, request_id, name, args_hash, now)
        except NativeError as error:
            return _mcp_error(error)
        if admitted['status'] == 'COMPLETED':
            return carry_receipt('MCP', admitted['result'], admitted['receipt'])
        return self.complete('MCP', agreement, request_id, _handled(handler, name, arguments, 'MCP'))

    def a2a(self, params, handler, now, *, method='SendMessage'):
        """Run one A2A request through handler(method, params). Refusals raise NativeError; map them
        to a JSON-RPC error with refusal(error) as data."""
        need(type(params) is dict, 'CALL_ARGUMENTS')
        args_hash = arguments_hash('A2A', params)
        metadata = params.get('metadata')
        agreement, request_id = self._carried(metadata.get(A2A_AGREEMENT) if type(metadata) is dict else None)
        if agreement is None:
            return self._tier1('A2A', request_id, method, args_hash, lambda: _handled(handler, method, params, 'A2A'))
        admitted = self.admit(agreement, request_id, method, args_hash, now)
        if admitted['status'] == 'COMPLETED':
            return carry_receipt('A2A', admitted['result'], admitted['receipt'])
        return self.complete('A2A', agreement, request_id, _handled(handler, method, params, 'A2A'))


def check_mcp_receipt(client, alias, request_id, *, server, price=None):
    """Tier 1 on the caller: verify the countersignature in a ToolClient's retained result."""
    held = client.retained_result(alias, request_id)
    need(held['result'] is not None, 'CALL_RECEIPT')
    receipt = read_receipt('MCP', held['result'])
    need(receipt is not None, 'CALL_RECEIPT')
    intent = held['intent']
    agreement = intent['agreement'][len(URN):] if (intent['agreement'] or '').startswith(URN) else None
    return verify_receipt(receipt, transport='MCP', server=server, agreement=agreement, request_id=request_id,
                          operation=intent['tool'], arguments_sha256=intent['arguments_sha256'],
                          result=held['result'], charge=price)


class CallAgreements:
    """Caller side of tier 2 over an installed ToolClient or A2AHTTPClient.

    custody is the owner-installed custody adapter the agreement names (for
    example DemoEscrowDesk): it must show the escrow locked before adoption,
    and it executes the settlement payout with the quorum's approvals.
    """
    def __init__(self, directory, *, custody=None):
        self.custody = custody
        self.ledger = _Ledger(directory, {'profile': PROFILE, 'role': 'CALLER'})

    def close(self):
        self.ledger.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _escrow(self, body):
        escrow = body['escrow']
        need(self.custody is not None and getattr(self.custody, 'ref', None) == escrow['adapter'], 'CALL_AGREEMENT_CUSTODY')
        need(getattr(self.custody, 'unit', escrow['unit']) == escrow['unit'], 'CALL_AGREEMENT_ESCROW_NOT_OBSERVED')
        funded = self.custody.observe(escrow['fund_effect'])
        value = funded.get('value') if type(funded) is dict else None
        need(type(funded) is dict and funded.get('status') == 'OBSERVED' and type(value) is dict
             and value.get('action') == 'FUND' and value.get('escrow') == escrow['policy']
             and value.get('amount') == escrow['amount'], 'CALL_AGREEMENT_ESCROW_NOT_OBSERVED')
        contract = getattr(self.custody, 'contract', None)
        current = contract(escrow['policy']) if contract is not None else None
        if current is not None:
            data = (current.get('policy') or {}).get('data') or {}
            need(current.get('status') == 'LOCKED' and current.get('amount') == escrow['amount']
                 and data.get('payer') == body['caller'] and data.get('payee') == body['server'],
                 'CALL_AGREEMENT_ESCROW_NOT_OBSERVED')
        return {'fund': deepcopy(funded), 'contract': deepcopy(current),
                'assurance': 'OWNER_INSTALLED_CUSTODY_ADAPTER_OBSERVATION'}

    def adopt(self, body, assents):
        """Both signatures and the observed escrow, before the first call."""
        pin = verify_assents(body, assents)
        current = self.ledger.state().get(pin)
        if current is not None:
            need(canonical(current['body']) == canonical(body), 'CALL_AGREEMENT_CHANGED')
            return {'agreement': pin, 'status': 'ADOPTED', 'replayed': True, 'escrow': deepcopy(current['escrow']), **FLAGS}
        escrow = self._escrow(body)
        self.ledger.append('CALL_AGREEMENT', pin, {'body': deepcopy(body), 'assents': deepcopy(assents), 'escrow': escrow})
        return {'agreement': pin, 'status': 'ADOPTED', 'replayed': False, 'escrow': escrow, **FLAGS}

    def _reserve(self, agreement, request_id, operation, arguments_sha256, transport, now):
        """Durable intent before dispatch. Returns (row, call, new)."""
        _request(request_id); _now(now)
        pin = _hex(agreement, 'CALL_AGREEMENT_ID')
        with self.ledger.exclusive():
            state = self.ledger.state()
            need(pin in state, 'CALL_AGREEMENT_NOT_ADOPTED')
            row = state[pin]; body = row['body']
            need(body['transport'] == transport, 'CALL_AGREEMENT_SCOPE')
            old = row['calls'].get(request_id)
            if old is not None:
                need(old['operation'] == operation and old['arguments_sha256'] == arguments_sha256, 'CALL_REQUEST_REUSED')
                return row, old, False
            need(row['settled'] is None, 'CALL_AGREEMENT_CLOSED')
            _window(body, now); _scope(body, operation)
            need(len(row['order']) < body['max_calls'], 'CALL_AGREEMENT_EXHAUSTED')
            if self.custody is not None and getattr(self.custody, 'contract', None) is not None:
                need(self.custody.contract(body['escrow']['policy']).get('status') == 'LOCKED', 'CALL_AGREEMENT_CLOSED')
            call = {'request_id': request_id, 'operation': operation, 'arguments_sha256': arguments_sha256, 'at': now}
            self.ledger.store.append('CALL_INTENT', pin, call)
            return row, {**call, 'state': 'PENDING', 'outcome': None}, True

    def _record(self, agreement, body, transport, call, state, result, *, error=None, rpc_error=False):
        countersigned, receipt, check = 'MISSING', read_receipt(transport, result), None
        if receipt is not None:
            try:
                check = verify_receipt(receipt, transport=transport, server=body['server'], agreement=agreement,
                                       request_id=call['request_id'], operation=call['operation'],
                                       arguments_sha256=call['arguments_sha256'], result=result,
                                       charge=body['price'], max_sequence=body['max_calls'])
                countersigned = 'VERIFIED'
            except NativeError as failure:
                countersigned = 'INVALID:' + failure.code
        verdict = evaluate(body['acceptance'], transport, result, rpc_error=rpc_error) if state == 'RECORDED' else None
        charged = state == 'RECORDED' and countersigned == 'VERIFIED' and verdict['verdict'] == 'ACCEPTED'
        outcome = {'request_id': call['request_id'], 'state': state, 'countersignature': countersigned,
                   'receipt': receipt if countersigned == 'VERIFIED' else None,
                   'sequence': None if check is None else check['sequence'],
                   'result_sha256': None if result is None else result_hash(transport, result),
                   'verdict': None if verdict is None else verdict['verdict'],
                   'criteria': None if verdict is None else verdict['results'],
                   'charge': body['price']['amount'] if charged else 0, 'error': error}
        self.ledger.append('CALL_OUTCOME', agreement, outcome)
        return outcome

    def _answer(self, agreement, outcome, replayed, result=None):
        return {'agreement': agreement, 'request_id': outcome['request_id'], 'state': outcome['state'],
                'countersignature': outcome['countersignature'], 'verdict': outcome['verdict'],
                'criteria': deepcopy(outcome['criteria']), 'charge': outcome['charge'], 'error': deepcopy(outcome['error']),
                'replayed': replayed, 'result': deepcopy(result), 'untrusted': True,
                'statement': 'COUNTERSIGNED_RECEIPT_IS_EVIDENCE; SETTLEMENT_NEEDS_THE_CUSTODY_QUORUM', **FLAGS}

    def call_mcp(self, client, alias, agreement, tool, arguments, *, request_id, now):
        """One tier-2 MCP call through an installed ToolClient whose server opts into agreement metadata."""
        args_hash = arguments_hash('MCP', arguments)
        row, call, new = self._reserve(agreement, request_id, tool, args_hash, 'MCP', now)
        if call['outcome'] is not None:
            held = client.retained_result(alias, request_id) if call['outcome']['state'] == 'RECORDED' else {'result': None}
            return self._answer(agreement, call['outcome'], True, held['result'])
        body = row['body']
        server = client.servers.get(alias) if hasattr(client, 'servers') else None
        need(type(server) is dict and server.get('pins', {}).get(tool) == body['target']['tools'][tool]
             and server.get('agreement_metadata') is True, 'CALL_AGREEMENT_PIN')
        try:
            reply = client.call(alias, tool, arguments, request_id=request_id, agreement=reference(agreement))
        except ValueError as error:
            outcome = self._record(agreement, body, 'MCP', call, 'NOT_SENT', None, error=str(error))
            return self._answer(agreement, outcome, False)
        held = client.retained_result(alias, request_id)
        state = 'RECORDED' if reply['receipt']['body']['outcome'] in ('RECORDED', 'OBSERVED') else 'UNKNOWN'
        outcome = self._record(agreement, body, 'MCP', call, state, held['result'] if state == 'RECORDED' else None)
        return self._answer(agreement, outcome, bool(reply.get('replayed')), held['result'])

    def reconcile_mcp(self, client, alias, agreement, request_id):
        """After the owner's observer resolved an UNKNOWN ToolClient call, record what it now holds."""
        state = self.ledger.state()
        _hex(agreement, 'CALL_AGREEMENT_ID')
        need(agreement in state and request_id in state[agreement]['calls'], 'CALL_AGREEMENT_NOT_ADOPTED')
        row = state[agreement]; call = row['calls'][request_id]
        if call['state'] not in ('PENDING', 'UNKNOWN'):
            return self._answer(agreement, call['outcome'], True)
        held = client.retained_result(alias, request_id)
        if held['state'] not in ('RECORDED', 'OBSERVED'):
            return {'agreement': agreement, 'request_id': request_id, 'state': 'UNKNOWN', 'replayed': True, **FLAGS}
        outcome = self._record(agreement, row['body'], 'MCP', call, 'RECORDED', held['result'])
        return self._answer(agreement, outcome, False, held['result'])

    def call_a2a(self, client, agreement, method, params, *, request_id, now):
        """One tier-2 A2A request through an installed A2AHTTPClient pinned to the agreed card."""
        _object(params, 'CALL_ARGUMENTS')
        args_hash = arguments_hash('A2A', params)
        row, call, new = self._reserve(agreement, request_id, method, args_hash, 'A2A', now)
        body = row['body']
        need(getattr(client, 'card', None) == body['target']['card'], 'CALL_AGREEMENT_PIN')
        if call['outcome'] is not None:
            return self._answer(agreement, call['outcome'], True)
        sent = deepcopy(params)
        sent.setdefault('metadata', {})[A2A_AGREEMENT] = {'agreement': reference(agreement), 'request_id': request_id}
        try:
            reply = client.call(method, sent, request_id)
        except ValueError as error:
            state = 'UNKNOWN' if 'UNKNOWN' in str(error) else 'NOT_SENT'
            outcome = self._record(agreement, body, 'A2A', call, state, None, error=str(error))
            return self._answer(agreement, outcome, False)
        response = reply['response']
        if 'error' in response:
            outcome = self._record(agreement, body, 'A2A', call, 'REFUSED', None, error=deepcopy(response['error']))
            return self._answer(agreement, outcome, False)
        result = response['result']
        outcome = self._record(agreement, body, 'A2A', call, 'RECORDED', result)
        return self._answer(agreement, outcome, False, result)

    def status(self, agreement):
        state = self.ledger.state()
        _hex(agreement, 'CALL_AGREEMENT_ID')
        need(agreement in state, 'CALL_AGREEMENT_NOT_ADOPTED')
        row = state[agreement]; body = row['body']
        counts = {}
        for request_id in row['order']:
            call = row['calls'][request_id]; outcome = call['outcome']
            if outcome is None or outcome['verdict'] is None:
                label = call['state']
            else:
                label = outcome['verdict'] if outcome['countersignature'] == 'VERIFIED' else 'UNCOUNTERSIGNED'
            counts[label] = counts.get(label, 0) + 1
        charge = sum(row['calls'][r]['outcome']['charge'] for r in row['order'] if row['calls'][r]['outcome'])
        return {'agreement': agreement, 'calls_used': len(row['order']), 'max_calls': body['max_calls'],
                'counts': counts, 'charge': charge, 'unit': body['price']['unit'], 'escrow': body['escrow']['amount'],
                'settled': row['settled'] is not None, 'head': row['head'],
                'basis': 'COUNTERSIGNED_AND_ACCEPTED_CALLS_ONLY; UNKNOWN_NEVER_CHARGED', **FLAGS}

    def settlement(self, agreement):
        """The exact custody payout to sign: the server earns accepted calls, the caller gets the rest."""
        summary = self.status(agreement)
        body = self.ledger.state()[agreement]['body']
        need(self.custody is not None and getattr(self.custody, 'ref', None) == body['escrow']['adapter'], 'CALL_AGREEMENT_CUSTODY')
        charge = summary['charge']; refund = body['escrow']['amount'] - charge
        payouts = {actor: amount for actor, amount in ((body['server'], charge), (body['caller'], refund)) if amount}
        request = {'action': 'PAYOUT', 'escrow': body['escrow']['policy'], 'payouts': payouts}
        effect = digest(SETTLEMENT_LABEL, {'agreement': agreement})
        payload = self.custody.assent_payload(effect, request)
        return {'agreement': agreement, 'effect': effect, 'request': request, 'payload': payload,
                'statement': summary, 'signature_created': False, **FLAGS}

    def settle(self, agreement, approvals):
        """Execute the prepared payout once with the quorum's approvals; an exact retry replays."""
        prepared = self.settlement(agreement)
        state = self.ledger.state()[agreement]
        if state['settled'] is not None:
            need(canonical(state['settled']['request']) == canonical(prepared['request']), 'CALL_SETTLEMENT_CHANGED')
            return {'agreement': agreement, 'status': 'SETTLED', 'replayed': True,
                    'receipt': deepcopy(state['settled']['receipt']), **FLAGS}
        receipt = self.custody.execute(prepared['effect'], {**prepared['request'], 'approvals': deepcopy(approvals)})
        need(type(receipt) is dict and receipt.get('status') == 'OBSERVED', 'CALL_CUSTODY_PAYOUT')
        value = receipt.get('value') or {}
        need(value.get('action') == 'PAYOUT' and canonical(value.get('payouts')) == canonical(prepared['request']['payouts']),
             'CALL_SETTLEMENT_CHANGED')
        self.ledger.append('CALL_SETTLED', agreement, {'effect': prepared['effect'], 'request': prepared['request'],
                                                       'receipt': deepcopy(receipt)})
        return {'agreement': agreement, 'status': 'SETTLED', 'replayed': False, 'receipt': receipt,
                'statement': prepared['statement'], **FLAGS}

    def intent_verifier(self, *, now):
        """A ProvenanceGate tier-2 hook: True only for an adopted, open agreement covering the intent."""
        _now(now)
        def check(intent):
            text = intent.get('agreement') if type(intent) is dict else None
            if type(text) is not str or not text.startswith(URN) or HEX.fullmatch(text[len(URN):]) is None:
                return False
            row = self.ledger.state().get(text[len(URN):])
            if row is None or row['settled'] is not None:
                return False
            body = row['body']
            return (body['transport'] == 'MCP' and body['target']['tools'].get(intent.get('tool')) == intent.get('descriptor')
                    and body['not_before'] <= now < body['expires'] and len(row['order']) < body['max_calls'])
        return check


def describe():
    return {'profile': PROFILE, 'receipt': RECEIPT, 'labels': {'assent': ASSENT_LABEL, 'receipt': RECEIPT_LABEL},
            'tiers': {'0': 'covenant_agent.provenance_policy owner policy', '1': 'server countersigned receipts',
                      '2': 'call agreement signed by caller and server before the first call'},
            'carriers': {'MCP': {'request': 'params._meta[' + MCP_AGREEMENT + ']', 'result': 'result._meta[' + MCP_RECEIPT + ']'},
                         'A2A': {'request': 'params.metadata[' + A2A_AGREEMENT + ']', 'result': 'result.metadata[' + A2A_RECEIPT + ']'}},
            'criteria': list(KINDS), 'limits': {'max_calls': MAX_CALLS, 'agreement_bytes': MAX_BODY},
            'refusals': sorted(HINTS), 'remediation': dict(HINTS),
            'not_claimed': ['remote effect truth', 'payment outside the installed custody adapter', 'global time',
                            'legal enforceability'], **FLAGS}
