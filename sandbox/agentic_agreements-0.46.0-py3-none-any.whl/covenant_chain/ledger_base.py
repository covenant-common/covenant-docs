"""Leaf helpers shared by the native reducer and its extension modules.

Kept separate from ``app`` so extension modules (economics, federation,
governance and the shielded path through governance) can use them without
importing ``app`` back, which kept ``app`` in an import cycle with the modules
the biomimicry coupling check forbids. ``app`` re-exports every name here, so
existing ``from .app import ...`` callers are unchanged.
"""
from .crypto import digest, integer

RESOURCE_SUPPLY_CAP = 2**32 - 1
# The combined native profile enforces RESOURCE_SUPPLY_CAP at this height and after.
SUPPLY_CAP_ACTIVATION_HEIGHT = 1


def agreement_id(terms):
    return digest('COVENANT-AGREEMENT-0.1', terms)


def amount(table, actor, rid):
    return table.get(actor, {}).get(rid, 0)


def add(table, actor, rid, qty):
    updated = amount(table, actor, rid) + qty
    integer(updated)
    table.setdefault(actor, {})[rid] = updated
