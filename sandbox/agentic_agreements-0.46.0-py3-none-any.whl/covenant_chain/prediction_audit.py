"""Prediction custody identity. Kept off prediction.py so conservation does not import app."""

from collections import defaultdict

from .crypto import integer, need


def check_accounting_deltas(s):
    """Custody and each outcome's supply reconcile over changed records only."""
    custody = defaultdict(int)
    shares = defaultdict(int)
    for market, old, new in s['prediction_markets'].changes():
        for row, signum in ((old, -1), (new, 1)):
            if row:
                integer(row['escrow'])
                integer(row['complete_sets'])
                custody[row['terms']['resource']] += signum * row['escrow']
                for outcome, qty in row['supply'].items():
                    integer(qty)
                    shares[(market, outcome)] -= signum * qty
        if new['status'] == 'FINAL':
            expected = sum(qty * new['settled']['payouts'][o] for o, qty in new['supply'].items())
        else:
            need(all(q == new['complete_sets'] for q in new['supply'].values()), 'PREDICTION_SET_SUPPLY')
            expected = new['complete_sets'] * new['terms']['payout_per_unit']
        need(new['escrow'] == expected, 'PREDICTION_ESCROW')
        if old:
            need(new['terms'] == old['terms'] and new['terms_id'] == old['terms_id'], 'PREDICTION_IMMUTABLE_TERMS')
    for _, old, new in s['prediction_positions'].changes():
        for row, signum in ((old, -1), (new, 1)):
            if row:
                for outcome, qty in row['shares'].items():
                    integer(qty)
                    shares[(row['market'], outcome)] += signum * qty
    for resource, old, new in s['prediction_held'].changes():
        integer(new)
        custody[resource] -= new - (old or 0)
    need(all(v == 0 for v in custody.values()), 'PREDICTION_CUSTODY')
    need(all(v == 0 for v in shares.values()), 'PREDICTION_SHARE_CONSERVATION')
