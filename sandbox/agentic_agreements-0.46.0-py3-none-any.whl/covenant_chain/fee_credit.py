"""Market fee routing. Balances move here so economics does not import market."""

from .balances import add
from .crypto import need


def allocation(state, account, resource, quantity, purpose):
    if purpose in {'MAINTENANCE', 'SERVICE_REWARDS'}:
        config = state['market_config']['active']['body']
        need(account == config['reserve']['account'] and resource == config['reserve']['resource'], 'MARKET_ROUTE_CONTEXT')
        state['market_held'][resource] += quantity
        if purpose == 'MAINTENANCE':
            state['market_reserve'][resource]['available'] += quantity
        else:
            state['market_rewards'][resource] += quantity
    elif quantity:
        for table in ('balances', 'authority_available'):
            add(state[table], account, resource, quantity)
