"""Out-of-band bootstrap bundle: a genesis digest, three peer records and a checkpoint.

The QR payload is the canonical JSON document, bounded to a version-40 binary
symbol. The link form is the same bytes with a covenant: prefix. Parsing the
link decodes those bytes. It does not resolve a name or open a socket.
"""
from __future__ import annotations

import base64
import binascii

from .anchor import checkpoint_digest
from .crypto import canonical, exact, key, loads, need
from .discovery import verify_record

VERSION = 'covenant-bootstrap-bundle/1'
QR_LIMIT = 2953
LINK_PREFIX = 'covenant:'


def build_bootstrap(genesis, peers, checkpoint, now):
    key(genesis)
    need(type(peers) is list and len(peers) == 3, 'BOOTSTRAP_PEERS')
    members = []
    for envelope in peers:
        body = verify_record(envelope, now)
        need(body['member'] not in members, 'BOOTSTRAP_MEMBER')
        members.append(body['member'])
    need(checkpoint['chain_id'] == genesis, 'BOOTSTRAP_CHECKPOINT')
    digest = checkpoint_digest(checkpoint)
    document = {'v': VERSION, 'genesis': genesis, 'peers': peers, 'checkpoint': checkpoint}
    raw = canonical(document)
    need(len(raw) <= QR_LIMIT, 'BOOTSTRAP_QR_SIZE')
    link = LINK_PREFIX + base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')
    return {
        'document': document,
        'qr': raw,
        'link': link,
        'checkpoint_digest': digest.hex(),
        'members': members,
        'fetched': False,
    }


def verify_bootstrap(document, now):
    exact(document, 'v genesis peers checkpoint')
    need(document['v'] == VERSION, 'BOOTSTRAP_VERSION')
    built = build_bootstrap(document['genesis'], document['peers'], document['checkpoint'], now)
    need(built['document'] == document, 'BOOTSTRAP_CANONICAL')
    return built


def parse_link(link, now):
    """Decode a covenant: link. The bytes are the bundle; nothing is fetched."""
    need(type(link) is str and link.startswith(LINK_PREFIX) and len(link) <= 8000, 'BOOTSTRAP_LINK')
    payload = link[len(LINK_PREFIX):]
    pad = '=' * (-len(payload) % 4)
    try:
        raw = base64.urlsafe_b64decode(payload + pad)
    except (ValueError, binascii.Error) as exc:
        raise ValueError('BOOTSTRAP_LINK') from exc
    document = loads(raw)
    report = verify_bootstrap(document, now)
    need(report['fetched'] is False, 'BOOTSTRAP_FETCH')
    return report
