"""Committee-certified light proofs; no transaction replay at the recipient.

Security is inherited from each adopted committee, including historical key
custody. Does not prove latest head, data availability, or application correctness
independently of the honest-quorum assumption. Caller pins genesis and freshness.
"""
from covenant_chain.crypto import genesis_id
from copy import deepcopy
from .crypto import exact, need, integer, digest, verify, verification_key, key, canonical
from .state import verify_record, prove_record
from . import app

PROFILE = 'covenant-native-light/0.1'
MODERN = {app.LIFECYCLE_VERSION, app.SHIELDED_VERSION, app.ECOSYSTEM_VERSION, app.MISSION_VERSION,app.FEDERATION_VERSION,app.EXTENSIBLE_VERSION,app.ECONOMIC_VERSION,app.CONFIDENTIAL_VERSION,app.CONTINUITY_VERSION,app.MARKET_VERSION,app.REVIEW_VERSION,app.PREDICTION_VERSION,app.UPGRADE_VERSION,app.MIGRATION_VERSION}
MAX_TRANSITIONS = 128

def committee(active):
    exact(active, 'epoch activation validators faults event')
    integer(active['epoch']); integer(active['activation'], True); integer(active['faults'], True)
    members = active['validators']
    need(type(members) is dict and len(members) == 3*active['faults']+1 and len(members) <= 64, 'LIGHT_COMMITTEE')
    for name, pub in members.items():
        need(type(name) is str and 0 < len(name) <= 80, 'LIGHT_MEMBER'); verification_key(pub)
    need(len({digest('COVENANT-VALIDATOR-KEY', p) for p in members.values()}) == len(members), 'LIGHT_DUPLICATE_KEY')
    if active['event'] is not None: key(active['event'])

def certified_record(frame, chain, active, floor):
    exact(frame, 'proof checkpoint')
    exact(frame['checkpoint'], 'block certificate'); block = frame['checkpoint']['block']; cert = frame['checkpoint']['certificate']
    exact(block, 'chain height parent txs state_root'); exact(cert, 'height round block_id votes')
    integer(block['height'], True); integer(cert['height'], True); integer(cert['round'])
    key(block['parent']); key(block['state_root'])
    need(block['chain'] == chain and cert['height'] == block['height'] and block['height'] >= max(floor, active['activation']), 'LIGHT_HEIGHT_CONTEXT')
    need(type(block['txs']) is list and len(block['txs']) <= 32, 'LIGHT_BLOCK_SIZE')
    bid = digest('COVENANT_CHAIN_BLOCK', block); need(cert['block_id'] == bid, 'BLOCK_ID')
    votes = cert['votes']; members = active['validators']
    need(type(votes) is list and 2*active['faults']+1 <= len(votes) <= len(members), 'QUORUM')
    seen = set()
    for msg in votes:
        exact(msg, 'kind body signer signature'); who = msg['signer']
        need(who in members and who not in seen, 'SIGNER'); seen.add(who)
        body = {'chain': chain, 'height': block['height'], 'round': cert['round'], 'block_id': bid}
        need(msg['kind'] == 'precommit' and msg['body'] == body, 'VOTE_CONTEXT')
        verify(members[who], 'COVENANT_CHAIN_PRECOMMIT', body, msg['signature'])
    need(frame['proof']['descriptor']['chain'] == chain, 'PROOF_CHAIN')
    need(frame['proof']['descriptor']['protocol'] in MODERN, 'LIGHT_PROTOCOL')
    return verify_record(frame['proof'], block['state_root'])

def export_light_bundle(genesis, entries, table, record_key, from_epoch=0):
    """Producer replays history to export proof material; consumer does not."""
    integer(from_epoch)
    need(genesis['protocol'] in MODERN and type(entries) is list and entries, 'LIGHT_HISTORY')
    chain = genesis_id(genesis)
    from .proofs import verify_history
    verified = verify_history(genesis, entries, chain)
    transitions = build_transition_index(genesis, entries, from_epoch)
    return export_checkpoint_bundle(genesis,verified['state'],entries[-1],transitions,table,record_key,from_epoch)

def build_transition_index(genesis, entries, from_epoch=0):
    """Disposable producer index; caller independently validates its input history."""
    integer(from_epoch)
    state = app.genesis_state(genesis); transitions = []
    for entry in entries:
        epoch = state['domain']['active']['epoch']
        state=app.begin_block(state,entry['block']['height'])
        for tx in entry['block']['txs']: state = app.apply_transaction(state, tx, entry['block']['height'])
        if state['domain']['active']['epoch'] != epoch and state['domain']['active']['epoch'] > from_epoch:
            transitions.append({'proof': prove_record(state, 'domain', 'active'), 'checkpoint': deepcopy(entry)})
    return transitions

def export_checkpoint_bundle(genesis, state, head, transitions, table, record_key, from_epoch=0):
    """Export from a node's already-validated state and disposable epoch index."""
    integer(from_epoch)
    chain=genesis_id(genesis)
    need(genesis['protocol'] in MODERN and state['chain']==chain and app.state_hash(state)==head['block']['state_root'], 'LIGHT_CHECKPOINT_STATE')
    transitions=[frame for frame in transitions if frame['proof']['path'][-1]['value']['epoch']>from_epoch]
    need(len(transitions) <= MAX_TRANSITIONS, 'LIGHT_TRANSITION_LIMIT')
    need(from_epoch <= state['domain']['active']['epoch'], 'LIGHT_START_EPOCH')
    # If final block is succession, its certificate belongs to predecessor.
    need(state['domain']['active']['activation'] <= head['block']['height'], 'LIGHT_WAIT_FOR_SUCCESSOR_CHECKPOINT')
    return {'profile': PROFILE, 'chain': chain, 'transitions': transitions,
            'active': {'proof': prove_record(state, 'domain', 'active'), 'checkpoint': deepcopy(head)},
            'record': {'proof': prove_record(state, table, record_key), 'checkpoint': deepcopy(head)}}

def verify_light_bundle(genesis, bundle, expected_chain, minimum_height, expected_table, expected_key):
    """Fresh genesis-pinned verification. Persist a prior head separately for rollback protection."""
    return _verify_light_bundle(genesis,bundle,expected_chain,minimum_height,expected_table,expected_key)

def _verify_light_bundle(genesis, bundle, expected_chain, minimum_height, expected_table, expected_key, starting_active=None):
    # starting_active is exclusively recipient-owned, previously verified security state.
    integer(minimum_height); canonical(bundle); exact(bundle, 'profile chain transitions active record')
    need(genesis['protocol'] in MODERN and genesis_id(genesis) == expected_chain, 'GENESIS_PIN')
    # Validate genesis rules, including key admission, without replaying history.
    app.genesis_state(genesis)
    need(bundle['profile'] == PROFILE and bundle['chain'] == expected_chain, 'LIGHT_CONTEXT')
    transitions = bundle['transitions']; need(type(transitions) is list and len(transitions) <= MAX_TRANSITIONS, 'LIGHT_TRANSITION_LIMIT')
    active = {'epoch': 0, 'activation': 1, 'validators': deepcopy(genesis['validators']), 'faults': genesis['faults'], 'event': None}
    if starting_active is not None: active = deepcopy(starting_active)
    committee(active)
    for frame in transitions + [bundle['active'], bundle['record']]:
        need(frame['proof']['descriptor']['protocol'] == genesis['protocol'], 'LIGHT_PROTOCOL_PIN')
    for frame in transitions:
        need(frame['proof']['table'] == 'domain' and frame['proof']['key'] == 'active', 'LIGHT_EPOCH_RECORD')
        successor = certified_record(frame, expected_chain, active, active['activation']); committee(successor)
        height = frame['checkpoint']['block']['height']
        need(successor['epoch'] == active['epoch']+1 and successor['activation'] == height+1, 'LIGHT_EPOCH_SEQUENCE')
        # Bind transition metadata to the transaction included in this certified block.
        matches = [tx for tx in frame['checkpoint']['block']['txs']
                   if tx.get('body', {}).get('op') == 'DOMAIN_SUCCESSION' and app.transaction_id(tx) == successor['event']]
        need(len(matches) == 1, 'LIGHT_SUCCESSION_EVENT')
        p = matches[0]['body']['payload']
        need(p['epoch'] == successor['epoch'] and p['validators'] == successor['validators'] and p['faults'] == successor['faults'] and p['activation'] in {'NEXT_HEIGHT', successor['activation']}, 'LIGHT_SUCCESSION_CONTEXT')
        from .lifecycle import approved
        body = {k:v for k,v in p.items() if k not in {'approvals','acceptances'}}; body['chain'] = expected_chain
        approved(p['approvals'], set(active['validators']), 2*active['faults']+1, 'COVENANT-SUCCESSION-0.3', body, lambda who:active['validators'][who])
        approved(p['acceptances'], set(successor['validators']), 2*successor['faults']+1, 'COVENANT-SUCCESSION-ACCEPT-0.3', body, lambda who:successor['validators'][who])
        active = deepcopy(successor)
    frame = bundle['active']
    need(frame['proof']['table'] == 'domain' and frame['proof']['key'] == 'active', 'LIGHT_EPOCH_RECORD')
    need(certified_record(frame, expected_chain, active, minimum_height) == active, 'LIGHT_ACTIVE_MISMATCH')
    record = bundle['record']; need(record['checkpoint'] == frame['checkpoint'], 'LIGHT_HEAD_MISMATCH')
    need(record['proof']['table'] == expected_table and record['proof']['key'] == expected_key, 'LIGHT_REQUESTED_RECORD')
    value = certified_record(record, expected_chain, active, minimum_height)
    return {'value': value, 'chain': expected_chain, 'height': frame['checkpoint']['block']['height'],
            'head': frame['checkpoint']['certificate']['block_id'], 'epoch': active['epoch'], 'active_committee': deepcopy(active),
            'assurance': 'COMMITTEE_CERTIFIED', 'history_replayed': False,
            'freshness': 'RECIPIENT_HEIGHT_FLOOR_ONLY', 'transition_proofs': len(transitions)}

def pin_fork(genesis, entries):
    """Pin one history. A divergent sibling is a different fork."""
    from .proofs import verify_history
    chain = genesis_id(genesis)
    need(type(entries) is list and entries, 'FORK_PIN')
    verify_history(genesis, entries, chain)
    blocks = []
    for entry in entries:
        block = entry['block']
        bid = entry['certificate']['block_id']
        key(bid)
        need(bid == digest('COVENANT_CHAIN_BLOCK', block), 'FORK_PIN')
        blocks.append(bid)
    custody = digest('COVENANT-FORK-PIN-0.15', {'chain': chain, 'blocks': blocks})
    return {'v': 'covenant-fork-pin/0.15', 'chain': chain, 'custody': custody, 'blocks': blocks, 'head': blocks[-1]}


def require_fork(pin, genesis, entries):
    """Accept an extension of the pinned fork and reject a sibling history."""
    exact(pin, 'v chain custody blocks head')
    need(pin['v'] == 'covenant-fork-pin/0.15', 'FORK_PIN')
    fresh = pin_fork(genesis, entries)
    need(pin['chain'] == fresh['chain'], 'FORK_PIN')
    pinned = pin['blocks']
    live = fresh['blocks']
    need(type(pinned) is list and pinned and pinned == list(pinned), 'FORK_PIN')
    limit = min(len(pinned), len(live))
    need(pinned[:limit] == live[:limit], 'FORK_PIN')
    need(pin['head'] == pinned[-1], 'FORK_PIN')
    need(pin['custody'] == digest('COVENANT-FORK-PIN-0.15', {'chain': pin['chain'], 'blocks': pinned}), 'FORK_PIN')
    return fresh


class LightClient:
    """Recipient-owned durable anti-rollback floor, never a latest-head oracle.

    The database is security state: retain/backup it; do not treat it as a cache.
    Calls on one instance must be serialized by its owner.
    """
    def __init__(self, path, genesis, expected_chain):
        import sqlite3
        from .crypto import loads
        need(genesis_id(genesis) == expected_chain, 'GENESIS_PIN')
        self.genesis, self.chain = deepcopy(genesis), expected_chain
        self.db = sqlite3.connect(path)
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS light_pin (id INTEGER PRIMARY KEY CHECK(id=1), chain TEXT NOT NULL, report BLOB)')
        row = self.db.execute('SELECT chain FROM light_pin WHERE id=1').fetchone()
        if row and row[0] != expected_chain:
            self.db.close(); raise ValueError('LIGHT_DATABASE_CONTEXT')
        if row is None: self.db.execute('INSERT INTO light_pin VALUES (1,?,NULL)', (expected_chain,))
        self.db.commit()
    def close(self): self.db.close()
    def canonical_warning(self, pinned_genesis, manifest=None):
        """Pin check. Does not change assess(). A non-canonical genesis returns a loud warning."""
        from .fork_defence import canonical_warning
        return canonical_warning(self.chain, pinned_genesis, manifest)
    def assess(self, bundle, minimum_height, table, record_key):
        from .crypto import loads
        integer(minimum_height)
        try:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.db.execute('SELECT report FROM light_pin WHERE id=1').fetchone()
            prior = loads(row[0]) if row[0] else None
            floor = max(minimum_height, prior['height'] if prior else 0)
            report = _verify_light_bundle(self.genesis, bundle, self.chain, floor, table, record_key,
                                          prior['active_committee'] if prior else None)
            if prior:
                need(report['epoch'] >= prior['epoch'], 'LIGHT_EPOCH_ROLLBACK')
                need(report['height'] != prior['height'] or report['head'] == prior['head'], 'LIGHT_HEAD_EQUIVOCATION')
            pin = {k:report[k] for k in ('height','head','epoch','active_committee')}
            self.db.execute('UPDATE light_pin SET report=? WHERE id=1', (canonical(pin),))
            self.db.commit()
            return report
        except BaseException:
            self.db.rollback(); raise
