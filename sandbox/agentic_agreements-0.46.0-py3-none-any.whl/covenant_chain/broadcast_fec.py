"""Content-addressed FEC chunks for one-way media. Any k of the n chunks rebuild the bytes.

A receiver on a satellite data broadcast, a radio net or a file passed along
cannot ask for a chunk again. The bytes travel as systematic Reed-Solomon
symbols, RFC 5510 FEC Encoding ID 5 over GF(2^8) with one source block, so
any k of the n chunks rebuild them. Each chunk carries the Encoding ID 5 FEC
object information and payload id, and an RFC 9162 audit path to the broadcast
id: a damaged or injected chunk fails alone, before any decoding.

This is a carrier. Carrier success never certifies settlement; a rebuilt
payload still needs its own AAP checks (checkpoint_broadcast for light-client
material, the envelope checks for an offline packet).
"""
import hashlib
import struct

from covenant_language.finality import inclusion_proof, leaf_hash, merkle_root, verify_inclusion

from . import crypto as c, dtn_bundle as bp
from .scale.erasure import _EXP, _div, _mul

VERSION = 'covenant-broadcast-chunk/0.1'
MAGIC = b'CVB1'
HEADER = struct.Struct('!4s32s6sHBB3sBB')
LEAF_LABEL = b'COVENANT-BROADCAST-CHUNK-0.1\0'
MAX_PAYLOAD = 1 << 20
MAX_SYMBOL = 8192
MAX_SYMBOLS = 255
MAX_DEPTH = 8
BROADCAST_EID = 'dtn://aap-broadcast/~checkpoints'
_TABLES = None


def _scale(symbol, coefficient):
    """coefficient * symbol in GF(2^8), one bytes.translate per symbol."""
    global _TABLES
    if _TABLES is None:
        _TABLES = [bytes(_mul(a, b) for b in range(256)) for a in range(256)]
    return int.from_bytes(symbol if coefficient == 1 else symbol.translate(_TABLES[coefficient]), 'big')


def _weights(points):
    rows = []
    for i, point in enumerate(points):
        weight = 1
        for j, other in enumerate(points):
            if i != j:
                weight = _mul(weight, point ^ other)
        rows.append(weight)
    return rows


def _combine(symbols, points, weights, x, size):
    """The interpolating polynomial through (points, symbols) evaluated at x."""
    whole = 1
    for point in points:
        whole = _mul(whole, x ^ point)
    total = 0
    for symbol, point, weight in zip(symbols, points, weights):
        coefficient = _div(whole, _mul(x ^ point, weight))
        if coefficient:
            total ^= _scale(symbol, coefficient)
    return total.to_bytes(size, 'big')


def _encode(source, n, size):
    """RFC 5510 section 8: GM = V(k,k)^-1 * V(k,n), v(i,j) = alpha^(i*j).

    Encoding symbol j is P(alpha^j) for the polynomial P of degree < k with
    P(alpha^i) = source symbol i, so symbols 0..k-1 are the source itself.
    """
    points = [_EXP[i] for i in range(len(source))]
    weights = _weights(points)
    return source + [_combine(source, points, weights, _EXP[j], size) for j in range(len(source), n)]


def _decode(received, k, size):
    chosen = sorted(received)[:k]
    if chosen == list(range(k)):
        return [received[i] for i in chosen]
    points = [_EXP[esi] for esi in chosen]
    weights = _weights(points)
    symbols = [received[esi] for esi in chosen]
    return [received[i] if i in received else _combine(symbols, points, weights, _EXP[i], size) for i in range(k)]


def _oti(length, size, k, n):
    """FEC Object Transmission Information for Encoding ID 5: L 48 bits, E 16, B 8, max_n 8."""
    return length.to_bytes(6, 'big') + size.to_bytes(2, 'big') + bytes([k, n])


def _leaf(oti, esi, symbol):
    # FEC Payload ID: source block number (24 bits, always 0 here) and ESI (8 bits).
    return hashlib.sha256(LEAF_LABEL + oti + bytes([0, 0, 0, esi]) + symbol).hexdigest()


def _root(oti, symbols):
    return merkle_root([leaf_hash(_leaf(oti, esi, symbol)) for esi, symbol in enumerate(symbols)])


def encode_chunks(payload, *, symbol_size=1024, repair=None):
    """Chunks for any bytes. Default repair: as many repair as source symbols, within 255."""
    c.need(type(payload) is bytes and 0 < len(payload) <= MAX_PAYLOAD, 'BROADCAST_PAYLOAD_SIZE')
    c.need(type(symbol_size) is int and 1 <= symbol_size <= MAX_SYMBOL, 'BROADCAST_SYMBOL_SIZE')
    k = -(-len(payload) // symbol_size)
    c.need(k <= MAX_SYMBOLS, 'BROADCAST_TOO_MANY_SYMBOLS')
    repair = min(k, MAX_SYMBOLS - k) if repair is None else repair
    c.need(type(repair) is int and 0 <= repair <= MAX_SYMBOLS - k, 'BROADCAST_REPAIR')
    padded = payload + bytes(k * symbol_size - len(payload))
    symbols = _encode([padded[i * symbol_size:(i + 1) * symbol_size] for i in range(k)], k + repair, symbol_size)
    oti = _oti(len(payload), symbol_size, k, k + repair)
    leaves = [_leaf(oti, esi, symbol) for esi, symbol in enumerate(symbols)]
    root = bytes.fromhex(merkle_root([leaf_hash(leaf) for leaf in leaves]))
    chunks = []
    for esi, symbol in enumerate(symbols):
        path = inclusion_proof(leaves, esi)['path']
        chunks.append(HEADER.pack(MAGIC, root, oti[:6], symbol_size, k, k + repair, bytes(3), esi, len(path)) +
                      b''.join(bytes.fromhex(step) for step in path) + symbol)
    return chunks


def parse_chunk(raw):
    """Check one chunk on its own: header, then the audit path to its broadcast id."""
    c.need(type(raw) is bytes and HEADER.size < len(raw) <= HEADER.size + 32 * MAX_DEPTH + MAX_SYMBOL,
           'BROADCAST_CHUNK_SIZE')
    magic, ref, length, size, k, n, block, esi, depth = HEADER.unpack_from(raw)
    length = int.from_bytes(length, 'big')
    c.need(magic == MAGIC, 'BROADCAST_CHUNK_MAGIC')
    c.need(0 < length <= MAX_PAYLOAD and 1 <= size <= MAX_SYMBOL and k == -(-length // size) and
           1 <= k <= n <= MAX_SYMBOLS and block == bytes(3) and esi < n and depth <= MAX_DEPTH,
           'BROADCAST_CHUNK_HEADER')
    c.need(len(raw) == HEADER.size + 32 * depth + size, 'BROADCAST_CHUNK_LENGTH')
    path = [raw[HEADER.size + 32 * i:HEADER.size + 32 * (i + 1)].hex() for i in range(depth)]
    symbol = raw[HEADER.size + 32 * depth:]
    try:
        verify_inclusion(_leaf(_oti(length, size, k, n), esi, symbol), {'index': esi, 'size': n, 'path': path},
                         ref.hex())
    except ValueError:
        raise ValueError('BROADCAST_CHUNK_PROOF') from None
    return {'broadcast': ref.hex(), 'length': length, 'symbol_size': size, 'k': k, 'n': n, 'esi': esi,
            'symbol': symbol}


def _rebuild(ref, length, size, k, n, received):
    source = _decode(received, k, size)
    oti = _oti(length, size, k, n)
    # The id commits to all n symbols: one payload per broadcast id, whatever subset arrived.
    c.need(_root(oti, _encode(source, n, size)) == ref, 'BROADCAST_CODEWORD')
    payload = b''.join(source)
    c.need(not any(payload[length:]), 'BROADCAST_PADDING')
    return payload[:length]


def decode_chunks(chunks):
    """Rebuild one broadcast from any k distinct verified chunks, in any order."""
    c.need(type(chunks) is list and 1 <= len(chunks) <= 4 * MAX_SYMBOLS, 'BROADCAST_CHUNKS')
    shape, received = None, {}
    for raw in chunks:
        chunk = parse_chunk(raw)
        current = tuple(chunk[name] for name in ('broadcast', 'length', 'symbol_size', 'k', 'n'))
        c.need(shape is None or current == shape, 'BROADCAST_MIXED')
        shape = current
        received.setdefault(chunk['esi'], chunk['symbol'])
    c.need(len(received) >= shape[3], 'BROADCAST_TOO_FEW_CHUNKS')
    return _rebuild(*shape, received)


class BroadcastReceiver:
    """Bounded sessions for chunks arriving in any order, mixed with other broadcasts.

    A partial session is normal, not an error. A bad chunk raises its own
    code; the caller drops it and keeps listening. Chunks for a broadcast
    already rebuilt within ``lifetime`` are ignored, so a carousel is cheap.
    """

    def __init__(self, *, max_sessions=4, max_bytes=2 * MAX_PAYLOAD, lifetime=86400):
        c.need(type(max_sessions) is int and 1 <= max_sessions <= 64 and type(max_bytes) is int and
               MAX_PAYLOAD <= max_bytes <= 64 * MAX_PAYLOAD and type(lifetime) is int and
               1 <= lifetime <= 30 * 86400, 'BROADCAST_RECEIVER_POLICY')
        self.max_sessions, self.max_bytes, self.lifetime = max_sessions, max_bytes, lifetime
        self.sessions, self.done = {}, {}

    def expire(self, now):
        c.integer(now)
        self.sessions = {k: v for k, v in self.sessions.items() if v['at'] <= now < v['at'] + self.lifetime}
        self.done = {k: at for k, at in self.done.items() if at <= now < at + self.lifetime}

    def accept(self, raw, *, now):
        chunk = parse_chunk(raw)
        self.expire(now)
        ref = chunk['broadcast']
        if ref in self.done:
            return None
        if ref not in self.sessions:
            used = sum(item['shape'][1] for item in self.sessions.values())
            c.need(len(self.sessions) < self.max_sessions and used + chunk['length'] <= self.max_bytes,
                   'BROADCAST_RECEIVER_QUOTA')
            self.sessions[ref] = {'at': now, 'shape': tuple(chunk[name] for name in (
                'broadcast', 'length', 'symbol_size', 'k', 'n')), 'symbols': {}}
        session = self.sessions[ref]
        session['symbols'].setdefault(chunk['esi'], chunk['symbol'])
        if len(session['symbols']) < chunk['k']:
            return None
        del self.sessions[ref]
        payload = _rebuild(*session['shape'], session['symbols'])
        self.done[ref] = now
        return payload


def chunk_bundles(chunks, *, created_ms, lifetime_ms, source=bp.NONE, destination=BROADCAST_EID,
                  crc_type=bp.CRC32C):
    """Optional BPv7 leg: each chunk as an anonymous bundle to a non-singleton endpoint."""
    c.need(type(chunks) is list and 1 <= len(chunks) <= MAX_SYMBOLS, 'BROADCAST_CHUNKS')
    for raw in chunks:
        parse_chunk(raw)
    return [bp.encode_bundle(raw, source=source, destination=destination, created_ms=created_ms,
                             lifetime_ms=lifetime_ms, sequence=index, crc_type=crc_type,
                             bundle_age_ms=0 if created_ms == 0 else None) for index, raw in enumerate(chunks)]


def bundle_chunk(raw, *, now_ms):
    """The chunk inside one received bundle, checked again on its own."""
    payload = bp.open_bundle(raw, now_ms=now_ms)['payload']
    parse_chunk(payload)
    return payload
