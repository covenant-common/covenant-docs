"""Readable local views over unchanged validated signed-social event semantics."""
from copy import deepcopy
from .agent_network import unpack
from .crypto import key,need


def _heads(events):
    return sorted(set(events)-{p for e in events.values() for p in e['body']['parents']})


def check_heads(network,expected):
    if expected is None:return
    need(type(expected) is list and len(expected)<=64 and expected==sorted(set(expected)),'NETWORK_EXPECTED_HEADS')
    for ref in expected:key(ref)
    need(expected==_heads(network.events()),'NETWORK_LOCAL_HEADS_CHANGED_REVIEW_AGAIN')


def guarded_emit(network,expected_heads=None,**parameters):
    if expected_heads is None:return network.emit(**parameters)
    # Use the same local writer lock as native emit/import so another local
    # process cannot insert observations between this guard and publication.
    with network.store.exclusive():
        check_heads(network,expected_heads)
        return network.emit(**parameters)


def preflight(network,kind,group=None,parents=()):
    """Preview causal context only; deliberately do not sign or emit a test event.

    This does not validate content, merits, payment conditions or publication
    policy. Use expected_heads on a real write to require the observed context.
    """
    from .agent_network import KINDS
    need(type(kind) is str and kind in KINDS,'NETWORK_KIND')
    need(type(parents) in (list,tuple) and len(parents)<=65,'NETWORK_PARENTS')
    events=network.events();refs=set(parents)
    for ref in refs:key(ref);need(ref in events,'NETWORK_PARENT_MISSING')
    own=[(r,e) for r,e in events.items() if e['body']['actor']==network.actor]
    last=max(own,key=lambda v:v[1]['body']['sequence']) if own else None
    if last:refs.add(last[0])
    if group is not None:
        key(group);need(group in events and events[group]['body']['kind']=='GROUP','NETWORK_GROUP')
        refs.add(group)
        same={r:e for r,e in events.items() if r==group or e['body']['group']==group}
        covered={p for e in same.values() for p in network._ancestors(e['body']['parents'],events)}
        refs.update(set(same)-covered)
    covered={p for r in refs for p in network._ancestors(events[r]['body']['parents'],events)}
    refs-=covered
    if last:refs.add(last[0])
    return {'kind':kind,'group':group,'proposed_parents':sorted(refs),'expected_heads':_heads(events),
            'parents_semantics':'ADDITIONAL_REFERENCES_PLUS_CURRENT_GROUP_FRONTIER_AND_ACTOR_PREDECESSOR',
            'scope':'CAUSAL_CONTEXT_ONLY_NOT_CONTENT_POLICY_OR_MERITS_VALIDATION',
            'next':'REVIEW_EXACT_CONTENT_THEN_EXPLICIT_WRITE_WITH_EXPECTED_HEADS',
            'historical_snapshot_selected':False,'signature_created':False,'event_created':False,'execution_authorized':False}


def event(network,reference,compact=False):
    need(type(compact) is bool,'NETWORK_EVENT_COMPACT')
    key(reference);events=network.events();need(reference in events,'NETWORK_EVENT_NOT_FOUND');e=events[reference]
    result={'id':reference,'content':unpack(e['body']),
            'authorship':'VALIDATED_SIGNATURE_AND_CAUSAL_POLICY_NOT_WORLD_TRUTH',
            'freshness':'LOCAL_REPLICA_ONLY','execution_authorized':False}
    if compact:
        result.update(body_without_payload={k:deepcopy(v) for k,v in e['body'].items() if k!='payload'},signature=e['signature'],
                      payload_reconstruction='HEX_OF_COVENANT_AGENTIC_CANONICAL_CONTENT')
    else:result['envelope']=deepcopy(e)
    return result


def timeline(network,group=None,query='',limit=100):
    need(type(query) is str and len(query)<=256,'NETWORK_QUERY');need(type(limit) is int and 1<=limit<=256,'NETWORK_TIMELINE_LIMIT')
    if group is not None:key(group)
    events=network.events();indegree={r:len(e['body']['parents']) for r,e in events.items()};children={r:[] for r in events}
    for r,e in events.items():
        for parent in e['body']['parents']:children[parent].append(r)
    import heapq,json
    ready=[r for r,n in indegree.items() if n==0];heapq.heapify(ready);ordered=[]
    while ready:
        r=heapq.heappop(ready);ordered.append(r)
        for child in children[r]:
            indegree[child]-=1
            if indegree[child]==0:heapq.heappush(ready,child)
    need(len(ordered)==len(events),'NETWORK_PARENT_MISSING_OR_CYCLE');items=[]
    for position,r in enumerate(ordered):
        b=events[r]['body'];content=unpack(b)
        if group is not None and r!=group and b['group']!=group:continue
        if query.casefold() not in json.dumps(content,ensure_ascii=False).casefold():continue
        items.append({'id':r,'causal_position':position,'actor':b['actor'],'actor_sequence':b['sequence'],'kind':b['kind'],
                      'group':b['group'],'parents':deepcopy(b['parents']),'content':content})
    parents={p for e in events.values() for p in e['body']['parents']}
    return {'events':items[-limit:],'total_matching':len(items),'truncated':len(items)>limit,'heads':sorted(set(events)-parents),
            'ordering':'DETERMINISTIC_CAUSAL_TOPOLOGY_WITH_ID_TIES_NOT_WALL_CLOCK',
            'authorship':'VALIDATED_SIGNATURE_AND_CAUSAL_POLICY_NOT_WORLD_TRUTH','freshness':'LOCAL_REPLICA_ONLY','execution_authorized':False}


def view(network,group=None,query=''):
    result=network.view(group,query);events=network.events();roles=[];cases=[]
    for ref,e in events.items():
        b=e['body']
        if group is not None and b['group']!=group:continue
        content=unpack(b)
        if b['kind']=='ROLE_PROPOSE':
            accepts=sorted(r for r,v in events.items() if v['body']['kind']=='ROLE_ACCEPT' and v['body']['group']==b['group'] and unpack(v['body'])['proposal']==ref)
            revocations=sorted(r for r,v in events.items() if v['body']['kind']=='ROLE_REVOKE' and v['body']['group']==b['group'] and unpack(v['body'])['role']==ref)
            roles.append({'id':ref,'group':b['group'],'proposed_by':b['actor'],'terms':content,'acceptance_events':accepts,'revocation_events':revocations,
                          'status':'REVOKED_LOCALLY' if revocations else 'ACCEPTED_LOCALLY' if accepts else 'AWAITING_HOLDER_ACCEPTANCE',
                          'current_permission':'USE_EXACT_CAUSAL_AUTHORIZATION_NOT_THIS_STATUS'})
        elif b['kind']=='DISPUTE':
            accepted=sorted({v['body']['actor'] for v in events.values() if v['body']['kind']=='DISPUTE_ACCEPT' and v['body']['group']==b['group'] and unpack(v['body'])['case']==ref})
            findings=sorted(r for r,v in events.items() if v['body']['kind']=='RESOLVE' and v['body']['group']==b['group'] and unpack(v['body'])['case']==ref)
            cases.append({'id':ref,'group':b['group'],'procedure':content['procedure'],'parties':content['parties'],'arbitrator':content['arbitrator'],
                          'accepted_parties':accepted,'missing_parties':sorted(set(content['parties'])-set(accepted)),'finding_events':findings,
                          'status':'FINDINGS_RECORDED_LOCALLY' if findings else 'ALL_PARTIES_ACCEPTED_LOCALLY' if set(content['parties'])<=set(accepted) else 'AWAITING_PARTY_ACCEPTANCE',
                          'transfer_authority':'NOT_GRANTED','operative_finding':'NOT_AUTOMATICALLY_SELECTED_READ_EXACT_EVENTS_AND_ADOPT_CORRECTIONS'})
    return {**result,'role_proposals':sorted(roles,key=lambda x:x['id']),'case_procedures':sorted(cases,key=lambda x:x['id']),
            'read_exact_event':'covenant_forum_read.event','negotiation_order':'covenant_forum_read.timeline',
            'freshness':'LOCAL_REPLICA_ONLY','execution_authorized':False}
