"""A disconnected order end to end, in test mode: python -m covenant_chain.offline_trade demo

Synthetic keys and a local copy of a covenant-native/0.15 ledger. Before going
offline the buyer's issuer locks a voucher escrow (offline_value). Offline, the
buyer drafts a 0.2 trade that states its risk in plain words, local witnesses
co-sign it, and it travels file -> BPv7 bundle -> Bluetooth frames through two
relays. The supplier checks freshness, timing and the escrow proof, accepts,
answers by QR frames and delivers with evidence. A copied buyer device spends
the same serial at a second, separate supplier. On reconnection each supplier
reconciles exactly once; the second note is slashed through offline_value; the
inboxes merge and find the conflict and the cloned state; the buyer device
recovers its lost newest checkpoint from peers. No network, no real value.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import tempfile
import time

from . import crypto as c, offline as courier, offline_trade as trade
from . import offline_trade_backing as backing, offline_trade_freshness as fresh
from .offline_trade_recovery import DeviceLog, RecoveryInbox, restore

T0 = 1_800_000_000
SCOPE = 'c0' * 32


def _ledger():
    from . import app, economics, light
    from .fixtures import ensure_founder_quorum, prediction_fixture
    keys, pubs, genesis, secrets = prediction_fixture()
    genesis = deepcopy(genesis); genesis['protocol'] = app.SCALE_VERSION
    ensure_founder_quorum(genesis, secrets)
    state = app.genesis_state(genesis)

    def fee(current, height):
        return {'policy': economics.policy_at(current, height)['id'], 'max_amount': 100000, 'sponsor': None}
    opened = app.make_transaction(keys['agent'], state['chain'], state['nonces'].get(pubs['agent'], 0),
                                  'SCALE_OFFLINE_VOUCHER', {'device': pubs['j0'], 'resource': 'payment', 'serials': 4,
                                                            'amount': 2500, 'expiry': 10000},
                                  protocol=app.SCALE_VERSION, actor=pubs['agent'], fee=fee(state, 1))
    book = app.transaction_id(opened)
    state = app.apply_transaction(state, opened, 1)
    block = {'chain': state['chain'], 'height': 1, 'parent': '0' * 64, 'txs': [opened], 'state_root': app.state_hash(state)}
    bid = c.digest('COVENANT_CHAIN_BLOCK', block)
    body = {'chain': state['chain'], 'height': 1, 'round': 0, 'block_id': bid}
    votes = [{'kind': 'precommit', 'body': body, 'signer': name,
              'signature': c.sign(keys[name], 'COVENANT_CHAIN_PRECOMMIT', body)} for name in ('v0', 'v1', 'v2')]
    head = {'block': block, 'certificate': {'height': 1, 'round': 0, 'block_id': bid, 'votes': votes}}
    proof = light.export_checkpoint_bundle(genesis, state, head, [], 'offline_vouchers', book)
    return keys, pubs, genesis, state, book, proof, fee


def _permission(owner_key, buyer, now):
    """The buyer's owner lets the buyer device pay up to 2500 payment units; a signed revocation list dates it."""
    from . import portable_trust as pt
    owner = c.public_key(owner_key)
    mandate = pt.mandate(owner, buyer, ['pay'], ['payment'], 'offline-market', {'payment': 2500}, now - 3600,
                         now + 30 * 86400, 'd1' * 32)
    record = pt.sign_record(mandate['body'], [owner_key])
    revocations = pt.revocations(owner, [], now - 600, now + 86400)
    snapshot = pt.sign_record(revocations['body'], [owner_key])
    return mandate['id'], {'profile': fresh.PORTABLE_TRUST, 'root': owner, 'records': [record],
                           'revocations': [snapshot], 'action': 'pay', 'resource': 'payment',
                           'audience': 'offline-market', 'usage': {'payment': 2500}}


def _order(keys, pubs, chain, book, supplier, nonce, capability, issued_at):
    order = trade.draft(agreement=hashlib.sha256(b'SYNTHETIC repair of one water pump').hexdigest(),
                        buyer=pubs['j0'], supplier=supplier, description='Repair one water pump. Synthetic test order.',
                        quantity=2500, unit='payment', asset='payment', rail='offline_value voucher',
                        issued_at=issued_at, spend_until=issued_at + 3600, redeem_until=issued_at + 86400,
                        delivery_check='The pump runs for ten minutes and a photo is retained.',
                        delivery_due=issued_at + 7200, dispute='Return to the market review desk within seven days.',
                        nonce=nonce, mode='PREALLOCATED_CLAIM', authority_reference=capability,
                        reservation={'issuer': pubs['agent'], 'reference': book, 'serial': '0',
                                     'beneficiary': supplier, 'amount': 2500, 'expires': issued_at + 86400})
    return trade.declare_risk(order, backing='OFFLINE_VALUE', chain=chain, kind='VOUCHER')


def _carry(packet, relay_keys, now, root):
    """file -> relay -> BPv7 bundle -> relay -> Bluetooth frames, shuffled and duplicated on the way."""
    from . import dtn_bundle, offline_ble, offline_carriers
    from .offline_forwarding import hop_receipt, verify_hop_receipt
    raw = c.canonical(packet)
    path = root / 'carried.offline'
    offline_carriers.write_file(path, raw)
    hops = [verify_hop_receipt(hop_receipt(packet, relay_keys[0], at=now), packet,
                               expected_peer=c.public_key(relay_keys[0]), now=now)]
    first = offline_carriers.read_file(path)
    bundle = dtn_bundle.envelope_bundle(courier.exact_load(first), source='ipn:21.1', destination='ipn:22.1',
                                        signing_key=None)
    opened = dtn_bundle.open_envelope_bundle(bundle, scope=SCOPE, allowed_senders={packet['header']['sender']},
                                             now=now + 60)
    hops.append(verify_hop_receipt(hop_receipt(opened['packet'], relay_keys[1], at=now + 60), packet,
                                   expected_peer=c.public_key(relay_keys[1]), now=now + 60))
    frames = offline_ble.frames(c.canonical(opened['packet']), mtu=180)
    noisy = frames + frames[:3]
    random.Random(7).shuffle(noisy)
    seen = {}
    for frame in noisy:
        seen.setdefault(frame, None)
    delivered = offline_ble.payload_of(sorted(seen, key=lambda f: offline_ble.parse_frame(f)[2]))
    return courier.exact_load(delivered), {'carriers': ['FILE', 'BPV7', 'BLE'], 'ble_frames': len(frames),
                                           'duplicates_dropped': 3, 'hops': [h['delivery'] for h in hops],
                                           'unchanged_bytes': delivered == raw}


def _qr_back(order, accepted, supplier):
    """Only the supplier's assent travels back, as QR frames the buyer scans and checks."""
    from . import offline_carriers
    reply = [row for row in accepted['assents'] if row['party'] == supplier]
    frames = offline_carriers.frames(c.canonical(reply), mtu=1024)
    assembler = offline_carriers.Reassembler(max_bytes=131072)
    result = None
    for frame in frames:
        result = assembler.accept(offline_carriers.scan_qr(offline_carriers.qr_png(frame)), now=T0) or result
    agreed = deepcopy(order)
    agreed['assents'] = sorted(order['assents'] + c.loads(result), key=lambda row: row['party'])
    info = trade.inspect(agreed, expected_id=trade.terms_id(order), now=T0 + 400)
    return agreed, len(frames), info['agreement_state']


def run(directory=None):
    started = time.monotonic()
    holder = None
    if directory is None:
        holder = tempfile.TemporaryDirectory()
        directory = holder.name
    root = Path(directory)
    try:
        return _run(root, started)
    finally:
        if holder is not None:
            holder.cleanup()


def _run(root, started):
    keys, pubs, genesis, ledger_state, book, proof, fee = _ledger()
    chain = ledger_state['chain']
    buyer_key, supplier_a, supplier_b = keys['j0'], keys['stranger'], keys['appeal']
    witnesses = [keys['a0'], keys['a1'], keys['a2']]
    group = fresh.group('market witnesses', [c.public_key(k) for k in witnesses], 2)
    capability, authority = _permission(keys['owner'], pubs['j0'], T0)
    policy_a = fresh.recipient_policy(owner=pubs['stranger'], max_age={'PERMISSION': 3600, 'QUALIFICATION': 3600},
                                      require=['PERMISSION'], high_risk_amount=10000, stale_limit=1000, groups=[group])
    policy_b = dict(policy_a, owner=pubs['appeal'])
    checks = {'chains': {chain: genesis}, 'authority_roots': [pubs['owner']]}

    # Disconnected: the buyer's device issues one note and records its head.
    device = DeviceLog(root / 'device', device=pubs['j0'])
    order = _order(keys, pubs, chain, book, pubs['stranger'], 'a1' * 32, capability, T0)
    order = trade.assent(order, buyer_key)
    order = trade.attach(order, 'RESERVATION', proof)
    order = trade.attach(order, 'AUTHORITY', authority)
    order = trade.attach(order, 'INSTRUCTION', backing.spend_instruction(buyer_key, order))
    backup = root / 'device-before-sale.sqlite'
    device.backup(backup)
    order = trade.attach(order, 'HEAD', device.record(buyer_key, order, now=T0 + 10))
    retained_position = device.checkpoint()
    for index, witness in enumerate(witnesses[:2]):
        member = RecoveryInbox(root / ('witness-%d' % index), owner=c.public_key(witness))
        order = trade.attach(order, 'COSIGN', member.cosign(order, witness, now=T0 + 20 + index))
        member.close()

    # Carried through two relays over three media; a hop receipt is custody only.
    shared = hashlib.sha256(b'SYNTHETIC pairing secret, adopted by QR at first meeting').digest()
    packet = trade.seal_bundle(order, signing_key=buyer_key, recipient=pubs['stranger'], shared_key=shared,
                               scope=SCOPE, created=T0 + 30, expires=T0 + 86400)
    carried, carriage = _carry(packet, [keys['a0'], keys['a1']], T0 + 30, root)
    received = trade.receive_bundle(carried, recipient=pubs['stranger'], shared_key=shared, scope=SCOPE,
                                    allowed_senders={pubs['j0']}, expected_id=trade.terms_id(order), now=T0 + 300)
    inbox_a = RecoveryInbox(root / 'supplier-a', owner=pubs['stranger'])
    inbox_a.receive(received, now=T0 + 300)
    accepted = inbox_a.accept(trade.terms_id(order), supplier_a, now=T0 + 310, policy=policy_a, **checks)

    # The supplier's assent goes back as QR frames; delivery and payment events follow.
    agreed, qr_frames, agreement_state = _qr_back(order, accepted['bundle'], pubs['stranger'])
    photo = b'SYNTHETIC photo of the running pump'
    evidence = courier.evidence_attachment(photo, key=shared, scope=SCOPE, media_type='image/jpeg')
    agreed = trade.append_event(agreed, supplier_a, 'DELIVERY_CLAIMED', {'evidence': evidence['sha256']}, at=T0 + 3000)
    agreed = trade.append_event(agreed, buyer_key, 'DELIVERY_ACCEPTED',
                                {'delivery': trade.event_id(agreed['events'][-1])}, at=T0 + 3100)
    agreed = trade.append_event(agreed, buyer_key, 'PAYMENT_SUBMITTED',
                                {'effect': trade.slot_id(agreed),
                                 'instruction': backing.instruction_id(trade.attached(agreed, 'INSTRUCTION')[0])},
                                at=T0 + 3200)
    inbox_a.receive(agreed, now=T0 + 3300)
    lost_ack_retry = inbox_a.receive(agreed, now=T0 + 3400)['status']

    # A copy of the buyer device, restored elsewhere, spends serial 0 again at supplier B.
    restore(backup, root / 'device-copy', name='device.sqlite')
    copy = DeviceLog(root / 'device-copy', device=pubs['j0'])
    second = _order(keys, pubs, chain, book, pubs['appeal'], 'b2' * 32, capability, T0 + 100)
    second = trade.assent(second, buyer_key)
    for kind, value in (('RESERVATION', proof), ('AUTHORITY', authority),
                        ('INSTRUCTION', backing.spend_instruction(buyer_key, second))):
        second = trade.attach(second, kind, value)
    second = trade.attach(second, 'HEAD', copy.record(buyer_key, second, now=T0 + 110))
    copy.close()
    inbox_b = RecoveryInbox(root / 'supplier-b', owner=pubs['appeal'])
    inbox_b.receive(second, now=T0 + 400)
    accepted_b = inbox_b.accept(trade.terms_id(second), supplier_b, now=T0 + 410, policy=policy_b, **checks)

    # Reconnection: one local ledger copy stands in for the adopted validators.
    leg_a = backing.LocalLedgerLeg(ledger_state, submitter_key=supplier_a, height=2, fee=fee)
    first_run = inbox_a.reconcile(leg_a, now=T0 + 90000)
    again = inbox_a.reconcile(leg_a, now=T0 + 90010)
    leg_b = backing.LocalLedgerLeg(leg_a.state, submitter_key=supplier_b, height=leg_a.height, fee=fee)
    run_b = inbox_b.reconcile(leg_b, now=T0 + 90020)
    row = leg_b.state['offline_vouchers'][book]
    merged = inbox_a.merge(inbox_b.trades_from(pubs['j0']), now=T0 + 90030)
    inbox_b.merge(inbox_a.trades_from(pubs['j0']), now=T0 + 90030)

    # The buyer device lost its newest checkpoint: it restores the older backup.
    device.close()
    (root / 'device' / 'device.sqlite').unlink()
    restore(backup, root / 'device-restored', name='device.sqlite')
    restored = DeviceLog(root / 'device-restored', device=pubs['j0'], retained=retained_position)
    blocked = restored.position()['recovery_required']
    heads = inbox_a.retained_heads() + inbox_b.retained_heads()
    recovered = restored.recover(heads, now=T0 + 90040,
                                 trades=inbox_a.trades_from(pubs['j0']) + inbox_b.trades_from(pubs['j0']))
    audit = restored.audit(heads)
    findings = inbox_a.findings()
    metrics = inbox_a.metrics()
    for store in (inbox_a, inbox_b, restored):
        store.close()
    elapsed = round(time.monotonic() - started, 3)
    return {
        'mode': 'TEST_MODE_SYNTHETIC_KEYS_LOCAL_LEDGER_COPY', 'network_used': False, 'real_value_moved': False,
        'carriage': {**carriage, 'reply': 'QR', 'qr_frames': qr_frames}, 'agreement': agreement_state,
        'risk_words': accepted['words'][0], 'freshness': accepted['freshness']['summary'],
        'timing': accepted['timing']['status'], 'issued_by': accepted['issued_by']['basis'],
        'backing': accepted['backing']['words'], 'decision': accepted['decision'],
        'second_supplier_decision': accepted_b['decision'],
        'delivery': trade.inspect(agreed, expected_id=trade.terms_id(agreed), now=T0 + 3400)['delivery'],
        'lost_acknowledgement_retry': lost_ack_retry,
        'reconcile': [r['status'] for r in first_run['results']],
        'reconcile_again': [(r['status'], r['repeat']) for r in again['results']],
        'second_supplier_reconcile': [r['status'] for r in run_b['results']],
        'book_after': {'status': row['status'], 'slash': row.get('slash')},
        'findings': sorted({f['kind'] for f in findings}), 'merge_refused': merged['refused'],
        'device_recovery_required_before_peers': blocked,
        'device_after_recovery': {k: recovered[k] for k in ('sequence', 'recovery_required')},
        'clone_detected_by_device': audit['cloned'],
        'metrics_lines': len(metrics.splitlines()),
        'assurance': backing.LOCAL_ASSURANCE, 'ledger_confirmed': False, 'payment_verified': False,
        'seconds': elapsed,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_chain.offline_trade demo', description=__doc__.split('\n')[0])
    parser.add_argument('--directory', help='keep the synthetic stores in this new private directory')
    args = parser.parse_args(argv)
    print(json.dumps(run(args.directory), indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
