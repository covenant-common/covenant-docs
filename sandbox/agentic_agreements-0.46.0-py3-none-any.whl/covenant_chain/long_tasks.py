"""Long tasks: milestone escrow tranches, signed heartbeats and a compensation clause per effect.

Roadmap runtime milestone "Orchestrate milestones, heartbeats and compensation".
A plan (urn:aap:long-task:0.1) is signed by the buyer, the provider and the
arbiter it names. Each milestone fixes typed acceptance criteria over the
provider's delivery claims, an escrow tranche, a delivery deadline, a
heartbeat cadence with grace, the late-delivery share, and every world effect
the provider may perform with its compensation clause: KEEP (the provider
keeps the stated share of the tranche if the milestone fails after the effect)
or UNDO (the provider must sign that it reversed the effect within the stated
window, or forfeits its share).

All tranches are reserved through the owner-installed custody adapter (for
example DemoEscrowDesk) before work starts, one escrow per milestone; each is
paid out once, with the custody quorum's approvals, by the outcome the plan
fixes. Milestones run in order; a failure cancels the ones after it.

Party events (heartbeats, effects, deliveries, reviews, disputes, decisions)
are signed statements: they prove who said what, not what happened. This
runtime judges missed heartbeats and deadlines with the owner-installed
clock, records each judgment, and replays deterministically from its
hash-chained journal. Custody operations are journaled before they run and
reconciled by observing the adapter after a crash, so nothing is paid twice.
A counterparty cannot install the clock, the adapter or a key.
"""
from copy import deepcopy
import re

from covenant_agent.errors import NativeError

from .crypto import canonical, digest, public_key, sign, verify
from .workflow_store import WorkflowStore

PROFILE = 'urn:aap:long-task:0.1'
EVENT = 'urn:aap:long-task-event:0.1'
ASSENT_LABEL = 'AAP-LONG-TASK-ASSENT-0.1'
ID_LABEL = 'AAP-LONG-TASK-ID-0.1'
EVENT_LABEL = 'AAP-LONG-TASK-EVENT-0.1'
EVENT_ID_LABEL = 'AAP-LONG-TASK-EVENT-ID-0.1'
EFFECT_LABEL = 'AAP-LONG-TASK-CUSTODY-EFFECT-0.1'
ROLES = ('BUYER', 'PROVIDER', 'ARBITER')
ACTIONS = {'HEARTBEAT': 'PROVIDER', 'EFFECT': 'PROVIDER', 'UNDONE': 'PROVIDER', 'DELIVER': 'PROVIDER',
           'ACCEPT': 'BUYER', 'REJECT': 'BUYER', 'DISPUTE': None, 'DECIDE': 'ARBITER'}
CRITERIA = ('BUYER_REVIEW', 'CONTENT_SHA256', 'EQUALS', 'MAX', 'MIN', 'PRESENT')
COMPENSATION = ('KEEP', 'UNDO')
FIELDS = 'profile buyer provider arbiter custody milestones issued_at expires nonce'
MILESTONE_FIELDS = 'id deliverable acceptance tranche due heartbeat late effects redeliveries'
MAX = 2**53 - 1
MAX_MILESTONES = 16
MAX_EFFECTS = 8
HEX = re.compile(r'[0-9a-f]{64}\Z')
NAME = re.compile(r'[a-z][a-z0-9_-]{0,31}\Z')
FLAGS = {'execution_authorized': False, 'payment_authorized': False, 'world_truth_verified': False}

HINTS = {
    'LONG_TASK_FIELDS': ('Use exactly: profile buyer provider arbiter custody milestones issued_at expires nonce; '
                         'each milestone exactly: id deliverable acceptance tranche due heartbeat late effects '
                         'redeliveries.'),
    'LONG_TASK_PROFILE': 'Use profile urn:aap:long-task:0.1. Another version needs its own reviewed reader.',
    'LONG_TASK_KEY': 'Name buyer, provider and arbiter by three distinct 64-hex Ed25519 public keys.',
    'LONG_TASK_CUSTODY': 'Name the installed custody adapter by its manifest id and the unit it holds; the adapter must build its own escrow policies.',
    'LONG_TASK_MILESTONES': 'Use 1 to 16 milestones with distinct lowercase ids and increasing due times.',
    'LONG_TASK_CRITERIA': 'Use 1 to 8 typed criteria: BUYER_REVIEW, CONTENT_SHA256 {value}, PRESENT {field}, MIN/MAX {field, value}, EQUALS {field, value}.',
    'LONG_TASK_TRANCHE': 'Set each tranche to a positive integer; the tranches together must fit in 2^53-1.',
    'LONG_TASK_HEARTBEAT': 'Set heartbeat {every, grace}: every from 1 second, grace from 0, both integers.',
    'LONG_TASK_SHARE': 'Use provider_bps from 0 to 10000.',
    'LONG_TASK_EFFECTS': 'Declare up to 8 effects {id, compensation: KEEP with provider_bps, or UNDO with within seconds}.',
    'LONG_TASK_WINDOW': 'Set integer issued_at < each due, increasing, <= expires. A delivery after due earns the late share; heartbeats keep the milestone alive until expires.',
    'LONG_TASK_NONCE': 'Use a fresh 64-hex nonce for a new plan.',
    'LONG_TASK_SIZE': 'Keep the plan within 65536 canonical bytes of printable ASCII.',
    'LONG_TASK_ASSENT': 'Collect one signature each from the buyer, the provider and the arbiter over the plan id.',
    'LONG_TASK_ROLE': 'Sign only as a role the plan names. Install the right key; never re-sign another role.',
    'LONG_TASK_NOT_ADOPTED': 'Adopt the signed plan in this runtime before funding or events.',
    'LONG_TASK_CHANGED': 'This runtime already holds another plan. Use a new directory for a new plan.',
    'LONG_TASK_UNKNOWN_MILESTONE': 'Name a milestone id from the plan.',
    'LONG_TASK_FUNDING': 'Fund each tranche once through the installed custody adapter with every party\'s approval.',
    'LONG_TASK_NOT_FUNDED': 'Reserve every tranche before work starts; events before full funding are refused.',
    'LONG_TASK_EVENT': 'Pass the event exactly as signed: {body, signature} with profile urn:aap:long-task-event:0.1.',
    'LONG_TASK_EVENT_ROLE': 'This action belongs to another role, or the signature is not by the named role key.',
    'LONG_TASK_EVENT_ARGUMENTS': 'Use the exact arguments for this action; hashes are 64 hex, shares 0 to 10000.',
    'LONG_TASK_STATE': 'This action is not allowed in the milestone\'s current state. Check status() first.',
    'LONG_TASK_HEARTBEAT_STALE': 'Send heartbeats with a sequence above the last accepted one.',
    'LONG_TASK_EFFECT_UNDECLARED': 'Only effects the plan declares for this milestone can be reported or undone.',
    'LONG_TASK_EFFECT_REPEATED': 'This effect is already reported with other evidence. Keep the first report; dispute if it is wrong.',
    'LONG_TASK_DUPLICATE_DELIVERY': 'This milestone already holds another delivery under review or accepted. Do not deliver twice; dispute instead.',
    'LONG_TASK_NO_REDELIVERY': 'No redelivery remains for this milestone. Open a dispute if the rejection is wrong.',
    'LONG_TASK_REVIEW_TARGET': 'Review the current delivery of this milestone by its delivery id.',
    'LONG_TASK_DISPUTE_TARGET': 'The arbiter decides the open dispute named by its event id.',
    'LONG_TASK_NOT_SETTLEABLE': 'Pay out only an accepted, decided, failed or cancelled milestone.',
    'LONG_TASK_COMPENSATION_PENDING': 'An UNDO effect is still inside its window. Wait for the provider\'s signed reversal or the window end.',
    'LONG_TASK_CUSTODY_RESULT': 'The custody adapter did not record this operation. Check approvals, then retry the same operation.',
    'LONG_TASK_CUSTODY_CHANGED': 'The custody adapter holds another result for this effect id. Investigate before relying on either.',
    'LONG_TASK_CLOCK': 'The owner must install a clock returning integer seconds; a counterparty cannot supply one.',
    'SYNTHETIC_CRASH_AFTER_CUSTODY_EFFECT':
        'A test asked for a crash right after the custody effect, before it was recorded. Call recover() '
        'before anything else: it records what the custody adapter holds, so nothing is paid twice.',
}


def need(ok, code):
    if not ok:
        raise NativeError(code, HINTS[code])


def _hex(value, code):
    need(type(value) is str and HEX.fullmatch(value) is not None, code)
    return value


def _int(value, low, high, code):
    need(type(value) is int and low <= value <= high, code)
    return value


def _key(value):
    from covenant_language.key_validation import valid_ed25519_key
    need(type(value) is str and HEX.fullmatch(value) is not None and valid_ed25519_key(value), 'LONG_TASK_KEY')
    return value


def _criteria(rows):
    need(type(rows) is list and 1 <= len(rows) <= 8, 'LONG_TASK_CRITERIA')
    for row in rows:
        need(type(row) is dict and row.get('kind') in CRITERIA, 'LONG_TASK_CRITERIA')
        kind = row['kind']
        if kind == 'BUYER_REVIEW':
            need(set(row) == {'kind'}, 'LONG_TASK_CRITERIA')
        elif kind == 'CONTENT_SHA256':
            need(set(row) == {'kind', 'value'}, 'LONG_TASK_CRITERIA'); _hex(row['value'], 'LONG_TASK_CRITERIA')
        elif kind == 'PRESENT':
            need(set(row) == {'kind', 'field'} and type(row['field']) is str and NAME.fullmatch(row['field']), 'LONG_TASK_CRITERIA')
        else:
            need(set(row) == {'kind', 'field', 'value'} and type(row['field']) is str and NAME.fullmatch(row['field']),
                 'LONG_TASK_CRITERIA')
            if kind in ('MIN', 'MAX'):
                _int(row['value'], -MAX, MAX, 'LONG_TASK_CRITERIA')
            else:
                _scalar(row['value'], 'LONG_TASK_CRITERIA')
    need(len({canonical(r) for r in rows}) == len(rows), 'LONG_TASK_CRITERIA')


def _scalar(value, code):
    need(type(value) is bool or type(value) is int and abs(value) <= MAX or
         type(value) is str and len(value) <= 256 and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _share(row):
    need(type(row) is dict and set(row) == {'provider_bps'}, 'LONG_TASK_SHARE')
    _int(row['provider_bps'], 0, 10000, 'LONG_TASK_SHARE')


def validate(plan):
    """Check an exact plan; it binds nothing until all three roles sign it."""
    need(type(plan) is dict and set(plan) == set(FIELDS.split()), 'LONG_TASK_FIELDS')
    need(plan['profile'] == PROFILE, 'LONG_TASK_PROFILE')
    keys = [_key(plan[role]) for role in ('buyer', 'provider', 'arbiter')]
    need(len(set(keys)) == 3, 'LONG_TASK_KEY')
    custody = plan['custody']
    need(type(custody) is dict and set(custody) == {'adapter', 'unit'} and type(custody['unit']) is str
         and 0 < len(custody['unit']) <= 128 and all(32 <= ord(c) <= 126 for c in custody['unit']), 'LONG_TASK_CUSTODY')
    _hex(custody['adapter'], 'LONG_TASK_CUSTODY')
    _int(plan['issued_at'], 0, MAX, 'LONG_TASK_WINDOW'); _int(plan['expires'], 0, MAX, 'LONG_TASK_WINDOW')
    rows = plan['milestones']
    need(type(rows) is list and 1 <= len(rows) <= MAX_MILESTONES, 'LONG_TASK_MILESTONES')
    seen, total, previous = set(), 0, plan['issued_at']
    for row in rows:
        need(type(row) is dict and set(row) == set(MILESTONE_FIELDS.split()), 'LONG_TASK_FIELDS')
        need(type(row['id']) is str and NAME.fullmatch(row['id']) is not None and row['id'] not in seen, 'LONG_TASK_MILESTONES')
        seen.add(row['id'])
        _hex(row['deliverable'], 'LONG_TASK_MILESTONES')
        _criteria(row['acceptance'])
        total += _int(row['tranche'], 1, MAX, 'LONG_TASK_TRANCHE')
        _int(row['due'], 0, MAX, 'LONG_TASK_WINDOW')
        need(previous < row['due'] <= plan['expires'], 'LONG_TASK_WINDOW'); previous = row['due']
        beat = row['heartbeat']
        need(type(beat) is dict and set(beat) == {'every', 'grace'}, 'LONG_TASK_HEARTBEAT')
        _int(beat['every'], 1, MAX, 'LONG_TASK_HEARTBEAT'); _int(beat['grace'], 0, MAX, 'LONG_TASK_HEARTBEAT')
        _share(row['late'])
        effects = row['effects']
        need(type(effects) is list and len(effects) <= MAX_EFFECTS and
             len({e.get('id') for e in effects if type(e) is dict}) == len(effects), 'LONG_TASK_EFFECTS')
        for effect in effects:
            need(type(effect) is dict and set(effect) == {'id', 'compensation'} and type(effect['id']) is str
                 and NAME.fullmatch(effect['id']) is not None, 'LONG_TASK_EFFECTS')
            clause = effect['compensation']
            need(type(clause) is dict and clause.get('kind') in COMPENSATION, 'LONG_TASK_EFFECTS')
            if clause['kind'] == 'KEEP':
                need(set(clause) == {'kind', 'provider_bps'}, 'LONG_TASK_EFFECTS')
                _int(clause['provider_bps'], 0, 10000, 'LONG_TASK_EFFECTS')
            else:
                need(set(clause) == {'kind', 'within'}, 'LONG_TASK_EFFECTS')
                _int(clause['within'], 1, MAX, 'LONG_TASK_EFFECTS')
        _int(row['redeliveries'], 0, 3, 'LONG_TASK_MILESTONES')
    need(total <= MAX, 'LONG_TASK_TRANCHE')
    _hex(plan['nonce'], 'LONG_TASK_NONCE')
    try:
        raw = canonical(plan)
    except ValueError:
        raise NativeError('LONG_TASK_SIZE', HINTS['LONG_TASK_SIZE']) from None
    need(len(raw) <= 65536, 'LONG_TASK_SIZE')
    return plan


def plan_id(plan):
    return digest(ID_LABEL, validate(plan))


def draft(*, buyer, provider, arbiter, adapter, unit, milestones, issued_at, expires, nonce):
    plan = {'profile': PROFILE, 'buyer': buyer, 'provider': provider, 'arbiter': arbiter,
            'custody': {'adapter': adapter, 'unit': unit}, 'milestones': deepcopy(milestones),
            'issued_at': issued_at, 'expires': expires, 'nonce': nonce}
    pin = plan_id(plan)
    return {'plan': plan, 'id': pin, 'required_signers': [buyer, provider, arbiter],
            'signing_payload': {'label': ASSENT_LABEL, 'body': {'plan': pin}}, 'signature_created': False,
            'status': 'AWAITING_THREE_SIGNATURES', **FLAGS}


def _roles(plan):
    return {'BUYER': plan['buyer'], 'PROVIDER': plan['provider'], 'ARBITER': plan['arbiter']}


def assent(plan, private_key):
    """Explicit owner signing step for one role."""
    pin = plan_id(plan); signer = public_key(private_key)
    need(signer in _roles(plan).values(), 'LONG_TASK_ROLE')
    return {'signer': signer, 'signature': sign(private_key, ASSENT_LABEL, {'plan': pin})}


def verify_assents(plan, assents):
    pin = plan_id(plan)
    need(type(assents) is list and len(assents) == 3, 'LONG_TASK_ASSENT')
    signers = []
    for row in assents:
        need(type(row) is dict and set(row) == {'signer', 'signature'}, 'LONG_TASK_ASSENT')
        try:
            verify(row['signer'], ASSENT_LABEL, {'plan': pin}, row['signature'])
        except ValueError:
            raise NativeError('LONG_TASK_ASSENT', HINTS['LONG_TASK_ASSENT']) from None
        signers.append(row['signer'])
    need(sorted(signers) == sorted(_roles(plan).values()), 'LONG_TASK_ASSENT')
    return pin


def _arguments(action, arguments):
    shapes = {'HEARTBEAT': {'sequence', 'progress_bps', 'note'}, 'EFFECT': {'effect', 'evidence'},
              'UNDONE': {'effect', 'evidence'}, 'DELIVER': {'delivery', 'content_sha256', 'claims'},
              'ACCEPT': {'delivery'}, 'REJECT': {'delivery', 'reason'}, 'DISPUTE': {'evidence', 'claim'},
              'DECIDE': {'dispute', 'provider_bps', 'reason'}}
    need(type(arguments) is dict and set(arguments) == shapes[action], 'LONG_TASK_EVENT_ARGUMENTS')
    for name in ('evidence', 'delivery', 'content_sha256', 'reason', 'claim', 'dispute'):
        if name in arguments:
            _hex(arguments[name], 'LONG_TASK_EVENT_ARGUMENTS')
    if action == 'HEARTBEAT':
        _int(arguments['sequence'], 1, MAX, 'LONG_TASK_EVENT_ARGUMENTS')
        _int(arguments['progress_bps'], 0, 10000, 'LONG_TASK_EVENT_ARGUMENTS')
        need(arguments['note'] is None or type(arguments['note']) is str and HEX.fullmatch(arguments['note']),
             'LONG_TASK_EVENT_ARGUMENTS')
    if 'effect' in arguments:
        need(type(arguments['effect']) is str and NAME.fullmatch(arguments['effect']) is not None, 'LONG_TASK_EVENT_ARGUMENTS')
    if action == 'DELIVER':
        claims = arguments['claims']
        need(type(claims) is dict and len(claims) <= 32, 'LONG_TASK_EVENT_ARGUMENTS')
        for name, value in claims.items():
            need(NAME.fullmatch(name) is not None, 'LONG_TASK_EVENT_ARGUMENTS'); _scalar(value, 'LONG_TASK_EVENT_ARGUMENTS')
    if action == 'DECIDE':
        _int(arguments['provider_bps'], 0, 10000, 'LONG_TASK_EVENT_ARGUMENTS')


def event(private_key, plan, role, action, milestone, arguments, at):
    """A role's signed statement. The signature proves who said it, not that it is true."""
    pin = plan_id(plan)
    need(role in ROLES and action in ACTIONS and (ACTIONS[action] in (None, role)), 'LONG_TASK_EVENT_ROLE')
    need(action != 'DISPUTE' or role in ('BUYER', 'PROVIDER'), 'LONG_TASK_EVENT_ROLE')
    need(public_key(private_key) == _roles(plan)[role], 'LONG_TASK_ROLE')
    _arguments(action, arguments); _int(at, 0, MAX, 'LONG_TASK_EVENT_ARGUMENTS')
    body = {'profile': EVENT, 'plan': pin, 'role': role, 'action': action, 'milestone': milestone,
            'arguments': deepcopy(arguments), 'at': at}
    return {'body': body, 'signature': sign(private_key, EVENT_LABEL, body)}


def event_id(body):
    return digest(EVENT_ID_LABEL, body)


def _check_event(plan, pin, value):
    need(type(value) is dict and set(value) == {'body', 'signature'}, 'LONG_TASK_EVENT')
    body = value['body']
    need(type(body) is dict and set(body) == {'profile', 'plan', 'role', 'action', 'milestone', 'arguments', 'at'}
         and body['profile'] == EVENT and body['plan'] == pin, 'LONG_TASK_EVENT')
    need(body['role'] in ROLES and body['action'] in ACTIONS and ACTIONS[body['action']] in (None, body['role'])
         and (body['action'] != 'DISPUTE' or body['role'] in ('BUYER', 'PROVIDER')), 'LONG_TASK_EVENT_ROLE')
    need(body['milestone'] in [m['id'] for m in plan['milestones']], 'LONG_TASK_UNKNOWN_MILESTONE')
    _arguments(body['action'], body['arguments']); _int(body['at'], 0, MAX, 'LONG_TASK_EVENT_ARGUMENTS')
    try:
        verify(_roles(plan)[body['role']], EVENT_LABEL, body, value['signature'])
    except ValueError:
        raise NativeError('LONG_TASK_EVENT_ROLE', HINTS['LONG_TASK_EVENT_ROLE']) from None
    return event_id(body)


def evaluate(criteria, content_sha256, claims):
    """Mechanical criteria over the delivery claims; BUYER_REVIEW leaves the verdict to the buyer."""
    results = []
    for row in criteria:
        kind = row['kind']
        if kind == 'BUYER_REVIEW':
            continue
        value = claims.get(row.get('field'))
        if kind == 'CONTENT_SHA256':
            met = content_sha256 == row['value']
        elif kind == 'PRESENT':
            met = row['field'] in claims
        elif kind == 'EQUALS':
            met = row['field'] in claims and type(value) is type(row['value']) and value == row['value']
        else:
            met = type(value) is int and (value >= row['value'] if kind == 'MIN' else value <= row['value'])
        results.append({'kind': kind, 'field': row.get('field'), 'met': met})
    review = any(row['kind'] == 'BUYER_REVIEW' for row in criteria)
    verdict = 'REJECTED' if not all(r['met'] for r in results) else 'AWAITING_REVIEW' if review else 'ACCEPTED'
    return {'verdict': verdict, 'results': results, 'basis': 'SIGNED_PROVIDER_CLAIMS_CHECKED; NOT_WORLD_TRUTH'}


def _milestone(row):
    return {'id': row['id'], 'status': 'PENDING', 'activated': None, 'last_beat': None, 'beat_sequence': 0,
            'progress_bps': 0, 'effects': {e['id']: {'clause': e['compensation'], 'performed': None, 'evidence': None,
                                                     'undone': None} for e in row['effects']},
            'deliveries': {}, 'current': None, 'delivered': 0, 'late': False, 'failure': None, 'failed_at': None,
            'dispute': None, 'paused': None, 'decision': None, 'undo_overdue': False, 'paid': None, 'judgments': []}


def _replay(plan, events):
    """Deterministic state from the journal; every judgment carries the owner-clock time it used."""
    rows = {m['id']: m for m in plan['milestones']}
    order = [m['id'] for m in plan['milestones']]
    state = {'milestones': {m: _milestone(rows[m]) for m in order}, 'funded': {}, 'started': None,
             'events': {}, 'custody': {}}
    milestones = state['milestones']

    def advance(index, at):
        """After a milestone settles its outcome, start the next or cancel the rest."""
        current = milestones[order[index]]
        if current['status'] == 'FAILED':
            for later in order[index + 1:]:
                if milestones[later]['status'] == 'PENDING':
                    milestones[later]['status'] = 'CANCELLED'
        elif index + 1 < len(order) and milestones[order[index + 1]]['status'] == 'PENDING':
            nxt = milestones[order[index + 1]]
            nxt.update(status='ACTIVE', activated=at, last_beat=at)

    for entry in events:
        kind, value = entry['kind'], entry['value']
        if kind == 'TASK_FUNDED':
            state['funded'][value['milestone']] = value
            if len(state['funded']) == len(order) and state['started'] is None:
                state['started'] = value['at']
                milestones[order[0]].update(status='ACTIVE', activated=value['at'], last_beat=value['at'])
        elif kind == 'TASK_CUSTODY_INTENT':
            state['custody'][value['effect']] = {'intent': value, 'result': None}
        elif kind == 'TASK_CUSTODY_RESULT':
            state['custody'][value['effect']]['result'] = value
            if value['purpose'] == 'PAYOUT':
                milestones[value['milestone']]['paid'] = value
        elif kind == 'TASK_JUDGED':
            m = milestones[value['milestone']]; m['judgments'].append(value)
            if value['judgment'] in ('MISSED_HEARTBEAT', 'EXPIRED_NO_DELIVERY'):
                m.update(status='FAILED', failure=value['judgment'], failed_at=value['at'])
                advance(order.index(m['id']), value['at'])
            elif value['judgment'] == 'UNDO_OVERDUE':
                m['undo_overdue'] = True
        elif kind == 'TASK_EVENT':
            body = value['event']['body']; at = value['received_at']; args = body['arguments']
            m = milestones[body['milestone']]; index = order.index(m['id']); spec = rows[m['id']]
            state['events'][value['id']] = value
            action = body['action']
            if action == 'HEARTBEAT':
                m.update(last_beat=at, beat_sequence=args['sequence'], progress_bps=args['progress_bps'])
            elif action == 'EFFECT':
                m['effects'][args['effect']].update(performed=at, evidence=args['evidence'])
            elif action == 'UNDONE':
                m['effects'][args['effect']]['undone'] = at
            elif action == 'DELIVER':
                m['delivered'] += 1; m['current'] = args['delivery']; m['last_beat'] = at
                late = at > spec['due']
                check = evaluate(spec['acceptance'], args['content_sha256'], args['claims'])
                m['deliveries'][args['delivery']] = {'event': value['id'], 'content_sha256': args['content_sha256'],
                                                     'claims': deepcopy(args['claims']), 'received_at': at,
                                                     'late': late, 'check': check}
                m['late'] = late
                if check['verdict'] == 'REJECTED':
                    _rejected(m, spec, at)
                    if m['status'] == 'FAILED':
                        advance(index, at)
                else:
                    m['status'] = check['verdict']
                    if m['status'] == 'ACCEPTED':
                        advance(index, at)
            elif action == 'ACCEPT':
                m['status'] = 'ACCEPTED'; advance(index, at)
            elif action == 'REJECT':
                _rejected(m, spec, at)
                if m['status'] == 'FAILED':
                    advance(index, at)
            elif action == 'DISPUTE':
                m['paused'] = m['status']; m['status'] = 'DISPUTED'; m['dispute'] = value['id']
            elif action == 'DECIDE':
                m['status'] = 'DECIDED'; m['decision'] = {'event': value['id'], 'provider_bps': args['provider_bps']}
                if m['paused'] in ('ACTIVE', 'REJECTED', 'AWAITING_REVIEW'):
                    advance(index, at)
    return state


def _rejected(m, spec, at):
    if m['delivered'] > spec['redeliveries']:
        m.update(status='FAILED', failure='REJECTED', failed_at=at)
    else:
        m.update(status='REJECTED', last_beat=at)


def _allowed(plan, state, body):
    """Refuse an event the current state does not allow, before it is journaled."""
    m = state['milestones'][body['milestone']]; args = body['arguments']; action = body['action']
    spec = {row['id']: row for row in plan['milestones']}[m['id']]
    if action == 'HEARTBEAT':
        need(m['status'] in ('ACTIVE', 'REJECTED'), 'LONG_TASK_STATE')
        need(args['sequence'] > m['beat_sequence'], 'LONG_TASK_HEARTBEAT_STALE')
    elif action == 'EFFECT':
        need(args['effect'] in m['effects'], 'LONG_TASK_EFFECT_UNDECLARED')
        need(m['status'] in ('ACTIVE', 'REJECTED', 'AWAITING_REVIEW'), 'LONG_TASK_STATE')
        need(m['effects'][args['effect']]['performed'] is None, 'LONG_TASK_EFFECT_REPEATED')
    elif action == 'UNDONE':
        effect = m['effects'].get(args['effect'])
        need(effect is not None and effect['clause']['kind'] == 'UNDO', 'LONG_TASK_EFFECT_UNDECLARED')
        need(effect['performed'] is not None and effect['undone'] is None and m['paid'] is None, 'LONG_TASK_STATE')
    elif action == 'DELIVER':
        need(m['status'] not in ('ACCEPTED', 'AWAITING_REVIEW', 'DECIDED') and m['paid'] is None, 'LONG_TASK_DUPLICATE_DELIVERY')
        need(args['delivery'] not in m['deliveries'], 'LONG_TASK_DUPLICATE_DELIVERY')
        need(m['status'] in ('ACTIVE', 'REJECTED'), 'LONG_TASK_STATE')
        need(m['delivered'] <= spec['redeliveries'], 'LONG_TASK_NO_REDELIVERY')
    elif action in ('ACCEPT', 'REJECT'):
        need(m['status'] == 'AWAITING_REVIEW', 'LONG_TASK_STATE')
        need(args['delivery'] == m['current'], 'LONG_TASK_REVIEW_TARGET')
    elif action == 'DISPUTE':
        need(m['status'] in ('ACTIVE', 'AWAITING_REVIEW', 'REJECTED', 'FAILED', 'ACCEPTED') and m['paid'] is None
             and m['dispute'] is None, 'LONG_TASK_STATE')
    else:
        need(m['status'] == 'DISPUTED', 'LONG_TASK_STATE')
        need(args['dispute'] == m['dispute'], 'LONG_TASK_DISPUTE_TARGET')


def provider_share(spec, m, now):
    """The plan's clause for this outcome, in basis points of the tranche."""
    status = m['status']
    if status == 'ACCEPTED':
        return 10000 if not m['late'] else spec['late']['provider_bps'], 'ACCEPTED_LATE' if m['late'] else 'ACCEPTED'
    if status == 'DECIDED':
        return m['decision']['provider_bps'], 'ARBITER_DECISION'
    if status == 'CANCELLED':
        return 0, 'CANCELLED_BEFORE_START'
    need(status == 'FAILED', 'LONG_TASK_NOT_SETTLEABLE')
    performed = [e for e in m['effects'].values() if e['performed'] is not None]
    pending = [e for e in performed if e['clause']['kind'] == 'UNDO' and e['undone'] is None]
    if pending:
        windows = [m['failed_at'] + e['clause']['within'] for e in pending]
        need(m['undo_overdue'] or now > max(windows), 'LONG_TASK_COMPENSATION_PENDING')
        return 0, 'UNDO_OVERDUE_PROVIDER_FORFEITS'
    keep = sum(e['clause']['provider_bps'] for e in performed if e['clause']['kind'] == 'KEEP')
    return min(10000, keep), 'FAILED_KEEP_EFFECTS' if keep else 'FAILED_FULL_REFUND'


class LongTask:
    """One plan's durable runtime on an owner host: funding, events, judgments, payouts and recovery.

    custody is the owner-installed custody adapter the plan names; clock is the
    owner-installed time source (integer seconds) used for every judgment.
    """
    def __init__(self, directory, *, custody, clock):
        need(callable(clock), 'LONG_TASK_CLOCK')
        self.custody = custody; self.clock = clock
        self.store = WorkflowStore(directory, {'profile': PROFILE, 'role': 'RUNTIME'})

    def close(self):
        self.store.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _now(self):
        value = self.clock()
        need(type(value) is int and 0 <= value <= MAX, 'LONG_TASK_CLOCK')
        return value

    def _history(self):
        return [{'kind': e['body']['kind'], 'value': e['body']['value'], 'id': e['id']} for e in self.store.events()]

    def _loaded(self):
        history = self._history()
        need(bool(history) and history[0]['kind'] == 'TASK_PLAN', 'LONG_TASK_NOT_ADOPTED')
        plan = history[0]['value']['plan']
        return plan, plan_id(plan), _replay(plan, history[1:]), history

    def _append(self, kind, value):
        return self.store.append(kind, 'long-task', value)

    def adopt(self, plan, assents):
        pin = verify_assents(plan, assents)
        need(getattr(self.custody, 'ref', None) == plan['custody']['adapter'] and callable(getattr(self.custody, 'escrow_policy', None))
             and getattr(self.custody, 'unit', plan['custody']['unit']) == plan['custody']['unit'], 'LONG_TASK_CUSTODY')
        with self.store.exclusive():
            history = self._history()
            if history:
                need(history[0]['kind'] == 'TASK_PLAN' and canonical(history[0]['value']['plan']) == canonical(plan),
                     'LONG_TASK_CHANGED')
                return {'plan': pin, 'status': 'ADOPTED', 'replayed': True, **FLAGS}
            self._append('TASK_PLAN', {'plan': deepcopy(plan), 'assents': deepcopy(assents)})
        return {'plan': pin, 'status': 'ADOPTED', 'replayed': False, **FLAGS}

    def _spec(self, plan, milestone):
        rows = {m['id']: m for m in plan['milestones']}
        need(milestone in rows, 'LONG_TASK_UNKNOWN_MILESTONE')
        return rows[milestone]

    def escrow_policy(self, milestone):
        """The exact per-milestone escrow: buyer pays, provider is payee, any two of three release."""
        plan, pin, _, _ = self._loaded(); spec = self._spec(plan, milestone)
        return self.custody.escrow_policy('Long task %s milestone %s' % (pin[:16], milestone), plan['buyer'],
                                          spec['tranche'], plan['buyer'], plan['provider'],
                                          [plan['buyer'], plan['provider'], plan['arbiter']], 2, pin)

    def _effect(self, pin, milestone, purpose):
        return digest(EFFECT_LABEL, {'plan': pin, 'milestone': milestone, 'purpose': purpose})

    def funding(self, milestone):
        """The custody FUND request and the exact payload every party signs."""
        plan, pin, _, _ = self._loaded(); self._spec(plan, milestone)
        request = {'action': 'FUND', 'policy': self.escrow_policy(milestone)}
        effect = self._effect(pin, milestone, 'FUND')
        return {'effect': effect, 'request': request, 'payload': self.custody.assent_payload(effect, request),
                'signature_created': False, **FLAGS}

    def _custody(self, milestone, purpose, effect, request, approvals, crash=None):
        """Journal the intent, execute through the adapter once, then journal its observed result."""
        with self.store.exclusive():
            _, _, state, _ = self._loaded()
            held = state['custody'].get(effect)
            if held is not None and held['result'] is not None:
                need(canonical(held['intent']['request']) == canonical(request), 'LONG_TASK_CUSTODY_CHANGED')
                return held['result']['receipt'], True
            if held is None:
                self._append('TASK_CUSTODY_INTENT', {'effect': effect, 'milestone': milestone, 'purpose': purpose,
                                                     'request': deepcopy(request), 'at': self._now()})
        receipt = self.custody.execute(effect, {**deepcopy(request), 'approvals': deepcopy(approvals)})
        if crash == 'AFTER_CUSTODY_EFFECT':
            raise RuntimeError('SYNTHETIC_CRASH_AFTER_CUSTODY_EFFECT')
        return self._observed(milestone, purpose, effect, request, receipt), False

    def _observed(self, milestone, purpose, effect, request, receipt):
        need(type(receipt) is dict and receipt.get('status') == 'OBSERVED', 'LONG_TASK_CUSTODY_RESULT')
        value = receipt.get('value') or {}
        need(value.get('action') == request['action'], 'LONG_TASK_CUSTODY_CHANGED')
        if request['action'] == 'PAYOUT':
            need(canonical(value.get('payouts')) == canonical(request['payouts']), 'LONG_TASK_CUSTODY_CHANGED')
        with self.store.exclusive():
            _, _, state, _ = self._loaded()
            held = state['custody'].get(effect)
            if held is not None and held['result'] is not None:
                return held['result']['receipt']
            at = self._now()
            if purpose == 'FUND':
                self._append('TASK_FUNDED', {'milestone': milestone, 'effect': effect, 'escrow': value.get('escrow'),
                                             'at': at})
            self._append('TASK_CUSTODY_RESULT', {'effect': effect, 'milestone': milestone, 'purpose': purpose,
                                                 'receipt': deepcopy(receipt), 'at': at})
        return receipt

    def fund(self, milestone, approvals):
        prepared = self.funding(milestone)
        receipt, replayed = self._custody(milestone, 'FUND', prepared['effect'], prepared['request'], approvals)
        return {'milestone': milestone, 'status': 'RESERVED', 'replayed': replayed, 'receipt': receipt, **FLAGS}

    def submit(self, signed):
        """Journal one role's signed event if the state allows it; an exact repeat is a replay."""
        with self.store.exclusive():
            plan, pin, state, _ = self._loaded()
            ident = _check_event(plan, pin, signed)
            if ident in state['events']:
                return {'event': ident, 'replayed': True, 'status': self.status()['milestones'], **FLAGS}
            need(state['started'] is not None, 'LONG_TASK_NOT_FUNDED')
            _allowed(plan, state, signed['body'])
            self._append('TASK_EVENT', {'id': ident, 'event': deepcopy(signed), 'received_at': self._now()})
        return {'event': ident, 'replayed': False, 'status': self.status()['milestones'], **FLAGS}

    def check(self):
        """Judge missed heartbeats, missed deadlines and overdue reversals at the owner clock."""
        judged = []
        with self.store.exclusive():
            plan, _, state, _ = self._loaded()
            now = self._now()
            for spec in plan['milestones']:
                m = state['milestones'][spec['id']]
                if m['status'] in ('ACTIVE', 'REJECTED'):
                    # Milestones run in order, so at most one is active at a time.
                    # due only sets the late share; heartbeats keep a late milestone alive until expiry.
                    deadline = m['last_beat'] + spec['heartbeat']['every'] + spec['heartbeat']['grace']
                    if now > plan['expires']:
                        judged.append({'milestone': spec['id'], 'judgment': 'EXPIRED_NO_DELIVERY', 'at': now,
                                       'deadline': plan['expires'], 'basis': 'OWNER_CLOCK'})
                    elif now > deadline:
                        judged.append({'milestone': spec['id'], 'judgment': 'MISSED_HEARTBEAT', 'at': now,
                                       'deadline': deadline, 'basis': 'OWNER_CLOCK'})
                elif m['status'] == 'FAILED' and not m['undo_overdue'] and m['paid'] is None:
                    pending = [e['clause']['within'] for e in m['effects'].values()
                               if e['clause']['kind'] == 'UNDO' and e['performed'] is not None and e['undone'] is None]
                    if pending and now > m['failed_at'] + max(pending):
                        judged.append({'milestone': spec['id'], 'judgment': 'UNDO_OVERDUE', 'at': now,
                                       'deadline': m['failed_at'] + max(pending), 'basis': 'OWNER_CLOCK'})
            for value in judged:
                self._append('TASK_JUDGED', value)
        return {'judged': judged, 'at': now, 'clock': 'OWNER_INSTALLED', **FLAGS}

    def settlement(self, milestone):
        """The tranche payout the plan's clauses give for this milestone's outcome."""
        plan, pin, state, _ = self._loaded(); spec = self._spec(plan, milestone)
        m = state['milestones'][milestone]
        need(milestone in state['funded'], 'LONG_TASK_NOT_FUNDED')
        bps, basis = provider_share(spec, m, self._now())
        provider = spec['tranche'] * bps // 10000; buyer = spec['tranche'] - provider
        payouts = {actor: amount for actor, amount in ((plan['provider'], provider), (plan['buyer'], buyer)) if amount}
        request = {'action': 'PAYOUT', 'escrow': state['funded'][milestone]['escrow'], 'payouts': payouts}
        effect = self._effect(pin, milestone, 'PAYOUT')
        return {'milestone': milestone, 'effect': effect, 'request': request, 'provider_bps': bps, 'basis': basis,
                'payload': self.custody.assent_payload(effect, request), 'signature_created': False, **FLAGS}

    def payout(self, milestone, approvals, *, crash=None):
        """Release one tranche once, with any two of buyer, provider and arbiter approving."""
        prepared = self.settlement(milestone)
        receipt, replayed = self._custody(milestone, 'PAYOUT', prepared['effect'], prepared['request'], approvals, crash)
        return {'milestone': milestone, 'status': 'PAID', 'replayed': replayed, 'receipt': receipt,
                'provider_bps': prepared['provider_bps'], 'basis': prepared['basis'], **FLAGS}

    def recover(self):
        """After a crash, record what the custody adapter actually holds for each journaled intent."""
        _, _, state, _ = self._loaded()
        recovered = []
        for effect, held in sorted(state['custody'].items()):
            if held['result'] is not None:
                continue
            seen = self.custody.observe(effect)
            if type(seen) is dict and seen.get('status') == 'OBSERVED':
                intent = held['intent']
                self._observed(intent['milestone'], intent['purpose'], effect, intent['request'], seen)
                recovered.append({'effect': effect, 'milestone': intent['milestone'], 'purpose': intent['purpose'],
                                  'status': 'RECORDED_FROM_CUSTODY'})
            else:
                recovered.append({'effect': effect, 'milestone': held['intent']['milestone'],
                                  'purpose': held['intent']['purpose'], 'status': 'NOT_EXECUTED_RETRY_THE_SAME_OPERATION'})
        return {'recovered': recovered, 'automatic_retry': False, **FLAGS}

    def status(self):
        plan, pin, state, history = self._loaded()
        rows = []
        for spec in plan['milestones']:
            m = state['milestones'][spec['id']]
            deadline = None
            if m['status'] in ('ACTIVE', 'REJECTED'):
                deadline = min(plan['expires'], m['last_beat'] + spec['heartbeat']['every'] + spec['heartbeat']['grace'])
            rows.append({'id': spec['id'], 'status': m['status'], 'tranche': spec['tranche'],
                         'reserved': spec['id'] in state['funded'], 'paid': m['paid'] is not None,
                         'progress_bps': m['progress_bps'], 'next_deadline': deadline, 'failure': m['failure'],
                         'late': m['late'], 'dispute': m['dispute'], 'decision': deepcopy(m['decision']),
                         'effects': {k: {'performed': v['performed'] is not None, 'undone': v['undone'] is not None,
                                         'clause': deepcopy(v['clause'])} for k, v in m['effects'].items()},
                         'judgments': [j['judgment'] for j in m['judgments']]})
        return {'plan': pin, 'milestones': rows, 'started': state['started'], 'head': history[-1]['id'],
                'clock': 'OWNER_INSTALLED', **FLAGS}


def describe():
    return {'profile': PROFILE, 'event': EVENT, 'actions': dict(ACTIONS), 'criteria': list(CRITERIA),
            'compensation': {'KEEP': 'provider keeps provider_bps of the tranche if the milestone fails after the effect',
                             'UNDO': 'provider signs the reversal within the window or forfeits its share'},
            'outcomes': {'ACCEPTED': 'provider 10000 bps, or the late share after the due time',
                         'DECIDED': 'the arbiter\'s provider_bps', 'FAILED': 'the effects\' clauses',
                         'CANCELLED': 'full refund'},
            'custody': 'one escrow per milestone through the owner-installed adapter; any two of three release',
            'clock': 'owner-installed; every judgment is journaled with the time it used',
            'remediation': dict(HINTS), **FLAGS}
