"""Read-only authority, evidence and private-successor composition.

These helpers join existing exact checks. They never sign, issue challenges,
protect/open content, publish, revoke, or move funds. Caller associations are
kept separate from verified statements and installed effect authority.
"""
from copy import deepcopy
import hashlib
import json
import re
from types import MethodType

from covenant_language import mechanism_plans as p, marketplace
from . import access_mechanisms as access
from .agent_tools import validate_json
from .crypto import need, verification_key


VERSION = 'covenant-coordination-review/0.1'
MAX_ITEMS = 64
_SAFE_ERRORS = set('''ACCESS_POLICY_CHANGED ACCESS_REVOCATION_STATE_STALE
ACCESS_INTEGER ACCESS_FIELDS ACCESS_CHAIN_LIMIT ACCESS_CHAIN_REPLAY
ACCESS_GRANT_EXPIRED_OR_NOT_YET_VALID ACCESS_GRANT_REVOKED_OR_SUPERSEDED
ACCESS_SUCCESSOR_NOT_ADOPTED ACCESS_SCOPE_MISMATCH ACCESS_UNTRUSTED_ROOT
ACCESS_PARENT_AUTHORITY ACCESS_CAPABILITY_WIDENING ACCESS_INTERVAL_WIDENING
ACCESS_DELEGATION_CYCLE ACCESS_SUBJECT_OR_CAPABILITY ACCESS_DELEGABLE
ACCESS_GRANT_INTERVAL ACCESS_SELF_DELEGATION ACCESS_DUPLICATE_CAPABILITY
ACCESS_GRANT_VERSION ACCESS_TEXT ACCESS_CAPABILITIES ACCESS_TRUSTED_ISSUERS
ACCESS_REVOCATION_LIMIT ACCESS_SUCCESSOR_STATE ACCESS_POLICY_NOT_INSTALLED
ACCESS_HANDLER_CHANGED MECHANISM_MANIFEST_CHANGED MECHANISM_NOT_INSTALLED
MECHANISM_OPERATION_NOT_INSTALLED MECHANISM_OPERATION_MODE
PROOF_EXPECTATION_MISMATCH PROOF_SYSTEM_MISMATCH PROOF_VERIFIER_CHANGED
PROOF_VERSION PROOF_SIZE PROOF_ENCODING PROOF_STATEMENT PROOF_SYSTEM
ADAPTER_NOT_INSTALLED ADAPTER_MANIFEST_CHANGED ESCROW_POLICY
ESCROW_ASSET_OR_CONNECTOR ESCROW_EXPLICIT_QUORUM
ESCROW_UNSUPPORTED_AUTOMATIC_RULES PUBLIC_KEY SIGNATURE SIGNATURE_ENCODING
PQ_SIGNATURE_ENCODING UNSUPPORTED_SIGNATURE_SUITE PQ_PUBLIC_KEY FIELDS KEY
COORDINATION_ESCROW_ADAPTER_SCOPE COORDINATION_ACCESS_CAPABILITY
COORDINATION_ACCESS_INSTALLATION_CHANGED
COORDINATION_ACCESS_STATE_CHANGED_REVIEW_AGAIN NETWORK_GROUP'''.split())


def _bounded(value):
    """Validate before copies, callback dispatch, or potentially costly hashing."""
    validate_json(value)
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=True, allow_nan=False).encode('ascii')
    need(len(raw) <= 4_000_000, 'COORDINATION_INPUT_LIMIT')
    return raw


def _hash(value):
    return hashlib.sha256(b'COVENANT-REVIEW-STATEMENT-0.1\0' + _bounded(value)).hexdigest()


def _rows(value):
    need(type(value) is list and len(value) <= MAX_ITEMS, 'COORDINATION_ITEMS')


def _fields(value, required, optional=()):
    need(type(value) is dict and set(required) <= set(value)
        and set(value) <= set(required) | set(optional), 'COORDINATION_FIELDS')


def _label(value):
    need(type(value) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}', value)
        is not None, 'COORDINATION_ITEM_ID')


def _error(error):
    # Owner callbacks and clocks may raise exception text containing custody
    # paths or secrets. Never copy arbitrary exception messages into a review.
    value = str(error)
    return value if value in _SAFE_ERRORS else 'COORDINATION_CHECK_FAILED'


def _agreement_roles(agreements):
    _rows(agreements)
    result = []
    seen = set()
    for row in agreements:
        _fields(row, ('id', 'parties', 'kind'))
        p.ref(row['id'])
        need(row['id'] not in seen, 'COORDINATION_DUPLICATE_AGREEMENT')
        seen.add(row['id'])
        p.text(row['kind'], 128)
        parties = row['parties']
        need(type(parties) is dict and len(parties) <= 64, 'COORDINATION_PARTIES')
        for role, identity in sorted(parties.items()):
            p.text(role, 128)
            verification_key(identity)
            result.append({'agreement': row['id'], 'kind': row['kind'], 'role': role,
                'identity': deepcopy(identity), 'basis': 'CALLER_DECLARED_ROLE_NOT_REVERIFIED',
                'native_controller_or_payment_authority': False})
    return result


def _installed_access(tools):
    entries = getattr(tools, 'access_desks', {})
    need(type(entries) is dict and len(entries) <= MAX_ITEMS, 'COORDINATION_ACCESS_LIMIT')
    result = []
    lookup = {}
    for mechanism, desk in sorted(entries.items()):
        row = {'mechanism': mechanism, 'policy': getattr(desk, 'ref', None),
            'authority': 'EXACT_LOCAL_ACCESS_SCOPE_ONLY', 'execution_authorized': False}
        try:
            need(isinstance(desk, access.AccessDesk), 'COORDINATION_ACCESS_INSTALLATION_CHANGED')
            for operation, function in (('password', access.AccessDesk.password),
                    ('delegation', access.AccessDesk.delegation)):
                manifest, handler, adapter = tools.mechanisms.get(mechanism, operation, 'LOCAL')
                need(type(handler) is MethodType and handler.__self__ is desk
                    and handler.__func__ is function and adapter is None
                    and p.canonical(manifest['assurances']['policy']) == p.canonical(desk._policy()),
                    'COORDINATION_ACCESS_INSTALLATION_CHANGED')
            now = desk._fresh()
            row.update(status='FRESH_OWNER_STATE', checked_at=now,
                scope={key: deepcopy(desk.policy[key]) for key in
                    ('context', 'target', 'operation', 'capabilities', 'issuers')},
                owner_state=desk.public_state(),
                issuer_and_revocation_completeness='TRUSTED_OWNER_ADOPTION_NOT_REMOTE_PROOF')
        except Exception as error:
            row.update(status='UNAVAILABLE', error=_error(error))
        result.append(row)
        lookup[mechanism] = (desk, row)
        if type(row['policy']) is str:
            lookup[row['policy']] = (desk, row)
    return result, lookup


def _group_roles(tools, group, expected_heads):
    if expected_heads is not None:
        need(type(expected_heads) is list and len(expected_heads) <= 64
            and all(type(ref) is str for ref in expected_heads)
            and expected_heads == sorted(set(expected_heads)), 'COORDINATION_EXPECTED_HEADS')
        for ref in expected_heads:
            p.ref(ref)
    if group is None:
        need(expected_heads is None, 'COORDINATION_GROUP_REQUIRED_FOR_HEADS')
        return {'status': 'NOT_REQUESTED', 'roles': [], 'execution_authorized': False}
    p.ref(group)
    network = getattr(tools, 'network', None)
    if network is None:
        return {'group': group, 'status': 'NETWORK_NOT_INSTALLED', 'roles': [],
            'execution_authorized': False}
    try:
        from .agent_network import permissions, role_view
        from .social_views import _heads
        events = network.events()  # Revalidates stored signatures and causal policy.
        need(group in events and events[group]['body']['kind'] == 'GROUP', 'NETWORK_GROUP')
        heads = _heads(events)
        if expected_heads is not None and heads != expected_heads:
            return {'group': group, 'status': 'EXPECTED_HEADS_MISMATCH', 'roles': [],
                'heads': heads, 'expected_heads': deepcopy(expected_heads),
                'freshness': 'LOCAL_REPLICA_ONLY', 'execution_authorized': False}
        return {'group': group, 'status': 'LOCAL_SIGNATURES_AND_CAUSAL_POLICY_VERIFIED',
            'heads': heads, 'expected_heads_match': None if expected_heads is None else True,
            'founder': events[group]['body']['actor'],
            'founder_group_permissions': sorted(permissions(events, group, events[group]['body']['actor'])),
            'roles': role_view(events, group),
            'revocation_scope': 'THIS_GROUP_LOCAL_REPLICA_AND_CAUSAL_PAST_ONLY',
            'native_controller_or_payment_authority': False,
            'freshness': 'LOCAL_REPLICA_ONLY_NOT_GLOBAL_CURRENT_AUTHORITY',
            'execution_authorized': False}
    except Exception as error:
        return {'group': group, 'status': 'UNAVAILABLE', 'roles': [],
            'error': _error(error), 'execution_authorized': False}


def _escrow_scopes(tools, policies):
    result = []
    for item in policies:
        if type(item) is dict and 'policy' in item:
            _fields(item, ('policy',), ('id',))
            policy = item['policy']
        else:
            policy = item
        marketplace.validate(policy)
        need(policy['kind'] == 'ESCROW_POLICY', 'COORDINATION_ESCROW_POLICY')
        ref = marketplace.identifier(policy)
        if type(item) is dict and 'policy' in item and 'id' in item:
            need(item['id'] == ref, 'COORDINATION_ESCROW_EXPECTED_ID')
        data = policy['data']
        row = {'policy': ref, 'connector': data['connector'],
            'funding_scope': {'eligible_signers': sorted(set([data['payer'], data['payee'],
                *data['controllers']])), 'requirement': 'ALL_NAMED_PARTICIPANTS'},
            'payout_scope': {'eligible_signers': deepcopy(data['controllers']),
                'threshold': data['threshold'], 'requirement': 'EXACT_EFFECT_POLICY_AND_COMPLETE_ALLOCATION'},
            'agreement_roles_do_not_replace_controller_signatures': True,
            'policy_assent_verified': False, 'funding_or_payout_created': False,
            'execution_authorized': False}
        try:
            workflow = getattr(tools, 'workflow', None)
            registry = getattr(tools, 'adapters', None) or getattr(workflow, 'adapters', None)
            need(registry is not None and data['connector'] is not None, 'ADAPTER_NOT_INSTALLED')
            adapter = registry.get(data['connector'])
            need(adapter.manifest['capability'] == 'payment.escrow', 'COORDINATION_ESCROW_ADAPTER_SCOPE')
            # Only this concrete installed implementation is interpreted here.
            # An unrelated custom connector may have different consent rules.
            from .escrow_desk import DemoEscrowDesk
            if type(adapter) is DemoEscrowDesk:
                adapter._policy(policy)
                row.update(status='INSTALLED_POLICY_ACCEPTED',
                    approval_scope_basis='INSTALLED_DEMO_ESCROW_POLICY_VALIDATION',
                    custody='LOCAL_DISPOSABLE_ONLY',
                    allocation='WHOLE_RESERVE_EXACT_QUORUM; USE_SEPARATE_POLICIES_FOR_MILESTONES')
            else:
                row.update(status='INSTALLED_CUSTOM_SCOPE_UNCHECKED',
                    approval_scope_basis='DECLARED_POLICY_ONLY; ADOPT_CUSTOM_CONNECTOR_REVIEW',
                    custody='OWNER_INSTALLED_CONNECTOR_NOT_INFERRED')
        except Exception as error:
            row.update(status='UNAVAILABLE', error=_error(error),
                approval_scope_basis='DECLARED_POLICY_ONLY_NOT_INSTALLED_APPROVAL_AUTHORITY')
        result.append(row)
    return result


def authority(tools, agreements, grants=None, group=None, expected_heads=None, policies=None):
    """Review verified role rows beside actual owner-installed access scopes.

    ``agreements`` contains caller-declared role summaries, not signed artifacts.
    Only the central review can mark its independently verified roles. Grant policy names may
    be either an installed mechanism ID or its exact AccessDesk policy ID.
    """
    grants = [] if grants is None else grants
    policies = [] if policies is None else policies
    _bounded({'agreements': agreements, 'grants': grants, 'group': group,
        'expected_heads': expected_heads, 'policies': policies})
    _rows(grants)
    _rows(policies)
    roles = _agreement_roles(agreements)
    installed, lookup = _installed_access(tools)
    checked = []
    seen = set()
    for item in grants:
        _fields(item, ('id', 'policy', 'chain', 'subject', 'capability'))
        _label(item['id'])
        need(item['id'] not in seen, 'COORDINATION_DUPLICATE_ITEM')
        seen.add(item['id'])
        p.ref(item['policy'])
        verification_key(item['subject'])
        p.text(item['capability'], 128)
        row = {'id': item['id'], 'policy': item['policy'], 'subject': deepcopy(item['subject']),
            'capability': item['capability'], 'verified': False,
            'delegate_challenge_possession': 'NOT_CHECKED; NO_CHALLENGE_CREATED_OR_CONSUMED',
            'password_factor': 'NOT_CHECKED', 'native_controller_or_payment_authority': False,
            'execution_authorized': False}
        try:
            need(item['policy'] in lookup, 'ACCESS_POLICY_NOT_INSTALLED')
            desk, owner = lookup[item['policy']]
            need(owner['status'] == 'FRESH_OWNER_STATE', owner.get('error', 'ACCESS_POLICY_NOT_INSTALLED'))
            need(item['capability'] in desk.policy['capabilities'], 'COORDINATION_ACCESS_CAPABILITY')
            report = access.verify_chain(item['chain'], context=desk.policy['context'],
                target=desk.policy['target'], operation=desk.policy['operation'],
                subject=item['subject'], capability=item['capability'],
                trusted_issuers=desk.policy['issuers'], now=owner['checked_at'],
                revoked=owner['owner_state']['revoked'], successors=owner['owner_state']['successors'])
            need(desk.public_state() == owner['owner_state'],
                'COORDINATION_ACCESS_STATE_CHANGED_REVIEW_AGAIN')
            row.update(status='VALID_CURRENT_OWNER_SCOPE', verified=report['verified'],
                root=report['root'], leaf=report['leaf'], mechanism=owner['mechanism'],
                owner_state_sequence=owner['owner_state']['sequence'],
                checked_at=owner['checked_at'],
                authority='ISSUER_SIGNED_DELEGATION_ONLY; SEPARATE_DELEGATE_CHALLENGE_AND_EFFECT_APPROVALS')
        except Exception as error:
            row.update(status='REFUSED', error=_error(error))
        checked.append(row)
    return {'version': VERSION, 'agreement_roles': roles, 'installed_access': installed,
        'grants': checked, 'group_authority': _group_roles(tools, group, expected_heads),
        'escrow_scopes': _escrow_scopes(tools, policies),
        'revocation_boundaries': [
            'AGREEMENT_REVISIONS_REQUIRE_THEIR_OWN_EXACT_ADOPTION',
            'ACCESS_GRANT_REVOCATION_IS_SEPARATE_OWNER_CURRENT_STATE',
            'GROUP_ROLE_REVOCATION_APPLIES_TO_LOCAL_GROUP_CAUSAL_POLICY',
            'PAYMENT_CONTROLLERS_REQUIRE_THEIR_OWN_EXACT_EFFECT_SIGNATURES',
            'PRIOR_PLAINTEXT_CANNOT_BE_RECALLED_BY_ANY_REVOCATION'],
        'state_changed': False, 'execution_authorized': False}


def evidence(tools, items, agreement_ids):
    """Verify exact installed proofs without returning proof/witness contents."""
    _bounded({'items': items, 'agreement_ids': agreement_ids})
    _rows(items)
    need(type(agreement_ids) is list and len(agreement_ids) <= MAX_ITEMS,
        'COORDINATION_AGREEMENT_IDS')
    for ref in agreement_ids:
        p.ref(ref)
    known = set(agreement_ids)
    result = []
    seen = set()
    for item in items:
        _fields(item, ('id', 'envelope', 'verifier', 'expected_context', 'expected_statement'), ('agreement',))
        _label(item['id'])
        need(item['id'] not in seen, 'COORDINATION_DUPLICATE_ITEM')
        seen.add(item['id'])
        p.ref(item['verifier'])
        p.ref(item['expected_context'])
        need(type(item['expected_statement']) is dict, 'COORDINATION_PROOF_STATEMENT')
        agreement = item.get('agreement')
        if agreement is not None:
            p.ref(agreement)
        row = {'id': item['id'], 'verifier': item['verifier'],
            'expected_context': item['expected_context'],
            'expected_statement_hash': _hash(item['expected_statement']),
            'statement_hash_domain': 'COVENANT-REVIEW-STATEMENT-0.1',
            'verified': False, 'agreement': agreement,
            'agreement_reference_status': 'NOT_SUPPLIED' if agreement is None else
                'VERIFIED_AGREEMENT_PRESENT' if agreement in known else 'AGREEMENT_NOT_IN_VERIFIED_REVIEW',
            'association': 'CALLER_LINK_ONLY_NOT_SIGNED_TERM_OR_LEGAL_ROOT_ADOPTION',
            'root_adoption': 'UNCHECKED_BY_THIS_HELPER',
            'proof_bytes_and_private_statement_values_returned': False,
            'world_truth': 'NOT_ESTABLISHED', 'authority': 'NOT_ESTABLISHED',
            'execution_authorized': False}
        try:
            # Verification always reaches the exact owner registry; no supplied
            # status, flag, signed assertion, or agreement link can bypass it.
            checked = tools.proofs.verify(item['envelope'], item['verifier'],
                item['expected_context'], item['expected_statement'])
            manifest = tools.proofs.describe().get(item['verifier'])
            row.update(envelope_id=checked['id'], status=checked['status'],
                verified=checked['verified'], system=item['envelope']['system'],
                scope=None if manifest is None else manifest['scope'],
                assumptions=None if manifest is None else manifest['trust'])
            if item['envelope']['system'] == 'sha256-merkle-path/0.1':
                root = item['expected_statement'].get('root')
                if type(root) is str and re.fullmatch('[0-9a-f]{64}', root):
                    row['membership'] = {'root': root, 'verified': checked['verified'],
                        'scope': 'EXACT_LEAF_BYTES_TO_ROOT_ONLY_NOT_TREE_COMPLETENESS_ORDER_OR_WORLD_TRUTH'}
        except Exception as error:
            row.update(status='REFUSED', error=_error(error))
        result.append(row)
    return {'version': VERSION, 'items': result,
        'all_provided_proofs_verified': all(row['verified'] for row in result),
        'statement_hash_metadata': 'IDENTIFIES_EXACT_EXPECTATION; NOT_A_CONFIDENTIALITY_MECHANISM',
        'installed_verifier_boundary': 'OWNER_INSTALLED_LOCAL_CALLBACKS_TRUSTED_AS_READ_ONLY',
        'statement_values_returned': False, 'state_changed': False, 'execution_authorized': False}


def private_copy(tools, plan, step, recipients, value, fields, salts,
                 previous_approvals=None, expected_previous=None):
    """Prepare one PRIVATE step's successor; no delivery or consent is made.

    Passing no fields and no readers explicitly prepares a WITHHELD step.
    An existing protection stack is retained for PRIVATE successors. The old
    plaintext, including unselected fields and salts, is never returned.
    """
    _bounded({'plan': plan, 'step': step, 'recipients': recipients, 'value': value,
        'fields': fields, 'salts': salts, 'previous_approvals': previous_approvals,
        'expected_previous': expected_previous})
    p.validate(plan)
    p.text(step, 64)
    before_id = p.identifier(plan)
    if expected_previous is not None:
        p.ref(expected_previous)
        need(expected_previous == before_id, 'COORDINATION_EXPECTED_PREVIOUS')
    prior = [item for item in plan['steps'] if item['id'] == step]
    need(len(prior) == 1, 'MECHANISM_STEP_MISSING')
    old = prior[0]
    need(old['visibility'] == 'PRIVATE', 'COORDINATION_PRIVATE_STEP_REQUIRED')
    need(type(recipients) is dict, 'MECHANISM_RECIPIENTS')
    need(type(fields) is list and len(fields) <= 32
        and all(type(path) is str for path in fields)
        and len(fields) == len(set(fields)), 'MECHANISM_SELECTORS')
    prior_verified = False
    if previous_approvals is not None:
        p.verify_assents(plan, previous_approvals, before_id, plan['controllers'])
        prior_verified = True
    visibility = 'WITHHELD' if fields == [] and recipients == {} else 'PRIVATE'
    replacement = p.prepare_step(step, old['target'], value, fields, salts, plan['context'],
        visibility=visibility, recipients=recipients,
        protection=[] if visibility == 'WITHHELD' else old['protection'],
        mechanisms=old['mechanisms'], gates=old['gates'], depends_on=old['depends_on'],
        frame=old['frame'])
    steps = [replacement if item['id'] == step else deepcopy(item) for item in plan['steps']]
    successor = p.amend(plan, {'steps': steps})
    assent = p.assent_payload(successor['plan'])
    from .mechanism_runtime import readiness
    return {**successor, 'selected_step': step,
        'change': {'readers_added': sorted(set(recipients) - set(old['recipients'])),
            'readers_removed': sorted(set(old['recipients']) - set(recipients)),
            'reader_descriptors_changed': sorted(name for name in set(recipients) & set(old['recipients'])
                if p.canonical(recipients[name]) != p.canonical(old['recipients'][name])),
            'fields_added': sorted(set(fields) - set(old['fields'])),
            'fields_removed': sorted(set(old['fields']) - set(fields)),
            'field_commitments': deepcopy(replacement['commitments']),
            'visibility_before': old['visibility'], 'visibility_after': visibility},
        'previous_assents_verified': prior_verified,
        'caller_retained_previous_match': None if expected_previous is None else True,
        'assent_payload': assent,
        'readiness': readiness(tools.mechanisms, successor['plan']),
        'protect_followup': {'plan': successor['plan'], 'step': step,
            'expected_id': successor['id'], 'expected_controllers': deepcopy(plan['controllers']),
            'previous': deepcopy(plan), 'expected_previous': before_id,
            'required_missing_inputs': ['FRESH_ALL_CONTROLLER_APPROVALS',
                'SELECTED_VALUE_AND_FRESH_SALTS_MATCHING_THESE_COMMITMENTS', 'EXACT_GATE_EVIDENCE_IF_ANY']},
        'new_assents_verified': False, 'delivery_created': False,
        'private_values_or_salts_returned': False,
        'removed_reader_effect': 'FUTURE_SUCCESSOR_DELIVERIES_ONLY',
        'prior_plaintext_recall': False, 'state_changed': False, 'execution_authorized': False}
