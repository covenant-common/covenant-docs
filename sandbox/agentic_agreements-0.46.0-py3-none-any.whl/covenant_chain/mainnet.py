"""Read-only mainnet preparation checks. Never activate custody from a report.

Signed operator statements bind adopted deployment choices; they do NOT prove
physical independence, service funding, external audits or application truth.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import ssl

from covenant_language.safe_io import atomic_write

from . import app, crypto
from .operator_surface import announce_console_path, release_id
from .security import readiness
from .transport import validate_https_peers,validate_pins

STATEMENT_LABEL='COVENANT-OPERATOR-LAUNCH-0.1'
GATES=[
 ('G01','Independent native application interpreter and consensus review','Independent engineering reviewer',
  'Complete native replay agrees on valid and invalid corpus; signed scope, reviewed consensus assumptions and unresolved findings published.'),
 ('G02','External cryptography and security review','Independent security reviewer',
  'Pinned candidate, dependencies, custody, privacy and transport reviewed; critical/high findings remediated and regression-tested.'),
 ('G03','Patched TLS and Internet transport qualification','Network operators',
  'Both signature and Python TLS backends pass adopted advisory floors; pins/rotation, malformed traffic, handshake/connection floods and public edge defenses exercised.'),
 ('G04','Independent multi-host testnet and recovery','At least 3f+1 independent validator operators',
  'Separate hosts/fault domains; <=f crashes/Byzantine schedules; regional partitions, restart, catchup, load and soak; retained common-prefix/inclusion evidence.'),
 ('G05','Signing-state custody and compromise recovery','Validator operators and independent custodian',
  'Unique live signer, protected monotone state, host/disk loss drills; lost state cannot restart same key; certified succession to new identities; key compromise procedure exercised.'),
 ('G06','Funded retention and operational availability','Archive operators and treasury owner',
  'Independent archives actually recover bytes/meaning; signed retention terms, measured restore/availability and funded service obligations exist.'),
 ('G07','Adopted genesis, rights and service admission','Founder and adopting counterparties',
  'Final genesis/allocation, named governance scope/exit, validator admission, fee or sponsorship policy, dissent, dispute/appeal and incident procedures assented before reliance.'),
 ('G08','Auditable release and source provenance','Release maintainers and adopting operators',
  'Exact candidate hashes independently retained; clean installed tests and reproducible builds; no secret material; signed release ceremony and rollback/upgrade procedures reviewed.'),
]


def read_bounded(path, maximum=4_000_000):
    with Path(path).open('rb') as f:raw=f.read(maximum+1)
    crypto.need(len(raw)<=maximum,'MAINNET_INPUT_SIZE')
    return raw


def operator_statement(key,genesis,member,endpoint,pins,operator,host):
    crypto.need(member in genesis['validators'] and crypto.public_key(key)==genesis['validators'][member],'MAINNET_OPERATOR_KEY')
    validate_https_peers({member:endpoint});validate_pins({member:pins})
    body={'v':'covenant-operator-launch/0.1','chain':crypto.genesis_id(genesis),
          'member':member,'endpoint':endpoint,'tls_pins':pins,'operator':operator,'host':host}
    crypto.canonical(body)
    return {'body':body,'signature':crypto.sign(key,STATEMENT_LABEL,body)}


def check_operator_statements(genesis,peers,pins,statements):
    crypto.need(type(statements) is list and len(statements)==len(peers),'MAINNET_OPERATOR_STATEMENTS')
    adopted_chain=crypto.genesis_id(genesis)
    seen=set();operators=set();hosts=set()
    for statement in statements:
        crypto.exact(statement,'body signature');body=statement['body']
        crypto.exact(body,'v chain member endpoint tls_pins operator host')
        member=body['member'];crypto.need(member in peers and member not in seen,'MAINNET_OPERATOR_MEMBER')
        crypto.need(body['v']=='covenant-operator-launch/0.1' and body['chain']==adopted_chain,'MAINNET_OPERATOR_CHAIN')
        crypto.need(body['endpoint']==peers[member] and body['tls_pins']==pins[member],'MAINNET_OPERATOR_TRANSPORT')
        for field in ('operator','host'):
            value=body[field];crypto.need(type(value) is str and 0<len(value)<=80 and value!='PENDING','MAINNET_OPERATOR_DOMAIN')
        crypto.verify(genesis['validators'][member],STATEMENT_LABEL,body,statement['signature'])
        seen.add(member);operators.add(body['operator']);hosts.add(body['host'])
    crypto.need(len(operators)==len(peers) and len(hosts)==len(peers),'MAINNET_ASSERTED_CONCENTRATION')
    return {'signed_statements':len(seen),'claimed_operators':len(operators),'claimed_hosts':len(hosts),
            'physical_independence_verified':False}


def prepare_report(plan,base):
    crypto.exact(plan,'v genesis_file genesis_sha256 release_sha256 peers tls_pins operator_statements policies')
    crypto.need(plan['v']=='covenant-mainnet-plan/0.1','MAINNET_PLAN_VERSION')
    result={'candidate':release_id(),'public_mainnet_ready':False,'purpose':'Preparation only; no network or custody activation',
            'runtime':readiness(),'checks':[],'gates':[{'id':gid,'requirement':name,'responsible_role':role,'exit_criteria':exit,'status':'OPEN'} for gid,name,role,exit in GATES]}
    def checked(name,action):
        try:value=action();result['checks'].append({'check':name,'passed':True,'detail':value});return value
        except (ValueError,KeyError,TypeError,OSError) as exc:
            result['checks'].append({'check':name,'passed':False,'detail':str(exc)[:250]});return None
    def genesis_check():
        crypto.need(type(plan['genesis_file']) is str and plan['genesis_file']!='PENDING','FINAL_GENESIS_NOT_ADOPTED')
        crypto.key(plan['genesis_sha256']);crypto.key(plan['release_sha256'])
        raw=read_bounded(Path(base)/plan['genesis_file'])
        crypto.need(hashlib.sha256(raw).hexdigest()==plan['genesis_sha256'],'MAINNET_GENESIS_BYTE_PIN')
        genesis=crypto.loads(raw);app.genesis_state(genesis)
        crypto.need(genesis['protocol'] in {app.EXTENSIBLE_VERSION,app.ECONOMIC_VERSION,app.CONFIDENTIAL_VERSION},'MAINNET_PROFILE_NOT_ADOPTED')
        return genesis
    genesis=checked('independently pinned final genesis',genesis_check)
    def peer_check():
        validate_https_peers(plan['peers']);validate_pins(plan['tls_pins'],plan['peers'])
        if genesis is not None:crypto.need(set(plan['peers'])==set(genesis['validators']),'MAINNET_PEER_COMMITTEE')
        return {'static_adopted_members':len(plan['peers'])}
    checked('bounded TLS peer registry',peer_check)
    if genesis is not None:
        result['chain']=crypto.genesis_id(genesis)
        checked('operator launch statements',lambda:check_operator_statements(genesis,plan['peers'],plan['tls_pins'],plan['operator_statements']))
    else:result['checks'].append({'check':'operator launch statements','passed':False,'detail':'Final genesis prerequisite absent'})
    def policy_check():
        crypto.exact(plan['policies'],'governance admission incidents custody archives funding')
        for name,pin in plan['policies'].items():crypto.key(pin)
        return 'Content pins declared; policy bytes, adoption, funding and adequacy require independent review'
    checked('explicit adopted policy content references',policy_check)
    result['configuration_complete']=all(check['passed'] for check in result['checks'])
    result['optional_unqualified_claims']=result['runtime']['optional_claims_not_qualified']
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',required=True,type=Path)
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    announce_console_path()
    report=prepare_report(crypto.loads(read_bounded(args.plan)),args.plan.parent)
    encoded=json.dumps(report,indent=2)+'\n'
    if args.out:atomic_write(args.out,encoded)
    print(encoded,end='')
    raise SystemExit(0 if report['public_mainnet_ready'] else 1)


if __name__=='__main__':main()
