"""Encrypted local custody and explicit delivery queue. No background effects."""
from contextlib import contextmanager
from copy import deepcopy
import secrets
import threading

from . import crypto as c, offline as o
from .workflow_store import WorkflowStore

VERSION = 'covenant-offline-vault/0.1'
MAX_RECORD = 196608


class OfflineStore:
    def __init__(self, directory, *, owner, scope, storage_key, retained_head=None):
        c.need(type(owner) is str, 'OFFLINE_ED25519_ONLY')
        c.verification_key(owner); c.key(scope); o._key(storage_key)
        self.cipher = o.transport_cipher()(storage_key)
        self.owner, self.scope, self.key = owner, scope, storage_key
        self.context = {'version': VERSION, 'owner': owner, 'scope': scope,
                        'key_id': o.key_id(storage_key)}
        self.lock = threading.RLock()
        self.store = WorkflowStore(directory, self.context, check_same_thread=False)
        try:
            with self._locked():
                self._records(retained_head)
        except BaseException:
            self.store.close()
            raise

    @contextmanager
    def _locked(self):
        with self.lock, self.store.exclusive():
            yield

    def _aad(self, sequence, previous):
        return c.canonical({'context': self.context, 'sequence': sequence, 'previous': previous})

    def _records(self, retained_head=None):
        events = self.store.events(); records = {}
        if retained_head is not None:
            c.key(retained_head)
            c.need(retained_head == '0'*64 or any(e['id'] == retained_head for e in events),
                   'OFFLINE_RETAINED_HEAD_MISSING')
        for event in events:
            body = event['body']; c.exact(body, 'kind task value')
            c.need(body['kind'] == 'SEALED' and body['task'] == 'vault', 'OFFLINE_VAULT_EVENT')
            sealed = body['value']; c.exact(sealed, 'nonce chunks')
            chunks = sealed['chunks']
            c.need(type(chunks) is list and 1 <= len(chunks) <= 9 and
                   all(type(x) is str and 0 < len(x) <= 32768 for x in chunks), 'OFFLINE_VAULT_CHUNKS')
            nonce = o.unb64(sealed['nonce'], 12); c.need(len(nonce) == 12, 'OFFLINE_VAULT_NONCE')
            cipher = o.unb64(''.join(chunks), MAX_RECORD+16)
            try:
                raw = self.cipher.decrypt(nonce, cipher,
                    self._aad(event['sequence'], event['previous']))
            except Exception as exc:
                raise ValueError('OFFLINE_VAULT_AUTHENTICATION') from exc
            record = o.exact_load(raw, MAX_RECORD); c.exact(record, 'key value')
            c.need(type(record['key']) is str, 'OFFLINE_VAULT_KEY')
            records[record['key']] = record['value']
        return records

    def _put(self, key, value):
        raw = c.canonical({'key': key, 'value': value})
        c.need(len(raw) <= MAX_RECORD, 'OFFLINE_VAULT_RECORD_SIZE')
        history = self.store.events(); seq = len(history)+1
        previous = history[-1]['id'] if history else '0'*64
        nonce = secrets.token_bytes(12)
        encrypted = o.b64(self.cipher.encrypt(nonce, raw, self._aad(seq, previous)))
        self.store.append('SEALED', 'vault', {'nonce': o.b64(nonce),
            'chunks': [encrypted[i:i+32768] for i in range(0, len(encrypted), 32768)]})

    def _clock(self, now, records):
        c.integer(now)
        c.need(now >= records.get('clock', 0), 'OFFLINE_CLOCK_ROLLBACK')
        if now > records.get('clock', 0):
            self._put('clock', now)

    def checkpoint(self):
        with self._locked():
            self._records()
            events = self.store.events()
            return events[-1]['id'] if events else '0'*64

    def ingest_frame(self, frame, *, now):
        """Persist incomplete fragments encrypted; restart can resume reception.

        The returned complete bytes still require independent packet validation
        and durable retention. A crash in that gap requires exact retransmission.
        """
        from .offline_carriers import Reassembler
        with self._locked():
            state = self._records().get('fragments', [])
            self._clock(now, self._records())
            assembler = Reassembler(max_bytes=68000)
            assembler.restore(state, now=now)
            raw = assembler.accept(frame, now=now)
            self._put('fragments', assembler.snapshot())
            return raw

    def cache_agreement(self, agreement, assents, *, expected_id, now):
        o.review(agreement, assents, expected_id=expected_id, now=now)
        c.need(agreement['scope'] == self.scope, 'OFFLINE_AGREEMENT_SCOPE')
        with self._locked():
            records = self._records(); key = 'agreement:'+expected_id
            self._clock(now, records)
            old = records.get(key, {'agreement': agreement, 'assents': []})
            c.need(c.canonical(old['agreement']) == c.canonical(agreement), 'OFFLINE_AGREEMENT_CONFLICT')
            merged = {a['signer']: a for a in old['assents']}
            for a in assents:
                c.need(a['signer'] not in merged or merged[a['signer']] == a, 'OFFLINE_ASSENT_CONFLICT')
                merged[a['signer']] = deepcopy(a)
            new = {'agreement': deepcopy(agreement), 'assents': [merged[k] for k in sorted(merged)]}
            result = o.review(**new, expected_id=expected_id, now=now)
            if old != new or key not in records:
                self._put(key, new)
            return result

    def agreement(self, reference, *, now):
        c.key(reference)
        with self._locked():
            records = self._records(); self._clock(now, records)
            value = records.get('agreement:'+reference)
            c.need(value is not None, 'OFFLINE_AGREEMENT_MISSING')
            return {**deepcopy(value), 'review': o.review(**value, expected_id=reference, now=now)}

    def enqueue(self, packet, *, now):
        ref = o.inspect_packet(packet, scope=self.scope, allowed_senders={self.owner}, now=now)
        with self._locked():
            key = 'packet:'+ref; records = self._records()
            self._clock(now, records)
            if key not in records:
                self._put(key, {'packet': packet, 'direction': 'OUT', 'attempts': 0,
                                'next_attempt': now, 'ack': None})
        return ref

    def retain(self, packet, *, allowed_senders, now, shared_key=None, relay=False):
        c.need(type(relay) is bool, 'OFFLINE_RELAY_POLICY')
        ref = o.inspect_packet(packet, scope=self.scope, allowed_senders=allowed_senders, now=now)
        c.need((packet['header']['recipient'] != self.owner) == relay, 'OFFLINE_DESTINATION_POLICY')
        payload = None if relay else o.open_packet(packet, recipient=self.owner, shared_key=shared_key,
            scope=self.scope, allowed_senders=allowed_senders, now=now)
        with self._locked():
            key = 'packet:'+ref; records = self._records()
            self._clock(now, records)
            if key not in records:
                self._put(key, {'packet': packet, 'payload': payload, 'direction': 'RELAY' if relay else 'IN',
                                'attempts': 0, 'next_attempt': now, 'ack': None})
        # Retention does not assent to terms or execute received instructions.
        return ref

    def note_carried_agreement(self, reference, *, now):
        """Read an imported drop that already carries assents. A bare retain does not."""
        value = self.packet(reference).get('payload')
        if type(value) is not dict or value.get('kind') != 'AGREEMENT':
            return None
        carried = value.get('value')
        if type(carried) is not dict or not (set(carried) >= {'agreement', 'assents'} and type(carried.get('assents')) is list):
            return None
        agreement = carried['agreement']
        if type(agreement) is not dict or agreement.get('scope') != self.scope:
            return None
        return self.cache_agreement(agreement, carried['assents'], expected_id=o.agreement_id(agreement), now=now)

    def packet(self, reference):
        c.key(reference)
        with self._locked():
            value = self._records().get('packet:'+reference)
            c.need(value is not None, 'OFFLINE_PACKET_MISSING')
            return deepcopy(value)

    def pending(self, *, now, limit=16):
        c.integer(now); c.need(type(limit) is int and 1 <= limit <= 64, 'OFFLINE_QUEUE_LIMIT')
        with self._locked():
            records = self._records(); self._clock(now, records)
            return [{'id': k[7:], 'packet': deepcopy(v['packet']), 'attempts': v['attempts']}
                    for k, v in records.items() if k.startswith('packet:') and
                    v['direction'] in ('OUT', 'RELAY') and v['ack'] is None and
                    v['next_attempt'] <= now < v['packet']['header']['expires']][:limit]

    def record_attempt(self, reference, *, now):
        c.integer(now); c.key(reference)
        with self._locked():
            records = self._records(); self._clock(now, records)
            key = 'packet:'+reference; value = records.get(key)
            c.need(value is not None and value['direction'] in ('OUT', 'RELAY') and
                   value['ack'] is None and value['next_attempt'] <= now < value['packet']['header']['expires'],
                   'OFFLINE_NOT_DUE')
            value['attempts'] += 1
            value['next_attempt'] = min(now + min(3600, 5*2**min(value['attempts']-1, 10)), 2**53-1)
            self._put(key, value)

    def acknowledge(self, reference, ack):
        c.key(reference)
        with self._locked():
            key = 'packet:'+reference; value = self._records().get(key)
            c.need(value is not None, 'OFFLINE_PACKET_MISSING')
            result = o.verify_ack(ack, value['packet'])
            if value['ack'] is None:
                value['ack'] = deepcopy(ack); self._put(key, value)
            return result

    def status(self, reference, *, now):
        c.integer(now)
        with self._locked():
            self._clock(now, self._records())
            # Do not nest filesystem lock contexts: flock unlock is process-wide.
            value = self._records().get('packet:'+reference)
            c.need(value is not None, 'OFFLINE_PACKET_MISSING')
        status = ('RECIPIENT_RETAINED' if value['ack'] else 'RECEIVED' if value['direction'] == 'IN'
                  else 'EXPIRED' if now >= value['packet']['header']['expires'] else 'AWAITING_DELIVERY')
        return {'id': reference, 'delivery': status, 'attempts': value['attempts'],
                'next_attempt': value['next_attempt'], 'ledger_confirmed': False, 'payment_verified': False}

    def overview(self, *, now):
        c.integer(now)
        with self._locked():
            records = self._records()
            self._clock(now, records)
            agreements = []
            evidence = []
            packets = []
            for k, v in records.items():
                if k.startswith('agreement:'):
                    row = o.review(**v, expected_id=k[10:], now=now)
                    row['terms'] = deepcopy(v['agreement'].get('terms'))
                    agreements.append(row)
                elif k.startswith('packet:'):
                    packets.append({'id': k[7:], 'direction': v['direction'],
                        'delivery': 'RECIPIENT_RETAINED' if v['ack'] else 'RECEIVED' if v['direction'] == 'IN'
                        else 'EXPIRED' if now >= v['packet']['header']['expires'] else 'AWAITING_DELIVERY',
                        'attempts': v['attempts'], 'next_attempt': v['next_attempt']})
                    payload = v.get('payload') if type(v.get('payload')) is dict else None
                    attachment = payload.get('value') if payload and payload.get('kind') == 'DATA' else None
                    if type(attachment) is dict and attachment.get('profile') == o.EVIDENCE_ATTACHMENT:
                        evidence.append({'packet': k[7:], 'media_type': attachment.get('media_type'),
                                         'sha256': attachment.get('sha256')})
            return {'owner': self.owner, 'scope': self.scope, 'agreements': agreements,
                    'evidence': evidence, 'packets': packets, 'ledger_confirmed': False,
                    'payment_verified': False}

    def apply_courier(self, reference, node):
        """Explicit native receiver; only its unchanged checks can accept items."""
        from .courier import receive
        value = self.packet(reference); payload = value.get('payload')
        c.need(value['direction'] == 'IN' and payload and payload['kind'] == 'COURIER', 'OFFLINE_NOT_COURIER')
        result = receive(node, payload['value'])
        # A certificate message still does not establish a particular payment.
        certified = (payload['value']['body']['kind'] == 'CERTIFIED_HISTORY' and
                     all(x['accepted'] for x in result['results']))
        return {**result, 'ledger_certificate_verified': certified, 'payment_verified': False}

    def close(self):
        with self.lock:
            self.store.close()


def describe_vault():
    """Vault bounds (salvaged Cursor PR 58). Reading them does not open a store or move funds."""
    return {'version': VERSION, 'max_record': MAX_RECORD, 'execution_authorized': False}
