"""Read-only agent tools for onboarding, invites and growth views.

They prepare payloads and local keys. They do not submit transactions.
"""
from copy import deepcopy

from .cooperation_interface import HASH, INT, OBJECT, TEXT, schema, tool


def action_schema(actions):
    return {'type': 'object', 'oneOf': [
        schema({'action': {'const': name}, 'parameters': schema(properties, required)}, ('action', 'parameters'))
        for name, properties, required in actions]}
from .crypto import need, public_key

HASH_OR_NULL = {'type': ['string', 'null'], 'pattern': '^[0-9a-f]{64}$'}
LONG_HASH_OR_NULL = {'type': ['string', 'null'], 'pattern': '^[0-9a-f]{128}$'}
LABEL = {'type': 'string', 'minLength': 1, 'maxLength': 80}


def specs():
    from .welcome import INTENT_SCHEMA
    onboard = [
        ('start', {}, ()),
        ('work', {}, ()),
        ('guide', {'query': {'type': 'string', 'maxLength': 400},
                   'task': LABEL, 'parameters': OBJECT}, ()),
        ('taxonomy', {'tool': LABEL, 'module': {'type': 'string', 'minLength': 1, 'maxLength': 256}}, ()),
        ('preview', {'intent': INTENT_SCHEMA}, ('intent',)),
        ('discover', {}, ()),
        ('ensure_key', {}, ()),
        ('registry', {}, ()),
        ('free_tier', {
            'resource': LABEL,
            'actors': {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': HASH},
            'operations': {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': LABEL},
            'unit_fee': {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
            'first_n': {'type': 'integer', 'minimum': 1, 'maximum': 64},
            'expiry': {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
            'verification_method': {'enum': ['PASSKEY', 'PERSONHOOD', 'STAKE', 'IDENTITY']},
            'verification_subject': HASH,
            'issuer_accepted': {'const': True},
        }, ('resource', 'actors', 'operations', 'unit_fee', 'first_n', 'expiry',
            'verification_method', 'verification_subject', 'issuer_accepted')),
    ]
    invite = [
        ('draft', {
            'chain': HASH, 'role': {'enum': ['COUNTERPARTY', 'RESOLVER', 'APPEAL_RESOLVER']},
            'principal': HASH, 'agent': HASH_OR_NULL, 'counterparty': HASH_OR_NULL,
            'resolver': HASH_OR_NULL, 'appeal_resolver': HASH_OR_NULL, 'mandate': HASH_OR_NULL,
            'profile': LABEL, 'resource': LABEL, 'quantity': {'type': 'integer', 'minimum': 1},
            'effect': {'enum': ['TRANSFER', 'CONSUME', 'AUTHORIZE']},
            'destination': {'type': 'string', 'minLength': 1, 'maxLength': 256},
            'executor': HASH, 'deadline': {'type': 'integer', 'minimum': 1},
            'challenge_blocks': {'type': 'integer', 'minimum': 1, 'maximum': 10000},
            'timeout': {'enum': ['RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION']},
            'terms_hash': HASH, 'terms_pin': HASH, 'projection': LONG_HASH_OR_NULL,
            'expiry': {'type': 'integer', 'minimum': 1},
            'unit_fee': {'type': 'integer', 'minimum': 1},
            'sponsor_resource': LABEL, 'sponsor_expiry': {'type': 'integer', 'minimum': 1},
            'height': INT,
        }, ('chain', 'role', 'principal', 'agent', 'counterparty', 'resolver', 'appeal_resolver',
            'mandate', 'profile', 'resource', 'quantity', 'effect', 'destination', 'executor',
            'deadline', 'challenge_blocks', 'timeout', 'terms_hash', 'terms_pin', 'projection',
            'expiry', 'unit_fee', 'sponsor_resource', 'sponsor_expiry', 'height')),
        ('accept', {
            'bundle': OBJECT, 'method': {'enum': ['EPHEMERAL_KEY', 'PASSKEY']},
            'height': INT, 'assertion': OBJECT, 'origin': TEXT,
        }, ('bundle', 'method', 'height')),
        ('transport', {'bundle': OBJECT}, ('bundle',)),
        ('accountability', {'inviter': HASH}, ('inviter',)),
    ]
    growth = [
        ('card', {
            'chain': HASH, 'agreement': HASH, 'status': {'enum': ['BOUND', 'SETTLED']},
            'terms_hash': HASH, 'role': {'enum': ['COUNTERPARTY', 'RESOLVER', 'APPEAL_RESOLVER', 'AGENT']},
            'quantity': {'type': 'integer', 'minimum': 1},
            'parties': {'type': 'array', 'minItems': 1, 'maxItems': 4, 'items': HASH},
            'opt_in': {'type': 'boolean'}, 'referrer': HASH,
            'platforms': {'type': 'array', 'minItems': 1, 'maxItems': 5, 'items': {
                'enum': ['open_graph', 'x', 'linkedin', 'farcaster', 'telegram']}},
        }, ('chain', 'agreement', 'status', 'terms_hash', 'role', 'quantity', 'parties',
            'opt_in', 'referrer', 'platforms')),
        ('qualify', {'chain': HASH, 'as_of': INT, 'domain': HASH}, ('chain', 'as_of', 'domain')),
        ('leaderboard', {'chain': HASH, 'actors': {'type': 'array', 'maxItems': 64, 'items': HASH}},
         ('chain', 'actors')),
        ('boundary', {}, ()),
        ('clawback', {'chain': HASH, 'actor': HASH, 'reason': LABEL}, ('chain', 'actor', 'reason')),
        ('viral', {
            'windows': {'type': 'array', 'maxItems': 256, 'items': OBJECT},
            'desk': {'type': 'object', 'properties': {
                'chain': HASH, 'niche': LABEL, 'start': INT, 'end': INT,
                'invite_ids': {'type': 'array', 'maxItems': 4096, 'items': HASH},
                'agreements': {'type': 'array', 'maxItems': 4096, 'items': HASH},
            }, 'required': ['chain', 'niche', 'start', 'end', 'invite_ids', 'agreements'],
                'additionalProperties': False},
        }, ()),
        ('monoculture', {
            'observations': {'type': 'array', 'maxItems': 4096, 'items': OBJECT},
            'threshold_bps': {'type': 'integer', 'minimum': 1, 'maximum': 9999},
        }, ('observations',)),
        ('rebate_tier', {
            'honoured': INT, 'settled': INT, 'lost_disputes': INT, 'fees_paid': INT,
            'season_closed': {'type': 'boolean'},
            'tiers': {'type': 'array', 'minItems': 1, 'maxItems': 8, 'items': {
                'type': 'array', 'minItems': 2, 'maxItems': 2, 'items': INT}},
        }, ('honoured', 'settled', 'lost_disputes', 'fees_paid', 'season_closed')),
        ('agent_share', {
            'settlements': {'type': 'array', 'maxItems': 4096, 'items': OBJECT},
            'budget': INT,
            'owner_cap_bps': {'type': 'integer', 'minimum': 1, 'maximum': 10000},
        }, ('settlements', 'budget')),
        ('zakat', {
            'holdings': {'type': 'array', 'maxItems': 64, 'items': OBJECT},
            'nisab': {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
            'unit': {'type': 'string', 'minLength': 1, 'maxLength': 32},
            'debts': INT, 'hawl_complete': {'type': 'boolean'},
            'giver': HASH, 'recipient': HASH,
            'recipient_class': {'enum': ['FUQARA', 'MASAKIN', 'AMILIN', 'MUALLAFAH', 'RIQAB', 'GHARIMIN',
                                         'FI_SABILILLAH', 'IBN_SABIL']},
        }, ('holdings', 'nisab', 'unit')),
    ]
    return [
        tool('covenant_onboard',
             "Start here: three steps (propose, accept, settle) with exact calls; guide maps a task to its next call. A deal is a promise both sides sign. Proof shows it was kept. If it wasn't, there is a fair way to fix it. Signs nothing.",
             action_schema(onboard), readonly=True, idempotent=True),
        tool('covenant_invite',
             'Draft a signed invite for a missing counterparty, resolver or appeal resolver. Accept with a local key or passkey. The first fee is a sponsor payload spent only by BIND. No new consensus operation.',
             action_schema(invite), readonly=True, idempotent=False),
        tool('covenant_growth',
             'Opt-in redacted share cards and covenant-native/0.15 incentive views. One-level referral, 20 percent holdback, no clicks. Status is non-transferable. Read-only views: viral coefficient per niche, monoculture alarm, season rebate tier, ad-funded agent token share, and an opt-in zakat calculator. Views never pay, transfer or submit.',
             action_schema(growth), readonly=True, idempotent=True),
    ]


def _store(exchange):
    store = getattr(exchange, 'local_keys', None)
    need(store is not None, 'LOCAL_KEY_STORE_ABSENT')
    return store


def _invites(exchange):
    if getattr(exchange, '_invite_desk', None) is None:
        from .invite import InviteDesk
        exchange._invite_desk = InviteDesk()
    return exchange._invite_desk


def _growth(exchange, chain):
    desk = getattr(exchange, '_growth_desk', None)
    if desk is None:
        from .growth import GrowthDesk
        exchange._growth_desk = GrowthDesk(chain)
    else:
        need(desk.chain == chain, 'GROWTH_CHAIN')
    return exchange._growth_desk


def dispatch(exchange, name, action, parameters):
    if name == 'covenant_onboard':
        return _onboard(exchange, action, parameters)
    if name == 'covenant_invite':
        return _invite(exchange, action, parameters)
    if name == 'covenant_growth':
        return _growth_call(exchange, action, parameters)
    raise ValueError('ADOPTION_TOOL')


def _onboard(exchange, action, parameters):
    from . import onboarding
    if action == 'taxonomy':
        from . import aap_levels
        need(not ('tool' in parameters and 'module' in parameters), 'TAXONOMY_SELECT_ONE')
        result = aap_levels.summary()
        result['parallel_navigation'] = {'enabled': getattr(exchange, 'navigation', None) is not None,
            'entry': 'covenant_onboard.guide', 'owner_setup': '--navigation-config',
            'telemetry': False, 'automatic_publication': False}
        if 'tool' in parameters:
            result['selection'] = {'tool': parameters['tool'], 'level': aap_levels.tool_level(parameters['tool'])}
        if 'module' in parameters:
            result['selection'] = {'module': parameters['module'], 'level': aap_levels.module_level(parameters['module'])}
        return {**result, 'execution_authorized': False, 'authority_changed': False}
    if action == 'guide':
        advisor = getattr(exchange, 'navigation', None)
        return advisor.guide(parameters) if advisor is not None else onboarding.task_guide(**parameters)
    if action == 'work':
        return onboarding.paid_work()
    if action in {'start', 'preview'}:
        from . import welcome
        return welcome.start() if action == 'start' else welcome.preview(parameters['intent'])
    if action == 'discover':
        return {'install': onboarding.install_card(), 'verifiers': onboarding.verifier_pins(),
                'openapi': '/.well-known/openapi.json', 'well_known': '/.well-known/covenant.json',
                'consensus_operation_added': False, 'execution_authorized': False}
    if action == 'registry':
        return onboarding.registry_listing()
    if action == 'ensure_key':
        store = _store(exchange)
        return {'public': store.public(), 'created_silently': True, 'wallet_required': False,
                'execution_authorized': False}
    verification = {
        'method': parameters['verification_method'],
        'subject': parameters['verification_subject'],
        'issuer_accepted': parameters['issuer_accepted'],
    }
    return onboarding.free_tier_sponsor(
        resource=parameters['resource'], actors=sorted(parameters['actors']),
        operations=sorted(parameters['operations']), unit_fee=parameters['unit_fee'],
        first_n=parameters['first_n'], expiry=parameters['expiry'], verification=verification)


def _invite(exchange, action, parameters):
    from .invite import transports
    desk = _invites(exchange)
    if action == 'accountability':
        return desk.accountability(parameters['inviter'])
    if action == 'transport':
        return transports(parameters['bundle'])
    if action == 'draft':
        store = _store(exchange)
        offer = deepcopy(parameters)
        height = offer.pop('height')
        issued = desk.issue(store.load(), offer, height=height)
        issued['inviter'] = public_key(store.load())
        return issued
    if action == 'accept':
        store = _store(exchange)
        accepted = desk.accept(parameters['bundle'], parameters['method'], height=parameters['height'],
                               assertion=parameters.get('assertion'), origin=parameters.get('origin'), store=store)
        need('local_key' not in accepted, 'INVITE_SECRET_LEAK')
        accepted['public'] = store.public()
        return accepted
    raise ValueError('INVITE_ACTION')


def _growth_views(exchange, action, parameters):
    if action == 'viral':
        from .network_effects import viral_coefficient, window_counts
        windows = list(parameters.get('windows', []))
        if 'desk' in parameters:
            desk = parameters['desk']
            windows.append(window_counts(
                _invites(exchange), _growth(exchange, desk['chain']), niche=desk['niche'],
                start=desk['start'], end=desk['end'], invite_ids=desk['invite_ids'],
                agreements=desk['agreements']))
        return viral_coefficient(windows)
    if action == 'monoculture':
        from .network_effects import THRESHOLD_BPS, monoculture
        return monoculture(parameters['observations'],
                           threshold_bps=parameters.get('threshold_bps', THRESHOLD_BPS))
    if action == 'rebate_tier':
        from .rebate_tiers import DEFAULT_TIERS, rebate_tier
        return rebate_tier(honoured=parameters['honoured'], settled=parameters['settled'],
                           lost_disputes=parameters['lost_disputes'], fees_paid=parameters['fees_paid'],
                           season_closed=parameters['season_closed'],
                           tiers=parameters.get('tiers', DEFAULT_TIERS))
    if action == 'agent_share':
        from .ads.token_share import OWNER_CAP_BPS, agent_token_payout
        return agent_token_payout(parameters['settlements'], budget=parameters['budget'],
                                  owner_cap_bps=parameters.get('owner_cap_bps', OWNER_CAP_BPS))
    from .zakat import giving_template, zakat_due
    template_fields = ('giver', 'recipient', 'recipient_class')
    present = [name for name in template_fields if name in parameters]
    need(not present or len(present) == len(template_fields), 'ZAKAT_TEMPLATE_FIELDS')
    due = zakat_due(parameters['holdings'], nisab=parameters['nisab'], unit=parameters['unit'],
                    debts=parameters.get('debts', 0), hawl_complete=parameters.get('hawl_complete', True))
    due['template'] = None
    if present and due['due'] > 0:
        due['template'] = giving_template(due['due'], unit=parameters['unit'], giver=parameters['giver'],
                                          recipient=parameters['recipient'],
                                          recipient_class=parameters['recipient_class'])
    return due


GROWTH_VIEWS = ('viral', 'monoculture', 'rebate_tier', 'agent_share', 'zakat')


def _growth_call(exchange, action, parameters):
    from .growth import placement_boundary, share_card
    if action in GROWTH_VIEWS:
        return _growth_views(exchange, action, parameters)
    if action == 'boundary':
        return placement_boundary()
    if action == 'card':
        receipt = {name: parameters[name] for name in
                   ('chain', 'agreement', 'status', 'terms_hash', 'role', 'quantity', 'parties')}
        return share_card(receipt, opt_in=parameters['opt_in'], referrer=parameters['referrer'],
                          platforms=parameters['platforms'])
    if action == 'leaderboard':
        return _growth(exchange, parameters['chain']).leaderboard(parameters['actors'])
    desk = _growth(exchange, parameters['chain'])
    if action == 'clawback':
        return desk.clawback(parameters['actor'], parameters['reason'])
    if action == 'qualify':
        return desk.qualify(as_of=parameters['as_of'], domain=parameters['domain'])
    raise ValueError('GROWTH_ACTION')
