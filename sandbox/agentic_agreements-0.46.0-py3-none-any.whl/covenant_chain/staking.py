"""Rules for the service-bond stake that already lives in market.py.

STAKE_OPEN, STAKE_EXIT, STAKE_WITHDRAW, STAKE_CLAIM and STAKE_SLASH move the units.
Rewards are a share of the reserve pot for work done. There is no APY and this
module does not move balances. Roles are validators, referees and ad-outcome
attesters. Holders delegate to them. Longer locks weigh more. Slashed stake is
partly burned and partly paid to the harmed party, and delegators are slashed
with the operator they chose. Unbonding is illustrative 21 days. A position
cannot vote to raise user costs. Shariah mode adds: no rehypothecation and no
liquid-staking receipt.
"""
from .crypto import exact, integer, key, need, verify
from .token_invariants import EFFICIENCY_RATCHET_FLOOR_BPS

ROLES = ('VALIDATOR', 'REFEREE', 'AD_ATTESTER')
FAULTS = ('DOUBLE_SIGN', 'FALSE_ATTESTATION', 'NO_RULING')
MIN_LOCK_DAYS = 30
MAX_LOCK_DAYS = 1460
UNBOND_DAYS = 21
SLASH_BPS = 1000
SLASH_BURN_BPS = 5000
STAKER_REVENUE_BPS = 2000
MAX_VE = 10**15


def lock_blocks(days, blocks_per_day):
    integer(days, True)
    integer(blocks_per_day, True)
    need(MIN_LOCK_DAYS <= days <= MAX_LOCK_DAYS, 'STAKE_LOCK')
    return days * blocks_per_day


def unbond_blocks(blocks_per_day):
    integer(blocks_per_day, True)
    return UNBOND_DAYS * blocks_per_day


def ve_power(amount, lock, max_lock):
    """ve-style weight. A 4-year lock is the whole amount. A 1-month lock is the short end."""
    integer(amount)
    integer(lock)
    integer(max_lock, True)
    if amount <= 0 or lock <= 0:
        return 0
    span = min(lock, max_lock)
    return min(amount * span // max_lock, MAX_VE)


def position_weight(position, work_credits, max_lock):
    """Revenue weight is ve times work. A lock with no work earns nothing."""
    integer(work_credits)
    if work_credits <= 0 or position.get('unbonding'):
        return 0
    return ve_power(position['amount'], position['lock_blocks'], max_lock) * work_credits


def claimable(cash, weight, total_weight, already):
    integer(cash)
    integer(weight)
    integer(total_weight)
    integer(already)
    if total_weight <= 0 or weight <= 0 or cash <= 0:
        return 0
    share = cash * weight // total_weight
    return max(0, share - already)


def slash_parts(amount):
    integer(amount)
    burn = amount * SLASH_BURN_BPS // 10000
    harmed = amount - burn
    return {'burn': burn, 'harmed': harmed, 'amount': amount}


def may_vote(proposal):
    """Staked weight is zero on a proposal that raises user costs or founder take."""
    need(type(proposal) is dict, 'STAKE_PROPOSAL')
    if proposal.get('user_cost') == 'UP':
        return False
    if proposal.get('ratchet_bps', EFFICIENCY_RATCHET_FLOOR_BPS) < EFFICIENCY_RATCHET_FLOOR_BPS:
        return False
    if proposal.get('founder_rate') == 'UP':
        return False
    return True


def prove_double_sign(operator, first, second):
    """Two verified votes by the same key at one height for different blocks."""
    key(operator)
    for vote in (first, second):
        exact(vote, 'body signature')
        exact(vote['body'], 'chain height block_id')
        integer(vote['body']['height'], True)
        key(vote['body']['block_id'])
        verify(operator, 'COVENANT-STAKE-VOTE-0.1', vote['body'], vote['signature'])
    need(first['body']['height'] == second['body']['height'], 'STAKE_DOUBLE_SIGN')
    need(first['body']['block_id'] != second['body']['block_id'], 'STAKE_DOUBLE_SIGN')
    need(first['body']['chain'] == second['body']['chain'], 'FORK_REPLAY')
    return True


def apply_lock(meter, actor, amount, role, lock_blocks_value, height):
    key(actor)
    integer(amount, True)
    need(role in ROLES, 'STAKE_ROLE')
    integer(lock_blocks_value, True)
    positions = dict(meter.get('positions') or {})
    row = positions.get(actor) or {'amount': 0, 'role': role, 'lock_blocks': lock_blocks_value,
                                   'locked_at': height, 'unbonding': False, 'rehypothecated': False}
    need(row['role'] == role and not row['rehypothecated'], 'STAKE_POSITION')
    row['amount'] += amount
    row['lock_blocks'] = max(row['lock_blocks'], lock_blocks_value)
    positions[actor] = row
    meter['positions'] = positions
    return row


def apply_delegate(meter, actor, operator, amount, lock_blocks_value, height):
    key(actor)
    key(operator)
    need(actor != operator, 'STAKE_SELF_DELEGATION')
    integer(amount, True)
    need(operator in (meter.get('positions') or {}), 'STAKE_OPERATOR')
    # Received stake cannot be delegated onward. An operator who already has delegators
    # keeps that bond in place; only an account with no incoming stake may delegate.
    incoming = [row for row in (meter.get('delegations') or {}).values()
                if row['operator'] == actor and row['amount'] > 0]
    need(not incoming, 'STAKE_REDELEGATION')
    need(not (meter.get('positions') or {}).get(actor, {}).get('rehypothecated'), 'STAKE_REDELEGATION')
    delegations = dict(meter.get('delegations') or {})
    mark = actor + ':' + operator
    row = delegations.get(mark) or {'delegator': actor, 'operator': operator, 'amount': 0,
                                    'lock_blocks': lock_blocks_value, 'locked_at': height, 'unbonding': False}
    row['amount'] += amount
    row['lock_blocks'] = max(row['lock_blocks'], lock_blocks_value)
    delegations[mark] = row
    meter['delegations'] = delegations
    return row


def start_unbond(meter, actor, amount, height, wait):
    integer(amount, True)
    integer(wait, True)
    positions = dict(meter.get('positions') or {})
    row = positions[actor]
    need(row['amount'] >= amount and not row['unbonding'], 'STAKE_UNBOND')
    row['amount'] -= amount
    row['unbonding'] = row['amount'] == 0
    positions[actor] = row
    queue = list(meter.get('unbonding') or [])
    queue.append({'account': actor, 'amount': amount, 'ready': height + wait})
    meter['unbonding'] = queue
    meter['positions'] = positions
    return queue[-1]


def start_unbond_delegation(meter, actor, operator, amount, height, wait):
    integer(amount, True)
    integer(wait, True)
    mark = actor + ':' + operator
    delegations = dict(meter.get('delegations') or {})
    row = delegations[mark]
    need(row['delegator'] == actor and row['amount'] >= amount and not row['unbonding'], 'STAKE_UNBOND')
    row['amount'] -= amount
    row['unbonding'] = row['amount'] == 0
    delegations[mark] = row
    queue = list(meter.get('unbonding') or [])
    queue.append({'account': actor, 'operator': operator, 'amount': amount, 'ready': height + wait})
    meter['unbonding'] = queue
    meter['delegations'] = delegations
    return queue[-1]


def slash_cut(amount):
    integer(amount)
    return amount * SLASH_BPS // 10000


def lock_discount_bps(lock, max_lock):
    """Fee discount grows with lock length. It is a surplus discount, not a yield."""
    integer(lock)
    integer(max_lock, True)
    if lock <= 0:
        return 0
    span = min(lock, max_lock)
    return 500 + 1500 * span // max_lock


def account_weights(meter, max_lock):
    """Revenue weight is ve times the operator's work. No work means no weight."""
    work = meter.get('work') or {}
    positions = meter.get('positions') or {}
    by_account = {}
    total = 0
    for operator, position in positions.items():
        credits = (work.get(operator) or {}).get('credits', 0)
        weight = position_weight(position, credits, max_lock)
        if weight <= 0:
            continue
        by_account[operator] = by_account.get(operator, 0) + weight
        total += weight
    for row in (meter.get('delegations') or {}).values():
        if row.get('unbonding'):
            continue
        credits = (work.get(row['operator']) or {}).get('credits', 0)
        if credits <= 0:
            continue
        weight = ve_power(row['amount'], row['lock_blocks'], max_lock) * credits
        if weight <= 0:
            continue
        who = row['delegator']
        by_account[who] = by_account.get(who, 0) + weight
        total += weight
    return by_account, total


def accrue(meter, amount, max_lock):
    """Split a realised reward across current work-weighted stake. Dust waits for the next split."""
    integer(amount)
    need(amount >= 0, 'STAKE_REWARD')
    pending = meter.get('unallocated_rewards', 0) + amount
    weights, total = account_weights(meter, max_lock)
    if total <= 0 or pending <= 0:
        meter['unallocated_rewards'] = pending
        return 0
    from .tokenomics_config import apportion
    accounts = sorted(account for account, weight in weights.items() if weight > 0)
    shares = apportion(pending, [weights[account] for account in accounts])
    accrued = dict(meter.get('accrued') or {})
    for account, share in zip(accounts, shares):
        if share:
            accrued[account] = accrued.get(account, 0) + share
    meter['accrued'] = accrued
    meter['unallocated_rewards'] = 0
    return pending


def claimable_accrued(meter, actor):
    accrued = (meter.get('accrued') or {}).get(actor, 0)
    already = (meter.get('rewards_claimed') or {}).get(actor, 0)
    return max(0, accrued - already)


def apply_slash(meter, operator):
    """Slash the operator and every delegator who chose them, including tokens in unbonding."""
    key(operator)
    cuts = []
    positions = dict(meter.get('positions') or {})
    if operator in positions:
        row = dict(positions[operator])
        cut = slash_cut(row['amount'])
        row['amount'] -= cut
        positions[operator] = row
        cuts.append(cut)
    delegations = dict(meter.get('delegations') or {})
    for mark, row in list(delegations.items()):
        if row['operator'] != operator:
            continue
        row = dict(row)
        cut = slash_cut(row['amount'])
        row['amount'] -= cut
        delegations[mark] = row
        cuts.append(cut)
    queue = []
    for row in meter.get('unbonding') or []:
        row = dict(row)
        if row['account'] == operator or row.get('operator') == operator:
            cut = slash_cut(row['amount'])
            row['amount'] -= cut
            cuts.append(cut)
        if row['amount'] > 0:
            queue.append(row)
    meter['positions'] = positions
    meter['delegations'] = delegations
    meter['unbonding'] = queue
    total = sum(cuts)
    if total <= 0:
        return None
    return slash_parts(total)


def prove_false_attestation(claimed, covenant_honoured):
    need(claimed == 'HONOURED' and covenant_honoured is False, 'STAKE_FALSE_ATTESTATION')
    return True


def prove_no_ruling(agreement_state, deadline, height, resolver, operator):
    need(resolver == operator, 'STAKE_NO_RULING')
    need(agreement_state in {'BOUND', 'CHALLENGED', 'INDETERMINATE'}, 'STAKE_NO_RULING')
    integer(deadline)
    integer(height)
    need(height > deadline, 'STAKE_NO_RULING')
    return True


def work_credit(meter, operator, subject):
    key(operator)
    key(subject)
    need(operator in (meter.get('positions') or {}), 'STAKE_OPERATOR')
    book = dict(meter.get('work') or {})
    seen = book.get(operator) or {'credits': 0, 'subjects': []}
    need(subject not in seen['subjects'], 'STAKE_WORK_REPLAY')
    subjects = list(seen['subjects'])
    need(len(subjects) < 4096, 'STAKE_WORK_LIMIT')
    subjects.append(subject)
    book[operator] = {'credits': seen['credits'] + 1, 'subjects': subjects}
    meter['work'] = book
    return book[operator]['credits']
