"""Opt-in signed agent discourse DAG with explicit roles and portable replicas.

Attribution and causal authorization, not world truth, consensus over scarce
resources, fresh revocation across partitions, or a public Sybil-resistant forum.
"""
from copy import deepcopy
import json
from .crypto import FieldError,canonical,digest,exact,key,need,sign,verify,public_key,integer
from .workflow_store import WorkflowStore
from covenant_language.agentic import canonical as text_bytes

VERSION='covenant-agent-network/0.1'
LABEL='COVENANT-AGENT-NETWORK-0.1'
# One head per admitted actor plus the group: the 0.1 event bound on parents.
# Raising either one is a successor profile, not configuration.
MAX_PEERS=64
MAX_PARENTS=MAX_PEERS+1


class LimitRefusal(FieldError):
    """A bound refusal that teaches. str() is the code; what, fix and retry say what next."""

    def __init__(self,code,path,what,fix,retry='after the fix'):
        super().__init__(code,path,what,fix)
        self.what,self.fix,self.retry=what,fix,retry

    def refusal(self):
        return {'status':'REFUSED','code':self.code,'what':self.what,'fix':self.fix,'retry':self.retry,
                'execution_authorized':False}
KINDS={'GROUP','POST','CORRECT','MODERATE','ROLE_PROPOSE','ROLE_ACCEPT','ROLE_REVOKE',
       'DISPUTE','DISPUTE_ACCEPT','RESOLVE','ENDORSE','LINK','PROPOSAL','BALLOT','SIGNAL'}


def payload(value):
    raw=text_bytes(value);need(len(raw)<=8192,'NETWORK_CONTENT_LIMIT');return raw.hex()


def unpack(body):
    need(type(body['payload']) is str and len(body['payload'])<=16384,'NETWORK_CONTENT_LIMIT')
    try:raw=bytes.fromhex(body['payload']);value=json.loads(raw)
    except (ValueError,UnicodeError,RecursionError):raise ValueError('NETWORK_CONTENT_ENCODING') from None
    need(text_bytes(value)==raw,'NETWORK_CONTENT_ENCODING');return value


def event_id(envelope):return digest(LABEL,envelope['body'])


def role_view(events,group):
    proposed={ref:e for ref,e in events.items() if e['body']['group']==group and e['body']['kind']=='ROLE_PROPOSE'}
    accepted={unpack(e['body'])['proposal'] for e in events.values() if e['body']['group']==group and e['body']['kind']=='ROLE_ACCEPT'}
    revoked={unpack(e['body'])['role'] for e in events.values() if e['body']['group']==group and e['body']['kind']=='ROLE_REVOKE'}
    slots={}
    for ref in accepted:
        if ref not in proposed:continue
        p=unpack(proposed[ref]['body']);slots.setdefault((p['holder'],p['name']),{})[ref]=p
    result=[]
    for (holder,name),values in sorted(slots.items()):
        superseded={p['supersedes'] for p in values.values() if p['supersedes'] is not None}
        heads=sorted(set(values)-superseded)
        active=[r for r in heads if r not in revoked]
        result.append({'holder':holder,'name':name,'heads':heads,'status':'CONFLICT' if len(heads)>1 else 'ACTIVE' if active else 'REVOKED',
                       'permissions':values[active[0]]['permissions'] if len(heads)==1 and active else [],'authority':'GROUP_LOCAL_ONLY'})
    return result


def permissions(events,group,actor):
    if group not in events:return set()
    root=events[group]['body']
    if root['actor']==actor:return {'post','govern','moderate','arbitrate','organize'}
    return {p for role in role_view(events,group) if role['holder']==actor and role['status']=='ACTIVE' for p in role['permissions']}


class AgentNetwork:
    def __init__(self,directory,domain,private_key,peers,seeds=None):
        key(domain);self.actor=public_key(private_key);key(self.actor)
        need(type(peers) is list and len(peers)>0,'NETWORK_PEERS')
        if len(peers)>MAX_PEERS:
            raise LimitRefusal('NETWORK_PEERS','peers',f'{len(peers)} peers is above the {MAX_PEERS} that {VERSION} admits',
                f'Each signed event names at most {MAX_PARENTS} causal parents, one head per admitted actor plus '
                'the group, and a replica holds at most 2048 events; more peers could leave a group no one can '
                f'post to. Split the swarm into networks of at most {MAX_PEERS} peers, or rank the whole '
                'population with discovery_rank.pagerank (owner limits) or scalable_discovery.sparse_rank. '
                'A larger forum is a successor network profile.')
        for peer in peers:key(peer)
        need(self.actor in peers,'NETWORK_LOCAL_IDENTITY_NOT_ADMITTED')
        self.domain=domain;self.signer=private_key;self.peers=set(peers);self.seeds=dict(seeds or {self.actor:1})
        need(set(self.seeds)<=self.peers and bool(self.seeds),'NETWORK_SEEDS')
        for weight in self.seeds.values():integer(weight,True)
        # The runtime tool host accepts each TCP client on its own thread and
        # holds one lock around the call. SQLite's thread check would refuse
        # that shared custody connection. Callers still serialize writes.
        self.store=WorkflowStore(directory,{'profile':VERSION,'domain':domain,'actor':self.actor,'peers':sorted(self.peers),'seeds':self.seeds},check_same_thread=False)

    def _ancestors(self,parents,events):
        seen={};pending=list(parents)
        while pending:
            ref=pending.pop();need(ref in events,'NETWORK_PARENT_MISSING')
            if ref in seen:continue
            seen[ref]=events[ref];pending.extend(events[ref]['body']['parents'])
            need(len(seen)<=2048,'NETWORK_EVENT_LIMIT')
        return seen

    def _validate(self,envelope,events):
        exact(envelope,'body signature');b=envelope['body']
        exact(b,'profile domain actor request sequence previous parents kind group payload')
        need(len(canonical(envelope))<=24000,'NETWORK_EVENT_SIZE')
        need(b['profile']==VERSION and b['domain']==self.domain,'NETWORK_CONTEXT')
        key(b['actor']);need(b['actor'] in self.peers,'NETWORK_PEER_NOT_ADMITTED');integer(b['sequence'],True)
        need(type(b['request']) is str and 0<len(b['request'])<=96,'NETWORK_REQUEST')
        need(type(b['parents']) is list and len(b['parents'])<=MAX_PARENTS and b['parents']==sorted(set(b['parents'])),'NETWORK_PARENTS')
        for ref in b['parents']:key(ref)
        actor_events=[(ref,e) for ref,e in events.items() if e['body']['actor']==b['actor']]
        previous=max(actor_events,key=lambda v:v[1]['body']['sequence']) if actor_events else None
        need(b['sequence']==(previous[1]['body']['sequence']+1 if previous else 1) and b['previous']==(previous[0] if previous else None),'NETWORK_ACTOR_FORK')
        need(previous is None or b['previous'] in b['parents'],'NETWORK_PREVIOUS_PARENT')
        need(not any(e['body']['request']==b['request'] for _,e in actor_events),'NETWORK_REQUEST_REUSE')
        need(len(actor_events)<256 and len(events)<2048,'NETWORK_EVENT_LIMIT')
        need(b['kind'] in KINDS,'NETWORK_KIND');verify(b['actor'],LABEL,b,envelope['signature'])
        ancestors=self._ancestors(b['parents'],events);p=unpack(b);need(type(p) is dict,'NETWORK_PAYLOAD')
        if b['kind']=='GROUP':
            need(b['group'] is None,'NETWORK_GROUP_CONTEXT');exact(p,'name kind charter open_posting')
            need(type(p['name']) is str and 0<len(p['name'])<=128 and type(p['kind']) is str and 0<len(p['kind'])<=64
                 and type(p['charter']) in (str,dict) and type(p['open_posting']) is bool,'NETWORK_GROUP_SCHEMA')
            return
        group=b['group'];key(group);need(group in ancestors and ancestors[group]['body']['kind']=='GROUP','NETWORK_GROUP_CONTEXT')
        root=unpack(ancestors[group]['body']);perms=permissions(ancestors,group,b['actor']);kind=b['kind']
        def target(ref,kinds):
            key(ref);need(ref in ancestors and ancestors[ref]['body']['group']==group and ancestors[ref]['body']['kind'] in kinds,'NETWORK_TARGET')
            return ancestors[ref]
        if kind=='ROLE_PROPOSE':
            need('govern' in perms,'NETWORK_GOVERNANCE_REQUIRED');exact(p,'holder name permissions supersedes revocable terms')
            key(p['holder']);need(p['holder'] in self.peers,'NETWORK_PEER_NOT_ADMITTED')
            need(type(p['name']) is str and 0<len(p['name'])<=80 and type(p['revocable']) is bool,'NETWORK_ROLE')
            need(type(p['permissions']) is list and len(p['permissions'])<=32 and all(type(x) is str and 0<len(x)<=80 for x in p['permissions'])
                 and p['permissions']==sorted(set(p['permissions'])),'NETWORK_ROLE')
            if p['supersedes'] is not None:
                old=unpack(target(p['supersedes'],{'ROLE_PROPOSE'})['body'])
                need((old['holder'],old['name'])==(p['holder'],p['name']),'NETWORK_ROLE_SUCCESSOR')
            payload(p['terms'])
        elif kind=='ROLE_ACCEPT':
            exact(p,'proposal');proposal=target(p['proposal'],{'ROLE_PROPOSE'});terms=unpack(proposal['body'])
            need(terms['holder']==b['actor'] and 'govern' in permissions(ancestors,group,proposal['body']['actor']),'NETWORK_ROLE_ACCEPTANCE')
        elif kind=='ROLE_REVOKE':
            exact(p,'role reason');proposal=target(p['role'],{'ROLE_PROPOSE'});terms=unpack(proposal['body'])
            need(b['actor']==terms['holder'] or ('govern' in perms and terms['revocable']),'NETWORK_ROLE_REVOCATION_NOT_AGREED')
        elif kind=='POST':
            need(root['open_posting'] or 'post' in perms,'NETWORK_POST_PERMISSION');exact(p,'thread title content tags')
            if p['thread'] is not None:target(p['thread'],{'POST'})
            need(type(p['title']) is str and len(p['title'])<=256 and type(p['tags']) is list and len(p['tags'])<=32
                 and all(type(t) is str and len(t)<=80 for t in p['tags']),'NETWORK_POST_SCHEMA')
        elif kind=='CORRECT':
            exact(p,'target content');original=target(p['target'],{'POST','CORRECT'})
            need(original['body']['actor']==b['actor'],'NETWORK_CORRECTION_AUTHOR')
        elif kind=='MODERATE':
            exact(p,'target action reason');target(p['target'],{'POST','CORRECT'})
            need('moderate' in perms and p['action'] in {'HIDE','RESTORE'},'NETWORK_MODERATION_PERMISSION')
        elif kind=='DISPUTE':
            exact(p,'target claim parties arbitrator procedure');target(p['target'],{'POST','ROLE_PROPOSE','RESOLVE','LINK'})
            need(root['open_posting'] or 'post' in perms,'NETWORK_POST_PERMISSION')
            need(type(p['parties']) is list and 2<=len(p['parties'])<=16 and p['parties']==sorted(set(p['parties'])) and b['actor'] in p['parties'],'NETWORK_DISPUTE_PARTIES')
            for who in p['parties']:key(who);need(who in self.peers,'NETWORK_PEER_NOT_ADMITTED')
            key(p['arbitrator']);need(p['arbitrator'] not in p['parties'],'NETWORK_ARBITRATOR_CONFLICT')
        elif kind=='DISPUTE_ACCEPT':
            exact(p,'case');case=unpack(target(p['case'],{'DISPUTE'})['body']);need(b['actor'] in case['parties'],'NETWORK_CASE_PARTY')
        elif kind=='RESOLVE':
            exact(p,'case outcome reasons evidence');case=unpack(target(p['case'],{'DISPUTE'})['body'])
            accepted={e['body']['actor'] for e in ancestors.values() if e['body']['kind']=='DISPUTE_ACCEPT' and unpack(e['body'])['case']==p['case']}
            need(set(case['parties'])<=accepted and b['actor']==case['arbitrator'] and 'arbitrate' in perms,'NETWORK_ARBITRATION_NOT_ADOPTED')
            need(p['outcome'] in {'SUPPORTED','REFUTED','INDETERMINATE'},'NETWORK_FINDING')
        elif kind=='ENDORSE':
            key(p['subject']);need(p['subject']!=b['actor'],'NETWORK_ENDORSEMENT')
            need(type(p['context']) is str and 0<len(p['context'])<=80,'NETWORK_REPUTATION_CONTEXT')
            fields=set(p)
            if fields=={'subject','context','origin','result'}:
                key(p['origin']);need(p['result'] in {'POSITIVE','NEGATIVE','UNKNOWN'},'NETWORK_ENDORSEMENT')
            elif fields=={'subject','context','origin','commitment','window_end','role'}:
                key(p['origin']);key(p['commitment']);integer(p['window_end'],True)
                need(p['role'] in {'PROVIDER','BUYER'},'NETWORK_ENDORSEMENT')
            elif fields=={'subject','context','origin','result','salt','commitment','rating_bps','role'}:
                key(p['origin']);key(p['salt']);key(p['commitment'])
                need(p['result'] in {'POSITIVE','NEGATIVE','UNKNOWN'} and p['role'] in {'PROVIDER','BUYER'},'NETWORK_ENDORSEMENT')
                integer(p['rating_bps']);need(p['rating_bps']<=10000,'NETWORK_ENDORSEMENT')
                from .network_incentives import commitment_for,review_body
                need(p['commitment']==commitment_for(p['salt'],review_body(p)),'REVIEW_COMMITMENT')
            else:raise ValueError('NETWORK_ENDORSEMENT')
        elif kind=='PROPOSAL':
            from .voting import validate_poll
            need(root['open_posting'] or 'post' in perms,'NETWORK_POST_PERMISSION');validate_poll(p)
            need(all(v['actor'] in self.peers for v in p['electorate']),'NETWORK_PEER_NOT_ADMITTED')
        elif kind=='BALLOT':
            exact(p,'proposal choices');poll=unpack(target(p['proposal'],{'PROPOSAL'})['body'])
            need(b['actor'] in {v['actor'] for v in poll['electorate']},'VOTE_NOT_IN_ELECTORATE')
            choices=p['choices'];need(type(choices) is list and len(choices)<=len(poll['options']) and all(c in poll['options'] for c in choices) and len(set(choices))==len(choices),'VOTE_CHOICES')
            need(poll['rule']!='PLURALITY' or len(choices)<=1,'VOTE_SINGLE_CHOICE')
        elif kind=='SIGNAL':
            from .voting import target as signal_target
            need(root['open_posting'] or 'post' in perms,'NETWORK_POST_PERMISSION');exact(p,'target context origin signal');signal_target(p['target']);key(p['origin'])
            need(type(p['context']) is str and 0<len(p['context'])<=80 and p['signal'] in {'RECOMMEND','PROMOTE','POSITIVE','NEGATIVE','UNKNOWN'},'SIGNAL_SCHEMA')
        elif kind=='LINK':
            exact(p,'target relation description');key(p['target'])
            need(root['open_posting'] or 'post' in perms,'NETWORK_POST_PERMISSION')

    def events(self):
        result={}
        for entry in self.store.events():
            if entry['body']['kind']!='NETWORK':continue
            env=entry['body']['value'];ref=event_id(env)
            need(entry['body']['task']==ref,'NETWORK_STORAGE_CHANGED');self._validate(env,result);result[ref]=env
        return result

    def emit(self,kind,request,content,group=None,parents=()):
        with self.store.exclusive():
            events=self.events();encoded=payload(content)
            for ref,e in events.items():
                b=e['body']
                if b['actor']==self.actor and b['request']==request:
                    need((b['kind'],b['group'],b['payload'])==(kind,group,encoded),'NETWORK_REQUEST_CHANGED')
                    return {'id':ref,'duplicate':True,'externally_delivered':False}
            own=[(ref,e) for ref,e in events.items() if e['body']['actor']==self.actor]
            last=max(own,key=lambda v:v[1]['body']['sequence']) if own else None
            refs=set(parents)
            if last:refs.add(last[0])
            if group is not None:
                refs.add(group)
                # Include the group's current causal frontier. If it grows too
                # wide, require explicit consolidation rather than omit changes.
                same={ref:e for ref,e in events.items() if ref==group or e['body']['group']==group}
                superseded={p for e in same.values() for p in self._ancestors(e['body']['parents'],events)}
                refs.update(set(same)-superseded)
            # Keep a causal antichain: each actor has one ordered chain, so
            # at most 64 admitted actors can contribute maximal heads.
            # An unknown group or parent is a coded refusal, not a KeyError.
            need(all(ref in events for ref in refs),'NETWORK_PARENT_MISSING')
            covered={p for ref in refs for p in self._ancestors(events[ref]['body']['parents'],events)}
            refs-=covered
            if last:refs.add(last[0]) # Immediate actor predecessor remains explicit.
            body={'profile':VERSION,'domain':self.domain,'actor':self.actor,'request':request,
                  'sequence':len(own)+1,'previous':last[0] if last else None,'parents':sorted(refs),'kind':kind,'group':group,'payload':encoded}
            env={'body':body,'signature':sign(self.signer,LABEL,body)};self._validate(env,events);ref=event_id(env)
            self.store.append('NETWORK',ref,env)
            return {'id':ref,'duplicate':False,'externally_delivered':False,'authority':'GROUP_LOCAL_ONLY'}

    def export(self):
        return {'version':VERSION,'domain':self.domain,'events':list(self.events().values()),'freshness':'LOCAL_REPLICA_ONLY'}

    def import_events(self,bundle):
        exact(bundle,'version domain events freshness');need(bundle['version']==VERSION and bundle['domain']==self.domain,'NETWORK_CONTEXT')
        need(type(bundle['events']) is list and len(bundle['events'])<=2048,'NETWORK_EVENT_LIMIT')
        with self.store.exclusive():
            current=self.events();pending={}
            for env in bundle['events']:
                ref=event_id(env)
                if ref in current:need(current[ref]==env,'NETWORK_EVENT_COLLISION')
                else:pending[ref]=env
            accepted=[];working=dict(current)
            while pending:
                ready=sorted(ref for ref,e in pending.items() if set(e['body']['parents'])<=set(working))
                need(bool(ready),'NETWORK_PARENT_MISSING_OR_CYCLE')
                for ref in ready:
                    env=pending.pop(ref);self._validate(env,working);working[ref]=env;accepted.append((ref,env))
            for ref,env in accepted:self.store.append('NETWORK',ref,env)
        return {'imported':len(accepted),'same_ids_preserved':True,'freshness':'LOCAL_REPLICA_ONLY','execution_authorized':False}

    def view(self,group=None,query=''):
        events=self.events();need(type(query) is str and len(query)<=256,'NETWORK_QUERY')
        groups=[];posts=[];cases=[];moderation={}
        for ref,e in events.items():
            b=e['body'];p=unpack(b)
            if b['kind']=='GROUP':groups.append({'id':ref,'founder':b['actor'],**p})
            if group is not None and b['group']!=group:continue
            if b['kind']=='MODERATE':moderation.setdefault(p['target'],[]).append((ref,p['action']))
            if b['kind'] in {'POST','CORRECT','LINK'}:
                if query.casefold() not in json.dumps(p,ensure_ascii=False).casefold():continue
                posts.append({'id':ref,'actor':b['actor'],'kind':b['kind'],'group':b['group'],'content':p,'truth':'ATTRIBUTED_NOT_VERIFIED'})
            if b['kind']=='DISPUTE':cases.append({'id':ref,'status':'CLAIM_NOT_FINDING',**p})
            if b['kind']=='RESOLVE':cases.append({'id':ref,'status':'ADOPTED_PROCEDURAL_FINDING_NOT_WORLD_TRUTH',**p})
        for post in posts:
            changes=moderation.get(post['id'],[])
            superseded=set()
            for ref,_ in changes:
                superseded.update(self._ancestors(events[ref]['body']['parents'],events))
            heads=[action for ref,action in changes if ref not in superseded]
            post['moderation']='CONFLICT' if len(set(heads))>1 else heads[0] if heads else 'VISIBLE'
        groups.sort(key=lambda x:x['id']);posts.sort(key=lambda x:x['id']);cases.sort(key=lambda x:x['id'])
        return {'version':VERSION,'groups':groups,'posts':posts,'disputes':cases,
                'roles':role_view(events,group) if group else [],'freshness':'LOCAL_REPLICA_ONLY',
                'privacy':'CONTENT_VISIBLE_TO_ADMITTED_REPLICAS','external_execution_authorized':False,'authorization_basis':'SIGNED_CAUSAL_PAST_NOT_GLOBAL_CURRENT_AUTHORITY'}

    def close(self):self.store.close()
