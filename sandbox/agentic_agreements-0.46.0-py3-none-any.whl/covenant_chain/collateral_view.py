"""Tranche collateral haircut view. Maturity: experimental.

Clean-room: no covenant.finance source. ``collateral_haircut`` values tranche
collateral from a caller-supplied price and a haircut. A non-positive or stale
price is UNKNOWN, never a stale value. It lives here, not in the frozen
market.py, and market.apply never calls it.

No existing bond, credit or collateral admission check posts a tranche and
compares it with this haircut: demo credit refuses every collateral list,
blueprint inspection records collateral value as NOT_VERIFIED, and
service-bond admission stays inside market.apply. The rail is observe-only.
"""
from .crypto import integer, need

TRANCHE_VERSION = 'covenant-tranche-collateral/0.1'
MAX_INTEGER = 2**53 - 1


def collateral_haircut(amount, price, price_scale, haircut_bps, updated_height, now_height, max_age):
    """amount x price / price_scale, less the haircut. Every argument is checked before any answer."""
    integer(amount)
    need(type(price) is int and -MAX_INTEGER <= price <= MAX_INTEGER, 'TRANCHE_PRICE')
    integer(price_scale, True)
    integer(haircut_bps)
    need(haircut_bps <= 10000, 'TRANCHE_HAIRCUT')
    integer(updated_height)
    integer(now_height)
    integer(max_age)
    unknown = {'status': 'UNKNOWN', 'value': None, 'execution_authorized': False}
    if price <= 0:
        return dict(unknown, reason='NON_POSITIVE_PRICE')
    if now_height < updated_height or now_height - updated_height > max_age:
        return dict(unknown, reason='STALE_PRICE')
    value = amount * price * (10000 - haircut_bps) // (price_scale * 10000)
    need(value <= MAX_INTEGER, 'TRANCHE_VALUE')
    return {'status': 'VALUED', 'value': value, 'execution_authorized': False}


class TrancheCollateralRail:
    """Observe-only collateral view on RailRegistry. It never moves a bond."""

    def __init__(self, enabled=False):
        need(type(enabled) is bool, 'PLUGIN_FLAG')
        self.enabled = enabled
        self.manifest = {
            'version': TRANCHE_VERSION,
            'rail': 'tranche-collateral',
            'observe_only': True,
            'external_broadcast': False,
            'oracle': 'CALLER_SUPPLIED_PRICE_NOT_A_PEG',
            'escrow': 'OPTIONAL',
            'maturity': 'experimental',
        }

    def execute(self, effect_id, request):
        raise ValueError('OBSERVE_ONLY')

    def observe(self, effect_id):
        need(self.enabled, 'PLUGIN_DISABLED')
        return {'status': 'NOT_OBSERVED', 'assurance': 'PASS_A_PRICE_TO_ASSESS', 'execution_authorized': False}

    def assess(self, amount, price, price_scale, haircut_bps, updated_height, now_height, max_age):
        need(self.enabled, 'PLUGIN_DISABLED')
        return collateral_haircut(amount, price, price_scale, haircut_bps, updated_height, now_height, max_age)


def install(registry, flags=None):
    """Register the observe-only rail behind the ``tranche_collateral`` flag."""
    need(flags is not None, 'PLUGIN_DISABLED')
    flags.require('tranche_collateral')
    return {'tranche': registry.register(TrancheCollateralRail(enabled=True)), 'execution_authorized': False}
