"""Opt-in, read-only Internet publication of exact signed public projections.

This is an off-chain application profile, not a consensus rule or a validator
RPC. Source records remain private inputs. All derived pages, metadata and JSON
use ONLY the fields named in a fresh, origin-bound publication consent. The
SQLite file is owner-controlled custody; rollback of that file is not detected
by a globally replicated revocation service. Previously fetched copies cannot
be recalled. No network requests, remote media, cookies or public writes occur.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import dataclass
from html import escape
from http.server import BaseHTTPRequestHandler
import ipaddress
import json
import os
from pathlib import Path
import re
import sqlite3
import threading
import time
from urllib.parse import urlsplit
from xml.sax.saxutils import escape as xml_escape

from covenant_language.safe_io import durable_sqlite

from .crypto import canonical, digest, exact, integer, key, loads, need, public_key, sign, verify
from . import observability
from .backup import refuse_pending_restore
from .http_limits import BoundedHTTPServer

VERSION = 'covenant-public-web/0.1'
LABEL = 'COVENANT-PUBLIC-WEB-0.1'
WITHDRAW = 'covenant-public-web-withdraw/0.1'
KINDS = {'marketplace': 'marketplace', 'social': 'social', 'profile': 'profiles', 'ledger': 'ledger'}
VISIBILITY = ('PRIVATE', 'UNLISTED', 'INDEXED')
MAX_ITEMS = 5000
MAX_PUBLIC_BYTES = 64_000
BOUNDARY = ('Signed public projection; source hash is a reference, not a ledger inclusion proof, '
            'current authority, verified identity, stock reservation or payment finality. '
            'Visibility and freshness are local to this publisher. Previously public copies may persist.')
STYLE = '''*{box-sizing:border-box}body{font-family:"Times New Roman",Times,serif;font-size:16px;line-height:1.16;color:#000;background:#fff;margin:1rem;overflow-wrap:anywhere}main{max-width:70rem;margin:auto;border:1px solid #000;padding:1rem}h1,h2,h3,p,ul,ol,pre,table,nav,dl{font-size:inherit;margin:0 0 .618rem}h1,h2,h3{font-weight:bold}h2{margin-top:1rem}a{color:#000}nav a{display:inline-block;margin:0 .618rem .382rem 0}ul{padding-left:1.618rem}li{margin-bottom:.236rem}article{border-top:1px solid #000;padding-top:.618rem;margin-top:.618rem}pre,code{font:inherit;white-space:pre-wrap;overflow-wrap:anywhere}dt{font-weight:bold;margin-top:.382rem}dd{margin:0 0 .382rem}input,button,select{font:inherit;color:#000;background:#fff;border:1px solid #000;padding:.382rem}footer{border-top:1px solid #000;margin-top:1rem;padding-top:.382rem}.value{white-space:pre-wrap;overflow-wrap:anywhere}'''


def origin_url(value):
    """A pinned origin, never inferred from Host, Forwarded or source URLs."""
    need(type(value) is str and 0 < len(value) <= 240 and value.isascii(), 'WEB_ORIGIN')
    need(all(33 <= ord(c) <= 126 for c in value) and '\\' not in value, 'WEB_ORIGIN')
    try:
        p = urlsplit(value)
        need(p.scheme in ('https', 'http') and p.hostname is not None and p.username is None
             and p.password is None and p.path in ('', '/') and not p.query and not p.fragment,
             'WEB_ORIGIN')
        host = p.hostname
        need(bool(re.fullmatch(r'[a-z0-9.-]+', host)) and '..' not in host
             and not host.startswith(('.', '-')) and not host.endswith(('.', '-')), 'WEB_ORIGIN')
        port = p.port
        if p.scheme == 'http':
            need(host == 'localhost' or ipaddress.ip_address(host).is_loopback, 'WEB_HTTPS_REQUIRED')
        netloc = host + ((':' + str(port)) if port is not None else '')
        need(p.netloc == netloc and (port is None or 1 <= port <= 65535), 'WEB_ORIGIN')
    except (ValueError, TypeError) as exc:
        raise ValueError('WEB_ORIGIN') from exc
    return p.scheme + '://' + netloc


def _text(value, limit=4000):
    need(type(value) is str and 0 < len(value) <= limit, 'WEB_TEXT')
    # The existing signature profile is deliberately ASCII. Do not silently
    # normalize historical source strings into different signed meanings.
    canonical(value)


def source_fields(kind, source):
    """Validate a supported source and derive authorities without exporting it.

    Forum signatures establish authorship, not full causal/group authorization.
    A directory settlement is a signed witness, not a native inclusion proof.
    """
    need(kind in KINDS, 'WEB_KIND')
    canonical(source)
    if kind == 'marketplace':
        from covenant_language import marketplace as m
        m.validate(source)
        ref = m.identifier(source)
        authors = {source['author']}
        data = source['data']
        if source['kind'] == 'ORDER':
            authors.update((data['buyer'], data['seller']))
        elif source['kind'] == 'ESCROW_POLICY':
            authors.update((data['payer'], data['payee'], *data['controllers']))
        values = {'title': source['title'], 'record_kind': source['kind'], **deepcopy(data)}
        # No frame, parents, routing notice, full envelope or unrelated catalog.
        source_type = 'marketplace-' + source['kind'].lower()
    elif kind in ('profile', 'ledger'):
        from .directory_network import open_document
        opened = open_document(source)
        b = opened['body']; data = b['payload']; ref = opened['id']
        need(b['kind'] == ('PROFILE' if kind == 'profile' else 'SETTLEMENT'), 'WEB_SOURCE_KIND')
        authors = {b['signer']}
        if kind == 'profile':
            authors.add(data['principal'])
            values = {'title': data['name'], **{k: deepcopy(v) for k, v in data.items()
                       if k not in ('identity', 'principal', 'grant', 'name')}}
        else:
            authors.update((*data['parties'], data['appeal_resolver']))
            values = {'title': 'Settlement witness', **deepcopy(data)}
        source_type = 'directory-' + b['kind'].lower()
    else:
        from .agent_network import VERSION as FORUM, LABEL as FORUM_LABEL, event_id, unpack
        exact(source, 'body signature'); b = source['body']
        exact(b, 'profile domain actor request sequence previous parents kind group payload')
        need(b['profile'] == FORUM and b['kind'] == 'POST', 'WEB_SOURCE_KIND')
        key(b['domain']); key(b['actor']); integer(b['sequence'], True)
        need(len(canonical(source)) <= 24000, 'WEB_SOURCE_SIZE')
        verify(b['actor'], FORUM_LABEL, b, source['signature'])
        data = unpack(b); exact(data, 'thread title content tags')
        need(type(data['title']) is str and type(data['tags']) is list, 'WEB_SOURCE_KIND')
        ref = event_id(source); authors = {b['actor']}
        values = {'title': data['title'], 'text': deepcopy(data['content']), 'tags': deepcopy(data['tags'])}
        source_type = 'forum-post'
    for actor in authors:
        key(actor)
    return {'type': source_type, 'id': ref}, sorted(authors), values


def approve(private, body):
    """Explicit local signing helper; never called automatically by preview/tools."""
    return {'signer': public_key(private), 'signature': sign(private, LABEL, body)}


def inspect_source(kind, source):
    """Discover field names and consent identities without exporting their values."""
    ref, principals, values = source_fields(kind, source)
    return {'source': ref, 'required_signers': principals, 'available_fields': sorted(values),
            'source_values_exported': False, 'published': False, 'execution_authorized': False}


def _consents(body, approvals, principals):
    need(type(approvals) is list and len(approvals) == len(principals), 'WEB_ALL_CONSENTS_REQUIRED')
    found = set()
    for a in approvals:
        exact(a, 'signer signature'); key(a['signer'])
        need(a['signer'] in principals and a['signer'] not in found, 'WEB_CONSENT_SIGNER')
        verify(a['signer'], LABEL, body, a['signature']); found.add(a['signer'])
    need(found == set(principals), 'WEB_ALL_CONSENTS_REQUIRED')


def verify_publication(envelope):
    """Verify the public signing body without requesting original private data."""
    exact(envelope, 'body approvals')
    body = envelope['body']
    _validate_body(body)
    _consents(body, envelope['approvals'], body['principals'])
    return {'id': body['id'], 'consent_hash': digest(LABEL, body),
            'exact_projection_signatures_verified': True,
            'source_authorship_or_inclusion_independently_verified': False,
            'current_publication_or_revocation_verified': False,
            'execution_authorized': False, 'boundary': BOUNDARY}


def _validate_body(body):
    exact(body, 'version origin id kind source principals sequence previous visibility fields links expires')
    need(body['version'] == VERSION and body['kind'] in KINDS, 'WEB_VERSION_KIND')
    need(body['origin'] == origin_url(body['origin']), 'WEB_ORIGIN')
    exact(body['source'], 'type id'); _text(body['source']['type'], 80); key(body['source']['id'])
    expected = digest('COVENANT-PUBLIC-WEB-ITEM-0.1',
                      {'origin': body['origin'], 'kind': body['kind'], 'source': body['source']})
    need(body['id'] == expected, 'WEB_ITEM_ID')
    need(type(body['principals']) is list and 1 <= len(body['principals']) <= 64, 'WEB_PRINCIPALS')
    for actor in body['principals']: key(actor)
    need(body['principals'] == sorted(set(body['principals'])), 'WEB_PRINCIPALS')
    integer(body['sequence'], True)
    if body['previous'] is not None: key(body['previous'])
    need(body['visibility'] in VISIBILITY, 'WEB_VISIBILITY')
    f = body['fields']
    need(type(f) is dict and 1 <= len(f) <= 32 and 'title' in f, 'WEB_FIELDS')
    _text(f['title'], 256)
    for name in f: _text(name, 64)
    need(type(body['links']) is list and len(body['links']) <= 32, 'WEB_LINKS')
    need(body['links'] == sorted(set(body['links'])), 'WEB_LINKS')
    for ref in body['links']: key(ref)
    if body['expires'] is not None: integer(body['expires'], True)
    need(len(canonical(body)) <= MAX_PUBLIC_BYTES, 'WEB_PUBLIC_SIZE')


def prepare(origin, kind, source, fields, visibility='PRIVATE', links=None, *,
            sequence=1, previous=None, expires=None):
    """Pure exact-field preview, safe on a keyless agent host. No I/O or signing."""
    origin = origin_url(origin)
    source_ref, principals, candidates = source_fields(kind, source)
    need(type(fields) is list and all(type(n) is str for n in fields)
         and len(fields) == len(set(fields)) and 1 <= len(fields) <= 32
         and all(n in candidates for n in fields),
         'WEB_FIELDS')
    need('title' in fields, 'WEB_TITLE_REQUIRED')
    need(type(links) is list or links is None, 'WEB_LINKS')
    for ref in links or []: key(ref)
    item = digest('COVENANT-PUBLIC-WEB-ITEM-0.1', {'origin': origin, 'kind': kind, 'source': source_ref})
    body = {'version': VERSION, 'origin': origin, 'id': item, 'kind': kind, 'source': source_ref,
            'principals': principals, 'sequence': sequence, 'previous': previous,
            'visibility': visibility, 'fields': {n: deepcopy(candidates[n]) for n in sorted(fields)},
            'links': sorted(links or []), 'expires': expires}
    _validate_body(body)
    path = '/' + KINDS[kind] + '/' + item
    return {'id': item, 'body': body, 'required_signers': principals, 'signing_label': LABEL,
            'url': origin + path, 'available_fields': sorted(candidates),
            'preview': {'public_fields': deepcopy(body['fields']), 'public_metadata':
                        ['origin', 'source hash/type', 'signing identities', 'revision', 'visibility',
                         'expiry', 'explicit links', 'consent signatures'],
                        'indexable': visibility == 'INDEXED', 'private_source_exported': False,
                        'boundary': BOUNDARY}, 'execution_authorized': False, 'published': False}


@dataclass(frozen=True)
class Response:
    status: int
    headers: dict
    body: bytes


class PublicWebStore:
    """Owner-only publication control and read-only web projection.

    Keep the DB and its history together during recovery. No public HTTP route
    can create consent, modify this store, load a key or query private sources.
    """
    def __init__(self, path, origin, *, clock=time.time):
        self.origin = origin_url(origin)
        self.clock = clock
        self.lock = threading.RLock()
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        need(not self.path.is_symlink(), 'WEB_DB_SYMLINK')
        fd = os.open(self.path, os.O_CREAT | os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        try: os.fchmod(fd, 0o600)
        finally: os.close(fd)
        self.db = sqlite3.connect(self.path, check_same_thread=False, timeout=5)
        try:
            # A rollback journal keeps one self-contained database file for backups.
            durable_sqlite(self.db, journal='DELETE')
            self.db.execute('BEGIN IMMEDIATE')
            self.db.execute('CREATE TABLE IF NOT EXISTS config (origin TEXT NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS history (id TEXT NOT NULL, sequence INTEGER NOT NULL, '
                            'revision TEXT NOT NULL, envelope TEXT NOT NULL, PRIMARY KEY(id,sequence))')
            rows = self.db.execute('SELECT origin FROM config').fetchall()
            if rows:
                need(rows == [(self.origin,)], 'WEB_DB_ORIGIN')
            else:
                self.db.execute('INSERT INTO config VALUES (?)', (self.origin,))
            self.db.commit()
        except BaseException:
            self.db.close(); raise

    def close(self):
        with self.lock: self.db.close()

    def _head(self, item):
        row = self.db.execute('SELECT envelope FROM history WHERE id=? ORDER BY sequence DESC LIMIT 1',
                              (item,)).fetchone()
        return loads(row[0]) if row else None

    def prepare(self, kind, source, fields, visibility='PRIVATE', links=None, *, expires=None):
        draft = prepare(self.origin, kind, source, fields, visibility, links, expires=expires)
        with self.lock:
            head = self._head(draft['id'])
            if head:
                draft = prepare(self.origin, kind, source, fields, visibility, links,
                                sequence=head['body']['sequence'] + 1,
                                previous=digest(LABEL, head['body']), expires=expires)
        return draft

    def publish(self, kind, source, body, approvals):
        _validate_body(body)
        expected = prepare(self.origin, kind, source, list(body['fields']), body['visibility'],
                           body['links'], sequence=body['sequence'], previous=body['previous'],
                           expires=body['expires'])['body']
        need(canonical(expected) == canonical(body), 'WEB_SOURCE_PROJECTION_MISMATCH')
        _consents(body, approvals, body['principals'])
        env = {'body': deepcopy(body), 'approvals': sorted(deepcopy(approvals), key=lambda a:a['signer'])}
        self._append(env)
        return {'id': body['id'], 'url': self.origin + '/' + KINDS[kind] + '/' + body['id'],
                'revision': digest(LABEL, body), 'visibility': body['visibility'], 'stored': True,
                'deployed': False, 'execution_authorized': False}

    def _append(self, env):
        body = env['body']; item = body['id']
        with self.lock:
            try:
                self.db.execute('BEGIN IMMEDIATE')
                head = self._head(item)
                # Exact retry is safe; a prior (non-head) grant can never restore
                # an item after withdrawal or a less public revision.
                if head and canonical(head) == canonical(env):
                    self.db.rollback(); return
                need(body['sequence'] == (head['body']['sequence']+1 if head else 1)
                     and body['previous'] == (digest(LABEL, head['body']) if head else None), 'WEB_STALE_REVISION')
                if not head:
                    need(self.db.execute('SELECT COUNT(DISTINCT id) FROM history').fetchone()[0] < MAX_ITEMS,
                         'WEB_ITEM_LIMIT')
                self.db.execute('INSERT INTO history VALUES (?,?,?,?)',
                                (item, body['sequence'], digest(LABEL, body), canonical(env).decode('ascii')))
                self.db.commit()
            except BaseException:
                self.db.rollback(); raise

    def prepare_withdraw(self, item):
        key(item)
        with self.lock:
            head = self._head(item)
            need(head is not None, 'WEB_ITEM_UNKNOWN')
            body = head['body']
            return {'version': WITHDRAW, 'origin': self.origin, 'id': item,
                    'principals': deepcopy(body['principals']), 'sequence': body['sequence']+1,
                    'previous': digest(LABEL, body)}

    def withdraw(self, body, approval):
        exact(body, 'version origin id principals sequence previous')
        need(body['version'] == WITHDRAW and body['origin'] == self.origin, 'WEB_WITHDRAW_CONTEXT')
        exact(approval, 'signer signature')
        with self.lock:
            head = self._head(body['id'])
            need(head is not None and canonical(head['body']['principals']) == canonical(body['principals']),
                 'WEB_ITEM_UNKNOWN')
            need(approval['signer'] in body['principals'], 'WEB_WITHDRAW_SIGNER')
            verify(approval['signer'], LABEL, body, approval['signature'])
            self._append({'body': deepcopy(body), 'approvals': [deepcopy(approval)]})
        return {'id': body['id'], 'withdrawn_locally': True, 'cached_copies_recalled': False}

    def _visible(self, *, indexed_only=False):
        rows = self.db.execute('SELECT h.envelope FROM history h JOIN '
            '(SELECT id,MAX(sequence) seq FROM history GROUP BY id) t ON h.id=t.id AND h.sequence=t.seq').fetchall()
        result = {}
        for row in rows:
            env = loads(row[0]); b = env['body']
            if b['version'] == WITHDRAW: continue
            _validate_body(b); _consents(b, env['approvals'], b['principals'])
            need(b['origin'] == self.origin, 'WEB_DB_ORIGIN')
            if b['visibility'] == 'PRIVATE' or indexed_only and b['visibility'] != 'INDEXED': continue
            if b['expires'] is not None and self.clock() >= b['expires']: continue
            result[b['id']] = env
        return result

    def response(self, path, method='GET'):
        # All responses avoid caches, including absent/private and machine data.
        # In-flight responses and outside copies are not revocable guarantees.
        headers = {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
                   'X-Robots-Tag': 'noindex, nofollow, noarchive',
                   'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
                   'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"}
        def response(status, data, mime='text/html; charset=utf-8', indexed=False):
            payload = data.encode('utf-8') if type(data) is str else data
            h = dict(headers); h['Content-Type'] = mime; h['Content-Length'] = str(len(payload))
            if indexed: h['X-Robots-Tag'] = 'index, follow'
            return Response(status, h, b'' if method == 'HEAD' else payload)
        not_found = lambda: response(404, 'Not found.')
        if method not in ('GET', 'HEAD'): return response(405, 'Method not allowed.')
        if type(path) is not str or len(path) > 2048 or not path.startswith('/'):
            return not_found()
        # No arbitrary query/filter/permutation crawl space, encoded aliases,
        # path normalization, absolute-form targets or URL-decoding ambiguity.
        if any(c in path for c in ('?', '#', '%', '\\')) or path.startswith('//'):
            return not_found()
        with self.lock:
            visible = self._visible(); indexed = {i:e for i,e in visible.items() if e['body']['visibility']=='INDEXED'}
            if path == '/robots.txt':
                return response(200, 'User-agent: *\nAllow: /\nSitemap: '+self.origin+'/sitemap.xml\n', 'text/plain; charset=utf-8')
            if path == '/sitemap.xml':
                urls = [self.origin+'/'] + [self.origin+'/'+v+'/' for v in KINDS.values()]
                urls += [self.origin + _path(e['body']) for _, e in sorted(indexed.items())]
                doc = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
                doc += ''.join('<url><loc>'+xml_escape(url)+'</loc></url>' for url in urls)+'</urlset>'
                return response(200, doc, 'application/xml; charset=utf-8')
            if path == '/feed.json':
                feed = {'version': 'https://jsonfeed.org/version/1.1', 'title': 'AAP public activity',
                        'home_page_url': self.origin+'/', 'feed_url': self.origin+'/feed.json',
                        'items': [{'id': i, 'url': self.origin+_path(e['body']),
                                   'title': e['body']['fields']['title'],
                                   'content_text': _description(e['body']['fields'])}
                                  for i,e in sorted(indexed.items())[:100]],
                        '_covenant': {'total_indexed': len(indexed), 'limit': 100,
                                      'truncated': len(indexed)>100,
                                      'content': 'SELECTED_PUBLIC_EXCERPTS; exact records at item URLs',
                                      'ordering': 'ITEM_ID_ORDER_NOT_PUBLICATION_TIME'}}
                return response(200, canonical(feed), 'application/feed+json; charset=utf-8')
            if path == '/' or path in ['/'+v+'/' for v in KINDS.values()]:
                selected = [e['body'] for _,e in sorted(indexed.items())
                            if path == '/' or path == '/'+KINDS[e['body']['kind']]+'/']
                title = 'Agentic Agreements Protocol — public explorer' if path == '/' else path.strip('/').capitalize()
                main = '<h1>'+escape(title)+'</h1><p>Opt-in public marketplace, community, profiles and ledger witnesses.</p>'
                for b in selected:
                    main += '<article><h2><a href="'+_path(b)+'">'+escape(b['fields']['title'])+'</a></h2>'
                    main += '<p>'+escape(_description(b['fields']))+'</p><p>'+escape(b['kind'])+'</p></article>'
                if not selected: main += '<p>No indexed publications in this local view.</p>'
                return response(200, _html(self.origin, path, title, 'Public records published by exact opt-in consent.', main, True), indexed=True)
            found = re.fullmatch(r'/(marketplace|social|profiles|ledger)/([0-9a-f]{64})(\.json)?', path)
            if found is None: return not_found()
            env = visible.get(found[2])
            if env is None or KINDS[env['body']['kind']] != found[1]: return not_found()
            b = env['body']; is_indexed = b['visibility'] == 'INDEXED'
            # Explicit relationship is shown only while target remains indexed;
            # a public source cannot expose an unlisted/private target or title.
            public_links = [indexed[r]['body'] for r in b['links'] if r in indexed]
            if found[3]:
                # The consent body includes EXACTLY the assent to links. Its
                # direct JSON is only served when all explicit links are public,
                # otherwise exclude link values and return a projection receipt.
                data = {'id': b['id'], 'url': self.origin+_path(b), 'fields': deepcopy(b['fields']),
                        'source': deepcopy(b['source']), 'principals': deepcopy(b['principals']),
                        'sequence': b['sequence'], 'visibility': b['visibility'], 'expires': b['expires'],
                        'links': [r['id'] for r in public_links], 'boundary': BOUNDARY}
                if len(public_links) == len(b['links']):
                    data['consent'] = deepcopy(env)
                else:
                    data['consent_hash'] = digest(LABEL, b)
                    data['consent_note'] = 'Some relationship identifiers withheld; this is not the full signing body.'
                result = response(200, canonical(data), 'application/json; charset=utf-8')
                result.headers['Link'] = '<'+self.origin+_path(b)+'>; rel="canonical"'
                return result
            main = '<h1>'+escape(b['fields']['title'])+'</h1><dl>'
            for name,value in b['fields'].items():
                if name == 'title': continue
                main += '<dt>'+escape(name.replace('_',' ').capitalize())+'</dt><dd class="value">'+escape(_display(value))+'</dd>'
            main += '</dl><h2>Publication evidence</h2><p>Source reference: '+escape(b['source']['type'])+' '+b['source']['id']+'</p>'
            main += '<p>Consenting identities: '+escape(', '.join(b['principals']))+'</p>'
            main += '<p>Publisher revision '+str(b['sequence'])+'; '+escape(b['visibility'])+'; local publisher view.</p>'
            main += '<p><a href="'+_path(b)+'.json">Machine-readable publication evidence</a></p>'
            if public_links:
                main += '<h2>Related public records</h2><ul>'+''.join('<li><a href="'+_path(r)+'">'+escape(r['fields']['title'])+'</a></li>' for r in public_links)+'</ul>'
            entity = {'@type': 'CreativeWork', 'name': b['fields']['title']}
            if b['kind'] == 'profile' and 'subject_kind' in b['fields']:
                entity['@type'] = {'AGENT':'SoftwareApplication','PERSON':'Person','ORGANISATION':'Organization'}[b['fields']['subject_kind']]
            if 'text' in b['fields'] and type(b['fields']['text']) is str: entity['text'] = b['fields']['text']
            ld = {'@context':'https://schema.org','@type':'WebPage','url':self.origin+_path(b),
                  'name':b['fields']['title'],'description':_description(b['fields']), 'mainEntity':entity}
            return response(200, _html(self.origin, _path(b), b['fields']['title'], _description(b['fields']),
                                       main, is_indexed, ld), indexed=is_indexed)


def _path(body):
    return '/' + KINDS[body['kind']] + '/' + body['id']


def _display(value):
    """Readable terms for people; exact typed values remain in consent JSON."""
    if type(value) is str: return value
    if value is None: return 'Not specified'
    if type(value) is bool: return 'Yes' if value else 'No'
    if type(value) is int: return str(value)
    if type(value) is list:
        return '\n'.join(_display(v) for v in value) if value else 'None'
    if type(value) is dict:
        if set(value) == {'asset','amount'} and type(value['asset']) is dict:
            asset = value['asset']
            text = str(value['amount'])+' '+str(asset['identifier'])+' / '+str(asset['unit'])+' ('+str(asset['namespace'])+')'
            if asset.get('adapter') is not None: text += '; adapter: '+_display(asset['adapter'])
            if asset.get('transfer_terms'): text += '; transfer terms: '+_display(asset['transfer_terms'])
            return text
        return '\n'.join(k.replace('_',' ')+': '+_display(v) for k,v in sorted(value.items())) if value else 'None'
    raise ValueError('WEB_DISPLAY_TYPE')


def _description(fields):
    value = fields.get('summary', fields.get('description', fields.get('text')))
    if value is None:
        value = {k:v for k,v in fields.items() if k != 'title'}
    if value == {}: value = fields['title']
    return ' '.join(_display(value).split())[:320]


def _html(origin, path, title, description, main, indexed, ld=None):
    url = escape(origin+path, quote=True)
    robots = 'index,follow' if indexed else 'noindex,nofollow,noarchive'
    nav = '<nav aria-label="Public sections"><a href="/">AAP explorer</a>'+''.join('<a href="/'+v+'/">'+escape(v.capitalize())+'</a>' for v in KINDS.values())+'</nav>'
    metadata = ''
    if ld is not None:
        safe = json.dumps(ld, ensure_ascii=True, sort_keys=True).replace('&', '\\u0026').replace('<', '\\u003c').replace('>', '\\u003e')
        metadata = '<script type="application/ld+json">'+safe+'</script>'
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+escape(title)+'</title><meta name="description" content="'+escape(description,quote=True)+'"><meta name="robots" content="'+robots+'"><link rel="canonical" href="'+url+'"><link rel="alternate" type="application/feed+json" href="'+escape(origin)+'/feed.json"><meta property="og:title" content="'+escape(title,quote=True)+'"><meta property="og:description" content="'+escape(description,quote=True)+'"><meta property="og:url" content="'+url+'"><meta property="og:type" content="website"><style>'+STYLE+'</style>'+metadata+'</head><body><main>'+nav+main+'<footer><details><summary>Publication and verification limits</summary><p>'+escape(BOUNDARY)+'</p></details></footer></main></body></html>'


class PublicWebHTTPServer(BoundedHTTPServer):
    """Bounded read-only origin; use an owner-managed HTTPS edge proxy."""


def handler_for(store):
    """Read-only adapter for PublicWebHTTPServer behind an HTTPS reverse proxy."""
    class Handler(observability.Instrumented, BaseHTTPRequestHandler):
        server_version = 'AAP-Public-Web/0.1'
        def setup(self):
            super().setup(); self.connection.settimeout(5)
        def _serve(self):
            try:
                result = store.response(self.path, self.command)
            except (ValueError, TypeError, KeyError, sqlite3.Error):
                # A damaged store fails closed, without private values/traceback.
                data = b'Unavailable.'
                result = Response(503, {'Content-Type':'text/plain; charset=utf-8', 'Content-Length':str(len(data)),
                                      'Cache-Control':'no-store','X-Robots-Tag':'noindex,nofollow'},
                                  b'' if self.command == 'HEAD' else data)
            self.send_response(result.status)
            for name,value in result.headers.items(): self.send_header(name,value)
            self.send_header('Connection', 'close')
            self.end_headers()
            if result.body: self.wfile.write(result.body)
            self.close_connection = True
        do_GET = do_HEAD = do_POST = do_PUT = do_PATCH = do_DELETE = do_OPTIONS = _serve
        def log_message(self, *args):
            # Do not log unlisted URLs, identifiers, query strings or headers.
            pass
    return Handler


def spec():
    return {'version': VERSION, 'kinds': sorted(KINDS), 'visibility': list(VISIBILITY),
            'default_visibility': 'PRIVATE', 'source_adapters':
            {'marketplace':'Exact marketplace record', 'profile':'Signed directory PROFILE',
             'social':'Signed forum POST', 'ledger':'Signed directory SETTLEMENT witness'},
            'consents': 'All derived principals; any principal may withdraw locally.',
            'boundary': BOUNDARY, 'public_http_writes': False, 'hosting_deployed': False,
            'limits': {'items':MAX_ITEMS,'public_bytes':MAX_PUBLIC_BYTES},
            'execution_authorized': False}


def observe(store):
    """Operator health and metrics for the serve listener. Paths are shapes; unlisted ids never become labels."""
    routes = {'/', '/robots.txt', '/sitemap.xml', '/feed.json'} | {'/' + v for v in KINDS.values()} | {'/' + v + '/*' for v in KINDS.values()}
    ops = observability.Ops('public-web', routes=routes)
    def store_ready():
        with store.lock:
            store.db.execute('SELECT COUNT(*) FROM config').fetchone()
        return True
    ops.health.add('store', store_ready)
    ops.storage('publication_db', [store.path, str(store.path) + '-journal'])
    return ops


def arguments():
    """The public web command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    sub.add_parser('spec')
    inspect = sub.add_parser('inspect')
    inspect.add_argument('--kind', choices=sorted(KINDS), required=True)
    inspect.add_argument('--source', required=True)
    verify_parser = sub.add_parser('verify')
    verify_parser.add_argument('--request', required=True)
    for name in ('prepare','publish','prepare-withdraw','withdraw','serve'):
        p = sub.add_parser(name)
        p.add_argument('--db', required=True); p.add_argument('--origin', required=True)
        if name == 'prepare':
            p.add_argument('--kind', choices=sorted(KINDS), required=True)
            p.add_argument('--source', required=True); p.add_argument('--fields', nargs='+', required=True)
            p.add_argument('--visibility', choices=VISIBILITY, default='PRIVATE')
            p.add_argument('--links', nargs='*'); p.add_argument('--expires', type=int)
        if name in ('publish','withdraw'): p.add_argument('--request', required=True)
        if name == 'prepare-withdraw': p.add_argument('--id', required=True)
        if name == 'serve':
            p.add_argument('--bind', default='127.0.0.1'); p.add_argument('--port', type=int, default=8787)
            observability.add_arguments(p)
    return parser


def main(argv=None):
    args = arguments().parse_args(argv)
    if args.action == 'spec':
        print(canonical(spec()).decode()); return 0
    if args.action == 'inspect':
        print(canonical(inspect_source(args.kind, loads(Path(args.source).read_bytes()))).decode()); return 0
    if args.action == 'verify':
        print(canonical(verify_publication(loads(Path(args.request).read_bytes()))).decode()); return 0
    refuse_pending_restore(args.db)
    store = PublicWebStore(args.db, args.origin)
    try:
        if args.action == 'prepare':
            result = store.prepare(args.kind, loads(Path(args.source).read_bytes()), args.fields,
                                   args.visibility, args.links, expires=args.expires)
        elif args.action == 'prepare-withdraw':
            result = store.prepare_withdraw(args.id)
        elif args.action in ('publish','withdraw'):
            request = loads(Path(args.request).read_bytes())
            if args.action == 'publish':
                exact(request, 'kind source body approvals'); result = store.publish(**request)
            else:
                exact(request, 'body approval'); result = store.withdraw(**request)
        else:
            server = PublicWebHTTPServer((args.bind,args.port), handler_for(store))
            server.ops = observability.start(observe(store), args)
            print('Local preview: http://'+args.bind+':'+str(server.server_address[1])+'/', flush=True)
            try: server.serve_forever()
            except KeyboardInterrupt: pass
            finally:
                server.server_close()
                server.ops.close()
            return 0
        print(canonical(result).decode()); return 0
    finally:
        store.close()


if __name__ == '__main__':
    raise SystemExit(main())
