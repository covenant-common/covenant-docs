"""Signed founder feedback, confidential content and append-only response history.

No report or response authorizes execution or protocol change. Keys establish
attribution, not unique agents, expertise, independence or truthful reports.
"""
from copy import deepcopy
import json,os,secrets,sqlite3
from pathlib import Path
from covenant_language.safe_io import atomic_write,durable_sqlite
from .crypto import canonical,digest,exact,need,key,sign,verify,public_key,verification_key,loads
from covenant_language.agentic import canonical as text_canonical
PROFILE='covenant-founder-feedback/0.1'
LABEL='COVENANT-FOUNDER-FEEDBACK-0.1'
CATEGORIES={'FRICTION','BUG','SECURITY','DESIGN','REQUEST','EXPERIMENT'}
STATUSES={'RECEIVED','NEEDS_REPRO','PLANNED','IMPLEMENTED','DECLINED'}
MAX_ENVELOPE=64*1024

def owner_id(owner):verification_key(owner);return digest('COVENANT-FEEDBACK-OWNER',owner)
def identifier(body):return digest('COVENANT-FEEDBACK-ID-0.1',body)
def _content(data,recipient,context):
    raw=text_canonical(data);need(len(raw)<=16384,'FEEDBACK_CONTENT_SIZE')
    payload={'utf8_json_hex':raw.hex()}
    if recipient is None:return {'mode':'PUBLIC','payload':payload}
    from .private import seal_annex
    return {'mode':'CONFIDENTIAL','payload':seal_annex(payload,{'owner':recipient},context)}

def report(private,domain,owner,category,scope,content,related=(),recipient=None,nonce=None):
    key(domain);need(category in CATEGORIES,'FEEDBACK_CATEGORY');tag=nonce or secrets.token_hex(32);key(tag)
    oid=owner_id(owner);context={'domain':domain,'owner':oid,'nonce':tag,'purpose':'FOUNDER_FEEDBACK'}
    body={'profile':PROFILE,'kind':'REPORT','domain':domain,'owner':oid,'issuer':public_key(private),'nonce':tag,
          'category':category,'scope':deepcopy(scope),'related':list(related),'content':_content(content,recipient,context)}
    return {'body':body,'signature':sign(private,LABEL,body)}

def response(private,domain,owner,parent,status,content,recipient=None,nonce=None):
    key(parent);need(status in STATUSES,'FEEDBACK_STATUS');tag=nonce or secrets.token_hex(32);key(tag)
    oid=owner_id(owner);context={'domain':domain,'owner':oid,'nonce':tag,'purpose':'FOUNDER_FEEDBACK'}
    body={'profile':PROFILE,'kind':'RESPONSE','domain':domain,'owner':oid,'issuer':public_key(private),'nonce':tag,
          'parent':parent,'status':status,'content':_content(content,recipient,context)}
    return {'body':body,'signature':sign(private,LABEL,body)}

def validate(envelope,domain,owner):
    need(len(canonical(envelope))<=MAX_ENVELOPE,'FEEDBACK_SIZE');exact(envelope,'body signature');b=envelope['body']
    need(b.get('profile')==PROFILE and b.get('domain')==domain and b.get('owner')==owner_id(owner),'FEEDBACK_CONTEXT')
    key(b['nonce']);verification_key(b['issuer'])
    if b['kind']=='REPORT':
        exact(b,'profile kind domain owner issuer nonce category scope related content');need(b['category'] in CATEGORIES,'FEEDBACK_CATEGORY')
        need(type(b['scope']) is dict and len(canonical(b['scope']))<=2048,'FEEDBACK_SCOPE')
        need(type(b['related']) is list and len(b['related'])<=16,'FEEDBACK_RELATED')
        for ref in b['related']:key(ref)
    else:
        exact(b,'profile kind domain owner issuer nonce parent status content')
        need(b['kind']=='RESPONSE' and b['issuer']==owner and b['status'] in STATUSES,'FEEDBACK_RESPONSE_OWNER');key(b['parent'])
    exact(b['content'],'mode payload');need(b['content']['mode'] in {'PUBLIC','CONFIDENTIAL'},'FEEDBACK_VISIBILITY')
    # Confidential bytes are structurally opaque until the intended reader opens them.
    if b['content']['mode']=='PUBLIC':open_content(envelope)
    verify(b['issuer'],LABEL,b,envelope['signature'])
    return identifier(b)

def open_content(envelope,secret=None):
    b=envelope['body'];c=b['content']
    if c['mode']=='CONFIDENTIAL':
        need(secret is not None,'FEEDBACK_CONFIDENTIAL')
        from .private import open_annex
        context={'domain':b['domain'],'owner':b['owner'],'nonce':b['nonce'],'purpose':'FOUNDER_FEEDBACK'}
        payload=open_annex(c['payload'],'owner',secret,context)
    else:payload=c['payload']
    exact(payload,'utf8_json_hex');hexdata=payload['utf8_json_hex']
    need(type(hexdata) is str and len(hexdata)<=32768 and len(hexdata)%2==0,'FEEDBACK_CONTENT_SIZE')
    try:raw=bytes.fromhex(hexdata);text=raw.decode('ascii');data=json.loads(text)
    except (ValueError,UnicodeError,RecursionError) as exc:raise ValueError('FEEDBACK_CONTENT_ENCODING') from exc
    need(raw==text_canonical(data),'FEEDBACK_CONTENT_CANONICAL')
    return data

class FeedbackDesk:
    """Local durable inbox; pin owner, optionally allowlist reporters.

    Default open admission is visibly marked UNVERIFIED_PSEUDONYM and bounded.
    Per-key quotas are not Sybil resistance; use an allowlist or upstream admission
    mechanism before exposing this outside a trusted localhost environment.
    """
    def __init__(self,path,domain,owner,reporters=None,max_events=5000,per_reporter=25,max_bytes=64*1024*1024,reserved_owner_events=None,reserved_owner_bytes=None):
        key(domain);verification_key(owner);need(type(max_events) is int and max_events>0 and type(per_reporter) is int and per_reporter>0,'FEEDBACK_QUOTA')
        self.domain,self.owner=domain,deepcopy(owner);self.max_events,self.per_reporter=max_events,per_reporter
        need(type(max_bytes) is int and max_bytes>0,'FEEDBACK_QUOTA');self.max_bytes=max_bytes
        self.reserved_owner_events=min(250,max_events//5) if reserved_owner_events is None else reserved_owner_events
        self.reserved_owner_bytes=min(8*1024*1024,max_bytes//5) if reserved_owner_bytes is None else reserved_owner_bytes
        need(type(self.reserved_owner_events) is int and 0<=self.reserved_owner_events<max_events and
             type(self.reserved_owner_bytes) is int and 0<=self.reserved_owner_bytes<max_bytes,'FEEDBACK_OWNER_RESERVE')
        need(str(path)==':memory:' or not Path(path).is_symlink(),'FEEDBACK_DATABASE_SYMLINK')
        self.reporters=None if reporters is None else {digest('COVENANT-FEEDBACK-ISSUER',p) for p in reporters}
        if reporters is not None:
            for p in reporters:verification_key(p)
        self.db=durable_sqlite(sqlite3.connect(path,check_same_thread=False))
        self.db.execute('CREATE TABLE IF NOT EXISTS context (pin TEXT NOT NULL)')
        pin=digest('COVENANT-FEEDBACK-DESK',{'domain':domain,'owner':owner})
        row=self.db.execute('SELECT pin FROM context').fetchone()
        if row and row[0]!=pin:self.db.close();raise ValueError('FEEDBACK_DATABASE_CONTEXT')
        if not row:self.db.execute('INSERT INTO context VALUES (?)',(pin,))
        self.db.execute('CREATE TABLE IF NOT EXISTS entries (sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, issuer TEXT NOT NULL, nonce TEXT NOT NULL, kind TEXT NOT NULL, parent TEXT, raw BLOB NOT NULL, UNIQUE(issuer,nonce))')
        self.db.execute("CREATE TRIGGER IF NOT EXISTS immutable_update BEFORE UPDATE ON entries BEGIN SELECT RAISE(ABORT,'FEEDBACK_APPEND_ONLY'); END")
        self.db.execute("CREATE TRIGGER IF NOT EXISTS immutable_delete BEFORE DELETE ON entries BEGIN SELECT RAISE(ABORT,'FEEDBACK_APPEND_ONLY'); END")
        self.db.commit()
        if str(path)!=':memory:':os.chmod(path,0o600)
    def close(self):self.db.close()
    def append(self,envelope):
        fid=validate(envelope,self.domain,self.owner);b=envelope['body'];issuer=digest('COVENANT-FEEDBACK-ISSUER',b['issuer'])
        try:
            self.db.execute('BEGIN IMMEDIATE')
            if self.db.execute('SELECT 1 FROM entries WHERE id=?',(fid,)).fetchone():
                self.db.commit();return {'id':fid,'duplicate':True,'effect':'NONE'}
            need(not self.db.execute('SELECT 1 FROM entries WHERE issuer=? AND nonce=?',(issuer,b['nonce'])).fetchone(),'FEEDBACK_NONCE_REUSE')
            need(self.db.execute('SELECT count(*) FROM entries').fetchone()[0]<self.max_events,'FEEDBACK_CAPACITY')
            need(self.db.execute('SELECT coalesce(sum(length(raw)),0) FROM entries').fetchone()[0]+len(canonical(envelope))<=self.max_bytes,'FEEDBACK_BYTE_CAPACITY')
            if b['kind']=='REPORT':
                need(self.reporters is None or issuer in self.reporters,'FEEDBACK_ADMISSION')
                report_count,report_bytes=self.db.execute("SELECT count(*),coalesce(sum(length(raw)),0) FROM entries WHERE kind='REPORT'").fetchone()
                need(report_count<self.max_events-self.reserved_owner_events,'FEEDBACK_REPORT_CAPACITY')
                need(report_bytes+len(canonical(envelope))<=self.max_bytes-self.reserved_owner_bytes,'FEEDBACK_REPORT_BYTE_CAPACITY')
                need(self.db.execute("SELECT count(*) FROM entries WHERE issuer=? AND kind='REPORT'",(issuer,)).fetchone()[0]<self.per_reporter,'FEEDBACK_REPORTER_QUOTA')
            else:need(self.db.execute("SELECT 1 FROM entries WHERE id=? AND kind='REPORT'",(b['parent'],)).fetchone(),'FEEDBACK_PARENT')
            self.db.execute('INSERT INTO entries(id,issuer,nonce,kind,parent,raw) VALUES (?,?,?,?,?,?)',(fid,issuer,b['nonce'],b['kind'],b.get('parent'),canonical(envelope)))
            self.db.commit()
        except BaseException:self.db.rollback();raise
        return {'id':fid,'duplicate':False,'effect':'NONE','admission':'OWNER_RESPONSE' if b['kind']=='RESPONSE' else 'ALLOWLISTED_KEY' if self.reporters is not None else 'UNVERIFIED_PSEUDONYM','truth':'SELF_REPORTED','governance_weight':'NONE'}
    def page(self,after=0,limit=50):
        need(type(after) is int and after>=0 and type(limit) is int and 1<=limit<=100,'FEEDBACK_PAGE')
        rows=self.db.execute('SELECT sequence,id,raw FROM entries WHERE sequence>? ORDER BY sequence LIMIT ?',(after,limit)).fetchall();items=[]
        response_bytes=0
        for sequence,fid,raw in rows:
            if items and response_bytes+len(raw)+256>900*1024:break
            e=loads(raw);need(validate(e,self.domain,self.owner)==fid,'FEEDBACK_STORAGE_CORRUPTION');items.append({'sequence':sequence,'id':fid,'envelope':e})
            response_bytes+=len(raw)+256
        return {'items':items,'next_after':items[-1]['sequence'] if items else after,'count_is_not_consensus':True}
    def export_html(self,path):
        """Read-only owner review board. Encrypted reports remain sealed."""
        from html import escape
        rows=[];after=0;statuses={};reports={};responses={}
        while True:
            page=self.page(after,100)
            if not page['items']:break
            for item in page['items']:
                b=item['envelope']['body']
                if b['kind']=='REPORT':reports[item['id']]=item
                else:
                    statuses[b['parent']]=b['status'];responses.setdefault(b['parent'],[]).append(item)
            after=page['next_after']
        for fid,item in reports.items():
            b=item['envelope']['body'];content='Confidential: use the owner decryption key.' if b['content']['mode']=='CONFIDENTIAL' else json.dumps(open_content(item['envelope']),ensure_ascii=False,indent=2)
            history=[]
            for reply in responses.get(fid,[]):
                rb=reply['envelope']['body'];note='Confidential response: sealed.' if rb['content']['mode']=='CONFIDENTIAL' else json.dumps(open_content(reply['envelope']),ensure_ascii=False,indent=2)
                history.append('<p class="meta">Owner · '+escape(rb['status'])+'</p><pre>'+escape(note)+'</pre>')
            rows.append('<article><p class="meta">'+escape(b['category'])+' · '+escape(statuses.get(fid,'RECEIVED'))+'</p><h2>'+escape(fid[:16])+'</h2><pre>'+escape(content)+'</pre><p class="meta">'+escape(json.dumps(b['scope']))+'</p>'+''.join(history)+'</article>')
        html='<!doctype html><meta charset="utf-8"><title>Covenant founder feedback</title><style>body{max-width:960px;margin:48px auto;padding:0 24px;background:#f5f2ec;color:#202a30;font:17px Georgia}article{padding:20px;border-top:1px solid #bbb}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px monospace}.meta{font:13px system-ui;color:#586670}h1{font-size:34px}h2{font:16px monospace}</style><h1>Covenant · Founder feedback</h1><p>Signed agent reports and owner follow-up. Report counts establish neither truth nor consensus. Confidential content remains sealed.</p>'+''.join(rows)
        atomic_write(path,html)

class FeedbackClient:
    """Small agent surface; signing/encryption keys and owner pins come from caller."""
    def __init__(self,url,domain,owner):
        key(domain);verification_key(owner);self.url=url.rstrip('/');self.domain=domain;self.owner=deepcopy(owner)
    def _request(self,path,value=None):
        import urllib.request
        req=urllib.request.Request(self.url+path,data=None if value is None else canonical(value),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=10) as r:
            raw=r.read(2*1024*1024+1);need(len(raw)<=2*1024*1024,'FEEDBACK_REPLY_SIZE');return loads(raw)
    def submit(self,envelope):
        fid=validate(envelope,self.domain,self.owner);result=self._request('/feedback',envelope)
        need(result['id']==fid,'FEEDBACK_REPLY_CONTEXT');return result
    def page(self,after=0,limit=50):
        need(type(after) is int and after>=0 and type(limit) is int and 1<=limit<=100,'FEEDBACK_PAGE')
        page=self._request(f'/feedback?after={after}&limit={limit}')
        for item in page['items']:need(validate(item['envelope'],self.domain,self.owner)==item['id'],'FEEDBACK_REPLY_CONTEXT')
        return page

def main():
    """Read a local desk and export the owner board; no keys or network required."""
    import argparse
    parser=argparse.ArgumentParser(description='Export a signed Covenant founder feedback board')
    parser.add_argument('--db',required=True);parser.add_argument('--domain',required=True);parser.add_argument('--owner',required=True,help='public signing key/descriptor file');parser.add_argument('--out',required=True)
    args=parser.parse_args();raw=Path(args.owner).read_text().strip();owner=loads(raw) if raw.startswith('{') else raw
    need(Path(args.db).is_file(),'FEEDBACK_DATABASE_MISSING')
    desk=FeedbackDesk(args.db,args.domain,owner)
    try:desk.export_html(args.out)
    finally:desk.close()
    print(json.dumps({'board':str(Path(args.out).resolve()),'protocol_effect':'NONE'}))

if __name__=='__main__':main()
