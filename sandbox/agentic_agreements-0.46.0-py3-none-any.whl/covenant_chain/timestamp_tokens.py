"""RFC 3161 time-stamp tokens as evidence, from owner-adopted time-stamp authorities.

A token (RFC 3161 section 2.4.2) is a CMS SignedData (RFC 5652 section 5) whose
content is a TSTInfo: the hash of some data, a policy, a serial and genTime.
verify() accepts a token only when every check below passes, and otherwise
refuses with a stable code; nothing unknown becomes verified:

* strict DER, no trailing bytes, exactly one signer, the TSA (RFC 3161 section 2.4.2);
* eContentType id-ct-TSTInfo, TSTInfo version 1, an imprint in SHA-256,
  SHA-384 or SHA-512 equal to the caller's hash;
* the signer is a certificate the owner adopted (adopt()), matched by issuer
  and serial or subject key identifier; certificates inside the token are
  ignored for trust;
* signed attributes carry content-type and message-digest (RFC 5652 sections
  5.3 and 11) and an ESS signing-certificate binding to that certificate
  (RFC 2634 section 5.4, RFC 5035; RFC 5816 for version 2);
* the signature verifies with RSA PKCS #1 v1.5, ECDSA or Ed25519 (RFC 8419,
  digest SHA-512), genTime falls inside the certificate's validity, the policy
  and any expected nonce match, and no extension is critical.

A verified token proves the hashed data existed no later than genTime plus the
token's accuracy, according to that authority's key. ETSI EN 319 422 section
9.1 lets a token claim to be an EU qualified electronic time-stamp with the
esi4-qtstStatement-1 statement (id-etsi-tsts-EuQCompliance 0.4.0.19422.1.1) in
a qcStatements extension (RFC 3739 section 3.2.6); verify() reports that claim
beside the owner's own adoption statement. Whether a stamp is qualified, and
its legal effect, are decided by the trusted lists and the law, not by AAP.
Revocation of an adopted certificate is the owner's act: withdraw the adoption.
Nothing here opens a socket; request() only builds the RFC 3161 request bytes.
"""
import base64
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import math

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa

from .crypto import need

VERSION = 'urn:aap:timestamp-evidence:0.1'
ADOPTION = 'urn:aap:adopted-tsa:0.1'
MAX_TOKEN = 65536
MAX_NODES = 4096
ID_SIGNED_DATA = '1.2.840.113549.1.7.2'
ID_CT_TSTINFO = '1.2.840.113549.1.9.16.1.4'
ID_CONTENT_TYPE = '1.2.840.113549.1.9.3'
ID_MESSAGE_DIGEST = '1.2.840.113549.1.9.4'
ID_SIGNING_CERTIFICATE = '1.2.840.113549.1.9.16.2.12'
ID_SIGNING_CERTIFICATE_V2 = '1.2.840.113549.1.9.16.2.47'
ID_KP_TIMESTAMPING = '1.3.6.1.5.5.7.3.8'
ID_PE_QC_STATEMENTS = '1.3.6.1.5.5.7.1.3'
ID_ETSI_TSTS_EU_QC = '0.4.0.19422.1.1'
DIGESTS = {'2.16.840.1.101.3.4.2.1': ('sha256', hashes.SHA256), '2.16.840.1.101.3.4.2.2': ('sha384', hashes.SHA384),
           '2.16.840.1.101.3.4.2.3': ('sha512', hashes.SHA512)}
SHA1 = '1.3.14.3.2.26'
RSA = {'1.2.840.113549.1.1.1': None, '1.2.840.113549.1.1.11': 'sha256', '1.2.840.113549.1.1.12': 'sha384',
       '1.2.840.113549.1.1.13': 'sha512'}
ECDSA = {'1.2.840.10045.4.3.2': 'sha256', '1.2.840.10045.4.3.3': 'sha384', '1.2.840.10045.4.3.4': 'sha512'}
ED25519 = '1.3.101.112'
FLAGS = {'execution_authorized': False, 'legal_effect': 'NOT_CLAIMED'}

REMEDIATION = {
    'TSA_TOKEN_SIZE': 'Pass the token as 1 to 65536 bytes of DER (or its base64).',
    'TSA_DER': 'The bytes are not strict DER of the expected structure. Obtain the token unchanged from the authority.',
    'TSA_TOKEN_CONTENT': 'The token is not SignedData over an RFC 3161 TSTInfo.',
    'TSA_TSTINFO': 'The TSTInfo is malformed or not version 1.',
    'TSA_SIGNERS': 'An RFC 3161 token carries exactly one signature, the authority\'s.',
    'TSA_ALGORITHM': 'Use SHA-256, SHA-384 or SHA-512 with RSA PKCS #1 v1.5, ECDSA or Ed25519. Other algorithms are refused, never assumed.',
    'TSA_IMPRINT_MISMATCH': 'The token stamps different data. Stamp the exact bytes, or pass the hash you actually hold.',
    'TSA_SIGNER_UNADOPTED': 'The token is signed by a certificate the owner has not adopted. Adopt the authority with adopt(); a certificate inside the token grants nothing.',
    'TSA_SIGNED_ATTRIBUTES': 'The signed attributes must contain one content-type of id-ct-TSTInfo and one message-digest.',
    'TSA_MESSAGE_DIGEST': 'The message-digest attribute does not hash the TSTInfo. The token was altered.',
    'TSA_ESS_CERT': 'The ESS signing-certificate attribute must identify the adopted certificate.',
    'TSA_SIGNATURE': 'The authority signature does not verify with the adopted certificate.',
    'TSA_CERT_VALIDITY': 'genTime lies outside the adopted certificate\'s validity period.',
    'TSA_POLICY_NOT_ADOPTED': 'The token names a policy the owner did not adopt for this authority.',
    'TSA_NONCE': 'The token\'s nonce differs from the one you sent. It answers another request.',
    'TSA_CRITICAL_EXTENSION': 'The token has a critical extension this verifier does not process. Refused rather than ignored.',
    'TSA_CERTIFICATE': 'Adopt a DER X.509 certificate whose only extended key usage is id-kp-timeStamping, marked critical (RFC 3161 section 2.3).',
    'TSA_ADOPTION': 'Pass the adoption record exactly as adopt() returned it, with a name, policies (or null) and default accuracy in seconds.',
    'TSA_RESPONSE_STATUS': 'The authority did not grant this request. Read its PKIStatus and send a corrected request.',
    'TSA_DIGEST': 'Pass the hash as bytes of the algorithm\'s length, or the data itself.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Correct the named input and retry.')


class _Node:
    __slots__ = ('tag', 'start', 'body', 'end', 'data')

    def __init__(self, data, tag, start, body, end):
        self.data, self.tag, self.start, self.body, self.end = data, tag, start, body, end

    @property
    def raw(self):
        return self.data[self.start:self.end]

    @property
    def value(self):
        return self.data[self.body:self.end]


def _read(data, offset, budget):
    budget[0] -= 1
    need(budget[0] >= 0 and offset + 2 <= len(data), 'TSA_DER')
    tag = data[offset]
    need(tag & 0x1f != 0x1f, 'TSA_DER')
    first = data[offset + 1]; cursor = offset + 2
    if first < 0x80:
        length = first
    else:
        count = first & 0x7f
        need(1 <= count <= 3 and cursor + count <= len(data) and data[cursor] != 0, 'TSA_DER')
        length = int.from_bytes(data[cursor:cursor + count], 'big'); cursor += count
        need(length >= 0x80, 'TSA_DER')
    need(cursor + length <= len(data), 'TSA_DER')
    return _Node(data, tag, offset, cursor, cursor + length)


def _children(node, budget):
    result, cursor = [], node.body
    need(node.tag & 0x20, 'TSA_DER')
    while cursor < node.end:
        child = _read(node.data, cursor, budget)
        need(child.end <= node.end, 'TSA_DER')
        result.append(child); cursor = child.end
    return result


def _oid(node):
    need(node.tag == 0x06 and node.end > node.body, 'TSA_DER')
    raw = node.value; parts = []; value = 0; fresh = True
    for byte in raw:
        need(not (fresh and byte == 0x80), 'TSA_DER')
        value = value << 7 | byte & 0x7f; fresh = False
        if not byte & 0x80:
            parts.append(value); value = 0; fresh = True
    need(fresh, 'TSA_DER')
    first = parts[0]
    head = [0, first] if first < 40 else [1, first - 40] if first < 80 else [2, first - 80]
    return '.'.join(str(p) for p in head + parts[1:])


def _integer(node, tag=0x02):
    raw = node.value
    need(node.tag == tag and raw and not (len(raw) > 1 and (raw[0] == 0 and raw[1] < 0x80 or raw[0] == 0xff and raw[1] >= 0x80)),
         'TSA_DER')
    return int.from_bytes(raw, 'big', signed=True)


def _octets(node):
    need(node.tag == 0x04, 'TSA_DER')
    return node.value


def _algorithm(node, budget):
    need(node.tag == 0x30, 'TSA_DER')
    kids = _children(node, budget)
    need(1 <= len(kids) <= 2, 'TSA_DER')
    if len(kids) == 2:
        need(kids[1].tag == 0x05 and kids[1].end == kids[1].body, 'TSA_ALGORITHM')
    return _oid(kids[0])


def _generalized_time(node):
    need(node.tag == 0x18, 'TSA_TSTINFO')
    text = node.value.decode('ascii', 'replace')
    need(len(text) >= 15 and text.endswith('Z') and text[:14].isdigit(), 'TSA_TSTINFO')
    fraction = Fraction(0)
    if len(text) > 15:
        need(text[14] == '.' and text[15:-1].isdigit() and not text[-2] == '0', 'TSA_TSTINFO')
        fraction = Fraction(int(text[15:-1]), 10 ** len(text[15:-1]))
    else:
        need(len(text) == 15, 'TSA_TSTINFO')
    try:
        moment = datetime.strptime(text[:14], '%Y%m%d%H%M%S').replace(tzinfo=timezone.utc)
    except ValueError:
        raise ValueError('TSA_TSTINFO') from None
    return text, int(moment.timestamp()) + fraction


def _tstinfo(raw):
    budget = [MAX_NODES]
    top = _read(raw, 0, budget)
    need(top.tag == 0x30 and top.end == len(raw), 'TSA_TSTINFO')
    kids = _children(top, budget)
    need(len(kids) >= 5 and _integer(kids[0]) == 1, 'TSA_TSTINFO')
    policy = _oid(kids[1])
    imprint = _children(kids[2], budget)
    need(kids[2].tag == 0x30 and len(imprint) == 2, 'TSA_TSTINFO')
    algorithm = _algorithm(imprint[0], budget)
    need(algorithm in DIGESTS, 'TSA_ALGORITHM')
    hashed = _octets(imprint[1])
    need(len(hashed) == DIGESTS[algorithm][1].digest_size, 'TSA_TSTINFO')
    serial = _integer(kids[3])
    gen_text, gen_time = _generalized_time(kids[4])
    accuracy = None; ordering = False; nonce = None; extensions = []
    rest = kids[5:]
    if rest and rest[0].tag == 0x30:
        accuracy = Fraction(0)
        for part in _children(rest.pop(0), budget):
            if part.tag == 0x02:
                accuracy += _integer(part)
            elif part.tag == 0x80:
                millis = _integer(part, 0x80); need(1 <= millis <= 999, 'TSA_TSTINFO'); accuracy += Fraction(millis, 1000)
            else:
                micros = _integer(part, 0x81); need(1 <= micros <= 999, 'TSA_TSTINFO'); accuracy += Fraction(micros, 10 ** 6)
        need(accuracy >= 0, 'TSA_TSTINFO')
    if rest and rest[0].tag == 0x01:
        flag = rest.pop(0).value; need(flag in (b'\xff',), 'TSA_TSTINFO')  # DER: DEFAULT FALSE is omitted
        ordering = True
    if rest and rest[0].tag == 0x02:
        nonce = _integer(rest.pop(0))
    if rest and rest[0].tag == 0xa0:
        rest.pop(0)  # tsa GeneralName: a hint, not an identity check.
    if rest and rest[0].tag == 0xa1:
        for extension in _children(rest.pop(0), budget):
            parts = _children(extension, budget)
            need(extension.tag == 0x30 and 2 <= len(parts) <= 3, 'TSA_TSTINFO')
            critical = len(parts) == 3
            if critical:
                need(parts[1].tag == 0x01 and parts[1].value == b'\xff', 'TSA_TSTINFO')
            extensions.append({'oid': _oid(parts[0]), 'critical': critical, 'value': _octets(parts[-1])})
    need(not rest, 'TSA_TSTINFO')
    return {'policy': policy, 'imprint_algorithm': algorithm, 'imprint': hashed, 'serial': serial, 'gen_time': gen_text,
            'gen_seconds': gen_time, 'accuracy': accuracy, 'ordering': ordering, 'nonce': nonce, 'extensions': extensions}


def _token_bytes(token):
    if type(token) is str:
        try:
            token = base64.b64decode(token.encode('ascii'), validate=True)
        except (ValueError, UnicodeError):
            raise ValueError('TSA_TOKEN_SIZE') from None
    need(type(token) is bytes and 0 < len(token) <= MAX_TOKEN, 'TSA_TOKEN_SIZE')
    return token


def response_token(response):
    """The TimeStampToken from a granted TimeStampResp (RFC 3161 section 2.4.2)."""
    raw = _token_bytes(response); budget = [MAX_NODES]
    top = _read(raw, 0, budget)
    need(top.tag == 0x30 and top.end == len(raw), 'TSA_DER')
    kids = _children(top, budget)
    need(1 <= len(kids) <= 2 and kids[0].tag == 0x30, 'TSA_DER')
    status = _children(kids[0], budget)
    need(status and _integer(status[0]) in (0, 1), 'TSA_RESPONSE_STATUS')
    need(len(kids) == 2, 'TSA_RESPONSE_STATUS')
    return kids[1].raw


def parse(token):
    """Structure of a TimeStampToken, unverified. Use verify() before relying on any field."""
    raw = _token_bytes(token); budget = [MAX_NODES]
    top = _read(raw, 0, budget)
    need(top.tag == 0x30 and top.end == len(raw), 'TSA_DER')
    info = _children(top, budget)
    need(len(info) == 2 and _oid(info[0]) == ID_SIGNED_DATA and info[1].tag == 0xa0, 'TSA_TOKEN_CONTENT')
    wrapped = _children(info[1], budget)
    need(len(wrapped) == 1 and wrapped[0].tag == 0x30, 'TSA_TOKEN_CONTENT')
    signed = _children(wrapped[0], budget)
    need(len(signed) >= 4 and signed[1].tag == 0x31 and signed[2].tag == 0x30 and signed[-1].tag == 0x31, 'TSA_TOKEN_CONTENT')
    # RFC 5652 section 5.1: version 3 for content other than id-data; every listed digest is well formed.
    need(_integer(signed[0]) == 3, 'TSA_TOKEN_CONTENT')
    listed = [_algorithm(node, budget) for node in _children(signed[1], budget)]
    encap = _children(signed[2], budget)
    need(len(encap) == 2 and _oid(encap[0]) == ID_CT_TSTINFO and encap[1].tag == 0xa0, 'TSA_TOKEN_CONTENT')
    content = _children(encap[1], budget)
    need(len(content) == 1, 'TSA_TOKEN_CONTENT')
    tst_der = _octets(content[0])
    certificates = []; unsigned = []
    for node in signed[3:-1]:
        need(node.tag in (0xa0, 0xa1), 'TSA_TOKEN_CONTENT')
        unsigned.append((node.start, node.end))
        if node.tag == 0xa0:
            certificates = [child.raw for child in _children(node, budget) if child.tag == 0x30]
    signers = _children(signed[-1], budget)
    need(len(signers) == 1 and signers[0].tag == 0x30, 'TSA_SIGNERS')
    parts = _children(signers[0], budget)
    need(6 <= len(parts) <= 7, 'TSA_SIGNERS')
    sid = parts[1]
    need(sid.tag in (0x30, 0x80) and _integer(parts[0]) == (1 if sid.tag == 0x30 else 3), 'TSA_SIGNERS')
    digest_algorithm = _algorithm(parts[2], budget)
    need(digest_algorithm in listed, 'TSA_TOKEN_CONTENT')
    need(parts[3].tag == 0xa0, 'TSA_SIGNED_ATTRIBUTES')
    attributes = {}
    for attribute in _children(parts[3], budget):
        pair = _children(attribute, budget)
        need(attribute.tag == 0x30 and len(pair) == 2 and pair[1].tag == 0x31, 'TSA_SIGNED_ATTRIBUTES')
        kind = _oid(pair[0])
        need(kind not in attributes, 'TSA_SIGNED_ATTRIBUTES')
        attributes[kind] = _children(pair[1], budget)
    signature_algorithm = _algorithm(parts[4], budget)
    signature = _octets(parts[5])
    need(all(node.tag == 0xa1 for node in parts[6:]), 'TSA_SIGNERS')
    unsigned.extend((node.start, node.end) for node in parts[6:])
    signed_attributes = b'\x31' + parts[3].raw[1:]
    return {'tst_der': tst_der, 'tst': _tstinfo(tst_der), 'certificates': certificates, 'sid': sid,
            'digest_algorithm': digest_algorithm, 'attributes': attributes, 'signed_attributes': signed_attributes,
            'signature_algorithm': signature_algorithm, 'signature': signature, 'budget': budget,
            'unsigned_spans': unsigned}


def _eku(certificate):
    try:
        extension = certificate.extensions.get_extension_for_oid(x509.oid.ExtensionOID.EXTENDED_KEY_USAGE)
    except x509.ExtensionNotFound:
        return False
    return extension.critical and [p.dotted_string for p in extension.value] == [ID_KP_TIMESTAMPING]


def adopt(certificate_der, *, name, policies=None, default_accuracy_seconds=1, qualified=False):
    """Owner act: trust this authority certificate for time-stamp evidence. Agreement text cannot do this."""
    need(type(certificate_der) is bytes and 0 < len(certificate_der) <= MAX_TOKEN, 'TSA_CERTIFICATE')
    try:
        certificate = x509.load_der_x509_certificate(certificate_der)
    except ValueError:
        raise ValueError('TSA_CERTIFICATE') from None
    need(_eku(certificate), 'TSA_CERTIFICATE')
    need(type(name) is str and 0 < len(name) <= 128 and name.isprintable(), 'TSA_ADOPTION')
    need(policies is None or type(policies) is list and 0 < len(policies) <= 16 and
         all(type(p) is str and all(part.isdigit() for part in p.split('.')) for p in policies), 'TSA_ADOPTION')
    need(type(default_accuracy_seconds) is int and 0 <= default_accuracy_seconds <= 86400, 'TSA_ADOPTION')
    need(type(qualified) is bool, 'TSA_ADOPTION')
    return {'version': ADOPTION, 'name': name, 'certificate': base64.b64encode(certificate_der).decode('ascii'),
            'certificate_sha256': hashlib.sha256(certificate_der).hexdigest(),
            'policies': None if policies is None else sorted(policies), 'default_accuracy_seconds': default_accuracy_seconds,
            'qualified': 'OWNER_ASSERTS_EU_QUALIFIED_TSA' if qualified else 'NOT_ASSERTED'}


def _adopted(record):
    need(type(record) is dict and set(record) == {'version', 'name', 'certificate', 'certificate_sha256', 'policies',
         'default_accuracy_seconds', 'qualified'} and record['version'] == ADOPTION, 'TSA_ADOPTION')
    try:
        der = base64.b64decode(record['certificate'].encode('ascii'), validate=True)
        certificate = x509.load_der_x509_certificate(der)
    except (ValueError, AttributeError, UnicodeError):
        raise ValueError('TSA_ADOPTION') from None
    need(hashlib.sha256(der).hexdigest() == record['certificate_sha256'] and _eku(certificate), 'TSA_ADOPTION')
    return der, certificate


def _matches(sid, certificate, budget):
    if sid.tag == 0x80:
        try:
            ski = certificate.extensions.get_extension_for_oid(x509.oid.ExtensionOID.SUBJECT_KEY_IDENTIFIER).value.digest
        except x509.ExtensionNotFound:
            return False
        return sid.value == ski
    parts = _children(sid, budget)
    return (len(parts) == 2 and parts[0].raw == certificate.issuer.public_bytes()
            and _integer(parts[1]) == certificate.serial_number)


def _ess(attributes, der, budget):
    for kind, version in ((ID_SIGNING_CERTIFICATE_V2, 2), (ID_SIGNING_CERTIFICATE, 1)):
        if kind not in attributes:
            continue
        values = attributes[kind]
        need(len(values) == 1, 'TSA_ESS_CERT')
        outer = _children(values[0], budget)
        need(values[0].tag == 0x30 and outer and outer[0].tag == 0x30, 'TSA_ESS_CERT')
        first = _children(outer[0], budget)
        need(first and first[0].tag == 0x30, 'TSA_ESS_CERT')
        fields = _children(first[0], budget)
        algorithm = hashes.SHA1 if version == 1 else hashes.SHA256
        if version == 2 and fields and fields[0].tag == 0x30:
            name = _algorithm(fields[0], budget)
            need(name in DIGESTS, 'TSA_ALGORITHM')
            algorithm = DIGESTS[name][1]; fields = fields[1:]
        need(fields and fields[0].tag == 0x04, 'TSA_ESS_CERT')
        digest = hashes.Hash(algorithm()); digest.update(der)
        need(fields[0].value == digest.finalize(), 'TSA_ESS_CERT')
        return 'ESS_CERT_ID_V2' if version == 2 else 'ESS_CERT_ID_V1'
    raise ValueError('TSA_ESS_CERT')


def _verify_signature(certificate, parsed):
    key = certificate.public_key(); message = parsed['signed_attributes']; signature = parsed['signature']
    digest = DIGESTS[parsed['digest_algorithm']]
    try:
        if isinstance(key, ed25519.Ed25519PublicKey):
            need(parsed['signature_algorithm'] == ED25519 and digest[0] == 'sha512', 'TSA_ALGORITHM')
            key.verify(signature, message)
        elif isinstance(key, rsa.RSAPublicKey):
            need(parsed['signature_algorithm'] in RSA and RSA[parsed['signature_algorithm']] in (None, digest[0]), 'TSA_ALGORITHM')
            key.verify(signature, message, padding.PKCS1v15(), digest[1]())
        elif isinstance(key, ec.EllipticCurvePublicKey):
            need(ECDSA.get(parsed['signature_algorithm']) == digest[0], 'TSA_ALGORITHM')
            key.verify(signature, message, ec.ECDSA(digest[1]()))
        else:
            raise ValueError('TSA_ALGORITHM')
    except InvalidSignature:
        raise ValueError('TSA_SIGNATURE') from None


def verify(token, *, adopted, data=None, digest=None, nonce=None):
    """Verify one token over data (or its digest) against owner-adopted authorities."""
    parsed = parse(token); tst = parsed['tst']; budget = parsed['budget']
    need(type(adopted) is list and 0 < len(adopted) <= 16, 'TSA_SIGNER_UNADOPTED')
    name, algorithm = DIGESTS[tst['imprint_algorithm']]
    if data is not None:
        need(type(data) is bytes and digest is None, 'TSA_DIGEST')
        check = hashes.Hash(algorithm()); check.update(data); digest = check.finalize()
    need(type(digest) is bytes and len(digest) == algorithm.digest_size, 'TSA_DIGEST')
    need(tst['imprint'] == digest, 'TSA_IMPRINT_MISMATCH')
    need(parsed['digest_algorithm'] in DIGESTS, 'TSA_ALGORITHM')
    record = der = certificate = None
    for row in adopted:
        candidate_der, candidate = _adopted(row)
        if _matches(parsed['sid'], candidate, budget):
            record, der, certificate = row, candidate_der, candidate
            break
    need(record is not None, 'TSA_SIGNER_UNADOPTED')
    attributes = parsed['attributes']
    need(len(attributes.get(ID_CONTENT_TYPE, [])) == 1 and len(attributes.get(ID_MESSAGE_DIGEST, [])) == 1, 'TSA_SIGNED_ATTRIBUTES')
    need(_oid(attributes[ID_CONTENT_TYPE][0]) == ID_CT_TSTINFO, 'TSA_SIGNED_ATTRIBUTES')
    content_digest = hashes.Hash(DIGESTS[parsed['digest_algorithm']][1]()); content_digest.update(parsed['tst_der'])
    need(_octets(attributes[ID_MESSAGE_DIGEST][0]) == content_digest.finalize(), 'TSA_MESSAGE_DIGEST')
    binding = _ess(attributes, der, budget)
    _verify_signature(certificate, parsed)
    seconds = tst['gen_seconds']
    need(certificate.not_valid_before_utc.timestamp() <= seconds <= certificate.not_valid_after_utc.timestamp(), 'TSA_CERT_VALIDITY')
    need(record['policies'] is None or tst['policy'] in record['policies'], 'TSA_POLICY_NOT_ADOPTED')
    need(nonce is None or tst['nonce'] == nonce, 'TSA_NONCE')
    need(not any(e['critical'] for e in tst['extensions']), 'TSA_CRITICAL_EXTENSION')
    accuracy = tst['accuracy'] if tst['accuracy'] is not None else Fraction(record['default_accuracy_seconds'])
    statement = _qualified_statement(tst['extensions'])
    return {'version': VERSION, 'status': 'VERIFIED', 'tsa': record['name'], 'tsa_certificate_sha256': record['certificate_sha256'],
            'gen_time': tst['gen_time'], 'not_before': math.floor(seconds - accuracy), 'not_after': math.ceil(seconds + accuracy),
            'accuracy': str(accuracy), 'accuracy_source': 'TOKEN' if tst['accuracy'] is not None else 'OWNER_ADOPTION_DEFAULT',
            'policy': tst['policy'], 'serial': tst['serial'], 'nonce': tst['nonce'], 'ordering': tst['ordering'],
            'imprint_algorithm': name, 'imprint': digest.hex(), 'certificate_binding': binding,
            'qualified': {'token_statement': 'ESI4_QTST_STATEMENT_1_PRESENT' if statement else 'ABSENT',
                          'owner_adoption': record['qualified'], 'legal_status': 'NOT_DETERMINED_BY_AAP'},
            'proves': 'THE_HASHED_DATA_EXISTED_NO_LATER_THAN_NOT_AFTER_PER_THE_ADOPTED_AUTHORITY_KEY',
            'revocation': 'NOT_CHECKED; WITHDRAW_THE_ADOPTION_TO_STOP_TRUSTING_A_KEY', **FLAGS}


def _qualified_statement(extensions):
    for extension in extensions:
        if extension['oid'] != ID_PE_QC_STATEMENTS:
            continue
        budget = [MAX_NODES]
        top = _read(extension['value'], 0, budget)
        need(top.tag == 0x30 and top.end == len(extension['value']), 'TSA_TSTINFO')
        for statement in _children(top, budget):
            parts = _children(statement, budget)
            if parts and _oid(parts[0]) == ID_ETSI_TSTS_EU_QC:
                return True
    return False


def existed_before(result, deadline):
    """BEFORE only when the token's upper bound is earlier than the deadline; otherwise UNDETERMINED."""
    need(type(result) is dict and result.get('version') == VERSION and result.get('status') == 'VERIFIED', 'TSA_TOKEN_CONTENT')
    need(type(deadline) is int, 'TSA_DIGEST')
    return {'deadline': deadline, 'status': 'BEFORE' if result['not_after'] < deadline else 'UNDETERMINED',
            'not_after': result['not_after'], 'basis': 'RFC3161_TOKEN_UPPER_BOUND', **FLAGS}


def _tlv(tag, body):
    size = len(body)
    if size < 0x80:
        return bytes([tag, size]) + body
    raw = size.to_bytes((size.bit_length() + 7) // 8, 'big')
    return bytes([tag, 0x80 | len(raw)]) + raw + body


def encode_oid(dotted):
    parts = [int(p) for p in dotted.split('.')]
    values = [parts[0] * 40 + parts[1]] + parts[2:]
    out = b''
    for value in values:
        chunk = [value & 0x7f]
        value >>= 7
        while value:
            chunk.append(0x80 | value & 0x7f); value >>= 7
        out += bytes(reversed(chunk))
    return _tlv(0x06, out)


def encode_integer(value, tag=0x02):
    size = max(1, (value.bit_length() + 8) // 8)
    return _tlv(tag, value.to_bytes(size, 'big', signed=True))


def encode(tag, *children):
    return _tlv(tag, b''.join(children))


def request(digest, *, algorithm='sha256', nonce=None, policy=None, certificate=True):
    """DER TimeStampReq (RFC 3161 section 2.4.1). Sending it is the owner's act; nothing is sent here."""
    names = {v[0]: k for k, v in DIGESTS.items()}
    need(algorithm in names, 'TSA_ALGORITHM')
    need(type(digest) is bytes and len(digest) == DIGESTS[names[algorithm]][1].digest_size, 'TSA_DIGEST')
    need(nonce is None or type(nonce) is int and 0 < nonce < 2**160, 'TSA_NONCE')
    imprint = encode(0x30, encode(0x30, encode_oid(names[algorithm]), b'\x05\x00'), _tlv(0x04, digest))
    parts = [encode_integer(1), imprint]
    if policy is not None:
        parts.append(encode_oid(policy))
    if nonce is not None:
        parts.append(encode_integer(nonce))
    if certificate:
        parts.append(b'\x01\x01\xff')
    return encode(0x30, *parts)


def describe():
    return {'version': VERSION, 'adoption': ADOPTION, 'digests': sorted(v[0] for v in DIGESTS.values()),
            'signatures': ['RSA PKCS #1 v1.5', 'ECDSA', 'Ed25519 (RFC 8419, SHA-512)'],
            'qualified_statement': ID_ETSI_TSTS_EU_QC, 'remediation': dict(REMEDIATION),
            'standards': ['RFC 3161 sections 2.3, 2.4.1, 2.4.2', 'RFC 5652 sections 5.1, 5.3, 5.4, 11',
                          'RFC 2634 section 5.4', 'RFC 5035', 'RFC 5816', 'RFC 8419', 'RFC 3739 section 3.2.6',
                          'ETSI EN 319 422 V1.1.1 section 9.1 and annex B'],
            'network_accessed': False, **FLAGS}
