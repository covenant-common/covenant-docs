"""Optional profile flag. It does not change the default chain.

When set, prediction markets, credit-rail borrowing, random rewards, shielded-pool
exclusion lists, rehypothecation and liquid staking are rejected. Staking rewards
remain a share of realised revenue. There is still no fixed yield.
"""
from .crypto import need

FORBIDDEN_PREFIXES = ('PREDICTION', 'CREDIT')
FORBIDDEN = {'ECON_LOTTERY', 'ECON_RAFFLE', 'ECON_MINT', 'STAKE_APY', 'LIQUID_STAKE', 'ECON_REHYPOTHECATE', 'ECON_LIQUID_STAKE'}
AD_SCREEN = {'GAMBLING', 'INTEREST_LENDING', 'ALCOHOL', 'WEAPONS'}


def enabled(scale):
    return bool(scale and scale.get('shariah_mode') is True)


def screen_op(scale, op):
    if not enabled(scale):
        return False
    need(op not in FORBIDDEN and not op.startswith(FORBIDDEN_PREFIXES), 'SHARIAH_FORBIDDEN')
    return True


def screen_ad_category(scale, category):
    if not enabled(scale):
        return False
    need(category not in AD_SCREEN, 'SHARIAH_CATEGORY')
    return True


def staking_rules(scale):
    """Shariah mode and the default profile share the no-APY rule. Shariah adds the leverage bans."""
    rules = {'fixed_apy': False, 'rewards': 'REALISED_FEE_AND_WORK', 'rehypothecation': False,
             'liquid_staking': False}
    if enabled(scale):
        rules['prediction_markets'] = False
        rules['credit_rails'] = False
        rules['random_rewards'] = False
        rules['shielded_pools'] = 'EXCLUDED'
    return rules
