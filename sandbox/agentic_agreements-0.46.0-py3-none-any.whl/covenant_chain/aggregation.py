"""Shared median and the drafting default for graded release.

The median is the rule in the arbitration notes (generalised median with one
phantom when the revealed count is even). A later covenant-native/0.15
activation, the same version gate as PR #21, can call ``median_rule`` from a
review panel. This module does not import the ledger and does not change
``apply_transaction``.

``recommend_release`` is a drafting default, not a protocol gate. Corroboration
is optional. A covenant lifts the default with an explicit field.
"""
from .crypto import integer, need
from .evidence_grade import ASSURANCE

RULE_SET = 'covenant-native/0.15'
MEDIAN_RULE = 'evidence-median'
RELEASE_RULE = 'evidence-release-bps'
CONSENSUS_APPLIED = False


def median_rule(values, *, fallback=None, phantoms=(), band=None, quorum=None):
    """Median shared with arbitration.

    Revealed values are sorted. An even revealed count takes one phantom at
    ``fallback`` when that phantom is supplied, then any fixed anchor phantoms,
    then the middle of the combined list (index ``len // 2``). An odd revealed
    count does not invent a fallback. ``band`` and ``quorum`` test only the
    revealed values: decisive when at least ``quorum`` of them lie within
    ``band`` of the median.
    """
    need(type(values) is list and 1 <= len(values) <= 4096, 'AGGREGATE_VALUES')
    for value in values:
        integer(value)
    need(type(phantoms) in (list, tuple) and len(phantoms) <= 32, 'AGGREGATE_PHANTOMS')
    for value in phantoms:
        integer(value)
    ballots = list(values)
    used_fallback = False
    if len(values) % 2 == 0 and fallback is not None:
        integer(fallback)
        ballots.append(fallback)
        used_fallback = True
    ballots.extend(phantoms)
    ballots.sort()
    median = ballots[len(ballots) // 2]
    within = None
    decisive = None
    if band is not None or quorum is not None:
        integer(band)
        integer(quorum, True)
        need(quorum <= len(values), 'AGGREGATE_QUORUM')
        within = sum(1 for value in values if abs(value - median) <= band)
        decisive = within >= quorum
    return {'rule_set': RULE_SET, 'rule': MEDIAN_RULE, 'median': median, 'ballots': ballots,
            'revealed': len(values), 'fallback_used': used_fallback, 'within_band': within,
            'decisive': decisive, 'consensus_applied': CONSENSUS_APPLIED, 'execution_authorized': False}


LEVELS = {
    'L0': {'min_sources': 1, 'single': 'ADMITTED', 'shortfall': 'ACCEPT'},
    'L1': {'min_sources': 1, 'single': 'DEFAULT', 'shortfall': 'HOLD'},
    'L2': {'min_sources': 2, 'single': 'DEFAULT', 'shortfall': 'HOLD'},
    'L3': {'min_sources': 2, 'single': 'DEFAULT', 'shortfall': 'PANEL'},
    'ABSENT': {'min_sources': 1, 'single': 'DEFAULT', 'shortfall': 'HOLD'},
}


def resolve_policy(policy=None):
    """Read the choice the parties stored. An unset field inherits the level.

    ``L0`` or ``on_shortfall: ACCEPT`` admits a single source. An explicit
    ``ADMITTED`` or ``DEFAULT`` is kept as written. Nothing here is a gate.
    """
    policy = {} if policy is None else policy
    need(type(policy) is dict, 'RELEASE_POLICY')
    level = policy.get('level_required', 'ABSENT')
    shortfall = policy.get('on_shortfall', 'ABSENT')
    single = policy.get('single_source_release', 'ABSENT')
    model = policy.get('model_release', 'ABSENT')
    assurance = policy.get('assurance_required', 'ABSENT')
    need(level in LEVELS and shortfall in {'ACCEPT', 'HOLD', 'PANEL', 'ABSENT'}, 'RELEASE_POLICY')
    need(single in {'DEFAULT', 'ADMITTED', 'ABSENT'} and model in {'DEFAULT', 'ADMITTED', 'ABSENT'}, 'RELEASE_POLICY')
    need(assurance == 'ABSENT' or assurance in ASSURANCE, 'RELEASE_POLICY')
    if single == 'ABSENT':
        single = 'ADMITTED' if level == 'L0' or shortfall == 'ACCEPT' else LEVELS[level]['single']
    if shortfall == 'ABSENT':
        shortfall = LEVELS[level]['shortfall']
    if model == 'ABSENT':
        model = 'DEFAULT'
    minimum = 1 if single == 'ADMITTED' else LEVELS[level]['min_sources']
    return {'level_required': level, 'on_shortfall': shortfall, 'single_source_release': single,
            'model_release': model, 'assurance_required': assurance, 'min_sources': minimum,
            'protocol_gate': False, 'policy_read': True}


def recommend_release(readings, policy=None):
    """Map confidence to a recommended ``release_bps``.

    The default withholds that recommendation when a single independent source,
    or model evidence with no second source class, would otherwise auto-release.
    A stored ``level_required: L0`` or ``on_shortfall: ACCEPT`` lifts that
    default, as does an explicit ``ADMITTED``. Nothing here moves escrow.
    """
    need(type(readings) is list and len(readings) <= 4096, 'RELEASE_READINGS')
    resolved = resolve_policy(policy)
    single = resolved['single_source_release']
    model = resolved['model_release']
    floor = resolved['assurance_required']
    grouped = {}
    classes = set()
    labels = []
    for row in readings:
        need(type(row) is dict, 'RELEASE_READING')
        integer(row['confidence_bps'])
        need(0 <= row['confidence_bps'] <= 10000, 'RELEASE_CONFIDENCE')
        key = row.get('independence_key') or row.get('adapter') or row.get('source')
        need(type(key) is str and 0 < len(key) <= 128, 'RELEASE_SOURCE')
        source_class = row.get('source_class') or 'DOCUMENT'
        need(type(source_class) is str and len(source_class) <= 80, 'RELEASE_CLASS')
        if floor != 'ABSENT':
            label = row.get('assurance', 'SELF_ASSERTED')
            need(label in ASSURANCE, 'EVIDENCE_ASSURANCE')
            if ASSURANCE.index(label) < ASSURANCE.index(floor):
                continue
        elif 'assurance' in row:
            need(row['assurance'] in ASSURANCE, 'EVIDENCE_ASSURANCE')
        classes.add(source_class)
        if 'assurance' in row:
            labels.append(row['assurance'])
        previous = grouped.get(key)
        if previous is None or row['confidence_bps'] > previous:
            grouped[key] = row['confidence_bps']
    confidences = [grouped[key] for key in sorted(grouped)]
    statistic = None if not confidences else median_rule(confidences)['median']
    single_source = len(grouped) < 2
    model_only = 'AI_MODEL' in classes and len(classes) < 2
    admit_single = single == 'ADMITTED'
    admit_model = model == 'ADMITTED'
    capped = (single_source and not admit_single) or (model_only and not admit_model) or (len(grouped) < resolved['min_sources'] and not admit_single)
    release = 0 if capped or statistic is None else statistic
    return {'rule_set': RULE_SET, 'rule': RELEASE_RULE, 'release_bps': release, 'statistic_bps': statistic,
            'sources': len(grouped), 'source_classes': sorted(classes), 'capped_by_template_default': capped,
            'single_source_release': single, 'model_release': model, 'level_required': resolved['level_required'],
            'on_shortfall': resolved['on_shortfall'], 'assurance_required': floor, 'assurances': sorted(set(labels)),
            'min_sources': resolved['min_sources'], 'policy_read': True,
            'protocol_gate': False, 'corroboration': 'OPTIONAL', 'consensus_applied': CONSENSUS_APPLIED,
            'execution_authorized': False}
