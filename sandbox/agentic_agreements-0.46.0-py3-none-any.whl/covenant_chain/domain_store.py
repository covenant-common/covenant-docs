"""Reference local runtime for agent-created Covenant domains.

This module deliberately uses SQLite as a disposable projection/storage engine,
not as the protocol's source of truth.  Events are immutable and content
addressed; current rows are reconstructed from event history.  Public/private is
an export policy of the domain declaration.  Private domains can still export
roots and scoped proofs without exporting payloads.
"""
from __future__ import annotations

from covenant_language.platform_support import require_posix
require_posix("covenant_chain/domain_store")
import hashlib
import json
import os
import sqlite3
import threading
from functools import wraps
from copy import deepcopy
from pathlib import Path

from covenant_language.domains import (
    DomainError, canonical, make_anchor, object_id, payload_commitment,
    validate_domain, validate_event,
)

ZERO_ROOT = hashlib.sha256(b"COVENANT-DOMAIN-EMPTY-0.1").hexdigest()


def _hash_obj(label, value):
    return hashlib.sha256(label.encode("ascii") + b"\0" + canonical(value)).hexdigest()


def _leaf(kind, value):
    return _hash_obj("COVENANT-DOMAIN-%s-LEAF-0.1" % kind, value)


def _parent(kind, left, right):
    return _hash_obj("COVENANT-DOMAIN-%s-NODE-0.1" % kind, {"left": left, "right": right})


def _merkle(kind, values):
    if not values:
        return ZERO_ROOT
    level = [_leaf(kind, value) for value in values]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else left
            nxt.append(_parent(kind, left, right))
        level = nxt
    return level[0]


def _merkle_proof(kind, values, index):
    if not 0 <= index < len(values):
        raise IndexError(index)
    level = [_leaf(kind, value) for value in values]
    idx = index
    path = []
    while len(level) > 1:
        sibling_index = idx - 1 if idx % 2 else idx + 1
        if sibling_index >= len(level):
            sibling_index = idx
        path.append({"side": "LEFT" if sibling_index < idx else "RIGHT",
                     "hash": level[sibling_index]})
        nxt = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else left
            nxt.append(_parent(kind, left, right))
        idx //= 2
        level = nxt
    return path


def verify_merkle_proof(kind, value, path, expected_root):
    current = _leaf(kind, value)
    if type(path) is not list or len(path) > 128:
        raise DomainError("PROOF_PATH")
    for step in path:
        if type(step) is not dict or set(step) != {"side", "hash"}:
            raise DomainError("PROOF_PATH")
        if step["side"] not in {"LEFT", "RIGHT"}:
            raise DomainError("PROOF_SIDE")
        if type(step["hash"]) is not str or len(step["hash"]) != 64:
            raise DomainError("PROOF_HASH")
        current = (_parent(kind, step["hash"], current)
                   if step["side"] == "LEFT"
                   else _parent(kind, current, step["hash"]))
    if current != expected_root:
        raise DomainError("PROOF_ROOT")
    return True


def synchronized(method):
    @wraps(method)
    def call(self, *args, **kwargs):
        with self.lock:
            return method(self, *args, **kwargs)
    return call


class DomainStore:
    """Append-only local ledger plus rebuildable database projection."""

    def __init__(self, path, domain):
        validate_domain(domain)
        self.domain = deepcopy(domain)
        self.domain_id = object_id(domain)
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock=threading.RLock()
        self.db = sqlite3.connect(self.path, isolation_level=None, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS meta (id INTEGER PRIMARY KEY CHECK(id=1), domain_id TEXT NOT NULL, body TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY, event_id TEXT UNIQUE NOT NULL, body TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS detached (event_id TEXT PRIMARY KEY, body TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS heads (collection TEXT NOT NULL, key TEXT NOT NULL, event_id TEXT NOT NULL, tombstone INTEGER NOT NULL, PRIMARY KEY(collection,key))")
        self.db.execute("CREATE TABLE IF NOT EXISTS anchors (height INTEGER PRIMARY KEY, body TEXT NOT NULL)")
        row = self.db.execute("SELECT domain_id,body FROM meta WHERE id=1").fetchone()
        body = canonical(domain).decode("ascii")
        if row is None:
            self.db.execute("INSERT INTO meta VALUES (1,?,?)", (self.domain_id, body))
            fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        elif row[0] != self.domain_id or row[1] != body:
            raise DomainError("DOMAIN_MISMATCH")
        self.collections = {c["name"]: c for c in domain["collections"]}

    @synchronized
    def close(self):
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    @property
    def height(self):
        return self.db.execute("SELECT COALESCE(MAX(seq),0) FROM events").fetchone()[0]

    def _head(self, collection, key):
        return self.db.execute(
            "SELECT event_id,tombstone FROM heads WHERE collection=? AND key=?",
            (collection, key)).fetchone()

    def append(self, event, *, detached_payload=None):
        """Append one valid transition atomically and return its new checkpoint."""
        validate_event(event)
        if event["domain"] != self.domain_id:
            raise DomainError("EVENT_DOMAIN")
        if event["collection"] not in self.collections:
            raise DomainError("EVENT_COLLECTION")
        event_id = object_id(event)
        raw = canonical(event).decode("ascii")
        with self.lock:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                collection = self.collections[event["collection"]]
                row=self.db.execute("SELECT event_id,body FROM events WHERE json_extract(body,'$.collection')=? AND json_extract(body,'$.key')=? ORDER BY seq DESC LIMIT 1",(event["collection"],event["key"])).fetchone()
                head=(row[0],json.loads(row[1])["op"]=="TOMBSTONE") if row else None
        
                if collection["mutation"] == "APPEND_ONLY":
                    if event["op"] != "ASSERT" or event["predecessor"] is not None:
                        raise DomainError("APPEND_ONLY_TRANSITION")
                else:
                    if head is None:
                        if event["op"] != "CREATE" or event["predecessor"] is not None:
                            raise DomainError("CREATE_REQUIRED")
                    else:
                        if event["op"] not in {"SUPERSEDE", "TOMBSTONE"}:
                            raise DomainError("SUCCESSOR_REQUIRED")
                        if event["predecessor"] != head[0]:
                            raise DomainError("STALE_PREDECESSOR")
        
                if event["payload_mode"] == "DETACHED":
                    if detached_payload is None:
                        raise DomainError("DETACHED_PAYLOAD_REQUIRED")
                    if payload_commitment(detached_payload) != event["payload_commitment"]:
                        raise DomainError("PAYLOAD_COMMITMENT")
                elif detached_payload is not None:
                    raise DomainError("UNEXPECTED_DETACHED_PAYLOAD")
        
                for parent in event["parents"]:
                    if not self.db.execute("SELECT 1 FROM events WHERE event_id=?",(parent,)).fetchone():raise DomainError("CAUSAL_PARENT_MISSING")
                if self.db.execute("SELECT 1 FROM events WHERE event_id=?", (event_id,)).fetchone():
                    raise DomainError("EVENT_DUPLICATE")
                seq = self.height + 1
                self.db.execute("INSERT INTO events VALUES (?,?,?)", (seq, event_id, raw))
                if detached_payload is not None:
                    self.db.execute("INSERT INTO detached VALUES (?,?)",
                                    (event_id, canonical(detached_payload).decode("ascii")))
                tombstone = 1 if event["op"] == "TOMBSTONE" else 0
                # APPEND_ONLY heads are only a convenience/latest projection; they do
                # not make earlier assertions mutable or invalid.
                self.db.execute(
                    "INSERT INTO heads VALUES (?,?,?,?) ON CONFLICT(collection,key) DO UPDATE SET event_id=excluded.event_id,tombstone=excluded.tombstone",
                    (event["collection"], event["key"], event_id, tombstone))
                result={"event_id":event_id,"height":seq,"anchor":self.anchor()}
                self.db.execute("COMMIT")
            except BaseException:
                if self.db.in_transaction:
                    self.db.execute("ROLLBACK")
                raise
            return result


    def _event_ids(self, height=None):
        height = self.height if height is None else height
        return [row[0] for row in self.db.execute(
            "SELECT event_id FROM events WHERE seq<=? ORDER BY seq", (height,))]

    def _state_items(self, height=None):
        # Historical state roots are rebuilt from the event stream so that an old
        # anchor never depends on today's materialized heads table.
        height = self.height if height is None else height
        heads = {}
        for eid, raw in self.db.execute("SELECT event_id,body FROM events WHERE seq<=? ORDER BY seq", (height,)):
            event = json.loads(raw)
            heads[(event["collection"], event["key"])] = {
                "collection": event["collection"], "key": event["key"],
                "event_id": eid, "tombstone": event["op"] == "TOMBSTONE",
            }
        return [heads[key] for key in sorted(heads)]

    @synchronized
    def anchor(self, *, height=None, finality_ref=None, witness_refs=()):
        height = self.height if height is None else height
        if type(height) is not int or not 0 <= height <= self.height:
            raise DomainError("HEIGHT")
        history_root = _merkle("HISTORY", self._event_ids(height))
        state_root = _merkle("STATE", self._state_items(height))
        return make_anchor(self.domain_id, height, history_root, state_root,
                           finality_ref=finality_ref, witness_refs=witness_refs)

    @synchronized
    def checkpoint(self, *, finality_ref=None, witness_refs=()):
        anchor = self.anchor(finality_ref=finality_ref, witness_refs=witness_refs)
        self.db.execute("INSERT OR REPLACE INTO anchors VALUES (?,?)",
                        (anchor["height"], canonical(anchor).decode("ascii")))
        return anchor

    @synchronized
    def get(self, collection, key, *, include_tombstone=False):
        head = self._head(collection, key)
        if head is None:
            raise KeyError((collection, key))
        eid, tombstone = head
        if tombstone and not include_tombstone:
            raise KeyError((collection, key))
        raw = self.db.execute("SELECT body FROM events WHERE event_id=?", (eid,)).fetchone()[0]
        event = json.loads(raw)
        if event["payload_mode"] == "INLINE":
            value = deepcopy(event["payload"])
        elif event["payload_mode"] == "DETACHED":
            row = self.db.execute("SELECT body FROM detached WHERE event_id=?", (eid,)).fetchone()
            value = json.loads(row[0]) if row else None
        else:
            value = None
        return {"event_id": eid, "event": event, "value": value}

    def history(self, collection=None, key=None, *, include_bodies=True):
        sql = "SELECT seq,event_id,body FROM events"
        clauses, params = [], []
        if collection is not None:
            clauses.append("json_extract(body,'$.collection')=?"); params.append(collection)
        if key is not None:
            clauses.append("json_extract(body,'$.key')=?"); params.append(key)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY seq"
        out = []
        for seq, eid, raw in self.db.execute(sql, params):
            item = {"seq": seq, "event_id": eid}
            if include_bodies:
                item["event"] = json.loads(raw)
            out.append(item)
        return out

    @synchronized
    def prove_event(self, event_id, *, height=None, disclose_body=False):
        height = self.height if height is None else height
        ids = self._event_ids(height)
        if event_id not in ids:
            raise KeyError(event_id)
        anchor = self.anchor(height=height)
        proof = {
            "version": "covenant-domain-proof/0.1",
            "kind": "EVENT_MEMBERSHIP",
            "domain": self.domain_id,
            "height": height,
            "event_id": event_id,
            "path": _merkle_proof("HISTORY", ids, ids.index(event_id)),
            "anchor": anchor,
            "event": None,
        }
        if disclose_body:
            proof["event"] = json.loads(self.db.execute(
                "SELECT body FROM events WHERE event_id=?", (event_id,)).fetchone()[0])
        return proof

    @synchronized
    def prove_head(self, collection, key, *, height=None):
        height = self.height if height is None else height
        items = self._state_items(height)
        index = next((i for i, item in enumerate(items)
                      if item["collection"] == collection and item["key"] == key), None)
        if index is None:
            raise KeyError((collection, key))
        anchor = self.anchor(height=height)
        return {
            "version": "covenant-domain-proof/0.1",
            "kind": "STATE_HEAD",
            "domain": self.domain_id,
            "height": height,
            "item": items[index],
            "path": _merkle_proof("STATE", items, index),
            "anchor": anchor,
        }

    @synchronized
    def export_replication_bundle(self, *, since=0):
        """Full-event replication is available only for explicitly public domains."""
        if self.domain["publication"] != "PUBLIC":
            raise DomainError("DOMAIN_NOT_PUBLIC")
        if type(since) is not int or not 0 <= since <= self.height:
            raise DomainError("HEIGHT")
        height = self.height
        for _,_,raw in self.db.execute("SELECT seq,event_id,body FROM events WHERE seq>? AND seq<=? ORDER BY seq",(since,height)):
            event=json.loads(raw);visibility=self.collections[event["collection"]]["visibility"]
            if visibility in {"PRIVATE","PROOFS_ONLY"}:raise DomainError("COLLECTION_NOT_PUBLIC")
        rows = self.db.execute("SELECT seq,event_id,body FROM events WHERE seq>? AND seq<=? ORDER BY seq", (since,height)).fetchall()
        return {
            "version": "covenant-domain-replication/0.1",
            "domain": deepcopy(self.domain),
            "from_height": since,
            "to_height": height,
            "events": [{"seq": seq, "event_id": eid, "event": json.loads(raw)}
                       for seq, eid, raw in rows],
            "anchor": self.anchor(height=height),
        }

    @synchronized
    def validate_history(self):
        heads={};seen=set();expected=1
        for seq,eid,raw in self.db.execute("SELECT seq,event_id,body FROM events ORDER BY seq"):
            event=json.loads(raw);validate_event(event)
            if seq!=expected or object_id(event)!=eid or event["domain"]!=self.domain_id or event["collection"] not in self.collections:raise DomainError("CORRUPT_HISTORY")
            if any(p not in seen for p in event["parents"]):raise DomainError("CAUSAL_PARENT_MISSING")
            pair=(event["collection"],event["key"]);prev=heads.get(pair);collection=self.collections[event["collection"]]
            if collection["mutation"]=="APPEND_ONLY":
                if event["op"]!="ASSERT" or event["predecessor"] is not None:raise DomainError("APPEND_ONLY_TRANSITION")
            elif prev is None:
                if event["op"]!="CREATE" or event["predecessor"] is not None:raise DomainError("CREATE_REQUIRED")
            elif event["op"] not in {"SUPERSEDE","TOMBSTONE"} or event["predecessor"]!=prev:raise DomainError("STALE_PREDECESSOR")
            if event["payload_mode"]=="DETACHED":
                row=self.db.execute("SELECT body FROM detached WHERE event_id=?",(eid,)).fetchone()
                if row is None or payload_commitment(json.loads(row[0]))!=event["payload_commitment"]:raise DomainError("CORRUPT_PAYLOAD")
            heads[pair]=eid;seen.add(eid);expected+=1
        return True

    @synchronized
    def rebuild_projection(self):
        """Destroy and reconstruct the disposable heads table from immutable history."""
        self.db.execute("BEGIN IMMEDIATE")
        try:
            self.validate_history()
            self.db.execute("DELETE FROM heads")
            for eid, raw in self.db.execute("SELECT event_id,body FROM events ORDER BY seq").fetchall():
                event = json.loads(raw)
                tombstone = 1 if event["op"] == "TOMBSTONE" else 0
                self.db.execute(
                    "INSERT INTO heads VALUES (?,?,?,?) ON CONFLICT(collection,key) DO UPDATE SET event_id=excluded.event_id,tombstone=excluded.tombstone",
                    (event["collection"], event["key"], eid, tombstone))
            self.db.execute("COMMIT")
        except BaseException:
            if self.db.in_transaction:
                self.db.execute("ROLLBACK")
            raise
        return self.anchor()


def verify_event_proof(proof, expected_anchor):
    if proof.get("version") != "covenant-domain-proof/0.1" or proof.get("kind") != "EVENT_MEMBERSHIP":
        raise DomainError("PROOF_KIND")
    if proof.get("anchor") != expected_anchor:
        raise DomainError("ANCHOR_MISMATCH")
    if proof["domain"] != expected_anchor["domain"] or proof["height"] != expected_anchor["height"]:
        raise DomainError("PROOF_SCOPE")
    if proof.get("event") is not None and object_id(proof["event"]) != proof["event_id"]:
        raise DomainError("EVENT_TAMPER")
    return verify_merkle_proof("HISTORY", proof["event_id"], proof["path"],
                               expected_anchor["history_root"])


def verify_head_proof(proof, expected_anchor):
    if proof.get("version") != "covenant-domain-proof/0.1" or proof.get("kind") != "STATE_HEAD":
        raise DomainError("PROOF_KIND")
    if proof.get("anchor") != expected_anchor:
        raise DomainError("ANCHOR_MISMATCH")
    if proof["domain"] != expected_anchor["domain"] or proof["height"] != expected_anchor["height"]:
        raise DomainError("PROOF_SCOPE")
    return verify_merkle_proof("STATE", proof["item"], proof["path"],
                               expected_anchor["state_root"])
