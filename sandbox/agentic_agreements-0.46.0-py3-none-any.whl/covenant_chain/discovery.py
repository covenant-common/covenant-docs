"""Signed peer records from several untrusted sources.

Identity is the consensus key. A DNS seed, a gossip message, a file next to
genesis, or an in-memory registry can all carry the same record. Only the
signature and the expiry are trusted.

A ``Directory`` pins each member's consensus key: the adopted committee when
the caller passes ``pins``, otherwise the first accepted record. A record with
a higher sequence and a different key (a QR or gossip eclipse) is ``PEER_KEY``
and leaves the previous endpoints dialable. A key changes only when the pinned
key signs the new record under ``COVENANT-PEER-ROTATION`` (``prior``) or the
governance council attests it under ``COVENANT-PEER-GOVERNANCE``
(``governance``). Those two optional fields live in the envelope; the signed
``covenant-peer-record/1`` body is unchanged, and callers other than the
directory keep the exact two-field envelope. Maturity: beta.

This module does not change peer admission for the live gateway.
transport.validate_https_peers still requires literal IPs. Overlay endpoints
are discovery records until an operator opts into them. Nothing here is an
ANNOUNCE_ENDPOINT consensus operation: app.py is not modified, and a record
cannot enlarge the adopted committee.
"""
from __future__ import annotations

import base64
import binascii
import ipaddress
import re
import urllib.parse

from .crypto import canonical, digest, exact, integer, key, need, sign, verify

VERSION = 'covenant-peer-record/1'
LABEL = 'COVENANT-PEER-RECORD'
ROTATION_LABEL = 'COVENANT-PEER-ROTATION'
GOVERNANCE_LABEL = 'COVENANT-PEER-GOVERNANCE'
_ENVELOPE_FIELDS = frozenset({'body', 'signature', 'prior', 'governance'})
MAX_GOVERNANCE_SIGNATURES = 16
_HEX64 = re.compile(r'[0-9a-f]{64}\Z')
_HEX128 = re.compile(r'[0-9a-f]{128}\Z')
MAX_LIFETIME = 30 * 24 * 3600
KINDS = {'ip', 'dns', 'onion', 'i2p'}
ONION = re.compile(r'[a-z2-7]{56}\.onion\Z')
I2P = re.compile(r'[a-z2-7]{52}\.b32\.i2p\Z')
DNS_LABEL = re.compile(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\Z')
TXT_PREFIX = 'covenant1 '


class DiscoveryError(ValueError):
    pass


def _fail(code):
    raise DiscoveryError(code)


def _endpoint(kind, url):
    need(kind in KINDS, 'PEER_ENDPOINT_KIND')
    need(type(url) is str and 12 <= len(url) <= 256 and all(33 <= ord(c) <= 126 for c in url), 'PEER_ENDPOINT')
    uri = urllib.parse.urlsplit(url)
    need(uri.scheme == 'https' and uri.port and 1 <= uri.port <= 65535, 'PEER_ENDPOINT')
    need(uri.username is None and uri.password is None and uri.path in ('', '/') and not uri.query and not uri.fragment, 'PEER_ENDPOINT')
    host = uri.hostname or ''
    if kind == 'ip':
        try:
            ipaddress.ip_address(host)
        except ValueError as exc:
            raise DiscoveryError('PEER_LITERAL_IP') from exc
    elif kind == 'dns':
        labels = host.split('.')
        need(1 < len(labels) <= 8 and all(DNS_LABEL.fullmatch(label) for label in labels), 'PEER_DNS')
        need(not host.endswith('.onion') and not host.endswith('.i2p'), 'PEER_DNS_OVERLAY')
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            _fail('PEER_DNS_IS_IP')
    elif kind == 'onion':
        need(ONION.fullmatch(host) is not None, 'PEER_ONION')
    else:
        need(I2P.fullmatch(host) is not None, 'PEER_I2P')
    return {'kind': kind, 'url': url}


def record_body(member, consensus_key, endpoints, tls_pin, expiry, sequence):
    need(type(member) is str and 0 < len(member) <= 80 and all(33 <= ord(c) <= 126 for c in member), 'PEER_MEMBER')
    key(consensus_key)
    key(tls_pin)
    integer(expiry, True)
    integer(sequence)
    need(type(endpoints) is list and 1 <= len(endpoints) <= 8, 'PEER_ENDPOINTS')
    cleaned = []
    seen = set()
    for item in endpoints:
        exact(item, 'kind url')
        endpoint = _endpoint(item['kind'], item['url'])
        need(endpoint['url'] not in seen, 'PEER_DUPLICATE_ENDPOINT')
        seen.add(endpoint['url'])
        cleaned.append(endpoint)
    body = {
        'v': VERSION, 'member': member, 'consensus_key': consensus_key, 'endpoints': cleaned,
        'tls_pin': tls_pin, 'expiry': expiry, 'sequence': sequence,
    }
    canonical(body)
    return body


def sign_record(private_key, body):
    from .crypto import public_key
    need(public_key(private_key) == body['consensus_key'], 'PEER_SIGNER')
    return {'body': body, 'signature': sign(private_key, LABEL, body)}


def sign_rotation(old_private, envelope):
    """The previous consensus key authorizes a record signed by the new key."""
    from .crypto import public_key
    _record_envelope(envelope)
    body = envelope['body']
    exact(body, 'v member consensus_key endpoints tls_pin expiry sequence')
    cleaned = record_body(body['member'], body['consensus_key'], body['endpoints'], body['tls_pin'], body['expiry'], body['sequence'])
    need(cleaned == body, 'PEER_CANONICAL')
    need(public_key(old_private) != body['consensus_key'], 'PEER_ROTATION_SAME')
    verify(body['consensus_key'], LABEL, body, envelope['signature'])
    return {'body': body, 'signature': envelope['signature'], 'prior': sign(old_private, ROTATION_LABEL, body)}


def governance_statement(body):
    """The council attests the member, the new key, and the record id."""
    return {'member': body['member'], 'consensus_key': body['consensus_key'], 'record': record_id(body)}


def sign_governance(private_key, policy, body):
    """One council member's signature for a governance key change under ``policy``."""
    from .governance_policy import sign_attestation
    return sign_attestation(private_key, policy, GOVERNANCE_LABEL, governance_statement(body))


def _record_envelope(envelope):
    need(type(envelope) is dict, 'FIELDS')
    fields = set(envelope)
    need({'body', 'signature'} <= fields <= _ENVELOPE_FIELDS, 'FIELDS')
    if 'prior' in envelope:
        need(type(envelope['prior']) is str and _HEX128.fullmatch(envelope['prior']) is not None, 'PEER_ROTATION')
    if 'governance' in envelope:
        signatures = envelope['governance']
        need(type(signatures) is dict and 1 <= len(signatures) <= MAX_GOVERNANCE_SIGNATURES, 'PEER_GOVERNANCE')
        for member, signature in signatures.items():
            need(type(member) is str and _HEX64.fullmatch(member) is not None, 'PEER_GOVERNANCE')
            need(type(signature) is str and _HEX128.fullmatch(signature) is not None, 'PEER_GOVERNANCE')
    return envelope


def verify_record(envelope, now, rotation=False):
    """Check one signed record. Only the directory passes ``rotation=True``.

    ``rotation=True`` also admits the optional ``prior`` and ``governance``
    envelope fields (``Directory.add`` decides whether they authorize a key
    change). Every other caller keeps the exact ``body signature`` envelope.
    """
    if rotation:
        _record_envelope(envelope)
    else:
        exact(envelope, 'body signature')
    body = envelope['body']
    exact(body, 'v member consensus_key endpoints tls_pin expiry sequence')
    need(body['v'] == VERSION, 'PEER_VERSION')
    cleaned = record_body(body['member'], body['consensus_key'], body['endpoints'], body['tls_pin'], body['expiry'], body['sequence'])
    need(cleaned == body, 'PEER_CANONICAL')
    integer(now)
    if not body['expiry'] > now:
        _fail('PEER_EXPIRED')
    if body['expiry'] > now + MAX_LIFETIME:
        _fail('PEER_LIFETIME')
    verify(body['consensus_key'], LABEL, body, envelope['signature'])
    return body


def encode_txt(envelope):
    verify_fields = canonical(envelope)
    text = TXT_PREFIX + base64.urlsafe_b64encode(verify_fields).decode('ascii').rstrip('=')
    need(len(text) <= 4000, 'PEER_TXT_SIZE')
    return text


def parse_txt(text):
    need(type(text) is str and text.startswith(TXT_PREFIX) and len(text) <= 4000, 'PEER_TXT')
    payload = text[len(TXT_PREFIX):]
    pad = '=' * (-len(payload) % 4)
    try:
        raw = base64.urlsafe_b64decode(payload + pad)
    except (ValueError, binascii.Error) as exc:
        raise DiscoveryError('PEER_TXT') from exc
    from .crypto import loads
    return loads(raw)


class Directory:
    """Highest sequence for each member, under that member's pinned key.

    ``pins`` is the adopted committee ``{member: consensus key}``. A member
    that is not listed is pinned by its first accepted record. A later record
    keeps the pinned key. A different key is stored only when ``prior``
    verifies under the pinned key or ``governance`` carries a governance-council
    attestation under ``governance`` (a ``governance_policy`` document); with no
    policy a governance blob authorizes nothing. ``roots`` keeps the first key,
    so ``dial_set`` still reaches a member after an authorized rotation.
    Sources are recorded and then ignored.
    """

    def __init__(self, pins=None, governance=None):
        self.records = {}
        self.sources = {}
        self.pins = {}
        self.roots = {}
        self.governance = None
        if governance is not None:
            from .governance_policy import check_policy
            self.governance = check_policy(governance)
        if pins is None:
            return
        need(type(pins) is dict and len(pins) <= 64, 'PEER_PINS')
        for member, public in pins.items():
            need(type(member) is str and 0 < len(member) <= 80 and all(33 <= ord(c) <= 126 for c in member), 'PEER_MEMBER')
            key(public)
        self.pins = dict(pins)
        self.roots = dict(pins)

    def add(self, envelope, now, source):
        need(type(source) is str and 0 < len(source) <= 40, 'PEER_SOURCE')
        try:
            body = verify_record(envelope, now, rotation=True)
        except (DiscoveryError, ValueError) as exc:
            return {'accepted': False, 'reason': str(exc)}
        member = body['member']
        pinned = self.pins.get(member)
        rotating = pinned is not None and body['consensus_key'] != pinned
        if rotating and not _rotation_authorized(pinned, body, envelope, self.governance):
            return {'accepted': False, 'reason': 'PEER_KEY', 'member': member}
        current = self.records.get(member)
        if current is not None:
            previous = current['body']['sequence']
            if body['sequence'] < previous:
                return {'accepted': False, 'reason': 'PEER_STALE'}
            if body['sequence'] == previous and canonical(current['body']) != canonical(body):
                return {'accepted': False, 'reason': 'PEER_CONFLICT'}
            if body['sequence'] == previous:
                return {'accepted': True, 'reason': 'PEER_DUPLICATE', 'member': member}
        self.records[member] = envelope
        self.sources[member] = source
        if member not in self.roots:
            self.roots[member] = pinned if pinned is not None else body['consensus_key']
        if pinned is None or rotating:
            self.pins[member] = body['consensus_key']
        return {'accepted': True, 'reason': 'PEER_ACCEPTED', 'member': member}

    def add_many(self, envelopes, now, source):
        return [self.add(envelope, now, source) for envelope in envelopes]


def _rotation_authorized(pinned, body, envelope, governance):
    """The pinned key signed the new record, or the governance council attested it. Nothing else."""
    if 'prior' in envelope:
        try:
            verify(pinned, ROTATION_LABEL, body, envelope['prior'])
            return True
        except ValueError:
            pass
    if governance is None or 'governance' not in envelope:
        return False
    from .governance_policy import attest
    try:
        attest(governance, GOVERNANCE_LABEL, governance_statement(body), envelope['governance'])
    except ValueError:
        return False
    return True


def load_bootstrap_file(raw, now, pins=None, governance=None):
    """A file beside genesis, not a field inside the consensus genesis object.

    Pass the adopted committee as ``pins`` so the file cannot pin a stranger's
    key for a validator id; without it the first record pins the member.
    """
    from .crypto import loads
    document = loads(raw)
    if type(document) is not dict or set(document) != {'v', 'records'}:
        _fail('BOOTSTRAP_FIELDS')
    need(document['v'] == 'covenant-peer-bootstrap/1', 'BOOTSTRAP_VERSION')
    need(type(document['records']) is list and 1 <= len(document['records']) <= 64, 'BOOTSTRAP_RECORDS')
    if 'protocol' in document or 'validators' in document:
        _fail('BOOTSTRAP_IS_GENESIS')
    directory = Directory(pins=pins, governance=governance)
    results = directory.add_many(document['records'], now, 'genesis-file')
    need(all(item['accepted'] for item in results), 'BOOTSTRAP_RECORD')
    return directory


def assert_separate_from_genesis(genesis):
    """Guard for callers. Peer endpoints must not be written into a genesis object."""
    need(type(genesis) is dict and 'protocol' in genesis and 'validators' in genesis, 'GENESIS_SHAPE')
    for field in ('peers', 'endpoints', 'peer_records', 'discovery'):
        need(field not in genesis, 'GENESIS_PEER_FIELD')
    return True


class RegistryHook:
    """In-memory stand-in for a future ANNOUNCE_ENDPOINT.

    Not called by app.py. Announcements are accepted only from the adopted
    committee, and only for that member's existing consensus key. Activating
    this as a consensus operation would be a new protocol version.
    """

    def __init__(self, committee):
        need(type(committee) is dict and 1 <= len(committee) <= 64, 'REGISTRY_COMMITTEE')
        for member, public in committee.items():
            need(type(member) is str and 0 < len(member) <= 80, 'REGISTRY_MEMBER')
            key(public)
        self.committee = dict(committee)
        self.rows = {}

    def announce(self, envelope, now):
        body = verify_record(envelope, now)
        public = self.committee.get(body['member'])
        if public is None or public != body['consensus_key']:
            _fail('REGISTRY_NOT_COMMITTEE')
        self.rows[body['member']] = envelope
        return {'accepted': True, 'consensus_change': False, 'member': body['member']}

    def read(self):
        return [self.rows[member] for member in sorted(self.rows)]


def dial_set(directory, committee, now):
    """Endpoints for adopted validators only. Strangers can be stored and still not dialed.

    A rotated member stays dialable when the directory root for that member is
    the adopted key and the stored record carries the pinned successor key.
    """
    chosen = {}
    roots = getattr(directory, 'roots', {})
    pins = getattr(directory, 'pins', {})
    for member, public in committee.items():
        envelope = directory.records.get(member)
        if envelope is None:
            continue
        body = verify_record(envelope, now, rotation=True)
        if body['consensus_key'] == public or (roots.get(member) == public and pins.get(member) == body['consensus_key']):
            chosen[member] = body
    return chosen


def overlay_dial_plan(url, proxy):
    """Describe a SOCKS path to an onion or i2p endpoint. Does not connect."""
    need(type(proxy) is str and proxy.startswith(('socks5://', 'socks5h://')), 'SOCKS_PROXY')
    parsed = urllib.parse.urlsplit(proxy)
    need(parsed.hostname in {'127.0.0.1', '::1'} and parsed.port and not parsed.username, 'SOCKS_LOOPBACK')
    kind = 'onion' if (parsed_host := urllib.parse.urlsplit(url).hostname or '').endswith('.onion') else 'i2p'
    endpoint = _endpoint(kind, url)
    host = urllib.parse.urlsplit(endpoint['url']).hostname
    port = urllib.parse.urlsplit(endpoint['url']).port
    return {
        'connected': False,
        'proxy_host': parsed.hostname,
        'proxy_port': parsed.port,
        'destination_host': host,
        'destination_port': port,
        'socks5_greeting': bytes((0x05, 0x01, 0x00)),
        'socks5_connect': socks5_connect_request(host, port),
    }


def socks5_connect_request(host, port):
    raw = host.encode('ascii')
    need(1 <= len(raw) <= 255 and 1 <= port <= 65535, 'SOCKS_DESTINATION')
    return bytes((0x05, 0x01, 0x00, 0x03, len(raw))) + raw + port.to_bytes(2, 'big')


def record_id(body):
    return digest(LABEL, body)


def match_seed_txt(seeds, txt_map, now):
    """Check supplied TXT strings against the signed seed operators.

    ``txt_map`` is ``{dns name: [covenant1 text, ...]}``. This function does
    not open a socket. A live lookup belongs in ``seed_dns.resolve_seed_list``.
    """
    from .release_trust import require_seed_operators
    report = require_seed_operators(seeds)
    need(report['independent'], 'SEED_OPERATORS')
    need(type(txt_map) is dict, 'SEED_DNS')
    matched = []
    for operator in seeds['operators']:
        for name in operator['names']:
            texts = txt_map.get(name)
            need(type(texts) is list and 1 <= len(texts) <= 8, 'SEED_DNS_EMPTY')
            ok = False
            for text in texts:
                try:
                    body = verify_record(parse_txt(text), now)
                except (DiscoveryError, ValueError):
                    continue
                if body['consensus_key'] == operator['key']:
                    ok = True
                    break
            need(ok, 'SEED_DNS_MISMATCH')
            matched.append(name)
    return {'matched': matched, 'operators': report['operators'], 'dns_contacted': False}
