"""Disposable offline BLE-like hop → adopted carrier → recipient simulation."""
import asyncio
import json
from pathlib import Path
import secrets
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from . import crypto as c, offline as o, offline_ble as b, offline_forwarding as f
from .offline_store import OfflineStore


async def journey():
    a,r,z=[Ed25519PrivateKey.generate() for _ in range(3)]; pa,pr,pz=map(c.public_key,(a,r,z))
    scope='a'*64; shared=secrets.token_bytes(32); storage=secrets.token_bytes(32)
    agreement=o.draft(scope=scope,parties=sorted([pa,pz]),terms={
        'who':['synthetic grower','synthetic village shop'],'what':'deliver one crate',
        'where':'synthetic village','when':'before the adopted deadline','why':'disconnected trade',
        'how':'signed receipt, separate payment confirmation','which':'crate-1','price':90},
        valid_from=90,valid_until=1000,nonce='b'*64)
    value={'agreement':agreement,'assents':[o.assent(agreement,a),o.assent(agreement,z)]}
    packet=o.seal('AGREEMENT',value,signing_key=a,recipient=pz,shared_key=shared,
                  scope=scope,created=90,expires=1000)
    with TemporaryDirectory(prefix='covenant-connectivity-demo-') as directory:
        def vault(name,owner): return OfflineStore(Path(directory)/name,owner=owner,scope=scope,storage_key=storage)
        source,relay,dest=vault('grower',pa),vault('courier',pr),vault('shop',pz)
        try:
            ref=source.enqueue(packet,now=100)
            inbox=b.BleInbox(relay,channel='synthetic-neighbour',allowed_senders={pa},relay=True)
            class LocalClient:
                is_connected=True
                def __init__(self):
                    self.rx=SimpleNamespace(uuid=b.RX,properties=['write']); self.tx=SimpleNamespace(uuid=b.TX,properties=['read'])
                    self.services=SimpleNamespace(get_service=lambda uuid: SimpleNamespace(
                        get_characteristic=lambda uuid: self.rx if uuid==b.RX else self.tx))
                    self.mailbox=b.GattMailbox(inbox,signing_key=r,clock=lambda:100)
                async def write_gatt_char(self,char,value,response): self.mailbox.write(char,value)
                async def read_gatt_char(self,char,**kw): return self.mailbox.read(char)
            client=LocalClient()
            async def first(raw): return await b.send_ble(client,raw,expected_peer=pr,clock=lambda:100)
            hop=await f.forward_once(source,[f.AdoptedLink(f.descriptor('neighbour','BLE',pr,8192,relay=True),
                                    available=lambda p:True,send=first)],clock=lambda:100)
            relay.close(); relay=vault('courier',pr)
            async def second(raw):
                original=o.exact_load(raw)
                dest.retain(original,allowed_senders={pa},now=101,shared_key=shared)
                return f.hop_receipt(original,z,at=101)
            final=await f.forward_once(relay,[f.AdoptedLink(f.descriptor('owner gateway','owner-provided-IP',pz,8192),
                                        available=lambda p:True,send=second)],clock=lambda:101)
            assert c.canonical(dest.packet(ref)['packet'])==c.canonical(packet)
            ack=o.delivery_ack(packet,z,at=101); source.acknowledge(ref,ack); relay.acknowledge(ref,ack)
            retained=dest.packet(ref)['payload']['value']
            review=o.review(retained['agreement'],retained['assents'],expected_id=o.agreement_id(agreement),now=101)
            assert review['status']=='SIGNED'
            return {'status':'PASS','simulation':True,'journey':[review['status'],hop['results'][0]['status'],
                    'RELAY_REOPENED',final['results'][0]['status'],source.status(ref,now=101)['delivery']],
                    'exact_encrypted_packet_preserved':True,'relay_can_read_terms':False,
                    'application_bytes':len(c.canonical(packet)),'ble_frames':len(b.frames(c.canonical(packet))),
                    'physical_ble':False,'satellite_service_called':False,'external_network_calls':0,
                    'payment_verified':False,'ledger_confirmed':False,'execution_authorized':False}
        finally: source.close(); relay.close(); dest.close()


def run(): return asyncio.run(journey())


if __name__=='__main__': print(json.dumps(run(),indent=2,sort_keys=True))
