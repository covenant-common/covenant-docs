"""Offline agreement and encrypted transport profiles, independent of finality.

Keys and peer pins belong to the owner. Relays need no decryption key. This is a
bounded Covenant store/carry/forward format. dtn_bundle carries the same signed
packet bytes inside a BPv7 (RFC 9171) bundle when a delay-tolerant network is used.
"""
import base64
from copy import deepcopy
import hashlib
import secrets

from . import crypto as c

AGREEMENT = 'covenant-offline-agreement/0.1'
ENVELOPE = 'covenant-offline-envelope/0.1'
ACK = 'covenant-offline-delivery/0.1'
ASSENT_LABEL = 'COVENANT-OFFLINE-ASSENT-0.1'
PACKET_LABEL = 'COVENANT-OFFLINE-PACKET-0.1'
ACK_LABEL = 'COVENANT-OFFLINE-DELIVERY-0.1'
MAX_PAYLOAD = 49152
MAX_PACKET = 68000
MAX_LIFETIME = 30 * 86400
KINDS = {'AGREEMENT', 'COURIER', 'DATA'}


def b64(raw):
    return base64.b64encode(raw).decode('ascii')


def unb64(value, limit):
    c.need(type(value) is str and len(value) <= 4*((limit+2)//3), 'OFFLINE_BASE64_SIZE')
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError('OFFLINE_BASE64') from exc
    c.need(len(raw) <= limit and b64(raw) == value, 'OFFLINE_BASE64_CANONICAL')
    return raw


def exact_load(raw, limit=MAX_PACKET):
    c.need(type(raw) is bytes and len(raw) <= limit, 'OFFLINE_SIZE')
    value = c.loads(raw)
    c.need(c.canonical(value) == raw, 'OFFLINE_CANONICAL_BYTES')
    return value


def draft(*, scope, parties, terms, valid_from, valid_until, nonce, previous=None):
    value = dict(version=AGREEMENT, scope=scope, parties=deepcopy(parties),
                 terms=deepcopy(terms), valid_from=valid_from, valid_until=valid_until,
                 nonce=nonce, previous=previous)
    agreement_id(value)
    return value


def agreement_id(value):
    c.exact(value, 'version scope parties terms valid_from valid_until nonce previous')
    c.need(value['version'] == AGREEMENT, 'OFFLINE_AGREEMENT_VERSION')
    c.key(value['scope']); c.key(value['nonce'])
    if value['previous'] is not None:
        c.key(value['previous'])
    parties = value['parties']
    c.need(type(parties) is list and 1 <= len(parties) <= 16 and
           all(type(p) is str for p in parties), 'OFFLINE_PARTIES')
    for party in parties:
        c.verification_key(party)
    c.need(parties == sorted(set(parties)), 'OFFLINE_PARTY_ORDER')
    c.integer(value['valid_from']); c.integer(value['valid_until'])
    c.need(value['valid_until'] > value['valid_from'], 'OFFLINE_AGREEMENT_WINDOW')
    c.need(len(c.canonical(value)) <= 32768, 'OFFLINE_AGREEMENT_SIZE')
    return c.digest('COVENANT-OFFLINE-AGREEMENT-0.1', value)


def signing_payload(agreement):
    return {'label': ASSENT_LABEL, 'body': {'agreement': agreement_id(agreement)}}


def assent(agreement, signing_key):
    """Explicit owner action. Never exposed as an agent tool."""
    who = c.public_key(signing_key)
    c.need(who in agreement['parties'], 'OFFLINE_NOT_PARTY')
    payload = signing_payload(agreement)
    return {'signer': who, 'signature': c.sign(signing_key, payload['label'], payload['body'])}


def review(agreement, assents, *, expected_id, now):
    ref = agreement_id(agreement); c.integer(now)
    c.need(ref == expected_id, 'OFFLINE_AGREEMENT_PIN')
    c.need(type(assents) is list and len(assents) <= 16, 'OFFLINE_ASSENTS')
    seen = set()
    for signed in assents:
        c.exact(signed, 'signer signature'); who = signed['signer']
        c.need(type(who) is str and who in agreement['parties'] and who not in seen,
               'OFFLINE_ASSENT_PARTY')
        c.verify(who, ASSENT_LABEL, {'agreement': ref}, signed['signature']); seen.add(who)
    complete = seen == set(agreement['parties'])
    active = agreement['valid_from'] <= now < agreement['valid_until']
    return {'agreement': ref, 'status': 'SIGNED' if complete else 'AWAITING_SIGNATURES',
            'missing_signers': sorted(set(agreement['parties'])-seen),
            'within_stated_window': active, 'current_authority_verified': False,
            'payment_verified': False, 'execution_authorized': False}


def transport_cipher(version=None):
    """AES-GCM-SIV, only when the installed cryptography is in the approved family.

    A machine still on cryptography 41 raises CRYPTOGRAPHY_VERSION here, as a
    ValueError, instead of an ImportError while the tool list is loading.
    """
    from .security import dependency_status
    if not dependency_status(version)['acceptable']:
        raise ValueError('CRYPTOGRAPHY_VERSION')
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCMSIV
    except ImportError as exc:
        raise ValueError('CRYPTOGRAPHY_VERSION') from exc
    return AESGCMSIV


def _key(value):
    c.need(type(value) is bytes and len(value) == 32, 'OFFLINE_KEY_32_BYTES')
    return value


def key_id(key):
    return hashlib.sha256(b'COVENANT-OFFLINE-KEY-0.1\0'+_key(key)).hexdigest()


def _header(h):
    c.exact(h, 'version scope sender recipient key_id created expires nonce')
    c.need(h['version'] == ENVELOPE, 'OFFLINE_ENVELOPE_VERSION')
    for name in ('scope', 'key_id'):
        c.key(h[name])
    for name in ('sender', 'recipient'):
        c.need(type(h[name]) is str, 'OFFLINE_ED25519_ONLY'); c.verification_key(h[name])
    c.need(h['sender'] != h['recipient'], 'OFFLINE_DISTINCT_ENDPOINTS')
    c.integer(h['created']); c.integer(h['expires'])
    c.need(0 < h['expires']-h['created'] <= MAX_LIFETIME, 'OFFLINE_LIFETIME')
    c.need(type(h['nonce']) is str and len(h['nonce']) == 24 and
           all(ch in '0123456789abcdef' for ch in h['nonce']), 'OFFLINE_NONCE')


def packet_id(packet):
    c.exact(packet, 'header ciphertext signature'); _header(packet['header'])
    c.need(len(c.canonical(packet)) <= MAX_PACKET, 'OFFLINE_PACKET_SIZE')
    unb64(packet['ciphertext'], MAX_PAYLOAD+16)
    c.verify(packet['header']['sender'], PACKET_LABEL,
             {k: packet[k] for k in ('header', 'ciphertext')}, packet['signature'])
    return c.digest('COVENANT-OFFLINE-PACKET-ID-0.1', packet)


def inspect_packet(packet, *, scope, allowed_senders, now):
    ref = packet_id(packet); c.integer(now)
    h = packet['header']
    c.need(h['scope'] == scope and h['sender'] in allowed_senders, 'OFFLINE_PEER_PIN')
    c.need(h['created'] <= now < h['expires'], 'OFFLINE_PACKET_WINDOW')
    return ref


def seal(kind, value, *, signing_key, recipient, shared_key, scope, created, expires):
    c.need(type(kind) is str and kind in KINDS, 'OFFLINE_KIND')
    payload = c.canonical({'kind': kind, 'value': value})
    c.need(len(payload) <= MAX_PAYLOAD, 'OFFLINE_PAYLOAD_SIZE')
    header = dict(version=ENVELOPE, scope=scope, sender=c.public_key(signing_key),
                  recipient=recipient, key_id=key_id(shared_key), created=created,
                  expires=expires, nonce=secrets.token_hex(12))
    _header(header)
    ciphertext = transport_cipher()(_key(shared_key)).encrypt(bytes.fromhex(header['nonce']),
                                                    payload, c.canonical(header))
    body = {'header': header, 'ciphertext': b64(ciphertext)}
    packet = {**body, 'signature': c.sign(signing_key, PACKET_LABEL, body)}
    packet_id(packet)
    return packet


def open_packet(packet, *, recipient, shared_key, scope, allowed_senders, now):
    inspect_packet(packet, scope=scope, allowed_senders=allowed_senders, now=now)
    h = packet['header']
    c.need(h['recipient'] == recipient and h['key_id'] == key_id(shared_key), 'OFFLINE_RECIPIENT_KEY')
    try:
        raw = transport_cipher()(_key(shared_key)).decrypt(bytes.fromhex(h['nonce']),
            unb64(packet['ciphertext'], MAX_PAYLOAD+16), c.canonical(h))
    except Exception as exc:
        raise ValueError('OFFLINE_DECRYPT') from exc
    payload = exact_load(raw, MAX_PAYLOAD); c.exact(payload, 'kind value')
    c.need(type(payload['kind']) is str and payload['kind'] in KINDS, 'OFFLINE_KIND')
    return payload


EVIDENCE_ATTACHMENT = 'covenant-evidence-attachment/0.1'
EVIDENCE_CONTEXT = b'covenant-delivery-evidence/0.1'


def evidence_context(scope):
    """Context the shop and the van both already know. It is not a secret."""
    c.key(scope)
    raw = EVIDENCE_CONTEXT + b'\0' + bytes.fromhex(scope)
    c.need(1 <= len(raw) <= 4096, 'OFFLINE_EVIDENCE_CONTEXT')
    return raw


def evidence_attachment(plaintext, *, key, scope, media_type='application/octet-stream'):
    """Wrap raw evidence bytes in the existing private-evidence envelope.

    A JPEG is not JSON. The offline packet still carries canonical JSON; the
    photo lives inside the envelope as ciphertext. Opening it needs the same
    adopted transport key and scope. The envelope does not prove the photo.
    """
    from covenant_language.private_evidence import seal as seal_evidence
    c.need(type(plaintext) is bytes and 1 <= len(plaintext) <= 1024 * 1024, 'OFFLINE_PAYLOAD_SIZE')
    c.need(type(media_type) is str and 1 <= len(media_type) <= 80 and
           all(32 <= ord(ch) <= 126 for ch in media_type), 'OFFLINE_MEDIA_TYPE')
    envelope = seal_evidence(plaintext, key=_key(key), context=evidence_context(scope))
    return {'profile': EVIDENCE_ATTACHMENT, 'media_type': media_type,
            'sha256': hashlib.sha256(plaintext).hexdigest(), 'envelope': envelope.decode('ascii')}


def open_attachment(value, *, key, scope):
    from covenant_language.private_evidence import open_envelope
    c.exact(value, 'profile media_type sha256 envelope')
    c.need(value['profile'] == EVIDENCE_ATTACHMENT, 'OFFLINE_EVIDENCE_ATTACHMENT')
    raw = open_envelope(value['envelope'].encode('ascii'), key=_key(key), context=evidence_context(scope))
    c.need(hashlib.sha256(raw).hexdigest() == value['sha256'], 'OFFLINE_EVIDENCE_HASH')
    return raw


def delivery_ack(packet, signing_key, *, at):
    ref = packet_id(packet); c.integer(at)
    c.need(c.public_key(signing_key) == packet['header']['recipient'], 'OFFLINE_ACK_RECIPIENT')
    c.need(packet['header']['created'] <= at < packet['header']['expires'], 'OFFLINE_ACK_WINDOW')
    body = {'version': ACK, 'packet': ref, 'scope': packet['header']['scope'],
            'recipient': c.public_key(signing_key), 'at': at, 'status': 'RETAINED'}
    return {'body': body, 'signature': c.sign(signing_key, ACK_LABEL, body)}


def verify_ack(ack, packet):
    ref = packet_id(packet); c.exact(ack, 'body signature'); body = ack['body']
    c.exact(body, 'version packet scope recipient at status'); c.integer(body['at'])
    h = packet['header']
    c.need(body['version'] == ACK and body['packet'] == ref and body['scope'] == h['scope']
           and body['recipient'] == h['recipient'] and body['status'] == 'RETAINED'
           and h['created'] <= body['at'] < h['expires'], 'OFFLINE_ACK_SCOPE')
    c.verify(h['recipient'], ACK_LABEL, body, ack['signature'])
    return {'delivery': 'RECIPIENT_RETAINED', 'payment_verified': False,
            'agreement_accepted': False, 'ledger_confirmed': False}
