"""AAP Connect: one small contract per adapter kind, so anyone can plug in.

A deal is a promise both sides sign. Proof shows it was kept. If it wasn't,
there is a fair way to fix it. An adapter brings one outside system to that
promise: a payment method (rail), a fair-fix forum (adjudicator), an identity
provider, a discovery source, a proof source (evidence), a carrier
(transport) or a registry export. Each kind has typed JSON inputs and
outputs, stable refusal codes with fix text, and one rule: an adapter's output
is evidence, never authority. A rail observation does not release escrow, a
decision does not finalise the ladder, a key binding does not grant a
permission, a directory entry adds no trust and a carrier does not confirm the
ledger. AAP's signed terms and the owner's adopted pins decide.

Adapters are owner-installed objects whose methods take one JSON object and
return one. invoke() validates both sides against the published schemas,
maps native refusals to the kind's codes and stamps the result as evidence.
Nothing here imports code by name, fetches, signs for an owner or installs.
"""
from copy import deepcopy
import base64
import binascii
import hashlib
import inspect
from pathlib import Path
import re

from .crypto import canonical, digest, integer, public_key, sign, verification_key, verify
from .tool_input import ToolInputError, validate_schema

CONTRACT = 'urn:aap:connect:0.1'
MANIFEST = 'urn:aap:connect-adapter-manifest:0.1'
MANIFEST_LABEL = 'AAP-CONNECT-MANIFEST-0.1'
DECISION = 'urn:aap:connect-decision:0.1'
DECISION_LABEL = 'AAP-CONNECT-DECISION-0.1'
MANIFEST_URN = 'urn:aap:connect-adapter-manifest:'
REFERENCE = 'docs/AAP_CONNECT.html#'
COMMAND = 'python -m covenant_chain.connect_cli adapter'
KINDS = ('payment_rail', 'adjudicator', 'identity_provider', 'discovery_source', 'evidence_source',
         'transport', 'registry_export')
MATURITY = ('experimental', 'beta', 'stable')
DECISIONS = ('GRAFT', 'TAKE_AND_IMPROVE', 'NATIVE')
RETRY = ('NO', 'YES', 'AFTER_FIX', 'OBSERVE_FIRST')
MAX_MANIFEST = 16384
MAX_PAYLOAD = 65536
_NAME = re.compile(r'[a-z0-9][a-z0-9-]{0,63}\Z')
_SEMVER = re.compile(r'(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\Z')
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_CODE = re.compile(r'[A-Z][A-Z0-9_]{1,79}\Z')

# Schema parts. Every object closes its fields; every string, list and number is bounded.
HASH = {'type': 'string', 'minLength': 64, 'maxLength': 64, 'pattern': '^[0-9a-f]{64}$'}
NULL_HASH = {**HASH, 'type': ['string', 'null']}
SIGNATURE = {'type': 'string', 'minLength': 128, 'maxLength': 128, 'pattern': '^[0-9a-f]{128}$'}
INT = {'type': 'integer', 'minimum': 0, 'maximum': 2**53 - 1}
NULL_INT = {**INT, 'type': ['integer', 'null']}
POSITIVE = {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1}
BPS = {'type': 'integer', 'minimum': 0, 'maximum': 10000}
BOOL = {'type': 'boolean'}
NAME = {'type': 'string', 'minLength': 1, 'maxLength': 64, 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
UNIT = {'type': 'string', 'minLength': 1, 'maxLength': 80, 'pattern': '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$'}
NULL_UNIT = {**UNIT, 'type': ['string', 'null']}
CODE = {'type': 'string', 'minLength': 2, 'maxLength': 80, 'pattern': '^[A-Z][A-Z0-9_]{1,79}$'}
OBJECT = {'type': 'object', 'maxProperties': 32}
B64 = {'type': 'string', 'minLength': 4, 'maxLength': 4 * ((MAX_PAYLOAD + 2) // 3),
       'pattern': '^[A-Za-z0-9+/]+={0,2}$'}
FRAME = {'type': 'string', 'minLength': 4, 'maxLength': 4 * ((MAX_PAYLOAD + 8192 + 2) // 3),
         'pattern': '^[A-Za-z0-9+/]+={0,2}$'}


def text(maximum, minimum=1):
    return {'type': 'string', 'minLength': minimum, 'maxLength': maximum, 'pattern': '^[ -~]*$'}


def obj(properties, required=None):
    return {'type': 'object', 'properties': properties,
            'required': sorted(properties if required is None else required),
            'additionalProperties': False, 'maxProperties': len(properties)}


def array(items, maximum, minimum=0):
    return {'type': 'array', 'items': items, 'minItems': minimum, 'maxItems': maximum}


def enum(*values):
    return {'enum': list(values)}


TRANSFER = obj({'action': {'const': 'TRANSFER'}, 'payer': HASH, 'recipient': HASH, 'unit': UNIT,
                'amount': POSITIVE, 'maximum_fee': INT})
QUOTE = obj({'amount': POSITIVE, 'fee': INT, 'total_debit': POSITIVE, 'unit': UNIT, 'within_fee_cap': BOOL,
             'sufficient_balance': {'type': ['boolean', 'null']}, 'funding': {'const': 'NOT_RESERVED'}})
OBSERVATION = obj({'status': enum('OBSERVED', 'NOT_OBSERVED', 'UNKNOWN'), 'effect': HASH,
                   'receipt_sha256': NULL_HASH, 'payer': NULL_HASH, 'recipient': NULL_HASH, 'unit': NULL_UNIT,
                   'amount': NULL_INT, 'fee': NULL_INT, 'assurance': text(160)})
OUTCOME = {'type': 'object', 'minProperties': 1, 'maxProperties': 16}
PARTY = obj({'role': NAME, 'key': HASH})
CASE = obj({'case': HASH, 'agreement': HASH, 'claim': HASH, 'stage': NAME, 'parties': array(PARTY, 16, 2),
            'outcomes': array(OUTCOME, 16, 1), 'evidence': array(HASH, 64), 'as_of': INT})
DECISION_SHAPE = obj({'version': {'const': DECISION}, 'case': HASH, 'agreement': HASH, 'stage': NAME,
                      'outcome_index': {'type': 'integer', 'minimum': 0, 'maximum': 15}, 'outcome': OUTCOME,
                      'decider': HASH, 'reasons_sha256': HASH, 'record_sha256': NULL_HASH,
                      'issued_at': INT, 'signature': SIGNATURE})
CREDENTIAL = obj({'format': NAME, 'subject': text(512), 'document': text(65536),
                  'bindings': array(OBJECT, 16), 'now': INT})
BINDING = obj({'format': NAME, 'subject': text(512), 'status': enum('BOUND', 'NOT_BOUND', 'DEACTIVATED', 'EXPIRED'),
               'bound_keys': array(obj({'key': HASH, 'basis': text(128)}), 16), 'listed_keys': array(HASH, 32),
               'document_sha256': HASH})
ITEM = {'type': 'object', 'minProperties': 1, 'maxProperties': 16}
FOUND = obj({'descriptors': array(obj({'id': HASH, 'key': HASH, 'sequence': INT,
                                       'status': enum('VALID', 'EXPIRED', 'NOT_YET_VALID'),
                                       'task_classes': array(text(80), 16)}), 64),
             'excluded': array(obj({'reason': CODE}), 64), 'pointers': INT,
             'conflicts': array(obj({'key': HASH, 'kind': enum('EQUIVOCATION', 'FORK')}), 16),
             'sources_add_trust': {'const': False}})
MIME = {'type': 'string', 'minLength': 3, 'maxLength': 146,
        'pattern': '^[A-Za-z0-9][A-Za-z0-9.+-]{0,64}/[A-Za-z0-9][A-Za-z0-9.+-]{0,80}$'}
OBSERVED_BLOB = obj({'blob_base64': B64, 'mime': MIME, 'provenance': OBJECT, 'claim': {'type': 'object', 'maxProperties': 8}})
READING = obj({'supports': BOOL, 'confidence_bps': BPS,
               'reason': enum('OK', 'MIME', 'PROVENANCE', 'CLAIM_SHAPE', 'BLOB', 'CLAIM'),
               'blob_sha256': HASH, 'notes': array(text(128), 8)})
PAYLOAD = obj({'payload_base64': B64})
FRAMES = obj({'frames': array(FRAME, 1024, 1)})
ENCODED = obj({'frames': array(FRAME, 1024, 1), 'payload_sha256': HASH})
DECODED = obj({'payload_base64': B64, 'payload_sha256': HASH})
SIGNED = obj({'body': OBJECT, 'signature': SIGNATURE})
EXPORT_IN = obj({'descriptor': SIGNED, 'options': {'type': 'object', 'maxProperties': 8}})
RECORDS = array(text(65536), 8, 1)
EXPORTED = obj({'format': NAME, 'records': RECORDS, 'media_type': text(128), 'descriptor': HASH})
PARSE_IN = obj({'records': RECORDS, 'now': INT})
PARSED = obj({'descriptors': array(HASH, 16), 'excluded': array(obj({'reason': CODE}), 16),
              'sources_add_trust': {'const': False}})

_GENERAL = {
    'CONNECT_KIND': ('That adapter kind is not one of the seven AAP Connect kinds.',
                     'Use a kind listed by describe(): ' + ', '.join(KINDS) + '.', 'NO'),
    'CONNECT_METHOD': ('That kind has no method of this name.',
                       'Call one of the methods listed by contract(kind).', 'NO'),
    'CONNECT_ADAPTER': ('The adapter object does not implement every method of its kind.',
                        'Add the missing method with the exact JSON input and output from contract(kind).', 'AFTER_FIX'),
    'CONNECT_SIZE': ('The input is larger than this kind allows.',
                     'Send a smaller input; the byte limit is in contract(kind).', 'AFTER_FIX'),
    'CONNECT_OUTPUT': ('The adapter returned output that breaks its contract, so the output was discarded.',
                       'Fix the adapter so every field matches contract(kind), then rerun the conformance suite.', 'NO'),
    'CONNECT_MANIFEST': ('The adapter manifest is malformed.',
                         'Build it with connect.manifest() and keep every field exactly as returned.', 'AFTER_FIX'),
    'CONNECT_MANIFEST_SIGNATURE': ('The manifest is not signed by the publisher key it names.',
                                   'Have the publisher sign the unchanged manifest body; never re-pin to force a pass.', 'NO'),
    'CONNECT_MANIFEST_ID': ('The manifest is not the one the owner pinned.',
                            'Obtain the exact manifest whose id the owner adopted, or adopt the new id explicitly.', 'NO'),
    'CONNECT_LEVEL': ('The manifest names a level that is not where this kind plugs in.',
                      'Use the level listed for the kind by describe().', 'AFTER_FIX'),
    'CONNECT_REPORT': ('The conformance report is malformed or is not the one the manifest names.',
                       'Supply the exact signed report the manifest names.', 'AFTER_FIX'),
    'CONNECT_REPORT_SIGNATURE': ('The conformance report is not signed by the tester it names.',
                                 'Obtain the unmodified report; never re-sign another tester\'s report.', 'NO'),
    'CONNECT_SUITE': ('The report ran a different conformance suite than this host knows for that kind.',
                      'Rerun the current suite for the kind and publish a new manifest.', 'AFTER_FIX'),
    'CONNECT_NOT_ADOPTED': ('The owner has not adopted that manifest id.',
                            'Adopt the exact manifest id first; finding an adapter does not adopt it.', 'AFTER_FIX'),
    'CONNECT_RETIRED': ('The owner retired that manifest.', 'Adopt a current release explicitly.', 'NO'),
    'CONNECT_RELEASE_CONFLICT': ('The publisher signed two different manifests for one release.',
                                 'Keep both as evidence and ask the publisher for a new release number.', 'NO'),
    'CONNECT_PREVIOUS': ('The manifest names a previous release this owner has not adopted, or another publisher\'s.',
                         'Adopt the previous release first, or adopt this one without previous.', 'AFTER_FIX'),
    'CONNECT_IMPLEMENTATION': ('The installed adapter code is not the code the owner pinned.',
                               'Install the exact release whose implementation hash the manifest names.', 'NO'),
    'CONNECT_REGISTRY_STATE': ('The registry file is missing, unsafe or changed outside this module.',
                               'Restore the registry file from a backup made by this module; keep it owner-only.', 'NO'),
    'CONNECT_CERT_FORMAT': ('The certificate, its status record or the credentials bundle is malformed.',
                            'Present the exact signed certificate and optional status as issued.', 'AFTER_FIX'),
    'CONNECT_CERT_SIGNATURE': ('A certificate or status signature does not verify.',
                               'Obtain an unmodified certificate from its issuer; never edit a signed record.', 'NO'),
    'CONNECT_CERT_ISSUER': ('The certificate issuer is not one this verifier trusts for that assessment.',
                            'Present a certificate from a pinned issuer, or a self-test where self-tests are accepted.', 'NO'),
    'CONNECT_CERT_SUBJECT': ('The certificate is for another key.', 'Present the certificate issued to the calling key.', 'NO'),
    'CONNECT_CERT_SCOPE': ('The certificate covers another kind, contract or assessment than required.',
                           'Obtain a certificate for the required kind and assessment.', 'AFTER_FIX'),
    'CONNECT_CERT_NOT_YET_VALID': ('The certificate is not valid yet.', 'Retry at or after its issued_at time.', 'YES'),
    'CONNECT_CERT_EXPIRED': ('The certificate has expired.', 'Renew it: rerun the current suite and ask the issuer again.', 'AFTER_FIX'),
    'CONNECT_CERT_STATUS_UNKNOWN': ('No fresh signed status from the issuer was presented, so current status is unknown.',
                                    'Staple a fresh ACTIVE status record from the issuer. Unknown is never treated as active.', 'AFTER_FIX'),
    'CONNECT_CERT_REVOKED': ('The issuer suspended or withdrew this certificate.', 'Resolve the issuer\'s finding and obtain a new certificate.', 'NO'),
    'CONNECT_CERT_ASSESSMENT': ('The evidence does not support this assessment: no passing report, or the issuer\'s rerun differs.',
                                'Rerun the exact release; issue only when the results hash matches.', 'AFTER_FIX'),
    'CONNECT_CERT_REQUEST': ('The certification request is malformed, unsigned or names other records.',
                             'Have the subject sign a request naming the exact manifest and report.', 'AFTER_FIX'),
    'CONNECT_SCAFFOLD_DIRECTORY': ('The project directory already exists, or is not a generated adapter project.',
                                   'Choose a new directory for adapter new, or point adapter check at a generated project.',
                                   'AFTER_FIX'),
    'CONNECT_KEY_FILE': ('The key file is missing, readable by others, or not a 64-character hex Ed25519 seed.',
                         'Use an owner-only (chmod 600) regular file holding the seed; never pass a key on the command line.',
                         'AFTER_FIX'),
    'CONNECT_INPUT_FILE': ('The input file is missing, too large, not strict JSON or not an AAP Connect record.',
                           'Pass the exact JSON file a command produced.', 'AFTER_FIX'),
    'CONNECT_CHECK_OUTPUT': ('The project\'s conformance run did not print its JSON result.',
                             'Run python conformance.py inside the project and fix the error it shows.', 'AFTER_FIX'),
    'CONNECT_CHECK_TIMEOUT': ('The project\'s conformance run did not finish in time and was stopped.',
                              'Make the adapter answer within the suite\'s time, for example by not waiting on a network, then rerun.',
                              'AFTER_FIX'),
}

KIND_SPECS = {
    'payment_rail': {
        'level': 'L2', 'job': 'Pay and get paid', 'prefix': 'CONNECT_RAIL',
        'purpose': 'Move value on a payment method the owner installed, and report what that method observed.',
        'rule': ('A rail observation is evidence that the rail reported a movement. AAP terms and the agreed '
                 'release or fair-fix step decide whether escrow is released; an observation never releases it.'),
        'methods': {'quote': (obj({'request': TRANSFER}), QUOTE, False),
                    'execute': (obj({'effect': HASH, 'request': TRANSFER}), OBSERVATION, True),
                    'observe': (obj({'effect': HASH}), OBSERVATION, False)},
        'max_bytes': 4096, 'input_code': 'CONNECT_RAIL_REQUEST', 'unknown_code': 'CONNECT_RAIL_OUTCOME_UNKNOWN',
        'codes': {
            'CONNECT_RAIL_REQUEST': ('The payment request is malformed.', 'Send action TRANSFER with payer, recipient, unit, a positive integer amount and maximum_fee.', 'AFTER_FIX'),
            'CONNECT_RAIL_UNIT': ('This rail does not move that unit; nothing converts units automatically.', 'Use a unit the rail lists, or agree a different rail.', 'NO'),
            'CONNECT_RAIL_FEE_CAP': ('The rail fee is above the maximum_fee you allowed.', 'Raise maximum_fee only if you accept the quoted fee, or choose another rail.', 'AFTER_FIX'),
            'CONNECT_RAIL_FUNDS': ('The payer does not hold enough on this rail.', 'Fund the payer on this rail, then retry with the same effect id.', 'AFTER_FIX'),
            'CONNECT_RAIL_RETRY_CHANGED': ('This effect id was already used for a different request.', 'Retry with the exact original request, or use a new effect id for a new payment.', 'NO'),
            'CONNECT_RAIL_OUTCOME_UNKNOWN': ('The rail call ended without a clear outcome; the payment may or may not have moved.', 'Call observe with the same effect id before any retry. Unknown is never success.', 'OBSERVE_FIRST'),
            'CONNECT_RAIL_REFUSED': ('The rail refused the request for its own reason (see native).', 'Read the native code from the rail and fix that input.', 'AFTER_FIX'),
        },
        'native': {'PAYMENT_UNIT_NO_AUTOMATIC_FX': 'CONNECT_RAIL_UNIT', 'TOKEN_REDEMPTION_UNIT': 'CONNECT_RAIL_UNIT',
                   'UNIT': 'CONNECT_RAIL_UNIT', 'STABLECOIN_REQUIRED': 'CONNECT_RAIL_UNIT',
                   'NATIVE_TOKEN_SETTLEMENT_REFUSED': 'CONNECT_RAIL_UNIT', 'PAYMENT_FEE_CAP': 'CONNECT_RAIL_FEE_CAP',
                   'PAYMENT_FUNDS': 'CONNECT_RAIL_FUNDS', 'PAYMENT_RETRY_CHANGED': 'CONNECT_RAIL_RETRY_CHANGED',
                   'SETTLEMENT_CONFLICT': 'CONNECT_RAIL_RETRY_CHANGED', 'PAYMENT_ACTION': 'CONNECT_RAIL_REQUEST',
                   'ADAPTER_INPUT_SIZE': 'CONNECT_RAIL_REQUEST', 'KEY': 'CONNECT_RAIL_REQUEST',
                   'FIELDS': 'CONNECT_RAIL_REQUEST', 'INTEGER': 'CONNECT_RAIL_REQUEST', 'QUANTITY': 'CONNECT_RAIL_REQUEST',
                   'PAYMENT_PARTIES': 'CONNECT_RAIL_REQUEST'},
    },
    'adjudicator': {
        'level': 'L3', 'job': 'Fix a problem', 'prefix': 'CONNECT_ADJUDICATOR',
        'purpose': 'Decide a dispute case from the outcomes both parties agreed, and sign the decision.',
        'rule': ('A decision is evidence for the named stage of the agreed fair-fix ladder. The stage deciders '
                 'still vote and the principal finalises; a decision never moves escrow by itself.'),
        'methods': {'decide': (CASE, DECISION_SHAPE, False)},
        'max_bytes': 131072, 'input_code': 'CONNECT_ADJUDICATOR_CASE', 'unknown_code': 'CONNECT_ADJUDICATOR_REFUSED',
        'codes': {
            'CONNECT_ADJUDICATOR_CASE': ('The case is malformed.', 'Send case, agreement, claim, stage, at least two parties, the agreed outcomes, evidence ids and as_of.', 'AFTER_FIX'),
            'CONNECT_ADJUDICATOR_DECLINED': ('The adjudicator declined to decide on this evidence.', 'Add the evidence it asks for, or move to the next agreed stage.', 'AFTER_FIX'),
            'CONNECT_ADJUDICATOR_CONFLICT': ('The deciding key is one of the parties.', 'Use an adjudicator that is not a party to the case.', 'NO'),
            'CONNECT_ADJUDICATOR_SIGNATURE': ('The decision signature does not verify, or the decider is not a pinned key.', 'Obtain a fresh decision signed by a key the owner pinned; never edit a signed decision.', 'NO'),
            'CONNECT_ADJUDICATOR_OUTCOME': ('The decision is not one of the outcomes both parties agreed.', 'Ask the adjudicator to choose among the agreed outcomes only.', 'NO'),
            'CONNECT_ADJUDICATOR_REFUSED': ('The adjudicator refused the case for its own reason (see native).', 'Read the native code and fix that input.', 'AFTER_FIX'),
        },
        'native': {'AWARD_TRIBUNAL': 'CONNECT_ADJUDICATOR_CONFLICT', 'AWARD_PARTIES': 'CONNECT_ADJUDICATOR_CASE',
                   'SIGNATURE': 'CONNECT_ADJUDICATOR_SIGNATURE', 'AWARD_SIGNER': 'CONNECT_ADJUDICATOR_SIGNATURE',
                   'AWARD_SIGNATURES': 'CONNECT_ADJUDICATOR_SIGNATURE'},
    },
    'identity_provider': {
        'level': 'L0', 'job': 'Find and be found', 'prefix': 'CONNECT_IDENTITY',
        'purpose': 'Check a credential and report which AAP keys it binds, and on what basis.',
        'rule': ('A key is bound only by a signature that key made. A listed key is not a bound key, domain '
                 'control is not checked, and a binding never grants a permission to act or pay.'),
        'methods': {'verify': (CREDENTIAL, BINDING, False)},
        'max_bytes': 131072, 'input_code': 'CONNECT_IDENTITY_CREDENTIAL', 'unknown_code': 'CONNECT_IDENTITY_REFUSED',
        'codes': {
            'CONNECT_IDENTITY_CREDENTIAL': ('The credential is malformed.', 'Send format, subject, the document text, any bindings and now.', 'AFTER_FIX'),
            'CONNECT_IDENTITY_FORMAT': ('This provider does not read that credential format.', 'Use a format the provider lists, or install a provider for it.', 'NO'),
            'CONNECT_IDENTITY_DOCUMENT': ('The credential document cannot be parsed.', 'Send the exact document bytes as received.', 'AFTER_FIX'),
            'CONNECT_IDENTITY_SIGNATURE': ('A proof or binding signature in the credential does not verify.', 'Obtain an unmodified credential; never re-sign it for the holder.', 'NO'),
            'CONNECT_IDENTITY_SUBJECT': ('The credential is about a different subject.', 'Send the credential issued for this subject.', 'NO'),
            'CONNECT_IDENTITY_REFUSED': ('The provider refused the credential for its own reason (see native).', 'Read the native code and fix that input.', 'AFTER_FIX'),
        },
        'native': {'DID_SYNTAX': 'CONNECT_IDENTITY_CREDENTIAL', 'DID_METHOD': 'CONNECT_IDENTITY_FORMAT',
                   'DID_DOCUMENT': 'CONNECT_IDENTITY_DOCUMENT', 'DID_CONTEXT': 'CONNECT_IDENTITY_DOCUMENT',
                   'DID_METHODS': 'CONNECT_IDENTITY_DOCUMENT', 'DID_REFERENCE': 'CONNECT_IDENTITY_DOCUMENT',
                   'DID_SERVICES': 'CONNECT_IDENTITY_DOCUMENT', 'DID_DOCUMENT_ID': 'CONNECT_IDENTITY_SUBJECT',
                   'DID_PROOF_REQUIRED': 'CONNECT_IDENTITY_SIGNATURE', 'DID_FINGERPRINT': 'CONNECT_IDENTITY_SIGNATURE',
                   'DID_PROOF_METHOD': 'CONNECT_IDENTITY_SIGNATURE', 'SIGNATURE': 'CONNECT_IDENTITY_SIGNATURE',
                   'INTEROP_PROOF': 'CONNECT_IDENTITY_SIGNATURE', 'INTEROP_PROOF_SIGNATURE': 'CONNECT_IDENTITY_SIGNATURE',
                   'INTEROP_PROOF_CONTEXT': 'CONNECT_IDENTITY_SIGNATURE', 'DID_BINDING_FIELDS': 'CONNECT_IDENTITY_CREDENTIAL'},
    },
    'discovery_source': {
        'level': 'L4', 'job': 'Find and be found', 'prefix': 'CONNECT_DISCOVERY',
        'purpose': 'Read agent descriptors from one carrier and report which signatures verify.',
        'rule': ('Only a descriptor signed by the key it names counts. A source adds availability, never trust; '
                 'an unsigned or forged descriptor is excluded with its reason, never merged.'),
        'methods': {'read': (obj({'item': ITEM, 'now': INT}), FOUND, False)},
        'max_bytes': 262144, 'input_code': 'CONNECT_DISCOVERY_ITEM', 'unknown_code': 'CONNECT_DISCOVERY_REFUSED',
        'codes': {
            'CONNECT_DISCOVERY_ITEM': ('The source item is malformed for this carrier.', 'Send the item fields this source lists, with the exact bytes received.', 'AFTER_FIX'),
            'CONNECT_DISCOVERY_REFUSED': ('The source refused the item for its own reason (see native).', 'Read the native code and fix that input.', 'AFTER_FIX'),
        },
        'native': {'DISCOVERY_SOURCE': 'CONNECT_DISCOVERY_ITEM', 'DISCOVERY_SIZE': 'CONNECT_DISCOVERY_ITEM',
                   'DISCOVERY_JSON': 'CONNECT_DISCOVERY_ITEM', 'DISCOVERY_DOCUMENT': 'CONNECT_DISCOVERY_ITEM'},
    },
    'evidence_source': {
        'level': 'L2', 'job': 'Deliver and prove', 'prefix': 'CONNECT_EVIDENCE',
        'purpose': 'Read one piece of evidence and its provenance against the typed claim the parties agreed.',
        'rule': ('A reading says whether this evidence supports the claim, and how strongly. It never decides '
                 'the deal: the agreed evidence policy, quorum and ladder do.'),
        'methods': {'read': (OBSERVED_BLOB, READING, False)},
        'max_bytes': 4 * ((MAX_PAYLOAD + 2) // 3) + 16384, 'input_code': 'CONNECT_EVIDENCE_INPUT',
        'unknown_code': 'CONNECT_EVIDENCE_REFUSED',
        'codes': {
            'CONNECT_EVIDENCE_INPUT': ('The evidence input is malformed.', 'Send blob_base64, mime, provenance and the agreed claim.', 'AFTER_FIX'),
            'CONNECT_EVIDENCE_REFUSED': ('The source refused the evidence for its own reason (see native).', 'Read the native code and fix that input.', 'AFTER_FIX'),
        },
        'native': {'EVIDENCE_FIELDS': 'CONNECT_EVIDENCE_INPUT'},
    },
    'transport': {
        'level': 'L0', 'job': 'Deliver and prove', 'prefix': 'CONNECT_TRANSPORT',
        'purpose': 'Carry exact signed bytes between peers as frames, and rebuild them on the other side.',
        'rule': ('Bytes out must equal bytes in or the carrier refuses. Carrier success never confirms the '
                 'ledger, payment or delivery; the signatures inside the bytes still decide.'),
        'methods': {'encode': (PAYLOAD, ENCODED, False), 'decode': (FRAMES, DECODED, False)},
        'max_bytes': 4 * ((MAX_PAYLOAD + 8192 + 2) // 3) * 4, 'input_code': 'CONNECT_TRANSPORT_INPUT',
        'unknown_code': 'CONNECT_TRANSPORT_REFUSED',
        'codes': {
            'CONNECT_TRANSPORT_INPUT': ('The payload is empty, too large for this carrier, or not base64.', 'Send 1 byte up to the carrier limit as canonical base64.', 'AFTER_FIX'),
            'CONNECT_TRANSPORT_FRAME': ('A frame is malformed or damaged.', 'Ask the sender to resend the frames; never patch a frame.', 'AFTER_FIX'),
            'CONNECT_TRANSPORT_INCOMPLETE': ('Some frames are missing.', 'Collect the missing frames, then decode again.', 'AFTER_FIX'),
            'CONNECT_TRANSPORT_MISMATCH': ('The rebuilt bytes do not match their digest, or frames from different payloads were mixed.', 'Decode each payload from its own frames; obtain fresh frames.', 'AFTER_FIX'),
            'CONNECT_TRANSPORT_REFUSED': ('The carrier refused for its own reason (see native).', 'Read the native code and fix that input.', 'AFTER_FIX'),
        },
        'native': {'OFFLINE_FRAME_INPUT': 'CONNECT_TRANSPORT_INPUT', 'OFFLINE_FRAME_SIZE': 'CONNECT_TRANSPORT_FRAME',
                   'OFFLINE_FRAME_HEADER': 'CONNECT_TRANSPORT_FRAME', 'OFFLINE_FRAME_LENGTH': 'CONNECT_TRANSPORT_FRAME',
                   'OFFLINE_FRAME_CONFLICT': 'CONNECT_TRANSPORT_MISMATCH', 'OFFLINE_REASSEMBLY_HASH': 'CONNECT_TRANSPORT_MISMATCH',
                   'OFFLINE_REASSEMBLY_QUOTA': 'CONNECT_TRANSPORT_MISMATCH', 'OFFLINE_FRAME_COUNT': 'CONNECT_TRANSPORT_INPUT'},
    },
    'registry_export': {
        'level': 'L4', 'job': 'Find and be found', 'prefix': 'CONNECT_REGISTRY',
        'purpose': 'Write a signed AAP descriptor into a registry format, and read such records back.',
        'rule': ('An export publishes only a descriptor whose signature verifies. Records are carriers: reading '
                 'them back adds availability, never trust.'),
        'methods': {'export': (EXPORT_IN, EXPORTED, False), 'parse': (PARSE_IN, PARSED, False)},
        'max_bytes': 4 * 65536 * 2, 'input_code': 'CONNECT_REGISTRY_INPUT', 'unknown_code': 'CONNECT_REGISTRY_REFUSED',
        'codes': {
            'CONNECT_REGISTRY_INPUT': ('The export or parse input is malformed.', 'Send the signed descriptor envelope unchanged, or the exact records received.', 'AFTER_FIX'),
            'CONNECT_REGISTRY_SIGNATURE': ('The descriptor signature does not verify, so it was not exported.', 'Have the agent sign the unchanged descriptor with the key it names.', 'NO'),
            'CONNECT_REGISTRY_RECORD': ('A registry record is malformed.', 'Send the exact record text as published.', 'AFTER_FIX'),
            'CONNECT_REGISTRY_REFUSED': ('The exporter refused for its own reason (see native).', 'Read the native code and fix that input.', 'AFTER_FIX'),
        },
        'native': {'DISCOVERY_SIGNATURE': 'CONNECT_REGISTRY_SIGNATURE', 'SIGNATURE': 'CONNECT_REGISTRY_SIGNATURE',
                   'DISCOVERY_FIELDS': 'CONNECT_REGISTRY_INPUT', 'DISCOVERY_PROFILE': 'CONNECT_REGISTRY_INPUT',
                   'DISCOVERY_ENVELOPE': 'CONNECT_REGISTRY_INPUT', 'AGENTFACTS': 'CONNECT_REGISTRY_RECORD',
                   'AGENTFACTS_AAP': 'CONNECT_REGISTRY_RECORD', 'OASF_RECORD': 'CONNECT_REGISTRY_RECORD'},
    },
}
LEVELS = {kind: KIND_SPECS[kind]['level'] for kind in KINDS}
CODES = dict(_GENERAL)
for _kind in KINDS:
    CODES.update(KIND_SPECS[_kind]['codes'])


class ConnectError(ValueError):
    """A contract refusal. str(error) is the stable code; refusal() teaches the fix."""

    def __init__(self, code, *, native=None, issues=None):
        super().__init__(code)
        self.code = code
        self.native = native
        self.issues = deepcopy(issues or [])[:16]

    def refusal(self):
        return refusal(self.code, native=self.native, issues=self.issues)


def refusal(code, *, native=None, issues=None):
    """What happened, what to do next, whether retrying helps and where the reference entry is."""
    message, fix, retry = CODES.get(code, ('The adapter refused.', 'Read the native code and fix that input.', 'AFTER_FIX'))
    return {'code': code, 'message': message, 'fix': fix, 'retry': retry, 'reference': REFERENCE + code,
            'native': native, 'issues': deepcopy(issues or [])[:16], 'execution_authorized': False}


def check(ok, code):
    if not ok:
        raise ConnectError(code)


def _kind(kind):
    check(type(kind) is str and kind in KIND_SPECS, 'CONNECT_KIND')
    return KIND_SPECS[kind]


def contract(kind):
    """The exact contract for one kind: methods with JSON Schemas, codes with fix text, and the rule."""
    spec = _kind(kind)
    return {'contract': CONTRACT, 'kind': kind, 'level': spec['level'], 'job': spec['job'],
            'purpose': spec['purpose'], 'rule': spec['rule'],
            'methods': {name: {'input': deepcopy(shape[0]), 'output': deepcopy(shape[1]),
                               'effect': shape[2]} for name, shape in spec['methods'].items()},
            'calling': 'adapter.<method>(one JSON object) returns one JSON object',
            'max_input_bytes': spec['max_bytes'],
            'codes': {code: refusal(code) for code in sorted(spec['codes'])},
            'general_codes': sorted(_GENERAL), 'authority': 'EVIDENCE_ONLY', 'execution_authorized': False}


def describe():
    return {'contract': CONTRACT, 'model': 'A deal is a promise both sides sign. Proof shows it was kept. '
                                          'If it wasn\'t, there is a fair way to fix it.',
            'kinds': [{'kind': kind, 'level': KIND_SPECS[kind]['level'], 'job': KIND_SPECS[kind]['job'],
                       'purpose': KIND_SPECS[kind]['purpose'], 'methods': sorted(KIND_SPECS[kind]['methods'])}
                      for kind in KINDS],
            'rule': 'An adapter\'s output is evidence, never authority.',
            'formats': {'manifest': MANIFEST, 'decision': DECISION},
            'guide': 'docs/AAP_CONNECT.html', 'start': COMMAND + ' new --kind <kind> <name>',
            'start_when_installed': 'aap adapter new --kind <kind> <name>',
            'network_accessed': False, 'installed': False, 'execution_authorized': False}


def _native(spec, adapter, error):
    """The adapter's own code when it is one; free text is replaced by the error class so nothing leaks."""
    code = getattr(error, 'code', None)
    code = code if type(code) is str else (str(error).splitlines()[0][:80] if str(error) else '')
    head = code.split(':', 1)[0].strip()
    if _CODE.fullmatch(head) is None:
        return type(error).__name__, None
    own = getattr(adapter, 'connect_native', None)
    mapped = (own.get(head) if type(own) is dict else None) or spec['native'].get(head)
    return head, mapped if mapped in spec['codes'] else None


def synthetic_key(label):
    """A deterministic, clearly synthetic test key for fixtures and conformance runs. Never a real key."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    check(type(label) is str and 0 < len(label) <= 200, 'CONNECT_SIZE')
    return Ed25519PrivateKey.from_private_bytes(
        hashlib.sha256(b'AAP-CONNECT-SYNTHETIC-TEST-KEY\0' + label.encode('ascii')).digest())


def _validate(value, schema, code):
    try:
        validate_schema(value, schema)
    except ToolInputError as error:
        raise ConnectError(code, issues=error.issues) from None


def b64(raw):
    return base64.b64encode(raw).decode('ascii')


def unb64(text_value, code, maximum=MAX_PAYLOAD):
    try:
        raw = base64.b64decode(text_value, validate=True)
    except (binascii.Error, ValueError, TypeError):
        raise ConnectError(code) from None
    check(0 < len(raw) <= maximum and b64(raw) == text_value, code)
    return raw


def invoke(kind, adapter, method, payload, *, pins=None):
    """Call one adapter method under its contract. The result is evidence, never authority."""
    spec = _kind(kind)
    check(type(method) is str and method in spec['methods'], 'CONNECT_METHOD')
    shape_in, shape_out, effect = spec['methods'][method]
    try:
        size = len(canonical(payload))
    except ValueError:
        raise ConnectError(spec['input_code']) from None
    check(size <= spec['max_bytes'], 'CONNECT_SIZE')
    _validate(payload, shape_in, spec['input_code'])
    _semantics_in(kind, method, payload)
    function = getattr(adapter, method, None)
    check(callable(function), 'CONNECT_ADAPTER')
    try:
        output = function(deepcopy(payload))
    except ConnectError as error:
        check(error.code in spec['codes'], 'CONNECT_OUTPUT')
        raise
    except (ValueError, TypeError, KeyError) as error:
        native, mapped = _native(spec, adapter, error)
        raise ConnectError(mapped or spec['prefix'] + '_REFUSED', native=native) from None
    except Exception as error:  # an effect may have happened: never report it as a clean refusal
        raise ConnectError(spec['unknown_code'] if effect else spec['prefix'] + '_REFUSED',
                           native=type(error).__name__) from None
    try:
        canonical(output)
        validate_schema(output, shape_out)
        _semantics_out(kind, method, payload, output, pins or {})
    except ConnectError:
        raise
    except (ValueError, TypeError, KeyError):
        raise ConnectError('CONNECT_OUTPUT') from None
    return {'contract': CONTRACT, 'kind': kind, 'method': method, 'output': deepcopy(output),
            'authority': 'EVIDENCE_ONLY', 'decides': 'AAP_SIGNED_TERMS_AND_OWNER_PINS', 'rule': spec['rule'],
            'execution_authorized': False}


def _semantics_in(kind, method, payload):
    if kind == 'adjudicator':
        keys = [row['key'] for row in payload['parties']]
        check(len(set(keys)) == len(keys) and len({row['role'] for row in payload['parties']}) == len(keys),
              'CONNECT_ADJUDICATOR_CASE')
        check(len({canonical(row) for row in payload['outcomes']}) == len(payload['outcomes']) and
              all(len(canonical(row)) <= 4096 for row in payload['outcomes']), 'CONNECT_ADJUDICATOR_CASE')
    elif kind == 'evidence_source':
        unb64(payload['blob_base64'], 'CONNECT_EVIDENCE_INPUT')
    elif kind == 'transport' and method == 'encode':
        unb64(payload['payload_base64'], 'CONNECT_TRANSPORT_INPUT')
    elif kind == 'transport':
        for frame in payload['frames']:
            unb64(frame, 'CONNECT_TRANSPORT_FRAME', MAX_PAYLOAD + 8192)
    elif kind == 'payment_rail' and method != 'observe':
        request = payload['request']
        check(request['payer'] != request['recipient'], 'CONNECT_RAIL_REQUEST')


def _semantics_out(kind, method, payload, output, pins):
    if kind == 'payment_rail':
        if method == 'quote':
            request = payload['request']
            check(output['amount'] == request['amount'] and output['unit'] == request['unit'] and
                 output['total_debit'] == output['amount'] + output['fee'] and
                 output['within_fee_cap'] == (output['fee'] <= request['maximum_fee']), 'CONNECT_OUTPUT')
            return
        observed = output['status'] == 'OBSERVED'
        check(output['effect'] == payload['effect'] and all(
            (output[name] is not None) == observed
            for name in ('receipt_sha256', 'payer', 'recipient', 'unit', 'amount', 'fee')), 'CONNECT_OUTPUT')
        if method == 'execute' and observed:
            request = payload['request']
            check(all(output[name] == request[name] for name in ('payer', 'recipient', 'unit', 'amount')) and
                 output['fee'] <= request['maximum_fee'], 'CONNECT_OUTPUT')
    elif kind == 'adjudicator':
        check(all(output[name] == payload[name] for name in ('case', 'agreement', 'stage')), 'CONNECT_OUTPUT')
        check(output['outcome_index'] < len(payload['outcomes']) and
              canonical(payload['outcomes'][output['outcome_index']]) == canonical(output['outcome']),
              'CONNECT_ADJUDICATOR_OUTCOME')
        check(output['decider'] not in {row['key'] for row in payload['parties']}, 'CONNECT_ADJUDICATOR_CONFLICT')
        verify_decision(output, pins.get('output_keys'))
    elif kind == 'identity_provider':
        bound = [row['key'] for row in output['bound_keys']]
        check(output['format'] == payload['format'] and output['subject'] == payload['subject'] and
             len(set(bound)) == len(bound) and not set(bound) & set(output['listed_keys']) and
             (output['status'] == 'BOUND') == bool(bound), 'CONNECT_OUTPUT')
    elif kind == 'evidence_source':
        raw = unb64(payload['blob_base64'], 'CONNECT_EVIDENCE_INPUT')
        check(output['blob_sha256'] == hashlib.sha256(raw).hexdigest() and
             output['supports'] == (output['reason'] == 'OK') and
             (output['supports'] or output['confidence_bps'] == 0), 'CONNECT_OUTPUT')
    elif kind == 'transport':
        if method == 'encode':
            check(output['payload_sha256'] == hashlib.sha256(unb64(payload['payload_base64'], 'CONNECT_OUTPUT')).hexdigest(),
                 'CONNECT_OUTPUT')
            for frame in output['frames']:
                unb64(frame, 'CONNECT_OUTPUT', MAX_PAYLOAD + 8192)
        else:
            raw = unb64(output['payload_base64'], 'CONNECT_OUTPUT')
            check(output['payload_sha256'] == hashlib.sha256(raw).hexdigest(), 'CONNECT_OUTPUT')
    elif kind == 'discovery_source':
        check(len({row['id'] for row in output['descriptors']}) == len(output['descriptors']), 'CONNECT_OUTPUT')
    elif kind == 'registry_export' and method == 'export':
        from .signed_discovery import descriptor_id
        check(output['descriptor'] == descriptor_id(payload['descriptor']['body']), 'CONNECT_OUTPUT')


# Adjudicator decisions --------------------------------------------------------

def decision_body(case, outcome_index, decider, reasons_sha256, record_sha256, issued_at):
    """The unsigned contract decision for one case; the decider signs it."""
    _validate(case, CASE, 'CONNECT_ADJUDICATOR_CASE')
    check(type(outcome_index) is int and 0 <= outcome_index < len(case['outcomes']), 'CONNECT_ADJUDICATOR_OUTCOME')
    body = {'version': DECISION, 'case': case['case'], 'agreement': case['agreement'], 'stage': case['stage'],
            'outcome_index': outcome_index, 'outcome': deepcopy(case['outcomes'][outcome_index]),
            'decider': decider, 'reasons_sha256': reasons_sha256, 'record_sha256': record_sha256,
            'issued_at': issued_at}
    _validate({**body, 'signature': '0' * 128}, DECISION_SHAPE, 'CONNECT_ADJUDICATOR_CASE')
    return body


def sign_decision(body, private_key):
    """The adjudicator's own act. Never exposed as an agent tool."""
    check(public_key(private_key) == body['decider'], 'CONNECT_ADJUDICATOR_SIGNATURE')
    return {**deepcopy(body), 'signature': sign(private_key, DECISION_LABEL, body)}


def verify_decision(decision, output_keys=None):
    _validate(decision, DECISION_SHAPE, 'CONNECT_ADJUDICATOR_SIGNATURE')
    if output_keys is not None:
        check(type(output_keys) in (list, tuple) and decision['decider'] in output_keys,
              'CONNECT_ADJUDICATOR_SIGNATURE')
    body = {name: value for name, value in decision.items() if name != 'signature'}
    try:
        verify(decision['decider'], DECISION_LABEL, body, decision['signature'])
    except ValueError:
        raise ConnectError('CONNECT_ADJUDICATOR_SIGNATURE') from None
    return digest(DECISION_LABEL, body)


# Signed adapter manifests -----------------------------------------------------

def implementation_sha256(value):
    """SHA-256 of the source file that defines an adapter's class (or of a path)."""
    if isinstance(value, (str, Path)):
        path = Path(value)
    else:
        source = inspect.getsourcefile(value if inspect.isclass(value) else type(value))
        check(source is not None, 'CONNECT_ADAPTER')
        path = Path(source)
    check(path.is_file() and path.stat().st_size <= 4_000_000, 'CONNECT_ADAPTER')
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _protocols(rows):
    check(type(rows) is list and len(rows) <= 16, 'CONNECT_MANIFEST')
    for row in rows:
        check(type(row) is dict and set(row) == {'id', 'version', 'decision'} and row['decision'] in DECISIONS
              and all(type(row[name]) is str and 0 < len(row[name]) <= 128 for name in ('id', 'version')),
              'CONNECT_MANIFEST')
    check(len({(row['id'], row['version']) for row in rows}) == len(rows), 'CONNECT_MANIFEST')


def validate_manifest(body):
    check(type(body) is dict and set(body) == set(
        'version kind name release contract level maturity publisher implementation artifact protocols '
        'output_keys conformance previous issued_at'.split()), 'CONNECT_MANIFEST')
    check(body['version'] == MANIFEST and body['contract'] == CONTRACT, 'CONNECT_MANIFEST')
    check(body['kind'] in KIND_SPECS, 'CONNECT_KIND')
    check(body['level'] == LEVELS[body['kind']], 'CONNECT_LEVEL')
    check(type(body['name']) is str and _NAME.fullmatch(body['name']) is not None and
          type(body['release']) is str and _SEMVER.fullmatch(body['release']) is not None and
          body['maturity'] in MATURITY, 'CONNECT_MANIFEST')
    try:
        verification_key(body['publisher'])
    except ValueError:
        raise ConnectError('CONNECT_MANIFEST') from None
    check(type(body['implementation']) is str and _HEX.fullmatch(body['implementation']) is not None, 'CONNECT_MANIFEST')
    artifact = body['artifact']
    check(artifact is None or (type(artifact) is dict and set(artifact) == {'name', 'sha256'} and
          type(artifact['name']) is str and 0 < len(artifact['name']) <= 200 and
          type(artifact['sha256']) is str and _HEX.fullmatch(artifact['sha256']) is not None), 'CONNECT_MANIFEST')
    _protocols(body['protocols'])
    keys = body['output_keys']
    check(type(keys) is list and len(keys) <= 16 and keys == sorted(set(keys)), 'CONNECT_MANIFEST')
    for value in keys:
        try:
            verification_key(value)
        except ValueError:
            raise ConnectError('CONNECT_MANIFEST') from None
    check(body['kind'] != 'adjudicator' or keys, 'CONNECT_MANIFEST')
    conformance = body['conformance']
    check(type(conformance) is dict and set(conformance) == {'report', 'suite', 'results', 'verdict'} and
          conformance['verdict'] == 'PASS' and all(type(conformance[name]) is str and
                                                   _HEX.fullmatch(conformance[name]) is not None
                                                   for name in ('report', 'suite', 'results')), 'CONNECT_MANIFEST')
    check(body['previous'] is None or (type(body['previous']) is str and _HEX.fullmatch(body['previous'])), 'CONNECT_MANIFEST')
    try:
        integer(body['issued_at'])
        size = len(canonical(body))
    except ValueError:
        raise ConnectError('CONNECT_MANIFEST') from None
    check(size <= MAX_MANIFEST, 'CONNECT_MANIFEST')
    return body


def manifest_id(body):
    return digest(MANIFEST_LABEL, validate_manifest(body))


def manifest(*, kind, name, release, publisher, implementation, report, maturity='experimental', artifact=None,
             protocols=(), output_keys=(), previous=None, issued_at):
    """An unsigned manifest bound to a passing conformance report; the publisher signs it."""
    from .connect_conformance import open_report
    opened = open_report(report)
    summary = opened['body']
    check(summary['kind'] == kind and summary['verdict'] == 'PASS', 'CONNECT_MANIFEST')
    check(summary['subject'] == {'kind': kind, 'name': name, 'release': release, 'implementation': implementation},
          'CONNECT_MANIFEST')
    body = {'version': MANIFEST, 'kind': kind, 'name': name, 'release': release, 'contract': CONTRACT,
            'level': LEVELS.get(kind), 'maturity': maturity, 'publisher': publisher,
            'implementation': implementation, 'artifact': deepcopy(artifact), 'protocols': deepcopy(list(protocols)),
            'output_keys': sorted(set(output_keys)),
            'conformance': {'report': opened['id'], 'suite': summary['suite']['sha256'],
                            'results': summary['results_sha256'], 'verdict': 'PASS'},
            'previous': previous, 'issued_at': issued_at}
    return {'id': manifest_id(body), 'body': body, 'signing_payload': {'label': MANIFEST_LABEL, 'body': deepcopy(body)},
            'required_signers': [publisher], 'signature_created': False, 'execution_authorized': False}


def sign_manifest(body, private_key):
    """The publisher's explicit local act. Not exposed as an agent tool."""
    validate_manifest(body)
    check(public_key(private_key) == body['publisher'], 'CONNECT_MANIFEST_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, MANIFEST_LABEL, body)}


def open_manifest(envelope, expected_id=None):
    check(type(envelope) is dict and set(envelope) == {'body', 'signature'}, 'CONNECT_MANIFEST')
    body = validate_manifest(envelope['body'])
    try:
        verify(body['publisher'], MANIFEST_LABEL, body, envelope['signature'])
    except ValueError:
        raise ConnectError('CONNECT_MANIFEST_SIGNATURE') from None
    ident = digest(MANIFEST_LABEL, body)
    check(expected_id is None or ident == expected_id, 'CONNECT_MANIFEST_ID')
    return {'id': ident, 'body': deepcopy(body), 'urn': MANIFEST_URN + ident}
