"""Agent Name Service transparency-log artefacts verified offline, as registry evidence beside signed discovery.

GRAFT: draft-narajala-courtney-ansv2-02 (26 October 2026) section 7 and the ANS-4 transparency
specification it cites (agentnameservice/ans-registry spec/ans-4-transparency.md, 0.2.0, at commit
f33c1aeb, Apache-2.0):

* Root keys (ANS-4 section 5.1): note verifier lines ``<origin>+<key hash>+base64(0x02 || SPKI)``, an
  ECDSA P-256 key whose 4-byte hash is SHA-256 of its SubjectPublicKeyInfo. The owner adopts the lines it
  trusts; the set is append-only, so several may be adopted for one log.
* Checkpoints (section 5.2): a C2SP signed note whose primary line is the key hash followed by an ASN.1
  DER ECDSA signature over SHA-256 of the note body.
* The agent badge (``GET /v1/agents/{id}``) holds the sealed envelope {payload, schemaVersion, signature} and
  a merkleProof. The leaf hash is SHA-256(0x00 || JCS(envelope)) (section 3, RFC 6962 section 2.1); the path
  is walked as RFC 9162 section 2.1.3.2 (ANS-6 section 4.3) to rootHash; rootSignature is the log's ES256
  JWS over its checkpoint JSON for that tree size; the outer ``signature`` is the log's detached ES256 JWS
  (RFC 7515 Appendix F) over the JCS of the envelope without its signature.
* The sealed event (ANS-1, V1 and V2 schemas): eventType, ansName, agent host and version, the DNS records
  the registration authority provisioned, certificate fingerprints and, in V2, agent card digests.

What this proves, offline: the log whose key the owner adopted signed a tree head containing that sealed
registration event. It does not prove the badge's computed status (unsigned in the response), current
liveness (a status token or fresh badge is needed), the registration authority's producer signature (its
keys are not published), DNS or certificate state, or the log's honesty, which needs consistency proofs and
witnesses. A registration concerns a did:aap account only through a covenant-evidence-binding/0.1 record
(kind ANS_REGISTRATION) that account key signs. Nothing here fetches, registers or grants authority.
"""
from copy import deepcopy
import base64
import hashlib
import json
import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from .crypto import need
from . import interop_codec as codec
from . import trust_evidence as evidence

DRAFT = 'draft-narajala-courtney-ansv2-02'
SPEC = 'agentnameservice/ans-registry ANS-4 0.2.0 (f33c1aeb)'
EVENTS = ('AGENT_REGISTERED', 'AGENT_RENEWED', 'AGENT_UPDATED', 'AGENT_DEPRECATED', 'AGENT_REVOKED')
MAX_BADGE = 65536
MAX_PATH = 64
MAX_KEYS = 8
LINE = re.compile(r'([A-Za-z0-9.-]{1,253})\+([0-9a-f]{8})\+([A-Za-z0-9+/=]{20,512})\Z')

REMEDIATION = {
    'ANS_TL_KEY': 'Adopt the log key yourself as its root-keys line: <origin>+<8-hex key hash>+base64(0x02 || SPKI).',
    'ANS_TL_NOT_ADOPTED': 'No adopted log key matches this log origin; adopt the log yourself, a badge cannot nominate it.',
    'ANS_CHECKPOINT': 'Supply the C2SP signed note: origin, size and base64 root, then a signature line by an adopted key.',
    'ANS_BADGE': 'Supply the badge JSON: payload, schemaVersion, signature and merkleProof {leafIndex, treeSize, leafHash, rootHash, path, rootSignature}.',
    'ANS_LEAF': 'The leaf hash of the sealed envelope does not match the badge; the envelope was changed.',
    'ANS_ATTESTATION': 'The log attestation over the envelope does not verify under an adopted log key.',
    'ANS_INCLUSION': 'The inclusion path does not lead from the leaf to the root for that tree size.',
    'ANS_ROOT_SIGNATURE': 'rootSignature does not sign this root and tree size under an adopted log key.',
    'ANS_EVENT': 'The sealed event lacks eventType, ansName or agent host and version.',
}


def remediation(code):
    return REMEDIATION.get(code, evidence.remediation(code))


def tl_key(line):
    """One adopted root-keys line: origin, key hash and the ECDSA P-256 public key it carries."""
    found = LINE.fullmatch(line) if type(line) is str else None
    need(found is not None, 'ANS_TL_KEY')
    try:
        raw = base64.b64decode(found.group(3), validate=True)
        need(raw[:1] == b'\x02', 'ANS_TL_KEY')
        public = serialization.load_der_public_key(raw[1:])
    except ValueError:
        raise ValueError('ANS_TL_KEY') from None
    need(isinstance(public, ec.EllipticCurvePublicKey) and public.curve.name == 'secp256r1'
         and hashlib.sha256(raw[1:]).digest()[:4].hex() == found.group(2), 'ANS_TL_KEY')
    return {'origin': found.group(1), 'key_hash': found.group(2), 'line': line, 'public': public}


def _keys(lines, origin=None):
    need(type(lines) in (list, tuple) and 0 < len(lines) <= MAX_KEYS, 'ANS_TL_KEY')
    keys = [tl_key(line) for line in lines]
    if origin is not None:
        keys = [row for row in keys if row['origin'] == origin]
        need(bool(keys), 'ANS_TL_NOT_ADOPTED')
    return keys


def _es256(keys, message, raw, code):
    need(len(raw) == 64, code)
    der = encode_dss_signature(int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:], 'big'))
    for row in keys:
        try:
            row['public'].verify(der, message, ec.ECDSA(hashes.SHA256()))
            return row
        except InvalidSignature:
            continue
    raise ValueError(code)


def checkpoint(note, lines):
    """Verify an ANS log checkpoint note under an adopted key; returns (origin, size, root bytes)."""
    need(type(note) is str and 0 < len(note) <= 8192 and '\n\n' in note, 'ANS_CHECKPOINT')
    body, _, signatures = note.partition('\n\n')
    body += '\n'
    rows = body.split('\n')[:-1]
    need(len(rows) >= 3 and rows[1].isdigit() and (rows[1] == '0' or not rows[1].startswith('0')), 'ANS_CHECKPOINT')
    try:
        root = base64.b64decode(rows[2], validate=True)
    except ValueError:
        raise ValueError('ANS_CHECKPOINT') from None
    need(len(root) == 32, 'ANS_CHECKPOINT')
    keys = _keys(lines, rows[0])
    for line in signatures.split('\n'):
        if not line.startswith('— '):
            continue
        parts = line.split(' ')
        need(len(parts) == 3, 'ANS_CHECKPOINT')
        try:
            raw = base64.b64decode(parts[2], validate=True)
        except ValueError:
            raise ValueError('ANS_CHECKPOINT') from None
        for row in keys:
            if parts[1] != row['origin'] or raw[:4].hex() != row['key_hash'] or raw[4:5] != b'\x30':
                continue
            try:
                row['public'].verify(raw[4:], body.encode('utf-8'), ec.ECDSA(hashes.SHA256()))
            except InvalidSignature:
                raise ValueError('ANS_CHECKPOINT') from None
            return rows[0], int(rows[1]), root
    raise ValueError('ANS_TL_NOT_ADOPTED')


def _b64(text, code, url=False):
    need(type(text) is str and len(text) <= 1024, code)
    try:
        return codec.b64url_decode(text.rstrip('='), 1024) if url else base64.b64decode(text, validate=True)
    except ValueError:
        raise ValueError(code) from None


def _inclusion(leaf, index, size, path):
    """RFC 9162 section 2.1.3.2 path walk, as ANS-6 section 4.3 spells it; returns the computed root."""
    need(type(index) is int and type(size) is int and 0 <= index < size < 2**63 and type(path) is list
         and len(path) <= MAX_PATH, 'ANS_INCLUSION')
    fn, sn, value = index, size - 1, leaf
    for item in path:
        sibling = _b64(item, 'ANS_INCLUSION')
        need(len(sibling) == 32 and sn != 0, 'ANS_INCLUSION')
        if fn & 1 or fn == sn:
            value = hashlib.sha256(b'\x01' + sibling + value).digest()
            if not fn & 1:
                while fn and not fn & 1:
                    fn >>= 1; sn >>= 1
        else:
            value = hashlib.sha256(b'\x01' + value + sibling).digest()
        fn >>= 1; sn >>= 1
    need(sn == 0, 'ANS_INCLUSION')
    return value


def _records(attestations):
    """Provisioned DNS records as {owner name: [text]}, from the V1 map or the V2 list."""
    provisioned = attestations.get('dnsRecordsProvisioned')
    out = {}
    if type(provisioned) is dict:
        for name, value in provisioned.items():
            if type(name) is str and type(value) is str:
                out.setdefault(name.rstrip('.').lower(), []).append(value)
    elif type(provisioned) is list:
        for row in provisioned:
            if type(row) is dict and type(row.get('name')) is str and type(row.get('data')) is str:
                out.setdefault(row['name'].rstrip('.').lower(), []).append(row['data'])
    return out


def _fingerprints(attestations):
    found = []
    for name in ('identityCert', 'serverCert'):
        if type(attestations.get(name)) is dict:
            found.append(attestations[name])
    for name in ('validIdentityCerts', 'validServerCerts', 'identityCerts', 'serverCerts'):
        if type(attestations.get(name)) is list:
            found.extend(row for row in attestations[name] if type(row) is dict)
    return sorted({(row.get('type'), row.get('fingerprint')) for row in found
                   if type(row.get('fingerprint')) is str and type(row.get('type')) is str})


def badge(document, lines, *, bindings=(), now=None, chain=None):
    """Verify one agent badge against the adopted log keys; returns registration evidence."""
    need(type(document) in (str, bytes) and 0 < len(document) <= MAX_BADGE, 'ANS_BADGE')
    try:
        value = codec.parse(document, MAX_BADGE, 16, 4096)
    except ValueError:
        raise ValueError('ANS_BADGE') from None
    need(type(value) is dict and {'payload', 'schemaVersion', 'signature', 'merkleProof'} <= set(value)
         and type(value['merkleProof']) is dict and type(value['payload']) is dict and type(value['signature']) is str, 'ANS_BADGE')
    proof = value['merkleProof']
    need({'leafIndex', 'treeSize', 'leafHash', 'rootHash', 'path', 'rootSignature'} <= set(proof), 'ANS_BADGE')
    envelope = {'payload': value['payload'], 'schemaVersion': value['schemaVersion'], 'signature': value['signature']}
    leaf = hashlib.sha256(b'\x00' + codec.jcs(envelope)).digest()
    need(type(proof['leafHash']) is str and proof['leafHash'].lower() == leaf.hex(), 'ANS_LEAF')
    root = _inclusion(leaf, proof['leafIndex'], proof['treeSize'], proof['path'])
    need(root == _b64(proof['rootHash'], 'ANS_INCLUSION'), 'ANS_INCLUSION')
    # The log's checkpoint signature for this tree size names the origin, so the key must be adopted for it.
    parts = proof['rootSignature'].split('.') if type(proof['rootSignature']) is str else []
    need(len(parts) == 3, 'ANS_ROOT_SIGNATURE')
    try:
        claims = codec.parse(codec.b64url_decode(parts[1], 4096), 4096, 4, 64)
        header = codec.parse(codec.b64url_decode(parts[0], 2048), 2048, 4, 64)
    except ValueError:
        raise ValueError('ANS_ROOT_SIGNATURE') from None
    need(type(header) is dict and header.get('alg') == 'ES256' and type(claims) is dict
         and type(claims.get('origin')) is str and claims.get('treesize') == proof['treeSize'], 'ANS_ROOT_SIGNATURE')
    need(_b64(claims.get('rootHash'), 'ANS_ROOT_SIGNATURE', url=True) == root, 'ANS_ROOT_SIGNATURE')
    keys = _keys(lines, claims['origin'])
    signer = _es256(keys, (parts[0] + '.' + parts[1]).encode('ascii'), _b64(parts[2], 'ANS_ROOT_SIGNATURE', url=True),
                    'ANS_ROOT_SIGNATURE')
    head, empty, tail = value['signature'].partition('..')
    need(empty == '..' and '.' not in tail, 'ANS_ATTESTATION')
    signed = {'payload': value['payload'], 'schemaVersion': value['schemaVersion']}
    _es256(keys, (head + '.' + codec.b64url(codec.jcs(signed))).encode('ascii'), _b64(tail, 'ANS_ATTESTATION', url=True),
           'ANS_ATTESTATION')
    producer = value['payload'].get('producer')
    event = producer.get('event') if type(producer) is dict else None
    agent = event.get('agent') if type(event) is dict else None
    need(type(event) is dict and event.get('eventType') in EVENTS and type(event.get('ansName')) is str
         and type(agent) is dict and type(agent.get('host')) is str and type(agent.get('version')) is str, 'ANS_EVENT')
    attestations = event.get('attestations') if type(event.get('attestations')) is dict else {}
    hashes_ = attestations.get('metadataHashes') if type(attestations.get('metadataHashes')) is dict else {}
    claims_out = {'ans_name': event['ansName'][:400], 'ans_id': str(event.get('ansId'))[:64], 'event_type': event['eventType'],
                  'host': agent['host'][:253].lower(), 'version': agent['version'][:32].lstrip('v'),
                  'sealed_records': _records(attestations), 'certificates': [list(row) for row in _fingerprints(attestations)],
                  'metadata_hashes': {str(name)[:32]: str(text)[:80] for name, text in hashes_.items()},
                  'issued_at': str(event.get('issuedAt'))[:40], 'expires_at': str(event.get('expiresAt'))[:40],
                  'log': claims['origin'], 'tree_size': proof['treeSize'], 'leaf_index': proof['leafIndex'],
                  'schema_version': str(value['schemaVersion'])[:8]}
    checks = {'leaf_hash': 'RECOMPUTED', 'inclusion': 'RFC9162_PATH_TO_SIGNED_ROOT', 'root_signature': 'VERIFIED',
              'attestation': 'VERIFIED', 'log_key': signer['key_hash'],
              'producer_signature': 'NOT_VERIFIED_RA_KEYS_UNPUBLISHED',
              'status_claimed': str(value.get('status'))[:16] if 'status' in value else None,
              'status': 'UNSIGNED_IN_BADGE_LIVENESS_UNKNOWN', 'consistency': 'NOT_CHECKED'}
    return evidence.evidence('ANS_REGISTRATION', 'ANS_TRANSPARENCY_LOG', claims['origin'], claims_out['ans_name'], leaf.hex(),
                             claims_out, checks, bindings=bindings, now=now, chain=chain)


def describe():
    return {'status': 'EXPERIMENTAL_GRAFT', 'draft': DRAFT, 'spec': SPEC, 'events': list(EVENTS),
            'verifies': ['root-keys line', 'checkpoint note primary ECDSA line', 'badge leaf hash',
                         'RFC 9162 inclusion to the signed root', 'log attestation over the envelope'],
            'not_verified': ['badge computed status', 'status token liveness', 'SCITT COSE receipt',
                             'producer (RA) signature', 'checkpoint consistency', 'DNSSEC and certificates'],
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'authority_granted': False,
            'execution_authorized': False}
