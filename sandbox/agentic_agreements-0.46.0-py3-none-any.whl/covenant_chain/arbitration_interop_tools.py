"""Keyless agent tool for arbitration interoperability, AAP awards and arbitrator records.

Every action validates, maps, renders or verifies. None accepts a private
key, signs, submits, appoints, pays or contacts a service; signatures come
back from the parties' own signers.
"""
import base64
import binascii
from copy import deepcopy

from .cooperation_interface import HASH, INT, OBJECT
from .crypto import FieldError, need
from . import agentic_arbitration as wire
from . import arbitration_interop as interop
from . import arbitrator_records as records
from . import award_documents as documents

NAME = 'covenant_arbitration_interop'
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 512}
PEM = {'type': 'string', 'minLength': 1, 'maxLength': 4096}
PEMS = {'type': 'array', 'maxItems': 16, 'items': PEM}
OBJECTS = {'type': 'array', 'maxItems': 256, 'items': OBJECT}
HASHES = {'type': 'array', 'maxItems': 64, 'items': HASH}
BOOL = {'type': 'boolean'}
BYTES = {'type': 'string', 'maxLength': 15_000_000, 'description': 'Standard base64 of the exact PDF bytes.'}
JSON_TEXT = {'type': 'string', 'minLength': 2, 'maxLength': wire.MAX_BYTES,
             'description': 'The exact received JSON text; it keeps member order and number spelling, which the upstream hashes depend on.'}
EXPORT_TEXT = {**JSON_TEXT, 'maxLength': 4 * wire.MAX_BYTES,
               'description': 'Custody export as received: a JSON array, a retrieval response with events, or JSON Lines.'}
KIND = {'type': 'string', 'enum': sorted(wire.RULES)}
UUID = {'type': 'string', 'minLength': 36, 'maxLength': 45, 'description': 'Caller-chosen UUID; reuse it for an exact retry.'}
WHEN = {'type': 'string', 'minLength': 20, 'maxLength': 40, 'description': 'RFC 3339 date-time asserted by the caller.'}

def _models():
    """Discover existing wire fields; cross-field equality and signatures stay runtime checks."""
    from .cooperation_interface import schema
    from .contract_application_tools import _input_models
    procedure = _input_models()

    def obj(fields): return schema(fields, tuple(fields))
    def array(item, maximum, minimum=0):
        return {'type': 'array', 'items': item, 'minItems': minimum, 'maxItems': maximum}
    def text(limit): return {'type': 'string', 'minLength': 1, 'maxLength': limit, 'pattern': '^[ -~]+$'}
    def nullable(item): return {'anyOf': [item, {'type': 'null'}]}
    def mapping(item, maximum):
        return {'type': 'object', 'maxProperties': maximum, 'additionalProperties': item}

    name = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
    signature = {'type': 'string', 'pattern': '^[0-9a-f]{128}$'}
    # Interop sides, awards and arbitrator records require historical Ed25519 keys.
    # Procedure adoption/events retain their existing supported signature suites.
    ladder = {'oneOf': [obj({'kind': {'const': 'PROCEDURE'}, 'id': HASH, 'stage': name}),
                        obj({'kind': {'const': 'PANEL'}, 'id': HASH, 'stage': {'enum': ['PRIMARY', 'APPEAL']}})]}
    side = obj({'role': name, 'key': HASH,
                'agent': {'type': 'string', 'pattern': '^agent://'},
                'organization': {'type': 'string', 'pattern': '^org://'}, 'external_key': nullable(HASH)})
    parties = obj({'claimant': side, 'respondent': side})
    money = obj({'unit': text(128), 'currency': {'type': 'string', 'pattern': '^[A-Z]{3}$'},
                 'exponent': {'type': 'integer', 'minimum': 0, 'maximum': 18}})
    # TEXT values are bounded by the complete terms' existing 64-KiB limit, not
    # the smaller application authoring convenience bound.
    typed_map = deepcopy(procedure['typed_map'])
    for branch in typed_map['additionalProperties']['oneOf']:
        if branch['properties']['kind'].get('const') == 'TEXT':
            branch['properties']['value'] = {'type': 'string', 'maxLength': 65536}
    panel_result = obj({'remedy': {'enum': list(interop.REMEDIES)},
                        'payee_bps': {**INT, 'maximum': 10000}, 'penalty': INT})
    outcome = obj({'outcome': {'enum': wire.OUTCOMES}, 'liability': {'enum': wire.LIABILITY},
                   'result': {'oneOf': [typed_map, panel_result]}})
    arbitrators = array(obj({'judge_id': text(128), 'type': {'enum': ['AI', 'HUMAN']}, 'key': HASH}), 16, 1)
    term_fields = {'version': {'const': interop.VERSION}, 'ladder': ladder, 'parties': parties,
                   'service': {'type': 'string', 'maxLength': 512},
                   'award_sender': {'type': 'string', 'pattern': '^agent://'}, 'rules_version': text(128),
                   'resolution_method': {'enum': wire.METHODS}, 'signature_date': WHEN,
                   'claim_type': {'enum': wire.CLAIM_TYPES}, 'money': money, 'outcomes': array(outcome, 8, 1),
                   'arbitrators': arbitrators, 'service_keys': array(HASH, 8),
                   'required_assurance': {'enum': list(interop.ASSURANCE)}}
    terms = obj(term_fields)
    terms['description'] = ('Exact signed interop terms (<=65536 canonical bytes). Parties, outcome rows and pins must be distinct. '
        'PROCEDURE results are typed maps; PANEL results use remedy/payee_bps/penalty. Runtime checks stage, roles, sums, '
        'URI/date validity, money precision and every signature; schemas do not establish authority.')
    signatures = array(obj({'side': {'enum': ['claimant', 'respondent']}, 'signature': signature}), 2, 2)
    policy = obj({'version': {'const': 'urn:aap:agreement-procedure:0.1'}, 'kind': {'const': 'ESCALATION'},
                  'title': {'type': 'string', 'minLength': 1, 'maxLength': 256}, 'parties': procedure['parties'],
                  'principal': name, 'context': HASH, 'configuration': procedure['escalation'], 'supersedes': nullable(HASH)})
    evidence_item = obj({'type': {'enum': wire.EVIDENCE_TYPES}, 'id': text(128), 'description': text(2000)})
    evidence = obj({'reference': HASH, **evidence_item['properties']})
    keyset = schema({'judges': mapping(PEM, 16), 'service': array(PEM, 8),
                     'parties': schema({'claimant': PEM, 'respondent': PEM})})
    keyset['description'] = 'Public PEM keys only. Each SPKI SHA-256 pin must occur in the separately signed terms; no key is adopted from award text.'
    basis = obj({'kind': {'enum': list(documents.BASES)}, 'reference': HASH, 'head': nullable(HASH)})
    body = obj({'version': {'const': documents.VERSION}, 'case': text(128), 'title': text(200),
                'issued': {'type': 'string', 'pattern': '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$'},
                'seat': nullable(text(128)), 'method': {'enum': list(documents.METHODS)},
                'parties': array(obj({'role': text(64), 'name': text(128), 'key': HASH}), 16, 2),
                'tribunal': array(obj({'name': text(128), 'key': HASH}), 16, 1),
                'threshold': {**INT, 'minimum': 1, 'maximum': 16}, 'basis': basis,
                'agreement': obj({'reference': HASH, 'clause': text(2000)}),
                'sections': array(obj({'heading': text(120), 'paragraphs': array(text(4000), 64, 1)}), 32, 1),
                'outcome': {'type': 'object', 'minProperties': 1, 'maxProperties': 32},
                'escrow_effect': {'const': 'DECIDED_BY_AAP_TERMS_AND_LADDER'}})
    body['description'] = ('Canonical body <=262144 bytes. Threshold must be a majority through all tribunal members. '
        'Distinct parties and tribunal keys cannot overlap. Outcome is deliberately an open declared map: it grants no authority.')
    award = obj({'version': {'const': documents.VERSION}, 'body': body, 'body_id': HASH,
                 'pdf': obj({'sha256': HASH, 'bytes': {**INT, 'minimum': 1},
                             'media_type': {'const': 'application/pdf'}, 'renderer': {'const': documents.RENDERER}}),
                 'signatures': array(obj({'signer': HASH, 'signature': signature}), 16, 1)})
    availability = obj({'status': {'enum': list(records.STATUS)}, 'max_caseload': {**INT, 'minimum': 1},
                        'current_caseload': INT, 'next_available': nullable(INT), 'as_of': INT})
    qualification = {'oneOf': [obj({'kind': {'const': kind}, 'value': value, 'context': context})
        for kind, value, context in [('CASES', {**INT, 'maximum': 1000000}, text(256)),
            ('EXPERIENCE_YEARS', {**INT, 'maximum': 1000000}, {'type': 'null'}),
            ('JURISDICTION', {'type': 'string', 'pattern': '^[A-Z]{2}(-[A-Z]{2})?$'}, {'type': 'null'}),
            ('SPECIALIZATION', text(128), text(256)), ('CERTIFICATION', text(128), {'type': 'null'}),
            ('MODEL', text(128), {'type': 'null'})]]}
    conflict = obj({'subject': HASH, 'relation': text(256), 'category': {'enum': list(records.CONFLICTS)}})
    record_body = obj({'version': {'const': records.VERSION}, 'arbitrator': HASH, 'kind': {'enum': ['AI', 'HUMAN']},
        'name': text(128), 'sequence': INT, 'previous': nullable(HASH), 'issued_at': INT, 'expires': INT,
        'categories': array({'type': 'string', 'pattern': '^[a-z0-9-]{1,32}$'}, 8),
        'qualifications': array(qualification, 32), 'availability': availability,
        'conflicts': array(conflict, 64), 'external_key': nullable(HASH)})
    record_body['description'] = 'Exact signed record; expiry/order, sorted categories, distinct conflicts and qualification claims are runtime checks. Claims do not prove qualifications.'
    prefixed_hash = {'type': 'string', 'pattern': '^sha256:[a-f0-9]{64}$'}
    evidence_record = obj({'version': {'const': interop.RECORD}, 'terms': HASH, 'ladder': ladder,
        'award': obj({'id': {'type': 'string', 'maxLength': 65536}, 'case': {'type': 'string', 'maxLength': 65536},
                      'issued_at': WHEN, 'message_sha256': HASH, 'json_hash': prefixed_hash,
                      'pdf_hash': prefixed_hash, 'pdf': {'enum': ['MATCHED', 'NOT_SUPPLIED']}}),
        'decision': obj({'outcome': {'enum': wire.OUTCOMES}, 'liability': {'enum': wire.LIABILITY},
                         'damages': nullable(obj({'minor': INT, 'currency': {'type': 'string', 'maxLength': 65536}}))}),
        'mapping': {'enum': ['MAPPED', 'DAMAGES_UNREPRESENTABLE', 'UNMAPPED_OUTCOME', 'DAMAGES_MISMATCH', 'DAMAGES_NOT_STATED']},
        'mapped_result': nullable({'oneOf': [typed_map, panel_result]}), 'assurance': {'enum': list(interop.ASSURANCE)},
        'judges_verified': array({'type': 'string', 'maxLength': 65536}, 16),
        'custody': nullable(obj({'head': prefixed_hash, 'events': {**INT, 'minimum': 1, 'maximum': wire.MAX_EVENTS},
                                'status': {'const': 'VERIFIED'}}))})
    evidence_record['description'] = ('Retain the exact award_evidence record and its independently retained id. '
        'This shape and an id check do not authenticate a caller-constructed record or execute the result.')
    signed_member = obj({'signer': HASH, 'signature': signature})
    waiver = obj({'body': obj({'version': {'const': records.WAIVER_VERSION}, 'case': HASH, 'record': HASH,
                               'subject': HASH, 'parties': array(HASH, 16, 2)}),
                  'signatures': array(signed_member, 16)})
    metrics = {**mapping({**INT, 'maximum': 10000}, 16), 'minProperties': 1,
               'propertyNames': {'type': 'string', 'pattern': '^[a-z][a-z0-9_]{0,63}$'}}
    audit = obj({'body': obj({'version': {'const': records.AUDIT_VERSION}, 'arbitrator': HASH, 'auditor': HASH,
        'period': obj({'from': INT, 'to': INT}), 'method': text(512), 'metrics': metrics, 'sample': INT,
        'report': nullable(HASH), 'issued_at': INT, 'nonce': HASH}), 'signature': signature})
    return dict(terms=terms, signatures=signatures, ladder=ladder, parties=parties, money=money,
                outcomes=array(outcome, 8, 1), arbitrators=arbitrators, policy=policy,
                adoptions=array(procedure['adoption'], 16), events=array(procedure['procedure_event'], 128),
                evidence=array(evidence, 32), item=evidence_item, keyset=keyset, body=body, award=award,
                qualifications=array(qualification, 32), availability=availability, conflicts=array(conflict, 64),
                categories=record_body['properties']['categories'], evidence_record=evidence_record,
                audits=array(audit, 32), waivers=array(waiver, 64),
                record=obj({'body': record_body, 'signature': signature}),
                affiliations={**mapping(array(HASH, 32), 16), 'propertyNames': HASH},
                requirements=array(obj({'kind': {'enum': ['CASES', 'SPECIALIZATION']}, 'context': text(256)}), 16))


MODELS = _models()
SESSION = {name: MODELS[name] for name in ('terms', 'signatures', 'policy', 'adoptions', 'events')}

SESSION_REQUIRED = ('terms', 'signatures', 'policy', 'adoptions', 'events')


def spec():
    return ('covenant_arbitration_interop',
        'Experimental. Agentic Arbitration Protocol interop (GRAFT, pinned upstream commit a38a4f3): validate its messages, '
        'verify custody chains and dual-format awards against caller-pinned keys, map AAP procedure ladders and chain '
        'panels to filings, responses, evidence and awards and back, and turn an external award into evidence for the '
        'stage both parties signed. Also AAP dual-format awards (canonical JSON plus deterministic PDF) and arbitrator '
        'records with receipt-backed qualifications, availability, bias audits and conflict checks before appointment. '
        'Awards are evidence: AAP terms and ladder decide escrow. No keys, signing, network, appointment or legal recognition.', True, [
        ('describe', {}, ()),
        ('validate', {'message_json': JSON_TEXT, 'kind': KIND}, ('message_json',)),
        ('verify_custody', {'events_json': EXPORT_TEXT, 'keys': {'type': 'object', 'maxProperties': 64, 'additionalProperties': PEM}, 'service_keys': PEMS, 'case': TEXT,
                            'anchor': {'type': 'string', 'pattern': '^sha256:[a-f0-9]{64}$'}, 'allow_unpinned': BOOL}, ('events_json',)),
        ('verify_award', {'message_json': JSON_TEXT, 'judges': {'type': 'object', 'maxProperties': 32, 'additionalProperties': PEM}, 'service_keys': PEMS, 'pdf_base64': BYTES,
                          'require_all_judges': BOOL}, ('message_json',)),
        ('terms_draft', {'ladder': MODELS['ladder'], 'parties': MODELS['parties'], 'service': TEXT, 'award_sender': TEXT, 'rules_version': TEXT,
                         'resolution_method': {'type': 'string', 'enum': wire.METHODS}, 'signature_date': WHEN,
                         'claim_type': {'type': 'string', 'enum': wire.CLAIM_TYPES}, 'money': MODELS['money'],
                         'outcomes': MODELS['outcomes'],
                         'arbitrators': MODELS['arbitrators'],
                         'service_keys': {'type': 'array', 'maxItems': 8, 'items': HASH},
                         'required_assurance': {'type': 'string', 'enum': list(interop.ASSURANCE)}},
         ('ladder', 'parties', 'service', 'award_sender', 'rules_version', 'resolution_method', 'signature_date',
          'claim_type', 'money', 'outcomes', 'arbitrators')),
        ('filing_message', {**SESSION, 'message_id': UUID, 'timestamp': WHEN, 'evidence': MODELS['evidence']},
         SESSION_REQUIRED + ('message_id', 'timestamp')),
        ('response_message', {**SESSION, 'case_id': TEXT, 'message_id': UUID, 'timestamp': WHEN,
                              'evidence': MODELS['evidence']},
         SESSION_REQUIRED + ('case_id', 'message_id', 'timestamp')),
        ('evidence_message', {**SESSION, 'event': HASH, 'case_id': TEXT, 'item': MODELS['item'], 'message_id': UUID, 'timestamp': WHEN},
         SESSION_REQUIRED + ('event', 'case_id', 'item', 'message_id', 'timestamp')),
        ('message_view', {'terms': MODELS['terms'], 'signatures': SESSION['signatures'], 'message_json': JSON_TEXT, 'policy': MODELS['policy'],
                          'chain_terms': OBJECT}, ('terms', 'signatures', 'message_json')),
        ('award_evidence', {'terms': MODELS['terms'], 'signatures': SESSION['signatures'], 'award_json': JSON_TEXT, 'keys': MODELS['keyset'],
                            'pdf_base64': BYTES, 'custody_json': EXPORT_TEXT, 'policy': MODELS['policy'], 'chain_terms': OBJECT},
         ('terms', 'signatures', 'award_json', 'keys')),
        ('ladder_step', {**SESSION, 'record': MODELS['evidence_record'], 'expected_record': HASH, 'actor': TEXT, 'at': INT,
                         'bond_receipt': HASH}, SESSION_REQUIRED + ('record', 'expected_record', 'actor', 'at')),
        ('panel_step', {'terms': MODELS['terms'], 'signatures': SESSION['signatures'], 'record': MODELS['evidence_record'], 'expected_record': HASH,
                        'chain_terms': OBJECT, 'chain': HASH}, ('terms', 'signatures', 'record', 'expected_record', 'chain_terms', 'chain')),
        ('award_prepare', {'body': MODELS['body']}, ('body',)),
        ('award_verify', {'award': MODELS['award'], 'pdf_base64': BYTES, 'detached': {'type': 'array', 'maxItems': 16, 'items': TEXT}},
         ('award', 'pdf_base64', 'detached')),
        ('record_draft', {'arbitrator': HASH, 'kind': {'type': 'string', 'enum': ['AI', 'HUMAN']}, 'name': TEXT, 'issued_at': INT,
                          'expires': INT, 'qualifications': MODELS['qualifications'],
                          'availability': MODELS['availability'], 'conflicts': MODELS['conflicts'],
                          'categories': MODELS['categories'], 'sequence': INT, 'previous': {'anyOf': [HASH, {'type': 'null'}]},
                          'external_key': {'anyOf': [HASH, {'type': 'null'}]}},
         ('arbitrator', 'kind', 'name', 'issued_at', 'expires', 'qualifications', 'availability')),
        ('record_evaluate', {'record': MODELS['record'], 'now': INT, 'max_age': {**INT, 'minimum': 1}, 'receipts': OBJECTS,
                             'trusted_contacts': OBJECT, 'adopted_resolvers': OBJECT,
                             'audits': MODELS['audits'], 'adopted_auditors': HASHES},
         ('record', 'now', 'max_age')),
        ('conflict_check', {'record': MODELS['record'], 'parties': {'type': 'array', 'minItems': 2, 'maxItems': 16, 'items': HASH},
                            'affiliations': MODELS['affiliations'], 'registry_row': OBJECT}, ('record', 'parties')),
        ('appointment', {'record': MODELS['record'], 'case': HASH, 'parties': {'type': 'array', 'minItems': 2, 'maxItems': 16, 'items': HASH},
                         'now': INT, 'max_age': {**INT, 'minimum': 1}, 'waivers': MODELS['waivers'],
                         'affiliations': MODELS['affiliations'], 'registry_row': OBJECT,
                         'requirements': MODELS['requirements'], 'receipts': OBJECTS,
                         'trusted_contacts': OBJECT, 'adopted_resolvers': OBJECT},
         ('record', 'case', 'parties', 'now', 'max_age')),
        ('manifest_read', {'manifest_json': JSON_TEXT}, ('manifest_json',)),
    ])


def _pdf(text):
    try:
        raw = base64.b64decode(text, validate=True)
    except (binascii.Error, ValueError, TypeError):
        raise ValueError('AWARD_PDF_SIZE') from None
    need(0 < len(raw) <= documents.MAX_PDF, 'AWARD_PDF_SIZE')
    return raw


def describe():
    return {'tool': NAME, 'maturity': 'experimental', 'guide': 'docs/ARBITRATION_INTEROP.html',
            'adapter': wire.describe(), 'interop': interop.describe(),
            'award': {'version': documents.VERSION, 'renderer': documents.RENDERER, 'remediation': deepcopy(documents.REMEDIATION)},
            'arbitrator_records': {'version': records.VERSION, 'remediation': deepcopy(records.REMEDIATION)},
            'keys_accepted': False, 'execution_authorized': False}


def remediation(code):
    """The remediation message for one of this tool's refusal codes, or None."""
    for table in (wire.REMEDIATION, interop.REMEDIATION, documents.REMEDIATION, records.REMEDIATION):
        if code in table: return table[code]
    return None


def call(action, p):
    """Refusals keep their stable code; a schema path travels as the issue path, never as data."""
    try:
        return _call(action, p)
    except FieldError:
        raise
    except ValueError as exc:
        code, _, path = str(exc).partition(':')
        hint = remediation(code)
        if hint is None: raise
        raise FieldError(code, path or '$', 'See next_action.', hint) from None


def _call(action, p):
    p = deepcopy(p)
    if action == 'describe':
        return describe()
    if action == 'validate':
        received = wire.read(p['message_json'], p.get('kind'))
        return {'kind': received['kind'], 'valid': True, 'sha256': received['sha256'], 'schema': received['schema'], **wire.FLAGS}
    if action == 'verify_custody':
        return wire.verify_custody(p['events_json'], keys=p.get('keys'), service_keys=p.get('service_keys', ()), case=p.get('case'),
                                   anchor=p.get('anchor'), allow_unpinned=p.get('allow_unpinned', False))
    if action == 'verify_award':
        pdf = _pdf(p['pdf_base64']) if 'pdf_base64' in p else None
        return wire.verify_award(wire.read(p['message_json'], 'ArbitrationAward')['document'], judges=p.get('judges'),
                                 service_keys=p.get('service_keys', ()), pdf=pdf, require_all_judges=p.get('require_all_judges', True))
    if action == 'terms_draft':
        return interop.terms_draft(**p)
    if action in ('filing_message', 'response_message', 'evidence_message'):
        session = [p.pop(name) for name in SESSION_REQUIRED]
        return getattr(interop, action)(*session, **p)
    if action == 'message_view':
        return interop.message_view(p.pop('terms'), p.pop('signatures'), p.pop('message_json').encode('utf-8'), **p)
    if action == 'award_evidence':
        if 'pdf_base64' in p: p['pdf'] = _pdf(p.pop('pdf_base64'))
        if 'custody_json' in p: p['custody'] = p.pop('custody_json')
        return interop.award_evidence(p.pop('terms'), p.pop('signatures'), p.pop('award_json').encode('utf-8'), **p)
    if action == 'ladder_step':
        terms, signatures, policy, adoptions, events = (p.pop(name) for name in SESSION_REQUIRED)
        return interop.ladder_step(terms, signatures, p.pop('record'), p.pop('expected_record'), policy, adoptions, events, **p)
    if action == 'panel_step':
        return interop.panel_step(p['terms'], p['signatures'], p['record'], p['expected_record'], p['chain_terms'], chain=p['chain'])
    if action == 'award_prepare':
        prepared = documents.prepare(p['body'])
        return {**{name: prepared[name] for name in prepared if name != 'pdf'},
                'pdf_base64': base64.b64encode(prepared['pdf']).decode('ascii'), 'signature_created': False}
    if action == 'award_verify':
        return documents.verify(p['award'], _pdf(p['pdf_base64']), p.get('detached', []))
    if action == 'record_draft':
        return records.record_draft(**p)
    if action == 'record_evaluate':
        return records.evaluate(p.pop('record'), **p)
    if action == 'conflict_check':
        return records.conflict_check(p.pop('record'), p.pop('parties'), **p)
    if action == 'appointment':
        return records.appointment(p.pop('record'), **p)
    if action == 'manifest_read':
        return records.from_manifest(p['manifest_json'])
    raise ValueError('ARBITRATION_INTEROP_ACTION')
