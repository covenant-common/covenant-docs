"""Bounded, offline verification of owner-pinned OIDC RS256 ID tokens.

This is an account-claim verifier, not an OAuth/OIDC login client, legal identity
service, token exchange, key-discovery client or complete protocol implementation.
The owner supplies issuer/client/JWKS pins, a fresh expected nonce and trusted
time. Keys are never fetched from a token-controlled URL. Stable account identity
uses exact issuer plus subject; email is selected only by explicit requirements.

Profile references: OpenID Connect Core 1.0 errata 2, sections 2, 3.1.3.7 and 5.7;
https://openid.net/specs/openid-connect-core-1_0.html
https://developers.google.com/identity/openid-connect/openid-connect
"""
from copy import deepcopy
import base64
import hashlib
import hmac
import json
import re
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from cryptography.hazmat.primitives.asymmetric import padding, rsa


VERSION = 'covenant-oidc-rs256/0.1'
MAX_TOKEN_BYTES = 65536
MAX_HEADER_BYTES = 8192
MAX_CLAIMS_BYTES = 32768
MAX_JWKS_BYTES = 262144
MAX_RSA_BITS = 8192
BASE64URL = re.compile(r'[A-Za-z0-9_-]+\Z')
STRING_CLAIMS = frozenset(('iss', 'sub', 'azp', 'nonce', 'email', 'name',
    'given_name', 'family_name', 'middle_name', 'nickname', 'preferred_username',
    'profile', 'picture', 'website', 'gender', 'birthdate', 'zoneinfo', 'locale',
    'phone_number', 'hd', 'acr'))
BOOLEAN_CLAIMS = frozenset(('email_verified', 'phone_number_verified'))
TIME_CLAIMS = frozenset(('iat', 'exp', 'nbf', 'auth_time', 'updated_at'))


def _need(condition, code):
    if not condition:
        raise ValueError(code)


def _text(value, maximum=1024, ascii_only=False):
    _need(type(value) is str and 0 < len(value.encode('utf-8')) <= maximum,
        'OIDC_STRING')
    _need(not any(ord(char) < 32 or ord(char) == 127 for char in value), 'OIDC_STRING')
    if ascii_only:
        _need(value.isascii(), 'OIDC_ASCII_STRING')


def _integer(value, positive=False):
    _need(type(value) is int and (1 if positive else 0) <= value <= 2**53 - 1,
        'OIDC_INTEGER')


def _json_value(value, depth=0):
    _need(depth <= 12, 'OIDC_JSON_DEPTH')
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        _need(abs(value) <= 2**53 - 1, 'OIDC_INTEGER_RANGE')
        return
    if type(value) is str:
        _need(len(value.encode('utf-8')) <= 16384, 'OIDC_JSON_STRING')
        return
    if type(value) is list:
        _need(len(value) <= 64, 'OIDC_JSON_ARRAY')
        for child in value:
            _json_value(child, depth + 1)
        return
    _need(type(value) is dict and len(value) <= 64, 'OIDC_JSON_OBJECT')
    for key, child in value.items():
        _need(type(key) is str and 0 < len(key.encode('utf-8')) <= 128, 'OIDC_JSON_KEY')
        _json_value(child, depth + 1)


def _canonical(value):
    _json_value(value)
    return json.dumps(value, ensure_ascii=True, allow_nan=False,
        separators=(',', ':'), sort_keys=True).encode('ascii')


def _decode_json(raw, maximum):
    _need(type(raw) is bytes and 0 < len(raw) <= maximum, 'OIDC_JSON_SIZE')
    def pairs(items):
        result = {}
        for key, value in items:
            _need(key not in result, 'OIDC_DUPLICATE_JSON_KEY')
            result[key] = value
        return result
    def number(_):
        raise ValueError('OIDC_NONINTEGER_JSON_NUMBER')
    def integer(value):
        _need(len(value.lstrip('-')) <= 16, 'OIDC_INTEGER_RANGE')
        return int(value)
    try:
        text = raw.decode('utf-8')
        _need(not text.startswith('\ufeff'), 'OIDC_JSON_BOM')
        result = json.loads(text, object_pairs_hook=pairs,
            parse_float=number, parse_constant=number, parse_int=integer)
        _json_value(result)
        _need(type(result) is dict, 'OIDC_JSON_OBJECT')
        return result
    except (UnicodeError, RecursionError, json.JSONDecodeError):
        raise ValueError('OIDC_JSON_ENCODING') from None


def _base64url(value, maximum):
    _need(type(value) is str and 0 < len(value) <= 4 * ((maximum + 2) // 3)
        and BASE64URL.fullmatch(value) is not None, 'OIDC_BASE64URL')
    try:
        result = base64.b64decode(value + '=' * ((-len(value)) % 4),
            altchars=b'-_', validate=True)
    except ValueError:
        raise ValueError('OIDC_BASE64URL') from None
    _need(len(result) <= maximum and base64.urlsafe_b64encode(result).rstrip(b'=').decode('ascii') == value,
        'OIDC_BASE64URL')
    return result


def _unsigned(value, maximum):
    raw = _base64url(value, maximum)
    _need(raw[0] != 0, 'OIDC_RSA_INTEGER_ENCODING')
    return int.from_bytes(raw, 'big')


def _issuer(value):
    _text(value, 2048, True)
    _need(not any(char.isspace() for char in value), 'OIDC_ISSUER_URL')
    try:
        parsed = urlsplit(value)
        _need(parsed.scheme == 'https' and bool(parsed.hostname)
            and parsed.username is None and parsed.password is None
            and not parsed.query and not parsed.fragment, 'OIDC_ISSUER_URL')
        parsed.port
    except ValueError:
        raise ValueError('OIDC_ISSUER_URL') from None


def _jwk(value):
    required = {'kty', 'kid', 'n', 'e'}
    allowed = required | {'use', 'alg', 'key_ops', 'x5c', 'x5t', 'x5t#S256'}
    _need(type(value) is dict and required <= set(value) <= allowed, 'OIDC_JWK_FIELDS')
    _need(value['kty'] == 'RSA', 'OIDC_RSA_REQUIRED')
    _text(value['kid'], 128)
    if 'use' in value:
        _need(value['use'] == 'sig', 'OIDC_JWK_USE')
    if 'alg' in value:
        _need(value['alg'] == 'RS256', 'OIDC_JWK_ALGORITHM')
    if 'key_ops' in value:
        _need(type(value['key_ops']) is list and value['key_ops'] == ['verify'], 'OIDC_JWK_OPERATIONS')
    if 'x5c' in value:
        _need(type(value['x5c']) is list and 1 <= len(value['x5c']) <= 4, 'OIDC_JWK_CERTIFICATES')
        for certificate in value['x5c']:
            _text(certificate, 16384, True)
    for name, size in (('x5t', 20), ('x5t#S256', 32)):
        if name in value:
            _need(len(_base64url(value[name], size)) == size, 'OIDC_JWK_THUMBPRINT')
    modulus = _unsigned(value['n'], MAX_RSA_BITS // 8)
    exponent = _unsigned(value['e'], 4)
    _need(2048 <= modulus.bit_length() <= MAX_RSA_BITS and modulus % 2 == 1,
        'OIDC_RSA_MODULUS')
    _need(3 <= exponent <= 2**32 - 1 and exponent % 2 == 1, 'OIDC_RSA_EXPONENT')
    try:
        return rsa.RSAPublicNumbers(exponent, modulus).public_key()
    except (ValueError, TypeError):
        raise ValueError('OIDC_RSA_KEY') from None


def _claim_type(name, value):
    if name in STRING_CLAIMS:
        _text(value, 4096)
    elif name in BOOLEAN_CLAIMS:
        _need(type(value) is bool, 'OIDC_BOOLEAN_CLAIM')
    elif name in TIME_CLAIMS:
        _integer(value)
    elif name == 'aud':
        _need(type(value) is list and 1 <= len(value) <= 16, 'OIDC_AUDIENCE')
        for audience in value:
            _text(audience, 512)
    elif name == 'amr':
        _need(type(value) is list and 1 <= len(value) <= 32, 'OIDC_AMR')
        for method in value:
            _text(method, 128)
    elif name == 'address':
        _need(type(value) is dict, 'OIDC_ADDRESS')
    _json_value(value)


class OIDCVerifier:
    """Pure RS256 checks against an immutable owner-adopted public key set.

    Requirements are explicit claim-name to exact typed value comparisons.
    None means actual JSON null, never a wildcard or an absent claim. The base
    audience is normalized to a list before requirements are compared. Optional
    claims are returned only when requested; requesting email also requires the
    issuer's literal boolean email_verified=True without inferring legal identity.
    """
    def __init__(self, issuer, client_id, jwks, *, max_token_age=300, clock_skew=0):
        _issuer(issuer); _text(client_id, 512)
        _integer(max_token_age, True); _integer(clock_skew)
        _need(max_token_age <= 86400 and clock_skew <= 120, 'OIDC_TIME_POLICY')
        _need(type(jwks) is dict and set(jwks) == {'keys'} and type(jwks['keys']) is list
            and 1 <= len(jwks['keys']) <= 16, 'OIDC_JWKS')
        raw = _canonical(jwks)
        _need(len(raw) <= MAX_JWKS_BYTES, 'OIDC_JWKS_SIZE')
        keys = {}
        for key in jwks['keys']:
            public = _jwk(key)
            _need(key['kid'] not in keys, 'OIDC_DUPLICATE_KEY_ID')
            keys[key['kid']] = public
        self._issuer = issuer; self._client_id = client_id
        self._jwks = deepcopy(jwks); self._jwks_bytes = raw; self._keys = keys
        self._key_pins = {kid: key.public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
            for kid, key in keys.items()}
        self._max_token_age = max_token_age; self._clock_skew = clock_skew
        self._pin = self._configuration()
        self._pin_bytes = _canonical(self._pin)

    def _configuration(self):
        return dict(version=VERSION, issuer=self._issuer, client_id=self._client_id,
            algorithm='RS256', jwks_sha256=hashlib.sha256(self._jwks_bytes).hexdigest(),
            key_ids=sorted(self._keys), max_token_age=self._max_token_age, clock_skew=self._clock_skew,
            account_identity='EXACT_ISSUER_AND_SUBJECT_NOT_EMAIL_OR_LEGAL_IDENTITY',
            key_refresh='OWNER_REINSTALLS_EXACT_JWKS_NO_REMOTE_FETCH')

    def _unchanged(self):
        _need(_canonical(self._jwks) == self._jwks_bytes
            and _canonical(self._configuration()) == self._pin_bytes,
            'OIDC_CONFIGURATION_CHANGED')
        _need(set(self._keys) == set(self._key_pins)
            and all(key.public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo) == self._key_pins[kid]
                for kid, key in self._keys.items()), 'OIDC_CONFIGURATION_CHANGED')

    @property
    def manifest_config(self):
        self._unchanged()
        return deepcopy(self._pin)

    def verify(self, id_token, *, nonce, now, requirements=None):
        self._unchanged(); _text(nonce, 512); _integer(now)
        requirements = {} if requirements is None else deepcopy(requirements)
        _need(type(requirements) is dict and len(requirements) <= 32, 'OIDC_REQUIREMENTS')
        _json_value(requirements)
        _need(type(id_token) is str and id_token.isascii()
            and 0 < len(id_token) <= MAX_TOKEN_BYTES, 'OIDC_TOKEN_SIZE_OR_ENCODING')
        segments = id_token.split('.')
        _need(len(segments) == 3, 'OIDC_COMPACT_JWT')
        header = _decode_json(_base64url(segments[0], MAX_HEADER_BYTES), MAX_HEADER_BYTES)
        _need({'alg', 'kid'} <= set(header) <= {'alg', 'kid', 'typ'}, 'OIDC_HEADER_FIELDS')
        _need(header['alg'] == 'RS256', 'OIDC_ALGORITHM')
        _text(header['kid'], 128)
        _need('typ' not in header or header['typ'] == 'JWT', 'OIDC_TOKEN_TYPE')
        _need(header['kid'] in self._keys, 'OIDC_KEY_NOT_PINNED')
        public = self._keys[header['kid']]
        signature = _base64url(segments[2], MAX_RSA_BITS // 8)
        _need(len(signature) == (public.key_size + 7) // 8, 'OIDC_SIGNATURE_SIZE')
        try:
            public.verify(signature, (segments[0] + '.' + segments[1]).encode('ascii'),
                padding.PKCS1v15(), hashes.SHA256())
        except InvalidSignature:
            raise ValueError('OIDC_SIGNATURE') from None
        claims = _decode_json(_base64url(segments[1], MAX_CLAIMS_BYTES), MAX_CLAIMS_BYTES)
        _need({'iss', 'sub', 'aud', 'iat', 'exp', 'nonce'} <= set(claims), 'OIDC_REQUIRED_CLAIMS')
        _need(type(claims['iss']) is str and claims['iss'] == self._issuer, 'OIDC_ISSUER_MISMATCH')
        _text(claims['sub'], 255, True)
        _text(claims['nonce'], 512)
        _need(hmac.compare_digest(claims['nonce'].encode('utf-8'), nonce.encode('utf-8')), 'OIDC_NONCE_MISMATCH')
        audience = [claims['aud']] if type(claims['aud']) is str else claims['aud']
        _claim_type('aud', audience)
        _need(len(set(audience)) == len(audience) and self._client_id in audience, 'OIDC_AUDIENCE_MISMATCH')
        if len(audience) > 1:
            _need(type(claims.get('azp')) is str and claims['azp'] == self._client_id, 'OIDC_AUTHORIZED_PARTY')
        elif 'azp' in claims:
            _need(type(claims['azp']) is str and claims['azp'] == self._client_id, 'OIDC_AUTHORIZED_PARTY')
        _integer(claims['iat']); _integer(claims['exp'], True)
        skew = self._clock_skew
        _need(claims['iat'] < claims['exp'] and claims['iat'] <= now + skew
            and now < claims['exp'] + skew and now - claims['iat'] <= self._max_token_age + skew,
            'OIDC_TOKEN_TIME')
        if 'nbf' in claims:
            _integer(claims['nbf'])
            _need(claims['nbf'] <= now + skew and claims['nbf'] < claims['exp'], 'OIDC_NOT_BEFORE')
        if 'auth_time' in claims:
            _integer(claims['auth_time'])
            _need(claims['auth_time'] <= claims['iat'] + skew, 'OIDC_AUTHENTICATION_TIME')
        selected = {'iss': self._issuer, 'sub': claims['sub'], 'aud': deepcopy(audience),
            'iat': claims['iat'], 'exp': claims['exp']}
        for name, expected in requirements.items():
            _need(name in claims, 'OIDC_REQUESTED_CLAIM_MISSING')
            value = selected[name] if name in selected else claims[name]
            _claim_type(name, value)
            _need(_canonical(value) == _canonical(expected), 'OIDC_REQUESTED_CLAIM_MISMATCH')
            if name == 'email':
                _need(type(claims.get('email_verified')) is bool and claims['email_verified'] is True,
                    'OIDC_EMAIL_NOT_VERIFIED')
            selected[name] = deepcopy(value)
        return selected
