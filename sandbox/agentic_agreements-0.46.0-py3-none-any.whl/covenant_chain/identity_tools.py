"""Opt-in claim/identity preparation and checks; no accounts or services started.

Every action here prepares exact bytes or checks a document. None signs, submits,
spends, contacts an issuer or holds a key. Signing stays with the account holder
or the owner-run service named in each result.
"""
from .cooperation_interface import HASH, INT, OBJECT, schema, tool

NAMES = ('covenant_credential', 'covenant_signin', 'covenant_recovery', 'covenant_org')
STRING = {'type': 'string', 'minLength': 1, 'maxLength': 512}
LONG = {'type': 'string', 'minLength': 1, 'maxLength': 32768}
NULL_STRING = {'type': ['string', 'null'], 'maxLength': 256}
ARRAY = {'type': 'array', 'maxItems': 4096}
KEYS = {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': HASH}
POSITIVE = {'type': 'integer', 'minimum': 1, 'maximum': 2 ** 53 - 1}


def action_schema(actions):
    return {'type': 'object', 'oneOf': [
        schema({'action': {'const': name}, 'parameters': schema(properties, required)}, ('action', 'parameters'))
        for name, properties, required in actions]}


def specs():
    credential = [
        ('profile', {}, ()),
        ('policy', {'issuers': OBJECT, 'require': {'type': 'array', 'maxItems': 2,
                                                    'items': {'enum': ['verified_agent', 'principal_kyb']}},
                    'max_mandate': {'type': ['object', 'null']}, 'scope': NULL_STRING, 'audience': STRING},
         ('issuers', 'require', 'max_mandate', 'scope', 'audience')),
        ('request', {'chain': HASH, 'account': HASH, 'holder_keys': KEYS, 'mode': {'enum': ['SCOPED', 'BATCH']},
                     'scope': NULL_STRING, 'nonce': HASH}, ('chain', 'account', 'holder_keys', 'mode', 'scope', 'nonce')),
        ('verify', {'presentation': LONG, 'policy': OBJECT, 'nonce': STRING, 'now': INT},
         ('presentation', 'policy', 'nonce', 'now')),
    ]
    signin = [
        ('profile', {}, ()),
        ('pkce', {'code_verifier': STRING}, ('code_verifier',)),
        ('verify_id_token', {'id_token': LONG, 'issuer': STRING, 'client_id': STRING, 'jwks': OBJECT,
                             'nonce': STRING, 'now': INT}, ('id_token', 'issuer', 'client_id', 'jwks', 'nonce', 'now')),
        ('passkey_registration', {'account': HASH, 'chain': HASH, 'credential_id': STRING, 'public_key': STRING,
                                  'rp_id': STRING}, ('account', 'chain', 'credential_id', 'public_key', 'rp_id')),
        ('give_draft', {'consent': OBJECT, 'scope': STRING}, ('consent', 'scope')),
    ]
    recovery = [
        ('profile', {}, ()),
        ('guardian_kit', {'entity': HASH, 'guardians': OBJECT, 'delay': POSITIVE, 'threshold': POSITIVE},
         ('entity', 'guardians', 'delay', 'threshold')),
        ('prf_request', {'document': OBJECT}, ('document',)),
        ('verify_audit', {'entries': ARRAY, 'audit_public': HASH}, ('entries', 'audit_public')),
    ]
    org = [
        ('profile', {}, ()),
        ('create', {'org': HASH, 'chain': HASH, 'admins': KEYS, 'admin_quorum': POSITIVE,
                    'approval_quorum': POSITIVE}, ('org', 'chain', 'admins', 'admin_quorum', 'approval_quorum')),
        ('next', {'log': ARRAY, 'kind': {'enum': ['ROLE_GRANT', 'ROLE_REVOKE']}, 'change': OBJECT},
         ('log', 'kind', 'change')),
        ('roles', {'log': ARRAY, 'height': {'type': ['integer', 'null'], 'minimum': 0}}, ('log', 'height')),
        ('mandate', {'log': ARRAY, 'member': HASH, 'height': INT}, ('log', 'member', 'height')),
        ('decide', {'log': ARRAY, 'request': OBJECT, 'approvals': ARRAY}, ('log', 'request', 'approvals')),
        ('export_request', {'log': ARRAY, 'requester': HASH, 'as_of': INT}, ('log', 'requester', 'as_of')),
        ('audit_export', {'log': ARRAY, 'requester': HASH, 'signature': STRING, 'as_of': INT},
         ('log', 'requester', 'signature', 'as_of')),
    ]
    return [
        tool('covenant_credential',
             'Selectively disclosed SD-JWT issuer claims; not zero knowledge, anonymity or unlinkability. Build a pinned verifier policy, prepare exact issuance requests or verify a presentation. Issuers, holder keys, scopes, disclosed claims and transport metadata can correlate. Verification returns a nullifier to check and record separately; it proves no legal identity, unique person, current spending authority or external truth.',
             action_schema(credential), readonly=True, idempotent=True),
        tool('covenant_signin',
             'Offline opt-in sign-in preparation and pinned OIDC token checks. Compute PKCE S256, check a pinned issuer token with audience/nonce at caller-supplied time, or prepare registration and unsigned GIVE drafts. No OAuth service starts, credential is issued, key is held, live authority is checked or transaction submitted.',
             action_schema(signin), readonly=True, idempotent=True),
        tool('covenant_recovery',
             'Key recovery for ordinary users: prepare a guardian continuity kit, the WebAuthn PRF request that unlocks a passkey-wrapped key, or verify a hosted-wallet audit log. Hosted wallets are custodial; the trust boundary is in every result.',
             action_schema(recovery), readonly=True, idempotent=True),
        tool('covenant_org',
             'Prepare org role changes and unsigned native GIVE payloads, verify supplied signed role logs, or review declared spending approval quorums. Caller supplies snapshot and height; no completeness or currentness is established, no native grant is observed and no spending authority or signature is created.',
             action_schema(org), readonly=True, idempotent=True),
    ]


def call(name, action, p):
    if name == 'covenant_credential':
        from . import hidden_credentials as hc
        if action == 'profile':
            return hc.profile()
        if action == 'policy':
            policy = hc.make_policy(**p)
            return {'policy': policy, 'id': hc.policy_id(policy), 'execution_authorized': False}
        if action == 'request':
            body = hc.issuance_request(p['chain'], p['account'], p['holder_keys'], mode=p['mode'], scope=p['scope'],
                                       nonce=p['nonce'])
            return {'body': body, 'label': hc.REQUEST_LABEL, 'signer': p['account'], 'signed': False,
                    'execution_authorized': False}
        return hc.verify_presentation(p['presentation'], p['policy'], nonce=p['nonce'], now=p['now'])
    if name == 'covenant_signin':
        from . import signin
        if action == 'profile':
            return signin.profile()
        if action == 'pkce':
            return {'code_challenge': signin.pkce_challenge(p['code_verifier']), 'code_challenge_method': 'S256',
                    'execution_authorized': False}
        if action == 'verify_id_token':
            return signin.relying_party_check(p['id_token'], issuer=p['issuer'], client_id=p['client_id'],
                                              jwks=p['jwks'], nonce=p['nonce'], now=p['now'])
        if action == 'passkey_registration':
            body = signin.passkey_registration(**p)
            return {'body': body, 'label': signin.PASSKEY_LABEL, 'signer': p['account'], 'signed': False,
                    'execution_authorized': False}
        return {'give': signin.give_payload(p['consent'], p['scope']), 'signed': False, 'execution_authorized': False}
    if name == 'covenant_recovery':
        from . import key_recovery as kr
        if action == 'profile':
            return kr.profile()
        if action == 'guardian_kit':
            return kr.guardian_kit(p['entity'], p['guardians'], delay=p['delay'], threshold=p['threshold'])
        if action == 'prf_request':
            return {**kr.prf_request(p['document']), 'execution_authorized': False}
        return kr.verify_audit_log(p['entries'], p['audit_public'])
    if name == 'covenant_org':
        from . import org_accounts as org
        if action == 'profile':
            return org.profile()
        if action == 'create':
            body = org.create_body(p['org'], p['chain'], p['admins'], admin_quorum=p['admin_quorum'],
                                   approval_quorum=p['approval_quorum'])
            return {'body': body, 'label': org.ENTRY_LABEL, 'signer': p['org'], 'signed': False,
                    'execution_authorized': False}
        if action == 'next':
            body = org.next_body(p['log'], p['kind'], p['change'])
            return {'body': body, 'label': org.ENTRY_LABEL, 'signers': 'ADMIN_QUORUM', 'signed': False,
                    'execution_authorized': False}
        if action == 'roles':
            return org.roles(p['log'], height=p['height'])
        if action == 'mandate':
            return org.give_payloads(p['log'], p['member'], p['height'])
        if action == 'decide':
            return org.spend_decision(p['log'], p['request'], p['approvals'])
        if action == 'export_request':
            body = org.export_request(p['log'], p['requester'], as_of=p['as_of'])
            return {'body': body, 'label': org.EXPORT_LABEL, 'signer': p['requester'], 'signed': False,
                    'execution_authorized': False}
        return org.audit_export(p['log'], p['requester'], p['signature'], as_of=p['as_of'])
    raise ValueError('IDENTITY_TOOL')
