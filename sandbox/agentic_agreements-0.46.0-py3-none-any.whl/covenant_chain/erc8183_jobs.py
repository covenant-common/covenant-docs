"""ERC-8183 Agentic Commerce jobs bound to AAP work orders, with appeals before release.

BOTH. GRAFT: an AAP open-rail work order (covenant-bilateral/0.3, rail
``urn:aap:rail:erc8183:1``) binds unchanged to one ERC-8183 job (ERC-8183
"Agentic Commerce", Draft, ethereum/ERCs ERCS/erc-8183.md; reference
implementation added at commit a078cab5, 13 March 2026; CC0): a job with an
escrowed ERC-20 budget, one evaluator and the states Open, Funded, Submitted,
Completed, Rejected and Expired. ``calls`` returns the job parameters as
calldata the owner may submit; ``job`` replays supplied job events (logs or
receipt proofs, see ``evm_evidence``) through the ERC-8183 state machine and
checks them against the pinned contract and the signed binding.

Implementations disagree on the wire: the ERC's reference contract uses
``uint256 expiredAt`` while github.com/erc-8183/base-contracts (commit
142e669c, MIT) uses ``uint48`` and per-job tokens, so selectors and event
topics differ (ERCs pull request 1732). The binding therefore names one exact
ABI profile and anything else is refused, not guessed.

TAKE-AND-IMPROVE: in ERC-8183 the evaluator's complete or reject is final
("reject/expire is final", Security Considerations). Parties who want an appeal
before release name an AAP ladder in the binding and make the evaluator an
AAP party who signs it. The evaluator's decision is then first an AAP-signed
evaluation, cited at the ladder's agreed stage; ``release`` produces complete
or reject calldata only from the ladder's final outcome, and ``conformance``
shows whether the on-chain decision followed it. On-chain events are evidence;
AAP never signs, submits or pays, and cannot stop an evaluator from calling
the contract early: it records that as a breach of the signed binding.
"""
from copy import deepcopy
import hashlib
import re

from . import arbitration_interop as interop
from . import evm_evidence as evm
from .crypto import canonical, digest, key, need, verification_key, verify

VERSION = 'urn:aap:erc8183-binding:0.1'
LABEL = 'AAP-ERC8183-BINDING-0.1'
EVALUATION = 'urn:aap:erc8183-evaluation:0.1'
EVALUATION_LABEL = 'AAP-ERC8183-EVALUATION-0.1'
RECORD = 'urn:aap:erc8183-evaluation-evidence:0.1'
RAIL = 'urn:aap:rail:erc8183:1'
ORDER_PROFILE = 'covenant-bilateral/0.3'
ZERO = '0x' + '00' * 20
STATES = ('Open', 'Funded', 'Submitted', 'Completed', 'Rejected', 'Expired')
DECISIONS = ('COMPLETE', 'REJECT')
FIELDS = ('version order abi network contract token client provider evaluator hook budget expired_at description '
          'provider_agent_id evaluator_key appeal required_assurance')
_COMMON_EVENTS = {
    'JobFunded': ('JobFunded(uint256,address,uint256)', (True, True, False)),
    'JobSubmitted': ('JobSubmitted(uint256,address,bytes32)', (True, True, False)),
    'JobCompleted': ('JobCompleted(uint256,address,bytes32)', (True, True, False)),
    'JobRejected': ('JobRejected(uint256,address,bytes32)', (True, True, False)),
    'JobExpired': ('JobExpired(uint256)', (True,)),
    'PaymentReleased': ('PaymentReleased(uint256,address,uint256)', (True, True, False)),
    'EvaluatorFeePaid': ('EvaluatorFeePaid(uint256,address,uint256)', (True, True, False)),
    'Refunded': ('Refunded(uint256,address,uint256)', (True, True, False)),
}
PROFILES = {
    # ethereum/ERCs ERCS/erc-8183.md, "Reference Implementation" AgenticCommerce.sol, commit a078cab5 (2026-03-13).
    'erc-8183/reference@a078cab5': {
        'source': 'https://github.com/ethereum/ERCs/blob/a078cab5cc8e9581c15f76c091ed96eed28f02f7/ERCS/erc-8183.md',
        'token': 'CONTRACT_WIDE', 'agent_id': False, 'open_rejectors': ('client',),
        'functions': {'createJob': 'createJob(address,address,uint256,string,address)',
                      'setProvider': 'setProvider(uint256,address)', 'setBudget': 'setBudget(uint256,uint256,bytes)',
                      'fund': 'fund(uint256,bytes)', 'submit': 'submit(uint256,bytes32,bytes)',
                      'complete': 'complete(uint256,bytes32,bytes)', 'reject': 'reject(uint256,bytes32,bytes)',
                      'claimRefund': 'claimRefund(uint256)'},
        'events': {'JobCreated': ('JobCreated(uint256,address,address,address,uint256,address)', (True, True, True, False, False, False)),
                   'ProviderSet': ('ProviderSet(uint256,address)', (True, True)),
                   'BudgetSet': ('BudgetSet(uint256,uint256)', (True, False)), **_COMMON_EVENTS},
        'unsupported': ()},
    # github.com/erc-8183/base-contracts contracts/ERC8183.sol, commit 142e669c (MIT).
    'erc-8183/base-contracts@142e669c': {
        'source': 'https://github.com/erc-8183/base-contracts/blob/142e669c/contracts/ERC8183.sol',
        'token': 'PER_JOB', 'agent_id': True, 'open_rejectors': ('client', 'provider'),
        'functions': {'createJob': 'createJob(address,address,uint48,string,address,uint256)',
                      'setProvider': 'setProvider(uint256,address,uint256)',
                      'setBudget': 'setBudget(uint256,address,uint256,bytes)',
                      'fund': 'fund(uint256,address,uint256,bytes)', 'submit': 'submit(uint256,bytes32,bytes)',
                      'complete': 'complete(uint256,bytes32,bytes)', 'reject': 'reject(uint256,bytes32,bytes)',
                      'claimRefund': 'claimRefund(uint256)'},
        'events': {'JobCreated': ('JobCreated(uint256,address,address,address,uint48,address)', (True, True, True, False, False, False)),
                   'ProviderSet': ('ProviderSet(uint256,address,uint256)', (True, True, False)),
                   'BudgetSet': ('BudgetSet(uint256,address,uint256)', (True, True, False)),
                   'PlatformFeePaid': ('PlatformFeePaid(uint256,address,uint256)', (True, True, False)), **_COMMON_EVENTS},
        # Extensions AAP does not interpret for a bound job: payouts elsewhere and partial claims.
        'unsupported': ('PayoutReceiverSet(uint256,address)', 'Disbursed(uint256,address,bytes4,uint256)',
                        'Settled(uint256,uint256,uint256)', 'ClaimSubmitted(uint256,address,uint256,uint256,bytes32,bytes)',
                        'ClaimSettled(uint256,address,uint256,uint256,bytes32)', 'ClaimApproved(uint256,address,uint256,uint256,bytes32)',
                        'ClaimRejected(uint256,address,bytes32)', 'HookDetached(uint256,address)')},
}
FLAGS = {'authority': 'EVIDENCE_ONLY', 'execution_authorized': False, 'submitted': False, 'signed': False,
         'network_accessed': False}

REMEDIATION = {
    'ERC8183_BINDING': 'Use exactly the binding fields of binding_draft; addresses lowercase 0x, amounts integers.',
    'ERC8183_VERSION': 'Use urn:aap:erc8183-binding:0.1; a meaning change needs a new version string.',
    'ERC8183_ABI_PROFILE': 'Name one supported ABI profile exactly; implementations differ in selectors and event topics.',
    'ERC8183_ORDER': 'Pass the bound covenant-bilateral/0.3 order whose id the binding names, paying through rail urn:aap:rail:erc8183:1.',
    'ERC8183_ORDER_TERMS': 'The order rail must name this network, the token as asset, the provider as payee and the budget as quantity.',
    'ERC8183_EXPIRY': 'expired_at must be after the order deadline and fit the profile integer width.',
    'ERC8183_APPEAL': 'An appeal needs {ladder (PROCEDURE), customer_role, provider_role, outcomes {COMPLETE, REJECT}} and an evaluator_key.',
    'ERC8183_SIGNATURES': 'Customer and provider, and the evaluator when evaluator_key is set, each sign the exact binding once.',
    'ERC8183_JOB_NOT_FOUND': 'No JobCreated event from the pinned contract matches the binding; supply it.',
    'ERC8183_AMBIGUOUS_JOB': 'Several jobs match the binding; pass job_id to choose the one both parties adopted.',
    'ERC8183_TRANSITION': 'The supplied events do not follow the ERC-8183 state machine for this job.',
    'ERC8183_ROLE': 'An event names a different client, provider, evaluator or token from the binding.',
    'ERC8183_AMOUNT': 'Funding, payment or refund amounts differ from the bound budget.',
    'ERC8183_EXTENSION_UNSUPPORTED': 'The job used an extension AAP does not interpret (payout receiver, partial claims); it is refused, not ignored.',
    'ERC8183_ASSURANCE': 'The events do not reach the assurance the binding requires; pass receipt proofs under pinned blocks.',
    'ERC8183_DECISION': 'Name COMPLETE or REJECT with 32-byte deliverable and reason hashes.',
    'ERC8183_EVALUATION': 'Pass the evaluation body and the evaluator signature over it.',
    'ERC8183_RECORD': 'Pass the exact evaluation evidence record and its id.',
    'ERC8183_APPEAL_OPEN': 'The ladder has no final outcome yet; release waits for it.',
    'ERC8183_OUTCOME_NOT_EXPRESSIBLE': 'ERC-8183 releases all or nothing; this outcome is neither the agreed COMPLETE nor REJECT result.',
    'ERC8183_NO_APPEAL': 'This binding names no AAP appeal; the on-chain evaluator decides alone.',
    'INTEROP_LADDER':
        'Name a PROCEDURE policy id and stage, or a PANEL agreement id and PRIMARY or APPEAL, and pass that '
        'ladder.',
}


def remediation(code):
    return REMEDIATION.get(code, evm.remediation(code))


def _address(value, code='ERC8183_BINDING'):
    try:
        normal = evm.address(value)
    except ValueError:
        raise ValueError(code) from None
    need(normal == value, code)
    return value


def _profile(name):
    need(type(name) is str and name in PROFILES, 'ERC8183_ABI_PROFILE')
    return PROFILES[name]


def description_for(order_id, task):
    """The job description: the AAP order id and the SHA-256 of its task text, nothing else."""
    key(order_id)
    need(type(task) is str, 'ERC8183_ORDER')
    return 'AAP work order %s task sha256 %s' % (order_id, hashlib.sha256(task.encode('utf-8')).hexdigest())


def _order(order, order_id):
    from covenant_agent import open_work
    try:
        info = open_work.inspect(order, order_id)
    except (ValueError, KeyError, TypeError):
        raise ValueError('ERC8183_ORDER') from None
    need(info['status'] == 'BOUND' and order['body']['profile'] == ORDER_PROFILE, 'ERC8183_ORDER')
    return order['body']


def validate_binding(binding):
    need(type(binding) is dict and set(binding) == set(FIELDS.split()), 'ERC8183_BINDING')
    need(binding['version'] == VERSION, 'ERC8183_VERSION')
    profile = _profile(binding['abi'])
    key(binding['order']); evm.network(binding['network'])
    for name in ('contract', 'token', 'client', 'provider', 'evaluator', 'hook'):
        _address(binding[name])
    need(len({binding['client'], binding['provider'], binding['evaluator']}) == 3 or binding['evaluator'] == binding['client'], 'ERC8183_BINDING')
    need(ZERO not in (binding['contract'], binding['token'], binding['client'], binding['provider'], binding['evaluator']), 'ERC8183_BINDING')
    need(type(binding['budget']) is int and 0 < binding['budget'] < 2**256, 'ERC8183_BINDING')
    width = 48 if binding['abi'].startswith('erc-8183/base-contracts') else 256
    need(type(binding['expired_at']) is int and 0 < binding['expired_at'] < 2**width, 'ERC8183_EXPIRY')
    need(type(binding['description']) is str and 0 < len(binding['description']) <= 2048, 'ERC8183_BINDING')
    if profile['agent_id']:
        need(type(binding['provider_agent_id']) is int and 0 <= binding['provider_agent_id'] < 2**256, 'ERC8183_BINDING')
    else:
        need(binding['provider_agent_id'] is None, 'ERC8183_BINDING')
    if binding['evaluator_key'] is not None:
        need(type(binding['evaluator_key']) is str, 'ERC8183_BINDING'); verification_key(binding['evaluator_key'])
    appeal = binding['appeal']
    if appeal is not None:
        need(binding['evaluator_key'] is not None and type(appeal) is dict
             and set(appeal) == {'ladder', 'customer_role', 'provider_role', 'outcomes'}, 'ERC8183_APPEAL')
        interop.ladder_reference(appeal['ladder'])
        need(appeal['ladder']['kind'] == 'PROCEDURE' and appeal['customer_role'] != appeal['provider_role'], 'ERC8183_APPEAL')
        for role in (appeal['customer_role'], appeal['provider_role']):
            need(type(role) is str and re.fullmatch(r'[A-Za-z][A-Za-z0-9_.:-]{0,63}', role) is not None, 'ERC8183_APPEAL')
        need(type(appeal['outcomes']) is dict and set(appeal['outcomes']) == set(DECISIONS), 'ERC8183_APPEAL')
        for result in appeal['outcomes'].values():
            interop.ladder_result('PROCEDURE', result, 'ERC8183_APPEAL')
        need(canonical(appeal['outcomes']['COMPLETE']) != canonical(appeal['outcomes']['REJECT']), 'ERC8183_APPEAL')
    need(binding['required_assurance'] in evm.ASSURANCE, 'ERC8183_ASSURANCE')
    need(len(canonical(binding)) <= 65536, 'ERC8183_BINDING')
    return binding


def binding_id(binding):
    return digest(LABEL, validate_binding(binding))


def _consistent(binding, body):
    terms, payment = body['terms'], body['terms']['payment']
    need(payment['identifier'] == RAIL and payment['network'] == binding['network']
         and payment['asset'] == binding['token'] and payment['payee'] == binding['provider']
         and terms['quantity'] == binding['budget'], 'ERC8183_ORDER_TERMS')
    need(binding['expired_at'] > terms['deadline'], 'ERC8183_EXPIRY')
    need(binding['description'] == description_for(binding['order'], terms['task']), 'ERC8183_BINDING')


def binding_draft(order, order_id, *, abi, contract, client, evaluator, expired_at, hook=ZERO, evaluator_key=None,
                  appeal=None, provider_agent_id=None, required_assurance=evm.ASSURANCE[0]):
    """The exact binding the customer, the provider and an AAP-bound evaluator sign. Nothing is signed or sent."""
    body = _order(order, order_id)
    payment = body['terms']['payment']
    binding = {'version': VERSION, 'order': order_id, 'abi': abi, 'network': payment['network'], 'contract': contract,
               'token': payment['asset'], 'client': client, 'provider': payment['payee'], 'evaluator': evaluator, 'hook': hook,
               'budget': body['terms']['quantity'], 'expired_at': expired_at,
               'description': description_for(order_id, body['terms']['task']), 'provider_agent_id': provider_agent_id,
               'evaluator_key': evaluator_key, 'appeal': deepcopy(appeal), 'required_assurance': required_assurance}
    ident = binding_id(binding)
    _consistent(binding, body)
    signers = {'customer': body['customer'], 'provider': body['provider']}
    if evaluator_key is not None:
        signers['evaluator'] = evaluator_key
    return {'binding': binding, 'id': ident, 'signing_payload': {'label': LABEL, 'body': deepcopy(binding)},
            'required_signers': signers, **FLAGS}


def adopt(binding, signatures, order, *, policy=None):
    """Every required party signed the exact binding; it matches the order and, with an appeal, the ladder."""
    ident = binding_id(binding)
    body = _order(order, binding['order'])
    _consistent(binding, body)
    signers = {'customer': body['customer'], 'provider': body['provider']}
    if binding['evaluator_key'] is not None:
        signers['evaluator'] = binding['evaluator_key']
    need(type(signatures) is list and len(signatures) == len(signers), 'ERC8183_SIGNATURES')
    seen = set()
    for row in signatures:
        need(type(row) is dict and set(row) == {'signer', 'signature'} and row['signer'] in signers
             and row['signer'] not in seen, 'ERC8183_SIGNATURES')
        verify(signers[row['signer']], LABEL, binding, row['signature'])
        seen.add(row['signer'])
    appeal = binding['appeal']
    if appeal is not None:
        sides = {'claimant': {'role': appeal['provider_role'], 'key': body['provider']},
                 'respondent': {'role': appeal['customer_role'], 'key': body['customer']}}
        interop.check_ladder(appeal['ladder'], sides, list(appeal['outcomes'].values()), policy=policy)
    return {'binding': deepcopy(binding), 'id': ident, 'signed_by': sorted(seen), 'customer': body['customer'],
            'provider_key': body['provider'], **FLAGS}


# Job parameters ----------------------------------------------------------------------

def _call(binding, step, sender, to, signature, values):
    return {'step': step, 'from': sender, 'to': to, 'function': signature, 'value': 0,
            'calldata': '0x' + evm.calldata(signature, values).hex()}


def calls(binding, signatures, order, *, job_id=None, deliverable=None, policy=None):
    """The job parameters as calldata: create, approve, budget, fund and (with a deliverable) submit.

    The owner reviews and submits each call from the named account, or does not.
    Calls needing the job id appear once the caller passes the id JobCreated reported.
    """
    adopted = adopt(binding, signatures, order, policy=policy)
    profile = _profile(binding['abi'])['functions']
    create = [binding['provider'], binding['evaluator'], binding['expired_at'], binding['description'], binding['hook']]
    if binding['provider_agent_id'] is not None:
        create.append(binding['provider_agent_id'])
    out = [_call(binding, 'create', binding['client'], binding['contract'], profile['createJob'], create),
           _call(binding, 'approve', binding['client'], binding['token'], 'approve(address,uint256)',
                 [binding['contract'], binding['budget']])]
    if job_id is not None:
        need(type(job_id) is int and 0 < job_id < 2**256, 'ERC8183_BINDING')
        if binding['abi'].startswith('erc-8183/base-contracts'):
            out += [_call(binding, 'budget', binding['provider'], binding['contract'], profile['setBudget'],
                          [job_id, binding['token'], binding['budget'], b'']),
                    _call(binding, 'fund', binding['client'], binding['contract'], profile['fund'],
                          [job_id, binding['token'], binding['budget'], b''])]
        else:
            out += [_call(binding, 'budget', binding['provider'], binding['contract'], profile['setBudget'], [job_id, binding['budget'], b'']),
                    _call(binding, 'fund', binding['client'], binding['contract'], profile['fund'], [job_id, b''])]
        if deliverable is not None:
            out.append(_call(binding, 'submit', binding['provider'], binding['contract'], profile['submit'],
                             [job_id, evm.hex_word(deliverable, 'ERC8183_DECISION'), b'']))
        out.append(_call(binding, 'refund_after_expiry', 'ANYONE_AFTER_EXPIRED_AT', binding['contract'], profile['claimRefund'], [job_id]))
    return {'binding': adopted['id'], 'abi': binding['abi'], 'network': binding['network'], 'calls': out,
            'note': 'Unsigned calldata; AAP signs, submits and pays nothing. A release is only from release() after the ladder.', **FLAGS}


# Job events ------------------------------------------------------------------------------

def _decode(binding, logs):
    profile = _profile(binding['abi'])
    topics = {evm.topic(signature): (name, signature, indexed) for name, (signature, indexed) in profile['events'].items()}
    unsupported = {evm.topic(signature) for signature in profile['unsupported']}
    rows = []
    for log in logs:
        if log['address'] != binding['contract'] or not log['topics']:
            continue
        need(log['topics'][0] not in unsupported, 'ERC8183_EXTENSION_UNSUPPORTED')
        if log['topics'][0] not in topics:
            continue
        name, signature, indexed = topics[log['topics'][0]]
        rows.append((name, evm.event(log, signature, indexed), log))
    return rows


def _created(binding, values):
    job_id, client, provider, evaluator, expired_at, hook = values
    return (client == binding['client'] and provider in (binding['provider'], ZERO) and evaluator == binding['evaluator']
            and expired_at == binding['expired_at'] and hook == binding['hook']), job_id


def job(binding, signatures, order, evidence, *, trusted_blocks=(), job_id=None, policy=None):
    """Replay supplied events for the bound job through the ERC-8183 state machine."""
    adopted = adopt(binding, signatures, order, policy=policy)
    logs = evm.logs(evidence, network_id=binding['network'], trusted_blocks=trusted_blocks)
    rows = _decode(binding, logs)
    candidates = sorted({jid for name, values, _ in rows if name == 'JobCreated' for ok, jid in [_created(binding, values)] if ok})
    if job_id is not None:
        need(job_id in candidates, 'ERC8183_JOB_NOT_FOUND')
    else:
        need(candidates, 'ERC8183_JOB_NOT_FOUND')
        need(len(candidates) == 1, 'ERC8183_AMBIGUOUS_JOB')
        job_id = candidates[0]
    mine = [(name, values, log) for name, values, log in rows if values[0] == job_id]
    state, provider, budget, assurance = None, None, None, evm.ASSURANCE[0]
    deliverable = decision = None
    funded_at_rejection = True
    paid = refunded = fees = 0
    sources = []
    for name, values, log in mine:
        if log['assurance'] != evm.ASSURANCE[0]:
            assurance = evm.ASSURANCE[1]
        sources.append({'block_hash': log['block_hash'], 'transaction_index': log['transaction_index'],
                        'log_index_in_receipt': log['log_index_in_receipt'], 'event': name, 'assurance': log['assurance']})
        if name == 'JobCreated':
            need(state is None and _created(binding, values)[0], 'ERC8183_TRANSITION')
            state, provider = 'Open', values[2]
        elif name == 'ProviderSet':
            need(state == 'Open' and provider == ZERO and values[1] == binding['provider'], 'ERC8183_TRANSITION')
            provider = values[1]
        elif name == 'BudgetSet':
            need(state == 'Open', 'ERC8183_TRANSITION')
            if len(values) == 3:
                need(values[1] == binding['token'], 'ERC8183_ROLE')
            budget = values[-1]
        elif name == 'JobFunded':
            need(state == 'Open' and provider == binding['provider'] and values[1] == binding['client'], 'ERC8183_TRANSITION')
            need(values[2] == binding['budget'] and budget in (None, binding['budget']), 'ERC8183_AMOUNT')
            state = 'Funded'
        elif name == 'JobSubmitted':
            need(state == 'Funded' and values[1] == binding['provider'], 'ERC8183_TRANSITION')
            state, deliverable = 'Submitted', '0x' + values[2].hex()
        elif name == 'JobCompleted':
            need(state == 'Submitted' and values[1] == binding['evaluator'], 'ERC8183_TRANSITION')
            state, decision = 'Completed', {'decision': 'COMPLETE', 'by': values[1], 'reason': '0x' + values[2].hex()}
        elif name == 'JobRejected':
            allowed = ({binding[role] for role in _profile(binding['abi'])['open_rejectors']} if state == 'Open'
                       else {binding['evaluator']})
            need(state in ('Open', 'Funded', 'Submitted') and values[1] in allowed, 'ERC8183_TRANSITION')
            funded_at_rejection = state != 'Open'
            state, decision = 'Rejected', {'decision': 'REJECT', 'by': values[1], 'reason': '0x' + values[2].hex()}
        elif name == 'JobExpired':
            need(state in ('Funded', 'Submitted'), 'ERC8183_TRANSITION')
            state, decision = 'Expired', {'decision': 'EXPIRED', 'by': None, 'reason': None}
        elif name == 'PaymentReleased':
            # Money events are tallied without order: implementations emit them before or after the decision.
            need(values[1] == binding['provider'], 'ERC8183_ROLE')
            paid += values[2]
        elif name == 'Refunded':
            need(values[1] == binding['client'], 'ERC8183_ROLE')
            refunded += values[2]
        else:
            fees += values[2]
    need(state is not None, 'ERC8183_JOB_NOT_FOUND')
    if state == 'Completed':
        need(refunded == 0 and paid + fees == binding['budget'], 'ERC8183_AMOUNT')
    elif state in ('Rejected', 'Expired'):
        need(paid == 0 and fees == 0 and refunded == (binding['budget'] if funded_at_rejection else 0), 'ERC8183_AMOUNT')
    else:
        need(paid == refunded == fees == 0, 'ERC8183_TRANSITION')
    need(evm.ASSURANCE.index(assurance) <= evm.ASSURANCE.index(binding['required_assurance']), 'ERC8183_ASSURANCE')
    return {'binding': adopted['id'], 'job_id': job_id, 'state': state, 'terminal': state in STATES[3:],
            'deliverable': deliverable, 'decision': decision, 'paid_to_provider': paid, 'refunded_to_client': refunded,
            'fees': fees, 'assurance': assurance, 'events': len(mine), 'sources': sources,
            'finality': 'ERC-8183 treats complete, reject and expiry as final; AAP records them as evidence',
            'token_check': 'PER_JOB_EVENT' if _profile(binding['abi'])['token'] == 'PER_JOB' else 'CONTRACT_WIDE_NOT_IN_EVENTS',
            **FLAGS}


# Evaluation before release ---------------------------------------------------------------

def _decision(decision, deliverable, reason):
    need(decision in DECISIONS, 'ERC8183_DECISION')
    return '0x' + evm.hex_word(deliverable, 'ERC8183_DECISION').hex(), '0x' + evm.hex_word(reason, 'ERC8183_DECISION').hex()


def evaluation_payload(binding, signatures, order, *, job_id, decision, deliverable, reason, policy=None):
    """What an AAP-bound evaluator signs instead of calling complete or reject at once."""
    adopted = adopt(binding, signatures, order, policy=policy)
    need(binding['appeal'] is not None, 'ERC8183_NO_APPEAL')
    need(type(job_id) is int and 0 < job_id < 2**256, 'ERC8183_BINDING')
    deliverable, reason = _decision(decision, deliverable, reason)
    body = {'version': EVALUATION, 'binding': adopted['id'], 'job': str(job_id), 'decision': decision,
            'deliverable': deliverable, 'reason': reason}
    return {'label': EVALUATION_LABEL, 'body': body, 'required_signer': binding['evaluator_key'], **FLAGS}


def record_id(record):
    from covenant_language.agreement_application import content_id
    return content_id(RECORD, record)


def evaluation_record(binding, signatures, order, evaluation, *, policy=None):
    """The evaluator's signed decision as evidence for the agreed ladder stage, with the parties' mapped result."""
    adopted = adopt(binding, signatures, order, policy=policy)
    need(binding['appeal'] is not None, 'ERC8183_NO_APPEAL')
    need(type(evaluation) is dict and set(evaluation) == {'body', 'signature'} and type(evaluation['body']) is dict
         and set(evaluation['body']) == {'version', 'binding', 'job', 'decision', 'deliverable', 'reason'}, 'ERC8183_EVALUATION')
    body = evaluation['body']
    need(body['version'] == EVALUATION and body['binding'] == adopted['id'] and type(body['job']) is str
         and re.fullmatch(r'[1-9][0-9]{0,77}', body['job']) is not None, 'ERC8183_EVALUATION')
    _decision(body['decision'], body['deliverable'], body['reason'])
    verify(binding['evaluator_key'], EVALUATION_LABEL, body, evaluation['signature'])
    record = {'version': RECORD, 'binding': adopted['id'], 'ladder': deepcopy(binding['appeal']['ladder']),
              'evaluation': digest(EVALUATION_LABEL, body), 'job': body['job'], 'decision': body['decision'],
              'deliverable': body['deliverable'], 'reason': body['reason'],
              'mapped_result': deepcopy(binding['appeal']['outcomes'][body['decision']])}
    ident = record_id(record)
    return {'record': record, 'id': ident, 'evidence_reference': ident, **FLAGS}


def ladder_step(binding, signatures, order, record, expected_record, policy, adoptions, events, *, actor, at, bond_receipt=None):
    """The one ladder event the evaluation supports, unsigned.

    Before any dispute a disputant OPENs the ladder citing the evaluation, with
    its mapped result; once open, the record enters the agreed stage as a
    CHALLENGE or a decider's VOTE. The actor signs; the ladder decides.
    """
    from covenant_language import agreement_procedures as procedures
    adopt(binding, signatures, order, policy=policy)
    need(binding['appeal'] is not None, 'ERC8183_NO_APPEAL')
    need(type(record) is dict and record.get('version') == RECORD and record_id(record) == expected_record
         and record['binding'] == binding_id(binding) and record['ladder'] == binding['appeal']['ladder'], 'ERC8183_RECORD')
    ladder = binding['appeal']['ladder']
    state = procedures.replay(policy, adoptions, events)
    if state['round'] is None and policy['configuration']['stages'][0]['name'] == ladder['stage']:
        arguments = {'claim': expected_record, 'result': deepcopy(record['mapped_result']), 'bond_receipt': bond_receipt}
        payload = procedures.event_payload(policy, adoptions, events, actor, 'OPEN', arguments, at)
        return {'event_payload': payload, 'action': 'OPEN', 'stage': ladder['stage'], 'record': expected_record,
                'decides_escrow': False, 'note': 'The disputant signs this OPEN; the ladder then runs its windows.', **FLAGS}
    return interop.procedure_step(ladder, expected_record, record['mapped_result'], policy, adoptions, events,
                                  actor=actor, at=at, bond_receipt=bond_receipt)


def _final(binding, policy, adoptions, events, expected_head):
    from covenant_language import agreement_procedures as procedures
    need(binding['appeal'] is not None, 'ERC8183_NO_APPEAL')
    need(procedures.identifier(policy) == binding['appeal']['ladder']['id'], 'INTEROP_LADDER')
    state = procedures.replay(policy, adoptions, events, expected_head)
    if state['status'] != 'FINAL_ATTESTED_OUTCOME':
        return state, None
    outcome = canonical(state['outcome'])
    found = [name for name, result in binding['appeal']['outcomes'].items() if canonical(result) == outcome]
    return state, (found[0] if found else 'NOT_EXPRESSIBLE')


def release(binding, signatures, order, policy, adoptions, events, *, job_id, expected_head=None):
    """complete or reject calldata from the ladder's final outcome; the evaluator submits it, or does not."""
    adopted = adopt(binding, signatures, order, policy=policy)
    need(type(job_id) is int and 0 < job_id < 2**256, 'ERC8183_BINDING')
    state, decision = _final(binding, policy, adoptions, events, expected_head)
    need(decision is not None, 'ERC8183_APPEAL_OPEN')
    need(decision != 'NOT_EXPRESSIBLE', 'ERC8183_OUTCOME_NOT_EXPRESSIBLE')
    profile = _profile(binding['abi'])['functions']
    reason = bytes.fromhex(state['head'])
    call = _call(binding, decision.lower(), binding['evaluator'], binding['contract'],
                 profile['complete' if decision == 'COMPLETE' else 'reject'], [job_id, reason, b''])
    return {'binding': adopted['id'], 'job_id': job_id, 'decision': decision, 'ladder_head': state['head'],
            'reason': '0x' + state['head'], 'call': call, 'outcome': deepcopy(state['outcome']),
            'note': 'The reason field carries the final ladder head so anyone can match the on-chain decision to it.', **FLAGS}


def conformance(binding, signatures, order, evidence, policy, adoptions, events, *, trusted_blocks=(), job_id=None, expected_head=None):
    """Whether the on-chain decision followed the ladder: evidence, never a reversal."""
    observed = job(binding, signatures, order, evidence, trusted_blocks=trusted_blocks, job_id=job_id, policy=policy)
    state, decision = _final(binding, policy, adoptions, events, expected_head)
    chain = observed['decision']
    if chain is None:
        verdict = 'PENDING_ON_CHAIN'
    elif chain['decision'] == 'EXPIRED':
        verdict = 'EXPIRED_REFUNDED_ON_CHAIN'
    elif decision is None:
        verdict = 'RELEASED_BEFORE_LADDER_FINAL'
    elif decision == chain['decision'] and chain['reason'] == '0x' + state['head']:
        verdict = 'CONSISTENT'
    elif decision == chain['decision']:
        verdict = 'CONSISTENT_DECISION_REASON_DIFFERS'
    else:
        verdict = 'RELEASED_AGAINST_LADDER'
    return {'binding': observed['binding'], 'job_id': observed['job_id'], 'chain': observed, 'ladder_status': state['status'],
            'ladder_decision': decision, 'verdict': verdict,
            'breach_evidence': verdict in ('RELEASED_BEFORE_LADDER_FINAL', 'RELEASED_AGAINST_LADDER'),
            'remedy': 'Through the AAP ladder and escrow terms the parties signed; the chain is not reversed.', **FLAGS}


def describe():
    return {'version': VERSION, 'decision': 'BOTH', 'rail': RAIL, 'order_profile': ORDER_PROFILE,
            'erc': 'ERC-8183 Agentic Commerce (Draft), ethereum/ERCs ERCS/erc-8183.md, commits 573d9854 (2026-03-05) and a078cab5 (2026-03-13)',
            'states': list(STATES), 'abi_profiles': {name: {'source': row['source'], 'functions': dict(row['functions']),
                                                            'events': {event: signature for event, (signature, _) in row['events'].items()},
                                                            'refused_extensions': list(row['unsupported'])}
                                                     for name, row in PROFILES.items()},
            'appeal': 'Optional: an AAP-bound evaluator signs an evaluation; the ladder decides; release() emits complete/reject',
            'not_established': ['that a pinned block is final', 'token transfers (only the contract events are read)',
                                'that the evaluator will wait: an early call is recorded as breach evidence'],
            'remediation': deepcopy(REMEDIATION), **FLAGS}
