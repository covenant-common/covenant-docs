"""Keyless tools for one courier drop.

They call the drafter, covenant-expr/0.2, and the panel. They do not open a
second formula language or a second ballot format.
"""
from .cooperation_interface import HASH, INT, OBJECT

# The shared TEXT cap is 128 characters. A delivery sentence is longer than that.
SENTENCE = {'type': 'string', 'minLength': 1, 'maxLength': 2000}
DATE = {'type': 'string', 'minLength': 10, 'maxLength': 10}


def specs():
    return [
        ('covenant_draft',
         'Turn one sentence into a draft. A price, a clock time, photo, GPS and a half refund stay in the terms.',
         True, [
             ('sentence', {'text': SENTENCE, 'as_of': DATE}, ('text',)),
         ]),
        ('covenant_lint',
         'Lint a draft. A zero price and a missing deadline are errors.',
         True, [('document', {'document': OBJECT}, ('document',))]),
        ('covenant_simulate',
         'Show who is paid in the delivered, late, disputed and silent outcomes. This does not move funds.',
         True, [('document', {'document': OBJECT}, ('document',))]),
        ('covenant_formula_eval',
         'Evaluate one covenant-expr/0.2 program. A missing fact stays UNKNOWN. This is not a consensus transition.',
         True, [('eval', {'program': OBJECT, 'bindings': OBJECT, 'facts': OBJECT, 'clock': OBJECT,
                          'step_limit': INT}, ('program',))]),
        ('covenant_delivery',
         'Pharmacy drop: draft the sentence, resolve names or exchange keys, grade a temperature with the 0.2 formula and pay the split, or submit a 50 percent panel ballot.',
         True, [
             ('draft', {'text': SENTENCE, 'as_of': DATE}, ('text',)),
             ('grade', {'quantity': INT, 'temp_c_millis': INT}, ()),
             ('settle', {'quantity': INT}, ()),
             ('propose', {'text': SENTENCE, 'as_of': DATE, 'payer_key': HASH, 'payee_key': HASH,
                          'aliases': OBJECT, 'phones': OBJECT, 'phonebook': OBJECT}, ('text',)),
         ]),
    ]


def call(name, action, parameters):
    if name == 'covenant_draft':
        from covenant_agent.drafting import draft
        return draft(parameters['text'], as_of=parameters.get('as_of'))
    if name == 'covenant_lint':
        from covenant_agent.drafting import lint
        return lint(parameters['document'])
    if name == 'covenant_simulate':
        from covenant_agent.drafting import simulate
        return simulate(parameters['document'])
    if name == 'covenant_formula_eval':
        from covenant_language.expr_tools import call as formula_call
        return formula_call('covenant_formula_eval', parameters)
    if name == 'covenant_delivery':
        from .courier_delivery import draft_agreement, grade, propose_drop, settle_dispute
        if action == 'draft':
            return draft_agreement(parameters['text'], as_of=parameters.get('as_of'))
        if action == 'grade':
            return grade(parameters.get('temp_c_millis'), quantity=parameters.get('quantity', 640))
        if action == 'settle':
            return settle_dispute(parameters.get('quantity', 640))
        if action == 'propose':
            drafted = draft_agreement(parameters['text'], as_of=parameters.get('as_of'))
            return propose_drop(drafted['document'], payer_key=parameters.get('payer_key'),
                                payee_key=parameters.get('payee_key'), directory=None,
                                aliases=parameters.get('aliases'), phones=parameters.get('phones'),
                                phonebook=parameters.get('phonebook'))
    raise ValueError('DELIVERY_ACTION')
