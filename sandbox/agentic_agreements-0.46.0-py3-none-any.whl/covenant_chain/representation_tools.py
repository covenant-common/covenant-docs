"""Read-only agent entrance to separately versioned represented agreements."""
from .cooperation_interface import HASH, INT, TEXT, OBJECT


def specs():
    array = {'type': 'array', 'maxItems': 64, 'items': OBJECT}
    chain = {'type': 'array', 'maxItems': 8, 'items': OBJECT}
    actor = {'oneOf': [HASH, {'type': 'object', 'maxProperties': 2,
        'additionalProperties': False, 'properties': {
            'suite': {'const': 'ML-DSA-65'},
            'key': {'type': 'string', 'maxLength': 3904, 'pattern': '^[0-9a-f]{3904}$'}},
        'required': ['suite', 'key']}]}
    return [('covenant_representation',
        'Agree through a representative while retaining the actual principal and signing actor. '
        'Prepare an exact legal module, scoped signed grants and portable countersignatures. '
        'Never signs through MCP. Authority-state and clock inputs require recipient adoption; '
        'a supplied hash is not evidence of current revocations or legal identity.', True, [
        ('prepare', {'module': OBJECT, 'context': HASH, 'dependencies': array}, ('module', 'context')),
        ('grant', {'package': OBJECT, 'party': TEXT, 'delegate': actor, 'not_before': INT,
                   'expires': INT, 'nonce': HASH, 'delegable': {'type': 'boolean'},
                   'issuer': actor, 'parent': HASH},
                  ('package', 'party', 'delegate', 'not_before', 'expires', 'nonce')),
        ('payload', {'package': OBJECT, 'party': TEXT, 'actor': actor, 'chain': chain},
                    ('package', 'party', 'actor')),
        ('add_approval', {'package': OBJECT, 'approval': OBJECT, 'expected_id': HASH},
                         ('package', 'approval', 'expected_id')),
        ('review', {'package': OBJECT, 'expected_id': HASH}, ('package', 'expected_id')),
        ('merge', {'left': OBJECT, 'right': OBJECT, 'expected_left': HASH, 'expected_right': HASH},
                  ('left', 'right', 'expected_left', 'expected_right')),
        ('authority_state', {'package': OBJECT, 'as_of': INT, 'expires': INT,
                             'revoked': {'type': 'array', 'maxItems': 4096, 'items': HASH},
                             'successors': OBJECT}, ('package', 'as_of', 'expires')),
        ('assess', {'package': OBJECT, 'expected_id': HASH, 'state': OBJECT,
                    'expected_state': HASH, 'now': INT, 'maximum_age': INT},
                   ('package', 'expected_id', 'state', 'expected_state', 'now')),
    ])]


def call(action, parameters):
    if action == 'describe':
        return {'profile': 'covenant-represented-agreement/0.1',
            'guide': 'docs/REPRESENTED_AGREEMENTS.html',
            'workflow': ['prepare exact legal module', 'principal signs exact scoped grant outside MCP',
                         'each owner reviews and signs its role', 'merge portable countersignatures',
                         'recipient assesses against independently adopted current authority state'],
            'historical_direct_assents': 'UNCHANGED; NEW_PROFILE_REQUIRES_EXPLICIT_ADOPTION',
            'native_grants': 'NO_AUTOMATIC_CONVERSION_FROM_NATIVE_GIVE',
            'state_adoption': 'A STATE FROM THE SIGNER IS NOT AUTOMATICALLY TRUSTED',
            'execution_authorized': False}
    from covenant_language import represented_agreements as records
    from . import representation_authority as authority
    if action in ('grant', 'authority_state', 'assess'):
        return getattr(authority, action)(**parameters)
    if action == 'payload':
        return records.signing_payload(**parameters)
    return getattr(records, action)(**parameters)
