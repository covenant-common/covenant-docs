"""Two-hop PQ onion submission with encrypted replies and fixed request padding.

Protects origin from a noncolluding exit/validator, and content from entry.
No global timing anonymity, Sybil resistance or independently operated network.
Optional random order and delay (submit_batch) blur one submitter's timing only.
"""
import hashlib,http.client,ipaddress,json,os,re,secrets,socket,ssl,threading,time,urllib.parse,urllib.error
from http.server import BaseHTTPRequestHandler
from . import observability
from .http_limits import BoundedHTTPServer
from .crypto import canonical,loads,need,exact,key
from covenant_language.quantum import recipient_keypair,encrypt_for,decrypt_for
PROFILE='covenant-onion-relay/0.1'
MAX_PACKET=65536
# Scoped reads only. /state is the full diagnostic export (agreements,
# balances, note lists) and is not forwarded.
RELAY_GET={'/status','/genesis','/context','/record'}
BATCH_VERSION='covenant-relay-batch/0.1'
MAX_BATCH=32
MAX_DELAY_MS=60000
TIMING_LIMITS=('Random order and delay blur timing against an observer of one link only. There is no global timing '
               'anonymity: an observer of both the entry and exit links, or of the destination over time, can still '
               'correlate submissions. There is no Sybil resistance: one operator running both hops sees origin and '
               'destination. Relays need independent operators, which this code cannot verify.')

def _context(identity,layer):return canonical({'profile':PROFILE,'relay':identity,'layer':layer})
def _pad(value,size):
    raw=canonical(value);need(len(raw)+4<=size,'RELAY_PAYLOAD_SIZE');return len(raw).to_bytes(4,'big')+raw+os.urandom(size-4-len(raw))
def _unpad(raw,size):
    need(type(raw) is bytes and len(raw)==size,'RELAY_PADDING');n=int.from_bytes(raw[:4],'big');need(0<n<=size-4,'RELAY_LENGTH');return loads(raw[4:4+n])
def _seal(body,recipient,size):
    return {'version':PROFILE,'relay':recipient['id'],'layer':recipient['layer'],
            'envelope':encrypt_for(_pad(body,size),recipient_public_key=bytes.fromhex(recipient['key']),context=_context(recipient['id'],recipient['layer']))}
def _literal_endpoint(url):
    """Relay hops are literal IP URLs. A hostname or file URL is not a route."""
    need(type(url) is str and 0 < len(url) <= 256 and all(33 <= ord(c) <= 126 for c in url), 'RELAY_URL')
    uri = urllib.parse.urlsplit(url)
    need(uri.scheme in {'http', 'https'} and not uri.username and not uri.password
         and not uri.query and not uri.fragment, 'RELAY_URL')
    try:
        ipaddress.ip_address(uri.hostname or '')
    except ValueError as exc:
        raise ValueError('RELAY_LITERAL_IP') from exc
    need(uri.port is not None, 'RELAY_URL')
    return url


def _http(url,value=None,timeout=15):
    uri=urllib.parse.urlsplit(url)
    host=uri.hostname or ''
    shown='['+host+']' if ':' in host else host
    _literal_endpoint(f'{uri.scheme}://{shown}:{uri.port}')
    raw=canonical(value) if value is not None else None
    # The selected endpoint is the adopted route. A redirect must not turn an
    # allowed relay or validator into a request to an unadopted endpoint.
    # Environment proxies would also replace the literal-IP route implicitly.
    # The literal socket and absolute deadline also bound trickled headers/body;
    # a timeout on each individual socket read does not provide that guarantee.
    deadline=time.monotonic()+timeout
    channel=socket.socket(socket.AF_INET6 if ':' in host else socket.AF_INET,socket.SOCK_STREAM)
    connection=None;response=None;timer=None;expired=threading.Event()
    try:
        channel.settimeout(timeout);channel.connect((host,uri.port))
        remaining=deadline-time.monotonic();need(remaining>0,'RELAY_TIMEOUT')
        channel.settimeout(remaining)
        if uri.scheme=='https':
            channel=ssl.create_default_context().wrap_socket(channel,server_hostname=host,do_handshake_on_connect=False)
        def expire():
            expired.set()
            try:channel.shutdown(socket.SHUT_RDWR)
            except OSError:pass
        timer=threading.Timer(max(0,deadline-time.monotonic()),expire);timer.daemon=True;timer.start()
        if uri.scheme=='https':channel.do_handshake()
        need(not expired.is_set() and time.monotonic()<deadline,'RELAY_TIMEOUT')
        connection=http.client.HTTPConnection(host,uri.port,timeout=timeout);connection.sock=channel
        path=(uri.path or '/')+('?' + uri.query if uri.query else '')
        connection.request('GET' if value is None else 'POST',path,body=raw,headers={'Content-Type':'application/json'})
        response=connection.getresponse()
        need(not 300<=response.status<400,'RELAY_REDIRECT_REFUSED')
        if response.status>=400:
            raise urllib.error.HTTPError(url,response.status,response.reason,response.headers,None)
        data=response.read(1000001)
        need(not expired.is_set() and time.monotonic()<deadline,'RELAY_TIMEOUT')
        need(len(data)<=1000000,'RELAY_REPLY_SIZE');return loads(data)
    finally:
        if timer is not None:timer.cancel();timer.join()
        if response is not None:response.close()
        if connection is not None:connection.close()
        channel.close()

def check_route(route):
    """A real two-hop route: distinct relay ids and URLs, literal-IP endpoints, ML-KEM keys.

    Returns a summary without keys. It cannot verify that the two relays have
    independent operators; ``same_host`` is reported, not refused, so a local
    test route still works.
    """
    exact(route,'entry exit destination');entry=route['entry'];exit=route['exit']
    for r,layer in [(entry,'entry'),(exit,'exit')]:
        exact(r,'id key layer url');key(r['id']);need(r['layer']==layer,'RELAY_LAYER')
        need(type(r['key']) is str and re.fullmatch(r'[0-9a-fA-F]{2368}',r['key']) is not None,'RELAY_KEY')
    need(entry['id']!=exit['id'] and entry['url']!=exit['url'],'RELAY_INDEPENDENCE')
    _literal_endpoint(entry['url']);_literal_endpoint(exit['url']);_literal_endpoint(route['destination'])
    need(route['destination'] not in {entry['url'],exit['url']},'RELAY_INDEPENDENCE')
    hosts=[ipaddress.ip_address(urllib.parse.urlsplit(r['url']).hostname) for r in (entry,exit)]
    return {'hops':2,'entry':entry['id'],'exit':exit['id'],'same_host':hosts[0]==hosts[1]}

def _delay(max_delay_ms,sleep):
    need(type(max_delay_ms) is int and 0<=max_delay_ms<=MAX_DELAY_MS,'RELAY_DELAY')
    wait=secrets.randbelow(max_delay_ms+1) if max_delay_ms else 0
    if wait:sleep(wait/1000)
    return wait

def request(route,method,path,body=None,*,max_delay_ms=0,sleep=time.sleep):
    """Only make native HTTP queries through this path to avoid direct-query leaks.

    ``max_delay_ms`` waits a uniformly random 0..max milliseconds before sending.
    """
    check_route(route);entry=route['entry'];exit=route['exit']
    _delay(max_delay_ms,sleep)
    pub,secret=recipient_keypair();nonce=os.urandom(32).hex()
    inner={'version':PROFILE,'kind':'request','destination':route['destination'],'method':method,'path':path,'body':body,'reply_key':pub.hex(),'nonce':nonce}
    packet=_seal(inner,exit,8192)
    outer=_seal({'version':PROFILE,'kind':'forward','destination':exit['url'],'packet':packet},entry,24576)
    response=_http(entry['url']+'/relay',outer)
    exact(response,'version nonce envelope');need(response['version']==PROFILE and response['nonce']==nonce,'RELAY_REPLY_CONTEXT')
    plain=decrypt_for(response['envelope'],recipient_secret_key=secret,context=canonical({'profile':PROFILE,'reply':nonce}))
    result=loads(plain);exact(result,'ok body error');need(result['ok'] is True,'RELAY_DESTINATION_REJECTED');return result['body']

def submit_batch(route,transactions,*,max_delay_ms=0,sleep=time.sleep):
    """Submit up to 32 transactions through the route in random order with random gaps.

    Results come back in input order. One refusal does not stop the rest; each
    row carries ``ok`` and either ``body`` or a stable ``error`` code.
    """
    check_route(route);need(type(max_delay_ms) is int and 0<=max_delay_ms<=MAX_DELAY_MS,'RELAY_DELAY')
    need(type(transactions) is list and 0<len(transactions)<=MAX_BATCH and all(type(tx) is dict for tx in transactions),'RELAY_BATCH')
    order=list(range(len(transactions)))
    for i in range(len(order)-1,0,-1):
        j=secrets.randbelow(i+1);order[i],order[j]=order[j],order[i]
    results=[None]*len(transactions);waited=0
    for index in order:
        waited+=_delay(max_delay_ms,sleep)
        try:results[index]={'ok':True,'body':request(route,'POST','/submit',transactions[index]),'error':None}
        except (urllib.error.URLError,OSError,ValueError) as exc:
            code=str(exc) if re.fullmatch(r'[A-Z][A-Z0-9_]{1,80}',str(exc)) else 'RELAY_REJECTED'
            results[index]={'ok':False,'body':None,'error':code}
    return {'version':BATCH_VERSION,'results':results,'submitted':sum(1 for r in results if r['ok']),
            'order_randomized':len(transactions)>1,'max_delay_ms':max_delay_ms,'total_delay_ms':waited,
            'timing_limits':TIMING_LIMITS,'execution_authorized':False}

class Relay:
    def __init__(self,identity,secret,layer,allowed,trace=None):
        key(identity);need(layer in {'entry','exit'},'RELAY_LAYER');self.identity=identity;self.secret=secret;self.layer=layer
        for endpoint in allowed:_literal_endpoint(endpoint)
        self.allowed=set(allowed);self.trace=trace;self.guard=threading.BoundedSemaphore(4);self.count=0;self.window=0;self.lock=threading.Lock()
        self.ops=observability.Ops('relay',routes={'/relay'})
    def process(self,packet):
        need(self.guard.acquire(False),'RELAY_BUSY')
        try:
            with self.lock:
                now=time.monotonic()
                if now-self.window>=1:self.window=now;self.count=0
                self.count+=1;need(self.count<=20,'RELAY_RATE_LIMIT')
            exact(packet,'version relay layer envelope');need(packet['version']==PROFILE and packet['relay']==self.identity and packet['layer']==self.layer,'RELAY_CONTEXT')
            raw=decrypt_for(packet['envelope'],recipient_secret_key=self.secret,context=_context(self.identity,self.layer))
            b=_unpad(raw,24576 if self.layer=='entry' else 8192)
            if self.trace:self.trace(b) # Test-only callback; production should log metrics, not content.
            if self.layer=='entry':
                exact(b,'version kind destination packet');need(b['version']==PROFILE and b['kind']=='forward' and b['destination'] in self.allowed,'RELAY_ROUTE')
                return _http(b['destination']+'/relay',b['packet'])
            exact(b,'version kind destination method path body reply_key nonce')
            need(b['version']==PROFILE and b['kind']=='request' and b['destination'] in self.allowed,'RELAY_ROUTE');key(b['nonce'])
            path=b['path'];need(type(path) is str,'RELAY_PATH')
            get=path in RELAY_GET or re.fullmatch(r'/tx/[0-9a-f]{64}|/record\?[A-Za-z0-9_=&]{1,200}|/blocks\?from=[1-9][0-9]{0,6}',path) is not None
            post=path in {'/submit','/preview'}
            need((b['method']=='GET' and get and b['body'] is None) or (b['method']=='POST' and post and type(b['body']) is dict),'RELAY_METHOD_PATH')
            need(type(b['reply_key']) is str and len(b['reply_key'])==2368,'RELAY_REPLY_KEY')
            try:result={'ok':True,'body':_http(b['destination']+path,b['body']),'error':None}
            except (urllib.error.URLError,OSError,ValueError):result={'ok':False,'body':None,'error':'DESTINATION_REJECTED'}
            reply=canonical(result)
            need(len(reply)<=40000,'RELAY_REPLY_SIZE')
            envelope=encrypt_for(reply,recipient_public_key=bytes.fromhex(b['reply_key']),context=canonical({'profile':PROFILE,'reply':b['nonce']}))
            return {'version':PROFILE,'nonce':b['nonce'],'envelope':envelope}
        finally:self.guard.release()
    def server(self,host='127.0.0.1',port=0,*,max_connections=8,connection_seconds=20):
        need(host in {'127.0.0.1','::1'},'RELAY_LOOPBACK_ONLY');relay=self
        class Handler(observability.Instrumented, BaseHTTPRequestHandler):
            ops=relay.ops
            def log_message(self,*args):pass
            def do_POST(self):
                try:
                    shown='['+host+']' if ':' in host else host
                    need(self.headers.get_all('Host')==[shown+':'+str(self.server.server_port)],'RELAY_HOST')
                    need(self.headers.get('Origin') is None,'RELAY_ORIGIN')
                    need(self.headers.get('Transfer-Encoding') is None and self.headers.get('Expect') is None,'RELAY_FRAMING')
                    need(self.headers.get_all('Content-Type')==['application/json'],'RELAY_CONTENT_TYPE')
                    lengths=self.headers.get_all('Content-Length')
                    need(lengths is not None and len(lengths)==1 and re.fullmatch('[0-9]{1,6}',lengths[0]),'RELAY_REQUEST_SIZE')
                    n=int(lengths[0]);need(self.path=='/relay' and 0<n<=MAX_PACKET,'RELAY_REQUEST_SIZE')
                    raw=self.rfile.read(n);need(len(raw)==n,'RELAY_REQUEST_SIZE')
                    result=relay.process(loads(raw));data=canonical(result);self.send_response(200)
                except Exception as exc:
                    # The caller learns only RELAY_REJECTED; the operator counts the specific code.
                    relay.ops.refusal(observability.refusal_code(exc))
                    data=canonical({'error':'RELAY_REJECTED'});self.send_response(400)
                self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)))
                self.send_header('Connection','close');self.send_header('Cache-Control','no-store')
                self.end_headers();self.wfile.write(data);self.close_connection=True
        if host=='::1':
            import socket
            class Server(BoundedHTTPServer):
                address_family=socket.AF_INET6
        else:Server=BoundedHTTPServer
        return Server((host,port),Handler,max_connections=max_connections,connection_seconds=connection_seconds)
