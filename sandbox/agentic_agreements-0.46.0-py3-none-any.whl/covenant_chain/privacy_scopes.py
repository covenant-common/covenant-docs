"""Optional privacy with exact recipient/field scope and fresh scope-change assent.

Built-in plaintext or existing padded ML-KEM-768/AES256GCM delivery. Additional
schemes are trusted owner-installed callbacks, never agent-selected code.
Removing recipients protects new ciphertext only, never erases prior knowledge.
"""
from copy import deepcopy
import hashlib,json
from covenant_language.agentic import canonical as content
from .crypto import canonical,digest,exact,key,need,verify,verification_key
from .private_covenant import _seal_payload,_open_payload,CONTENT_BYTES,LARGE_CONTENT_BYTES
VERSION='covenant-disclosure-scope/0.1'
PLAIN='NONE_EXPLICIT_PLAINTEXT'
ENCRYPTED='ML-KEM-768-HKDF-SHA256-AES256GCM_PADDED'
LABEL='COVENANT-DISCLOSURE-SCOPE-ASSENT-0.1'

def identifier(policy):return digest('COVENANT-DISCLOSURE-SCOPE-0.1',policy)
def validate(policy):
    exact(policy,'version context controllers recipients fields purpose suite supersedes')
    need(policy['version']==VERSION,'PRIVACY_VERSION');key(policy['context'])
    need(type(policy['controllers']) is list and 1<=len(policy['controllers'])<=8,'PRIVACY_CONTROLLERS')
    controllers=[canonical(c) for c in policy['controllers']];need(len(set(controllers))==len(controllers),'PRIVACY_DUPLICATE_CONTROLLER')
    for c in policy['controllers']:verification_key(c)
    need(type(policy['recipients']) is dict and len(policy['recipients'])<=8,'PRIVACY_RECIPIENTS')
    for name,public in policy['recipients'].items():
        need(type(name) is str and 0<len(name)<=64 and type(public) is str and len(public)==2368,'PRIVACY_RECIPIENT_KEY')
        try:raw=bytes.fromhex(public)
        except ValueError:raise ValueError('PRIVACY_RECIPIENT_KEY') from None
        need(raw.hex()==public,'PRIVACY_RECIPIENT_KEY')
    need(type(policy['fields']) is list and 0<len(policy['fields'])<=32 and len(set(policy['fields']))==len(policy['fields']),'PRIVACY_FIELDS')
    for path in policy['fields']:
        need(type(path) is str and 1<len(path)<=256 and path.startswith('/') and all('~' not in s.replace('~0','').replace('~1','') for s in path[1:].split('/')),'PRIVACY_FIELD_PATH')
    need(type(policy['purpose']) is str and 0<len(policy['purpose'])<=4096 and type(policy['suite']) is str and 0<len(policy['suite'])<=128,'PRIVACY_POLICY')
    if policy['suite']!=PLAIN:need(len(policy['recipients'])>0,'PRIVACY_RECIPIENTS')
    if policy['supersedes'] is not None:key(policy['supersedes'])
    canonical(policy);return True

def draft(context,controllers,recipients,fields,purpose,suite=ENCRYPTED,supersedes=None):
    p=dict(version=VERSION,context=context,controllers=deepcopy(controllers),recipients=deepcopy(recipients),fields=deepcopy(fields),purpose=purpose,suite=suite,supersedes=supersedes)
    validate(p);return inspect(p)
def inspect(policy):
    validate(policy);return {'id':identifier(policy),'policy':deepcopy(policy),'label':LABEL,'assent_body':deepcopy(policy),'status':'REQUIRES_ALL_CONTROLLER_ASSENTS',
        'prior_plaintext_recall':False,'removed_recipient':'FUTURE_VERSIONS_ONLY','metadata_and_host_plaintext':'NOT_HIDDEN_BY_THIS_POLICY','execution_authorized':False}
def amend(policy,changes):
    validate(policy);need(type(changes) is dict and set(changes)<={'recipients','fields','purpose','suite'},'PRIVACY_AMEND_FIELDS')
    new={**deepcopy(policy),**deepcopy(changes),'supersedes':identifier(policy)};return inspect(new)
def verify_scope(policy,approvals,expected_id,expected_controllers):
    validate(policy);key(expected_id)
    need(identifier(policy)==expected_id and canonical(policy['controllers'])==canonical(expected_controllers),'PRIVACY_EXPECTED_POLICY')
    need(type(approvals) is list and len(approvals)==len(expected_controllers),'PRIVACY_ALL_ASSENTS')
    seen=set()
    for approval in approvals:
        exact(approval,'controller signature');encoded=canonical(approval['controller'])
        need(encoded in {canonical(c) for c in expected_controllers} and encoded not in seen,'PRIVACY_ALL_ASSENTS')
        verify(approval['controller'],LABEL,policy,approval['signature']);seen.add(encoded)
    return True

def verify_transition(before,after,approvals,expected_before,expected_after):
    validate(before);validate(after);key(expected_before);key(expected_after)
    need(identifier(before)==expected_before and after['supersedes']==expected_before and before['context']==after['context'] and canonical(before['controllers'])==canonical(after['controllers']),'PRIVACY_TRANSITION')
    verify_scope(after,approvals,expected_after,before['controllers'])
    return {'previous':expected_before,'current':expected_after,'fresh_unanimous_scope_assent_verified':True,
        'prior_plaintext_recall':False,'execution_authorized':False}

def project(value,fields):
    need(type(value) is dict,'PRIVACY_CONTENT');content(value);selected={}
    for path in fields:
        v=value
        for step in path[1:].split('/'):
            step=step.replace('~1','/').replace('~0','~')
            need(type(v) is dict and step in v,'PRIVACY_FIELD_MISSING');v=v[step]
        selected[path]=deepcopy(v)
    return selected

class PrivacyDesk:
    def __init__(self,recipient_keys=None):self.keys=dict(recipient_keys or {});self.schemes={}
    def register(self,manifest,sealer,opener):
        exact(manifest,'name implementation scope');key(manifest['implementation'])
        need(callable(sealer) and callable(opener),'PRIVACY_SCHEME')
        ref=digest('COVENANT-PRIVACY-SCHEME-0.1',manifest);need(ref not in self.schemes,'PRIVACY_SCHEME_EXISTS')
        self.schemes[ref]=(deepcopy(manifest),sealer,opener);return ref
    def suites(self):return {'builtins':[PLAIN,ENCRYPTED],'custom':{k:deepcopy(v[0]) for k,v in self.schemes.items()},'composition':'SIGNATURES_PROOFS_CONTRACTS_AND_CAPSULES_CAN_BE_SELECTED_PAYLOADS','recipient_secrets_in_tool_arguments':False}
    def protect(self,value,policy,approvals,expected_id,expected_controllers,padding=CONTENT_BYTES):
        verify_scope(policy,approvals,expected_id,expected_controllers)
        selected=project(value,policy['fields']);payload={'policy':expected_id,'selected_hex':content(selected).hex()}
        suite=policy['suite'];context={'chain':policy['context'],'scope':'scoped-disclosure/'+expected_id}
        if suite==PLAIN:packet=payload;assurance='EXPLICIT_PLAINTEXT_SELECTED_FIELDS'
        elif suite==ENCRYPTED:
            packet=_seal_payload(payload,VERSION,recipient_public_keys=[bytes.fromhex(v) for v in policy['recipients'].values()],context=context,padding=padding)
            assurance='EXISTING_PADDED_ML_KEM_AES_GCM_PROFILE'
        else:
            need(suite in self.schemes,'PRIVACY_SCHEME_NOT_INSTALLED');m,sealer,_=self.schemes[suite]
            need(digest('COVENANT-PRIVACY-SCHEME-0.1',m)==suite,'PRIVACY_SCHEME_CHANGED')
            packet=sealer(deepcopy(payload),deepcopy(policy));canonical(packet);assurance='OWNER_INSTALLED_SCHEME_ASSERTIONS'
        return {'policy':expected_id,'suite':suite,'packet':packet,'assurance':assurance,'scope_assented':True,'prior_plaintext_recall':False,'execution_authorized':False}
    def open(self,delivery,policy,approvals,expected_id,expected_controllers,recipient=None):
        verify_scope(policy,approvals,expected_id,expected_controllers)
        exact(delivery,'policy suite packet assurance scope_assented prior_plaintext_recall execution_authorized')
        need(delivery['policy']==expected_id and delivery['suite']==policy['suite'],'PRIVACY_DELIVERY_POLICY')
        suite=policy['suite'];context={'chain':policy['context'],'scope':'scoped-disclosure/'+expected_id}
        if suite==PLAIN:payload=delivery['packet']
        elif suite==ENCRYPTED:
            need(recipient in policy['recipients'] and recipient in self.keys,'PRIVACY_RECIPIENT_NOT_CONFIGURED')
            record=self.keys[recipient];need(record['public'].hex()==policy['recipients'][recipient],'PRIVACY_RECIPIENT_KEY')
            payload=_open_payload(delivery['packet'],VERSION,recipient_secret_key=record['secret'],expected_context=context)
        else:
            need(suite in self.schemes,'PRIVACY_SCHEME_NOT_INSTALLED');m,_,opener=self.schemes[suite]
            need(digest('COVENANT-PRIVACY-SCHEME-0.1',m)==suite,'PRIVACY_SCHEME_CHANGED')
            payload=opener(deepcopy(delivery['packet']),deepcopy(policy),recipient)
        exact(payload,'policy selected_hex');need(payload['policy']==expected_id,'PRIVACY_DELIVERY_POLICY')
        try:raw=bytes.fromhex(payload['selected_hex']);selected=json.loads(raw)
        except (ValueError,UnicodeError):raise ValueError('PRIVACY_CONTENT_ENCODING') from None
        need(content(selected)==raw and type(selected) is dict and set(selected)==set(policy['fields']),'PRIVACY_CONTENT_ENCODING')
        return {'policy':expected_id,'selected':selected,'execution_authorized':False,'recipient_may_retain_or_redisclose':True,'content_authorship':'SEPARATE_SIGNATURE_OR_PROOF_REQUIRED'}
