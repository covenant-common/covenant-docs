"""Optional hash-based detached witness profile; not native consensus or encryption.

Recipients independently adopt witness keys, required suites, epoch and threshold.
SPHINCS+ is named as the actual backend, not asserted to be FIPS205 SLH-DSA.
"""
import hashlib
from .crypto import canonical,exact,need,integer
VERSION='covenant-defense/0.1'
HASH='SPHINCS+-SHA2-256s-simple-pqcrypto-0.4'
LATTICE='ML-DSA-65'
LABEL=b'COVENANT-DEFENSE-WITNESS-0.1\0'
MAX_DATA=64*1024*1024

def backend(suite):
    try:
        if suite==HASH:
            from pqcrypto.sign import sphincs_sha2_256s_simple
            return sphincs_sha2_256s_simple
        if suite==LATTICE:
            from pqcrypto.sign import ml_dsa_65
            return ml_dsa_65
    except ImportError as e: raise ValueError('DEFENSE_BACKEND_UNAVAILABLE: optional pqcrypto package is required for ' + str(suite)) from e
    raise ValueError('DEFENSE_SUITE')

def keypair(suite=HASH):return backend(suite).generate_keypair()

def _name(value):
    need(type(value) is str and 1<=len(value)<=80 and all(33<=ord(c)<=126 for c in value),'DEFENSE_NAME')

def _hex(value,size):
    need(type(value) is str and len(value)==2*size and all(c in '0123456789abcdef' for c in value),'DEFENSE_HEX')
    return bytes.fromhex(value)

def fingerprints(data):
    need(type(data) is bytes and len(data)<=MAX_DATA,'DEFENSE_DATA')
    return {'sha512':hashlib.sha512(data).hexdigest(),'sha3_512':hashlib.sha3_512(data).hexdigest()}

def attest(data,context,member,secrets,epoch):
    _name(member);integer(epoch)
    need(type(context) is bytes and len(context)<=4096,'DEFENSE_CONTEXT')
    need(type(secrets) is dict and HASH in secrets and set(secrets)<= {HASH,LATTICE},'DEFENSE_REQUIRED_HASH')
    body={'version':VERSION,'member':member,'epoch':epoch,'context':fingerprints(context),'data':fingerprints(data),'suites':sorted(secrets)}
    message=LABEL+canonical(body);signatures={}
    for suite,secret in secrets.items():
        b=backend(suite);need(type(secret) is bytes and len(secret)==b.SECRET_KEY_SIZE,'DEFENSE_SECRET')
        signatures[suite]=b.sign(secret,message).hex()
    return {'body':body,'signatures':signatures}

def verify_witnesses(data,context,proofs,*,members,threshold,epoch,required_suites=(HASH,LATTICE)):
    """Verify exact byte attestations. Caller supplies all policy/trust inputs.

    This is no ordering protocol and establishes no latest-state or world truth.
    A quorum means only the explicitly adopted witnesses signed these bytes.
    """
    integer(epoch);integer(threshold,True)
    need(type(context) is bytes and len(context)<=4096,'DEFENSE_CONTEXT')
    need(type(required_suites) in (tuple,list) and len(set(required_suites))==len(required_suites),'DEFENSE_SUITE_POLICY')
    required=set(required_suites);need(HASH in required and required<={HASH,LATTICE},'DEFENSE_SUITE_POLICY')
    need(type(members) is dict and 1<=len(members)<=16 and threshold<=len(members),'DEFENSE_MEMBERS')
    adopted_keys=set()
    for member,keys in members.items():
        _name(member);need(type(keys) is dict and set(keys)==required,'DEFENSE_MEMBER_SUITES')
        for suite,pub in keys.items():
            _hex(pub,backend(suite).PUBLIC_KEY_SIZE)
            tag=(suite,pub);need(tag not in adopted_keys,'DEFENSE_DUPLICATE_KEY');adopted_keys.add(tag)
    need(type(proofs) is list and threshold<=len(proofs)<=len(members),'DEFENSE_QUORUM')
    data_fp,context_fp=fingerprints(data),fingerprints(context);seen=set()
    for proof in proofs:
        exact(proof,'body signatures');body=proof['body'];exact(body,'version member epoch context data suites')
        who=body['member'];_name(who);integer(body['epoch'])
        need(who in members and who not in seen,'DEFENSE_SIGNER');seen.add(who)
        need(body['version']==VERSION and body['epoch']==epoch,'DEFENSE_EPOCH')
        need(body['context']==context_fp and body['data']==data_fp,'DEFENSE_BINDING')
        need(body['suites']==sorted(required) and type(proof['signatures']) is dict and set(proof['signatures'])==required,'DEFENSE_DOWNGRADE')
        message=LABEL+canonical(body)
        for suite in required:
            b=backend(suite);sig=_hex(proof['signatures'][suite],b.SIGNATURE_SIZE)
            need(b.verify(_hex(members[who][suite],b.PUBLIC_KEY_SIZE),message,sig),'DEFENSE_SIGNATURE')
    return {'verified':True,'witnesses':sorted(seen),'threshold':threshold,'epoch':epoch,
            'suites':sorted(required),'data':data_fp,'assurance':'ADOPTED_WITNESSES_SIGNED_EXACT_BYTES',
            'native_consensus_changed':False,'freshness':'CALLER_POLICY_REQUIRED'}
