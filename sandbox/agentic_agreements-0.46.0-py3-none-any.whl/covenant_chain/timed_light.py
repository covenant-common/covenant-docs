"""Opt-in light-proof successor; frozen /0.1 and migration readers are unchanged.

This authenticates exact timed or untimed checkpoints and committee lineage,
not application replay, wall-clock truth, global latestness or execution rights.
Durable recipients additionally require a hash-linked extension of their own
retained head. Their SQLite database is security state, not a disposable cache.
"""
from copy import deepcopy
import hashlib
from importlib.resources import files
import os
from pathlib import Path
import sqlite3
import stat
import threading

from . import app
from .crypto import MAX_BYTES, canonical, digest, exact, genesis_id, integer, key, loads, need, verify
from .light import committee
from .state import prove_record, verify_record

PROFILE = 'covenant-native-light/0.2'
PROTOCOLS = frozenset((app.UPGRADE_VERSION, app.MIGRATION_VERSION))
MAX_TRANSITIONS = 128
MAX_ANCESTORS = 256
FLAGS = {'execution_authorized': False, 'global_currentness_verified': False,
         'core_adoption': 'PENDING; EXPLICIT_SUCCESSOR_ONLY; FROZEN_MIGRATION_UNCHANGED'}


def genesis_pin(genesis):
    """Exact carrier pin, including fields omitted by native0.16 intent identity."""
    return digest('AAP-TIMED-LIGHT-GENESIS-0.2', genesis)


def _block(block, chain):
    need(type(block) is dict and set(block) in (
        {'chain', 'height', 'parent', 'txs', 'state_root'},
        {'chain', 'height', 'parent', 'txs', 'state_root', 'time'}), 'TIMED_LIGHT_BLOCK_FIELDS')
    integer(block['height'], True); key(block['parent']); key(block['state_root'])
    need(block['chain'] == chain, 'TIMED_LIGHT_CHAIN')
    need(type(block['txs']) is list and len(block['txs']) <= 32, 'TIMED_LIGHT_BLOCK_SIZE')
    need(sum(len(canonical(tx)) for tx in block['txs']) <= 768 * 1024, 'TIMED_LIGHT_BLOCK_SIZE')
    if 'time' in block:
        integer(block['time'])
    if block['height'] == 1:
        need(block['parent'] == '0' * 64, 'TIMED_LIGHT_GENESIS_PARENT')
    return digest('COVENANT_CHAIN_BLOCK', block)


def _certificate(frame, chain, protocol, active, floor):
    exact(frame, 'proof checkpoint'); exact(frame['checkpoint'], 'block certificate')
    block, cert = frame['checkpoint']['block'], frame['checkpoint']['certificate']
    bid = _block(block, chain); exact(cert, 'height round block_id votes')
    integer(cert['height'], True); integer(cert['round'])
    need(cert['height'] == block['height'] and block['height'] >= max(floor, active['activation']), 'TIMED_LIGHT_HEIGHT')
    need(cert['block_id'] == bid, 'BLOCK_ID')
    votes, members = cert['votes'], active['validators']
    need(type(votes) is list and 2 * active['faults'] + 1 <= len(votes) <= len(members), 'QUORUM')
    seen = set()
    for vote in votes:
        exact(vote, 'kind body signer signature'); who = vote['signer']
        need(type(who) is str and who in members and who not in seen, 'SIGNER'); seen.add(who)
        body = {'chain': chain, 'height': block['height'], 'round': cert['round'], 'block_id': bid}
        need(vote['kind'] == 'precommit' and vote['body'] == body, 'VOTE_CONTEXT')
        verify(members[who], 'COVENANT_CHAIN_PRECOMMIT', body, vote['signature'])
    proof = frame['proof']
    need(type(proof) is dict and type(proof.get('descriptor')) is dict and
         proof['descriptor'].get('chain') == chain and proof['descriptor'].get('protocol') == protocol,
         'TIMED_LIGHT_PROTOCOL_PIN')
    return verify_record(proof, block['state_root'])


def _ancestry(bundle, chain, prior=None):
    """Full block bytes bind every parent edge into the certified final head."""
    blocks = bundle['ancestors']; head = bundle['active']['checkpoint']['block']
    need(type(blocks) is list and len(blocks) <= MAX_ANCESTORS, 'TIMED_LIGHT_ANCESTRY_BOUND')
    if prior is not None:
        need(head['height'] >= prior['height'], 'TIMED_LIGHT_ROLLBACK')
        if head['height'] == prior['height']:
            need(_block(head, chain) == prior['head'], 'TIMED_LIGHT_EQUIVOCATION')
            _ancestry(bundle, chain)
            return
        need(len(blocks) == head['height'] - prior['height'] - 1, 'TIMED_LIGHT_ANCESTRY_REQUIRED')
    previous = prior
    for block in [*blocks, head]:
        bid = _block(block, chain)
        if previous is not None:
            need(block['height'] == previous['height'] + 1 and block['parent'] == previous['head'], 'TIMED_LIGHT_FORK')
            if previous['time'] is not None:
                from .governance import MIN_BLOCK_INTERVAL
                need('time' in block and block['time'] >= previous['time'] + MIN_BLOCK_INTERVAL, 'TIMED_LIGHT_TIME_ROLLBACK')
        previous = {'height': block['height'], 'head': bid, 'time': block.get('time')}


def export_checkpoint_bundle(genesis, state, head, transitions, table, record_key, from_epoch=0, ancestors=()):
    """Build from producer-owned already-validated state; never replay or sign.

    ``ancestors`` are complete block dictionaries between a recipient's prior
    head and this head, excluding both endpoints. A direct next-height update
    needs none. Gaps beyond 257 blocks need intermediate recipient checkpoints.
    Epoch-transition index frames must already come from validated history.
    """
    integer(from_epoch); chain = genesis_id(genesis)
    need(genesis['protocol'] in PROTOCOLS and state['chain'] == chain and
         state['protocol'] == genesis['protocol'] and app.state_hash(state) == head['block']['state_root'],
         'TIMED_LIGHT_CHECKPOINT_STATE')
    need(type(transitions) is list and len(transitions) <= MAX_TRANSITIONS, 'TIMED_LIGHT_TRANSITION_BOUND')
    selected = [deepcopy(frame) for frame in transitions if frame['proof']['path'][-1]['value']['epoch'] > from_epoch]
    need(from_epoch <= state['domain']['active']['epoch'], 'TIMED_LIGHT_START_EPOCH')
    need(state['domain']['active']['activation'] <= head['block']['height'], 'TIMED_LIGHT_WAIT_FOR_SUCCESSOR_CHECKPOINT')
    need(type(ancestors) in (list, tuple) and len(ancestors) <= MAX_ANCESTORS, 'TIMED_LIGHT_ANCESTRY_BOUND')
    bundle = {'profile': PROFILE, 'chain': chain, 'protocol': genesis['protocol'], 'transitions': selected,
        'active': {'proof': prove_record(state, 'domain', 'active'), 'checkpoint': deepcopy(head)},
        'record': {'proof': prove_record(state, table, record_key), 'checkpoint': deepcopy(head)},
        'ancestors': deepcopy(list(ancestors))}
    canonical(bundle); _ancestry(bundle, chain)
    return bundle


def verify_light_bundle(genesis, bundle, expected_chain, minimum_height, expected_table, expected_key,
                        *, expected_protocol=None, expected_head=None, minimum_time=None, expected_genesis=None):
    """Stateless exact certificate/record verification; no latest-head oracle."""
    return _verify(genesis, bundle, expected_chain, minimum_height, expected_table, expected_key,
                   expected_protocol, expected_head, minimum_time, expected_genesis)


def _verify(genesis, bundle, chain, floor, table, record_key, protocol=None, expected_head=None,
            minimum_time=None, expected_genesis=None, prior=None):
    integer(floor); key(chain); canonical(bundle); canonical(genesis)
    bundle, genesis = deepcopy(bundle), deepcopy(genesis)
    need(type(table) is str and type(record_key) is str, 'TIMED_LIGHT_REQUEST')
    exact(bundle, 'profile chain protocol transitions active record ancestors')
    need(genesis['protocol'] in PROTOCOLS and genesis_id(genesis) == chain, 'GENESIS_PIN')
    app.genesis_state(genesis)
    if expected_genesis is not None:
        key(expected_genesis); need(genesis_pin(genesis) == expected_genesis, 'TIMED_LIGHT_GENESIS_PIN')
    if protocol is not None:
        need(protocol == genesis['protocol'], 'TIMED_LIGHT_PROTOCOL_PIN')
    need(bundle['profile'] == PROFILE and bundle['chain'] == chain and
         bundle['protocol'] == genesis['protocol'], 'TIMED_LIGHT_CONTEXT')
    transitions = bundle['transitions']
    need(type(transitions) is list and len(transitions) <= MAX_TRANSITIONS, 'TIMED_LIGHT_TRANSITION_BOUND')
    initial = {
        'epoch': 0, 'activation': 1, 'validators': deepcopy(genesis['validators']), 'faults': genesis['faults'], 'event': None}
    full_prefix = False
    if prior and transitions:
        # Select full versus incremental proof parsing from untrusted metadata;
        # every selected frame is still authenticated below before it is used.
        first = transitions[0]
        exact(first, 'proof checkpoint'); exact(first['proof'], 'descriptor table key path')
        path = first['proof']['path']
        need(type(path) is list and path and type(path[-1]) is dict and 'value' in path[-1], 'TIMED_LIGHT_EPOCH_RECORD')
        candidate = path[-1]['value']; committee(candidate)
        full_prefix = candidate['epoch'] == 1
    active = deepcopy(prior['active_committee']) if prior and not full_prefix else initial
    committee(active)
    last_transition = prior['height'] if prior and not full_prefix else 0
    for frame in transitions:
        need(frame['proof']['table'] == 'domain' and frame['proof']['key'] == 'active', 'TIMED_LIGHT_EPOCH_RECORD')
        transition_floor = max(active['activation'], last_transition + 1,
            prior['height'] + 1 if prior and active['epoch'] >= prior['epoch'] else 0)
        successor = _certificate(frame, chain, genesis['protocol'], active, transition_floor); committee(successor)
        height = frame['checkpoint']['block']['height']
        need(successor['epoch'] == active['epoch'] + 1 and successor['activation'] == height + 1, 'TIMED_LIGHT_EPOCH_SEQUENCE')
        matches = [tx for tx in frame['checkpoint']['block']['txs'] if type(tx) is dict and type(tx.get('body')) is dict and
                   tx.get('body', {}).get('op') == 'DOMAIN_SUCCESSION' and app.transaction_id(tx) == successor['event']]
        need(len(matches) == 1, 'TIMED_LIGHT_SUCCESSION_EVENT')
        payload = matches[0]['body']['payload']
        need(payload['epoch'] == successor['epoch'] and payload['validators'] == successor['validators'] and
             payload['faults'] == successor['faults'] and payload['activation'] in ('NEXT_HEIGHT', successor['activation']),
             'TIMED_LIGHT_SUCCESSION_CONTEXT')
        from .lifecycle import approved
        body = {k: v for k, v in payload.items() if k not in ('approvals', 'acceptances')}; body['chain'] = chain
        approved(payload['approvals'], set(active['validators']), 2 * active['faults'] + 1,
                 'COVENANT-SUCCESSION-0.3', body, lambda who: active['validators'][who])
        approved(payload['acceptances'], set(successor['validators']), 2 * successor['faults'] + 1,
                 'COVENANT-SUCCESSION-ACCEPT-0.3', body, lambda who: successor['validators'][who])
        active = deepcopy(successor); last_transition = height
        if prior and active['epoch'] == prior['epoch']:
            need(active == prior['active_committee'], 'TIMED_LIGHT_RETAINED_COMMITTEE_MISMATCH')
    if prior:
        need(active['epoch'] >= prior['epoch'], 'TIMED_LIGHT_EPOCH_ROLLBACK')
    frame = bundle['active']
    need(frame['proof']['table'] == 'domain' and frame['proof']['key'] == 'active', 'TIMED_LIGHT_EPOCH_RECORD')
    need(_certificate(frame, chain, genesis['protocol'], active, floor) == active, 'TIMED_LIGHT_ACTIVE_MISMATCH')
    record = bundle['record']; need(record['checkpoint'] == frame['checkpoint'], 'TIMED_LIGHT_HEAD_MISMATCH')
    need(record['proof']['table'] == table and record['proof']['key'] == record_key, 'TIMED_LIGHT_REQUESTED_RECORD')
    value = _certificate(record, chain, genesis['protocol'], active, floor)
    head = frame['checkpoint']['certificate']['block_id']; block = frame['checkpoint']['block']
    if expected_head is not None:
        key(expected_head); need(head == expected_head, 'TIMED_LIGHT_HEAD_PIN')
    if minimum_time is not None:
        integer(minimum_time); need('time' in block and block['time'] >= minimum_time, 'TIMED_LIGHT_TIME_FLOOR')
    _ancestry(bundle, chain, prior)
    ancestor_ids = {b['height']: _block(b, chain) for b in [*bundle['ancestors'], block]}
    for transition in transitions:
        b = transition['checkpoint']['block']
        if b['height'] in ancestor_ids:
            need(ancestor_ids[b['height']] == transition['checkpoint']['certificate']['block_id'], 'TIMED_LIGHT_TRANSITION_FORK')
    return {'profile': PROFILE, 'protocol': genesis['protocol'], 'genesis_pin': genesis_pin(genesis),
        'chain': chain, 'value': value, 'height': block['height'], 'head': head, 'time': block.get('time'),
        'epoch': active['epoch'], 'active_committee': deepcopy(active), 'assurance': 'COMMITTEE_CERTIFIED',
        'history_replayed': False, 'transition_proofs': len(transitions),
        'genesis_validation': 'MAINTAINED_PRIMARY_GENESIS_ADMISSION; NOT_APPLICATION_HISTORY_REPLAY',
        'checker': {'implementation': 'covenant_chain.timed_light',
                    'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
        'time_validation': 'SIGNED_NONNEGATIVE_FIELD; GOVERNANCE_ACTIVATION_AND_WALL_CLOCK_NOT_REPLAYED',
        'ancestry': 'EXTENDS_DURABLE_RECIPIENT_HEAD' if prior else 'NO_PRIOR_RECIPIENT_HEAD',
        'freshness': 'RECIPIENT_HEIGHT_AND_OPTIONAL_SIGNED_TIME_FLOORS_ONLY; NOT_WALL_CLOCK_VERIFIED', **FLAGS}


class TimedLightClient:
    """Serialized, durable recipient pin. Keep and back up its security database.

    The filesystem/database integrity and adopted genesis are owner assumptions.
    A valid committee signature does not prove the committee's world assertions.
    """
    def __init__(self, path, genesis, expected_chain, *, expected_protocol=None, expected_genesis=None):
        need(str(path) != ':memory:' and not Path(path).is_symlink(), 'TIMED_LIGHT_DATABASE_PATH')
        need(genesis_id(genesis) == expected_chain and genesis['protocol'] in PROTOCOLS, 'GENESIS_PIN')
        app.genesis_state(genesis)
        if expected_protocol is not None: need(expected_protocol == genesis['protocol'], 'TIMED_LIGHT_PROTOCOL_PIN')
        pin = genesis_pin(genesis)
        if expected_genesis is not None: need(pin == expected_genesis, 'TIMED_LIGHT_GENESIS_PIN')
        self.genesis, self.chain, self.pin = deepcopy(genesis), expected_chain, pin
        self.lock = threading.RLock(); self.db = None; self._dirfd = None
        try:
            from .request_workspace import _directory
            self.directory, self._dirfd = _directory(Path(path).parent)
            self.filename = Path(path).name
            need(self.filename not in ('', '.', '..'), 'TIMED_LIGHT_DATABASE_PATH')
            try:
                fd = os.open(self.filename, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW,
                             0o600, dir_fd=self._dirfd)
                os.close(fd)
            except FileExistsError:
                pass
            # lstat-equivalent checks never open/close an existing live SQLite
            # file: close() could release another connection's POSIX locks.
            info = os.stat(self.filename, dir_fd=self._dirfd, follow_symlinks=False)
            need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and
                 info.st_nlink == 1 and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'TIMED_LIGHT_PRIVATE_FILE')
            self._identity = (info.st_dev, info.st_ino)
            self._files()
            self.db = sqlite3.connect(self.directory / self.filename, timeout=5, check_same_thread=False,
                                      isolation_level=None)
            self._files()
            self.db.execute('PRAGMA synchronous=FULL')
            tables = {row[0] for row in self.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
            need(tables <= {'timed_light_pin'}, 'TIMED_LIGHT_DATABASE_CONTEXT')
            self.db.execute('BEGIN IMMEDIATE')
            tables = {row[0] for row in self.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
            need(tables <= {'timed_light_pin'}, 'TIMED_LIGHT_DATABASE_CONTEXT')
            self.db.execute('CREATE TABLE IF NOT EXISTS timed_light_pin (id INTEGER PRIMARY KEY CHECK(id=1), profile TEXT NOT NULL, chain TEXT NOT NULL, genesis TEXT NOT NULL, report BLOB, checksum TEXT)')
            row = self.db.execute('SELECT profile,chain,genesis FROM timed_light_pin WHERE id=1').fetchone()
            need(row is None or row == (PROFILE, expected_chain, pin), 'TIMED_LIGHT_DATABASE_CONTEXT')
            if row is None: self.db.execute('INSERT INTO timed_light_pin VALUES(1,?,?,?,NULL,NULL)', (PROFILE, expected_chain, pin))
            self._files(); self.db.commit()
            self.db.execute('PRAGMA journal_mode=WAL'); self._files()
        except BaseException:
            if self.db is not None: self.db.rollback()
            self.close(); raise

    def _files(self):
        held = os.fstat(self._dirfd); current = os.stat(self.directory, follow_symlinks=False)
        need(stat.S_ISDIR(current.st_mode) and (held.st_dev, held.st_ino) == (current.st_dev, current.st_ino)
             and held.st_uid == os.getuid() and stat.S_IMODE(held.st_mode) & 0o077 == 0,
             'TIMED_LIGHT_PRIVATE_DIRECTORY')
        for name in (self.filename, self.filename + '-wal', self.filename + '-shm', self.filename + '-journal'):
            try: info = os.stat(name, dir_fd=self._dirfd, follow_symlinks=False)
            except FileNotFoundError:
                need(name != self.filename, 'TIMED_LIGHT_DATABASE_REPLACED'); continue
            need(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and
                 info.st_nlink == 1 and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'TIMED_LIGHT_PRIVATE_FILE')
            if name == self.filename:
                need((info.st_dev, info.st_ino) == self._identity, 'TIMED_LIGHT_DATABASE_REPLACED')

    def close(self):
        with self.lock:
            if self.db is not None: self.db.close(); self.db = None
            if self._dirfd is not None: os.close(self._dirfd); self._dirfd = None

    def assess(self, bundle, minimum_height, table, record_key, *, expected_head=None, minimum_time=None):
        integer(minimum_height)
        with self.lock:
            need(self.db is not None, 'TIMED_LIGHT_CLIENT_CLOSED')
            self._files()
            try:
                self.db.execute('BEGIN IMMEDIATE')
                row = self.db.execute('SELECT profile,chain,genesis,report,checksum FROM timed_light_pin WHERE id=1').fetchone()
                need(row is not None and row[:3] == (PROFILE, self.chain, self.pin), 'TIMED_LIGHT_DATABASE_CONTEXT')
                prior = None
                need((row[3] is None) == (row[4] is None), 'TIMED_LIGHT_DATABASE_CORRUPTION')
                if row[3] is not None:
                    need(hashlib.sha256(row[3]).hexdigest() == row[4], 'TIMED_LIGHT_DATABASE_CORRUPTION')
                    prior = loads(row[3]); exact(prior, 'height head time epoch active_committee')
                    integer(prior['height'], True); key(prior['head']); integer(prior['epoch']); committee(prior['active_committee'])
                    need(prior['epoch'] == prior['active_committee']['epoch'], 'TIMED_LIGHT_DATABASE_CORRUPTION')
                    if prior['time'] is not None: integer(prior['time'])
                report = _verify(self.genesis, bundle, self.chain, max(minimum_height, prior['height'] if prior else 0),
                    table, record_key, self.genesis['protocol'], expected_head, minimum_time, self.pin, prior)
                pin = {k: report[k] for k in ('height', 'head', 'time', 'epoch', 'active_committee')}
                raw = canonical(pin)
                self._files()
                self.db.execute('UPDATE timed_light_pin SET report=?,checksum=? WHERE id=1', (raw, hashlib.sha256(raw).hexdigest()))
                self.db.commit(); return report
            except BaseException:
                self.db.rollback(); raise


def independent_verifier():
    """Describe local carried bytes; this never executes or adopts a verifier."""
    root = files(__package__).joinpath('data/independent_native016')
    value = {'profile': PROFILE,
        'entrypoint_sha256': hashlib.sha256(root.joinpath('timed_light_02.mjs').read_bytes()).hexdigest(),
        'dependencies': {name: hashlib.sha256(root.joinpath(name).read_bytes()).hexdigest()
                         for name in ('native016/primitives.mjs', 'verify_native_029.mjs')}}
    return {'id': digest('AAP-TIMED-LIGHT-INDEPENDENT-0.2', value), **value,
        'backend': 'JavaScript/Node', 'resource': 'data/independent_native016/timed_light_02.mjs',
        'scope': 'INDEPENDENT_CERTIFICATE_MERKLE_EPOCH_AND_SIGNED_TIME_READER; NO_DURABLE_DATABASE_OR_APPLICATION_REPLAY',
        'trust': 'LOCAL_BYTES_ONLY; OWNER_MUST_INDEPENDENTLY_ADOPT_CODE_AND_NODE_RUNTIME',
        'execution_authorized': False}


def describe():
    return {'profile': PROFILE, 'protocols': sorted(PROTOCOLS), 'timed_and_untimed': True,
        'maximum_transitions': MAX_TRANSITIONS, 'maximum_ancestor_blocks': MAX_ANCESTORS,
        'maximum_canonical_bytes': MAX_BYTES, 'independent_verifier': independent_verifier(),
        'producer': 'export_checkpoint_bundle from already-validated state; no replay/signing',
        'recipient': 'verify_light_bundle or durable TimedLightClient with owner-pinned genesis/chain/floors',
        'recipient_storage': 'Private no-symlink directory and owner-only single-link SQLite/WAL files; retain original security database',
        'ancestry': 'Full block bytes hash-link skipped heights to a durable retained head; never caller-asserted parent labels',
        'limits': 'Committee honesty/custody assumed; no application replay, live clock, global latestness, migration adoption or external effect', **FLAGS}
