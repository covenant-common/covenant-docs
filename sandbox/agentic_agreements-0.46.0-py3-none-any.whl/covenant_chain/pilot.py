"""Invited developer pilot: local checks, an explicit synthetic lesson and MCP setup.

No account, telemetry, stored custody, provider or network connection is created.
The demo signs only its own fixed synthetic example with fresh in-memory keys.
It cannot accept a user's deal or confer authority on another workflow.
"""
import argparse
from copy import deepcopy
from importlib import metadata
import json
import os
import shlex
import sys


def guide():
    """Actionable local handoff; commands are displayed, never executed here."""
    def command(action):
        return shlex.join([sys.executable, '-m', 'covenant_chain.pilot', action])
    return {'format': 'covenant-pilot-guide/0.1', 'track': 'INVITED_DEVELOPER_PILOT',
        'commands': {name: command(name) for name in ('doctor', 'demo', 'connect')},
        'expected': {'doctor': 'PASS', 'demo': 'SYNTHETIC_AGREEMENT_VERIFIED',
                     'connect': 'CONFIGURATION_ONLY'},
        'guide': 'docs/DEVELOPER_PILOT.html', 'telemetry': 'NONE',
        'owner_signing': {'guide': 'docs/OWNER_HANDOFF.html',
            'describe_command': shlex.join([sys.executable, '-m', 'covenant_chain.owner_handoff_app', '--describe']),
            'authority': 'OWNER_REVIEW_AND_EXPLICIT_LOCAL_ACTION_REQUIRED'},
        'publication': 'PRIVATE_INVITED_SOURCE', 'mainnet': False}


def doctor():
    """Check this installed environment without loading user configuration."""
    checks = []
    def check(name, ok, fix):
        checks.append({'check': name, 'status': 'PASS' if ok else 'ACTION_REQUIRED',
                       'next': None if ok else fix})
    check('python', sys.version_info >= (3, 11), 'Use Python 3.11 or newer in a virtual environment.')
    check('platform', os.name == 'posix', 'Use Linux or macOS for this pilot; Windows is not qualified.')
    try:
        version = metadata.version('cryptography')
        parts = tuple(int(x) for x in version.split('.'))
        crypto_ok = (50, 0, 2) <= parts < (51,)
    except (metadata.PackageNotFoundError, ValueError):
        crypto_ok = False
    check('cryptography', crypto_ok, 'Reinstall the pinned pilot package and its declared dependencies in the same environment.')
    try:
        from .quickstart import run
        result = run()
        ok = result['status'] == 'DRAFT_REQUIRES_ASSENT' and not result['execution_authorized']
    except Exception:
        ok = False
    check('keyless_draft', ok, 'Check the invited revision and installation; run python -m covenant_chain.quickstart in this environment.')
    try:
        from .agent_server import keyless_host_config
        from .runtime_host import RuntimeHost
        with_host = RuntimeHost(keyless_host_config(stateless=True))
        try:
            discovery = with_host.tools.call('covenant_discover', {})
            names = {tool['name'] for tool in with_host.tools.list_tools()}
            ok = 'covenant_onboard' in names and discovery['execution_authorized'] is False
        finally:
            with_host.close()
    except Exception:
        ok = False
    check('agent_discovery', ok, 'Run python -m covenant_chain.agent_server --keyless --stateless --discover; retain only the error code when reporting a failure.')
    return {'status': 'PASS' if all(row['status'] == 'PASS' for row in checks) else 'ACTION_REQUIRED',
        'checks': checks, 'telemetry': 'NONE', 'production_ready': False,
        'next': guide()['commands']['demo']}


def connect(client=None, *, launcher='python', profile=None):
    """Print an MCP configuration; nothing is written, started, connected or granted.

    Without a client this is the original mcpServers object. A named client
    gets its own file, command or TOML table from client_configs.
    """
    from .client_configs import CLIENTS, snippet
    if client is None:
        if launcher != 'python' or profile is not None:
            raise ValueError('PILOT_CONNECT_CLIENT_REQUIRED')
        from .welcome import connection_manifest
        configuration = connection_manifest()
        configuration['mcpServers']['covenant']['args'].append('--stateless')
        # Python 3.11+: never import modules from the client's working directory.
        configuration['mcpServers']['covenant']['env'] = {'PYTHONSAFEPATH': '1'}
        return {'status': 'CONFIGURATION_ONLY', 'configuration': configuration,
            'first_call': {'name': 'covenant_onboard', 'arguments': {
                'action': 'guide', 'parameters': {'task': 'simple-trade'}}},
            'expected': 'A task guide and exact installed schema; no transaction is executed.',
            'owner_action': 'Add this local command to your host MCP settings and enable it after reviewing permissions.',
            'scope': 'KEYLESS_DRAFTING_ONLY', 'connected': False, 'authority_granted': False,
            'clients': list(CLIENTS),
            'client_command': shlex.join([sys.executable, '-m', 'covenant_chain.pilot', 'connect', '--client', 'CLIENT']),
            'recovery': 'Use the same installed Python environment. Inspect missing parameters; never supply example parties as real identities.'}
    made = snippet(client, launcher=launcher, profile=profile)
    return {'status': 'CONFIGURATION_ONLY', 'client': client, 'configuration': made,
        'first_call': made['first_call'],
        'expected': ('The client lists covenant_onboard, covenant_find, covenant_explain and covenant_call. '
                     'covenant_onboard guide returns a task, its exact installed schema and next_call; covenant_call '
                     'accepts that next_call unchanged. No transaction is executed.'),
        'owner_action': made['owner_action'], 'scope': 'KEYLESS_DRAFTING_ONLY',
        'connected': False, 'authority_granted': False,
        'recovery': ('Run check_command in the same environment. Connected but no tools: confirm the absolute '
                     'interpreter path exists on the agent host and the client enabled the server.')}


def demo(*, full=False):
    """Exercise draft, negotiation, party assent and stale-assent rejection."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from .crypto import public_key, sign
    from covenant_language import marketplace as market
    keys = [Ed25519PrivateKey.generate() for _ in range(2)]
    buyer, seller = map(public_key, keys)
    by_public = dict(zip((buyer, seller), keys))
    initial = market.quick_trade(seller, buyer, 'One synthetic inventory report', 90,
        market.asset('pilot-synthetic', 'CREDIT', 'demo credit'), 'a' * 64)
    def approve(ready):
        payload = ready['prepared']['assent_payload']
        return [{'concept': row['concept'], 'party': row['party'],
                 'signature': sign(by_public[row['identity']], payload['label'], row['body'])}
                for row in payload['required_assents']]
    old_approvals = approve(initial)
    old = market.verify_order(initial['order'], old_approvals, initial['id'])
    give = deepcopy(initial['order']['data']['give'])
    give[0]['amount'] = 85
    revised = market.counter(initial['order'], {'give': give})
    rejected = False
    try:
        market.verify_order(revised['order'], old_approvals, revised['id'])
    except ValueError:
        rejected = True
    approvals = approve(revised)
    checked = market.verify_order(revised['order'], approvals, revised['id'], revised['id'])
    if not rejected or old['acceptance'] != 'EXACT_PARTY_ASSENTS_VERIFIED' or checked['acceptance'] != 'EXACT_PARTY_ASSENTS_VERIFIED':
        raise ValueError('PILOT_DEMO_VERIFICATION_FAILED')
    result = {'status': 'SYNTHETIC_AGREEMENT_VERIFIED',
        'human_goal': 'I run a small shop. I want an exact price for an inventory report and a record of the negotiated terms.',
        'steps': [
            {'action': 'Draft and sign the sample offer', 'amount': 90, 'id': initial['id']},
            {'action': 'Negotiate a new price', 'amount': 85, 'id': revised['id']},
            {'action': 'Reject the old signatures on changed terms', 'passed': rejected},
            {'action': 'Verify fresh buyer and seller signatures', 'passed': True}],
        'outstanding': ['Report delivery', 'Customer acceptance of delivery', 'Separately authorised payment'],
        'assent_verified': True, 'execution_authorized': False, 'payment_verified': False,
        'identities': 'TWO_FRESH_EPHEMERAL_SYNTHETIC_KEYS', 'custody_persisted': False,
        'telemetry': 'NONE', 'network_accessed': False,
        'next': 'Use connect for your agent, or onboarding --task paid-work for a separate owner-controlled synthetic settlement exercise. This sample does not sign your own draft.'}
    if full:
        result['verification_material'] = {'order': revised['order'], 'approvals': approvals,
                                         'expected_id': revised['id'], 'result': checked}
    return result


def main(argv=None):
    from .client_configs import CLIENTS, LAUNCHERS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('doctor', 'demo', 'connect', 'guide'))
    parser.add_argument('--full', action='store_true', help='Include portable public verification material for the synthetic demo.')
    parser.add_argument('--client', choices=CLIENTS, help='With connect, print the configuration for this MCP client.')
    parser.add_argument('--launcher', choices=LAUNCHERS, help='With --client: python (default, the installed environment), or uvx/pipx/npx for the pinned package once it is published.')
    parser.add_argument('--profile', choices=('entry', 'full'), help='With --client, the tools the client lists (default entry).')
    parser.add_argument('--text', action='store_true', help='With --client, print only the first paste-ready snippet.')
    args = parser.parse_args(argv)
    if args.full and args.action != 'demo':
        parser.error('--full applies only to demo')
    if (args.client or args.launcher or args.profile or args.text) and args.action != 'connect':
        parser.error('--client, --launcher, --profile and --text apply only to connect')
    if (args.launcher or args.profile or args.text) and not args.client:
        parser.error('--launcher, --profile and --text need --client')
    try:
        if args.action == 'connect':
            result = connect(args.client, launcher=args.launcher or 'python', profile=args.profile)
        else:
            result = demo(full=args.full) if args.action == 'demo' else globals()[args.action]()
    except Exception:
        # Local paths, configuration and dependency errors are not a diagnostic export.
        print(json.dumps({'status': 'ACTION_REQUIRED', 'code': 'PILOT_CHECK_FAILED',
                          'next': 'Run doctor and report only its check names and statuses.'}))
        return 1
    if args.text:
        print(result['configuration']['snippets'][0]['text'].rstrip('\n'))
        return 0
    print(json.dumps(result, indent=2, ensure_ascii=True))
    return 1 if result.get('status') == 'ACTION_REQUIRED' else 0


if __name__ == '__main__':
    raise SystemExit(main())
