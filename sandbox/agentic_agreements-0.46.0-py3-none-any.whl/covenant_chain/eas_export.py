"""Ethereum Attestation Service (EAS) export of AAP receipts. Maturity: experimental.

An EXTERNAL_CHAIN mode beside receipt-based reputation: a verified AAP delivery
receipt (urn:aap:delivery-receipt:0.1) or portable-trust OUTCOME receipt
(covenant-portable-trust/0.1) becomes an EAS attestation that EAS tooling
reads, while AAP keeps reading the AAP receipt. GRAFT, unchanged:

* Schemas: SchemaRegistry.register(string schema, address resolver, bool
  revocable) and its UID keccak256(abi.encodePacked(schema, resolver,
  revocable)) (ethereum-attestation-service/eas-contracts v1.4.0); attestation
  data is the Solidity ABI encoding of the schema's fields.
* Off-chain attestations: the eas-sdk v2.10.0 version 2 format (EIP-712 domain
  "EAS Attestation", the deployment's contract version, chainId and EAS
  address; Attest(uint16 version,bytes32 schema,address recipient,uint64 time,
  uint64 expirationTime,bool revocable,bytes32 refUID,bytes data,bytes32 salt))
  with the SDK's offchain UID, including its packing of the schema UID as the
  UTF-8 bytes of its 0x-hex text. They verify with no chain. Versions 1 and 2
  are verified; version 0 is refused.
* On-chain submission is bytes only: EAS.attest(AttestationRequest) calldata.

An attestation is evidence that an Ethereum key repeated an AAP receipt; it is
never a receipt, an outcome or reputation by itself. aap_record() returns the
AAP receipt only after both the receipt's own Ed25519 signatures and the
attestation's projection of it verify, so reputation still verifies from AAP
receipts. Nothing here submits, broadcasts or reads a chain.
"""
from copy import deepcopy
import hashlib
import re

from . import evm_codec as evm
from .crypto import canonical, need

DELIVERY, OUTCOME = 'delivery', 'outcome'
SCHEMAS = {
    DELIVERY: 'string aapProfile,bytes32 aapReceipt,bytes32 agreement,bytes32 application,bytes32 criteria,'
              'string verdict,uint64 receiptTime,bytes32 aapSigner,bytes32 recordDigest',
    OUTCOME: 'string aapProfile,bytes32 aapRecord,bytes32 agreement,string context,string subjectKind,bytes32 subjectId,'
             'string outcome,string mode,uint64 issuedAt,bytes32[] aapSigners,bytes32 recordDigest',
}
DOMAIN_NAME = 'EAS Attestation'
EAS_VERSIONS = ('0.26', '1.0.0', '1.0.1', '1.0.2', '1.1.0', '1.2.0', '1.3.0', '1.4.0')
ATTEST_V1 = [{'name': name, 'type': kind} for kind, name in (
    ('uint16', 'version'), ('bytes32', 'schema'), ('address', 'recipient'), ('uint64', 'time'), ('uint64', 'expirationTime'),
    ('bool', 'revocable'), ('bytes32', 'refUID'), ('bytes', 'data'))]
ATTEST_V2 = ATTEST_V1 + [{'name': 'salt', 'type': 'bytes32'}]
DOMAIN_TYPES = [{'name': 'name', 'type': 'string'}, {'name': 'version', 'type': 'string'},
                {'name': 'chainId', 'type': 'uint256'}, {'name': 'verifyingContract', 'type': 'address'}]
REGISTER = 'register(string,address,bool)'
ATTEST = 'attest((bytes32,(address,uint64,bool,bytes32,bytes,uint256)))'
SALT_LABEL = b'AAP-EAS-SALT-0.1\x00'
ZERO32 = '0x' + '00' * 32
MAX_PACKAGE = 65536
FLAGS = {'submitted': False, 'broadcast': False, 'chain_checked': False, 'execution_authorized': False}

REMEDIATION = {
    'EAS_KIND': 'Use kind delivery or outcome.',
    'EAS_DOMAIN': 'Pass the EAS deployment {chain_id, eas, version}: a positive chain id, the EAS contract address and a released EAS version.',
    'EAS_RECORD': 'Export only an AAP receipt that verifies with its own signatures and adopted agreement or resolver.',
    'EAS_RECIPIENT': 'Pass the recipient as a 0x Ethereum address, or omit it for the zero address.',
    'EAS_REF': 'Pass refUID as 0x and 64 hex characters (another attestation UID), or omit it.',
    'EAS_PACKAGE': 'Pass the EAS shareable package {sig, signer} with version 1 or 2 typed data exactly as the SDK writes it.',
    'EAS_VERSION': 'Only offchain attestation versions 1 and 2 are verified; version 0 is refused.',
    'EAS_UID': 'The attestation UID does not match its fields; the attestation was altered.',
    'EAS_SIGNATURE': 'The signature does not recover the named attester for these exact fields.',
    'EAS_DATA': 'The attestation data does not decode under the AAP schema, or does not match the AAP record.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the input against the documented EAS export.')


def _kind(kind):
    need(kind in SCHEMAS, 'EAS_KIND')
    return kind


def _fields(schema):
    return [part.rsplit(' ', 1) for part in schema.split(',')]


def schema_uid(schema, resolver=evm.ZERO_ADDRESS, revocable=False):
    """SchemaRegistry UID: keccak256(abi.encodePacked(schema, resolver, revocable))."""
    need(type(schema) is str and 0 < len(schema) <= 4096 and type(revocable) is bool, 'EAS_KIND')
    return '0x' + evm.keccak(evm.encode_packed(['string', 'address', 'bool'], [schema, resolver, revocable])).hex()


def register_call(kind, *, registry, resolver=evm.ZERO_ADDRESS, revocable=False):
    """SchemaRegistry.register calldata for an AAP schema; the owner submits it, or does not."""
    schema = SCHEMAS[_kind(kind)]
    try:
        registry, resolver = evm.address(registry), evm.address(resolver)
    except ValueError:
        raise ValueError('EAS_DOMAIN') from None
    data = evm.call(REGISTER, ['string', 'address', 'bool'], [schema, resolver, revocable])
    return {'kind': kind, 'schema': schema, 'schema_uid': schema_uid(schema, resolver, revocable), 'to': registry,
            'value': 0, 'function': REGISTER, 'data': '0x' + data.hex(), **FLAGS}


def _b32(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, 'EAS_RECORD')
    return bytes.fromhex(value)


def _digest(record):
    return hashlib.sha256(canonical(record)).digest()


def delivery_values(application, agreement, receipt, adoption):
    """The verified delivery receipt's fields in schema order (raises unless the receipt and assent verify)."""
    from covenant_agent import commerce
    try:
        checked = commerce.verify_receipt(application, agreement, receipt, adoption)
        buyer = commerce.terms(application)['parties']['buyer']
    except ValueError:
        raise ValueError('EAS_RECORD') from None
    need(checked['agreement_adoption'] == 'VERIFIED' and type(buyer) is str, 'EAS_RECORD')
    body = receipt['body']
    return [commerce.RECEIPT, _b32(checked['receipt']), _b32(agreement), _b32(body['application']), _b32(body['criteria']),
            body['verdict'], body['at'], _b32(buyer), _digest(receipt)], body['at']


def outcome_values(record, adopted_resolvers=None):
    """The verified portable-trust OUTCOME receipt's fields in schema order."""
    from . import portable_trust
    try:
        body = record['body']
        reference = portable_trust.record_id(body)
        checked = portable_trust.verify_outcome(record, reference, body['agreement'], body['context'], body['subject'],
                                                adopted_resolvers)
    except (ValueError, KeyError, TypeError):
        raise ValueError('EAS_RECORD') from None
    return [portable_trust.VERSION, _b32(reference), _b32(body['agreement']), body['context'], body['subject']['kind'],
            _b32(body['subject']['id']), body['outcome'], body['mode'], body['issued_at'],
            [_b32(signer) for signer in checked['signers']], _digest(record)], body['issued_at']


def _domain(domain):
    need(type(domain) is dict and set(domain) == {'chain_id', 'eas', 'version'} and type(domain['chain_id']) is int
         and 0 < domain['chain_id'] < 2 ** 63 and domain['version'] in EAS_VERSIONS, 'EAS_DOMAIN')
    try:
        return {'name': DOMAIN_NAME, 'version': domain['version'], 'chainId': domain['chain_id'],
                'verifyingContract': evm.checksum(evm.address(domain['eas']))}
    except ValueError:
        raise ValueError('EAS_DOMAIN') from None


def offchain_uid(message, version=2):
    """eas-sdk Offchain.getOffchainUID: the schema UID is packed as the UTF-8 bytes of its 0x-hex text."""
    need(version in (1, 2), 'EAS_VERSION')
    types = ['uint16', 'bytes', 'address', 'address', 'uint64', 'uint64', 'bool', 'bytes32', 'bytes'] + \
        (['bytes32'] if version == 2 else []) + ['uint32']
    values = [version, message['schema'].encode('utf-8'), message['recipient'], evm.ZERO_ADDRESS, message['time'],
              message['expirationTime'], message['revocable'], evm.unhex(message['refUID'], 32), evm.unhex(message['data'])] + \
        ([evm.unhex(message['salt'], 32)] if version == 2 else []) + [0]
    return '0x' + evm.keccak(evm.encode_packed(types, values)).hex()


def _typed(package_sig):
    types = deepcopy(package_sig['types'])
    types['EIP712Domain'] = DOMAIN_TYPES
    return {'types': types, 'primaryType': package_sig['primaryType'], 'domain': package_sig['domain'],
            'message': package_sig['message']}


def attest(kind, *, domain, attester_key, record=None, application=None, agreement=None, receipt=None, adoption=None,
           adopted_resolvers=None, recipient=evm.ZERO_ADDRESS, ref_uid=ZERO32, salt=None):
    """Owner action: a version 2 offchain attestation of one verified AAP receipt, as the SDK's shareable package."""
    _kind(kind)
    if kind == DELIVERY:
        values, at = delivery_values(application, agreement, receipt, adoption)
        record_id = values[1].hex()
    else:
        values, at = outcome_values(record, adopted_resolvers)
        record_id = values[1].hex()
    try:
        recipient = evm.checksum(evm.address(recipient))
    except ValueError:
        raise ValueError('EAS_RECIPIENT') from None
    need(type(ref_uid) is str and re.fullmatch('0x[0-9a-f]{64}', ref_uid) is not None, 'EAS_REF')
    schema = SCHEMAS[kind]
    data = evm.encode([kind_ for kind_, _ in _fields(schema)], values)
    if salt is None:
        salt = '0x' + hashlib.sha256(SALT_LABEL + kind.encode('ascii') + bytes.fromhex(record_id)).hexdigest()
    need(type(salt) is str and re.fullmatch('0x[0-9a-f]{64}', salt) is not None, 'EAS_REF')
    message = {'version': 2, 'schema': schema_uid(schema), 'recipient': recipient, 'time': at, 'expirationTime': 0,
               'revocable': False, 'refUID': ref_uid, 'data': '0x' + data.hex(), 'salt': salt}
    sig = {'version': 2, 'domain': _domain(domain), 'primaryType': 'Attest', 'types': {'Attest': deepcopy(ATTEST_V2)},
           'message': message}
    digest = evm.typed_data_digest(_typed(sig))
    signature = evm.sign_digest(attester_key, digest)
    sig.update(signature={'v': signature['v'], 'r': '0x' + signature['r'], 's': '0x' + signature['s']},
               uid=offchain_uid(message, 2))
    return {'sig': sig, 'signer': evm.checksum(evm.address_of(attester_key))}


def verify_offchain(package, *, expected_attester=None):
    """Verify an offchain attestation package with no chain: domain, types, UID and the recovered signer."""
    need(type(package) is dict and set(package) == {'sig', 'signer'} and type(package['sig']) is dict, 'EAS_PACKAGE')
    need(len(canonical(package)) <= MAX_PACKAGE, 'EAS_PACKAGE')
    sig = package['sig']
    message = sig.get('message')
    need(type(message) is dict and type(message.get('version')) is int, 'EAS_PACKAGE')
    version = message['version']
    need(version in (1, 2), 'EAS_VERSION')
    need(set(sig) in ({'domain', 'primaryType', 'types', 'message', 'signature', 'uid'},
                      {'version', 'domain', 'primaryType', 'types', 'message', 'signature', 'uid'})
         and sig.get('version', version) == version and sig['primaryType'] == 'Attest'
         and sig['types'] == {'Attest': ATTEST_V2 if version == 2 else ATTEST_V1}, 'EAS_PACKAGE')
    domain = sig['domain']
    need(type(domain) is dict and set(domain) == {'name', 'version', 'chainId', 'verifyingContract'}
         and domain['name'] == DOMAIN_NAME and domain['version'] in EAS_VERSIONS, 'EAS_PACKAGE')
    need(set(message) == {field['name'] for field in sig['types']['Attest']}, 'EAS_PACKAGE')
    signature = sig['signature']
    need(type(signature) is dict and set(signature) == {'v', 'r', 's'} and type(signature['v']) is int, 'EAS_PACKAGE')
    try:
        fields = {**message, 'time': int(message['time']), 'expirationTime': int(message['expirationTime'])}
        uid = offchain_uid(fields, version)
        digest = evm.typed_data_digest(_typed({**sig, 'domain': {**domain, 'chainId': int(domain['chainId'])}, 'message': fields}))
        raw = evm.unhex(signature['r'], 32, 'EAS_SIGNATURE') + evm.unhex(signature['s'], 32, 'EAS_SIGNATURE') + bytes([signature['v']])
        signer = evm.recover(digest, raw)
        named = evm.address(package['signer'])
    except (ValueError, TypeError, KeyError):
        raise ValueError('EAS_SIGNATURE') from None
    need(type(sig['uid']) is str and sig['uid'].lower() == uid, 'EAS_UID')
    need(signer == named and (expected_attester is None or evm.address(expected_attester) == signer), 'EAS_SIGNATURE')
    return {'status': 'VERIFIED', 'uid': uid, 'attester': evm.checksum(signer), 'schema': message['schema'],
            'version': version, 'eas': domain['verifyingContract'], 'chain_id': int(domain['chainId']),
            'basis': 'EIP712_SIGNATURE_BY_THE_ATTESTER_NOT_AN_AAP_RECEIPT', **FLAGS}


def decode_data(kind, package):
    """The attestation data as a {field: value} map under the AAP schema."""
    fields = _fields(SCHEMAS[_kind(kind)])
    message = package['sig']['message'] if type(package) is dict and type(package.get('sig')) is dict else None
    need(type(message) is dict and message.get('schema') == schema_uid(SCHEMAS[kind]), 'EAS_DATA')
    try:
        values = evm.decode([kind_ for kind_, _ in fields], evm.unhex(message['data']))
    except ValueError:
        raise ValueError('EAS_DATA') from None
    out = {}
    for (kind_, name), value in zip(fields, values):
        out[name] = '0x' + value.hex() if type(value) is bytes else ['0x' + item.hex() for item in value] if type(value) is list else value
    return out


def aap_record(kind, package, *, expected_attester=None, record=None, application=None, agreement=None, receipt=None,
               adoption=None, adopted_resolvers=None):
    """The AAP receipt itself, once it and the attestation's exact projection of it both verify.

    Reputation consumes what this returns: the AAP record, never the attestation."""
    checked = verify_offchain(package, expected_attester=expected_attester)
    _kind(kind)
    if kind == DELIVERY:
        values, at = delivery_values(application, agreement, receipt, adoption)
        found = receipt
    else:
        values, at = outcome_values(record, adopted_resolvers)
        found = record
    data = '0x' + evm.encode([kind_ for kind_, _ in _fields(SCHEMAS[kind])], values).hex()
    message = package['sig']['message']
    need(message['schema'] == schema_uid(SCHEMAS[kind]) and message['data'] == data and int(message['time']) == at, 'EAS_DATA')
    return {'kind': kind, 'record': deepcopy(found), 'attestation': checked['uid'], 'attester': checked['attester'],
            'reputation_input': 'THE_AAP_RECORD_ONLY', **FLAGS}


def attest_call(package):
    """EAS.attest(AttestationRequest) calldata for optional on-chain submission. The on-chain UID will differ."""
    checked = verify_offchain(package)
    message = package['sig']['message']
    request = [evm.unhex(message['schema'], 32), [message['recipient'], int(message['expirationTime']), message['revocable'],
                                                    evm.unhex(message['refUID'], 32), evm.unhex(message['data']), 0]]
    data = evm.call(ATTEST, ['(bytes32,(address,uint64,bool,bytes32,bytes,uint256))'], [request])
    return {'to': checked['eas'], 'chain_id': checked['chain_id'], 'value': 0, 'function': ATTEST, 'data': '0x' + data.hex(),
            'from': checked['attester'], 'onchain_uid': 'ASSIGNED_BY_EAS_ON_INCLUSION', **FLAGS}


def describe():
    return {'schemas': {kind: {'schema': schema, 'uid': schema_uid(schema), 'resolver': evm.ZERO_ADDRESS, 'revocable': False}
                        for kind, schema in SCHEMAS.items()},
            'offchain': 'eas-sdk v2.10.0 version 2 (version 1 verified)', 'contracts': 'eas-contracts v1.4.0',
            'eas_versions': list(EAS_VERSIONS), 'reputation_input': 'AAP_RECORD_ONLY', **FLAGS}
