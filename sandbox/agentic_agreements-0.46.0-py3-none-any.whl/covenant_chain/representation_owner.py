"""Owner-only signing CLI. No key is generated, uploaded or exposed to MCP.

Read a package from --input or stdin. Signing requires a recipient-adopted exact
package pin; delegated signing also requires a pinned authority snapshot and
an explicit clock value. Output is JSON on stdout; files remain owner managed.
"""
import argparse
import json
import os
import stat
import sys

from .crypto import load_private, need, public_key, sign
from .agent_tools import decode
from .launch_security import read_signing_key
from . import access_mechanisms as access, representation_authority as authority
from covenant_language import represented_agreements as records


def _read(path):
    if path is None:
        raw = sys.stdin.buffer.read(records.MAX_BYTES + 1)
    else:
        # Incoming agreement handoffs are data files, not devices or pipes.
        # In particular, opening a FIFO in blocking mode would hang before the
        # byte bound or expected package pin can be checked.
        try:
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except OSError:
            raise ValueError('REPRESENTATION_OWNER_INPUT_FILE') from None
        try:
            need(stat.S_ISREG(os.fstat(descriptor).st_mode), 'REPRESENTATION_OWNER_REGULAR_INPUT')
            with os.fdopen(descriptor, 'rb', closefd=False) as stream:
                raw = stream.read(records.MAX_BYTES + 1)
        finally:
            os.close(descriptor)
    need(len(raw) <= records.MAX_BYTES, 'REPRESENTATION_BOUND')
    try:
        return decode(raw)
    except (RecursionError, UnicodeError, json.JSONDecodeError):
        raise ValueError('REPRESENTATION_OWNER_JSON') from None


def demo():
    from copy import deepcopy
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from .crypto import digest
    from covenant_language import legal_composition as legal
    company, agent, supplier, guarantor = [Ed25519PrivateKey.generate() for _ in range(4)]
    module = legal.draft('Buy a supplier-research report for a small business', {
        'Buyer':public_key(company),'Supplier':public_key(supplier),'Guarantor':public_key(guarantor)}, {}, {
        'report':legal.node('OBLIGATION',{'debtor':'Supplier','creditor':'Buyer',
            'performance':'Deliver a cited report; buyer reviews the agreed questions; price 85 demo credits'}),
        'guarantee':legal.node('TERM',{'text':'Guarantor promises one replacement report if the agreed reviewer finds it incomplete. No collateral is represented.'})},
        [legal.reference('SELF','report'),legal.reference('SELF','guarantee')])['module']
    package = records.prepare(module,digest('SYNTHETIC-REPRESENTATION-CONTEXT',{'task':'supplier report'}))['package']
    grant = authority.grant(package,'Buyer',public_key(agent),100,200,
                            digest('SYNTHETIC-GRANT-NONCE',{'role':'Buyer'}))
    chain = [{'grant':grant['grant'],'signature':sign(company,grant['label'],grant['body'])}]
    state = authority.authority_state(package,100,200)
    buyer = authority.owner_sign(package,'Buyer',agent,records.identifier(package),chain,
        state=state['state'],expected_state=state['id'],now=120)['package']
    vendor = authority.owner_sign(package,'Supplier',supplier,records.identifier(package))['package']
    backer = authority.owner_sign(package,'Guarantor',guarantor,records.identifier(package))['package']
    merged = records.merge(buyer,vendor,records.identifier(buyer),records.identifier(vendor))['package']
    merged = records.merge(merged,backer,records.identifier(merged),records.identifier(backer))['package']
    assessed = authority.assess(merged,records.identifier(merged),state['state'],state['id'],120)
    revoked = authority.authority_state(package,125,200,[access.grant_id(grant['grant'])])
    refused = False
    try:authority.assess(merged,records.identifier(merged),revoked['state'],revoked['id'],130)
    except ValueError as e:refused = str(e)=='ACCESS_GRANT_REVOKED_OR_SUPERSEDED'
    changed = deepcopy(merged);changed['module']['title']='Counteroffer requiring fresh assent'
    amendment_refused = False
    try:records.review(changed,records.identifier(changed))
    except ValueError:amendment_refused = True
    return {'synthetic':True,'human_need':'A business delegates procurement while retaining a contractor and guarantor record',
        'profile':records.VERSION,'status':assessed['status'],'roles':assessed['actors'],
        'buyer_partial_missing':records.review(buyer,records.identifier(buyer))['missing_parties'],
        'changed_terms_reject_old_signatures':amendment_refused,
        'revoked_grant_refuses_new_authority_check':refused,
        'historical_signatures_retained':records.review(merged,records.identifier(merged))['signatures_verified'],
        'revocation_discharge':'NOT_INFERRED','funds_moved':False,'keys_saved':False,
        'execution_authorized':False}



def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('demo', 'review', 'review-grant', 'sign', 'sign-grant', 'assess'))
    parser.add_argument('--input', help='JSON package/grant file; default stdin')
    parser.add_argument('--expected-package', help='Exact independently reviewed package hash')
    parser.add_argument('--expected-grant', help='Exact independently reviewed grant hash')
    parser.add_argument('--party')
    parser.add_argument('--key-file', help='Owner-only existing private key file')
    parser.add_argument('--chain', help='Signed grant-chain JSON file')
    parser.add_argument('--state', help='Authority state from a separately adopted source')
    parser.add_argument('--expected-state', help='Independently adopted authority-state hash')
    parser.add_argument('--now', type=int, help='Recipient clock in agreed seconds')
    parser.add_argument('--maximum-age', type=int, default=300)
    args = parser.parse_args(argv)
    try:
        if args.action == 'demo':
            print(json.dumps(demo(),sort_keys=True))
            return 0
        obj = _read(args.input)
        if args.action == 'review-grant':
            access.validate_grant(obj)
            result = {'grant': obj, 'id': access.grant_id(obj),
                'scope': 'CHECK_ISSUER_DELEGATE_TARGET_ROLE_AND_TIME_BEFORE_EXPLICIT_SIGNING',
                'execution_authorized': False}
        elif args.action == 'sign-grant':
            access.validate_grant(obj)
            need(args.expected_grant is not None and access.grant_id(obj) == args.expected_grant,
                 'REPRESENTATION_EXPECTED_GRANT')
            need(args.key_file is not None, 'REPRESENTATION_OWNER_KEY_REQUIRED')
            key = load_private(read_signing_key(args.key_file))
            need(public_key(key) == obj['issuer'], 'REPRESENTATION_GRANT_SIGNER')
            payload = access.grant_payload(obj)
            result = {'grant': obj, 'signature': sign(key, payload['label'], payload['body'])}
        else:
            need(args.expected_package is not None, 'REPRESENTATION_EXPECTED_PACKAGE_REQUIRED')
            if args.action == 'review':
                result = records.review(obj, args.expected_package)
            else:
                state = _read(args.state) if args.state is not None else None
                if args.action == 'assess':
                    need(state is not None and args.expected_state is not None and args.now is not None,
                         'REPRESENTATION_OWNER_AUTHORITY_STATE_REQUIRED')
                    result = authority.assess(obj, args.expected_package, state, args.expected_state,
                                              args.now, args.maximum_age)
                else:
                    need(args.key_file is not None and args.party is not None,
                         'REPRESENTATION_OWNER_KEY_AND_PARTY_REQUIRED')
                    key = load_private(read_signing_key(args.key_file))
                    result = authority.owner_sign(obj, args.party, key, args.expected_package,
                        _read(args.chain) if args.chain else [], state=state,
                        expected_state=args.expected_state, now=args.now, maximum_age=args.maximum_age)
        print(json.dumps(result, sort_keys=True))
        return 0
    except ImportError:
        # A received optional signature suite cannot turn the owner interface
        # into a traceback or trigger installation from untrusted content.
        print(json.dumps({'error': 'REPRESENTATION_SIGNATURE_DEPENDENCY_UNAVAILABLE',
            'next_action': 'Install the owner-selected optional signature suite, then review the exact package again.',
            'execution_authorized': False}), file=sys.stderr)
        return 2
    except (ValueError, OSError, TypeError, KeyError) as error:
        # No traceback, private key data, received document or host path in errors.
        code = str(error) if isinstance(error, ValueError) else 'REPRESENTATION_OWNER_INPUT'
        print(json.dumps({'error': code[:160], 'execution_authorized': False}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
