"""Opt-in economic SDK: caller pins a fee policy and maximum cost explicitly.

The default native/0.9 profile retains its historical economics/0.1 meaning.
Tokenomics operations require an explicit ``protocol=TOKENOMICS_VERSION`` pin
and a native/0.15 chain with an adopted economics/0.3 policy. Profile selection
does not establish independent finality or authorize a fee beyond the cap.

Service stakes use ``MarketClient.stake(operator, quantity, acceptance)`` and
its exact counterparty acceptance; this client has no alternate stake methods.
"""
from .world_sdk import WorldClient
from .app import ECONOMIC_VERSION, TOKENOMICS_VERSION, MIGRATION_VERSION

PROFILES = (ECONOMIC_VERSION, TOKENOMICS_VERSION, MIGRATION_VERSION)


class EconomyClient(WorldClient):
    def __init__(self, client, private_key, chain, *, fee_policy, max_fee, actor=None, sponsor=None,
                 protocol=ECONOMIC_VERSION):
        from .crypto import need
        need(type(protocol) is str and protocol in PROFILES, 'SDK_PROFILE')
        super().__init__(client, private_key, chain, actor=actor, protocol=protocol,
                         fee_policy=fee_policy, max_fee=max_fee, sponsor=sponsor)

    def sponsor_fees(self, resource, budget, actors, operations, per_actor_cap, expiry):
        return self.submit('ECON_SPONSOR_CREATE', dict(resource=resource, budget=budget,
            actors=sorted(set(actors)), operations=sorted(set(operations)),
            per_actor_cap=per_actor_cap, expiry=expiry))

    def close_sponsor(self, sponsor):
        return self.submit('ECON_SPONSOR_CLOSE', {'sponsor': sponsor})

    def create_reward(self, domain, resource, root, expiry, eligibility='APPROVED'):
        return self.submit('ECON_REWARD_CREATE', dict(domain=domain, resource=resource,
            root=root, expiry=expiry, eligibility=eligibility))

    def claim_reward(self, campaign, opening):
        return self.submit('ECON_REWARD_CLAIM', {'campaign': campaign, **opening})

    def reclaim_expired_reward(self, campaign):
        return self.submit('ECON_REWARD_RECLAIM', {'campaign': campaign})

    def clear(self, clearing, resource, transfers, approvals):
        return self.submit('ECON_CLEAR', dict(clearing=clearing, resource=resource,
                                             transfers=transfers, approvals=approvals))

    # covenant-economics/0.3 only: explicitly pin protocol=TOKENOMICS_VERSION.
    # Earlier economics profiles reject these with UNKNOWN_ECONOMIC_OPERATION.
    # None of them mint supply.
    def lock_bond(self, amount):
        return self.submit('ECON_BOND_LOCK', {'amount': amount})

    def release_bond(self, amount):
        return self.submit('ECON_BOND_RELEASE', {'amount': amount})

    def claim_rebate(self, amount):
        return self.submit('ECON_REBATE_CLAIM', {'amount': amount})

    def note_integrator(self, agreement, integrator):
        return self.submit('ECON_INTEGRATOR_NOTE', {'agreement': agreement, 'integrator': integrator})

    def pay_integrator(self, integrator, amount):
        return self.submit('ECON_INTEGRATOR_PAY', {'integrator': integrator, 'amount': amount})

    def sweep_integrator(self, amount):
        return self.submit('ECON_INTEGRATOR_SWEEP', {'amount': amount})

    def ad_subsidy(self, receipt):
        return self.submit('ECON_AD_SUBSIDY', {'receipt': receipt})

    def clawback_reward(self, campaign, claim):
        return self.submit('ECON_REWARD_CLAWBACK', {'campaign': campaign, 'claim': claim})

    def vest_reward(self, campaign, claim):
        return self.submit('ECON_REWARD_VEST', {'campaign': campaign, 'claim': claim})

    def canonical_status(self, pinned_genesis, manifest=None):
        """Loud pin for a light client, SDK, or MCP host. Does not submit a transaction."""
        from .fork_defence import mcp_advertisement
        return mcp_advertisement(self.chain, pinned_genesis, manifest)

    def explain_fee(self, stable_amount, token_amount):
        """The savings line only when paying in the token is actually cheaper.

        A token quote above the stable quote is an impossible pair (TOKEN_SAVINGS);
        equal quotes say nothing rather than 'you saved 0'.
        """
        from .crypto import need
        from .token_preference import savings_line
        need(type(stable_amount) is int and type(token_amount) is int and 0 <= token_amount <= stable_amount, 'TOKEN_SAVINGS')
        if stable_amount == token_amount:
            return ''
        return savings_line(stable_amount, token_amount)

    def balance_of(self, state, resource=None):
        """This client's ledger balances in a state snapshot. Read-only."""
        from .wallet import balance
        return balance(state, self.actor, resource)

    def payment_quote(self, policy, view):
        """The stable and token fee for one unit under the adopted 0.3 policy. Nothing is charged."""
        from .scale_fees import fee_parts
        from .token_preference import savings_line
        stable = fee_parts(policy, 0, 0, view, 0, None)
        token_tx = {'body': {'actor': self.actor, 'op': 'REGISTER_RESOURCE',
                             'fee': {'asset': policy['scale']['supply']['resource']}}}
        token = fee_parts(policy, 0, 0, view, 0, token_tx)
        saved = stable['total'] - token['total']
        return {'stable': stable['total'], 'token': token['total'], 'saved': saved,
                'token_discount': token['token_discount'],
                'line': savings_line(stable['total'], token['total']) if saved > 0 else '',
                'execution_authorized': False}

    def arm_founder_payouts(self):
        return self.submit('ECON_FOUNDER_PAYOUTS', {'chain': self.chain})
