"""Disposable, key-local robot/A2A simulation; no device or external network."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json

from . import a2a_agreement_gate as g
from . import robotics as r
from .robotics_adapters import RosbridgeAction


def run():
    sent, inbox = [], []
    driver = RosbridgeAction(robot='simulated-porter', action='/porter/route',
        action_type='example_interfaces/action/Fibonacci',
        semantics={'purpose': 'synthetic robot action, not actual movement', 'unit': 'count', 'maximum': 8},
        session='synthetic-owner-session', implementation='a'*64,
        send=sent.append, receive=lambda _: inbox.pop(0) if inbox else None)
    prepared = r.draft('simulated-porter', r.binding_id(driver.binding), 'ros.action',
        {'order': 5}, 90, 150, 'b'*64,
        context={'who': ['synthetic customer', 'synthetic operator'],
                 'why': 'try exact task coordination without a robot'})
    mission, ref = prepared['mission'], prepared['id']
    fixture = g.demo_fixture(operation='robot.submit', payload=mission)
    def authorize(caller, selected, action):
        return dict(revision=1, now=100,
            allowed=caller == fixture['caller'] and r.mission_id(selected) == ref,
            ready=True, observed_at=100, valid_until=120)
    with TemporaryDirectory(prefix='covenant-robot-demo-') as directory:
        robot_dir = Path(directory)/'robot'
        runtime = r.RobotRuntime(robot_dir, driver=driver, authorize=authorize)
        gate = g.AgreementGate(Path(directory)/'a2a', service=fixture['service'], policy_id=fixture['policy_id'],
            owner_state=lambda: fixture['state'], execute=runtime.a2a_executor, receipt_key=fixture['receipt_key'])
        try:
            task = gate.dispatch('SendMessage', fixture['params'], caller=fixture['caller'],
                                 active_extensions=fixture['active_extensions'])['task']
            dispatch = g.decode_task_artifact(task)['execution_result']
            runtime.close()
            runtime = r.RobotRuntime(robot_dir, driver=driver, authorize=authorize)
            # Identical adopted mission is retained, never transmitted again.
            duplicate = runtime.submit(mission, caller=fixture['caller'])
            inbox.append({'op': 'action_feedback', 'id': ref, 'action': '/porter/route', 'values': {'sequence': [1, 1]}})
            progress = runtime.observe(mission, caller=fixture['caller'])
            inbox.append({'op': 'action_result', 'id': ref, 'action': '/porter/route',
                          'status': 4, 'result': True, 'values': {'sequence': [1, 1, 2, 3, 5]}})
            final = runtime.observe(mission, caller=fixture['caller'])
            evidence = gate.export_evidence(task['id'], caller=fixture['caller'],
                tenant=fixture['agreement']['tenant'], active_extensions=fixture['active_extensions'])
            verified = g.verify_evidence(evidence, expected_agreement=fixture['agreement'],
                                         expected_receipt_signer=g.public_key(fixture['receipt_key']))
            return {'status': 'PASS', 'simulation': True, 'mission': ref,
                'journey': [prepared['status'], dispatch['status'], duplicate['status'], progress['status'], final['status']],
                'dispatches_across_restart': len(sent), 'a2a_dispatch_task_state': task['status']['state'],
                'historical_receipt_verified': verified['receipt_signature_verified'],
                'physical_delivery_verified': False, 'payment_verified': False,
                'hardware_qualified': False, 'external_network_calls': 0}
        finally:
            runtime.close(); gate.close()


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True, indent=2))
