"""Principal override over an existing grant. This is not a native operation.

A delegate binds only when a live GIVE grant is the mandate. The policy may
narrow that grant, a PERMIT, a reliance mandate, and the continuity epoch.
It does not move authority_available onto a second record, and it does not
let the delegate bind as the principal when the grant is missing.
"""
from copy import deepcopy

from .crypto import canonical, exact, integer, key, need, verify

VERSION = 'covenant-principal-override/1.0'
LABEL = 'COVENANT-PRINCIPAL-OVERRIDE-1.0'
EFFECTS = {'AUTHORIZE', 'CONSUME', 'TRANSFER'}


def validate(policy):
    canonical(policy)
    exact(policy, 'version principal agent grant permit action context spend expiry effects profiles counterparties window')
    need(policy['version'] == VERSION, 'PRINCIPAL_VERSION')
    from .crypto import FieldError, resolve_party
    resolve_party(policy['principal'], 'principal')
    resolve_party(policy['agent'], 'agent')
    for name in ('grant', 'permit', 'context'):
        try:
            key(policy[name])
        except ValueError as exc:
            raise FieldError('KEY', name, '^[0-9a-f]{64}$',
                             f'{name} must be a 64-character lowercase hex id.') from exc
    need(policy['agent'] != policy['principal'], 'PRINCIPAL_AUTHORITY')
    need(type(policy['action']) is str and 0 < len(policy['action']) <= 80, 'PERMISSION_SCOPE')
    integer(policy['expiry'])
    integer(policy['window'], True)
    need(policy['window'] <= 10000, 'PRINCIPAL_WINDOW')
    need(type(policy['spend']) is dict and 1 <= len(policy['spend']) <= 8, 'PRINCIPAL_SPEND')
    for resource, amount in policy['spend'].items():
        need(type(resource) is str and 0 < len(resource) <= 80, 'PRINCIPAL_SPEND')
        integer(amount, True)
    for field in ('effects', 'profiles', 'counterparties'):
        value = policy[field]
        need(type(value) is list and value == sorted(set(value)) and bool(value), 'PRINCIPAL_SCOPE')
    need(set(policy['effects']) <= EFFECTS, 'PRINCIPAL_SCOPE')
    need(len(policy['counterparties']) <= 32, 'PRINCIPAL_COUNTERPARTY')
    for index, party in enumerate(policy['counterparties']):
        resolve_party(party, f'counterparties[{index}]')
        need(party != policy['agent'], 'PRINCIPAL_COUNTERPARTY')
    return True


def draft(principal, agent, grant, permit, action, context, spend, expiry, effects, profiles, counterparties, window):
    policy = {
        'version': VERSION, 'principal': principal, 'agent': agent, 'grant': grant, 'permit': permit,
        'action': action, 'context': context, 'spend': deepcopy(spend), 'expiry': expiry,
        'effects': sorted(set(effects)), 'profiles': sorted(set(profiles)),
        'counterparties': sorted(set(counterparties)), 'window': window,
    }
    validate(policy)
    return policy


def _epoch(state, grant):
    from .continuity import authority_epoch
    if 'continuity_epoch' in grant or 'continuity_policies' in state:
        need(grant.get('continuity_epoch', 0) == authority_epoch(state, grant['principal']), 'GRANT_INACTIVE')


def authorize_bind(state, terms, policy, signature, height):
    """Refuse the bind unless the mandate is a live GIVE grant this policy only narrows."""
    validate(policy)
    verify(policy['principal'], LABEL, policy, signature)
    exact(terms, 'chain principal agent counterparty mandate profile resource quantity effect destination executor resolver appeal_resolver deadline challenge_blocks timeout terms_hash')
    need(terms['agent'] != terms['principal'], 'PRINCIPAL_AUTHORITY')
    need(terms['mandate'] is not None and terms['mandate'] == policy['grant'], 'GRANT_MISSING')
    need(terms['principal'] == policy['principal'] and terms['agent'] == policy['agent'], 'GRANT_HOLDER')
    from .app import live_grant
    grant = live_grant(state, policy['grant'], height)
    need(grant['holder'] == policy['agent'] and grant['principal'] == policy['principal'], 'GRANT_HOLDER')
    need(set(policy['spend']) == {grant['resource']} and terms['resource'] == grant['resource'], 'PRINCIPAL_SPEND')
    need(terms['quantity'] <= policy['spend'][terms['resource']] <= grant['remaining'], 'PRINCIPAL_SPEND')
    integer(height, True)
    integer(terms['deadline'])
    need(height <= terms['deadline'] <= policy['expiry'] <= grant['expiry'], 'PRINCIPAL_EXPIRY')
    need(terms['effect'] in policy['effects'] and set(policy['effects']) <= set(grant['effects']), 'PRINCIPAL_SCOPE')
    need(terms['profile'] in policy['profiles'] and set(policy['profiles']) <= set(grant['profiles']), 'PRINCIPAL_SCOPE')
    need(terms['counterparty'] in policy['counterparties'], 'PRINCIPAL_COUNTERPARTY')
    permissions = state.get('permissions')
    need(permissions is not None and policy['permit'] in permissions, 'PERMISSION_MISSING')
    permission = permissions[policy['permit']]
    need(permission['issuer'] == policy['principal'] and permission['holder'] == policy['agent'], 'PERMISSION_ISSUER')
    need(not permission['revoked'] and height <= permission['expiry'] and policy['expiry'] <= permission['expiry'], 'PERMISSION_INACTIVE')
    need(permission['action'] == policy['action'] and permission['context'] == policy['context'], 'PERMISSION_SCOPE')
    _epoch(state, grant)
    return {'authorized': True, 'grant': policy['grant'], 'delegate_bound_without_grant': False,
            'moves_authority': False, 'execution_authorized': False}


def reliance_narrows(policy, intent, grant_remaining):
    """A reliance mandate may only narrow. It is not a second source of authority."""
    from .reliance import validate_intent, validate_policy, wallet_id
    validate_policy(policy)
    validate_intent(intent)
    need(intent['wallet'] == wallet_id(policy), 'RELIANCE_SCOPE')
    need(policy['not_before'] <= intent['not_before'] and intent['expires'] <= policy['expires'], 'RELIANCE_EXPIRED')
    need(type(grant_remaining) is dict and grant_remaining, 'PRINCIPAL_SPEND')
    for resource, amount in intent['allocations'].items():
        need(resource in policy['per_action'] and amount <= policy['per_action'][resource] <= policy['limits'][resource], 'RELIANCE_ALLOCATION')
        need(resource in grant_remaining and amount <= grant_remaining[resource], 'PRINCIPAL_SPEND')
        need(policy['limits'][resource] <= grant_remaining[resource] and policy['per_action'][resource] <= grant_remaining[resource], 'PRINCIPAL_SPEND')
    return {'narrows': True, 'widens_grant': False, 'execution_authorized': False}


def _open(agreement):
    need(type(agreement) is dict and agreement.get('held') is True, 'ALREADY_DISCHARGED')
    need(agreement.get('state') != 'AUTHORIZED' and 'effect_id' not in agreement, 'PRINCIPAL_SETTLED')


def revoke_before_settlement(agreement, reliance_state=None):
    """REVOKE unused grant remaining, and reliance cancel only while the intent is still HELD.

    Neither path unbinds an agreement that native BIND already formed, and neither
    takes back funds EXECUTE already delivered.
    """
    _open(agreement)
    cancel = False
    if reliance_state is not None:
        need(reliance_state == 'HELD', 'RELIANCE_CANNOT_RELEASE_AFTER_START')
        cancel = True
    return {'revoke_grant': True, 'cancel_reliance': cancel, 'confiscate': False,
            'unbinds_existing_agreement': False, 'execution_authorized': False}


def challenge(agreement, height, policy):
    """A signed instruction to use the existing CHALLENGE op. It adds no native signer."""
    validate(policy)
    _open(agreement)
    need(agreement['state'] in {'BOUND', 'DECIDED', 'INDETERMINATE', 'CHALLENGED'}, 'CHALLENGE_AUTHORITY_STATE')
    integer(height, True)
    need(height <= agreement['height'] + policy['window'], 'PRINCIPAL_WINDOW')
    if agreement.get('challenge_end') is not None:
        need(height <= agreement['challenge_end'], 'CHALLENGE_CLOSED')
    return {'verdict': 'CHALLENGE', 'native_op': 'CHALLENGE', 'adds_native_signer': False,
            'execution_authorized': False}


def overturn(agreement, height, policy):
    """Before settlement the principal may still REVOKE. After EXECUTE this refuses."""
    validate(policy)
    _open(agreement)
    integer(height, True)
    need(height <= agreement['height'] + policy['window'], 'PRINCIPAL_WINDOW')
    return {'verdict': 'OVERTURN_BEFORE_SETTLEMENT', 'confiscate': False, 'changes_native_state': False,
            'native_ops': ['REVOKE'], 'unbinds_existing_agreement': False, 'execution_authorized': False}
