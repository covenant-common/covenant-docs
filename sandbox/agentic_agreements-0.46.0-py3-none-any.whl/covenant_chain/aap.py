"""aap: one command for AAP, starting from the golden path.

    aap                                  the model, the three steps and aap demo
    aap demo                             a complete synthetic deal in seconds
    aap propose "One logo" --price 50    offer exact terms and sign them
    aap accept DEAL                      the other side signs; the price is held
    aap settle DEAL                      deliver with proof, then release payment
    aap show [DEAL]                      list your test deals, or show and check one
    aap setup                            make the test keys; print the test hosts for an agent
    aap help [JOB]                       the seven jobs; aap help commands lists every command
    aap adapter ...                      AAP Connect: plug a service into AAP, when this build has it
    aap NAME ...                         every earlier command, unchanged: aap chain, aap agent ...

Test mode is the default: synthetic units and test keys in a folder only you
can read ($COVENANT_HOME/test-mode), nothing real. The steps run the same
signing hosts an agent uses (covenant_agent), each with its own test key, and a
local test payment record. Real value needs your own keys and payment
provider; --live says so and stops.
"""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
from importlib import import_module
from importlib.util import find_spec
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import sys
import tempfile
import time

from .plain_words import JOBS, MODEL, STEPS, golden_path, job

DEAL_FORMAT = 'covenant-aap-deal/0.1'
DEMO_FORMAT = 'covenant-aap-demo/0.1'
REFERENCE = 'docs/AAP_COMMAND.html'
LABEL = 'TEST MODE: synthetic units, test keys, nothing real.'
TEST_BALANCE = 1_000_000
MAX_TEXT = 400
MAX_WORK = 1_000_000
MAX_DEALS = 10_000
MAX_RECORD = 4_000_000
MAX_DAYS = 365
DAY = 86_400
LOCK_SECONDS = 10
ROLES = ('buyer', 'seller', 'resolver', 'appeal')
NAMES = {'buyer': 'buyer', 'seller': 'seller', 'resolver': 'referee', 'appeal': 'appeal referee'}
DEMO = {'what': 'One stock report for a small shop', 'price': 45, 'days': 7,
        'work': b'SYNTHETIC stock report: 12 items counted, 3 to reorder.\n'}
EXAMPLE = 'aap propose "One logo as a PNG file" --price 50'
_HEX64 = re.compile(r'[0-9a-f]{64}\Z')
_PREFIX = re.compile(r'[0-9a-f]{4,64}\Z')

# Every refusal: what happened, the fix, and whether a retry helps. The code
# is stable; docs/AAP_COMMAND.html has one entry per code.
ERRORS = {
    'AAP_ARGUMENTS': ('{detail}.', 'Run aap help to see the commands, or add --help after one command.',
                      'after the fix'),
    'AAP_UNKNOWN_COMMAND': ('There is no aap command "{name}".',
                            'Run aap help commands to list every command, including the earlier covenant ones.',
                            'after the fix'),
    'AAP_HELP_TOPIC': ('There is no help topic "{topic}".',
                       'Use a job number from 1 to 7, a job such as pay, a verb such as refund, or commands.',
                       'after the fix'),
    'AAP_TEXT': ('The deal text must be 1 to 400 plain ASCII characters.',
                 'Shorten it, or use plain letters, digits and punctuation.', 'after the fix'),
    'AAP_PRICE': ('The price must be a whole number from 1 to 1000000 test units.',
                  'Pass --price with a whole number in that range.', 'after the fix'),
    'AAP_DAYS': ('The time to deliver must be 1 to 365 days.', 'Pass --days with a whole number in that range.',
                 'after the fix'),
    'AAP_LIVE': ('aap runs in test mode only. Real value needs your own keys and a payment provider you chose.',
                 'Read docs/OWNER_SETUP.html. Each side then runs its own signing host with its own keys.', 'no'),
    'AAP_NO_DEALS': ('There is no test folder at {home} yet.',
                     'Start with ' + EXAMPLE + ', or pass --home with the folder you used before.', 'after the fix'),
    'AAP_TEST_FOLDER': ('The test folder {home} cannot be used: {reason}.',
                        'Use a folder only you can read (chmod 700), or choose a new one with --home.',
                        'after the fix'),
    'AAP_FOLDER_BUSY': ('Another aap command is using {home}.', 'Wait for it to finish, then run this command again.',
                        'yes'),
    'AAP_DEAL_UNKNOWN': ('There is no test deal "{deal}".', 'Run aap show to list your deals, then use one of those IDs.',
                         'after the fix'),
    'AAP_DEAL_AMBIGUOUS': ('"{deal}" matches more than one deal.', 'Type more of the deal ID; aap show lists them.',
                           'after the fix'),
    'AAP_DEAL_STEP': ('Deal {deal} is {stage}, so it cannot be {verb} now.', 'Run aap show {deal}; it names the next step.',
                      'no'),
    'AAP_DEAL_UNREADABLE': ('The saved deal {deal} does not check out.',
                            'Keep the file for review and start a new deal with aap propose.', 'no'),
    'AAP_WORK': ('The work must be 1 to 1000000 bytes.', 'Pass --work with text, or --file with a smaller file.',
                 'after the fix'),
    'AAP_WORK_FILE': ('The file {file} could not be read.', 'Check the path, and that you can read the file.',
                      'after the fix'),
    'AAP_WORK_CHANGED': ('An earlier attempt already delivered different work for deal {deal}.',
                         'Run aap settle {deal} without --work or --file to finish with that work.', 'after the fix'),
    'AAP_STEP_REFUSED': ('The {verb} step was refused: {reason}.', '{fix}', '{retry}'),
    'AAP_CONNECT_MISSING': ('AAP Connect is not installed in this build, so aap adapter is not available.',
                            'Install a build that includes AAP Connect (covenant_chain.connect_cli), '
                            'then run aap adapter again.', 'after the fix'),
}

# Each code in plain text, without the values a refusal fills in: what docs/REFERENCE.html and the shared
# error catalogue (covenant_chain/data/error_fixes.json) list for the aap command. ERRORS above
# is what aap itself prints.
REMEDIATION = {
    'AAP_ARGUMENTS':
        'The aap command line has a missing or wrong argument. Run aap help to see the commands, or add '
        '--help after one command.',
    'AAP_UNKNOWN_COMMAND':
        'There is no aap command with that name. Run aap help commands to list every command, including the '
        'earlier covenant ones.',
    'AAP_HELP_TOPIC':
        'There is no help topic with that name. Use a job number from 1 to 7, a job such as pay, a verb such '
        'as refund, or commands.',
    'AAP_TEXT':
        'The deal text must be 1 to 400 plain ASCII characters. Shorten it, or use plain letters, digits and '
        'punctuation.',
    'AAP_PRICE':
        'The price must be a whole number from 1 to 1000000 test units. Pass --price with a whole number in '
        'that range.',
    'AAP_DAYS': 'The time to deliver must be 1 to 365 days. Pass --days with a whole number in that range.',
    'AAP_LIVE':
        'The aap command runs in test mode only; real value needs your own keys and a payment provider you '
        'chose. Read docs/OWNER_SETUP.html; each side then runs its own signing host with its own keys.',
    'AAP_NO_DEALS':
        'There is no aap test folder yet. Start with aap propose, or pass --home with the folder you used '
        'before.',
    'AAP_TEST_FOLDER':
        'The test folder cannot be used: it is not private, not an aap test folder, or not readable. Use a '
        'folder only you can read (chmod 700), or choose a new one with --home.',
    'AAP_FOLDER_BUSY':
        'Another aap command is using the test folder. Wait for it to finish, then run this command again.',
    'AAP_DEAL_UNKNOWN':
        'There is no test deal with that ID. Run aap show to list your deals, then use one of those IDs.',
    'AAP_DEAL_AMBIGUOUS':
        'That deal ID prefix matches more than one deal. Type more of the deal ID; aap show lists them.',
    'AAP_DEAL_STEP':
        'The deal is at another step, so this command cannot run on it now. Run aap show with the deal ID; '
        'it names the next step.',
    'AAP_DEAL_UNREADABLE':
        'The saved test deal does not check out. Keep the file for review and start a new deal with aap '
        'propose.',
    'AAP_WORK': 'The work must be 1 to 1000000 bytes. Pass --work with text, or --file with a smaller file.',
    'AAP_WORK_FILE': 'The work file could not be read. Check the path, and that you can read the file.',
    'AAP_WORK_CHANGED':
        'An earlier attempt already delivered different work for this deal. Run aap settle with the deal ID '
        'and without --work or --file to finish with that work.',
    'AAP_STEP_REFUSED':
        'The signing host refused this step; the reply names its reason, fix and whether a retry helps. '
        'Follow that fix, then run the step again.',
    'AAP_CONNECT_MISSING':
        'AAP Connect is not installed in this build, so aap adapter is not available. Install a build that '
        'includes AAP Connect (covenant_chain.connect_cli), then run aap adapter again.',
}

# Codes a signing host can return during a test step, in plain words.
STEP_REASONS = {
    'DEADLINE_EXPIRED': ('the deadline has passed', 'Propose a new deal with more days (--days).', 'no'),
    'PAYMENT_FUNDS': ('the test buyer does not hold enough test units',
                      'Propose a lower price, or start a new test folder with --home.', 'no'),
    'DOCUMENT': ('the deal text was refused', 'Use 1 to 400 plain ASCII characters.', 'after the fix'),
    'ASCII_PROFILE': ('the deal text was refused', 'Use 1 to 400 plain ASCII characters.', 'after the fix'),
}

STAGES = {
    'PROPOSED': ('proposed', 'Waiting for the other side to sign.', 'aap accept {deal}'),
    'BOUND': ('signed', 'Both sides signed the same terms. The price is held.', 'aap settle {deal}'),
    'DELIVERED': ('delivered', 'The work was delivered with proof. Payment is not released yet.', 'aap settle {deal}'),
    'DISPUTED': ('in a fair fix', 'Someone raised a problem. The referee decides.', 'aap help fix'),
    'DECIDED': ('decided', 'The referee decided. Payment follows that decision.', 'aap help fix'),
    'SETTLED': ('settled', 'Paid. The deal is complete.', None),
    'RELEASED': ('refunded', 'The held price went back to the buyer.', None),
    'INVALID': ('unreadable', 'This saved deal does not check out.', None),
}

# The golden-path commands, in the order aap help commands shows them.
COMMANDS = (
    ('propose', STEPS[0][1]),
    ('accept', STEPS[1][1]),
    ('settle', STEPS[2][1]),
    ('demo', 'Run a complete synthetic deal in seconds.'),
    ('show', 'List your test deals, or show one deal and check it.'),
    ('setup', 'Make the test keys and print the two test hosts for an agent.'),
    ('help', 'The seven jobs, one job, or this list (aap help commands).'),
    ('adapter', 'Plug your service into AAP as an adapter: a payment method, forum, identity, directory and more.'),
)

# Earlier commands, unchanged: aap NAME runs the function the console script
# (or module command) names, with the same arguments and exit status. Each
# import names its module literally. The six historical alias names keep only
# their earlier name: aap covenant-verify, aap covenant-peer, and so on.
EARLIER = (
    ('agent', 'covenant-agent', lambda: import_module('covenant_chain.agent_server').main,
     'Start the keyless tool server for agents (MCP).'),
    ('agentic-agreements', 'agentic-agreements', lambda: import_module('covenant_chain.agent_server').main,
     'The same tool server, under the package name.'),
    ('agent-native', 'covenant-agent-native', lambda: import_module('covenant_agent.server').main,
     'Start a signing tool server for one side of a deal.'),
    ('covenant', 'covenant', lambda: import_module('covenant_agent.cli').main,
     'Find, explain, draft, check and counter actions in the terminal.'),
    ('language', 'covenant-language', lambda: import_module('covenant_language.__main__').main,
     'Work offline with the portable deal language.'),
    ('sandbox', 'covenant-sandbox', lambda: import_module('covenant_language.sandbox').main,
     'Run a repeatable many-agent experiment with no outside effects.'),
    ('modules', 'covenant-modules', lambda: import_module('covenant_language.module_registry').main,
     'Pack and check local language modules; installing never runs code.'),
    ('chain', 'covenant-chain', lambda: import_module('covenant_chain.node').main,
     'Run an optional ledger node. Deals work without one.'),
    ('feedback', 'covenant-feedback', lambda: import_module('covenant_chain.feedback').main,
     'Keep signed founder feedback and the replies to it.'),
    ('gateway', 'covenant-gateway', lambda: import_module('covenant_chain.network_gateway').main,
     'Run the network gateway in front of a ledger node.'),
    ('mainnet-preflight', 'covenant-mainnet-preflight', lambda: import_module('covenant_chain.mainnet').main,
     'Read-only checks before a public network launch.'),
    ('cooperate', 'covenant-cooperate', lambda: import_module('covenant_chain.cooperation_cli').main,
     'Compare and assess work plans locally. Never signs or sends.'),
    ('earn', 'covenant-earn', lambda: import_module('covenant_agent.earn').main,
     'Run the example earning agent.'),
    ('bench', 'covenant-bench', lambda: import_module('covenantbench.__main__').main,
     'Print the benchmark report.'),
    ('developer', 'covenant-developer', lambda: import_module('covenant_chain.developer_cli').main,
     'Start a new developer project, or check a gateway audit.'),
    ('offline', 'covenant-offline', lambda: import_module('covenant_chain.offline_cli').main,
     'Keep keys and sign deals on a machine with no Internet.'),
    ('update', 'covenant-update', lambda: import_module('covenant_chain.update_trust').main,
     'Check a software or version update, from any source.'),
    ('settlement', 'covenant-settlement', lambda: import_module('covenant_chain.settlement_plugins.__main__').main,
     'List the payment plugins. All stay off until the owner turns them on.'),
    ('proof', 'covenant-evidence', lambda: import_module('covenant_chain.evidence_cli').main,
     'Seal a photo or a location as proof.'),
    ('public-web', 'covenant-public-web', lambda: import_module('covenant_chain.public_web').main,
     'Publish chosen public pages, only when you opt in.'),
    ('welcome', 'covenant-welcome', lambda: import_module('covenant_chain.welcome_app').main,
     'Open the local welcome page in your browser.'),
    ('handoff', 'covenant-handoff', lambda: import_module('covenant_chain.owner_handoff_app').main,
     'Review and sign your own deal locally, then hand it over.'),
    ('backup', 'covenant-backup', lambda: import_module('covenant_chain.backup').main,
     'Back up, check and restore the local stores.'),
    ('doctor', 'covenant-doctor', lambda: import_module('covenant_chain.ops_doctor').main,
     'Check a service setup before it starts.'),
    ('quickstart', 'python -m covenant_chain.quickstart', lambda: import_module('covenant_chain.quickstart').main,
     'Print a first unsigned draft. No keys, network or payment.'),
    ('pilot', 'python -m covenant_chain.pilot', lambda: import_module('covenant_chain.pilot').main,
     'Invited pilot: check this install, run a lesson, print agent setup.'),
    ('tasks', 'python -m covenant_chain.onboarding', lambda: import_module('covenant_chain.onboarding').main,
     'Find a task by ordinary words and print its exact call.'),
    (None, 'covenant-peer', lambda: import_module('covenant_chain.aliases').peer, 'Earlier name kept for old guides.'),
    (None, 'covenant-validator', lambda: import_module('covenant_chain.aliases').validator,
     'Earlier name kept for old guides.'),
    (None, 'covenant-verify', lambda: import_module('covenant_chain.aliases').verify,
     'Earlier name kept for old guides.'),
    (None, 'covenant-state', lambda: import_module('covenant_chain.aliases').state, 'Earlier name kept for old guides.'),
    (None, 'covenant-py', lambda: import_module('covenant_chain.aliases').py, 'Earlier name kept for old guides.'),
    (None, 'covenant-common-language', lambda: import_module('covenant_chain.aliases').common_language,
     'Earlier name kept for old guides.'),
)
ALIASES = {}
for _short, _earlier, _load, _purpose in EARLIER:
    if not _earlier.startswith('python '):
        ALIASES[_earlier] = (_earlier, _load)
    if _short is not None:
        ALIASES[_short] = (_earlier, _load)
del _short, _earlier, _load, _purpose


class Refusal(Exception):
    """A plain refusal: a stable code, what happened, the fix and whether a retry helps."""

    def __init__(self, code, **values):
        super().__init__(code)
        self.code, self.values = code, values

    def body(self):
        what, fix, retry = ERRORS[self.code]
        values = {key: str(value) for key, value in self.values.items()}
        body = {'status': 'REFUSED', 'code': self.code, 'what': what.format(**values), 'fix': fix.format(**values),
                'retry': retry.format(**values), 'reference': REFERENCE + '#' + self.code,
                'test_mode': True, 'execution_authorized': False}
        if 'cause' in values:
            body['cause'] = values['cause']
        return body


class Parser(argparse.ArgumentParser):
    """Argument mistakes become the same plain refusal as every other one."""

    def error(self, message):
        raise Refusal('AAP_ARGUMENTS', detail=message[:1].upper() + message[1:300])


def _home(value):
    if value:
        return Path(value).expanduser().absolute()
    return Path(os.environ.get('COVENANT_HOME') or Path.home() / '.covenant').expanduser().absolute() / 'test-mode'


def _private(path, limit, home):
    """Bytes of one owner-only regular file, read without following links."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        raise Refusal('AAP_TEST_FOLDER', home=home, reason=path.name + ' is missing or is a link') from None
    try:
        info = os.fstat(fd)
        if not (stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_mode & 0o077 == 0
                and info.st_size <= limit):
            raise Refusal('AAP_TEST_FOLDER', home=home, reason=path.name + ' is not a private file of a usable size')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(limit + 1)
    finally:
        os.close(fd)
    if len(raw) > limit:
        raise Refusal('AAP_TEST_FOLDER', home=home, reason=path.name + ' is too large')
    return raw


def _json(path, limit, home):
    from covenant_agent.codec import loads
    try:
        value = loads(_private(path, limit, home))
    except ValueError:
        raise Refusal('AAP_TEST_FOLDER', home=home, reason=path.name + ' is not readable') from None
    if type(value) is not dict:
        raise Refusal('AAP_TEST_FOLDER', home=home, reason=path.name + ' is not readable')
    return value


def check_terms(what, price, days):
    """Refuse unusable terms before any folder, key or record is created."""
    if not (type(what) is str and 1 <= len(what) <= MAX_TEXT and what.strip()
            and all(32 <= ord(c) <= 126 for c in what)):
        raise Refusal('AAP_TEXT')
    if type(price) is not int or not 1 <= price <= TEST_BALANCE:
        raise Refusal('AAP_PRICE')
    if type(days) is not int or not 1 <= days <= MAX_DAYS:
        raise Refusal('AAP_DAYS')


class Workspace:
    """The test folder: four test keys, one local test payment record and the deals.

    It is the owner-private folder covenant_agent.demo_setup creates, so the
    same signing hosts an agent connects to run every step. One aap command
    at a time holds its lock; every record is written atomically.
    """

    def __init__(self, home, *, create=False):
        self.home = Path(home)
        self._lock = None
        if not os.path.lexists(self.home):
            if not create:
                raise Refusal('AAP_NO_DEALS', home=self.home)
            self._create()
        info = os.lstat(self.home)
        if not (stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and info.st_mode & 0o077 == 0):
            raise Refusal('AAP_TEST_FOLDER', home=self.home, reason='it must be a folder only you can read, not a link')
        manifest = _json(self.home / 'manifest.json', 65536, self.home)
        hosts = manifest.get('hosts')
        if not (manifest.get('format') == 'covenant-reference-demo/0.1' and manifest.get('synthetic_only') is True
                and manifest.get('profile') == 'covenant-bilateral/0.2' and type(hosts) is dict
                and set(hosts) == set(ROLES) and all(type(hosts[role]) is dict and type(hosts[role].get('identity')) is str
                                                     and _HEX64.fullmatch(hosts[role]['identity']) for role in ROLES)):
            raise Refusal('AAP_TEST_FOLDER', home=self.home, reason='it is not an aap test folder')
        self.ids = {role: hosts[role]['identity'] for role in ROLES}
        self.deals = self.home / 'deals'

    def _create(self):
        from covenant_agent.demo_setup import create
        from covenant_agent.errors import NativeError
        try:
            self.home.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            create(self.home, balance=TEST_BALANCE)
        except (NativeError, OSError) as exc:
            if getattr(exc, 'code', None) != 'DEMO_DIRECTORY_EXISTS':
                raise Refusal('AAP_TEST_FOLDER', home=self.home,
                              reason='it could not be created (' + getattr(exc, 'code', 'OS_ERROR') + ')') from None

    def __enter__(self):
        from covenant_language.safe_io import lock_file
        if not os.path.lexists(self.deals):
            os.mkdir(self.deals, 0o700)
        info = os.lstat(self.deals)
        if not (stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and info.st_mode & 0o077 == 0):
            raise Refusal('AAP_TEST_FOLDER', home=self.home, reason='its deals folder must be private, not a link')
        fd = os.open(self.home / '.aap.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            lock_file(fd, timeout=LOCK_SECONDS)
        except TimeoutError:
            os.close(fd)
            raise Refusal('AAP_FOLDER_BUSY', home=self.home) from None
        self._lock = fd
        return self

    def __exit__(self, *_):
        if self._lock is not None:
            os.close(self._lock)
            self._lock = None

    def host(self, role):
        """The signing host for one role, from its private test configuration."""
        from covenant_agent.codec import key_from_seed, public_key
        from covenant_agent.mcp import Host
        config = _json(self.home / (role + '.json'), 65536, self.home)
        database = config.get('settlement_db')
        try:
            same = type(database) is str and os.path.samefile(database, self.home / 'reference.sqlite')
            identity = public_key(key_from_seed(config.get('seed')))
        except (OSError, ValueError, TypeError):
            same, identity = False, None
        if not (same and config.get('sandbox') is True and identity == self.ids[role]
                and config.get('work_order_profile') == 'covenant-bilateral/0.2'):
            raise Refusal('AAP_TEST_FOLDER', home=self.home, reason=role + '.json does not match this test folder')
        return Host(config)

    def step(self, verb, deal, role, tool, arguments):
        """One call on one signing host; a refusal comes back in plain words."""
        from covenant_agent.errors import NativeError
        host = self.host(role)
        try:
            return host.call(tool, arguments)
        except (OSError, sqlite3.Error) as exc:
            raise Refusal('AAP_STEP_REFUSED', verb=verb, reason='the local test payment record could not be used',
                          fix='Wait a moment, then run the same command again.', retry='yes',
                          cause=type(exc).__name__) from None
        except (NativeError, ValueError, TypeError, KeyError) as exc:
            cause = getattr(exc, 'code', None) or 'REFUSED'
            reason, fix, retry = STEP_REASONS.get(cause, (
                'the signing host returned ' + cause,
                'Run aap show ' + (deal or '') + ' to see where the deal stands. ' + REFERENCE + ' explains each code.',
                'no'))
            raise Refusal('AAP_STEP_REFUSED', verb=verb, reason=reason, fix=fix, retry=retry, cause=cause) from None

    def identifiers(self):
        found = []
        with os.scandir(self.deals) as entries:
            for entry in entries:
                if entry.name.endswith('.json') and _HEX64.fullmatch(entry.name[:-5]):
                    found.append(entry.name[:-5])
                    if len(found) > MAX_DEALS:
                        raise Refusal('AAP_TEST_FOLDER', home=self.home, reason='it holds too many deals')
        return found

    def find(self, prefix):
        wanted = prefix.strip().lower() if type(prefix) is str else ''
        if not _PREFIX.fullmatch(wanted):
            raise Refusal('AAP_DEAL_UNKNOWN', deal=str(prefix)[:64])
        matches = [ident for ident in self.identifiers() if ident.startswith(wanted)]
        if not matches:
            raise Refusal('AAP_DEAL_UNKNOWN', deal=wanted)
        if len(matches) > 1:
            raise Refusal('AAP_DEAL_AMBIGUOUS', deal=wanted)
        return self.load(matches[0])

    def load(self, ident):
        from covenant_agent.bilateral_v2 import identifier
        record = _json(self.deals / (ident + '.json'), MAX_RECORD, self.home)
        try:
            ok = (set(record) == {'format', 'n', 'envelope'} and record['format'] == DEAL_FORMAT
                  and type(record['n']) is int and identifier(record['envelope']) == ident)
        except (KeyError, TypeError, ValueError):
            ok = False
        if not ok:
            raise Refusal('AAP_DEAL_UNREADABLE', deal=ident[:8])
        return record

    def save(self, record):
        from covenant_agent.bilateral_v2 import identifier
        from covenant_language.safe_io import atomic_write
        raw = (json.dumps(record, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode('ascii')
        atomic_write(self.deals / (identifier(record['envelope']) + '.json'), raw, mode=0o600, follow_symlinks=False)

    def work(self, ident):
        path = self.deals / (ident + '.work')
        return _private(path, MAX_WORK, self.home) if os.path.lexists(path) else None

    def propose(self, what, price, days):
        check_terms(what, price, days)
        made = self.step('propose', None, 'buyer', 'covenant_make', {
            'document': what, 'counterparty': self.ids['seller'], 'resolver': self.ids['resolver'],
            'appeal_resolver': self.ids['appeal'], 'quantity': price, 'pay_to': 'seller',
            'deadline': int(time.time()) + days * DAY})
        numbers = [self.load(ident)['n'] for ident in self.identifiers()]
        record = {'format': DEAL_FORMAT, 'n': max(numbers, default=0) + 1, 'envelope': made['envelope']}
        self.save(record)
        return record

    def accept(self, record):
        short, stage = _short(record), _stage(record)
        if stage == 'PROPOSED':
            accepted = self.step('accept', short, 'seller', 'covenant_accept', {'envelope': record['envelope']})
            record = {**record, 'envelope': accepted['envelope']}
            self.save(record)
            return record, False
        if stage in ('BOUND', 'DELIVERED', 'SETTLED'):
            return record, True
        raise Refusal('AAP_DEAL_STEP', deal=short, stage=STAGES[stage][0], verb='accepted')

    def settle(self, record, work=None):
        from covenant_language.safe_io import atomic_write
        short, stage = _short(record), _stage(record)
        ident = _ident(record)
        if stage == 'PROPOSED':
            raise Refusal('AAP_DEAL_STEP', deal=short, stage='proposed and not yet accepted', verb='settled')
        if stage not in ('BOUND', 'DELIVERED', 'SETTLED'):
            raise Refusal('AAP_DEAL_STEP', deal=short, stage=STAGES[stage][0], verb='settled')
        replayed = stage == 'SETTLED'
        deliveries = record['envelope'].get('deliveries') or []
        if work is not None and deliveries and hashlib.sha256(work).hexdigest() != deliveries[0]['content_hash']:
            raise Refusal('AAP_WORK_CHANGED', deal=short)
        if stage == 'BOUND':
            kept = self.work(ident)
            if kept is not None and work is not None and kept != work:
                raise Refusal('AAP_WORK_CHANGED', deal=short)
            content = kept if kept is not None else work if work is not None else (
                b'SYNTHETIC TEST DELIVERY for deal ' + short.encode('ascii') + b'.\n')
            if kept is None:
                atomic_write(self.deals / (ident + '.work'), content, mode=0o600, exclusive=True)
            delivered = self.step('settle', short, 'seller', 'covenant_deliver', {
                'envelope': record['envelope'], 'content_base64': base64.b64encode(content).decode('ascii')})
            record = {**record, 'envelope': delivered['envelope']}
            self.save(record)
            stage = 'DELIVERED'
        if stage == 'DELIVERED':
            settled = self.step('settle', short, 'buyer', 'covenant_settle', {'envelope': record['envelope']})
            record = {**record, 'envelope': settled['envelope']}
            self.save(record)
        return record, replayed

    def check(self, record):
        """Check offline: both signatures, the proof against the kept work, and the test payment record."""
        verdict = self.step('check', _short(record), 'seller', 'covenant_verify', {'envelope': record['envelope']})
        deliveries = record['envelope'].get('deliveries') or []
        kept = self.work(_ident(record)) if deliveries else None
        proof = None
        if deliveries:
            proof = {'sha256': deliveries[0]['content_hash'],
                     'matches_kept_work': None if kept is None else hashlib.sha256(kept).hexdigest() == deliveries[0]['content_hash']}
        return {'ok': verdict['ok'] is True, 'stage': verdict['verdict'], 'paid_observed': verdict['funds_observed'] is True,
                'proof': proof}


def _ident(record):
    from covenant_agent.bilateral_v2 import identifier
    return identifier(record['envelope'])


def _short(record):
    return _ident(record)[:8]


def _stage(record):
    from covenant_agent.bilateral_v2 import verify
    return verify(record['envelope'])['verdict']


def _when(seconds):
    return datetime.fromtimestamp(seconds, timezone.utc).strftime('%Y-%m-%d %H:%M UTC')


def _say(lines):
    sys.stdout.write('\n'.join(lines).rstrip('\n') + '\n')
    return 0


def _emit(args, value, lines):
    if getattr(args, 'json', False):
        sys.stdout.write(json.dumps(value, sort_keys=True, ensure_ascii=True) + '\n')
        return 0
    return _say(lines)


def banner():
    """What aap alone prints: the model, the three steps and aap demo."""
    return ['aap · Agentic Agreements Protocol', '', MODEL, '',
            'Three steps, the same everywhere:',
            *('  %d. %-8s %s' % (number, name, say) for number, (name, say) in enumerate(STEPS, 1)), '',
            'See a whole deal in seconds:  aap demo',
            'Then make your own:           ' + EXAMPLE, '',
            'Test mode is on: synthetic units, test keys, nothing real. aap help shows the seven jobs.']


def usage():
    """aap --help: every golden-path command, the jobs and the earlier commands."""
    lines = ['usage: aap [COMMAND] [ARGUMENTS]', '', MODEL, '']
    lines += ['  %-9s %s' % row for row in COMMANDS]
    lines += ['', 'Seven jobs: ' + '; '.join(title.lower() for _, title, _ in JOBS) + '.',
              'aap help JOB shows one job. aap help commands lists the earlier commands, which run',
              'unchanged as aap NAME (for example aap chain, aap agent or aap covenant explain).', '',
              LABEL + ' Real value needs your own keys and payment provider.']
    return lines


def help_lines(topic=None):
    """aap help, aap help JOB and aap help commands."""
    if topic is None:
        lines = ['Seven jobs. aap help JOB shows how to do one: in this terminal, or as an agent tool.', '']
        lines += ['%d. %-19s %s' % (number, title, ', '.join(verb[0] for verb in verbs))
                  for number, (_, title, verbs) in enumerate(JOBS, 1)]
        return lines + ['', 'aap help commands lists every command, including the earlier covenant ones.']
    if topic == 'commands':
        lines = ['The golden path and its companions:']
        lines += ['  %-9s %s' % row for row in COMMANDS]
        lines += ['', 'Earlier commands, unchanged. Run aap NAME, or aap with the earlier name:']
        lines += ['  %-19s %-36s %s' % (short or '', earlier, purpose) for short, earlier, _, purpose in EARLIER]
        return lines
    found = job(topic)
    if found is None:
        raise Refusal('AAP_HELP_TOPIC', topic=topic[:40])
    number, (_, title, verbs) = found
    lines = ['%d. %s' % (number, title), '']
    for verb, say, command, tools in verbs:
        lines.append('%-8s %s' % (verb, say))
        if command:
            lines.append('%-8s Terminal: %s' % ('', command))
        lines.append('%-8s Agents:   %s' % ('', tools.replace(' | ', ', ')))
    return lines + ['', 'Agents reach every tool through covenant_explain and covenant_call.']


def _options(sub, *, live=True):
    sub.add_argument('--home', help='Test folder (default $COVENANT_HOME/test-mode).')
    sub.add_argument('--json', action='store_true', help='Print one JSON object instead of plain text.')
    if live:
        sub.add_argument('--live', action='store_true', help='Real value. Refused: it needs your own setup.')


def _propose_arguments(sub):
    sub.add_argument('what', help='What the seller will deliver: 1 to 400 plain ASCII characters.')
    sub.add_argument('--price', type=int, default=50, help='Whole test units the buyer pays (default 50).')
    sub.add_argument('--days', type=int, default=7, help='Days the seller has to deliver (default 7).')
    _options(sub)


def _accept_arguments(sub):
    sub.add_argument('deal', help='The deal ID aap propose printed; 4 or more characters are enough.')
    _options(sub)


def _settle_arguments(sub):
    sub.add_argument('deal', help='The deal ID; 4 or more characters are enough.')
    work = sub.add_mutually_exclusive_group()
    work.add_argument('--work', help='The delivered work as text. Default: a synthetic test delivery.')
    work.add_argument('--file', help='Deliver the exact bytes of this file instead.')
    _options(sub)


def _show_arguments(sub):
    sub.add_argument('deal', nargs='?', help='A deal ID; without one, list every test deal.')
    _options(sub, live=False)


def _demo_arguments(sub):
    sub.add_argument('--json', action='store_true', help='Print one JSON object instead of plain text.')


def _help_arguments(sub):
    sub.add_argument('topic', nargs='?', help='A job number, job, verb, or commands.')


# One table builds every subcommand: name -> (description, arguments).
SUBCOMMANDS = {
    'propose': ('Offer exact terms and sign them, in test mode.', _propose_arguments),
    'accept': ('The seller signs the same terms; the price is held.', _accept_arguments),
    'settle': ('The seller delivers with proof, then the buyer releases payment.', _settle_arguments),
    'demo': ('Propose, accept and settle one synthetic deal in a fresh test folder that is deleted afterwards.',
             _demo_arguments),
    'show': ('List your test deals, or show one and check it offline.', _show_arguments),
    'setup': ('Make the test keys (once) and print the test hosts an agent connects to.',
              lambda sub: _options(sub, live=False)),
    'help': ('The seven jobs, one job, or every command.', _help_arguments),
    'adapter': ('AAP Connect: build, check and publish an adapter. Runs covenant_chain.connect_cli when this build '
                'includes it.', lambda sub: sub.add_argument('arguments', nargs=argparse.REMAINDER,
                                                             help='Everything after adapter, passed on unchanged.')),
}


def _parser():
    parser = Parser(prog='aap', add_help=False)
    commands = parser.add_subparsers(dest='command', parser_class=Parser)
    for name, say in COMMANDS:
        description, arguments = SUBCOMMANDS[name]
        arguments(commands.add_parser(name, help=say, description=description))
    return parser


def _live(args):
    if getattr(args, 'live', False):
        raise Refusal('AAP_LIVE')


def _next(stage, short):
    command = STAGES[stage][2]
    return command.format(deal=short) if command else None


def _run_propose(args):
    _live(args)
    check_terms(args.what, args.price, args.days)
    with Workspace(_home(args.home), create=True) as space:
        record = space.propose(args.what, args.price, args.days)
    short, terms = _short(record), record['envelope']['terms']
    return _emit(args, {'test_mode': True, 'command': 'propose', 'deal': _ident(record), 'stage': 'PROPOSED',
                        'price': terms['quantity'], 'deadline': terms['deadline'], 'next': 'aap accept ' + short,
                        'execution_authorized': False}, [
        LABEL, '',
        'Proposed deal %s: the test buyer (you) pays %d test units to the test seller for "%s".'
        % (short, terms['quantity'], args.what),
        'You signed the exact terms. The seller has until %s to deliver.' % _when(terms['deadline']), '',
        'Next: aap accept %s    the seller signs the same terms' % short])


def _run_accept(args):
    _live(args)
    with Workspace(_home(args.home)) as space:
        record, replayed = space.accept(space.find(args.deal))
    short, price = _short(record), record['envelope']['terms']['quantity']
    first = ('Deal %s was already accepted. Nothing changed.' % short if replayed else
             'Accepted deal %s. Both sides signed the same terms; %d test units are held until it settles.' % (short, price))
    stage = _stage(record)
    return _emit(args, {'test_mode': True, 'command': 'accept', 'deal': _ident(record), 'stage': stage,
                        'replayed': replayed, 'next': _next(stage, short), 'execution_authorized': False}, [
        LABEL, '', first, '',
        'Next: aap settle %s    the seller delivers with proof, then you release payment' % short
        if stage in ('BOUND', 'DELIVERED') else 'Next: aap show %s' % short])


def _work(args):
    if args.work is not None:
        raw = args.work.encode('utf-8')
    elif args.file is not None:
        try:
            with open(args.file, 'rb') as stream:
                raw = stream.read(MAX_WORK + 1)
        except OSError:
            raise Refusal('AAP_WORK_FILE', file=args.file[:200]) from None
    else:
        return None
    if not 1 <= len(raw) <= MAX_WORK:
        raise Refusal('AAP_WORK')
    return raw


def _run_settle(args):
    _live(args)
    work = _work(args)
    with Workspace(_home(args.home)) as space:
        record, replayed = space.settle(space.find(args.deal), work)
        checked = space.check(record)
    short, terms = _short(record), record['envelope']['terms']
    proof = checked['proof'] or {}
    lines = [LABEL, '', ('Deal %s was already settled. Nothing changed.' % short if replayed else 'Settled deal %s.' % short),
             '  Delivered  The seller signed proof of the exact work: sha256 %s' % proof.get('sha256', '')[:16] + '...',
             '  Paid       %d test units went from the test buyer to the test seller.' % terms['quantity'],
             '  Checked    %s' % _checked(checked), '',
             'Done. Keep the record: aap show %s --json' % short]
    return _emit(args, {'test_mode': True, 'command': 'settle', 'deal': _ident(record), 'stage': checked['stage'],
                        'replayed': replayed, 'check': checked, 'next': None, 'execution_authorized': False}, lines)


def _checked(checked):
    if not checked['ok']:
        return 'The saved deal does not check out.'
    parts = ['Both signatures']
    if checked['proof'] is not None:
        parts.append('the proof' + ('' if checked['proof']['matches_kept_work'] is not False else ' (but not the kept work)'))
    if checked['paid_observed']:
        parts.append('the test payment record')
    return (', '.join(parts[:-1]) + ' and ' + parts[-1] if len(parts) > 1 else parts[0]) + ' check out offline.'


def _run_show(args):
    home = _home(args.home)
    if args.deal is None and not os.path.lexists(home):
        return _emit(args, {'test_mode': True, 'command': 'show', 'home': str(home), 'deals': [],
                            'execution_authorized': False},
                     [LABEL, '', 'No test deals yet. Start with ' + EXAMPLE + ' or watch aap demo.'])
    with Workspace(home) as space:
        if args.deal is None:
            rows = sorted((space.load(ident) for ident in space.identifiers()), key=lambda row: row['n'])
            listed = [{'deal': _ident(row), 'stage': _stage(row), 'price': row['envelope']['terms']['quantity'],
                       'what': row['envelope']['document']['text'] if type(row['envelope'].get('document')) is dict else None}
                      for row in rows]
            lines = [LABEL, '']
            if not listed:
                lines.append('No test deals yet. Start with ' + EXAMPLE + '.')
            else:
                lines.append('Your test deals in %s:' % home)
                lines += ['  %s  %-12s %8d test units  %s' % (row['deal'][:8], STAGES[row['stage']][0], row['price'],
                                                              (row['what'] or '')[:60]) for row in listed]
                lines += ['', 'aap show DEAL shows one deal and checks it.']
            return _emit(args, {'test_mode': True, 'command': 'show', 'home': str(home), 'deals': listed,
                                'execution_authorized': False}, lines)
        record = space.find(args.deal)
        checked = space.check(record)
    short, envelope = _short(record), record['envelope']
    stage = checked['stage'] if checked['stage'] in STAGES else 'INVALID'
    name, meaning, _ = STAGES[stage]
    text = envelope['document']['text'] if type(envelope.get('document')) is dict else ''
    lines = [LABEL, '', 'Deal %s: %s. %s' % (short, name, meaning),
             '  What      %s' % text,
             '  Price     %d test units, from the test buyer to the test seller' % envelope['terms']['quantity'],
             '  Deadline  %s' % _when(envelope['terms']['deadline'])]
    if checked['proof'] is not None:
        matches = checked['proof']['matches_kept_work']
        lines.append('  Proof     sha256 %s...%s' % (checked['proof']['sha256'][:16], '' if matches is None else
                                                    ' matches the delivered work.' if matches else ' does NOT match the kept work.'))
    lines.append('  Check     ' + _checked(checked))
    following = _next(stage, short)
    lines += ['', 'Next: ' + following if following else 'Keep the record: aap show %s --json' % short]
    return _emit(args, {'test_mode': True, 'command': 'show', 'deal': _ident(record), 'stage': stage,
                        'check': checked, 'next': following, 'record': record, 'execution_authorized': False}, lines)


def filled_path(ids):
    """The golden path with this test folder's IDs in place of the placeholders."""
    path = golden_path()
    names = {'<seller ID>': ids['seller'], '<referee ID>': ids['resolver'], '<appeal referee ID>': ids['appeal']}
    for step in path['steps']:
        for call in step['calls']:
            call['arguments'] = {key: names.get(value, value) if type(value) is str else value
                                 for key, value in call['arguments'].items()}
    return path


def hosts(home):
    """The two test hosts an agent connects to: one MCP server per side."""
    return {role: {'command': sys.executable,
                   'args': ['-P', '-m', 'covenant_agent.server', '--config', str(Path(home) / (role + '.json'))]}
            for role in ('buyer', 'seller')}


def _run_setup(args):
    home = _home(args.home)
    with Workspace(home, create=True) as space:
        ids = dict(space.ids)
    served = hosts(home)
    lines = [LABEL, '', 'Test folder: %s (only you can read it)' % home]
    lines += ['  %-15s %s' % (NAMES[role], ids[role]) for role in ROLES]
    lines += ['', 'For an agent, connect two test hosts (MCP servers), one for each side:']
    lines += ['  %-7s %s' % (role + ':', ' '.join([served[role]['command'], *served[role]['args']])) for role in served]
    lines += ['Then: covenant_make on the buyer host, covenant_accept and covenant_deliver on the seller host,',
              'covenant_settle on the buyer host. aap setup --json prints those calls with these IDs filled in.',
              'Or stay in this terminal: ' + EXAMPLE]
    return _emit(args, {'test_mode': True, 'command': 'setup', 'home': str(home), 'ids': ids, 'hosts': served,
                        'golden_path': filled_path(ids), 'execution_authorized': False}, lines)


def demo():
    """One complete synthetic deal in a fresh test folder, deleted afterwards. Returns the timings."""
    started = time.monotonic()
    timings = {}
    with tempfile.TemporaryDirectory(prefix='aap-demo-') as temporary:
        with Workspace(Path(temporary) / 'test-mode', create=True) as space:
            timings['ready'] = time.monotonic() - started
            record = space.propose(DEMO['what'], DEMO['price'], DEMO['days'])
            timings['propose'] = time.monotonic() - started
            record, _ = space.accept(record)
            timings['accept'] = time.monotonic() - started
            record, _ = space.settle(record, DEMO['work'])
            timings['settle'] = time.monotonic() - started
            checked = space.check(record)
    timings['done'] = time.monotonic() - started
    return {'format': DEMO_FORMAT, 'test_mode': True, 'model': MODEL, 'deal': _ident(record),
            'what': DEMO['what'], 'price': DEMO['price'], 'proof_sha256': checked['proof']['sha256'],
            'check': checked, 'seconds': {key: round(value, 3) for key, value in timings.items()},
            'first_signed_deal_seconds': round(timings['accept'], 3), 'settled_seconds': round(timings['settle'], 3),
            'kept': False, 'execution_authorized': False}


def _run_demo(args):
    result = demo()
    seconds = result['seconds']
    return _emit(args, result, [
        'aap demo · ' + LABEL, '', MODEL, '',
        '1. Propose  The test buyer offers %d test units for "%s" and signs.' % (result['price'], result['what']),
        '2. Accept   The test seller signs the same terms. %d test units are held.' % result['price'],
        '3. Settle   The seller delivers the report with proof (sha256 %s...). The buyer releases payment.'
        % result['proof_sha256'][:12],
        '   Check    ' + _checked(result['check']), '',
        'First signed deal after %.1f s; settled after %.1f s. The test folder is gone; nothing real moved.'
        % (seconds['accept'], seconds['settle']),
        'Make your own: ' + EXAMPLE])


def _run_help(args):
    return _say(help_lines(args.topic))


def adapter(args):
    """aap adapter ...: AAP Connect, imported only when this build includes it.

    Everything from adapter onwards goes to covenant_chain.connect_cli.main
    unchanged, so its output and exit status are AAP Connect's own.
    """
    if find_spec('covenant_chain.connect_cli') is None:
        raise Refusal('AAP_CONNECT_MISSING')
    return import_module('covenant_chain.connect_cli').main(list(args))


HANDLERS = {'propose': _run_propose, 'accept': _run_accept, 'settle': _run_settle, 'show': _run_show,
            'setup': _run_setup, 'demo': _run_demo, 'help': _run_help,
            'adapter': lambda parsed: adapter(['adapter', *parsed.arguments])}


def _earlier(name, rest):
    """Run an earlier command exactly as its console script does."""
    earlier, load = ALIASES[name]
    function = load()
    saved = sys.argv
    sys.argv = [earlier, *rest]
    try:
        return function()
    finally:
        sys.argv = saved


def _refuse(refusal, as_json=False):
    """Write one refusal to standard error: JSON, or four plain lines."""
    body = refusal.body()
    if as_json:
        sys.stderr.write(json.dumps(body, sort_keys=True, ensure_ascii=True) + '\n')
    else:
        sys.stderr.write('%s: %s\nFix: %s\nRetry: %s.\nReference: %s\n' % (
            body['code'], body['what'], body['fix'], body['retry'], body['reference']))


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        return _say(banner())
    if args[0] in ('-h', '--help'):
        return _say(usage())
    if args[0] in ALIASES:
        return _earlier(args[0], args[1:])
    try:
        if args[0] == 'adapter':
            return adapter(args)
        if not args[0].startswith('-') and args[0] not in HANDLERS:
            raise Refusal('AAP_UNKNOWN_COMMAND', name=args[0][:40])
        parsed = _parser().parse_args(args)
        if parsed.command is None:
            raise Refusal('AAP_ARGUMENTS', detail='Name a command first, for example aap demo')
        return HANDLERS[parsed.command](parsed)
    except Refusal as refusal:
        _refuse(refusal, '--json' in args)
        return 2 if refusal.code in ('AAP_ARGUMENTS', 'AAP_UNKNOWN_COMMAND') else 1


if __name__ == '__main__':
    raise SystemExit(main())
