"""Map an LCP ``disputeResolution.method`` onto an owner-chosen forum.

Maturity: experimental. Off unless the registry is built with ``enabled=True``
(host flag ``forum_arbiter``). The owner installs each method: either a
private-agreement procedure (covenant_chain.private_covenant) or a native panel
clause (covenant_chain.arbitration_clause.clause_for). A known method is BOUND
and runs that procedure; an unknown method is UNKNOWN and asks a human to name an
arbiter. Method names are counterparty data: they never install a forum.

``MockAaaAdapter`` is a mock. It records a local case id and builds the same
unsigned private-agreement proposal any configured forum would. It opens no
socket, files nothing with any institution and implies no partnership.

``host_forum`` and ``forum_resolvers`` live here rather than in the frozen
review.py and in private_covenant.py, where Cursor PR 80 (refs/pull/80/head,
575be847) had put them.
"""
from __future__ import annotations

import json
from copy import deepcopy

from .crypto import canonical, digest, key, need

AAA_FORUM = 'AAA-ICDR'
METHOD_LABEL = 'COVENANT-FORUM-MAPPING-0.1'
CASE_LABEL = 'COVENANT-AAA-CASE-0.1'
MAX_METHODS = 64
PROMPT = 'Name an arbiter for this forum before the agreement proceeds.'


def _method(value):
    need(type(value) is str and 0 < len(value) <= 256 and all(32 <= ord(c) <= 126 for c in value), 'FORUM_METHOD')


def _unknown(method):
    return {'status': 'UNKNOWN', 'method': method, 'kind': None, 'procedure': None, 'panel': None,
            'human_prompt': True, 'prompt': PROMPT, 'runs_procedure': False, 'execution_authorized': False}


class ArbiterRegistry:
    """Owner-filled method table. Nothing is installed from a tool argument."""

    def __init__(self, *, enabled=False):
        self.enabled = enabled is True
        self.methods = {}

    def _open(self, method):
        need(self.enabled, 'PLUGIN_DISABLED')
        _method(method)
        need(method not in self.methods and len(self.methods) < MAX_METHODS, 'FORUM_METHOD_INSTALLED')

    def install(self, method, resolvers, *, mode='JUDGMENT', threshold=1, appeal=''):
        """Map a method to a private-agreement procedure with these resolvers."""
        from .private_covenant import MODES, _procedure
        self._open(method)
        need(mode in MODES, 'FORUM_MODE')
        procedure = {'mode': mode, 'method': method, 'resolvers': deepcopy(resolvers), 'threshold': threshold,
                     'question': 'forum:' + method, 'appeal': appeal}
        _procedure(procedure)
        self.methods[method] = ('PRIVATE_PROCEDURE', procedure)
        return digest(METHOD_LABEL, {'method': method, 'kind': 'PRIVATE_PROCEDURE', 'procedure': procedure})

    def install_panel(self, method, panel):
        """Map a method to a native arbitration panel clause (arbitration_clause.clause_for)."""
        from .arbitration import validate_panel
        self._open(method)
        checked = validate_panel(deepcopy(panel))
        self.methods[method] = ('NATIVE_PANEL', checked)
        return digest(METHOD_LABEL, {'method': method, 'kind': 'NATIVE_PANEL', 'panel': checked})

    def resolve(self, dispute):
        """BOUND with the installed forum, or UNKNOWN with a human prompt."""
        need(self.enabled, 'PLUGIN_DISABLED')
        method = dispute.get('method') if type(dispute) is dict else None
        try:
            _method(method)
        except ValueError:
            return _unknown(None)
        found = self.methods.get(method)
        if found is None:
            return _unknown(method)
        kind, value = found
        return {'status': 'BOUND', 'method': method, 'kind': kind,
                'procedure': deepcopy(value) if kind == 'PRIVATE_PROCEDURE' else None,
                'panel': deepcopy(value) if kind == 'NATIVE_PANEL' else None,
                'human_prompt': False, 'runs_procedure': True, 'execution_authorized': False}

    def describe(self):
        return {'enabled': self.enabled, 'methods': {name: kind for name, (kind, _value) in sorted(self.methods.items())},
                'execution_authorized': False}


def host_forum(registry, dispute):
    """Map a forum choice for a host. Not called by apply()."""
    need(isinstance(registry, ArbiterRegistry) and registry.enabled, 'PLUGIN_DISABLED')
    return registry.resolve(dispute)


def forum_resolvers(registry, method):
    """Resolvers of an installed private-procedure method, or the UNKNOWN record."""
    found = host_forum(registry, {'method': method})
    if found['status'] != 'BOUND' or found['kind'] != 'PRIVATE_PROCEDURE':
        return found
    return deepcopy(found['procedure']['resolvers'])


class MockAaaAdapter:
    """Mock AAA-ICDR forum. ``open_case`` records a local id; it never dials out or files a case."""

    def __init__(self, registry, resolvers):
        need(isinstance(registry, ArbiterRegistry) and registry.enabled, 'PLUGIN_DISABLED')
        self.registry = registry
        self.method = AAA_FORUM
        registry.install(self.method, resolvers)
        self.cases = {}

    def open_case(self, clause_id, question):
        key(clause_id)
        need(type(question) is str and 0 < len(question) <= 4096, 'FORUM_QUESTION')
        canonical(question)
        case = digest(CASE_LABEL, {'clause': clause_id, 'question': question, 'mock': True})
        self.cases[case] = {'forum': self.method, 'clause': clause_id, 'mock': True, 'network': False}
        mapped = self.registry.resolve({'method': self.method})
        return {**mapped, 'case': case, 'mock': True, 'partnership': False, 'network': False}

    def run(self, clause_id, question, *, context, parties, terms):
        """Open the mock case and build the unsigned private-agreement proposal with the mapped procedure."""
        from .private_covenant import create_agreement
        opened = self.open_case(clause_id, question)
        agreement = create_agreement(context=context, parties=parties, terms=terms, procedure=opened['procedure'])
        return {'case': opened['case'], 'agreement': agreement, 'mock': True, 'network': False,
                'runs_procedure': True, 'assented': False, 'execution_authorized': False}


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Forum mapping. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    args = parser.parse_args(argv)
    print(json.dumps({'plugin': 'forum_arbiter', 'enabled': bool(args.enabled), 'mock': AAA_FORUM,
                      'network': False, 'maturity': 'experimental', 'execution_authorized': False}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
