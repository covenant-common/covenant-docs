"""Hash-locked conditional escrow released only by a verified AAP delivery receipt. Maturity: experimental.

A PEER mode beside the hosted reference ledger (settlement_ledger_v2) and the
native service jobs: the buyer's payment waits in a hash-time-locked contract
(HTLC) on a payment network the parties chose, and only the preimage releases
it to the seller. The buyer's AAP host, the holder, derives a fresh preimage
for each condition and reveals it only when the buyer-signed delivery receipt
verifies against the agreement's typed acceptance criteria
(covenant_agent.commerce.verify_receipt: verdict MEETS and exact assent
verified). Otherwise nothing is revealed and the payment returns to the buyer
after the timeout. Two legs, each bound to one condition both parties sign:

* Lightning hold invoice (BOLT #11): payment_hash is the condition's hash and
  the h field commits to the condition URN. The seller's node creates it with
  LND invoicesrpc.AddHoldInvoice (lnd v0.21.5-beta invoices.proto: hash,
  value_msat, description_hash, expiry, cltv_expiry; REST POST /v2/invoices/hodl)
  and settles with SettleInvoice(preimage). The hold must fit in half of the
  invoice's expected CLTV time, so long deliveries use another leg.
* EVM hash-time-locked contract: the HashedTimelock and HashedTimelockERC20
  interface of chatch/hashed-timelock-contract-ethereum (611f2d3):
  newContract, withdraw(contractId, preimage), refund(contractId), with
  contractId = sha256(abi.encodePacked(sender, receiver[, token], amount,
  hashlock, timelock)) and a SHA-256 hashlock, the same hash as Lightning.

Replay safety: the holder keeps one condition per agreement; a fresh nonce makes
each preimage and payment hash unique, so one reveal never unlocks another
invoice or contract; a reveal binds once to the exact receipt id and replays only
for that receipt. Invoices, contract calls and settlement proofs are evidence or
a payment leg, never authority beyond the signed condition. Nothing here pays,
signs a payment or contacts a node or chain.
"""
from copy import deepcopy
import base64
import hashlib
import hmac
import json
import re
import secrets

from covenant_language import agreement_application as application_profile

from . import evm_codec as evm
from .crypto import integer, need

CONDITION = 'urn:aap:hashlock-escrow:0.1'
CONDITION_LABEL = 'AAP-HASHLOCK-ESCROW-0.1'
REVEAL = 'urn:aap:hashlock-reveal:0.1'
REVEAL_LABEL = 'AAP-HASHLOCK-REVEAL-0.1'
STORE = 'urn:aap:hashlock-holder:0.1'
PREIMAGE_DOMAIN = b'AAP-HASHLOCK-PREIMAGE-0.1\x00'
SEED_DOMAIN = b'AAP-HASHLOCK-SEED-ID-0.1'
LIGHTNING, EVM_HTLC = 'LIGHTNING_HOLD_INVOICE', 'EVM_HTLC'
REQUIRES = 'VERIFIED_AAP_DELIVERY_RECEIPT_MEETS_CRITERIA'
MIN_CLAIM_MARGIN = 3600
BLOCK_SECONDS = 600
MIN_CLTV, MAX_CLTV = 18, 2016
MAX_CONDITIONS = 100000
MAX_TIME = 2 ** 53 - 1
HTLC = {'NATIVE': ('newContract(address,bytes32,uint256)', 'LogHTLCWithdraw(bytes32)', 'LogHTLCRefund(bytes32)'),
        'ERC20': ('newContract(address,bytes32,uint256,address,uint256)', 'HTLCERC20Withdraw(bytes32)', 'HTLCERC20Refund(bytes32)')}
WITHDRAW, REFUND = 'withdraw(bytes32,bytes32)', 'refund(bytes32)'
FLAGS = {'execution_authorized': False, 'payment_authorized': False, 'release_authorized': False}

REMEDIATION = {
    'HASHLOCK_SEED': 'Install a 32 to 64 byte holder secret from the owner keystore; it never leaves the holder process.',
    'HASHLOCK_SEED_MISMATCH': 'This holder secret did not create the condition. Open the store with the secret that prepared it.',
    'HASHLOCK_RAIL': 'Describe the leg exactly: LIGHTNING_HOLD_INVOICE {network, amount_msat, payee_node, min_final_cltv_expiry_delta, invoice_expiry} or EVM_HTLC {chain_id, contract, asset, amount, sender, receiver}.',
    'HASHLOCK_TIMES': 'Order the owner-adopted times as_of <= deliver_by <= reveal_by and leave at least 3600 seconds between reveal_by and refund_after.',
    'HASHLOCK_HOLD_TOO_LONG': 'A Lightning hold must end within half of min_final_cltv_expiry_delta x 600 seconds (at most 2016 blocks); use the EVM leg or the two-of-three escrow for longer deliveries.',
    'HASHLOCK_NONCE': 'Pass the condition nonce as 64 lowercase hex characters, or omit it to draw a fresh one.',
    'HASHLOCK_CONDITION': 'Pass the exact condition returned by prepare, unchanged.',
    'HASHLOCK_CONDITION_CHANGED': 'The condition no longer matches the agreement or the holder store. Prepare and sign a new condition.',
    'HASHLOCK_CONDITION_UNKNOWN': 'This holder store never prepared the condition. Reveal from the holder that prepared it.',
    'HASHLOCK_AGREEMENT_HELD': 'This holder store already holds a condition for the agreement with other parameters; reuse it. One agreement has one condition per holder.',
    'HASHLOCK_STORE_FULL': 'The holder store is full (100000 conditions). Open a new store directory.',
    'HASHLOCK_APPROVALS': 'Pass approvals as [{party, signature}] from the buyer and the seller over the condition assent payload.',
    'HASHLOCK_NOT_ADOPTED': 'Both buyer and seller must sign the exact condition before any reveal.',
    'HASHLOCK_RECEIPT_NOT_VERIFIED': 'Supply the buyer-signed delivery receipt and the agreement adoption so the receipt verifies; nothing is revealed until it does.',
    'HASHLOCK_RECEIPT_FAILS': 'The delivery receipt fails the typed acceptance criteria. Follow the agreed remedy; the payment returns after refund_after.',
    'HASHLOCK_REVEAL_CLOSED': 'reveal_by has passed or the condition expired; the preimage stays secret and the payment returns after refund_after.',
    'HASHLOCK_REVEALED_FOR_OTHER_RECEIPT': 'The preimage was already revealed for another receipt; the first binding stands.',
    'HASHLOCK_SIGNER': 'Sign the reveal record with the buyer key named in the agreement, or omit the signer.',
    'HASHLOCK_INVOICE': 'The invoice does not match the condition (network, amount, payment hash, description hash, payee, CLTV delta, secret or expiry). Ask the seller for a matching hold invoice.',
    'HASHLOCK_PROOF': 'Pass a settlement proof {kind: PREIMAGE, preimage} or {kind: EVM_TRANSACTION, to, data, logs}.',
    'HASHLOCK_REFUND_NOT_DUE': 'refund_after has not passed at the owner-adopted time.',
    'HASHLOCK_APPEND_ONLY': 'The holder store only moves PREPARED to REVEALED or EXPIRED; restore a backup instead of editing rows.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the input against the documented hashlock condition.')


def _hex(value, size=64, code='HASHLOCK_CONDITION'):
    need(type(value) is str and re.fullmatch('[0-9a-f]{%d}' % size, value) is not None, code)
    return value


def _time(value, code='HASHLOCK_TIMES'):
    need(type(value) is int and 0 <= value <= MAX_TIME, code)
    return value


def _commerce():
    from covenant_agent import commerce
    return commerce


def _rail(rail):
    need(type(rail) is dict and rail.get('kind') in (LIGHTNING, EVM_HTLC), 'HASHLOCK_RAIL')
    if rail['kind'] == LIGHTNING:
        from . import bitcoin_codec as btc, lightning_invoice as bolt11
        need(set(rail) == {'kind', 'network', 'amount_msat', 'payee_node', 'min_final_cltv_expiry_delta', 'invoice_expiry'},
             'HASHLOCK_RAIL')
        need(rail['network'] in bolt11.CURRENCIES and type(rail['amount_msat']) is int
             and 0 < rail['amount_msat'] <= bolt11.MAX_MSAT, 'HASHLOCK_RAIL')
        need(type(rail['min_final_cltv_expiry_delta']) is int and MIN_CLTV <= rail['min_final_cltv_expiry_delta'] <= MAX_CLTV
             and type(rail['invoice_expiry']) is int and 60 <= rail['invoice_expiry'] <= 7 * 86400, 'HASHLOCK_RAIL')
        try:
            btc.pubkey(rail['payee_node'])
        except ValueError:
            raise ValueError('HASHLOCK_RAIL') from None
        return rail
    need(set(rail) == {'kind', 'chain_id', 'contract', 'asset', 'amount', 'sender', 'receiver'}, 'HASHLOCK_RAIL')
    need(type(rail['chain_id']) is int and 0 < rail['chain_id'] < 2 ** 63 and type(rail['amount']) is int
         and 0 < rail['amount'] < 2 ** 256, 'HASHLOCK_RAIL')
    try:
        addresses = [evm.address(rail[name]) for name in ('contract', 'sender', 'receiver')]
        need(rail['asset'] == 'NATIVE' or evm.address(rail['asset']) == rail['asset'], 'HASHLOCK_RAIL')
    except ValueError:
        raise ValueError('HASHLOCK_RAIL') from None
    need(addresses == [rail['contract'], rail['sender'], rail['receiver']] and evm.ZERO_ADDRESS not in addresses
         and len(set(addresses)) == 3, 'HASHLOCK_RAIL')
    return rail


def _core(application, agreement, rail, deliver_by, reveal_by, refund_after, nonce):
    commerce = _commerce()
    t = commerce.terms(application)
    _hex(agreement)
    _hex(nonce, code='HASHLOCK_NONCE')
    return {'version': CONDITION, 'agreement': agreement, 'application': t['application'], 'criteria': t['criteria'],
            'price': {'amount': t['amount'], 'currency': t['currency']}, 'holder': 'buyer', 'receipt_signer': 'buyer',
            'requires': REQUIRES, 'deliver_by': _time(deliver_by), 'reveal_by': _time(reveal_by),
            'refund_after': _time(refund_after), 'rail': deepcopy(_rail(rail)), 'nonce': nonce, 'on_failure': t['remedy']}


def _times(core, as_of):
    _time(as_of)
    need(as_of <= core['deliver_by'] <= core['reveal_by'] and core['refund_after'] - core['reveal_by'] >= MIN_CLAIM_MARGIN,
         'HASHLOCK_TIMES')
    if core['rail']['kind'] == LIGHTNING:
        need(core['reveal_by'] + MIN_CLAIM_MARGIN - as_of <= core['rail']['min_final_cltv_expiry_delta'] * BLOCK_SECONDS // 2,
             'HASHLOCK_HOLD_TOO_LONG')


def condition_id(condition):
    return application_profile.content_id(CONDITION, condition)


def urn(condition):
    return CONDITION + ':' + condition_id(condition)


def assent_payload(condition, application):
    t = _commerce().terms(application)
    return {'label': CONDITION_LABEL, 'body': deepcopy(condition), 'required_signers': dict(t['parties'])}


def _condition(condition, application, agreement):
    """The supplied condition, required to equal the one rebuilt from the agreement and its own fields."""
    need(type(condition) is dict and set(condition) == {'version', 'agreement', 'application', 'criteria', 'price', 'holder',
                                                         'receipt_signer', 'requires', 'deliver_by', 'reveal_by',
                                                         'refund_after', 'rail', 'nonce', 'on_failure', 'payment_hash'}
         and condition['version'] == CONDITION, 'HASHLOCK_CONDITION')
    _hex(condition['payment_hash'])
    core = _core(application, agreement, condition['rail'], condition['deliver_by'], condition['reveal_by'],
                 condition['refund_after'], condition['nonce'])
    need(application_profile.canonical({**core, 'payment_hash': condition['payment_hash']}) ==
         application_profile.canonical(condition), 'HASHLOCK_CONDITION_CHANGED')
    return core


def adopted(condition, approvals, application):
    """Both buyer and seller signed the exact condition (Ed25519 over the AAP assent label)."""
    from .crypto import verify
    parties = _commerce().terms(application)['parties']
    need(type(approvals) is list and len(approvals) <= 2, 'HASHLOCK_APPROVALS')
    signed = set()
    for approval in approvals:
        need(type(approval) is dict and set(approval) == {'party', 'signature'} and approval['party'] in parties
             and approval['party'] not in signed, 'HASHLOCK_APPROVALS')
        try:
            verify(parties[approval['party']], CONDITION_LABEL, condition, approval['signature'])
        except ValueError:
            raise ValueError('HASHLOCK_APPROVALS') from None
        signed.add(approval['party'])
    need(signed == {'buyer', 'seller'}, 'HASHLOCK_NOT_ADOPTED')
    return True


# Rail parameters ---------------------------------------------------------------

def _b64(raw):
    return base64.b64encode(raw).decode('ascii')


def contract_id(condition):
    """chatch HashedTimelock contractId for this condition's EVM leg."""
    rail = condition['rail']
    need(rail['kind'] == EVM_HTLC, 'HASHLOCK_RAIL')
    native = rail['asset'] == 'NATIVE'
    types = ['address', 'address'] + ([] if native else ['address']) + ['uint256', 'bytes32', 'uint256']
    values = [rail['sender'], rail['receiver']] + ([] if native else [rail['asset']]) + \
        [rail['amount'], bytes.fromhex(condition['payment_hash']), condition['refund_after']]
    return hashlib.sha256(evm.encode_packed(types, values)).digest()


def rail_parameters(condition):
    """What each side's own software needs: hold-invoice request or contract calls. Bytes only, nothing sent."""
    rail = condition['rail']
    if rail['kind'] == LIGHTNING:
        description = urn(condition).encode('ascii')
        return {'kind': LIGHTNING, 'description': description.decode('ascii'),
                'description_hash': hashlib.sha256(description).hexdigest(), 'payment_hash': condition['payment_hash'],
                'lnd_add_hold_invoice': {'rpc': 'invoicesrpc.Invoices.AddHoldInvoice', 'rest': 'POST /v2/invoices/hodl',
                                         'body': {'hash': _b64(bytes.fromhex(condition['payment_hash'])),
                                                  'value_msat': str(rail['amount_msat']),
                                                  'description_hash': _b64(hashlib.sha256(description).digest()),
                                                  'expiry': str(rail['invoice_expiry']),
                                                  'cltv_expiry': str(rail['min_final_cltv_expiry_delta'])}},
                'creator': 'SELLER_NODE', 'payer': 'BUYER_WALLET', 'submitted': False, **FLAGS}
    native = rail['asset'] == 'NATIVE'
    create = HTLC['NATIVE' if native else 'ERC20'][0]
    arguments = ([rail['receiver'], bytes.fromhex(condition['payment_hash']), condition['refund_after']] +
                 ([] if native else [rail['asset'], rail['amount']]))
    types = ['address', 'bytes32', 'uint256'] + ([] if native else ['address', 'uint256'])
    calls = []
    if not native:
        calls.append({'to': rail['asset'], 'value': 0, 'function': 'approve(address,uint256)',
                      'data': '0x' + evm.call('approve(address,uint256)', ['address', 'uint256'], [rail['contract'], rail['amount']]).hex()})
    calls.append({'to': rail['contract'], 'value': rail['amount'] if native else 0, 'function': create,
                  'data': '0x' + evm.call(create, types, arguments).hex()})
    return {'kind': EVM_HTLC, 'chain_id': rail['chain_id'], 'sender': rail['sender'], 'calls': calls,
            'contract_id': '0x' + contract_id(condition).hex(), 'timelock': condition['refund_after'],
            'payment_hash': condition['payment_hash'], 'submitted': False, 'broadcast': False, **FLAGS}


def check_invoice(condition, application, agreement, invoice, *, as_of):
    """Does the seller's hold invoice match the signed condition? Evidence for the buyer before paying."""
    from . import lightning_invoice as bolt11
    core = _condition(condition, application, agreement)
    rail = core['rail']
    need(rail['kind'] == LIGHTNING, 'HASHLOCK_RAIL')
    _time(as_of)
    try:
        found = bolt11.decode(invoice)
    except ValueError:
        raise ValueError('HASHLOCK_INVOICE') from None
    description = hashlib.sha256(urn(condition).encode('ascii')).hexdigest()
    mismatches = sorted(name for name, ok in (
        ('network', found['currency'] == rail['network']), ('amount_msat', found['amount_msat'] == rail['amount_msat']),
        ('payment_hash', found['payment_hash'] == condition['payment_hash']),
        ('description_hash', found.get('description_hash') == description), ('payee', found['payee'] == rail['payee_node']),
        ('min_final_cltv_expiry_delta', rail['min_final_cltv_expiry_delta'] <= found['min_final_cltv_expiry_delta'] <= MAX_CLTV),
        ('unexpired', found['timestamp'] <= as_of < found['expires_at'])) if not ok)
    need(not mismatches, 'HASHLOCK_INVOICE')
    return {'condition': condition_id(condition), 'status': 'INVOICE_MATCHES_CONDITION', 'payee': found['payee'],
            'payment_hash': found['payment_hash'], 'amount_msat': found['amount_msat'], 'expires_at': found['expires_at'],
            'min_final_cltv_expiry_delta': found['min_final_cltv_expiry_delta'],
            'clock': 'OWNER_ADOPTED_ASSERTION_NOT_OBSERVED', 'paid': False, **FLAGS}


def settlement_parameters(condition, preimage):
    """The seller's claim once the preimage is revealed: SettleInvoice or withdraw calldata."""
    raw = bytes.fromhex(_hex(preimage))
    need(hashlib.sha256(raw).hexdigest() == condition['payment_hash'], 'HASHLOCK_PROOF')
    if condition['rail']['kind'] == LIGHTNING:
        return {'kind': LIGHTNING, 'lnd_settle_invoice': {'rpc': 'invoicesrpc.Invoices.SettleInvoice',
                                                         'rest': 'POST /v2/invoices/settle', 'body': {'preimage': _b64(raw)}},
                'submitted': False, **FLAGS}
    rail = condition['rail']
    return {'kind': EVM_HTLC, 'chain_id': rail['chain_id'], 'from': rail['receiver'],
            'call': {'to': rail['contract'], 'value': 0, 'function': WITHDRAW,
                     'data': '0x' + evm.call(WITHDRAW, ['bytes32', 'bytes32'], [contract_id(condition), raw]).hex()},
            'submitted': False, 'broadcast': False, **FLAGS}


def refund_parameters(condition, *, as_of):
    """The buyer's recovery after refund_after: refund calldata, or the hold invoice cancel request."""
    _time(as_of)
    need(as_of >= condition['refund_after'], 'HASHLOCK_REFUND_NOT_DUE')
    if condition['rail']['kind'] == LIGHTNING:
        return {'kind': LIGHTNING, 'lnd_cancel_invoice': {'rpc': 'invoicesrpc.Invoices.CancelInvoice',
                                                         'rest': 'POST /v2/invoices/cancel',
                                                         'body': {'payment_hash': _b64(bytes.fromhex(condition['payment_hash']))}},
                'note': 'An unsettled hold invoice HTLC also fails back to the payer before its CLTV expiry.',
                'submitted': False, **FLAGS}
    rail = condition['rail']
    return {'kind': EVM_HTLC, 'chain_id': rail['chain_id'], 'from': rail['sender'],
            'call': {'to': rail['contract'], 'value': 0, 'function': REFUND,
                     'data': '0x' + evm.call(REFUND, ['bytes32'], [contract_id(condition)]).hex()},
            'submitted': False, 'broadcast': False, **FLAGS}


def verify_settlement(condition, proof, *, reveal=None):
    """Check a supplied settlement proof against the condition. Inclusion on any chain stays UNKNOWN here."""
    _hex(condition.get('payment_hash') if type(condition) is dict else None)
    need(type(proof) is dict and proof.get('kind') in ('PREIMAGE', 'EVM_TRANSACTION'), 'HASHLOCK_PROOF')
    preimage, outcome = None, None
    if proof['kind'] == 'PREIMAGE':
        need(set(proof) == {'kind', 'preimage'}, 'HASHLOCK_PROOF')
        preimage = _hex(proof['preimage'], code='HASHLOCK_PROOF')
        need(hashlib.sha256(bytes.fromhex(preimage)).hexdigest() == condition['payment_hash'], 'HASHLOCK_PROOF')
        outcome, evidence = 'PREIMAGE_MATCHES', 'NOT_OBSERVABLE_OFFLINE'
    else:
        need(set(proof) == {'kind', 'to', 'data', 'logs'} and condition['rail']['kind'] == EVM_HTLC, 'HASHLOCK_PROOF')
        rail, ident = condition['rail'], contract_id(condition)
        try:
            need(evm.address(proof['to']) == rail['contract'], 'HASHLOCK_PROOF')
            data = evm.unhex(proof['data'], None, 'HASHLOCK_PROOF')
            if data[:4] == evm.selector(WITHDRAW):
                cid, raw = evm.decode_call(WITHDRAW, ['bytes32', 'bytes32'], data)
                need(cid == ident and hashlib.sha256(raw).hexdigest() == condition['payment_hash'], 'HASHLOCK_PROOF')
                preimage, outcome, event = raw.hex(), 'WITHDRAW_CALL_MATCHES', HTLC['NATIVE' if rail['asset'] == 'NATIVE' else 'ERC20'][1]
            else:
                (cid,) = evm.decode_call(REFUND, ['bytes32'], data)
                need(cid == ident, 'HASHLOCK_PROOF')
                outcome, event = 'REFUND_CALL_MATCHES', HTLC['NATIVE' if rail['asset'] == 'NATIVE' else 'ERC20'][2]
            logs = proof['logs']
            need(type(logs) is list and len(logs) <= 64, 'HASHLOCK_PROOF')
            logged = any(type(row) is dict and set(row) == {'address', 'topics', 'data'} and evm.address(row['address']) == rail['contract']
                         and row['topics'] == ['0x' + evm.topic(event).hex(), '0x' + ident.hex()] for row in logs)
        except ValueError:
            raise ValueError('HASHLOCK_PROOF') from None
        evidence = 'CALL_AND_EVENT_LOG_MATCH_INCLUSION_NOT_VERIFIED' if logged else 'CALL_MATCHES_NO_EVENT_LOG'
    bound = None
    if reveal is not None:
        need(type(reveal) is dict and type(reveal.get('body')) is dict, 'HASHLOCK_PROOF')
        body = reveal['body']
        need(body.get('condition') == condition_id(condition) and body.get('payment_hash') == condition['payment_hash'], 'HASHLOCK_PROOF')
        need(preimage is None or body.get('preimage') == preimage, 'HASHLOCK_PROOF')
        bound = body.get('receipt')
    return {'condition': condition_id(condition), 'outcome': outcome, 'evidence': evidence, 'bound_receipt': bound,
            'funds_moved': 'UNKNOWN_NOT_OBSERVED', 'chain_checked': False, **FLAGS}


def verify_reveal(reveal, condition, application, agreement, receipt=None, adoption=None):
    """The seller's offline check: the preimage opens the hash, the condition is unchanged and, if given, the receipt binds."""
    from .crypto import verify
    _condition(condition, application, agreement)
    need(type(reveal) is dict and set(reveal) == {'body', 'signer', 'signature'} and type(reveal['body']) is dict, 'HASHLOCK_PROOF')
    body = reveal['body']
    need(set(body) == {'version', 'condition', 'agreement', 'receipt', 'criteria', 'payment_hash', 'preimage', 'revealed_at', 'rail'}
         and body['version'] == REVEAL and body['condition'] == condition_id(condition) and body['agreement'] == agreement
         and body['payment_hash'] == condition['payment_hash'] and body['criteria'] == condition['criteria'], 'HASHLOCK_PROOF')
    need(hashlib.sha256(bytes.fromhex(_hex(body['preimage'], code='HASHLOCK_PROOF'))).hexdigest() == condition['payment_hash'],
         'HASHLOCK_PROOF')
    signed = 'UNSIGNED'
    if reveal['signer'] is not None:
        buyer = _commerce().terms(application)['parties']['buyer']
        need(reveal['signer'] == buyer, 'HASHLOCK_SIGNER')
        try:
            verify(buyer, REVEAL_LABEL, body, reveal['signature'])
        except ValueError:
            raise ValueError('HASHLOCK_SIGNER') from None
        signed = 'BUYER_SIGNATURE_VERIFIED'
    receipt_status = 'NOT_SUPPLIED'
    if receipt is not None:
        checked = _commerce().verify_receipt(application, agreement, receipt, adoption)
        need(checked['receipt'] == body['receipt'], 'HASHLOCK_PROOF')
        receipt_status = 'RECEIPT_VERIFIED_MEETS' if checked['delivery_verified'] else 'RECEIPT_BOUND_NOT_VERIFIED'
    return {'condition': body['condition'], 'status': 'PREIMAGE_OPENS_PAYMENT_HASH', 'signature': signed,
            'receipt': body['receipt'], 'receipt_status': receipt_status, 'settle': settlement_parameters(condition, body['preimage']),
            **FLAGS}


# The holder ---------------------------------------------------------------------

class HashlockHolder:
    """The buyer host's private custody of conditions and reveals (WorkflowStore SQLite, WAL, FULL sync).

    The holder secret stays in this process. The store keeps conditions and the
    one receipt each was revealed for; state moves PREPARED -> REVEALED or
    PREPARED -> EXPIRED only, enforced by triggers, in IMMEDIATE transactions.
    """

    def __init__(self, directory, seed):
        from .workflow_store import WorkflowStore
        need(type(seed) is bytes and 32 <= len(seed) <= 64, 'HASHLOCK_SEED')
        self._seed = seed
        identity = hmac.new(seed, SEED_DOMAIN, hashlib.sha256).hexdigest()
        self.store = WorkflowStore(directory, {'holder': STORE, 'secret_id': identity})
        db = self.store.db
        with self.store.exclusive():
            db.execute('CREATE TABLE IF NOT EXISTS hashlock_conditions(id TEXT PRIMARY KEY, agreement TEXT UNIQUE NOT NULL, '
                       'payment_hash TEXT UNIQUE NOT NULL, body BLOB NOT NULL, state TEXT NOT NULL, receipt TEXT, reveal BLOB)')
            db.execute("CREATE TRIGGER IF NOT EXISTS hashlock_no_delete BEFORE DELETE ON hashlock_conditions "
                       "BEGIN SELECT RAISE(ABORT,'HASHLOCK_APPEND_ONLY'); END")
            db.execute("CREATE TRIGGER IF NOT EXISTS hashlock_transitions BEFORE UPDATE ON hashlock_conditions "
                       "WHEN NOT (OLD.state='PREPARED' AND NEW.state IN ('REVEALED','EXPIRED') AND NEW.id=OLD.id "
                       "AND NEW.agreement=OLD.agreement AND NEW.payment_hash=OLD.payment_hash AND NEW.body=OLD.body) "
                       "BEGIN SELECT RAISE(ABORT,'HASHLOCK_APPEND_ONLY'); END")

    def close(self):
        self.store.close()

    def _preimage(self, core):
        return hmac.new(self._seed, PREIMAGE_DOMAIN + application_profile.canonical(core), hashlib.sha256).digest()

    def prepare(self, application, agreement, *, rail, deliver_by, reveal_by, refund_after, as_of, nonce=None):
        """A fresh condition for both parties to sign. The preimage stays with the holder."""
        nonce = secrets.token_hex(32) if nonce is None else nonce
        core = _core(application, agreement, rail, deliver_by, reveal_by, refund_after, nonce)
        _times(core, as_of)
        condition = {**core, 'payment_hash': hashlib.sha256(self._preimage(core)).hexdigest()}
        ident = condition_id(condition)
        db = self.store.db
        with self.store.exclusive():
            db.execute('BEGIN IMMEDIATE')
            try:
                row = db.execute('SELECT body FROM hashlock_conditions WHERE agreement=?', (agreement,)).fetchone()
                if row is not None:
                    stored = json.loads(row[0])
                    same = {k: v for k, v in stored.items() if k not in ('nonce', 'payment_hash')} == \
                        {k: v for k, v in core.items() if k != 'nonce'}
                    need(same, 'HASHLOCK_AGREEMENT_HELD')
                    db.execute('COMMIT')
                    return self._prepared(stored, application, replayed=True)
                count = db.execute('SELECT count(*) FROM hashlock_conditions').fetchone()[0]
                need(count < MAX_CONDITIONS, 'HASHLOCK_STORE_FULL')
                db.execute('INSERT INTO hashlock_conditions VALUES (?,?,?,?,?,?,?)',
                           (ident, agreement, condition['payment_hash'], application_profile.canonical(condition), 'PREPARED', None, None))
                db.execute('COMMIT')
            except BaseException:
                db.execute('ROLLBACK')
                raise
        return self._prepared(condition, application, replayed=False)

    def _prepared(self, condition, application, replayed):
        return {'condition': deepcopy(condition), 'id': condition_id(condition), 'urn': urn(condition),
                'assent_payload': assent_payload(condition, application), 'rail_parameters': rail_parameters(condition),
                'replayed': replayed, 'preimage_disclosed': False, **FLAGS}

    def status(self, condition):
        row = self.store.db.execute('SELECT state, receipt FROM hashlock_conditions WHERE id=?',
                                    (condition_id(condition),)).fetchone()
        need(row is not None, 'HASHLOCK_CONDITION_UNKNOWN')
        return {'condition': condition_id(condition), 'state': row[0], 'receipt': row[1], 'preimage_disclosed': row[0] == 'REVEALED'}

    def reveal(self, condition, approvals, application, agreement, receipt, adoption, *, as_of, signer=None):
        """Reveal the preimage only for a verified receipt that meets the criteria, before reveal_by, once."""
        from .crypto import public_key, sign
        commerce = _commerce()
        core = _condition(condition, application, agreement)
        adopted(condition, approvals, application)
        _time(as_of)
        ident = condition_id(condition)
        parties = commerce.terms(application)['parties']
        need(signer is None or public_key(signer) == parties['buyer'], 'HASHLOCK_SIGNER')
        db = self.store.db
        with self.store.exclusive():
            db.execute('BEGIN IMMEDIATE')
            try:
                row = db.execute('SELECT body, state, receipt, reveal FROM hashlock_conditions WHERE id=?', (ident,)).fetchone()
                need(row is not None, 'HASHLOCK_CONDITION_UNKNOWN')
                need(bytes(row[0]) == application_profile.canonical(condition), 'HASHLOCK_CONDITION_CHANGED')
                checked = commerce.verify_receipt(application, agreement, receipt, adoption)
                if row[1] == 'REVEALED':
                    need(checked['receipt'] == row[2], 'HASHLOCK_REVEALED_FOR_OTHER_RECEIPT')
                    db.execute('COMMIT')
                    stored = json.loads(row[3])
                    return {'reveal': stored, 'settle': settlement_parameters(condition, stored['body']['preimage']),
                            'replayed': True, 'preimage_disclosed': True, **FLAGS}
                need(row[1] == 'PREPARED', 'HASHLOCK_REVEAL_CLOSED')
                if as_of > core['reveal_by']:
                    db.execute("UPDATE hashlock_conditions SET state='EXPIRED' WHERE id=?", (ident,))
                    db.execute('COMMIT')
                    raise ValueError('HASHLOCK_REVEAL_CLOSED')
                if not checked['delivery_verified']:
                    failed = checked['verdict'] == 'FAILS' and checked['agreement_adoption'] == 'VERIFIED'
                    raise ValueError('HASHLOCK_RECEIPT_FAILS' if failed else 'HASHLOCK_RECEIPT_NOT_VERIFIED')
                preimage = self._preimage(core)
                need(hashlib.sha256(preimage).hexdigest() == condition['payment_hash'], 'HASHLOCK_SEED_MISMATCH')
                body = {'version': REVEAL, 'condition': ident, 'agreement': agreement, 'receipt': checked['receipt'],
                        'criteria': condition['criteria'], 'payment_hash': condition['payment_hash'], 'preimage': preimage.hex(),
                        'revealed_at': as_of, 'rail': condition['rail']['kind']}
                record = {'body': body, 'signer': None if signer is None else parties['buyer'],
                          'signature': None if signer is None else sign(signer, REVEAL_LABEL, body)}
                db.execute("UPDATE hashlock_conditions SET state='REVEALED', receipt=?, reveal=? WHERE id=?",
                           (checked['receipt'], application_profile.canonical(record), ident))
                db.execute('COMMIT')
            except BaseException:
                if db.in_transaction:
                    db.execute('ROLLBACK')
                raise
        return {'reveal': record, 'settle': settlement_parameters(condition, body['preimage']), 'replayed': False,
                'preimage_disclosed': True, **FLAGS}

    def expire(self, condition, *, as_of):
        """After reveal_by the condition closes; the payment returns to the buyer after refund_after."""
        _time(as_of)
        ident = condition_id(condition)
        db = self.store.db
        with self.store.exclusive():
            db.execute('BEGIN IMMEDIATE')
            try:
                row = db.execute('SELECT state FROM hashlock_conditions WHERE id=?', (ident,)).fetchone()
                need(row is not None, 'HASHLOCK_CONDITION_UNKNOWN')
                need(as_of > condition['reveal_by'] or row[0] != 'PREPARED', 'HASHLOCK_TIMES')
                if row[0] == 'PREPARED':
                    db.execute("UPDATE hashlock_conditions SET state='EXPIRED' WHERE id=?", (ident,))
                db.execute('COMMIT')
            except BaseException:
                db.execute('ROLLBACK')
                raise
        return self.status(condition)


def describe():
    return {'version': CONDITION, 'reveal': REVEAL, 'store': STORE, 'legs': [LIGHTNING, EVM_HTLC],
            'requires': REQUIRES, 'lightning': 'BOLT #11 hold invoice; LND invoicesrpc AddHoldInvoice/SettleInvoice/CancelInvoice (v0.21.5-beta)',
            'evm': 'chatch/hashed-timelock-contract-ethereum HashedTimelock and HashedTimelockERC20 (611f2d3)',
            'hash': 'SHA-256 preimage, unique per condition', 'min_claim_margin_seconds': MIN_CLAIM_MARGIN,
            'max_cltv_delta': MAX_CLTV, 'clock': 'OWNER_ADOPTED_ASSERTION', 'network_contacted': False, **FLAGS}
