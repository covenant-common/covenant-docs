"""Portable exact-assent agreements and padded, unlabeled recipient delivery.

This opt-in profile authenticates an agreed procedure, not physical truth, legal
effect or a native private escrow. Payload encryption does not make signatures,
the chain, or ZK proofs post-quantum. See docs/PRIVATE_COVENANTS_032.md.
"""
from copy import deepcopy
import hashlib
import os
import re
import secrets

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from covenant_language import quantum
from .crypto import canonical, loads, need, exact, key, digest, public_key, sign, verify, verification_key

VERSION = "covenant-private-agreement/0.1"
RESOLUTION_VERSION = "covenant-private-resolution/0.1"
DELIVERY_VERSION = "covenant-private-delivery/0.1"
LARGE_DELIVERY_VERSION = "covenant-private-delivery/0.2"
DELIVERY_SUITE = "ML-KEM-768-HKDF-SHA256-AES256GCM+AES256GCM"
CONTENT_BYTES = 16 * 1024
LARGE_CONTENT_BYTES = 64 * 1024
PADDING_BUCKETS = (CONTENT_BYTES, LARGE_CONTENT_BYTES)
RECIPIENT_SLOTS = 8
RESULTS = frozenset(("SUPPORTED", "REFUTED", "INDETERMINATE"))
MODES = frozenset(("COMPUTABLE", "EVIDENTIARY", "JUDGMENT"))


def _label(value):
    need(type(value) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}", value) is not None, "PRIVATE_LABEL")


def _text(value, maximum=4096, empty=False):
    need(type(value) is str and len(value) <= maximum and (empty or bool(value)), "PRIVATE_TEXT")
    canonical(value)


def _context(context):
    exact(context, "chain scope")
    key(context["chain"])
    _text(context["scope"], 256)


def _keys(keys):
    need(type(keys) is dict and 1 <= len(keys) <= 8, "PRIVATE_KEYS")
    identities = []
    for name, value in keys.items():
        _label(name)
        verification_key(value)
        identities.append(canonical(value))
    need(len(set(identities)) == len(identities), "PRIVATE_KEY_ALIAS")


def _refs(refs):
    need(type(refs) is list and len(refs) <= 32, "PRIVATE_REFERENCES")
    for ref in refs:
        key(ref)
    need(len(set(refs)) == len(refs), "PRIVATE_REFERENCES")


def _procedure(procedure):
    exact(procedure, "mode method resolvers threshold question appeal")
    need(type(procedure["mode"]) is str and procedure["mode"] in MODES, "PRIVATE_SEMANTIC_MODE")
    _text(procedure["method"])
    _text(procedure["question"])
    _text(procedure["appeal"], empty=True)
    _keys(procedure["resolvers"])
    need(type(procedure["threshold"]) is int and 1 <= procedure["threshold"] <= len(procedure["resolvers"]), "PRIVATE_RESOLVER_THRESHOLD")


def _body(body):
    exact(body, "version context parties terms procedure content_refs disclosure_manifest salt")
    need(body["version"] == VERSION, "PRIVATE_VERSION")
    _context(body["context"])
    _keys(body["parties"])
    canonical(body["terms"])
    _procedure(body["procedure"])
    _refs(body["content_refs"])
    if body["disclosure_manifest"] is not None:
        key(body["disclosure_manifest"])
    key(body["salt"])
    canonical(body)


def create_agreement(*, context, parties, terms, procedure, content_refs=None, disclosure_manifest=None):
    """Make an unsigned immutable proposal. Any change requires a new assent.

    Terms use the existing bounded ASCII/integer profile. Non-ASCII text, video
    and arbitrary future byte formats belong in opaque content-addressed refs.
    """
    body = deepcopy(dict(version=VERSION, context=context, parties=parties,
                         terms=terms, procedure=procedure, content_refs=content_refs or [],
                         disclosure_manifest=disclosure_manifest, salt=os.urandom(32).hex()))
    _body(body)
    return dict(body=body, agreement_id=digest("COVENANT-PRIVATE-AGREEMENT-0.1", body), assents={})


def _proposal(agreement):
    exact(agreement, "body agreement_id assents")
    _body(agreement["body"])
    key(agreement["agreement_id"])
    need(agreement["agreement_id"] == digest("COVENANT-PRIVATE-AGREEMENT-0.1", agreement["body"]), "PRIVATE_AGREEMENT_ID")
    need(type(agreement["assents"]) is dict and set(agreement["assents"]) <= set(agreement["body"]["parties"]), "PRIVATE_ASSENTS")


def assent(agreement, party, signing_key):
    """Return a new bundle containing one exact-ID assent, never mutate input."""
    _proposal(agreement)
    need(party in agreement["body"]["parties"], "PRIVATE_PARTY")
    need(public_key(signing_key) == agreement["body"]["parties"][party], "PRIVATE_SIGNER")
    out = deepcopy(agreement)
    statement = dict(agreement_id=agreement["agreement_id"], party=party)
    out["assents"][party] = sign(signing_key, "COVENANT-PRIVATE-ASSENT-0.1", statement)
    return out


def verify_agreement(agreement, *, expected_context, expected_parties, expected_id):
    """Trust anchors must be supplied locally; proof-contained keys are not policy."""
    _context(expected_context)
    _keys(expected_parties)
    key(expected_id)
    _proposal(agreement)
    need(agreement["body"]["context"] == expected_context, "PRIVATE_CONTEXT")
    need(agreement["body"]["parties"] == expected_parties, "PRIVATE_PARTIES")
    need(agreement["agreement_id"] == expected_id, "PRIVATE_ID_POLICY")
    need(set(agreement["assents"]) == set(expected_parties), "PRIVATE_MISSING_ASSENT")
    for party, signer in expected_parties.items():
        verify(signer, "COVENANT-PRIVATE-ASSENT-0.1",
               dict(agreement_id=expected_id, party=party), agreement["assents"][party])
    return dict(verified=True, agreement_id=expected_id, parties=sorted(expected_parties),
                semantic_mode=agreement["body"]["procedure"]["mode"],
                native_private_escrow=False, world_truth_proven=False)


def _resolution(resolution):
    exact(resolution, "body attestations")
    body = resolution["body"]
    exact(body, "version agreement_id context question evidence result reasons")
    need(body["version"] == RESOLUTION_VERSION and type(body["result"]) is str and body["result"] in RESULTS, "PRIVATE_RESOLUTION")
    key(body["agreement_id"])
    _context(body["context"])
    _text(body["question"])
    _refs(body["evidence"])
    _text(body["reasons"])
    need(type(resolution["attestations"]) is dict and len(resolution["attestations"]) <= 8, "PRIVATE_ATTESTATIONS")
    for judge in resolution["attestations"]:
        _label(judge)
    canonical(resolution)


def resolve(agreement, judge, signing_key, result, *, evidence=None, reasons):
    """Create a judge attestation. Consumers must still verify all original assents."""
    _proposal(agreement)
    procedure = agreement["body"]["procedure"]
    need(judge in procedure["resolvers"] and public_key(signing_key) == procedure["resolvers"][judge], "PRIVATE_JUDGE")
    body = deepcopy(dict(version=RESOLUTION_VERSION, agreement_id=agreement["agreement_id"],
                         context=agreement["body"]["context"], question=procedure["question"],
                         evidence=evidence or [], result=result, reasons=reasons))
    resolution = dict(body=body, attestations={})
    _resolution(resolution)
    return attest_resolution(resolution, judge, signing_key)


def attest_resolution(resolution, judge, signing_key):
    """Co-sign the same exact question/evidence/decision/reasons statement."""
    _resolution(resolution)
    _label(judge)
    out = deepcopy(resolution)
    out["attestations"][judge] = sign(signing_key, "COVENANT-PRIVATE-RESOLUTION-0.1",
                                     dict(judge=judge, resolution=out["body"]))
    return out


def verify_resolution(agreement, resolution, *, expected_context, expected_parties, expected_id):
    verified = verify_agreement(agreement, expected_context=expected_context,
                                expected_parties=expected_parties, expected_id=expected_id)
    _resolution(resolution)
    body = resolution["body"]
    procedure = agreement["body"]["procedure"]
    need(body["agreement_id"] == expected_id and body["context"] == expected_context, "PRIVATE_RESOLUTION_BINDING")
    need(body["question"] == procedure["question"], "PRIVATE_RESOLUTION_QUESTION")
    judges = resolution["attestations"]
    need(set(judges) <= set(procedure["resolvers"]), "PRIVATE_UNAUTHORIZED_JUDGE")
    need(len(judges) >= procedure["threshold"], "PRIVATE_RESOLVER_THRESHOLD")
    for judge, signature in judges.items():
        verify(procedure["resolvers"][judge], "COVENANT-PRIVATE-RESOLUTION-0.1",
               dict(judge=judge, resolution=body), signature)
    return dict(verified=True, agreement_id=verified["agreement_id"], result=body["result"],
                judges=sorted(judges), world_truth_proven=False, native_private_escrow=False)


def _hex(value, byte_length):
    need(type(value) is str and len(value) == byte_length * 2 and
         re.fullmatch(r"[0-9a-f]+", value) is not None, "PRIVATE_DELIVERY_ENCODING")


def _padding(header):
    need(type(header) is dict, "PRIVATE_DELIVERY_HEADER")
    if header.get("version") == DELIVERY_VERSION:
        exact(header, "version suite nonce ciphertext_hash")
        padding = CONTENT_BYTES
    elif header.get("version") == LARGE_DELIVERY_VERSION:
        exact(header, "version suite nonce ciphertext_hash padding")
        need(type(header["padding"]) is int and header["padding"] == LARGE_CONTENT_BYTES, "PRIVATE_DELIVERY_PADDING")
        padding = LARGE_CONTENT_BYTES
    else:
        raise ValueError("PRIVATE_DELIVERY_SUITE")
    need(header["suite"] == DELIVERY_SUITE, "PRIVATE_DELIVERY_SUITE")
    return padding


def _ciphertext_bytes(ciphertext, padding):
    if padding == CONTENT_BYTES:
        _hex(ciphertext, CONTENT_BYTES + 16)
        return bytes.fromhex(ciphertext)
    # The existing canonical profile caps any individual ASCII string at 100k.
    # Two fixed chunks preserve that profile without loosening its bounds.
    need(type(ciphertext) is list and len(ciphertext) == 2, "PRIVATE_DELIVERY_ENCODING")
    for chunk in ciphertext:
        _hex(chunk, (LARGE_CONTENT_BYTES + 16) // 2)
    return b"".join(bytes.fromhex(chunk) for chunk in ciphertext)


def _packet(packet):
    exact(packet, "header ciphertext wraps")
    header = packet["header"]
    padding = _padding(header)
    _hex(header["nonce"], 12)
    _hex(header["ciphertext_hash"], 32)
    cipherbytes = _ciphertext_bytes(packet["ciphertext"], padding)
    need(hashlib.sha256(cipherbytes).hexdigest() == header["ciphertext_hash"], "PRIVATE_DELIVERY_CIPHERTEXT")
    need(type(packet["wraps"]) is list and len(packet["wraps"]) == RECIPIENT_SLOTS, "PRIVATE_DELIVERY_SLOTS")
    for envelope in packet["wraps"]:
        exact(envelope, "body ciphertext")
        exact(envelope["body"], "version suite encapsulation nonce")
        need(envelope["body"]["version"] == quantum.VERSION and envelope["body"]["suite"] == quantum.KEM, "PRIVATE_DELIVERY_SUITE")
        _hex(envelope["body"]["encapsulation"], 1088)
        _hex(envelope["body"]["nonce"], 12)
        _hex(envelope["ciphertext"], 48)
    need(len({canonical(item) for item in packet["wraps"]}) == RECIPIENT_SLOTS, "PRIVATE_DELIVERY_DUPLICATE_SLOT")
    canonical(packet)
    return padding


def _delivery_aad(header, context):
    # Authenticate context without emitting a stable public scope fingerprint.
    return canonical(dict(header=header, context=context))


def _seal_payload(payload, kind, *, recipient_public_keys, context, padding=CONTENT_BYTES):
    _context(context)
    need(type(padding) is int and padding in PADDING_BUCKETS, "PRIVATE_DELIVERY_PADDING")
    need(type(recipient_public_keys) is list and 1 <= len(recipient_public_keys) <= RECIPIENT_SLOTS, "PRIVATE_RECIPIENTS")
    need(all(type(pub) is bytes and len(pub) == 1184 for pub in recipient_public_keys), "PRIVATE_RECIPIENT_KEY")
    need(len(set(recipient_public_keys)) == len(recipient_public_keys), "PRIVATE_RECIPIENT_ALIAS")
    raw = canonical(dict(kind=kind, payload=payload))
    need(len(raw) <= padding - 4, "PRIVATE_CONTENT_LIMIT")
    padded = len(raw).to_bytes(4, "big") + raw + os.urandom(padding - 4 - len(raw))
    content_key = os.urandom(32)
    header = dict(version=DELIVERY_VERSION if padding == CONTENT_BYTES else LARGE_DELIVERY_VERSION,
                  suite=DELIVERY_SUITE, nonce=os.urandom(12).hex())
    if padding == LARGE_CONTENT_BYTES:
        header["padding"] = padding
    ciphertext = AESGCM(content_key).encrypt(bytes.fromhex(header["nonce"]), padded, _delivery_aad(header, context))
    header["ciphertext_hash"] = hashlib.sha256(ciphertext).hexdigest()
    recipients = list(recipient_public_keys)
    while len(recipients) < RECIPIENT_SLOTS:
        dummy_public, _dummy_secret = quantum.recipient_keypair()
        recipients.append(dummy_public)
    wraps = [quantum.encrypt_for(content_key, recipient_public_key=pub, context=_delivery_aad(header, context)) for pub in recipients]
    secrets.SystemRandom().shuffle(wraps)
    encoded_ciphertext = ciphertext.hex() if padding == CONTENT_BYTES else [
        ciphertext[:len(ciphertext)//2].hex(), ciphertext[len(ciphertext)//2:].hex()]
    packet = dict(header=header, ciphertext=encoded_ciphertext, wraps=wraps)
    _packet(packet)
    return packet


def _open_payload(packet, kind, *, recipient_secret_key, expected_context, expected_padding=None):
    padding = _packet(packet)
    if expected_padding is not None:
        need(type(expected_padding) is int and expected_padding in PADDING_BUCKETS, "PRIVATE_DELIVERY_PADDING")
        need(padding == expected_padding, "PRIVATE_PADDING_POLICY")
    _context(expected_context)
    header = packet["header"]
    matching = []
    for envelope in packet["wraps"]:
        try:
            content_key = quantum.decrypt_for(envelope, recipient_secret_key=recipient_secret_key, context=_delivery_aad(header, expected_context))
            if len(content_key) == 32:
                matching.append(content_key)
        except (ValueError, TypeError):
            continue
    need(len(matching) == 1, "PRIVATE_DELIVERY_AUTHENTICATION")
    content_header = {k: v for k, v in header.items() if k != "ciphertext_hash"}
    try:
        padded = AESGCM(matching[0]).decrypt(bytes.fromhex(header["nonce"]), _ciphertext_bytes(packet["ciphertext"], padding), _delivery_aad(content_header, expected_context))
    except (InvalidTag, ValueError, TypeError) as error:
        raise ValueError("PRIVATE_DELIVERY_AUTHENTICATION") from error
    size = int.from_bytes(padded[:4], "big")
    need(0 < size <= padding - 4, "PRIVATE_CONTENT_LIMIT")
    raw = padded[4:4+size]
    content = loads(raw)
    need(canonical(content) == raw, "PRIVATE_CONTENT_ENCODING")
    exact(content, "kind payload")
    need(content["kind"] == kind, "PRIVATE_CONTENT_KIND")
    return content["payload"]


def seal_agreement(agreement, *, recipient_public_keys, context, padding=CONTENT_BYTES):
    """Padded exact-assent delivery with eight unlabeled real/dummy key wraps.

    Format metadata concealment is not a proof of anonymous broadcast or origin
    anonymity. Exact context is authenticated privately and never published.
    """
    _proposal(agreement)
    verify_agreement(agreement, expected_context=context, expected_parties=agreement["body"]["parties"], expected_id=agreement["agreement_id"])
    return _seal_payload(agreement, "agreement", recipient_public_keys=recipient_public_keys, context=context, padding=padding)


def open_agreement(packet, *, recipient_secret_key, expected_context, expected_parties, expected_id, expected_padding=None):
    """Try all slots; return a verified agreement and never return the matching slot."""
    _keys(expected_parties)
    key(expected_id)
    agreement = _open_payload(packet, "agreement", recipient_secret_key=recipient_secret_key, expected_context=expected_context, expected_padding=expected_padding)
    verify_agreement(agreement, expected_context=expected_context, expected_parties=expected_parties, expected_id=expected_id)
    return agreement


def seal_resolution(agreement, resolution, *, recipient_public_keys, context, padding=CONTENT_BYTES):
    """Deliver a verified judgment through the same padded private format."""
    verify_resolution(agreement, resolution, expected_context=context,
                      expected_parties=agreement["body"]["parties"], expected_id=agreement["agreement_id"])
    return _seal_payload(resolution, "resolution", recipient_public_keys=recipient_public_keys, context=context, padding=padding)


def open_resolution(packet, agreement, *, recipient_secret_key, expected_context, expected_parties, expected_id, expected_padding=None):
    """Original-assent and judge verification remain mandatory after decryption."""
    verify_agreement(agreement, expected_context=expected_context, expected_parties=expected_parties, expected_id=expected_id)
    resolution = _open_payload(packet, "resolution", recipient_secret_key=recipient_secret_key, expected_context=expected_context, expected_padding=expected_padding)
    verify_resolution(agreement, resolution, expected_context=expected_context, expected_parties=expected_parties, expected_id=expected_id)
    return resolution


def settlement_memo(agreement_id, action="settlement"):
    """Fresh event-specific opaque memo; keep its private linkage off the ledger."""
    key(agreement_id)
    _text(action, 128)
    return digest("COVENANT-PRIVATE-SETTLEMENT-MEMO-0.1",
                  dict(agreement_id=agreement_id, action=action, salt=os.urandom(32).hex()))


def capabilities():
    return dict(exact_assent=True, declared_resolution=True, padded_delivery=True, private_resolution_delivery=True,
                encryption="ML-KEM-768-HKDF-SHA256-AES256GCM", recipient_slots=RECIPIENT_SLOTS,
                padding_buckets=list(PADDING_BUCKETS), padding_profile_visible=True,
                forward_secrecy=False, post_compromise_recovery=False, network_origin_hidden=False,
                anonymous_broadcast_proven=False, trustless_native_private_escrow=False,
                monero_equivalent=False, production_qualified=False)
