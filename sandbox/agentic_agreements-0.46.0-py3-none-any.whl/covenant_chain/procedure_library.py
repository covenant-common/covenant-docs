"""Private, bounded reusable procedures. Publishing is local data, never adoption."""
import fcntl,os,stat
from pathlib import Path
from covenant_language.capsules import canonical,decode,validate,capsule_id,procedure_body,reference
from covenant_language.safe_io import atomic_write,lock_file
from .adapters import _instance
from .crypto import need


class UnknownProcedure(FileNotFoundError):
    """A procedure this library does not hold. The code names it; no path is echoed."""
    code='LIBRARY_UNKNOWN_PROCEDURE'

    def __init__(self):
        super().__init__(self.code)

    def __str__(self):
        return self.code


class ProcedureLibrary:
    def __init__(self,directory):
        self.directory=Path(directory);_instance(self.directory)
        fd=os.open(self.directory/'library.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600)
        info=os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode)&0o077==0,'LIBRARY_PRIVATE_LOCK')
        self.lock=os.fdopen(fd,'rb')

    def load(self,ref):
        reference(ref)
        try:fd=os.open(self.directory/(ref+'.json'),os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        except FileNotFoundError:raise UnknownProcedure() from None
        try:
            info=os.fstat(fd);need(stat.S_ISREG(info.st_mode) and info.st_size<=150000,'LIBRARY_FILE')
            raw=os.read(fd,150001)
        finally:os.close(fd)
        obj=decode(raw);need(canonical(obj)==raw and capsule_id(obj)==ref,'LIBRARY_CONTENT_CHANGED');return obj

    def graph(self,root,pending=None):
        objects={} if pending is None else dict(pending);seen=set();active=set();requirements=set()
        def visit(ref,depth):
            need(depth<=16 and len(seen)<128,'LIBRARY_GRAPH_LIMIT')
            need(ref not in active,'LIBRARY_CYCLE')
            if ref in seen:return
            active.add(ref)
            obj=objects[ref] if ref in objects else self.load(ref)
            need(capsule_id(obj)==ref,'LIBRARY_CONTENT_CHANGED');body=procedure_body(obj)
            objects[ref]=obj;requirements.update(body['requires'])
            for child in body['members']:visit(child,depth+1)
            active.remove(ref);seen.add(ref)
        visit(root,0)
        return {r:objects[r] for r in sorted(seen)},sorted(requirements)

    def publish(self,capsule):
        ref=capsule_id(capsule);procedure_body(capsule)
        lock_file(self.lock.fileno())
        try:
            self.graph(ref,{ref:capsule})
            files=list(self.directory.glob('*.json'))
            need(len(files)<256 or (self.directory/(ref+'.json')).exists(),'LIBRARY_QUOTA')
            try:atomic_write(self.directory/(ref+'.json'),canonical(capsule),mode=0o600,exclusive=True,follow_symlinks=False)
            except FileExistsError:need(self.load(ref)==capsule,'LIBRARY_CONTENT_CHANGED')
        finally:fcntl.flock(self.lock.fileno(),fcntl.LOCK_UN)
        return {'id':ref,'status':'STORED_IN_LOCAL_LIBRARY','adopted':False,'externally_published':False}

    def export(self,ref):
        objects,requirements=self.graph(ref)
        return {'version':'covenant-procedure-bundle/0.1','root':ref,'objects':objects,'requirements':requirements,'authority':'NONE'}

    def import_bundle(self,bundle):
        need(type(bundle) is dict and set(bundle)=={'version','root','objects','requirements','authority'} and
             bundle['version']=='covenant-procedure-bundle/0.1' and bundle['authority']=='NONE','LIBRARY_BUNDLE')
        need(type(bundle['objects']) is dict and 0<len(bundle['objects'])<=128,'LIBRARY_BUNDLE_LIMIT')
        objects,requirements=self.graph(bundle['root'],bundle['objects'])
        need(set(objects)==set(bundle['objects']) and requirements==bundle['requirements'],'LIBRARY_BUNDLE_CLOSURE')
        # All content is validated before storage; adoption is always separate.
        done=set()
        def store(ref):
            if ref in done:return
            for child in objects[ref]['dependencies']:store(child)
            self.publish(objects[ref]);done.add(ref)
        store(bundle['root'])
        return {'id':bundle['root'],'imported':len(done),'adopted':False}

    def search(self,tags,capabilities):
        need(type(tags) is list and len(tags)<=32 and all(type(t) is str for t in tags),'LIBRARY_TAGS')
        result=[]
        files=sorted(self.directory.glob('*.json'));need(len(files)<=256,'LIBRARY_QUOTA')
        for path in files:
            obj=self.load(path.stem);body=procedure_body(obj)
            if not set(tags)<=set(body['tags']):continue
            _,requirements=self.graph(path.stem)
            missing=sorted(set(requirements)-set(capabilities))
            result.append({'id':path.stem,'name':body['name'],'tags':body['tags'],'missing_capabilities':missing,
                           'capability_match':not missing,'adopted':False,'authority':'NONE'})
        return {'procedures':result,'ranking':'CONTENT_ID_ORDER_NOT_REPUTATION','execution_authorized':False}

    def close(self):self.lock.close()
