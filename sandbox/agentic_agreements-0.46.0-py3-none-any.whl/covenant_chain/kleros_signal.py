"""Kleros registry decisions synced to ERC-8004, read as a weak, labelled signal outside the receipt score.

TAKE-AND-IMPROVE on a GRAFT. The Kleros reputation oracle (kleros/reputation-oracle) writes ERC-8004
Reputation Registry feedback (erc8004_bridge reads the NewFeedback and FeedbackRevoked events) for agents
that its curated Kleros agent registry lists, and revokes it when the listing ends. Its feedback document,
schema ``kleros-reputation-oracle/v1``, names the registry item, stake, dispute and ruling.

* Only feedback from an oracle client address the owner pinned counts; every other client is excluded.
* Feedback documents come from the caller: an inline ``data:application/json;base64`` URI carried in the
  log itself, or an ``ipfs://`` CIDv0 file checked against its CID (one UnixFS dag-pb block, sha2-256).
  A document the caller did not supply is reported NOT_SUPPLIED; one that does not hash to its CID is
  excluded. The oracle writes a zero feedbackHash, which commits to nothing; a non-zero one must match.
* A revoked feedback no longer stands. Per agent the signal reports the standing decision, its document
  and how it was checked.

The result is a WEAK, LABELLED registry decision. A curated listing is a crowd judgement about listing
criteria and a deposit, not a receipt of an honoured agreement: it never enters anchored_reputation, the
receipt score or any ranking order. ``annotate`` reports it beside a ranking, which is returned unchanged,
and the ERC-8004 agentId to AAP key mapping stays the owner's claim. Nothing is fetched or submitted.
"""
from copy import deepcopy
import base64
import hashlib
import re

from .anchor import keccak256
from .crypto import need
from . import erc8004_bridge as erc
from . import interop_codec as codec

SCHEMA = 'kleros-reputation-oracle/v1'
REVOKED = 'FeedbackRevoked(uint256,address,uint64)'
DATA_URI = 'data:application/json;base64,'
MAX_ENTRIES = 1024
MAX_DOCUMENTS = 256
MAX_DOCUMENT = 65536
CIDV0 = re.compile(r'Qm[1-9A-HJ-NP-Za-km-z]{44}\Z')
ZERO = '0x' + '00' * 32

REMEDIATION = {
    'KLEROS_ORACLE': 'Pin the oracle client address(es) yourself: at most 8 0x-prefixed 20-byte addresses.',
    'KLEROS_LOG': 'Supply NewFeedback or FeedbackRevoked logs {topics, data} of the ERC-8004 Reputation Registry.',
    'KLEROS_NOT_ORACLE': 'This feedback comes from a client you did not pin as the Kleros oracle; it is excluded.',
    'KLEROS_DOCUMENT': 'Supply the feedback document: inline in a data:application/json;base64 URI or as {uri, body} for its ipfs:// CIDv0.',
    'KLEROS_CID': 'The supplied body does not hash to the ipfs:// CIDv0 the log names; refuse it.',
    'KLEROS_HASH': 'The feedback document does not match the non-zero keccak256 feedbackHash in the log.',
    'KLEROS_SCHEMA': 'The document is not a kleros-reputation-oracle/v1 feedback consistent with its log.',
    'KLEROS_INPUT': 'Pass at most 1024 log entries and 256 documents.',
}


def remediation(code):
    return REMEDIATION.get(code, erc.remediation(code))


def _varint(number):
    out = bytearray()
    while True:
        low, number = number & 0x7f, number >> 7
        out.append(low | (0x80 if number else 0))
        if not number:
            return bytes(out)


def _field(number, payload):
    if type(payload) is int:
        return _varint(number << 3) + _varint(payload)
    return _varint(number << 3 | 2) + _varint(len(payload)) + payload


def cid_v0(raw):
    """CIDv0 of a file stored as one UnixFS dag-pb block (ipfs add defaults, up to 256 KiB)."""
    need(isinstance(raw, (bytes, bytearray)) and 0 < len(raw) <= 262144, 'KLEROS_CID')
    unixfs = _field(1, 2) + _field(2, bytes(raw)) + _field(3, len(raw))
    return codec.base58btc(b'\x12\x20' + hashlib.sha256(_field(1, unixfs)).digest())


def decode_revoked(log):
    """FeedbackRevoked(uint256 indexed agentId, address indexed clientAddress, uint64 indexed feedbackIndex)."""
    need(type(log) is dict and set(log) == {'topics', 'data'} and type(log['topics']) is list and len(log['topics']) == 4
         and log['data'] in ('0x', ''), 'KLEROS_LOG')
    topics = [erc._hex(item, 32) for item in log['topics']]
    need(all(len(item) == 32 for item in topics) and topics[0] == keccak256(REVOKED.encode('ascii'))
         and topics[2][:12] == b'\0' * 12 and int.from_bytes(topics[3], 'big') < 2**64, 'KLEROS_LOG')
    return {'agent_id': int.from_bytes(topics[1], 'big'), 'client': '0x' + topics[2][12:].hex(),
            'index': int.from_bytes(topics[3], 'big')}


def _documents(rows):
    rows = [] if rows is None else rows
    need(type(rows) is list and len(rows) <= MAX_DOCUMENTS, 'KLEROS_INPUT')
    found = {}
    for row in rows:
        need(type(row) is dict and set(row) == {'uri', 'body'} and type(row['uri']) is str and type(row['body']) is str
             and len(row['body'].encode('utf-8')) <= MAX_DOCUMENT, 'KLEROS_DOCUMENT')
        found[row['uri']] = row['body'].encode('utf-8')
    return found


def _document(row, documents):
    """(raw bytes, how they were checked) for the feedback URI of one decoded log."""
    uri = row['feedback_uri']
    if uri.startswith(DATA_URI):
        try:
            raw = codec.b64_decode(uri[len(DATA_URI):], MAX_DOCUMENT)
        except ValueError:
            raise ValueError('KLEROS_DOCUMENT') from None
        check = 'INLINE_IN_THE_LOG'
    else:
        cid = uri[len('ipfs://'):] if uri.startswith('ipfs://') else ''
        need(CIDV0.fullmatch(cid) is not None, 'KLEROS_DOCUMENT')
        if uri not in documents:
            return None, 'NOT_SUPPLIED'
        raw = documents[uri]
        need(cid_v0(raw) == cid, 'KLEROS_CID')
        check = 'IPFS_CIDV0_RECOMPUTED'
    if row['feedback_hash'] != ZERO:
        need('0x' + keccak256(raw).hex() == row['feedback_hash'], 'KLEROS_HASH')
        check += '+KECCAK256_FEEDBACK_HASH'
    return raw, check


def _decision(row, raw, agent_registry):
    try:
        value = codec.parse(raw.decode('utf-8'), MAX_DOCUMENT, 8, 512)
    except (UnicodeError, ValueError):
        raise ValueError('KLEROS_SCHEMA') from None
    need(type(value) is dict and value.get('schema') == SCHEMA and type(value.get('kleros')) is dict, 'KLEROS_SCHEMA')
    agent = value.get('agentId')
    agent = int(agent) if type(agent) is str and re.fullmatch(r'0|[1-9][0-9]{0,77}', agent) else agent
    client = value.get('clientAddress')
    try:
        same = (agent == row['agent_id'] and type(client) is str and erc.address(client.rsplit(':', 1)[-1]) == row['client']
                and erc.registry(value.get('agentRegistry')) == agent_registry and value.get('value') == row['value']
                and value.get('valueDecimals') == row['decimals'] and value.get('tag1') == row['tag1']
                and value.get('tag2') == row['tag2'])
    except ValueError:
        same = False
    need(same, 'KLEROS_SCHEMA')
    kleros = value['kleros']
    plain = {name: kleros.get(name) for name in ('pgtcrAddress', 'pgtcrItemId', 'stakeAmount', 'stakeToken', 'disputeId', 'ruling')
             if type(kleros.get(name)) in (str, int, type(None))}
    return {name: (text[:256] if type(text) is str else text) for name, text in plain.items()}


def _oracles(values):
    need(type(values) in (list, tuple) and 0 < len(values) <= 8, 'KLEROS_ORACLE')
    try:
        return {erc.address(value) for value in values}
    except ValueError:
        raise ValueError('KLEROS_ORACLE') from None


def signal(entries, agent_registry, oracles, documents=None):
    """Per-agent standing Kleros decision from pinned-oracle ERC-8004 feedback; never part of a score."""
    agent_registry = erc.registry(agent_registry)
    pinned = _oracles(oracles)
    need(type(entries) is list and len(entries) <= MAX_ENTRIES, 'KLEROS_INPUT')
    supplied = _documents(documents)
    given, revoked, excluded = {}, set(), []
    for index, entry in enumerate(entries):
        try:
            need(type(entry) is dict and set(entry) == {'log'} and type(entry['log']) is dict, 'KLEROS_INPUT')
            topics = entry['log'].get('topics')
            if type(topics) is list and topics and str(topics[0]).lower() == '0x' + keccak256(REVOKED.encode()).hex():
                row = decode_revoked(entry['log'])
                need(row['client'] in pinned, 'KLEROS_NOT_ORACLE')
                revoked.add((row['agent_id'], row['client'], row['index']))
                continue
            row = erc.decode_feedback(entry['log'])
            need(row['client'] in pinned, 'KLEROS_NOT_ORACLE')
            raw, check = _document(row, supplied)
            decision = None if raw is None else _decision(row, raw, agent_registry)
            given[(row['agent_id'], row['client'], row['index'])] = {
                'feedback_index': row['index'], 'value': row['value'], 'decimals': row['decimals'], 'tag1': row['tag1'],
                'tag2': row['tag2'], 'registry_item': decision, 'document': check,
                'document_sha256': None if raw is None else hashlib.sha256(raw).hexdigest()}
        except ValueError as error:
            code = str(error)
            excluded.append({'index': index, 'status': 'EXCLUDED',
                             'reason': code if code in REMEDIATION or code in erc.REMEDIATION else 'KLEROS_INPUT'})
    agents = {}
    for (agent, client, number), row in sorted(given.items()):
        slot = agents.setdefault(str(agent), {'standing': [], 'revoked': []})
        (slot['revoked'] if (agent, client, number) in revoked else slot['standing']).append({**row, 'oracle': client})
    summary = {}
    for agent, slot in agents.items():
        latest = slot['standing'][-1] if slot['standing'] else None
        summary[agent] = {'decision': 'LISTED_BY_KLEROS_REGISTRY' if latest else 'LISTING_REVOKED',
                          'standing': deepcopy(latest), 'revoked_feedback': len(slot['revoked']),
                          'label': 'WEAK_REGISTRY_DECISION_NOT_A_RECEIPT'}
    return {'signal': 'KLEROS_REGISTRY_DECISION_VIA_ERC8004', 'agent_registry': agent_registry,
            'oracles': sorted(pinned), 'agents': summary, 'excluded': excluded,
            'revocations_seen': len(revoked), 'weight': 'WEAK_LABELLED_NOT_SCORED',
            'sybil_resistance': 'CURATED_LIST_DEPOSIT_AND_ARBITRATION_NOT_RECEIPTS', 'enters_score': False,
            'world_truth_verified': False, 'network_accessed': False, 'execution_authorized': False}


def annotate(ranking, kleros, agent_ids):
    """Report Kleros decisions beside an anchored ranking; the ranking is returned unchanged."""
    need(type(ranking) is dict and type(ranking.get('ranking')) is list and type(kleros) is dict
         and kleros.get('signal') == 'KLEROS_REGISTRY_DECISION_VIA_ERC8004' and type(agent_ids) is dict
         and len(agent_ids) <= 256, 'KLEROS_INPUT')
    beside = {}
    for row in ranking['ranking']:
        agent = agent_ids.get(row.get('provider'))
        if type(agent) is int and str(agent) in kleros['agents']:
            beside[row['provider']] = {**deepcopy(kleros['agents'][str(agent)]), 'agent_id': agent,
                                       'weight': kleros['weight']}
    return {'ranking': deepcopy(ranking), 'external_signals': beside, 'external_signals_enter_score': False,
            'mapping': 'OWNER_ASSERTED_AGENT_IDS', 'execution_authorized': False}


def describe():
    return {'status': 'EXPERIMENTAL_ADAPTER', 'schema': SCHEMA, 'events': [erc.NEW_FEEDBACK, REVOKED],
            'documents': ['data:application/json;base64 (inline)', 'ipfs:// CIDv0 single block, recomputed'],
            'pinning': 'OWNER_PINS_THE_ORACLE_CLIENT_ADDRESS', 'weight': 'WEAK_LABELLED_NOT_SCORED',
            'enters_score': False, 'limits': {'entries': MAX_ENTRIES, 'documents': MAX_DOCUMENTS, 'document_bytes': MAX_DOCUMENT},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
