"""ERC-7710 delegations (MetaMask Delegation Framework) mapped onto AAP mandates, narrowing only.

GRAFT. ERC-7710 "Smart Contract Delegation" (Draft; ethereum/ERCs ERCS/erc-7710.md,
commit be46db7f; CC0) fixes only ``redeemDelegations(bytes[],bytes32[],bytes[])``
and leaves the permission context to each delegation manager. The deployed
manager is the MetaMask Delegation Framework (github.com/MetaMask/
delegation-framework tag v1.3.0, commit bfbdf979; MIT AND Apache-2.0), which
the Smart Accounts Kit 2.0 uses: a permission context is
``abi.encode(Delegation[])`` from leaf to root; each Delegation(delegate,
delegator, authority, caveats, salt, signature) is signed under the EIP-712
domain ("DelegationManager", "1", chainId, manager); every caveat names an
enforcer contract that checks its terms when the delegation is redeemed.

``map_delegation`` reads a supplied chain, checks its links and hashes, decodes
each caveat through an owner-pinned table of enforcer addresses, and proposes
one AAP portable-trust MANDATE whose actions, resources, time window and
per-request limits are no wider than the delegation's effective scope (the
caveats of every link intersect, because the manager enforces them all) and,
when a parent AAP mandate is named, no wider than that parent
(``portable_trust`` attenuation). Caveats AAP cannot interpret are refused,
not ignored. Stateful caveats (cumulative amounts, call counts, nonces, ids)
are interpreted and listed as residual constraints that the chain keeps
enforcing; the AAP mandate never relaxes them. The proposal is unsigned: the
AAP issuer signs it, or does not. Nothing here redeems, signs or submits.
"""
from copy import deepcopy
import re

from . import evm_evidence as evm
from .anchor import keccak256
from .crypto import digest, key, need
from .weierstrass import SECP256K1

VERSION = 'urn:aap:erc7710-mapping:0.1'
LABEL = 'AAP-ERC7710-MAPPING-0.1'
FRAMEWORK = {'name': 'MetaMask Delegation Framework', 'tag': 'v1.3.0', 'commit': 'bfbdf9795a976833ed2fa000baf42fbb83958b03',
             'repository': 'https://github.com/MetaMask/delegation-framework', 'licence': 'MIT AND Apache-2.0',
             'erc': 'ERC-7710 (Draft), ethereum/ERCs ERCS/erc-7710.md, commit be46db7fef10e4413216b2f5c2b98773dffa717f'}
DELEGATION_TYPE = ('Delegation(address delegate,address delegator,bytes32 authority,Caveat[] caveats,uint256 salt)'
                   'Caveat(address enforcer,bytes terms)')
CAVEAT_TYPE = 'Caveat(address enforcer,bytes terms)'
DELEGATION_TYPEHASH = keccak256(DELEGATION_TYPE.encode('ascii'))
CAVEAT_TYPEHASH = keccak256(CAVEAT_TYPE.encode('ascii'))
DOMAIN_TYPEHASH = keccak256(b'EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)')
ROOT_AUTHORITY = b'\xff' * 32
ANY_DELEGATE = '0x0000000000000000000000000000000000000a11'
CONTEXT_TYPE = '(address,address,bytes32,(address,bytes,bytes)[],uint256,bytes)[]'
REDEEM = 'redeemDelegations(bytes[],bytes32[],bytes[])'
MAX_CHAIN = 16
MAX_CAVEATS = 32
SAFE = 2**53 - 1
TRANSFER = 'call:0xa9059cbb'
NFT_TRANSFERS = ('call:0x23b872dd', 'call:0x42842e0e', 'call:0xb88d4fde')
# documents/Deployments.md at v1.3.0: CREATE2 addresses, identical on every listed chain.
V1_3_0_MANAGER = '0xdb9b1e94b5b69df7e401ddbede43491141047db3'
V1_3_0_ENFORCERS = {
    '0xc2b0d624c1c4319760C96503BA27C347F3260f55': 'AllowedCalldata', '0x2c21fD0Cb9DC8445CB3fb0DC5E7Bb0Aca01842B5': 'AllowedMethods',
    '0x7F20f61b1f09b08D970938F6fa563634d65c4EeB': 'AllowedTargets', '0x5d9818dF0AE3f66e9c3D0c5029DAF99d1823ca6c': 'BlockNumber',
    '0x24ff2AA430D53a8CD6788018E902E098083dcCd2': 'Deployed', '0xcdF6aB796408598Cea671d79506d7D48E97a5437': 'ERC20BalanceChange',
    '0xf100b0819427117EcF76Ed94B358B1A5b5C6D2Fc': 'ERC20TransferAmount', '0x474e3Ae7E169e940607cC624Da8A15Eb120139aB': 'ERC20PeriodTransfer',
    '0x56c97aE02f233B29fa03502Ecc0457266d9be00e': 'ERC20Streaming', '0x8aFdf96eDBbe7e1eD3f5Cd89C7E084841e12A09e': 'ERC721BalanceChange',
    '0x3790e6B7233f779b09DA74C72b6e94813925b9aF': 'ERC721Transfer', '0x63c322732695cAFbbD488Fc6937A0A7B66fC001A': 'ERC1155BalanceChange',
    '0x982FD5C86BBF425d7d1451f974192d4525113DfD': 'ExactCalldataBatch', '0x99F2e9bF15ce5eC84685604836F71aB835DBBdED': 'ExactCalldata',
    '0x1e141e455d08721Dd5BCDA1BaA6Ea5633Afd5017': 'ExactExecutionBatch', '0x146713078D39eCC1F5338309c28405ccf85Abfbb': 'ExactExecution',
    '0xC8B5D93463c893401094cc70e66A206fb5987997': 'Id', '0xE1302607a3251AF54c3a6e69318d6aa07F5eB46c': 'LogicalOrWrapper',
    '0x04658B29F6b82ed55274221a06Fc97D318E25416': 'LimitedCalls', '0xFB2f1a9BD76d3701B730E5d69C3219D42D80eBb7': 'MultiTokenPeriod',
    '0xbD7B277507723490Cd50b12EaaFe87C616be6880': 'NativeBalanceChange', '0x44B8C6ae3C304213c3e298495e12497Ed3E56E41': 'ArgsEqualityCheck',
    '0x4803a326ddED6dDBc60e659e5ed12d85c7582811': 'NativeTokenPayment', '0xF71af580b9c3078fbc2BBF16FbB8EEd82b330320': 'NativeTokenTransferAmount',
    '0xD10b97905a320b13a0608f7E9cC506b56747df19': 'NativeTokenStreaming', '0x9BC0FAf4Aca5AE429F4c06aEEaC517520CB16BD9': 'NativeTokenPeriodTransfer',
    '0xDE4f2FAC4B3D87A1d9953Ca5FC09FCa7F366254f': 'Nonce', '0x7EEf9734E7092032B5C56310Eb9BbD1f4A524681': 'OwnershipTransfer',
    '0xE144b0b2618071B4E56f746313528a669c7E65c5': 'Redeemer', '0x00e0251aaA263dfE3B3541B758A82D1CBA1c3B6D': 'SpecificActionERC20TransferBatch',
    '0x1046bb45C8d673d4ea75321280DB34899413c069': 'Timestamp', '0x92Bf12322527cAA612fd31a0e810472BBB106A8F': 'ValueLte',
}
INTERPRETED = ('AllowedCalldata', 'AllowedMethods', 'AllowedTargets', 'ERC20PeriodTransfer', 'ERC20Streaming', 'ERC20TransferAmount',
               'ERC721Transfer', 'ExactCalldata', 'ExactExecution', 'Id', 'LimitedCalls', 'NativeTokenPeriodTransfer',
               'NativeTokenStreaming', 'NativeTokenTransferAmount', 'Nonce', 'OwnershipTransfer', 'Redeemer', 'Timestamp', 'ValueLte')
REFUSED = {'BlockNumber': 'block heights cannot be compared with AAP owner-clock windows offline',
           'ArgsEqualityCheck': 'depends on arguments chosen at redemption', 'NativeTokenPayment': 'requires a payment at redemption',
           'Deployed': 'deploys contracts', 'LogicalOrWrapper': 'the redeemer chooses among caveat groups',
           'ERC20BalanceChange': 'a post-condition on balances, not a scope', 'ERC721BalanceChange': 'a post-condition on balances',
           'ERC1155BalanceChange': 'a post-condition on balances', 'NativeBalanceChange': 'a post-condition on balances',
           'MultiTokenPeriod': 'the redeemer selects an entry by argument', 'SpecificActionERC20TransferBatch': 'a batch execution',
           'ExactCalldataBatch': 'a batch execution', 'ExactExecutionBatch': 'a batch execution'}
FLAGS = {'authority': 'PROPOSAL_ONLY', 'signed': False, 'redeemed': False, 'submitted': False,
         'network_accessed': False, 'execution_authorized': False}

REMEDIATION = {
    'ERC7710_CONTEXT': 'Pass the permission context as abi.encode(Delegation[]) hex, or a list of delegation objects, leaf first.',
    'ERC7710_DELEGATION': 'Each delegation needs delegate, delegator, authority (32 bytes), caveats, salt and signature.',
    'ERC7710_CHAIN': 'Each delegation must name the next one\'s hash as authority, the last ROOT_AUTHORITY; delegates must match delegators.',
    'ERC7710_OPEN_DELEGATE': 'The leaf delegate must be a named account; an AAP mandate needs one recipient.',
    'ERC7710_ENFORCERS': 'Pin the enforcer table yourself: {address: enforcer kind}; V1_3_0_ENFORCERS lists the v1.3.0 deployment.',
    'ERC7710_CAVEAT_UNKNOWN': 'A caveat names an enforcer that is not in your pinned table; it is refused, not ignored.',
    'ERC7710_CAVEAT_UNSUPPORTED': 'AAP cannot interpret this enforcer kind; map a delegation without it.',
    'ERC7710_CAVEAT_TERMS': 'The caveat terms do not have the length or layout its enforcer defines.',
    'ERC7710_REDEEMER': 'A Redeemer caveat excludes the leaf delegate, so the chain cannot be redeemed by it.',
    'ERC7710_EMPTY_SCOPE': 'The caveats intersect to nothing: no target, action or time remains.',
    'ERC7710_UNBOUNDED': 'The delegation leaves targets, methods or expiry open; pass an explicit narrower scope.',
    'ERC7710_SCOPE_ESCALATION': 'The requested scope is wider than the delegation allows.',
    'ERC7710_PRINCIPALS': 'Map the root delegator and the leaf delegate addresses to their AAP keys.',
    'ERC7710_PARENT': 'The parent mandate must be held by the root delegator\'s AAP key, for this audience.',
    'ERC7710_SIGNATURE': 'A delegation signature did not verify as the delegator\'s ECDSA signature; contract (ERC-1271) signatures need the chain.',
    'ERC7710_EXECUTION': 'Pass one ERC-7579 single-call default-mode execution: mode 0x00 00, data target(20) value(32) callData.',
}


def remediation(code):
    return REMEDIATION.get(code, evm.remediation(code))


# Decoding and hashing ----------------------------------------------------------------

def _row(value):
    """One delegation in canonical form: lowercase addresses, bytes fields, integer salt."""
    if type(value) is dict:
        need(set(value) == {'delegate', 'delegator', 'authority', 'caveats', 'salt', 'signature'}, 'ERC7710_DELEGATION')
        need(type(value['caveats']) is list and len(value['caveats']) <= MAX_CAVEATS, 'ERC7710_DELEGATION')
        caveats = []
        for item in value['caveats']:
            need(type(item) is dict and set(item) in ({'enforcer', 'terms', 'args'}, {'enforcer', 'terms'}), 'ERC7710_DELEGATION')
            caveats.append([evm.address(item['enforcer']), evm.hex_bytes(item['terms'], 65536, 'ERC7710_DELEGATION'),
                            evm.hex_bytes(item.get('args', '0x'), 65536, 'ERC7710_DELEGATION')])
        salt = value['salt']
        if type(salt) is str:
            need(re.fullmatch(r'0x[0-9a-fA-F]{1,64}|[0-9]{1,78}', salt) is not None, 'ERC7710_DELEGATION')
            salt = int(salt, 16) if salt.startswith('0x') else int(salt)
        need(type(salt) is int and 0 <= salt < 2**256, 'ERC7710_DELEGATION')
        return [evm.address(value['delegate']), evm.address(value['delegator']),
                evm.hex_word(value['authority'], 'ERC7710_DELEGATION'), caveats, salt,
                evm.hex_bytes(value['signature'], 4096, 'ERC7710_DELEGATION')]
    need(type(value) in (list, tuple) and len(value) == 6, 'ERC7710_DELEGATION')
    return list(value)


def decode_context(context):
    """A permission context (hex) or list of delegation objects, as canonical rows, leaf first."""
    if type(context) is str:
        try:
            rows = evm.abi_decode([CONTEXT_TYPE], evm.hex_bytes(context, 1_048_576, 'ERC7710_CONTEXT'))[0]
        except ValueError:
            raise ValueError('ERC7710_CONTEXT') from None
    else:
        need(type(context) is list, 'ERC7710_CONTEXT')
        rows = [_row(item) for item in context]
    need(1 <= len(rows) <= MAX_CHAIN, 'ERC7710_CONTEXT')
    return [_row(item) for item in rows]


def encode_context(rows):
    return '0x' + evm.abi_encode([CONTEXT_TYPE], [rows]).hex()


def caveat_hash(enforcer, terms):
    return keccak256(CAVEAT_TYPEHASH + evm.abi_encode(['address', 'bytes32'], [enforcer, keccak256(terms)]))


def delegation_hash(row):
    """EncoderLib.getDelegationHash: signature and caveat args are not hashed."""
    delegate, delegator, authority, caveats, salt, _ = row
    packed = keccak256(b''.join(caveat_hash(enforcer, terms) for enforcer, terms, _ in caveats))
    return keccak256(DELEGATION_TYPEHASH + evm.abi_encode(['address', 'address', 'bytes32', 'bytes32', 'uint256'],
                                                          [delegate, delegator, authority, packed, salt]))


def signing_digest(row, *, chain_id, manager):
    """EIP-712: keccak256(0x1901, hashStruct(EIP712Domain("DelegationManager", "1", chainId, manager)), the hash)."""
    need(type(chain_id) is int and 0 <= chain_id < 2**256, 'ERC7710_DELEGATION')
    domain = keccak256(DOMAIN_TYPEHASH + keccak256(b'DelegationManager') + keccak256(b'1') + chain_id.to_bytes(32, 'big')
                       + bytes(12) + bytes.fromhex(evm.address(manager)[2:]))
    return keccak256(b'\x19\x01' + domain + delegation_hash(row))


def _recover(digest_bytes, v, r, s):
    """The address that made a low-s secp256k1 signature (SEC 1 v2 section 4.1.6), from public values only."""
    curve = SECP256K1
    need(type(digest_bytes) is bytes and len(digest_bytes) == 32, 'ERC7710_SIGNATURE')
    need(v in (27, 28) and 1 <= r < curve.n and 1 <= s <= curve.n // 2, 'ERC7710_SIGNATURE')
    x, y = curve.lift_x(r)
    if y % 2 != v - 27:
        y = curve.p - y
    inverse = pow(r, -1, curve.n)
    message = int.from_bytes(digest_bytes, 'big') % curve.n
    point = curve.add(curve.mul(-message * inverse % curve.n, curve.g), curve.mul(s * inverse % curve.n, (x, y)))
    need(point is not None, 'ERC7710_SIGNATURE')
    return '0x' + keccak256(point[0].to_bytes(32, 'big') + point[1].to_bytes(32, 'big'))[-20:].hex()


def _signature_status(row, chain_id, manager):
    raw = row[5]
    if len(raw) != 65:
        return 'NOT_VERIFIED_OFFLINE; NOT_A_65_BYTE_ECDSA_SIGNATURE (ERC-1271 needs the chain)'
    r, s, v = int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:64], 'big'), raw[64]
    v = v + 27 if v in (0, 1) else v
    try:
        signer = _recover(signing_digest(row, chain_id=chain_id, manager=manager), v, r, s)
    except ValueError:
        return 'NOT_VERIFIED_OFFLINE; ECDSA_RECOVERY_FAILED (ERC-1271 or invalid)'
    return 'ECDSA_VERIFIED' if signer == row[1] else 'NOT_VERIFIED_OFFLINE; ECDSA_SIGNER_IS_NOT_THE_DELEGATOR (ERC-1271 or invalid)'


def check_chain(rows):
    """Links as DelegationManager checks them: authority hashes, delegate/delegator hand-off, root authority."""
    hashes = [delegation_hash(row) for row in rows]
    for index, row in enumerate(rows):
        if index + 1 < len(rows):
            need(row[2] == hashes[index + 1], 'ERC7710_CHAIN')
            need(rows[index + 1][0] in (row[1], ANY_DELEGATE), 'ERC7710_CHAIN')
        else:
            need(row[2] == ROOT_AUTHORITY, 'ERC7710_CHAIN')
    need(rows[0][0] != ANY_DELEGATE, 'ERC7710_OPEN_DELEGATE')
    return ['0x' + item.hex() for item in hashes]


# Caveats --------------------------------------------------------------------------------

def _words(terms, *sizes):
    need(len(terms) == sum(sizes), 'ERC7710_CAVEAT_TERMS')
    out, at = [], 0
    for size in sizes:
        out.append(terms[at:at + size]); at += size
    return out


def _list(terms, size):
    need(len(terms) > 0 and len(terms) % size == 0, 'ERC7710_CAVEAT_TERMS')
    return [terms[i:i + size] for i in range(0, len(terms), size)]


def _num(raw):
    return int.from_bytes(raw, 'big')


def _addr(raw):
    return '0x' + raw.hex()


def caveat_scope(kind, terms, net):
    """What one interpreted caveat allows: resources, actions, limits, window, redeemers and residual duties."""
    native, token = net + '/native', lambda address: net + '/erc20:' + address
    scope = {'resources': None, 'actions': None, 'limits': {}, 'after': 0, 'before': 0, 'redeemers': None, 'residual': []}
    if kind == 'AllowedTargets':
        scope['resources'] = {net + ':' + _addr(raw) for raw in _list(terms, 20)}
    elif kind == 'AllowedMethods':
        scope['actions'] = {'call:0x' + raw.hex() for raw in _list(terms, 4)}
    elif kind == 'ValueLte':
        scope['limits'] = {native: _num(_words(terms, 32)[0])}
    elif kind == 'Timestamp':
        after, before = _words(terms, 16, 16)
        scope['after'], scope['before'] = _num(after), _num(before)
    elif kind == 'Redeemer':
        scope['redeemers'] = {_addr(raw) for raw in _list(terms, 20)}
    elif kind == 'ERC20TransferAmount':
        address, amount = _words(terms, 20, 32)
        scope.update(resources={net + ':' + _addr(address)}, actions={TRANSFER}, limits={token(_addr(address)): _num(amount)})
        scope['residual'] = ['cumulative ERC-20 transfers of %s capped at %d' % (_addr(address), _num(amount))]
    elif kind == 'ERC20PeriodTransfer':
        address, amount, duration, start = _words(terms, 20, 32, 32, 32)
        scope.update(resources={net + ':' + _addr(address)}, actions={TRANSFER}, limits={token(_addr(address)): _num(amount)})
        scope['residual'] = ['%d of %s per %d-second period from %d' % (_num(amount), _addr(address), _num(duration), _num(start))]
    elif kind == 'ERC20Streaming':
        address, initial, maximum, rate, start = _words(terms, 20, 32, 32, 32, 32)
        scope.update(resources={net + ':' + _addr(address)}, actions={TRANSFER}, limits={token(_addr(address)): _num(maximum)})
        scope['residual'] = ['stream of %s: %d at start %d, %d per second, at most %d' % (
            _addr(address), _num(initial), _num(start), _num(rate), _num(maximum))]
    elif kind == 'NativeTokenTransferAmount':
        scope['limits'] = {native: _num(_words(terms, 32)[0])}
        scope['residual'] = ['cumulative native transfers capped at %d wei' % _num(terms)]
    elif kind == 'NativeTokenPeriodTransfer':
        amount, duration, start = _words(terms, 32, 32, 32)
        scope['limits'] = {native: _num(amount)}
        scope['residual'] = ['%d wei per %d-second period from %d' % (_num(amount), _num(duration), _num(start))]
    elif kind == 'NativeTokenStreaming':
        initial, maximum, rate, start = _words(terms, 32, 32, 32, 32)
        scope['limits'] = {native: _num(maximum)}
        scope['residual'] = ['native stream: %d at start %d, %d per second, at most %d' % (
            _num(initial), _num(start), _num(rate), _num(maximum))]
    elif kind in ('LimitedCalls', 'Nonce', 'Id'):
        value = _num(_words(terms, 32)[0])
        scope['residual'] = [{'LimitedCalls': 'at most %d redemptions in total', 'Nonce': 'valid only while the delegator nonce is %d',
                              'Id': 'id %d may be redeemed once'}[kind] % value]
    elif kind == 'AllowedCalldata':
        need(len(terms) >= 33, 'ERC7710_CAVEAT_TERMS')
        scope['residual'] = ['calldata at byte %d must equal 0x%s' % (_num(terms[:32]), terms[32:].hex())]
    elif kind == 'ExactCalldata':
        scope['actions'] = {'native-transfer'} if not terms else ({'call:0x' + terms[:4].hex()} if len(terms) >= 4 else set())
        scope['residual'] = ['calldata must equal 0x%s exactly' % terms.hex()]
    elif kind == 'ExactExecution':
        need(len(terms) >= 52, 'ERC7710_CAVEAT_TERMS')
        target, value, calldata = terms[:20], _num(terms[20:52]), terms[52:]
        scope.update(resources={net + ':' + _addr(target)}, limits={native: value},
                     actions={'native-transfer'} if not calldata else ({'call:0x' + calldata[:4].hex()} if len(calldata) >= 4 else set()))
        scope['residual'] = ['execution must be exactly target %s, value %d, calldata 0x%s' % (_addr(target), value, calldata.hex())]
    elif kind == 'OwnershipTransfer':
        scope.update(resources={net + ':' + _addr(_words(terms, 20)[0])}, actions={'call:0xf2fde38b'})
    elif kind == 'ERC721Transfer':
        address, token_id = _words(terms, 20, 32)
        scope.update(resources={net + ':' + _addr(address)}, actions=set(NFT_TRANSFERS))
        scope['residual'] = ['only token id %d of %s' % (_num(token_id), _addr(address))]
    else:
        raise ValueError('ERC7710_CAVEAT_UNSUPPORTED')
    return scope


def _enforcers(table):
    need(type(table) is dict and 1 <= len(table) <= 256, 'ERC7710_ENFORCERS')
    out = {}
    for address, kind in table.items():
        need(type(kind) is str and (kind in INTERPRETED or kind in REFUSED), 'ERC7710_ENFORCERS')
        out[evm.address(address)] = kind
    return out


def effective_scope(rows, *, network, enforcers):
    """Intersect every caveat of every link: the most the chain can do, as AAP reads it."""
    net = evm.network(network)
    table = _enforcers(enforcers)
    total = {'resources': None, 'actions': None, 'limits': {}, 'after': 0, 'before': 0, 'redeemers': None, 'residual': []}
    caveats = []
    for depth, row in enumerate(rows):
        for enforcer, terms, _ in row[3]:
            need(enforcer in table, 'ERC7710_CAVEAT_UNKNOWN')
            kind = table[enforcer]
            need(kind in INTERPRETED, 'ERC7710_CAVEAT_UNSUPPORTED')
            part = caveat_scope(kind, terms, net)
            caveats.append({'link': depth, 'enforcer': enforcer, 'kind': kind, 'terms': '0x' + terms.hex()})
            for name in ('resources', 'actions', 'redeemers'):
                if part[name] is not None:
                    total[name] = set(part[name]) if total[name] is None else total[name] & part[name]
            for unit, amount in part['limits'].items():
                total['limits'][unit] = min(amount, total['limits'].get(unit, amount))
            total['after'] = max(total['after'], part['after'])
            if part['before']:
                total['before'] = part['before'] if not total['before'] else min(total['before'], part['before'])
            total['residual'] += part['residual']
    if total['redeemers'] is not None:
        need(rows[0][0] in total['redeemers'], 'ERC7710_REDEEMER')
    for name in ('resources', 'actions'):
        need(total[name] is None or total[name], 'ERC7710_EMPTY_SCOPE')
    need(not total['before'] or total['before'] > total['after'] + 1, 'ERC7710_EMPTY_SCOPE')
    return total, caveats


def _requested(total, scope):
    """The scope AAP will grant: explicit and inside the delegation's effective scope."""
    narrowed = []
    if scope is None:
        need(total['resources'] is not None and total['actions'] is not None and total['before'], 'ERC7710_UNBOUNDED')
        limits = {}
        for unit, amount in sorted(total['limits'].items()):
            limits[unit] = min(amount, SAFE)
            if amount > SAFE:
                narrowed.append('%s per-request limit capped at 2^53-1 from %d' % (unit, amount))
        scope = {'actions': sorted(total['actions']), 'resources': sorted(total['resources']), 'per_request_limits': limits,
                 'not_before': total['after'] + 1 if total['after'] else 0, 'expires': total['before']}
    need(type(scope) is dict and set(scope) == {'actions', 'resources', 'per_request_limits', 'not_before', 'expires'}, 'ERC7710_SCOPE_ESCALATION')
    for name in ('actions', 'resources'):
        need(type(scope[name]) is list and scope[name] and (total[name] is None or set(scope[name]) <= total[name]), 'ERC7710_SCOPE_ESCALATION')
    limits = scope['per_request_limits']
    need(type(limits) is dict and set(total['limits']) <= set(limits), 'ERC7710_SCOPE_ESCALATION')
    for unit, amount in limits.items():
        need(type(amount) is int and 0 <= amount <= min(total['limits'].get(unit, SAFE), SAFE), 'ERC7710_SCOPE_ESCALATION')
    need(type(scope['not_before']) is int and type(scope['expires']) is int and scope['not_before'] < scope['expires'], 'ERC7710_SCOPE_ESCALATION')
    need(scope['not_before'] > total['after'] or total['after'] == 0, 'ERC7710_SCOPE_ESCALATION')
    need(not total['before'] or scope['expires'] <= total['before'], 'ERC7710_SCOPE_ESCALATION')
    return deepcopy(scope), narrowed


# The mapping ------------------------------------------------------------------------------------

def audience_for(network, manager):
    return evm.network(network) + ':' + evm.address(manager)


def map_delegation(context, *, network, manager, enforcers, principals, nonce, scope=None, parent=None,
                   expected_parent_id=None, may_delegate=False, require_signatures=False):
    """Propose the AAP mandate a supplied ERC-7710 delegation chain supports, never wider than it."""
    from . import portable_trust
    net, manager = evm.network(network), evm.address(manager)
    rows = decode_context(context)
    hashes = check_chain(rows)
    statuses = [_signature_status(row, evm.chain_id(net), manager) for row in rows]
    need(not require_signatures or all(item == 'ECDSA_VERIFIED' for item in statuses), 'ERC7710_SIGNATURE')
    total, caveats = effective_scope(rows, network=net, enforcers=enforcers)
    granted, narrowed = _requested(total, scope)
    need(type(principals) is dict and len(principals) <= 64, 'ERC7710_PRINCIPALS')
    accounts = {evm.address(address): value for address, value in principals.items()}
    root, leaf = rows[-1][1], rows[0][0]
    need(root in accounts and leaf in accounts, 'ERC7710_PRINCIPALS')
    key(nonce)
    audience = audience_for(net, manager)
    limits = dict(sorted(granted['per_request_limits'].items()))
    # Without a parent the root delegator's AAP key issues; with one, portable_trust.delegate applies
    # AAP's attenuation rule (TRUST_SCOPE_ESCALATION, TRUST_TIME_ESCALATION, TRUST_LIMIT_ESCALATION).
    if parent is None:
        prepared = portable_trust.mandate(accounts[root], accounts[leaf], sorted(granted['actions']), sorted(granted['resources']),
                                          audience, limits, granted['not_before'], granted['expires'], nonce, may_delegate)
    else:
        need(type(parent) is dict and type(parent.get('body')) is dict and parent['body'].get('recipient') == accounts[root]
             and parent['body'].get('audience') == audience, 'ERC7710_PARENT')
        prepared = portable_trust.delegate(parent, expected_parent_id, accounts[leaf], sorted(granted['actions']),
                                           sorted(granted['resources']), limits, granted['not_before'], granted['expires'],
                                           nonce, may_delegate)
    mapping = {'version': VERSION, 'network': net, 'manager': manager, 'chain': hashes, 'root_delegator': root,
               'leaf_delegate': leaf, 'signatures': statuses, 'caveats': caveats,
               'effective': {'resources': None if total['resources'] is None else sorted(total['resources']),
                             'actions': None if total['actions'] is None else sorted(total['actions']),
                             'limits': {unit: str(amount) for unit, amount in sorted(total['limits'].items())},
                             'after': total['after'], 'before': total['before']},
               'granted': granted, 'narrowed': narrowed, 'residual': sorted(set(total['residual'])),
               'mandate': prepared['id'], 'parent': expected_parent_id if parent is not None else None}
    return {'mapping': mapping, 'id': digest(LABEL, mapping), 'mandate': prepared,
            'redeem': {'function': REDEEM, 'manager': manager, 'permission_context': encode_context(rows)},
            'notes': ['The AAP issuer signs the mandate or not; the delegation signature is not AAP authority.',
                      'Residual constraints are enforced by their enforcers on chain at redemption; AAP never relaxes them.',
                      'Revocation (disableDelegation) and enforcer state are on chain and unknown offline.'], **FLAGS}


def execution_request(execution, *, network, mode='0x' + '00' * 32):
    """The AAP action, resource and usage of one ERC-7579 single-call execution, for check_capability."""
    raw_mode = evm.hex_word(mode, 'ERC7710_EXECUTION')
    need(raw_mode[0] == 0 and raw_mode[1] == 0, 'ERC7710_EXECUTION')
    data = evm.hex_bytes(execution, 1_048_576, 'ERC7710_EXECUTION')
    need(len(data) >= 52, 'ERC7710_EXECUTION')
    net = evm.network(network)
    target, value, calldata = _addr(data[:20]), _num(data[20:52]), data[52:]
    need(not calldata or len(calldata) >= 4, 'ERC7710_EXECUTION')
    action = 'native-transfer' if not calldata else 'call:0x' + calldata[:4].hex()
    usage = {net + '/native': value}
    if action == TRANSFER and len(calldata) == 68:
        usage[net + '/erc20:' + target] = _num(calldata[36:68])
    return {'action': action, 'resource': net + ':' + target, 'usage': usage, 'value_wei': str(value),
            'note': 'Pass action, resource and the usage entries your mandate limits to portable_trust.check_capability.'}


def describe():
    return {'version': VERSION, 'decision': 'GRAFT', 'framework': deepcopy(FRAMEWORK),
            'typehashes': {'delegation': '0x' + DELEGATION_TYPEHASH.hex(), 'caveat': '0x' + CAVEAT_TYPEHASH.hex()},
            'domain': {'name': 'DelegationManager', 'version': '1', 'chainId': 'from the network', 'verifyingContract': 'the manager'},
            'context': CONTEXT_TYPE + ' leaf first', 'redeem': REDEEM, 'v1_3_0_manager': V1_3_0_MANAGER,
            'interpreted': list(INTERPRETED), 'refused': deepcopy(REFUSED),
            'rule': 'The proposed AAP mandate is never wider than the delegation or its AAP parent; unknown caveats are refused',
            'remediation': deepcopy(REMEDIATION), **FLAGS}
