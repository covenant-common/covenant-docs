"""Bounded, read-only JSON pointer summaries; no interpretation or assent."""
import hashlib
from covenant_language.agentic import canonical

def paths(before,after,limit=128):
    changes=[];truncated=False
    def add(path,a,b,missing_a=False,missing_b=False):
        nonlocal truncated
        if len(changes)>=limit:truncated=True;return
        changes.append({'path':path,'change':'ADDED' if missing_a else 'REMOVED' if missing_b else 'REPLACED',
            'before_type':'ABSENT' if missing_a else type(a).__name__,'after_type':'ABSENT' if missing_b else type(b).__name__,
            'before_sha256':None if missing_a else hashlib.sha256(canonical(a)).hexdigest(),
            'after_sha256':None if missing_b else hashlib.sha256(canonical(b)).hexdigest()})
    def child(path,k):return path+'/'+str(k).replace('~','~0').replace('/','~1')
    def visit(a,b,path='',depth=0):
        nonlocal truncated
        if canonical(a)==canonical(b):return
        if len(changes)>=limit:truncated=True;return
        if depth>=32 or type(a) is not type(b):add(path,a,b);return
        if type(a) is dict:
            for k in sorted(set(a)|set(b)):
                if k not in a:add(child(path,k),None,b[k],missing_a=True)
                elif k not in b:add(child(path,k),a[k],None,missing_b=True)
                else:visit(a[k],b[k],child(path,k),depth+1)
        elif type(a) is list:
            for i in range(max(len(a),len(b))):
                if i>=len(a):add(child(path,i),None,b[i],missing_a=True)
                elif i>=len(b):add(child(path,i),a[i],None,missing_b=True)
                else:visit(a[i],b[i],child(path,i),depth+1)
        else:add(path,a,b)
    visit(before,after)
    return {'changed_paths':changes,'changed_paths_truncated':truncated,'path_basis':'EXACT_TYPED_JSON_STRUCTURE; VALUES_HASHED; NO_INTERPRETATION_OR_ASSENT'}
