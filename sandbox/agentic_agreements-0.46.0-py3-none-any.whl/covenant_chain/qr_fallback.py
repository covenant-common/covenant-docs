"""QR Code byte-mode encoder and decoder. No third-party package.

Error correction is level L. Mask 0 is the one this encoder writes. The PNG
is grayscale with a four-module quiet zone. ``render_qr`` in ``bootstrap``
uses the ``qrcode`` package when that extra is installed and this module
otherwise.
"""
from __future__ import annotations

import struct
import zlib

from .crypto import need

SCALE = 4
BORDER = 4
# ECC L: (ecc per block, group1 blocks, group1 data, group2 blocks, group2 data).
_L = {
    1: (7, 1, 19, 0, 0), 2: (10, 1, 34, 0, 0), 3: (15, 1, 55, 0, 0), 4: (20, 1, 80, 0, 0),
    5: (26, 1, 108, 0, 0), 6: (18, 2, 68, 0, 0), 7: (20, 2, 78, 0, 0), 8: (24, 2, 97, 0, 0),
    9: (30, 2, 116, 0, 0), 10: (18, 2, 68, 2, 69), 11: (20, 4, 81, 0, 0), 12: (24, 2, 92, 2, 93),
    13: (26, 4, 107, 0, 0), 14: (30, 3, 115, 1, 116), 15: (22, 5, 87, 1, 88), 16: (24, 5, 98, 1, 99),
    17: (28, 1, 107, 5, 108), 18: (30, 5, 120, 1, 121), 19: (28, 3, 113, 4, 114), 20: (28, 3, 107, 5, 108),
    21: (28, 4, 116, 4, 117), 22: (28, 2, 111, 7, 112), 23: (30, 4, 121, 5, 122), 24: (30, 6, 117, 4, 118),
    25: (26, 8, 106, 4, 107), 26: (28, 10, 114, 2, 115), 27: (30, 8, 122, 4, 123), 28: (30, 3, 117, 10, 118),
    29: (30, 7, 116, 7, 117), 30: (30, 5, 115, 10, 116), 31: (30, 13, 115, 3, 116), 32: (30, 17, 115, 0, 0),
    33: (30, 17, 115, 1, 116), 34: (30, 13, 115, 6, 116), 35: (30, 12, 121, 7, 122), 36: (30, 6, 121, 14, 122),
    37: (30, 17, 122, 4, 123), 38: (30, 4, 122, 18, 123), 39: (30, 20, 117, 4, 118), 40: (30, 19, 118, 6, 119),
}
_ALIGN = [
    [], [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50],
    [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78],
    [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102],
    [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122],
    [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138],
    [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154],
    [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170],
]
_REMAINDER = [0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0]

_EXP = [0] * 512
_LOG = [0] * 256
_value = 1
for _i in range(255):
    _EXP[_i] = _value
    _LOG[_value] = _i
    _value <<= 1
    if _value & 0x100:
        _value ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _mul(left, right):
    if left == 0 or right == 0:
        return 0
    return _EXP[_LOG[left] + _LOG[right]]


def _generator(length):
    poly = [1]
    for index in range(length):
        updated = [0] * (len(poly) + 1)
        for coef_index, coef in enumerate(poly):
            updated[coef_index] ^= coef
            updated[coef_index + 1] ^= _mul(coef, _EXP[index])
        poly = updated
    return poly


def _remainder(data, ecc_len):
    generator = _generator(ecc_len)
    block = list(data) + [0] * ecc_len
    for index in range(len(data)):
        coef = block[index]
        if coef == 0:
            continue
        for step, factor in enumerate(generator):
            block[index + step] ^= _mul(factor, coef)
    return block[-ecc_len:]


def _capacity(version):
    _ecc, g1n, g1d, g2n, g2d = _L[version]
    return g1n * g1d + g2n * g2d - (3 if version >= 10 else 2)


def _version_for(size):
    for version in range(1, 41):
        if size <= _capacity(version):
            return version
    raise ValueError('QR_PAYLOAD')


def _data_codewords(payload, version):
    count_bits = 16 if version >= 10 else 8
    bits = [(0x4, 4), (len(payload), count_bits)]
    raw = []
    for value, width in bits:
        for shift in range(width - 1, -1, -1):
            raw.append((value >> shift) & 1)
    for byte in payload:
        for shift in range(7, -1, -1):
            raw.append((byte >> shift) & 1)
    capacity = _L[version]
    total = capacity[1] * capacity[2] + capacity[3] * capacity[4]
    target = total * 8
    terminator = min(4, target - len(raw))
    raw.extend([0] * terminator)
    while len(raw) % 8:
        raw.append(0)
    bytes_out = [int(''.join(str(bit) for bit in raw[index:index + 8]), 2) for index in range(0, len(raw), 8)]
    pad = 0xEC
    while len(bytes_out) < total:
        bytes_out.append(pad)
        pad = 0x11 if pad == 0xEC else 0xEC
    return bytes_out


def _interleave(data, version):
    ecc, g1n, g1d, g2n, g2d = _L[version]
    blocks = []
    cursor = 0
    for count, width in ((g1n, g1d), (g2n, g2d)):
        for _block in range(count):
            chunk = data[cursor:cursor + width]
            cursor += width
            blocks.append((chunk, _remainder(chunk, ecc)))
    out = []
    longest = max(g1d, g2d)
    for index in range(longest):
        for chunk, _ecc_bytes in blocks:
            if index < len(chunk):
                out.append(chunk[index])
    for index in range(ecc):
        for _chunk, ecc_bytes in blocks:
            out.append(ecc_bytes[index])
    return out


def _modules(version):
    size = 17 + 4 * version
    grid = [[False] * size for _row in range(size)]
    reserved = [[False] * size for _row in range(size)]

    def mark(row, col, dark):
        grid[row][col] = dark
        reserved[row][col] = True

    def finder(row, col):
        for y in range(-1, 8):
            for x in range(-1, 8):
                rr, cc = row + y, col + x
                if 0 <= rr < size and 0 <= cc < size:
                    inside = 0 <= y <= 6 and 0 <= x <= 6
                    dark = inside and (y in (0, 6) or x in (0, 6) or 2 <= y <= 4 and 2 <= x <= 4)
                    mark(rr, cc, dark)

    finder(0, 0)
    finder(0, size - 7)
    finder(size - 7, 0)
    for index in range(8, size - 8):
        mark(6, index, index % 2 == 0)
        mark(index, 6, index % 2 == 0)
    positions = _ALIGN[version]
    for row in positions:
        for col in positions:
            if reserved[row][col]:
                continue
            for y in range(-2, 3):
                for x in range(-2, 3):
                    mark(row + y, col + x, max(abs(x), abs(y)) != 1)
    mark(4 * version + 9, 8, True)
    for index in range(9):
        reserved[8][index] = reserved[index][8] = True
    for index in range(8):
        reserved[8][size - 1 - index] = reserved[size - 1 - index][8] = True
    reserved[8][8] = True
    if version >= 7:
        for index in range(6):
            for bit in range(3):
                reserved[index][size - 11 + bit] = True
                reserved[size - 11 + bit][index] = True
    return grid, reserved


def _format_bits(mask):
    data = (1 << 3) | mask
    remainder = data << 10
    for index in range(4, -1, -1):
        if remainder & (1 << (index + 10)):
            remainder ^= 0x537 << index
    return ((data << 10) | (remainder & 0x3FF)) ^ 0x5412


def _version_bits(version):
    remainder = version << 12
    for index in range(5, -1, -1):
        if remainder & (1 << (index + 12)):
            remainder ^= 0x1F25 << index
    return (version << 12) | (remainder & 0xFFF)


def _paint_meta(grid, version, mask):
    size = len(grid)
    bits = _format_bits(mask)
    order_a = [(8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 8), (7, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (0, 8)]
    order_b = [(size - 1, 8), (size - 2, 8), (size - 3, 8), (size - 4, 8), (size - 5, 8), (size - 6, 8), (size - 7, 8),
               (8, size - 8), (8, size - 7), (8, size - 6), (8, size - 5), (8, size - 4), (8, size - 3), (8, size - 2), (8, size - 1)]
    for index, ((r1, c1), (r2, c2)) in enumerate(zip(order_a, order_b)):
        dark = bool((bits >> index) & 1)
        grid[r1][c1] = dark
        grid[r2][c2] = dark
    if version >= 7:
        vbits = _version_bits(version)
        for index in range(18):
            dark = bool((vbits >> index) & 1)
            row, col = divmod(index, 3)
            grid[row][size - 11 + (index % 3)] = dark
            grid[size - 11 + (index % 3)][row] = dark


def _walk(size):
    positions = []
    col = size - 1
    upward = True
    while col > 0:
        if col == 6:
            col -= 1
        for step in range(size):
            row = (size - 1 - step) if upward else step
            for offset in (0, -1):
                positions.append((row, col + offset))
        upward = not upward
        col -= 2
    return positions


def _matrix(payload):
    version = _version_for(len(payload))
    codewords = _interleave(_data_codewords(payload, version), version)
    bits = []
    for byte in codewords:
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    bits.extend([0] * _REMAINDER[version])
    grid, reserved = _modules(version)
    cursor = 0
    for row, col in _walk(len(grid)):
        if reserved[row][col]:
            continue
        dark = bits[cursor] if cursor < len(bits) else 0
        cursor += 1
        if (row + col) % 2 == 0:
            dark ^= 1
        grid[row][col] = bool(dark)
    _paint_meta(grid, version, 0)
    return grid


def _png(grid):
    size = len(grid) + BORDER * 2
    width = size * SCALE
    rows = []
    for y in range(width):
        module_y = y // SCALE - BORDER
        row = bytearray([0])
        for x in range(width):
            module_x = x // SCALE - BORDER
            dark = 0 <= module_y < len(grid) and 0 <= module_x < len(grid) and grid[module_y][module_x]
            row.append(0 if dark else 255)
        rows.append(bytes(row))
    raw = b''.join(rows)
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)
    ihdr = struct.pack('>IIBBBBB', width, width, 8, 0, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')


def encode_png(payload):
    need(type(payload) is bytes and 1 <= len(payload) <= 2953, 'QR_PAYLOAD')
    return _png(_matrix(payload))


def _read_png(blob):
    need(blob.startswith(b'\x89PNG\r\n\x1a\n'), 'QR_PNG')
    offset = 8
    width = height = None
    compressed = b''
    while offset < len(blob):
        length = struct.unpack('>I', blob[offset:offset + 4])[0]
        tag = blob[offset + 4:offset + 8]
        data = blob[offset + 8:offset + 8 + length]
        offset += 12 + length
        if tag == b'IHDR':
            width, height, depth, color = struct.unpack('>IIBB', data[:10])
            need(width == height and depth == 8 and color == 0, 'QR_PNG')
        elif tag == b'IDAT':
            compressed += data
        elif tag == b'IEND':
            break
    raw = zlib.decompress(compressed)
    stride = width + 1
    pixels = []
    for y in range(height):
        row = raw[y * stride:(y + 1) * stride]
        need(row[0] == 0, 'QR_PNG')
        pixels.append(row[1:])
    modules = (width // SCALE) - 2 * BORDER
    grid = []
    for y in range(modules):
        grid.append([pixels[(y + BORDER) * SCALE + SCALE // 2][(x + BORDER) * SCALE + SCALE // 2] == 0 for x in range(modules)])
    return grid


def _decode_matrix(grid):
    size = len(grid)
    need((size - 17) % 4 == 0, 'QR_MATRIX')
    version = (size - 17) // 4
    reserved = _modules(version)[1]
    bits = []
    for row, col in _walk(size):
        if reserved[row][col]:
            continue
        dark = grid[row][col]
        if (row + col) % 2 == 0:
            dark = not dark
        bits.append(1 if dark else 0)
    if _REMAINDER[version]:
        bits = bits[:-_REMAINDER[version]]
    data = [int(''.join(str(bit) for bit in bits[index:index + 8]), 2) for index in range(0, len(bits) - len(bits) % 8, 8)]
    ecc, g1n, g1d, g2n, g2d = _L[version]
    total = g1n * g1d + g2n * g2d
    # Undo interleave enough to read the byte-mode header from the data codewords.
    blocks = [([] ) for _i in range(g1n + g2n)]
    widths = [g1d] * g1n + [g2d] * g2n
    cursor = 0
    longest = max(widths)
    for index in range(longest):
        for block, width in zip(blocks, widths):
            if index < width:
                block.append(data[cursor])
                cursor += 1
    plain = []
    for block in blocks:
        plain.extend(block)
    bitstring = ''.join(f'{byte:08b}' for byte in plain)
    need(bitstring[:4] == '0100', 'QR_MODE')
    count_bits = 16 if version >= 10 else 8
    length = int(bitstring[4:4 + count_bits], 2)
    start = 4 + count_bits
    return bytes(int(bitstring[start + index * 8:start + (index + 1) * 8], 2) for index in range(length))


def decode_png(blob):
    return _decode_matrix(_read_png(blob))
