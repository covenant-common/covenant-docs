"""Proof-of-kept-promises score. Derived from honoured covenants; it does not mint.

A covenant counts only after it has been executed on a SUPPORTED decision, which
the ledger allows only once the challenge window has closed. Overturned and
refuted covenants contribute nothing. Wash clusters earn nothing when configured.
Points decay. Token entitlements are a cap on later funded claims, not an issue.
"""
from .crypto import integer, need
from .discovery_rank import SCALE, pagerank


def honoured(agreement):
    if type(agreement) is not dict or agreement.get('state') != 'AUTHORIZED' or agreement.get('held'):
        return False
    decision = agreement.get('decision') or {}
    if decision.get('result') != 'SUPPORTED':
        return False
    effect_id = agreement.get('effect_id')
    return effect_id is None or type(effect_id) is str


def broken(agreement):
    if type(agreement) is not dict:
        return False
    if agreement.get('state') == 'RELEASED':
        return True
    return (agreement.get('decision') or {}).get('result') == 'REFUTED'


def _items(table):
    if not table:
        return []
    return sorted(table.items())


def honoured_rows(state, height=None):
    """One row per kept covenant. Prefer the scale meter's height and integrator note."""
    meter_events = {}
    policy = state.get('economic_policy') if hasattr(state, 'get') else None
    if policy is not None and 'scale' in policy:
        for event in policy['scale'].get('events', []):
            meter_events[event['agreement']] = event
    rows = []
    for cid, agreement in _items(state.get('agreements')):
        if not honoured(agreement):
            continue
        terms = agreement['terms']
        event = meter_events.get(cid)
        row_height = event['height'] if event else agreement.get('challenge_end') or 0
        if type(row_height) is not int:
            row_height = 0
        rows.append({'agreement': cid, 'principal': terms['principal'], 'agent': terms['agent'],
                     'counterparty': terms['counterparty'], 'quantity': terms['quantity'],
                     'height': row_height, 'integrator': (event or {}).get('integrator') or ''})
    return rows


def usage_snapshot(rows, height, blocks_per_day):
    integer(height)
    integer(blocks_per_day, True)
    day = [row for row in rows if height - row['height'] < blocks_per_day]
    month = [row for row in rows if height - row['height'] < 30 * blocks_per_day]
    parties = set()
    for row in month:
        parties.add(row['counterparty'])
        parties.add(row['principal'])
    return {'settled_per_day': len(day), 'distinct_counterparties': len(parties), 'settled_in_month': len(month)}


def log_points(quantity, log_scale):
    integer(quantity)
    integer(log_scale, True)
    if quantity <= 0:
        return 0
    # floor(log2(1+quantity)) * scale. Linear volume cannot outrun a log.
    return ((quantity + 1).bit_length() - 1) * log_scale


def decay_multiplier(age, season_blocks, decay_after, decay_bps):
    integer(age)
    integer(season_blocks, True)
    integer(decay_after)
    seasons = age // season_blocks
    if seasons <= decay_after:
        return 10000
    multiplier = 10000
    for _ in range(min(seasons - decay_after, 64)):
        multiplier = multiplier * decay_bps // 10000
    return multiplier


def _wash_accounts(rows):
    nodes = sorted({party for row in rows for party in (row['principal'], row['counterparty'])})
    parent = {node: node for node in nodes}

    def find(node):
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    for row in rows:
        left, right = find(row['principal']), find(row['counterparty'])
        if left != right:
            parent[right] = left
    groups = {}
    for node in nodes:
        groups.setdefault(find(node), set()).add(node)
    wash = set()
    for members in groups.values():
        if len(members) <= 2:
            wash |= members
    return wash


def _reputation(rows, bonds, damping_bps):
    nodes = sorted({party for row in rows for party in (row['principal'], row['agent'], row['counterparty']) if party})
    if not nodes or len(nodes) > 256:
        return {node: SCALE for node in nodes}, 'EQUAL_WEIGHT_ABOVE_PAGERANK_CAP' if len(nodes) > 256 else 'NO_GRAPH'
    seeded = {node: bonds[node] for node in nodes if bonds.get(node, 0) > 0}
    seeds = seeded or {node: 1 for node in nodes}
    edges = [[row['principal'], row['counterparty']] for row in rows if row['principal'] != row['counterparty']]
    # Unique edges, bounded by the pagerank edge cap.
    unique = []
    seen = set()
    for edge in edges:
        mark = tuple(edge)
        if mark not in seen:
            seen.add(mark)
            unique.append(edge)
    try:
        return pagerank(nodes, unique[:4096], seeds, damping_bps=damping_bps), 'PERSONALIZED_PAGERANK_FROM_BONDS_OR_EQUAL_SEEDS'
    except ValueError:
        return {node: SCALE for node in nodes}, 'EQUAL_WEIGHT_PAGERANK_REFUSED'


def score_rows(rows, height, points_cfg, bonds, integrator_cfg, stake_power=None):
    """Points by earner. The earner is the agent, or the principal when they are their own agent."""
    integer(height)
    bonds = bonds or {}
    wash = _wash_accounts(rows) if points_cfg['wash_earns_zero'] else set()
    reputation, reputation_method = _reputation(rows, bonds, points_cfg['pagerank_damping_bps'])
    ceiling = max(reputation.values()) if reputation else 1
    distinct = {}
    for row in rows:
        earner = row['agent'] or row['principal']
        distinct.setdefault(earner, set()).add(row['counterparty'])
    totals = {}
    detail = []
    referred_owners = {}
    for row in rows:
        earner = row['agent'] or row['principal']
        pair = {row['principal'], row['counterparty']}
        if pair and pair <= wash:
            detail.append({**row, 'points': 0, 'reason': 'WASH_CLUSTER'})
            continue
        base = log_points(row['quantity'], points_cfg['log_scale'])
        diversity = min(len(distinct.get(earner, ())), points_cfg['diversity_cap'])
        if base <= 0 or diversity <= 0:
            continue
        decay = decay_multiplier(max(0, height - row['height']), points_cfg['season_blocks'],
                                 points_cfg['decay_after_seasons'], points_cfg['decay_bps'])
        points = base * diversity * decay // 10000
        # Reputation moves the score within half to full, so a low-mass account earns less
        # without a rounding cliff that deletes a real kept promise.
        mass = reputation.get(earner, 0)
        points = points * (5000 + mass * 5000 // ceiling) // 10000
        if points <= 0:
            continue
        totals[earner] = totals.get(earner, 0) + points
        detail.append({**row, 'points': points, 'earner': earner, 'reason': 'HONOURED'})
        integrator = row.get('integrator') or ''
        if integrator and integrator != earner:
            owners = referred_owners.setdefault(integrator, set())
            if row['principal'] not in owners and len(owners) < integrator_cfg['per_owner_cap']:
                owners.add(row['principal'])
                bonus = points // 4
                if bonus:
                    totals[integrator] = totals.get(integrator, 0) + bonus
    scored = {}
    for account, total in totals.items():
        bonded = bonds.get(account, 0) >= points_cfg['min_bond'] and (points_cfg['min_bond'] > 0 or bonds.get(account, 0) > 0)
        # min_bond == 0: a positive bond still takes the loyalty multiple; eligibility is separate.
        if points_cfg['min_bond'] == 0:
            bonded = bonds.get(account, 0) > 0
        adjusted = total * points_cfg['loyalty_bps'] // 10000 if bonded else total
        boost = 0
        if stake_power and stake_power.get(account, 0) > 0:
            # Longer locks add reputation weight. The boost is capped at the loyalty multiple.
            boost = min(points_cfg['loyalty_bps'] - 10000, stake_power[account] // 1000)
            if boost > 0:
                adjusted = adjusted * (10000 + boost) // 10000
        scored[account] = {'points': adjusted, 'raw_points': total, 'bonded': bonds.get(account, 0) > 0,
                           'loyalty_applied': bonded, 'stake_boost_bps': boost}
    return {'accounts': scored, 'rows': detail, 'wash_accounts': sorted(wash),
            'reputation_method': reputation_method, 'execution_authorized': False, 'token_issuance': 0}


def tokens_for(points, bond, points_cfg):
    integer(points)
    integer(bond)
    if bond < points_cfg['min_bond']:
        return 0
    return points * points_cfg['tokens_per_point_num'] // points_cfg['tokens_per_point_den']


def epoch_budget(height, points_cfg):
    """Bitcoin-style halving every `halving_blocks` (illustrative: 4 years). No percentage decay."""
    from .emissions import halving_budget
    integer(height)
    epoch = height // points_cfg['epoch_blocks']
    budget = halving_budget(height, points_cfg['epoch_emission'], points_cfg['halving_blocks'])
    return {'epoch': epoch, 'budget': budget, 'halvings': height // points_cfg['halving_blocks'],
            'schedule': 'BITCOIN_HALVING_4Y', 'fixed_apy': False, 'token_issuance': 0, 'decayed': True}


def honour_bps(state, account):
    good = bad = 0
    for _, agreement in _items(state.get('agreements')):
        terms = agreement.get('terms') or {}
        if account not in {terms.get('principal'), terms.get('agent'), terms.get('counterparty')}:
            continue
        if honoured(agreement):
            good += 1
        elif broken(agreement):
            bad += 1
    if good + bad == 0:
        return 0
    return good * 10000 // (good + bad)


def distinct_counterparties(rows, account, height, retention_blocks):
    found = set()
    for row in rows:
        if account not in {row['principal'], row['agent']}:
            continue
        if height - row['height'] < retention_blocks:
            continue
        if row['counterparty'] != account:
            found.add(row['counterparty'])
    return found
