"""Attribute statements over /0.3 hidden credentials, so an agent can enter a regulated deal unnamed.

TAKE-AND-IMPROVE from Concordium's Web3 ID statements (RevealAttribute,
AttributeInRange, AttributeInSet, AttributeNotInSet): a verifier asks typed
questions and the holder answers without naming its principal. AAP keeps the
credential scheme it already has, IETF SD-JWT (RFC 9901) with an SD-JWT VC type
and a key binding JWT, signed with EdDSA, and answers each statement by
disclosing an issuer-signed claim that implies it:

* AGE_AT_LEAST n: the smallest disclosed age_equal_or_over_m with m >= n
  (ISO/IEC 18013-5:2021 clause 7.2.5 age_over_NN; the EUDI PID age_equal_or_over).
* JURISDICTION_IN S: an issuer-named set whose members all lie in S, the
  largest such set first; JURISDICTION_NOT_IN S: a set disjoint from S. The exact
  ISO 3166 code is disclosed only when the holder allows it (reveal_exact).
* LICENSED a, TRUE_CLAIM c, MANDATE_AT_MOST, REVEAL: one claim each.

What this is, precisely. It is sound: every claim is a salted SHA-256 commitment
the pinned issuer signed, and the presenter proves possession of the one-time
holder key over the verifier's nonce and audience. It is not zero knowledge:
the verifier learns the disclosed claim exactly (age 21 or more when 19 was
asked; the members of the disclosed set), the issuer, the scope, the expiry and
the holder key. Only statements the issuer anticipated can be answered: a
threshold between two issued steps falls back to the next step up, a set that
contains no issued set fails unless the exact code may be revealed, and upper
bounds (AttributeInRange with an upper end) are not supported. Claims are true
when issued; revocation is expiry only; the issuer can link presentations it
sees to the account. Zero-knowledge range and set proofs over committed
attributes (as Concordium does with Bulletproofs) are not implemented here.
"""
from copy import deepcopy
import datetime
import re

from .crypto import canonical, digest, integer, key, need, verification_key
from . import hidden_credentials as hc

VERSION = 'covenant-attribute-policy/0.1'
LABEL = 'COVENANT-ATTRIBUTE-POLICY-0.1'
STATEMENTS = ('AGE_AT_LEAST', 'JURISDICTION_IN', 'JURISDICTION_NOT_IN', 'LICENSED', 'TRUE_CLAIM', 'MANDATE_AT_MOST',
              'REVEAL')
CONCORDIUM = {'AGE_AT_LEAST': 'AttributeInRange (lower bound only)', 'JURISDICTION_IN': 'AttributeInSet',
              'JURISDICTION_NOT_IN': 'AttributeNotInSet', 'REVEAL': 'RevealAttribute'}
AGE_LADDER = (12, 14, 16, 18, 21, 25, 65)
DATE = re.compile(r'(\d{4})-(\d{2})-(\d{2})\Z')
MAX_STATEMENTS = 8

REMEDIATION = {
    'ATTRIBUTE_STATEMENT': 'Use statements from describe(): a type and its exact fields.',
    'ATTRIBUTE_STATEMENTS': 'Ask 1 to 8 distinct statements.',
    'ATTRIBUTE_UPPER_BOUND': 'Upper bounds are not supported; ask AGE_AT_LEAST with a lower bound only.',
    'ATTRIBUTE_POLICY': 'Use the exact attribute policy fields from describe().',
    'ATTRIBUTE_POLICY_VERSION': 'Use version covenant-attribute-policy/0.1.',
    'ATTRIBUTE_UNSATISFIED': 'The credential holds no issuer-signed claim that implies this statement.',
    'ATTRIBUTE_NOT_PROVEN': 'The presentation discloses no claim that implies a requested statement.',
    'ATTRIBUTE_ESCROW_REQUIRED': 'This verifier requires an accountable credential: present it with its escrow record.',
    'ATTRIBUTE_DATE': 'Use ISO 8601 calendar dates YYYY-MM-DD.',
    'ATTRIBUTE_LADDER': 'Use 1 to 8 increasing ages from 1 to 150.',
    'ATTRIBUTE_CREDENTIAL': 'Supply the credential the issuer returned: holder_key, sd_jwt and disclosures.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Inspect hidden_credentials and the module description for the exact shape.')


def _codes(value):
    try:
        return hc._members(value)
    except ValueError:
        raise ValueError('ATTRIBUTE_STATEMENT') from None


def statement(value):
    """One validated statement."""
    need(type(value) is dict and value.get('type') in STATEMENTS, 'ATTRIBUTE_STATEMENT')
    kind = value['type']
    if kind == 'AGE_AT_LEAST':
        need('upper' not in value, 'ATTRIBUTE_UPPER_BOUND')
        need(set(value) == {'type', 'years'} and type(value['years']) is int and 1 <= value['years'] <= 150,
             'ATTRIBUTE_STATEMENT')
    elif kind in ('JURISDICTION_IN', 'JURISDICTION_NOT_IN'):
        need(set(value) == {'type', 'set'}, 'ATTRIBUTE_STATEMENT')
        _codes(value['set'])
    elif kind == 'LICENSED':
        need(set(value) == {'type', 'activity'} and type(value['activity']) is str
             and hc.ACTIVITY.fullmatch(value['activity']) is not None, 'ATTRIBUTE_STATEMENT')
    elif kind == 'TRUE_CLAIM':
        need(set(value) == {'type', 'claim'} and value['claim'] in hc.BOOLEAN_CLAIMS, 'ATTRIBUTE_STATEMENT')
    elif kind == 'MANDATE_AT_MOST':
        need(set(value) == {'type', 'resource', 'amount'} and type(value['resource']) is str
             and 0 < len(value['resource']) <= 80 and value['resource'].isprintable(), 'ATTRIBUTE_STATEMENT')
        integer(value['amount'], True)
    else:
        need(set(value) == {'type', 'attribute'} and value['attribute'] == 'jurisdiction', 'ATTRIBUTE_STATEMENT')
    canonical(value)
    return value


def _statements(values):
    need(type(values) is list and 1 <= len(values) <= MAX_STATEMENTS, 'ATTRIBUTE_STATEMENTS')
    for value in values:
        statement(value)
    need(len({canonical(value) for value in values}) == len(values), 'ATTRIBUTE_STATEMENTS')
    return values


def make_policy(*, issuers, statements, audience, scope=None, escrow_policies=None):
    """A verifier's attribute policy. ``escrow_policies`` (disclosure policy ids) makes accountability mandatory."""
    need(type(issuers) is dict and 1 <= len(issuers) <= 8, 'ATTRIBUTE_POLICY')
    for name, value in issuers.items():
        need(type(name) is str and 0 < len(name) <= 256 and name.isascii() and type(value) is str, 'ATTRIBUTE_POLICY')
        verification_key(value)
    hc._scope(scope)
    need(type(audience) is str and 0 < len(audience) <= 256 and audience.isascii(), 'ATTRIBUTE_POLICY')
    if escrow_policies is not None:
        need(type(escrow_policies) is list and 1 <= len(escrow_policies) <= 8
             and escrow_policies == sorted(set(escrow_policies)), 'ATTRIBUTE_POLICY')
        for item in escrow_policies:
            key(item)
    return {'version': VERSION, 'issuers': deepcopy(issuers), 'statements': deepcopy(_statements(statements)),
            'audience': audience, 'scope': scope, 'escrow_policies': deepcopy(escrow_policies)}


def check_policy(policy):
    need(type(policy) is dict and set(policy) == {'version', 'issuers', 'statements', 'audience', 'scope',
                                                  'escrow_policies'}, 'ATTRIBUTE_POLICY')
    need(policy['version'] == VERSION, 'ATTRIBUTE_POLICY_VERSION')
    rebuilt = make_policy(issuers=policy['issuers'], statements=policy['statements'], audience=policy['audience'],
                          scope=policy['scope'], escrow_policies=policy['escrow_policies'])
    need(rebuilt == policy, 'ATTRIBUTE_POLICY')
    return digest(LABEL, policy)


def age_thresholds(birth_date, on, ladder=AGE_LADDER):
    """Issuer helper: every ladder age the holder has reached on ``on`` (ISO dates), for age_equal_or_over."""
    def parse(text):
        found = DATE.fullmatch(text) if type(text) is str else None
        need(found is not None, 'ATTRIBUTE_DATE')
        try:
            return datetime.date(int(found.group(1)), int(found.group(2)), int(found.group(3)))
        except ValueError:
            raise ValueError('ATTRIBUTE_DATE') from None
    born, today = parse(birth_date), parse(on)
    need(born <= today, 'ATTRIBUTE_DATE')
    need(type(ladder) in (list, tuple) and 1 <= len(ladder) <= hc.MAX_ATTRIBUTE_ITEMS and list(ladder) == sorted(set(ladder))
         and all(type(age) is int and 1 <= age <= 150 for age in ladder), 'ATTRIBUTE_LADDER')
    years = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
    return [age for age in ladder if age <= years]


def sets_containing(jurisdiction, registry):
    """Issuer helper: the named sets of ``registry`` ({name: members}) that contain ``jurisdiction``."""
    need(type(jurisdiction) is str and hc.JURISDICTION.fullmatch(jurisdiction) is not None, 'ATTRIBUTE_STATEMENT')
    need(type(registry) is dict and len(registry) <= 64, 'ATTRIBUTE_STATEMENT')
    return {name: _codes(members) for name, members in sorted(registry.items()) if jurisdiction in members}


def _held(credential):
    need(type(credential) is dict and {'holder_key', 'sd_jwt', 'disclosures'} <= set(credential), 'ATTRIBUTE_CREDENTIAL')
    held = {}
    for item in credential['disclosures']:
        _, name, value = hc._json(hc._unb64(item))
        held[name] = value
    return held


def _answer(kind, item, claims, *, reveal_exact):
    """The claim name (and disclose value) that implies ``item`` among ``claims``, or None."""
    if kind == 'AGE_AT_LEAST':
        steps = sorted(int(name[18:]) for name, value in claims.items()
                       if hc.AGE_CLAIM.fullmatch(name) and value is True and int(name[18:]) >= item['years'])
        return ('age_equal_or_over_' + str(steps[0]), True) if steps else None
    if kind in ('JURISDICTION_IN', 'JURISDICTION_NOT_IN'):
        wanted = set(item['set'])
        fits = [(len(value['members']), name) for name, value in claims.items() if hc.SET_CLAIM.fullmatch(name)
                and type(value) is dict and (set(value['members']) <= wanted if kind == 'JURISDICTION_IN'
                                             else not set(value['members']) & wanted)]
        if fits:
            return sorted(fits, key=lambda row: (-row[0], row[1]))[0][1], True
        exact = claims.get('jurisdiction')
        if reveal_exact and type(exact) is str and ((exact in wanted) == (kind == 'JURISDICTION_IN')):
            return 'jurisdiction', True
        return None
    if kind == 'LICENSED':
        name = 'licensed_' + item['activity']
        return (name, True) if claims.get(name) is True else None
    if kind == 'TRUE_CLAIM':
        return (item['claim'], True) if claims.get(item['claim']) is True else None
    if kind == 'MANDATE_AT_MOST':
        steps = sorted(value['amount'] for name, value in claims.items()
                       if (hc.STEP_CLAIM.fullmatch(name) or name == 'mandate_at_most') and type(value) is dict
                       and value.get('resource') == item['resource'] and value.get('amount', 0) <= item['amount'])
        return ('mandate_at_most', steps[-1]) if steps else None
    return ('jurisdiction', True) if type(claims.get('jurisdiction')) is str else None


def select(credential, statements, *, reveal_exact=False):
    """Holder side: the least-revealing disclose map for present(); ATTRIBUTE_UNSATISFIED if one cannot be met."""
    held = _held(credential)
    need(type(reveal_exact) is bool, 'ATTRIBUTE_STATEMENT')
    disclose = {}
    for item in _statements(statements):
        answer = _answer(item['type'], item, held, reveal_exact=reveal_exact or item['type'] == 'REVEAL')
        need(answer is not None, 'ATTRIBUTE_UNSATISFIED')
        disclose[answer[0]] = answer[1]
    return disclose


def prove(credential, holder_private, policy, *, nonce, now, reveal_exact=False):
    """Explicit local holder action: answer the policy's statements in one key-bound presentation."""
    check_policy(policy)
    disclose = select(credential, policy['statements'], reveal_exact=reveal_exact)
    return hc.present(credential, holder_private, disclose=disclose, audience=policy['audience'], nonce=nonce, now=now)


def _learned(kind, name, value):
    if kind == 'AGE_AT_LEAST':
        return 'age is at least ' + name[18:]
    if name == 'jurisdiction':
        return 'jurisdiction is ' + value
    if hc.SET_CLAIM.fullmatch(name):
        return 'jurisdiction is one of ' + ','.join(value['members'])
    if kind == 'MANDATE_AT_MOST':
        return 'mandate for ' + value['resource'] + ' is at most ' + str(value['amount'])
    return name + ' is true'


def check(presentation, policy, *, nonce, now, escrow=None, clock_skew=30):
    """Verifier side: every statement is implied by an issuer-signed disclosed claim, or the presentation is refused.

    Record the nullifier with a hidden_credentials.NullifierSet before counting it.
    With escrow_policies in the policy, ``escrow`` (the escrow record) must match the
    credential's aap_escrow, its pseudonym and one of the accepted disclosure policies.
    """
    policy_id = check_policy(policy)
    opened = hc.open_attribute_presentation(presentation, policy['issuers'], audience=policy['audience'], nonce=nonce,
                                            now=now, scope=policy['scope'], clock_skew=clock_skew)
    claims = opened['claims']
    rows, used = [], set()
    for item in policy['statements']:
        answer = _answer(item['type'], item, claims, reveal_exact=True)
        need(answer is not None, 'ATTRIBUTE_NOT_PROVEN')
        name = answer[0]
        used.add(name)
        rows.append({'statement': deepcopy(item), 'satisfied_by': name,
                     'learned': _learned(item['type'], name, claims[name])})
    accountable = None
    if policy['escrow_policies'] is not None:
        need(opened['escrow'] is not None and escrow is not None, 'ATTRIBUTE_ESCROW_REQUIRED')
        from .disclosure_escrow import check_credential_escrow
        accountable = check_credential_escrow(escrow, opened, policy['escrow_policies'])
    return {'version': VERSION, 'accepted': True, 'policy': policy_id, 'credential_version': opened['version'],
            'issuer': opened['issuer'], 'scope': opened['scope'], 'statements': rows,
            'over_disclosed': sorted(set(claims) - used), 'nullifier': opened['nullifier'],
            'account_revealed': opened['account_revealed'], 'principal_revealed': opened['principal_revealed'],
            'escrow': opened['escrow'], 'accountable': accountable, 'zero_knowledge': False,
            'proves': ['each statement is implied by a claim the pinned issuer signed for this one-time holder key',
                       'the presenter holds that key now (key binding over this nonce and audience)'],
            'does_not_prove': ['nothing beyond issuance time: claims are true when issued; revocation is expiry only',
                               'zero knowledge: the verifier learns each disclosed claim exactly',
                               'unlinkability against the issuer',
                               'any authority to sign, spend or bind; execution_authorized is always false'],
            'execution_authorized': False}


def describe():
    return {'version': VERSION, 'credential_version': hc.ATTRIBUTE_VERSION, 'status': 'EXPERIMENTAL_OPTIONAL',
            'scheme': 'IETF SD-JWT (RFC 9901) VC with key binding, EdDSA; issuer-precomputed predicate claims',
            'statements': {'AGE_AT_LEAST': ['years'], 'JURISDICTION_IN': ['set'], 'JURISDICTION_NOT_IN': ['set'],
                           'LICENSED': ['activity'], 'TRUE_CLAIM': ['claim'], 'MANDATE_AT_MOST': ['resource', 'amount'],
                           'REVEAL': ['attribute']},
            'concordium_mapping': dict(CONCORDIUM), 'age_ladder_default': list(AGE_LADDER),
            'claims': ['age_equal_or_over_<n>', 'jurisdiction', 'jurisdiction_in_<SET>', 'licensed_<activity>'],
            'zero_knowledge': False,
            'limits': ['answers only statements the issuer anticipated; a threshold between steps uses the next step up',
                       'the verifier learns the disclosed claim exactly, plus issuer, scope, expiry and holder key',
                       'no upper bounds; no proofs over committed attributes (no Bulletproofs or BBS here)',
                       'true at issuance; revocation is expiry only; the issuer can link presentations it sees'],
            'remediation': dict(REMEDIATION), 'execution_authorized': False}
