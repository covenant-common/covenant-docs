"""Balance arithmetic shared by the reducer and the profiles that post into it.

``amount`` and ``move`` do not import ``app``. Profiles call them directly so
the reducer can call those profiles without a cycle.
"""

from .crypto import integer, need


def amount(table, actor, rid):
    return table.get(actor, {}).get(rid, 0)


def add(table, actor, rid, qty):
    table.setdefault(actor, {})[rid] = amount(table, actor, rid) + qty
    integer(table[actor][rid])


def move(state, source, target, resource, quantity):
    integer(quantity, True)
    need(type(resource) is str and resource in state['resources'], 'RESOURCE')
    need(amount(state['authority_available'], source, resource) >= quantity, 'WORLD_FUNDS')
    for table in ('balances', 'authority_available'):
        add(state[table], source, resource, -quantity)
        add(state[table], target, resource, quantity)
