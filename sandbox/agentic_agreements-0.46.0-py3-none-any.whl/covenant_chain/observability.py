"""Operator observability for long-running AAP services.

Stdlib only. Three operator surfaces, none of them telemetry:

* JSON Lines logs: one RFC 8259 object per line with an RFC 3339 UTC time.
  Off unless the operator passes ``--log-json``. Field names are fixed by the
  caller and every value passes through ``redact``, so keys, bearer tokens,
  PEM blocks, e-mail addresses, telephone numbers, IP addresses, DIDs and long
  hex or base64 strings never reach the stream.
* ``GET /healthz`` (liveness) and ``GET /readyz`` (readiness) on a service's
  own HTTP listener. They report stable codes, never configuration, keys,
  paths or peer data.
* Prometheus text exposition format 0.0.4 on ``GET /metrics``, served only by
  the loopback operator listener (``--ops-port``), which is off by default.

Health, readiness and metrics describe one process. They are not consensus
evidence, authority, payment or delivery, and an unknown check is not ready.
"""
from http.server import BaseHTTPRequestHandler
import ipaddress
import json
import math
import os
import re
import sys
import threading
import time

from .crypto import need

CONTENT_TYPE = 'text/plain; version=0.0.4; charset=utf-8'
JSON_TYPE = 'application/json'
LATENCY_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0)
MAX_FAMILIES = 128
MAX_SERIES = 64
MAX_LABEL_VALUE = 64
MAX_CHECKS = 16
MAX_LINE = 8192
MAX_FIELDS = 32
MAX_STRING = 256
MAX_SCAN = 8192
MAX_ITEMS = 16
MAX_DEPTH = 3
STORAGE_TTL = 30.0
MAX_STORAGE_ENTRIES = 200_000
OVERFLOW = '_overflow'
PROBE_PATHS = {'/healthz': 'live', '/readyz': 'ready', '/metrics': 'metrics'}
LEVELS = {'debug': 10, 'info': 20, 'warning': 30, 'error': 40}
METHODS = frozenset({'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'})

# Readiness and operator-configuration codes, with the remediation the runbook prints.
REMEDIATION = {
    'NOT_READY': 'A readiness check returned false without a code. Read the service log with --log-json.',
    'CHECK_FAILED': 'A readiness check raised. Restart the service; if it repeats, run covenant-doctor for it.',
    'CONSENSUS_STORAGE_FAILED': 'The validator journal could not be written. Stop the node, free space or fix the disk, run covenant-doctor, then restart.',
    'MIGRATION_HALTED': 'This source chain is halted for migration. It serves reads only; follow docs/WORLD_MIGRATION_016.html.',
    'CONSENSUS_STOPPED': 'The consensus pump stopped (see /status errors). Restart the node; repeated stops need the journal checked.',
    'PUMP_STOPPED': 'The pump thread ended. Restart the node and read node_error log lines for the category.',
    'STORE_DIRECTORY_MISSING': 'The store directory is gone or is a link. Stop the service and restore it from a verified backup.',
    'STORE_DIRECTORY_READ_ONLY': 'The store directory is not writable by the service user. Fix ownership or the mount.',
    'GATEWAY_NOT_LISTENING': 'The gateway has not bound its listener yet, or failed to. Check the TLS config and port.',
    'UNAPPROVED_GATEWAY_BACKEND': 'Install aiohttp >=3.14.4,<3.15 from requirements/network.lock.',
    'GATEWAY_UPSTREAM_UNAVAILABLE': 'Three forwards in a row failed. Check that the validator on 127.0.0.1 is up and ready.',
    'REPLICA_FAILED': 'The replica or its consensus engine latched a failure. Stop it and run covenant-doctor replica.',
    'REPLICA_THREAD_STOPPED': 'A replica worker thread ended. Restart the replica service.',
    'WELCOME_CLOSED': 'The welcome session closed. Restart covenant-welcome.',
    'HANDOFF_CLOSED': 'The handoff session closed. Restart covenant-handoff.',
    'CONNECTOR_GRANTS': 'The connector has no grants. Regenerate the policy with --init-directory.',
    'OPS_SERVICE': 'Internal: an operator bundle needs a lowercase service name.',
    'OPS_ROUTES': 'Internal: a route list is limited to 64 entries.',
    'OPS_QUEUE': 'Internal: queue gauges need a lowercase name and a callable; at most 64.',
    'OPS_STORE': 'Internal: storage gauges need a lowercase name; at most 64.',
    'OPS_PORT': 'Use --ops-port with an integer from 0 to 65535.',
    'OPS_LISTENER_RUNNING': 'Internal: the operator listener was started twice.',
    'OPS_LISTENER_NOT_LOOPBACK': 'The operator listener binds loopback only; reach it through SSH or a local agent.',
    'OPS_NOT_FOUND': 'The operator listener serves /healthz, /readyz and /metrics only.',
    'OPS_METHOD': 'The operator listener accepts GET only.',
    'LOG_LEVEL': 'Use one of debug, info, warning or error.',
    'HEALTH_CHECK_NAME': 'Internal: check names are lowercase identifiers.',
    'HEALTH_CHECK': 'Internal: a readiness check must be callable.',
    'HEALTH_CHECK_DUPLICATE': 'Internal: a readiness check name was registered twice.',
    'HEALTH_CHECK_LIMIT': 'Internal: at most 16 readiness checks per service.',
    'METRIC_KIND': 'Internal: the operation does not apply to this metric type.',
    'METRIC_NAME': 'Internal: metric names follow the Prometheus data model.',
    'METRIC_HELP': 'Internal: metric help text is 1 to 512 characters.',
    'METRIC_LABELS': 'Internal: label names must match the family declaration.',
    'METRIC_LABEL_NAME': 'Internal: label names follow the Prometheus data model and avoid le, quantile and __.',
    'METRIC_CALLBACK': 'Internal: callback metrics return a number or a map of label tuples to numbers.',
    'METRIC_SERIES_LIMIT': 'Internal: a family holds 1 to 4096 series.',
    'METRIC_BUCKETS': 'Internal: histogram buckets are 1 to 32 increasing finite numbers.',
    'METRIC_VALUE': 'Internal: metric values are finite numbers.',
    'METRIC_NEGATIVE': 'Internal: counters only increase.',
    'METRIC_DUPLICATE': 'Internal: a metric family name was registered twice.',
    'METRIC_FAMILY_LIMIT': 'Internal: a registry holds at most 128 families.',
}

_METRIC_NAME = re.compile(r'[a-zA-Z_:][a-zA-Z0-9_:]*\Z')
_LABEL_NAME = re.compile(r'[a-zA-Z_][a-zA-Z0-9_]*\Z')
_NAME = re.compile(r'[a-z][a-z0-9_]{0,39}\Z')
_EVENT = re.compile(r'[a-z][a-z0-9_.]{0,63}\Z')
_SERVICE = re.compile(r'[a-z][a-z0-9_-]{0,47}\Z')
_CODE = re.compile(r'([A-Z][A-Z0-9_]{2,63})(?=$|[:\s(])')
_SEGMENT = re.compile(r'[A-Za-z0-9._~-]{1,48}\Z')
_IDENTIFIER = re.compile(r'[0-9a-fA-F]{16,}|[0-9]{4,}|[A-Za-z0-9_-]{32,}|^[0-9]+$')
_ERROR_FIELD = re.compile(rb'"error"\s*:\s*(?:\{\s*"code"\s*:\s*)?"([A-Z][A-Z0-9_]{2,63})(?=["\s:(])')

SECRET_FIELD = re.compile(r'(?i)pass(?:word|phrase)?|secret|token|bearer|authori[sz]ation|cookie|private|seed|'
                          r'mnemonic|api_?key|credential|signature|csrf|session|otp|nonce|email|phone|'
                          r'address|remote|client_ip|peer_ip')
_REDACTIONS = (
    (re.compile(r'-----BEGIN [A-Z0-9 ]{1,40}-----.*?(?:-----END [A-Z0-9 ]{1,40}-----|\Z)', re.S), '[REDACTED:PEM]'),
    (re.compile(r'(?i)\b([a-z][a-z0-9+.-]{0,15}://)[^/\s:@]{1,256}:[^/\s@]{1,256}@'), r'\1[REDACTED]@'),
    (re.compile(r'(?i)([?&;](?:token|key|secret|password|pass|sig|signature|auth|code|session)=)[^&;\s]+'), r'\1[REDACTED]'),
    (re.compile(r'(?i)\b(bearer|basic|token)\s+[A-Za-z0-9._~+/=-]{4,}'), r'\1 [REDACTED]'),
    (re.compile(r'\beyJ[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]*'), '[REDACTED:JWT]'),
    (re.compile(r'[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]{1,63}(?:\.[A-Za-z0-9-]{1,63})*\.[A-Za-z]{2,24}'), '[REDACTED:EMAIL]'),
    (re.compile(r'\bdid:[a-z0-9]{1,16}:[A-Za-z0-9._:%-]{1,256}'), '[REDACTED:DID]'),
    (re.compile(r'(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])'), '[REDACTED:IP]'),
    (re.compile(r'(?<![\w:])(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}(?![\w:])|'
                r'(?<![\w:])(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{0,4}::(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{0,4}(?![\w:])'),
     '[REDACTED:IP]'),
    (re.compile(r'(?<![\w+])\+\d[\d ().-]{6,20}\d(?!\w)|(?<!\w)\(\d{3}\)\s?\d{3}-\d{4}(?!\w)|(?<!\w)\d{3}-\d{3}-\d{4}(?!\w)'),
     '[REDACTED:PHONE]'),
    (re.compile(r'(?<![0-9A-Za-z])[0-9a-fA-F]{32,}(?![0-9A-Za-z])'), '[REDACTED:HEX]'),
)
_BASE64 = re.compile(r'(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{40,}={0,2}')


def package_version():
    from covenant_language._version import __version__
    return __version__


def _text(value, limit=MAX_STRING):
    return value if len(value) <= limit else value[:limit] + '...[truncated]'


def _base64(match):
    token = match.group(0)
    classes = sum(1 for test in (str.isupper, str.islower, str.isdigit) if any(test(c) for c in token))
    return '[REDACTED:B64]' if classes == 3 else token


def redact_text(value):
    """Remove secrets and personal data from free text, then bound its length."""
    text = value[:MAX_SCAN]
    home = os.path.expanduser('~')
    if len(home) > 1:
        text = text.replace(home, '~')
    for pattern, replacement in _REDACTIONS:
        text = pattern.sub(replacement, text)
    text = _BASE64.sub(_base64, text)
    return _text(text + ('...[truncated]' if len(value) > MAX_SCAN else ''))


def redact(value, key=None, depth=0):
    """A bounded, JSON-safe copy of ``value`` with secrets and personal data removed."""
    if key is not None and SECRET_FIELD.search(key):
        return '[REDACTED]'
    if value is None or type(value) is bool:
        return value
    if type(value) is int:
        return value if abs(value) <= 2**63 else '[INTEGER]'
    if type(value) is float:
        return value if math.isfinite(value) else str(value)
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, (bytes, bytearray, memoryview)):
        return f'[BYTES:{len(value)}]'
    if isinstance(value, BaseException):
        return refusal_code(value)
    if depth >= MAX_DEPTH:
        return '[DEPTH]'
    if isinstance(value, dict):
        out = {}
        for name, item in list(value.items())[:MAX_ITEMS]:
            if type(name) is str and _NAME.fullmatch(name):
                out[name] = redact(item, name, depth + 1)
        return out
    if isinstance(value, (list, tuple, set, frozenset)):
        return [redact(item, None, depth + 1) for item in list(value)[:MAX_ITEMS]]
    return '[' + type(value).__name__[:32] + ']'


def refusal_code(value):
    """The stable UPPER_SNAKE code an error or reply carries, else UNCLASSIFIED."""
    if isinstance(value, BaseException):
        value = value.args[0] if value.args and type(value.args[0]) is str else ''
    if type(value) is not str:
        return 'UNCLASSIFIED'
    match = _CODE.match(value[:80])
    return match.group(1) if match else 'UNCLASSIFIED'


def route_shape(path):
    """A low-cardinality route label: identifiers and long segments become ``*``."""
    if type(path) is not str or path[:1] != '/' or len(path) > 4096:
        return 'other'
    parts = path.split('?', 1)[0].split('#', 1)[0].split('/')[1:]
    shaped = []
    for part in parts[:3]:
        if part == '':
            continue
        shaped.append(part if _SEGMENT.fullmatch(part) and not _IDENTIFIER.search(part) else '*')
    if len(parts) > 3:
        shaped.append('*')
    return '/' + '/'.join(shaped)


def _label_value(value):
    text = value if type(value) is str else str(value)
    text = ''.join(c if c.isprintable() else '?' for c in text[:MAX_LABEL_VALUE])
    return text


def _escape_label(value):
    return value.replace('\\', '\\\\').replace('\n', '\\n').replace('"', '\\"')


def _escape_help(value):
    return value.replace('\\', '\\\\').replace('\n', '\\n')


def _number(value):
    if type(value) is bool:
        value = int(value)
    if type(value) is int:
        return str(value)
    value = float(value)
    if math.isnan(value):
        return 'NaN'
    if math.isinf(value):
        return '+Inf' if value > 0 else '-Inf'
    return repr(value)


def _labels(names, values, extra=()):
    pairs = list(zip(names, values)) + list(extra)
    if not pairs:
        return ''
    return '{' + ','.join(f'{name}="{_escape_label(value)}"' for name, value in pairs) + '}'


class Family:
    """One metric family: a counter, gauge or histogram with bounded label sets."""

    def __init__(self, kind, name, documentation, labelnames=(), *, buckets=None, fn=None,
                 max_series=MAX_SERIES, overflow=None):
        need(kind in {'counter', 'gauge', 'histogram'}, 'METRIC_KIND')
        need(type(name) is str and _METRIC_NAME.fullmatch(name) is not None, 'METRIC_NAME')
        need(type(documentation) is str and 0 < len(documentation) <= 512, 'METRIC_HELP')
        labelnames = tuple(labelnames)
        need(len(labelnames) <= 8 and len(set(labelnames)) == len(labelnames), 'METRIC_LABELS')
        for label in labelnames:
            need(type(label) is str and _LABEL_NAME.fullmatch(label) is not None
                 and not label.startswith('__') and label not in {'le', 'quantile'}, 'METRIC_LABEL_NAME')
        need(fn is None or (callable(fn) and kind != 'histogram'), 'METRIC_CALLBACK')
        need(type(max_series) is int and 1 <= max_series <= 4096, 'METRIC_SERIES_LIMIT')
        if kind == 'histogram':
            buckets = tuple(float(b) for b in (buckets or LATENCY_BUCKETS))
            need(0 < len(buckets) <= 32 and all(math.isfinite(b) for b in buckets)
                 and list(buckets) == sorted(set(buckets)), 'METRIC_BUCKETS')
        self.kind, self.name, self.documentation = kind, name, documentation
        self.labelnames, self.buckets, self.fn = labelnames, buckets, fn
        self.max_series, self.overflow = max_series, overflow
        self._lock = threading.Lock()
        self._series = {}

    def _key(self, labels):
        need(set(labels) == set(self.labelnames), 'METRIC_LABELS')
        key = tuple(_label_value(labels[name]) for name in self.labelnames)
        if key not in self._series and len(self._series) >= self.max_series:
            if self.overflow is not None:
                self.overflow(self.name)
            key = (OVERFLOW,) * len(self.labelnames)
        return key

    def inc(self, amount=1, **labels):
        need(self.kind in {'counter', 'gauge'} and self.fn is None, 'METRIC_KIND')
        need(type(amount) in (int, float) and math.isfinite(amount), 'METRIC_VALUE')
        need(self.kind == 'gauge' or amount >= 0, 'METRIC_NEGATIVE')
        with self._lock:
            key = self._key(labels)
            self._series[key] = self._series.get(key, 0) + amount

    def dec(self, amount=1, **labels):
        need(self.kind == 'gauge', 'METRIC_KIND')
        self.inc(-amount, **labels)

    def set(self, value, **labels):
        need(self.kind == 'gauge' and self.fn is None, 'METRIC_KIND')
        need(type(value) in (int, float) and not math.isnan(value), 'METRIC_VALUE')
        with self._lock:
            self._series[self._key(labels)] = value

    def observe(self, value, **labels):
        need(self.kind == 'histogram', 'METRIC_KIND')
        need(type(value) in (int, float) and math.isfinite(value) and value >= 0, 'METRIC_VALUE')
        with self._lock:
            key = self._key(labels)
            state = self._series.get(key)
            if state is None:
                state = self._series[key] = [[0] * len(self.buckets), 0.0, 0]
            for index, bound in enumerate(self.buckets):
                if value <= bound:
                    state[0][index] += 1
                    break
            state[1] += value
            state[2] += 1

    def value(self, **labels):
        """Current value of one series, for tests and readiness checks."""
        with self._lock:
            key = tuple(_label_value(labels[name]) for name in self.labelnames) if set(labels) == set(self.labelnames) else None
            state = self._series.get(key)
        if self.kind == 'histogram' and state is not None:
            return {'count': state[2], 'sum': state[1]}
        return state

    def _collected(self):
        if self.fn is None:
            with self._lock:
                return [(key, (list(v[0]), v[1], v[2]) if self.kind == 'histogram' else v)
                        for key, v in sorted(self._series.items())]
        result = self.fn()
        if result is None:
            return []
        if not self.labelnames:
            return [((), result)]
        need(isinstance(result, dict), 'METRIC_CALLBACK')
        rows = []
        for key, value in sorted(result.items(), key=lambda item: str(item[0]))[:self.max_series]:
            key = key if type(key) is tuple else (key,)
            need(len(key) == len(self.labelnames), 'METRIC_LABELS')
            if value is not None:
                rows.append((tuple(_label_value(v) for v in key), value))
        return rows

    def render(self):
        rows = self._collected()
        lines = [f'# HELP {self.name} {_escape_help(self.documentation)}', f'# TYPE {self.name} {self.kind}']
        for key, value in rows:
            if self.kind != 'histogram':
                need(type(value) in (int, float, bool), 'METRIC_VALUE')
                lines.append(f'{self.name}{_labels(self.labelnames, key)} {_number(value)}')
                continue
            counts, total, count = value
            cumulative = 0
            for bound, observed in zip(self.buckets, counts):
                cumulative += observed
                lines.append(f'{self.name}_bucket{_labels(self.labelnames, key, (("le", _number(bound)),))} {cumulative}')
            lines.append(f'{self.name}_bucket{_labels(self.labelnames, key, (("le", "+Inf"),))} {count}')
            lines.append(f'{self.name}_sum{_labels(self.labelnames, key)} {_number(total)}')
            lines.append(f'{self.name}_count{_labels(self.labelnames, key)} {count}')
        return lines


class Metrics:
    """Bounded metric families rendered in Prometheus text exposition format 0.0.4."""

    def __init__(self, *, max_series=MAX_SERIES):
        self.max_series = max_series
        self._lock = threading.Lock()
        self._families = {}
        self.dropped = self._register(Family('counter', 'aap_metric_series_dropped_total',
            'Label sets folded into the overflow series because a family reached its series limit.',
            ('metric',), max_series=MAX_FAMILIES))
        self.errors = self._register(Family('counter', 'aap_metric_collect_errors_total',
            'Callback metrics that failed during a scrape and were omitted.', ('metric',), max_series=MAX_FAMILIES))

    def _register(self, family):
        with self._lock:
            need(family.name not in self._families, 'METRIC_DUPLICATE')
            need(len(self._families) < MAX_FAMILIES, 'METRIC_FAMILY_LIMIT')
            self._families[family.name] = family
        return family

    def _overflowed(self, name):
        self.dropped.inc(metric=name)

    def counter(self, name, documentation, labels=(), fn=None):
        return self._register(Family('counter', name, documentation, labels, fn=fn,
                                     max_series=self.max_series, overflow=self._overflowed))

    def gauge(self, name, documentation, labels=(), fn=None):
        return self._register(Family('gauge', name, documentation, labels, fn=fn,
                                     max_series=self.max_series, overflow=self._overflowed))

    def histogram(self, name, documentation, labels=(), buckets=LATENCY_BUCKETS):
        return self._register(Family('histogram', name, documentation, labels, buckets=buckets,
                                     max_series=self.max_series, overflow=self._overflowed))

    def family(self, name):
        with self._lock:
            return self._families.get(name)

    def render(self):
        with self._lock:
            families = sorted(self._families.values(), key=lambda family: family.name)
        lines = []
        for family in families:
            try:
                lines.extend(family.render())
            except Exception:  # A failing callback omits its own family, never the scrape.
                if family is not self.errors:
                    self.errors.inc(metric=family.name)
        return '\n'.join(lines) + '\n'


def _cpu_seconds():
    import resource
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return usage.ru_utime + usage.ru_stime


def _open_fds():
    for directory in ('/proc/self/fd', '/dev/fd'):
        if os.path.isdir(directory):
            with os.scandir(directory) as entries:
                return sum(1 for _ in entries)
    return None


def _max_fds():
    import resource
    soft = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    return None if soft == resource.RLIM_INFINITY else soft


def _resident_bytes():
    try:
        with open('/proc/self/statm', 'rb') as handle:
            fields = handle.read(256).split()
        return int(fields[1]) * os.sysconf('SC_PAGE_SIZE')
    except (OSError, ValueError, IndexError):
        return None


def _peak_resident_bytes():
    import resource
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return peak if sys.platform == 'darwin' else peak * 1024


def process_metrics(metrics, *, started=None):
    """Standard process families; values a platform cannot report are omitted, not guessed."""
    wall = time.time() if started is None else started
    metrics.gauge('process_start_time_seconds', 'Start time of the process since the Unix epoch in seconds.', fn=lambda: wall)
    metrics.counter('process_cpu_seconds_total', 'Total user and system CPU time spent in seconds.', fn=_cpu_seconds)
    metrics.gauge('process_open_fds', 'Number of open file descriptors.', fn=_open_fds)
    metrics.gauge('process_max_fds', 'Maximum number of open file descriptors.', fn=_max_fds)
    metrics.gauge('process_resident_memory_bytes', 'Resident memory size in bytes.', fn=_resident_bytes)
    metrics.gauge('aap_process_peak_resident_memory_bytes', 'Peak resident memory size in bytes.', fn=_peak_resident_bytes)
    metrics.gauge('aap_process_threads', 'Live Python threads in the process.', fn=threading.active_count)


def tree_bytes(paths, *, limit=MAX_STORAGE_ENTRIES):
    """Bytes held by files and directory trees, or None when the scan exceeds ``limit`` entries."""
    total = entries = 0
    for path in paths:
        path = os.fspath(path)
        try:
            info = os.lstat(path)
        except FileNotFoundError:
            continue
        if not os.path.isdir(path) or os.path.islink(path):
            total += info.st_size
            entries += 1
            continue
        for root, directories, files in os.walk(path, followlinks=False):
            entries += len(directories) + len(files)
            if entries > limit:
                return None
            for name in files:
                try:
                    total += os.lstat(os.path.join(root, name)).st_size
                except FileNotFoundError:
                    continue
    return total


class Health:
    """Liveness plus named readiness checks. A check returns True, False or a stable code."""

    def __init__(self, service, *, version=None, clock=time.monotonic):
        self.service = service
        self.version = version or package_version()
        self.clock = clock
        self.started = clock()
        self._checks = []

    def add(self, name, check):
        need(type(name) is str and _NAME.fullmatch(name) is not None, 'HEALTH_CHECK_NAME')
        need(callable(check), 'HEALTH_CHECK')
        need(all(name != existing for existing, _ in self._checks), 'HEALTH_CHECK_DUPLICATE')
        need(len(self._checks) < MAX_CHECKS, 'HEALTH_CHECK_LIMIT')
        self._checks.append((name, check))

    def live(self):
        return {'status': 'ok', 'service': self.service, 'version': self.version,
                'uptime_seconds': int(max(0, self.clock() - self.started))}

    def ready(self):
        results = {}
        for name, check in self._checks:
            try:
                outcome = check()
            except Exception as exc:  # A failing check is a not-ready code, never a crash or a pass.
                outcome = refusal_code(exc)
                outcome = 'CHECK_FAILED' if outcome == 'UNCLASSIFIED' else outcome
            if outcome is True:
                results[name] = 'ok'
            elif type(outcome) is str and _CODE.fullmatch(outcome):
                results[name] = outcome
            else:
                results[name] = 'NOT_READY'
        ready = all(value == 'ok' for value in results.values())
        return ready, {'status': 'ready' if ready else 'not_ready', 'service': self.service, 'checks': results}


class Log:
    """Redacted JSON Lines to one stream. Disabled until ``enable`` is called."""

    def __init__(self, service, stream=None, *, level='info', clock=time.time):
        need(level in LEVELS, 'LOG_LEVEL')
        self.service, self.stream, self.threshold, self.clock = service, stream, LEVELS[level], clock
        self.dropped = 0
        self._lock = threading.Lock()

    @property
    def enabled(self):
        return self.stream is not None

    def enable(self, stream, level=None):
        need(level is None or level in LEVELS, 'LOG_LEVEL')
        self.stream = stream
        if level is not None:
            self.threshold = LEVELS[level]

    def line(self, event, level='info', **fields):
        need(level in LEVELS, 'LOG_LEVEL')
        now = self.clock()
        stamp = time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(now)) + f'.{int(now % 1 * 1000):03d}Z'
        record = {'ts': stamp, 'level': level, 'service': self.service,
                  'event': event if type(event) is str and _EVENT.fullmatch(event) else 'invalid_event'}
        names = [name for name in sorted(fields) if _NAME.fullmatch(name) and name not in record][:MAX_FIELDS]
        extra = {name: redact(fields[name], name) for name in names}
        encoded = json.dumps({**record, **extra}, ensure_ascii=True, separators=(',', ':'), allow_nan=False)
        while len(encoded) + 1 > MAX_LINE and names:
            extra.pop(names.pop())
            encoded = json.dumps({**record, **extra, 'truncated': True}, ensure_ascii=True,
                                 separators=(',', ':'), allow_nan=False)
        return encoded + '\n'

    def event(self, event, level='info', **fields):
        if self.stream is None or LEVELS.get(level, 100) < self.threshold:
            return False
        encoded = self.line(event, level, **fields)
        with self._lock:
            try:
                self.stream.write(encoded)
                self.stream.flush()
            except (OSError, ValueError):  # Logging never stops the service it describes.
                self.dropped += 1
                return False
        return True


class Ops:
    """One service's logs, health, metrics and optional loopback operator listener."""

    def __init__(self, service, *, version=None, log_stream=None, routes=None):
        need(type(service) is str and _SERVICE.fullmatch(service) is not None, 'OPS_SERVICE')
        need(routes is None or (len(routes) <= MAX_SERIES and all(type(r) is str for r in routes)), 'OPS_ROUTES')
        self.service = service
        # With a route list, any other path is labelled 'other': a caller cannot mint label series.
        self.routes = None if routes is None else frozenset(routes) | frozenset(PROBE_PATHS)
        self.metrics = Metrics()
        self.health = Health(service, version=version)
        self.log = Log(service, log_stream)
        self.listener = None
        self._queues = {}
        self._stores = {}
        self._storage_cache = {}
        process_metrics(self.metrics)
        version = self.health.version
        self.metrics.gauge('aap_build_info', 'AAP service and release; the value is always 1.',
                           ('service', 'version'), fn=lambda: {(service, version): 1})
        self.requests = self.metrics.counter('aap_http_requests_total',
            'HTTP requests answered, by route shape, method and status code.', ('route', 'method', 'code'))
        self.latency = self.metrics.histogram('aap_http_request_duration_seconds',
            'Seconds from reading a request to finishing its reply, by route shape.', ('route',))
        self.refusals = self.metrics.counter('aap_refusals_total',
            'Requests and operations refused, by stable error code.', ('code',))
        self.metrics.gauge('aap_queue_depth', 'Items waiting in a bounded in-process queue.', ('queue',),
                           fn=lambda: {(name,): fn() for name, fn in list(self._queues.items())})
        self.metrics.gauge('aap_storage_bytes', 'Bytes held by a durable store on disk (files, WAL and directories).',
                           ('store',), fn=self._storage)
        self.metrics.counter('aap_log_lines_dropped_total', 'Log lines the stream refused.', fn=lambda: self.log.dropped)

    def refusal(self, code):
        code = code if type(code) is str and _CODE.fullmatch(code) else refusal_code(code)
        self.refusals.inc(code=code)
        return code

    def route(self, path, status):
        if status == 404:
            return 'unmatched'
        shape = route_shape(path)
        return shape if self.routes is None or shape in self.routes else 'other'

    def observe_reply(self, method, path, status, seconds, body=b''):
        """observe_http with the stable code read from the first bytes of a JSON error body."""
        found = None
        if status >= 400 and isinstance(body, (bytes, bytearray)):
            found = _ERROR_FIELD.search(bytes(body[:2048]))
        self.observe_http(method, path, status, seconds, found.group(1).decode('ascii') if found else None)

    def observe_http(self, method, path, status, seconds, refusal=None):
        route = self.route(path, status)
        method = method if method in METHODS else 'OTHER'
        self.requests.inc(route=route, method=method, code=str(int(status)))
        self.latency.observe(max(0.0, float(seconds)), route=route)
        code = None
        if status >= 400:
            code = self.refusal(refusal if refusal and refusal != 'UNCLASSIFIED' else f'HTTP_{int(status)}')
        self.log.event('http_request', 'warning' if status >= 500 else 'info', method=method, route=route,
                       status=int(status), duration_ms=round(seconds * 1000, 3), code=code)

    def queue(self, name, fn):
        need(type(name) is str and _NAME.fullmatch(name) is not None and callable(fn), 'OPS_QUEUE')
        need(name in self._queues or len(self._queues) < MAX_SERIES, 'OPS_QUEUE')
        self._queues[name] = fn

    def storage(self, name, paths):
        need(type(name) is str and _NAME.fullmatch(name) is not None, 'OPS_STORE')
        need(name in self._stores or len(self._stores) < MAX_SERIES, 'OPS_STORE')
        self._stores[name] = tuple(os.fspath(path) for path in paths)

    def _storage(self):
        now = time.monotonic()
        result = {}
        for name, paths in list(self._stores.items()):
            cached = self._storage_cache.get(name)
            if cached is None or now - cached[0] > STORAGE_TTL:
                cached = self._storage_cache[name] = (now, tree_bytes(paths))
            result[(name,)] = cached[1]
        return result

    def probe(self, method, path, *, operator=False):
        """(status, content type, body) for a probe path, else None so the service answers."""
        kind = PROBE_PATHS.get(path)
        if kind is None or method != 'GET' or (kind == 'metrics' and not operator):
            return None
        if kind == 'live':
            return 200, JSON_TYPE, _json(self.health.live())
        if kind == 'ready':
            ready, report = self.health.ready()
            return (200 if ready else 503), JSON_TYPE, _json(report)
        return 200, CONTENT_TYPE, self.metrics.render().encode('utf-8')

    def serve(self, port, host='127.0.0.1'):
        """Start the loopback operator listener in a daemon thread."""
        need(self.listener is None, 'OPS_LISTENER_RUNNING')
        need(type(port) is int and 0 <= port <= 65535, 'OPS_PORT')
        try:
            loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            loopback = False
        need(loopback, 'OPS_LISTENER_NOT_LOOPBACK')
        from .http_limits import BoundedHTTPServer
        server = BoundedHTTPServer((host, port), operator_handler(self), max_connections=4, connection_seconds=5)
        thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.2},
                                  name='aap-ops-listener', daemon=True)
        thread.start()
        self.listener = (server, thread)
        self.log.event('ops_listener', port=server.server_address[1])
        return server.server_address[1]

    def close(self):
        if self.listener is not None:
            server, thread = self.listener
            self.listener = None
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
        self.log.event('service_stop')


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode('ascii')


def answer(handler, ops, *, operator=False):
    """Answer a probe on a BaseHTTPRequestHandler. False means the service handles the path."""
    if ops is None:
        return False
    reply = ops.probe(handler.command, handler.path.split('?', 1)[0], operator=operator)
    if reply is None:
        return False
    status, content_type, body = reply
    handler.send_response(status)
    handler.send_header('Content-Type', content_type)
    handler.send_header('Content-Length', str(len(body)))
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('X-Content-Type-Options', 'nosniff')
    handler.end_headers()
    handler.wfile.write(body)
    return True


class _Tee:
    """Write-through stream that keeps the first bytes of each reply for its error code."""

    def __init__(self, stream, limit=2048):
        self.stream, self.limit, self.head = stream, limit, bytearray()

    def write(self, data):
        room = self.limit - len(self.head)
        if room > 0:
            self.head += bytes(data[:room])
        return self.stream.write(data)

    def __getattr__(self, name):
        return getattr(self.stream, name)


class Instrumented:
    """Mixin for BaseHTTPRequestHandler subclasses: answer probes, count and time every reply.

    Set ``ops`` on the handler class or on the server. GET /healthz and /readyz
    are answered before the service's own dispatch, locks and authentication.
    Only the method, a route shape, the status and the reply's stable error
    code are recorded, never the query, headers, body, peer address or identity.
    """
    ops = None

    def _observer(self):
        return self.ops if self.ops is not None else getattr(getattr(self, 'server', None), 'ops', None)

    def setup(self):
        super().setup()
        self.wfile = _Tee(self.wfile)

    def parse_request(self):
        # The clock starts at the request line, not while a kept-alive connection idles.
        self._aap_started = time.monotonic()
        if not super().parse_request():
            return False
        # False tells BaseHTTPRequestHandler the reply is already written.
        return not answer(self, self._observer())

    def send_response(self, code, message=None):
        self._aap_status = code
        super().send_response(code, message)

    def handle_one_request(self):
        self._aap_status = self._aap_started = None
        self.wfile.head.clear()
        try:
            super().handle_one_request()
        finally:
            ops, status, started = self._observer(), self._aap_status, self._aap_started
            if ops is not None and status is not None and started is not None:
                body = bytes(self.wfile.head).partition(b'\r\n\r\n')[2]
                ops.observe_reply(getattr(self, 'command', None), getattr(self, 'path', ''), status,
                                  time.monotonic() - started, body)


def operator_handler(ops):
    class OperatorHandler(Instrumented, BaseHTTPRequestHandler):
        server_version = 'aap-ops'
        sys_version = ''

        def log_message(self, *_args):
            pass

        def _refuse(self, status, code):
            body = _json({'error': code})
            self.send_response(status)
            self.send_header('Content-Type', JSON_TYPE)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def parse_request(self):
            self._aap_started = time.monotonic()
            if not BaseHTTPRequestHandler.parse_request(self):
                return False
            return not answer(self, ops, operator=True)

        def do_GET(self):
            self._refuse(404, 'OPS_NOT_FOUND')

        def do_POST(self):
            self._refuse(405, 'OPS_METHOD')

        do_PUT = do_DELETE = do_PATCH = do_HEAD = do_OPTIONS = do_POST
    OperatorHandler.ops = ops
    return OperatorHandler


def add_arguments(parser, *, stdio=False):
    """The shared operator options: ``--log-json`` plus ``--ops-port`` or, for stdio servers, ``--health``."""
    group = parser.add_argument_group('operator observability')
    group.add_argument('--log-json', action='store_true',
                       help='write redacted JSON-line operational logs to standard error')
    if stdio:
        group.add_argument('--health', action='store_true',
                           help='check configuration and state, print a readiness report, exit 0 when ready')
    else:
        group.add_argument('--ops-port', type=int, metavar='PORT',
                           help='serve /healthz, /readyz and /metrics on 127.0.0.1:PORT (off by default)')
    return group


def start(ops, args, stream=None):
    """Apply the parsed operator options after the service state is open."""
    if getattr(args, 'log_json', False):
        ops.log.enable(stream if stream is not None else sys.stderr)
    port = getattr(args, 'ops_port', None)
    if port is not None:
        ops.serve(port)
    ops.log.event('service_start', version=ops.health.version, pid=os.getpid())
    return ops


def health_report(ops, stream=None):
    """Print the readiness report for a stdio service. Returns the process exit code."""
    ready, report = ops.health.ready()
    (stream if stream is not None else sys.stdout).write(json.dumps(report, sort_keys=True) + '\n')
    return 0 if ready else 1


def writable_directory(path):
    """Readiness check: the directory exists, is not a symlink and accepts a new file."""
    def check():
        if not os.path.isdir(path) or os.path.islink(path):
            return 'STORE_DIRECTORY_MISSING'
        if not os.access(path, os.W_OK | os.X_OK):
            return 'STORE_DIRECTORY_READ_ONLY'
        return True
    return check
