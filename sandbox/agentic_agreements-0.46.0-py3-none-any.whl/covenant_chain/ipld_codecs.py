"""Multiformats and IPLD codecs, computed locally, for content-addressed AAP bytes.

GRAFT: AAP writes and reads the IPFS wire formats unchanged, so any IPFS node,
gateway, CAR tool or pinning service can carry AAP bytes and AAP needs none of
them. A block is used only after it hashes to its CID; a mismatch is refused,
never repaired.

* unsigned-varint (multiformats/unsigned-varint): minimal LEB128, at most 9 bytes.
* multihash (multiformats/multihash): sha2-256 (0x12) with a 32-byte digest only.
* multibase (multiformats/multibase): base32 lower case without padding ("b",
  RFC 4648 section 6) for CIDv1 text, base58btc ("z") accepted on read; CIDv0 is
  bare base58btc.
* CID (multiformats/cid): CIDv1 is <varint 1><varint codec><multihash>; CIDv0 is a
  sha2-256 multihash that names dag-pb.
* multicodec (multiformats/multicodec table.csv): raw 0x55, dag-pb 0x70, dag-cbor 0x71.
* DAG-PB (ipld/ipld specs/codecs/dag-pb/spec.md, "Descriptive - Final"): Links
  first when writing; reading refuses unknown fields and wire types, duplicates,
  PBLink fields out of order, interleaved Links and Data, a missing Hash and
  non-minimal varints, and accepts Data first as the spec requires.
* UnixFS v1 Data message (ipfs/specs src/unixfs.md): Type, Data, filesize,
  blocksizes (protobuf 2, not packed), mode and mtime kept opaque on read.
* DAG-CBOR (ipld/ipld specs/codecs/dag-cbor/spec.md): RFC 8949 section 4.2.1
  deterministic CBOR, string map keys sorted length first, tag 42 links over the
  0x00 identity multibase prefix. AAP writes no floats and refuses them on read.
* CARv1 (ipld/ipld specs/transport/car/carv1/index.md, "Final"): a DAG-CBOR header
  {roots, version: 1}, then varint-framed (CID, block) sections.

covenant_chain/cbor.py stays the DTN profile; it refuses tags by design.
Nothing here fetches, pins, announces or publishes.
"""
import base64
import hashlib

from .crypto import need
from . import interop_codec as codec

RAW, DAG_PB, DAG_CBOR = 0x55, 0x70, 0x71
CODECS = {RAW: 'raw', DAG_PB: 'dag-pb', DAG_CBOR: 'dag-cbor'}
SHA2_256 = 0x12
MAX_BLOCK = 2 * 1024 * 1024
MAX_LINKS = 4096
MAX_NAME = 255
MAX_DEPTH = 32
MAX_ITEMS = 4096
MAX_CAR = 64 * 1024 * 1024
MAX_CAR_BLOCKS = 65536
MAX_ROOTS = 64
UNIXFS_TYPES = {0: 'Raw', 1: 'Directory', 2: 'File', 3: 'Metadata', 4: 'Symlink', 5: 'HAMTShard'}

REMEDIATION = {
    'IPLD_VARINT': 'Use a minimal unsigned varint of at most 9 bytes (multiformats/unsigned-varint).',
    'IPLD_TYPE': 'Pass bytes for blocks and binary CIDs, and str for CID text.',
    'IPLD_BLOCK_SIZE': 'Keep each block at or below 2 MiB; split larger content into a UnixFS DAG.',
    'CID_SYNTAX': 'Use CIDv1 text in base32 ("b...") or base58btc ("z..."), CIDv0 text ("Qm..."), or binary CID bytes.',
    'CID_VERSION': 'Use CIDv1, or CIDv0 for a dag-pb block.',
    'CID_CODEC': 'Use the raw (0x55), dag-pb (0x70) or dag-cbor (0x71) codec.',
    'CID_HASH': 'Use a sha2-256 multihash (0x12) with a 32-byte digest; other hashes are not verified here.',
    'CID_MISMATCH': 'The bytes do not hash to the CID; fetch the block again from another source.',
    'DAGPB_FIELD': 'Encode only PBNode Links (2) and Data (1) and PBLink Hash (1), Name (2) and Tsize (3).',
    'DAGPB_ORDER': 'Write PBLink fields as Hash, Name, Tsize and keep Links contiguous (dag-pb spec, Protobuf Strictness).',
    'DAGPB_DUPLICATE': 'Give each field once per message; only Links repeats.',
    'DAGPB_TRUNCATED': 'Supply the complete block; a length runs past its end.',
    'DAGPB_HASH': 'Every PBLink needs a Hash that is a valid binary CID.',
    'DAGPB_NAME': 'Use a UTF-8 link name of at most 255 bytes.',
    'DAGPB_LINKS': 'Keep a node at or below 4096 links.',
    'UNIXFS_DATA': 'Encode a UnixFS v1 Data message: Type, then Data, filesize, blocksizes, mode, mtime in field order.',
    'UNIXFS_TYPE': 'Use a UnixFS File, Directory or legacy Raw node.',
    'DAGCBOR_ENCODING': 'Use deterministic DAG-CBOR: shortest heads, definite lengths, no trailing bytes.',
    'DAGCBOR_TYPE': 'Use maps with string keys, lists, strings, bytes, integers, booleans, null and links.',
    'DAGCBOR_FLOAT': 'AAP DAG-CBOR objects carry no floats; encode numbers as integers.',
    'DAGCBOR_TAG': 'Only tag 42 (an IPLD link written as 0xd82a) is allowed.',
    'DAGCBOR_MAP_ORDER': 'Sort map keys by encoded bytes (length first) with no duplicates.',
    'DAGCBOR_UTF8': 'Strings must be valid UTF-8.',
    'DAGCBOR_DEPTH': 'Nest at most 32 levels.',
    'DAGCBOR_ITEMS': 'Keep each list or map at or below 4096 entries.',
    'DAGCBOR_INTEGER': 'Integers must lie within the 64-bit CBOR range.',
    'CAR_HEADER': 'Start with a DAG-CBOR header {roots: [link, ...], version: 1} holding 1 to 64 roots.',
    'CAR_SECTION': 'Frame each block as varint(length) || binary CID || block bytes.',
    'CAR_SIZE': 'Keep the archive within the stated byte and block bounds.',
}


def remediation(code):
    return REMEDIATION.get(code, codec.remediation(code))


# Unsigned varints.

def varint(value):
    need(type(value) is int and 0 <= value < 1 << 63, 'IPLD_VARINT')
    out = bytearray()
    while True:
        byte, value = value & 0x7f, value >> 7
        if not value:
            out.append(byte)
            return bytes(out)
        out.append(byte | 0x80)


def read_varint(raw, offset=0, code='IPLD_VARINT'):
    """(value, next offset); refuses a non-minimal or over-long (more than 9 bytes) varint."""
    value = 0
    for index in range(9):
        need(offset + index < len(raw), code)
        byte = raw[offset + index]
        value |= (byte & 0x7f) << 7 * index
        if not byte & 0x80:
            need(index == 0 or byte != 0, code)
            return value, offset + index + 1
    raise ValueError(code)


# Multihash, multibase and CIDs.

def multihash(data):
    need(type(data) is bytes, 'IPLD_TYPE')
    return bytes([SHA2_256, 32]) + hashlib.sha256(data).digest()


def cid(codec_code, data):
    """Binary CIDv1 of ``data`` under ``codec_code`` and a sha2-256 multihash."""
    need(codec_code in CODECS, 'CID_CODEC')
    return varint(1) + varint(codec_code) + multihash(data)


def _base32(raw):
    return base64.b32encode(raw).decode('ascii').lower().rstrip('=')


def _unbase32(text):
    need(len(text) <= 160 and all(c in 'abcdefghijklmnopqrstuvwxyz234567' for c in text), 'CID_SYNTAX')
    try:
        raw = base64.b32decode(text.upper() + '=' * (-len(text) % 8))
    except ValueError:
        raise ValueError('CID_SYNTAX') from None
    need(_base32(raw) == text, 'CID_SYNTAX')
    return raw


def _parse_binary(raw, offset=0):
    """Parse one binary CID at ``offset``; returns (fields, next offset)."""
    if raw[offset:offset + 2] == b'\x12\x20':
        end = offset + 34
        need(end <= len(raw), 'CID_SYNTAX')
        return {'version': 0, 'codec': DAG_PB, 'digest': raw[offset + 2:end], 'binary': raw[offset:end]}, end
    version, cursor = read_varint(raw, offset, 'CID_SYNTAX')
    need(version == 1, 'CID_VERSION')
    codec_code, cursor = read_varint(raw, cursor, 'CID_SYNTAX')
    need(codec_code in CODECS, 'CID_CODEC')
    hash_code, cursor = read_varint(raw, cursor, 'CID_SYNTAX')
    size, cursor = read_varint(raw, cursor, 'CID_SYNTAX')
    need(hash_code == SHA2_256 and size == 32, 'CID_HASH')
    end = cursor + 32
    need(end <= len(raw), 'CID_SYNTAX')
    return {'version': 1, 'codec': codec_code, 'digest': raw[cursor:end], 'binary': raw[offset:end]}, end


def read_cid(raw, offset=0):
    """A binary CID embedded at ``offset`` (a CAR section, a dag-pb Hash); returns (parsed, next offset)."""
    need(type(raw) is bytes and type(offset) is int and 0 <= offset < len(raw), 'CID_SYNTAX')
    fields, end = _parse_binary(raw, offset)
    return _finish(fields), end


def _finish(fields):
    binary = fields['binary']
    text = codec.base58btc(binary) if fields['version'] == 0 else 'b' + _base32(binary)
    return {**fields, 'codec_name': CODECS[fields['codec']], 'text': text}


def parse_cid(value):
    """Exactly one CID, given as text or binary bytes: version, codec, digest, binary and canonical text."""
    if type(value) is bytes:
        need(0 < len(value) <= 64, 'CID_SYNTAX')
        fields, end = _parse_binary(value)
        need(end == len(value), 'CID_SYNTAX')
        return _finish(fields)
    need(type(value) is str and 2 <= len(value) <= 160 and value.isascii(), 'CID_SYNTAX')
    if value.startswith('Qm') and len(value) == 46:
        try:
            raw = codec.base58btc_decode(value, 34)
        except ValueError:
            raise ValueError('CID_SYNTAX') from None
    elif value[0] == 'b':
        raw = _unbase32(value[1:])
    elif value[0] == 'z':
        try:
            raw = codec.base58btc_decode(value[1:])
        except ValueError:
            raise ValueError('CID_SYNTAX') from None
        need(raw[:2] != b'\x12\x20', 'CID_SYNTAX')  # CIDv0 has no multibase prefix
    else:
        raise ValueError('CID_SYNTAX')
    return parse_cid(raw)


def cid_text(value):
    return parse_cid(value)['text']


def verify_block(cid_value, data):
    """The parsed CID when ``data`` hashes to it; CID_MISMATCH otherwise."""
    parsed = parse_cid(cid_value)
    need(type(data) is bytes, 'IPLD_TYPE')
    need(len(data) <= MAX_BLOCK, 'IPLD_BLOCK_SIZE')
    need(hashlib.sha256(data).digest() == parsed['digest'], 'CID_MISMATCH')
    return parsed


# Protobuf fields shared by DAG-PB and UnixFS.

def _field(raw, offset, code, truncated):
    """(field number, wire type, value, next offset) for wire types 0 and 2."""
    key, offset = read_varint(raw, offset, code)
    number, wire = key >> 3, key & 7
    need(number > 0, code)
    if wire == 0:
        value, offset = read_varint(raw, offset, code)
        return number, wire, value, offset
    need(wire == 2, code)
    size, offset = read_varint(raw, offset, code)
    need(offset + size <= len(raw), truncated)
    return number, wire, raw[offset:offset + size], offset + size


def _bytes_field(number, value):
    return varint(number << 3 | 2) + varint(len(value)) + value


def _name(value):
    need(type(value) is str, 'DAGPB_NAME')
    try:
        raw = value.encode('utf-8')
    except UnicodeError:
        raise ValueError('DAGPB_NAME') from None
    need(len(raw) <= MAX_NAME, 'DAGPB_NAME')
    return raw


def dagpb_encode(links, data=None):
    """PBNode bytes, Links first. ``links`` are {'hash': binary CID, 'name': str or None, 'tsize': int or None}.

    Links are written in the order given: directories sort by name before calling.
    """
    need(type(links) is list and len(links) <= MAX_LINKS, 'DAGPB_LINKS')
    out = bytearray()
    for link in links:
        need(type(link) is dict and set(link) <= {'hash', 'name', 'tsize'} and 'hash' in link, 'DAGPB_FIELD')
        try:
            target = parse_cid(link['hash'])['binary']
        except ValueError:
            raise ValueError('DAGPB_HASH') from None
        body = _bytes_field(1, target)
        if link.get('name') is not None:
            body += _bytes_field(2, _name(link['name']))
        if link.get('tsize') is not None:
            body += varint(3 << 3) + varint(link['tsize'])
        out += _bytes_field(2, body)
    if data is not None:
        need(type(data) is bytes and len(data) <= MAX_BLOCK, 'IPLD_TYPE')
        out += _bytes_field(1, data)
    return bytes(out)


def _decode_link(raw):
    link, last = {'hash': None, 'name': None, 'tsize': None}, 0
    offset = 0
    while offset < len(raw):
        number, wire, value, offset = _field(raw, offset, 'DAGPB_FIELD', 'DAGPB_TRUNCATED')
        need(number in (1, 2, 3) and wire == (0 if number == 3 else 2), 'DAGPB_FIELD')
        need(number != last, 'DAGPB_DUPLICATE')
        need(number > last, 'DAGPB_ORDER')
        last = number
        if number == 1:
            try:
                link['hash'] = parse_cid(value)['binary']
            except ValueError:
                raise ValueError('DAGPB_HASH') from None
        elif number == 2:
            try:
                link['name'] = value.decode('utf-8')
            except UnicodeError:
                raise ValueError('DAGPB_NAME') from None
            need(len(value) <= MAX_NAME, 'DAGPB_NAME')
        else:
            link['tsize'] = value
    need(link['hash'] is not None, 'DAGPB_HASH')
    return link


def dagpb_decode(raw):
    """{'links': [...], 'data': bytes or None}; accepts Links-first and Data-first, nothing else."""
    need(type(raw) is bytes and len(raw) <= MAX_BLOCK, 'IPLD_BLOCK_SIZE')
    links, data, links_before_data = [], None, False
    offset = 0
    while offset < len(raw):
        number, wire, value, offset = _field(raw, offset, 'DAGPB_FIELD', 'DAGPB_TRUNCATED')
        need(wire == 2 and number in (1, 2), 'DAGPB_FIELD')
        if number == 1:
            need(data is None, 'DAGPB_DUPLICATE')
            data, links_before_data = value, bool(links)
        else:
            need(not links_before_data, 'DAGPB_ORDER')
            need(len(links) < MAX_LINKS, 'DAGPB_LINKS')
            links.append(_decode_link(value))
    return {'links': links, 'data': data}


def unixfs_encode(kind, *, data=None, filesize=None, blocksizes=()):
    """A UnixFS v1 Data message for a File (2) or Directory (1); fields in number order, blocksizes unpacked."""
    need(kind in (1, 2), 'UNIXFS_TYPE')
    out = varint(1 << 3) + varint(kind)
    if data is not None:
        need(type(data) is bytes, 'UNIXFS_DATA')
        out += _bytes_field(2, data)
    if filesize is not None:
        out += varint(3 << 3) + varint(filesize)
    need(type(blocksizes) in (list, tuple), 'UNIXFS_DATA')
    for size in blocksizes:
        out += varint(4 << 3) + varint(size)
    return out


def unixfs_decode(raw):
    """{'type', 'data', 'filesize', 'blocksizes', 'mode', 'mtime'}; refuses unknown, repeated or out-of-order fields."""
    need(type(raw) is bytes, 'UNIXFS_DATA')
    out = {'type': None, 'data': None, 'filesize': None, 'blocksizes': [], 'hash_type': None, 'fanout': None,
           'mode': None, 'mtime': None}
    names = {1: 'type', 2: 'data', 3: 'filesize', 5: 'hash_type', 6: 'fanout', 7: 'mode', 8: 'mtime'}
    last, offset = 0, 0
    while offset < len(raw):
        number, wire, value, offset = _field(raw, offset, 'UNIXFS_DATA', 'UNIXFS_DATA')
        need(1 <= number <= 8 and wire == (2 if number in (2, 8) else 0), 'UNIXFS_DATA')
        need(number > last or (number == last == 4), 'UNIXFS_DATA')
        last = number
        if number == 4:
            need(len(out['blocksizes']) < MAX_LINKS, 'UNIXFS_DATA')
            out['blocksizes'].append(value)
        else:
            out[names[number]] = value
    need(out['type'] in UNIXFS_TYPES, 'UNIXFS_DATA')
    out['type_name'] = UNIXFS_TYPES[out['type']]
    return out


# DAG-CBOR.

class Link:
    """An IPLD link: CBOR tag 42 over 0x00 and the binary CID."""
    __slots__ = ('cid',)

    def __init__(self, value):
        self.cid = parse_cid(value)['binary']

    def __eq__(self, other):
        return isinstance(other, Link) and other.cid == self.cid

    def __hash__(self):
        return hash(self.cid)

    def __repr__(self):
        return f'Link({self.text!r})'

    @property
    def text(self):
        return cid_text(self.cid)


def _head(major, value):
    if value < 24:
        return bytes([major << 5 | value])
    for info, size in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if value < 1 << 8 * size:
            return bytes([major << 5 | info]) + value.to_bytes(size, 'big')
    raise ValueError('DAGCBOR_INTEGER')


def _encode(value, out, depth):
    need(depth <= MAX_DEPTH, 'DAGCBOR_DEPTH')
    if value is None or value is True or value is False:
        out += {None: b'\xf6', True: b'\xf5', False: b'\xf4'}[value]
    elif type(value) is int:
        need(-(1 << 64) <= value < 1 << 64, 'DAGCBOR_INTEGER')
        out += _head(0, value) if value >= 0 else _head(1, -1 - value)
    elif type(value) is bytes:
        out += _head(2, len(value)) + value
    elif type(value) is str:
        try:
            raw = value.encode('utf-8')
        except UnicodeError:
            raise ValueError('DAGCBOR_UTF8') from None
        out += _head(3, len(raw)) + raw
    elif type(value) is Link:
        out += b'\xd8\x2a' + _head(2, len(value.cid) + 1) + b'\x00' + value.cid
    elif type(value) is list:
        need(len(value) <= MAX_ITEMS, 'DAGCBOR_ITEMS')
        out += _head(4, len(value))
        for item in value:
            _encode(item, out, depth + 1)
    elif type(value) is dict:
        need(len(value) <= MAX_ITEMS, 'DAGCBOR_ITEMS')
        pairs = []
        for name, item in value.items():
            need(type(name) is str, 'DAGCBOR_TYPE')
            key = bytearray()
            _encode(name, key, depth + 1)
            pairs.append((bytes(key), item))
        pairs.sort(key=lambda pair: pair[0])
        out += _head(5, len(pairs))
        for key, item in pairs:
            out += key
            _encode(item, out, depth + 1)
    elif type(value) is float:
        raise ValueError('DAGCBOR_FLOAT')
    else:
        raise ValueError('DAGCBOR_TYPE')


def dagcbor_encode(value):
    out = bytearray()
    _encode(value, out, 0)
    need(len(out) <= MAX_BLOCK, 'IPLD_BLOCK_SIZE')
    return bytes(out)


def _argument(raw, offset, info):
    if info < 24:
        return info, offset
    need(info <= 27, 'DAGCBOR_ENCODING')  # 28-30 are reserved and 31 is indefinite length
    size = 1 << info - 24
    need(offset + size <= len(raw), 'DAGCBOR_ENCODING')
    value = int.from_bytes(raw[offset:offset + size], 'big')
    need(value >= (24 if size == 1 else 1 << 4 * size), 'DAGCBOR_ENCODING')
    return value, offset + size


def _item(raw, offset, depth):
    need(depth <= MAX_DEPTH, 'DAGCBOR_DEPTH')
    need(offset < len(raw), 'DAGCBOR_ENCODING')
    major, info = raw[offset] >> 5, raw[offset] & 0x1f
    offset += 1
    if major == 7:
        need(info not in (25, 26, 27), 'DAGCBOR_FLOAT')
        need(info in (20, 21, 22), 'DAGCBOR_TYPE')
        return (False, True, None)[info - 20], offset
    if major == 6:
        need(info == 24 and raw[offset:offset + 1] == b'\x2a', 'DAGCBOR_TAG')
        payload, offset = _item(raw, offset + 1, depth + 1)
        need(type(payload) is bytes and payload[:1] == b'\x00', 'DAGCBOR_TAG')
        try:
            return Link(payload[1:]), offset
        except ValueError:
            raise ValueError('DAGCBOR_TAG') from None
    value, offset = _argument(raw, offset, info)
    if major == 0:
        return value, offset
    if major == 1:
        return -1 - value, offset
    if major in (2, 3):
        need(value <= len(raw) - offset, 'DAGCBOR_ENCODING')
        data = raw[offset:offset + value]
        if major == 2:
            return data, offset + value
        try:
            return data.decode('utf-8'), offset + value
        except UnicodeError:
            raise ValueError('DAGCBOR_UTF8') from None
    need(value <= MAX_ITEMS, 'DAGCBOR_ITEMS')
    if major == 4:
        items = []
        for _ in range(value):
            item, offset = _item(raw, offset, depth + 1)
            items.append(item)
        return items, offset
    result, previous = {}, None
    for _ in range(value):
        start = offset
        need(offset < len(raw) and raw[offset] >> 5 == 3, 'DAGCBOR_TYPE')
        name, offset = _item(raw, offset, depth + 1)
        key = raw[start:offset]
        # Bytewise order of the encoded keys sorts length first; strictly rising also refuses duplicates.
        need(previous is None or key > previous, 'DAGCBOR_MAP_ORDER')
        previous = key
        result[name], offset = _item(raw, offset, depth + 1)
    return result, offset


def dagcbor_decode(raw):
    """Exactly one deterministic DAG-CBOR item with no trailing bytes; links come back as Link."""
    need(type(raw) is bytes and len(raw) <= MAX_BLOCK, 'IPLD_BLOCK_SIZE')
    value, end = _item(raw, 0, 0)
    need(end == len(raw), 'DAGCBOR_ENCODING')
    return value


def links_of(codec_code, data):
    """Binary CIDs a block links to, in block order: dag-pb links or DAG-CBOR tag 42 links."""
    if codec_code == RAW:
        return []
    if codec_code == DAG_PB:
        return [link['hash'] for link in dagpb_decode(data)['links']]
    need(codec_code == DAG_CBOR, 'CID_CODEC')
    found, stack = [], [dagcbor_decode(data)]
    while stack:
        item = stack.pop()
        if type(item) is Link:
            found.append(item.cid)
        elif type(item) is list:
            stack.extend(reversed(item))
        elif type(item) is dict:
            stack.extend(reversed(list(item.values())))  # decoded maps keep their encoded order
    return found


# CARv1.

def car_encode(roots, blocks):
    """CARv1 bytes: roots (CIDs) and blocks [(CID, bytes)], each block checked against its CID first."""
    need(type(roots) in (list, tuple) and 1 <= len(roots) <= MAX_ROOTS, 'CAR_HEADER')
    header = dagcbor_encode({'roots': [Link(root) for root in roots], 'version': 1})
    out = bytearray(varint(len(header)) + header)
    need(type(blocks) in (list, tuple) and len(blocks) <= MAX_CAR_BLOCKS, 'CAR_SIZE')
    for cid_value, data in blocks:
        parsed = verify_block(cid_value, data)
        section = parsed['binary'] + data
        out += varint(len(section)) + section
        need(len(out) <= MAX_CAR, 'CAR_SIZE')
    return bytes(out)


def car_decode(raw, *, max_bytes=MAX_CAR, max_blocks=MAX_CAR_BLOCKS):
    """{'roots': [CID text], 'blocks': {CID text: bytes}, 'order': [CID text]}; every block verified.

    A repeated identical block is kept once. Roots are listed, not trusted: a root
    without its block in the archive is reported in 'missing_roots'.
    """
    need(type(raw) is bytes and len(raw) <= max_bytes, 'CAR_SIZE')
    try:
        size, offset = read_varint(raw, 0)
    except ValueError:
        raise ValueError('CAR_HEADER') from None
    need(0 < size <= MAX_BLOCK and offset + size <= len(raw), 'CAR_HEADER')
    try:
        header = dagcbor_decode(raw[offset:offset + size])
    except ValueError:
        raise ValueError('CAR_HEADER') from None
    need(type(header) is dict and set(header) == {'roots', 'version'} and header['version'] == 1
         and type(header['roots']) is list and 1 <= len(header['roots']) <= MAX_ROOTS
         and all(type(root) is Link for root in header['roots']), 'CAR_HEADER')
    offset += size
    blocks, order = {}, []
    while offset < len(raw):
        try:
            length, offset = read_varint(raw, offset)
        except ValueError:
            raise ValueError('CAR_SECTION') from None
        end = offset + length
        need(0 < length and end <= len(raw), 'CAR_SECTION')
        try:
            parsed, start = read_cid(raw, offset)
        except ValueError:
            raise ValueError('CAR_SECTION') from None
        need(start <= end, 'CAR_SECTION')
        data = raw[start:end]
        verify_block(parsed['binary'], data)
        if parsed['text'] not in blocks:
            need(len(blocks) < max_blocks, 'CAR_SIZE')
            blocks[parsed['text']] = data
            order.append(parsed['text'])
        offset = end
    roots = [root.text for root in header['roots']]
    return {'roots': roots, 'blocks': blocks, 'order': order,
            'missing_roots': [root for root in roots if root not in blocks]}


def describe():
    return {'module': 'covenant_chain.ipld_codecs', 'status': 'EXPERIMENTAL_CODEC',
            'cid': 'CIDV1_BASE32_AND_CIDV0_READ', 'multihash': 'SHA2_256_ONLY', 'codecs': sorted(CODECS.values()),
            'dag_pb': 'LINKS_FIRST_WRITE_STRICT_READ', 'dag_cbor': 'DETERMINISTIC_TAG_42_NO_FLOATS',
            'car': 'CARV1_VERIFIED_BLOCKS', 'unixfs_types_read': ['Raw', 'Directory', 'File'],
            'limits': {'block_bytes': MAX_BLOCK, 'links': MAX_LINKS, 'name_bytes': MAX_NAME, 'depth': MAX_DEPTH,
                       'items': MAX_ITEMS, 'car_bytes': MAX_CAR, 'car_blocks': MAX_CAR_BLOCKS},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
