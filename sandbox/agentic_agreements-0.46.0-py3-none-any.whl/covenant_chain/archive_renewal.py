"""Optional offline archival continuity companions; originals are never rewritten.

Records authenticate exact preservation assertions and reference dependencies.
The recipient independently adopts keys, verifier code and time-source policies.
A renewal cannot repair past false evidence, broken provenance or an already
obsolete signature suite. Nothing here broadcasts, timestamps or reads a clock.
"""
from copy import deepcopy
import base64
import hashlib
import io
import json
from pathlib import Path
import re
import tempfile
import zipfile

from . import archive
from .crypto import canonical as signature_canonical, loads as native_loads, verification_key, verify

VERSION = 'covenant-archive-continuity/0.1'
PACKAGE = 'covenant-archive-continuity-package/0.1'
LABEL = 'AAP-ARCHIVE-CONTINUITY-0.1'
MAX_ARCHIVE = 2_000_000
MAX_PACKAGE = 4_000_000
KINDS = ('VERIFIER', 'CHECKPOINT_REFERENCE', 'QUANTUM_ATTESTATION', 'QUANTUM_SUCCESSION', 'TIME_POLICY', 'TIME_BUNDLE')
FLAGS = {'execution_authorized': False, 'broadcast': False, 'source_rewritten': False,
         'global_currentness_verified': False, 'future_cryptographic_security_guaranteed': False}


def _need(ok, code):
    if not ok: raise ValueError(code)


def _canonical(value):
    nodes = 0
    def visit(v, depth=0):
        nonlocal nodes
        nodes += 1; _need(nodes <= 100000 and depth <= 32, 'ARCHIVE_RENEWAL_COMPLEXITY')
        if v is None or type(v) is bool: return
        if type(v) is int:
            _need(abs(v) <= 2**53-1, 'ARCHIVE_RENEWAL_INTEGER'); return
        if type(v) is str:
            _need(len(v) <= 3000000 and v.isascii() and all(32 <= ord(c) <= 126 for c in v), 'ARCHIVE_RENEWAL_TEXT'); return
        if type(v) is list:
            _need(len(v) <= 256, 'ARCHIVE_RENEWAL_ARRAY')
            for item in v: visit(item, depth+1)
            return
        _need(type(v) is dict and len(v) <= 128, 'ARCHIVE_RENEWAL_OBJECT')
        for key, item in v.items():
            _need(type(key) is str and 0 < len(key) <= 128 and key.isascii(), 'ARCHIVE_RENEWAL_KEY')
            visit(item, depth+1)
    visit(value)
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')
    _need(len(raw) <= MAX_PACKAGE, 'ARCHIVE_RENEWAL_SIZE')
    return raw


def _fields(value, names):
    _need(type(value) is dict and set(value) == set(names.split()), 'ARCHIVE_RENEWAL_FIELDS')


def _hash(value, size=64):
    _need(type(value) is str and re.fullmatch('[0-9a-f]{' + str(size) + '}', value) is not None, 'ARCHIVE_RENEWAL_REFERENCE')


def _id(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + _canonical(value)).hexdigest()


def _error(error):
    value = str(error)
    return value if re.fullmatch('[A-Z][A-Z0-9_]{0,95}', value) else 'ARCHIVE_RENEWAL_CHECK_FAILED'


def verifier_descriptor():
    """Pin the local historical verifier bytes; never execute a carried program."""
    root = Path(archive.__file__).resolve().parent
    dependencies = {'covenant_chain.crypto': root / 'crypto.py', 'covenant_chain.proofs': root / 'proofs.py',
                    'covenant_chain.time_evidence': root / 'time_evidence.py',
                    'covenant_language.quantum': root.parent / 'covenant_language' / 'quantum.py'}
    return {'version': 'covenant-archive-verifier/0.1', 'implementation': 'covenant_chain.archive.restore',
            'archive_profile': 'covenant-native-archive/0.1',
            'source_sha256': hashlib.sha256(Path(archive.__file__).read_bytes()).hexdigest(),
            'direct_dependency_sources': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(dependencies.items())},
            'dependency_closure': 'PINNED_MAINTAINED_VERIFIER_FILES_ONLY; TRANSITIVE_RUNTIME_AND_LIBRARIES_NOT_BUNDLED'}


def artifact(kind, value):
    _need(type(kind) is str and 0 < len(kind) <= 64, 'ARCHIVE_RENEWAL_ARTIFACT_KIND')
    _canonical(value)
    _need(not archive.off_chain_payloads([value]), 'ARCHIVE_OFF_CHAIN_PAYLOAD')
    body = {'kind': kind, 'value': deepcopy(value)}
    return {'id': _id('AAP-ARCHIVE-ARTIFACT-0.1', body), **body}


def validate(body):
    _canonical(body)
    _fields(body, 'version context archive previous predecessor_verifier checkpoint verifier signer attestation succession time_policy time_evidence')
    _need(body['version'] == VERSION, 'ARCHIVE_RENEWAL_VERSION'); _hash(body['context'])
    _fields(body['archive'], 'profile sha512 chain head height')
    original = body['archive']
    _need(type(original['profile']) is str and len(original['profile']) <= 128, 'ARCHIVE_RENEWAL_PROFILE')
    _hash(original['sha512'], 128); _hash(original['chain']); _hash(original['head'])
    _need(type(original['height']) is int and 0 <= original['height'] <= 100000, 'ARCHIVE_RENEWAL_HEIGHT')
    for field in ('previous', 'predecessor_verifier', 'checkpoint', 'verifier', 'attestation', 'succession', 'time_policy'):
        if body[field] is not None: _hash(body[field])
    _need(body['verifier'] is not None, 'ARCHIVE_RENEWAL_VERIFIER_REQUIRED')
    _need((body['previous'] is None) == (body['predecessor_verifier'] is None), 'ARCHIVE_RENEWAL_PREDECESSOR')
    verification_key(body['signer'])
    if body['time_evidence'] is not None:
        _fields(body['time_evidence'], 'bundle policy')
        _hash(body['time_evidence']['bundle']); _hash(body['time_evidence']['policy'])
        _need(body['time_policy'] is not None, 'ARCHIVE_RENEWAL_TIME_POLICY')
    # Signature material is always historical crypto canonical bytes.
    signature_canonical(body)
    return True


def prepare(body):
    validate(body)
    return {'body': deepcopy(body), 'assent_payload': {'label': LABEL, 'body': deepcopy(body)},
            'status': 'UNSIGNED_PRESERVATION_ASSERTION', **FLAGS}


def identifier(record):
    _fields(record, 'body signature'); validate(record['body'])
    _need(type(record['signature']) is str and len(record['signature']) <= 8192, 'ARCHIVE_RENEWAL_SIGNATURE')
    return _id('AAP-ARCHIVE-RECORD-0.1', record)


def time_subject(body):
    """Break proof-reference recursion; final signature binds the proof references."""
    validate(body); source = deepcopy(body); source['time_evidence'] = None
    return _id('AAP-ARCHIVE-TIME-SUBJECT-0.1', source)


def package_identifier(package):
    return _id('AAP-ARCHIVE-PACKAGE-0.1', package)


def _original(data, metadata, known_private=()):
    """Use the actual historical archive verifier over an exact temporary copy."""
    _need(type(data) is bytes and 1 <= len(data) <= MAX_ARCHIVE, 'ARCHIVE_RENEWAL_ARCHIVE_BOUND')
    _need(hashlib.sha512(data).hexdigest() == metadata['sha512'], 'ARCHIVE_RENEWAL_ARCHIVE_PIN')
    if metadata['profile'] != 'covenant-native-archive/0.1':
        return {'status': 'UNSUPPORTED_ARCHIVE_PROFILE', 'archive_sha512': metadata['sha512']}
    # Preflight decompression before the existing restore code reads any member.
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos = z.infolist()
        _need(len(infos) <= 100002 and len({i.filename for i in infos}) == len(infos), 'ARCHIVE_ENTRIES')
        _need(all(i.file_size <= 4000000 for i in infos) and sum(i.file_size for i in infos) <= 16_000_000, 'ARCHIVE_RENEWAL_EXPANSION_BOUND')
        _need(all(not i.flag_bits & 1 for i in infos), 'ARCHIVE_RENEWAL_ENCRYPTED_ZIP')
        _need(all(i.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED, zipfile.ZIP_BZIP2, zipfile.ZIP_LZMA) for i in infos), 'ARCHIVE_RENEWAL_UNSUPPORTED_COMPRESSION')
        # Recognized off-chain/private payloads are refused, not copied into exports.
        values = [native_loads(z.read(i.filename)) for i in infos if i.filename in ('genesis.json', 'manifest.json') or i.filename.startswith('history/')]
        _need(not archive.off_chain_payloads(values, known_private), 'ARCHIVE_OFF_CHAIN_PAYLOAD')
    with tempfile.TemporaryDirectory(prefix='aap-archive-check-') as directory:
        path = Path(directory) / 'original.zip'; path.write_bytes(data)
        checked = archive.restore(path, metadata['sha512'], metadata['chain'], metadata['height'])
    _need(checked['height'] == metadata['height'] and checked['head'] == metadata['head'], 'ARCHIVE_RENEWAL_HEAD_PIN')
    return {'status': 'EXACT_NATIVE_HISTORY_VERIFIED', 'archive_sha512': metadata['sha512'],
            'chain': checked['chain'], 'head': checked['head'], 'height': checked['height'],
            'scope': 'HISTORICAL_LOCAL_REPLAY; NO_GLOBAL_FINALITY_OR_CURRENTNESS'}


def export_package(original, records, artifacts, *, context, audience=None, known_private=()):
    """Explicitly export selected exact bytes; no inferred dependency collection."""
    _hash(context)
    if audience is not None: _hash(audience)
    _need(type(records) is list and 1 <= len(records) <= 64 and type(artifacts) is list and len(artifacts) <= 128, 'ARCHIVE_RENEWAL_PACKAGE_BOUND')
    for record in records: identifier(record)
    _need(all(r['body']['context'] == context for r in records), 'ARCHIVE_RENEWAL_CONTEXT')
    metadata = records[0]['body']['archive']
    _need(all(r['body']['archive'] == metadata for r in records), 'ARCHIVE_RENEWAL_ORIGINAL_MISMATCH')
    original_check = _original(original, metadata, known_private)
    selected = []
    for entry in artifacts:
        _fields(entry, 'id kind value')
        expected = artifact(entry['kind'], entry['value'])
        _need(expected == entry, 'ARCHIVE_RENEWAL_ARTIFACT_PIN'); selected.append(deepcopy(entry))
    package = {'version': PACKAGE, 'context': context, 'audience': audience,
        'archive': {'profile': metadata['profile'], 'sha512': metadata['sha512'], 'bytes_base64': base64.b64encode(original).decode('ascii')},
        'records': sorted(deepcopy(records), key=identifier), 'artifacts': sorted(selected, key=lambda r: r['id'])}
    _canonical(package)
    return {'package': package, 'id': package_identifier(package), 'original_bytes_preserved': True, 'original_check': original_check,
            'signature_check': 'NOT_PERFORMED_ON_EXPORT; RECIPIENT_POLICY_REQUIRED',
            'privacy': 'EXPLICIT_SELECTED_EXPORT; NOT_ENCRYPTION; HASHES_AND_PUBLIC_HISTORY_MAY_BE_IDENTIFYING', **FLAGS}


def encode_package(package):
    """Deterministic integer-only JSON; does not verify trust or write a file."""
    return _canonical(package)


def decode_package(raw):
    _need(type(raw) is bytes and len(raw) <= MAX_PACKAGE, 'ARCHIVE_RENEWAL_SIZE')
    def pairs(items):
        result = {}
        for key, value in items:
            _need(key not in result, 'ARCHIVE_RENEWAL_DUPLICATE_FIELD'); result[key] = value
        return result
    def bad(_): raise ValueError('ARCHIVE_RENEWAL_NUMBER')
    try: value = json.loads(raw, object_pairs_hook=pairs, parse_float=bad, parse_constant=bad)
    except (UnicodeError, json.JSONDecodeError, RecursionError): raise ValueError('ARCHIVE_RENEWAL_JSON') from None
    _need(_canonical(value) == raw, 'ARCHIVE_RENEWAL_NONCANONICAL_PACKAGE')
    return value


def _quantum_keys(keys):
    _need(type(keys) is dict and len(keys) <= 32, 'ARCHIVE_RENEWAL_KEY_POLICY')
    output = {}
    for key_id, entry in keys.items():
        _need(type(key_id) is str and len(key_id) <= 128, 'ARCHIVE_RENEWAL_KEY_POLICY')
        _fields(entry, 'suite public_key')
        _need(entry['suite'] in ('ML-DSA-65', 'Ed25519') and type(entry['public_key']) is str and
              re.fullmatch('[0-9a-f]+', entry['public_key']) is not None and len(entry['public_key']) <= 8192 and len(entry['public_key']) % 2 == 0, 'ARCHIVE_RENEWAL_KEY_POLICY')
        output[key_id] = {'suite': entry['suite'], 'public_key': bytes.fromhex(entry['public_key'])}
    return output


def import_package(package, *, expected_id, expected_context, trusted_signers, audience=None,
                   expected_tip=None, quantum_keys=None, succession_policies=None,
                   trusted_time_policies=None, known_private=(), include_original=False):
    """Offline verification first. No source is executed or durable state imported.

    ``include_original`` is a separate explicit opening after byte/privacy checks;
    the default result contains pins/statuses and no raw archive/proof bytes.
    """
    _canonical(package); _fields(package, 'version context audience archive records artifacts')
    _need(package['version'] == PACKAGE, 'ARCHIVE_RENEWAL_PACKAGE_VERSION')
    _hash(expected_id); _hash(expected_context)
    _need(package_identifier(package) == expected_id, 'ARCHIVE_RENEWAL_PACKAGE_PIN')
    _need(package['context'] == expected_context, 'ARCHIVE_RENEWAL_CONTEXT')
    if audience is not None: _hash(audience)
    if package['audience'] is not None: _hash(package['audience'])
    _need(package['audience'] is None or package['audience'] == audience, 'ARCHIVE_RENEWAL_AUDIENCE')
    _need(type(include_original) is bool, 'ARCHIVE_RENEWAL_BOOLEAN')
    _need(type(trusted_signers) is list and 1 <= len(trusted_signers) <= 32, 'ARCHIVE_RENEWAL_SIGNERS_REQUIRED')
    for identity in trusted_signers: verification_key(identity)
    signers = {signature_canonical(key) for key in trusted_signers}
    keys = _quantum_keys({} if quantum_keys is None else quantum_keys)
    succession_policies = {} if succession_policies is None else succession_policies
    trusted_time_policies = [] if trusted_time_policies is None else trusted_time_policies
    _need(type(succession_policies) is dict and len(succession_policies) <= 64 and type(trusted_time_policies) is list and len(trusted_time_policies) <= 64, 'ARCHIVE_RENEWAL_POLICY_BOUND')
    for ref in trusted_time_policies: _hash(ref)
    rows = package['records']; entries = package['artifacts']
    _need(type(rows) is list and 1 <= len(rows) <= 64 and type(entries) is list and len(entries) <= 128, 'ARCHIVE_RENEWAL_PACKAGE_BOUND')
    records = {}; artifacts = {}; statuses = []
    for record in rows:
        ref = identifier(record); _need(ref not in records, 'ARCHIVE_RENEWAL_DUPLICATE_RECORD'); records[ref] = record
        _need(record['body']['context'] == expected_context, 'ARCHIVE_RENEWAL_CONTEXT')
    for entry in entries:
        _fields(entry, 'id kind value'); computed = artifact(entry['kind'], entry['value'])
        _need(computed == entry and entry['id'] not in artifacts, 'ARCHIVE_RENEWAL_ARTIFACT_PIN'); artifacts[entry['id']] = entry
    _fields(package['archive'], 'profile sha512 bytes_base64')
    _need(type(package['archive']['bytes_base64']) is str and len(package['archive']['bytes_base64']) <= 4*((MAX_ARCHIVE+2)//3), 'ARCHIVE_RENEWAL_ARCHIVE_BOUND')
    try: original = base64.b64decode(package['archive']['bytes_base64'], validate=True)
    except (ValueError, UnicodeError): raise ValueError('ARCHIVE_RENEWAL_BASE64') from None
    _need(base64.b64encode(original).decode('ascii') == package['archive']['bytes_base64'], 'ARCHIVE_RENEWAL_BASE64')
    metadata = rows[0]['body']['archive']
    _need(all(r['body']['archive'] == metadata for r in rows) and package['archive']['sha512'] == metadata['sha512'] and package['archive']['profile'] == metadata['profile'], 'ARCHIVE_RENEWAL_ORIGINAL_MISMATCH')
    try: original_report = _original(original, metadata, known_private)
    except (ValueError, KeyError, OSError, zipfile.BadZipFile) as error:
        return {'version': VERSION, 'id': expected_id, 'status': 'REFUSED', 'code': _error(error), 'original_bytes_returned': False, **FLAGS}
    missing = []; unsupported = ['UNSUPPORTED_ARTIFACT_KIND:' + e['kind'] for e in entries if e['kind'] not in KINDS]; refused = []; referenced = set()
    local_verifier = artifact('VERIFIER', verifier_descriptor())
    for ref, record in sorted(records.items()):
        body = record['body']; row = {'id': ref, 'previous': body['previous'], 'suite': 'Ed25519' if type(body['signer']) is str else body['signer']['suite'], 'signature': 'NOT_VERIFIED', 'dependencies': []}
        try:
            _need(signature_canonical(body['signer']) in signers, 'ARCHIVE_RENEWAL_SIGNER_NOT_ADOPTED')
            verify(body['signer'], LABEL, body, record['signature']); row['signature'] = 'VERIFIED_PRESERVATION_ASSERTION'
        except (ValueError, TypeError, KeyError) as error:
            row['signature'] = 'REFUSED'; row['code'] = _error(error); refused.append(ref)
        previous = body['previous']
        if previous is not None:
            if previous not in records: missing.append({'record': ref, 'kind': 'PREVIOUS_RECORD', 'id': previous})
            else:
                _need(body['predecessor_verifier'] == records[previous]['body']['verifier'], 'ARCHIVE_RENEWAL_PREDECESSOR_VERIFIER')
        refs = [('VERIFIER', body['verifier']), ('CHECKPOINT_REFERENCE', body['checkpoint']),
                ('QUANTUM_ATTESTATION', body['attestation']), ('QUANTUM_SUCCESSION', body['succession'])]
        if body['time_evidence'] is not None:
            refs += [('TIME_BUNDLE', body['time_evidence']['bundle']), ('TIME_POLICY', body['time_evidence']['policy'])]
        elif body['time_policy'] is not None: missing.append({'record': ref, 'kind': 'TIME_EVIDENCE', 'id': body['time_policy']})
        for kind, target in refs:
            if target is None: continue
            referenced.add(target); entry = artifacts.get(target)
            if entry is None:
                missing.append({'record': ref, 'kind': kind, 'id': target}); continue
            _need(entry['kind'] == kind, 'ARCHIVE_RENEWAL_ARTIFACT_KIND')
            state = 'REFERENCE_PIN_CHECKED'
            if kind == 'VERIFIER' and target != local_verifier['id']:
                state = 'UNSUPPORTED_VERIFIER; NO_CARRIED_CODE_EXECUTED'; unsupported.append(target)
            elif kind == 'CHECKPOINT_REFERENCE':
                state = 'UNASSESSED_CHECKPOINT_REFERENCE; CHECKPOINT_AUTHORITY_NOT_VERIFIED'; unsupported.append(target)
            row['dependencies'].append({'kind': kind, 'id': target, 'status': state})
        # Reuse maintained verifiers, requiring recipient-provided key/suite policy.
        for kind, target in [('QUANTUM_ATTESTATION', body['attestation']), ('QUANTUM_SUCCESSION', body['succession'])]:
            if target is None or target not in artifacts: continue
            value = artifacts[target]['value']
            try:
                if kind == 'QUANTUM_ATTESTATION':
                    with tempfile.TemporaryDirectory(prefix='aap-attestation-check-') as directory:
                        path = Path(directory) / 'original.zip'; path.write_bytes(original)
                        archive.verify_quantum_attestation(path, value, {key: entry['public_key'] for key, entry in keys.items() if entry['suite'] == 'ML-DSA-65'})
                else:
                    from covenant_language import quantum
                    _need(target in succession_policies, 'ARCHIVE_RENEWAL_SUCCESSION_POLICY_REQUIRED')
                    policy = succession_policies[target]
                    _fields(policy, 'expected_previous_root expected_previous_key expected_next_key expected_epoch expected_next_hash')
                    quantum.verify_renewal(original, value, keys=keys, **policy)
                row['dependencies'].append({'kind': kind, 'id': target, 'status': 'ACTUAL_MAINTAINED_VERIFIER_PASSED'})
            except (ValueError, TypeError, KeyError, ImportError) as error:
                refused.append(target); row['dependencies'].append({'kind': kind, 'id': target, 'status': 'REFUSED', 'code': _error(error)})
        if body['time_evidence'] is not None:
            tb = artifacts.get(body['time_evidence']['bundle']); tp = artifacts.get(body['time_evidence']['policy'])
            if tb is not None and tp is not None:
                try:
                    from . import time_evidence as te
                    _need(body['time_policy'] in trusted_time_policies and te.policy_id(tp['value']) == body['time_policy'], 'ARCHIVE_RENEWAL_TIME_POLICY_NOT_ADOPTED')
                    _need(type(tb['value']) is dict and tb['value'].get('subject') == time_subject(body), 'ARCHIVE_RENEWAL_TIME_SUBJECT')
                    assessed = te.assess(tb['value'], tp['value'])
                    row['time'] = {'status': assessed['status'], 'not_before': assessed['not_before'], 'not_after': assessed['not_after'],
                        'policy': assessed['policy'], 'basis': 'ACTUAL_TIME_EVIDENCE_ASSESSMENT_OF_COMPANION_SUBJECT_SEAL; NOT_RENEWAL_EFFECTIVENESS_OR_CURRENTNESS'}
                    if assessed['status'] != 'INTERVAL': unsupported.append(tb['id'])
                except (ValueError, TypeError, KeyError) as error:
                    refused.append(tb['id']); row['time'] = {'status': 'REFUSED', 'code': _error(error)}
        statuses.append(row)
    # Digest-linked records form a finite chain; concurrent successors stay visible.
    roots = sorted(ref for ref, r in records.items() if r['body']['previous'] is None)
    children = {}
    for ref, record in records.items(): children.setdefault(record['body']['previous'], []).append(ref)
    forks = [{'previous': key, 'successors': sorted(value)} for key, value in children.items() if key is not None and len(value) > 1]
    tips = sorted(set(records) - {r['body']['previous'] for r in records.values() if r['body']['previous'] is not None})
    if expected_tip is not None:
        _hash(expected_tip); _need(expected_tip in records and expected_tip in tips, 'ARCHIVE_RENEWAL_EXPECTED_TIP')
    if len(roots) != 1 or forks or len(tips) != 1: unsupported.append('NONUNIQUE_RENEWAL_HISTORY')
    if original_report['status'] != 'EXACT_NATIVE_HISTORY_VERIFIED': unsupported.append(original_report['status'])
    result = {'version': VERSION, 'id': expected_id,
        'status': 'REFUSED' if refused else 'INCOMPLETE' if missing else 'PARTIAL_REVIEW' if unsupported else 'VERIFIED_IN_DECLARED_SCOPE',
        'original': original_report, 'records': statuses, 'missing_dependencies': missing,
        'unsupported_or_unassessed': sorted(set(unsupported)), 'roots': roots, 'tips': tips, 'forks': forks,
        'unused_artifacts': sorted(set(artifacts) - referenced), 'selected_tip': expected_tip,
        'selection_basis': 'CALLER_PIN_ONLY; NO_GLOBAL_LATEST_OR_AUTOMATIC_FORK_CHOICE',
        'historical_security': 'NO_CLAIM_THAT_RENEWAL_PRECEDED_OBSOLESCENCE_OR_REPAIRS_PAST_FALSE_PROVENANCE',
        'privacy': 'DEFAULT_REPORT_OMITS_ARCHIVE_PROOF_AND_ARTIFACT_CONTENTS; PACKAGE_IS_NOT_ENCRYPTION',
        'original_bytes_returned': False, **FLAGS}
    if include_original:
        _need(result['status'] == 'VERIFIED_IN_DECLARED_SCOPE', 'ARCHIVE_RENEWAL_OPEN_REQUIRES_COMPLETE_VERIFICATION')
        result['original_bytes_base64'] = package['archive']['bytes_base64']; result['original_bytes_returned'] = True
    return result


def describe():
    return {'version': VERSION, 'package_version': PACKAGE,
        'existing_checks_reused': ['archive.restore', 'archive.verify_quantum_attestation', 'quantum.verify_renewal', 'time_evidence.assess'],
        'record_fields': 'version context archive previous predecessor_verifier checkpoint verifier signer attestation succession time_policy time_evidence'.split(),
        'artifact_kinds': list(KINDS), 'signature_label': LABEL,
        'recipient_policy': 'Independently pin package ID/context and adopt signer keys, quantum key/suite/succession expectations and any time policy. Package claims cannot install trust.',
        'supported_original': 'covenant-native-archive/0.1; exact original <=2MB and expanded ZIP <=16MB. Historical larger archives stay valid but unsupported by this companion.',
        'verifier_boundary': 'Only current locally pinned archive.restore source is executed. Historic/foreign verifier artifacts are unsupported inert data.',
        'checkpoint_boundary': 'Exact checkpoint reference preserved; no checkpoint authority or external finality inferred.',
        'time_boundary': 'Proof subject hashes record body with time_evidence=None; final record signature binds proof refs. Assesses subject sealing only, never currentness or legal effectiveness.',
        'independent_replay': 'CURRENT_PYTHON_VERIFIERS_ONLY; EXTERNAL_IMPLEMENTATION_QUALIFICATION_REMAINS_SEPARATE',
        'publication': 'OFFLINE_ONLY; NO_OTS_L2_OR_OTHER_BROADCAST', **FLAGS}
