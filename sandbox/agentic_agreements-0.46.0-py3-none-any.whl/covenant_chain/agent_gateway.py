"""Verified agent gateway: admission policy, signed audit log, public trust mark.

A company places this in front of its own agents. Every external agent that
calls in, and every external agent the company's agents call out to, is
decided by one published policy. Each decision, admitted or refused, is
appended to a hash-chained log before any effect. An auditor replays an
exported log against the policies it records and must reach the same
decisions. A trust mark is the signed public summary: the policy hash, the
log head, and the counts.

Trust boundary. The owner host, its clock and the record callback are trusted,
as in the required A2A agreement gate. Inbound callers prove possession of
their key by signing each request; transport authentication still applies.
Exports hold hashes, not payloads. Replacing the whole log with an older valid
copy is detected only against a trust mark someone retained. A trust mark is
the operator's signed statement that external agents reach the service only
through this gateway; the log proves what the gateway decided, not that no
other path exists. Admission does not prove what an admitted agent will do.
Operations that need a binding agreement route through the agreement gate.

Policy /0.6 adds a certification requirement: an operation can require the
caller to present an AAP-compatible certificate (covenant_chain/
connect_certification.py) from issuers the owner pinned, for the adapter kinds
and assessment levels the policy names, with a fresh issuer-signed status when
the policy asks. The certificate travels in the identity slot as a credentials
bundle beside any identity statement; it is unsigned context, so a refusal for
it never reserves the caller's nonce.

Policy /0.3 adds an owner-adopted witness policy. Every logged event is a leaf
of a C2SP-checkpointed RFC 6962 journal; a decision is admitted only when a
fresh quorum of the adopted witnesses cosigned the journal over every earlier
event, and an admission takes effect only once a fresh quorum also covers the
logged admission itself. Otherwise the call is refused, or its admission is
WITHHELD. Replay re-verifies the recorded witness evidence against the log.
"""
from copy import deepcopy
import bisect
import hashlib
import re
import threading

from covenant_agent.barrier import quote_untrusted
from .crypto import canonical, digest, need, public_key, sign, verification_key, verify
from .kept_promises import broken, honoured, honour_bps
from . import witness_journal
from .workflow_store import WorkflowStore, identifier

POLICY_VERSION = "covenant-agent-gateway-policy/0.1"
POLICY_VERSION_V2 = "covenant-agent-gateway-policy/0.2"
POLICY_VERSION_V3 = "covenant-agent-gateway-policy/0.3"
POLICY_VERSION_V4 = "covenant-agent-gateway-policy/0.4"
POLICY_VERSION_V5 = "covenant-agent-gateway-policy/0.5"
POLICY_VERSION_V6 = "covenant-agent-gateway-policy/0.6"
WITNESSED_POLICIES = (POLICY_VERSION_V3, POLICY_VERSION_V5)
SPIFFE_POLICIES = (POLICY_VERSION_V4, POLICY_VERSION_V5)
CERTIFIED_POLICIES = (POLICY_VERSION_V6,)
NONCE_V2_POLICIES = (POLICY_VERSION_V2, POLICY_VERSION_V3, POLICY_VERSION_V4, POLICY_VERSION_V5, POLICY_VERSION_V6)
REQUEST_VERSION = "covenant-agent-gateway-request/0.1"
IDENTITY_VERSION = "covenant-agent-gateway-identity/0.1"
DECISION_VERSION = "covenant-agent-gateway-decision/0.1"
DECISION_VERSION_V2 = "covenant-agent-gateway-decision/0.2"
PROOF_VERSION = "covenant-agent-gateway-proof/0.1"
CHECKPOINT_VERSION = "covenant-agent-gateway-checkpoint/0.1"
EXPORT_VERSION = "covenant-agent-gateway-export/0.1"
MARK_VERSION = "covenant-agent-gateway-mark/0.1"
POLICY_LABEL = "COVENANT-AGENT-GATEWAY-POLICY-0.1"
POLICY_LABEL_V2 = "COVENANT-AGENT-GATEWAY-POLICY-0.2"
POLICY_LABEL_V3 = "COVENANT-AGENT-GATEWAY-POLICY-0.3"
POLICY_LABELS = {POLICY_VERSION: POLICY_LABEL, POLICY_VERSION_V2: POLICY_LABEL_V2,
                 POLICY_VERSION_V3: POLICY_LABEL_V3,
                 POLICY_VERSION_V4: "COVENANT-AGENT-GATEWAY-POLICY-0.4",
                 POLICY_VERSION_V5: "COVENANT-AGENT-GATEWAY-POLICY-0.5",
                 POLICY_VERSION_V6: "COVENANT-AGENT-GATEWAY-POLICY-0.6"}
REQUEST_LABEL = "COVENANT-AGENT-GATEWAY-REQUEST-0.1"
IDENTITY_LABEL = "COVENANT-AGENT-GATEWAY-IDENTITY-0.1"
CHECKPOINT_LABEL = "COVENANT-AGENT-GATEWAY-CHECKPOINT-0.1"
MARK_LABEL = "COVENANT-AGENT-GATEWAY-MARK-0.1"
EVENT_LABEL = "COVENANT-WORKFLOW-EVENT-0.1"
EXTENSION_URI = ("https://github.com/covenant-common/covenant/blob/release/0.15-rc/docs/"
                 "AGENT_GATEWAY.md#covenant-agent-gateway-0.1")
STATEMENT = ("The operator states that external agents reach this service only through "
             "this gateway. Each decision, admitted or refused, is in the hash-chained "
             "log this mark summarises, signed by the log key. Refusal is the default.")
DIRECTIONS = ("INBOUND", "OUTBOUND")
CHANNELS = ("DIRECT", "AGREEMENT")
KINDS = ("AGENT_GATEWAY_POLICY", "AGENT_GATEWAY_DECISION", "AGENT_GATEWAY_RESULT")
MAX_PAYLOAD = 262144
MAX_LIST = 1024
MAX_OPERATIONS = 64
MAX_SKEW = 86400
ZERO = "0" * 64
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
HEX128 = re.compile(r"[0-9a-f]{128}\Z")
RULE_FIELDS = ("min_honour_bps min_honoured require_identity require_agreement screen "
               "rate max_payload_bytes")
POLICY_FIELDS = ("version company service policy_id log_signer receipt_signer valid_from "
                 "valid_until allow deny identity_issuers inbound outbound max_skew")
SUBJECT_FIELDS = ("direction channel request payload_match counterparty operation "
                  "payload_sha256 payload_bytes identity")
TOTAL_FIELDS = ("inbound_admitted", "inbound_refused", "outbound_admitted",
                "outbound_refused", "agreement_refused", "unknown_outcome", "pending")
# Refusals that depend on context the caller did not sign: the attached identity
# and the channel the request arrived on. A relay holding the signed envelope can
# change both, so under policy 0.2 such a refusal never reserves the nonce.
UNSIGNED_CONTEXT_CODES = frozenset(("GATEWAY_IDENTITY_MISSING", "GATEWAY_IDENTITY_INVALID",
                                    "GATEWAY_AGREEMENT_REQUIRED"))
# /0.6: the attached certificate is also unsigned context. Kept apart so the /0.2-/0.5
# reservation rule (and its independent JavaScript projection) is unchanged.
CERTIFICATE_CONTEXT_CODES = frozenset(("GATEWAY_CERTIFICATE_MISSING", "GATEWAY_CERTIFICATE_INVALID",
                                       "GATEWAY_CERTIFICATE_ISSUER", "GATEWAY_CERTIFICATE_SUBJECT",
                                       "GATEWAY_CERTIFICATE_SCOPE", "GATEWAY_CERTIFICATE_EXPIRED",
                                       "GATEWAY_CERTIFICATE_STATUS_UNKNOWN", "GATEWAY_CERTIFICATE_REVOKED"))
NONCE_RULE_V2 = "AUTHENTICATED_SERVICE_FRESH_PAYLOAD_NO_UNSIGNED_CONTEXT_REFUSAL"
WITNESS_FIELDS = "status codes size root checkpoint"
WITNESS_STATUSES = ("VERIFIED", "UNKNOWN", "REFUSED")
WITNESS_CODES = ("GATEWAY_WITNESS_UNKNOWN", "GATEWAY_WITNESS_REFUSED")


def _fields(value, names, code):
    need(type(value) is dict and set(value) == set(names.split()), code)


def _text(value, maximum=256, code="GATEWAY_TEXT"):
    need(type(value) is str and 0 < len(value) <= maximum and
         all(32 <= ord(c) <= 126 for c in value), code)


def _int(value, code, minimum=0, maximum=2**53 - 1):
    need(type(value) is int and minimum <= value <= maximum, code)


def _hex(value, code, pattern=HEX64):
    need(type(value) is str and pattern.fullmatch(value) is not None, code)


def _ed25519(value, code):
    need(type(value) is str, code)
    try:
        verification_key(value)
    except ValueError as exc:
        raise ValueError(code) from exc


def _keys(values, code):
    need(type(values) is list and len(values) <= MAX_LIST, code)
    for value in values:
        _ed25519(value, code)
    need(values == sorted(set(values)), code)


def _signed(envelope, label, signer):
    """True when envelope signature verifies; never raises for a bad signature."""
    try:
        _hex(envelope["signature"], "SIGNATURE", HEX128)
        verify(signer, label, envelope["body"], envelope["signature"])
        return True
    except (ValueError, KeyError, TypeError):
        return False


def _rule(rule, direction, certified=False):
    _fields(rule, RULE_FIELDS + (" require_certificate" if certified else ""), "GATEWAY_RULE_FIELDS")
    _int(rule["min_honour_bps"], "GATEWAY_RULE", 0, 10000)
    _int(rule["min_honoured"], "GATEWAY_RULE")
    for field in ("require_identity", "require_agreement", "screen") + (("require_certificate",) if certified else ()):
        need(type(rule[field]) is bool, "GATEWAY_RULE")
    need(direction == "INBOUND" or not rule["require_agreement"], "GATEWAY_RULE_DIRECTION")
    if rule["rate"] is not None:
        _fields(rule["rate"], "count window", "GATEWAY_RULE_RATE")
        _int(rule["rate"]["count"], "GATEWAY_RULE_RATE", 1)
        _int(rule["rate"]["window"], "GATEWAY_RULE_RATE", 1)
    _int(rule["max_payload_bytes"], "GATEWAY_RULE", 1, MAX_PAYLOAD)


def validate_policy(policy):
    """Versioned optional policies: /0.3 witnesses, /0.4 SPIFFE, /0.5 both, /0.6 certificates."""
    witnessed = type(policy) is dict and policy.get("version") in WITNESSED_POLICIES
    successor = type(policy) is dict and policy.get("version") in SPIFFE_POLICIES
    certified = type(policy) is dict and policy.get("version") in CERTIFIED_POLICIES
    _fields(policy, POLICY_FIELDS + (" witness" if witnessed else "") + (" spiffe" if successor else "") +
            (" certification" if certified else ""), "GATEWAY_POLICY_FIELDS")
    need(policy["version"] in POLICY_LABELS, "GATEWAY_POLICY_VERSION")
    if successor:
        from .spiffe_identity import validate_adoption
        try:
            validate_adoption(policy["spiffe"])
        except ValueError as exc:
            raise ValueError("GATEWAY_SPIFFE_ADOPTION") from exc
    if certified:
        from .connect_certification import validate_requirement
        try:
            validate_requirement(policy["certification"])
        except ValueError as exc:
            raise ValueError("GATEWAY_CERTIFICATION_POLICY") from exc
    _text(policy["company"], code="GATEWAY_POLICY_TEXT")
    _text(policy["service"], code="GATEWAY_POLICY_TEXT")
    _text(policy["policy_id"], code="GATEWAY_POLICY_TEXT")
    _ed25519(policy["log_signer"], "GATEWAY_LOG_SIGNER")
    if policy["receipt_signer"] is not None:
        _ed25519(policy["receipt_signer"], "GATEWAY_RECEIPT_SIGNER")
    _int(policy["valid_from"], "GATEWAY_POLICY_WINDOW")
    _int(policy["valid_until"], "GATEWAY_POLICY_WINDOW")
    need(policy["valid_from"] <= policy["valid_until"], "GATEWAY_POLICY_WINDOW")
    for field in ("allow", "deny", "identity_issuers"):
        _keys(policy[field], "GATEWAY_POLICY_KEYS")
    need(not set(policy["allow"]) & set(policy["deny"]), "GATEWAY_POLICY_KEYS")
    for direction in DIRECTIONS:
        rules = policy[direction.lower()]
        need(type(rules) is dict and len(rules) <= MAX_OPERATIONS, "GATEWAY_POLICY_RULES")
        for operation, rule in rules.items():
            _text(operation, 80, "GATEWAY_POLICY_RULES")
            _rule(rule, direction, certified)
            need(not rule["require_identity"] or policy["identity_issuers"] or
                 (successor and policy["spiffe"]["trust_domains"]), "GATEWAY_IDENTITY_ISSUERS")
            need(not rule["require_agreement"] or policy["receipt_signer"] is not None,
                 "GATEWAY_RECEIPT_SIGNER")
    _int(policy["max_skew"], "GATEWAY_POLICY_SKEW", 1, MAX_SKEW)
    if witnessed:
        _witness_rules(policy)
    return policy


def _witness_rules(policy):
    """The /0.3 witness policy journals this gateway's log under its own log key."""
    try:
        rules = witness_journal.validate_policy(policy["witness"])
    except ValueError as exc:
        raise ValueError("GATEWAY_WITNESS_POLICY") from exc
    need(rules["log"]["public"].hex() == policy["log_signer"], "GATEWAY_WITNESS_POLICY")
    return rules


def policy_label(policy):
    """The policy version selects its signature and hash domain.

    The retained 0.1 label and exact historical bytes are unchanged. A 0.2
    policy adopts authenticated nonce reservations; 0.3 keeps them and adds a
    witness policy. Each needs fresh owner assent.
    """
    validate_policy(policy)
    return POLICY_LABELS[policy["version"]]


def policy_hash(policy):
    validate_policy(policy)
    return digest(policy_label(policy), policy)


def public_policy(policy):
    """What a trust mark discloses. Allow and deny lists stay private; counts do not."""
    validate_policy(policy)
    summary = {"company": policy["company"], "service": policy["service"],
            "policy_id": policy["policy_id"], "default": "REFUSE",
            "valid_from": policy["valid_from"], "valid_until": policy["valid_until"],
            "allow_list": bool(policy["allow"]), "deny_count": len(policy["deny"]),
            "identity_issuers": list(policy["identity_issuers"]),
            "receipt_signer": policy["receipt_signer"], "max_skew": policy["max_skew"],
            "inbound": deepcopy(policy["inbound"]), "outbound": deepcopy(policy["outbound"])}
    if policy["version"] in NONCE_V2_POLICIES:
        summary.update(version=policy["version"], nonce_rule=NONCE_RULE_V2)
    if policy["version"] in WITNESSED_POLICIES:
        summary["witness"] = deepcopy(policy["witness"])
    if policy["version"] in SPIFFE_POLICIES:
        from .spiffe_identity import summary as spiffe_summary
        summary["spiffe"] = spiffe_summary(policy["spiffe"])
    if policy["version"] in CERTIFIED_POLICIES:
        summary["certification"] = deepcopy(policy["certification"])
    return summary


def payload_digest(payload):
    raw = canonical(payload)
    need(len(raw) <= MAX_PAYLOAD, "GATEWAY_PAYLOAD_SIZE")
    return hashlib.sha256(raw).hexdigest(), len(raw)


def _request_body(body):
    _fields(body, "version service caller operation payload_sha256 payload_bytes nonce issued_at",
            "GATEWAY_REQUEST_FIELDS")
    need(body["version"] == REQUEST_VERSION, "GATEWAY_REQUEST_VERSION")
    _text(body["service"], code="GATEWAY_REQUEST_FIELDS")
    _ed25519(body["caller"], "GATEWAY_REQUEST_CALLER")
    _text(body["operation"], 80, "GATEWAY_REQUEST_FIELDS")
    _hex(body["payload_sha256"], "GATEWAY_REQUEST_FIELDS")
    _int(body["payload_bytes"], "GATEWAY_REQUEST_FIELDS", 1, MAX_PAYLOAD)
    _hex(body["nonce"], "GATEWAY_REQUEST_FIELDS")
    _int(body["issued_at"], "GATEWAY_REQUEST_FIELDS")


def validate_request(envelope):
    _fields(envelope, "body signature", "GATEWAY_REQUEST_FIELDS")
    _request_body(envelope["body"])
    _hex(envelope["signature"], "GATEWAY_REQUEST_FIELDS", HEX128)
    return envelope


def sign_request(private_key, *, service, operation, payload, nonce, issued_at):
    """The calling agent's side: one signed request per call. The payload is not inside."""
    sha, size = payload_digest(payload)
    body = {"version": REQUEST_VERSION, "service": service, "caller": public_key(private_key),
            "operation": operation, "payload_sha256": sha, "payload_bytes": size,
            "nonce": nonce, "issued_at": issued_at}
    _request_body(body)
    return {"body": body, "signature": sign(private_key, REQUEST_LABEL, body)}


def _identity_body(body):
    _fields(body, "version issuer subject organisation not_before expires", "GATEWAY_IDENTITY_FIELDS")
    need(body["version"] == IDENTITY_VERSION, "GATEWAY_IDENTITY_FIELDS")
    _ed25519(body["issuer"], "GATEWAY_IDENTITY_FIELDS")
    _ed25519(body["subject"], "GATEWAY_IDENTITY_FIELDS")
    _text(body["organisation"], 200, "GATEWAY_IDENTITY_FIELDS")
    _int(body["not_before"], "GATEWAY_IDENTITY_FIELDS")
    _int(body["expires"], "GATEWAY_IDENTITY_FIELDS")


def sign_identity(issuer_key, *, subject, organisation, not_before, expires):
    """An issuer the policy names vouches that subject acts for organisation."""
    body = {"version": IDENTITY_VERSION, "issuer": public_key(issuer_key), "subject": subject,
            "organisation": organisation, "not_before": not_before, "expires": expires}
    _identity_body(body)
    return {"body": body, "signature": sign(issuer_key, IDENTITY_LABEL, body)}


def _identity_code(identity, policy, counterparty, now, history):
    """None when the identity holds, else the refusal code. ``/0.4`` and ``/0.5`` also read SPIFFE bindings."""
    if policy["version"] in SPIFFE_POLICIES:
        from .spiffe_identity import check_logged, is_binding
        if is_binding(identity):
            code, _ = check_logged(identity, policy["spiffe"], counterparty, now, history.pins)
            if code is None:
                return None
            return "GATEWAY_IDENTITY_REPLAY" if code == "SPIFFE_REPLAY" else "GATEWAY_IDENTITY_INVALID"
    return None if _identity_ok(identity, policy, counterparty, now) else "GATEWAY_IDENTITY_INVALID"


def _identity_ok(identity, policy, counterparty, now):
    try:
        _fields(identity, "body signature", "GATEWAY_IDENTITY_FIELDS")
        _identity_body(identity["body"])
    except ValueError:
        return False
    body = identity["body"]
    return (body["issuer"] in policy["identity_issuers"] and body["subject"] == counterparty and
            body["not_before"] <= now <= body["expires"] and
            _signed(identity, IDENTITY_LABEL, body["issuer"]))


def _record(record):
    if record is None:
        return
    _fields(record, "honour_bps honoured broken chain height", "GATEWAY_RECORD")
    _int(record["honour_bps"], "GATEWAY_RECORD", 0, 10000)
    _int(record["honoured"], "GATEWAY_RECORD")
    _int(record["broken"], "GATEWAY_RECORD")
    _text(record["chain"], 128, "GATEWAY_RECORD")
    _int(record["height"], "GATEWAY_RECORD")


def record_from_state(state, account, *, chain, height):
    """Kept-promise record for one account from native chain state. Pure; reads only."""
    _ed25519(account, "GATEWAY_RECORD")
    good = bad = 0
    agreements = state.get("agreements") if type(state) is dict else None
    for _, agreement in sorted((agreements or {}).items()):
        terms = agreement.get("terms") or {} if type(agreement) is dict else {}
        if account not in {terms.get("principal"), terms.get("agent"), terms.get("counterparty")}:
            continue
        good += 1 if honoured(agreement) else 0
        bad += 1 if broken(agreement) and not honoured(agreement) else 0
    record = {"honour_bps": honour_bps(state, account), "honoured": good, "broken": bad,
              "chain": chain, "height": height}
    _record(record)
    return record


def _evidence(evidence, witnessed=False):
    _fields(evidence, "now record witness" if witnessed else "now record", "GATEWAY_EVIDENCE")
    _int(evidence["now"], "GATEWAY_EVIDENCE")
    _record(evidence["record"])
    if witnessed:
        value = evidence["witness"]
        _fields(value, WITNESS_FIELDS, "GATEWAY_WITNESS_EVIDENCE")
        need(value["status"] in WITNESS_STATUSES and type(value["codes"]) is list and
             len(value["codes"]) <= 16, "GATEWAY_WITNESS_EVIDENCE")
        for code in value["codes"]:
            _text(code, 80, "GATEWAY_WITNESS_EVIDENCE")
        _int(value["size"], "GATEWAY_WITNESS_EVIDENCE")
        _hex(value["root"], "GATEWAY_WITNESS_EVIDENCE")
        need(value["checkpoint"] is None or type(value["checkpoint"]) is dict, "GATEWAY_WITNESS_EVIDENCE")
        need(value["status"] != "VERIFIED" or (value["checkpoint"] is not None and not value["codes"]),
             "GATEWAY_WITNESS_EVIDENCE")


def _witnessed(evidence, policy, prefix):
    """Replay check: a VERIFIED record names a fresh quorum over exactly the earlier events."""
    value = evidence["witness"]
    try:
        checked = witness_journal.evaluate(value["checkpoint"], policy["witness"], evidence["now"])
    except ValueError:
        checked = None
    need(checked is not None and checked["status"] == "VERIFIED" and
         checked["size"] == value["size"] == prefix.size and
         checked["root"] == value["root"] == prefix.root(), "GATEWAY_WITNESS_EVIDENCE")


def _subject(subject):
    _fields(subject, SUBJECT_FIELDS, "GATEWAY_SUBJECT")
    need(subject["direction"] in DIRECTIONS and subject["channel"] in CHANNELS, "GATEWAY_SUBJECT")
    need(type(subject["payload_match"]) is bool, "GATEWAY_SUBJECT")
    if subject["direction"] == "OUTBOUND":
        need(subject["channel"] == "DIRECT" and subject["request"] is None and
             subject["payload_match"] is True, "GATEWAY_SUBJECT")
    if subject["direction"] == "INBOUND" and subject["request"] is None:
        # A malformed inbound request is logged by hash only.
        need(subject["counterparty"] is None and subject["operation"] is None and
             subject["payload_bytes"] is None and subject["identity"] is None, "GATEWAY_SUBJECT")
        need(subject["payload_sha256"] is None or HEX64.fullmatch(str(subject["payload_sha256"])),
             "GATEWAY_SUBJECT")
        return
    if subject["direction"] == "INBOUND":
        validate_request(subject["request"])
        body = subject["request"]["body"]
        need(subject["counterparty"] == body["caller"] and subject["operation"] == body["operation"]
             and subject["payload_sha256"] == body["payload_sha256"] and
             subject["payload_bytes"] == body["payload_bytes"], "GATEWAY_SUBJECT")
    _ed25519(subject["counterparty"], "GATEWAY_SUBJECT")
    _text(subject["operation"], 80, "GATEWAY_SUBJECT")
    _hex(subject["payload_sha256"], "GATEWAY_SUBJECT")
    _int(subject["payload_bytes"], "GATEWAY_SUBJECT", 1, MAX_PAYLOAD)


class History:
    """Prior decisions that later ones depend on: request nonces and admission times."""

    def __init__(self, signatures=None):
        self.nonces = set()
        self.admitted = {}
        self.pins = {}
        self.last_now = None
        # Optional memo of request-signature results keyed by the exact
        # canonical request bytes. The result is a pure function of those
        # bytes (the label is fixed and the signer is the signed caller), so a
        # shared memo cannot change any outcome; it only avoids re-verifying
        # every logged request on each live decision.
        self._signatures = {} if signatures is None else signatures

    def _authentic(self, request):
        key = canonical(request)
        known = self._signatures.get(key)
        if known is None:
            known = _signed(request, REQUEST_LABEL, request["body"]["caller"])
            self._signatures[key] = known
        return known

    def recent(self, direction, counterparty, operation, now, window):
        times = self.admitted.get((direction, counterparty, operation), [])
        return len(times) - bisect.bisect_right(times, now - window)

    def see(self, subject, evidence, outcome, policy, codes):
        """Project one decision using the policy that governed that decision.

        Under 0.1 every parsed request reserved its claimed caller's nonce,
        including refused forgeries; ``codes`` is ignored. 0.2 reserves only an
        authenticated, fresh, service- and payload-bound request, and only when
        the decision is ADMIT or its refusal depends solely on what the caller
        signed and on policy facts about that caller (deny/allow lists, record,
        rate, unlisted operation, payload size, policy window). A refusal that
        names unsigned context (identity missing or invalid, agreement channel
        required) is logged but does not reserve, so a relay that submits the
        envelope first with another identity or channel cannot burn the nonce.
        ``codes`` are the decision's refusal codes, exactly as decide() returns
        and the log records them. Migration never deletes earlier reservations.
        """
        request = subject["request"]
        reserve = request is not None
        if reserve and policy["version"] in NONCE_V2_POLICIES:
            # Preserve authenticated service/freshness and unsigned-context nonce protection.
            validate_request(request)
            need(type(codes) is list and all(type(code) is str for code in codes),
                 "GATEWAY_DECISION_EVENT")
            body = request["body"]
            unsigned = UNSIGNED_CONTEXT_CODES | (CERTIFICATE_CONTEXT_CODES
                                                 if policy["version"] in CERTIFIED_POLICIES else frozenset())
            reserve = (subject["payload_match"] is True and
                       body["service"] == policy["service"] and
                       abs(evidence["now"] - body["issued_at"]) <= policy["max_skew"] and
                       (outcome == "ADMIT" or not unsigned.intersection(codes)) and
                       self._authentic(request))
        if reserve:
            body = subject["request"]["body"]
            self.nonces.add((body["caller"], body["nonce"]))
        if outcome == "ADMIT":
            row = (subject["direction"], subject["counterparty"], subject["operation"])
            self.admitted.setdefault(row, []).append(evidence["now"])
        if policy["version"] in SPIFFE_POLICIES and subject["identity"] is not None:
            # A JWT-SVID is a bearer token: the first AAP key it validly binds to keeps it.
            from .spiffe_identity import check_logged, is_binding
            if is_binding(subject["identity"]):
                code, named = check_logged(subject["identity"], policy["spiffe"], subject["counterparty"],
                                           evidence["now"], self.pins)
                if code is None and named["svid_type"] == "JWT":
                    self.pins.setdefault(named["svid_sha256"], named["key"])
        self.last_now = evidence["now"]


def decide(policy, subject, evidence, history=None):
    """Pure admission rule. The gateway and an auditor's replay both call this.

    Returns every reason that applies, in a fixed order, so a refusal names all
    of them. Unlisted operations and malformed requests stop early.
    """
    validate_policy(policy)
    witnessed = policy["version"] in WITNESSED_POLICIES
    _subject(subject)
    _evidence(evidence, witnessed)
    history = History() if history is None else history
    now, codes = evidence["now"], []
    if not policy["valid_from"] <= now <= policy["valid_until"]:
        codes.append("GATEWAY_POLICY_INACTIVE")
    if witnessed and evidence["witness"]["status"] != "VERIFIED":
        # Admission relies on the logged policy, nonces and rates: no fresh witnessed head, no admission.
        codes.append("GATEWAY_WITNESS_UNKNOWN" if evidence["witness"]["status"] == "UNKNOWN"
                     else "GATEWAY_WITNESS_REFUSED")
    if subject["direction"] == "INBOUND" and subject["request"] is None:
        return {"outcome": "REFUSE", "codes": codes + ["GATEWAY_REQUEST_MALFORMED"]}
    rule = policy[subject["direction"].lower()].get(subject["operation"])
    if rule is None:
        return {"outcome": "REFUSE", "codes": codes + ["GATEWAY_OPERATION_UNLISTED"]}
    party = subject["counterparty"]
    if subject["request"] is not None:
        body = subject["request"]["body"]
        if not _signed(subject["request"], REQUEST_LABEL, body["caller"]):
            codes.append("GATEWAY_REQUEST_SIGNATURE")
        if body["service"] != policy["service"]:
            codes.append("GATEWAY_REQUEST_SCOPE")
        if abs(now - body["issued_at"]) > policy["max_skew"]:
            codes.append("GATEWAY_REQUEST_STALE")
        if (body["caller"], body["nonce"]) in history.nonces:
            codes.append("GATEWAY_REQUEST_REPLAY")
        if not subject["payload_match"]:
            codes.append("GATEWAY_PAYLOAD_MISMATCH")
    if subject["payload_bytes"] > rule["max_payload_bytes"]:
        codes.append("GATEWAY_PAYLOAD_SIZE")
    if party in policy["deny"]:
        codes.append("GATEWAY_DENIED")
    if policy["allow"] and party not in policy["allow"]:
        codes.append("GATEWAY_NOT_ALLOWED")
    identity, presented = subject["identity"], None
    certified = policy["version"] in CERTIFIED_POLICIES
    if certified and identity is not None:
        from .connect_certification import is_credentials, split_credentials
        if is_credentials(identity):
            try:
                identity, presented = split_credentials(identity)
            except ValueError:
                identity, presented = None, "MALFORMED"
    if identity is not None:
        code = _identity_code(identity, policy, party, now, history)
        if code is not None:
            codes.append(code)
    elif rule["require_identity"]:
        codes.append("GATEWAY_IDENTITY_MISSING")
    if certified:
        # /0.6: a presented certificate is always checked; a required one must be present.
        if presented == "MALFORMED":
            codes.append("GATEWAY_CERTIFICATE_INVALID")
        elif presented is not None:
            from .connect_certification import gateway_code
            code = gateway_code(presented, policy["certification"], party, now)
            if code is not None:
                codes.append(code)
        elif rule["require_certificate"]:
            codes.append("GATEWAY_CERTIFICATE_MISSING")
    record = evidence["record"]
    if record is None:
        if rule["min_honour_bps"] or rule["min_honoured"]:
            codes.append("GATEWAY_RECORD_MISSING")
    else:
        if record["honour_bps"] < rule["min_honour_bps"]:
            codes.append("GATEWAY_RECORD_LOW")
        if record["honoured"] < rule["min_honoured"]:
            codes.append("GATEWAY_RECORD_SHORT")
    if rule["require_agreement"] and subject["channel"] != "AGREEMENT":
        codes.append("GATEWAY_AGREEMENT_REQUIRED")
    if rule["rate"] is not None and history.recent(
            subject["direction"], party, subject["operation"], now,
            rule["rate"]["window"]) >= rule["rate"]["count"]:
        codes.append("GATEWAY_RATE_LIMIT")
    return {"outcome": "REFUSE" if codes else "ADMIT", "codes": codes}


def screen_payload(payload):
    """Copy for a model. Instruction-shaped strings are replaced by their hash."""
    withheld = []

    def walk(node):
        if type(node) is list:
            return [walk(item) for item in node]
        if type(node) is dict:
            return {name: walk(item) for name, item in node.items()}
        if type(node) is str:
            quote = quote_untrusted(node, "content")
            if quote["withheld"] is not None:
                withheld.append(quote["sha256"])
                return {"withheld": quote["withheld"], "sha256": quote["sha256"]}
        return node

    return walk(deepcopy(payload)), len(withheld)


def _totals():
    totals = {name: 0 for name in TOTAL_FIELDS}
    totals["codes"] = {}
    return totals


def _receipt_ok(receipt, policy, counterparty, outcome):
    from .a2a_agreement_gate import RECEIPT_LABEL
    try:
        _fields(receipt, "body signer signature", "GATEWAY_RECEIPT")
        body = receipt["body"]
        need(type(body) is dict, "GATEWAY_RECEIPT")
        expected = "COMPLETED_RECORDED" if outcome == "RECORDED" else "UNKNOWN_EXTERNAL_OUTCOME"
        return (receipt["signer"] == policy["receipt_signer"] and body.get("caller") == counterparty
                and body.get("outcome") == expected and
                _signed(receipt, RECEIPT_LABEL, receipt["signer"]))
    except ValueError:
        return False


def replay(events, log_signer, *, audit=True, signatures=None):
    """Walk a gateway log. With audit, re-verify every signature and decision.

    Returns the policy in force, the history, totals and per-policy hashes. The
    first difference raises a stable code; ``sequence`` names the event.
    ``signatures`` optionally memoises request-signature results by exact
    canonical request bytes across calls; it never changes a result.
    """
    _ed25519(log_signer, "GATEWAY_LOG_SIGNER")
    need(type(events) is list, "GATEWAY_LOG_CHAIN")
    previous, policy, history, totals = ZERO, None, History(signatures), _totals()
    decisions, hashes = {}, []
    prefix = witness_journal.Range() if audit else None
    for index, event in enumerate(events):
        try:
            _fields(event, "sequence previous id body", "GATEWAY_LOG_CHAIN")
            need(event["sequence"] == index + 1 and event["previous"] == previous, "GATEWAY_LOG_CHAIN")
            if audit:
                need(event["id"] == identifier(EVENT_LABEL, {"sequence": event["sequence"],
                     "previous": previous, "body": event["body"]}), "GATEWAY_LOG_CHAIN")
            body = event["body"]
            _fields(body, "kind task value", "GATEWAY_LOG_KIND")
            need(body["kind"] in KINDS, "GATEWAY_LOG_KIND")
            value = body["value"]
            if body["kind"] == "AGENT_GATEWAY_POLICY":
                _fields(value, "policy policy_hash signature", "GATEWAY_POLICY_EVENT")
                validate_policy(value["policy"])
                need(value["policy"]["log_signer"] == log_signer, "GATEWAY_LOG_SIGNER")
                need(policy is None or value["policy"]["service"] == policy["service"],
                     "GATEWAY_POLICY_SCOPE")
                if audit:
                    need(value["policy_hash"] == policy_hash(value["policy"]) and
                         _signed({"body": value["policy"], "signature": value["signature"]},
                                 policy_label(value["policy"]), log_signer), "GATEWAY_POLICY_EVENT")
                policy = value["policy"]
                hashes.append(value["policy_hash"])
            elif body["kind"] == "AGENT_GATEWAY_DECISION":
                need(policy is not None, "GATEWAY_LOG_ORDER")
                _fields(value, "version subject evidence outcome codes", "GATEWAY_DECISION_EVENT")
                witnessed = policy["version"] in WITNESSED_POLICIES
                need(value["version"] == (DECISION_VERSION_V2 if witnessed else DECISION_VERSION),
                     "GATEWAY_DECISION_EVENT")
                _evidence(value["evidence"], witnessed)
                need(history.last_now is None or value["evidence"]["now"] >= history.last_now,
                     "GATEWAY_CLOCK_ROLLBACK")
                if audit and witnessed and value["evidence"]["witness"]["status"] == "VERIFIED":
                    _witnessed(value["evidence"], policy, prefix)
                if audit:
                    again = decide(policy, value["subject"], value["evidence"], history)
                    need(again == {"outcome": value["outcome"], "codes": value["codes"]},
                         "GATEWAY_REPLAY_MISMATCH")
                history.see(value["subject"], value["evidence"], value["outcome"], policy,
                            value["codes"])
                direction = value["subject"]["direction"].lower()
                admitted = value["outcome"] == "ADMIT"
                totals[direction + ("_admitted" if admitted else "_refused")] += 1
                for code in value["codes"]:
                    totals["codes"][code] = totals["codes"].get(code, 0) + 1
                if admitted and direction == "inbound":
                    totals["pending"] += 1
                decisions[event["id"]] = {"value": value, "policy": policy, "result": False}
            else:
                _fields(value, "decision outcome code result_sha256 receipt", "GATEWAY_RESULT_EVENT")
                row = decisions.get(value["decision"])
                withheld = value["outcome"] == "WITHHELD"
                need(row is not None and row["value"]["outcome"] == "ADMIT" and not row["result"] and
                     (row["value"]["subject"]["direction"] == "INBOUND" or withheld),
                     "GATEWAY_RESULT_ORPHAN")
                row["result"] = True
                if row["value"]["subject"]["direction"] == "INBOUND":
                    totals["pending"] -= 1
                channel = row["value"]["subject"]["channel"]
                outcome = value["outcome"]
                need(outcome in ("RECORDED", "UNKNOWN", "AGREEMENT_REFUSED") or
                     (withheld and row["policy"]["version"] in WITNESSED_POLICIES), "GATEWAY_RESULT_EVENT")
                if withheld:
                    # /0.3: the admission could not be witnessed, so nothing was executed.
                    need(value["code"] in WITNESS_CODES and value["receipt"] is None and
                         value["result_sha256"] is None, "GATEWAY_RESULT_EVENT")
                    totals["codes"][value["code"]] = totals["codes"].get(value["code"], 0) + 1
                elif outcome == "AGREEMENT_REFUSED":
                    need(channel == "AGREEMENT" and value["receipt"] is None and
                         value["result_sha256"] is None, "GATEWAY_RESULT_EVENT")
                    _text(value["code"], 80, "GATEWAY_RESULT_EVENT")
                    totals["agreement_refused"] += 1
                    totals["codes"][value["code"]] = totals["codes"].get(value["code"], 0) + 1
                else:
                    need(value["code"] is None, "GATEWAY_RESULT_EVENT")
                    if outcome == "UNKNOWN":
                        totals["unknown_outcome"] += 1
                    if value["result_sha256"] is not None:
                        _hex(value["result_sha256"], "GATEWAY_RESULT_EVENT")
                    if channel == "AGREEMENT":
                        need(not audit or _receipt_ok(value["receipt"], row["policy"],
                             row["value"]["subject"]["counterparty"], outcome), "GATEWAY_RECEIPT")
                    else:
                        need(value["receipt"] is None, "GATEWAY_RESULT_EVENT")
            previous = event["id"]
            if prefix is not None:
                prefix.append(previous)
        except ValueError as exc:
            error = ValueError(str(exc))
            error.sequence = index + 1
            raise error from exc
    return {"policy": policy, "history": history, "totals": totals, "policies": hashes,
            "head": previous, "count": len(events)}


class AgentGateway:
    """One company's gateway. Owner callbacks are trusted; caller input is not.

    clock() returns the owner's current time. record(account) returns that
    account's kept-promise record (see record_from_state) or None.
    witnesses maps adopted witness names to owner-installed transports, and
    retained_head is a file kept apart from this directory. Either one means
    this host requires a /0.3 witness policy before any decision.
    """

    def __init__(self, directory, *, policy, log_key, clock, record, witnesses=None, retained_head=None):
        validate_policy(policy)
        need(callable(clock) and callable(record), "GATEWAY_OWNER_CALLBACK")
        need(witnesses is None or type(witnesses) is dict, "GATEWAY_WITNESS_TRANSPORTS")
        signer = public_key(log_key)
        need(signer == policy["log_signer"], "GATEWAY_LOG_KEY")
        self.log_key, self.clock, self.record = log_key, clock, record
        self.log_signer, self.service = signer, policy["service"]
        self._witnesses, self._retained_path = dict(witnesses or {}), retained_head
        self._witnessing = bool(witnesses) or retained_head is not None
        self._journal = self._retained = None
        self._lock = threading.RLock()
        # Request-signature memo for the live projection, for this object's
        # lifetime. Keyed by exact canonical request bytes; see History.
        self._signatures = {}
        self.store = WorkflowStore(directory, {"profile": DECISION_VERSION, "service": self.service,
                                               "log_signer": signer}, check_same_thread=False)
        self.adopt_policy(policy)

    def close(self):
        with self._lock:
            self.store.close()
            for part in (self._journal, self._retained):
                if part is not None:
                    part.close()

    def _current(self):
        return replay(self.store.events(), self.log_signer, audit=False,
                      signatures=self._signatures)

    def adopt_policy(self, policy):
        """Append a policy change. Same service and log key; earlier decisions keep theirs."""
        validate_policy(policy)
        need(policy["log_signer"] == self.log_signer and policy["service"] == self.service,
             "GATEWAY_POLICY_SCOPE")
        with self._lock, self.store.exclusive():
            state = self._current()
            reference = policy_hash(policy)
            if state["policy"] is not None and state["policies"][-1] == reference:
                return reference
            self.store.append("AGENT_GATEWAY_POLICY", reference,
                              {"policy": deepcopy(policy), "policy_hash": reference,
                               "signature": sign(self.log_key, policy_label(policy), policy)})
            return reference

    @property
    def policy(self):
        with self._lock:
            return deepcopy(self._current()["policy"])

    def _now(self, history, now=None):
        now = self.clock() if now is None else now
        _int(now, "GATEWAY_CLOCK")
        need(history.last_now is None or now >= history.last_now, "GATEWAY_CLOCK_ROLLBACK")
        return now

    def _gate(self, policy):
        """The journal beside the log, the retained head and the transports this policy adopts."""
        rules = policy["witness"]
        if self._journal is None:
            self._journal = witness_journal.open_journal(self.store.directory / "journal.sqlite")
        if self._retained is None and self._retained_path is not None:
            self._retained = witness_journal.RetainedHead(self._retained_path, rules["origin"])
        adopted = witness_journal.validate_policy(rules)["witnesses"]
        return witness_journal.Gate(self._journal, rules, log_key=self.log_key, clock=self.clock,
                                    witnesses={name: transport for name, transport in self._witnesses.items()
                                               if name in adopted}, retained=self._retained)

    def _sync(self, gate, events):
        """Append the event ids the journal lacks. A journal ahead of or unlike the log refuses."""
        journal, ids = gate.journal, [event["id"] for event in events]
        size = journal.size()
        if size <= len(ids) and journal.entries() == ids[:size]:
            with journal.write():
                for reference in ids[size:]:
                    journal.append(reference)
            return True
        presented = witness_journal.Range()
        roots = [presented.root()]
        for reference in ids:
            presented.append(reference); roots.append(presented.root())
        found = gate.compare(roots.__getitem__, len(ids))
        if found is not None:
            journal.store_evidence(found)
        return False

    def _verdict(self, policy, events, required=None):
        try:
            gate = self._gate(policy)
            if self._sync(gate, events):
                return gate.check(required)
            codes = ["GATEWAY_JOURNAL_MISMATCH"]
        except ValueError as exc:
            codes = [str(exc)[:80] or "GATEWAY_WITNESS_UNAVAILABLE"]
        presented = witness_journal.Range()
        for event in events:
            presented.append(event["id"])
        return {"status": "REFUSED", "codes": codes, "size": presented.size, "root": presented.root(),
                "checkpoint": None, "now": self.clock()}

    def _decide(self, subject):
        """Decide and log before any effect. Callers hold the lock."""
        events = self.store.events()
        state = replay(events, self.log_signer, audit=False)
        witnessed = state["policy"]["version"] in WITNESSED_POLICIES
        need(witnessed or not self._witnessing, "GATEWAY_WITNESS_POLICY_REQUIRED")
        verdict = self._verdict(state["policy"], events) if witnessed else None
        now = self._now(state["history"], None if verdict is None else verdict["now"])
        if state["policy"]["version"] in SPIFFE_POLICIES and subject["identity"] is not None:
            from .spiffe_identity import admission_form
            subject = {**subject, "identity": admission_form(subject["identity"], state["policy"]["spiffe"])}
        record = None
        if subject["counterparty"] is not None:
            record = deepcopy(self.record(subject["counterparty"]))
            _record(record)
        evidence = {"now": now, "record": record}
        if witnessed:
            evidence["witness"] = {"status": verdict["status"], "codes": list(verdict["codes"])[:16],
                                   "size": verdict["size"], "root": verdict["root"],
                                   "checkpoint": verdict["checkpoint"]}
        decision = decide(state["policy"], subject, evidence, state["history"])
        value = {"version": DECISION_VERSION_V2 if witnessed else DECISION_VERSION, "subject": deepcopy(subject),
                 "evidence": evidence, "outcome": decision["outcome"], "codes": decision["codes"]}
        reference = self.store.append("AGENT_GATEWAY_DECISION",
                                      digest(DECISION_VERSION, subject), value)
        rule = state["policy"][subject["direction"].lower()].get(subject["operation"] or "")
        return reference, decision, rule

    def _withhold(self, reference):
        """/0.3: an admission takes effect only under a fresh quorum that covers it. Callers hold the lock."""
        events = self.store.events()
        policy = replay(events, self.log_signer, audit=False)["policy"]
        if policy["version"] not in WITNESSED_POLICIES:
            return None
        need(events[-1]["id"] == reference, "GATEWAY_LOG_ORDER")
        verdict = self._verdict(policy, events, len(events))
        if verdict["status"] == "VERIFIED":
            return None
        code = WITNESS_CODES[0] if verdict["status"] == "UNKNOWN" else WITNESS_CODES[1]
        self._result(reference, "WITHHELD", code=code)
        return code

    def _witnessed_gate(self, sync=True):
        events = self.store.events()
        policy = replay(events, self.log_signer, audit=False)["policy"]
        need(policy["version"] in WITNESSED_POLICIES, "GATEWAY_WITNESS_POLICY_REQUIRED")
        gate = self._gate(policy)
        need(not sync or self._sync(gate, events), "GATEWAY_JOURNAL_MISMATCH")
        return gate, events

    def journal_checkpoint(self):
        """The C2SP checkpoint of every logged event so far, signed by the log key."""
        with self._lock, self.store.exclusive():
            return self._witnessed_gate()[0].publish()

    def witness(self):
        """One add-checkpoint round to each installed witness, then the verdict."""
        with self._lock, self.store.exclusive():
            gate, _ = self._witnessed_gate()
            report = gate.collect()
            return {"witnesses": report, "verdict": gate.verdict()}

    def decision_proof(self, decision):
        """The logged decision and its inclusion under the newest witnessed checkpoint."""
        with self._lock, self.store.exclusive():
            gate, events = self._witnessed_gate()
            index = next((i for i, event in enumerate(events) if event["id"] == decision and
                          event["body"]["kind"] == "AGENT_GATEWAY_DECISION"), None)
            need(index is not None, "GATEWAY_PROOF_DECISION")
            return {"version": PROOF_VERSION, "event": deepcopy(events[index]), "proof": gate.proof(index)}

    def journal_extension(self, old):
        """A consistency proof from a checkpoint size someone retained to the newest witnessed one."""
        with self._lock, self.store.exclusive():
            gate, _ = self._witnessed_gate()
            gate.check()
            return gate.extension(old)

    def witness_evidence(self):
        """Kept split-view, rollback and fork evidence for this log."""
        with self._lock, self.store.exclusive():
            return self._witnessed_gate(sync=False)[0].journal.evidence()

    def _inbound_subject(self, envelope, payload, channel, identity):
        try:
            validate_request(envelope)
            sha, size = payload_digest(payload)
        except (ValueError, TypeError, KeyError):
            try:
                raw = hashlib.sha256(canonical(envelope)).hexdigest()
            except (ValueError, TypeError):
                raw = None
            return {"direction": "INBOUND", "channel": channel, "request": None,
                    "payload_match": False, "counterparty": None, "operation": None,
                    "payload_sha256": raw, "payload_bytes": None, "identity": None}
        body = envelope["body"]
        matches = sha == body["payload_sha256"] and size == body["payload_bytes"]
        if channel == "AGREEMENT":
            # The gateway's rule selector must describe the operation the
            # agreement gate will execute. A valid signature over two different
            # selectors must not route a restrictive operation through a more
            # permissive gateway rule. Parsing is local and performs no effect.
            from .a2a_agreement_gate import _params
            try:
                _, selected, _ = _params(payload)
                matches = matches and selected["operation"] == body["operation"]
            except (ValueError, TypeError, KeyError):
                matches = False
        return {"direction": "INBOUND", "channel": channel, "request": deepcopy(envelope),
                "payload_match": matches,
                "counterparty": body["caller"], "operation": body["operation"],
                "payload_sha256": body["payload_sha256"], "payload_bytes": body["payload_bytes"],
                "identity": deepcopy(identity)}

    def _result(self, reference, outcome, code=None, result_sha256=None, receipt=None):
        self.store.append("AGENT_GATEWAY_RESULT", reference,
                          {"decision": reference, "outcome": outcome, "code": code,
                           "result_sha256": result_sha256, "receipt": deepcopy(receipt)})

    def inbound(self, envelope, payload, execute, *, identity=None):
        """Admit or refuse one external call. execute runs once, only after ADMIT is logged.

        execute receives the caller key, operation, the screened payload when the
        rule asks for screening, and the decision id. An exception is recorded as
        UNKNOWN and is not retried: it does not prove there was no effect.
        """
        need(callable(execute), "GATEWAY_OWNER_CALLBACK")
        with self._lock, self.store.exclusive():
            subject = self._inbound_subject(envelope, payload, "DIRECT", identity)
            reference, decision, rule = self._decide(subject)
            out = {"decision": reference, "outcome": decision["outcome"],
                   "codes": decision["codes"], "result": None, "execution": None}
            if decision["outcome"] != "ADMIT":
                return out
            code = self._withhold(reference)
            if code is not None:
                out.update(outcome="REFUSE", codes=[code], execution="WITHHELD")
                return out
            shown, withheld = screen_payload(payload) if rule["screen"] else (deepcopy(payload), 0)
            call = {"caller": subject["counterparty"], "operation": subject["operation"],
                    "payload": shown, "withheld": withheld, "decision": reference,
                    "untrusted": True}
            try:
                result = deepcopy(execute(call))
                result_sha256, _ = payload_digest(result)
                execution = "RECORDED"
            except Exception:
                result, result_sha256, execution = None, None, "UNKNOWN"
            self._result(reference, execution, result_sha256=result_sha256)
            out.update(result=result, execution=execution, withheld=withheld)
            return out

    def inbound_agreement(self, gate, envelope, params, *, identity=None):
        """An operation that needs a pinned agreement: policy first, then the agreement gate."""
        from .a2a_agreement_gate import EXTENSION_URI as GATE_EXTENSION, decode_task_artifact
        with self._lock, self.store.exclusive():
            need(gate.receipt_signer is not None and
                 gate.receipt_signer == self._current()["policy"]["receipt_signer"],
                 "GATEWAY_RECEIPT_SIGNER")
            subject = self._inbound_subject(envelope, params, "AGREEMENT", identity)
            reference, decision, _ = self._decide(subject)
            out = {"decision": reference, "outcome": decision["outcome"],
                   "codes": decision["codes"], "task": None, "execution": None}
            if decision["outcome"] != "ADMIT":
                return out
            code = self._withhold(reference)
            if code is not None:
                out.update(outcome="REFUSE", codes=[code], execution="WITHHELD")
                return out
            try:
                task = gate.dispatch("SendMessage", params, caller=subject["counterparty"],
                                     active_extensions=[GATE_EXTENSION])
            except ValueError as exc:
                code = str(exc)[:80] or "A2A_GATE_REFUSED"
                self._result(reference, "AGREEMENT_REFUSED", code=code)
                out.update(execution="AGREEMENT_REFUSED", code=code)
                return out
            receipt = decode_task_artifact(task["task"])["receipt"]
            execution = ("RECORDED" if receipt["body"]["outcome"] == "COMPLETED_RECORDED"
                         else "UNKNOWN")
            self._result(reference, execution, result_sha256=receipt["body"]["result_sha256"],
                         receipt=receipt)
            out.update(task=task, execution=execution)
            return out

    def outbound(self, counterparty, operation, payload, *, identity=None):
        """Check an external agent before one of the company's agents calls it."""
        sha, size = payload_digest(payload)
        subject = {"direction": "OUTBOUND", "channel": "DIRECT", "request": None,
                   "payload_match": True, "counterparty": counterparty, "operation": operation,
                   "payload_sha256": sha, "payload_bytes": size, "identity": deepcopy(identity)}
        _subject(subject)
        with self._lock, self.store.exclusive():
            reference, decision, _ = self._decide(subject)
            out = {"decision": reference, "outcome": decision["outcome"], "codes": decision["codes"]}
            code = self._withhold(reference) if decision["outcome"] == "ADMIT" else None
            if code is not None:
                out.update(outcome="REFUSE", codes=[code], execution="WITHHELD")
            return out

    def checkpoint(self):
        with self._lock, self.store.exclusive():
            events = self.store.events()
            state = replay(events, self.log_signer, audit=False, signatures=self._signatures)
            body = {"version": CHECKPOINT_VERSION, "company": state["policy"]["company"],
                    "service": self.service, "policy_hash": state["policies"][-1],
                    "log_signer": self.log_signer, "head": state["head"],
                    "count": state["count"], "now": self._now(state["history"]),
                    "totals": state["totals"]}
            return {"body": body, "signature": sign(self.log_key, CHECKPOINT_LABEL, body)}

    def export(self):
        """Everything an auditor needs: the log (hashes, no payloads) and a signed head."""
        with self._lock, self.store.exclusive():
            events = deepcopy(self.store.events())
            checkpoint = self.checkpoint()
        need(checkpoint["body"]["count"] == len(events), "GATEWAY_EXPORT_RACE")
        return {"version": EXPORT_VERSION, "events": events, "checkpoint": checkpoint}

    def trust_mark(self):
        return trust_mark(self.checkpoint(), self.policy, self.log_key)


def _checkpoint(checkpoint, log_signer):
    _fields(checkpoint, "body signature", "GATEWAY_CHECKPOINT")
    body = checkpoint["body"]
    _fields(body, "version company service policy_hash log_signer head count now totals",
            "GATEWAY_CHECKPOINT")
    need(body["version"] == CHECKPOINT_VERSION and body["log_signer"] == log_signer and
         _signed(checkpoint, CHECKPOINT_LABEL, log_signer), "GATEWAY_CHECKPOINT")
    return body


def trust_mark(checkpoint, policy, log_key):
    """Signed public statement for an agent card, a website or a procurement file."""
    body = _checkpoint(checkpoint, public_key(log_key))
    need(body["policy_hash"] == policy_hash(policy), "GATEWAY_MARK_POLICY")
    mark = {"version": MARK_VERSION, "statement": STATEMENT, "policy": public_policy(policy),
            "policy_hash": body["policy_hash"], "log_signer": body["log_signer"],
            "head": body["head"], "count": body["count"], "now": body["now"],
            "totals": deepcopy(body["totals"]), "request_version": REQUEST_VERSION,
            "extension": EXTENSION_URI}
    return {"body": mark, "signature": sign(log_key, MARK_LABEL, mark)}


def verify_trust_mark(mark, *, expected_log_signer=None, policy=None):
    """Check a mark's signature, and its policy when the full policy is disclosed."""
    _fields(mark, "body signature", "GATEWAY_MARK")
    body = mark["body"]
    _fields(body, "version statement policy policy_hash log_signer head count now totals "
                  "request_version extension", "GATEWAY_MARK")
    need(body["version"] == MARK_VERSION and body["statement"] == STATEMENT and
         body["request_version"] == REQUEST_VERSION and body["extension"] == EXTENSION_URI,
         "GATEWAY_MARK")
    _ed25519(body["log_signer"], "GATEWAY_MARK")
    need(expected_log_signer is None or body["log_signer"] == expected_log_signer,
         "GATEWAY_MARK_SIGNER")
    _hex(body["head"], "GATEWAY_MARK")
    _hex(body["policy_hash"], "GATEWAY_MARK")
    _int(body["count"], "GATEWAY_MARK", 1)
    need(_signed(mark, MARK_LABEL, body["log_signer"]), "GATEWAY_MARK_SIGNATURE")
    if policy is not None:
        need(policy_hash(policy) == body["policy_hash"] and
             canonical(public_policy(policy)) == canonical(body["policy"]), "GATEWAY_MARK_POLICY")
    return {"mark_signature_verified": True, "service": body["policy"]["service"],
            "company": body["policy"]["company"], "head": body["head"], "count": body["count"],
            "totals": deepcopy(body["totals"]), "log_replayed": False}


def verify_export(bundle, *, expected_log_signer, known_marks=()):
    """An auditor's check. Replays every decision; compares with retained marks."""
    _fields(bundle, "version events checkpoint", "GATEWAY_EXPORT")
    need(bundle["version"] == EXPORT_VERSION, "GATEWAY_EXPORT")
    body = _checkpoint(bundle["checkpoint"], expected_log_signer)
    state = replay(bundle["events"], expected_log_signer, audit=True)
    need(state["policy"] is not None, "GATEWAY_EXPORT")
    need(body["head"] == state["head"] and body["count"] == state["count"] and
         body["policy_hash"] == state["policies"][-1] and body["service"] == state["policy"]["service"]
         and canonical(body["totals"]) == canonical(state["totals"]) and
         (state["history"].last_now is None or body["now"] >= state["history"].last_now),
         "GATEWAY_EXPORT_CHECKPOINT")
    for mark in known_marks:
        summary = verify_trust_mark(mark, expected_log_signer=expected_log_signer)
        position = summary["count"]
        need(position <= len(bundle["events"]) and
             bundle["events"][position - 1]["id"] == summary["head"], "GATEWAY_LOG_FORK")
    return {"log_replayed": True, "decisions_match_policy": True,
            "service": state["policy"]["service"], "company": state["policy"]["company"],
            "head": state["head"], "count": state["count"], "policies": len(state["policies"]),
            "totals": state["totals"], "marks_checked": len(known_marks),
            "payloads_checked": False}


def verify_decision_proof(bundle, witness_policy, now):
    """The counterparty's offline check: the decision as logged, included under a witnessed checkpoint."""
    _fields(bundle, "version event proof", "GATEWAY_PROOF")
    need(bundle["version"] == PROOF_VERSION, "GATEWAY_PROOF")
    event = bundle["event"]
    _fields(event, "sequence previous id body", "GATEWAY_PROOF")
    need(event["id"] == identifier(EVENT_LABEL, {"sequence": event["sequence"], "previous": event["previous"],
                                                 "body": event["body"]}), "GATEWAY_PROOF")
    _fields(event["body"], "kind task value", "GATEWAY_PROOF")
    value = event["body"]["value"]
    need(event["body"]["kind"] == "AGENT_GATEWAY_DECISION" and type(bundle["proof"]) is dict and
         bundle["proof"].get("index") == event["sequence"] - 1, "GATEWAY_PROOF")
    _fields(value, "version subject evidence outcome codes", "GATEWAY_PROOF")
    checked = witness_journal.verify_proof(bundle["proof"], witness_policy, now, entry=event["id"])
    return {**checked, "decision": event["id"], "outcome": value["outcome"], "codes": list(value["codes"]),
            "counterparty": value["subject"]["counterparty"], "operation": value["subject"]["operation"]}


def identity_names(events):
    """Decisions that carried an identity, naming the caller key, its did:aap and its SPIFFE ID.

    Read after verify_export: it lists what the log recorded and verifies nothing itself.
    """
    from .spiffe_identity import names
    need(type(events) is list, "GATEWAY_LOG_CHAIN")
    rows = []
    for event in events:
        body = event.get("body") if type(event) is dict else None
        if type(body) is not dict or body.get("kind") != "AGENT_GATEWAY_DECISION":
            continue
        value = body.get("value") if type(body.get("value")) is dict else {}
        subject = value.get("subject") if type(value.get("subject")) is dict else {}
        identity = subject.get("identity")
        if type(identity) is dict and identity.get("version") == "urn:aap:connect-credentials:0.1":
            identity = identity.get("identity")
        if identity is None:
            continue
        row = {"sequence": event.get("sequence"), "decision": event.get("id"),
               "counterparty": subject.get("counterparty"), "operation": subject.get("operation"),
               "outcome": value.get("outcome"),
               "did": None, "spiffe_id": None, "svid_type": None, "organisation": None}
        named = names(identity)
        if named is not None:
            row.update(named)
        elif type(identity) is dict and type(identity.get("body")) is dict:
            row["organisation"] = identity["body"].get("organisation")
        rows.append(row)
    return rows


def agent_card_extension(mark):
    """A2A AgentExtension entry. Callers read it to learn they must sign requests."""
    summary = verify_trust_mark(mark)
    return {"uri": EXTENSION_URI, "required": True,
            "description": ("Calls are admitted by a published AAP gateway policy. Sign each "
                            "request as " + REQUEST_VERSION + ". Decisions are logged."),
            "params": {"requestVersion": REQUEST_VERSION, "service": summary["service"],
                       "policyHash": mark["body"]["policy_hash"],
                       "logSigner": mark["body"]["log_signer"], "trustMark": deepcopy(mark)}}
