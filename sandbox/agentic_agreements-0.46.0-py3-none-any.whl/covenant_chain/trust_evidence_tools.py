"""Keyless agent tool for external trust evidence: HTTP message signatures, agent identity and principal credentials.

Verifies Web Bot Auth, Visa TAP and Mastercard Agent Pay request signatures (RFC 9421), Skyfire KYAPay
tokens, Catena ACK-ID ownership credentials, ANS transparency-log badges and Kleros registry decisions
under keys, issuers and logs the caller adopted, and prepares unsigned key directories, ANS records,
signature bases, Agent Pay rail references and evidence bindings. Every result is labelled evidence that
concerns a did:aap account only through that account's own signature. No signing, fetching,
publication, payment or execution: signing inputs are returned for the owner to sign locally.
"""
from .cooperation_interface import HASH, INT
from .crypto import need
from . import ack_identity
from . import agent_pay
from . import ans_transparency
from . import http_signatures
from . import kleros_signal
from . import kya_tokens
from . import registry_records
from . import trust_evidence
from . import web_bot_auth

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 512}
URL = {'type': 'string', 'pattern': '^https://', 'minLength': 9, 'maxLength': 2048}
DID = {'type': 'string', 'pattern': '^did:', 'minLength': 7, 'maxLength': 2048}
TOKEN = {'type': 'string', 'minLength': 5, 'maxLength': 16384}
DOCUMENT = {'type': 'string', 'minLength': 2, 'maxLength': 65536}
HEADERS = {'type': 'array', 'maxItems': 128, 'items': {'type': 'array', 'minItems': 2, 'maxItems': 2,
                                                       'items': {'type': 'string', 'maxLength': 8192}}}
REQUEST = {'type': 'object', 'additionalProperties': False, 'required': ['method', 'target_uri', 'headers'],
           'properties': {'method': {'type': 'string', 'minLength': 1, 'maxLength': 32},
                          'target_uri': {'type': 'string', 'pattern': '^https?://', 'minLength': 8, 'maxLength': 8192},
                          'headers': HEADERS, 'body': {'type': 'string', 'maxLength': 4194304}}}
RESPONSE = {'type': 'object', 'additionalProperties': False, 'required': ['status', 'headers'],
            'properties': {'status': {'type': 'integer', 'minimum': 100, 'maximum': 599}, 'headers': HEADERS,
                           'body': {'type': 'string', 'maxLength': 4194304}, 'request': REQUEST}}
MESSAGE = {'oneOf': [REQUEST, RESPONSE]}
JWK = {'type': 'object', 'maxProperties': 32}
KEYS = {'description': 'Adopted keys: a JWK set {keys}, a list of JWKs or 64-hex AAP keys.',
        'oneOf': [{'type': 'object', 'required': ['keys'], 'maxProperties': 8,
                   'properties': {'keys': {'type': 'array', 'maxItems': 64, 'items': JWK}}},
                  {'type': 'array', 'maxItems': 64, 'items': {'oneOf': [HASH, JWK]}}]}
ADOPTED = {'description': 'Adopted keys, or {Signature-Agent identifier: keys} so a key only vouches for its own URL.',
           'oneOf': [KEYS, {'type': 'object', 'maxProperties': 64, 'additionalProperties': KEYS,
                            'propertyNames': {'type': 'string', 'pattern': '^https://', 'maxLength': 2048}}]}
NAMES = {'type': 'array', 'maxItems': 32, 'items': {'type': 'string', 'minLength': 1, 'maxLength': 512}}
NONCES = {'type': 'array', 'maxItems': 4096, 'items': {'type': 'string', 'maxLength': 512}}
RECORDS = {'type': 'array', 'maxItems': 16, 'items': {'type': 'object', 'maxProperties': 3}}
PROFILE = {'enum': list(web_bot_auth.PROFILES)}
WINDOW = {'type': 'integer', 'minimum': 1, 'maximum': 2**32}
LOG_LINES = {'type': 'array', 'minItems': 1, 'maxItems': 8, 'items': {'type': 'string', 'minLength': 20, 'maxLength': 800}}
PARAMS = {'type': 'object', 'maxProperties': 16, 'description': 'Signature parameters: created, expires, nonce, alg, keyid, tag.'}
ENDPOINTS = {'type': 'array', 'minItems': 1, 'maxItems': 8, 'items': {
    'type': 'object', 'additionalProperties': False, 'required': ['protocol', 'url'],
    'properties': {'protocol': {'enum': list(registry_records.ANS_PROTOCOLS)}, 'url': TEXT, 'card_url': URL,
                   'card_sha256': HASH}}}
REFERENCE = {'type': 'object', 'additionalProperties': False, 'required': ['kind', 'value'],
             'properties': {'kind': {'enum': sorted(agent_pay.REFERENCES)},
                            'value': {'type': 'string', 'minLength': 8, 'maxLength': 64}}}


def spec():
    return ('covenant_trust_evidence',
        'Experimental external trust evidence. Verify Web Bot Auth, Visa TAP and Mastercard Agent Pay request '
        'signatures (RFC 9421, RFC 9530), Skyfire KYAPay tokens, Catena ACK-ID ownership credentials, ANS '
        'transparency-log badges and Kleros registry decisions under keys, issuers and logs you adopted; prepare '
        'unsigned key directories, ANS records, signature bases, Agent Pay rail references and evidence bindings. '
        'Results are labelled evidence that concern a did:aap account only through that account\'s own signature; '
        'never authority, payment or assent. No signing, fetching, publication or execution.', True, [
        ('describe', {}, ()),
        ('http_signature_base', {'message': MESSAGE, 'covered': NAMES, 'parameters': PARAMS,
                                 'label': {'type': 'string', 'pattern': '^[a-z*][a-z0-9_.*-]{0,63}$'}},
         ('message', 'covered', 'parameters')),
        ('http_signature_verify', {'message': MESSAGE, 'keys': KEYS, 'now': INT, 'label': TEXT,
                                   'tag': {'oneOf': [TEXT, {'type': 'array', 'maxItems': 8,
                                                            'items': {'type': ['string', 'null'], 'maxLength': 128}}]},
                                   'required': NAMES, 'max_age': WINDOW, 'max_window': WINDOW,
                                   'skew': {'type': 'integer', 'minimum': 0, 'maximum': 3600},
                                   'require_created': {'type': 'boolean'}, 'require_expires': {'type': 'boolean'},
                                   'require_nonce': {'type': 'boolean'}, 'seen_nonces': NONCES},
         ('message', 'keys', 'now')),
        ('content_digest', {'body': {'type': 'string', 'maxLength': 4194304},
                            'algorithms': {'type': 'array', 'minItems': 1, 'maxItems': 2,
                                           'items': {'enum': list(http_signatures.DIGESTS)}}}, ('body',)),
        ('web_bot_auth_request', {'request': REQUEST, 'key': HASH, 'created': INT, 'expires': INT, 'profile': PROFILE,
                                  'label': {'type': 'string', 'pattern': '^[a-z*][a-z0-9_.*-]{0,63}$'}, 'agent': URL,
                                  'agent_type': {'enum': list(web_bot_auth.AGENT_TYPES)}, 'legacy': {'type': 'boolean'},
                                  'nonce': {'type': 'string', 'minLength': 1, 'maxLength': 512}, 'tag': TEXT},
         ('request', 'key', 'created', 'expires')),
        ('web_bot_auth_verify', {'request': REQUEST, 'adopted': ADOPTED, 'now': INT, 'profile': PROFILE, 'label': TEXT,
                                 'seen_nonces': NONCES, 'chain': HASH, 'bindings': RECORDS, 'audience': TEXT,
                                 'max_window': WINDOW}, ('request', 'adopted', 'now')),
        ('key_directory', {'keys': {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': HASH}, 'origin': URL,
                           'created': INT, 'expires': INT}, ('keys', 'origin', 'created', 'expires')),
        ('key_directory_verify', {'response': RESPONSE, 'now': INT}, ('response', 'now')),
        ('kya_verify', {'token': TOKEN, 'issuer': URL, 'issuer_keys': KEYS, 'now': INT, 'audience': TEXT, 'env': TEXT,
                        'skew': {'type': 'integer', 'minimum': 5, 'maximum': 60},
                        'max_lifetime': {'type': 'integer', 'minimum': 1, 'maximum': 31536000},
                        'seen_jti': NONCES, 'algorithms': {'type': 'array', 'minItems': 1, 'maxItems': 4,
                                                          'items': {'enum': ['ES256', 'ES384', 'EdDSA', 'RS256', 'PS512']}},
                        'pricing': {'type': 'object', 'additionalProperties': False, 'maxProperties': 2,
                                    'properties': {'tpr': TEXT, 'tps': TEXT}},
                        'request': REQUEST, 'chain': HASH, 'bindings': RECORDS},
         ('token', 'issuer', 'issuer_keys', 'now', 'audience')),
        ('ack_verify', {'credential': {'oneOf': [TOKEN, {'type': 'object', 'maxProperties': 16}]},
                        'trusted_issuers': {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': DID}, 'now': INT,
                        'documents': {'type': 'object', 'maxProperties': 16, 'additionalProperties': DOCUMENT},
                        'status_lists': {'type': 'object', 'maxProperties': 8,
                                         'additionalProperties': {'oneOf': [TOKEN, {'type': 'object', 'maxProperties': 16}]}},
                        'trusted_status_issuers': {'type': 'array', 'maxItems': 16, 'items': DID},
                        'skew': {'type': 'integer', 'minimum': 0, 'maximum': 600}, 'chain': HASH,
                        'did_bindings': RECORDS, 'bindings': RECORDS},
         ('credential', 'trusted_issuers', 'now')),
        ('agent_pay_signal', {'request': REQUEST, 'adopted': ADOPTED, 'now': INT, 'seen_nonces': NONCES, 'chain': HASH,
                              'bindings': RECORDS, 'agreement': HASH}, ('request', 'adopted', 'now')),
        ('agent_pay_statement', {'statement': {'type': 'string', 'minLength': 2, 'maxLength': 16384}, 'source': TEXT,
                                 'agreement': HASH, 'chain': HASH, 'bindings': RECORDS, 'now': INT},
         ('statement', 'source')),
        ('agent_pay_rail', {'currency': TEXT, 'payee': TEXT, 'reference': REFERENCE, 'unit': TEXT},
         ('currency', 'payee', 'reference')),
        ('agent_pay_bind', {'order': {'type': 'object', 'maxProperties': 8}, 'expected_id': HASH}, ('order', 'expected_id')),
        ('kleros_signal', {'entries': {'type': 'array', 'maxItems': 1024, 'items': {'type': 'object', 'maxProperties': 1}},
                           'agent_registry': {'type': 'string', 'pattern': '^eip155:[1-9][0-9]{0,18}:0x[0-9a-fA-F]{40}$',
                                              'maxLength': 70},
                           'oracles': {'type': 'array', 'minItems': 1, 'maxItems': 8,
                                       'items': {'type': 'string', 'pattern': '^0x[0-9a-fA-F]{40}$'}},
                           'documents': {'type': 'array', 'maxItems': 256, 'items': {'type': 'object', 'maxProperties': 2}}},
         ('entries', 'agent_registry', 'oracles')),
        ('ans_badge', {'badge': DOCUMENT, 'log_keys': LOG_LINES, 'bindings': RECORDS, 'now': INT, 'chain': HASH},
         ('badge', 'log_keys')),
        ('ans_checkpoint', {'note': {'type': 'string', 'minLength': 10, 'maxLength': 8192}, 'log_keys': LOG_LINES},
         ('note', 'log_keys')),
        ('ans_records', {'host': TEXT, 'version': {'type': 'string', 'pattern': '^[0-9]+[.][0-9]+[.][0-9]+$', 'maxLength': 32},
                         'endpoints': ENDPOINTS, 'badge_url': URL,
                         'profiles': {'type': 'array', 'minItems': 1, 'maxItems': 2, 'items': {'enum': ['ANS_DNSAID', 'ANS_TXT']}}},
         ('host', 'version', 'endpoints')),
        ('evidence_binding', {'did': DID, 'kind': {'enum': list(trust_evidence.KINDS)}, 'issuer': TEXT, 'subject': TEXT,
                              'evidence_sha256': HASH, 'audience': TEXT, 'issued_at': INT, 'expires': INT, 'nonce': HASH,
                              'holder': {'type': 'string', 'pattern': '^[A-Za-z0-9_-]{43}$'}},
         ('did', 'kind', 'issuer', 'subject', 'evidence_sha256', 'audience', 'issued_at', 'expires', 'nonce')),
    ])


def describe():
    """Compact orientation; each adapter's full describe() stays in its module."""
    return {'tool': 'covenant_trust_evidence', 'status': 'EXPERIMENTAL_ADAPTERS',
            'profiles': [trust_evidence.VERSION, trust_evidence.EVIDENCE],
            'grafts': {'http_signatures': 'RFC 9421, RFC 9530, RFC 8941/9651',
                       'web_bot_auth': web_bot_auth.DRAFT + '; Visa TAP; Mastercard Agent Pay',
                       'kyapay': kya_tokens.DRAFT, 'ack_id': ack_identity.PROTOCOL,
                       'ans': ans_transparency.DRAFT + '; ' + ans_transparency.SPEC,
                       'kleros': kleros_signal.SCHEMA + ' via ERC-8004', 'agent_pay_rail': agent_pay.RAIL},
            'binding': 'EVIDENCE_CONCERNS_A_DID_AAP_ACCOUNT_ONLY_THROUGH_THAT_ACCOUNT_KEY_SIGNATURE',
            'never': ['sign', 'fetch a key, token, directory, badge or document', 'pay or authorize a payment',
                      'accept card data', 'grant authority or assent'],
            'guide': 'docs/TRUST_EVIDENCE.html', 'signing_in_tool': False, 'network_accessed': False,
            'authority_granted': False, 'execution_authorized': False}


def _flag(result):
    if type(result) is dict:
        result.setdefault('execution_authorized', False)
        result.setdefault('authority_granted', False)
    return result


def _checkpoint(note, lines):
    origin, size, root = ans_transparency.checkpoint(note, lines)
    return {'origin': origin, 'size': size, 'root': root.hex(), 'consistency': 'NOT_CHECKED'}


ACTIONS = {
    'describe': lambda p: describe(),
    'http_signature_base': lambda p: http_signatures.prepare(p['message'], p['covered'], p['parameters'],
                                                             p.get('label', 'sig1')),
    'http_signature_verify': lambda p: http_signatures.verify(p.pop('message'), p.pop('keys'), p.pop('now'), **p),
    'content_digest': lambda p: _flag({'content_digest': http_signatures.content_digest(
        p['body'], tuple(p.get('algorithms', ('sha-256',))))}),
    'web_bot_auth_request': lambda p: web_bot_auth.prepare_request(p.pop('request'), p.pop('key'), p.pop('created'),
                                                                   p.pop('expires'), **p),
    'web_bot_auth_verify': lambda p: web_bot_auth.verify_request(p.pop('request'), p.pop('adopted'), p.pop('now'), **p),
    'key_directory': lambda p: web_bot_auth.directory(p['keys'], p['origin'], p['created'], p['expires']),
    'key_directory_verify': lambda p: web_bot_auth.verify_directory(p['response'], p['now']),
    'kya_verify': lambda p: kya_tokens.verify(p.pop('token'), p.pop('issuer'), p.pop('issuer_keys'), p.pop('now'), **p),
    'ack_verify': lambda p: ack_identity.verify(p.pop('credential'), p.pop('trusted_issuers'), p.pop('now'), **p),
    'agent_pay_signal': lambda p: agent_pay.verify_signal(p.pop('request'), p.pop('adopted'), p.pop('now'), **p),
    'agent_pay_statement': lambda p: agent_pay.record_signal(p.pop('statement'), p.pop('source'), **p),
    'agent_pay_rail': lambda p: _flag({'rail': agent_pay.rail(p['currency'], p['payee'], p['reference'], p.get('unit', 'minor')),
                                       'use': 'covenant_interoperate work-order draft payment', 'payment_authorized': False}),
    'agent_pay_bind': lambda p: agent_pay.bind(p['order'], p['expected_id']),
    'kleros_signal': lambda p: kleros_signal.signal(p['entries'], p['agent_registry'], p['oracles'], p.get('documents')),
    'ans_badge': lambda p: ans_transparency.badge(p.pop('badge'), p.pop('log_keys'), **p),
    'ans_checkpoint': lambda p: _checkpoint(p['note'], p['log_keys']),
    'ans_records': lambda p: registry_records.ans_profile_records(p.pop('host'), p.pop('version'), p.pop('endpoints'), **p),
    'evidence_binding': lambda p: trust_evidence.binding(p.pop('did'), p.pop('kind'), p.pop('issuer'), p.pop('subject'),
                                                         p.pop('evidence_sha256'), p.pop('audience'), p.pop('issued_at'),
                                                         p.pop('expires'), p.pop('nonce'), holder=p.get('holder')),
}


def call(action, parameters):
    need(type(action) is str and action in ACTIONS and type(parameters) is dict, 'TRUST_EVIDENCE_TOOL_ACTION')
    return _flag(ACTIONS[action](dict(parameters)))
