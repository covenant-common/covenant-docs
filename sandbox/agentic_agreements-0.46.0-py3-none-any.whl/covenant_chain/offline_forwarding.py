"""Explicit owner routing across BLE and adopted intermittent carriers.

Preserves the original signed encrypted packet. No automatic execution, node
provisioning, network discovery, satellite subscription or global finality.
"""
from copy import deepcopy
import hashlib

from . import crypto as c, offline as o

HOP = 'covenant-offline-hop-receipt/0.1'
LABEL = 'COVENANT-OFFLINE-HOP-RECEIPT-0.1'
LINK = 'covenant-offline-link/0.1'


def hop_receipt(packet, signing_key, *, at):
    ref = o.packet_id(packet); c.integer(at)
    c.need(packet['header']['created'] <= at < packet['header']['expires'], 'FORWARD_RECEIPT_TIME')
    body = {'version': HOP, 'packet': ref, 'scope': packet['header']['scope'],
            'peer': c.public_key(signing_key), 'bytes_sha256': hashlib.sha256(c.canonical(packet)).hexdigest(),
            'at': at, 'status': 'HOP_RETAINED'}
    return {'body': body, 'signature': c.sign(signing_key, LABEL, body)}


def verify_hop_receipt(receipt, packet, *, expected_peer, now):
    c.verification_key(expected_peer); c.integer(now)
    c.exact(receipt, 'body signature'); body = receipt['body']
    c.exact(body, 'version packet scope peer bytes_sha256 at status'); c.integer(body['at'])
    c.need(body['version'] == HOP and body['packet'] == o.packet_id(packet) and
           body['peer'] == expected_peer and body['scope'] == packet['header']['scope'] and
           body['bytes_sha256'] == hashlib.sha256(c.canonical(packet)).hexdigest() and
           body['status'] == 'HOP_RETAINED' and packet['header']['created'] <= body['at'] <
           packet['header']['expires'] and body['at'] <= now, 'FORWARD_RECEIPT_SCOPE')
    c.verify(expected_peer, LABEL, body, receipt['signature'])
    return {'delivery': 'HOP_RETAINED', 'peer_assertion_verified': True,
            'end_recipient_verified': False, 'agreement_accepted': False,
            'execution_authorized': False, 'payment_verified': False, 'ledger_confirmed': False}


def descriptor(name, carrier, peer, max_packet, *, relay=False, cost_units=0, interface=None):
    value = dict(version=LINK, name=name, carrier=carrier, peer=peer, max_packet=max_packet,
                 relay=relay, cost_units=cost_units, interface=deepcopy({} if interface is None else interface))
    link_id(value)
    return value


def link_id(value):
    c.exact(value, 'version name carrier peer max_packet relay cost_units interface')
    c.need(value['version'] == LINK and type(value['name']) is str and 0 < len(value['name']) <= 64 and
           type(value['carrier']) is str and 0 < len(value['carrier']) <= 64 and
           type(value['interface']) is dict and type(value['relay']) is bool and
           type(value['max_packet']) is int and 1 <= value['max_packet'] <= o.MAX_PACKET, 'FORWARD_LINK')
    c.verification_key(value['peer']); c.integer(value['cost_units'])
    c.need(len(c.canonical(value)) <= 16384, 'FORWARD_LINK_SIZE')
    return c.digest('COVENANT-OFFLINE-LINK-0.1', value)


class AdoptedLink:
    """Owner-installed callbacks, not code or URLs taken from a packet.

    available(packet) is a current owner assertion. async send(raw) returns a
    signed hop receipt. It can wrap a BLE client, IP socket over cellular or
    satellite, a modem SDK or a future technology. The descriptor is inert.
    """
    def __init__(self, description, *, available, send):
        self.description = deepcopy(description); self.id = link_id(self.description)
        c.need(callable(available) and callable(send), 'FORWARD_CALLBACK')
        self.available, self.send = available, send


async def forward_once(vault, links, *, clock, packet_limit=4, byte_budget=32768,
                       cost_budget=0, timeout=30):
    import asyncio
    c.integer(byte_budget); c.integer(cost_budget)
    c.need(callable(clock) and type(links) in (tuple, list) and 1 <= len(links) <= 8 and
           all(isinstance(link, AdoptedLink) for link in links) and
           len({link.id for link in links}) == len(links) and type(packet_limit) is int and
           1 <= packet_limit <= 16 and type(timeout) is int and 1 <= timeout <= 3600,
           'FORWARD_POLICY')
    submitted = spent = 0; results = []
    now = clock(); c.integer(now)
    for row in vault.pending(now=now, limit=packet_limit):
        packet = row['packet']; ref = row['id']; raw = c.canonical(packet)
        records = None
        with vault._locked(): records = vault._records()
        selected = None
        for link in sorted(links, key=lambda v: (v.description['cost_units'], v.id)):
            c.need(link_id(link.description) == link.id, 'FORWARD_LINK_CHANGED')
            d = link.description
            if ('forward:'+ref+':'+link.id) in records or len(raw) > d['max_packet']: continue
            if not d['relay'] and d['peer'] != packet['header']['recipient']: continue
            if submitted+len(raw) > byte_budget or spent+d['cost_units'] > cost_budget: continue
            available = link.available(deepcopy(packet))
            c.need(type(available) is bool, 'FORWARD_AVAILABILITY')
            if available: selected = link; break
        if selected is None:
            results.append({'packet': ref, 'status': 'NO_ADOPTED_LINK_WITHIN_BUDGET'})
            continue
        c.need(link_id(selected.description) == selected.id, 'FORWARD_LINK_CHANGED')
        policy = deepcopy(selected.description)
        # Reserve durable retry/backoff BEFORE a possible transport effect.
        vault.record_attempt(ref, now=now)
        submitted += len(raw); spent += policy['cost_units']
        try:
            receipt = await asyncio.wait_for(selected.send(raw), timeout=timeout)
            finished = clock(); c.integer(finished)
            c.need(finished >= now, 'FORWARD_CLOCK_ROLLBACK')
            c.need(link_id(selected.description) == selected.id, 'FORWARD_LINK_CHANGED')
            verify_hop_receipt(receipt, packet, expected_peer=policy['peer'], now=finished)
            with vault._locked():
                # Callback must not hold this vault lock. Keep original bytes;
                # a relay receipt never closes the native end-recipient queue.
                vault._clock(finished, vault._records())
                vault._put('forward:'+ref+':'+selected.id, {'receipt': receipt})
            status = 'HOP_RETAINED'
        except Exception:
            status = 'UNKNOWN_TRANSPORT_OUTCOME'
        results.append({'packet': ref, 'link': selected.id, 'status': status})
        now = clock(); c.integer(now)
    return {'results': results, 'application_bytes_reserved': submitted,
            'quoted_cost_units_reserved': spent, 'payment_executed': False,
            'ledger_confirmed': False, 'end_recipient_verified': False}


def describe_hop():
    """Hop-receipt profile (salvaged Cursor PR 58). A hop is custody, not payment and not execution."""
    return {'hop': HOP, 'link': LINK, 'execution_authorized': False}
