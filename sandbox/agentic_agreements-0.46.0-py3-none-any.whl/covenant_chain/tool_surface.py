"""Owner-adopted tool extensions and least-privilege, portable tool surfaces.

Agents can author packages as data. Only the host owner supplies callbacks and
adopts the exact package hash. A READ declaration is an owner assertion, not an
audit or a sandbox. New application layers still use ApplicationRegistry.
"""
from copy import deepcopy
import hashlib
import json
import re

from .agent_tools import validate_json, decode, _fields
from .crypto import need, key
from .tool_input import validate_schema

VERSION = 'covenant-tool-package/0.1'
NAME = re.compile(r'[A-Za-z][A-Za-z0-9_]{0,63}\Z')


def _wire(value):
    validate_json(value)
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode('ascii')


def _id(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + _wire(value)).hexdigest()


def package(name, release, implementation, tools, dependencies=()):
    """Draft an inert extension manifest. No fetching, import or registration."""
    value = {'version': VERSION, 'name': name, 'release': release,
             'implementation': implementation, 'tools': deepcopy(tools),
             'dependencies': sorted(dependencies)}
    return {'id': package_id(value), 'manifest': value, 'installed': False,
            'execution_authorized': False, 'security_inherited': False}


def package_id(value):
    validate_json(value)
    _fields(value, ('version', 'name', 'release', 'implementation', 'tools', 'dependencies'))
    need(value['version'] == VERSION, 'TOOL_PACKAGE_VERSION')
    need(type(value['name']) is str and NAME.fullmatch(value['name']), 'TOOL_PACKAGE_NAME')
    need(type(value['release']) is str and 0 < len(value['release']) <= 64, 'TOOL_PACKAGE_RELEASE')
    key(value['implementation'])
    dependencies = value['dependencies']
    need(type(dependencies) is list and len(dependencies) <= 32
         and all(type(x) is str for x in dependencies)
         and dependencies == sorted(set(dependencies)), 'TOOL_PACKAGE_DEPENDENCIES')
    for ref in dependencies:
        key(ref)
    rows = value['tools']
    need(type(rows) is list and 1 <= len(rows) <= 32, 'TOOL_PACKAGE_LIMIT')
    seen = set()
    for row in rows:
        _fields(row, ('name', 'description', 'inputSchema', 'classification'))
        need(type(row['name']) is str and NAME.fullmatch(row['name'])
             and row['name'] not in seen, 'TOOL_PACKAGE_TOOL_NAME')
        seen.add(row['name'])
        need(type(row['description']) is str and 0 < len(row['description']) <= 4096,
             'TOOL_PACKAGE_DESCRIPTION')
        need(type(row['inputSchema']) is dict and row['inputSchema'].get('type') == 'object',
             'TOOL_PACKAGE_SCHEMA')
        _schema(row['inputSchema'])
        need(row['classification'] in ('READ', 'WRITE', 'SENSITIVE_WRITE'), 'TOOL_PACKAGE_CLASSIFICATION')
    return _id('COVENANT-TOOL-PACKAGE-0.1', value)


def _schema(shape, depth=0):
    """Reject unsupported schema assertions rather than silently ignore them.

    Native tool values use exact bounded integers; external formats can be
    carried as explicit text and interpreted by an owner-adopted backend.
    """
    need(type(shape) is dict and depth <= 32, 'TOOL_PACKAGE_SCHEMA')
    allowed = {'type', 'description', 'title', 'const', 'enum', 'oneOf', 'properties',
               'required', 'additionalProperties', 'items', 'minItems', 'maxItems',
               'minLength', 'maxLength', 'minimum', 'maximum'}
    need(set(shape) <= allowed, 'TOOL_PACKAGE_UNSUPPORTED_SCHEMA')
    if 'type' in shape:
        choices = shape['type'] if type(shape['type']) is list else [shape['type']]
        need(0 < len(choices) <= 7 and all(type(t) is str and t in
             ('object', 'array', 'string', 'integer', 'boolean', 'null') for t in choices),
             'TOOL_PACKAGE_SCHEMA_TYPE')
    if 'properties' in shape:
        need(type(shape['properties']) is dict, 'TOOL_PACKAGE_SCHEMA')
        for child in shape['properties'].values():
            _schema(child, depth + 1)
    if 'required' in shape:
        need(type(shape['required']) is list and all(type(x) is str for x in shape['required'])
             and set(shape['required']) <= set(shape.get('properties', {})), 'TOOL_PACKAGE_SCHEMA')
    if 'additionalProperties' in shape:
        need(type(shape['additionalProperties']) is bool, 'TOOL_PACKAGE_SCHEMA')
    if 'items' in shape:
        _schema(shape['items'], depth + 1)
    if 'oneOf' in shape:
        need(type(shape['oneOf']) is list and 1 <= len(shape['oneOf']) <= 32, 'TOOL_PACKAGE_SCHEMA')
        for child in shape['oneOf']:
            _schema(child, depth + 1)
    if 'enum' in shape:
        need(type(shape['enum']) is list and 1 <= len(shape['enum']) <= 128, 'TOOL_PACKAGE_SCHEMA')
    for name in ('minItems', 'maxItems', 'minLength', 'maxLength', 'minimum', 'maximum'):
        if name in shape:
            need(type(shape[name]) is int, 'TOOL_PACKAGE_SCHEMA')


class ExtensionTools:
    """An owner-composed tool source, usable with stdio, MCP HTTP or Grok.

    Installed callbacks execute with the owner's process permissions. Isolate
    untrusted implementations separately. No agent operation installs a tool.
    """
    def __init__(self, base):
        self.base = base
        self._base_tools = deepcopy(base.list_tools())
        self._base_pin = _id('COVENANT-BASE-TOOL-CATALOG-0.1', self._base_tools)
        self._entries = {}
        self._packages = {}

    def _check(self):
        need(_id('COVENANT-BASE-TOOL-CATALOG-0.1', self.base.list_tools()) == self._base_pin,
             'TOOL_SOURCE_CHANGED')

    def register(self, manifest, handlers, *, expected_id):
        self._check()
        ref = package_id(manifest)
        need(ref == expected_id and ref not in self._packages, 'TOOL_PACKAGE_PIN')
        need(len(self._packages) < 32, 'TOOL_PACKAGE_REGISTRY_LIMIT')
        need(all(x in self._packages for x in manifest['dependencies']), 'TOOL_PACKAGE_DEPENDENCY_MISSING')
        names = {r['name'] for r in manifest['tools']}
        need(type(handlers) is dict and set(handlers) == names and all(callable(f) for f in handlers.values()),
             'TOOL_PACKAGE_HANDLERS')
        need(not names & ({r['name'] for r in self._base_tools} | set(self._entries)), 'TOOL_PACKAGE_NAME_COLLISION')
        # Snapshot data and function identities, not a caller-owned mutable dict.
        self._packages[ref] = deepcopy(manifest)
        for row in manifest['tools']:
            readonly = row['classification'] == 'READ'
            descriptor = {k: deepcopy(row[k]) for k in ('name', 'description', 'inputSchema')}
            descriptor['annotations'] = {'readOnlyHint': readonly, 'destructiveHint': not readonly,
                                         'idempotentHint': False, 'openWorldHint': True}
            self._entries[row['name']] = (descriptor, handlers[row['name']], ref)
        return ref

    def list_tools(self):
        self._check()
        return deepcopy(self._base_tools + [v[0] for v in self._entries.values()])

    def call(self, name, arguments):
        self._check()
        validate_json(arguments)
        if name not in self._entries:
            return self.base.call(name, arguments)
        descriptor, callback, _ = self._entries[name]
        validate_schema(arguments, descriptor['inputSchema'])
        result = callback(deepcopy(arguments))
        need(type(result) is dict, 'TOOL_PACKAGE_RESULT_OBJECT')
        validate_json(result)
        return deepcopy(result)


class ScopedTools:
    """Snapshot an explicit owner allowlist, flattening multi-action tools.

    A remote client cannot widen the set. This surface deliberately accepts
    READ tools only; native signing, publication and execution stay separate.
    """
    def __init__(self, source, allow):
        validate_json(allow)
        need(type(allow) is dict and 0 < len(allow) <= 64, 'TOOL_SURFACE_ALLOWLIST')
        self.source = source
        catalog = source.list_tools()
        self._source_pin = _id('COVENANT-TOOL-SOURCE-0.1', catalog)
        by_name = {t['name']: t for t in catalog}
        need(len(by_name) == len(catalog), 'TOOL_SURFACE_DUPLICATE')
        self._routes = {}
        self._tools = []
        for name, actions in allow.items():
            need(name in by_name, 'TOOL_SURFACE_UNKNOWN_TOOL')
            t = by_name[name]
            need(t.get('annotations', {}).get('readOnlyHint') is True, 'TOOL_SURFACE_READ_ONLY')
            if actions is None:
                need('oneOf' not in t['inputSchema'] and 'action' not in t['inputSchema'].get('properties', {}),
                     'TOOL_SURFACE_ACTIONS_REQUIRED')
                self._add(name, name, None, t['inputSchema'], t['description'], t['annotations'])
            else:
                need(type(actions) is list and 0 < len(actions) <= 64
                     and all(type(a) is str for a in actions) and len(set(actions)) == len(actions),
                     'TOOL_SURFACE_ACTIONS')
                variants = t['inputSchema'].get('oneOf', [])
                variants = {v['properties']['action']['const']: v['properties']['parameters'] for v in variants}
                need(all(a in variants for a in actions), 'TOOL_SURFACE_UNKNOWN_ACTION')
                for action in actions:
                    self._add(name + '__' + action, name, action, variants[action],
                              t['description'] + ' Selected action: ' + action + '.', t['annotations'])
        need(len(self._tools) <= 128, 'TOOL_SURFACE_LIMIT')
        self.id = _id('COVENANT-SCOPED-TOOLS-0.1', self._tools)

    def _add(self, exposed, original, action, shape, description, annotations):
        need(len(exposed) <= 64 and NAME.fullmatch(exposed) and exposed not in self._routes,
             'TOOL_SURFACE_NAME')
        self._routes[exposed] = (original, action, deepcopy(shape))
        self._tools.append({'name': exposed, 'description': description, 'inputSchema': deepcopy(shape),
            'annotations': {'readOnlyHint': True, 'destructiveHint': False,
                            'idempotentHint': False,
                            'openWorldHint': annotations.get('openWorldHint', True)}})

    def _check(self):
        need(_id('COVENANT-TOOL-SOURCE-0.1', self.source.list_tools()) == self._source_pin,
             'TOOL_SOURCE_CHANGED')

    def list_tools(self):
        self._check()
        return deepcopy(self._tools)

    def call(self, name, arguments):
        self._check()
        need(type(name) is str and name in self._routes, 'TOOL_SURFACE_NOT_ALLOWED')
        validate_json(arguments)
        original, action, shape = self._routes[name]
        validate_schema(arguments, shape)
        return self.source.call(original, deepcopy(arguments) if action is None else
                                {'action': action, 'parameters': deepcopy(arguments)})


DEFAULT_ALLOW = {
    'covenant_provider': ['describe', 'command', 'receipt', 'handover', 'replica_describe', 'replica_command', 'private_describe', 'private_command', 'private_receipt'],
    'covenant_reliance': ['policy', 'intent', 'recover', 'plan', 'outcomes', 'qualification'],
    'covenant_contract': ['draft', 'inspect', 'amend', 'compare', 'render'],
    'covenant_concept': ['simple', 'prepare', 'review'],
    'covenant_agreement': ['prepare', 'review', 'revise', 'private_copy', 'reopen'],
    'covenant_review': ['spec', 'case', 'review', 'render', 'authority', 'evidence', 'compare'],
    'covenant_marketplace': ['quick_trade'],
    'covenant_ads': ['directory', 'promote', 'escrow'],
    'covenant_developer': ['draft', 'inspect', 'resolve', 'policy', 'quote', 'scenario', 'service_model', 'scaffold'],
    'covenant_builder': ['spec', 'draft', 'inspect'],
    'covenant_standards': ['blueprints', 'draft', 'inspect', 'inspect_source', 'a2a_extension', 'inspect_a2a', 'linked_data'],
    'covenant_a2a_agreement': ['spec', 'prepare_request', 'draft', 'attach', 'verify', 'verify_receipt', 'verify_evidence', 'decode_artifact'],
    'covenant_offline': ['spec', 'draft', 'review', 'verify_history'],
    'covenant_portable_trust': ['atr_hash', 'verify_atr', 'verify_opencovenant_receipt', 'verify_causal_receipt', 'verify_trust_bundle'],
    'covenant_robotics': ['spec', 'binding', 'draft', 'review', 'massrobotics_status'],
    'covenant_connectivity': ['spec', 'descriptor', 'plan', 'verify_hop'],
    'covenant_find': ['search'],
    'covenant_explain': ['action'],
    'covenant_draft': ['sentence'],
    'covenant_lint': ['check'],
    'covenant_simulate': ['run'],
    'covenant_counter': ['propose'],
    'covenant_feedback': ['report', 'issue', 'dashboard'],
    'covenant_onboard': ['start', 'guide', 'taxonomy', 'work', 'preview', 'discover', 'ensure_key', 'registry', 'free_tier'],
    'covenant_invite': ['draft', 'accept', 'transport', 'accountability'],
    'covenant_growth': ['card', 'qualify', 'leaderboard', 'boundary', 'clawback'],
    'covenant_directory': ['search', 'profile', 'feed', 'graph', 'page', 'index', 'draft', 'share'],
    'covenant_principal': ['describe', 'draft', 'review', 'authorize', 'narrow', 'kill'],
    'covenant_surface': ['describe', 'inventory'],
    'covenant_tool_catalog': ['list'],
}


# Credential-free offline receipt checks (PR 73 WP-19). agent_server --trust
# serves this over stdio; an agent_connector grant can serve it over HTTP.
TRUST_ALLOW = {
    'covenant_portable_trust': ['describe', 'atr_hash', 'verify_atr', 'verify_opencovenant_receipt',
                                'verify_causal_receipt', 'verify_trust_bundle', 'local_reputation'],
    'covenant_credential': ['profile', 'verify'],
}


def keyless_surface(allow=None):
    from .runtime_host import RuntimeHost
    host = RuntimeHost({'version': 'covenant-runtime-host/0.1',
        'read_tools': {'version': 'covenant-agent-tools/0.1', 'templates': {}, 'targets': {}},
        'cooperation': {'version': 'covenant-cooperation-interface/0.1'}})
    return ScopedTools(host.tools, DEFAULT_ALLOW if allow is None else allow)


def grok_functions(surface):
    """xAI Responses function definitions. No server-side tools are added."""
    return [{'type': 'function', 'name': t['name'], 'description': t['description'],
             'parameters': deepcopy(t['inputSchema'])} for t in surface.list_tools()]


def grok_tool_result(surface, call):
    """Explicitly dispatch one owner-permitted local READ proposal.

    This function never calls a model, spends money or loops autonomously.
    """
    _fields(call, ('type', 'call_id', 'name', 'arguments'), ('id', 'status'))
    need(call['type'] == 'function_call' and type(call['call_id']) is str
         and 0 < len(call['call_id']) <= 256, 'GROK_FUNCTION_CALL')
    arguments = decode(call['arguments'])
    value = surface.call(call['name'], arguments)
    return {'type': 'function_call_output', 'call_id': call['call_id'],
            'output': _wire(value).decode('ascii')}
