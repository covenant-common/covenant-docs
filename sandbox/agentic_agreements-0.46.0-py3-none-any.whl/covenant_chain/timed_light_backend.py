"""Pinned second-language light reader using the existing bounded local runner."""
from pathlib import Path
import hashlib
import json
import shutil
from . import independent_replay as runner

ENTRY='timed_light_02.mjs'


def describe():
    root=runner.ASSETS;path=root/ENTRY
    runner._need(path.is_file() and not path.is_symlink() and path.stat().st_size<=1000000,'TIMED_READER_ASSETS')
    runner._bundle()  # Verify the maintained imported dependency files first.
    from .timed_light import independent_verifier
    source=independent_verifier();pin=source['id']
    return {'profile':'urn:aap:timed-independent-reader:0.1','verifier':pin,'sources':source,
        'assurance':'INDEPENDENT_NODE_CERTIFICATE_AND_MERKLE_CHECK; NO_PYTHON_PROOF_ORACLE',
        'genesis_admission':'PINNED_CHAIN_AND_COMMITTEE_ONLY; NOT_FULL_APPLICATION_GENESIS_OR_HISTORY',
        'execution_authorized':False,'network_accessed':False,'runtime':'OWNER_INSTALLED_NODE_PERMISSION_MODE_REQUIRED'}


def verify(genesis,bundle,expected_chain,minimum_height,expected_table,expected_key,expected_verifier,
           expected_protocol=None,expected_head=None,minimum_time=None,expected_genesis=None):
    descriptor=describe();runner._need(expected_verifier==descriptor['verifier'],'TIMED_READER_PIN')
    request={'genesis':genesis,'bundle':bundle,'expected_chain':expected_chain,'minimum_height':minimum_height,
             'table':expected_table,'key':expected_key}
    for name,value in (('expected_protocol',expected_protocol),('expected_head',expected_head),('minimum_time',minimum_time),('expected_genesis',expected_genesis)):
        if value is not None:request[name]=value
    raw=runner._wire(request);node=shutil.which('node');runner._need(node is not None,'INDEPENDENT_NODE_REQUIRED')
    command=[str(Path(node).resolve()),'--permission','--allow-fs-read='+str(runner.ASSETS),
             '--max-old-space-size=192',str(runner.ASSETS/ENTRY)]
    code,stdout,stderr=runner._run(command,raw)
    try:result=json.loads(stdout if code==0 else stderr)
    except (ValueError,UnicodeError):raise ValueError('TIMED_READER_RUNTIME_UNAVAILABLE') from None
    runner._need(type(result) is dict,'TIMED_READER_RESPONSE')
    if code:
        error=result.get('error');runner._need(type(error) is str and len(error)<=100 and all(c.isupper() or c.isdigit() or c in '_:' for c in error),'TIMED_READER_RESPONSE')
        raise ValueError('TIMED_READER_REFUSED:'+error)
    runner._need(result.get('profile')=='covenant-native-light/0.2' and result.get('execution_authorized') is False,'TIMED_READER_RESPONSE')
    return {**result,'verifier':descriptor['verifier'],'backend':'INDEPENDENT_NODE','network_accessed':False}
