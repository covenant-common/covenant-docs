"""Signed SLA events from verified resource observations.

Maturity: experimental. Off unless the host passes ``enabled=True`` (host flag
``sla_telemetry``). The host checks each observation envelope a
``ResourceObservationAdapter`` recorded with ``resource_observations.verify_observation``
(source-key signature, exact resource, query, context and source, optional
predicate) and signs what it observed against one deadline:

* ``OK`` / ``ON_TIME``: a verified reading was observed by the deadline;
* ``BREACH`` / ``LATE``: the earliest verified reading came after it;
* ``BREACH`` / ``MISSED``: no verified reading, and the deadline has passed;
* ``PENDING`` / ``NOT_YET_DUE``: no verified reading yet, deadline not passed.

The signed body says so in ``statement``: it is the host's view of the readings
it was given. ``observed_at`` is the source's claim, ``as_of`` is the host clock,
and the source key is named so a counterparty can apply its own pins. Nothing
here is world truth, a dashboard or a ledger change.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847). There the rows were
caller-supplied ids and times, MISSED fired before the deadline and LATE fired
even after an on-time reading; all three are fixed here.
"""
from __future__ import annotations

import json

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify

EVENT_VERSION = 'covenant-sla-breach-event/0.1'
LABEL = 'COVENANT-SLA-BREACH-EVENT-0.1'
STATEMENT = 'HOST_SIGNS_THE_VERIFIED_READINGS_IT_WAS_GIVEN_NOT_WORLD_TRUTH'
MAX_OBSERVATIONS = 64
OUTCOMES = {('OK', 'ON_TIME'), ('BREACH', 'LATE'), ('BREACH', 'MISSED'), ('PENDING', 'NOT_YET_DUE')}
BODY_FIELDS = ('version statement status reason deadline as_of context source source_key asset query predicate '
               'observation observed_at readings rejected')
ANY_AGE = 2 ** 53 - 1


def _policy(policy):
    from .resource_observations import query_id, resource_id
    exact(policy, 'deadline asset query context source source_key predicate')
    integer(policy['deadline'])
    key(policy['context'])
    key(policy['source'])
    verification_key(policy['source_key'])
    return resource_id(policy['asset']), query_id(policy['query'])


def evaluate(policy, observations, now, signing_key, *, enabled=False):
    """Sign the host's SLA view of verified observation envelopes at host time ``now``."""
    need(enabled is True, 'PLUGIN_DISABLED')
    from .resource_observations import verify_observation
    resource, query = _policy(policy)
    integer(now)
    need(type(observations) is list and len(observations) <= MAX_OBSERVATIONS, 'SLA_OBSERVATIONS')
    counted = []
    rejected = 0
    for envelope in observations:
        try:
            report = verify_observation(envelope, policy['asset'], policy['query'], policy['context'], policy['source'],
                                        policy['source_key'], now, ANY_AGE, policy['predicate'])
        except (ValueError, TypeError, KeyError):
            rejected += 1
            continue
        wanted = 'OBSERVED' if policy['predicate'] is None else 'SATISFIED'
        if report['status'] == wanted:
            counted.append((envelope['body']['observed_at'], report['observation']))
    counted.sort()
    on_time = [row for row in counted if row[0] <= policy['deadline']]
    if on_time:
        status, reason, chosen = 'OK', 'ON_TIME', on_time[0]
    elif counted:
        status, reason, chosen = 'BREACH', 'LATE', counted[0]
    elif now > policy['deadline']:
        status, reason, chosen = 'BREACH', 'MISSED', None
    else:
        status, reason, chosen = 'PENDING', 'NOT_YET_DUE', None
    body = {
        'version': EVENT_VERSION, 'statement': STATEMENT, 'status': status, 'reason': reason,
        'deadline': policy['deadline'], 'as_of': now, 'context': policy['context'], 'source': policy['source'],
        'source_key': policy['source_key'], 'asset': resource, 'query': query, 'predicate': policy['predicate'],
        'observation': None if chosen is None else chosen[1], 'observed_at': None if chosen is None else chosen[0],
        'readings': len(counted), 'rejected': rejected,
    }
    canonical(body)
    return {'body': body, 'public': public_key(signing_key), 'signature': sign(signing_key, LABEL, body),
            'id': digest(LABEL, body), 'execution_authorized': False}


def verify_event(signed, *, signers=None):
    """True for an untampered event of a known outcome; with ``signers``, only from a pinned host key."""
    if type(signed) is not dict or not {'body', 'public', 'signature'} <= set(signed) or \
            not set(signed) <= {'body', 'public', 'signature', 'id', 'execution_authorized'} or type(signed.get('public')) is not str:
        return False
    if signers is not None and signed['public'] not in signers:
        return False
    body = signed['body']
    try:
        exact(body, BODY_FIELDS)
        need(body['version'] == EVENT_VERSION and body['statement'] == STATEMENT, 'SLA_EVENT')
        need((body['status'], body['reason']) in OUTCOMES, 'SLA_EVENT')
        for name in ('deadline', 'as_of', 'readings', 'rejected'):
            integer(body[name])
        need((body['observation'] is None) == (body['reason'] in ('MISSED', 'NOT_YET_DUE')), 'SLA_EVENT')
        if body['observation'] is None:
            need(body['observed_at'] is None, 'SLA_EVENT')
        else:
            key(body['observation'])
            integer(body['observed_at'])
        need('id' not in signed or signed['id'] == digest(LABEL, body), 'SLA_EVENT')
        need(signed.get('execution_authorized', False) is False, 'SLA_EVENT')
        verify(signed['public'], LABEL, body, signed['signature'])
    except (ValueError, TypeError):
        return False
    return True


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Signed SLA events from verified observations. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    args = parser.parse_args(argv)
    print(json.dumps({'plugin': 'sla_telemetry', 'enabled': bool(args.enabled), 'statement': STATEMENT,
                      'maturity': 'experimental', 'execution_authorized': False}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
