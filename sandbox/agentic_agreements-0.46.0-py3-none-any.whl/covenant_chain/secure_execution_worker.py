"""Fixed private-pipe worker for secure-execution-0.1; never a command runner.

The owner-controlled parent launches this exact source under Seatbelt. Its first
record contains public policy and TLS custody paths, never bound credentials.
It checks mTLS and the server certificate pin before requesting bindings. No
remote response bytes, status, headers, exceptions or hashes leave the worker.
"""
import hashlib
from datetime import datetime, timezone
import http.client
import json
import ssl
import sys

from cryptography import x509


def _record(limit):
    raw = sys.stdin.buffer.readline(limit + 1)
    if len(raw) > limit or not raw.endswith(b'\n'):
        raise ValueError('BOUND')
    return json.loads(raw)


def main():
    connection = None
    bound = False
    try:
        policy = _record(131072)
        tls = policy['tls']
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_3
        context.verify_flags |= ssl.VERIFY_X509_STRICT
        context.keylog_filename = None
        context.options |= ssl.OP_NO_COMPRESSION
        context.set_alpn_protocols(['http/1.1'])
        context.load_verify_locations(cafile=tls['ca_file'])
        context.load_cert_chain(tls['cert_file'], tls['key_file'])
        with open(tls['cert_file'], encoding='ascii') as certificate:
            pem = certificate.read()
            client_pin = hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest()
        client_cert = x509.load_pem_x509_certificate(pem.encode('ascii'))
        now = datetime.now(timezone.utc)
        if not client_cert.not_valid_before_utc <= now < client_cert.not_valid_after_utc:
            raise ValueError('EXECUTOR_EXPIRED')
        if client_pin != policy['executor_pin']:
            raise ValueError('EXECUTOR_PIN')
        connection = http.client.HTTPSConnection('127.0.0.1', policy['port'],
                                                  context=context, timeout=policy['timeout'])
        connection.connect()
        peer = hashlib.sha256(connection.sock.getpeercert(binary_form=True)).hexdigest()
        if peer != policy['server_pin']:
            raise ValueError('PIN')
        print('READY', flush=True)
        bindings = _record(131072)
        bound = True
        headers = dict(policy['headers'])
        for row in policy['bindings']:
            headers[row['header']] = row['prefix'] + bindings[row['secret_id']]
        connection.request(policy['method'], policy['path'],
                           body=bytes.fromhex(policy['body_hex']), headers=headers)
        # Deliberately do not read getresponse(): even a status bit can encode a
        # credential. Dispatch can have happened without any usable response.
    except BaseException:
        if not bound:
            print('REFUSED', flush=True)
            return
    finally:
        if connection is not None:
            connection.close()
    print('ATTEMPT_RECORDED', flush=True)


if __name__ == '__main__':
    main()
