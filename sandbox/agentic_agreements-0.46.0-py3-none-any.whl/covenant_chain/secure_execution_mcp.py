"""Owner-bound MCP surface for secure-execution-0.1.

The agent can inspect fixed operations and use an independently authorised
session. This adapter cannot provision secrets, authorise presence, change
targets or claim a peer identity. Default CLI mode has no execution custody.
"""
import sys
from copy import deepcopy

from .cooperation_interface import HASH, schema, tool
from .tool_input import validate_schema

_RECOVERY = {
    'SECURE_SESSION': 'Ask the owner for a fresh session scoped to this agent and operation.',
    'SECURE_REQUEST_REPLAY': 'Inspect scoped audit with the same request_id; do not repeat an uncertain action.',
    'SECURE_REVOCATION_VIEW_STALE': 'Ask the owner to adopt a fresh revocation view before execution.',
    'SECURE_REVOKED': 'Ask the owner to review revocation and current authority; do not bypass it.',
    'SECURE_SANDBOX_UNAVAILABLE': 'Ask the owner to install a qualified execution backend.',
}


def description():
    return dict(profile='secure-execution-0.1', guide='docs/SECURE_EXECUTION.html',
        owner_sdk='covenant_chain.secure_execution.GuardedExecutor',
        mcp_adapter='covenant_chain.secure_execution_mcp.serve_owner',
        workflow=['owner installs fixed HTTPS operations and opaque secret references',
                  'owner verifies exact scoped WebAuthn challenge outside MCP',
                  'agent previews operation and submits opaque session and request id',
                  'broker retains possible-attempt receipt; independently observe external outcome'],
        session_max_seconds=14400, execution_authorized=False,
        backend='macOS Seatbelt; fixed HTTPS 127.0.0.1 port only',
        arbitrary_commands=False, hardware_attestation=False,
        cryptographic_zero_knowledge=False,
        assumptions=['trusted owner process, OS, Python and installed worker',
                     'owner-adopted hardware credential; physical key not qualified by software assertions',
                     'pinned target must itself enforce client authentication',
                     'timing and host inspection remain outside the isolation claim'])


def specs():
    return [('covenant_execution_security',
        'Inspect the separately owner-installed guarded executor. No secrets, session '
        'authorisation or effects are available from this read-only discovery tool. '
        'The dedicated owner-bound MCP adapter supports fixed operation previews and '
        'scoped execution with an externally approved session.', True, [])]


def call(action, parameters):
    if action != 'describe' or parameters:
        raise ValueError('SECURE_DISCOVERY_READ_ONLY')
    return description()


class SecureTools:
    """Expose only the AgentClient surface to one authenticated agent transport.

    The hosting owner chooses the AgentClient before serving. Incoming names,
    fingerprints and tool arguments cannot change that binding. Do not share a
    transport between principals or run untrusted Python inside this process.
    """
    def __init__(self, client=None):
        if client is not None:
            from .secure_execution import AgentClient
            if type(client) is not AgentClient:
                raise ValueError('SECURE_OWNER_CLIENT_REQUIRED')
        self.__client = client
        # Existing MCP host instructions must reflect actual owner custody.
        self.workflow = client is not None

    def list_tools(self):
        actions = [('describe', {}, ()), ('operations', {}, ()),
            ('preview', {'operation_id': HASH}, ('operation_id',)),
            ('audit', {'request_id': HASH,
                       'limit': {'type': 'integer', 'minimum': 1, 'maximum': 100}}, ()),
            ('execute', {'session': HASH, 'operation_id': HASH,
                         'request_id': HASH}, ('session', 'operation_id', 'request_id'))]
        shape = {'type':'object', 'oneOf': [schema({'action':{'const':name},
            'parameters':schema(fields, required)}, ('action','parameters'))
            for name, fields, required in actions]}
        return [tool('covenant_guarded_executor',
            'Use owner-installed fixed HTTPS operations with a separately owner-approved '
            'session. No secret provisioning, owner presence signing, target changes, '
            'arbitrary commands or raw external responses. A receipt is a possible attempt, '
            'not external success. This MCP connection is bound to its owner-selected agent.',
            shape, readonly=False, idempotent=False)]

    def call(self, name, arguments):
        if name != 'covenant_guarded_executor':
            raise ValueError('SECURE_TOOL')
        validate_schema(arguments, self.list_tools()[0]['inputSchema'])
        action, parameters = arguments['action'], arguments['parameters']
        if action == 'describe':
            return dict(**description(), owner_client_installed=self.__client is not None)
        if self.__client is None:
            raise ValueError('SECURE_OWNER_CLIENT_REQUIRED')
        try:
            if action in ('operations', 'audit'):
                return {action: deepcopy(getattr(self.__client, action)(**parameters))}
            if action == 'preview':
                return self.__client.preview(parameters['operation_id'])
            return self.__client.execute(**parameters)
        except (ValueError, TypeError, KeyError, OSError, RuntimeError) as error:
            # Finite owner-local pre-binding codes only. Never reflect arbitrary
            # exception text, remote status/headers/body or secret encodings.
            code = error.args[0] if type(error) is ValueError and len(error.args) == 1 else None
            if type(code) is str and code in _RECOVERY:
                return dict(status='NOT_COMMITTED', code=code, next_action=_RECOVERY[code],
                            operation_dispatched_by_this_call=False,
                            prior_external_outcome='unknown', execution_authorized=False)
            raise ValueError('SECURE_REQUEST_REFUSED') from None


def serve_owner(client, incoming=None, outgoing=None):
    """Owner SDK entry point; authorisation/provisioning stays outside MCP."""
    from .agent_server import serve
    return serve(SecureTools(client), incoming or sys.stdin, outgoing or sys.stdout, profile='full')


def main():
    """Keyless discovery server. It cannot load keys or mint an approved session."""
    from .agent_server import serve
    return serve(SecureTools(), sys.stdin, sys.stdout, profile='full')


if __name__ == '__main__':
    raise SystemExit(main())
