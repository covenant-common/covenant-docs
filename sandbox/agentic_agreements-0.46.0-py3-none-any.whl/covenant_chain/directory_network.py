"""Signed directory of agents, people and organisations.

Profiles, follows, job posts and bids are off-chain documents. A forum replica
may carry them inside ordinary POST events; it does not gain a new kind, a
reputation balance, or a second ledger. Public work history is a view over
resolver-signed witnesses plus mutual publication consent. A row is SETTLED
only when `chain_state` shows that agreement AUTHORIZED and SUPPORTED. Caller
stake is checked and ignored; a job from outside the peer set needs stake
read off that snapshot. Organic
order uses relevance 50, seeded trust mass 20 and the outcome lower bound 30.
Spend, a founder flag and a price charged elsewhere are not inputs. Sponsored
cards stay in a separate list, matching the PR #19
directory split. Nothing here is a native operation.
"""
from collections.abc import Mapping
from copy import deepcopy
from html import escape
import json

from covenant_language.agentic import canonical as text_canonical
from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verify, verification_key
from .discovery_rank import reputation
from .agent_network import unpack

VERSION = 'covenant-directory/0.1'
LABEL = 'COVENANT-DIRECTORY-0.1'
TERMS_LABEL = 'COVENANT-DIRECTORY-TERMS-0.1'
SHARE_LABEL = 'COVENANT-GROWTH-SHARE-0.1'
CONSENSUS_CHANGE = None
# Stable names for callers. Documents are signed envelopes; views do not store rank.
SURFACES = ('profile', 'search', 'feed', 'graph', 'page', 'index', 'json_ld', 'draft', 'share', 'listing')
EFFECTS = {'TRANSFER', 'CONSUME', 'AUTHORIZE'}
SUBJECTS = {'AGENT', 'PERSON', 'ORGANISATION'}
AVAILABILITY = {'AVAILABLE', 'LIMITED', 'UNAVAILABLE'}
SKILL_SOURCES = {'MODULE', 'PRACTICE', 'AGENTIC'}
PUBLIC_FIELDS = ('agreement', 'terms_hash', 'quantity', 'asset', 'milestone', 'counterparty', 'role', 'height')
POST_KINDS = {'PROFILE', 'FOLLOW', 'CONNECT', 'ACCEPT', 'FEED', 'JOB', 'RFP', 'BID'}
EVIDENCE_KINDS = {'SETTLEMENT', 'OPT_IN', 'REDACT'}
KINDS = POST_KINDS | EVIDENCE_KINDS
FEED_EVENTS = {'CAPABILITY', 'MILESTONE', 'JOB', 'TEMPLATE'}
WORK_FIELDS = ('title capability domain price asset quantity principal agent mandate counterparty '
               'resolver appeal_resolver resource native_profile deadline challenge_blocks timeout '
               'effect destination executor terms_text listing')
BID_FIELDS = ('target target_kind price quantity note principal agent mandate resolver appeal_resolver '
              'resource native_profile deadline challenge_blocks timeout effect destination executor asset')
RATE_CONTEXT = 'directory'


def document_id(envelope):
    exact(envelope, 'body signature')
    return digest(LABEL, envelope['body'])


def _text(value, limit, code='DIRECTORY_TEXT'):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _url(value):
    _text(value, 200, 'DIRECTORY_URL')
    local = value.startswith('http://127.0.0.1') or value.startswith('http://localhost')
    need(value.startswith('https://') or local, 'DIRECTORY_URL')
    need(' ' not in value and '\\' not in value and '"' not in value, 'DIRECTORY_URL')


def _hash(value):
    key(value)


def _sort_unique(values, code):
    need(type(values) is list and values == sorted(set(values)), code)
    return values


def agent_card(name, description, url, skills=()):
    """A2A Agent Card as data. Nothing is fetched and nothing is installed."""
    _text(name, 80)
    _text(description, 240)
    _url(url)
    card_skills = []
    for skill in skills:
        exact(skill, 'id name')
        _hash(skill['id'])
        _text(skill['name'], 64)
        card_skills.append({'id': skill['id'], 'name': skill['name']})
    card = {
        'name': name, 'description': description, 'version': '0.1',
        'supportedInterfaces': [{'url': url, 'protocolBinding': 'JSONRPC', 'protocolVersion': '1.0'}],
        'capabilities': {'extensions': []},
        'defaultInputModes': ['text/plain'], 'defaultOutputModes': ['text/plain'],
        'skills': card_skills,
    }
    from .a2a_connector import inspect_card
    inspected = inspect_card(json.dumps(card, ensure_ascii=True, sort_keys=True, separators=(',', ':')))
    need(inspected['compatible'], 'DIRECTORY_A2A_CARD')
    canonical(card)
    return card


def _money(value, code):
    if value is None:
        return None
    exact(value, 'amount asset unit')
    integer(value['amount'])
    _text(value['asset'], 16, code)
    _text(value['unit'], 16, code)
    return {'amount': value['amount'], 'asset': value['asset'], 'unit': value['unit']}


def _sla(value):
    if value is None:
        return None
    exact(value, 'response_seconds availability_bps')
    integer(value['response_seconds'])
    integer(value['availability_bps'])
    need(value['availability_bps'] <= 10000, 'DIRECTORY_SLA')
    return {'response_seconds': value['response_seconds'], 'availability_bps': value['availability_bps']}


def _roles(payload, signer, *, counterparty_required):
    _hash(payload['principal'])
    _hash(payload['agent'])
    _hash(payload['resolver'])
    _hash(payload['appeal_resolver'])
    _hash(payload['resource'])
    _hash(payload['native_profile'])
    need(payload['agent'] == signer, 'DIRECTORY_AUTHOR')
    if payload['principal'] == payload['agent']:
        need(payload['mandate'] is None, 'DIRECTORY_MANDATE')
    else:
        _hash(payload['mandate'])
    counterparty = payload['counterparty']
    if counterparty_required:
        _hash(counterparty)
    else:
        need(counterparty is None, 'DIRECTORY_COUNTERPARTY')
    known = {payload['principal'], payload['agent'], payload['resolver'], payload['appeal_resolver']}
    if counterparty is not None:
        need(counterparty not in known, 'DIRECTORY_RESOLVER_CONFLICT')
    need(payload['resolver'] != payload['appeal_resolver'], 'DIRECTORY_RESOLVER_CONFLICT')
    need(payload['resolver'] not in {payload['principal'], payload['agent']}, 'DIRECTORY_RESOLVER_CONFLICT')
    need(payload['appeal_resolver'] not in {payload['principal'], payload['agent'], payload['resolver']}, 'DIRECTORY_RESOLVER_CONFLICT')
    integer(payload['price'], True)
    integer(payload['quantity'], True)
    integer(payload['deadline'], True)
    integer(payload['challenge_blocks'], True)
    need(payload['challenge_blocks'] <= 10000, 'DIRECTORY_CHALLENGE')
    need(payload['timeout'] in {'RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION'}, 'DIRECTORY_TIMEOUT')
    need(payload['effect'] in EFFECTS, 'DIRECTORY_EFFECT')
    _text(payload['destination'], 256, 'DIRECTORY_DESTINATION')
    if payload['executor'] is not None:
        _hash(payload['executor'])
    if payload['listing'] is not None:
        _hash(payload['listing'])


def _normalize(kind, signer, payload):
    need(type(payload) is dict, 'DIRECTORY_PAYLOAD')
    payload = deepcopy(payload)
    if kind == 'PROFILE':
        exact(payload, 'subject_kind identity principal grant name summary capabilities skills pricing sla availability domain a2a mcp portfolio')
        need(payload['subject_kind'] in SUBJECTS, 'DIRECTORY_SUBJECT')
        _hash(payload['identity'])
        _hash(payload['principal'])
        need(payload['identity'] == signer, 'DIRECTORY_AUTHOR')
        if payload['principal'] == payload['identity']:
            need(payload['grant'] is None, 'DIRECTORY_MANDATE')
        else:
            _hash(payload['grant'])
        _text(payload['name'], 80, 'DIRECTORY_NAME')
        _text(payload['summary'], 240)
        capabilities = payload['capabilities']
        need(type(capabilities) is list and 0 < len(capabilities) <= 16, 'DIRECTORY_CAPABILITIES')
        for item in capabilities:
            _text(item, 64, 'DIRECTORY_CAPABILITIES')
        need(capabilities == sorted(set(capabilities)), 'DIRECTORY_CAPABILITIES')
        skills = payload['skills']
        need(type(skills) is list and len(skills) <= 8, 'DIRECTORY_SKILLS')
        normalized = []
        for skill in skills:
            exact(skill, 'source id name')
            need(skill['source'] in SKILL_SOURCES, 'DIRECTORY_SKILLS')
            _hash(skill['id'])
            _text(skill['name'], 64, 'DIRECTORY_SKILLS')
            normalized.append({'source': skill['source'], 'id': skill['id'], 'name': skill['name']})
        need(len({item['id'] for item in normalized}) == len(normalized), 'DIRECTORY_SKILLS')
        payload['skills'] = sorted(normalized, key=lambda item: (item['source'], item['id']))
        payload['pricing'] = _money(payload['pricing'], 'DIRECTORY_PRICE')
        payload['sla'] = _sla(payload['sla'])
        need(payload['availability'] in AVAILABILITY, 'DIRECTORY_AVAILABILITY')
        _text(payload['domain'], 80, 'DIRECTORY_DOMAIN')
        if payload['a2a'] is None:
            pass
        else:
            exact(payload['a2a'], 'url card')
            _url(payload['a2a']['url'])
            from .a2a_connector import inspect_card
            card = payload['a2a']['card']
            canonical(card)
            inspected = inspect_card(json.dumps(card, ensure_ascii=True, sort_keys=True, separators=(',', ':')))
            need(inspected['compatible'], 'DIRECTORY_A2A_CARD')
            payload['a2a'] = {'url': payload['a2a']['url'], 'card': card}
        if payload['mcp'] is None:
            pass
        else:
            exact(payload['mcp'], 'url')
            _url(payload['mcp']['url'])
        portfolio = payload['portfolio']
        need(type(portfolio) is list and len(portfolio) <= 4, 'DIRECTORY_PORTFOLIO')
        for url in portfolio:
            _url(url)
        need(len(set(portfolio)) == len(portfolio), 'DIRECTORY_PORTFOLIO')
    elif kind == 'SETTLEMENT':
        exact(payload, 'agreement terms_hash parties resolver appeal_resolver quantity asset milestone height')
        _hash(payload['agreement'])
        _hash(payload['terms_hash'])
        parties = payload['parties']
        need(type(parties) is list and len(parties) == 2 and parties == sorted(set(parties)), 'DIRECTORY_PARTIES')
        for party in parties:
            _hash(party)
        _hash(payload['resolver'])
        _hash(payload['appeal_resolver'])
        need(signer == payload['resolver'], 'DIRECTORY_WITNESS')
        need(payload['resolver'] not in parties and payload['appeal_resolver'] not in parties, 'DIRECTORY_WITNESS_PARTY')
        need(payload['appeal_resolver'] != payload['resolver'], 'DIRECTORY_RESOLVER_CONFLICT')
        integer(payload['quantity'], True)
        _text(payload['asset'], 16, 'DIRECTORY_ASSET')
        _text(payload['milestone'], 160)
        integer(payload['height'])
    elif kind == 'OPT_IN':
        exact(payload, 'agreement terms_hash counterparty fields')
        _hash(payload['agreement'])
        _hash(payload['terms_hash'])
        _hash(payload['counterparty'])
        need(payload['counterparty'] != signer, 'DIRECTORY_OPT_IN')
        fields = _sort_unique(payload['fields'], 'DIRECTORY_OPT_IN_FIELDS')
        need(set(fields) <= set(PUBLIC_FIELDS) and 'agreement' in fields and 'terms_hash' in fields, 'DIRECTORY_OPT_IN_FIELDS')
    elif kind == 'REDACT':
        exact(payload, 'agreement withdraw hide')
        _hash(payload['agreement'])
        need(type(payload['withdraw']) is bool, 'DIRECTORY_REDACT')
        hide = _sort_unique(payload['hide'], 'DIRECTORY_REDACT')
        need(set(hide) <= set(PUBLIC_FIELDS), 'DIRECTORY_REDACT')
        if payload['withdraw']:
            need(hide == [], 'DIRECTORY_REDACT')
        else:
            need('agreement' not in hide and 'terms_hash' not in hide, 'DIRECTORY_REDACT_IDENTITY')
    elif kind == 'FOLLOW':
        exact(payload, 'subject')
        _hash(payload['subject'])
        need(payload['subject'] != signer, 'DIRECTORY_FOLLOW')
    elif kind == 'CONNECT':
        exact(payload, 'subject note')
        _hash(payload['subject'])
        need(payload['subject'] != signer, 'DIRECTORY_CONNECT')
        _text(payload['note'], 160)
    elif kind == 'ACCEPT':
        exact(payload, 'connect')
        _hash(payload['connect'])
    elif kind == 'FEED':
        exact(payload, 'event ref text')
        need(payload['event'] in FEED_EVENTS, 'DIRECTORY_FEED')
        _hash(payload['ref'])
        _text(payload['text'], 160)
    elif kind in {'JOB', 'RFP'}:
        exact(payload, WORK_FIELDS)
        _text(payload['title'], 120, 'DIRECTORY_TITLE')
        _text(payload['capability'], 64, 'DIRECTORY_CAPABILITIES')
        _text(payload['domain'], 80, 'DIRECTORY_DOMAIN')
        _text(payload['asset'], 16, 'DIRECTORY_ASSET')
        _text(payload['terms_text'], 400)
        _roles(payload, signer, counterparty_required=kind == 'JOB')
        if kind == 'RFP':
            need(payload['executor'] is None, 'DIRECTORY_EXECUTOR')
        else:
            _hash(payload['executor'])
            need(payload['executor'] == payload['counterparty'], 'DIRECTORY_EXECUTOR')
    elif kind == 'BID':
        exact(payload, BID_FIELDS)
        _hash(payload['target'])
        need(payload['target_kind'] in {'LISTING', 'RFP'}, 'DIRECTORY_BID_TARGET')
        integer(payload['price'], True)
        integer(payload['quantity'], True)
        _text(payload['note'], 240)
        _text(payload['asset'], 16, 'DIRECTORY_ASSET')
        _hash(payload['principal'])
        _hash(payload['agent'])
        _hash(payload['resolver'])
        _hash(payload['appeal_resolver'])
        _hash(payload['resource'])
        _hash(payload['native_profile'])
        _hash(payload['executor'])
        _text(payload['destination'], 256, 'DIRECTORY_DESTINATION')
        integer(payload['deadline'], True)
        integer(payload['challenge_blocks'], True)
        need(payload['challenge_blocks'] <= 10000, 'DIRECTORY_CHALLENGE')
        need(payload['timeout'] in {'RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION'}, 'DIRECTORY_TIMEOUT')
        need(payload['effect'] in EFFECTS, 'DIRECTORY_EFFECT')
        if payload['principal'] == payload['agent']:
            need(payload['mandate'] is None, 'DIRECTORY_MANDATE')
        else:
            _hash(payload['mandate'])
        if payload['target_kind'] == 'LISTING':
            need(signer == payload['agent'], 'DIRECTORY_AUTHOR')
        else:
            need(signer not in {payload['agent'], payload['principal'], payload['resolver'], payload['appeal_resolver']}, 'DIRECTORY_BID_PARTY')
        need(payload['resolver'] != payload['appeal_resolver'], 'DIRECTORY_RESOLVER_CONFLICT')
        need(payload['resolver'] not in {payload['principal'], payload['agent']}, 'DIRECTORY_RESOLVER_CONFLICT')
        need(payload['appeal_resolver'] not in {payload['principal'], payload['agent'], payload['resolver']}, 'DIRECTORY_RESOLVER_CONFLICT')
        need(payload['executor'] not in {payload['principal'], payload['agent'], payload['resolver'], payload['appeal_resolver']}, 'DIRECTORY_RESOLVER_CONFLICT')
    else:
        raise ValueError('DIRECTORY_KIND')
    canonical(payload)
    return payload


def sign_document(private, chain, kind, revision, payload):
    """Sign one directory document. The caller keeps it; this stores nothing."""
    _hash(chain)
    need(kind in KINDS, 'DIRECTORY_KIND')
    integer(revision, True)
    signer = public_key(private)
    verification_key(signer)
    body = {'version': VERSION, 'kind': kind, 'signer': signer, 'chain': chain,
            'revision': revision, 'payload': _normalize(kind, signer, payload)}
    exact(body, 'version kind signer chain revision payload')
    need(len(canonical({'body': body, 'signature': '0' * 128})) <= 6000, 'DIRECTORY_SIZE')
    envelope = {'body': body, 'signature': sign(private, LABEL, body)}
    need(len(canonical(envelope)) <= 6000, 'DIRECTORY_SIZE')
    return envelope


def open_document(envelope):
    exact(envelope, 'body signature')
    body = envelope['body']
    exact(body, 'version kind signer chain revision payload')
    need(body['version'] == VERSION and body['kind'] in KINDS, 'DIRECTORY_VERSION')
    verification_key(body['signer'])
    _hash(body['chain'])
    integer(body['revision'], True)
    normalized = _normalize(body['kind'], body['signer'], body['payload'])
    need(normalized == body['payload'], 'DIRECTORY_CANONICAL')
    verify(body['signer'], LABEL, body, envelope['signature'])
    return {'id': document_id(envelope), 'body': body, 'signature': envelope['signature']}


def _stake_map(stake):
    """Validate a caller attestation. The units are not a balance and are not used."""
    if stake is None:
        return {}
    if type(stake) is list:
        mapped = {}
        need(len(stake) <= 64, 'DIRECTORY_STAKE')
        for row in stake:
            exact(row, 'actor units')
            _hash(row['actor'])
            integer(row['units'])
            need(row['actor'] not in mapped, 'DIRECTORY_STAKE')
            mapped[row['actor']] = row['units']
        return mapped
    need(type(stake) is dict and len(stake) <= 64, 'DIRECTORY_STAKE')
    for actor, units in stake.items():
        _hash(actor)
        integer(units)
    return dict(stake)


def _chain_units(chain_state):
    """Stake the directory read off a chain snapshot. Caller dicts are not stake."""
    if chain_state is None:
        return {}
    need(hasattr(chain_state, 'get'), 'DIRECTORY_CHAIN')
    units = {}
    stakes = chain_state.get('service_stakes') or {}
    need(isinstance(stakes, Mapping), 'DIRECTORY_CHAIN')
    for row in stakes.values():
        if type(row) is not dict or row.get('closed') or row.get('amount', 0) <= 0:
            continue
        who = row.get('operator')
        if type(who) is not str:
            continue
        units[who] = units.get(who, 0) + row['amount']
    scale = (chain_state.get('economic_policy') or {}).get('scale') or {}
    positions = scale.get('positions') or {}
    need(isinstance(positions, Mapping), 'DIRECTORY_CHAIN')
    for actor, row in positions.items():
        if type(row) is not dict or row.get('amount', 0) <= 0 or row.get('unbonding'):
            continue
        units[actor] = units.get(actor, 0) + row['amount']
    return units


def _chain_settled(chain_state, payload, chain):
    """Match witness facts to native terms in the host's snapshot; not a proof replay."""
    if not isinstance(chain_state, Mapping) or chain_state.get('chain') != chain:
        return False
    agreements = chain_state.get('agreements') or {}
    if not isinstance(agreements, Mapping):
        return False
    row = agreements.get(payload['agreement'])
    if type(row) is not dict:
        return False
    decision = row.get('decision') or {}
    terms = row.get('terms')
    if type(terms) is not dict or type(decision) is not dict:
        return False
    parties = [terms.get('principal'), terms.get('counterparty')]
    if any(type(party) is not str for party in parties):
        return False
    return (row.get('state') == 'AUTHORIZED' and row.get('held') is False
            and decision.get('result') == 'SUPPORTED' and terms.get('chain') == chain
            and sorted(parties) == payload['parties']
            and all(terms.get(name) == payload[name]
                    for name in ('terms_hash', 'resolver', 'appeal_resolver', 'quantity')))


def forum_documents(network, group=None):
    """Directory envelopes carried in ordinary forum POST events."""
    if group is not None:
        _hash(group)
    found = []
    for event in network.events().values():
        body = event['body']
        if body['kind'] != 'POST':
            continue
        if group is not None and body['group'] != group:
            continue
        content = unpack(body)
        if 'covenant-directory' not in content.get('tags', []):
            continue
        inner = content.get('content')
        if type(inner) is dict and type(inner.get('body')) is dict and inner['body'].get('version') == VERSION:
            found.append(inner)
    return found


def _reputation_index(network, context):
    if network is None:
        return {}
    _text(context, 80, 'DIRECTORY_DOMAIN')
    view = reputation(network, context)
    return {row['agent']: row for row in view['agents']}


def _allowance(actor, network, stake_units, rep_index):
    peer = network is not None and actor in network.peers
    if not peer and stake_units <= 0:
        return 1, True
    base = 2 if peer else 1
    if peer and (actor in network.seeds or (rep_index.get(actor) or {}).get('positive_origins', 0) > 0
                 or (rep_index.get(actor) or {}).get('discovery_mass_ppb', 0) > 0):
        base = 8
    if stake_units > 0:
        base = max(base, min(32, 4 + min(stake_units, 28)))
    return base, False


def collect(documents=(), settlements=(), network=None, stake=None, group=None, chain_state=None):
    """Verify a bundle and admit what the posting budget allows.

    Dropped documents are reported. They are not written to a side store.
    Caller-supplied stake is checked and ignored. A resolver or a job is
    admitted only from stake read off `chain_state`.
    """
    attested = _stake_map(stake)
    stake_units = _chain_units(chain_state)
    attested_ignored = bool(attested)
    incoming = list(documents) + list(settlements)
    if network is not None:
        incoming.extend(forum_documents(network, group))
    need(len(incoming) <= 256, 'DIRECTORY_BUNDLE')
    opened = []
    seen = {}
    for envelope in incoming:
        document = open_document(envelope)
        previous = seen.get(document['id'])
        if previous is not None:
            need(previous['body'] == document['body'] and previous['signature'] == document['signature'], 'DIRECTORY_COLLISION')
            continue
        seen[document['id']] = document
        opened.append(document)
    chain = network.domain if network is not None else (opened[0]['body']['chain'] if opened else None)
    for document in opened:
        need(document['body']['chain'] == chain, 'DIRECTORY_CHAIN')
    by_signer = {}
    for document in opened:
        by_signer.setdefault(document['body']['signer'], []).append(document)
    rep_index = _reputation_index(network, RATE_CONTEXT)
    admitted = []
    dropped = []
    for signer, docs in sorted(by_signer.items()):
        revisions = [item['body']['revision'] for item in docs]
        need(len(revisions) == len(set(revisions)), 'DIRECTORY_REVISION_FORK')
        limit, profile_only = _allowance(signer, network, stake_units.get(signer, 0), rep_index)
        profiles = [item for item in docs if item['body']['kind'] == 'PROFILE']
        posts = [item for item in docs if item['body']['kind'] in POST_KINDS and item['body']['kind'] != 'PROFILE']
        evidence = [item for item in docs if item['body']['kind'] in EVIDENCE_KINDS]
        chosen = []
        if profiles:
            chosen.append(max(profiles, key=lambda item: (item['body']['revision'], item['id'])))
            dropped.extend(item['id'] for item in profiles if item is not chosen[0])
        posts.sort(key=lambda item: (item['body']['revision'], item['id']))
        evidence.sort(key=lambda item: (item['body']['revision'], item['id']))
        if profile_only:
            dropped.extend(item['id'] for item in posts)
        else:
            room = max(0, limit - len(chosen))
            chosen.extend(posts[:room])
            dropped.extend(item['id'] for item in posts[room:])
        chosen.extend(evidence[:64])
        dropped.extend(item['id'] for item in evidence[64:])
        admitted.extend(chosen)
    return Index(admitted, dropped, chain, network, stake_units, rep_index, chain_state, attested_ignored)


class Index:
    def __init__(self, admitted, dropped, chain, network, stake_units, rep_index, chain_state=None, attested_ignored=False):
        self.documents = {item['id']: item for item in admitted}
        self.dropped = sorted(dropped)
        self.chain = chain
        self.network = network
        self.stake_units = stake_units
        self.rep_index = rep_index
        self.chain_state = chain_state
        self.attested_ignored = attested_ignored
        self.stake_checked_against_chain = True
        self.by_kind = {}
        for item in admitted:
            self.by_kind.setdefault(item['body']['kind'], []).append(item)
        self._work = None

    def _payload(self, item):
        return item['body']['payload']

    def profiles(self):
        rows = []
        for item in self.by_kind.get('PROFILE', []):
            payload = self._payload(item)
            same = [other for other in self.by_kind.get('PROFILE', [])
                    if other['body']['signer'] == item['body']['signer'] and other['body']['revision'] == item['body']['revision'] and other['id'] != item['id']]
            rows.append(self._profile_row(item, conflict=bool(same)))
        rows.sort(key=lambda row: row['identity'])
        return rows

    def _distribution(self, identity, context):
        base = {'positive_origins': 0, 'negative_origins': 0, 'unknown_origins': 0,
                'conflicting_origins': 0, 'discovery_mass_ppb': 0, 'shape': 'DISTRIBUTION_NOT_A_SCORE',
                'reputation_balance': False, 'portable': False, 'stored_reputation': False,
                'chain': self.chain, 'context': context, 'graph_rank_is_authority': False,
                'claims': 'SIGNED_OPINIONS_NOT_CERTIFIED_PERFORMANCE'}
        if self.network is None:
            base['available'] = False
            return base
        _text(context, 80, 'DIRECTORY_DOMAIN')
        if context == RATE_CONTEXT:
            row = self.rep_index.get(identity)
        else:
            row = _reputation_index(self.network, context).get(identity)
        if row:
            for name in ('positive_origins', 'negative_origins', 'unknown_origins', 'conflicting_origins', 'discovery_mass_ppb'):
                base[name] = row[name]
        base['available'] = True
        base['admitted_peer'] = identity in self.network.peers
        return base

    def _profile_row(self, item, conflict=False):
        payload = self._payload(item)
        identity = payload['identity']
        peer = self.network is not None and identity in self.network.peers
        row = {
            'id': item['id'], 'subject_kind': payload['subject_kind'], 'identity': identity,
            'principal': payload['principal'], 'accountable_principal': payload['principal'],
            'principal_is_agent': payload['principal'] == identity, 'grant': payload['grant'],
            'grant_replayed': False, 'name': payload['name'], 'summary': payload['summary'],
            'capabilities': list(payload['capabilities']), 'skills': deepcopy(payload['skills']),
            'skill_registry': 'REFERENCED_NOT_COPIED', 'pricing': deepcopy(payload['pricing']),
            'sla': deepcopy(payload['sla']), 'availability': payload['availability'],
            'domain': payload['domain'], 'chain': item['body']['chain'],
            'portfolio': list(payload['portfolio']), 'revision': item['body']['revision'],
            'a2a': None if payload['a2a'] is None else {'url': payload['a2a']['url'], 'card': deepcopy(payload['a2a']['card']),
                                                         'fetched': False, 'dialed': False, 'remote_creates_assent': False},
            'mcp': None if payload['mcp'] is None else {'url': payload['mcp']['url'], 'fetched': False, 'dialed': False},
            'reputation': self._distribution(identity, payload['domain']),
            'work': [] if conflict else self.work_for(identity),
            'ranked': bool(peer), 'conflict': conflict, 'login_required': False,
            'declaration_not_performance': True, 'reputation_balance': False,
            'portable_reputation': False, 'stored_reputation': False,
            'moat': 'NON_PORTABLE_WORK_HISTORY_AND_CONTEXTUAL_REPUTATION_VIEW',
            'consensus_change': CONSENSUS_CHANGE, 'chain_replayed': False,
        }
        return row

    def profile(self, identity):
        _hash(identity)
        for row in self.profiles():
            if row['identity'] == identity and not row['conflict']:
                return row
        raise ValueError('DIRECTORY_PROFILE')

    def _resolver_admitted(self, resolver):
        return self.stake_units.get(resolver, 0) > 0

    def _latest(self, kind, signer, agreement=None):
        chosen = None
        for item in self.by_kind.get(kind, []):
            if item['body']['signer'] != signer:
                continue
            payload = self._payload(item)
            if agreement is not None and payload.get('agreement') != agreement:
                continue
            if chosen is None or item['body']['revision'] > chosen['body']['revision']:
                chosen = item
        return chosen

    def public_work(self):
        if self._work is not None:
            return self._work
        rows = []
        for item in self.by_kind.get('SETTLEMENT', []):
            payload = self._payload(item)
            if not self._resolver_admitted(payload['resolver']):
                continue
            optins = []
            redactions = []
            published = True
            for party in payload['parties']:
                opt = self._latest('OPT_IN', party, payload['agreement'])
                if opt is None or self._payload(opt)['terms_hash'] != payload['terms_hash']:
                    published = False
                    break
                if self._payload(opt)['counterparty'] not in payload['parties'] or self._payload(opt)['counterparty'] == party:
                    published = False
                    break
                red = self._latest('REDACT', party, payload['agreement'])
                optins.append(opt)
                redactions.append(red)
            if not published:
                continue
            if any(red is not None and self._payload(red)['withdraw'] for red in redactions):
                continue
            fields = set(self._payload(optins[0])['fields']) & set(self._payload(optins[1])['fields'])
            for red in redactions:
                if red is not None:
                    fields -= set(self._payload(red)['hide'])
            if 'agreement' not in fields or 'terms_hash' not in fields:
                continue
            settled = _chain_settled(self.chain_state, payload, item['body']['chain'])
            row = {'agreement': payload['agreement'], 'terms_hash': payload['terms_hash'], 'chain': item['body']['chain'],
                   'status': 'SETTLED' if settled else 'CALLER_SIGNED', 'witness': item['id'],
                   'chain_replayed': False, 'party_signed_settlement': False, 'chain_state_matched': settled,
                   'ledger_source': 'HOST_SUPPLIED_STATE_NOT_LIGHT_CLIENT_PROOF',
                   'display_claims': 'ASSET_SYMBOL_MILESTONE_HEIGHT_ARE_RESOLVER_ATTESTED',
                   'fields': sorted(fields), 'shareable': False}
            if 'quantity' in fields:
                row['quantity'] = payload['quantity']
            if 'asset' in fields:
                row['asset'] = payload['asset']
            if 'milestone' in fields:
                row['milestone'] = payload['milestone']
            if 'height' in fields:
                row['height'] = payload['height']
            if 'role' in fields:
                row['role'] = 'PARTY'
            if 'counterparty' in fields:
                row['parties'] = list(payload['parties'])
                row['shareable'] = settled and 'quantity' in fields and 'role' in fields
            else:
                row['parties_hidden'] = True
            rows.append(row)
        rows.sort(key=lambda row: row['agreement'])
        self._work = rows
        return rows

    def work_for(self, identity):
        return [deepcopy(row) for row in self.public_work() if identity in row.get('parties', []) or (
            row.get('parties_hidden') and self._party_of(row['agreement'], identity))]

    def _party_of(self, agreement, identity):
        for item in self.by_kind.get('SETTLEMENT', []):
            payload = self._payload(item)
            if payload['agreement'] == agreement and identity in payload['parties']:
                return True
        return False

    def graph(self):
        follows = []
        for item in self.by_kind.get('FOLLOW', []):
            follows.append({'actor': item['body']['signer'], 'subject': self._payload(item)['subject'], 'document': item['id']})
        connections = []
        connects = {item['id']: item for item in self.by_kind.get('CONNECT', [])}
        for item in self.by_kind.get('ACCEPT', []):
            request = connects.get(self._payload(item)['connect'])
            if request is None:
                continue
            if item['body']['signer'] != self._payload(request)['subject']:
                continue
            pair = tuple(sorted((request['body']['signer'], item['body']['signer'])))
            connections.append({'parties': list(pair), 'request': request['id'], 'accept': item['id']})
        worked = []
        for row in self.public_work():
            if row.get('status') == 'SETTLED' and 'parties' in row:
                worked.append({'parties': list(row['parties']), 'agreement': row['agreement'], 'chain': row['chain'],
                               'source': 'SETTLED_COVENANT_WITNESS_AND_MUTUAL_OPT_IN'})
        follows.sort(key=lambda row: (row['actor'], row['subject']))
        connections.sort(key=lambda row: row['parties'])
        worked.sort(key=lambda row: row['parties'])
        return {'follows': follows, 'connections': connections, 'worked_with': worked,
                'worked_with_source': 'SETTLED_COVENANT_WITNESS_AND_MUTUAL_OPT_IN',
                'endorsements_are_worked_with': False, 'follows_are_worked_with': False,
                'reputation_balance': False, 'login_required': False, 'chain': self.chain,
                'consensus_change': CONSENSUS_CHANGE}

    def feed(self):
        items = []
        public_agreements = {row['agreement'] for row in self.public_work()}
        profiles = {item['body']['signer']: self._payload(item) for item in self.by_kind.get('PROFILE', [])}
        for item in self.by_kind.get('JOB', []) + self.by_kind.get('RFP', []):
            payload = self._payload(item)
            items.append({'event': 'JOB', 'document': item['id'], 'actor': item['body']['signer'],
                          'text': payload['title'], 'ref': item['id'], 'ranked_author': self._ranked(item['body']['signer']),
                          'chain': self.chain})
        for item in self.by_kind.get('FEED', []):
            payload = self._payload(item)
            signer = item['body']['signer']
            if payload['event'] == 'MILESTONE' and payload['ref'] not in public_agreements:
                continue
            if payload['event'] == 'CAPABILITY':
                profile = profiles.get(signer)
                if profile is None or payload['text'] not in profile['capabilities']:
                    continue
            if payload['event'] == 'JOB' and payload['ref'] not in self.documents:
                continue
            items.append({'event': payload['event'], 'document': item['id'], 'actor': signer,
                          'text': payload['text'], 'ref': payload['ref'], 'ranked_author': self._ranked(signer),
                          'chain': self.chain, 'template_bytes': 'NOT_FETCHED' if payload['event'] == 'TEMPLATE' else None})
        items.sort(key=lambda row: (row['event'], row['document']))
        return {'events': items, 'opt_in': 'FEED_JOB_AND_RFP_ARE_THE_PUBLIC_ACTS', 'login_required': False,
                'chain': self.chain, 'reputation_balance': False}

    def _ranked(self, actor):
        return self.network is not None and actor in self.network.peers

    def search(self, query='', capability=None, max_price=None, min_positive=0, availability=None,
               domain=None, sponsored=None, boost=None, policy=None, split=None, receipts=None,
               newcomers=None, exploration_seed=None, operator=None, price_elsewhere=None):
        _text(query, 256, 'DIRECTORY_QUERY') if query else None
        if query == '':
            pass
        else:
            _text(query, 256, 'DIRECTORY_QUERY')
        integer(min_positive)
        if availability is not None:
            need(availability in AVAILABILITY, 'DIRECTORY_AVAILABILITY')
        if domain is not None:
            _text(domain, 80, 'DIRECTORY_DOMAIN')
        if max_price is not None:
            integer(max_price)
        if boost is not None:
            integer(boost)
        if operator is not None:
            key(operator)
        if price_elsewhere is not None:
            integer(price_elsewhere)
        if receipts is not None:
            need(type(receipts) is list and len(receipts) <= 4096, 'DIRECTORY_RECEIPTS')
        if newcomers is not None:
            key(exploration_seed)
        context = domain or RATE_CONTEXT
        rep = _reputation_index(self.network, context) if self.network is not None else {}
        candidates = []
        unranked = []
        for row in self.profiles():
            if row['conflict']:
                continue
            payload_caps = row['capabilities'] + [skill['name'] for skill in row['skills']]
            if capability is not None and capability not in payload_caps:
                continue
            if availability is not None and row['availability'] != availability:
                continue
            if domain is not None and row['domain'] != domain:
                continue
            if max_price is not None and (row['pricing'] is None or row['pricing']['amount'] > max_price):
                continue
            positive = rep.get(row['identity'], {}).get('positive_origins', 0)
            if positive < min_positive:
                continue
            if self.network is not None and row['identity'] not in self.network.peers:
                unranked.append(row['identity'])
                continue
            candidates.append(row)
        ranked_rows = []
        from .network_incentives import WEIGHTS, blend_score, outcome_profile, place_newcomers, trust_from_network
        if candidates:
            objects = []
            for row in candidates:
                description = ' '.join([row['summary'], row['domain'], *row['capabilities'],
                                         *[skill['name'] for skill in row['skills']]])
                objects.append({'target': {'kind': 'directory-profile', 'id': row['identity']},
                                'title': row['name'], 'description': description[:4096],
                                'attributes': {'availability': row['availability'], 'domain': row['domain'],
                                               'price': 0 if row['pricing'] is None else row['pricing']['amount'],
                                               'chain': row['chain']},
                                'links': []})
            from .desire_discovery import discover
            found = discover(objects, {'query': query, 'context': context, 'requirements': {},
                                        'strict_requirements': False,
                                        'weights': {'relevance': 1, 'pagerank': 0, 'reputation': 0}},
                             network=self.network)
            by_identity = {row['identity']: row for row in candidates}
            trust = trust_from_network(self.network) if receipts and self.network is not None else None
            if receipts and len(candidates) > 1:
                for receipt in receipts:
                    need(type(receipt) is dict and 'party' in receipt, 'INCENTIVE_PARTY')
            bounds = {}
            for row in candidates:
                if receipts:
                    bounds[row['identity']] = outcome_profile(row['identity'], receipts, trust, context=context)['lower_bound_bps']
                else:
                    bounds[row['identity']] = 0
            scored = []
            for item in found['ranking']:
                identity = item['target']['id']
                profile = by_identity[identity]
                mass = self._distribution(identity, context)['discovery_mass_ppb']
                scored.append((item, identity, profile, mass))
            max_mass = max((mass for _, _, _, mass in scored), default=0)
            for item, identity, profile, mass in scored:
                blend = blend_score(item['components_ppm']['relevance'], mass, max_mass, bounds[identity])
                ranked_rows.append({'identity': identity, 'name': profile['name'], 'domain': profile['domain'],
                                    'availability': profile['availability'], 'pricing': profile['pricing'],
                                    'capabilities': profile['capabilities'], 'principal': profile['principal'],
                                    'score_ppm': blend['score_ppm'], 'components_ppm': blend['components_ppm'],
                                    'lower_bound_bps': bounds[identity], 'weights': blend['weights'],
                                    'reputation': self._distribution(identity, context),
                                    'ranking_view': True, 'stored_reputation': False, 'spend_ignored': True,
                                    'opinion_input': False, 'payment_input': False, 'operator_input': False,
                                    'price_elsewhere_input': False})
            ranked_rows.sort(key=lambda row: (-row['score_ppm'], row['identity']))
        separated = separate_sponsored(ranked_rows, [] if sponsored is None else sponsored, policy, split)
        if newcomers is None:
            shown = [{'identity': row['identity'], 'slot': 'ORGANIC'} for row in separated['organic']]
            exploration = []
            organic_changed = False
        else:
            placed = place_newcomers([{'identity': row['identity']} for row in separated['organic']],
                                     newcomers, exploration_seed)
            shown = placed['shown']
            exploration = placed['exploration']
            organic_changed = placed['organic_changed']
        separated.update({'unranked': sorted(unranked), 'ignored_boost': boost, 'paid_boosts_organic': False,
                          'shown': shown, 'exploration': exploration, 'organic_changed': organic_changed,
                          'exploration_stride': 8, 'weights': dict(WEIGHTS) if candidates else {'relevance': 50, 'pagerank': 20, 'reputation': 30},
                          'operator_ignored': operator, 'price_elsewhere_ignored': price_elsewhere,
                          'self_preference': False,
                          'stored_reputation': False, 'reputation_balance': False, 'portable_reputation': False,
                          'moat': 'NON_PORTABLE_WORK_HISTORY_AND_CONTEXTUAL_REPUTATION_VIEW',
                          'sybil_resistance': 'BOUNDED_ADMISSION_AND_TRUST_SEEDS_OR_CHAIN_STAKE_NOT_A_PROOF',
                          'stake_source': 'CHAIN_STAKE' if self.stake_units else 'CALLER_ATTESTED_IGNORED' if self.attested_ignored else 'NO_CHAIN_STAKE',
                          'stake_checked_against_chain': True,
                          'login_required': False, 'chain': self.chain, 'consensus_change': CONSENSUS_CHANGE,
                          'organic_inputs': 'RELEVANCE_50_TRUST_MASS_20_OUTCOME_LB_30',
                          'outcome_context': context,
                          'receipt_authenticity': 'CALLER_SUPPLIED_NOT_VERIFIED_HERE',
                          'sample_completeness': 'UNKNOWN', 'independence': 'NOT_ESTABLISHED',
                          'rate_limited': self.dropped})
        return separated

    def receipt(self, agreement):
        for row in self.public_work():
            if row['agreement'] == agreement and row['shareable']:
                return {'chain': row['chain'], 'agreement': row['agreement'], 'status': 'SETTLED',
                        'terms_hash': row['terms_hash'], 'role': 'PARTY', 'quantity': row['quantity'],
                        'parties': list(row['parties'])}
        raise ValueError('DIRECTORY_RECEIPT')


def separate_sponsored(organic, sponsored, policy=None, split=None):
    """Keep paid placement out of the organic list. Price never reorders it."""
    need(type(sponsored) is list and len(sponsored) <= 16, 'DIRECTORY_SPONSORED')
    labelled = []
    for card in sponsored:
        need(type(card) is dict, 'DIRECTORY_SPONSORED')
        canonical(card)
        row = deepcopy(card)
        row['label'] = 'SPONSORED'
        row['organic_rank_weight'] = 0
        labelled.append(row)
    if policy is not None and split is not None:
        try:
            from covenant_chain.ads.directory import present_directory
        except ImportError:
            present_directory = None
        if present_directory is not None:
            result = present_directory(organic, labelled, policy, split)
            result['paid_boosts_organic'] = False
            result['ads_package'] = 'covenant_chain.ads.directory.present_directory'
            return result
    return {'organic': organic, 'sponsored': labelled, 'separation': 'SPONSORED_FIELD_ONLY',
            'organic_ranking': 'SPEND_BLIND', 'ordering': 'RELEVANCE_THEN_REPUTATION_MASS_NOT_PRICE',
            'instructions_include_ads': False, 'paid_boosts_organic': False,
            'ads_package': 'ABSENT_SEPARATION_MATCHES_PR19_PRESENT_DIRECTORY'}


def share_card(receipt, *, opt_in, referrer, platforms):
    """Hand a settled public receipt to the growth loop. A click is not a payment."""
    need(opt_in is True, 'DIRECTORY_SHARE_OPT_IN')
    _hash(referrer)
    need(type(platforms) is list and 1 <= len(platforms) <= 8, 'DIRECTORY_SHARE_PLATFORM')
    for platform in platforms:
        _text(platform, 32, 'DIRECTORY_SHARE_PLATFORM')
    exact(receipt, 'chain agreement status terms_hash role quantity parties')
    need(receipt['status'] == 'SETTLED', 'DIRECTORY_SHARE_STATUS')
    _hash(receipt['chain'])
    _hash(receipt['agreement'])
    _hash(receipt['terms_hash'])
    need(receipt['role'] == 'PARTY', 'DIRECTORY_SHARE_ROLE')
    integer(receipt['quantity'], True)
    parties = receipt['parties']
    need(type(parties) is list and len(parties) == 2 and parties == sorted(set(parties)), 'DIRECTORY_PARTIES')
    for party in parties:
        _hash(party)
    public = {'chain': receipt['chain'], 'agreement': receipt['agreement'], 'status': 'SETTLED',
              'terms_hash': receipt['terms_hash'], 'role': 'PARTY', 'quantity': receipt['quantity'],
              'parties': list(parties)}
    try:
        from covenant_chain.growth import share_card as growth_share
    except ImportError:
        growth_share = None
    if growth_share is not None:
        card = growth_share(public, opt_in=True, referrer=referrer, platforms=list(platforms))
        card['feeds_growth_loop'] = True
        card['portable_reputation'] = False
        card['reputation_balance'] = False
        return card
    card_id = digest(SHARE_LABEL, {'referrer': referrer, 'public': public})
    return {'id': card_id, 'attribution': 'covenant:share/' + card_id + '?ref=' + referrer,
            'referrer': referrer, 'public': public, 'platforms': list(platforms),
            'payment': 'NOT_FOR_THE_SHARE_OR_THE_CLICK', 'portable_reputation': False,
            'reputation_balance': False, 'feeds_growth_loop': True,
            'growth_module': 'ABSENT_CARD_MATCHES_COVENANT-GROWTH-SHARE-0.1',
            'moat': 'NON_PORTABLE_WORK_HISTORY_AND_CONTEXTUAL_REPUTATION_VIEW',
            'execution_authorized': False}


def profile_link(profile_id, chain, referrer):
    _hash(profile_id)
    _hash(chain)
    _hash(referrer)
    return {'kind': 'PROFILE_PAGE', 'chain': chain, 'profile': profile_id, 'referrer': referrer,
            'deep_link': 'covenant:profile/' + profile_id + '?ref=' + referrer,
            'portable_reputation': False, 'settlement_claimed': False, 'feeds_growth_loop': True,
            'payment': 'NOT_FOR_THE_SHARE_OR_THE_CLICK'}


def json_ld(profile):
    """schema.org Person, Organization and Service. The chain is part of the id."""
    kind = profile['subject_kind']
    node_id = 'covenant:' + profile['chain'] + ':' + profile['identity']
    node_type = 'Organization' if kind == 'ORGANISATION' else 'Person'
    node = {'@type': node_type, '@id': node_id, 'identifier': profile['identity'],
            'name': profile['name'], 'description': profile['summary'],
            'knowsAbout': list(profile['capabilities'])}
    if profile['portfolio']:
        node['sameAs'] = list(profile['portfolio'])
    if kind == 'AGENT':
        node['additionalType'] = 'Agent'
    principal = {'@type': 'Person', 'identifier': profile['principal']}
    if profile['principal'] != profile['identity']:
        if kind == 'ORGANISATION':
            node['member'] = principal
        elif kind == 'AGENT':
            node['worksFor'] = {'@type': 'Organization', 'identifier': profile['principal']}
        else:
            node['affiliation'] = {'@type': 'Organization', 'identifier': profile['principal']}
    services = []
    for capability in profile['capabilities']:
        service = {'@type': 'Service', 'name': capability, 'serviceType': capability,
                   'provider': {'@id': node_id}, 'areaServed': profile['domain']}
        if profile['pricing'] is not None:
            service['offers'] = {'@type': 'Offer', 'price': profile['pricing']['amount'],
                                 'priceCurrency': profile['pricing']['asset']}
        services.append(service)
    return {'@context': 'https://schema.org', '@graph': [node, *services]}


def _json_blob(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')


def render_profile(profile, referrer=None):
    """Static HTML from an already verified profile. No login and no script."""
    data = json_ld(profile)
    kind = 'Organization' if profile['subject_kind'] == 'ORGANISATION' else 'Person'
    reputation = profile['reputation']
    counts = ' '.join(name + ' ' + str(reputation.get(name, 0)) for name in (
        'positive_origins', 'negative_origins', 'unknown_origins', 'conflicting_origins', 'discovery_mass_ppb'))
    skills = ''.join('<li>' + escape(skill['source'] + ' ' + skill['id'] + ' ' + skill['name']) + '</li>' for skill in profile['skills'])
    caps = ''.join('<li>' + escape(item) + '</li>' for item in profile['capabilities'])
    price = 'undeclared' if profile['pricing'] is None else str(profile['pricing']['amount']) + ' ' + profile['pricing']['asset']
    sla = 'undeclared' if profile['sla'] is None else str(profile['sla']['response_seconds']) + 's / ' + str(profile['sla']['availability_bps']) + ' bps'
    work_rows = []
    for row in profile['work']:
        cells = [row['agreement'], row['status']]
        if 'milestone' in row:
            cells.append(row['milestone'])
        if 'quantity' in row:
            cells.append(str(row['quantity']) + ' ' + row.get('asset', ''))
        if 'parties' in row:
            cells.append(' '.join(row['parties']))
        work_rows.append('<li>' + escape(' | '.join(cells)) + '</li>')
    endpoints = []
    if profile['a2a'] is not None:
        endpoints.append('<li>A2A ' + escape(profile['a2a']['url']) + '</li>')
    if profile['mcp'] is not None:
        endpoints.append('<li>MCP ' + escape(profile['mcp']['url']) + '</li>')
    for url in profile['portfolio']:
        endpoints.append('<li>Portfolio ' + escape(url) + '</li>')
    link = ''
    if referrer is not None:
        deep = profile_link(profile['id'], profile['chain'], referrer)
        link = '<meta property="og:url" content="' + escape(deep['deep_link'], quote=True) + '">'
    title = escape(profile['name'])
    html = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta name="robots" content="index,follow">'
            '<meta name="covenant-login" content="not-required">'
            '<meta property="og:title" content="' + title + '">'
            '<meta property="og:description" content="' + escape('Chain ' + profile['chain'] + '. Reputation is a distribution bound to this chain.', quote=True) + '">'
            + link + '<title>' + title + '</title></head><body>'
            '<article><h1>' + title + '</h1>'
            '<p>' + escape(kind + ' ' + profile['subject_kind']) + '</p>'
            '<p>' + escape(profile['summary']) + '</p>'
            '<p>Accountable principal ' + escape(profile['principal']) + '</p>'
            '<p>Identity ' + escape(profile['identity']) + '</p>'
            '<p>Chain ' + escape(profile['chain']) + '</p>'
            '<p>Domain ' + escape(profile['domain']) + ' Availability ' + escape(profile['availability']) + '</p>'
            '<p>Price ' + escape(price) + ' SLA ' + escape(sla) + '</p>'
            '<h2>Capabilities</h2><ul>' + caps + '</ul>'
            '<h2>Skills</h2><ul>' + skills + '</ul>'
            '<h2>Endpoints</h2><ul>' + ''.join(endpoints) + '</ul>'
            '<h2>Reputation distribution</h2><p>' + escape(counts) + '</p>'
            '<p>This distribution is a view. It is not a balance and it is not portable off this chain.</p>'
            '<h2>Settled work</h2><ul>' + ''.join(work_rows) + '</ul>'
            '<p>A covenant is shown only when a resolver signed the settlement and both parties opted in. Redacted fields are omitted.</p>'
            '</article><script type="application/ld+json">' + _json_blob(data) + '</script></body></html>')
    need(html.count('<script') == 1, 'DIRECTORY_PAGE')
    return html


def render_directory(result):
    organic = ''.join('<li data-organic="true">' + escape(row['name'] + ' ' + row['identity']) + '</li>' for row in result['organic'])
    sponsored = ''.join('<li data-sponsored="true">Sponsored ' + escape(json.dumps(row, ensure_ascii=True, sort_keys=True, default=str)[:400]) + '</li>' for row in result['sponsored'])
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Covenant directory</title></head><body>'
            '<h1>Directory</h1><p>Organic results follow relevance, seeded trust and the outcome lower bound. Spend is not an input.</p>'
            '<h2>Organic</h2><ol>' + organic + '</ol>'
            '<h2>Sponsored</h2><ul>' + sponsored + '</ul></body></html>')


def _bind_terms(chain, principal, agent, counterparty, mandate, native_profile, resource, quantity,
                effect, destination, executor, resolver, appeal_resolver, deadline, challenge_blocks,
                timeout, terms_hash):
    terms = {'chain': chain, 'principal': principal, 'agent': agent, 'counterparty': counterparty,
             'mandate': mandate, 'profile': native_profile, 'resource': resource, 'quantity': quantity,
             'effect': effect, 'destination': destination, 'executor': executor, 'resolver': resolver,
             'appeal_resolver': appeal_resolver, 'deadline': deadline, 'challenge_blocks': challenge_blocks,
             'timeout': timeout, 'terms_hash': terms_hash}
    exact(terms, 'chain principal agent counterparty mandate profile resource quantity effect destination executor resolver appeal_resolver deadline challenge_blocks timeout terms_hash')
    need(agent != counterparty, 'DISTINCT_PARTIES')
    need(resolver not in {agent, counterparty, principal}, 'RESOLVER_CONFLICT')
    need(appeal_resolver not in {agent, counterparty, resolver, principal}, 'RESOLVER_CONFLICT')
    integer(quantity, True)
    return terms


def _escrow(principal, counterparty, resolver, appeal_resolver, asset_name, amount, terms_hash):
    from covenant_language.marketplace import escrow_policy
    asset = {'namespace': 'covenant-directory', 'identifier': asset_name, 'unit': asset_name}
    controllers = sorted({resolver, appeal_resolver})
    return escrow_policy('Directory escrow', principal, asset, amount, principal, counterparty,
                         controllers, 1, terms_hash, {'on': 'SUPPORTED_AFTER_CHALLENGE_WINDOW'},
                         {'on': 'TIMEOUT_POLICY'})


def compile_draft(index, *, job=None, bid=None, listing=None):
    """Prepare a BIND body. Nothing is signed, funded, or submitted."""
    listing_id = None
    job_id = None
    bid_id = None
    note = ''
    if listing is not None:
        record = listing['record'] if type(listing) is dict and 'record' in listing else listing
        from covenant_language.marketplace import identifier, validate
        validate(record)
        need(record['kind'] == 'LISTING', 'DIRECTORY_LISTING')
        need(bid is not None, 'DIRECTORY_BID')
        need(type(bid) is str and bid in index.documents, 'DIRECTORY_BID')
        bid_doc = index.documents[bid]
        payload = bid_doc['body']['payload']
        need(payload['target_kind'] == 'LISTING' and payload['target'] == identifier(record), 'DIRECTORY_BID_TARGET')
        need(bid_doc['body']['signer'] == payload['agent'], 'DIRECTORY_AUTHOR')
        want = record['data']['want']
        need(len(want) == 1 and payload['price'] == want[0]['amount'], 'DIRECTORY_LISTING_PRICE')
        need(payload['executor'] == record['author'], 'DIRECTORY_EXECUTOR')
        seller = record['author']
        need(seller not in {payload['agent'], payload['principal'], payload['resolver'], payload['appeal_resolver']}, 'RESOLVER_CONFLICT')
        source = payload
        principal, agent, counterparty = payload['principal'], payload['agent'], seller
        mandate = payload['mandate']
        price = payload['price']
        title = record['title']
        terms_text = title
        note = payload['note']
        listing_id = identifier(record)
        bid_id = bid_doc['id']
    else:
        if type(job) is not str or job not in index.documents:
            # Named-field refusal salvaged from Cursor PR 45.
            from .crypto import FieldError
            raise FieldError('DIRECTORY_JOB', 'job', 'id of a signed JOB or RFP document included in documents',
                             'This job id is not in the bundle. Pass the signed JOB or RFP document in documents, then draft again.')
        job_doc = index.documents[job]
        kind = job_doc['body']['kind']
        payload = job_doc['body']['payload']
        need(kind in {'JOB', 'RFP'}, 'DIRECTORY_JOB')
        job_id = job_doc['id']
        title = payload['title']
        terms_text = payload['terms_text']
        if kind == 'RFP':
            need(type(bid) is str and bid in index.documents, 'DIRECTORY_BID')
            bid_doc = index.documents[bid]
            offer = bid_doc['body']['payload']
            need(offer['target_kind'] == 'RFP' and offer['target'] == job_id, 'DIRECTORY_BID_TARGET')
            need(bid_doc['body']['signer'] == offer['executor'], 'DIRECTORY_EXECUTOR')
            for field in ('principal', 'agent', 'mandate', 'resolver', 'appeal_resolver', 'resource',
                          'native_profile', 'deadline', 'challenge_blocks', 'timeout', 'effect', 'destination', 'asset'):
                need(offer[field] == payload[field], 'DIRECTORY_BID_TERMS')
            need(offer['quantity'] <= payload['quantity'], 'DIRECTORY_QUANTITY')
            source = offer
            principal, agent = payload['principal'], payload['agent']
            counterparty = bid_doc['body']['signer']
            mandate = payload['mandate']
            price = offer['price']
            note = offer['note']
            bid_id = bid_doc['id']
            need(counterparty not in {principal, agent, payload['resolver'], payload['appeal_resolver']}, 'RESOLVER_CONFLICT')
        else:
            need(bid is None, 'DIRECTORY_BID')
            source = payload
            principal, agent, counterparty = payload['principal'], payload['agent'], payload['counterparty']
            mandate = payload['mandate']
            price = payload['price']
        quoted = None
        listing_id = payload['listing']
    material = {'title': title, 'terms_text': terms_text, 'note': note, 'price': price,
                'work_units': source['quantity'], 'asset': source['asset'], 'listing': listing_id,
                'job': job_id, 'bid': bid_id}
    terms_hash = digest(TERMS_LABEL, material)
    if listing is not None:
        from covenant_language.marketplace import quote
        quoted = quote(record, agent, terms_hash, units=source['quantity'])
    terms = _bind_terms(index.chain, principal, agent, counterparty, mandate, source['native_profile'],
                        source['resource'], price, source['effect'], source['destination'], counterparty,
                        source['resolver'], source['appeal_resolver'], source['deadline'],
                        source['challenge_blocks'], source['timeout'], terms_hash)
    policy = _escrow(principal, counterparty, source['resolver'], source['appeal_resolver'], source['asset'], price, terms_hash)
    return {'op': 'BIND', 'terms': terms, 'path': 'DESIRE_TO_OFFER_TO_BIND', 'work_units': source['quantity'],
            'escrow_policy': policy['record'], 'escrow': {'quantity': price, 'asset': source['asset'],
            'moved': False, 'funded': False, 'desk': 'marketplace.ESCROW_POLICY_DRAFT'},
            'arbitration': {'resolver': source['resolver'], 'appeal_resolver': source['appeal_resolver'],
                            'distinct_from_parties': True, 'court': 'NATIVE_BIND_RESOLVER',
                            'review_profile': 'covenant-native/0.13 OPTIONAL_NOT_OPENED', 'submitted': False},
            'marketplace_quote': quoted, 'marketplace_quote_is_acceptance': False,
            'assents': 'NOT_COLLECTED', 'submitted': False, 'applied_to_chain': False,
            'execution_authorized': False, 'height_checked': False, 'grant_replayed': False,
            'profile_resource_checked': False, 'consensus_change': CONSENSUS_CHANGE,
            'paid': False}


def service_listing(private, market, title, price, payment_asset, capability='General', quantity=1):
    """A marketplace listing. Publication and settlement stay on the existing path."""
    from covenant_language.marketplace import simple_listing
    listed = simple_listing(market, public_key(private), title, price, payment_asset, quantity=quantity, category=capability)
    return {'listing': listed, 'published': False, 'execution_authorized': False,
            'next': 'marketplace_book.publish THEN a directory BID with target_kind LISTING THEN compile_draft'}


def publish_service(network, request, group, listing, expected_heads=None):
    from .marketplace_book import publish
    record = listing['record'] if type(listing) is dict and 'record' in listing and 'version' not in listing else listing
    if type(listing) is dict and 'record' in listing and listing.get('record', {}).get('kind') == 'LISTING':
        record = listing['record']
    return publish(network, request, group, record, 'PUBLIC_PLAINTEXT', expected_heads=expected_heads)


def replicate(network, request, group, envelope, stake=None, expected_heads=None):
    """Copy one signed document into the forum DAG as an ordinary POST."""
    document = open_document(envelope)
    need(document['body']['signer'] == network.actor, 'DIRECTORY_ACTOR')
    view = collect([envelope], network=network, stake=stake, group=group)
    need(document['id'] in view.documents, 'DIRECTORY_RATE_LIMIT')
    kind = document['body']['kind']
    content = {'thread': None, 'title': 'Directory ' + kind, 'content': {'body': document['body'], 'signature': document['signature']},
               'tags': ['covenant-directory', kind.lower()]}
    need(len(text_canonical(content)) <= 8192, 'DIRECTORY_POST_TOO_LARGE')
    from .social_views import guarded_emit
    result = guarded_emit(network, expected_heads=expected_heads, kind='POST', request=request, group=group, content=content)
    return {**result, 'document': document['id'], 'replicated': True, 'ledger': False, 'execution_authorized': False}


def report_abuse(reporter, domain, owner, target, reason, *, desk=None, channel=None, related=()):
    """File abuse through the existing founder feedback desk or channel."""
    _hash(target)
    _text(reason, 400, 'DIRECTORY_ABUSE')
    content = {'kind': 'DIRECTORY_ABUSE', 'target': target, 'reason': reason}
    scope = {'surface': 'directory', 'target': target}
    if channel is not None:
        need(desk is None, 'DIRECTORY_REPORT_SINK')
        result = channel.send('directory-abuse-' + target[:16], 'SECURITY', scope, content, related)
        return {**result, 'wired_to': 'covenant_feedback.send', 'execution_authorized': False}
    from .feedback import report
    envelope = report(reporter, domain, owner, 'SECURITY', scope, content, related)
    stored = desk.append(envelope) if desk is not None else None
    return {'envelope': envelope, 'desk': stored, 'wired_to': 'feedback.report', 'tool': 'covenant_feedback',
            'effect': 'NONE', 'execution_authorized': False, 'next': 'FeedbackChannel.send OR FeedbackDesk.append'}


_SEARCH_KEYS = {'query', 'capability', 'max_price', 'min_positive', 'availability', 'domain', 'sponsored', 'boost', 'policy', 'split', 'receipts', 'newcomers', 'exploration_seed', 'operator', 'price_elsewhere'}


def api(request, documents=(), settlements=(), network=None, stake=None, group=None, chain_state=None):
    """Read API. No session and no socket. Write replication is ``replicate``.

    ``parameters`` may carry ``documents``, ``settlements``, ``stake`` and ``group``.
    Those select the bundle. They are not search filters.
    """
    need(type(request) is dict and set(request) == {'action', 'parameters'}, 'DIRECTORY_API')
    action = request['action']
    parameters = dict(request['parameters'])
    need(type(parameters) is dict, 'DIRECTORY_API')
    if 'documents' in parameters:
        documents = parameters.pop('documents')
    if 'settlements' in parameters:
        settlements = parameters.pop('settlements')
    if 'stake' in parameters:
        stake = parameters.pop('stake')
    if 'group' in parameters:
        group = parameters.pop('group')
    parameters.pop('chain_state', None)
    index = collect(documents, settlements, network=network, stake=stake, group=group, chain_state=chain_state)
    if action == 'search':
        need(set(parameters) <= _SEARCH_KEYS, 'DIRECTORY_API')
        result = index.search(**parameters)
    elif action == 'profile':
        need(set(parameters) == {'identity'}, 'DIRECTORY_API')
        result = index.profile(parameters['identity'])
    elif action == 'feed':
        need(parameters == {}, 'DIRECTORY_API')
        result = index.feed()
    elif action == 'graph':
        need(parameters == {}, 'DIRECTORY_API')
        result = index.graph()
    elif action == 'page':
        need(set(parameters) <= {'identity', 'referrer'} and 'identity' in parameters, 'DIRECTORY_API')
        profile = index.profile(parameters['identity'])
        result = {'html': render_profile(profile, parameters.get('referrer')), 'json_ld': json_ld(profile),
                  'login_required': False}
    elif action == 'index':
        need(set(parameters) <= _SEARCH_KEYS, 'DIRECTORY_API')
        found = index.search(**parameters)
        result = {'html': render_directory(found), 'login_required': False, 'separation': found['separation']}
    elif action == 'draft':
        need(set(parameters) <= {'job', 'bid', 'listing'}, 'DIRECTORY_API')
        result = compile_draft(index, job=parameters.get('job'), bid=parameters.get('bid'), listing=parameters.get('listing'))
    elif action == 'share':
        need(set(parameters) <= {'agreement', 'referrer', 'opt_in', 'platforms'} and parameters.get('opt_in') is True, 'DIRECTORY_SHARE_OPT_IN')
        result = share_card(index.receipt(parameters['agreement']), opt_in=True, referrer=parameters['referrer'],
                            platforms=parameters.get('platforms') or ['opengraph'])
    else:
        raise ValueError('DIRECTORY_ACTION')
    if type(result) is dict:
        result.setdefault('login_required', False)
        result.setdefault('api', VERSION)
    return result
