"""Two-of-three threshold escrow: buyer, seller and arbitrator, on a chain the parties choose. Maturity: experimental.

An EXTERNAL_CHAIN mode beside the hosted reference ledger and the local quorum
escrow desk: the funds sit in an account any two of the three keys can spend.
Buyer and seller can settle together. The arbitrator's key signs only through
this module's arbitrator gate, which first replays the AAP dispute ladder
(covenant_language.agreement_procedures, an ESCALATION policy bound to this
agreement and these disputants) to FINAL_ATTESTED_OUTCOME and requires the
transaction to pay exactly the ladder's typed outcome. Two legs, as bytes for
the owners to sign and broadcast themselves:

* Safe (safe-global/safe-smart-account v1.4.1; same EIP-712 type hashes as
  v1.3.0): SafeTx typed data, EIP712Domain(uint256 chainId,address
  verifyingContract), the safeTxHash, packed r||s||v owner signatures in
  ascending owner order (checkNSignatures, GS026) and execTransaction calldata.
  A split pays through MultiSendCallOnly v1.4.1 by DELEGATECALL; ERC-20 assets
  use transfer(address,uint256). The canonical v1.4.1 deployment addresses are
  those of safe-global/safe-deployments.
* Bitcoin P2WSH: wsh(multi(2,B,S,A)) (BIP 380/383), optionally the miniscript
  (BIP 379, Draft) wsh(or_d(multi(2,B,S,A),and_v(v:pk(B),older(N)))) whose
  timeout branch refunds the buyer alone after N blocks (BIP 68/112). PSBTs
  follow BIP 174 (version 0) or BIP 370 (version 2); signatures are BIP 143
  SIGHASH_ALL, strict DER, low s; finalisation and extraction produce the
  signed transaction bytes.

Ladder decisions, signatures and transactions are evidence or a payment leg.
Only the terms all three parties signed decide; nothing here broadcasts.
"""
from copy import deepcopy
import re
import secrets

from covenant_language import agreement_application as application_profile

from . import bitcoin_codec as btc
from . import evm_codec as evm
from .crypto import need

TERMS = 'urn:aap:threshold-escrow:0.1'
TERMS_LABEL = 'AAP-THRESHOLD-ESCROW-0.1'
ROLES = ('buyer', 'seller', 'arbitrator')
SAFE, BITCOIN = 'SAFE', 'BITCOIN_P2WSH'
SAFE_VERSION = '1.4.1'
SAFE_141 = {'singleton': '0x41675c099f32341bf84bfc5382af534df5c7461a',
            'proxy_factory': '0x4e1dcf7ad4e460cfd30791ccc4f9c8a4f820ec67',
            'multi_send_call_only': '0x9641d764fc13c8b624c04430c7356c1c7c8102e2',
            'fallback_handler': '0xfd0732dc9e303f09fcef3a7388ad10a83459ec99'}
SAFE_TX = [{'name': name, 'type': kind} for kind, name in (
    ('address', 'to'), ('uint256', 'value'), ('bytes', 'data'), ('uint8', 'operation'), ('uint256', 'safeTxGas'),
    ('uint256', 'baseGas'), ('uint256', 'gasPrice'), ('address', 'gasToken'), ('address', 'refundReceiver'), ('uint256', 'nonce'))]
SAFE_DOMAIN = [{'name': 'chainId', 'type': 'uint256'}, {'name': 'verifyingContract', 'type': 'address'}]
EXEC = 'execTransaction(address,uint256,bytes,uint8,uint256,uint256,uint256,address,address,bytes)'
EXEC_TYPES = ['address', 'uint256', 'bytes', 'uint8', 'uint256', 'uint256', 'uint256', 'address', 'address', 'bytes']
SETUP = 'setup(address[],uint256,address,bytes,address,address,uint256,address)'
CREATE_PROXY = 'createProxyWithNonce(address,bytes,uint256)'
SEQUENCE = 0xfffffffd
FLAGS = {'execution_authorized': False, 'payment_authorized': False, 'release_authorized': False}

REMEDIATION = {
    'THRESHOLD_TERMS': 'Pass the exact escrow terms returned by terms(), unchanged.',
    'THRESHOLD_PARTIES': 'Name three distinct AAP keys for buyer, seller and arbitrator.',
    'THRESHOLD_AMOUNT': 'Use a positive integer amount and a unit of 1 to 32 printable characters (sat for Bitcoin).',
    'THRESHOLD_RAIL': 'Describe the leg exactly: SAFE {chain_id, safe, version 1.4.1, asset, owners, payees} with lowercase 0x addresses, or BITCOIN_P2WSH {network, keys, refund_older, payees} in sat; three distinct owners.',
    'THRESHOLD_LADDER': 'Bind the escrow to an ESCALATION ladder {policy, outcome} whose context is this agreement and whose disputants are its buyer and seller.',
    'THRESHOLD_APPROVALS': 'Pass approvals as [{party, signature}] from buyer, seller and arbitrator over the terms assent payload.',
    'THRESHOLD_NOT_ADOPTED': 'All three parties must sign the exact terms before any escrow transaction.',
    'THRESHOLD_PAID': 'The paid amount must be an integer from 0 to the escrowed amount.',
    'THRESHOLD_LADDER_NOT_FINAL': 'The arbitrator signs only after the ladder replays to FINAL_ATTESTED_OUTCOME with its retained head.',
    'THRESHOLD_LADDER_MISMATCH': 'The transaction does not pay the ladder outcome; build it from the outcome itself.',
    'THRESHOLD_ARBITRATOR_NEEDS_LADDER': 'Use the arbitrator gate with the ladder record; the arbitrator key has no other signing path.',
    'THRESHOLD_SIGNER_KEY': 'Sign with the key the terms name for this role.',
    'THRESHOLD_SIGNATURES': 'Pass owner signatures as 65-byte r||s||v hex values, or the packed Safe signature bytes in ascending owner order.',
    'THRESHOLD_TRANSACTION': 'Pass the exact transaction or PSBT built from these terms; outputs must pay only the agreed payees.',
    'THRESHOLD_UTXO': 'Spend the one escrow output {txid, vout, amount} whose amount equals the escrowed amount.',
    'THRESHOLD_FEE': 'Use a fee that leaves every output at or above the 546 satoshi dust limit.',
    'THRESHOLD_NOT_READY': 'Collect two valid owner signatures within the mandate before finalising.',
    'THRESHOLD_NO_TIMEOUT': 'These terms have no timeout branch; use the two-of-three path.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the input against the documented threshold escrow terms.')


def _hex(value, size=64, code='THRESHOLD_TERMS'):
    need(type(value) is str and re.fullmatch('[0-9a-f]{%d}' % size, value) is not None, code)
    return value


def _rail(rail, unit):
    need(type(rail) is dict and rail.get('kind') in (SAFE, BITCOIN), 'THRESHOLD_RAIL')
    if rail['kind'] == SAFE:
        need(set(rail) == {'kind', 'chain_id', 'safe', 'version', 'asset', 'owners', 'payees'} and rail['version'] == SAFE_VERSION
             and type(rail['chain_id']) is int and 0 < rail['chain_id'] < 2 ** 63, 'THRESHOLD_RAIL')
        need(type(rail['owners']) is dict and set(rail['owners']) == set(ROLES) and type(rail['payees']) is dict
             and set(rail['payees']) == {'buyer', 'seller'}, 'THRESHOLD_RAIL')
        try:
            values = [rail['safe'], *rail['owners'].values(), *rail['payees'].values()] + ([] if rail['asset'] == 'NATIVE' else [rail['asset']])
            need(all(evm.address(value) == value and value != evm.ZERO_ADDRESS for value in values), 'THRESHOLD_RAIL')
        except (ValueError, TypeError):
            raise ValueError('THRESHOLD_RAIL') from None
        need(len(set(rail['owners'].values())) == 3, 'THRESHOLD_RAIL')
        return rail
    need(set(rail) == {'kind', 'network', 'keys', 'refund_older', 'payees'} and rail['network'] in btc.NETWORKS and unit == 'sat',
         'THRESHOLD_RAIL')
    need(type(rail['keys']) is dict and set(rail['keys']) == set(ROLES) and type(rail['payees']) is dict
         and set(rail['payees']) == {'buyer', 'seller'}, 'THRESHOLD_RAIL')
    try:
        btc.escrow_script([rail['keys'][role] for role in ROLES], rail['refund_older'])
        scripts = [btc.output_script(rail['network'], rail['payees'][role]) for role in ('buyer', 'seller')]
    except ValueError:
        raise ValueError('THRESHOLD_RAIL') from None
    need(scripts[0] != scripts[1], 'THRESHOLD_RAIL')
    return rail


def _body(agreement, amount, unit, parties, ladder, rail, nonce):
    from .crypto import verification_key
    _hex(agreement)
    _hex(nonce)
    need(type(amount) is int and 0 < amount < 2 ** 256 and type(unit) is str and 0 < len(unit) <= 32
         and all(33 <= ord(c) <= 126 for c in unit), 'THRESHOLD_AMOUNT')
    need(type(parties) is dict and set(parties) == set(ROLES) and len(set(parties.values())) == 3, 'THRESHOLD_PARTIES')
    for value in parties.values():
        try:
            need(type(value) is str, 'THRESHOLD_PARTIES')
            verification_key(value)
        except ValueError:
            raise ValueError('THRESHOLD_PARTIES') from None
    need(type(ladder) is dict and set(ladder) == {'policy', 'outcome'} and type(ladder['outcome']) is str
         and re.fullmatch(r'[A-Za-z][A-Za-z0-9_.:-]{0,63}', ladder['outcome']) is not None, 'THRESHOLD_LADDER')
    _hex(ladder['policy'], code='THRESHOLD_LADDER')
    return {'version': TERMS, 'agreement': agreement, 'amount': amount, 'unit': unit, 'parties': dict(parties),
            'ladder': dict(ladder), 'rail': deepcopy(_rail(rail, unit)), 'nonce': nonce}


def terms_id(body):
    return application_profile.content_id(TERMS, body)


def terms(agreement, *, amount, unit, parties, ladder, rail, nonce=None):
    """Unsigned escrow terms and the assent payload all three parties sign."""
    body = _body(agreement, amount, unit, parties, ladder, rail, secrets.token_hex(32) if nonce is None else nonce)
    out = {'terms': body, 'id': terms_id(body),
           'assent_payload': {'label': TERMS_LABEL, 'body': deepcopy(body), 'required_signers': dict(parties)},
           'assent': 'NOT_GIVEN', **FLAGS}
    if rail['kind'] == BITCOIN:
        out['bitcoin'] = bitcoin_escrow(body)
    return out


def _terms(body):
    need(type(body) is dict and set(body) == {'version', 'agreement', 'amount', 'unit', 'parties', 'ladder', 'rail', 'nonce'}
         and body['version'] == TERMS, 'THRESHOLD_TERMS')
    rebuilt = _body(body['agreement'], body['amount'], body['unit'], body['parties'], body['ladder'], body['rail'], body['nonce'])
    need(application_profile.canonical(rebuilt) == application_profile.canonical(body), 'THRESHOLD_TERMS')
    return body


def adopted(body, approvals):
    """All three parties signed the exact terms."""
    from .crypto import verify
    _terms(body)
    need(type(approvals) is list and len(approvals) <= 3, 'THRESHOLD_APPROVALS')
    signed = set()
    for approval in approvals:
        need(type(approval) is dict and set(approval) == {'party', 'signature'} and approval['party'] in ROLES
             and approval['party'] not in signed, 'THRESHOLD_APPROVALS')
        try:
            verify(body['parties'][approval['party']], TERMS_LABEL, body, approval['signature'])
        except ValueError:
            raise ValueError('THRESHOLD_APPROVALS') from None
        signed.add(approval['party'])
    need(signed == set(ROLES), 'THRESHOLD_NOT_ADOPTED')
    return True


def ladder_outcome(body, ladder):
    """Replay the bound dispute ladder; the paid amount when it is final, else refuse."""
    from covenant_language import agreement_procedures as procedures
    need(type(ladder) is dict and set(ladder) == {'policy', 'adoptions', 'events', 'head'}, 'THRESHOLD_LADDER')
    policy = ladder['policy']
    try:
        need(procedures.identifier(policy) == body['ladder']['policy'] and policy['kind'] == 'ESCALATION', 'THRESHOLD_LADDER')
        state = procedures.replay(policy, ladder['adoptions'], ladder['events'], ladder['head'])
    except (ValueError, KeyError, TypeError) as error:
        raise ValueError(str(error) if str(error) == 'THRESHOLD_LADDER' else 'THRESHOLD_LADDER_NOT_FINAL') from None
    disputants = {policy['parties'][role] for role in policy['configuration']['disputants']}
    need(policy['context'] == body['agreement'] and disputants == {body['parties']['buyer'], body['parties']['seller']},
         'THRESHOLD_LADDER')
    need(state['status'] == 'FINAL_ATTESTED_OUTCOME', 'THRESHOLD_LADDER_NOT_FINAL')
    value = state['outcome'].get(body['ladder']['outcome'])
    need(type(value) is dict and value.get('kind') == 'MONEY' and value.get('unit') == body['unit']
         and 0 <= value.get('amount', -1) <= body['amount'], 'THRESHOLD_LADDER_MISMATCH')
    return {'paid': value['amount'], 'refunded': body['amount'] - value['amount'], 'head': state['head'],
            'policy': body['ladder']['policy'], 'status': state['status']}


def _paid(body, paid):
    need(type(paid) is int and 0 <= paid <= body['amount'], 'THRESHOLD_PAID')
    return {'paid': paid, 'refunded': body['amount'] - paid}


# Safe -------------------------------------------------------------------------

def safe_setup(owners, *, salt_nonce, fallback_handler=SAFE_141['fallback_handler']):
    """Safe.setup initializer and SafeProxyFactory.createProxyWithNonce calldata for a 2-of-3 Safe v1.4.1."""
    need(type(owners) is dict and set(owners) == set(ROLES), 'THRESHOLD_RAIL')
    try:
        addresses = [evm.address(owners[role]) for role in ROLES]
        handler = evm.address(fallback_handler)
    except ValueError:
        raise ValueError('THRESHOLD_RAIL') from None
    need(len(set(addresses)) == 3 and type(salt_nonce) is int and 0 <= salt_nonce < 2 ** 256, 'THRESHOLD_RAIL')
    initializer = evm.call(SETUP, ['address[]', 'uint256', 'address', 'bytes', 'address', 'address', 'uint256', 'address'],
                           [addresses, 2, evm.ZERO_ADDRESS, b'', handler, evm.ZERO_ADDRESS, 0, evm.ZERO_ADDRESS])
    create = evm.call(CREATE_PROXY, ['address', 'bytes', 'uint256'], [SAFE_141['singleton'], initializer, salt_nonce])
    return {'version': SAFE_VERSION, 'threshold': 2, 'owners': addresses, 'initializer': '0x' + initializer.hex(),
            'call': {'to': SAFE_141['proxy_factory'], 'value': 0, 'function': CREATE_PROXY, 'data': '0x' + create.hex()},
            'safe_address': 'READ_FROM_THE_PROXY_CREATION_EVENT', 'submitted': False, 'broadcast': False, **FLAGS}


def _transfer(rail, payee, amount):
    if rail['asset'] == 'NATIVE':
        return payee, amount, b''
    return rail['asset'], 0, evm.call('transfer(address,uint256)', ['address', 'uint256'], [payee, amount])


def safe_transaction(body, paid, *, nonce):
    """The SafeTx paying paid to the seller and the rest to the buyer, as EIP-712 typed data and safeTxHash."""
    _terms(body)
    rail = body['rail']
    need(rail['kind'] == SAFE, 'THRESHOLD_RAIL')
    split = _paid(body, paid)
    need(type(nonce) is int and 0 <= nonce < 2 ** 256, 'THRESHOLD_TRANSACTION')
    legs = [(rail['payees'][role], value) for role, value in (('seller', split['paid']), ('buyer', split['refunded'])) if value]
    if len(legs) == 1:
        to, value, data = _transfer(rail, *legs[0])
        operation = 0
    else:
        packed = b''
        for payee, amount in legs:
            target, value, inner = _transfer(rail, payee, amount)
            packed += evm.encode_packed(['uint8', 'address', 'uint256', 'uint256', 'bytes'], [0, target, value, len(inner), inner])
        to, value, operation = SAFE_141['multi_send_call_only'], 0, 1
        data = evm.call('multiSend(bytes)', ['bytes'], [packed])
    message = {'to': to, 'value': value, 'data': '0x' + data.hex(), 'operation': operation, 'safeTxGas': 0, 'baseGas': 0,
               'gasPrice': 0, 'gasToken': evm.ZERO_ADDRESS, 'refundReceiver': evm.ZERO_ADDRESS, 'nonce': nonce}
    typed = {'types': {'EIP712Domain': SAFE_DOMAIN, 'SafeTx': SAFE_TX}, 'primaryType': 'SafeTx',
             'domain': {'chainId': rail['chain_id'], 'verifyingContract': rail['safe']}, 'message': message}
    return {'terms': terms_id(body), 'typed_data': typed, 'safe_tx_hash': '0x' + evm.typed_data_digest(typed).hex(),
            'outcome': split, 'safe': rail['safe'], 'chain_id': rail['chain_id'], **FLAGS}


def _safe_check(body, transaction):
    need(type(transaction) is dict and type(transaction.get('typed_data')) is dict, 'THRESHOLD_TRANSACTION')
    message = transaction['typed_data'].get('message')
    need(type(message) is dict and type(message.get('nonce')) is int, 'THRESHOLD_TRANSACTION')
    paid = transaction.get('outcome', {}).get('paid') if type(transaction.get('outcome')) is dict else None
    expected = safe_transaction(body, paid, nonce=message['nonce'])
    need(application_profile.canonical(expected['typed_data']) == application_profile.canonical(transaction['typed_data']),
         'THRESHOLD_TRANSACTION')
    return expected


def _sign_safe(body, transaction, role, private_key):
    expected = _safe_check(body, transaction)
    try:
        signer = evm.address_of(private_key)
    except ValueError:
        raise ValueError('THRESHOLD_SIGNER_KEY') from None
    need(signer == body['rail']['owners'][role], 'THRESHOLD_SIGNER_KEY')
    signature = evm.sign_digest(private_key, bytes.fromhex(expected['safe_tx_hash'][2:]))
    return {'role': role, 'owner': signer, 'signature': signature['bytes'], 'safe_tx_hash': expected['safe_tx_hash']}


def party_sign(body, approvals, transaction, role, private_key):
    """Owner action for buyer or seller: sign the exact SafeTx. The arbitrator has no path here."""
    need(role != 'arbitrator', 'THRESHOLD_ARBITRATOR_NEEDS_LADDER')
    need(role in ROLES, 'THRESHOLD_SIGNER_KEY')
    adopted(body, approvals)
    return _sign_safe(body, transaction, role, private_key)


def arbitrator_sign(body, approvals, transaction, ladder, private_key):
    """Owner action for the arbitrator: only after the bound ladder is final and the SafeTx pays its outcome."""
    adopted(body, approvals)
    outcome = ladder_outcome(body, ladder)
    expected = _safe_check(body, transaction)
    need(expected['outcome']['paid'] == outcome['paid'], 'THRESHOLD_LADDER_MISMATCH')
    return {**_sign_safe(body, transaction, 'arbitrator', private_key), 'ladder_head': outcome['head']}


def signing_request(body, approvals, transaction, role, ladder=None):
    """Typed data for an external wallet: buyer and seller freely, the arbitrator only through the ladder."""
    adopted(body, approvals)
    expected = _safe_check(body, transaction)
    if role == 'arbitrator':
        need(ladder is not None, 'THRESHOLD_ARBITRATOR_NEEDS_LADDER')
        need(ladder_outcome(body, ladder)['paid'] == expected['outcome']['paid'], 'THRESHOLD_LADDER_MISMATCH')
    need(role in ROLES, 'THRESHOLD_SIGNER_KEY')
    return {'role': role, 'owner': body['rail']['owners'][role], 'typed_data': expected['typed_data'],
            'safe_tx_hash': expected['safe_tx_hash'], 'method': 'eth_signTypedData_v4', **FLAGS}


def verify_safe(body, approvals, transaction, signatures, *, ladder=None):
    """Two valid owner signatures within the mandate make the execTransaction bytes; anything else is reported."""
    adopted(body, approvals)
    expected = _safe_check(body, transaction)
    digest = bytes.fromhex(expected['safe_tx_hash'][2:])
    owners = {address: role for role, address in body['rail']['owners'].items()}
    if type(signatures) is str:
        raw = evm.unhex(signatures, None, 'THRESHOLD_SIGNATURES')
        need(0 < len(raw) <= 3 * 65 and len(raw) % 65 == 0, 'THRESHOLD_SIGNATURES')
        signatures = ['0x' + raw[i:i + 65].hex() for i in range(0, len(raw), 65)]
        packed = True
    else:
        need(type(signatures) is list and 0 < len(signatures) <= 3, 'THRESHOLD_SIGNATURES')
        packed = False
    recovered = []
    for value in signatures:
        try:
            recovered.append(evm.recover(digest, value))
        except ValueError:
            raise ValueError('THRESHOLD_SIGNATURES') from None
    need(all(address in owners for address in recovered) and len(set(recovered)) == len(recovered), 'THRESHOLD_SIGNATURES')
    need(not packed or recovered == sorted(recovered), 'THRESHOLD_SIGNATURES')
    roles = sorted(owners[address] for address in recovered)
    mandate = 'COOPERATIVE'
    if 'arbitrator' in roles:
        try:
            ruled = ladder is not None and ladder_outcome(body, ladder)['paid'] == expected['outcome']['paid']
        except ValueError:
            ruled = False
        mandate = 'LADDER_DECISION_VERIFIED' if ruled else 'ARBITRATOR_SIGNATURE_WITHOUT_LADDER_DECISION'
    ready = len(roles) >= 2 and mandate != 'ARBITRATOR_SIGNATURE_WITHOUT_LADDER_DECISION'
    out = {'terms': terms_id(body), 'signers': roles, 'mandate': mandate, 'onchain_threshold_met': len(roles) >= 2,
           'status': 'READY' if ready else 'REFUSED' if len(roles) >= 2 else 'INSUFFICIENT_SIGNATURES',
           'outcome': expected['outcome'], 'safe_tx_hash': expected['safe_tx_hash'], **FLAGS}
    if ready:
        ordered = sorted(zip(recovered, signatures))
        packed_bytes = b''.join(evm.unhex(value, 65, 'THRESHOLD_SIGNATURES') for _, value in ordered)
        message = expected['typed_data']['message']
        data = evm.call(EXEC, EXEC_TYPES, [message['to'], message['value'], bytes.fromhex(message['data'][2:]), message['operation'],
                                           0, 0, 0, evm.ZERO_ADDRESS, evm.ZERO_ADDRESS, packed_bytes])
        out['exec_transaction'] = {'to': body['rail']['safe'], 'value': 0, 'function': EXEC, 'data': '0x' + data.hex(),
                                   'signatures': '0x' + packed_bytes.hex(), 'submitted': False, 'broadcast': False}
    return out


# Bitcoin P2WSH ----------------------------------------------------------------

def bitcoin_escrow(body):
    """Descriptor, witness script, P2WSH output script and address of the escrow output."""
    rail = body['rail']
    need(rail['kind'] == BITCOIN, 'THRESHOLD_RAIL')
    keys = [rail['keys'][role] for role in ROLES]
    script = btc.escrow_script(keys, rail['refund_older'])
    output = btc.p2wsh(script)
    return {'descriptor': btc.escrow_descriptor(keys, rail['refund_older']), 'witness_script': script.hex(),
            'script_pubkey': output.hex(), 'address': btc.segwit_address(rail['network'], 0, output[2:]),
            'key_order': list(ROLES), 'timeout_branch': rail['refund_older'] is not None}


def _utxo(body, utxo):
    need(type(utxo) is dict and set(utxo) == {'txid', 'vout', 'amount'}, 'THRESHOLD_UTXO')
    need(type(utxo['txid']) is str and re.fullmatch('[0-9a-f]{64}', utxo['txid']) is not None and type(utxo['vout']) is int
         and 0 <= utxo['vout'] < 2 ** 32 and utxo['amount'] == body['amount'], 'THRESHOLD_UTXO')
    return utxo


def _payouts(body, paid, fee):
    """[(role, script hex, value)]: the fee comes out of the seller's share unless the seller receives nothing."""
    split = _paid(body, paid)
    need(type(fee) is int and 0 < fee < body['amount'], 'THRESHOLD_FEE')
    rail = body['rail']
    rows = []
    for role, value in (('seller', split['paid'] - fee if split['paid'] else 0), ('buyer', split['refunded'] - (0 if split['paid'] else fee))):
        if (role == 'seller' and split['paid']) or (role == 'buyer' and split['refunded']):
            need(value >= btc.DUST, 'THRESHOLD_FEE')
            rows.append((role, btc.output_script(rail['network'], rail['payees'][role]).hex(), value))
    return rows


def bitcoin_psbt(body, approvals, *, utxo, paid, fee, version=0):
    """Unsigned PSBT spending the escrow output to the agreed split (two-of-three branch)."""
    adopted(body, approvals)
    need(body['rail']['kind'] == BITCOIN, 'THRESHOLD_RAIL')
    _utxo(body, utxo)
    escrow = bitcoin_escrow(body)
    rows = _payouts(body, paid, fee)
    tx = {'version': 2, 'locktime': 0, 'inputs': [{'txid': utxo['txid'], 'vout': utxo['vout'], 'sequence': SEQUENCE}],
          'outputs': [{'value': value, 'script': script} for _, script, value in rows]}
    fields = [[(btc.I_WITNESS_UTXO, btc.witness_utxo(utxo['amount'], bytes.fromhex(escrow['script_pubkey']))),
               (btc.I_WITNESS_SCRIPT, bytes.fromhex(escrow['witness_script'])),
               (btc.I_SIGHASH, btc.SIGHASH_ALL.to_bytes(4, 'little'))]]
    psbt = btc.make_psbt(tx, fields, version)
    return {'terms': terms_id(body), 'psbt': btc.psbt_base64(psbt), 'version': version, 'outcome': _paid(body, paid), 'fee': fee,
            'txid': btc.txid(tx), 'submitted': False, 'broadcast': False, **FLAGS}


def _psbt(body, psbt):
    """The escrow input's facts and the paid amount the PSBT's outputs encode."""
    need(body['rail']['kind'] == BITCOIN, 'THRESHOLD_RAIL')
    try:
        parsed = btc.decode_psbt(psbt)
        tx = btc.unsigned_tx(parsed)
    except ValueError:
        raise ValueError('THRESHOLD_TRANSACTION') from None
    escrow = bitcoin_escrow(body)
    need(len(tx['inputs']) == 1 and len(parsed['inputs']) == 1, 'THRESHOLD_TRANSACTION')
    pairs = parsed['inputs'][0]
    utxo = btc.get(pairs, btc.I_WITNESS_UTXO)
    need(utxo is not None and btc.get(pairs, btc.I_WITNESS_SCRIPT) == bytes.fromhex(escrow['witness_script']), 'THRESHOLD_TRANSACTION')
    amount, script = btc.read_witness_utxo(utxo)
    need(script.hex() == escrow['script_pubkey'] and amount == body['amount'], 'THRESHOLD_UTXO')
    sighash = btc.get(pairs, btc.I_SIGHASH)
    need(sighash is None or sighash == btc.SIGHASH_ALL.to_bytes(4, 'little'), 'THRESHOLD_TRANSACTION')
    payees = {btc.output_script(body['rail']['network'], body['rail']['payees'][role]).hex(): role for role in ('buyer', 'seller')}
    outputs = {}
    for row in tx['outputs']:
        role = payees.get(row['script'])
        need(role is not None and role not in outputs and row['value'] >= btc.DUST, 'THRESHOLD_TRANSACTION')
        outputs[role] = row['value']
    fee = amount - sum(outputs.values())
    need(0 < fee < amount and outputs, 'THRESHOLD_TRANSACTION')
    paid = body['amount'] - outputs.get('buyer', 0) if 'seller' in outputs else 0
    return parsed, tx, {'paid': paid, 'refunded': body['amount'] - paid, 'fee': fee}, escrow


def _sign_psbt(body, psbt, role, private_key, sequence=None):
    parsed, tx, outcome, escrow = _psbt(body, psbt)
    need(sequence is None or tx['inputs'][0]['sequence'] == sequence, 'THRESHOLD_TRANSACTION')
    try:
        public = btc.public_bytes(private_key)
    except ValueError:
        raise ValueError('THRESHOLD_SIGNER_KEY') from None
    need(public.hex() == body['rail']['keys'][role], 'THRESHOLD_SIGNER_KEY')
    digest = btc.bip143_sighash(tx, 0, bytes.fromhex(escrow['witness_script']), body['amount'])
    signature = btc.ecdsa_sign(private_key, digest)
    parsed['inputs'][0] = btc.put(parsed['inputs'][0], btc.I_PARTIAL_SIG, signature, public)
    return {'role': role, 'psbt': btc.psbt_base64(parsed), 'outcome': outcome, **FLAGS}


def party_sign_psbt(body, approvals, psbt, role, private_key):
    """Owner action for buyer or seller on the two-of-three branch."""
    need(role != 'arbitrator', 'THRESHOLD_ARBITRATOR_NEEDS_LADDER')
    need(role in ROLES, 'THRESHOLD_SIGNER_KEY')
    adopted(body, approvals)
    return _sign_psbt(body, psbt, role, private_key)


def arbitrator_sign_psbt(body, approvals, psbt, ladder, private_key):
    """Owner action for the arbitrator: only for a PSBT paying the final ladder outcome."""
    adopted(body, approvals)
    outcome = ladder_outcome(body, ladder)
    need(_psbt(body, psbt)[2]['paid'] == outcome['paid'], 'THRESHOLD_LADDER_MISMATCH')
    return {**_sign_psbt(body, psbt, 'arbitrator', private_key), 'ladder_head': outcome['head']}


def verify_psbt(body, approvals, psbt, *, ladder=None):
    """Valid partial signatures by role, the mandate check, and READY when two owners may spend."""
    adopted(body, approvals)
    parsed, tx, outcome, escrow = _psbt(body, psbt)
    digest = btc.bip143_sighash(tx, 0, bytes.fromhex(escrow['witness_script']), body['amount'])
    keys = {value: role for role, value in body['rail']['keys'].items()}
    signed = {}
    for public, signature in btc.partial_signatures(parsed['inputs'][0]).items():
        need(public in keys and signature[-1:] == b'\x01', 'THRESHOLD_SIGNATURES')
        try:
            valid = btc.ecdsa_verify(bytes.fromhex(public), digest, signature[:-1])
        except ValueError:
            valid = False
        need(valid, 'THRESHOLD_SIGNATURES')
        signed[keys[public]] = signature
    mandate = 'COOPERATIVE'
    if 'arbitrator' in signed:
        try:
            ruled = ladder is not None and ladder_outcome(body, ladder)['paid'] == outcome['paid']
        except ValueError:
            ruled = False
        mandate = 'LADDER_DECISION_VERIFIED' if ruled else 'ARBITRATOR_SIGNATURE_WITHOUT_LADDER_DECISION'
    ready = len(signed) >= 2 and mandate != 'ARBITRATOR_SIGNATURE_WITHOUT_LADDER_DECISION'
    return {'terms': terms_id(body), 'signers': sorted(signed), 'mandate': mandate, 'outcome': outcome,
            'status': 'READY' if ready else 'REFUSED' if len(signed) >= 2 else 'INSUFFICIENT_SIGNATURES',
            'sighash': digest.hex(), **FLAGS}


def finalize_psbt(body, approvals, psbt, *, ladder=None):
    """BIP 174 finaliser and extractor for a READY two-of-three spend: the signed transaction bytes."""
    checked = verify_psbt(body, approvals, psbt, ladder=ladder)
    need(checked['status'] == 'READY', 'THRESHOLD_NOT_READY')
    parsed, tx, outcome, escrow = _psbt(body, psbt)
    signatures = btc.partial_signatures(parsed['inputs'][0])
    chosen = [signatures[body['rail']['keys'][role]] for role in ROLES if body['rail']['keys'][role] in signatures][:2]
    final = btc.finalize(parsed, 0, [b''] + chosen + [bytes.fromhex(escrow['witness_script'])])
    raw = btc.extract(final)
    return {'terms': terms_id(body), 'transaction': raw.hex(), 'txid': btc.txid(tx), 'psbt': btc.psbt_base64(final),
            'outcome': outcome, 'signers': checked['signers'], 'mandate': checked['mandate'], 'submitted': False,
            'broadcast': False, **FLAGS}


def bitcoin_refund_psbt(body, approvals, *, utxo, fee, version=0):
    """The buyer-only timeout branch: an unsigned PSBT whose input waits refund_older blocks (BIP 68)."""
    adopted(body, approvals)
    need(body['rail']['kind'] == BITCOIN, 'THRESHOLD_RAIL')
    need(body['rail']['refund_older'] is not None, 'THRESHOLD_NO_TIMEOUT')
    _utxo(body, utxo)
    escrow = bitcoin_escrow(body)
    rows = _payouts(body, 0, fee)
    tx = {'version': 2, 'locktime': 0, 'inputs': [{'txid': utxo['txid'], 'vout': utxo['vout'], 'sequence': body['rail']['refund_older']}],
          'outputs': [{'value': value, 'script': script} for _, script, value in rows]}
    fields = [[(btc.I_WITNESS_UTXO, btc.witness_utxo(utxo['amount'], bytes.fromhex(escrow['script_pubkey']))),
               (btc.I_WITNESS_SCRIPT, bytes.fromhex(escrow['witness_script'])),
               (btc.I_SIGHASH, btc.SIGHASH_ALL.to_bytes(4, 'little'))]]
    psbt = btc.make_psbt(tx, fields, version)
    return {'terms': terms_id(body), 'psbt': btc.psbt_base64(psbt), 'version': version, 'outcome': _paid(body, 0),
            'relative_timelock_blocks': body['rail']['refund_older'], 'submitted': False, 'broadcast': False, **FLAGS}


def finalize_refund(body, approvals, psbt, private_key):
    """Owner action for the buyer after the timeout: sign and finalise the refund branch."""
    adopted(body, approvals)
    need(body['rail']['refund_older'] is not None, 'THRESHOLD_NO_TIMEOUT')
    signed = _sign_psbt(body, psbt, 'buyer', private_key, sequence=body['rail']['refund_older'])
    parsed, tx, outcome, escrow = _psbt(body, signed['psbt'])
    need(outcome['paid'] == 0, 'THRESHOLD_TRANSACTION')
    signature = btc.partial_signatures(parsed['inputs'][0])[body['rail']['keys']['buyer']]
    final = btc.finalize(parsed, 0, [signature, b'', b'', b'', bytes.fromhex(escrow['witness_script'])])
    return {'terms': terms_id(body), 'transaction': btc.extract(final).hex(), 'txid': btc.txid(tx), 'outcome': outcome,
            'relative_timelock_blocks': body['rail']['refund_older'], 'submitted': False, 'broadcast': False, **FLAGS}


def describe():
    return {'version': TERMS, 'roles': list(ROLES), 'threshold': 2,
            'safe': {'version': SAFE_VERSION, 'deployments': dict(SAFE_141), 'typed_data': 'EIP-712 SafeTx',
                     'signatures': 'r||s||v, ascending owner order'},
            'bitcoin': {'descriptor': 'wsh(multi(2,B,S,A)) or wsh(or_d(multi(2,B,S,A),and_v(v:pk(B),older(N))))',
                        'psbt': 'BIP 174 v0 and BIP 370 v2', 'sighash': 'BIP 143 SIGHASH_ALL'},
            'arbitrator': 'SIGNS_ONLY_THROUGH_THE_LADDER_GATE', 'network_contacted': False, **FLAGS}
