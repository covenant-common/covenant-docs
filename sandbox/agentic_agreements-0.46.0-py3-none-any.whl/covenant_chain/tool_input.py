"""Bounded schema validation with schema-owned, value-free diagnostics."""
from copy import deepcopy
import re
from covenant_language.agentic import canonical

class ToolInputError(ValueError):
    def __init__(self,issues):
        super().__init__('EXCHANGE_SCHEMA');self.issues=deepcopy(issues[:16])


def validate_schema(value,shape):
    types={'object':lambda v:type(v) is dict,'array':lambda v:type(v) is list,'string':lambda v:type(v) is str,
           'integer':lambda v:type(v) is int,'boolean':lambda v:type(v) is bool,'null':lambda v:v is None}
    def issue(path,code,**detail):return {'path':path,'code':code,**detail}
    def child(path,key):return path+'/'+key.replace('~','~0').replace('/','~1')
    def discriminants(v,s):
        """Compare only schema-owned const fields, never input field names."""
        matched=mismatched=0
        if 'const' in s:
            if canonical(v)==canonical(s['const']):matched+=1
            else:mismatched+=1
        if type(v) is dict:
            for name,sub in s.get('properties',{}).items():
                if name in v:
                    yes,no=discriminants(v[name],sub);matched+=yes;mismatched+=no
        return matched,mismatched
    def branch_rank(v,s,problems):
        matched,mismatched=discriminants(v,s)
        recognized=sum(name in s.get('properties',{}) for name in v) if type(v) is dict else 0
        # One REQUIRED issue can stand for many absent fields. Likewise an
        # UNKNOWN_FIELDS issue has an explicit count. Counting either as one
        # made a short, unrelated shortcut win over the caller's chosen form.
        cost=sum(10 if i['code']=='CONST' else len(i['fields']) if i['code']=='REQUIRED'
                 else i['count'] if i['code']=='UNKNOWN_FIELDS' else 1 for i in problems)
        return mismatched,-matched,-recognized,cost
    def check(v,s,path=''):
        out=[]
        if 'type' in s:
            choices=s['type'] if type(s['type']) is list else [s['type']]
            if not any(types[t](v) for t in choices):return [issue(path,'TYPE',expected=choices)]
        if 'const' in s and canonical(v)!=canonical(s['const']):return [issue(path,'CONST')]
        if 'enum' in s and not any(canonical(v)==canonical(x) for x in s['enum']):out.append(issue(path,'ENUM',allowed=deepcopy(s['enum'])))
        if 'oneOf' in s:
            branches=[check(v,b,path) for b in s['oneOf']];valid=sum(not b for b in branches)
            if valid!=1:
                if valid>1:out.append(issue(path,'AMBIGUOUS_BRANCH'))
                else:
                    # Select diagnostics only after every branch has failed;
                    # this ranking cannot change accepted/rejected semantics.
                    selected=min(range(len(branches)),key=lambda i:branch_rank(v,s['oneOf'][i],branches[i]))
                    best=branches[selected]
                    out.extend(best or [issue(path,'NO_MATCHING_BRANCH')])
        if type(v) is dict:
            if len(v)<s.get('minProperties',0) or len(v)>s.get('maxProperties',2**53):
                return out+[issue(path,'OBJECT_LENGTH',minimum=s.get('minProperties',0),maximum=s.get('maxProperties',2**53))]
            missing=[k for k in s.get('required',[]) if k not in v]
            if missing:out.append(issue(path,'REQUIRED',fields=missing[:16]))
            props=s.get('properties',{})
            if s.get('additionalProperties') is False:
                count=sum(k not in props for k in v)
                if count:out.append(issue(path,'UNKNOWN_FIELDS',count=count,allowed=sorted(props)[:32]))
            for k,sub in props.items():
                if k in v:
                    problems=check(v[k],sub,child(path,k));out.extend(problems)
                    if 'const' in sub and problems:return out[:16]
                if len(out)>=16:break
            # Variable map keys may themselves contain private names. Validate
            # typed entries but use a schema-owned wildcard in diagnostics.
            for k,item in v.items():
                if 'propertyNames' in s:
                    out.extend(check(k,s['propertyNames'],child(path,'*')))
                if k not in props and type(s.get('additionalProperties')) is dict:
                    out.extend(check(item,s['additionalProperties'],child(path,'*')))
                if len(out)>=16:break
        if type(v) is list:
            if len(v)<s.get('minItems',0) or len(v)>s.get('maxItems',2**53):return out+[issue(path,'ARRAY_LENGTH',minimum=s.get('minItems',0),maximum=s.get('maxItems',2**53))]
            if 'items' in s:
                for i,item in enumerate(v):
                    out.extend(check(item,s['items'],child(path,str(i))))
                    if len(out)>=16:break
        if type(v) is str:
            if len(v)<s.get('minLength',0) or len(v)>s.get('maxLength',2**53):out.append(issue(path,'STRING_LENGTH',minimum=s.get('minLength',0),maximum=s.get('maxLength',2**53)))
            if 'pattern' in s and re.search(s['pattern'],v) is None:out.append(issue(path,'PATTERN'))
        if type(v) is int and (v<s.get('minimum',-2**53) or v>s.get('maximum',2**53)):out.append(issue(path,'INTEGER_RANGE',minimum=s.get('minimum',-2**53),maximum=s.get('maximum',2**53)))
        return out[:16]
    errors=check(value,shape)
    if errors:raise ToolInputError(errors)
