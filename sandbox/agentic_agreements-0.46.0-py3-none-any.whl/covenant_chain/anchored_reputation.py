"""Anchored, Sybil-resistant contextual reputation computed by the principal.

AAP application profile ``covenant-anchored-reputation/0.1``. Evidence about a
provider counts only through witnesses the principal already reaches: its own
trusted contacts and agents introduced to them within a few hops
(``covenant-introductions/0.1``). Each piece of evidence is weighted by the
witness's anchor weight, by verified stake at risk and by recency, in one exact
task class. Witnesses reached through the same trusted contact (a shared
introduction root), a declared operator or one resolver form one independence
cluster; a cluster counts once. Introducers
whose subjects misbehave lose weight, and their own standing is discounted.

A Sybil ring can sign any number of receipts among itself. Without an
introduction from an anchored agent its evidence weighs nothing; with one, the
whole ring sits inside the cluster of the trusted contact it entered through,
and its introducer's standing is at risk. Influence is bounded by attack
edges into distinct trusted contacts, never by ring size.

Inputs are signed records: portable-trust OUTCOME receipts (unchanged),
unilateral REPORT records, STAKE attestations by owner-adopted holders,
introductions and postage KEEP decisions. The score is the principal's own
view, not a global or portable number, and never world truth or authority.
"""
from copy import deepcopy

from .crypto import canonical, digest, integer, key, need, public_key, sign, verification_key, verify
from . import introductions as intro
from .network_incentives import wilson_lb_bps

VERSION = 'covenant-anchored-reputation/0.1'
LABEL = 'COVENANT-ANCHORED-REPUTATION-0.1'
FIELDS = {
    'REPORT': 'reporter subject agreement task_class outcome evidence issued_at nonce',
    'STAKE': 'holder agreement party amount unit held_at nonce',
}
SIGNER = {'REPORT': 'reporter', 'STAKE': 'holder'}
DEFAULT_POLICY = {
    'max_depth': intro.DEFAULT_DEPTH, 'decay_bps': intro.DEFAULT_DECAY_BPS, 'half_life': 7776000,
    'stake_step_bps': 1250, 'stake_cap_bps': 30000, 'failure_multiplier': 2, 'spam_multiplier': 1,
    'min_clusters': 3, 'min_lower_bound_bps': 4000, 'penalty_step_bps': intro.PENALTY_STEP_BPS,
}
POLICY_RANGES = {
    'max_depth': (0, intro.MAX_DEPTH), 'decay_bps': (1, 10000), 'half_life': (1, 2**40),
    'stake_step_bps': (0, 10000), 'stake_cap_bps': (10000, 100000), 'failure_multiplier': (0, 16),
    'spam_multiplier': (0, 16), 'min_clusters': (1, 64), 'min_lower_bound_bps': (0, 10000),
    'penalty_step_bps': (0, 10000),
}
STANDINGS = ('ESTABLISHED', 'EMERGING', 'UNKNOWN', 'NEGATIVE')
MAX_EVIDENCE = 1024
MAX_CANDIDATES = 256
MAX_LINKS = 1024
MAX_RECORD_BYTES = 16384
MAX_INPUT_BYTES = 8_000_000

REMEDIATION = {
    'REPUTATION_FIELDS': 'Use the exact field set of the record kind from describe().',
    'REPUTATION_PROFILE': 'Use version covenant-anchored-reputation/0.1.',
    'REPUTATION_KIND': 'Use kind REPORT or STAKE.',
    'REPUTATION_TEXT': 'Use 1 to 80 printable ASCII characters for task_class and 1 to 32 for unit.',
    'REPUTATION_OUTCOME': 'A report outcome is FULFILLED or FAILED; disputes belong in a resolver receipt.',
    'REPUTATION_SELF_EVIDENCE': 'A provider cannot witness its own outcome; use a counterparty or adopted resolver.',
    'REPUTATION_EVIDENCE_LIST': 'Cite at most 32 distinct sorted evidence hashes.',
    'REPUTATION_ENVELOPE': 'Pass {"body": ..., "signature": <128 hex>} exactly.',
    'REPUTATION_SIGNATURE': 'Obtain a fresh signature by the named reporter or holder over the unchanged body.',
    'REPUTATION_COMPLEXITY': 'Flatten the input; nesting and node counts are bounded.',
    'REPUTATION_JSON_TYPE': 'Use JSON objects, arrays, strings, integers, booleans or null.',
    'REPUTATION_SIZE': 'Stay within the documented record, evidence, candidate and link bounds.',
    'REPUTATION_POLICY': 'Policy keys and ranges are listed in describe(); unknown keys are refused.',
    'REPUTATION_CANDIDATES': 'Pass at most 256 distinct provider keys.',
    'REPUTATION_LINKS': 'Pass links as [key, key] pairs of distinct keys, at most 1024.',
    'REPUTATION_HOLDERS': 'Pass adopted holders as a list of at most 64 distinct keys.',
    'REPUTATION_SCOPE': 'The evidence names another task class than the one requested.',
    'REPUTATION_FUTURE_EVIDENCE': 'Evidence dated after the supplied clock is not counted.',
    'REPUTATION_SUBJECT_NOT_PARTY': 'An outcome counts only when its subject id is one of its party keys.',
    'REPUTATION_HOLDER_NOT_ADOPTED': 'Only stake attestations by holders the principal adopted count as stake.',
    'REPUTATION_DUPLICATE': 'Each record id may appear once.',
}


def remediation(code):
    return REMEDIATION.get(code, intro.remediation(code))


def _text(value, maximum=80):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value), 'REPUTATION_TEXT')


def _keyed(value):
    need(type(value) is str, 'KEY'); verification_key(value)


def _validate(body):
    intro._bounded(body, MAX_RECORD_BYTES, 'REPUTATION')
    need(type(body) is dict and type(body.get('kind')) is str and body['kind'] in FIELDS, 'REPUTATION_KIND')
    need(set(body) == set(('version kind ' + FIELDS[body['kind']]).split()), 'REPUTATION_FIELDS')
    need(body['version'] == VERSION, 'REPUTATION_PROFILE')
    key(body['agreement']); key(body['nonce'])
    if body['kind'] == 'REPORT':
        _keyed(body['reporter']); _keyed(body['subject'])
        need(body['reporter'] != body['subject'], 'REPUTATION_SELF_EVIDENCE')
        _text(body['task_class'])
        need(body['outcome'] in ('FULFILLED', 'FAILED'), 'REPUTATION_OUTCOME')
        need(type(body['evidence']) is list and len(body['evidence']) <= 32, 'REPUTATION_EVIDENCE_LIST')
        for value in body['evidence']:
            key(value)
        need(body['evidence'] == sorted(set(body['evidence'])), 'REPUTATION_EVIDENCE_LIST')
        integer(body['issued_at'])
    else:
        _keyed(body['holder']); _keyed(body['party']); integer(body['amount'], True)
        _text(body['unit'], 32); integer(body['held_at'])
    need(len(canonical(body)) <= MAX_RECORD_BYTES, 'REPUTATION_SIZE')
    return body


def record_id(body):
    _validate(body)
    return digest(LABEL, body)


def _prepare(kind, **fields):
    body = {'version': VERSION, 'kind': kind, **deepcopy(fields)}
    return {'id': record_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [body[SIGNER[kind]]], 'signature_created': False, 'execution_authorized': False}


def report(reporter, subject, agreement, task_class, outcome, evidence, issued_at, nonce):
    """Prepare a unilateral counterparty report. It weighs only what the reporter's anchor weighs."""
    return _prepare('REPORT', reporter=reporter, subject=subject, agreement=agreement, task_class=task_class,
                    outcome=outcome, evidence=evidence, issued_at=issued_at, nonce=nonce)


def stake(holder, agreement, party, amount, unit, held_at, nonce):
    """Prepare a holder's attestation that ``amount`` was held from ``party`` for ``agreement``."""
    return _prepare('STAKE', holder=holder, agreement=agreement, party=party, amount=amount, unit=unit,
                    held_at=held_at, nonce=nonce)


def sign_record(body, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body[SIGNER[body['kind']]], 'REPUTATION_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}


def open_record(envelope, kind=None):
    intro._bounded(envelope, MAX_RECORD_BYTES * 2, 'REPUTATION')
    need(type(envelope) is dict and set(envelope) == {'body', 'signature'}, 'REPUTATION_ENVELOPE')
    body = _validate(envelope['body'])
    need(kind is None or body['kind'] == kind, 'REPUTATION_KIND')
    try:
        verify(body[SIGNER[body['kind']]], LABEL, body, envelope['signature'])
    except ValueError:
        raise ValueError('REPUTATION_SIGNATURE') from None
    return {'id': digest(LABEL, body), 'body': deepcopy(body)}


def policy(overrides=None):
    """Defaults merged with validated owner overrides."""
    result = dict(DEFAULT_POLICY)
    if overrides is None:
        return result
    need(type(overrides) is dict and set(overrides) <= set(DEFAULT_POLICY), 'REPUTATION_POLICY')
    for name, value in overrides.items():
        low, high = POLICY_RANGES[name]
        need(type(value) is int and low <= value <= high, 'REPUTATION_POLICY')
        result[name] = value
    return result


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL,
            'kinds': {kind: ('version kind ' + fields).split() for kind, fields in FIELDS.items()},
            'inputs': ['covenant-portable-trust/0.1 OUTCOME receipts', 'REPORT', 'STAKE by adopted holders',
                       'covenant-introductions/0.1', 'covenant-postage/0.1 KEEP decisions'],
            'policy_keys': sorted(DEFAULT_POLICY), 'policy_ranges': {k: list(v) for k, v in POLICY_RANGES.items()},
            'standings': list(STANDINGS), 'order': 'STANDING_THEN_SCORE_THEN_KEY', 'anchoring': 'WITNESS_MUST_BE_REACHED_FROM_PRINCIPAL_TRUSTED_CONTACTS',
            'independence': 'SHARED_TRUST_ROOT_DECLARED_OPERATOR_OR_RESOLVER_IS_ONE_CLUSTER_COUNTED_ONCE',
            'sybil_resistance': 'BOUNDED_BY_ATTACK_EDGES_NOT_RING_SIZE_NOT_A_PROOF',
            'limits': {'evidence': MAX_EVIDENCE, 'candidates': MAX_CANDIDATES, 'links': MAX_LINKS,
                       'record_bytes': MAX_RECORD_BYTES, 'input_bytes': MAX_INPUT_BYTES},
            'remediation': dict(REMEDIATION), 'global_score': False, 'portable_score': False,
            'world_truth_verified': False, 'network_accessed': False, 'execution_authorized': False}


def decay(value, age, half_life):
    """Integer half-life decay with linear interpolation inside each half-life."""
    integer(value); integer(age); integer(half_life, True)
    halves, rest = divmod(age, half_life)
    if halves >= 62:
        return 0
    base = value >> halves
    return base - (base - (base >> 1)) * rest // half_life


def stake_bps(amount, rules):
    integer(amount)
    if amount <= 0:
        return 10000
    return min(rules['stake_cap_bps'], 10000 + rules['stake_step_bps'] * ((amount + 1).bit_length() - 1))


class _Groups:
    """Union-find over keys that the principal knows share an operator, controller or resolver."""
    def __init__(self, links):
        self.parent = {}
        for left, right in links:
            self.union(left, right)

    def find(self, name):
        self.parent.setdefault(name, name)
        while self.parent[name] != name:
            self.parent[name] = self.parent[self.parent[name]]
            name = self.parent[name]
        return name

    def union(self, left, right):
        a, b = self.find(left), self.find(right)
        if a != b:
            self.parent[max(a, b)] = min(a, b)


def _links(links):
    need(type(links) in (list, tuple) and len(links) <= MAX_LINKS, 'REPUTATION_LINKS')
    result = []
    for pair in links:
        need(type(pair) in (list, tuple) and len(pair) == 2 and pair[0] != pair[1], 'REPUTATION_LINKS')
        key(pair[0]); key(pair[1]); result.append((pair[0], pair[1]))
    return result


def _candidates(candidates):
    if candidates is None:
        return None
    need(type(candidates) is list and len(candidates) <= MAX_CANDIDATES and len(set(candidates)) == len(candidates),
         'REPUTATION_CANDIDATES')
    for value in candidates:
        key(value)
    return list(candidates)


def match(edges):
    """Maximum-cardinality matching of witness groups to trust roots, heavier edges first.

    ``edges`` is {witness_group: {root_group: weight}}. A witness group and a root
    are each credited at most once, so one trusted contact's neighbourhood counts
    once however many witnesses it holds. Returns {witness_group: (root, weight)}.
    """
    owner = {}

    def augment(left, seen):
        for right in sorted(edges[left], key=lambda name: (-edges[left][name], name)):
            if right in seen:
                continue
            seen.add(right)  # Recursion depth is bounded by the number of roots.
            if right not in owner or augment(owner[right], seen):
                owner[right] = left
                return True
        return False

    for left in sorted(edges, key=lambda name: (-max(edges[name].values()), name)):
        augment(left, set())
    return {left: (right, edges[left][right]) for right, left in owner.items()}


def _edges_for(witness, value_of, anchors, groups, target):
    anchor = anchors.get(witness)
    if anchor is None:
        return False
    left = groups.find(witness)
    slot = target.setdefault(left, {})
    for root, weight in anchor.get('roots', {anchor['cluster']: anchor['weight']}).items():
        value = value_of(weight)
        if value > 0:
            right = groups.find(root)
            slot[right] = max(slot.get(right, 0), value)
    if not slot:
        del target[left]
        return False
    return True


def score(rows, anchors, now, rules=None, *, links=(), penalties=None, spam_rows=(), candidates=None):
    """Pure scoring core over verified evidence rows; the simulation calls this too.

    ``rows``: {provider, witness, agreement, outcome FULFILLED|FAILED, at, stake, resolver}.
    ``anchors``: introductions.walk() output. ``spam_rows``: {sender, recipient, at}.
    Independence is a maximum matching between witness groups and the trusted
    contacts they are reached through; every side is matched separately.
    """
    rules = policy(rules); integer(now)
    penalties = intro._penalties(penalties)
    need(type(rows) is list and len(rows) <= MAX_EVIDENCE * 4 and type(spam_rows) in (list, tuple)
         and len(spam_rows) <= MAX_EVIDENCE, 'REPUTATION_SIZE')
    groups = _Groups(_links(links))
    grouped = {}; future = {}
    for row in rows:
        if row['at'] > now:
            future[row['provider']] = future.get(row['provider'], 0) + 1
            continue
        grouped.setdefault((row['provider'], row['agreement']), []).append(row)
    per_provider = {}
    for (provider, _agreement), items in sorted(grouped.items()):
        entry = per_provider.setdefault(provider, {'positive': {}, 'negative': {}, 'conflicts': 0,
                                                   'anchored': 0, 'unanchored': 0})
        outcomes = {row['outcome'] for row in items}
        if len(outcomes) > 1:
            entry['conflicts'] += 1
            continue
        side = entry['positive' if outcomes == {'FULFILLED'} else 'negative']
        anchored = False
        for row in items:
            multiplier = stake_bps(row['stake'], rules); age = now - row['at']
            anchored |= _edges_for(row['witness'], lambda weight: decay(weight * multiplier // 10000, age,
                                   rules['half_life']), anchors, groups, side)
        entry['anchored' if anchored else 'unanchored'] += 1
    spam = {}
    for row in spam_rows:
        if row['at'] <= now:
            age = now - row['at']
            _edges_for(row['recipient'], lambda weight: decay(weight, age, rules['half_life']), anchors,
                       groups, spam.setdefault(row['sender'], {}))
    names = set(per_provider) | set(spam) if candidates is None else set(_candidates(candidates))
    results = []
    for provider in sorted(names):
        entry = per_provider.get(provider, {'positive': {}, 'negative': {}, 'conflicts': 0, 'anchored': 0,
                                            'unanchored': 0})
        matched = {side: match(entry[side]) for side in ('positive', 'negative')}
        marks = match(spam.get(provider, {}))
        positive = sum(weight for _, weight in matched['positive'].values())
        negative = sum(weight for _, weight in matched['negative'].values())
        spam_mass = sum(weight for _, weight in marks.values())
        k_pos = len(matched['positive']); k_neg = len(matched['negative']) + len(marks)
        bound = wilson_lb_bps(k_pos, k_pos + k_neg)
        value = positive * bound // 10000 - rules['failure_multiplier'] * negative - rules['spam_multiplier'] * spam_mass
        penalty = penalties.get(provider, 0)
        if value > 0:
            value = value * (10000 - penalty) // 10000
        if value < 0:
            standing = 'NEGATIVE'
        elif k_pos >= rules['min_clusters'] and bound >= rules['min_lower_bound_bps'] and value > 0:
            standing = 'ESTABLISHED'
        elif positive > 0 and value > 0:
            standing = 'EMERGING'
        else:
            standing = 'UNKNOWN'
        credited = [{'side': side, 'witness': left, 'root': right, 'weight': weight}
                    for side, values in (('positive', matched['positive']), ('negative', matched['negative']),
                                         ('spam', marks))
                    for left, (right, weight) in sorted(values.items())][:64]
        results.append({
            'provider': provider, 'score': value, 'standing': standing, 'positive_mass': positive,
            'negative_mass': negative, 'spam_mass': spam_mass, 'independent_positive': k_pos,
            'independent_negative': k_neg, 'lower_bound_bps': bound, 'introducer_penalty_bps': penalty,
            'evidence': {'anchored': entry['anchored'], 'unanchored': entry['unanchored'],
                         'conflicts': entry['conflicts'], 'future_dated': future.get(provider, 0)},
            'credited': credited,
        })
    results.sort(key=rank_key)
    return results


def rank_key(row):
    """Order: standing first (independent corroboration beats volume from one source), then score, then key."""
    return (STANDINGS.index(row['standing']), -row['score'], row['provider'])


def _outcome_rows(outcomes, task_class, excluded):
    rows = []
    for ref, body in sorted(outcomes.items()):
        if body['context'] != task_class:
            continue
        provider = body['subject']['id']
        if provider not in body['parties']:
            excluded.append({'kind': 'OUTCOME', 'id': ref, 'status': 'EXCLUDED', 'reason': 'REPUTATION_SUBJECT_NOT_PARTY'})
            continue
        if body['outcome'] not in ('FULFILLED', 'FAILED'):
            excluded.append({'kind': 'OUTCOME', 'id': ref, 'status': 'DISPUTED_OR_UNKNOWN_NOT_SCORED'})
            continue
        witnesses = [body['resolver']] if body['mode'] == 'RESOLVER' else [p for p in body['parties'] if p != provider]
        for witness in witnesses:
            if witness == provider:
                continue
            rows.append({'provider': provider, 'witness': witness, 'agreement': body['agreement'],
                         'outcome': body['outcome'], 'at': body['issued_at'], 'stake': 0,
                         'resolver': body['mode'] == 'RESOLVER', 'id': ref})
    return rows


def _opened(records, kind, opener, excluded):
    need(type(records) in (list, tuple) and len(records) <= MAX_EVIDENCE, 'REPUTATION_SIZE')
    result = {}
    for envelope in records:
        try:
            opened = opener(envelope, kind)
            need(opened['id'] not in result, 'REPUTATION_DUPLICATE')
            result[opened['id']] = opened['body']
        except ValueError as error:
            excluded.append({'kind': kind, 'status': 'EXCLUDED', 'reason': intro._code(error)})
    return result


def evidence(task_class, now, *, receipts=(), reports=(), stakes=(), spam=(), adopted_resolvers=None,
             adopted_holders=(), verified_receipts=None):
    """Verify signed evidence once; return pure rows for ``score`` and every exclusion."""
    _text(task_class); integer(now)
    need(type(adopted_holders) in (list, tuple) and len(adopted_holders) <= 64
         and len(set(adopted_holders)) == len(adopted_holders), 'REPUTATION_HOLDERS')
    for holder in adopted_holders:
        key(holder)
    excluded = []
    if verified_receipts is None:
        verified_receipts, bad = intro.verify_outcome_receipts(list(receipts), adopted_resolvers)
        excluded.extend(bad)
    rows = _outcome_rows(verified_receipts, task_class, excluded)
    for ref, body in sorted(_opened(reports, 'REPORT', open_record, excluded).items()):
        if body['task_class'] != task_class:
            excluded.append({'kind': 'REPORT', 'id': ref, 'status': 'EXCLUDED', 'reason': 'REPUTATION_SCOPE'})
            continue
        rows.append({'provider': body['subject'], 'witness': body['reporter'], 'agreement': body['agreement'],
                     'outcome': body['outcome'], 'at': body['issued_at'], 'stake': 0, 'resolver': False, 'id': ref})
    held = {}
    for ref, body in sorted(_opened(stakes, 'STAKE', open_record, excluded).items()):
        if body['holder'] not in adopted_holders:
            excluded.append({'kind': 'STAKE', 'id': ref, 'status': 'EXCLUDED', 'reason': 'REPUTATION_HOLDER_NOT_ADOPTED'})
            continue
        if body['held_at'] > now:
            excluded.append({'kind': 'STAKE', 'id': ref, 'status': 'EXCLUDED', 'reason': 'REPUTATION_FUTURE_EVIDENCE'})
            continue
        held[body['agreement']] = max(held.get(body['agreement'], 0), body['amount'])
    for row in rows:
        row['stake'] = held.get(row['agreement'], 0)
    spam_rows = []
    if spam:
        from . import postage
        need(type(spam) in (list, tuple) and len(spam) <= MAX_EVIDENCE, 'REPUTATION_SIZE')
        for item in spam:
            try:
                marked = postage.spam_mark(item)
                spam_rows.append({'sender': marked['sender'], 'recipient': marked['recipient'], 'at': marked['at']})
            except ValueError as error:
                excluded.append({'kind': 'SPAM', 'status': 'EXCLUDED', 'reason': intro._code(error)})
    return {'rows': rows, 'spam_rows': spam_rows, 'excluded': excluded}


def rank(trusted_contacts, task_class, now, *, receipts=(), reports=(), introductions=(), withdrawals=(),
         stakes=(), spam=(), adopted_resolvers=None, adopted_holders=(), links=(), candidates=None, rules=None,
         principal=None):
    """Rank providers for one task class from the principal's trusted contacts.

    Two passes keep accountability non-circular: a first walk anchors failure
    witnesses, failures penalize their subjects' introducers, then the final
    walk applies those penalties before scoring.
    """
    rules = policy(rules)
    seeds = intro._seeds(trusted_contacts)
    need(all(type(v) in (list, tuple) and len(v) <= MAX_EVIDENCE
             for v in (receipts, reports, introductions, withdrawals, stakes, spam)), 'REPUTATION_SIZE')
    intro._bounded([list(v) for v in (receipts, reports, introductions, withdrawals, stakes, spam)],
                   MAX_INPUT_BYTES, 'REPUTATION')
    verified, bad = intro.verify_outcome_receipts(list(receipts), adopted_resolvers)
    found = evidence(task_class, now, reports=reports, stakes=stakes, spam=spam, adopted_resolvers=adopted_resolvers,
                     adopted_holders=adopted_holders, verified_receipts=verified)
    found['excluded'][:0] = bad
    # Anchoring uses introductions of every class; class competence comes from class receipts.
    walked = intro.edges(list(introductions), [], None, now, withdrawals=list(withdrawals),
                         verified_receipts=verified)
    every = walked['active'] + [row for row in walked['inactive'] if row['issued_at'] <= now]
    first = intro.walk(seeds, walked['active'], rules['max_depth'], rules['decay_bps'], principal=principal)
    failures = []
    for row in found['rows']:
        anchor = first.get(row['witness'])
        if row['outcome'] == 'FAILED' and anchor is not None and row['at'] <= now:
            failures.append({'subject': row['provider'], 'at': row['at'], 'cluster': anchor['cluster'],
                             'weight': decay(anchor['weight'], now - row['at'], rules['half_life'])})
    for row in found['spam_rows']:
        anchor = first.get(row['recipient'])
        if anchor is not None and row['at'] <= now:
            failures.append({'subject': row['sender'], 'at': row['at'], 'cluster': anchor['cluster'],
                             'weight': decay(anchor['weight'], now - row['at'], rules['half_life'])})
    penalties, liable = intro.accountability(every, failures, rules['penalty_step_bps'])
    anchors = intro.walk(seeds, walked['active'], rules['max_depth'], rules['decay_bps'], penalties, principal)
    ranking = score(found['rows'], anchors, now, rules, links=links, penalties=penalties,
                    spam_rows=found['spam_rows'], candidates=candidates)
    return {'version': VERSION, 'task_class': task_class, 'as_of': now, 'ranking': ranking,
            'anchors': len(anchors), 'introducers_at_risk': liable,
            'introductions': {'active': len(walked['active']), 'inactive': len(walked['inactive']),
                              'excluded': walked['excluded']},
            'excluded': found['excluded'], 'rules': rules, 'clock': 'CALLER_ASSERTION',
            'basis': 'PRINCIPAL_TRUSTED_CONTACTS_SIGNED_EVIDENCE_AND_EXACT_TASK_CLASS_ONLY',
            'sybil_resistance': 'BOUNDED_BY_ATTACK_EDGES_NOT_RING_SIZE_NOT_A_PROOF',
            'global_score': False, 'portable_score': False, 'world_truth_verified': False,
            'payment_verified': False, 'network_accessed': False, 'execution_authorized': False}
