"""Illustrative fees for surfaces around the core verbs.

Core settlement stays on the scale-economies price. These quotes are for value
that goes to a third party or a premium service. Every figure is illustrative.
None of them move chain balances: economics.py charges the fee resource, and an
x402 or AP2 adapter registers on payment_rails.RailRegistry. Founder share, when
a quote is adopted, is the FOUNDER beneficiary row inside that charge's 10,000 bps.
"""
from .crypto import integer, need
from .token_preference import LAUNCH_DISCOUNT_BPS, fee_after

SURFACES = (
    'recourse', 'arbitration_filing', 'arbitration_panel', 'appeal_bond',
    'template_royalty', 'template_protocol', 'score_query', 'oracle_query',
    'channel_open', 'channel_settle', 'priority_lane', 'storage', 'name_renewal',
    'hosted_rpc', 'compliance_export', 'bridge_anchor', 'insurance_premium',
    'governance_deposit',
)
# Illustrative. A genesis can adopt lower numbers. Caps only fall with the fee schedule.
ILLUSTRATIVE = {
    'recourse_bps': 50,
    'arbitration_filing': 100,
    'arbitration_panel_bps': 200,
    'appeal_bond': 1000,
    'template_royalty_bps': 250,
    'template_protocol_bps': 50,
    'score_query': 10,
    'oracle_query': 25,
    'channel_open': 20,
    'channel_settle': 10,
    'priority_lane': 15,
    'storage_per_kib': 2,
    'name_renewal': 100,
    'hosted_rpc': 50,
    'compliance_export': 200,
    'bridge_anchor': 30,
    'insurance_premium_bps': 100,
    'governance_deposit': 500,
}


def _discount(amount, pay_in_token, qualified_volume):
    from .token_preference import discount_bps
    if not pay_in_token:
        return amount, 0
    bps = discount_bps(qualified_volume)
    return fee_after(amount, bps), bps


def quote(surface, base, *, pay_in_token=False, qualified_volume=0, self_query=False):
    """One integer quote. A score query about the caller's own agent is free."""
    need(surface in SURFACES, 'FEE_SURFACE')
    integer(base)
    integer(qualified_volume)
    if surface == 'score_query' and self_query:
        amount, bps = 0, 0
    else:
        amount, bps = _discount(base, pay_in_token, qualified_volume)
    return {'surface': surface, 'amount': amount, 'undiscounted': 0 if self_query and surface == 'score_query' else base,
            'token_discount_bps': bps, 'pay_in_token': bool(pay_in_token), 'illustrative': True,
            'founder_route': 'ECONOMICS_BENEFICIARY_ROW', 'moves_balances': False,
            'rail': 'REGISTRY' if surface == 'recourse' else 'ECONOMICS_FEE'}


def recourse(volume, pay_in_token=False, qualified_volume=0):
    """Premium on x402/AP2 volume that sits in escrow. Priced like an insurance premium, settled by the rail."""
    integer(volume)
    base = volume * ILLUSTRATIVE['recourse_bps'] // 10000
    row = quote('recourse', base, pay_in_token=pay_in_token, qualified_volume=qualified_volume)
    row['volume'] = volume
    row['bps'] = ILLUSTRATIVE['recourse_bps']
    return row


def arbitration(claim, pay_in_token=False, qualified_volume=0):
    integer(claim)
    filing = quote('arbitration_filing', ILLUSTRATIVE['arbitration_filing'], pay_in_token=pay_in_token, qualified_volume=qualified_volume)
    panel_base = claim * ILLUSTRATIVE['arbitration_panel_bps'] // 10000
    panel = quote('arbitration_panel', panel_base, pay_in_token=pay_in_token, qualified_volume=qualified_volume)
    appeal = quote('appeal_bond', ILLUSTRATIVE['appeal_bond'], pay_in_token=pay_in_token, qualified_volume=qualified_volume)
    return {'filing': filing, 'panel': panel, 'appeal_bond': appeal,
            'total': filing['amount'] + panel['amount'] + appeal['amount'], 'refundable_appeal': True}


def template_use(royalty_base, pay_in_token=False, qualified_volume=0):
    integer(royalty_base)
    royalty = royalty_base * ILLUSTRATIVE['template_royalty_bps'] // 10000
    protocol = royalty_base * ILLUSTRATIVE['template_protocol_bps'] // 10000
    creator = quote('template_royalty', royalty, pay_in_token=pay_in_token, qualified_volume=qualified_volume)
    cut = quote('template_protocol', protocol, pay_in_token=pay_in_token, qualified_volume=qualified_volume)
    return {'creator': creator, 'protocol': cut, 'total': creator['amount'] + cut['amount']}


def score_query(pay_in_token=False, qualified_volume=0, self_query=False):
    return quote('score_query', ILLUSTRATIVE['score_query'], pay_in_token=pay_in_token,
                 qualified_volume=qualified_volume, self_query=self_query)


def catalog(pay_in_token=False, qualified_volume=0):
    """One pass over the fixed surfaces, using each illustrative parameter as the base."""
    rows = []
    rows.append(recourse(10_000, pay_in_token, qualified_volume))
    arb = arbitration(10_000, pay_in_token, qualified_volume)
    rows.extend((arb['filing'], arb['panel'], arb['appeal_bond']))
    use = template_use(10_000, pay_in_token, qualified_volume)
    rows.extend((use['creator'], use['protocol']))
    rows.append(score_query(pay_in_token, qualified_volume, False))
    for surface, key in (
        ('oracle_query', 'oracle_query'), ('channel_open', 'channel_open'), ('channel_settle', 'channel_settle'),
        ('priority_lane', 'priority_lane'), ('storage', 'storage_per_kib'), ('name_renewal', 'name_renewal'),
        ('hosted_rpc', 'hosted_rpc'), ('compliance_export', 'compliance_export'), ('bridge_anchor', 'bridge_anchor'),
        ('governance_deposit', 'governance_deposit'),
    ):
        rows.append(quote(surface, ILLUSTRATIVE[key], pay_in_token=pay_in_token, qualified_volume=qualified_volume))
    premium = 10_000 * ILLUSTRATIVE['insurance_premium_bps'] // 10000
    rows.append(quote('insurance_premium', premium, pay_in_token=pay_in_token, qualified_volume=qualified_volume))
    return rows


def book(meter, height, row):
    """Append a quote to the revenue ledger. Still no balance movement."""
    from .revenue_ledger import record
    amount = row['amount']
    return record(meter, height, 'protocol_fee', row['surface'], amount, 0, 0, 0, amount, 0, 0)
