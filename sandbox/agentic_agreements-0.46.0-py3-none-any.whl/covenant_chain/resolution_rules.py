"""Named covenant-native/0.15 rules from the agent-to-agent adversarial suite.

Each name is a consensus rule on that profile only. Profiles 0.1–0.14 keep
their original field sets and results. This module does not open a second
court: a panel is a threshold of keys both parties already signed into the
terms, matching the mutual-choice modes of the panel adapter (`named`,
`tahkim`, `zabla`, `drawn`, `standing`).
"""
import re

from .profile import MIGRATION_VERSION
from .crypto import digest, exact, integer, key, need, verify

RULES = (
    'evidence_preimage',
    'mutual_arbiter',
    'indeterminate_release',
    'release_custody',
    'grant_lifetime',
)
PANEL_VERSION = 'covenant-panel/1'
MODES = {'named', 'tahkim', 'zabla', 'drawn', 'standing'}
PREIMAGE = 'COVENANT-EVIDENCE-PREIMAGE-0.15'
AVAILABLE = 'COVENANT-EVIDENCE-AVAILABLE-0.15'
_GPS = re.compile(r'gps\s*-?\d', re.I)
_ORACLE = re.compile(r'oracle says', re.I)


def _resolution(state):
    """The five rules share the 0.15 string, and turn on only for an armed chain.

    A continuity policy that names ``veto-guardian`` is the arming mark from
    PR #37. Other 0.15 chains, including economics-shaped genesis and the
    panel-arbitration fixtures, keep their own field sets.
    """
    from .app import RESOLUTION_VERSION
    if state.get('protocol') not in {RESOLUTION_VERSION,MIGRATION_VERSION}:
        return False
    policies = state.get('continuity_policies') or {}
    values = policies.values() if hasattr(policies, 'values') else ()
    for row in values:
        body = row.get('body') if type(row) is dict else None
        guardians = body.get('guardians') if type(body) is dict else None
        if type(guardians) is dict and 'veto-guardian' in guardians:
            return True
    return False


def _gps(text):
    return type(text) is str and (_GPS.search(text) is not None or _ORACLE.search(text) is not None)


def accept_show(state, payload):
    """`evidence_preimage`. A bare hash is not evidence. A GPS sentence is not either."""
    if not _resolution(state):
        return
    has_preimage = 'preimage' in payload
    has_availability = 'commitment' in payload or 'availability' in payload
    need(has_preimage != has_availability, 'EVIDENCE_PREIMAGE')
    need(not _gps(payload.get('description')), 'EVIDENCE_GPS_UNSUPPORTED')
    if has_preimage:
        exact(payload, 'agreement content_hash description preimage')
        preimage = payload['preimage']
        need(type(preimage) is str and 1 <= len(preimage) <= 4096, 'EVIDENCE_PREIMAGE')
        need(not _gps(preimage), 'EVIDENCE_GPS_UNSUPPORTED')
        need(payload['content_hash'] == digest(PREIMAGE, preimage), 'EVIDENCE_PREIMAGE')
        return
    exact(payload, 'agreement content_hash description commitment availability')
    need(payload['commitment'] == payload['content_hash'], 'EVIDENCE_PREIMAGE')
    key(payload['commitment'])
    availability = payload['availability']
    exact(availability, 'attestors')
    attestors = availability['attestors']
    need(type(attestors) is list and 2 <= len(attestors) <= 8, 'EVIDENCE_AVAILABILITY')
    signers = []
    for row in attestors:
        exact(row, 'signer signature')
        key(row['signer'])
        signers.append(row['signer'])
    need(signers == sorted(set(signers)), 'EVIDENCE_AVAILABILITY')
    agreement = state['agreements'][payload['agreement']]
    terms = agreement['terms']
    body = {'chain': state['chain'], 'agreement': payload['agreement'], 'commitment': payload['commitment']}
    for row in attestors:
        verify(row['signer'], AVAILABLE, body, row['signature'])
    need({terms['agent'], terms['counterparty']} <= set(signers), 'EVIDENCE_AVAILABILITY')


def classify(terms):
    """`mutual_arbiter`. Omitted choice is a panel. One key pays only if both parties named it."""
    if 'panel' in terms:
        panel = terms['panel']
        need(type(panel) is dict, 'PANEL_REQUIRED')
        mode = panel.get('mode')
        threshold = panel.get('threshold')
        selection = panel.get('selection') if type(panel.get('selection')) is dict else {}
        arbitrators = selection.get('arbitrators') if type(selection.get('arbitrators')) is list else []
        version = panel.get('v')
    elif 'arbiter' in terms:
        body = terms['arbiter']
        exact(body, 'v mode threshold arbitrators')
        version = body['v']
        mode = body['mode']
        threshold = body['threshold']
        arbitrators = body['arbitrators']
    else:
        return {'kind': 'panel', 'threshold': 2, 'seats': []}
    need(version == PANEL_VERSION, 'ARBITER_VERSION')
    need(mode in MODES, 'ARBITER_MODE')
    integer(threshold, True)
    need(type(arbitrators) is list and arbitrators == sorted(set(arbitrators)) and len(arbitrators) <= 16, 'ARBITER_SEATS')
    for who in arbitrators:
        key(who)
    parties = {terms['agent'], terms['counterparty'], terms['principal']}
    if mode in {'named', 'tahkim'} and threshold == 1 and arbitrators == [terms['resolver']]:
        need(terms['resolver'] not in parties, 'ARBITER_SEATS')
        return {'kind': 'sole', 'threshold': 1, 'seats': list(arbitrators)}
    need(threshold >= 2 and len(arbitrators) >= threshold, 'PANEL_REQUIRED')
    for who in arbitrators:
        need(who not in parties, 'PANEL_CONFLICT')
    return {'kind': 'panel', 'threshold': threshold, 'seats': list(arbitrators)}


def accept_terms(state, terms):
    if not _resolution(state):
        return
    if 'indeterminate_outcome' in terms:
        need(terms['indeterminate_outcome'] in {'REFUND', 'PAY'}, 'DEADLINE_OUTCOME')
    classify(terms)


def decision_gate(state, agreement, terms, actor, payload):
    """Return `final` or `wait`. A default panel rejects a single named resolver."""
    if not _resolution(state):
        return 'final'
    choice = classify(terms)
    if choice['kind'] == 'sole':
        return 'final'
    if not choice['seats']:
        raise ValueError('PANEL_REQUIRED')
    need(agreement['state'] in {'BOUND', 'INDETERMINATE'} and not agreement['appeal_final'], 'RESOLVER_STATE')
    need(actor in choice['seats'], 'PANEL_SEAT')
    votes = dict(agreement.get('panel_votes') or {})
    need(actor not in votes, 'PANEL_VOTE')
    votes[actor] = payload['result']
    agreement['panel_votes'] = votes
    matching = sorted(who for who, value in votes.items() if value == payload['result'])
    if len(matching) < choice['threshold']:
        return 'wait'
    agreement['panel_tally'] = {'result': payload['result'], 'count': len(matching), 'seats': matching}
    return 'final'


def require_panel(state, agreement, terms):
    """Payment needs the mutual sole arbiter, or a met panel threshold."""
    if not _resolution(state):
        return
    choice = classify(terms)
    if choice['kind'] == 'sole':
        return
    tally = agreement.get('panel_tally')
    need(type(tally) is dict and tally.get('count', 0) >= choice['threshold']
         and agreement.get('decision') and agreement['decision']['result'] == tally.get('result'), 'PANEL_REQUIRED')


def schedule_indeterminate(state, agreement, terms, height):
    """`indeterminate_release`. The deadline outcome is REFUND unless the terms say PAY."""
    if not _resolution(state):
        return
    outcome = terms['indeterminate_outcome'] if 'indeterminate_outcome' in terms else 'REFUND'
    need(outcome in {'REFUND', 'PAY'}, 'DEADLINE_OUTCOME')
    agreement['deadline_outcome'] = outcome
    agreement['release_height'] = max(terms['deadline'], height + terms['challenge_blocks'])


def custody_for(state, height):
    return digest('COVENANT-CUSTODY-0.15', {
        'chain': state['chain'], 'fork': state['fork_pin'], 'height': height, 'events': len(state['events']),
    })


def release_fields(state):
    if _resolution(state):
        return 'agreement custody nonce'
    return 'agreement'


def bind_custody(state, previous, payload, height, tid):
    """`release_custody`. The signature covers this fork's custody id and one nonce."""
    if not _resolution(state):
        return
    key(payload['custody'])
    integer(payload['nonce'], True)
    need(payload['custody'] == custody_for(previous, height), 'CUSTODY_PIN')
    need(str(payload['nonce']) not in state['release_nonces'], 'RELEASE_NONCE')
    state['release_nonces'][str(payload['nonce'])] = tid


def give_fields(state):
    base = 'parent holder resource limit expiry effects profiles delegate'
    if _resolution(state):
        return base + ' counterparty task_hash'
    return base


def stamp_grant(state, grant, payload, parent):
    """`grant_lifetime`. The limit is a lifetime remainder pinned to one counterparty and task."""
    if not _resolution(state):
        return
    key(payload['counterparty'])
    key(payload['task_hash'])
    if parent is not None:
        need(payload['counterparty'] == parent.get('counterparty') and payload['task_hash'] == parent.get('task_hash'), 'GRANT_COUNTERPARTY')
    grant['lifetime'] = payload['limit']
    grant['spent'] = 0


def bind_grant(state, grant, terms):
    if not _resolution(state) or terms['mandate'] is None:
        return
    need('lifetime' in grant and 'spent' in grant, 'GRANT_LIFETIME')
    need(terms['counterparty'] == grant['counterparty'], 'GRANT_COUNTERPARTY')
    need(terms['terms_hash'] == grant['task_hash'], 'GRANT_TASK')
    need(grant['spent'] + terms['quantity'] <= grant['lifetime'], 'GRANT_LIFETIME')
    grant['spent'] += terms['quantity']
