"""Adopted portable capability checks for the represented-agreement successor.

Authority-state pins and the clock come from the recipient, outside the incoming
package. A hash cannot establish the freshness or completeness of revocations.
The caller must adopt their source; these checks never execute an agreement.
"""
from copy import deepcopy
from . import access_mechanisms as access
from .crypto import digest, integer, need, sign, public_key
from covenant_language import represented_agreements as records

STATE_VERSION = 'covenant-represented-authority-state/0.1'
OPERATION = 'SIGN_REPRESENTED_LEGAL_MODULE'


def _scope(package, party):
    records._terms(package)
    need(type(party) is str and party in package['module']['parties'], 'REPRESENTATION_PARTY')
    return {'context': package['context'],
            'target': {'kind': 'represented-agreement', 'id': records.terms_id(package)},
            'operation': OPERATION, 'capability': 'assent:' + party}


def grant(package, party, delegate, not_before, expires, nonce, delegable=False,
          issuer=None, parent=None):
    scope = _scope(package, party)
    return access.grant(scope['context'], scope['target'], scope['operation'],
        package['module']['parties'][party] if issuer is None else issuer,
        delegate, [scope['capability']], not_before, expires, nonce,
        delegable=delegable, parent=parent)


def authority_state(package, as_of, expires, revoked=None, successors=None):
    integer(as_of); integer(expires, True)
    need(as_of < expires, 'REPRESENTATION_STATE_INTERVAL')
    revoked = [] if revoked is None else deepcopy(revoked)
    successors = {} if successors is None else deepcopy(successors)
    need(type(revoked) is list and len(revoked) <= 4096 and
         all(type(x) is str for x in revoked) and revoked == sorted(set(revoked)),
         'REPRESENTATION_STATE_REVOKED')
    need(type(successors) is dict and len(successors) <= 4096, 'REPRESENTATION_STATE_SUCCESSORS')
    from covenant_language.legal_composition import hashref
    for item in revoked:
        hashref(item)
    for old, new in successors.items():
        hashref(old); hashref(new)
    state = {'version': STATE_VERSION, 'agreement': records.terms_id(package),
             'as_of': as_of, 'expires': expires, 'revoked': revoked, 'successors': successors}
    return {'state': state, 'id': state_id(state),
            'adoption': 'RECIPIENT_MUST_AUTHENTICATE_SOURCE_AND_FRESHNESS_OUTSIDE_PACKAGE',
            'execution_authorized': False}


def state_id(state):
    need(type(state) is dict and set(state) == {
        'version', 'agreement', 'as_of', 'expires', 'revoked', 'successors'}, 'REPRESENTATION_STATE_FIELDS')
    need(state['version'] == STATE_VERSION, 'REPRESENTATION_STATE_VERSION')
    # Validate all state members independently of a package.
    from covenant_language.legal_composition import hashref
    hashref(state['agreement']); integer(state['as_of']); integer(state['expires'], True)
    need(state['as_of'] < state['expires'], 'REPRESENTATION_STATE_INTERVAL')
    need(type(state['revoked']) is list and len(state['revoked']) <= 4096 and
         all(type(x) is str for x in state['revoked']) and state['revoked'] == sorted(set(state['revoked'])),
         'REPRESENTATION_STATE_REVOKED')
    need(type(state['successors']) is dict and len(state['successors']) <= 4096,
         'REPRESENTATION_STATE_SUCCESSORS')
    for item in state['revoked']:
        hashref(item)
    for old, new in state['successors'].items():
        hashref(old); hashref(new)
    return digest('COVENANT-REPRESENTED-AUTHORITY-STATE-0.1', state)


def authorize(package, party, actor, chain, state, expected_state, now, maximum_age=300):
    from covenant_language.legal_composition import hashref
    hashref(expected_state); integer(now); integer(maximum_age, True)
    need(maximum_age <= 86400, 'REPRESENTATION_STATE_AGE')
    need(state_id(state) == expected_state, 'REPRESENTATION_EXPECTED_STATE')
    need(state['agreement'] == records.terms_id(package), 'REPRESENTATION_STATE_SCOPE')
    need(state['as_of'] <= now < state['expires'] and now - state['as_of'] <= maximum_age,
         'REPRESENTATION_STATE_STALE')
    scope = _scope(package, party)
    principal = package['module']['parties'][party]
    # Payload validation refuses a supplied chain on a direct signature.
    records.signing_payload(package, party, actor, chain)
    if actor == principal:
        return {'party': party, 'principal': principal, 'actor': actor, 'mode': 'DIRECT'}
    checked = access.verify_chain(chain, subject=actor, trusted_issuers=[principal], now=now,
        revoked=state['revoked'], successors=state['successors'], **scope)
    return {'party': party, 'principal': principal, 'actor': deepcopy(actor),
            'mode': 'DELEGATED', 'root': checked['root'], 'leaf': checked['leaf']}


def assess(package, expected_id, state, expected_state, now, maximum_age=300):
    result = records.review(package, expected_id)
    need(not result['missing_parties'], 'REPRESENTATION_MISSING_ASSENT')
    need(result['closure']['status'] == 'STRUCTURALLY_RESOLVED', 'REPRESENTATION_INCOMPLETE_CLOSURE')
    checked = [authorize(package, row['party'], row['actor'], row['chain'], state,
                         expected_state, now, maximum_age) for row in package['approvals']]
    return {**result, 'status': 'ASSENT_VALID_UNDER_ADOPTED_AUTHORITY_STATE',
        'actors': checked, 'authority_state': expected_state, 'assessed_at': now,
        'authority_current': 'ONLY_UNDER_RECIPIENT_ADOPTED_STATE_AND_CLOCK',
        'signature_creation_time': 'NOT_PROVED_BY_SIGNATURE',
        'existing_obligations': 'REVOCATION_OR_EXPIRY_DOES_NOT_AUTOMATICALLY_DISCHARGE',
        'assumptions': ['STATE_SOURCE_AUTHENTICATED_BY_RECIPIENT',
                        'REVOCATIONS_COMPLETE_AS_OF_SNAPSHOT', 'RECIPIENT_CLOCK_CORRECT',
                        'IDENTITY_KEY_BINDINGS_ADOPTED_OUTSIDE_THIS_PACKAGE'],
        'legal_effect': 'NOT_DETERMINED', 'execution_authorized': False}


def owner_sign(package, party, private_key, expected_id, chain=None, *, state=None,
               expected_state=None, now=None, maximum_age=300):
    """Owner SDK only; no signing key or signing operation is exposed through MCP."""
    reviewed = records.review(package, expected_id)
    need(reviewed['closure']['status'] == 'STRUCTURALLY_RESOLVED',
         'REPRESENTATION_INCOMPLETE_CLOSURE')
    actor = public_key(private_key)
    chain = [] if chain is None else chain
    payload = records.signing_payload(package, party, actor, chain)
    if chain:
        need(state is not None and expected_state is not None and now is not None,
             'REPRESENTATION_OWNER_AUTHORITY_STATE_REQUIRED')
        authorize(package, party, actor, chain, state, expected_state, now, maximum_age)
    approval = {'party': party, 'actor': actor, 'chain': deepcopy(chain),
                'signature': sign(private_key, payload['label'], payload['body'])}
    return records.add_approval(package, approval, expected_id)
