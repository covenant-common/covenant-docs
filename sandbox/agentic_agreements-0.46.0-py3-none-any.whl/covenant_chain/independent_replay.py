"""Bounded, keyless invocation of the vendored second-language native replayer.

Python encodes the request and contains the process. It does not provide genesis,
application transitions, state roots, committee decisions or proof results.
"""
from pathlib import Path
import hashlib
import json
import os
import selectors
import shutil
import signal
import subprocess
import time

PROFILE = 'covenant-independent-native-replay/0.1'
ASSETS = Path(__file__).resolve().parent/'data/independent_native016'
MAX_INPUT = 4_000_000
MAX_OUTPUT = 6_000_000
TIMEOUT = 20


def _need(condition, code):
    if not condition:
        raise ValueError(code)


def _object(value):
    return type(value) is dict


def _exact(value, required, optional=()):
    _need(_object(value) and set(required) <= set(value) <= set(required) | set(optional), 'INDEPENDENT_FIELDS')


def _wire(value):
    # Bound the decoded tree before allocating its serialized representation.
    # This is admission only; the JS implementation still parses/validates it.
    stack = [(value, 0, False)]
    estimated = 0
    while stack:
        item, depth, map_key = stack.pop()
        _need(depth <= 40, 'INDEPENDENT_INPUT_DEPTH')
        if item is None:
            estimated += 4
        elif type(item) is bool:
            estimated += 4 if item else 5
        elif type(item) is int:
            _need(abs(item) <= 2**53-1, 'INDEPENDENT_INPUT_INTEGER')
            estimated += len(str(item))
        elif type(item) is str:
            _need(len(item) <= (256 if map_key else 100000) and all(32 <= ord(c) <= 126 for c in item), 'INDEPENDENT_INPUT_STRING')
            estimated += len(item)+2+item.count('"')+item.count('\\')
        elif type(item) is list:
            _need(len(item) <= 20000, 'INDEPENDENT_INPUT_ARRAY')
            estimated += 2+max(0, len(item)-1)
            stack.extend((v, depth+1, False) for v in item)
        elif type(item) is dict:
            _need(len(item) <= 20000 and all(type(k) is str for k in item), 'INDEPENDENT_INPUT_MAP')
            estimated += 2+max(0, len(item)-1)+len(item)
            for k, v in item.items():
                stack.append((k, depth+1, True)); stack.append((v, depth+1, False))
        else:
            raise ValueError('INDEPENDENT_INPUT')
        _need(estimated <= MAX_INPUT, 'INDEPENDENT_INPUT_LIMIT')
    try:
        raw = json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('ascii')
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValueError('INDEPENDENT_INPUT') from exc
    _need(len(raw) <= MAX_INPUT, 'INDEPENDENT_INPUT_LIMIT')
    return raw


def _bundle():
    _need(ASSETS.is_dir() and not ASSETS.is_symlink(), 'INDEPENDENT_ASSETS')
    manifest_path = ASSETS/'manifest.json'
    _need(manifest_path.is_file() and not manifest_path.is_symlink() and manifest_path.stat().st_size <= 65536, 'INDEPENDENT_ASSETS')
    raw = manifest_path.read_bytes()
    try:
        manifest = json.loads(raw)
    except (ValueError, UnicodeError) as exc:
        raise ValueError('INDEPENDENT_ASSETS') from exc
    _exact(manifest, ('profile', 'files'))
    _need(manifest['profile'] == 'covenant-independent-native-bundle/0.1' and
          _object(manifest['files']) and 2 <= len(manifest['files']) <= 32, 'INDEPENDENT_ASSETS')
    for name, expected in manifest['files'].items():
        _need(type(name) is str and (name.endswith('.mjs') or name in ('coverage.json', 'demo-replay.json')) and not name.startswith('/') and
              all(p not in ('..', '.', '') for p in name.split('/')), 'INDEPENDENT_ASSETS')
        p = ASSETS/name
        _need(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ASSETS.resolve()) and
              p.stat().st_size <= 1_000_000 and hashlib.sha256(p.read_bytes()).hexdigest() == expected, 'INDEPENDENT_ASSETS')
    _need('native016/replay.mjs' in manifest['files'], 'INDEPENDENT_ASSETS')
    return hashlib.sha256(raw).hexdigest()


def _stop(process):
    if process.poll() is not None:
        return
    try:
        if os.name == 'posix':
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    except ProcessLookupError:
        pass
    process.wait(timeout=5)


def _run(command, raw, *, timeout=TIMEOUT, output_limit=MAX_OUTPUT):
    # No inherited preload modules, proxy credentials, signing keys or HOME.
    env = {'PATH': str(Path(command[0]).parent), 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC'}
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               env=env, cwd=ASSETS, start_new_session=True)
    selector = selectors.DefaultSelector()
    output = {'stdout': bytearray(), 'stderr': bytearray()}
    sent = 0
    try:
        for pipe, name in ((process.stdin, 'stdin'), (process.stdout, 'stdout'), (process.stderr, 'stderr')):
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_WRITE if name == 'stdin' else selectors.EVENT_READ, name)
        deadline = time.monotonic()+timeout
        while selector.get_map():
            _need(time.monotonic() < deadline, 'INDEPENDENT_TIMEOUT')
            for item, _events in selector.select(min(.1, max(0, deadline-time.monotonic()))):
                name = item.data
                if name == 'stdin':
                    if sent == len(raw):
                        selector.unregister(item.fileobj); item.fileobj.close(); continue
                    try:
                        sent += os.write(item.fd, raw[sent:sent+65536])
                    except BlockingIOError:
                        continue
                    except BrokenPipeError:
                        selector.unregister(item.fileobj); item.fileobj.close()
                else:
                    try:
                        chunk = os.read(item.fd, 65536)
                    except BlockingIOError:
                        continue
                    if not chunk:
                        selector.unregister(item.fileobj); item.fileobj.close(); continue
                    output[name].extend(chunk)
                    _need(len(output[name]) <= (output_limit if name == 'stdout' else 65536), 'INDEPENDENT_OUTPUT_LIMIT')
        process.wait(timeout=max(.01, deadline-time.monotonic()))
        return process.returncode, bytes(output['stdout']), bytes(output['stderr'])
    except (BaseException, subprocess.TimeoutExpired):
        _stop(process)
        raise
    finally:
        selector.close()
        for pipe in (process.stdin, process.stdout, process.stderr):
            if not pipe.closed:
                pipe.close()


def _invoke(request, expected_verifier=None):
    bundle_id = _bundle()
    if expected_verifier is not None:
        _need(type(expected_verifier) is str and expected_verifier == bundle_id, 'INDEPENDENT_VERIFIER_PIN')
    raw = _wire(request)
    node = shutil.which('node')
    _need(node is not None, 'INDEPENDENT_NODE_REQUIRED')
    # Permission mode is a guard for trusted code, not a malicious-code sandbox.
    # Unsupported older runtimes refuse. No permissive retry or Python fallback.
    command = [str(Path(node).resolve()), '--permission', '--allow-fs-read='+str(ASSETS),
               '--max-old-space-size=192', str(ASSETS/'native016/replay.mjs')]
    code, stdout, stderr = _run(command, raw)
    try:
        decoded = json.loads(stdout if code == 0 else stderr)
    except (ValueError, UnicodeError) as exc:
        raise ValueError('INDEPENDENT_RUNTIME_UNAVAILABLE') from exc
    _need(_object(decoded), 'INDEPENDENT_RESPONSE')
    if code != 0 or decoded.get('ok') is not True:
        error = decoded.get('error')
        _need(type(error) is str and len(error) <= 100 and all(c.isupper() or c.isdigit() or c in '_:' for c in error), 'INDEPENDENT_RESPONSE')
        raise ValueError('INDEPENDENT_REFUSED:'+error)
    _need(decoded.get('profile') == PROFILE or decoded.get('coverage', {}).get('profile') == PROFILE, 'INDEPENDENT_RESPONSE')
    return decoded, bundle_id


def describe():
    bundle_id = _bundle()
    result = json.loads((ASSETS/'coverage.json').read_bytes())
    return {**result, 'version': PROFILE, 'verifier': bundle_id, 'guide': 'docs/INDEPENDENT_NATIVE_016.html',
            'input_limit': MAX_INPUT, 'timeout_seconds': TIMEOUT, 'output_limit': MAX_OUTPUT,
            'keys': False, 'network': False, 'writes': False, 'execution_authorized': False,
            'runtime_available': shutil.which('node') is not None,
            'trust': 'Owner trusts installed distribution/runtime and independently retains chain, verifier, height/head pins.',
            'receipt': 'Unsigned local computation; recipients must recompute or separately adopt its issuer.'}


def demo():
    info = describe()
    packet = json.loads((ASSETS/'demo-replay.json').read_bytes())
    return {'synthetic': True, 'goal': 'A person buys a report, obtains an agreed decision and retains an unknown external execution receipt.',
            'parameters': {k:v for k,v in packet.items() if k not in ('action', 'include_state')},
            'expected_verifier': info['verifier'], 'guide': info['guide'], 'execution_authorized': False}


def inspect_genesis(genesis, expected_verifier):
    result, bundle_id = _invoke({'action': 'genesis', 'genesis': genesis}, expected_verifier)
    return {'status': 'GENESIS_CHECKED_WITHIN_DECLARED_COVERAGE', 'chain': result['chain'],
            'state_root': result['state_root'], 'coverage': result['coverage'],
            'verifier': bundle_id, 'history_replayed': False, 'execution_authorized': False}


def verify(genesis, entries, expected_chain, minimum_height, expected_verifier, expected_head=None):
    _need(type(entries) is list and len(entries) <= 256, 'INDEPENDENT_HISTORY_LIMIT')
    request = {'action': 'replay', 'genesis': genesis, 'entries': entries, 'expected_chain': expected_chain,
               'minimum_height': minimum_height, 'include_state': False}
    if expected_head is not None:
        request['expected_head'] = expected_head
    result, bundle_id = _invoke(request, expected_verifier)
    receipt = {'profile': PROFILE, 'verifier': bundle_id,
               'request_sha256': hashlib.sha256(_wire(request)).hexdigest(),
               'chain': result['chain'], 'height': result['height'], 'head': result['head'],
               'state_root': result['state_root'], 'history_replayed': True,
               'assurance': 'INDEPENDENT_REPLAY_WITHIN_DECLARED_COVERAGE', 'signed': False}
    return {**result, 'status': 'VERIFIED_WITHIN_DECLARED_COVERAGE', 'verifier': bundle_id,
            'receipt': receipt, 'execution_authorized': False}
