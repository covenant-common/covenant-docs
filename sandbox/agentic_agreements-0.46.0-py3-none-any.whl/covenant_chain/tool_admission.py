"""Per-identity and per-IP token buckets with AIMD backpressure.

This is the view-layer limit from the biomimicry note (A2 and H4). It does
not change block validity, fees, or the consensus engine.

A2 integer form (Chiu and Jain 1989; Gordon / Prabhakar 2012):

- floor α0 = 1 slot per epoch
- additive increase of 1 slot per settled success
- multiplicative decrease ×1/2 on rejection
- a call is admitted only when both the identity bucket and the IP bucket
  still have a token

H4 (Seeley tremble dance): intake closes when the host backlog exceeds
W_hi and stays closed until the backlog falls below W_lo. W_hi = 2·W_lo.

The starting window is 4, above the floor and below the 12-call discover
burst measured on the public tool host. A host should enter ``peer`` with
the authenticated identity and the socket address. Missing values share
one anonymous identity and one unspecified address, so an unauthenticated
burst is still limited.
"""
from __future__ import annotations

import contextvars
import ipaddress
import math
import re
import threading
import time

from .crypto import integer, need

VERSION = 'covenant-tool-admission/1'
FLOOR = 1
INITIAL_WINDOW = 4
MAX_WINDOW = 32
EPOCH = 60
W_LO = 4
W_HI = W_LO * 2
MAX_KEYS = 4096
IDENTITY = re.compile(r'[A-Za-z0-9_.:@-]{1,128}\Z')

_PEER = contextvars.ContextVar('covenant_tool_peer', default=(None, None))


class peer:
    """Bind the caller identity and IP for the current context."""

    def __init__(self, identity, ip):
        self.identity = identity
        self.ip = ip
        self._token = None

    def __enter__(self):
        self._token = _PEER.set((self.identity, self.ip))
        return self

    def __exit__(self, *_exc):
        _PEER.reset(self._token)
        return False


def canonical_identity(value):
    if value is None:
        return 'anonymous'
    need(type(value) is str and IDENTITY.fullmatch(value) is not None, 'TOOL_ADMISSION_IDENTITY')
    return value


def canonical_ip(value):
    if value is None:
        return 'unspecified'
    need(type(value) is str and 0 < len(value) <= 64, 'TOOL_ADMISSION_IP')
    try:
        parsed = ipaddress.ip_address(value)
    except ValueError:
        raise ValueError('TOOL_ADMISSION_IP') from None
    mapped = getattr(parsed, 'ipv4_mapped', None)
    if mapped is not None:
        return str(mapped)
    return str(parsed)


class _Bucket:
    def __init__(self):
        self.window = INITIAL_WINDOW
        self.tokens = INITIAL_WINDOW
        self.epoch = None

    def roll(self, epoch):
        if self.epoch != epoch:
            self.epoch = epoch
            self.tokens = self.window

    def decrease(self):
        self.window = max(FLOOR, self.window // 2)
        if self.tokens > self.window:
            self.tokens = self.window

    def reward(self):
        if self.window < MAX_WINDOW:
            self.window += 1
        if self.tokens < self.window:
            self.tokens += 1


class Admission:
    """One host's identity table and IP table."""

    def __init__(self, now=None):
        self._now = now or time.monotonic
        self._lock = threading.Lock()
        self._by_identity = {}
        self._by_ip = {}
        self.backlog = 0
        self._closed = False

    @property
    def intake_open(self):
        return not self._closed

    def _clock(self, now):
        if now is None:
            now = self._now()
        need(type(now) in (int, float) and math.isfinite(now) and now >= 0, 'TOOL_ADMISSION_CLOCK')
        return now

    def _bucket(self, table, key):
        found = table.get(key)
        if found is not None:
            return found
        need(len(table) < MAX_KEYS, 'TOOL_ADMISSION_RATE')
        found = _Bucket()
        table[key] = found
        return found

    def _pair(self, identity, ip):
        bound_identity, bound_ip = _PEER.get()
        if identity is None:
            identity = bound_identity
        if ip is None:
            ip = bound_ip
        return (self._bucket(self._by_identity, canonical_identity(identity)),
                self._bucket(self._by_ip, canonical_ip(ip)))

    def note_backlog(self, depth):
        """H4. Close intake above W_hi; reopen it only below W_lo."""
        integer(depth)
        with self._lock:
            if depth > W_HI:
                self._closed = True
            elif depth < W_LO:
                self._closed = False
            self.backlog = depth

    def note_settled(self, identity=None, ip=None, *, now=None):
        """A2 additive increase: one slot on each bucket after a settled success."""
        moment = self._clock(now)
        with self._lock:
            epoch = int(moment // EPOCH)
            ident, addr = self._pair(identity, ip)
            ident.roll(epoch)
            addr.roll(epoch)
            ident.reward()
            addr.reward()

    def allow(self, identity=None, ip=None, *, now=None):
        """Consume one identity token and one IP token, or refuse."""
        moment = self._clock(now)
        with self._lock:
            epoch = int(moment // EPOCH)
            ident, addr = self._pair(identity, ip)
            ident.roll(epoch)
            addr.roll(epoch)
            if self._closed:
                ident.decrease()
                addr.decrease()
                raise ValueError('TOOL_ADMISSION_BACKPRESSURE')
            if ident.tokens < 1 or addr.tokens < 1:
                if ident.tokens < 1:
                    ident.decrease()
                if addr.tokens < 1:
                    addr.decrease()
                raise ValueError('TOOL_ADMISSION_RATE')
            ident.tokens -= 1
            addr.tokens -= 1

    def window(self, identity=None, ip=None):
        """Test helper. Returns (identity window, ip window) without consuming."""
        with self._lock:
            ident, addr = self._pair(identity, ip)
            return ident.window, addr.window
