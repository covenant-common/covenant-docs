"""POSIX sandbox launch boundaries, not production key custody.

The host/parent directories remain trusted. Owner-only files prevent accidental
local disclosure; they are not an HSM, rollback protection or operator diversity.
This transport permits literal loopback HTTP peers only and never follows
redirects or environment proxy settings.
"""
from __future__ import annotations

import ipaddress
import os
from pathlib import Path
import stat
import urllib.parse
import urllib.request

from .crypto import need

MAX_KEY_FILE_BYTES = 32768


def literal_ip(host):
    """Accept one canonical literal IP. DNS names, zone ids, mapped and unspecified addresses are rejected."""
    need(type(host) is str and host and '%' not in host, 'TLS_IP_ZONE')
    try:
        ip = ipaddress.ip_address(host)
    except ValueError as exc:
        raise ValueError('TLS_LITERAL_IP') from exc
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
        raise ValueError('TLS_IP_MAPPED')
    canonical = ip.compressed if isinstance(ip, ipaddress.IPv6Address) else str(ip)
    need(host == canonical, 'TLS_IP_CANONICAL')
    if ip.is_multicast or ip.is_unspecified:
        raise ValueError('TLS_IP_RANGE')
    return ip


def read_signing_key(path):
    """Read one already-created signing file without symlink following."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError as exc:
        raise ValueError('LAUNCH_KEY_FILE') from exc
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode), 'LAUNCH_KEY_REGULAR')
        need(info.st_uid == os.geteuid(), 'LAUNCH_KEY_OWNER')
        need(info.st_mode & 0o077 == 0, 'LAUNCH_KEY_PERMISSIONS')
        need(info.st_nlink == 1, 'LAUNCH_KEY_LINKS')
        need(0 < info.st_size <= MAX_KEY_FILE_BYTES, 'LAUNCH_KEY_SIZE')
        chunks = []
        remaining = MAX_KEY_FILE_BYTES + 1
        while remaining:
            chunk = os.read(fd, min(remaining, 4096))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        raw = b''.join(chunks)
        need(0 < len(raw) <= MAX_KEY_FILE_BYTES, 'LAUNCH_KEY_SIZE')
        try:
            return raw.decode('ascii')
        except UnicodeError as exc:
            raise ValueError('LAUNCH_KEY_ENCODING') from exc
    finally:
        os.close(fd)


def validate_peers(peers):
    need(type(peers) is dict and 1 <= len(peers) <= 64, 'LAUNCH_PEERS')
    for name, endpoint in peers.items():
        need(type(name) is str and 0 < len(name) <= 80, 'LAUNCH_PEER_NAME')
        need(type(endpoint) is str and len(endpoint) <= 256 and
             all(33 <= ord(c) <= 126 for c in endpoint), 'LAUNCH_PEER_URL')
        try:
            uri = urllib.parse.urlsplit(endpoint)
            address = ipaddress.ip_address(uri.hostname or '')
            port = uri.port
        except ValueError as exc:
            raise ValueError('LAUNCH_PEER_LOOPBACK') from exc
        need(uri.scheme == 'http' and address.is_loopback and port is not None and
             1 <= port <= 65535 and uri.username is None and uri.password is None and
             uri.path in ('', '/') and not uri.query and not uri.fragment,
             'LAUNCH_PEER_LOOPBACK')


def check_storage_paths(base, causal=False, feedback=False):
    """Fail before opening an existing unsafe safety file or sidecar.

    Parent paths are trusted by the operator. A host administrator can still
    replace files; independently retained checkpoints remain necessary.
    """
    base = str(base)
    paths = [base, base+'.lock', base+'.sqlite3', base+'.sqlite3-wal', base+'.sqlite3-shm']
    for enabled, suffix in ((causal,'.causal.sqlite3'), (feedback,'.feedback.sqlite3')):
        if enabled:
            paths.extend(base+suffix+tail for tail in ('','-wal','-shm'))
    for name in paths:
        path = Path(name)
        try:
            info = path.lstat()
        except FileNotFoundError:
            continue
        need(stat.S_ISREG(info.st_mode), 'LAUNCH_STORAGE_REGULAR')
        need(info.st_uid == os.geteuid(), 'LAUNCH_STORAGE_OWNER')
        need(info.st_mode & 0o077 == 0, 'LAUNCH_STORAGE_PERMISSIONS')
        need(info.st_nlink == 1, 'LAUNCH_STORAGE_LINKS')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def local_opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
