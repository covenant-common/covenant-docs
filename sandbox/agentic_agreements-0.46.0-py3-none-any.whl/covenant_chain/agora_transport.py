"""Owner-installed Agora HTTPS transport over the existing durable connector.

Endpoints, TLS trust and credentials are owner configuration. Protocol text never
chooses an endpoint or installs this client. Receipts establish observed bytes,
not business success, payment, peer signing authority or protocol conformance.
"""
import base64
from copy import deepcopy
import re
from urllib.parse import urlsplit

from covenant_agent.tool_client import _json, _loads, sha256
from . import agora_bridge
from .connector_harness import ConnectorHarness, _url_path
from .crypto import need


def describe():
    return {'profile': 'covenant-agora-https/0.1', 'maturity': 'EXPERIMENTAL',
            'owner_setup': 'AgoraHTTPClient(private_directory, fixed_https_origin); ExchangeTools(agora_peer=client)',
            'actions': ['discover', 'exchange', 'recover'],
            'tls': 'HOSTNAME_AND_CERTIFICATE_VERIFICATION_ENABLED; OWNER_PROCESS_TRUST_STORE',
            'recovery': 'RETAIN_EFFECT_ID; UNKNOWN_OUTCOMES_DO_NOT_RETRANSMIT',
            'authority': 'TRANSPORT_INSTALLATION_ONLY; NO_SIGNING_PAYMENT_OR_BUSINESS_TRUTH',
            'network': False, 'execution_authorized': False}


class AgoraHTTPClient:
    def __init__(self, directory, origin, path='/agora', *, headers=None, timeout=5):
        need(type(origin) is str and urlsplit(origin).scheme == 'https', 'AGORA_HTTPS_REQUIRED')
        need(type(path) is str and path.startswith('/') and not path.endswith('/') and
             '?' not in path and _url_path(path) == path, 'AGORA_OWNER_PATH')
        need(headers is None or callable(headers), 'AGORA_OWNER_HEADERS')
        self.path = path
        self.headers = headers
        self.harness = ConnectorHarness(directory, http_routes={'agora': {
            'origin': origin, 'path_prefix': path, 'methods': ['GET', 'POST'],
            'headers': self._headers, 'response_headers': ['content-type']}},
            timeout=timeout, max_request_bytes=1000000, max_response_bytes=1000000)
        self._adopted_headers = headers
        self._harness = self.harness
        self._pin = sha256(self._configuration())

    def _configuration(self):
        return {'path': self.path, 'connector': self.harness.ref,
                'policy': self.harness.policy_pin, 'timeout': self.harness.timeout,
                'request_limit': self.harness.max_request_bytes,
                'response_limit': self.harness.max_response_bytes,
                'routes': {k: {n: deepcopy(v) for n, v in row.items() if n != 'headers'}
                           for k, row in self.harness.routes.items()}}

    def _unchanged(self):
        need(self.harness is self._harness and self.headers is self._adopted_headers and
             sha256(self._configuration()) == self._pin and
             self.harness.routes['agora']['headers'] == self._headers,
             'AGORA_OWNER_CONFIGURATION_CHANGED')

    def _headers(self):
        self._unchanged()
        extra = {} if self.headers is None else self.headers()
        need(type(extra) is dict and not {k.lower() for k in extra} & {'content-type', 'accept'},
             'AGORA_RESERVED_HEADERS')
        return {'Content-Type': 'application/json', 'Accept': 'application/json', **extra}

    def _effect(self, effect_id):
        need(type(effect_id) is str and re.fullmatch(r'[A-Za-z0-9._:-]{1,128}', effect_id),
             'AGORA_EFFECT_ID')
        return sha256({'transport': 'covenant-agora-https/0.1', 'owner': self._pin, 'effect': effect_id})

    def _read(self, receipt):
        need(receipt.get('status') == 'OBSERVED', 'AGORA_OUTCOME_UNKNOWN_RECOVER_EXISTING_EFFECT')
        response = receipt['value']['response']
        need(response['status'] == 200, 'AGORA_HTTP_STATUS')
        need(response['headers'].get('content-type', '').split(';')[0].strip().lower() == 'application/json',
             'AGORA_JSON_REQUIRED')
        return _loads(base64.b64decode(response['body_base64'], validate=True))

    def discover(self, effect_id):
        self._unchanged()
        receipt = self.harness.execute(self._effect(effect_id), {'protocol': 'HTTP', 'operation': 'agora',
            'parameters': {'path': self.path + '/wellknown', 'method': 'GET'}})
        records = self._read(receipt)
        need(type(records) is dict and len(records) <= 256, 'AGORA_DISCOVERY_LIMIT')
        for digest, sources in records.items():
            need(type(digest) is str and re.fullmatch(r'[0-9a-f]{40}', digest) and
                 type(sources) is list and 1 <= len(sources) <= 16 and
                 all(type(s) is str and len(s.encode('utf-8')) <= agora_bridge.MAX_DOCUMENT_BYTES
                     for s in sources), 'AGORA_DISCOVERY_FIELDS')
        return {'protocols': records, 'source_authentication': 'OWNER_ADOPTED_TLS_ENDPOINT_ONLY',
                'documents_fetched': False, 'protocol_adopted': False,
                'execution_authorized': False, 'receipt_id': receipt['output_hash']}

    def exchange(self, prepared, expected_request_id, effect_id, now):
        self._unchanged()
        agora_bridge._prepared(prepared, expected_request_id)
        need(prepared['variant'] == 'AGORA_WORKING_2025', 'AGORA_TRANSPORT_VARIANT')
        agora_bridge._time(now)
        # Validate expiry before sending, not only when the response arrives.
        if prepared['conversation'] is not None:
            agora_bridge._conversation(prepared['conversation'], prepared['conversation_pin'], now)
        receipt = self.harness.execute(self._effect(effect_id), {'protocol': 'HTTP', 'operation': 'agora',
            'parameters': {'path': self.path + prepared['path'], 'method': 'POST',
                'body_base64': base64.b64encode(_json(prepared['envelope'])).decode('ascii')}})
        response = self._read(receipt)
        result = agora_bridge.observe(prepared, response, now, expected_request_id)
        return {**result, 'receipt_id': receipt['output_hash'], 'network_observed': True,
                'business_outcome_verified': False, 'payment_verified': False}

    def recover(self, effect_id):
        """Read a retained transport result without transmission or fresh authority."""
        self._unchanged()
        receipt = self.harness.observe(self._effect(effect_id))
        return {'receipt': receipt,
                'response': self._read(receipt) if receipt.get('status') == 'OBSERVED' else None,
                'network_observed': False, 'execution_authorized': False,
                'business_outcome_verified': False, 'payment_verified': False}

    def close(self):
        self.harness.close()
