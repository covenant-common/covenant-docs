"""PQ-encrypted private annexes; ledger identities/amounts/graph remain public."""
import hashlib,os
from .crypto import canonical,loads,need
from covenant_language.quantum import encrypt_for,decrypt_for

def seal_annex(terms,recipients,context):
    salt=os.urandom(32).hex();raw=canonical({'salt':salt,'terms':terms})
    commitment=hashlib.sha256(b'COVENANT-PRIVATE-ANNEX-0.1\0'+raw).hexdigest()
    return {'version':'covenant-private-annex/0.1','context':context,'commitment':commitment,
            'recipients':{name:encrypt_for(raw,recipient_public_key=pub,context=canonical(context)) for name,pub in recipients.items()}}

def open_annex(packet,recipient,secret,context):
    need(packet['version']=='covenant-private-annex/0.1' and packet['context']==context,'PRIVATE_CONTEXT')
    raw=decrypt_for(packet['recipients'][recipient],recipient_secret_key=secret,context=canonical(context))
    need(hashlib.sha256(b'COVENANT-PRIVATE-ANNEX-0.1\0'+raw).hexdigest()==packet['commitment'],'PRIVATE_COMMITMENT')
    return loads(raw)['terms']
