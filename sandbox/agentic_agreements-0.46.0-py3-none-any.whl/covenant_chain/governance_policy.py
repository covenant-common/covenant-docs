"""K-of-n councils for policies that are not yet consensus.

Existing economics and market fixtures keep threshold 1. Raising those
thresholds would change consensus for every chain that already uses them, so
this module does not edit those fixtures. It rejects a new production policy
whose threshold is 1, and it can lint a document to point those fixtures out.

Maintainer-seat rotation uses the same 3-of-5 idea: the remaining seats sign
a replacement. The lost seat's key does not count.

``attest`` checks governance-council signatures over one exact body under one
policy (the signed message names the policy id, so a signature cannot be
replayed under another policy that seats the same council). It changes no
consensus state; discovery uses it to approve a validator peer-key rotation.
"""
from __future__ import annotations

import hashlib

from .crypto import canonical, exact, key, need, sign, verify

VERSION = 'covenant-governance-policy/1'
LABEL = 'COVENANT-GOVERNANCE-POLICY'
ROTATION_LABEL = 'COVENANT-MAINTAINER-ROTATION'
ACTION_LABEL = 'COVENANT-GOVERNANCE-ACTION'
COUNCILS = ('governance', 'admission', 'incidents', 'custody', 'archives', 'funding')
# attest() labels belong to the caller's domain, never to this module's own messages.
RESERVED_LABELS = frozenset({LABEL, ROTATION_LABEL, ACTION_LABEL})


class GovernanceError(ValueError):
    pass


def _council(value, profile):
    exact(value, 'members threshold')
    members = value['members']
    need(type(members) is list and len(members) == len(set(members)), 'COUNCIL_MEMBERS')
    for member in members:
        key(member)
    threshold = value['threshold']
    need(type(threshold) is int and threshold >= 2, 'GOVERNANCE_THRESHOLD_ONE' if threshold == 1 else 'COUNCIL_THRESHOLD')
    need(threshold <= len(members) and threshold * 2 > len(members), 'COUNCIL_MAJORITY')
    if profile == 'production':
        need(len(members) == 5 and threshold == 3, 'COUNCIL_PRODUCTION')
    elif profile == 'sandbox':
        need(3 <= len(members) <= 16, 'COUNCIL_SANDBOX')
    else:
        raise GovernanceError('COUNCIL_PROFILE')
    ordered = dict(value)
    ordered['members'] = sorted(members)
    return ordered


def make_policy(profile, councils):
    need(type(councils) is dict and set(councils) == set(COUNCILS), 'COUNCIL_SET')
    body = {'v': VERSION, 'profile': profile, 'councils': {name: _council(councils[name], profile) for name in COUNCILS}}
    canonical(body)
    return body


def policy_id(policy):
    return hashlib.sha256(b'COVENANT-GOVERNANCE-POLICY\0' + canonical(policy)).hexdigest()


def check_policy(policy):
    """The exact canonical policy document, or a refusal."""
    exact(policy, 'v profile councils')
    need(policy['v'] == VERSION, 'GOVERNANCE_VERSION')
    cleaned = make_policy(policy['profile'], policy['councils'])
    need(cleaned == policy, 'GOVERNANCE_CANONICAL')
    return policy


def adopt(policy, signatures):
    """Governance-council signatures adopt the whole policy. Other councils act later."""
    check_policy(policy)
    council = policy['councils']['governance']
    _require(council, signatures, LABEL, {'policy': policy_id(policy)})
    return {'adopted': True, 'policy': policy_id(policy), 'threshold': council['threshold'], 'consensus_change': False}


def _attest_label(label):
    need(type(label) is str and 0 < len(label) <= 80 and all(33 <= ord(char) <= 126 for char in label), 'GOVERNANCE_LABEL')
    need(label not in RESERVED_LABELS, 'GOVERNANCE_LABEL')
    return label


def attestation(policy, body):
    """The message council members sign for ``attest``: this policy and one exact body."""
    canonical(body)
    return {'policy': policy_id(policy), 'body': body}


def sign_attestation(private_key, policy, label, body):
    check_policy(policy)
    return sign(private_key, _attest_label(label), attestation(policy, body))


def attest(policy, label, body, signatures):
    """Governance-council signatures over one exact body under this policy. Consensus state stays put."""
    _attest_label(label)
    check_policy(policy)
    _require(policy['councils']['governance'], signatures, label, attestation(policy, body))
    return {'attested': True, 'policy': policy_id(policy), 'consensus_change': False}


def authorize(policy, council_name, action, signatures):
    need(council_name in COUNCILS and council_name != 'governance', 'COUNCIL_ACTION')
    exact(action, 'v name body')
    need(action['v'] == 'covenant-governance-action/1' and action['name'] == council_name, 'COUNCIL_ACTION')
    canonical(action['body'])
    message = {'policy': policy_id(policy), 'action': action}
    _require(policy['councils'][council_name], signatures, ACTION_LABEL, message)
    return {'authorized': True, 'council': council_name, 'executed': False}


def _require(council, signatures, label, body):
    need(type(signatures) is dict and len(signatures) <= len(council['members']), 'COUNCIL_SIGNATURES')
    seen = set()
    for member, signature in signatures.items():
        need(member in council['members'] and member not in seen, 'COUNCIL_SIGNER')
        verify(member, label, body, signature)
        seen.add(member)
    need(len(seen) >= council['threshold'], 'COUNCIL_THRESHOLD')


def sign_adoption(private_key, policy):
    body = {'policy': policy_id(policy)}
    return sign(private_key, LABEL, body)


def sign_action(private_key, policy, action):
    return sign(private_key, ACTION_LABEL, {'policy': policy_id(policy), 'action': action})


def lint_threshold_one(document, path='document'):
    """Report threshold 1. Does not rewrite the document."""
    found = []
    if type(document) is dict:
        if document.get('threshold') == 1:
            found.append(path + '.threshold')
        for key_name, value in document.items():
            found.extend(lint_threshold_one(value, path + '.' + str(key_name)))
    elif type(document) is list:
        for index, value in enumerate(document):
            found.extend(lint_threshold_one(value, f'{path}[{index}]'))
    return found


def rotate_maintainer(maintainers, seat_id, replacement, signatures):
    """Remaining seats replace one seat. The seat being replaced cannot sign."""
    from .release_trust import canonical as tool_canonical, validate_maintainers
    validate_maintainers(maintainers)
    if maintainers['profile'] == 'unadopted':
        raise GovernanceError('MAINTAINER_UNADOPTED')
    seats = {seat['id']: seat for seat in maintainers['seats']}
    if seat_id not in seats:
        raise GovernanceError('MAINTAINER_SEAT')
    exact(replacement, 'ed25519 ml_dsa_65')
    proposal = {
        'v': 'covenant-maintainer-rotation/1',
        'previous': hashlib.sha256(tool_canonical(maintainers)).hexdigest(),
        'seat': seat_id,
        'ed25519': replacement['ed25519'],
        'ml_dsa_65': replacement['ml_dsa_65'],
    }
    canonical(proposal)
    eligible = [seat for seat in maintainers['seats'] if seat['id'] != seat_id]
    need(type(signatures) is dict, 'ROTATION_SIGNATURES')
    seen = set()
    for seat in eligible:
        signature = signatures.get(seat['id'])
        if signature is None:
            continue
        verify(seat['ed25519'], ROTATION_LABEL, proposal, signature)
        seen.add(seat['id'])
    if seat_id in signatures:
        raise GovernanceError('ROTATION_LOST_SEAT')
    need(len(seen) >= maintainers['threshold'], 'ROTATION_THRESHOLD')
    updated = []
    for seat in maintainers['seats']:
        if seat['id'] != seat_id:
            updated.append(dict(seat))
            continue
        updated.append({'id': seat['id'], 'jurisdiction': seat['jurisdiction'], 'ed25519': replacement['ed25519'], 'ml_dsa_65': replacement['ml_dsa_65']})
    rotated = {'v': maintainers['v'], 'profile': maintainers['profile'], 'threshold': maintainers['threshold'], 'seats': updated}
    validate_maintainers(rotated)
    return {'maintainers': rotated, 'proposal': proposal, 'signers': sorted(seen)}
