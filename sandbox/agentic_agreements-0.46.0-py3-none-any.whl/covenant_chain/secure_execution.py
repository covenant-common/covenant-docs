"""Owner-provisioned agent-blind HTTP bindings, profile secure-execution-0.1.

This narrow macOS backend admits only fixed HTTPS templates at 127.0.0.1 and
uses Seatbelt to restrict outbound network to that loopback port. It is not an
arbitrary-code or complete filesystem sandbox. The host, Python, worker source,
TLS files, owner provisioning channel and local service are trusted. Secret
values live in owner process memory and a private child pipe, never MCP args.
WebAuthn verifies an owner-adopted credential; hardware origin is NOT attested
by this module. Timing, host inspection and endpoint covert channels are not
eliminated. A receipt records a possible attempt, not external success.
"""
import base64
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re
import secrets
import selectors
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

from cryptography import x509
from cryptography.hazmat.primitives import serialization

from .signin import passkey_challenge, verify_passkey_assertion
from .transport import tls_context
from .json_bounds import validate_json

VERSION = 'secure-execution-0.1'
MAX_SESSION_SECONDS = 14400
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_NAME = re.compile(r'[A-Za-z][A-Za-z0-9_-]{0,63}\Z')
_HEADER = re.compile(r'[!#$%&\'*+.^_`|~0-9A-Za-z-]{1,64}\Z')
_WORKER = Path(__file__).with_name('secure_execution_worker.py')


def _need(value, code):
    if not value:
        raise ValueError(code)


def _hash(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def canonical(value):
    validate_json(value)
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')


def _text(value, limit=256):
    return type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value)


def _number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def _hex(value):
    return type(value) is str and _HEX.fullmatch(value) is not None


class SecretVault:
    """Memory-only owner object. Never expose this object or put() through MCP.

    Python cannot promise zeroisation or isolation from the embedding owner
    process. An agent receives neither this object nor a reference-reading API.
    """
    def __init__(self):
        self.__values = {}
        self.__lock = threading.RLock()

    def __repr__(self):
        return 'SecretVault(<redacted>)'

    def put(self, value):
        return self.restore(secrets.token_hex(32), value)

    def restore(self, reference, value):
        """Owner-only rebind after restart; persist IDs, never vault values.

        The owner must obtain the value through its private provisioning
        channel. Rebinding does not verify that an external credential has
        stayed valid. Existing bindings cannot be silently overwritten.
        """
        with self.__lock:
            _need(_hex(reference), 'SECURE_SECRET_REFERENCE')
            _need(reference not in self.__values, 'SECURE_SECRET_ALREADY_BOUND')
            _need(type(value) is bytes and 1 <= len(value) <= 8192 and
                  all(33 <= char <= 126 for char in value), 'SECURE_SECRET_VALUE')
            self.__values[reference] = value
        return reference

    def remove(self, reference):
        with self.__lock:
            self.__values.pop(reference, None)

    def _contains(self, reference):
        with self.__lock:
            return reference in self.__values

    def _bind(self, references):
        # Internal owner-side boundary, deliberately no general get() method.
        with self.__lock:
            return {reference: self.__values[reference].decode('ascii') for reference in references}


def operation(*, name, endpoint, server_pin, method='POST', path='/', body=b'', headers=None, bindings=()):
    """Owner installs a complete fixed request; agent arguments cannot alter it.

    bindings: [{secret_id, header, prefix}], with credentials injected only in
    HTTP headers. The MVP deliberately refuses non-loopback network targets.
    """
    _need(type(name) is str and _NAME.fullmatch(name), 'SECURE_OPERATION_NAME')
    _need(_text(endpoint, 128), 'SECURE_ENDPOINT')
    uri = urlsplit(endpoint)
    try:
        port = uri.port
    except ValueError:
        raise ValueError('SECURE_ENDPOINT') from None
    _need(uri.scheme == 'https' and uri.hostname == '127.0.0.1' and port is not None and
          1 <= port <= 65535 and uri.netloc == f'127.0.0.1:{port}' and uri.path in ('', '/') and
          not uri.query and not uri.fragment, 'SECURE_LOOPBACK_ENDPOINT_REQUIRED')
    _need(_hex(server_pin), 'SECURE_SERVER_PIN')
    _need(method in ('GET', 'POST', 'PUT', 'DELETE', 'PATCH') and type(method) is str, 'SECURE_METHOD')
    _need(_text(path, 2048) and path.startswith('/') and not path.startswith('//') and
          '#' not in path and ' ' not in path, 'SECURE_PATH')
    _need(type(body) is bytes and len(body) <= 16384, 'SECURE_BODY')
    headers = {} if headers is None else headers
    _need(type(headers) is dict and len(headers) <= 16, 'SECURE_HEADERS')
    checked = {}
    forbidden = {'host', 'content-length', 'transfer-encoding', 'connection', 'upgrade',
                 'proxy-authorization', 'proxy-connection', 'expect', 'trailer', 'te'}
    for key, value in headers.items():
        _need(type(key) is str and _HEADER.fullmatch(key) and key.lower() not in forbidden and
              _text(value, 1024) and key.lower() not in checked, 'SECURE_HEADERS')
        checked[key.lower()] = value
    _need(type(bindings) in (tuple, list) and 1 <= len(bindings) <= 8, 'SECURE_BINDINGS')
    bound = []
    for row in bindings:
        _need(type(row) is dict and set(row) == {'secret_id', 'header', 'prefix'}, 'SECURE_BINDINGS')
        key, prefix = row['header'], row['prefix']
        _need(_hex(row['secret_id']) and type(key) is str and _HEADER.fullmatch(key) and
              key.lower() not in forbidden and key.lower() not in checked and
              type(prefix) is str and len(prefix) <= 128 and all(32 <= ord(c) <= 126 for c in prefix),
              'SECURE_BINDINGS')
        checked[key.lower()] = None
        bound.append(dict(secret_id=row['secret_id'], header=key.lower(), prefix=prefix))
    row = dict(version=VERSION, name=name, endpoint=f'https://127.0.0.1:{port}', port=port,
               server_pin=server_pin, method=method, path=path, body_hex=body.hex(),
               headers={k: v for k, v in checked.items() if v is not None}, bindings=bound)
    row['id'] = _hash(row)
    return row


class SeatbeltWorker:
    """Fixed source, actual deny-default network; unsupported hosts refuse.

    File reads and process startup remain permitted for the installed Python
    runtime. This is a qualified network boundary, not full host isolation.
    """
    def __init__(self):
        self._source_pin = hashlib.sha256(_WORKER.read_bytes()).hexdigest()

    @staticmethod
    def network_policy(port):
        _need(type(port) is int and 1 <= port <= 65535, 'SECURE_PORT')
        return ('(version 1) (deny default) (allow process*) (allow file-read*) '
                '(allow sysctl-read) (allow mach-lookup) '
                f'(allow network-outbound (remote tcp "localhost:{port}"))')

    def start(self, policy):
        _need(sys.platform == 'darwin' and Path('/usr/bin/sandbox-exec').is_file(),
              'SECURE_SANDBOX_UNAVAILABLE')
        _need(hashlib.sha256(_WORKER.read_bytes()).hexdigest() == self._source_pin,
              'SECURE_WORKER_CHANGED')
        process = subprocess.Popen(['/usr/bin/sandbox-exec', '-p', self.network_policy(policy['port']),
                                    sys.executable, '-I', str(_WORKER)], stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   env={'PATH': '/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1'},
                                   close_fds=True, bufsize=0)
        try:
            process.stdin.write(canonical(policy) + b'\n')
            process.stdin.flush()
            selector = selectors.DefaultSelector()
            try:
                selector.register(process.stdout, selectors.EVENT_READ)
                ready = bool(selector.select(policy['timeout'] + 2))
            finally:
                selector.close()
            _need(ready and process.stdout.readline(32) == b'READY\n', 'SECURE_PREFLIGHT_REFUSED')
            return process
        except BaseException:
            self.stop(process)
            raise ValueError('SECURE_PREFLIGHT_REFUSED') from None

    @staticmethod
    def stop(process):
        if process.poll() is None:
            process.kill()
        process.wait(timeout=2)
        process.stdin.close()
        process.stdout.close()

    def dispatch(self, process, values, timeout):
        # Never return child output: it is not a safe information channel.
        try:
            process.stdin.write(canonical(values) + b'\n')
            process.stdin.flush()
            process.wait(timeout=timeout + 2)
        except (OSError, subprocess.TimeoutExpired):
            pass
        finally:
            self.stop(process)


class GuardedExecutor:
    """Trusted owner host. Only agent()'s three methods belong in an MCP view.

    register/presence/revocations/vault provisioning stay outside the agent
    interface. A local caller holding this Python object is part of the TCB.
    """
    def __init__(self, directory, *, owner, registration, origin, hardware_evidence,
                 vault, tls, operations, clock=time.time, monotonic=time.monotonic):
        try:
            import fcntl
            from .workflow_store import WorkflowStore
        except ImportError:
            raise ValueError('SECURE_SANDBOX_UNAVAILABLE') from None
        _need(_text(owner) and _text(hardware_evidence, 1024), 'SECURE_OWNER_HARDWARE_ADOPTION_REQUIRED')
        _need(type(registration) is dict and registration.get('account') == owner,
              'SECURE_OWNER_REGISTRATION')
        _need(_text(origin, 512) and origin.startswith('https://'), 'SECURE_OWNER_ORIGIN')
        _need(isinstance(vault, SecretVault), 'SECURE_OWNER_VAULT')
        _need(type(tls) is dict and all(type(tls.get(k)) is str and Path(tls[k]).is_absolute()
                                     for k in ('ca_file', 'cert_file', 'key_file')), 'SECURE_TLS_CONFIG')
        # Checks actual private-key custody and key/certificate consistency.
        tls_context(tls)
        cert = x509.load_pem_x509_certificate(Path(tls['cert_file']).read_bytes())
        executor_pin = hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()
        _need(type(operations) in (list, tuple) and 1 <= len(operations) <= 64, 'SECURE_OPERATIONS')
        checked = {}
        for row in operations:
            _need(type(row) is dict, 'SECURE_OPERATION')
            try:
                adopted = operation(name=row['name'], endpoint=row['endpoint'], server_pin=row['server_pin'],
                                    method=row['method'], path=row['path'], body=bytes.fromhex(row['body_hex']),
                                    headers=row['headers'], bindings=row['bindings'])
            except (KeyError, TypeError, ValueError):
                raise ValueError('SECURE_OPERATION') from None
            _need(row == adopted and row['id'] not in checked, 'SECURE_OPERATION')
            _need(all(vault._contains(b['secret_id']) for b in row['bindings']), 'SECURE_SECRET_MISSING')
            checked[row['id']] = deepcopy(row)
        self._lock = threading.RLock()
        self._owner, self._registration, self._origin = owner, deepcopy(registration), origin
        self._vault, self._tls, self._operations = vault, deepcopy(tls), checked
        self._executor_pin, self._hardware_evidence = executor_pin, hardware_evidence
        self._clock, self._monotonic = clock, monotonic
        self._last_wall = self._last_mono = None
        self._clock_failed = False
        self._sessions, self._challenges = {}, {}
        self._revocations = None
        self._worker = SeatbeltWorker()
        self._policy = _hash(dict(version=VERSION, owner=owner, registration=registration,
                                 origin=origin, executor_pin=executor_pin,
                                 hardware_evidence=hardware_evidence, operations=checked))
        self._store = WorkflowStore(directory, dict(version=VERSION, policy=self._policy), check_same_thread=False)
        try:
            # Cached counters, reservations and sessions require one broker per
            # custody directory, including across processes. Hold until close.
            fcntl.flock(self._store.lockfile.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self._store.close()
            raise ValueError('SECURE_CUSTODY_IN_USE') from None
        self._counter = 0
        self._requests = set()
        self._revocation_sequence = -1
        for event in self._store.events():
            value = event['body']['value']
            if event['body']['kind'] == 'SECURE_PRESENCE':
                self._counter = max(self._counter, value['counter'])
            if event['body']['kind'] == 'SECURE_REQUEST':
                self._requests.add(event['body']['task'])
            if event['body']['kind'] == 'SECURE_REVOCATIONS':
                self._revocation_sequence = max(self._revocation_sequence, value['sequence'])

    def __repr__(self):
        return f'GuardedExecutor({VERSION}, <owner-provisioned>)'

    def close(self):
        with self._lock:
            self._sessions.clear()
            self._challenges.clear()
            self._store.close()

    def _now(self):
        wall, mono = self._clock(), self._monotonic()
        if not (_number(wall) and _number(mono)) or (self._last_wall is not None and
                (wall < self._last_wall or mono < self._last_mono)):
            self._clock_failed = True
        _need(not self._clock_failed, 'SECURE_CLOCK_ROLLBACK')
        self._last_wall, self._last_mono = wall, mono
        return int(wall), mono

    def adopt_revocations(self, *, sequence, issued_at, expires_at, executor_pins=(), server_pins=(), sessions=()):
        """Owner adopts a current revocation view; not autonomous global OCSP.

        Snapshot freshness is at most 300 seconds. Reopening requires a newer
        owner snapshot; sessions are never restored from disk.
        """
        with self._lock:
            now, _ = self._now()
            _need(type(sequence) is int and sequence > self._revocation_sequence and type(issued_at) is int and
                  type(expires_at) is int and issued_at <= now < expires_at <= issued_at + 300,
                  'SECURE_REVOCATION_VIEW')
            for values in (executor_pins, server_pins, sessions):
                _need(type(values) in (tuple, list) and len(values) <= 4096 and all(_hex(v) for v in values),
                      'SECURE_REVOCATION_VIEW')
            row = dict(sequence=sequence, issued_at=issued_at, expires_at=expires_at,
                       executor_pins=list(executor_pins), server_pins=list(server_pins), sessions=list(sessions))
            self._store.append('SECURE_REVOCATIONS', str(sequence), row)
            self._revocations, self._revocation_sequence = row, sequence

    def begin_presence(self, *, agent, operation_ids, ttl=3600, max_calls=1):
        """Owner-only challenge construction; never register credentials via MCP."""
        with self._lock:
            now, mono = self._now()
            _need(_text(agent) and type(operation_ids) in (list, tuple) and operation_ids and
                  len(operation_ids) <= 64 and len(set(operation_ids)) == len(operation_ids) and
                  all(op in self._operations for op in operation_ids), 'SECURE_SESSION_OPERATIONS')
            _need(type(ttl) is int and 1 <= ttl <= MAX_SESSION_SECONDS and
                  type(max_calls) is int and 1 <= max_calls <= 1000, 'SECURE_SESSION_BOUNDS')
            consent = dict(version=VERSION, owner=self._owner, agent=agent, policy=self._policy,
                           executor_pin=self._executor_pin, operations=sorted(operation_ids),
                           ttl=ttl, max_calls=max_calls, nonce=secrets.token_hex(32), issued_at=now)
            challenge = passkey_challenge(consent)
            self._challenges[challenge] = (consent, now + 120, mono + 120)
            return dict(consent=deepcopy(consent), challenge=challenge, rp_id=self._registration['rp_id'],
                        credential_id=self._registration['credential_id'], user_verification='required')

    def complete_presence(self, challenge, assertion):
        with self._lock:
            now, mono = self._now()
            _need(type(challenge) is str and challenge in self._challenges, 'SECURE_CHALLENGE_MISSING')
            consent, expiry, deadline = self._challenges.pop(challenge)
            _need(now < expiry and mono < deadline, 'SECURE_CHALLENGE_EXPIRED')
            try:
                verify_passkey_assertion(consent, assertion, self._registration,
                                         origin=self._origin, require_user_verification=True)
                raw = assertion['authenticator_data']
                auth = base64.urlsafe_b64decode(raw + '=' * (-len(raw) % 4))
                counter = int.from_bytes(auth[33:37], 'big')
            except (ValueError, KeyError, TypeError, UnicodeError):
                raise ValueError('SECURE_PRESENCE_REFUSED') from None
            _need(counter > self._counter, 'SECURE_AUTHENTICATOR_COUNTER')
            token = secrets.token_hex(32)
            handle = hashlib.sha256(token.encode('ascii')).hexdigest()
            self._store.append('SECURE_PRESENCE', handle, dict(counter=counter, agent=consent['agent'],
                               executor_pin=self._executor_pin, operations=consent['operations'],
                               issued_at=now, expires_at=now + consent['ttl'], policy=self._policy))
            self._counter = counter
            self._sessions[handle] = dict(agent=consent['agent'], operations=consent['operations'],
                                         expiry=now + consent['ttl'], deadline=mono + consent['ttl'],
                                         remaining=consent['max_calls'])
            return token

    def agent(self, agent):
        _need(_text(agent), 'SECURE_AGENT')
        return AgentClient(self, agent)

    def _check(self, agent, token, operation_id, *, reserved=False):
        now, mono = self._now()
        _need(_hex(token) and _hex(operation_id), 'SECURE_SESSION')
        handle = hashlib.sha256(token.encode('ascii')).hexdigest()
        session = self._sessions.get(handle)
        _need(session is not None and session['agent'] == agent and operation_id in session['operations'] and
              now < session['expiry'] and mono < session['deadline'] and
              (session['remaining'] > 0 or reserved),
              'SECURE_SESSION')
        view = self._revocations
        _need(view is not None and view['issued_at'] <= now < view['expires_at'], 'SECURE_REVOCATION_VIEW_STALE')
        _need(self._executor_pin not in view['executor_pins'] and handle not in view['sessions'] and
              self._operations[operation_id]['server_pin'] not in view['server_pins'], 'SECURE_REVOKED')
        return now, handle, session

    def _execute(self, agent, token, operation_id, request_id):
        with self._lock:
            now, handle, session = self._check(agent, token, operation_id)
            _need(_hex(request_id) and request_id not in self._requests, 'SECURE_REQUEST_REPLAY')
            row = self._operations[operation_id]
            refs = sorted({b['secret_id'] for b in row['bindings']})
            _need(all(self._vault._contains(ref) for ref in refs), 'SECURE_SECRET_MISSING')
            metadata = dict(version=VERSION, owner=self._owner, agent=agent, executor_pin=self._executor_pin,
                            operation_id=operation_id, endpoint=row['endpoint'], method=row['method'],
                            path=row['path'], when=now, session_id=handle, secret_ids=refs)
            # Durable reservation BEFORE any network effect; no automatic retry
            # after a crash or ambiguous dispatch. Reservations remain consumed.
            self._store.append('SECURE_REQUEST', request_id, metadata)
            self._requests.add(request_id)
            session['remaining'] -= 1
            policy = {k: deepcopy(row[k]) for k in ('port', 'server_pin', 'method', 'path', 'body_hex', 'headers', 'bindings')}
            policy.update(tls=self._tls, executor_pin=self._executor_pin, timeout=3)
        # No credentials are available to the worker yet. Owner revocations can
        # be adopted concurrently while the TLS handshake is in progress.
        process = self._worker.start(policy)
        try:
            with self._lock:
                now, _, _ = self._check(agent, token, operation_id, reserved=True)
                metadata['when'] = now
                event = self._store.append('SECURE_DISPATCH_INTENT', request_id, metadata)
                values = self._vault._bind(refs)
        except BaseException:
            self._worker.stop(process)
            raise
        self._worker.dispatch(process, values, 3)
        # Same public receipt for response reflection, errors and no body.
        return dict(version=VERSION, request_id=request_id, audit_id=event,
                    state='attempt_recorded', external_outcome='unknown', auto_retry=False)

    def describe(self):
        return dict(version=VERSION, session_max_seconds=MAX_SESSION_SECONDS,
                    backend='macos-seatbelt-fixed-loopback-https', remote_plaintext=False,
                    arbitrary_commands=False, hardware_attestation=False,
                    filesystem_isolation=False, response='broker-generated-attempt-only',
                    limitations=['trusted owner host and Python runtime', 'loopback HTTPS only',
                                 'remote service must separately enforce client-certificate authentication',
                                 'owner-adopted hardware credential; no authenticator attestation',
                                 'counterless passkeys unsupported', 'timing and host side channels remain',
                                 'local audit rollback needs an independently retained head'])


class AgentClient:
    """MCP-safe surface: describe, preview, execute, scoped audit; no owner methods.

    Python introspection is not an isolation boundary: expose methods through
    an owner-controlled RPC/MCP adapter, never run untrusted Python in-process.
    """
    def __init__(self, executor, agent):
        self.__executor, self.__agent = executor, agent

    def describe(self):
        return self.__executor.describe()

    def operations(self):
        return [self.preview(operation_id) for operation_id in sorted(self.__executor._operations)]

    def preview(self, operation_id):
        _need(_hex(operation_id) and operation_id in self.__executor._operations, 'SECURE_OPERATION')
        row = self.__executor._operations[operation_id]
        return dict(operation_id=operation_id, name=row['name'], endpoint=row['endpoint'], method=row['method'],
                    path=row['path'], body_sha256=hashlib.sha256(bytes.fromhex(row['body_hex'])).hexdigest(),
                    secret_ids=sorted({b['secret_id'] for b in row['bindings']}),
                    owner_presence_required=True, external_outcome='unknown-until-independently-observed')

    def execute(self, *, session, operation_id, request_id):
        return self.__executor._execute(self.__agent, session, operation_id, request_id)

    def audit(self, *, request_id=None, limit=100):
        _need(request_id is None or _hex(request_id), 'SECURE_REQUEST_ID')
        _need(type(limit) is int and 1 <= limit <= 100, 'SECURE_AUDIT_LIMIT')
        with self.__executor._lock:
            rows = [event for event in self.__executor._store.events()
                    if event['body']['value'].get('agent') == self.__agent and
                    event['body']['kind'] in ('SECURE_REQUEST', 'SECURE_DISPATCH_INTENT') and
                    (request_id is None or event['body']['task'] == request_id)]
            fields = ('version', 'agent', 'executor_pin', 'operation_id', 'endpoint', 'method', 'path', 'when', 'secret_ids')
            return [dict(audit_id=event['id'], kind=event['body']['kind'], request_id=event['body']['task'],
                         **{key: deepcopy(event['body']['value'][key]) for key in fields}) for event in rows[-limit:]]
