"""Keyless required-agreement drafting and evidence checks; never execution."""
from copy import deepcopy

from . import a2a_agreement_gate as g
from .cooperation_interface import HASH, INT, OBJECT, TEXT


def spec():
    assents = {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': OBJECT}
    return ('covenant_a2a_agreement',
        'Draft an exact required A2A agreement, return the payload for explicit party signing, '
        'attach supplied signatures and verify retained evidence against independent pins. '
        'No keys, signing, owner adoption, live authority checks, network calls or payment.', True, [
        ('spec', {}, ()),
        ('prepare_request', {'params': OBJECT, 'carrier': {'enum': ['DATA', 'EXACT_JSON']}}, ('params',)),
        ('draft', {'params': OBJECT, 'service': TEXT, 'policy_id': TEXT, 'caller': HASH,
            'grant': HASH, 'required_signers': {'type': 'array', 'minItems': 1,
                'maxItems': 16, 'items': HASH}, 'valid_from': INT, 'valid_until': INT,
            'nonce': HASH, 'terms': {'type': 'string', 'minLength': 1, 'maxLength': 8192}},
            ('params', 'service', 'policy_id', 'caller', 'grant', 'required_signers',
             'valid_from', 'valid_until', 'nonce', 'terms')),
        ('attach', {'params': OBJECT, 'agreement': OBJECT, 'assents': assents},
            ('params', 'agreement', 'assents')),
        ('verify', {'agreement': OBJECT, 'assents': assents, 'expected_agreement': OBJECT},
            ('agreement', 'assents', 'expected_agreement')),
        ('verify_receipt', {'receipt': OBJECT, 'expected_signer': HASH,
            'expected_agreement': HASH, 'expected_request': HASH, 'execution_result': OBJECT},
            ('receipt', 'expected_signer', 'expected_agreement', 'expected_request')),
        ('verify_evidence', {'evidence': OBJECT, 'expected_agreement': OBJECT,
            'expected_receipt_signer': HASH},
            ('evidence', 'expected_agreement', 'expected_receipt_signer')),
        ('decode_artifact', {'task': OBJECT}, ('task',)),
    ])


def instructions():
    return {'profile': g.VERSION, 'required_extension': g.EXTENSION_URI,
        'journey': [
            'Select the owner service, adopted policy and authenticated caller.',
            'Prepare the exact request digest so the owner can issue a narrowly scoped grant.',
            'Draft one exact operation; review resources, terms and validity before signing.',
            'Each required party explicitly signs the returned label/body in its own custody.',
            'Attach all supplied assents; this offline check does not adopt an agreement.',
            'Owner separately pins the agreement and current scoped grant in authoritative state.',
            'Send through an authenticated A2A route with the exact extension activated.',
            'Retain the original request and signed receipt; confirm acceptance and payment separately.',
        ],
        'simple': 'One exact operation and explicit required-party acceptance; no compulsory escrow or token.',
        'complex': 'Exact payloads may reference separately drafted nested contracts and procedures; '
                   'their execution semantics must be part of the independently adopted policy.',
        'unknown_outcome': 'Use the exact original request; never invent a fresh message ID to retry an uncertain effect.',
        'privacy': 'The gate journal holds private plaintext. Exports disclose selected records and are voluntary; '
                   'encryption and public-chain anchoring are separate adopted mechanisms.',
        'scope': 'Bounded synchronous A2A 1.0 JSONRPC profile; ASCII strings and exact integers; '
                 'not a complete A2A server, general contract interpreter or external verifier.',
        'sdk_carrier': 'Use prepare_request(carrier=EXACT_JSON) before signing when a client uses '
                       'protobuf Struct numbers. Exact encoded operation, envelope and receipt bytes survive SDK serialization; '
                       'keep its configuration and tenant unchanged after signing.',
        'execution_authorized': False, 'payment_verified': False}


def prepare_request(params, carrier=None):
    params = deepcopy(params)
    g.need(type(params) is dict and type(params.get('message')) is dict,
           'A2A_GATE_PARAMS')
    metadata = params.get('metadata', {})
    g.need(type(metadata) is dict and g.METADATA_KEY not in metadata,
           'A2A_GATE_DRAFT_ALREADY_ATTACHED')
    message = params['message']
    if 'extensions' not in message:
        message['extensions'] = [g.EXTENSION_URI]
    parts = message.get('parts', [])
    encoded = type(parts) is list and len(parts) == 1 and type(parts[0]) is dict and 'raw' in parts[0]
    carrier = ('EXACT_JSON' if encoded else 'DATA') if carrier is None else carrier
    g.need(carrier in ('DATA', 'EXACT_JSON'), 'A2A_GATE_CARRIER')
    if carrier == 'EXACT_JSON':
        if not encoded:
            g.need(type(parts) is list and len(parts) == 1 and type(parts[0]) is dict and
                   set(parts[0]) == {'data'}, 'A2A_GATE_PARTS')
            message['parts'] = [g.encode_operation_part(parts[0]['data'])]
        # The official SDK creates an empty configuration even in default mode.
        # Commit that explicit shape now, rather than weaken the digest later.
        params.setdefault('configuration', {})
    else:
        g.need(not encoded, 'A2A_GATE_CARRIER')
    candidate = deepcopy(params)
    envelope = {'agreement': {}, 'assents': []}
    candidate.setdefault('metadata', {})[g.METADATA_KEY] = (
        g.canonical(envelope).decode('ascii') if carrier == 'EXACT_JSON' else envelope)
    _, data, _ = g._params(candidate)
    return {'profile': g.VERSION, 'params': params, 'request': g.request_digest(params),
        'operation': data['operation'], 'resources': deepcopy(data['resources']), 'carrier': carrier,
        'grant_scope_required': 'Owner must independently authorize this exact request for the selected caller/service/policy/tenant.',
        'execution_authorized': False, 'payment_verified': False}


def draft(*, params, service, policy_id, caller, grant, required_signers,
          valid_from, valid_until, nonce, terms):
    prepared = prepare_request(params)
    params = prepared['params']
    agreement = {'version': g.VERSION, 'service': service, 'policy': policy_id,
        'tenant': params['tenant'], 'operation': prepared['operation'],
        'request': prepared['request'], 'resources': prepared['resources'],
        'required_signers': deepcopy(required_signers), 'caller': caller, 'grant': grant,
        'valid_from': valid_from, 'valid_until': valid_until, 'nonce': nonce, 'terms': terms}
    reference = g.agreement_id(agreement)
    # Validate the full execution shape without creating any signatures.
    candidate = deepcopy(params)
    envelope = {'agreement': agreement, 'assents': []}
    candidate.setdefault('metadata', {})[g.METADATA_KEY] = (
        g.canonical(envelope).decode('ascii') if prepared['carrier'] == 'EXACT_JSON' else envelope)
    g._params(candidate)
    return {'profile': g.VERSION, 'params': params, 'agreement': agreement,
        'agreement_id': reference, 'request': agreement['request'],
        'assent_payload': {'label': g.ASSENT_LABEL, 'body': {'agreement': reference}},
        'required_signers': deepcopy(required_signers), 'adopted': False,
        'execution_authorized': False, 'payment_verified': False}


def attach(*, params, agreement, assents):
    # The parties' supplied signatures are verified. Current owner adoption and
    # authority are intentionally not inferred from this self-selected object.
    prepared = g.attach_assents(params, agreement, assents)
    return {'params': prepared, 'headers': {'A2A-Version': '1.0', 'A2A-Extensions': g.EXTENSION_URI},
        'required_assents_verified': True, 'owner_adoption_verified': False,
        'execution_authorized': False, 'payment_verified': False}


def call(action, parameters):
    if action == 'spec':
        return instructions()
    if action == 'draft':
        return draft(**parameters)
    if action == 'prepare_request':
        return prepare_request(**parameters)
    if action == 'attach':
        return attach(**parameters)
    if action == 'verify':
        return g.verify_agreement(**parameters)
    if action == 'verify_receipt':
        return g.verify_receipt(**parameters)
    if action == 'verify_evidence':
        return g.verify_evidence(**parameters)
    if action == 'decode_artifact':
        return {'data': g.decode_task_artifact(**parameters), 'execution_authorized': False,
                'decoded_bytes_are_authority': False}
    raise ValueError('A2A_GATE_ACTION')
