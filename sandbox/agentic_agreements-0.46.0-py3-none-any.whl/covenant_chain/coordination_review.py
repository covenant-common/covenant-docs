"""One read-only review over independently adopted coordination mechanisms.

The case ID pins caller inputs, not their truth. Every review rechecks the
supplied exact assents and reads current owner observations. Neither a case,
its links nor this report signs, publishes, installs, revokes or executes.
"""
from copy import deepcopy
from html import escape
import base64,hashlib,json,re

from .crypto import need,verify as verify_signature
from covenant_language import external_drafts as external,frame_concepts as concepts
from covenant_language import marketplace,legal_composition

VERSION='covenant-coordination-case/0.1'
EXTENDED_VERSION='covenant-coordination-case/0.2'
BILATERAL_VERSION='covenant-coordination-case/0.3'
PERFORMANCE_VERSION='covenant-coordination-case/0.4'
RESULT='covenant-coordination-review/0.1'
DOMAIN=b'COVENANT-COORDINATION-CASE-0.1\0'
EXTENDED_DOMAIN=b'COVENANT-COORDINATION-CASE-0.2\0'
BILATERAL_DOMAIN=b'COVENANT-COORDINATION-CASE-0.3\0'
PERFORMANCE_DOMAIN=b'COVENANT-COORDINATION-CASE-0.4\0'
MAX_BYTES=1000000
NAME=re.compile(r'[A-Za-z][A-Za-z0-9_.:-]{0,79}\Z')
SECTIONS=('agreements','obligations','payments','evidence','grants','policies','bindings','links','decisions','recoveries','notes')
EXTENDED_SECTIONS=(*SECTIONS,'disputes')
PERFORMANCE_SECTIONS=(*EXTENDED_SECTIONS,'performance')

def _sections(version):
    return PERFORMANCE_SECTIONS if version==PERFORMANCE_VERSION else EXTENDED_SECTIONS if version in (EXTENDED_VERSION,BILATERAL_VERSION) else SECTIONS

def canonical(value):
    """Own bounded carrier; earlier signed canonical profiles remain unchanged."""
    nodes=0
    def visit(v,depth=0):
        nonlocal nodes
        nodes+=1;need(nodes<=100000 and depth<=32,'REVIEW_COMPLEXITY')
        if v is None or type(v) is bool:return
        if type(v) is int:need(abs(v)<=2**53-1,'REVIEW_INTEGER');return
        if type(v) is str:
            try:size=len(v.encode('utf-8'))
            except UnicodeError:raise ValueError('REVIEW_UNICODE') from None
            need(size<=524288,'REVIEW_STRING');return
        if type(v) is list:
            need(len(v)<=256,'REVIEW_ARRAY')
            for item in v:visit(item,depth+1)
            return
        need(type(v) is dict and len(v)<=256,'REVIEW_OBJECT')
        for k,item in v.items():
            need(type(k) is str,'REVIEW_KEY')
            try:need(len(k.encode('utf-8'))<=128,'REVIEW_KEY')
            except UnicodeError:raise ValueError('REVIEW_UNICODE') from None
            visit(item,depth+1)
    visit(value)
    raw=json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
    need(len(raw)<=MAX_BYTES,'REVIEW_SIZE');return raw

def _fields(v,allowed,required=()):
    need(type(v) is dict and set(required)<=set(v)<=set(allowed),'REVIEW_FIELDS')

def _name(value):need(type(value) is str and NAME.fullmatch(value),'REVIEW_ITEM_ID')
def _text(value,limit=256):need(type(value) is str and 0<len(value)<=limit,'REVIEW_TEXT')
def _hash(value):need(type(value) is str and re.fullmatch('[0-9a-f]{64}',value),'REVIEW_REFERENCE')
def _digest(value):return hashlib.sha256(canonical(value)).hexdigest()

def case(title,agreements=None,version=None,**sections):
    _text(title)
    need(set(sections)<=set(PERFORMANCE_SECTIONS)|{'group','expected_heads','primary'},'REVIEW_SECTION')
    payment_rows=sections.get('payments',[])
    extended='disputes' in sections or (type(payment_rows) is list and any(type(p) is dict and 'authorization' in p for p in payment_rows))
    selected=version if version is not None else PERFORMANCE_VERSION if 'performance' in sections else EXTENDED_VERSION if extended else VERSION
    value={'version':selected,'title':title,'primary':sections.pop('primary',None),'group':sections.pop('group',None),'expected_heads':sections.pop('expected_heads',None)}
    value.update({name:[] for name in _sections(selected)});value['agreements']=[] if agreements is None else agreements;value.update(sections)
    validate(value);return deepcopy(value)

def validate(value):
    canonical(value)
    sections=_sections(value.get('version')) if type(value) is dict else SECTIONS
    _fields(value,('version','title','primary','group','expected_heads',*sections),('version','title','agreements'))
    need(value['version'] in (VERSION,EXTENDED_VERSION,BILATERAL_VERSION,PERFORMANCE_VERSION),'REVIEW_VERSION');_text(value['title'])
    for section in sections:
        rows=value.get(section,[]);need(type(rows) is list and len(rows)<=64,'REVIEW_SECTION_LIMIT')
        if section=='notes':
            for row in rows:_text(row,4096)
        elif section in ('policies','links'):
            for row in rows:need(type(row) is dict,'REVIEW_ITEM')
        elif section not in ('policies','links'):
            seen=set()
            for row in rows:
                need(type(row) is dict and 'id' in row,'REVIEW_ITEM');_name(row['id']);need(row['id'] not in seen,'REVIEW_DUPLICATE_ITEM');seen.add(row['id'])
    if value.get('primary') is not None:
        _name(value['primary']);need(value['primary'] in {a['id'] for a in value['agreements']},'REVIEW_PRIMARY_MISSING')
    if value.get('group') is not None:_hash(value['group'])
    if value.get('expected_heads') is not None:
        heads=value['expected_heads'];need(type(heads) is list and len(heads)<=65 and heads==sorted(set(heads)),'REVIEW_HEADS')
        for h in heads:_hash(h)
    if value['version'] in (BILATERAL_VERSION,PERFORMANCE_VERSION):
        for row in value['agreements']:
            if row.get('kind')=='BILATERAL':_bilateral_fields(row)
    return True

def identifier(value):
    validate(value)
    domain=PERFORMANCE_DOMAIN if value['version']==PERFORMANCE_VERSION else BILATERAL_DOMAIN if value['version']==BILATERAL_VERSION else EXTENDED_DOMAIN if value['version']==EXTENDED_VERSION else DOMAIN
    return hashlib.sha256(domain+canonical(value)).hexdigest()

def amend_case(before,changes):
    """Prepare another observation case; preserve exact agreement bytes/proofs."""
    validate(before);canonical(changes)
    _fields(changes,('version','title','primary','group','expected_heads',*PERFORMANCE_SECTIONS))
    need(bool(changes),'REVIEW_CHANGES_REQUIRED');after=deepcopy(before);after.update(deepcopy(changes))
    payment_rows=after.get('payments',[])
    if 'disputes' in changes or (type(payment_rows) is list and any(type(p) is dict and 'authorization' in p for p in payment_rows)):
        if after['version'] not in (BILATERAL_VERSION,PERFORMANCE_VERSION):after['version']=EXTENDED_VERSION
        after.setdefault('disputes',[])
    if 'performance' in changes and 'version' not in changes:after['version']=PERFORMANCE_VERSION
    if after['version'] in (BILATERAL_VERSION,PERFORMANCE_VERSION):after.setdefault('disputes',[])
    if after['version']==PERFORMANCE_VERSION:after.setdefault('performance',[])
    validate(after)
    return {'case':after,'before':identifier(before),'id':identifier(after),
            'changed_sections':[k for k in sorted(set(before)|set(after)) if (k in before)!=(k in after) or canonical(before.get(k))!=canonical(after.get(k))],
            'previous_case_preserved':True,'agreement_bytes_and_proofs':'COPIED_EXACTLY_UNLESS_EXPLICITLY_REPLACED; REVERIFY_AT_REVIEW',
            'signature_created':False,'execution_authorized':False,'recorded':False}

def _code(error):
    value=str(error)
    return value if re.fullmatch('[A-Z][A-Z0-9_]{0,95}',value) else 'REVIEW_CHECK_FAILED'

def _attempt(function,*args,**kwargs):
    try:return function(*args,**kwargs)
    except (ValueError,TypeError,KeyError,UnicodeError,OverflowError) as error:
        return {'status':'REFUSED','code':_code(error),'execution_authorized':False}

def _summary(value,key=''):
    """Keep aggregate reviews useful without copying raw carriers/openings."""
    private={'prepared','envelope','envelopes','bundle','artifacts','document','source_base64',
             'proof','witness','salt','salts','openings','authorization','proofs'}
    if key in private or key.endswith('_envelope'):
        return {'content_hash':_digest(value),'contents':'OMITTED_FROM_COMBINED_REVIEW; REQUEST_THE_EXPLICIT_SOURCE_HANDOFF_IF_NEEDED'}
    if type(value) is dict:
        return {k:_summary(v,k) for k,v in value.items()}
    if type(value) is list:return [_summary(v,key) for v in value]
    return deepcopy(value)

def _current(actual,expected):return external._current(actual,expected)

def _assent_progress(payload,approvals,verified):
    """Per-role diagnostics never replace verification of the complete proof set."""
    required=payload.get('required_assents')
    if required is None:
        required=[{'party':role,'identity':identity,'body':payload['body']} for role,identity in payload['required_parties'].items()]
    rows=[]
    for role in required:
        candidates=[p for p in approvals if type(p) is dict and p.get('party')==role['party'] and
                    ('concept' not in role or p.get('concept')==role['concept'])] if type(approvals) is list else []
        good=False
        for proof in candidates:
            try:verify_signature(role['identity'],payload['label'],role['body'],proof.get('signature'));good=True
            except (ValueError,TypeError,KeyError):pass
        rows.append({'role':role['party'],'concept':role.get('concept'),'identity':deepcopy(role['identity']),
                     'status':'VALID_ROLE_SIGNATURE' if good else 'INVALID_ROLE_SIGNATURE' if candidates else 'MISSING_ROLE_SIGNATURE'})
    return {'required':len(rows),'valid_required':sum(r['status']=='VALID_ROLE_SIGNATURE' for r in rows),
            'missing_or_invalid':[r for r in rows if r['status']!='VALID_ROLE_SIGNATURE'],
            'complete_proof_set':'VERIFIED' if verified else 'NOT_VERIFIED; INDIVIDUAL_ROLE_COUNTS_ARE_DIAGNOSTIC_ONLY'}

def _cid_reference(value):
    # Exact returned CIDv1, not a lookup alias or an invariant terms hash.
    need(type(value) is str and re.fullmatch(r'bafkrei[a-z2-7]{52}',value),'REVIEW_BILATERAL_CID')

def _bilateral_fields(row):
    _fields(row,('id','kind','envelope','expected_id','expected_current_id'),('id','kind','envelope','expected_id'))
    _name(row['id']);need(row['kind']=='BILATERAL' and type(row['envelope']) is dict,'REVIEW_BILATERAL_FIELDS')
    _cid_reference(row['expected_id'])
    if 'expected_current_id' in row:_cid_reference(row['expected_current_id'])

def _bilateral_agreement(row):
    """Verify the retained profile in place. Never convert it or observe funds.

    ExchangeTools has no adopted bilateral provider capability. A carried
    receipt therefore remains a signature claim even if another host observed
    it. No request field, attribute or callback installs that missing trust.
    """
    from covenant_agent import envelope as bilateral, bilateral_v2
    _bilateral_fields(row);env=row['envelope']
    need(env.get('profile') in (bilateral.PROFILE,bilateral_v2.PROFILE),'REVIEW_BILATERAL_PROFILE')
    checked=bilateral.verify(env)
    need(checked['ok'],'REVIEW_BILATERAL_'+_code(ValueError(checked['code'])))
    need(checked['cid']==row['expected_id'],'REVIEW_BILATERAL_EXPECTED_ENVELOPE')
    v2=env['profile']==bilateral_v2.PROFILE;parties=env['parties'];terms=env['terms']
    adopted=checked['verdict']!='PROPOSED'
    role_rows=[{'role':role,'identity':identity,
                'basis':'EXACT_AGREEMENT_ROLE_FROM_VERIFIED_INPUT' if adopted else 'PROPOSED_ROLE_NOT_COUNTERPARTY_ADOPTED',
                'current_authority':'UNKNOWN','execution_authorized':False} for role,identity in sorted(parties.items())]
    missing=[] if adopted else [{'role':'counterparty','identity':parties['counterparty'],'status':'MISSING_ROLE_SIGNATURE'}]
    progress={'required':2,'valid_required':2 if adopted else 1,'missing_or_invalid':missing,
              'complete_proof_set':'VERIFIED' if adopted else 'NOT_VERIFIED; COUNTERPARTY_ASSENT_REQUIRED'}
    deliveries=[{'signer':d['signer'],'content_hash':d['content_hash'],'content_cid':d['content_cid'],
                 **({'claimed_at':d['body']['at']} if v2 else {})} for d in env['deliveries']]
    dispute=None
    if env['dispute'] is not None:
        original=env['dispute'];dispute={'evidence_hash':original['evidence_hash'],
            'opener':original['opening']['signer'] if v2 else original['opener'],
            'primary':None,'appeal':None,'merits':'NOT_ESTABLISHED'}
        for key in ('decision','appeal') if v2 else ('decision',):
            decision=original.get(key)
            if decision is not None:
                body=decision['body'] if v2 else decision
                dispute['primary' if key=='decision' else 'appeal']={
                    'signer':decision['signer'],'result':body['result'],'evidence_hash':body['evidence_hash'],
                    **({k:body[k] for k in ('paid_amount','parent','at')} if v2 else {})}
        if v2:dispute['claimed_opened_at']=original['opening']['body']['at']
    receipt=None
    if env['settlement'] is not None:
        original=env['settlement'];body=original['body'] if v2 else original
        action=body['action'];paid=body['paid_amount'] if v2 else 0 if action=='REFUND_PRINCIPAL' else terms['quantity']
        receipt={'action':action,'amount':terms['quantity'],'paid_amount_claim':paid,
            'refunded_amount_claim':body['refunded_amount'] if v2 else terms['quantity']-paid,
            'unit':terms['unit'],'payer':parties['principal'],'payee':parties['counterparty'],
            'authorized_by':body['authorized_by'],'basis':'PROFILE_VERIFIED_RECEIPT_CLAIM; FUNDS_NOT_OBSERVED',
            'funds_observed':False,'external_payment_observed':False,
            **({k:body[k] for k in ('at','decision','settlement_authority')} if v2 else {})}
    agreement_hash=bilateral_v2.identifier(env) if v2 else bilateral.escrow_id(env)
    current={'status':'UNKNOWN; NO_INDEPENDENT_CURRENTNESS_PROVIDER',
             'matches':None if 'expected_current_id' not in row else checked['cid']==row['expected_current_id'],
             'basis':'CALLER_REFERENCE_COMPARISON_ONLY; NO_GLOBAL_LATEST_OR_CURRENT_AUTHORITY'}
    result={'item':row['id'],'id':checked['cid'],'kind':'BILATERAL','profile':env['profile'],
        'agreement_hash':agreement_hash,
        'agreement_hash_basis':'BILATERAL_0.2_SIGNED_AGREEMENT_ID' if v2 else 'HISTORICAL_0.1_ESCROW_ID_OF_EXACT_ASSENT_BODY',
        'status':'VERIFIED' if adopted else 'AWAITING_ASSENT',
        'assent':'EXACT_REQUIRED_SIGNATURES_VERIFIED' if adopted else 'COUNTERPARTY_ASSENT_MISSING',
        'parties':deepcopy(parties),'roles':role_rows,'assent_progress':progress,'currentness':current,
        'current_authority':'UNKNOWN','funds_observed':False,'provider_status':'NOT_CONFIGURED_IN_COORDINATION_REVIEW',
        'verification':{k:checked[k] for k in ('ok','verdict','code','complete','expiry_checked')},
        'terms_summary':{k:terms[k] for k in ('task_hash','quantity','unit','rail','deadline','challenge_window','timeout')},
        'lifecycle':{'state':checked['verdict'],'deliveries':deliveries,'dispute':dispute,'signed_receipt':receipt},
        'remaining_obligations':'UNKNOWN; NO_PROSE_OBLIGATION_EXTRACTION_OR_PAYMENT_OBSERVATION',
        'statement_scope':'EXACT_HISTORICAL_PROFILE_VERIFICATION; NO_WORLD_TRUTH_LEGAL_DISCHARGE_CURRENT_AUTHORITY_OR_PAYMENT_OBSERVATION',
        'execution_authorized':False,'ledger_touched':False,'chain_ledger_touched':False}
    return result,env

def _agreement(row,case_version=VERSION):
    if case_version in (BILATERAL_VERSION,PERFORMANCE_VERSION) and type(row) is dict and row.get('kind')=='BILATERAL':
        return _bilateral_agreement(row)
    _fields(row,('id','kind','bundle','module','order','context','approvals','expected_id','expected_closure','expected_current_id','reference','description'),('id','kind'))
    _name(row['id']);need(type(row['kind']) is str,'REVIEW_AGREEMENT_KIND');kind=row['kind']
    if kind=='REFERENCE':
        _fields(row,('id','kind','reference','description'),('id','kind','reference'))
        return {'item':row['id'],'kind':kind,'reference':deepcopy(row['reference']),'status':'DECLARED_REFERENCE_ONLY','parties':{},'assent':'NOT_VERIFIED','execution_authorized':False},None
    need(kind in ('EXTERNAL','CONCEPT','ORDER','LEGAL'),'REVIEW_AGREEMENT_KIND')
    required={'id','kind','expected_id','approvals'}
    required|={'order'} if kind=='ORDER' else {'module','context'} if kind=='LEGAL' else {'bundle','context','expected_closure'}
    need(required<=set(row),'REVIEW_AGREEMENT_REQUIRED');_hash(row['expected_id'])
    base={'item':row['id'],'id':row['expected_id'],'kind':kind,'parties':{},'assent':'NOT_VERIFIED','status':'REFUSED','execution_authorized':False}
    if kind=='ORDER':
        obj=row['order'];marketplace.validate(obj);need(marketplace.identifier(obj)==row['expected_id'],'MARKETPLACE_EXPECTED_ORDER')
        prepared=marketplace.order_review(obj)['prepared'];payload=prepared['assent_payload'];parties={r['party']:r['identity'] for r in payload['required_assents']};context=obj['data']['context']
        check=lambda:marketplace.verify_order(obj,row['approvals'],row['expected_id'],row.get('expected_current_id'))
    elif kind=='LEGAL':
        obj=row['module'];legal_composition.validate(obj);need(legal_composition.identifier(obj)==row['expected_id'],'LEGAL_EXPECTED_MODULE');context=row['context'];parties=obj['parties'];payload=legal_composition.assent_payload(obj,context)
        check=lambda:legal_composition.verify_assents(obj,context,row['approvals'],row['expected_id'])
    else:
        bundle=row['bundle'];_fields(bundle,('root','concepts','frames','artifacts'),('root','concepts','frames','artifacts'))
        payload=concepts.assent_payload(**bundle,context=row['context']);need(bundle['root']==row['expected_id'],'CONCEPT_EXPECTED_ROOT');need(payload['body']['closure']==row['expected_closure'],'CONCEPT_EXPECTED_CLOSURE')
        obj=next(c for c in bundle['concepts'] if concepts.identifier(c)==bundle['root']);parties=obj['parties'];context=row['context']
        # Unreferenced carrier material cannot select a different verifier for
        # the exact signed meaning. Only declared transitive artifacts count.
        declared={(a['kind'],a['id']) for a in concepts.resolve(**bundle)['manifest']['artifacts']}
        has_external=any(a['kind']=='capsule' and ('capsule',concepts.artifact_id(a['kind'],a['value'])) in declared and a['value'].get('language')==external.VERSION for a in bundle['artifacts'])
        if kind=='EXTERNAL' or has_external:
            check=lambda:external.verify(bundle,context,row['approvals'],row['expected_id'],row['expected_closure'],row.get('expected_current_id'))
        else:check=lambda:concepts.verify_assents(**bundle,context=context,approvals=row['approvals'],expected_id=row['expected_id'],expected_closure=row['expected_closure'])
    base.update(context=context,parties=deepcopy(parties),supersedes=obj.get('supersedes'),currentness=_current(row['expected_id'],row.get('expected_current_id')),
                required_assent=deepcopy(payload),statement_scope='EXACT_DECLARED_MEANING; FACTS_AND_LEGAL_EFFECT_NOT_ESTABLISHED')
    result=_attempt(check);base['verification']=result
    if result.get('status')=='REFUSED':
        base['status']='AWAITING_ASSENT' if not row['approvals'] else 'REFUSED';base['code']=result['code']
    else:base.update(status='VERIFIED',assent='EXACT_REQUIRED_SIGNATURES_VERIFIED')
    base['assent_progress']=_assent_progress(payload,row['approvals'],base['status']=='VERIFIED')
    if base['assent_progress']['required']==0:
        # A vacuously complete native proof set is not evidence of assent.
        # Retain the historical native verification result, but exclude this
        # unsigned object from signed-field bindings and finance projections.
        base.update(status='NO_DECLARED_SIGNING_ROLES',assent='NOT_ESTABLISHED',code='REVIEW_NO_DECLARED_SIGNING_ROLES')
        base['assent_progress']['complete_proof_set']='NOT_VERIFIED; NO_DECLARED_SIGNING_ROLES'
    return base,obj

def _agreements(rows,case_version=VERSION):
    result=[];objects={};verified=[];seen=set()
    for row in rows:
        try:
            summary,obj=_agreement(row,case_version)
            if obj is not None and summary['status']=='VERIFIED':objects[row['expected_id']]=(row,obj)
        except (ValueError,TypeError,KeyError,UnicodeError) as error:
            summary={'item':row['id'],'kind':row.get('kind') if type(row.get('kind')) is str else 'INVALID','status':'REFUSED','code':_code(error),'execution_authorized':False}
        result.append(summary)
        if summary['status']=='VERIFIED' and summary['id'] not in seen:verified.append(summary);seen.add(summary['id'])
    return result,objects,verified

def authorization_scopes(tools,case,authorization,expected_id=None,expected_domain=None):
    """Find eligible exact verified roots without choosing an obligation."""
    from .coordination_finance import _AUTHORIZATION_LABEL
    validate(case);ref=identifier(case);canonical(authorization)
    if expected_id is not None:_hash(expected_id);need(ref==expected_id,'REVIEW_EXPECTED_CASE')
    _fields(authorization,('label','body','signature'),('label','body','signature'))
    need(authorization['label']==_AUTHORIZATION_LABEL,'REVIEW_AUTHORIZATION_PROFILE')
    body=authorization['body'];_fields(body,('domain','agreement','closure','effect','payment','context'),('domain','agreement','closure','effect','payment','context'))
    for k in ('domain','agreement','closure','effect','context'):_hash(body[k])
    owner_domain=getattr(getattr(tools,'network',None),'domain',None)
    if expected_domain is not None:_hash(expected_domain)
    domain=expected_domain if expected_domain is not None else owner_domain
    need(domain is not None,'REVIEW_AUTHORIZATION_DOMAIN_REQUIRED')
    need(body['domain']==domain and (owner_domain is None or owner_domain==domain),'REVIEW_AUTHORIZATION_DOMAIN')
    request=body['payment'];fields=('action','payer','recipient','unit','amount','maximum_fee');_fields(request,fields,fields)
    need(request['action']=='TRANSFER','REVIEW_AUTHORIZATION_PROFILE')
    _hash(request['payer']);_hash(request['recipient']);_text(request['unit'],128)
    need(request['payer']!=request['recipient'] and type(request['amount']) is int and 0<request['amount']<=2**53-1 and type(request['maximum_fee']) is int and 0<=request['maximum_fee']<=2**53-1,'REVIEW_AUTHORIZATION_PAYMENT')
    verify_signature(request['payer'],authorization['label'],body,authorization['signature'])
    _,_,verified=_agreements(case['agreements'],case['version']);matches=[]
    for row in verified:
        scope=row.get('required_assent',{}).get('body',{});parties={canonical(p) for p in row['parties'].values()}
        if scope.get('semantics')==concepts.SEMANTICS and (scope.get('root'),scope.get('closure'),scope.get('context'))==(body['agreement'],body['closure'],body['context']) and canonical(request['payer']) in parties and canonical(request['recipient']) in parties:
            matches.append({'agreement':row['id'],'item':row['item'],'kind':row['kind'],'status':'EXACT_VERIFIED_ASSENT_SCOPE_MATCH','signed_root':body['agreement'],'signed_closure':body['closure'],'context':body['context']})
    return {'case_id':ref,'status':'MATCHING_VERIFIED_SCOPES' if matches else 'NO_MATCHING_VERIFIED_SCOPE',
            'authorization_hash':_digest(authorization),'payer_signature':'VERIFIED_FOR_THIS_EXACT_AUTHORIZATION',
            'effect_id':body['effect'],'domain':domain,'payment_request':deepcopy(request),'matching_agreements':matches,
            'next_action':('Explicitly choose the matching outer agreement for payment.authorization_agreement and separately choose the obligation; review then checks the actual receipt, fee cap and intent.' if matches else 'Obtain the exact fully adopted agreement and valid required assents matching this payer authorization, or obtain a new correctly scoped authorization. No existing obligation or receipt is selected.'),
            'obligation_selected':False,'receipt_observed':False,'adoption_or_spending_authority':'NOT_GRANTED',
            'signature_created':False,'recorded':False,'execution_authorized':False}

def _pointer(value,path):
    need(type(path) is str and len(path)<=1024 and (path=='' or path.startswith('/')),'REVIEW_BINDING_POINTER')
    current=value
    for raw in ([] if path=='' else path[1:].split('/')):
        need(not re.search(r'~(?![01])',raw),'REVIEW_BINDING_POINTER');part=raw.replace('~1','/').replace('~0','~')
        if type(current) is dict:need(part in current,'REVIEW_BINDING_PATH_MISSING');current=current[part]
        elif type(current) is list:
            need(re.fullmatch('0|[1-9][0-9]*',part) is not None,'REVIEW_BINDING_POINTER');index=int(part);need(index<len(current),'REVIEW_BINDING_PATH_MISSING');current=current[index]
        else:raise ValueError('REVIEW_BINDING_PATH_MISSING')
    return current

def _source_document(row,obj,alias):
    need(row['kind'] in ('EXTERNAL','CONCEPT'),'REVIEW_BINDING_NOT_BYTE_AGREEMENT')
    root=obj;need(alias in root['artifacts'],'REVIEW_BINDING_DOCUMENT');reference=root['artifacts'][alias];need(reference['kind']=='capsule','REVIEW_BINDING_DOCUMENT')
    from covenant_language.capsules import capsule_id
    objects={capsule_id(a['value']):a for a in row['bundle']['artifacts'] if a['kind']=='capsule'}
    cap=objects[reference['id']]['value'];document={'version':external.VERSION,'root':reference['id'],'artifacts':[objects[k] for k in sorted({reference['id'],*cap['dependencies']})]}
    return external.inspect(document,reference['id'])

def open_source(tools,case,agreement,document='terms',expected_id=None,encoding='UTF8'):
    """Explicit selected source disclosure, also available before any assent."""
    validate(case);ref=identifier(case)
    if expected_id is not None:_hash(expected_id);need(ref==expected_id,'REVIEW_EXPECTED_CASE')
    _name(agreement);_text(document,128);need(encoding in ('UTF8','BASE64'),'REVIEW_SOURCE_ENCODING')
    row=next((r for r in case['agreements'] if r['id']==agreement),None)
    need(row is not None,'REVIEW_SOURCE_AGREEMENT_MISSING')
    checked,obj=_agreement(row,case['version']);need(obj is not None,'REVIEW_BINDING_NOT_BYTE_AGREEMENT')
    opened=_source_document(row,obj,document);raw=base64.b64decode(opened['source_base64'],validate=True)
    try:source=raw.decode('utf-8') if encoding=='UTF8' else opened['source_base64']
    except UnicodeError:raise ValueError('REVIEW_SOURCE_NOT_UTF8_CHOOSE_BASE64') from None
    return {'case_id':ref,'agreement':agreement,'agreement_id':checked.get('id'),'assent_status':checked['status'],
            'document':document,'document_id':opened['id'],'source_sha256':hashlib.sha256(raw).hexdigest(),
            'encoding':encoding,'source':source,'disclosure':'EXPLICIT_SELECTED_SOURCE; NOT_ENCRYPTION_OR_PUBLICATION',
            'signature_created':False,'recorded':False,'execution_authorized':False}

def open_object(tools,case,agreement,path='',expected_id=None):
    """Explicitly open a typed root/value; do not invent external document bytes."""
    validate(case);ref=identifier(case)
    if expected_id is not None:_hash(expected_id);need(ref==expected_id,'REVIEW_EXPECTED_CASE')
    _name(agreement);row=next((r for r in case['agreements'] if r['id']==agreement),None)
    need(row is not None,'REVIEW_SOURCE_AGREEMENT_MISSING')
    checked,obj=_agreement(row,case['version']);need(obj is not None,'REVIEW_SOURCE_TYPED_OBJECT_REQUIRED')
    selected=_pointer(obj,path)
    return {'case_id':ref,'agreement':agreement,'agreement_id':checked['id'],'assent_status':checked['status'],
            'path':path,'value_sha256':_digest(selected),'encoding':'CANONICAL_JSON','source':canonical(selected).decode('ascii'),
            'opening':'EXACT_TYPED_ROOT_VALUE; NOT_EXTERNAL_SOURCE_BYTES_OR_LEGAL_INTERPRETATION',
            'canonicalization':'COORDINATION_JSON_PRESENTATION; AGREEMENT_ID_RETAINS_ITS_NATIVE_PROFILE',
            'disclosure':'EXPLICIT_SELECTED_VALUE; NOT_ENCRYPTION_OR_PUBLICATION',
            'signature_created':False,'recorded':False,'execution_authorized':False}

def _json_source(row,obj,alias):
    opened=_source_document(row,obj,alias);raw=base64.b64decode(opened['source_base64'],validate=True)
    def pairs(items):
        v={}
        for k,x in items:need(k not in v,'REVIEW_BINDING_DUPLICATE_JSON_KEY');v[k]=x
        return v
    def bad(_):raise ValueError('REVIEW_BINDING_EXACT_JSON_ONLY')
    try:value=json.loads(raw,object_pairs_hook=pairs,parse_float=bad,parse_constant=bad)
    except (UnicodeError,json.JSONDecodeError,RecursionError):raise ValueError('REVIEW_BINDING_EXACT_JSON_ONLY') from None
    canonical(value);return value

def _bindings(items,objects,verified):
    allowed={v['id'] for v in verified};out=[];opened={}
    for item in items:
        try:
            _fields(item,('id','agreement','document','path','expected'),('id','agreement','path','expected'))
            need(item['agreement'] in allowed,'REVIEW_BINDING_AGREEMENT_NOT_VERIFIED');row,obj=objects[item['agreement']]
            value=_json_source(row,obj,item['document']) if 'document' in item else obj
            actual=_pointer(value,item['path']);match=canonical(actual)==canonical(item['expected'])
            out.append({'id':item['id'],'agreement':item['agreement'],'path':item['path'],'document':item.get('document'),'status':'EXACT_SIGNED_FIELD_MATCH' if match else 'MISMATCH','expected_value_hash':_digest(item['expected']),'opened_value_hash':_digest(actual),'interpretation':'LITERAL_VALUE_OPENING_NOT_LEGAL_INTERPRETATION','execution_authorized':False})
            if match:opened[item['id']]={'value':actual,'agreement':item['agreement']}
        except (ValueError,TypeError,KeyError,UnicodeError) as error:out.append({'id':item['id'],'status':'REFUSED','code':_code(error),'execution_authorized':False})
    return out,opened

def _links(items,known,opened,case_value,objects,verified,decisions,disputes=()):
    output=[];obligations={v['id']:v for v in case_value.get('obligations',[])};evidence={v['id']:v for v in case_value.get('evidence',[])}
    agreement_aliases={v['item']:v['id'] for v in verified if v['status']=='VERIFIED'};decision_items={v['id']:v['result'] for v in decisions}
    dispute_items={v['id']:v for v in disputes}
    for item in items:
        try:
            _fields(item,('from','to','relation','document'),('from','to','relation'));_text(item['relation'],128)
            need(type(item['from']) is str and type(item['to']) is str,'REVIEW_LINK_TARGET')
            need('document' not in item or item['relation']=='decision_adoption','REVIEW_LINK_FIELDS')
            need(item['from'] in known and item['to'] in known,'REVIEW_LINK_TARGET_MISSING')
            result={**deepcopy(item),'status':'DECLARED_ASSOCIATION','authority':'NONE','interpretation':'CALLER_CHOSEN_RELATIONSHIP_NOT_AUTOMATIC_SEMANTICS'}
            if item['from'].startswith('binding:') and item['relation'] in ('amount','payer','payee','asset','evidence_root'):
                source=item['from'].split(':',1)[1];need(source in opened,'REVIEW_LINK_BINDING_NOT_MATCHED');bound=opened[source]
                if item['relation']=='evidence_root':
                    need(item['to'].startswith('evidence:'),'REVIEW_LINK_KIND');target=evidence[item['to'].split(':',1)[1]]
                    need(target.get('agreement')==bound['agreement'],'REVIEW_LINK_AGREEMENT_MISMATCH');expected=target['expected_statement']['root']
                else:
                    need(item['to'].startswith('obligation:'),'REVIEW_LINK_KIND');target=obligations[item['to'].split(':',1)[1]]
                    need(target['agreement']==bound['agreement'],'REVIEW_LINK_AGREEMENT_MISMATCH');expected=target[item['relation']]
                need(canonical(bound['value'])==canonical(expected),'REVIEW_LINK_VALUE_MISMATCH')
                result.update(status='EXACT_SIGNED_LITERAL_LINK_CHECKED',interpretation='FIELD_VALUE_AND_TARGET_MATCH; LEGAL_OR_PHYSICAL_MEANING_NOT_INFERRED')
            elif item['relation'] in ('case_reference','finding_reference'):
                need(item['from'].startswith('binding:') and item['to'].startswith('dispute:'),'REVIEW_LINK_KIND')
                source=item['from'].split(':',1)[1];need(source in opened,'REVIEW_LINK_BINDING_NOT_MATCHED')
                bound=opened[source];target=dispute_items[item['to'].split(':',1)[1]]
                need(target['result'].get('status')!='REFUSED','REVIEW_LINK_DISPUTE_UNAVAILABLE')
                need(target.get('settlement_agreement')==bound['agreement'],'REVIEW_LINK_AGREEMENT_MISMATCH')
                expected=target['result'].get('case_event' if item['relation']=='case_reference' else 'selected_finding_event')
                need(expected is not None and canonical(bound['value'])==canonical(expected),'REVIEW_LINK_VALUE_MISMATCH')
                result.update(status='EXACT_SIGNED_DISPUTE_REFERENCE_CHECKED',interpretation='THE_VERIFIED_SETTLEMENT_SOURCE_NAMES_THIS_EVENT; NO_LEGAL_EXTINGUISHMENT_OR_TRANSFER_AUTHORITY_INFERRED')
            elif item['relation']=='decision_adoption':
                need(item['from'].startswith('agreement:') and item['to'].startswith('decision:'),'REVIEW_LINK_KIND')
                alias=item['from'].split(':',1)[1];need(alias in agreement_aliases,'REVIEW_LINK_AGREEMENT_NOT_VERIFIED')
                packet=decision_items[item['to'].split(':',1)[1]];need('snapshot' in packet,'REVIEW_LINK_DECISION_UNAVAILABLE')
                row,obj=objects[agreement_aliases[alias]]
                actual=_json_source(row,obj,item.get('document','decision'))
                need(canonical(actual)==canonical(packet['snapshot']),'REVIEW_LINK_DECISION_SNAPSHOT_MISMATCH')
                result.update(status='EXACT_DECISION_SNAPSHOT_ADOPTION_LINK_CHECKED',snapshot_id=packet['snapshot_id'],
                              interpretation='THE_VERIFIED_AGREEMENT_CONTAINS_THIS_EXACT_DECISION_SNAPSHOT; NO_SPENDING_OR_OTHER_AUTHORITY_INFERRED')
            output.append(result)
        except (ValueError,TypeError,KeyError) as error:output.append({**{k:v for k,v in item.items() if k in ('from','to','relation') and type(v) is str},'status':'REFUSED','code':_code(error),'authority':'NONE'})
    return output

def _disputes(tools,value,verified):
    from .coordination_disputes import dispute
    ids={v['id'] for v in verified};obligations={o['id'] for o in value.get('obligations',[])};rows=[]
    for item in value.get('disputes',[]):
        def checked():
            _fields(item,('id','case_event','finding_event','agreement','settlement_agreement','obligation','group','required_parties','designated_arbitrator','excluded_obligations','expected_scope','expected_heads','expected_target'),('id','case_event'))
            for key in ('agreement','settlement_agreement'):
                if key in item:_hash(item[key]);need(item[key] in ids,'REVIEW_DISPUTE_AGREEMENT_NOT_VERIFIED')
            if 'obligation' in item:need(item['obligation'] in obligations,'REVIEW_DISPUTE_OBLIGATION_MISSING')
            excluded=item.get('excluded_obligations',[])
            need(type(excluded) is list and len(excluded)<=64 and all(type(x) is str and x in obligations for x in excluded) and len(excluded)==len(set(excluded)),'REVIEW_DISPUTE_EXCLUSIONS')
            need(item.get('obligation') not in excluded,'REVIEW_DISPUTE_SCOPE_CONFLICT')
            if 'expected_scope' in item:_text(item['expected_scope'],4096)
            result=dispute(tools,item['case_event'],item.get('finding_event'),item.get('group'),item.get('required_parties'),item.get('designated_arbitrator'),item.get('expected_heads',value.get('expected_heads')))
            if 'expected_target' in item:_hash(item['expected_target']);need(result['target_event']==item['expected_target'],'REVIEW_DISPUTE_TARGET_MISMATCH')
            return result
        row={'id':item['id'],'result':_attempt(checked),'scope_basis':'CALLER_CHOSEN_ASSOCIATIONS; NO_ARBITRARY_PROSE_INTERPRETATION',
             'payment_or_release_authorized':False}
        row.update({k:deepcopy(item[k]) for k in ('agreement','settlement_agreement','obligation','excluded_obligations','expected_scope') if k in item})
        rows.append(row)
    return rows

def _reconcile_source_links(payments,links,agreements):
    """Keep declared arithmetic visible but withhold a conflicted review balance."""
    for row in payments.get('declared_obligations',[]):
        mapped=[link for link in links if link.get('to')=='obligation:'+row['id'] and
                link.get('from','').startswith('binding:') and link.get('relation') in ('amount','payer','payee','asset')]
        refused=[link for link in mapped if link['status']=='REFUSED']
        row['source_binding_status']='CONFLICT' if refused else 'EXACT_SIGNED_LITERAL_LINK_CHECKED' if mapped else 'CALLER_DECLARED_BASIS'
        historical=any(a.get('id')==row['agreement'] and a.get('currentness',{}).get('matches') is False for a in agreements)
        row['current_reference_status']='DIFFERS_FROM_CALLER_REFERENCE' if historical else 'INSPECT_AGREEMENT_CURRENTNESS'
        if refused or historical:
            row['declared_remaining_in_supplied_scope']=row['remaining_in_supplied_scope']
            row['remaining_in_supplied_scope']=None;row['unknown']=True
            row['status']='SOURCE_BINDING_CONFLICT' if refused else 'HISTORICAL_REFERENCE_CONFLICT'
            row['warnings'].append('REVIEW_REMAINDER_WITHHELD_UNTIL_SIGNED_SOURCE_OR_CURRENT_REFERENCE_CONFLICT_IS_RESOLVED')
    return payments

def _authority(tools,agreements,**parameters):
    # A case policy id is a local graph alias. The standalone authority helper's
    # optional id is an actual policy content pin; never pass the alias as that.
    from . import coordination_privacy as privacy
    policies=[]
    for row in parameters.pop('policies',None) or []:
        if 'policy' in row:
            _fields(row,('id','policy'),('policy',));policies.append(row['policy'])
        else:policies.append(row)
    result=privacy.authority(tools,agreements,policies=policies,**parameters)
    exact_roles={(a['id'],a['kind'],role,canonical(identity)) for a in agreements for role,identity in a['parties'].items()}
    for role in result.get('agreement_roles',[]):
        if (role['agreement'],role['kind'],role['role'],canonical(role['identity'])) in exact_roles:
            role['basis']='EXACT_AGREEMENT_ROLE_FROM_VERIFIED_INPUT'
    return result

def _overview(value,agreements,authority,evidence,payments,links,decisions,recoveries):
    primary=next((a for a in agreements if a['item']==value.get('primary')),None)
    selected=None if primary is None else {k:deepcopy(primary[k]) for k in ('item','id','status','currentness','assent_progress') if k in primary}
    financial={r['id']:r for r in payments.get('declared_obligations',[])};money=[]
    for original in value.get('obligations',[]):
        row=financial.get(original['id'],{});refunds=[o.get('payer_refund_not_counted',0) for o in payments.get('observations',[])
                if o.get('obligation')==original['id'] and o.get('attributed_payment') is not None]
        money.append({'id':original['id'],'label':original.get('label',original['id']),'agreement':original.get('agreement'),
            'unit':original.get('asset',{}).get('unit') if type(original.get('asset')) is dict else None,
            'declared_amount':original.get('amount'),'paid_in_supplied_scope':row.get('observed_paid_in_supplied_scope'),
            'refunded_to_payer_in_supplied_scope':sum(refunds) if row and sum(refunds)<=2**53-1 else None,
            'remaining_in_supplied_scope':row.get('remaining_in_supplied_scope'),
            'source_binding_status':row.get('source_binding_status','UNAVAILABLE'),
            'status':row.get('status','UNAVAILABLE'),'basis':'SUPPLIED_SCOPE_ONLY; REFUNDS_DO_NOT_PAY_THE_PAYEE'})
    decision_rows=[]
    for item in decisions:
        packet=item['result'];checked=[l for l in links if l.get('to')=='decision:'+item['id'] and l.get('relation')=='decision_adoption']
        decision_rows.append({'id':item['id'],'snapshot_id':packet.get('snapshot_id'),'winner':packet.get('tally',{}).get('winner'),
            'quorum_met':packet.get('tally',{}).get('quorum_met'),
            'adoption_link':'EXACT_SNAPSHOT_CHECKED' if any(l['status']=='EXACT_DECISION_SNAPSHOT_ADOPTION_LINK_CHECKED' for l in checked) else 'CONFLICT' if checked else 'NOT_SUPPLIED'})
    recovery_rows=[]
    for item in recoveries:
        packet=item['result'];recovery_rows.append({'id':item['id'],'valid_branches':packet.get('valid_branches'),
            'invalid_branches':packet.get('invalid_branches'),'conflicts':[{'actor':f['actor'],'sequence':f['sequence'],'event_ids':f['event_ids']} for f in packet.get('same_key_forks',[])],
            'chosen_policy_reference':item.get('policy_reference'),'fork_choice':'NONE'})
    return {'selected_agreement':selected,'selection_basis':'EXPLICIT_CASE_PRIMARY; NO_GLOBAL_LATEST_INFERENCE',
        'verified_agreements':sum(a['status']=='VERIFIED' for a in agreements),
        'unverified_agreements':sum(a['status']!='VERIFIED' for a in agreements),
        'assent':[{'item':a['item'],'status':a['status'],**deepcopy(a.get('assent_progress',{}))} for a in agreements],
        'money':money,'evidence_verified':sum(i.get('verified') is True for i in evidence.get('items',[])),
        'evidence_unverified':len(value.get('evidence',[]))-sum(i.get('verified') is True for i in evidence.get('items',[])),
        'evidence_count_scope':'TOP_LEVEL_ADOPTED_PROOF_ROWS_ONLY; PERFORMANCE_REFERENCES_COUNTED_SEPARATELY',
        'section_status':{name:packet.get('status','CHECKED_IN_SUPPLIED_SCOPE') for name,packet in [('authority',authority),('evidence',evidence),('payments',payments)]},
        'authority_grants':[{'id':g['id'],'status':g.get('status'),'capability':g.get('capability')} for g in authority.get('grants',[])],
        'group_roles':{'status':authority.get('group_authority',{}).get('status','UNAVAILABLE'),
                       'roles':[{k:r[k] for k in ('holder','name','status','permissions')} for r in authority.get('group_authority',{}).get('roles',[])],
                       'scope':'LOCAL_GROUP_ONLY; SEPARATE_FROM_GRANTS_AND_PAYMENT_AUTHORITY'},
        'escrow_policies':[{'policy':p['policy'],'status':p['status'],'funding_participants':len(p['funding_scope']['eligible_signers']),
                           'payout_threshold':p['payout_scope']['threshold']} for p in authority.get('escrow_scopes',[])],
        'authority_grants_requiring_attention':[g['id'] for g in authority.get('grants',[]) if g.get('status') in ('REFUSED','UNAVAILABLE')],
        'unresolved_connections':sum(l['status']=='REFUSED' for l in links),
        'decisions':decision_rows,'recovery':recovery_rows,'execution_authorized':False}

def _obligation_coverage(value, agreements, objects):
    """A local inventory, not a promise extractor or discharge adjudicator."""
    rows=[]
    for agreement in agreements:
        pin=agreement.get('id')
        row={'item':agreement['item'],'agreement':pin,'kind':agreement['kind'],
             'status':'UNASSESSED','all_obligations_complete':None,
             'prose':'UNASSESSED; POSSIBLE_WRITTEN_DUTIES_NOT_EXTRACTED',
             'nonmonetary':'ONLY_CALLER_LISTED_PERFORMANCE_DUTIES',
             'history':'EXACT_SUPPLIED_OBJECT_ONLY; OTHER_HOSTS_AND_GLOBAL_CURRENTNESS_UNKNOWN'}
        if agreement['status']=='VERIFIED' and agreement['kind']=='LEGAL' and pin in objects:
            row['legal_declarations']=legal_composition._obligation_projection(objects[pin][1])
            row['nonmonetary']='LOCAL_LEGAL_DECLARATIONS_PROJECTED; APPLICABILITY_AND_PERFORMANCE_UNKNOWN'
        if agreement['status']!='VERIFIED':row['nonmonetary']='NOT_PROJECTED; AGREEMENT_NOT_FULLY_VERIFIED'
        rows.append(row)
    return {'agreements':rows,'host':'SUPPLIED_CASE_ONLY; NO_GLOBAL_OBLIGATION_INDEX',
            'profiles':{'agreement_kinds':['EXTERNAL','CONCEPT','ORDER','LEGAL','BILATERAL_0.1_0.2'],
                        'portable_bilateral_0.3':'UNSUPPORTED_IN_THIS_CASE_PROFILE; USE_PORTABLE_OBLIGATION_SUMMARY'},
            'history':'NO_COMPLETE_HISTORY_OR_SUPERSESSION_ASSERTION',
            'financial':'ONLY_EXPLICITLY_DECLARED_FINANCE_ROWS_AND_RECEIPT_ASSOCIATIONS',
            'performance':'ONLY_EXPLICIT_CASE_0.4_CHECKLIST_AND_LOCAL_LEGAL_DECLARATIONS',
            'prose':'UNASSESSED; PAYMENT_AND_PROTOCOL_COMPLETION_DO_NOT_COMPLETE_WRITTEN_DUTIES',
            'all_obligations_complete':None}


def _assurance(value, agreements, authority, evidence, payments, coverage):
    """Independent review dimensions with exact pins and explicit open claims."""
    closures=[]
    for row in coverage['agreements']:
        declaration=row.get('legal_declarations')
        if declaration:
            closures.append({'item':row['item'],**deepcopy(declaration['reference_closure'])})
        else:
            agreement=next(a for a in agreements if a['item']==row['item'])
            closures.append({'item':row['item'],'status':'EXACT_DECLARED_CLOSURE_CHECKED' if agreement.get('required_assent',{}).get('body',{}).get('closure') and agreement['status']=='VERIFIED' else 'NOT_CHECKED',
                             'scope':'NATIVE_DECLARED_REFERENCE_SCOPE_ONLY'})
    def source_version(row):
        if row.get('kind')=='BILATERAL' and type(row.get('envelope')) is dict:return row['envelope'].get('profile')
        if row.get('kind')=='LEGAL' and type(row.get('module')) is dict:return row['module'].get('version')
        if row.get('kind')=='ORDER' and type(row.get('order')) is dict:return row['order'].get('version')
        if row.get('kind') in ('CONCEPT','EXTERNAL') and type(row.get('bundle')) is dict:return concepts.VERSION
        return None
    source_by_item={a['item']:a for a in agreements}
    authority_requested=bool(value.get('grants') or value.get('group') or value.get('policies'))
    return {'version':'covenant-coordination-assurance/0.1',
        'dimensions':{
            'syntax':{'status':'CHECKED','scope':'BOUNDED_CASE_CARRIER; INDIVIDUAL_SOURCE_REFUSALS_REMAIN_VISIBLE'},
            'reference_closure':{'status':'SEE_EACH_AGREEMENT','items':closures},
            'logical_checks':{'status':'NOT_CHECKED','scope':'NO_SATISFIABILITY_TEMPORAL_OR_LEGAL_CONSISTENCY_PROOF'},
            'assent':{'status':'SEE_EACH_AGREEMENT','items':[{'item':a['item'],'status':a['status'],'assent':a.get('assent','NOT_VERIFIED')} for a in agreements]},
            'current_authority':{'status':'REFUSED' if authority.get('status')=='REFUSED' else 'SEE_LOCAL_SCOPED_CHECKS' if authority_requested else 'NOT_REQUESTED',
                                 'scope':'OWNER_INSTALLED_GRANTS_AND_LOCAL_GROUP_ONLY; SIGNATURES_AND_ROLE_NAMES_ARE_NOT_DISPATCH_AUTHORITY'},
            'factual_support':{'status':'REFUSED' if evidence.get('status')=='REFUSED' else 'SCOPED_VERIFIER_RESULTS_ONLY' if value.get('evidence') else 'NOT_REQUESTED','verified_proof_rows':sum(i.get('verified') is True for i in evidence.get('items',[])),
                               'scope':'PROOF_RELATIONS_NOT_PHYSICAL_TRUTH; INVALID_PROOF_DOES_NOT_REFUTE_SUBJECT_CLAIM'},
            'legal_review':{'status':'NOT_CHECKED','scope':'APPLICABLE_LAW_CAPACITY_FORMALITIES_AND_DISCHARGE_UNDETERMINED'},
            'privacy':{'status':'DEFAULT_REVIEW_REDACTION_ONLY','scope':'NO_ENCRYPTION_OR_DISCLOSURE_AUTHORITY_AUDIT; HASHES_MAY_REVEAL_LOW_ENTROPY_INPUTS'},
            'execution':{'status':'NOT_AUTHORIZED','execution_authorized':False}},
        'pins':{'case_id':identifier(value),'case_version':value['version'],
                'agreements':[{'item':r['id'],'kind':source_by_item[r['id']]['kind'],'expected_id':source_by_item[r['id']].get('id'),
                               'profile_version':source_version(r) if source_by_item[r['id']]['status']=='VERIFIED' else None,'context':source_by_item[r['id']].get('context'),
                               'input_hash':_digest(r)} for r in value['agreements']],
                'contexts':sorted({a['context'] for a in agreements if type(a.get('context')) is str}),
                'policies_hash':_digest(value.get('policies',[])),
                'verifier_inputs_hash':_digest(value.get('evidence',[])),
                'verifiers':[{'item':r['id'],'verifier_pin':r.get('verifier') if type(r.get('verifier')) is str and re.fullmatch('[0-9a-f]{64}',r['verifier']) else None,
                              'input_hash':_digest(r)} for r in value.get('evidence',[])],
                'expected_data_heads':deepcopy(value.get('expected_heads')),
                'data_heads_hash':_digest({'expected_heads':value.get('expected_heads'),'payments':value.get('payments',[]),
                                          'bindings':value.get('bindings',[]),'performance':value.get('performance',[])}),
                'owner_observations_hash':_digest({'authority':authority,'evidence':evidence,'payments':payments}),
                'implementation':'covenant_chain.coordination_review/assurance-0.1'},
        'assumptions':['Caller supplies the intended exact case and agreement references.',
                       'Installed owner observations cover only their declared local scope and may change after review.',
                       'Caller reference equality does not establish global currentness or current dispatch authority.'],
        'unchecked_claims':['Unlisted or other-host obligations','Physical performance and external payment truth',
                            'Legal validity enforceability and discharge','Complete history and current global state',
                            'Satisfiability and semantic agreement of prose with executable provisions'],
        'execution_authorized':False}


def review(tools,case,expected_id=None):
    validate(case);ref=identifier(case)
    if expected_id is not None:_hash(expected_id);need(ref==expected_id,'REVIEW_EXPECTED_CASE')
    value=deepcopy(case);agreements,objects,verified=_agreements(value['agreements'],value['version'])
    # Bilateral signature review is separate from native/generic obligation,
    # access and payment adapters. A CID does not install a cross-profile map.
    native_verified=[v for v in verified if v['kind']!='BILATERAL'];ids=[v['id'] for v in native_verified]
    from . import coordination_finance as finance,coordination_privacy as privacy,coordination_collective as collective
    authority=_attempt(_authority,tools,[{'id':v['id'],'kind':v['kind'],'parties':v['parties']} for v in native_verified],grants=value.get('grants'),group=value.get('group'),expected_heads=value.get('expected_heads'),policies=value.get('policies'))
    evidence=_attempt(privacy.evidence,tools,value.get('evidence',[]),ids)
    payment_options={}
    if value['version'] in (EXTENDED_VERSION,BILATERAL_VERSION,PERFORMANCE_VERSION):
        payment_options={'allow_authorizations':True,'agreement_scopes':{v['id']:{**deepcopy(v['required_assent']['body']),'parties':deepcopy(v['parties'])} for v in verified if 'body' in v.get('required_assent',{})},'authorization_domain':getattr(getattr(tools,'network',None),'domain',None)}
    payments=_attempt(finance.payments,tools,value.get('payments',[]),value.get('obligations',[]),ids,**payment_options)
    bindings,opened=_bindings(value.get('bindings',[]),objects,verified)
    nodes=[];known=set()
    for section,prefix in [('agreements','agreement'),('obligations','obligation'),('payments','payment'),('evidence','evidence'),('grants','grant'),('bindings','binding'),('decisions','decision'),('recoveries','recovery'),('disputes','dispute'),('performance','performance')]:
        for row in value.get(section,[]):
            node_id=prefix+':'+row['id'];known.add(node_id)
            reference=row.get('expected_id',row.get('agreement',row.get('effect_id')))
            if reference is not None and type(reference) is not str:
                reference={'content_hash':_digest(reference),'contents':'UNVERIFIED_REFERENCE_VALUE_OMITTED'}
            nodes.append({'id':node_id,'label':row['id'],'kind':prefix,'reference':reference,'outcome':'REVIEW_ASSOCIATION; INSPECT_THE_CHECKED_SECTION'})
    for row in value.get('policies',[]):
        label=row.get('id') if 'policy' in row and 'id' in row else _digest(row)
        _name(label) if not re.fullmatch('[0-9a-f]{64}',label) else None
        node_id='policy:'+label;need(node_id not in known,'REVIEW_DUPLICATE_POLICY');known.add(node_id)
        nodes.append({'id':node_id,'label':label,'kind':'policy','outcome':'SEPARATE_CUSTODY_CONTROLLER_SCOPE; INSPECT_AUTHORITY_REVIEW'})
    decisions=[];recoveries=[]
    for section,function,output in [('decisions',collective.decision,decisions),('recoveries',collective.recovery,recoveries)]:
        for item in value.get(section,[]):
            _fields(item,('id','parameters','policy_reference') if section=='recoveries' else ('id','parameters'),('id','parameters'));need(type(item['parameters']) is dict,'REVIEW_PACKET_PARAMETERS')
            packet={'id':item['id'],'result':_attempt(function,tools,**item['parameters'])}
            if 'policy_reference' in item:
                _text(item['policy_reference'],1024);packet['policy_reference']=item['policy_reference']
                packet['policy_reference_basis']='CALLER_CHOSEN_REFERENCE_ONLY; NOT_EXECUTED_OR_AUTOMATICALLY_AUTHORIZING_RECOVERY'
            output.append(packet)
    disputes=_disputes(tools,value,verified)
    links=_links(value.get('links',[]),known,opened,value,objects,agreements,decisions,disputes)
    payments=_reconcile_source_links(payments,links,agreements)
    overview=_overview(value,agreements,authority,evidence,payments,links,decisions,recoveries)
    if value['version'] in (EXTENDED_VERSION,BILATERAL_VERSION,PERFORMANCE_VERSION):
        overview['disputes']=[{'id':d['id'],'status':d['result'].get('status'),'case_event':d['result'].get('case_event'),
             'selected_finding_event':d['result'].get('selected_finding_event'),'missing_parties':d['result'].get('missing_parties'),
             'readiness':d['result'].get('readiness'),'scope_basis':d['scope_basis'],'payment_or_release_authorized':False} for d in disputes]
    notices=[];actions=[]
    for a in agreements:
        if a['status']!='VERIFIED':
            if a['kind']=='BILATERAL' and value['version'] not in (BILATERAL_VERSION,PERFORMANCE_VERSION):
                action='This case profile does not verify bilateral rows. Explicitly adopt a new case /0.3 and retain the original bilateral envelope and exact returned CID; do not relabel old signatures.'
            elif a['status']=='AWAITING_ASSENT':
                action='Review the exact required assent and obtain missing valid role signatures.'
            elif a['status']=='NO_DECLARED_SIGNING_ROLES':
                action='Prepare a new agreement with the intended signing roles, review it and obtain their explicit assent. Preserve the unsigned historical object.'
            elif a['kind'] not in ('EXTERNAL','CONCEPT','ORDER','LEGAL','BILATERAL'):
                action='This is an unsupported agreement kind or an unverified reference. Select a supported typed verification route; additional signatures do not establish that mapping.'
            else:
                action='Correct the exact profile, source fields, retained identifier or failed signature check before relying on this agreement.'
            actions.append({'section':'agreements','item':a['item'],'action':action,'status':a['status']})
        if a.get('currentness',{}).get('matches') is False:notices.append('A historically valid agreement differs from the caller-retained current reference.')
        if a.get('supersedes'):notices.append('Successor signatures do not establish a prior or removed party’s amendment authorization.')
    for name,block in [('authority',authority),('evidence',evidence),('payments',payments)]:
        if block.get('status')=='REFUSED':actions.append({'section':name,'action':'Correct or supply the exact missing source before relying on this section.','code':block['code']})
    for item in evidence.get('items',[]):
        if not item.get('verified'):actions.append({'section':'evidence','item':item['id'],'action':'Obtain a valid proof under the exact adopted verifier, statement and context.','status':item.get('status','UNKNOWN')})
    for item in authority.get('grants',[]):
        if item.get('status') in ('REFUSED','UNAVAILABLE'):actions.append({'section':'authority','item':item['id'],'action':'Review the separately installed grant and current owner revocation state.','status':item['status']})
    for item in payments.get('declared_obligations',[]):
        if item.get('remaining_in_supplied_scope') is None:actions.append({'section':'payments','item':item['id'],'action':'Resolve source, current-reference or observation conflicts; the reviewed remaining amount is unknown.','status':item['status']})
        elif item['remaining_in_supplied_scope']>0:actions.append({'section':'payments','item':item['id'],'action':'Review the remaining declared obligation; any payment needs separate exact authorization.','remaining_in_supplied_scope':item['remaining_in_supplied_scope']})
    if any(b['status']!='EXACT_SIGNED_FIELD_MATCH' for b in bindings):notices.append('One or more proposed literal source bindings did not match a verified signed object.')
    if any(l['status']=='REFUSED' for l in links):notices.append('One or more proposed relationships have missing targets or do not match their exact signed literals.')
    for d in disputes:
        if d['result'].get('status')=='REFUSED':actions.append({'section':'disputes','item':d['id'],'action':'Correct the exact case, finding or verified agreement reference.','code':d['result']['code']})
        elif d['result'].get('missing_parties'):actions.append({'section':'disputes','item':d['id'],'action':'Obtain the remaining explicit party acceptances for this exact dispute case.'})
    result={'version':RESULT,'id':ref,'title':value['title'],'status':'READ_ONLY_REVIEW','overview':overview,'agreements':agreements,'authority':authority,'evidence':evidence,'payments':payments,'bindings':bindings,'links':links,'decisions':decisions,'recovery':recoveries,
            'graph':{'nodes':nodes,'edges':[{'source':x['from'],'target':x['to'],'relation':x['relation'],'scope':x['status']} for x in links if x['status']!='REFUSED']},
            'notices':list(dict.fromkeys(notices)),'next_actions':actions,'notes':deepcopy(value.get('notes',[])),
            'provenance':{'case_id':'PINS_CALLER_INPUTS_NOT_TRUTH_OR_AUTHORITY','agreements':'RECHECKED_EXACT_PROOFS_EACH_CALL','financial_basis':'DECLARED_OBLIGATIONS_AND_EXPLICIT_RECEIPT_ASSOCIATIONS; OWNER_OBSERVATIONS_REPORTED_SEPARATELY','snapshot':'SEPARATE_LOCAL_OWNER_OBSERVATIONS_NOT_A_GLOBAL_ATOMIC_OR_FINAL_VIEW'},
            'private_input_policy':'NO_RAW_SOURCE_PROOF_BYTES_SALTS_OR_WITNESSES_IN_THE_DEFAULT_RENDER; THIS_REVIEW_IS_NOT_ENCRYPTION',
            'recorded':False,'signature_created':False,'connector_installed':False,'execution_authorized':False}
    if value['version'] in (EXTENDED_VERSION,BILATERAL_VERSION,PERFORMANCE_VERSION):result['version']='covenant-coordination-review/0.2';result['disputes']=disputes
    if value['version'] in (BILATERAL_VERSION,PERFORMANCE_VERSION):
        result['version']='covenant-coordination-review/0.3'
        overview['bilateral']=[{k:deepcopy(a[k]) for k in ('item','profile','current_authority','funds_observed','terms_summary','lifecycle','remaining_obligations')} for a in agreements if a.get('kind')=='BILATERAL' and a.get('status') in ('VERIFIED','AWAITING_ASSENT')]
    if value['version']==PERFORMANCE_VERSION:
        from . import coordination_performance
        result['version']='covenant-coordination-review/0.4'
        result['performance']=coordination_performance.review(value.get('performance',[]),agreements,value.get('evidence',[]),evidence)
        overview['performance']=deepcopy(result['performance'])
        refs=[ref for duty in result['performance']['items'] for assertion in duty.get('assertions',[])
              for ref in assertion.get('evidence',[])]
        overview['performance_evidence']={'references':len(refs),
            'verified_under_adopted_scope':sum(ref.get('verified') is True for ref in refs),
            'not_verified':sum(ref.get('verified') is not True for ref in refs),
            'duties_with_unavailable_review':sum(duty.get('status')=='REFUSED' for duty in result['performance']['items']),
            'count_basis':'PER_ASSERTION_REFERENCE; REPEATED_REFERENCES_COUNTED_EACH_TIME',
            'performance_verified':False,'discharge_established':False}
        for duty in result['performance']['items']:
            actions.append({'section':'performance','item':duty['id'],'status':duty['status'],
                'action':'Review the exact duty, missing or disputed party assertions and evidence. Reported fulfillment does not establish performance or discharge.'})
    result['obligation_coverage']=_obligation_coverage(value,agreements,objects)
    result['assurance']=_assurance(value,agreements,authority,evidence,payments,result['obligation_coverage'])
    result=_summary(result)
    result['snapshot_id']=hashlib.sha256(b'COVENANT-COORDINATION-SNAPSHOT-0.1\0'+canonical(result)).hexdigest()
    return result

def start(tools,title,parties,context_value,terms=None,source_base64=None,media_type='text/plain',language='opaque',meaning=None,previous=None):
    """One purpose-led handoff; exact role signatures remain external."""
    need((terms is None)!=(source_base64 is None),'REVIEW_START_CHOOSE_ONE_SOURCE')
    _text(title)
    if terms is not None:_text(terms,16384);source_base64=base64.b64encode(terms.encode('utf-8')).decode('ascii')
    context=external.context_reference(context_value)
    packed=external.pack(source_base64,title=title,media_type=media_type,language=language)
    arguments={'title':title,'documents':{'terms':packed['document']},'parties':parties,'context':context['id'],'previous':previous}
    if meaning is not None:arguments['meaning']=meaning
    prepared=external.prepare(**arguments)
    row={'id':'agreement','kind':'EXTERNAL','bundle':prepared['bundle'],'context':context['id'],'approvals':[],'expected_id':prepared['id'],'expected_closure':prepared['assent_payload']['body']['closure'],'expected_current_id':prepared['id']}
    value=case(title,[row],primary='agreement')
    return {'prepared':prepared,'context':context,'document':packed['document'],'case':value,'case_id':identifier(value),'next_action':'Each declared role reviews and signs prepared.assent_payload; add those proofs to case.agreements[0].approvals then call covenant_review.review.','recorded':False,'execution_authorized':False}

def compare(before,after):
    validate(before);validate(after)
    from .review_changes import paths
    return {'before':identifier(before),'after':identifier(after),'changed_sections':[k for k in sorted(set(before)|set(after)) if (k in before)!=(k in after) or canonical(before.get(k))!=canonical(after.get(k))],'assent':'NOT_CREATED_OR_TRANSFERRED_BY_COMPARISON','prior_case_preserved':True,'execution_authorized':False,**paths(before,after)}

def _display(value):
    if isinstance(value,dict):
        return '<table>'+''.join('<tr><th>'+escape(str(k).replace('_',' '))+'</th><td>'+_display(v)+'</td></tr>' for k,v in value.items())+'</table>'
    if isinstance(value,list):return '<ol>'+''.join('<li>'+_display(v)+'</li>' for v in value)+'</ol>' if value else 'None'
    if value is None:return 'Not provided'
    return escape(str(value))

def _short_overview(result):
    view=result['overview'];selected=view['selected_agreement']
    body='<h2>Review at a glance</h2>'
    body+='<p>'+('Selected agreement: <strong>'+escape(selected['item'])+'</strong> · '+escape(selected['status'])+'.' if selected else 'No primary agreement selected.')
    body+=' '+str(view['verified_agreements'])+' verified; '+str(view['unverified_agreements'])+' awaiting valid adoption or source checks.</p>'
    if selected and selected.get('currentness',{}).get('matches') is False:
        body+='<p><strong>The selected agreement differs from the caller-retained current reference.</strong></p>'
    unresolved=[r for r in view['assent'] if r['status']!='VERIFIED']
    for row in unresolved:
        missing=', '.join(p['role']+' ('+p['status'].lower().replace('_',' ')+')' for p in row.get('missing_or_invalid',[]))
        body+='<p><strong>'+escape(row['item'])+': '+escape(missing or 'complete proof set or source requires correction')+'.</strong></p>'
    if view.get('bilateral'):
        body+='<h2>Bilateral work orders</h2><p>These amounts are profile-verified signed receipt claims. Funds, current authority and remaining prose obligations are unobserved or unknown in this review.</p><table><thead><tr><th>Order / state</th><th>Agreed / unit</th><th>Signed paid claim</th><th>Signed refund claim</th><th>Observed funds</th></tr></thead><tbody>'
        for row in view['bilateral']:
            receipt=row['lifecycle']['signed_receipt'];terms=row['terms_summary']
            fields=[row['item']+' / '+row['lifecycle']['state'],str(terms['quantity'])+' '+terms['unit'],
                    receipt['paid_amount_claim'] if receipt else 'No receipt',receipt['refunded_amount_claim'] if receipt else 'No receipt','Not observed']
            body+='<tr>'+''.join('<td>'+escape(str(v))+'</td>' for v in fields)+'</tr>'
        body+='</tbody></table>'
        for row in view['bilateral']:
            dispute=row['lifecycle']['dispute']
            if dispute:
                for key,label in (('primary','Primary'),('appeal','Appeal')):
                    decision=dispute.get(key)
                    if decision:body+='<p>'+escape(row['item'])+' · '+label+' finding: '+escape(decision['result'])+(' · award '+escape(str(decision['paid_amount'])) if 'paid_amount' in decision else '')+'. Evidence and signer references are retained below; merits are not established.</p>'
    if 'performance' in view:
        body+='<h2>Nonmonetary obligations</h2><p>Only explicitly listed duties appear here. Party assertions are caller reported, not authenticated. Payment or settlement never establishes performance or discharge.</p>'
        if not view['performance']['items']:body+='<p>Remaining obligations unknown: no duties supplied.</p>'
        for duty in view['performance']['items']:
            body+='<p><strong>'+escape(duty.get('label',duty['id']))+'</strong> ('+escape(duty['id'])+'): '+escape(duty['status'])+' · evidence '+escape(duty.get('evidence_status','UNKNOWN'))+'. Remaining: '+escape(duty.get('remaining_obligation','UNKNOWN'))+'.</p>'
    if view['money']:
        body+='<p>Amounts below use only the supplied obligations and observations. Payer refunds do not reduce the payee’s price.</p><table><thead><tr><th>Obligation / unit</th><th>Declared</th><th>Paid</th><th>Refunded to payer</th><th>Remaining</th><th>Source check</th></tr></thead><tbody>'
        for row in view['money']:
            fields=[row['label']+' / '+str(row['unit']),row['declared_amount'],row['paid_in_supplied_scope'],row['refunded_to_payer_in_supplied_scope'],row['remaining_in_supplied_scope'],row['source_binding_status']]
            body+='<tr>'+''.join('<td>'+('Unknown — resolve checks' if v is None else escape(str(v)))+'</td>' for v in fields)+'</tr>'
        body+='</tbody></table>'
    body+='<p>Top-level proof evidence: '+str(view['evidence_verified'])+' verified under selected expectations; '+str(view['evidence_unverified'])+' unverified. These counts exclude performance assertion references. Connections needing correction: '+str(view['unresolved_connections'])+'. Delegation grants needing attention: '+str(len(view['authority_grants_requiring_attention']))+'.</p>'
    if 'performance_evidence' in view:
        pe=view['performance_evidence']
        body+='<p>Performance assertion references: '+str(pe['references'])+' supplied; '+str(pe['not_verified'])+' not verified; '+str(pe['verified_under_adopted_scope'])+' verified within their adopted proof scope. '+str(pe['duties_with_unavailable_review'])+' duty reviews unavailable. Repeated references count separately. No performance or discharge is established.</p>'
    for name,status in view['section_status'].items():
        if status=='REFUSED':body+='<p><strong>'+escape(name.capitalize())+' section unavailable — resolve the source check below.</strong></p>'
    for grant in view['authority_grants']:
        body+='<p>Delegation '+escape(grant['id'])+': '+escape(str(grant['status']))+' · '+escape(str(grant['capability']))+'.</p>'
    for role in view['group_roles']['roles']:
        body+='<p>Group role '+escape(role['name'])+': '+escape(role['status'])+' (local group scope only).</p>'
    if view['group_roles']['status'] not in ('NOT_REQUESTED','LOCAL_SIGNATURES_AND_CAUSAL_POLICY_VERIFIED'):
        body+='<p>Group authority: '+escape(view['group_roles']['status'])+'.</p>'
    for row in view['decisions']:
        body+='<p>Decision '+escape(row['id'])+': winner '+escape(str(row['winner']))+'; exact snapshot adoption link '+escape(row['adoption_link'])+'.</p>'
    for row in view.get('disputes',[]):
        acceptance=str(len(row['missing_parties']))+' party acceptances missing' if type(row.get('missing_parties')) is list else 'acceptance state unavailable'
        body+='<p>Dispute '+escape(row['id'])+': '+escape(str(row['status']))+'; '+acceptance+'. Finding reference: '+escape(str(row.get('selected_finding_event') or 'not selected'))+'. Scope is caller declared; no transfer authority.</p>'
    for row in view['recovery']:
        body+='<p>Recovery '+escape(row['id'])+': '+str(row['valid_branches'])+' valid branches, '+str(row['invalid_branches'])+' invalid; '+str(len(row['conflicts']))+' same-key conflicts. No branch selected.</p>'
        for conflict in row['conflicts']:
            body+='<p>Actor '+escape(conflict['actor'])+' · sequence '+str(conflict['sequence'])+' · '+str(len(conflict['event_ids']))+' conflicting signed records retained.</p>'
        if row['chosen_policy_reference']:body+='<p>Chosen recovery-policy reference: '+escape(row['chosen_policy_reference'])+' (declared reference; no recovery executed).</p>'
    if result['notices'] or result['next_actions']:
        body+='<h2>Needs attention</h2><ul>'
        body+=''.join('<li>'+escape(n)+'</li>' for n in result['notices'])
        body+=''.join('<li>'+escape((a.get('item','')+': ' if a.get('item') else '')+a['action'])+'</li>' for a in result['next_actions'])
        body+='</ul>'
    return body

def render(tools,case,expected_id=None,source_documents=None,source_objects=None):
    result=review(tools,case,expected_id)
    style='body{font:16px/1.16 "Times New Roman",serif;background:#fff;color:#000;margin:1rem}main{max-width:70rem;border:1px solid #000;padding:1rem;margin:auto}h1,h2,h3,p,li,td,th,summary{font:inherit}h1,h2,th,summary{font-weight:bold}h1,h2{margin:1rem 0 .382rem}h1{margin-top:0}p,table,ol,ul,details{margin:0 0 .618rem}ol,ul{padding-left:1rem}li{margin:.236rem 0}table{width:100%;border-collapse:collapse}td,th{padding:.382rem;text-align:left;vertical-align:top;border:1px solid #000;overflow-wrap:anywhere}summary{cursor:pointer;padding:.382rem 0}details>p{overflow-wrap:anywhere}a{color:#000}'
    body='<h1>'+escape(result['title'])+'</h1><p>One review · exact agreements, authority, evidence, payments and remaining obligations. Read only; any effect needs separate authorization.</p>'
    chosen=[];seen=set()
    need(source_documents is None or (type(source_documents) is list and len(source_documents)<=8),'REVIEW_SOURCE_SELECTION')
    for selected in source_documents or []:
        _fields(selected,('agreement','document'),('agreement',));key=(selected['agreement'],selected.get('document','terms'))
        need(all(type(k) is str for k in key) and key not in seen,'REVIEW_SOURCE_SELECTION');seen.add(key)
        opened=open_source(tools,case,*key,expected_id=expected_id);chosen.append({k:opened[k] for k in ('agreement','document','document_id','source_sha256','assent_status')})
        body+='<h2>Selected terms: '+escape(opened['agreement'])+' / '+escape(opened['document'])+'</h2><p>'+escape(opened['assent_status'])+' · explicitly opened exact bytes</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;font:inherit">'+escape(opened['source'])+'</pre>'
    selected_objects=[];seen_objects=set()
    need(source_objects is None or (type(source_objects) is list and len(source_objects)<=8),'REVIEW_SOURCE_SELECTION')
    for selected in source_objects or []:
        _fields(selected,('agreement','path'),('agreement',));key=(selected['agreement'],selected.get('path',''))
        need(all(type(k) is str for k in key) and key not in seen_objects,'REVIEW_SOURCE_SELECTION');seen_objects.add(key)
        opened=open_object(tools,case,*key,expected_id=expected_id);selected_objects.append({k:opened[k] for k in ('agreement','path','value_sha256','assent_status')})
        body+='<h2>Selected typed value: '+escape(opened['agreement'])+' '+escape(opened['path'])+'</h2><p>'+escape(opened['assent_status'])+' · canonical JSON presentation of the exact selected value</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;font:inherit">'+escape(opened['source'])+'</pre>'
    body+=_short_overview(result)
    body+='<h2>Assurance and obligation coverage</h2><p>Syntax, exact assent, reference closure, current authority, factual support, legal review, privacy and execution are separate checks. Unlisted duties and uninterpreted prose remain unassessed; completion is unknown.</p>'
    body+='<details><summary>Assurance dimensions, assumptions and exact pins</summary>'+_display(result['assurance'])+'</details>'
    body+='<details><summary>Profile, history and nonmonetary obligation coverage</summary>'+_display(result['obligation_coverage'])+'</details>'
    body+='<p><a href="#agreements">Agreements</a> · <a href="#authority">Authority</a> · <a href="#evidence">Evidence</a> · <a href="#payments">Payments and obligations</a> · <a href="#links">Connections</a></p>'
    for key,title in [('agreements','Agreements and required consent'),('authority','Authority and independent revocation'),('evidence','Evidence and its assumptions'),('payments','Payments and remaining obligations'),('bindings','Exact signed literal bindings'),('links','Connections between the records'),('decisions','Selected decisions'),('recovery','Recovery and retained references'),('notes','Chosen notes')]:
        body+='<details id="'+key+'"><summary>'+title+'</summary>'+_display(result[key])+'</details>'
    if 'performance' in result:body+='<details id="performance"><summary>Duty IDs, party assertions and evidence references</summary>'+_display(result['performance'])+'</details>'
    if 'disputes' in result:body+='<details id="disputes"><summary>Dispute adoption, findings and scope</summary>'+_display(result['disputes'])+'</details>'
    body+='<details><summary>Case and observation pins</summary><p>Case '+result['id']+'</p><p>Observation snapshot '+result['snapshot_id']+'</p><p>No signing, recording, installation, revocation or execution.</p></details>'
    body+='<p>Obligation extraction and associations remain declared unless an explicit literal binding checks a signed field. A signature or cryptographic membership check does not establish physical facts, legal effect or global finality. This readable review is not encryption.</p>'
    return {'id':result['id'],'snapshot_id':result['snapshot_id'],'selected_source_documents':chosen,'selected_source_objects':selected_objects,'html':'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+escape(result['title'])+'</title><style>'+style+'</style></head><body><main>'+body+'</main></body></html>','execution_authorized':False,'recorded':False}

def spec():
    return {'version':VERSION,'purpose':'One read-only review linking exact agreements, independent authority, adopted evidence, observed payments and declared remaining obligations.',
            'supported_versions':[VERSION,EXTENDED_VERSION,BILATERAL_VERSION,PERFORMANCE_VERSION],
            'response_shapes':{'case':'RAW_CASE; pass the entire returned object to review(case=...).','start':'WRAPPER {prepared,context,document,case,case_id,...}; pass result.case to review.','amend_case':'WRAPPER {case,before,id,changed_sections,...}; pass result.case to review.','review':'WRAPPER {id,snapshot_id,overview,agreements,...}; this is a report, not a case.','render':'WRAPPER {id,snapshot_id,selected_source_documents,selected_source_objects,html,...}; save result.html only when you intend a readable copy.','open_source':'WRAPPER with source, encoding, exact hashes and assent_status; explicit selected disclosure.','open_object':'WRAPPER with source as canonical JSON, exact path/value hash and assent_status; typed value presentation, not external file bytes.'},
            'independent_carrier_checker':{'path':'implementations/coordination_review_058.mjs','command':'node implementations/coordination_review_058.mjs < exact_case.json','supported_versions':[VERSION,EXTENDED_VERSION,BILATERAL_VERSION,PERFORMANCE_VERSION],'scope':'STRUCTURE_AND_ID_ONLY; NO_SIGNATURE_OR_OWNER_OR_MERITS_VERIFICATION','historical_055':'Preserved0.1-only checker; intentionally refuses0.2.','historical_056':'Preserved0.1/0.2 checker; intentionally refuses0.3.','historical_057':'Preserved0.1/0.2/0.3 checker; intentionally refuses0.4.'},
            'performance_tracking':'Supplying performance selects case0.4 unless an explicit version is given. amend_case replaces the complete performance section and returns a new case ID. Exact duty and party matches never authenticate caller-reported assertions. REPORTED_FULFILLED requires all caller-selected required_roles to report fulfillment; remaining performance/discharge stays UNKNOWN. OPEN versus FULFILLED or a DISPUTED claim shows DISPUTED. Missing/mismatched parties or references remain UNKNOWN. Evidence may be unknown independently of reported status. An empty list does not establish completion.',
            'performance_example':{'id':'corrections','agreement':'exact verified agreement hash or bilateral envelope CID','label':'Supply corrected captions','responsible_role':'counterparty','required_roles':['principal','counterparty'],'assertions':[{'agreement':'same exact agreement pin','obligation':'corrections','role':'counterparty','identity':'exact agreement role identity','status':'OPEN','evidence':[]}]},
            'performance_evidence':'Each reference has kind, id, expected_hash. DELIVERY: exact bilateral content_cid and content_hash; verifies only retained signed delivery reference. PROOF: case evidence row id and SHA256 of coordination canonical(row); verifies the exact row and adopted proof scope, with matching agreement. REFERENCE: chosen identifier and SHA256; always unknown, never fetched. No reference establishes real-world performance.',
            'successor':'Supplying disputes or an explicit payment authorization selects case0.2. Explicit version=covenant-coordination-case/0.3 admits BILATERAL rows under its separate identity domain. Earlier carrier IDs and bilateral signed profiles retain their meanings; no conversion or ledger execution occurs.',
            'bilateral_review':'Explicit case0.3 or performance case0.4. expected_id is the exact envelope CID returned by the five-verb flow; agreement_hash is separate. Reuses the retained bilateral0.1/0.2 verifier. No bilateral provider capability is installed on ExchangeTools: signed receipt claims are shown, funds_observed is always false, current authority/currentness and remaining obligations are unknown. Caller observation flags and provider selectors are refused.',
            'selected_source':'open_source explicitly opens one exact agreement/document. render source_documents includes only selected UTF8 sources. Default review/render omits them. Source may be opened before assent and is labelled accordingly.',
            'typed_source':'open_source supports named external byte documents only. For typed CONCEPT, ORDER or LEGAL root terms, use open_object with agreement and optional exact JSON pointer path, or render source_objects. The canonical JSON presentation opens exact typed values; it is not an external source-file byte claim.',
            'payment_scope_handoff':'authorization_scopes verifies the supplied exact payer authorization and lists matching VERIFIED outer agreement IDs while showing the original signed payment request. Choose authorization_agreement explicitly; it does not select obligations, observe receipts or grant authority.',
            'amend_case':'Replace selected complete sections in a new case. Retain old case ID; exact copied agreement proofs are reverified, never transferred to new agreement bytes.',
            'dispute_example':{'id':'caption-case','case_event':'actual native DISPUTE event hash','finding_event':'optional exact RESOLVE event for this case','obligation':'captions','agreement':'verified original hash','settlement_agreement':'verified settlement hash','excluded_obligations':['original-edit'],'expected_scope':'Only the added captions; caller-declared scope until exact source bindings are checked.'},
            'decision_example':{'id':'vote','parameters':{'proposal':'actual proposal hash','heads':['retained causal head hash']}},
            'native_permissions':'Call permissions with group and optional actor; labels are case sensitive. Custom labels and organize currently grant no checked native actions. Open posting remains independent of role revocation.',
            'workflow':['start returns the exact any-format agreement preparation and a minimal case.','The roles sign separately; put exact approvals into the case.','Add typed references, declared obligations, proof expectations and owner-observable payment effect IDs.','Use optional signed JSON-field bindings to check exact amounts or evidence roots.','review rechecks assents and current owner observations; render produces a readable single review.'],
            'case_fields':['version','title','primary','performance (case0.4)','agreements','authority via grants/policies/group/expected_heads','evidence','obligations','payments','bindings','links','decisions','recoveries','notes'],
            'agreement_kinds':['EXTERNAL','CONCEPT','ORDER','LEGAL','REFERENCE','BILATERAL'],
            'bilateral_case_example':{'version':BILATERAL_VERSION,'title':'Branding job final review','primary':'stage2','agreements':[{'id':'stage2','kind':'BILATERAL','envelope':'exact retained bilateral0.1 or0.2 envelope','expected_id':'exact retained envelope CIDv1 returned by the work-order verbs'}]},
            'agreement_example':{'id':'sale','kind':'EXTERNAL','bundle':'prepared.bundle','context':'retained 64 hex context','approvals':[],'expected_id':'retained prepared.id','expected_closure':'retained prepared.assent_payload.body.closure'},
            'obligation_example':{'id':'price','agreement':'verified actual agreement hash','payer':'payer signing identity','payee':'payee signing identity','asset':{'namespace':'chosen','identifier':'asset','unit':'unit','adapter':None,'transfer_terms':{}},'amount':1700},
            'payment_example':{'id':'deposit-release','adapter':'owner-installed adapter hash','effect_id':'retained local effect hash','obligation':'price'},
            'binding_example':{'id':'total','agreement':'verified actual agreement hash','document':'terms','path':'/price','expected':1700},
            'link_example':{'from':'binding:total','to':'obligation:price','relation':'amount'},
            'checked_link_relations':{'binding_to_obligation':['amount','payer','payee','asset'],'binding_to_evidence':['evidence_root'],'binding_to_dispute':['case_reference','finding_reference'],'agreement_to_decision':['decision_adoption'],'other_labels':'DECLARED_ASSOCIATION_ONLY; NEVER_AUTOMATIC_SEMANTICS'},
            'dispute_link_example':{'from':'binding:finding','to':'dispute:caption-case','relation':'finding_reference'},
            'decision_link_example':{'from':'agreement:chosen','to':'decision:vote','relation':'decision_adoption','document':'decision'},
            'review_summary':'Explicit primary selection, exact missing roles, paid/refund/remaining amounts, source conflicts, decision adoption links and retained recovery conflicts. A failed amount/party/asset binding or current-reference conflict makes the reviewed remainder unknown; declared arithmetic remains separate.',
            'future_mechanisms':'Use exact references and owner-installed verifiers; unknown claims remain unverified. No mandatory drafting grammar or universal payment rail.',
            'privacy':'No raw source, proof bytes, salts or witnesses in default review output/render. Caller-chosen notes, balances and scoped metadata may still be sensitive; no automatic encryption.',
            'limits':{'bytes':MAX_BYTES,'depth':32,'section_items':64},'execution_authorized':False}
