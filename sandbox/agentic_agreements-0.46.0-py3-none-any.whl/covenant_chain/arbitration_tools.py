"""MCP-shaped tools for a panel. They prepare payloads and search a snapshot.

They do not sign, submit, or move escrow. A host can mount ``ArbitrationTools``
beside the read-only agent tools.
"""
from copy import deepcopy

from .arbitration_sdk import ballot_body, evidence_payload, open_payload, search_arbitrators, vote_payload
from .crypto import key, need

HASH = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 2000}
SEARCH = {'registry': {'type': 'array', 'maxItems': 64}, 'category': {'type': ['string', 'null']},
          'min_reputation': {'type': 'integer', 'minimum': -1000, 'maximum': 1000},
          'exclude': {'type': 'array', 'maxItems': 32, 'items': HASH},
          'parties': {'type': 'array', 'minItems': 2, 'maxItems': 16, 'items': HASH,
                      'description': 'Dispute party keys; they and their registry affiliates are excluded and signed records are conflict-checked against them.'},
          'profiles': {'type': 'array', 'maxItems': 64, 'items': {'type': 'object'},
                       'description': 'Signed urn:aap:arbitrator-record:0.1 records {body, signature}; claims stay data.'},
          'now': {'type': 'integer', 'minimum': 0, 'maximum': 9007199254740991,
                  'description': 'Caller clock for record validity and availability; required with profiles.'},
          'max_age': {'type': 'integer', 'minimum': 1, 'maximum': 9007199254740991},
          'require_profile': {'type': 'boolean'}}


def _schema(properties, required):
    return {'type': 'object', 'properties': properties, 'required': list(required), 'additionalProperties': False}


def _tool(name, title, description, schema, readonly):
    return {'name': name, 'title': title, 'description': description, 'inputSchema': schema,
            'annotations': {'readOnlyHint': readonly, 'destructiveHint': not readonly,
                            'idempotentHint': True, 'openWorldHint': False}}


TOOLS = [
    _tool('covenant_dispute', 'Open a panel dispute',
          'Prepare PANEL_OPEN for an agreement whose terms name a panel. Does not submit.',
          _schema({'agreement': HASH}, ('agreement',)), False),
    _tool('covenant_submit_evidence', 'Submit panel evidence',
          'Prepare PANEL_EVIDENCE. A confidential panel accepts the hash and the description SEALED.',
          _schema({'agreement': HASH, 'content_hash': HASH, 'format': {'type': 'string', 'enum': ['hash', 'attestation', 'show']},
                   'description': TEXT, 'attestation': {'type': ['object', 'null']}},
                  ('agreement', 'content_hash', 'format', 'description', 'attestation')), False),
    _tool('covenant_panel_vote', 'Prepare a panel ballot',
          'Return the exact ballot body and the PANEL_VOTE payload with an empty ballot. The arbitrator signs the body.',
          _schema({'chain': HASH, 'agreement': HASH, 'phase': {'type': 'string', 'enum': ['PRIMARY', 'APPEAL']},
                   'remedy': {'type': 'string', 'enum': ['release', 'refund', 'split', 'penalty', 'redeliver']},
                   'payee_bps': {'type': 'integer', 'minimum': 0, 'maximum': 10000},
                   'penalty': {'type': 'integer', 'minimum': 0}, 'reasons': HASH},
                  ('chain', 'agreement', 'phase', 'remedy', 'payee_bps', 'penalty', 'reasons')), False),
    _tool('covenant_arbitrators_search', 'Search staked arbitrators',
          'Filter a caller-supplied registry snapshot by category, reputation and exclusion. Optional parties and signed '
          'arbitrator records drop members with non-waivable conflicts or no current availability. Does not read a live chain or appoint.',
          _schema(SEARCH, ('registry', 'min_reputation', 'exclude')), True),
]


def exchange_actions():
    """Rows for the exchange tool catalogue. One action each, same payloads."""
    return [
        ('covenant_dispute', 'Prepare a panel dispute opening. Does not submit or move escrow.', False,
         [('prepare', {'agreement': HASH}, ('agreement',))]),
        ('covenant_submit_evidence', 'Prepare a panel evidence record. Does not submit.', False,
         [('prepare', {'agreement': HASH, 'content_hash': HASH,
                       'format': {'type': 'string', 'enum': ['hash', 'attestation', 'show']},
                       'description': TEXT, 'attestation': {'type': ['object', 'null']}},
           ('agreement', 'content_hash', 'format', 'description', 'attestation'))]),
        ('covenant_panel_vote', 'Prepare an unsigned panel ballot. The arbitrator signs it.', False,
         [('prepare', {'chain': HASH, 'agreement': HASH, 'phase': {'type': 'string', 'enum': ['PRIMARY', 'APPEAL']},
                       'remedy': {'type': 'string', 'enum': ['release', 'refund', 'split', 'penalty', 'redeliver']},
                       'payee_bps': {'type': 'integer', 'minimum': 0, 'maximum': 10000},
                       'penalty': {'type': 'integer', 'minimum': 0}, 'reasons': HASH},
           ('chain', 'agreement', 'phase', 'remedy', 'payee_bps', 'penalty', 'reasons'))]),
        ('covenant_arbitrators_search', 'Filter a registry snapshot by category, reputation and exclusion; optionally conflict-check signed arbitrator records against the parties.', True,
         [('search', SEARCH, ('registry', 'min_reputation', 'exclude'))]),
    ]


def _prepare(name, arguments):
    if name == 'covenant_dispute':
        key(arguments['agreement'])
        return {'op': 'PANEL_OPEN', 'payload': open_payload(arguments['agreement']),
                'execution_authorized': False, 'automatic_assent': False}
    if name == 'covenant_submit_evidence':
        key(arguments['agreement'])
        key(arguments['content_hash'])
        return {'op': 'PANEL_EVIDENCE', 'payload': evidence_payload(
            arguments['agreement'], arguments['content_hash'], format=arguments['format'],
            description=arguments['description'], attestation=arguments['attestation']),
            'execution_authorized': False, 'automatic_assent': False}
    if name == 'covenant_panel_vote':
        for field in ('chain', 'agreement', 'reasons'):
            key(arguments[field])
        body = ballot_body(arguments['chain'], arguments['agreement'], arguments['phase'], arguments['remedy'],
                           arguments['payee_bps'], arguments['penalty'], arguments['reasons'])
        return {'op': 'PANEL_VOTE', 'ballot_body': body, 'ballot_label': 'COVENANT-PANEL-BALLOT-1',
                'payload': vote_payload(body, ''), 'execution_authorized': False, 'automatic_assent': False}
    rows = search_arbitrators(arguments['registry'], category=arguments.get('category'),
                              min_reputation=arguments['min_reputation'], exclude=arguments['exclude'],
                              parties=arguments.get('parties'), profiles=arguments.get('profiles'),
                              now=arguments.get('now'), max_age=arguments.get('max_age'),
                              require_profile=arguments.get('require_profile', False))
    return {'arbitrators': rows, 'execution_authorized': False, 'automatic_assent': False}


def invoke(name, action, parameters):
    need(action in {'prepare', 'search'}, 'ARBITRATION_TOOL')
    return _prepare(name, parameters)


class ArbitrationTools:
    def list_tools(self):
        return deepcopy(TOOLS)

    def call(self, name, arguments):
        need(name in {tool['name'] for tool in TOOLS}, 'ARBITRATION_TOOL')
        return _prepare(name, arguments)
