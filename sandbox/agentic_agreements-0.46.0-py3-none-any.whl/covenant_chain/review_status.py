"""Whether a review case has confirmed performance. No proof import."""


def performance_confirmed(state, job):
    """An agreed fallback payment does not assert successful performance."""
    if job not in state.get('review_jobs', {}):
        return True
    case = state['review_cases'][state['review_jobs'][job]]
    return case['status'] == 'FINAL' and case['finding']['result'] == 'SUPPORTED' and case['decision']['result'] == 'SUPPORTED'
