"""Read-only adopted decision and recovery packets over existing signed profiles.

A selected causal snapshot, contextual ranking, or intact export is never a
spending grant, a fork-choice rule, world truth, or a global freshness claim.
No function here signs, emits, imports, repairs custody, or invokes a connector.
"""
from copy import deepcopy
import base64
import hashlib
import re

from covenant_language import external_drafts
from . import social_views, voting, desire_discovery
from .agent_network import AgentNetwork, VERSION as NETWORK_VERSION, LABEL as NETWORK_LABEL, event_id, unpack
from .crypto import canonical as wire_canonical, exact, integer, key, need, verify
from .workflow_store import canonical as json_canonical

VERSION = 'covenant-coordination-collective-review/0.1'
MAX_REVIEW_BYTES = 4_000_000
MAX_NOTE_BYTES = 262144


def _bounded(value, limit=MAX_REVIEW_BYTES):
    # This iterative JSON validator runs before deepcopy, including direct calls.
    raw = json_canonical(value)
    need(len(raw) <= limit, 'REVIEW_INPUT_SIZE')
    return raw


def _hash(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + json_canonical(value)).hexdigest()


def _heads(events):
    return sorted(set(events) - {p for e in events.values() for p in e['body']['parents']})


def _references(values, code, nonempty=False, limit=65):
    need(type(values) is list and (not nonempty or bool(values)) and len(values) <= limit, code)
    for value in values:
        key(value)
    need(values == sorted(set(values)), code)
    return values


class _FrozenNetwork:
    """Public network configuration plus one validated immutable local read."""
    _ancestors = AgentNetwork._ancestors
    _validate = AgentNetwork._validate

    def __init__(self, network, events):
        self.actor = network.actor
        self.domain = network.domain
        self.peers = set(network.peers)
        self.seeds = dict(network.seeds)
        self._events = deepcopy(events)

    def events(self):
        return deepcopy(self._events)


def _capture(tools):
    network = getattr(tools, 'network', None)
    need(network is not None, 'REVIEW_NETWORK_REQUIRED')
    with network.store.exclusive():
        events = network.events()
        return _FrozenNetwork(network, events)


def _expect_tally(tally, expected):
    if expected is None:
        return {'status': 'NOT_SUPPLIED', 'matches': None}
    _bounded(expected, MAX_NOTE_BYTES)
    need(type(expected) is dict and bool(expected) and set(expected) <= set(tally),
         'REVIEW_EXPECTED_RESULT')
    comparisons = {name: json_canonical(tally[name]) == json_canonical(value)
                   for name, value in sorted(expected.items())}
    matches = all(comparisons.values())
    return {'status': 'MATCHES_CALLER_EXPECTATION' if matches else 'DIFFERS_FROM_CALLER_EXPECTATION',
            'matches': matches, 'expected': deepcopy(expected), 'fields_match': comparisons,
            'basis': 'CALLER_EXPECTATIONS_COMPARED_TO_ACTUAL_LOCAL_SNAPSHOT_TALLY'}


def decision(tools, proposal, heads, desire=None, objects=None, edges=None,
             seeds=None, expected_result=None, title=None, parties=None):
    """Pin one exact decision snapshot and prepare optional subsequent adoption.

    Default party aliases are voter01, voter02, ... in actor-key order. Signing
    these prepared roles remains a separate operation. Closing prose and any
    custom tally program are data; only the existing poll's actual rule is run.
    """
    key(proposal)
    _references(heads, 'REVIEW_DECISION_HEADS', nonempty=True)
    _bounded({'desire': desire, 'objects': objects, 'edges': edges, 'seeds': seeds,
              'expected_result': expected_result, 'title': title, 'parties': parties})
    need((desire is None) == (objects is None), 'REVIEW_DISCOVERY_PAIR')
    need(desire is not None or (edges is None and seeds is None), 'REVIEW_DISCOVERY_PAIR')
    frozen = _capture(tools)
    all_events = frozen.events()
    selected = frozen._ancestors(heads, all_events)
    need(proposal in selected and selected[proposal]['body']['kind'] == 'PROPOSAL',
         'VOTE_PROPOSAL_OUTSIDE_CUTOFF')
    # Tally, discovery and source references all read the same captured map.
    selected_network = _FrozenNetwork(frozen, selected)
    result = voting.tally(selected_network, proposal, heads)
    poll = unpack(selected[proposal]['body'])
    discovery = None
    adopted_discovery = None
    if desire is not None:
        discovery = desire_discovery.discover(objects, desire, edges=edges, seeds=seeds,
                    network=selected_network, group=selected[proposal]['body']['group'])
        discovery['why_ranked'] = [
            {'position': i + 1, 'target': deepcopy(row['target']),
             'score_ppm': row['score_ppm'], 'components_ppm': deepcopy(row['components_ppm']),
             'requirements': deepcopy(row['requirements']),
             'opinion_status': row['reputation']['status'],
             'basis': 'ADOPTED_DESIRE_WEIGHTS_GRAPH_AND_CONTEXTUAL_SIGNED_OPINIONS',
             'performance_or_authority_proven': False}
            for i, row in enumerate(discovery['ranking'])]
        adopted_discovery = {'desire': deepcopy(desire), 'objects': deepcopy(objects),
                             'edges': deepcopy(edges), 'seeds': deepcopy(seeds),
                             'result': discovery}
    expectation = _expect_tally(result, expected_result)
    snapshot = {'version': VERSION, 'kind': 'DECISION_SNAPSHOT',
                'network_domain': frozen.domain, 'proposal': proposal,
                'proposal_envelope': deepcopy(selected[proposal]), 'poll': deepcopy(poll),
                'selected_heads': deepcopy(heads), 'selected_event_ids': sorted(selected),
                'tally': result, 'discovery': adopted_discovery,
                'expected_result_review': expectation,
                'closing_policy_enforced': False,
                'custom_execution': 'ONLY_EXISTING_POLL_RULE_COMPUTED; OTHER_PROGRAMS_REQUIRE_SEPARATE_ADOPTION_AND_IMPLEMENTATION',
                'native_authority_or_spending': 'NONE'}
    raw = _bounded(snapshot, external_drafts.MAX_BYTES)
    snapshot_id = hashlib.sha256(b'COVENANT-DECISION-SNAPSHOT-0.1\0' + raw).hexdigest()
    context = external_drafts.context_reference({'network_domain': frozen.domain,
                    'proposal': proposal, 'snapshot': snapshot_id})['id']
    if parties is None:
        parties = {'voter%02d' % (i + 1): row['actor'] for i, row in
                   enumerate(sorted(poll['electorate'], key=lambda v: v['actor']))}
    need(type(parties) is dict and bool(parties), 'REVIEW_DECISION_PARTIES')
    selected_title = 'Decision snapshot' if title is None else title
    document = external_drafts.pack(base64.b64encode(raw).decode('ascii'),
                    title=selected_title, media_type='application/json', language=VERSION)
    prepared = external_drafts.prepare({'decision': document['document']}, parties, context,
                    title=selected_title,
                    meaning='The declared roles adopt this exact decision snapshot: the pinned poll, causal cutoff, actual tally and any expressly supplied discovery policy. Adoption does not execute spending or establish physical facts, global finality, automatic closing or independent performance.')
    return {'version': VERSION, 'snapshot_id': snapshot_id, 'snapshot': snapshot,
            'tally': deepcopy(result), 'discovery': deepcopy(discovery),
            'expected_result_review': deepcopy(expectation), 'context': context,
            'prepared': prepared,
            'adoption_status': 'UNSIGNED_PREPARATION_AWAITING_DECLARED_ROLE_SIGNATURES',
            'observed_local_heads': _heads(all_events),
            'freshness': 'EXPLICIT_RETAINED_CAUSAL_SNAPSHOT_NOT_GLOBAL_LATEST',
            'later_ballots': 'DO_NOT_OVERWRITE_THIS_RETURNED_SNAPSHOT',
            'capability_claims': 'SUPPLIED_CATALOG_CLAIMS_NOT_CERTIFIED_PERFORMANCE',
            'signature_created': False, 'event_created': False,
            'execution_authorized': False}


def _agreement_reference(value):
    need(type(value) is str and re.fullmatch(r'(?:[0-9a-f]{64}|[0-9a-f]{128})', value) is not None,
         'REVIEW_AGREEMENT_REFERENCE')


def _agreement_comparison(expected):
    if expected is None:
        return {'status': 'UNKNOWN', 'matches': None,
                'basis': 'NO_INDEPENDENT_AGREEMENT_REFERENCE_SUPPLIED'}
    exact(expected, 'observed_id expected_current_id')
    for value in expected.values():
        _agreement_reference(value)
    matches = expected['observed_id'] == expected['expected_current_id']
    return {**deepcopy(expected), 'status': 'MATCHES_CALLER_REFERENCE' if matches else 'DIFFERS_FROM_CALLER_REFERENCE',
            'matches': matches,
            'basis': 'CALLER_RETAINED_AGREEMENT_REFERENCES_ONLY; NO_ASSENT_OR_GLOBAL_CURRENTNESS_VERIFICATION'}


def _head_comparison(actual, expected):
    if expected is None:
        return {'status': 'UNKNOWN', 'matches': None, 'observed_local_heads': actual,
                'basis': 'NO_RETAINED_LOCAL_HEADS_SUPPLIED; NOT_GLOBAL_FRESHNESS'}
    matches = actual == expected
    return {'status': 'MATCHES_CALLER_REFERENCE' if matches else 'LOCAL_HEADS_CHANGED_REVIEW_AGAIN',
            'matches': matches, 'expected_heads': deepcopy(expected), 'observed_local_heads': actual,
            'basis': 'RETAINED_LOCAL_HEAD_COMPARISON_ONLY; NOT_GLOBAL_FRESHNESS'}


def _pending(frozen, proposed):
    if proposed is None:
        return None
    _bounded(proposed, MAX_NOTE_BYTES)
    need(type(proposed) is dict and 'kind' in proposed, 'REVIEW_PROPOSED_NOTE')
    parents = proposed.get('parents', [])
    need(type(parents) is list, 'NETWORK_PARENTS')
    result = {'note': deepcopy(proposed), 'signature_created': False, 'event_created': False,
              'content_validation': 'NOT_PERFORMED; UNSIGNED_NOTE_RETAINED_EXACTLY',
              'execution_authorized': False}
    if frozen is None:
        result['preflight'] = {'status': 'LOCAL_CUSTODY_INVALID_OR_UNAVAILABLE', 'execution_authorized': False}
    else:
        try:
            result['preflight'] = social_views.preflight(frozen, proposed['kind'], proposed.get('group'), parents)
        except ValueError as exc:
            result['preflight'] = {'status': 'REFUSED', 'reason': str(exc), 'execution_authorized': False}
    return result


def changed_heads(tools, proposed, expected_heads=None):
    """Refresh causal preflight while retaining the caller's unsigned content."""
    if expected_heads is not None:
        _references(expected_heads, 'REVIEW_EXPECTED_HEADS', limit=64)
    frozen = _capture(tools)
    return {'version': VERSION, 'local_heads': _head_comparison(_heads(frozen.events()), expected_heads),
            'pending': _pending(frozen, proposed), 'signature_created': False,
            'event_created': False, 'execution_authorized': False}


def _review_bundle(validator, bundle, index):
    branch = {'index': index, 'valid': False, 'diagnostics': [], 'missing_references': [],
              'heads': [], 'validated_event_ids': [], 'duplicate_deliveries': [],
              'envelopes': deepcopy(bundle.get('events', [])) if type(bundle) is dict else [],
              'freshness': 'SIGNED_LOCAL_PREFIX_NOT_GLOBAL_LATEST',
              'detached_validation_order': 'DETERMINISTIC_ID_ORDER_ONLY; INVALID_PARTIAL_MAP_IS_NOT_A_FORK_CHOICE'}
    working = {}
    try:
        exact(bundle, 'version domain events freshness')
        need(bundle['version'] == NETWORK_VERSION and bundle['domain'] == validator.domain,
             'NETWORK_CONTEXT')
        need(type(bundle['events']) is list and len(bundle['events']) <= 2048, 'NETWORK_EVENT_LIMIT')
        pending = {}
        for position, envelope in enumerate(bundle['events']):
            try:
                # Bound and check shape before event_id indexes an untrusted value.
                wire_canonical(envelope)
                exact(envelope, 'body signature')
                exact(envelope['body'], 'profile domain actor request sequence previous parents kind group payload')
                need(type(envelope['body']['parents']) is list, 'NETWORK_PARENTS')
                for parent in envelope['body']['parents']:
                    key(parent)
                reference = event_id(envelope)
                if reference in pending:
                    need(pending[reference] == envelope, 'NETWORK_EVENT_COLLISION')
                    branch['duplicate_deliveries'].append({'id': reference, 'position': position})
                else:
                    pending[reference] = envelope
            except (ValueError, KeyError, TypeError, RecursionError) as exc:
                branch['diagnostics'].append({'position': position, 'reason': str(exc)})
        supplied = set(pending)
        branch['missing_references'] = sorted({p for e in pending.values()
                        for p in e['body']['parents'] if p not in supplied})
        while pending:
            ready = sorted(ref for ref, env in pending.items()
                           if set(env['body']['parents']) <= set(working))
            if not ready:
                branch['diagnostics'].append({'reason': 'NETWORK_PARENT_MISSING_OR_CYCLE',
                                              'event_ids': sorted(pending)})
                break
            for reference in ready:
                envelope = pending.pop(reference)
                try:
                    validator._validate(envelope, working)
                    working[reference] = deepcopy(envelope)
                except (ValueError, KeyError, TypeError, RecursionError) as exc:
                    branch['diagnostics'].append({'id': reference, 'reason': str(exc)})
        branch['validated_event_ids'] = sorted(working)
        branch['heads'] = _heads(working)
        branch['valid'] = not branch['diagnostics'] and not branch['missing_references']
    except (ValueError, KeyError, TypeError, RecursionError) as exc:
        branch['diagnostics'].append({'reason': str(exc)})
    branch['snapshot_id'] = _hash('COVENANT-RECOVERY-EXPORTED-BRANCH-0.1', bundle)
    return branch, working


def recovery(tools, bundles, expected_heads=None, expected_agreement=None, proposed=None):
    """Review portable causal branches without selecting or importing a winner.

    Each full export is validated separately against an empty detached map. A
    partial export cannot borrow missing history from current owner custody.
    Identical deliveries are counted; conflicting same-key envelopes survive in
    the returned source bundles and conflict rows, including invalid bundles.
    """
    need(type(bundles) is list and 1 <= len(bundles) <= 16, 'REVIEW_RECOVERY_BUNDLES')
    _bounded({'bundles': bundles, 'expected_heads': expected_heads,
              'expected_agreement': expected_agreement, 'proposed': proposed})
    if expected_heads is not None:
        _references(expected_heads, 'REVIEW_EXPECTED_HEADS', limit=64)
    agreement = _agreement_comparison(expected_agreement)
    network = getattr(tools, 'network', None)
    need(network is not None, 'REVIEW_NETWORK_REQUIRED')
    local_error = None
    try:
        frozen = _capture(tools)
        local_events = frozen.events()
    except ValueError as exc:
        local_error = str(exc)
        frozen = None
        local_events = {}
    validator = frozen if frozen is not None else _FrozenNetwork(network, {})
    branches = []
    maps = []
    for index, bundle in enumerate(bundles):
        branch, validated = _review_bundle(validator, bundle, index)
        branches.append(branch)
        maps.append(validated)
    valid_maps = [mapping for branch, mapping in zip(branches, maps) if branch['valid']]
    common = set.intersection(*(set(mapping) for mapping in valid_maps)) if valid_maps else set()
    common_events = {ref: valid_maps[0][ref] for ref in common} if valid_maps else {}
    deliveries = {}
    slots = {}
    # Duplicate delivery counts use fully validated branches. Fork evidence also
    # preserves signed same-key contradictions inside an invalid combined export:
    # crypto attribution alone never labels those envelopes causally authorized.
    for branch, mapping in zip(branches, maps):
        if branch['valid']:
            for ref in mapping:
                deliveries.setdefault(ref, []).append(branch['index'])
        source = branch['envelopes'] if type(branch['envelopes']) is list else []
        for envelope in source:
            try:
                wire_canonical(envelope)
                exact(envelope, 'body signature')
                body = envelope['body']
                exact(body, 'profile domain actor request sequence previous parents kind group payload')
                need(body['profile'] == NETWORK_VERSION and body['domain'] == validator.domain, 'NETWORK_CONTEXT')
                key(body['actor'])
                need(body['actor'] in validator.peers, 'NETWORK_PEER_NOT_ADMITTED')
                integer(body['sequence'], True)
                verify(body['actor'], NETWORK_LABEL, body, envelope['signature'])
                ref = event_id(envelope)
                slots.setdefault((body['actor'], body['sequence']), {})[ref] = envelope
            except (ValueError, KeyError, TypeError, RecursionError):
                continue
    conflicts = [{'actor': actor, 'sequence': sequence,
                  'event_ids': sorted(events), 'envelopes': [deepcopy(events[ref]) for ref in sorted(events)],
                  'status': 'SIGNED_SAME_KEY_FORK_REQUIRES_EXPLICIT_EXTERNAL_RECOVERY_POLICY',
                  'signature_scope': 'CRYPTOGRAPHIC_ATTRIBUTION_ONLY; READ_PER_BRANCH_CAUSAL_VALIDATION'}
                 for (actor, sequence), events in sorted(slots.items()) if len(events) > 1]
    packet = {'version': VERSION, 'kind': 'RECOVERY_REVIEW', 'network_domain': network.domain,
              'branches': branches, 'valid_branches': sum(branch['valid'] for branch in branches),
              'invalid_branches': sum(not branch['valid'] for branch in branches),
              'common_ancestor_ids': sorted(common), 'common_ancestor_heads': _heads(common_events),
              'duplicate_deliveries': [{'id': ref, 'branch_indices': indices}
                                      for ref, indices in sorted(deliveries.items()) if len(indices) > 1],
              'same_key_forks': conflicts,
              'local_heads': (_head_comparison(_heads(local_events), expected_heads) if local_error is None else
                 {'status': 'LOCAL_CUSTODY_INVALID_OR_UNAVAILABLE', 'matches': None, 'reason': local_error,
                  'expected_heads': deepcopy(expected_heads), 'basis': 'NO_FRESHNESS_COMPARISON_POSSIBLE'}),
              'agreement_currentness': agreement, 'pending': _pending(frozen, proposed),
              'fork_choice': 'NONE; NO_BRANCH_SELECTED_OR_MERGED',
              'source_status': 'ATTRIBUTED_SIGNED_PREFIXES_ONLY; NO_GLOBAL_FINALITY_OR_WORLD_TRUTH',
              'owner_store_written': False, 'signature_created': False,
              'event_created': False, 'execution_authorized': False}
    packet['snapshot_id'] = _hash('COVENANT-RECOVERY-REVIEW-0.1', packet)
    return packet
