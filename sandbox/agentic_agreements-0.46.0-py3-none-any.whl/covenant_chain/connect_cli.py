"""Adapter commands: plug a payment method, fair-fix forum, identity, directory, proof source, carrier or registry into AAP.

    python -m covenant_chain.connect_cli adapter kinds
    python -m covenant_chain.connect_cli adapter new --kind payment_rail acme-pay
    python -m covenant_chain.connect_cli adapter check acme-pay
    python -m covenant_chain.connect_cli adapter manifest --project acme-pay --report acme-pay/conformance-report.json --key-file publisher.key
    python -m covenant_chain.connect_cli adapter verify manifest.json
    python -m covenant_chain.connect_cli adapter terms --kind payment_rail

Once the aap command is installed, `aap adapter ...` runs the same commands:
main(argv) takes the arguments that follow `aap`, for example
['adapter', 'new', '--kind', 'payment_rail', 'acme-pay'].

Every command prints one JSON object. A refusal prints the code, what happened,
what to do next and whether retrying helps, and exits 2. Signing uses an
owner-only key file you choose; nothing is uploaded, installed or adopted.
"""
import argparse
import json
import os
from pathlib import Path
import stat
import sys

from . import connect
from .connect import ConnectError, check

MODEL = ('A deal is a promise both sides sign. Proof shows it was kept. If it wasn\'t, there is a fair way to fix it.')
MODULE = 'python -m covenant_chain.connect_cli'


def _prog():
    """The name usage text shows: the module when run directly, aap when mounted by the aap command."""
    return MODULE if Path(sys.argv[0] or '').name == 'connect_cli.py' else 'aap'
MAX_FILE = 4_000_000


def load_key_file(path):
    """An Ed25519 signing seed (64 hex characters) from an owner-only regular file. Never printed."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        raise ConnectError('CONNECT_KEY_FILE') from None
    try:
        info = os.fstat(fd)
        check(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0 and info.st_size <= 256,
              'CONNECT_KEY_FILE')
        raw = os.read(fd, 257).decode('ascii', 'replace').strip()
    finally:
        os.close(fd)
    check(len(raw) == 64 and all(c in '0123456789abcdef' for c in raw), 'CONNECT_KEY_FILE')
    return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(raw))


def _json_file(path):
    from .crypto import loads
    target = Path(path)
    check(target.is_file() and not target.is_symlink() and target.stat().st_size <= MAX_FILE, 'CONNECT_INPUT_FILE')
    try:
        return loads(target.read_bytes())
    except ValueError:
        raise ConnectError('CONNECT_INPUT_FILE') from None


def _verify(value):
    from .connect_certification import CERTIFICATE, open_certificate
    from .connect_conformance import REPORT, open_report
    version = value.get('version') if type(value) is dict else None
    body = value.get('body') if type(value) is dict and type(value.get('body')) is dict else {}
    if version == connect.DECISION:
        return {'record': 'decision', 'id': connect.verify_decision(value), 'case': value['case'],
                'outcome': value['outcome'], 'decider': value['decider'], 'authority': 'EVIDENCE_ONLY'}
    if body.get('version') == connect.MANIFEST:
        opened = connect.open_manifest(value)
        return {'record': 'manifest', 'id': opened['id'], 'urn': opened['urn'],
                **{name: opened['body'][name] for name in ('kind', 'name', 'release', 'level', 'maturity', 'publisher')},
                'conformance': opened['body']['conformance'], 'adopted': False}
    if body.get('version') == REPORT:
        opened = open_report(value)
        return {'record': 'report', 'id': opened['id'], 'kind': opened['body']['kind'],
                'verdict': opened['body']['verdict'], 'summary': opened['body']['summary'],
                'tester': opened['body']['tester'], 'subject': opened['body']['subject'],
                'results_sha256': opened['body']['results_sha256']}
    if body.get('version') == CERTIFICATE:
        opened = open_certificate(value)
        return {'record': 'certificate', 'id': opened['id'], 'mark': opened['body']['mark'],
                **{name: opened['body'][name] for name in ('assessment', 'issuer', 'subject', 'kind', 'manifest',
                                                           'issued_at', 'expires')},
                'trust': 'SIGNATURE_ONLY; pass trusted issuers to verify_certificate for a trust decision'}
    raise ConnectError('CONNECT_INPUT_FILE')


def _protocol(text):
    try:
        ident, rest = text.split('@', 1)
        version, decision = rest.rsplit(':', 1)
    except ValueError:
        raise ConnectError('CONNECT_MANIFEST') from None
    return {'id': ident, 'version': version, 'decision': decision}


def _check(directory, key_file, out, timeout=300):
    import subprocess
    from covenant_language.safe_io import run_subprocess
    project = Path(directory)
    check((project / 'conformance.py').is_file() and (project / 'project.json').is_file(), 'CONNECT_SCAFFOLD_DIRECTORY')
    argv = [sys.executable, 'conformance.py', '--out', out]
    if key_file:
        argv += ['--key-file', str(Path(key_file).resolve())]
    env = dict(os.environ)
    env['PYTHONPATH'] = os.pathsep.join([str(Path(__file__).resolve().parents[1])] +
                                        ([env['PYTHONPATH']] if env.get('PYTHONPATH') else []))
    try:
        done = run_subprocess(argv, timeout=timeout, cwd=str(project), env=env, max_output=1_000_000)
    except subprocess.TimeoutExpired:
        raise ConnectError('CONNECT_CHECK_TIMEOUT') from None
    check(len(done.stdout) <= 1_000_000, 'CONNECT_CHECK_OUTPUT')
    try:
        result = json.loads(done.stdout.decode('utf-8').strip().splitlines()[-1])
    except (ValueError, IndexError, UnicodeError):
        raise ConnectError('CONNECT_CHECK_OUTPUT') from None
    return {**result, 'project': str(project), 'exit': done.returncode}


def _manifest(args):
    from .connect_conformance import open_report
    from .crypto import public_key
    key = load_key_file(args.key_file)
    project = _json_file(Path(args.project) / 'project.json') if args.project else {}
    report = _json_file(args.report)
    opened = open_report(report)
    subject = opened['body']['subject']
    implementation = (connect.implementation_sha256(args.implementation) if args.implementation
                      else subject['implementation'])
    artifact = None
    if args.artifact:
        import hashlib
        target = Path(args.artifact)
        check(target.is_file() and target.stat().st_size <= 64 * 1024 * 1024, 'CONNECT_INPUT_FILE')
        artifact = {'name': target.name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
    made = connect.manifest(kind=args.kind or project.get('kind') or subject['kind'],
                            name=args.name or project.get('name') or subject['name'],
                            release=args.release or project.get('release') or subject['release'],
                            publisher=public_key(key), implementation=implementation, report=report,
                            maturity=args.maturity, artifact=artifact,
                            protocols=[_protocol(text) for text in args.protocol], output_keys=args.output_key,
                            previous=args.previous, issued_at=args.issued_at)
    signed = connect.sign_manifest(made['body'], key)
    return {'manifest': signed, 'id': made['id'], 'urn': connect.MANIFEST_URN + made['id'],
            'next': 'List the urn in your signed discovery descriptor; owners adopt this exact id with the report.',
            'adopted': False, 'execution_authorized': False}


def _reference(args):
    from .connect_conformance import run, sign_report
    from .connect_wrappers import REFERENCES, reference
    from .crypto import public_key
    check(args.name in REFERENCES, 'CONNECT_KIND')
    key = load_key_file(args.key_file) if args.key_file else connect.synthetic_key('aap-adapter-reference/tester')
    built = reference(args.name)
    try:
        body = run(built['kind'], built['adapter'], built['fixture'], subject={
            'name': 'reference-' + args.name.replace('_', '-').replace('/', '-'), 'release': '0.1.0',
            'implementation': built['implementation']}, tester=public_key(key), pins=built['pins'])
    finally:
        built['close']()
    signed = sign_report(body, key)
    return {'reference': args.name, 'adapter': type(built['adapter']).__name__, 'verdict': body['verdict'],
            'summary': body['summary'], 'results_sha256': body['results_sha256'],
            'report': signed if args.full else None, 'synthetic_key': not args.key_file}


def _request(args):
    from .connect_certification import request, sign_request
    from .connect_conformance import open_report
    from .crypto import public_key
    key = load_key_file(args.key_file)
    manifest = connect.open_manifest(_json_file(args.manifest))
    report = open_report(_json_file(args.report))
    made = request(public_key(key), manifest['id'], report['id'], args.nonce, args.issued_at)
    return {'request': sign_request(made['body'], key), 'id': made['id'], 'execution_authorized': False}


def _certify(args):
    from .connect_certification import issue
    key = load_key_file(args.key_file)
    issued = issue(_json_file(args.request), _json_file(args.manifest), _json_file(args.report), issuer_key=key,
                   assessment=args.assessment, issued_at=args.issued_at, expires=args.expires,
                   rerun=_json_file(args.rerun) if args.rerun else None)
    return issued


def parser():
    from .connect_wrappers import REFERENCES
    top = argparse.ArgumentParser(prog=_prog(), description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    groups = top.add_subparsers(dest='group')
    adapter = groups.add_parser('adapter', help='Build, check, publish and verify AAP Connect adapters.')
    commands = adapter.add_subparsers(dest='command', required=True)
    commands.add_parser('kinds', help='The seven adapter kinds and their contracts.')
    contract = commands.add_parser('contract', help='One kind\'s methods, JSON Schemas and refusal codes.')
    contract.add_argument('kind', choices=connect.KINDS)
    new = commands.add_parser('new', help='Generate a working adapter project that passes its suite.')
    new.add_argument('--kind', required=True, choices=connect.KINDS)
    new.add_argument('name', help='Lowercase letters, digits and hyphens.')
    new.add_argument('--directory', help='Defaults to ./NAME. An existing path is never overwritten.')
    new.add_argument('--release', default='0.1.0')
    run = commands.add_parser('check', help='Run a generated project\'s conformance suite and write its signed report.')
    run.add_argument('directory')
    run.add_argument('--key-file', help='Owner-only tester key file; omitted means a synthetic test key.')
    run.add_argument('--out', default='conformance-report.json')
    ref = commands.add_parser('reference', help='Run the suite on an existing AAP adapter wrapped for its kind.')
    ref.add_argument('name', choices=sorted(REFERENCES))
    ref.add_argument('--key-file')
    ref.add_argument('--full', action='store_true', help='Include the signed report.')
    manifest = commands.add_parser('manifest', help='Sign a manifest bound to a passing conformance report.')
    manifest.add_argument('--report', required=True)
    manifest.add_argument('--key-file', required=True, help='Owner-only publisher key file.')
    manifest.add_argument('--project', help='A generated project directory (reads project.json).')
    manifest.add_argument('--kind', choices=connect.KINDS)
    manifest.add_argument('--name')
    manifest.add_argument('--release')
    manifest.add_argument('--implementation', help='The adapter source file; defaults to the report subject hash.')
    manifest.add_argument('--artifact', help='The wheel or archive owners install.')
    manifest.add_argument('--maturity', default='experimental', choices=connect.MATURITY)
    manifest.add_argument('--protocol', action='append', default=[], help='id@version:GRAFT|TAKE_AND_IMPROVE|NATIVE')
    manifest.add_argument('--output-key', action='append', default=[], help='A key whose signatures the adapter emits.')
    manifest.add_argument('--previous', help='The manifest id this release succeeds.')
    manifest.add_argument('--issued-at', type=int, default=0)
    verify = commands.add_parser('verify', help='Check the signature and shape of a manifest, report, certificate or decision.')
    verify.add_argument('file')
    terms = commands.add_parser('terms', help='How a plugged-in adapter earns under the existing economics.')
    terms.add_argument('--kind', choices=connect.KINDS)
    request = commands.add_parser('request', help='As the subject key, ask an issuer to certify a manifest.')
    for name in ('--manifest', '--report', '--key-file', '--nonce'):
        request.add_argument(name, required=True)
    request.add_argument('--issued-at', type=int, default=0)
    certify = commands.add_parser('certify', help='As an issuer, sign a certificate derived from a passing report.')
    for name in ('--request', '--manifest', '--report', '--key-file'):
        certify.add_argument(name, required=True)
    certify.add_argument('--assessment', default='SELF_TEST', choices=('SELF_TEST', 'PROJECT_ASSESSMENT', 'INDEPENDENT_ASSESSMENT'))
    certify.add_argument('--rerun', help='The issuer\'s own signed rerun report (required for assessments).')
    certify.add_argument('--issued-at', type=int, required=True)
    certify.add_argument('--expires', type=int, required=True)
    return top


def run(argv=None):
    args = parser().parse_args(argv)
    if args.group is None:
        return {'model': MODEL, 'commands': [connect.COMMAND + ' ' + name for name in (
                    'kinds', 'new --kind <kind> <name>', 'check <directory>', 'manifest ...', 'verify <file>', 'terms')],
                'installed': 'aap adapter ... runs the same commands once the aap command is installed',
                'guide': 'docs/AAP_CONNECT.html', 'execution_authorized': False}
    command = args.command
    if command == 'kinds':
        return connect.describe()
    if command == 'contract':
        return connect.contract(args.kind)
    if command == 'new':
        from .connect_scaffold import new_adapter
        return new_adapter(args.kind, args.name, args.directory, args.release)
    if command == 'check':
        return _check(args.directory, args.key_file, args.out)
    if command == 'reference':
        return _reference(args)
    if command == 'manifest':
        return _manifest(args)
    if command == 'verify':
        return _verify(_json_file(args.file))
    if command == 'terms':
        from .connect_terms import terms
        return terms(args.kind)
    if command == 'request':
        return _request(args)
    return _certify(args)


def main(argv=None):
    try:
        result = run(argv)
    except (ConnectError, ValueError, OSError) as error:
        code = getattr(error, 'code', None) or (str(error).splitlines()[0][:80] if str(error) else type(error).__name__)
        print(json.dumps({'error': connect.refusal(code)}, sort_keys=True), file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0 if result.get('verdict', 'PASS') == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
