"""Bounded foreign JSON, RFC 8785 canonical JSON, multibase keys and eddsa-jcs-2022 proofs.

Agent documents from other ecosystems (ANP, A2A, AgentFacts, OASF, ERC-8004
files, SPIFFE bundles) carry UTF-8 text and JSON numbers that AAP's own
canonical form refuses. This module reads them under fixed bounds and writes
them back only through the JSON Canonicalization Scheme (RFC 8785), so a
signature over foreign bytes is checked exactly as the foreign signer made it.

* ``parse``: strict RFC 8259 text under I-JSON (RFC 7493 section 2): UTF-8 without
  a byte-order mark, no duplicate names, no lone surrogates, finite numbers,
  integers within 2**53. Depth is checked before the decoder recurses.
* ``jcs``: RFC 8785 section 3.2: names sorted by UTF-16 code units, minimal string
  escapes, numbers in the ECMAScript shortest form.
* Codecs: unpadded base64url (RFC 4648 section 5, RFC 7515 section 2), padded base64
  (RFC 4648 section 4, as x5c uses), base58btc multibase and the Ed25519 Multikey
  header 0xed01 (W3C Controlled Identifiers 1.0, VC-DI-EdDSA 1.0 section 2.1.1),
  OKP JWKs (RFC 8037 section 2) and JWK thumbprints (RFC 7638 section 3).
* ``eddsa-jcs-2022`` (W3C VC Data Integrity EdDSA Cryptosuites 1.0, section 3.3):
  proof preparation, an explicit local signing helper and verification.

Nothing here fetches, resolves or trusts a key: the caller says which key a proof
must verify under. Signatures are attribution, never authority.
"""
from copy import deepcopy
import base64
import hashlib
import json
import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .crypto import need, public_key
from covenant_language.key_validation import valid_ed25519_key

MAX_BYTES = 262144
MAX_DEPTH = 32
MAX_NODES = 20000
MAX_TEXT = 65536
SAFE_INTEGER = 2**53 - 1
B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
ED25519_MULTIKEY = b'\xed\x01'
DI_TYPE = 'DataIntegrityProof'
DI_SUITE = 'eddsa-jcs-2022'
DATETIME = re.compile(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(\.\d{1,9})?(Z|[+-](\d{2}):(\d{2}))\Z')

REMEDIATION = {
    'INTEROP_JSON': 'Supply one strict JSON text: UTF-8, no byte-order mark, no duplicate names, no NaN or Infinity.',
    'INTEROP_SIZE': 'Shrink the document below the stated byte bound.',
    'INTEROP_DEPTH': 'Flatten the document: nesting is bounded.',
    'INTEROP_COMPLEXITY': 'Reduce the number of values in the document.',
    'INTEROP_NUMBER': 'Use finite numbers; integers must lie within plus or minus 2**53 - 1 (I-JSON).',
    'INTEROP_UNICODE': 'Remove lone surrogates; text must be valid Unicode scalar values.',
    'INTEROP_TYPE': 'Use JSON objects, arrays, strings, numbers, booleans or null.',
    'INTEROP_BASE64': 'Use canonical base64url without padding (RFC 4648 section 5) or padded base64 where stated.',
    'INTEROP_BASE58': 'Use canonical base58btc text of the stated length.',
    'INTEROP_MULTIKEY': 'Use a z-prefixed base58btc Multikey whose header is 0xed01 and whose key is a valid Ed25519 point.',
    'INTEROP_JWK': 'Use an OKP JWK with crv Ed25519 and a 32-byte x, without private members.',
    'INTEROP_PROOF': 'Use one DataIntegrityProof with cryptosuite eddsa-jcs-2022, proofPurpose and verificationMethod.',
    'INTEROP_PROOF_CONTEXT': 'The document @context must begin with every proof @context value in order.',
    'INTEROP_PROOF_SIGNATURE': 'The proof does not verify under the expected key; sign the unchanged document again.',
    'INTEROP_DATETIME': 'Use an XML Schema dateTimeStamp such as 2026-10-25T00:00:00Z.',
    'INTEROP_KEY': 'Supply a 64-hex Ed25519 verification key.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Inspect the module description and supply the exact documented shape.')


def _depth_scan(text, max_depth):
    """Nesting depth of a JSON text, computed before any recursive decoder runs."""
    depth = 0; in_string = False; escaped = False
    for char in text:
        if in_string:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                in_string = False
        elif char == '"':
            in_string = True
        elif char in '[{':
            depth += 1
            need(depth <= max_depth, 'INTEROP_DEPTH')
        elif char in ']}':
            depth -= 1


def _walk(value, max_nodes, max_text):
    pending = [value]; nodes = 0
    while pending:
        item = pending.pop(); nodes += 1
        need(nodes <= max_nodes, 'INTEROP_COMPLEXITY')
        if type(item) is str:
            need(len(item) <= max_text, 'INTEROP_SIZE')
            need(not any(0xD800 <= ord(c) <= 0xDFFF for c in item), 'INTEROP_UNICODE')
        elif type(item) is int:
            need(abs(item) <= SAFE_INTEGER, 'INTEROP_NUMBER')
        elif type(item) is float:
            need(item == item and item not in (float('inf'), float('-inf')), 'INTEROP_NUMBER')
        elif type(item) is dict:
            for name, child in item.items():
                need(type(name) is str and len(name) <= 1024, 'INTEROP_TYPE')
                need(not any(0xD800 <= ord(c) <= 0xDFFF for c in name), 'INTEROP_UNICODE')
                pending.append(child)
        elif type(item) is list:
            pending.extend(item)
        else:
            need(item is None or type(item) is bool, 'INTEROP_TYPE')


def parse(raw, max_bytes=MAX_BYTES, max_depth=MAX_DEPTH, max_nodes=MAX_NODES, max_text=MAX_TEXT):
    """One strict I-JSON value from text or UTF-8 bytes, within explicit bounds."""
    need(type(raw) in (str, bytes), 'INTEROP_JSON')
    if type(raw) is bytes:
        need(len(raw) <= max_bytes, 'INTEROP_SIZE')
        need(not raw.startswith(b'\xef\xbb\xbf'), 'INTEROP_JSON')
        try:
            raw = raw.decode('utf-8')
        except UnicodeError:
            raise ValueError('INTEROP_JSON') from None
    need(len(raw) <= max_bytes and len(raw.encode('utf-8', 'surrogatepass')) <= max_bytes, 'INTEROP_SIZE')
    need(not raw.startswith('﻿'), 'INTEROP_JSON')
    _depth_scan(raw, max_depth)

    def pairs(items):
        out = {}
        for name, value in items:
            need(name not in out, 'INTEROP_JSON')
            out[name] = value
        return out

    def constant(_value):
        raise ValueError('INTEROP_NUMBER')

    def floating(text):
        need(len(text) <= 64, 'INTEROP_NUMBER')
        return float(text)

    def integral(text):
        need(len(text) <= 22, 'INTEROP_NUMBER')
        number = int(text)
        if abs(number) <= SAFE_INTEGER:
            return number
        # RFC 8785 numbers are doubles: keep a large literal only when it is the shortest form of its double,
        # so no digit is silently lost (9007199254740993 is refused, 58124963873663350 is kept).
        double = float(number)
        need(_number(double) == text.lstrip('+'), 'INTEROP_NUMBER')
        return double

    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=constant, parse_float=floating,
                           parse_int=integral)
    except ValueError as error:
        code = str(error)
        raise ValueError(code if code in ('INTEROP_JSON', 'INTEROP_NUMBER') else 'INTEROP_JSON') from None
    except RecursionError:
        raise ValueError('INTEROP_DEPTH') from None
    _walk(value, max_nodes, max_text)
    return value


def _number(value):
    """ECMAScript Number::toString for a finite double (RFC 8785 section 3.2.2.3)."""
    if type(value) is int:
        need(abs(value) <= SAFE_INTEGER, 'INTEROP_NUMBER')
        return str(value)
    need(value == value and value not in (float('inf'), float('-inf')), 'INTEROP_NUMBER')
    if value == 0:
        return '0'
    sign = '-' if value < 0 else ''
    mantissa, _, exponent = repr(abs(value)).partition('e')
    whole, _, fraction = mantissa.partition('.')
    full = whole + fraction
    stripped = full.lstrip('0')
    digits = stripped.rstrip('0')
    k = len(digits)
    n = len(stripped) + (int(exponent) if exponent else 0) - len(fraction)
    if k <= n <= 21:
        text = digits + '0' * (n - k)
    elif 0 < n <= 21:
        text = digits[:n] + '.' + digits[n:]
    elif -6 < n <= 0:
        text = '0.' + '0' * (-n) + digits
    else:
        power = n - 1
        text = digits[0] + ('.' + digits[1:] if k > 1 else '') + 'e' + ('+' if power >= 0 else '-') + str(abs(power))
    return sign + text


def _jcs(value, out):
    if value is None:
        out.append('null')
    elif value is True:
        out.append('true')
    elif value is False:
        out.append('false')
    elif type(value) in (int, float):
        out.append(_number(value))
    elif type(value) is str:
        need(not any(0xD800 <= ord(c) <= 0xDFFF for c in value), 'INTEROP_UNICODE')
        out.append(json.dumps(value, ensure_ascii=False))
    elif type(value) is list:
        out.append('[')
        for index, item in enumerate(value):
            if index:
                out.append(',')
            _jcs(item, out)
        out.append(']')
    elif type(value) is dict:
        out.append('{')
        for index, name in enumerate(sorted(value, key=lambda text: text.encode('utf-16-be', 'surrogatepass'))):
            need(type(name) is str, 'INTEROP_TYPE')
            if index:
                out.append(',')
            _jcs(name, out); out.append(':'); _jcs(value[name], out)
        out.append('}')
    else:
        raise ValueError('INTEROP_TYPE')


def jcs(value, max_bytes=MAX_BYTES * 4):
    """RFC 8785 canonical UTF-8 bytes of a bounded JSON value."""
    _walk(value, MAX_NODES * 4, MAX_BYTES)
    out = []
    _jcs(value, out)
    raw = ''.join(out).encode('utf-8')
    need(len(raw) <= max_bytes, 'INTEROP_SIZE')
    return raw


def b64url(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def b64url_decode(text, max_bytes=MAX_BYTES):
    """Canonical unpadded base64url; non-zero trailing bits and padding are refused."""
    need(type(text) is str and len(text) <= max_bytes * 4 // 3 + 4 and re.fullmatch('[A-Za-z0-9_-]*', text) is not None
         and len(text) % 4 != 1, 'INTEROP_BASE64')
    raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    need(b64url(raw) == text and len(raw) <= max_bytes, 'INTEROP_BASE64')
    return raw


def b64_decode(text, max_bytes=MAX_BYTES):
    """Canonical padded standard base64 (RFC 4648 section 4), as JWK x5c carries DER."""
    need(type(text) is str and 0 < len(text) <= max_bytes * 4 // 3 + 4 and len(text) % 4 == 0, 'INTEROP_BASE64')
    try:
        raw = base64.b64decode(text.encode('ascii'), validate=True)
    except (ValueError, UnicodeError):
        raise ValueError('INTEROP_BASE64') from None
    need(base64.b64encode(raw).decode('ascii') == text and len(raw) <= max_bytes, 'INTEROP_BASE64')
    return raw


def base58btc(raw):
    need(type(raw) is bytes and len(raw) <= 256, 'INTEROP_BASE58')
    number = int.from_bytes(raw, 'big'); text = ''
    while number:
        number, rest = divmod(number, 58)
        text = B58[rest] + text
    return '1' * (len(raw) - len(raw.lstrip(b'\0'))) + text


def base58btc_decode(text, size=None):
    need(type(text) is str and 0 < len(text) <= 352 and all(c in B58 for c in text), 'INTEROP_BASE58')
    number = 0
    for char in text:
        number = number * 58 + B58.index(char)
    body = number.to_bytes((number.bit_length() + 7) // 8, 'big') if number else b''
    raw = b'\0' * (len(text) - len(text.lstrip('1'))) + body
    need(base58btc(raw) == text and (size is None or len(raw) == size), 'INTEROP_BASE58')
    return raw


def _ed25519(value):
    need(type(value) is str and len(value) == 64 and valid_ed25519_key(value), 'INTEROP_KEY')
    return value


def multikey(public_hex):
    """W3C Multikey text (z + base58btc of 0xed01 || key) for an Ed25519 key."""
    return 'z' + base58btc(ED25519_MULTIKEY + bytes.fromhex(_ed25519(public_hex)))


def from_multikey(text):
    need(type(text) is str and text.startswith('z'), 'INTEROP_MULTIKEY')
    try:
        raw = base58btc_decode(text[1:], 34)
    except ValueError:
        raise ValueError('INTEROP_MULTIKEY') from None
    need(raw[:2] == ED25519_MULTIKEY and valid_ed25519_key(raw[2:].hex()), 'INTEROP_MULTIKEY')
    return raw[2:].hex()


def okp_jwk(public_hex):
    return {'kty': 'OKP', 'crv': 'Ed25519', 'x': b64url(bytes.fromhex(_ed25519(public_hex)))}


def from_okp_jwk(jwk):
    """Ed25519 key of an OKP JWK (RFC 8037 section 2); private member d is refused."""
    need(type(jwk) is dict and jwk.get('kty') == 'OKP' and jwk.get('crv') == 'Ed25519' and 'd' not in jwk
         and set(jwk) <= {'kty', 'crv', 'x', 'kid', 'alg', 'use', 'key_ops'}, 'INTEROP_JWK')
    try:
        raw = b64url_decode(jwk.get('x'), 32)
    except ValueError:
        raise ValueError('INTEROP_JWK') from None
    need(len(raw) == 32 and valid_ed25519_key(raw.hex()), 'INTEROP_JWK')
    return raw.hex()


def jwk_thumbprint(public_hex):
    """RFC 7638 section 3 SHA-256 thumbprint of the OKP JWK (members crv, kty, x)."""
    jwk = okp_jwk(public_hex)
    return b64url(hashlib.sha256(jcs({'crv': jwk['crv'], 'kty': jwk['kty'], 'x': jwk['x']})).digest())


def datetime_stamp(value):
    """XML Schema 1.1 dateTimeStamp: a dateTime with a required time zone."""
    found = DATETIME.fullmatch(value) if type(value) is str else None
    need(found is not None, 'INTEROP_DATETIME')
    year, month, day, hour, minute, second = (int(found.group(i)) for i in range(1, 7))
    days = (31, 29 if year % 4 == 0 and (year % 100 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    need(1 <= month <= 12 and 1 <= day <= days[month - 1] and hour <= 23 and minute <= 59 and second <= 59, 'INTEROP_DATETIME')
    if found.group(9) is not None:
        need(int(found.group(9)) <= 14 and int(found.group(10)) <= 59, 'INTEROP_DATETIME')
    return value


def _proof_options(options):
    need(type(options) is dict and options.get('type') == DI_TYPE and options.get('cryptosuite') == DI_SUITE
         and type(options.get('verificationMethod')) is str and 0 < len(options['verificationMethod']) <= 2048
         and type(options.get('proofPurpose')) is str and 0 < len(options['proofPurpose']) <= 64
         and 'proofValue' not in options, 'INTEROP_PROOF')
    if 'created' in options:
        datetime_stamp(options['created'])
    return options


def di_hash(unsecured, options):
    """VC-DI-EdDSA 1.0 sections 3.3.3-3.3.5: SHA-256(JCS(proof config)) || SHA-256(JCS(document))."""
    need(type(unsecured) is dict and 'proof' not in unsecured, 'INTEROP_PROOF')
    _proof_options(options)
    return hashlib.sha256(jcs(options)).digest() + hashlib.sha256(jcs(unsecured)).digest()


def di_options(unsecured, verification_method, proof_purpose='assertionMethod', created=None):
    """Proof options for section 3.3.1; the document @context is copied as the note there advises."""
    need(type(unsecured) is dict and 'proof' not in unsecured, 'INTEROP_PROOF')
    options = {'type': DI_TYPE, 'cryptosuite': DI_SUITE, 'verificationMethod': verification_method,
               'proofPurpose': proof_purpose}
    if created is not None:
        options['created'] = created
    if '@context' in unsecured:
        options['@context'] = deepcopy(unsecured['@context'])
    _proof_options(options)
    return options


def di_prepare(unsecured, verification_method, proof_purpose='assertionMethod', created=None):
    """Unsigned proof options and the exact 64 bytes the key holder signs; no signature is made."""
    options = di_options(unsecured, verification_method, proof_purpose, created)
    return {'proof_options': options, 'hash_data': di_hash(unsecured, options).hex(),
            'algorithm': 'Ed25519 (RFC 8032) over hash_data', 'signature_created': False}


def di_sign(unsecured, options, private_key):
    """Explicit local owner action (section 3.3.6). Not exposed as a tool; no permission is inferred."""
    signature = private_key.sign(di_hash(unsecured, options))
    return {**deepcopy(unsecured), 'proof': {**deepcopy(options), 'proofValue': 'z' + base58btc(signature)}}


def di_verify(secured, public_hex):
    """VC-DI-EdDSA 1.0 section 3.3.2 for one proof, under a key the caller already expects."""
    _ed25519(public_hex)
    need(type(secured) is dict and type(secured.get('proof')) is dict, 'INTEROP_PROOF')
    proof = secured['proof']
    value = proof.get('proofValue')
    need(type(value) is str and value.startswith('z'), 'INTEROP_PROOF')
    try:
        signature = base58btc_decode(value[1:], 64)
    except ValueError:
        raise ValueError('INTEROP_PROOF') from None
    options = {name: item for name, item in proof.items() if name != 'proofValue'}
    _proof_options(options)
    unsecured = {name: item for name, item in secured.items() if name != 'proof'}
    candidates = [('IN_PROOF' if '@context' in options else 'NONE', options)]
    if '@context' in options:
        mine = options['@context'] if type(options['@context']) is list else [options['@context']]
        theirs = unsecured.get('@context')
        theirs = theirs if type(theirs) is list else [theirs]
        need(theirs[:len(mine)] == mine, 'INTEROP_PROOF_CONTEXT')
        unsecured['@context'] = deepcopy(options['@context'])
    elif '@context' in unsecured:
        # Section 3.3.1 step 2 copies the document @context into the proof configuration.
        # Some signers (ANP-03 fixtures among them) hash it there without storing it in the proof.
        candidates.append(('DOCUMENT_CONTEXT_IMPLIED', {**options, '@context': deepcopy(unsecured['@context'])}))
    verifier = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex))
    for form, config in candidates:
        try:
            verifier.verify(signature, di_hash(unsecured, config))
        except InvalidSignature:
            continue
        return {'verified': True, 'cryptosuite': DI_SUITE, 'verification_method': options['verificationMethod'],
                'proof_purpose': options['proofPurpose'], 'proof_context': form, 'key': public_hex,
                'execution_authorized': False}
    raise ValueError('INTEROP_PROOF_SIGNATURE')


def _go(value, out):
    """Go encoding/json output for a value decoded into ``any`` (numbers are float64)."""
    if value is None or type(value) is bool:
        out.append('null' if value is None else ('true' if value else 'false'))
    elif type(value) in (int, float):
        number = float(value)
        out.append('-0' if number == 0 and str(number).startswith('-') else _number(number))
    elif type(value) is str:
        text = json.dumps(value, ensure_ascii=False)
        for char, escaped in (('<', '\\u003c'), ('>', '\\u003e'), ('&', '\\u0026'), (' ', '\\u2028'), (' ', '\\u2029')):
            text = text.replace(char, escaped)
        out.append(text)
    elif type(value) is list:
        out.append('[')
        for index, item in enumerate(value):
            if index:
                out.append(',')
            _go(item, out)
        out.append(']')
    elif type(value) is dict:
        out.append('{')
        for index, name in enumerate(sorted(value, key=lambda text: text.encode('utf-8', 'surrogatepass'))):
            if index:
                out.append(',')
            _go(name, out); out.append(':'); _go(value[name], out)
        out.append('}')
    else:
        raise ValueError('INTEROP_TYPE')


def go_json(value, max_bytes=MAX_BYTES * 4):
    """Bytes Go's encoding/json writes after decoding into ``any``: names in UTF-8 byte order,
    shortest ECMAScript-style numbers, and <, >, &, U+2028 and U+2029 escaped (Go 1.22 or later)."""
    _walk(value, MAX_NODES * 4, MAX_BYTES)
    out = []
    _go(value, out)
    raw = ''.join(out).encode('utf-8')
    need(len(raw) <= max_bytes, 'INTEROP_SIZE')
    return raw


def cid_v1(raw, codec_code=0x01):
    """CIDv1 text (multibase base32, lowercase) of a sha2-256 multihash over ``raw``."""
    need(type(raw) is bytes and type(codec_code) is int and 0 <= codec_code < 128, 'INTEROP_TYPE')
    binary = bytes([1, codec_code, 0x12, 0x20]) + hashlib.sha256(raw).digest()
    return 'b' + base64.b32encode(binary).decode('ascii').lower().rstrip('=')


def integral(value):
    """Copy of a foreign JSON value with integral doubles as integers; any other fraction is refused.

    ProtoJSON and other carriers may re-encode 1000 as 1000.0. Both name one number,
    and RFC 8785 serialises both as 1000, so AAP bodies recovered from them stay exact.
    """
    if type(value) is float:
        need(value.is_integer() and abs(value) <= SAFE_INTEGER, 'INTEROP_NUMBER')
        return int(value)
    if type(value) is list:
        return [integral(item) for item in value]
    if type(value) is dict:
        return {name: integral(item) for name, item in value.items()}
    return value


def did_key(public_hex):
    """did:key verification method of an Ed25519 key: did:key:<multikey>#<multikey> (W3C CCG did:key)."""
    text = multikey(public_hex)
    return 'did:key:' + text + '#' + text


def describe():
    return {'module': 'covenant_chain.interop_codec', 'status': 'EXPERIMENTAL_CODEC',
            'json': 'RFC8259_IJSON_RFC7493_BOUNDED', 'canonical': 'RFC8785_JCS',
            'proof': 'W3C_VC_DI_EDDSA_1.0_EDDSA_JCS_2022', 'multikey': 'ED25519_0XED01_BASE58BTC',
            'jwk': 'RFC8037_OKP_ED25519_RFC7638_THUMBPRINT',
            'limits': {'bytes': MAX_BYTES, 'depth': MAX_DEPTH, 'nodes': MAX_NODES, 'text': MAX_TEXT},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}


def owner_key(private_key):
    """The verification key of a local private key (for the explicit signing helpers)."""
    return public_key(private_key)
