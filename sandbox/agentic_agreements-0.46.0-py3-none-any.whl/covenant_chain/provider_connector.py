"""Signed provider RPC and owner-installed fenced inventory adapter.

Every RPC, including inspection, discloses data and commits a provider audit
event. This is outside the keyless READ surface. Endpoints, keys and clocks are
owner configuration. The local HTTP server needs an owner-operated HTTPS proxy
for remote use; it never listens on a public interface by itself.
"""
import base64
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, HTTPServer
import ipaddress
import re
import secrets
import time
from urllib.parse import urlsplit

from . import resource_provider as p
from .adapters import manifest
from .agent_tools import decode
from .connector_harness import ConnectorHarness
from .crypto import exact, integer, key, need, public_key, sign, verification_key
from .workflow_store import canonical, identifier


def provider_server(factory, *, hosts, port=0, calls_per_minute=120):
    """Factory creates a fresh connection to the SAME provider on each request."""
    need(callable(factory) and type(hosts) is list and 1 <= len(hosts) <= 16
         and all(type(h) is str and 0 < len(h) <= 256 for h in hosts), 'PROVIDER_SERVER_CONFIG')
    integer(port); need(port <= 65535, 'PROVIDER_PORT')
    integer(calls_per_minute,True); need(calls_per_minute <= 100000, 'PROVIDER_RATE_LIMIT_CONFIG')
    allowed_hosts = set(hosts)
    recent = []
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def setup(self):
            super().setup(); self.connection.settimeout(3)
        def reply(self, status, value):
            from covenant_agent.errors import shaped  # one refusal shape across the agent boundary
            raw = canonical(shaped(value))
            need(len(raw) <= 1000000, 'PROVIDER_RESPONSE_SIZE')
            self.send_response(status); self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store')
            self.send_header('Connection','close'); self.end_headers()
            try:self.wfile.write(raw)
            except (BrokenPipeError,ConnectionResetError):pass
        def do_GET(self): self.reply(405,{'error':'PROVIDER_POST_REQUIRED'})
        do_DELETE = do_PUT = do_PATCH = do_GET
        def do_POST(self):
            provider = None
            try:
                now = time.monotonic(); recent[:] = [t for t in recent if now-t < 60]
                if len(recent) >= calls_per_minute:
                    self.reply(429,{'error':'PROVIDER_RATE_LIMIT'}); return
                recent.append(now)
                need(self.path == '/provider' and self.headers.get_all('Host',[]) in [[h] for h in allowed_hosts], 'PROVIDER_HTTP_SCOPE')
                need(not any(self.headers.get_all(h,[]) for h in ('Transfer-Encoding','Origin','Expect')), 'PROVIDER_HTTP_FRAMING')
                types = self.headers.get_all('Content-Type',[])
                need(len(types) == 1 and types[0].lower() in ('application/json','application/json; charset=utf-8'), 'PROVIDER_HTTP_CONTENT')
                lengths = self.headers.get_all('Content-Length',[])
                need(len(lengths) == 1 and lengths[0].isascii() and lengths[0].isdigit() and len(lengths[0]) <= 7, 'PROVIDER_HTTP_LENGTH')
                length = int(lengths[0]); need(0 < length <= 262144, 'PROVIDER_HTTP_LENGTH')
                raw = self.rfile.read(length); need(len(raw) == length, 'PROVIDER_HTTP_INCOMPLETE')
                envelope = decode(raw); p.verify_command(envelope)
                provider = factory(); result = provider.handle(envelope)
                self.reply(200,result)
            except (ValueError,TypeError,KeyError,UnicodeError,RecursionError,OverflowError) as exc:
                code = str(exc)
                self.reply(400,{'error':code if re.fullmatch(r'PROVIDER_[A-Z_0-9]{1,80}',code) else 'PROVIDER_REQUEST_REFUSED'})
            except Exception:
                self.reply(503,{'error':'PROVIDER_UNAVAILABLE'})
            finally:
                if provider is not None: provider.close()
    server = HTTPServer(('127.0.0.1',port),Handler)
    allowed_hosts.add('127.0.0.1:'+str(server.server_port))
    return server


class ProviderClient:
    """Owner SDK. Signing a command is an explicit owner-authorized action.

    Holder epoch/expiry come from an owner-verified handover. Snapshot claims do
    not automatically change this configuration or adopt a new key/endpoint.
    A network timeout does not fall back to local resources or another provider.
    """
    def __init__(self, directory, *, provider, signer, wallet, controller, epoch, lease_expires,
                 endpoint, clock, allow_insecure_loopback=False):
        key(provider); key(wallet); verification_key(signer); integer(epoch); integer(lease_expires)
        need(callable(clock), 'PROVIDER_CLIENT_CLOCK')
        parsed = urlsplit(endpoint)
        need(parsed.path == '/provider' and not parsed.query and not parsed.fragment
             and parsed.username is None and parsed.password is None, 'PROVIDER_ENDPOINT')
        if parsed.scheme != 'https':
            try: loopback = ipaddress.ip_address(parsed.hostname).is_loopback
            except (ValueError,TypeError): loopback = False
            need(allow_insecure_loopback is True and parsed.scheme == 'http' and loopback, 'PROVIDER_HTTPS_REQUIRED')
        self.provider = provider; self.signer = deepcopy(signer); self.wallet = wallet; self.controller = controller
        self.epoch = epoch; self.lease_expires = lease_expires; self.clock = clock
        self._pin = identifier('COVENANT-PROVIDER-CLIENT-SCOPE-0.1',{'provider':provider,'wallet':wallet,'signer':signer})
        self.transport = ConnectorHarness(directory, http_routes={'provider':{'origin':parsed.scheme+'://'+parsed.netloc,
            'methods':['POST'],'path_prefix':'/provider','headers':{'Content-Type':'application/json'}}},
            max_request_bytes=262144,max_response_bytes=1000000)

    def prepare(self, operation, parameters, *, nonce=None, ttl=30):
        integer(ttl,True); need(ttl <= 300, 'PROVIDER_CLIENT_TTL'); now = self.clock(); integer(now)
        return p.draft_command(self.provider,self.wallet,public_key(self.controller),self.epoch,operation,parameters,
                               now,now+ttl,nonce or secrets.token_hex(32))

    def send(self, envelope):
        need(self._pin == identifier('COVENANT-PROVIDER-CLIENT-SCOPE-0.1',
             {'provider':self.provider,'wallet':self.wallet,'signer':self.signer}), 'PROVIDER_CLIENT_SCOPE_CHANGED')
        command = p.verify_command(envelope)
        need(command['provider'] == self.provider and command['wallet'] == self.wallet, 'PROVIDER_CLIENT_SCOPE')
        request = {'protocol':'HTTP','operation':'provider','parameters':{'path':'/provider','method':'POST',
            'body_base64':base64.b64encode(canonical(envelope)).decode('ascii')}}
        observed = self.transport.execute(p.command_id(command),request)
        need(observed['status'] == 'OBSERVED', 'PROVIDER_TRANSPORT_OUTCOME_UNKNOWN')
        response = observed['value']['response']
        result = decode(base64.b64decode(response['body_base64'],validate=True))
        if response['status'] != 200:
            code = result.get('error') if type(result) is dict else None
            raise ValueError(code if type(code) is str and re.fullmatch(r'PROVIDER_[A-Z_0-9]{1,80}',code) else 'PROVIDER_REMOTE_REFUSED')
        p.verify_receipt(result,command,expected_provider=self.provider,signer=self.signer)
        return result

    def call(self, operation, parameters):
        draft = self.prepare(operation,parameters)
        envelope = {'command':draft['command'],'signature':sign(self.controller,draft['label'],draft['body'])}
        return self.send(envelope)

    def close(self): self.transport.close()


class ProviderAdapter:
    """An approval covers observe/reserve/consume for the exact logical record.

    Every resource effect is committed at the provider under its current fence.
    There is deliberately no arbitrary downstream callback after validation.
    Changing the holder/host preserves this manifest; native booking and fresh
    delegation still govern whichever workflow invokes it.
    """
    def __init__(self, client, *, hold_seconds=30):
        integer(hold_seconds,True); need(hold_seconds <= 86400*30, 'PROVIDER_HOLD_DURATION')
        self.client = client; self.hold_seconds = hold_seconds
        self._scope = (client.provider,client.wallet)
        self.manifest = manifest('provider-inventory','provider.entitle',effect='PROVIDER_ATOMIC_INVENTORY_ENTITLEMENT',
            instance=identifier('COVENANT-PROVIDER-ADAPTER-0.1',{'provider':client.provider,'wallet':client.wallet,
                'hold_seconds':hold_seconds,'protocol':p.VERSION}),
            recovery='IDEMPOTENT_KEY',max_bytes=65536)
        self.manifest['requirements']['resources'] = 'PROVIDER_ENFORCED_INVENTORY_AND_ACCOUNT_LIMITS'

    def observe(self, effect_id):
        need(self._scope == (self.client.provider,self.client.wallet), 'PROVIDER_ADAPTER_SCOPE_CHANGED')
        key(effect_id)
        receipt = self.client.call('observe',{'effect':effect_id})
        return {**receipt['receipt']['value'],'provider_receipt':receipt}

    def close(self): self.client.close()

    def execute(self, effect_id, request, *, crash=None):
        request = deepcopy(request); expected = p._record(request); key(effect_id)
        prior = self.observe(effect_id)
        need(prior['request_hash'] in (None,expected), 'PROVIDER_REQUEST_CHANGED')
        if prior['status'] == 'OBSERVED': return prior
        need(prior['state'] in ('ABSENT','HELD'), 'PROVIDER_HOLD_TERMINAL')
        if prior['state'] == 'ABSENT':
            expires = min(self.client.clock()+self.hold_seconds,self.client.lease_expires)
            self.client.call('reserve',{'effect':effect_id,'request':request,'expires':expires})
        if crash == 'after_reserve':
            from covenant_language.handoff import InjectedCrash
            raise InjectedCrash('PROVIDER_AFTER_RESERVE')
        receipt = self.client.call('consume',{'effect':effect_id,'request':request})
        if crash == 'after_effect':
            from covenant_language.handoff import InjectedCrash
            raise InjectedCrash('PROVIDER_AFTER_EFFECT')
        return {**receipt['receipt']['value'],'provider_receipt':receipt}
