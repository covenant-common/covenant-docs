"""Host crank for an unchallenged release window. Maturity: experimental.

A deal chooses its own window, from 0 through the native cap of 10000 blocks.
The crank adds no reducer rule. It waits until the native challenge has
closed (height after ``challenge_end``) and the host window has passed, then
asks the host to submit the existing EXECUTE payload. On an armed
covenant-native/0.15 chain that payload also carries the fork's custody id
and a fresh release nonce (``resolution_rules.release_fields``); elsewhere it
is the agreement id alone. The crank cannot name a payee or a destination. A
missed block does not strand a release: any height at or after the target is
accepted, unless the host asks for exact scheduling with ``exact=True``.

workflow.py and market_runtime.py keep no hook: they sit in the reducer's
static import graph, so prediction markets and work orders call this module.
"""
from collections.abc import Mapping
from copy import deepcopy

from .crypto import digest, integer, key, need

CHALLENGE_CAP = 10000
NONCE_LABEL = 'COVENANT-RELEASE-CRANK-NONCE-0.1'


def release_height(deal, agreement):
    """First height at which the host window and the native challenge have both closed."""
    need(type(deal) is dict and type(agreement) is dict, 'FINALITY_DEAL')
    window = deal.get('window')
    integer(window)
    need(window <= CHALLENGE_CAP, 'FINALITY_WINDOW')
    integer(deal.get('decided_at'))
    challenge_end = agreement.get('challenge_end')
    integer(challenge_end)
    native_earliest = challenge_end + 1
    if window == 0:
        return native_earliest
    return max(native_earliest, deal['decided_at'] + window)


def challenger_bond(agreement_resource, bond_resource):
    """Host-side check: a challenge bond must be in the agreement's own resource.

    No reducer consumes a challenge bond yet. A host refuses a bond offer in
    another asset before it signs anything.
    """
    need(type(agreement_resource) is str and 1 <= len(agreement_resource) <= 80, 'RESOURCE')
    need(type(bond_resource) is str and bond_resource == agreement_resource, 'CHALLENGER_BOND_ASSET')
    return {'resource': agreement_resource, 'accepted': True, 'execution_authorized': False}


def _row(deal, state):
    need(type(deal) is dict, 'FINALITY_DEAL')
    if 'payee' in deal or 'destination' in deal:
        raise ValueError('CRANK_REDIRECT_REFUSED')
    key(deal.get('agreement'))
    need(isinstance(state, Mapping) and isinstance(state.get('agreements'), Mapping), 'FINALITY_STATE')
    agreements = state['agreements']
    need(deal['agreement'] in agreements, 'AGREEMENT')
    row = agreements[deal['agreement']]
    need(type(row) is dict, 'AGREEMENT')
    if row.get('state') == 'CHALLENGED':
        raise ValueError('FINALITY_CHALLENGED')
    decision = row.get('decision')
    need(row.get('state') == 'DECIDED' and type(decision) is dict and decision.get('result') == 'SUPPORTED',
         'NOT_EXECUTABLE')
    return row


def payload(state, agreement, height):
    """The exact native EXECUTE payload for this chain at ``height``.

    The custody id pins the state the transaction is applied to, so compute it
    from the state the host will submit against, at the height it submits.
    """
    from .resolution_rules import custody_for, release_fields
    key(agreement)
    integer(height, True)
    fields = release_fields(state).split()
    body = {'agreement': agreement}
    if fields != ['agreement']:
        nonce = int(digest(NONCE_LABEL, {'agreement': agreement, 'height': height})[:13], 16) or 1
        need(str(nonce) not in state.get('release_nonces', {}), 'RELEASE_NONCE')
        body.update(custody=custody_for(state, height), nonce=nonce)
    need(sorted(body) == sorted(fields), 'CRANK_PAYLOAD')
    return body


def preview(deal, state, height=None):
    """Name the target height and the payload fields. Submits nothing."""
    from .resolution_rules import release_fields
    row = _row(deal, state)
    target = release_height(deal, row)
    fields = release_fields(state).split()
    at = target if height is None else height
    integer(at, True)
    return {
        'agreement': deal['agreement'],
        'target': target,
        'payload_fields': fields,
        'payload': {'agreement': deal['agreement']} if fields == ['agreement'] else None,
        'payload_note': None if fields == ['agreement'] else
            'custody and nonce are computed from the state at the submission height',
        'ready': at >= target,
        'execution_authorized': False,
    }


def crank(deal, state, height, send, *, enabled=False, exact=False, payee=None, **extra):
    """Ask the host to submit the release at ``height``. No argument can choose a payee."""
    if payee is not None or extra:
        raise ValueError('CRANK_REDIRECT_REFUSED')
    need(enabled is True, 'PLUGIN_DISABLED')
    need(type(exact) is bool, 'FINALITY_EXACT')
    need(callable(send), 'FINALITY_SEND')
    integer(height, True)
    row = _row(deal, state)
    target = release_height(deal, row)
    if height < target:
        raise ValueError('FINALITY_NOT_YET')
    if exact and height > target:
        raise ValueError('FINALITY_WINDOW_MISSED')
    body = payload(state, deal['agreement'], height)
    sent = send(deepcopy(body))
    return {
        'payload': body,
        'height': height,
        'target': target,
        'late_by': height - target,
        'sent': sent,
        'execution_authorized': False,
    }


def enabled_from(flags):
    """The ``auto_finality`` host flag, or PLUGIN_DISABLED."""
    need(flags is not None, 'PLUGIN_DISABLED')
    return flags.require('auto_finality')
