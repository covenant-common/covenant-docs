"""Detached, field-scoped PQ disclosure. No anonymous ledger or remote erasure claim.

Bind manifest_id into the agreement's exact signed terms. Keep manifest, grants
and encrypted deliveries off the public ledger. Caller adopts issuer and obtains
verified ledger height/revocations independently; these functions do no RPC.
"""
import os
from .crypto import canonical,loads,digest,exact,need,integer,key,public_key,sign,verify,verification_key
from covenant_language.quantum import encrypt_for,decrypt_for

VERSION='covenant-disclosure/0.1'
LABEL='COVENANT-DISCLOSURE-GRANT-0.1'

def _fields(fields):
    need(type(fields) is list and 0<len(fields)<=64 and all(type(x) is str for x in fields) and fields==sorted(set(fields)),'DISCLOSURE_FIELDS')
    for field in fields:key(field)

def _kem_id(pub):
    need(type(pub) is bytes and len(pub)==1184,'RECIPIENT_KEM_KEY')
    return digest('COVENANT-DISCLOSURE-RECIPIENT-0.1',{'key':pub.hex()})

def manifest_id(manifest):return digest('COVENANT-DISCLOSURE-MANIFEST-0.1',manifest)
def grant_id(grant):return digest('COVENANT-DISCLOSURE-GRANT-ID-0.1',grant)

def prepare(fields,context,delegation=False):
    """Return publishable opaque manifest and PRIVATE salt/value openings."""
    need(type(fields) is dict and 0<len(fields)<=64,'DISCLOSURE_FIELDS')
    need(type(context) is dict and len(canonical(context))<=1024,'DISCLOSURE_CONTEXT')
    need(all(type(name) is str and 0<len(name)<=80 for name in fields),'FIELD_NAME')
    openings={};slots={};names={}
    for name,value in sorted(fields.items()):
        need(type(name) is str and 0<len(name)<=80,'FIELD_NAME')
        slot=os.urandom(32).hex();opening={'name':name,'value':value,'salt':os.urandom(32).hex()}
        need(len(canonical(opening))<=12000,'FIELD_SIZE')
        openings[slot]=opening;slots[slot]=digest('COVENANT-DISCLOSURE-FIELD-0.1',opening);names[name]=slot
    need(type(delegation) is bool,'DISCLOSURE_DELEGATION_POLICY')
    manifest={'version':VERSION,'context':context,'slots':slots,'delegation':delegation}
    return manifest,openings,names

def _manifest(m):
    exact(m,'version context slots delegation');need(m['version']==VERSION,'DISCLOSURE_VERSION')
    need(type(m['delegation']) is bool,'DISCLOSURE_DELEGATION_POLICY')
    need(type(m['context']) is dict and len(canonical(m['context']))<=1024,'DISCLOSURE_CONTEXT')
    need(type(m['slots']) is dict and 0<len(m['slots'])<=64,'DISCLOSURE_SLOTS')
    for slot,commitment in m['slots'].items():key(slot);key(commitment)

def validate_chain(manifest,chain,expected_issuer,height,revoked=()):
    """Validate an adopted issuer and every attenuation, including ancestor expiry."""
    _manifest(manifest);integer(height)
    need(type(chain) is list and 0<len(chain)<=9,'DISCLOSURE_CHAIN')
    verification_key(expected_issuer);revoked=set(revoked)
    for revoked_id in revoked:key(revoked_id)
    parent=None
    for grant in chain:
        exact(grant,'body signature');b=grant['body']
        exact(b,'version manifest parent issuer subject recipient_key fields start end delegation_depth')
        need(b['version']==VERSION and b['manifest']==manifest_id(manifest),'DISCLOSURE_BINDING')
        verification_key(b['issuer']);verification_key(b['subject']);key(b['recipient_key']);_fields(b['fields'])
        need(set(b['fields'])<=set(manifest['slots']),'UNKNOWN_DISCLOSURE_FIELD')
        for n in ['start','end','delegation_depth']:integer(b[n])
        need(b['start']<=height<=b['end'] and b['start']<=b['end'],'DISCLOSURE_EXPIRED')
        need(b['delegation_depth']<=8,'DISCLOSURE_DEPTH')
        need(manifest['delegation'] or b['delegation_depth']==0,'DISCLOSURE_POLICY')
        need(grant_id(grant) not in revoked,'DISCLOSURE_REVOKED')
        if parent is None:
            need(b['issuer']==expected_issuer and b['parent'] is None,'DISCLOSURE_ISSUER')
        else:
            p=parent['body'];need(b['parent']==grant_id(parent) and b['issuer']==p['subject'],'DISCLOSURE_PARENT')
            need(set(b['fields'])<=set(p['fields']) and b['start']>=p['start'] and b['end']<=p['end'],'DISCLOSURE_EXPANSION')
            need(p['delegation_depth']>0 and b['delegation_depth']<p['delegation_depth'],'DISCLOSURE_DELEGATION')
        verify(b['issuer'],LABEL,b,grant['signature']);parent=grant
    return parent['body']

def _delivery(manifest,openings,chain,recipient_key):
    b=chain[-1]['body'];need(b['recipient_key']==_kem_id(recipient_key),'DISCLOSURE_RECIPIENT')
    selected={slot:openings[slot] for slot in b['fields']}
    for slot,opening in selected.items():
        exact(opening,'name value salt');key(opening['salt'])
        need(digest('COVENANT-DISCLOSURE-FIELD-0.1',opening)==manifest['slots'][slot],'DISCLOSURE_OPENING')
    context=canonical({'manifest':manifest_id(manifest),'grant':grant_id(chain[-1])})
    return {'version':VERSION,'manifest':manifest_id(manifest),'grant':grant_id(chain[-1]),
            'envelope':encrypt_for(canonical(selected),recipient_public_key=recipient_key,context=context)}

def grant(manifest,openings,issuer_key,subject,recipient_key,fields,start,end,delegation_depth=0):
    """Create an exact root view grant and selected-field delivery; never spend authority."""
    body={'version':VERSION,'manifest':manifest_id(manifest),'parent':None,'issuer':public_key(issuer_key),
          'subject':subject,'recipient_key':_kem_id(recipient_key),'fields':fields,'start':start,'end':end,'delegation_depth':delegation_depth}
    chain=[{'body':body,'signature':sign(issuer_key,LABEL,body)}]
    validate_chain(manifest,chain,public_key(issuer_key),start)
    return chain,_delivery(manifest,openings,chain,recipient_key)

def _open(manifest,chain,delivery,recipient_secret,expected_issuer,height,revoked=(),*,expected_manifest):
    need(manifest_id(manifest)==expected_manifest,'DISCLOSURE_ADOPTED_MANIFEST')
    b=validate_chain(manifest,chain,expected_issuer,height,revoked);exact(delivery,'version manifest grant envelope')
    need(delivery['version']==VERSION and delivery['manifest']==manifest_id(manifest) and delivery['grant']==grant_id(chain[-1]),'DISCLOSURE_DELIVERY')
    context=canonical({'manifest':delivery['manifest'],'grant':delivery['grant']})
    selected=loads(decrypt_for(delivery['envelope'],recipient_secret_key=recipient_secret,context=context))
    need(type(selected) is dict and set(selected)==set(b['fields']),'DISCLOSURE_SCOPE')
    for slot,opening in selected.items():
        exact(opening,'name value salt');key(opening['salt'])
        need(digest('COVENANT-DISCLOSURE-FIELD-0.1',opening)==manifest['slots'][slot],'DISCLOSURE_OPENING')
    return selected

def open_fields(manifest,chain,delivery,recipient_secret,expected_issuer,height,revoked=(),*,expected_manifest):
    selected=_open(manifest,chain,delivery,recipient_secret,expected_issuer,height,revoked,expected_manifest=expected_manifest)
    values={o['name']:o['value'] for o in selected.values()}
    need(len(values)==len(selected),'DUPLICATE_FIELD_NAME')
    return values

def delegate(manifest,chain,delivery,current_secret,current_signer,expected_issuer,height,
             subject,recipient_key,fields,start,end,delegation_depth=0,revoked=(),*,expected_manifest):
    """Holder re-encrypts a permitted subset, without needing the original issuer online."""
    openings=_open(manifest,chain,delivery,current_secret,expected_issuer,height,revoked,expected_manifest=expected_manifest)
    need(public_key(current_signer)==chain[-1]['body']['subject'],'DISCLOSURE_HOLDER')
    body={'version':VERSION,'manifest':manifest_id(manifest),'parent':grant_id(chain[-1]),'issuer':public_key(current_signer),
          'subject':subject,'recipient_key':_kem_id(recipient_key),'fields':fields,'start':start,'end':end,'delegation_depth':delegation_depth}
    child=chain+[{'body':body,'signature':sign(current_signer,LABEL,body)}]
    # Parent must be live now (_open above); a future child is validated at
    # its activation, still bounded by every ancestor. This does not unlock it now.
    integer(start)
    validate_chain(manifest,child,expected_issuer,max(height,start),revoked)
    return child,_delivery(manifest,openings,child,recipient_key)
