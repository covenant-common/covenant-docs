"""Read-only tools on an explicitly owner-installed publisher/crawler desk."""
from .cooperation_interface import HASH,INT
from .commerce_tools import ADOPTION

OBJECT={'type':'object','maxProperties':64}
URL={'type':'string','minLength':9,'maxLength':1024}
TEXT={'type':'string','minLength':1,'maxLength':128}
REQUEST={'type':'object','additionalProperties':False,'required':['crawl','resource','right','purpose','sha256','bytes'],
         'properties':{'crawl':HASH,'resource':URL,'right':{'enum':['ARCHIVE','EVALUATE','INDEX','RAG','TRAIN']},
                       'purpose':TEXT,'sha256':HASH,'bytes':INT}}


def spec():
    return ('covenant_crawl_licence',
        'Experimental, owner-installed publisher/crawler licensing desk. Inspect signed bounded offers; draft exact '
        'content rights, purpose, URLs/digests, expiry, price and quotas for both parties to assent; bind a pinned '
        'source payment observation to one crawl; prepare or verify a dual-signed crawl receipt. Latest fresh '
        'owner-adopted issuer snapshot is local evidence only. No legal title/domain-control inference, fetch, '
        'crawl, signing, payment, snapshot adoption or receipt recording through this tool.',True,[
        ('offers',{'offers':{'type':'array','maxItems':32,'items':OBJECT},'resource':URL,'right':TEXT,'purpose':TEXT},
         ('offers','resource','right','purpose')),
        ('draft',{'offer':OBJECT,'crawler':HASH,'context':HASH},('offer','crawler','context')),
        ('payment_request',{'application':OBJECT,'agreement':HASH,'request':REQUEST},('application','agreement','request')),
        ('check',{'application':OBJECT,'agreement':HASH,'adoption':ADOPTION,'request':REQUEST,'payment':OBJECT},
         ('application','agreement','request')),
        ('receipt_payload',{'application':OBJECT,'agreement':HASH,'adoption':ADOPTION,'request':REQUEST,'payment':OBJECT},
         ('application','agreement','adoption','request')),
        ('verify_receipt',{'application':OBJECT,'agreement':HASH,'adoption':ADOPTION,'receipt':OBJECT,'payment':OBJECT},
         ('application','agreement','adoption','receipt'))])


def call(desk,action,p):
    if action=='describe':
        from .crawl_licensing import PROFILE,FLAGS
        return {'profile':PROFILE,'maturity':'experimental','guide':'docs/CRAWL_LICENSING.html',
                'currentness':'LATEST_LOCALLY_ADOPTED_FRESH_SNAPSHOT_NOT_GLOBAL',
                'owner_steps':['construct CrawlLicenceDesk with public pins, private WorkflowStore directory and adopted clock',
                              'explicitly adopt publisher-signed status snapshots through the owner SDK',
                              'both roles sign meaning echoes and exact agreement outside the tool',
                              'owner payment connector supplies ResourceObservationAdapter evidence',
                              'both parties sign crawl receipt; owner explicitly records it through the SDK'],**FLAGS}
    if action=='offers':return desk.offers(**p)
    if action=='draft':return desk.draft(**p)
    if action=='payment_request':return desk.payment_request(**p)
    if action=='check':return desk.check(**{**p,'adoption':p.get('adoption')})
    if action=='receipt_payload':return desk.receipt_payload(**p)
    if action=='verify_receipt':return desk.verify_receipt(**p)
    raise ValueError('CRAWL_ACTION')
