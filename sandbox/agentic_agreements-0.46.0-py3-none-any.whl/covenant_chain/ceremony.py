"""Structural checks for a Groth16 phase-2 transcript.

This module does not run a ceremony, does not call snarkjs, and does not
rewrite zk/*/build. The keys in the tree are still SINGLE_OPERATOR_SANDBOX.
A transcript that passes these checks is ready for the security agent. It is
not permission to put the pools in a shared genesis. One honest contributor
is the cryptographic assumption; this code cannot check honesty, only that
the published transcript has the shape of a multi-party contribution.
"""
from __future__ import annotations

import hashlib
import re

from .crypto import canonical, exact, need

VERSION = 'covenant-zk-ceremony/1'
MINIMUM_CONTRIBUTORS = 10
FORBIDDEN = {'single-operator-sandbox', 'single-operator', 'sandbox', 'test'}
HEX64 = re.compile(r'[0-9a-f]{64}\Z')
CIRCUITS = {'shielded', 'confidential'}


class CeremonyError(ValueError):
    pass


def _no_secrets(value, depth=0):
    need(depth <= 20, 'CEREMONY_DEPTH')
    if type(value) is dict:
        for key, item in value.items():
            if key.lower() in {'entropy', 'toxic', 'secret', 'tau', 'private'}:
                raise CeremonyError('CEREMONY_SECRET_FIELD')
            _no_secrets(item, depth + 1)
    elif type(value) is list:
        for item in value:
            _no_secrets(item, depth + 1)


def verify_transcript(transcript, *, minimum=MINIMUM_CONTRIBUTORS):
    _no_secrets(transcript)
    exact(transcript, 'v circuit circuit_sha256 powers_of_tau contributions')
    need(transcript['v'] == VERSION, 'CEREMONY_VERSION')
    need(transcript['circuit'] in CIRCUITS, 'CEREMONY_CIRCUIT')
    need(HEX64.fullmatch(transcript['circuit_sha256']) is not None, 'CEREMONY_CIRCUIT_HASH')
    pot = transcript['powers_of_tau']
    exact(pot, 'source sha256 public')
    need(pot['public'] is True and pot['source'] != 'single-operator-sandbox', 'CEREMONY_POT')
    need(type(pot['source']) is str and 8 <= len(pot['source']) <= 120, 'CEREMONY_POT')
    need(HEX64.fullmatch(pot['sha256']) is not None, 'CEREMONY_POT_HASH')
    contributions = transcript['contributions']
    need(type(contributions) is list, 'CEREMONY_CONTRIBUTIONS')
    if len(contributions) < minimum:
        raise CeremonyError('CEREMONY_TOO_FEW')
    need(len(contributions) <= 256, 'CEREMONY_TOO_MANY')
    names = set()
    previous = pot['sha256']
    for index, item in enumerate(contributions, start=1):
        exact(item, 'index name previous_sha256 output_sha256 contribution_sha256 entropy_commitment')
        need(item['index'] == index, 'CEREMONY_INDEX')
        name = item['name']
        need(type(name) is str and 1 <= len(name) <= 40 and name == name.strip(), 'CEREMONY_NAME')
        need(name.casefold() not in FORBIDDEN and name not in names, 'CEREMONY_NAME')
        names.add(name)
        for field in ('previous_sha256', 'output_sha256', 'contribution_sha256', 'entropy_commitment'):
            need(HEX64.fullmatch(item[field]) is not None, 'CEREMONY_HASH')
        need(item['previous_sha256'] == previous, 'CEREMONY_CHAIN')
        need(len({item['previous_sha256'], item['output_sha256'], item['contribution_sha256'], item['entropy_commitment']}) == 4, 'CEREMONY_DISTINCT')
        bound = canonical({
            'name': name,
            'previous_sha256': item['previous_sha256'],
            'output_sha256': item['output_sha256'],
            'entropy_commitment': item['entropy_commitment'],
        })
        need(hashlib.sha256(bound).hexdigest() == item['contribution_sha256'], 'CEREMONY_BINDING')
        previous = item['output_sha256']
    return {
        'transcript': 'READY_FOR_SECURITY_REVIEW',
        'pools': 'BLOCKED',
        'contributors': len(contributions),
        'circuit': transcript['circuit'],
        'reason': 'Hand this transcript to the security agent. This module does not enable pools or edit genesis.',
        'ceremony_executed': False,
        'network_contacted': False,
    }


def pool_gate(descriptor):
    """The security agent owns the decision to enable a pool. The default is blocked."""
    setup = descriptor.get('setup') if type(descriptor) is dict else None
    return {
        'pools': 'BLOCKED',
        'setup': setup,
        'single_operator': setup == 'SINGLE_OPERATOR_SANDBOX',
        'reason': 'SINGLE_OPERATOR_SETUP' if setup == 'SINGLE_OPERATOR_SANDBOX' else 'SECURITY_AGENT_GATE',
        'genesis_modified': False,
    }


def contribution_binding(name, previous_sha256, output_sha256, entropy_commitment):
    body = canonical({
        'name': name,
        'previous_sha256': previous_sha256,
        'output_sha256': output_sha256,
        'entropy_commitment': entropy_commitment,
    })
    return hashlib.sha256(body).hexdigest()
