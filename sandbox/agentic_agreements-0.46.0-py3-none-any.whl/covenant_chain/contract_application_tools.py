"""Stateless descriptors for exact contractual applications and signed procedures."""
from .cooperation_interface import HASH, OBJECT, schema


def _input_models():
    """Discoverable nested input shapes; native validation remains authoritative."""
    integer = {'type': 'integer', 'minimum': 0, 'maximum': 9007199254740991}
    positive = {**integer, 'minimum': 1}
    name = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
    nullable_name = {'anyOf': [name, {'type': 'null'}]}
    nullable_hash = {'anyOf': [HASH, {'type': 'null'}]}
    unit = {'type': 'string', 'minLength': 1, 'maxLength': 128,
            'description': 'Exact unit label; native validation also enforces 128 UTF-8 bytes.'}
    def record(properties):
        return schema(properties, tuple(properties))
    def array(items, maximum, minimum=0):
        return {'type': 'array', 'items': items, 'minItems': minimum, 'maxItems': maximum}
    def mapping(items, maximum=32):
        return {'type': 'object', 'propertyNames': name, 'additionalProperties': items, 'maxProperties': maximum}
    typed = {'oneOf': [record({'kind': {'const': kind}, 'value': value}) for kind, value in (
        ('INTEGER', integer), ('BOOLEAN', {'type': 'boolean'}),
        ('TEXT', {'type': 'string', 'maxLength': 16384}), ('HASH', HASH), ('ROLE', name))]
        + [record({'kind': {'const': 'MONEY'}, 'amount': integer, 'unit': unit})]}
    typed_map = mapping(typed)
    acceptance = {**typed_map, 'minProperties': 1,
                  'description': 'Exact typed criteria echoed by every party; this is not evidence that criteria are met.'}
    parties = {**mapping({'anyOf': [HASH, OBJECT]}, 16), 'minProperties': 2,
               'description': 'Named roles mapped to distinct supported verification keys, not human identity or current authority.'}
    norm = record({'id': name, 'kind': {'enum': ['OBLIGATION', 'PERMISSION', 'PROHIBITION', 'POWER']},
                   'actor': name, 'action': name, 'beneficiary': nullable_name, 'trigger': nullable_name,
                   'deadline': nullable_name, 'reparations': array(name, 8), 'discharges': array(name, 8)})
    norm['description'] = ('All fields are required; use null and [] explicitly. Only POWER can discharge norms. '
                           'Triggers/actions apply even when a machine transition returns to the same state. '
                           'Only typed event names compute; time labels and prose do not schedule events.')
    machine = record({'states': array(name, 16, 1), 'initial': name, 'terminals': array(name, 16, 1),
        'events': {**mapping(array(name, 16, 1), 8), 'minProperties': 1}, 'facts': array(name, 4),
        'transitions': array(record({'from': name, 'event': name, 'to': name,
            'guard': mapping({'type': 'boolean'}, 4),
            'release': array(record({'party': name, 'amount': integer}), 16)}), 128, 1)})
    machine['description'] = ('Every reachable nonterminal event/fact combination needs exactly one transition. '
        'State transitions gate simulated releases, not norm event processing. A self-loop is not an ignored event.')
    escrow = record({'amount': integer, 'unit': unit})
    escrow['description'] = 'Simulated ledger balance only; no custody, funding or payment is established.'
    trace_event = record({'event': name, 'actor': name, 'facts': mapping({'type': 'boolean'}, 4)})
    trace_event['description'] = 'Supply every declared Boolean fact; values remain actor assertions.'
    # A signature can be the historical hex signature or a supported structured signature.
    signature = {'anyOf': [{'type': 'string'}, OBJECT]}
    echo = record({'party': name, 'acceptance': acceptance, 'signature': signature})
    adoption = record({'party': name, 'signature': signature})
    negotiation = record({'opens': integer, 'commit_until': integer, 'reveal_until': integer,
        'select_from': integer, 'expires': integer, 'bidders': array(name, 15, 1), 'unit': unit,
        'maximum_price': integer, 'latest_delivery': integer, 'acceptance': acceptance,
        'allowed_terms': mapping(array(typed, 16, 1), 16)})
    negotiation['description'] = ('Claimed times must satisfy opens < commit_until < reveal_until <= select_from '
        '< expires < latest_delivery. Bidders are named nonprincipal roles. Each offer must supply every allowed term '
        'with one enumerated value and exactly echo acceptance. Times require separate observation.')
    stage = record({'name': name, 'mode': {'enum': ['NEGOTIATION', 'OPTIMISTIC', 'JUDGMENT']},
        'deciders': array(name, 16), 'quorum': integer, 'window': positive, 'bond': integer})
    stage['description'] = ('JUDGMENT needs named nondisputant deciders and quorum 1..len(deciders); other modes '
        'use deciders=[] and quorum=0. Bonds must not decrease between stages.')
    escalation = record({'disputants': array(name, 2, 2), 'stages': array(stage, 6, 1),
        'outcomes': array(typed_map, 16, 1), 'bond_unit': unit, 'maximum_total_bond': integer, 'expires': positive})
    escalation['description'] = ('Two distinct named disputants; unique stage names and outcomes. Sum of stage bonds '
        'must fit maximum_total_bond. Each opened stage deadline must precede expires. Bond receipts remain UNKNOWN.')
    offer = record({'version': {'const': 'urn:aap:typed-offer:0.1'}, 'policy': HASH, 'bidder': name,
        'price': record({'kind': {'const': 'MONEY'}, 'amount': integer, 'unit': unit}),
        'deliver_by': integer, 'terms': typed_map, 'acceptance': acceptance})
    arguments = {'anyOf': [
        {**record({'offer': offer, 'parent': nullable_hash}), 'title': 'PROPOSE or COUNTER'},
        {**record({'commitment': HASH}), 'title': 'COMMIT'},
        {**record({'offer': offer, 'salt': HASH}), 'title': 'REVEAL'},
        {**record({'bidder': name}), 'title': 'SELECT'},
        {**record({'claim': HASH, 'result': typed_map, 'bond_receipt': nullable_hash}), 'title': 'OPEN'},
        {**record({'result': typed_map}), 'title': 'AGREE or VOTE'},
        {**record({'evidence': HASH, 'bond_receipt': nullable_hash,
                   'result': {'anyOf': [typed_map, {'type': 'null'}]}}), 'title': 'CHALLENGE'},
        {**record({}), 'title': 'FINALIZE or CLOSE_UNRESOLVED'}],
        'description': 'Use the exact fields for the named action. CHALLENGE result is null except when entering OPTIMISTIC. '
                       'Use null bond_receipt for a zero bond; a nonzero bond takes a receipt hash, not proof of payment.'}
    procedure_event = record({'body': record({'version': {'const': 'urn:aap:agreement-procedure:0.1'},
        'policy': HASH, 'previous': HASH, 'sequence': integer, 'actor': name, 'action': name,
        'arguments_hash': HASH, 'at': integer}), 'arguments': arguments, 'signature': signature})
    return dict(parties=parties, typed_map=typed_map, acceptance=acceptance, norm=norm, machine=machine,
        escrow=escrow, trace_event=trace_event, echo=echo, adoption=adoption,
        negotiation=negotiation, escalation=escalation, arguments=arguments, procedure_event=procedure_event,
        offer=offer)


def specs():
    m = _input_models()
    text = {'type': 'string', 'maxLength': 16384}
    title = {'type': 'string', 'minLength': 1, 'maxLength': 256}
    role = {'type': 'string', 'minLength': 1, 'maxLength': 64}
    integer = {'type': 'integer', 'minimum': 0, 'maximum': 9007199254740991}
    array = {'type': 'array', 'items': OBJECT, 'maxItems': 128}
    application = {**OBJECT, 'description': 'Exact urn:aap:agreement-application:0.1 application; all content remains private to its chosen carrier unless separately shared.'}
    policy = {**OBJECT, 'description': 'Exact adopted procedure policy. Clock and receipt claims are not independently observed.'}
    bounds = {'maximum_nodes': {'type': 'integer', 'minimum': 1, 'maximum': 8192},
              'maximum_steps': {'type': 'integer', 'minimum': 1, 'maximum': 131072}}
    adoption = {'application': application, 'echoes': {**array, 'items': m['echo']}, 'approvals': array, 'expected_id': HASH, 'expected_closure': HASH, **bounds,
                'expected_current_id': HASH}
    session = {'policy': policy, 'adoptions': {**array, 'items': m['adoption']}, 'events': {**array, 'items': m['procedure_event']}}
    return [
        ('covenant_contract_application', 'Build a simple or typed contractual application; pin default packs, render exact declared display, rehearse finite states and escrow, obtain actual signed meaning echoes and prepare existing exact role assent. Only typed model semantics compute. No legal completeness, physical performance, custody, payment, current authority, encryption or execution is established.', True, [
            ('describe', {}, ()),
            ('simple_exchange', {'parties': m['parties'], 'context': HASH, 'item': text, 'amount': integer, 'unit': title,
                                  'acceptance': m['acceptance'], 'title': title}, ('parties', 'context', 'item', 'amount', 'unit', 'acceptance')),
            ('rule_pack', {'title': title, 'rules': m['typed_map']}, ('title', 'rules')),
            ('draft', {'title': title, 'parties': m['parties'], 'context': HASH, 'norms': {**array, 'items': m['norm'], 'minItems': 1, 'maxItems': 16}, 'machine': m['machine'],
                       'escrow': m['escrow'], 'acceptance': m['acceptance'], 'template': text, 'terms': m['typed_map'], 'rule_packs': array,
                       'precedence': {'type': 'array', 'items': {'type': 'string'}, 'maxItems': 9}, 'supersedes': HASH},
                      ('title', 'parties', 'context', 'norms', 'machine', 'escrow', 'acceptance', 'template')),
            ('rehearse', {'application': application, **bounds}, ('application',)),
            ('replay', {'application': application, 'trace': {**array, 'items': m['trace_event']}}, ('application', 'trace')),
            ('lint', {'application': application, 'echoes': OBJECT}, ('application',)),
            ('echo_payload', {'application': application, 'party': role, 'acceptance': m['acceptance']}, ('application', 'party', 'acceptance')),
            ('prepare', {'application': application, 'echoes': {**array, 'items': m['echo']}, **bounds}, ('application', 'echoes')),
            ('verify', adoption, ('application', 'echoes', 'approvals', 'expected_id', 'expected_closure')),
            ('trace_payload', {'application': application, 'agreement': HASH, 'events': array, 'event': m['trace_event']}, ('application', 'agreement', 'events', 'event')),
            ('verify_trace', {**adoption, 'events': array, 'expected_head': HASH}, ('application', 'echoes', 'approvals', 'expected_id', 'expected_closure', 'events', 'expected_head')),
        ]),
        ('covenant_agreement_procedure', 'Invited typed negotiation, counteroffers, sealed commitments, price/unit/term reservation caps and comparison windows; finite negotiate/optimistic/resolver/panel/appeal ladders. Every named party adopts the policy and every advancing event needs an actual current-root role signature. Bond hashes and signed times are claims; selected proposals require separate final agreement assent. No public admission, custody, incentives, payment, legal award or global latest is proved.', True, [
            ('describe', {}, ()),
            ('negotiation', {'title': title, 'parties': m['parties'], 'principal': role, 'context': HASH, 'configuration': m['negotiation'], 'supersedes': HASH}, ('title', 'parties', 'principal', 'context', 'configuration')),
            ('escalation', {'title': title, 'parties': m['parties'], 'principal': role, 'context': HASH, 'configuration': m['escalation'], 'supersedes': HASH}, ('title', 'parties', 'principal', 'context', 'configuration')),
            ('adoption_payload', {'policy': policy, 'party': role}, ('policy', 'party')),
            ('offer', {'policy': policy, 'bidder': role, 'price': integer, 'deliver_by': integer, 'terms': m['typed_map'], 'acceptance': m['acceptance']}, ('policy', 'bidder', 'price', 'deliver_by', 'terms', 'acceptance')),
            ('counter_offer', {'policy': policy, 'previous': m['offer'], 'changes': OBJECT}, ('policy', 'previous', 'changes')),
            ('seal_bid', {'policy': policy, 'bid': m['offer'], 'salt': {**HASH, 'description': 'Owner-generated unpredictable 256-bit blinding salt. Host sees input; retain privately until the agreed reveal window. This is not an encryption key or password.'}}, ('policy', 'bid', 'salt')),
            ('replay', {**session, 'expected_head': HASH}, ('policy', 'adoptions', 'events')),
            ('event_payload', {**session, 'actor': role, 'action': {**title, 'enum': ['PROPOSE', 'COUNTER', 'COMMIT', 'REVEAL', 'SELECT', 'OPEN', 'AGREE', 'VOTE', 'CHALLENGE', 'FINALIZE', 'CLOSE_UNRESOLVED']}, 'arguments': m['arguments'], 'at': integer}, ('policy', 'adoptions', 'events', 'actor', 'action', 'arguments', 'at')),
            ('advance', {**session, 'event': m['procedure_event']}, ('policy', 'adoptions', 'events', 'event')),
            ('compare', {**session, 'as_of': integer, 'expected_head': HASH}, ('policy', 'adoptions', 'events', 'as_of', 'expected_head')),
        ])] + _deal_specs(m)


def _deal_specs(m):
    from .agreement_profile_review import describe as profile_description
    profile_schema = profile_description()['schema']
    profile_fields = profile_schema['properties']
    profile_parties = profile_fields['parties']
    profile_name = profile_parties['propertyNames']
    name = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
    nullable_hash = {'anyOf': [HASH, {'type': 'null'}]}
    text = {'type': 'string', 'minLength': 1, 'maxLength': 4096}
    integer = {'type': 'integer', 'minimum': 0, 'maximum': 9007199254740991}
    expression = {**OBJECT, 'description': 'Exact CLAIM, CONST, NOT, ALL, ANY or EXCEPT grammar from describe. Missing evidence is UNKNOWN, not false.'}
    def record(fields): return schema(fields, tuple(fields))
    def mapping(items, limit): return {'type': 'object', 'maxProperties': limit, 'additionalProperties': items}
    def array(items, limit): return {'type': 'array', 'items': items, 'maxItems': limit}
    source = record({'key': {'anyOf': [HASH, OBJECT]}, 'control_group': name, 'method': text, 'method_pin': nullable_hash})
    claim = record({'meaning': text, 'kind': {'enum': ['INTERNAL_RECORD', 'EXTERNAL_FACT', 'JUDGMENT']},
                    'scope': OBJECT, 'sources': {**array(name, 32), 'minItems': 1},
                    'support_quorum': {'type': 'integer', 'minimum': 1, 'maximum': 32},
                    'refute_quorum': {'type': 'integer', 'minimum': 1, 'maximum': 32}})
    formality = record({'medium': {'enum': ['ORAL_REPORTED', 'HANDSHAKE_REPORTED', 'MESSAGE', 'WRITTEN', 'CUSTOM']},
                       'jurisdiction': {'anyOf': [text, {'type': 'null'}]}, 'note': text})
    offset = {'type': ['integer', 'null'], 'minimum': -10**12, 'maximum': 10**12}
    points = {**array(record({'id': name, 'earliest': offset, 'latest': offset}), 64), 'minItems': 1}
    constraints = array(record({'id': name, 'before': name, 'after': name, 'minimum': offset, 'maximum': offset}), 256)
    temporal = record({'timepoints': points, 'constraints': constraints})
    deduction = record({'premises': array(expression, 32), 'conclusion': expression})
    plan = {**OBJECT, 'description': 'Exact plan returned by draft; retain its id. Unknown keys refuse. Review does not adopt the plan or original agreement.'}
    adoption = record({'approvals': array(OBJECT, 128), 'expected_id': HASH,
                       'expected_closure': HASH, 'expected_current_id': nullable_hash})
    return [('covenant_deal_review',
        'Optional review of exact evidence policies, four-valued claims, bounded classical deductions and relative-time dependencies. '
        'Separate formality, source attribution, evidence support, model checks and plan assent. No global soundness, legal approval, underlying agreement assent, current authority, payment, fetching or execution.', True, [
            ('describe', {}, ()),
            ('draft', {'title': text, 'agreement': record({'kind': {'enum': ['APPLICATION', 'EXTERNAL_DOCUMENT', 'CUSTOM']}, 'id': HASH}),
                       'context': HASH, 'parties': m['parties'], 'sources': mapping(source, 32),
                       'claims': mapping(claim, 64), 'requirements': mapping(expression, 32),
                       'formality': formality, 'temporal': temporal, 'deduction': deduction},
             ('title', 'agreement', 'context', 'parties')),
            ('prepare', {'plan': plan}, ('plan',)),
            ('verify_adoption', {'plan': plan, **adoption['properties']},
             ('plan', 'approvals', 'expected_id', 'expected_closure')),
            ('assertion_payload', {'plan': plan, 'claim': name, 'source': name, 'position': {'enum': ['AFFIRM', 'DENY']},
                                   'evidence': nullable_hash, 'issued_at': integer, 'expires': integer},
             ('plan', 'claim', 'source', 'position', 'evidence', 'issued_at', 'expires')),
            ('review', {'plan': plan, 'assertions': array(record({'body': OBJECT, 'signature': {'anyOf': [{'type': 'string'}, OBJECT]}}), 256),
                        'as_of': integer, 'adoption': adoption, 'application': OBJECT,
                        'maximum_nodes': {'type': 'integer', 'minimum': 1, 'maximum': 8192},
                        'maximum_steps': {'type': 'integer', 'minimum': 1, 'maximum': 131072}}, ('plan', 'assertions', 'as_of')),
            ('evaluate', {'expression': expression, 'evidence': mapping({'enum': ['UNKNOWN', 'SUPPORTED', 'REFUTED', 'CONFLICTING']}, 128)},
             ('expression', 'evidence')),
            ('deduction', deduction['properties'], ('premises', 'conclusion')),
            ('schedule', temporal['properties'], ('timepoints', 'constraints')),
            ('profile_describe', {}, ()),
            ('profile_draft', {'agreement': profile_fields['agreement'], 'parties': profile_parties, 'as_of': integer,
                               **{key: profile_fields[key] for key in ('decisions', 'relationships', 'formality', 'mappings')}}, ('agreement', 'parties', 'as_of')),
            ('profile_assent', {'profile': profile_schema}, ('profile',)),
            ('profile_review', {'profile': profile_schema, 'expected_id': HASH,
                                'sources': array(record({'document': HASH, 'text': {'type': 'string', 'maxLength': 262144}}), 64),
                                'models': array(record({'document': HASH, 'value': {}}), 64),
                                'approvals': array(record({'party': profile_name, 'signature': {'anyOf': [{'type': 'string'}, OBJECT]}}), 32),
                                'reviewed_at': integer}, ('profile', 'expected_id')),
            ('temporal_describe', {}, ()),
            ('temporal_prepare', {'profile': OBJECT}, ('profile',)),
            ('temporal_assent', {'profile': OBJECT}, ('profile',)),
            ('temporal_event', {'profile': OBJECT, 'event': OBJECT}, ('profile', 'event')),
            ('temporal_waiver', {'profile': OBJECT, 'waiver': OBJECT}, ('profile', 'waiver')),
            ('temporal_subject', {'profile': OBJECT, 'target': {'type': 'string'}, 'event': OBJECT}, ('profile', 'target')),
            ('temporal_review', {'profile': OBJECT, 'events': array(OBJECT, 64), 'approvals': array(OBJECT, 16),
                                 'now': OBJECT, 'waivers': array(OBJECT, 256), 'time_evidence': array(OBJECT, 65)}, ('profile', 'events')),
            ('evidence_choice', {'priors': mapping({'type': 'integer', 'minimum': 0, 'maximum': 10000}, 16),
                                 'utilities': mapping(mapping({'type': 'integer', 'minimum': -10**6, 'maximum': 10**6}, 16), 16),
                                 'experiments': array(record({'id': name,
                                     'signals': mapping(mapping({'type': 'integer', 'minimum': 0, 'maximum': 10000}, 16), 16),
                                     'monetary_cost': {'type': 'integer', 'minimum': 0, 'maximum': 10**6},
                                     'delay_cost': {'type': 'integer', 'minimum': 0, 'maximum': 10**6},
                                     'disclosure_cost': {'type': 'integer', 'minimum': 0, 'maximum': 10**6}}), 16),
                                 'utility_unit': {'type': 'string', 'minLength': 1, 'maxLength': 128}},
             ('priors', 'utilities', 'experiments', 'utility_unit')),
            ('domain_describe', {}, ()),
            ('domain_manifest', {}, ()),
            ('domain_pam_draft', {'source_utf8': {'type': 'string', 'maxLength': 262144}, 'expected_source': HASH,
                                  'case': profile_name, 'parties': record({'lender': HASH, 'borrower': HASH}), 'context': HASH},
             ('source_utf8', 'expected_source', 'case', 'parties', 'context')),
            ('domain_open_source', {'module': OBJECT, 'expected_id': HASH}, ('module', 'expected_id')),
            ('archive_describe', {}, ()),
            ('archive_verifier', {}, ()),
            ('archive_prepare', {'body': OBJECT}, ('body',)),
            ('archive_artifact', {'kind': {'type': 'string', 'minLength': 1, 'maxLength': 64}, 'value': OBJECT}, ('kind', 'value')),
            ('archive_subject', {'body': OBJECT}, ('body',)),
            ('archive_export', {'original_base64': {'type': 'string', 'maxLength': 2666668},
                                 'records': array(OBJECT, 64), 'artifacts': array(OBJECT, 128),
                                 'context': HASH, 'audience': nullable_hash, 'known_private': array(HASH, 256)},
             ('original_base64', 'records', 'artifacts', 'context')),
            ('archive_import', {'package': OBJECT, 'expected_id': HASH, 'expected_context': HASH,
                                 'trusted_signers': array({'anyOf': [HASH, OBJECT]}, 32), 'audience': nullable_hash,
                                 'quantum_keys': OBJECT, 'succession_policies': OBJECT,
                                 'trusted_time_policies': array(HASH, 64), 'expected_tip': nullable_hash,
                                 'known_private': array(HASH, 256),
                                 'include_original': {'type': 'boolean'}},
             ('package', 'expected_id', 'expected_context', 'trusted_signers')),
        ])]


def call(tool, action, parameters):
    from covenant_language import agreement_application, agreement_procedures, deal_assurance, deal_logic
    if tool == 'covenant_deal_review':
        from covenant_language import temporal_obligations, evidence_decisions
        from . import agreement_profile_review, domain_adapter_review, archive_renewal
        extras = {'profile_describe': agreement_profile_review.describe,
                  'profile_draft': agreement_profile_review.draft,
                  'profile_assent': agreement_profile_review.assent_payload,
                  'profile_review': agreement_profile_review.review,
                  'temporal_describe': temporal_obligations.describe,
                  'temporal_prepare': temporal_obligations.prepare,
                  'temporal_assent': temporal_obligations.assent_payload,
                  'temporal_event': temporal_obligations.event_payload,
                  'temporal_waiver': temporal_obligations.waiver_payload,
                  'temporal_subject': temporal_obligations.time_subject,
                  'temporal_review': temporal_obligations.review,
                  'evidence_choice': evidence_decisions.advise,
                  'domain_describe': domain_adapter_review.describe,
                  'domain_manifest': domain_adapter_review.manifest,
                  'domain_pam_draft': domain_adapter_review.pam_draft,
                  'domain_open_source': domain_adapter_review.open_source,
                  'archive_describe': archive_renewal.describe,
                  'archive_verifier': archive_renewal.verifier_descriptor,
                  'archive_prepare': archive_renewal.prepare,
                  'archive_artifact': archive_renewal.artifact,
                  'archive_subject': archive_renewal.time_subject,
                  'archive_export': _archive_export,
                  'archive_import': archive_renewal.import_package}
        if action in extras:
            return extras[action](**parameters)
    modules = {'covenant_contract_application': agreement_application, 'covenant_agreement_procedure': agreement_procedures,
               'covenant_deal_review': deal_logic if action in ('evaluate', 'deduction', 'schedule') else deal_assurance}
    allowed = {name: {entry[0] for entry in actions} for name, _, _, actions in specs()}
    if tool not in modules or action not in allowed[tool]:
        raise ValueError('APPLICATION_TOOL_ACTION')
    return getattr(modules[tool], action)(**parameters)


def _archive_export(original_base64, records, artifacts, context, audience=None, known_private=()):
    """JSON facade; refuse oversized/noncanonical base64 before allocating bytes."""
    import base64
    from . import archive_renewal
    if type(original_base64) is not str or len(original_base64) > 4 * ((archive_renewal.MAX_ARCHIVE + 2) // 3):
        raise ValueError('ARCHIVE_RENEWAL_ARCHIVE_BOUND')
    try:
        original = base64.b64decode(original_base64, validate=True)
    except (ValueError, UnicodeError):
        raise ValueError('ARCHIVE_RENEWAL_BASE64') from None
    if base64.b64encode(original).decode('ascii') != original_base64:
        raise ValueError('ARCHIVE_RENEWAL_BASE64')
    return archive_renewal.export_package(original, records, artifacts, context=context, audience=audience,
                                         known_private=known_private)
