"""Usage audit and disputes: reconcile crawl receipts with the signed licence, then use the agreed route.

TAKE-AND-IMPROVE: RSL defines reporting hooks but no receipts, audit or
disputes (RSL 1.0 section 3.12); Cloudflare Pay Per Crawl and TollBit offer
none either. The audit reads only signed evidence: crawl receipts
(urn:aap:crawl-receipt:0.1) and publisher-signed edge observations
(urn:aap:crawl-observation:0.1). It reports typed findings with the evidence
behind each: OVER_CRAWL, OUT_OF_SCOPE, MISSING_ATTRIBUTION, UNPAID_FETCH and
UNPAID_USE. A finding signed by either side can open the AAP dispute ladder
(covenant_language.agreement_procedures) the licence names, and the licence's
LCP forum (the AAA path the Legal Context Protocol names) maps through the
owner's forum registry (forum_arbiter). Bonds and escrow effects are allowed
only as far as the signed licence allows them.

A finding is a signed claim over signed evidence, never world truth. Nothing
here files a case, pays, releases escrow or blocks a crawler.
"""
from collections import deque
from copy import deepcopy
import re

from covenant_language import agreement_application as app
from covenant_language import agreement_procedures as procedures
from . import crawl_receipts
from . import crawl_terms
from . import forum_arbiter
from . import interop_codec
from .crypto import need, verify

PROFILE = 'urn:aap:crawl-audit:0.1'
FINDING = 'urn:aap:crawl-finding:0.1'
FINDING_LABEL = 'AAP-CRAWL-FINDING-0.1'
OBSERVATION = 'urn:aap:crawl-observation:0.1'
OBSERVATION_LABEL = 'AAP-CRAWL-OBSERVATION-0.1'
REFERRAL = 'urn:aap:crawl-referral:0.1'
KINDS = ('MISSING_ATTRIBUTION', 'OUT_OF_SCOPE', 'OVER_CRAWL', 'UNPAID_FETCH', 'UNPAID_USE')
FLAGS = {**crawl_terms.FLAGS, 'filed': False, 'network_accessed': False}
MAX_RECEIPTS = 10000
MAX_OBSERVATIONS = 10000
MAX_EVIDENCE = 64
FINDING_FIELDS = 'version agreement terms kind detail evidence evidence_total as_of'
OBSERVATION_FIELDS = 'version agreement url at keyid status charged evidence'
REFERENCE = crawl_terms.REFERENCE

ERRORS = {
    'CRAWL_AUDIT_INPUT': ('The receipts, observations, clock or tolerance are malformed or too many.',
                          'Pass at most 10000 receipts and 10000 observations, an integer as_of and a tolerance up to a day.', False),
    'CRAWL_OBSERVATION_FIELDS': ('An edge observation is malformed or signed by someone other than the publisher.',
                                 'Build it with observation_payload; the publisher signs the exact body.', False),
    'CRAWL_FINDING_FIELDS': ('The finding is malformed, edited or of an unknown kind.',
                             'Send the finding exactly as the audit returned it.', False),
    'CRAWL_FINDING_SIGNATURE': ('The finding signature does not verify for the named role.',
                                'Sign the exact finding body with the crawler or publisher key of this licence.', False),
    'CRAWL_DISPUTE_NO_ROUTE': ('The signed licence names no dispute ladder.',
                               'Agree a new licence with a ladder, or use the forum route if one was agreed.', False),
    'CRAWL_DISPUTE_NO_FORUM': ('The signed licence names no outside forum.', 'Use the agreed ladder instead.', False),
    'CRAWL_DISPUTE_LADDER': ('The ladder is not {policy, adoptions, events} for a valid escalation policy.',
                             'Pass the exact adopted escalation policy, its adoptions and events.', False),
    'CRAWL_DISPUTE_ROUTE': ('The ladder is not the one the licence names.', 'Use the ladder whose id the signed licence names.', False),
    'CRAWL_DISPUTE_PARTIES': ('The ladder disputants are not the crawler and publisher of this licence.',
                              'Use a ladder whose two disputants hold exactly these keys.', False),
    'CRAWL_DISPUTE_BOND_NOT_AGREED': ('The ladder bonds exceed the bond cap the licence allows.',
                                      'Use a ladder within the signed bond cap; with cap 0, every stage bond must be 0.', False),
    'CRAWL_DISPUTE_ESCROW_NOT_AGREED': ('A ladder outcome moves escrow the licence does not name.',
                                        'Remove escrow effects or agree a licence naming that escrow policy.', False),
    'CRAWL_DISPUTE_FORUM': ('The forum adapter does not match the licence forum or the clause is missing.',
                            'Install the adapter for the exact LCP method the licence names; the clause id is required.', False),
}


def explain(code):
    if code in ERRORS:
        what, fix, retry = ERRORS[code]
        return {'code': code, 'what': what, 'fix': fix, 'retry': retry, 'reference': REFERENCE + code}
    return crawl_receipts.explain(code)


def _hex(value, code):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, code)
    return value


def observation_payload(view, *, url, at, keyid, status, charged=None, evidence):
    """A publisher-signed record of one fetch its edge saw: URL, time, the verified Web Bot Auth keyid, status, charge.

    ``evidence`` is the SHA-256 of the publisher's own log record. The publisher signs; nothing is sent.
    """
    body = {'version': OBSERVATION, 'agreement': view['agreement'], 'url': url, 'at': at, 'keyid': keyid,
            'status': status, 'charged': deepcopy(charged), 'evidence': evidence}
    _observation_body(view, body)
    return {'label': OBSERVATION_LABEL, 'body': body, 'id': app.content_id(OBSERVATION_LABEL, body),
            'signer': view['publisher'], **FLAGS}


def _observation_body(view, body):
    need(type(body) is dict and set(body) == set(OBSERVATION_FIELDS.split()) and body['version'] == OBSERVATION
         and body['agreement'] == view['agreement'], 'CRAWL_OBSERVATION_FIELDS')
    try:
        normal, _target = crawl_terms.resource(body['url'], view['body']['origin'])
    except ValueError:
        raise ValueError('CRAWL_OBSERVATION_FIELDS') from None
    need(normal == body['url'] and type(body['at']) is int and 0 <= body['at'] <= 2 ** 53 - 1
         and type(body['keyid']) is str and re.fullmatch('[A-Za-z0-9_-]{43}', body['keyid']) is not None
         and type(body['status']) is int and 100 <= body['status'] <= 599, 'CRAWL_OBSERVATION_FIELDS')
    crawl_receipts._money(body['charged'], 'CRAWL_OBSERVATION_FIELDS')
    _hex(body['evidence'], 'CRAWL_OBSERVATION_FIELDS')
    return body


def _observation(view, value):
    need(type(value) is dict and set(value) == {'body', 'signature'}, 'CRAWL_OBSERVATION_FIELDS')
    body = _observation_body(view, value['body'])
    crawl_terms._checked(verify, 'CRAWL_OBSERVATION_FIELDS', view['publisher'], OBSERVATION_LABEL, body, value['signature'])
    return app.content_id(OBSERVATION_LABEL, body), body


def _row(kind, ident, assurance):
    return {'kind': kind, 'id': ident, 'assurance': assurance}


def _priced(price, charged, units):
    """Charged covers the agreed price for this many units, in the agreed currency unit."""
    return charged is not None and charged['unit'] == price['unit'] and charged['amount'] >= price['amount'] * units


def audit(view, receipts, *, observations=(), as_of, tolerance=300):
    """Reconcile signed receipts (and the publisher's signed edge observations) against the signed licence.

    Receipts that do not verify are listed as refused and count for nothing. Each finding names its evidence
    (at most 64 ids, with the total) and how strongly each item is signed. ``tolerance`` is how many seconds
    apart an observation and a receipt for the same URL may be and still describe one fetch.
    """
    need(type(receipts) is list and len(receipts) <= MAX_RECEIPTS and type(observations) in (list, tuple)
         and len(observations) <= MAX_OBSERVATIONS and type(as_of) is int and 0 <= as_of <= 2 ** 53 - 1
         and type(tolerance) is int and 0 <= tolerance <= 86400, 'CRAWL_AUDIT_INPUT')
    terms = view['body']
    price, limits = terms['price'], terms['limits']
    keyids = {interop_codec.jwk_thumbprint(key): key for key in view['bot_keys']}
    events, refused, seen = [], [], set()
    for index, receipt in enumerate(receipts):
        try:
            checked = crawl_receipts.verify_receipt(view, receipt)
        except ValueError as error:
            refused.append({'kind': 'RECEIPT', 'index': index, 'code': str(error)})
            continue
        if checked['id'] not in seen:
            seen.add(checked['id']); events.append(checked)
    events.sort(key=lambda row: (row['body']['at'], row['id']))
    observed, foreign = [], 0
    for index, value in enumerate(observations):
        try:
            ident, body = _observation(view, value)
        except ValueError as error:
            refused.append({'kind': 'OBSERVATION', 'index': index, 'code': str(error)})
            continue
        if body['keyid'] not in keyids:
            foreign += 1
        elif body['status'] == 200 and ident not in seen:
            seen.add(ident); observed.append((ident, body))
    observed.sort(key=lambda row: (row[1]['at'], row[0]))
    findings = []

    def finding(kind, detail, evidence):
        rows = sorted(evidence, key=lambda row: (row['kind'], row['id']))
        value = {'version': FINDING, 'agreement': view['agreement'], 'terms': view['terms'], 'kind': kind,
                 'detail': detail, 'evidence': rows[:MAX_EVIDENCE], 'evidence_total': len(rows), 'as_of': as_of}
        findings.append({**value, 'id': app.content_id(FINDING_LABEL, value)})

    fetches = [row for row in events if row['kind'] == 'FETCH']
    uses = [row for row in events if row['kind'] == 'USE']
    payments = [row for row in events if row['kind'] == 'PAYMENT']
    # Out of scope: content, use and window, grouped by the use and the exact reasons.
    groups = {}
    for row in fetches + uses:
        body = row['body']
        scope = crawl_terms._scope(terms, body['resource'], body['use'], body['at'])
        if scope['status'] == 'OUT_OF_SCOPE':
            groups.setdefault((body['use'], tuple(scope['reasons'])), []).append(_row('RECEIPT', row['id'], row['assurance']))
    for (use, reasons), rows in sorted(groups.items()):
        finding('OUT_OF_SCOPE', {'use': use, 'reasons': list(reasons)}, rows)
    # Missing attribution: every reported use under a licence that requires attribution must carry it.
    if terms['attribution']['required']:
        missing = [_row('RECEIPT', row['id'], row['assurance']) for row in uses if row['body']['attribution'] is None]
        if missing:
            finding('MISSING_ATTRIBUTION', {'required': deepcopy(terms['attribution'])}, missing)
    # Payment coverage. Unmatched edge observations are fetches the crawler did not receipt: both lists are in
    # time order, so each observation takes the earliest unused receipt for its URL and key within tolerance.
    queues = {}
    for row in fetches:
        queues.setdefault((row['body']['resource'], row['body']['bot']['keyid']), deque()).append(row)
    unmatched = []
    for ident, body in observed:
        queue = queues.get((body['url'], body['keyid']), deque())
        while queue and queue[0]['body']['at'] < body['at'] - tolerance:
            queue.popleft()
        if queue and queue[0]['body']['at'] <= body['at'] + tolerance:
            queue.popleft()
        else:
            unmatched.append((ident, body))
    model = price['model']
    periods = [row['body'] for row in payments if _priced(price, row['body']['charged'], 1)]

    def covered(at):
        if model == 'SUBSCRIPTION':
            return any(body['period'] is not None and body['period']['from'] <= at < body['period']['to'] for body in periods)
        return any(body['at'] <= at for body in periods)

    for kind, rows in (('UNPAID_FETCH', fetches), ('UNPAID_USE', uses)):
        if model not in crawl_terms.PAID:
            continue
        short = []
        for row in rows:
            body = row['body']
            if model == ('PER_CRAWL' if kind == 'UNPAID_FETCH' else 'PER_USE'):
                paid = _priced(price, body['charged'], body['count'])
            elif model in ('SUBSCRIPTION', 'PURCHASE'):
                paid = covered(body['at'])
            else:
                continue
            if not paid:
                short.append(_row('RECEIPT', row['id'], row['assurance']))
        if kind == 'UNPAID_FETCH':
            for ident, body in unmatched:
                if model == 'PER_CRAWL':
                    paid = _priced(price, body['charged'], 1)
                elif model in ('SUBSCRIPTION', 'PURCHASE'):
                    paid = covered(body['at'])
                else:
                    continue
                if not paid:
                    short.append(_row('OBSERVATION', ident, 'PUBLISHER_SIGNED'))
        if short:
            finding(kind, {'model': model, 'price': {'amount': price['amount'], 'unit': price['unit']},
                           'period': price['period']}, short)
    # Over-crawling: total fetches and a sliding rate window, counting receipted and unreceipted fetches.
    timeline = sorted([(row['body']['at'], row['id'], 'RECEIPT', row['assurance']) for row in fetches] +
                      [(body['at'], ident, 'OBSERVATION', 'PUBLISHER_SIGNED') for ident, body in unmatched])
    if limits['fetches'] is not None and len(timeline) > limits['fetches']:
        finding('OVER_CRAWL', {'limit': limits['fetches'], 'count': len(timeline), 'window': None},
                [_row(kind, ident, assurance) for _at, ident, kind, assurance in timeline[limits['fetches']:]])
    if limits['rate'] is not None:
        window, allowed, start, excess, peak = limits['rate']['window'], limits['rate']['count'], 0, [], 0
        for index, (at, ident, kind, assurance) in enumerate(timeline):
            while timeline[start][0] <= at - window:
                start += 1
            count = index - start + 1
            peak = max(peak, count)
            if count > allowed:
                excess.append(_row(kind, ident, assurance))
        if excess:
            finding('OVER_CRAWL', {'limit': allowed, 'count': peak, 'window': window}, excess)
    # Receipt chains: gaps, broken links and two receipts for one sequence number are reported per bot key, not
    # judged. Gaps are listed from the sorted sequence numbers, so a huge claimed sequence costs nothing extra.
    chains = []
    for key in sorted({row['body']['bot']['key'] for row in events}):
        rows = sorted((row for row in events if row['body']['bot']['key'] == key), key=lambda row: (row['body']['sequence'], row['id']))
        by_sequence = {}
        for row in rows:
            by_sequence.setdefault(row['body']['sequence'], []).append(row)
        present, missing, expected = sorted(by_sequence), [], 0
        for number in present:
            while expected < number and len(missing) < MAX_EVIDENCE:
                missing.append(expected); expected += 1
            expected = number + 1
        broken = sum(1 for number in present if number > 0 and number - 1 in by_sequence
                     for row in by_sequence[number] if row['body']['previous'] not in {r['id'] for r in by_sequence[number - 1]})
        chains.append({'bot': key, 'receipts': len(rows), 'highest': present[-1], 'missing': missing,
                       'missing_total': present[-1] + 1 - len(present), 'broken_links': broken,
                       'equivocations': sum(1 for group in by_sequence.values() if len(group) > 1)})
    return {'version': PROFILE, 'agreement': view['agreement'], 'terms': view['terms'], 'as_of': as_of,
            'receipts': len(events), 'observations': len(observed), 'foreign_observations': foreign,
            'unreceipted_fetches': len(unmatched), 'refused': refused[:256], 'findings': findings, 'chains': chains,
            'clean': not findings, 'basis': 'SIGNED_RECEIPTS_AND_PUBLISHER_OBSERVATIONS_ONLY; NOT_WORLD_TRUTH', **FLAGS}


def _finding(view, finding):
    need(type(finding) is dict and set(finding) == set(FINDING_FIELDS.split()) | {'id'}, 'CRAWL_FINDING_FIELDS')
    value = {name: finding[name] for name in FINDING_FIELDS.split()}
    need(value['version'] == FINDING and value['agreement'] == view['agreement'] and value['terms'] == view['terms']
         and value['kind'] in KINDS and type(value['detail']) is dict and type(value['evidence']) is list
         and 1 <= len(value['evidence']) <= MAX_EVIDENCE and type(value['evidence_total']) is int
         and value['evidence_total'] >= len(value['evidence']) and type(value['as_of']) is int, 'CRAWL_FINDING_FIELDS')
    for row in value['evidence']:
        need(type(row) is dict and set(row) == {'kind', 'id', 'assurance'} and row['kind'] in ('OBSERVATION', 'RECEIPT')
             and row['assurance'] in ('COUNTERSIGNED', 'CRAWLER_SIGNED', 'PUBLISHER_SIGNED'), 'CRAWL_FINDING_FIELDS')
        _hex(row['id'], 'CRAWL_FINDING_FIELDS')
    try:
        ident = app.content_id(FINDING_LABEL, value)
    except ValueError:
        raise ValueError('CRAWL_FINDING_FIELDS') from None
    need(ident == finding['id'], 'CRAWL_FINDING_FIELDS')
    return value, ident


def finding_payload(view, finding, role):
    """What the crawler or publisher signs to stand behind a finding. Signing it opens nothing by itself."""
    value, ident = _finding(view, finding)
    need(role in ('crawler', 'publisher'), 'CRAWL_FINDING_SIGNATURE')
    return {'label': FINDING_LABEL, 'body': value, 'id': ident, 'signer': view[role], **FLAGS}


def verify_finding(view, finding, signature, role):
    value, ident = _finding(view, finding)
    need(role in ('crawler', 'publisher'), 'CRAWL_FINDING_SIGNATURE')
    crawl_terms._checked(verify, 'CRAWL_FINDING_SIGNATURE', view[role], FINDING_LABEL, value, signature)
    return ident


def _ladder(view, ladder, role):
    route = view['body']['dispute']
    need(route['ladder'] is not None, 'CRAWL_DISPUTE_NO_ROUTE')
    need(type(ladder) is dict and set(ladder) == {'policy', 'adoptions', 'events'}, 'CRAWL_DISPUTE_LADDER')
    policy = ladder['policy']
    try:
        ref = procedures.identifier(policy)
    except ValueError:
        raise ValueError('CRAWL_DISPUTE_LADDER') from None
    need(ref == route['ladder'], 'CRAWL_DISPUTE_ROUTE')
    need(policy['kind'] == 'ESCALATION', 'CRAWL_DISPUTE_LADDER')
    c = policy['configuration']
    roles = {app.canonical(policy['parties'][name]): name for name in c['disputants']}
    mine = roles.get(app.canonical(view[role]))
    other = roles.get(app.canonical(view['publisher' if role == 'crawler' else 'crawler']))
    need(mine is not None and other is not None and mine != other, 'CRAWL_DISPUTE_PARTIES')
    need(sum(stage['bond'] for stage in c['stages']) <= route['bond_cap'], 'CRAWL_DISPUTE_BOND_NOT_AGREED')
    for result in c['outcomes']:
        moves = 'escrow' in result or {'release', 'refund'} & set(result)
        need(not moves or route['escrow'] is not None and result.get('escrow') == {'kind': 'HASH', 'value': route['escrow']},
             'CRAWL_DISPUTE_ESCROW_NOT_AGREED')
    return ref, mine


def dispute_payload(view, finding, signature, ladder, *, role, at, outcome, bond_receipt=None):
    """The signed OPEN event the claimant's ladder role signs next, claiming with the signed finding.

    The ladder must be the one the licence names, with the licence's two parties as disputants, bonds within
    the signed cap and escrow effects only on the escrow the licence names. The ladder then decides.
    """
    ident = verify_finding(view, finding, signature, role)
    ref, actor = _ladder(view, ladder, role)
    payload = procedures.event_payload(ladder['policy'], ladder['adoptions'], ladder['events'], actor, 'OPEN',
                                       {'claim': ident, 'result': deepcopy(outcome), 'bond_receipt': bond_receipt}, at)
    return {'version': FINDING, 'ladder': ref, 'actor': actor, 'claim': ident, 'event_payload': payload,
            'forum': deepcopy(view['body']['dispute']['forum']),
            'next': 'The claimant signs event_payload.body with its own key and appends it to the ladder; the ladder '
                    'decides. Bond receipts stay claims until an adopted observer verifies them.', **FLAGS}


def forum_route(view, registry):
    """The licence's LCP forum mapped through the owner's forum registry: BOUND, or UNKNOWN with a human prompt."""
    forum = view['body']['dispute']['forum']
    need(forum is not None, 'CRAWL_DISPUTE_NO_FORUM')
    return {'forum': deepcopy(forum), 'mapping': forum_arbiter.host_forum(registry, {'method': forum['method']}), **FLAGS}


def referral(view, finding, signature, role, adapter, *, ladder_head=None):
    """The AAA path: refer a signed finding to the forum the licence's LCP disputeResolution names.

    ``adapter`` is owner-installed (forum_arbiter.MockAaaAdapter for AAA-ICDR); its method must equal the signed
    forum method and the licence must carry the LCP clause id. The packet names the finding and its evidence ids;
    the mock adapter records a local case id. Nothing is filed and no institution is contacted.
    """
    ident = verify_finding(view, finding, signature, role)
    forum = view['body']['dispute']['forum']
    need(forum is not None, 'CRAWL_DISPUTE_NO_FORUM')
    need(getattr(adapter, 'method', None) == forum['method'] and callable(getattr(adapter, 'open_case', None))
         and forum['clause'] is not None, 'CRAWL_DISPUTE_FORUM')
    if ladder_head is not None:
        _hex(ladder_head, 'CRAWL_DISPUTE_LADDER')
    opened = adapter.open_case(forum['clause'][len('sha256:0x'):],
                               'AAP crawl finding ' + ident + ' (' + finding['kind'] + ') under agreement ' + view['agreement'])
    packet = {'version': REFERRAL, 'agreement': view['agreement'], 'terms': view['terms'], 'finding': ident,
              'kind': finding['kind'], 'evidence': [row['id'] for row in finding['evidence']],
              'evidence_total': finding['evidence_total'], 'forum': deepcopy(forum), 'case': opened['case'],
              'ladder_head': ladder_head}
    return {'packet': packet, 'id': app.content_id(REFERRAL, packet), 'case': opened['case'],
            'mock': bool(opened.get('mock')), **FLAGS}


def describe():
    return {'profile': PROFILE, 'finding': FINDING, 'observation': OBSERVATION, 'referral': REFERRAL,
            'kinds': list(KINDS), 'evidence': 'SIGNED_RECEIPTS_AND_PUBLISHER_SIGNED_EDGE_OBSERVATIONS',
            'ladder': procedures.VERSION, 'forum': 'LCP_DISPUTE_RESOLUTION_VIA_OWNER_FORUM_REGISTRY',
            'limits': {'receipts': MAX_RECEIPTS, 'observations': MAX_OBSERVATIONS, 'evidence_per_finding': MAX_EVIDENCE},
            'errors': {code: explain(code) for code in sorted(ERRORS)}, **FLAGS}
