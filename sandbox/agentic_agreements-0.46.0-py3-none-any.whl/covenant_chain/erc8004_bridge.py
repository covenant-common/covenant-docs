"""ERC-8004 registries as optional, owner-operated legs beside receipt-based reputation.

ERC-8004 "Trustless Agents" (Draft; ethereum/ERCs ERCS/erc-8004.md, last modified
2026-01-25, commit 503591a; reference contracts getVersion 2.0.0):

* Export (GRAFT): a verified AAP portable-trust OUTCOME receipt becomes the two
  Validation Registry calls, ``validationRequest(address,uint256,string,bytes32)``
  by the agent owner and ``validationResponse(bytes32,uint8,string,bytes32,string)``
  by the named validator, as Solidity ABI calldata plus the off-chain request and
  response documents (RFC 8785 bytes) whose keccak256 values are the request and
  response hashes. FULFILLED maps to 100 and FAILED to 0; DISPUTED and UNKNOWN
  are not exported, because an unknown outcome never becomes a number. Nothing
  is signed, sent or broadcast: the owner submits the bytes, or does not.
* Import (TAKE-AND-IMPROVE): ``NewFeedback`` event logs and off-chain feedback
  files are read into a weak, labelled signal per agent. Feedback is free-form
  and unanchored, so it never enters ``anchored_reputation``: it is reported
  beside a ranking, never inside its scores, standings or order.
"""
from copy import deepcopy
from decimal import Decimal
import re

from .anchor import keccak256
from .crypto import need
from . import interop_codec as codec

VERSION = 'covenant-erc8004-bridge/0.1'
EIP = 'ERC-8004 (Draft, erc-8004.md 2026-01-25, commit 503591a6)'
REQUEST_FUNCTION = 'validationRequest(address,uint256,string,bytes32)'
RESPONSE_FUNCTION = 'validationResponse(bytes32,uint8,string,bytes32,string)'
NEW_FEEDBACK = 'NewFeedback(uint256,address,uint64,int128,uint8,string,string,string,string,string,bytes32)'
TAG = 'aap-outcome'
RESPONSES = {'FULFILLED': 100, 'FAILED': 0}
FEEDBACK_REQUIRED = ('agentRegistry', 'agentId', 'clientAddress', 'createdAt', 'value', 'valueDecimals')
MAX_ENTRIES = 1024
MAX_LOG_DATA = 16384
MAX_URI = 2048
ADDRESS = re.compile(r'0x[0-9a-fA-F]{40}\Z')
REGISTRY = re.compile(r'eip155:([1-9][0-9]{0,18}):(0x[0-9a-fA-F]{40})\Z')

REMEDIATION = {
    'ERC8004_ADDRESS': 'Use a 0x-prefixed 20-byte address; mixed case must be a valid EIP-55 checksum.',
    'ERC8004_REGISTRY': 'Name the registry as eip155:<chainId>:<identity registry address>.',
    'ERC8004_AGENT_ID': 'Use the ERC-721 agentId as an integer from 0 to 2**256 - 1.',
    'ERC8004_URI': 'Use an ipfs://, https:// or ar:// URI of at most 2048 printable ASCII characters.',
    'ERC8004_OUTCOME': 'Supply a verified covenant-portable-trust/0.1 OUTCOME receipt.',
    'ERC8004_NOT_EXPORTABLE': 'Only FULFILLED (100) and FAILED (0) outcomes export; DISPUTED and UNKNOWN stay unknown.',
    'ERC8004_LOG': 'Supply a NewFeedback log {topics: [4 x 32-byte hex], data: hex} from the Reputation Registry.',
    'ERC8004_ABI': 'The log data is not a valid ABI encoding of the NewFeedback fields.',
    'ERC8004_FILE': 'Supply a feedback file with agentRegistry, agentId, clientAddress, createdAt, value and valueDecimals.',
    'ERC8004_HASH': 'The feedback file does not match the keccak256 feedbackHash it was published with.',
    'ERC8004_INPUT': 'Pass at most 1024 entries, each {log} or {file[, hash]}.',
}


def remediation(code):
    return REMEDIATION.get(code, codec.remediation(code))


def selector(signature):
    return keccak256(signature.encode('ascii'))[:4]


def topic(signature):
    return '0x' + keccak256(signature.encode('ascii')).hex()


def address(value):
    """A 20-byte address; mixed case must carry a valid EIP-55 checksum."""
    need(type(value) is str and ADDRESS.fullmatch(value) is not None, 'ERC8004_ADDRESS')
    body = value[2:]
    if body != body.lower() and body != body.upper():
        hashed = keccak256(body.lower().encode('ascii')).hex()
        need(all((char.upper() if int(hashed[i], 16) >= 8 else char.lower()) == char for i, char in enumerate(body)),
             'ERC8004_ADDRESS')
    return '0x' + body.lower()


def registry(value):
    found = REGISTRY.fullmatch(value) if type(value) is str else None
    need(found is not None, 'ERC8004_REGISTRY')
    return 'eip155:' + found.group(1) + ':' + address(found.group(2))


def _uri(value):
    need(type(value) is str and 0 < len(value) <= MAX_URI and value.isascii() and value.isprintable()
         and value.startswith(('ipfs://', 'https://', 'ar://')), 'ERC8004_URI')
    return value


def _agent_id(value):
    need(type(value) is int and 0 <= value < 2**256, 'ERC8004_AGENT_ID')
    return value


def _word(value):
    return value.to_bytes(32, 'big')


def _string(text):
    raw = text.encode('utf-8')
    return _word(len(raw)) + raw + b'\0' * (-len(raw) % 32)


def abi(types, values):
    """Solidity ABI head/tail encoding for address, uint, bytes32 and string arguments."""
    heads, tails = [], b''
    offset = 32 * len(types)
    for kind, value in zip(types, values):
        if kind == 'string':
            heads.append(_word(offset + len(tails)))
            tails += _string(value)
        elif kind == 'address':
            heads.append(b'\0' * 12 + bytes.fromhex(address(value)[2:]))
        elif kind == 'bytes32':
            need(type(value) is bytes and len(value) == 32, 'ERC8004_ABI'); heads.append(value)
        else:
            bits = int(kind[4:])
            need(kind.startswith('uint') and type(value) is int and 0 <= value < 2**bits, 'ERC8004_ABI')
            heads.append(_word(value))
    return b''.join(heads) + tails


def _outcome(record, adopted_resolvers):
    from . import portable_trust
    try:
        body = record['body']
        reference = portable_trust.record_id(body)
        need(body['kind'] == 'OUTCOME', 'ERC8004_OUTCOME')
        portable_trust.verify_outcome(record, reference, body['agreement'], body['context'], body['subject'], adopted_resolvers)
    except (ValueError, KeyError, TypeError):
        raise ValueError('ERC8004_OUTCOME') from None
    return body, reference


def export_outcome(record, *, agent_registry, agent_id, validator, request_uri, response_uri, adopted_resolvers=None):
    """Validation Registry request and response bytes for one verified AAP outcome receipt."""
    body, reference = _outcome(record, adopted_resolvers)
    need(body['outcome'] in RESPONSES, 'ERC8004_NOT_EXPORTABLE')
    agent_registry, validator = registry(agent_registry), address(validator)
    agent_id, request_uri, response_uri = _agent_id(agent_id), _uri(request_uri), _uri(response_uri)
    request = {'profile': VERSION, 'kind': 'VALIDATION_REQUEST', 'agentRegistry': agent_registry, 'agentId': str(agent_id),
               'validatorAddress': validator, 'outcome': reference, 'agreement': body['agreement'], 'context': body['context'],
               'subject': deepcopy(body['subject'])}
    request_bytes = codec.jcs(request)
    request_hash = keccak256(request_bytes)
    response = {'profile': VERSION, 'kind': 'VALIDATION_RESPONSE', 'requestHash': '0x' + request_hash.hex(),
                'response': RESPONSES[body['outcome']], 'outcome': reference, 'receipt': deepcopy(record),
                'basis': 'AAP_SIGNED_OUTCOME_ASSERTION_NOT_PAYMENT_OR_WORLD_TRUTH'}
    response_bytes = codec.jcs(response)
    response_hash = keccak256(response_bytes)
    call_request = selector(REQUEST_FUNCTION) + abi(('address', 'uint256', 'string', 'bytes32'),
                                                    (validator, agent_id, request_uri, request_hash))
    call_response = selector(RESPONSE_FUNCTION) + abi(('bytes32', 'uint8', 'string', 'bytes32', 'string'),
                                                      (request_hash, RESPONSES[body['outcome']], response_uri, response_hash, TAG))
    return {'outcome': reference, 'response': RESPONSES[body['outcome']], 'agent_registry': agent_registry, 'agent_id': agent_id,
            'request': {'uri': request_uri, 'document': request_bytes.decode('utf-8'), 'hash': '0x' + request_hash.hex(),
                        'function': REQUEST_FUNCTION, 'calldata': '0x' + call_request.hex(), 'sender': 'AGENT_OWNER_OR_OPERATOR'},
            'validation': {'uri': response_uri, 'document': response_bytes.decode('utf-8'), 'hash': '0x' + response_hash.hex(),
                           'function': RESPONSE_FUNCTION, 'calldata': '0x' + call_response.hex(), 'tag': TAG,
                           'sender': validator},
            'submitted': False, 'broadcast': False, 'chain_checked': False, 'registry_address_checked': False,
            'execution_authorized': False}


def _hex(text, maximum):
    need(type(text) is str and text.startswith('0x') and len(text) % 2 == 0 and len(text) <= 2 + 2 * maximum
         and re.fullmatch('0x[0-9a-fA-F]*', text) is not None, 'ERC8004_LOG')
    return bytes.fromhex(text[2:])


def _dynamic(data, offset):
    need(offset % 32 == 0 and offset + 32 <= len(data), 'ERC8004_ABI')
    size = int.from_bytes(data[offset:offset + 32], 'big')
    need(size <= len(data) - offset - 32 and size <= MAX_URI * 2, 'ERC8004_ABI')
    raw = data[offset + 32:offset + 32 + size]
    need(data[offset + 32 + size:offset + 32 + size + (-size % 32)] == b'\0' * (-size % 32), 'ERC8004_ABI')
    try:
        return raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('ERC8004_ABI') from None


def decode_feedback(log):
    """One NewFeedback log (topics: signature, agentId, clientAddress, keccak(tag1); data: the rest)."""
    need(type(log) is dict and set(log) == {'topics', 'data'} and type(log['topics']) is list and len(log['topics']) == 4,
         'ERC8004_LOG')
    topics = [_hex(item, 32) for item in log['topics']]
    need(all(len(item) == 32 for item in topics) and '0x' + topics[0].hex() == topic(NEW_FEEDBACK), 'ERC8004_LOG')
    data = _hex(log['data'], MAX_LOG_DATA)
    need(len(data) >= 32 * 8 and len(data) % 32 == 0 and topics[2][:12] == b'\0' * 12, 'ERC8004_ABI')
    words = [data[i:i + 32] for i in range(0, 32 * 8, 32)]
    index, raw_value, decimals = (int.from_bytes(words[i], 'big') for i in range(3))
    value = raw_value - 2**256 if raw_value >= 2**255 else raw_value
    need(index < 2**64 and -2**127 <= value < 2**127 and decimals <= 18, 'ERC8004_ABI')
    tag1, tag2, endpoint, uri = (_dynamic(data, int.from_bytes(words[i], 'big')) for i in range(3, 7))
    need(keccak256(tag1.encode('utf-8')) == topics[3], 'ERC8004_ABI')
    return {'agent_id': int.from_bytes(topics[1], 'big'), 'client': '0x' + topics[2][12:].hex(), 'index': index,
            'value': value, 'decimals': decimals, 'tag1': tag1, 'tag2': tag2, 'endpoint': endpoint,
            'feedback_uri': uri, 'feedback_hash': '0x' + words[7].hex()}


def _file(text, expected_hash):
    need(type(text) is str and len(text) <= 65536, 'ERC8004_FILE')
    if expected_hash is not None:
        need('0x' + keccak256(text.encode('utf-8')).hex() == '0x' + _hex(expected_hash, 32).hex(), 'ERC8004_HASH')
    try:
        value = codec.parse(text, 65536, 16, 2048)
    except ValueError:
        raise ValueError('ERC8004_FILE') from None
    need(type(value) is dict and all(name in value for name in FEEDBACK_REQUIRED), 'ERC8004_FILE')
    need(type(value['value']) is int and -2**127 <= value['value'] < 2**127 and type(value['valueDecimals']) is int
         and 0 <= value['valueDecimals'] <= 18 and type(value['agentId']) is int and type(value['clientAddress']) is str, 'ERC8004_FILE')
    client = value['clientAddress'].rsplit(':', 1)[-1]
    return {'agent_id': _agent_id(value['agentId']), 'client': address(client), 'registry': registry(value['agentRegistry']),
            'value': value['value'], 'decimals': value['valueDecimals'], 'tag1': str(value.get('tag1', '')),
            'tag2': str(value.get('tag2', '')), 'endpoint': str(value.get('endpoint', '')), 'created_at': str(value['createdAt'])}


def feedback_signal(entries, agent_registry):
    """A weak, labelled per-agent summary of ERC-8004 feedback; it never enters an AAP score."""
    agent_registry = registry(agent_registry)
    need(type(entries) is list and len(entries) <= MAX_ENTRIES, 'ERC8004_INPUT')
    agents, excluded = {}, []
    for index, entry in enumerate(entries):
        try:
            need(type(entry) is dict and (set(entry) == {'log'} or set(entry) in ({'file'}, {'file', 'hash'})), 'ERC8004_INPUT')
            row = decode_feedback(entry['log']) if 'log' in entry else _file(entry['file'], entry.get('hash'))
            need(row.get('registry', agent_registry) == agent_registry, 'ERC8004_REGISTRY')
        except ValueError as error:
            code = str(error)
            excluded.append({'index': index, 'status': 'EXCLUDED', 'reason': code if code in REMEDIATION else 'ERC8004_INPUT'})
            continue
        slot = agents.setdefault(row['agent_id'], {'entries': 0, 'clients': set(), 'tags': {}, 'values': []})
        slot['entries'] += 1; slot['clients'].add(row['client'])
        slot['tags'][row['tag1']] = slot['tags'].get(row['tag1'], 0) + 1
        slot['values'].append(str(Decimal(row['value']).scaleb(-row['decimals'])))
    summary = {str(agent): {'entries': slot['entries'], 'distinct_clients': len(slot['clients']),
                            'tags': dict(sorted(slot['tags'].items())), 'values': slot['values'][:64]}
               for agent, slot in sorted(agents.items())}
    return {'signal': 'ERC8004_FEEDBACK', 'agent_registry': agent_registry, 'agents': summary, 'excluded': excluded,
            'weight': 'WEAK_UNANCHORED_LABELLED_NOT_SCORED', 'sybil_resistance': 'NONE_FREE_FORM_CLIENT_FEEDBACK',
            'enters_score': False, 'world_truth_verified': False, 'network_accessed': False, 'execution_authorized': False}


def annotate(ranking, signal, agent_ids):
    """Report a feedback signal beside an anchored ranking. The ranking itself is returned unchanged.

    ``agent_ids`` maps AAP provider keys to the ERC-8004 agentId the owner believes they hold;
    that mapping is the owner's claim, not verified identity.
    """
    need(type(ranking) is dict and type(ranking.get('ranking')) is list and type(signal) is dict
         and signal.get('signal') == 'ERC8004_FEEDBACK' and type(agent_ids) is dict and len(agent_ids) <= 256, 'ERC8004_INPUT')
    beside = {}
    for row in ranking['ranking']:
        agent = agent_ids.get(row['provider'])
        if type(agent) is int and str(agent) in signal['agents']:
            beside[row['provider']] = {**signal['agents'][str(agent)], 'agent_id': agent, 'label': signal['weight']}
    return {'ranking': deepcopy(ranking), 'external_signals': beside, 'external_signals_enter_score': False,
            'mapping': 'OWNER_ASSERTED_AGENT_IDS', 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_ADAPTER', 'eip': EIP,
            'export': {'functions': [REQUEST_FUNCTION, RESPONSE_FUNCTION], 'responses': dict(RESPONSES), 'tag': TAG,
                       'documents': 'RFC8785_BYTES_KECCAK256_HASHES', 'submitted': False},
            'import': {'event': NEW_FEEDBACK, 'topic': topic(NEW_FEEDBACK), 'file_required': list(FEEDBACK_REQUIRED),
                       'weight': 'WEAK_UNANCHORED_LABELLED_NOT_SCORED', 'enters_score': False},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
