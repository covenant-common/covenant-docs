"""BPv7 bundles (RFC 9171) around AAP canonical bytes, with an optional BPSec BIB.

The bundle is the outer delay-tolerant frame, so a bundle agent such as ION,
uD3TN or dtn7 can store, carry and forward AAP bytes. The payload block holds
the exact canonical bytes (for an offline envelope: crypto.canonical of the
signed packet). That AAP signature stays authoritative. Block CRCs
(CRC-16/X-25 or CRC-32C, RFC 9171 section 4.2.1) catch accidental damage only.

The optional Block Integrity Block (RFC 9172) uses an AAP-defined security
context: the existing Ed25519 rule, label || 0x00 || canonical JSON, over the
target block and the primary block. Its id is negative, a local/site-specific
value under RFC 9172 section 11.3. A verified BIB binds routing fields to a
pinned key; it never replaces the AAP signature, and no carrier result
certifies settlement.

Accepted: one unfragmented bundle; ipn and dtn endpoint IDs; Previous Node,
Bundle Age and Hop Count blocks; unknown blocks unless flagged for deletion.
Refused: fragments, BCB-encrypted payloads, administrative records as AAP
payloads, and any CBOR that is not deterministic apart from the outer array.
No convergence layer, routing or status report is implemented.
"""
import hashlib
import re

from . import cbor, crypto as c

VERSION = 'covenant-bpv7-carrier/0.1'
BIB_VERSION = 'covenant-bpsec-ed25519/0.1'
BIB_LABEL = 'COVENANT-BPSEC-ED25519-0.1'
BIB_CONTEXT = -16705
DTN_EPOCH = 946684800
CRC_NONE, CRC16, CRC32C = 0, 1, 2
PAYLOAD, PREVIOUS_NODE, BUNDLE_AGE, HOP_COUNT, BIB, BCB = 1, 6, 7, 10, 11, 12
FRAGMENT, ADMIN_RECORD, NO_FRAGMENT = 0x01, 0x02, 0x04
REPORTS = 0x004000 | 0x010000 | 0x020000 | 0x040000
BLOCK_STATUS, BLOCK_DELETE = 0x02, 0x04
NONE = 'dtn:none'
MAX_PAYLOAD = 131072
MAX_BUNDLE = MAX_PAYLOAD + 8192
MAX_BLOCKS = 16
_DTN = re.compile(r"//(?:[A-Za-z0-9._~!$&'()*+,;=-]|%[0-9A-Fa-f]{2})+/[\x21-\x7e]*\Z")
_IPN = re.compile(r'ipn:(0|[1-9][0-9]{0,19})\.(0|[1-9][0-9]{0,19})\Z')


def _table(poly):
    rows = []
    for byte in range(256):
        crc = byte
        for _ in range(8):
            crc = crc >> 1 ^ poly if crc & 1 else crc >> 1
        rows.append(crc)
    return rows


_X25, _C32 = _table(0x8408), _table(0x82F63B78)


def crc16_x25(raw):
    """CRC-16/X-25: reflected 0x1021, init and xorout 0xFFFF; check 0x906E."""
    crc = 0xFFFF
    for byte in raw:
        crc = crc >> 8 ^ _X25[(crc ^ byte) & 0xFF]
    return crc ^ 0xFFFF


def crc32c(raw):
    """CRC-32C (Castagnoli): reflected 0x1EDC6F41, init and xorout 0xFFFFFFFF; check 0xE3069283."""
    crc = 0xFFFFFFFF
    for byte in raw:
        crc = crc >> 8 ^ _C32[(crc ^ byte) & 0xFF]
    return crc ^ 0xFFFFFFFF


def _crc(crc_type, raw):
    if crc_type == CRC16:
        return crc16_x25(raw).to_bytes(2, 'big')
    return crc32c(raw).to_bytes(4, 'big')


def _uint(value, code):
    c.need(type(value) is int and 0 <= value < cbor.LIMIT, code)
    return value


def eid(text):
    """Text endpoint ID to its RFC 9171 section 4.2.5 CBOR form."""
    c.need(type(text) is str and 0 < len(text) <= 1024, 'BPV7_EID')
    if text == NONE:
        return [1, 0]
    if text.startswith('dtn:'):
        c.need(_DTN.fullmatch(text[4:]) is not None, 'BPV7_EID')
        return [1, text[4:]]
    found = _IPN.fullmatch(text)
    c.need(found is not None, 'BPV7_EID')
    node, service = int(found.group(1)), int(found.group(2))
    c.need(node < cbor.LIMIT and service < cbor.LIMIT, 'BPV7_EID')
    return [2, [node, service]]


def eid_text(value):
    """CBOR endpoint ID to text. The RFC 9758 three-number ipn form is refused."""
    c.need(type(value) is list and len(value) == 2 and type(value[0]) is int, 'BPV7_EID')
    scheme, ssp = value
    if scheme == 1 and type(ssp) is int:
        c.need(ssp == 0, 'BPV7_EID')
        return NONE
    if scheme == 1:
        c.need(type(ssp) is str and len(ssp) <= 1020 and _DTN.fullmatch(ssp) is not None, 'BPV7_EID')
        return 'dtn:' + ssp
    c.need(scheme == 2 and type(ssp) is list and len(ssp) == 2, 'BPV7_EID')
    return 'ipn:%d.%d' % (_uint(ssp[0], 'BPV7_EID'), _uint(ssp[1], 'BPV7_EID'))


def singleton(text):
    """Every ipn EID is a singleton; a dtn demux starting with '~' names a group (section 4.2.5.1.1)."""
    eid(text)
    if text == NONE:
        return False
    return text.startswith('ipn:') or not text[4:].split('/', 3)[3].startswith('~')


def _block(items, crc_type):
    """One block; its CRC covers the whole block with the CRC field zeroed (RFC 9171 sections 4.2.2, 4.3)."""
    if crc_type == CRC_NONE:
        return cbor.encode(items)
    size = 2 if crc_type == CRC16 else 4
    zeroed = cbor.encode(list(items) + [bytes(size)])
    return zeroed[:-size] + _crc(crc_type, zeroed)


def _check_crc(value, raw, crc_type):
    size = 2 if crc_type == CRC16 else 4
    c.need(type(value[-1]) is bytes and len(value[-1]) == size, 'BPV7_CRC')
    c.need(_crc(crc_type, raw[:-size] + bytes(size)) == raw[-size:], 'BPV7_CRC')


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _bib_body(source, primary, target, block):
    return {'profile': BIB_VERSION, 'context': BIB_CONTEXT, 'security_source': source,
            'primary_sha256': _sha(primary), 'target': target, 'block_type': block['type'],
            'block_flags': block['flags'], 'data_sha256': _sha(block['data'])}


def _bib_data(signing_key, source, primary, target, block):
    public = c.public_key(signing_key)
    c.need(type(public) is str, 'BPV7_BIB_ED25519_ONLY')
    signature = c.sign(signing_key, BIB_LABEL, _bib_body(source, primary, target, block))
    # The abstract security block is a CBOR sequence (RFC 9172 section 3.6).
    return b''.join(cbor.encode(item) for item in (
        [target], BIB_CONTEXT, 1, eid(source), [[1, bytes.fromhex(public)]],
        [[[1, bytes.fromhex(signature)]]]))


def encode_bundle(payload, *, source, destination, created_ms, lifetime_ms, report_to=NONE,
                  sequence=0, crc_type=CRC32C, bundle_age_ms=None, signing_key=None,
                  security_source=None):
    """One unfragmented bundle. A zero creation time needs a Bundle Age block."""
    c.need(type(payload) is bytes and 0 < len(payload) <= MAX_PAYLOAD, 'BPV7_PAYLOAD_SIZE')
    c.need(crc_type in (CRC16, CRC32C), 'BPV7_CRC_TYPE')
    for value in (created_ms, lifetime_ms, sequence):
        _uint(value, 'BPV7_TIMESTAMP')
    c.need(source == NONE or singleton(source), 'BPV7_SOURCE')
    c.need(created_ms > 0 or bundle_age_ms is not None, 'BPV7_BUNDLE_AGE_REQUIRED')
    primary = _block([7, NO_FRAGMENT, crc_type, eid(destination), eid(source), eid(report_to),
                      [created_ms, sequence], lifetime_ms], crc_type)
    blocks, number = [], 2
    if bundle_age_ms is not None:
        blocks.append(_block([BUNDLE_AGE, number, 0, crc_type,
                              cbor.encode(_uint(bundle_age_ms, 'BPV7_BUNDLE_AGE'))], crc_type))
        number += 1
    if signing_key is not None:
        signer = security_source or source
        c.need(signer != NONE and singleton(signer), 'BPV7_BIB_SOURCE')
        data = _bib_data(signing_key, signer, primary, PAYLOAD, {'type': PAYLOAD, 'flags': 0, 'data': payload})
        blocks.append(_block([BIB, number, 0, crc_type, data], crc_type))
    raw = b'\x9f' + primary + b''.join(blocks) + _block([PAYLOAD, 1, 0, crc_type, payload], crc_type) + b'\xff'
    c.need(len(raw) <= MAX_BUNDLE, 'BPV7_SIZE')
    return raw


def _pairs(value, code):
    c.need(type(value) is list and len(value) <= 16, code)
    for pair in value:
        c.need(type(pair) is list and len(pair) == 2, code)
        _uint(pair[0], code)
    return value


def _asb(data):
    items = cbor.decode_sequence(data, 6)
    c.need(len(items) in (5, 6), 'BPV7_ASB')
    targets, context, flags, source = items[:4]
    c.need(type(targets) is list and 1 <= len(targets) <= MAX_BLOCKS and
           len(set(_uint(n, 'BPV7_ASB_TARGETS') for n in targets)) == len(targets), 'BPV7_ASB_TARGETS')
    c.need(type(context) is int and -32768 <= context <= 32767, 'BPV7_ASB_CONTEXT')
    c.need(len(items) == (6 if _uint(flags, 'BPV7_ASB') & 1 else 5), 'BPV7_ASB')
    results = items[-1]
    c.need(type(results) is list and len(results) == len(targets), 'BPV7_ASB_RESULTS')
    return {'targets': targets, 'context': context, 'flags': flags, 'source': eid_text(source),
            'parameters': _pairs(items[4] if len(items) == 6 else [], 'BPV7_ASB_PARAMETERS'),
            'results': [_pairs(row, 'BPV7_ASB_RESULTS') for row in results]}


def _primary(value, raw):
    c.need(type(value) is list and 8 <= len(value) <= 11, 'BPV7_PRIMARY')
    version, flags, crc_type = value[:3]
    c.need(type(version) is int and version == 7, 'BPV7_VERSION')
    _uint(flags, 'BPV7_FLAGS')
    c.need(type(crc_type) is int and crc_type in (CRC_NONE, CRC16, CRC32C), 'BPV7_CRC_TYPE')
    c.need(not flags & FRAGMENT, 'BPV7_FRAGMENT_UNSUPPORTED')
    c.need(len(value) == (9 if crc_type else 8), 'BPV7_PRIMARY')
    if crc_type:
        _check_crc(value, raw, crc_type)
    source = eid_text(value[4])
    c.need(source == NONE or singleton(source), 'BPV7_SOURCE')
    stamp = value[6]
    c.need(type(stamp) is list and len(stamp) == 2, 'BPV7_TIMESTAMP')
    if source == NONE or flags & ADMIN_RECORD:
        c.need(not flags & REPORTS and (source != NONE or flags & NO_FRAGMENT), 'BPV7_ANONYMOUS_FLAGS')
    return {'bundle_flags': flags, 'crc_type': crc_type, 'destination': eid_text(value[3]), 'source': source,
            'report_to': eid_text(value[5]), 'created_ms': _uint(stamp[0], 'BPV7_TIMESTAMP'),
            'sequence': _uint(stamp[1], 'BPV7_TIMESTAMP'), 'lifetime_ms': _uint(value[7], 'BPV7_LIFETIME'),
            'administrative_record': bool(flags & ADMIN_RECORD)}


def _canonical(value, raw):
    c.need(type(value) is list and len(value) in (5, 6), 'BPV7_BLOCK')
    kind, number, flags, crc_type, data = value[:5]
    for item in (kind, number, flags):
        _uint(item, 'BPV7_BLOCK')
    c.need(type(crc_type) is int and crc_type in (CRC_NONE, CRC16, CRC32C), 'BPV7_CRC_TYPE')
    c.need(len(value) == (6 if crc_type else 5) and type(data) is bytes, 'BPV7_BLOCK')
    if crc_type:
        _check_crc(value, raw, crc_type)
    return {'type': kind, 'number': number, 'flags': flags, 'crc_type': crc_type, 'data': data}


def _parse(raw, limit):
    c.need(type(raw) is bytes and 0 < len(raw) <= limit, 'BPV7_SIZE')
    c.need(raw[0] == 0x9f, 'BPV7_BUNDLE_ARRAY')
    offset, found = 1, []
    while True:
        c.need(offset < len(raw), 'CBOR_TRUNCATED')
        if raw[offset] == 0xff:
            offset += 1
            break
        c.need(len(found) < MAX_BLOCKS, 'BPV7_BLOCK_COUNT')
        c.need(raw[offset] >> 5 == 4, 'BPV7_BLOCK_ARRAY')
        value, end = cbor.decode_prefix(raw, offset)
        found.append((value, raw[offset:end]))
        offset = end
    c.need(offset == len(raw), 'CBOR_TRAILING')
    c.need(len(found) >= 2, 'BPV7_BLOCKS')
    bundle = _primary(*found[0])
    blocks = [_canonical(*item) for item in found[1:]]
    numbers = [block['number'] for block in blocks]
    c.need(len(set(numbers)) == len(numbers), 'BPV7_BLOCK_NUMBER')
    c.need(blocks[-1]['type'] == PAYLOAD and [b['type'] for b in blocks].count(PAYLOAD) == 1, 'BPV7_PAYLOAD_LAST')
    c.need(blocks[-1]['number'] == 1 and min(numbers[:-1], default=2) >= 2, 'BPV7_BLOCK_NUMBER')
    anonymous = bundle['source'] == NONE or bundle['administrative_record']
    c.need(not anonymous or not any(b['flags'] & BLOCK_STATUS for b in blocks), 'BPV7_ANONYMOUS_FLAGS')
    extensions, security, encrypted = {}, [], set()
    for block in blocks[:-1]:
        kind = block['type']
        if kind in (PREVIOUS_NODE, BUNDLE_AGE, HOP_COUNT):
            c.need(kind not in extensions, 'BPV7_DUPLICATE_EXTENSION')
            extensions[kind] = cbor.decode(block['data'])
        elif kind in (BIB, BCB):
            asb = _asb(block['data'])
            c.need(all(t == 0 or t in numbers for t in asb['targets']), 'BPV7_ASB_TARGETS')
            c.need(not any(t != 0 and blocks[numbers.index(t)]['type'] in (BIB, BCB) for t in asb['targets']),
                   'BPV7_ASB_TARGETS')
            if kind == BIB:
                security.append({**asb, 'number': block['number']})
            else:
                c.need(0 not in asb['targets'], 'BPV7_ASB_TARGETS')
                encrypted.update(asb['targets'])
        else:
            c.need(not block['flags'] & BLOCK_DELETE, 'BPV7_BLOCK_UNSUPPORTED')
    previous = extensions.get(PREVIOUS_NODE)
    if previous is not None:
        previous = eid_text(previous)
        c.need(singleton(previous), 'BPV7_PREVIOUS_NODE')
    age = extensions.get(BUNDLE_AGE)
    if age is not None:
        _uint(age, 'BPV7_BUNDLE_AGE')
    c.need(bundle['created_ms'] > 0 or age is not None, 'BPV7_BUNDLE_AGE_REQUIRED')
    hops = extensions.get(HOP_COUNT)
    if hops is not None:
        c.need(type(hops) is list and len(hops) == 2 and type(hops[0]) is int and 1 <= hops[0] <= 255 and
               _uint(hops[1], 'BPV7_HOP_COUNT') <= hops[0], 'BPV7_HOP_COUNT')
    c.need(bundle['crc_type'] or any(0 in asb['targets'] for asb in security), 'BPV7_PRIMARY_CRC_REQUIRED')
    meta = {'version': VERSION, **bundle, 'bundle_age_ms': age, 'previous_node': previous, 'hop_count': hops,
            'blocks': [{k: b[k] for k in ('type', 'number', 'flags', 'crc_type')} for b in blocks],
            'integrity': security, 'payload_encrypted': PAYLOAD in encrypted}
    return meta, blocks, found[0][1]


def parse_bundle(raw, *, limit=MAX_BUNDLE):
    """Structure, deterministic CBOR, CRCs and RFC 9171 block rules. No clock, no keys."""
    meta, blocks, _primary_raw = _parse(raw, limit)
    return {**meta, 'payload': blocks[-1]['data']}


def _verify_bib(primary, blocks, asb):
    """AAP context: parameter 1 is the Ed25519 key, result 1 the signature, per target."""
    c.need(asb['flags'] & 1 and len(asb['parameters']) == 1 and asb['parameters'][0][0] == 1 and
           type(asb['parameters'][0][1]) is bytes and len(asb['parameters'][0][1]) == 32, 'BPV7_BIB_PARAMETERS')
    public = asb['parameters'][0][1].hex()
    c.verification_key(public)
    by_number = {block['number']: block for block in blocks}
    for target, results in zip(asb['targets'], asb['results']):
        c.need(target in by_number and len(results) == 1 and results[0][0] == 1 and
               type(results[0][1]) is bytes and len(results[0][1]) == 64, 'BPV7_BIB_RESULT')
        try:
            c.verify(public, BIB_LABEL, _bib_body(asb['source'], primary, target, by_number[target]),
                     results[0][1].hex())
        except ValueError:
            raise ValueError('BPV7_BIB_SIGNATURE') from None
    return public


def open_bundle(raw, *, now_ms, bib_keys=(), require_bib=False, limit=MAX_BUNDLE):
    """Receive one bundle at the receiver's DTN time in milliseconds.

    Expired, future-dated, fragmented or encrypted bundles are refused. Every
    AAP-context BIB must verify, even from an unpinned key: a failure is
    tampering. Only a pinned key makes the result VERIFIED. The payload still
    needs its own AAP check before anything relies on it.
    """
    _uint(now_ms, 'BPV7_CLOCK')
    c.need(type(bib_keys) in (list, tuple, set, frozenset) and len(bib_keys) <= 64 and
           type(require_bib) is bool, 'BPV7_POLICY')
    for item in bib_keys:
        c.need(type(item) is str, 'BPV7_BIB_ED25519_ONLY')
        c.verification_key(item)
    bundle, blocks, primary = _parse(raw, limit)
    c.need(not bundle['administrative_record'], 'BPV7_ADMINISTRATIVE_RECORD')
    c.need(not bundle['payload_encrypted'], 'BPV7_PAYLOAD_ENCRYPTED')
    if bundle['created_ms']:
        c.need(bundle['created_ms'] <= now_ms, 'BPV7_CREATED_IN_FUTURE')
        age = now_ms - bundle['created_ms']
    else:
        age = bundle['bundle_age_ms']
    c.need(age <= bundle['lifetime_ms'], 'BPV7_EXPIRED')
    status, signer = 'ABSENT', None
    for asb in bundle['integrity']:
        if asb['context'] != BIB_CONTEXT:
            status = 'UNSUPPORTED_CONTEXT' if status == 'ABSENT' else status
            continue
        public = _verify_bib(primary, blocks, asb)
        if public in bib_keys:
            status, signer = 'VERIFIED', public
        elif status != 'VERIFIED':
            status = 'SIGNED_BY_UNPINNED_KEY'
    c.need(not require_bib or status == 'VERIFIED', 'BPV7_BIB_REQUIRED')
    return {'payload': blocks[-1]['data'], 'bundle': bundle, 'age_ms': age, 'bib': status, 'bib_signer': signer,
            'transport': 'BUNDLE_OPENED', 'recipient_verified': False, 'payment_verified': False,
            'ledger_confirmed': False}


def dtn_time(unix_seconds):
    """Milliseconds since 2000-01-01T00:00:00Z (RFC 9171 section 4.2.6)."""
    c.integer(unix_seconds)
    c.need(unix_seconds > DTN_EPOCH, 'BPV7_TIMESTAMP')
    return (unix_seconds - DTN_EPOCH) * 1000


def envelope_bundle(packet, *, source, destination, report_to=NONE, crc_type=CRC32C, signing_key=None,
                    security_source=None, sequence=None):
    """Carry one sealed covenant-offline-envelope/0.1 packet; its times become the bundle's."""
    from . import offline as o
    ref = o.packet_id(packet)
    header = packet['header']
    if signing_key is not None:
        c.need(c.public_key(signing_key) == header['sender'], 'BPV7_BIB_SIGNER')
    return encode_bundle(c.canonical(packet), source=source, destination=destination, report_to=report_to,
                         created_ms=dtn_time(header['created']),
                         lifetime_ms=(header['expires'] - header['created']) * 1000,
                         sequence=int(ref[:8], 16) if sequence is None else sequence, crc_type=crc_type,
                         signing_key=signing_key, security_source=security_source)


def open_envelope_bundle(raw, *, scope, allowed_senders, now, require_bib=False):
    """Bundle checks, then the unchanged AAP packet checks. The AAP signature decides."""
    from . import offline as o
    c.need(type(allowed_senders) in (list, tuple, set, frozenset), 'OFFLINE_PEER_PIN')
    opened = open_bundle(raw, now_ms=dtn_time(now), bib_keys=sorted(allowed_senders), require_bib=require_bib,
                         limit=o.MAX_PACKET + 8192)
    packet = o.exact_load(opened['payload'])
    ref = o.inspect_packet(packet, scope=scope, allowed_senders=allowed_senders, now=now)
    return {'packet_id': ref, 'packet': packet, 'sender': packet['header']['sender'], 'bundle': opened['bundle'],
            'bib': opened['bib'], 'bib_signer': opened['bib_signer'], 'delivery': 'BUNDLE_RECEIVED',
            'agreement_accepted': False, 'payment_verified': False, 'ledger_confirmed': False,
            'execution_authorized': False}
