"""Exact robot missions and an owner-operated, single-gateway custody runtime.

This is coordination, not a real-time/safety controller or distributed lease.
The authorizer, driver, clock, authenticated connection and host are trusted.
An incoming mission never installs a driver or authorizes its own execution.
"""
from copy import deepcopy
import threading

from .crypto import canonical, digest, exact, integer, key, need
from .workflow_store import WorkflowStore

MISSION = 'covenant-robot-mission/0.1'
BINDING = 'covenant-robot-binding/0.1'
TERMINAL = frozenset(('REPORTED_SUCCEEDED', 'REPORTED_FAILED', 'REPORTED_CANCELED'))
STATUSES = TERMINAL | {'EXECUTING', 'SUBMITTED_UNCONFIRMED', 'UNKNOWN', 'CANCEL_REQUESTED'}


def text(value, maximum=256):
    need(type(value) is str and 0 < len(value) <= maximum and
         all(32 <= ord(c) <= 126 for c in value), 'ROBOT_TEXT')


def bounded(value):
    need(len(canonical(value)) <= 32768, 'ROBOT_SIZE')


def binding(robot, protocol, interface, implementation):
    """Describe owner-selected semantics. No import, installation or connection."""
    value = dict(version=BINDING, robot=robot, protocol=protocol,
                 interface=deepcopy(interface), implementation=implementation)
    binding_id(value)
    return value


def binding_id(value):
    bounded(value)
    exact(value, 'version robot protocol interface implementation')
    need(value['version'] == BINDING, 'ROBOT_BINDING_VERSION')
    text(value['robot']); text(value['protocol']); key(value['implementation'])
    need(type(value['interface']) is dict, 'ROBOT_INTERFACE')
    return digest('COVENANT-ROBOT-BINDING-0.1', value)


def draft(robot, adapter, capability, arguments, valid_from, valid_until, nonce, context=None):
    """Keyless preparation; place this exact object in the chosen agreement."""
    frame = {'who': [], 'what': capability, 'which': robot, 'where': [],
             'when': {'from': valid_from, 'until': valid_until}, 'why': '', 'how': adapter}
    if context is not None:
        need(type(context) is dict, 'ROBOT_CONTEXT')
        frame.update(deepcopy(context))
    value = dict(version=MISSION, robot=robot, adapter=adapter, capability=capability,
                 arguments=deepcopy(arguments), valid_from=valid_from, valid_until=valid_until,
                 nonce=nonce, context=frame)
    reference = mission_id(value)
    return {'mission': value, 'id': reference, 'status': 'DRAFT_REQUIRES_ASSENT',
            'execution_authorized': False, 'physical_delivery_verified': False,
            'payment_verified': False}


def mission_id(value):
    bounded(value)
    exact(value, 'version robot adapter capability arguments valid_from valid_until nonce context')
    need(value['version'] == MISSION, 'ROBOT_MISSION_VERSION')
    for field in ('robot', 'capability'):
        text(value[field])
    key(value['adapter']); key(value['nonce'])
    need(type(value['arguments']) is dict and type(value['context']) is dict and
         set('who what which where when why how'.split()) <= value['context'].keys(), 'ROBOT_CONTEXT')
    integer(value['valid_from']); integer(value['valid_until'])
    need(value['valid_from'] < value['valid_until'] and
         value['valid_until'] - value['valid_from'] <= 86400, 'ROBOT_INTERVAL')
    return digest('COVENANT-ROBOT-MISSION-0.1', value)


def review(mission, expected_id):
    need(mission_id(mission) == expected_id, 'ROBOT_MISSION_NOT_PINNED')
    return {'id': expected_id, 'exact_mission_verified': True, 'execution_authorized': False,
            'assents_verified': False, 'physical_delivery_verified': False, 'payment_verified': False}


class RobotRuntime:
    """One adopted robot/driver per local journal; one outstanding mission.

    authorize(caller, mission, action) MUST independently check the chosen exact
    agreement, scope, operator authority and live controller interlocks. It
    returns revision/now/allowed/ready/observed_at/valid_until. Revision and clock
    floors are retained; current facts still depend on that trusted callback.
    Drivers must bound calls and keep physical safety/watchdogs at the device.
    No retries after possible side effects; recovery observes the original ID.
    The filesystem journal is private by permissions, not encrypted or consensus.
    """
    def __init__(self, directory, *, driver, authorize, max_state_age=5):
        need(callable(authorize), 'ROBOT_AUTHORIZER_REQUIRED')
        integer(max_state_age, positive=True)
        need(max_state_age <= 60, 'ROBOT_FRESHNESS_LIMIT')
        self.driver, self.authorize, self.max_state_age = driver, authorize, max_state_age
        self.binding = deepcopy(driver.binding)
        self.adapter = binding_id(self.binding)
        self.lock = threading.RLock()
        self.store = WorkflowStore(directory, {'profile': MISSION, 'adapter': self.adapter},
                                   check_same_thread=False)

    def close(self):
        with self.lock:
            self.store.close()

    def _records(self):
        return {e['body']['task']: e['body']['value'] for e in self.store.events()
                if e['body']['kind'] == 'ROBOT_MISSION'}

    def _authority(self, caller, mission, action):
        text(caller)
        need(binding_id(self.driver.binding) == self.adapter, 'ROBOT_DRIVER_CHANGED')
        need(mission['adapter'] == self.adapter and mission['robot'] == self.binding['robot'],
             'ROBOT_ADAPTER_SCOPE')
        state = deepcopy(self.authorize(caller, deepcopy(mission), action))
        bounded(state)
        exact(state, 'revision now allowed ready observed_at valid_until')
        for f in ('revision', 'now', 'observed_at', 'valid_until'):
            integer(state[f])
        need(type(state['allowed']) is bool and type(state['ready']) is bool, 'ROBOT_PERMISSION_TYPE')
        floor = None
        for e in self.store.events():
            if e['body']['kind'] == 'ROBOT_AUTHORITY':
                floor = e['body']['value']
        need(floor is None or (state['revision'] >= floor['revision'] and state['now'] >= floor['now']),
             'ROBOT_AUTHORITY_ROLLBACK')
        self.store.append('ROBOT_AUTHORITY', self.binding['robot'],
                          {k: state[k] for k in ('revision', 'now')})
        need(state['allowed'], 'ROBOT_NOT_AUTHORIZED')
        need(state['observed_at'] <= state['now'] <= state['valid_until'] and
             state['now'] - state['observed_at'] <= self.max_state_age, 'ROBOT_STALE_AUTHORITY')
        if action == 'submit':
            need(state['ready'], 'ROBOT_INTERLOCK_REFUSED')
            need(mission['valid_from'] <= state['now'] < mission['valid_until'], 'ROBOT_MISSION_EXPIRED')
        return state

    def _save(self, ref, record):
        # A valid mission and observation each have their own 32 KiB bound;
        # custody must also fit their combination and fixed metadata.
        need(len(canonical(record)) <= 98304, 'ROBOT_RECORD_SIZE')
        self.store.append('ROBOT_MISSION', ref, record)

    def _result(self, ref, record):
        return {'mission': ref, 'robot': self.binding['robot'], 'status': record['status'],
                'observation': deepcopy(record.get('observation')),
                'cancel_requested': record['cancel_requested'],
                'physical_stop_verified': False, 'physical_delivery_verified': False,
                'payment_verified': False, 'automatic_retry': False}

    def submit(self, mission, *, caller):
        mission = deepcopy(mission); ref = mission_id(mission)
        with self.lock, self.store.exclusive():
            self._authority(caller, mission, 'submit')
            records = self._records()
            if ref in records:
                return self._result(ref, records[ref])
            need(not any(r['status'] not in TERMINAL for r in records.values()), 'ROBOT_BUSY_OR_UNCERTAIN')
            # Pure driver preparation and argument/capability validation before
            # durable intent. Drivers may NOT transmit from validate().
            self.driver.validate(mission)
            record = {'mission': mission, 'status': 'UNKNOWN', 'cancel_requested': False,
                      'sequence': -1, 'observation': None}
            self._save(ref, record)  # Commit BEFORE any possible physical effect.
            try:
                self.driver.submit(ref, deepcopy(mission))
                record['status'] = 'SUBMITTED_UNCONFIRMED'
            except Exception:
                pass  # readiness: unknown-outcome the saved record stays UNKNOWN; driver errors may hold secrets, so none is logged
            self._save(ref, record)
            return self._result(ref, record)

    def inspect(self, mission, *, caller):
        mission = deepcopy(mission); ref = mission_id(mission)
        with self.lock, self.store.exclusive():
            self._authority(caller, mission, 'inspect')
            records = self._records(); need(ref in records, 'ROBOT_MISSION_MISSING')
            return self._result(ref, records[ref])

    def observe(self, mission, *, caller):
        mission = deepcopy(mission); ref = mission_id(mission)
        with self.lock, self.store.exclusive():
            self._authority(caller, mission, 'observe')
            records = self._records(); need(ref in records, 'ROBOT_MISSION_MISSING')
            record = records[ref]
            # Owner driver queries/consumes an authenticated report; never resends.
            observation = self.driver.observe(ref, deepcopy(mission), previous=deepcopy(record['observation']))
            if observation is None:
                return self._result(ref, record)
            bounded(observation)
            exact(observation, 'mission sequence status evidence')
            need(observation['mission'] == ref, 'ROBOT_WRONG_MISSION')
            integer(observation['sequence'])
            need(type(observation['status']) is str and observation['status'] in STATUSES and
                 type(observation['evidence']) is dict,
                 'ROBOT_OBSERVATION')
            if observation['sequence'] <= record['sequence']:
                need(observation['sequence'] == record['sequence'] and
                     canonical(observation) == canonical(record['observation']), 'ROBOT_STALE_OR_CONFLICTING_REPORT')
                return self._result(ref, record)
            if record['status'] in TERMINAL:
                need(observation['status'] == record['status'], 'ROBOT_TERMINAL_CONFLICT')
            record.update(sequence=observation['sequence'], status=observation['status'],
                          observation=deepcopy(observation))
            self._save(ref, record)
            return self._result(ref, record)

    def cancel(self, mission, *, caller):
        mission = deepcopy(mission); ref = mission_id(mission)
        with self.lock, self.store.exclusive():
            # Cancellation can remain authorized after deadline/interlock refusal.
            self._authority(caller, mission, 'cancel')
            records = self._records(); need(ref in records, 'ROBOT_MISSION_MISSING')
            record = records[ref]
            if record['cancel_requested'] or record['status'] in TERMINAL:
                return self._result(ref, record)
            record.update(cancel_requested=True, status='CANCEL_REQUESTED')
            self._save(ref, record)
            try:
                self.driver.cancel(ref, deepcopy(mission))
            except Exception:
                record['status'] = 'UNKNOWN'
                self._save(ref, record)
            return self._result(ref, record)

    def a2a_executor(self, verified):
        """Install ONLY as the owner AgreementGate callback, never as a public tool.

        Outer gate checks exact request assent/grants; robot authorizer separately
        checks current robot-specific authority. A2A COMPLETED means this dispatch
        was recorded, not the robot mission or physical delivery completed.
        """
        from .a2a_agreement_gate import VERSION
        need(verified.get('profile') == VERSION, 'ROBOT_A2A_PROFILE')
        operation = verified['operation']
        exact(operation, 'operation payload resources')
        name = operation['operation']
        need(name in ('robot.submit', 'robot.inspect', 'robot.observe', 'robot.cancel'), 'ROBOT_A2A_OPERATION')
        return getattr(self, name.split('.')[1])(operation['payload'], caller=verified['caller'])
