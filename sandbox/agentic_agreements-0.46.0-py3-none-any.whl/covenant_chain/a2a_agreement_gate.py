"""Required Covenant agreements for a bounded A2A 1.0 inbound operation.

This new profile is separate from inert standards bindings. Authentication and
fresh authority state are supplied by a trusted owner, not message metadata.
The local journal is private custody, not consensus or rollback-proof storage.
"""
from copy import deepcopy
import base64
import hashlib
import threading

from .crypto import (canonical, digest, exact, integer, key, need, public_key,
                     sign, verification_key, verify, loads)
from .workflow_store import WorkflowStore

VERSION = "covenant-required-a2a-agreement/0.1"
GRANT_VERSION = "covenant-required-a2a-grant/0.1"
RECEIPT_VERSION = "covenant-required-a2a-receipt/0.1"
EVIDENCE_VERSION = "covenant-required-a2a-evidence/0.1"
EXTENSION_URI = ("https://github.com/malik-degen/covenant/blob/main/docs/"
                 "REQUIRED_A2A_AGREEMENTS.html#covenant-required-a2a-agreement-0.1")
METADATA_KEY = VERSION
ASSENT_LABEL = "COVENANT-REQUIRED-A2A-ASSENT-0.1"
RECEIPT_LABEL = "COVENANT-REQUIRED-A2A-RECEIPT-0.1"
MAX_REQUEST = 262144
MAX_EXACT_BYTES = 65536
MAX_EXACT_RESULT = MAX_EXACT_BYTES - 8192
EXACT_CARRIER_VERSION = "covenant-a2a-exact-json/0.1"
OPERATION_MEDIA_TYPE = "application/vnd.covenant.operation+json"
RECEIPT_MEDIA_TYPE = "application/vnd.covenant.execution-receipt+json"


def _text(value, maximum=256):
    need(type(value) is str and 0 < len(value) <= maximum and
         all(32 <= ord(c) <= 126 for c in value), "A2A_GATE_TEXT")


def _bounded(value, maximum=MAX_REQUEST):
    raw = canonical(value)
    need(len(raw) <= maximum, "A2A_GATE_SIZE")
    return raw


def _exact_json(raw):
    """Preserve native exact integers through protobuf Struct-based clients."""
    need(type(raw) is str and raw.isascii() and 0 < len(raw) <= MAX_EXACT_BYTES,
         "A2A_GATE_EXACT_JSON")
    value = loads(raw)
    need(_bounded(value, MAX_EXACT_BYTES) == raw.encode("ascii"),
         "A2A_GATE_CANONICAL_JSON")
    return value


def _encode_raw(value, media_type):
    raw = _bounded(value, MAX_EXACT_BYTES)
    return {"raw": base64.b64encode(raw).decode("ascii"), "mediaType": media_type}


def _decode_raw(part, media_type):
    exact(part, "raw mediaType")
    need(part["mediaType"] == media_type, "A2A_GATE_MEDIA_TYPE")
    encoded = part["raw"]
    need(type(encoded) is str and 0 < len(encoded) <= 4 * ((MAX_EXACT_BYTES + 2) // 3),
         "A2A_GATE_RAW_SIZE")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError):
        raise ValueError("A2A_GATE_RAW_ENCODING") from None
    need(base64.b64encode(raw).decode("ascii") == encoded and len(raw) <= MAX_EXACT_BYTES,
         "A2A_GATE_RAW_ENCODING")
    try:
        text = raw.decode("ascii")
    except UnicodeError:
        raise ValueError("A2A_GATE_EXACT_JSON") from None
    return _exact_json(text)


def _operation(operation):
    exact(operation, "operation payload resources")
    _text(operation["operation"])
    _resources(operation["resources"])


def encode_operation_part(operation):
    """Exact-byte A2A raw part, without float coercion or automatic signing."""
    _operation(operation)
    return _encode_raw(operation, OPERATION_MEDIA_TYPE)


def _raw_carrier(params):
    message = params.get("message", {}) if type(params) is dict else {}
    parts = message.get("parts", []) if type(message) is dict else []
    return type(parts) is list and len(parts) == 1 and type(parts[0]) is dict and "raw" in parts[0]


def decode_task_artifact(task):
    """Recover exact receipt data from either profile carrier, without verifying it."""
    need(type(task) is dict and type(task.get("artifacts")) is list and
         len(task["artifacts"]) == 1, "A2A_GATE_RECEIPT_ARTIFACT")
    artifact = task["artifacts"][0]
    exact(artifact, "artifactId parts")
    need(artifact["artifactId"] == "covenant-execution-receipt" and
         type(artifact["parts"]) is list and len(artifact["parts"]) == 1,
         "A2A_GATE_RECEIPT_ARTIFACT")
    part = artifact["parts"][0]
    if type(part) is dict and "raw" in part:
        data = _decode_raw(part, RECEIPT_MEDIA_TYPE)
    else:
        exact(part, "data")
        data = deepcopy(part["data"])
        _bounded(data)
    exact(data, "receipt execution_result payment_verified counterparty_acceptance_verified external_truth_verified")
    need(data["payment_verified"] is False and data["counterparty_acceptance_verified"] is False
         and data["external_truth_verified"] is False, "A2A_GATE_RECEIPT_CLAIMS")
    return data


def _refs(values, minimum=0, maximum=64):
    need(type(values) is list and minimum <= len(values) <= maximum,
         "A2A_GATE_REFERENCES")
    for value in values:
        key(value)
    need(values == sorted(set(values)), "A2A_GATE_REFERENCES")


def _resources(resources):
    need(type(resources) is list and len(resources) <= 16, "A2A_GATE_RESOURCES")
    order = []
    for row in resources:
        exact(row, "resource quantity unit")
        _text(row["resource"])
        _text(row["unit"])
        integer(row["quantity"])
        order.append((row["resource"], row["unit"]))
    need(order == sorted(set(order)), "A2A_GATE_RESOURCES")


def request_digest(params):
    """Hash all execution parameters, excluding only the assent envelope.

    This successor profile deliberately accepts bounded ASCII/integer JSON.
    Its identifier is not JSON-LD canonicalization or A2A's generic wire hash.
    Message IDs, extension lists, unrelated metadata and configuration remain
    signed. JSON-RPC correlation IDs and HTTP headers are outside this object.
    """
    _bounded(params)
    need(type(params) is dict, "A2A_GATE_PARAMS")
    value = deepcopy(params)
    metadata = value.get("metadata")
    if metadata is not None:
        need(type(metadata) is dict, "A2A_GATE_METADATA")
        metadata.pop(METADATA_KEY, None)
        if not metadata:
            value.pop("metadata")
    return digest("COVENANT-REQUIRED-A2A-REQUEST-0.1", value)


def _agreement(agreement):
    _bounded(agreement)
    exact(agreement, "version service policy tenant operation request resources "
                     "required_signers caller grant valid_from valid_until nonce terms")
    need(agreement["version"] == VERSION, "A2A_GATE_VERSION")
    for field in ("service", "policy", "tenant", "operation"):
        _text(agreement[field])
    for field in ("request", "grant", "nonce"):
        key(agreement[field])
    verification_key(agreement["caller"])
    need(type(agreement["caller"]) is str, "A2A_GATE_ED25519_PROFILE")
    _refs(agreement["required_signers"], minimum=1, maximum=16)
    for signer in agreement["required_signers"]:
        verification_key(signer)
    _resources(agreement["resources"])
    integer(agreement["valid_from"])
    integer(agreement["valid_until"])
    need(agreement["valid_from"] <= agreement["valid_until"], "A2A_GATE_INTERVAL")
    _text(agreement["terms"], 8192)


def agreement_id(agreement):
    _agreement(agreement)
    return digest("COVENANT-REQUIRED-A2A-AGREEMENT-0.1", agreement)


def assent(agreement, private_key):
    """Explicit owner signing helper; never called by the inbound gate."""
    body = {"agreement": agreement_id(agreement)}
    return {"signer": public_key(private_key),
            "signature": sign(private_key, ASSENT_LABEL, body)}


def verify_agreement(agreement, assents, *, expected_agreement):
    """Offline exact assent verification with an independently selected pin.

    Fresh authority, expiry, revocation and business truth require other checks.
    The expected object must never be selected from the untrusted envelope.
    """
    reference = agreement_id(agreement)
    need(canonical(agreement) == canonical(expected_agreement),
         "A2A_GATE_AGREEMENT_NOT_PINNED")
    need(type(assents) is list and len(assents) <= 16, "A2A_GATE_ASSENTS")
    seen = []
    for row in assents:
        exact(row, "signer signature")
        need(type(row["signer"]) is str, "A2A_GATE_SIGNER")
        verify(row["signer"], ASSENT_LABEL, {"agreement": reference}, row["signature"])
        seen.append(row["signer"])
    # Arrival order is transport detail; exact membership is signed in the
    # agreement. Sorting here neither adds assent nor changes its meaning.
    need(sorted(seen) == agreement["required_signers"], "A2A_GATE_REQUIRED_ASSENTS")
    return {"agreement": reference, "required_assents_verified": True,
            "execution_authorized": False, "fresh_authority_checked": False,
            "payment_verified": False, "external_truth_verified": False}


def attach_assents(params, agreement, assents):
    """Assemble an already agreed request without signing or granting authority."""
    verify_agreement(agreement, assents, expected_agreement=agreement)
    need(request_digest(params) == agreement["request"], "A2A_GATE_REQUEST_MISMATCH")
    result = deepcopy(params)
    envelope = {"agreement": deepcopy(agreement), "assents": deepcopy(assents)}
    result.setdefault("metadata", {})[METADATA_KEY] = (
        _bounded(envelope, MAX_EXACT_BYTES).decode("ascii") if _raw_carrier(result) else envelope)
    _params(result)
    return result


def _grant(grant):
    _bounded(grant)
    exact(grant, "version service policy tenant caller operations requests resources "
                 "valid_from valid_until revoked")
    need(grant["version"] == GRANT_VERSION, "A2A_GATE_GRANT_VERSION")
    for field in ("service", "policy", "tenant"):
        _text(grant[field])
    verification_key(grant["caller"])
    need(type(grant["caller"]) is str, "A2A_GATE_ED25519_PROFILE")
    need(type(grant["operations"]) is list and 1 <= len(grant["operations"]) <= 16,
         "A2A_GATE_OPERATIONS")
    for operation in grant["operations"]:
        _text(operation)
    need(grant["operations"] == sorted(set(grant["operations"])), "A2A_GATE_OPERATIONS")
    _refs(grant["requests"], minimum=1)
    _resources(grant["resources"])
    integer(grant["valid_from"])
    integer(grant["valid_until"])
    need(grant["valid_from"] <= grant["valid_until"], "A2A_GATE_INTERVAL")
    need(type(grant["revoked"]) is bool, "A2A_GATE_REVOKED_BOOLEAN")


def grant_id(grant):
    """Stable grant scope ID; revoked is fresh owner state, not signed scope."""
    _grant(grant)
    value = {k: v for k, v in grant.items() if k != "revoked"}
    return digest("COVENANT-REQUIRED-A2A-GRANT-0.1", value)


def _params(params):
    _bounded(params)
    need(type(params) is dict and {"tenant", "message", "metadata"} <= set(params)
         and set(params) <= {"tenant", "message", "metadata", "configuration"},
         "A2A_GATE_PARAMS")
    _text(params["tenant"])
    message = params["message"]
    need(type(message) is dict and {"messageId", "role", "parts", "extensions"} <= set(message)
         and set(message) <= {"messageId", "role", "parts", "extensions", "contextId", "metadata"},
         "A2A_GATE_MESSAGE")
    _text(message["messageId"])
    need(message["role"] == "ROLE_USER", "A2A_GATE_ROLE")
    if "contextId" in message:
        _text(message["contextId"])
    if "metadata" in message:
        need(type(message["metadata"]) is dict, "A2A_GATE_METADATA")
    need(message["extensions"] == [EXTENSION_URI], "A2A_GATE_EXTENSION_REQUIRED")
    parts = message["parts"]
    need(type(parts) is list and len(parts) == 1, "A2A_GATE_PARTS")
    if _raw_carrier(params):
        operation = _decode_raw(parts[0], OPERATION_MEDIA_TYPE)
    else:
        exact(parts[0], "data")
        operation = parts[0]["data"]
    _operation(operation)
    if "configuration" in params:
        configuration = params["configuration"]
        need(type(configuration) is dict and set(configuration) <=
             {"acceptedOutputModes", "historyLength", "returnImmediately"},
             "A2A_GATE_CONFIGURATION")
        if "acceptedOutputModes" in configuration:
            need(configuration["acceptedOutputModes"] == ["application/json"],
                 "A2A_GATE_OUTPUT_MODE")
        if "historyLength" in configuration:
            integer(configuration["historyLength"])
            need(configuration["historyLength"] <= 100, "A2A_GATE_HISTORY_LENGTH")
        if "returnImmediately" in configuration:
            need(type(configuration["returnImmediately"]) is bool,
                 "A2A_GATE_RETURN_IMMEDIATELY")
    metadata = params["metadata"]
    need(type(metadata) is dict and METADATA_KEY in metadata, "A2A_GATE_ENVELOPE_REQUIRED")
    envelope = metadata[METADATA_KEY]
    if _raw_carrier(params):
        envelope = _exact_json(envelope)
    exact(envelope, "agreement assents")
    return message, operation, envelope


def verify_receipt(receipt, *, expected_signer, expected_agreement, expected_request,
                   execution_result=None):
    """Verify retained receipt bytes against independent pins, not outcome truth."""
    exact(receipt, "body signer signature")
    body = receipt["body"]
    exact(body, "version service policy tenant caller agreement request task outcome "
                "result_sha256 state_revision state_hash grant now")
    need(body["version"] == RECEIPT_VERSION, "A2A_GATE_RECEIPT_VERSION")
    for field in ("service", "policy", "tenant"):
        _text(body[field])
    for field in ("agreement", "request", "task", "result_sha256", "state_hash", "grant"):
        key(body[field])
    verification_key(body["caller"])
    integer(body["state_revision"])
    integer(body["now"])
    need(canonical(receipt["signer"]) == canonical(expected_signer), "A2A_GATE_RECEIPT_SIGNER")
    need(body["agreement"] == expected_agreement and body["request"] == expected_request,
         "A2A_GATE_RECEIPT_SCOPE")
    need(body["outcome"] in ("COMPLETED_RECORDED", "UNKNOWN_EXTERNAL_OUTCOME"),
         "A2A_GATE_RECEIPT_OUTCOME")
    if execution_result is not None:
        need(body["result_sha256"] == hashlib.sha256(_bounded(execution_result)).hexdigest(),
             "A2A_GATE_RECEIPT_RESULT")
    verify(receipt["signer"], RECEIPT_LABEL, body, receipt["signature"])
    return {"receipt_signature_verified": True, "agreement": expected_agreement,
            "request": expected_request, "outcome": body["outcome"],
            "external_truth_verified": False, "payment_verified": False,
            "counterparty_acceptance_verified": False}


def extension_declaration():
    """Public capability advertisement contains no private terms or evidence."""
    return {"uri": EXTENSION_URI, "required": True,
            "description": "Exact signed Covenant agreement and current scoped authority required."}


def verify_evidence(evidence, *, expected_agreement, expected_receipt_signer):
    """Verify a holder-exported case, without contacting a service or trusting a card.

    Selected historical authority is a signed service assertion. This does not
    prove the owner's registry was true/current or reveal unrelated registry
    subjects. It does not establish payment or counterparty acceptance.
    """
    _bounded(evidence, 1_000_000)
    exact(evidence, "version agreement assents params receipt execution_result authority")
    need(evidence["version"] == EVIDENCE_VERSION, "A2A_GATE_EVIDENCE_VERSION")
    agreement, params = evidence["agreement"], evidence["params"]
    verified = verify_agreement(agreement, evidence["assents"],
                                expected_agreement=expected_agreement)
    _, operation, envelope = _params(params)
    need(canonical(envelope["agreement"]) == canonical(agreement) and
         canonical(envelope["assents"]) == canonical(evidence["assents"]),
         "A2A_GATE_EVIDENCE_ENVELOPE")
    request = request_digest(params)
    need(request == agreement["request"] and params["tenant"] == agreement["tenant"] and
         operation["operation"] == agreement["operation"] and
         canonical(operation["resources"]) == canonical(agreement["resources"]),
         "A2A_GATE_EVIDENCE_REQUEST")
    receipt = verify_receipt(evidence["receipt"], expected_signer=expected_receipt_signer,
                             expected_agreement=verified["agreement"], expected_request=request,
                             execution_result=evidence["execution_result"])
    body, authority = evidence["receipt"]["body"], evidence["authority"]
    exact(authority, "grant revision state_hash now")
    need(authority["revision"] == body["state_revision"] and
         type(authority["revision"]) is int and
         authority["state_hash"] == body["state_hash"] and
         authority["now"] == body["now"] and type(authority["now"]) is int,
         "A2A_GATE_EVIDENCE_AUTHORITY")
    grant = authority["grant"]
    need(grant_id(grant) == agreement["grant"] and not grant["revoked"],
         "A2A_GATE_EVIDENCE_GRANT")
    need(all(body[field] == agreement[field] == grant[field]
             for field in ("service", "policy", "tenant", "caller")),
         "A2A_GATE_EVIDENCE_SCOPE")
    need(body["grant"] == agreement["grant"] and
         grant["valid_from"] <= body["now"] <= grant["valid_until"] and
         agreement["valid_from"] <= body["now"] <= agreement["valid_until"] and
         agreement["operation"] in grant["operations"] and request in grant["requests"],
         "A2A_GATE_EVIDENCE_GRANT")
    caps = {(row["resource"], row["unit"]): row["quantity"] for row in grant["resources"]}
    for row in agreement["resources"]:
        need(row["quantity"] <= caps.get((row["resource"], row["unit"]), -1),
             "A2A_GATE_EVIDENCE_GRANT")
    return {**verified, **receipt, "historical_authority_asserted_by_service": True,
            "current_authority_verified": False, "unrelated_owner_state_disclosed": False}


def agent_card(url, *, name="Covenant required agreement service"):
    """Bounded A2A 1.0 advertisement; URL is an owner-supplied inert value."""
    _text(url, 8192)
    _text(name)
    return {"name": name, "description": "Required exact agreement verification before execution.",
            "version": "0.1", "supportedInterfaces": [
                {"url": url, "protocolBinding": "JSONRPC", "protocolVersion": "1.0"}],
            "capabilities": {"extensions": [extension_declaration()]},
            "defaultInputModes": ["application/json"],
            "defaultOutputModes": ["application/json"],
            "skills": [{"id": "covenant-required-agreement", "name": "Agreed operation",
                        "description": "Owner-installed operation requiring independently pinned assent.",
                        "tags": ["agreement"]}]}


class AgreementGate:
    """Synchronous inbound gate. Owner callbacks, clock and OS remain trusted.

    caller is supplied ONLY by an independently authenticated transport. Never
    copy caller or active_extensions from JSON metadata. All reads recheck fresh
    authority. One selected owner process serializes custody through its lock.
    Resource ceilings are per agreed invocation, not pooled spend budgets.
    """
    def __init__(self, directory, *, service, policy_id, owner_state, execute,
                 receipt_key=None):
        _text(service)
        _text(policy_id)
        need(callable(owner_state) and callable(execute), "A2A_GATE_OWNER_CALLBACK")
        self.service, self.policy_id = service, policy_id
        self._thread_lock = threading.RLock()
        self.owner_state, self.execute = owner_state, execute
        self.receipt_key = receipt_key
        self.receipt_signer = None if receipt_key is None else public_key(receipt_key)
        if self.receipt_signer is not None:
            verification_key(self.receipt_signer)
            need(type(self.receipt_signer) is str, "A2A_GATE_ED25519_PROFILE")
        self.store = WorkflowStore(directory, {"profile": VERSION, "service": service,
                                              "policy": policy_id,
                                              "receipt_signer": self.receipt_signer},
                                   check_same_thread=False)

    def close(self):
        with self._thread_lock:
            self.store.close()

    def export_evidence(self, task, *, caller, tenant, active_extensions):
        """Explicit private holder export, after the same fresh read authorization."""
        self.dispatch("GetTask", {"id": task, "tenant": tenant}, caller=caller,
                      active_extensions=active_extensions)
        with self._thread_lock, self.store.exclusive():
            # Recheck inside this lock; authorization may have changed since
            # the preceding call. No unsigned cached capability is retained.
            state, _ = self._state()
            record = self._records().get(task)
            need(record is not None and record["caller"] == caller and
                 record["tenant"] == tenant, "A2A_GATE_TASK_NOT_AVAILABLE")
            self._authorize(record["agreement"], caller, state)
            data = decode_task_artifact(self._task(record)["task"])
            return {"version": EVIDENCE_VERSION, "agreement": deepcopy(record["agreement"]),
                    "assents": deepcopy(record["assents"]), "params": deepcopy(record["params"]),
                    "receipt": data["receipt"], "execution_result": data["execution_result"],
                    "authority": {"grant": deepcopy(record["grant"]),
                                  "revision": record["state_revision"],
                                  "state_hash": record["state_hash"], "now": record["now"]}}

    def _state(self):
        state = deepcopy(self.owner_state())
        _bounded(state, 1_000_000)
        exact(state, "revision now agreements grants revoked_agreements")
        integer(state["revision"])
        integer(state["now"])
        for field in ("agreements", "grants"):
            need(type(state[field]) is dict and len(state[field]) <= 128,
                 "A2A_GATE_OWNER_STATE")
        _refs(state["revoked_agreements"], maximum=128)
        static = {k: v for k, v in state.items() if k != "now"}
        state_hash = digest("COVENANT-REQUIRED-A2A-STATE-0.1", static)
        previous = None
        for event in self.store.events():
            if event["body"]["kind"] == "A2A_GATE_STATE":
                previous = event["body"]["value"]
        if previous is not None:
            need(state["revision"] >= previous["revision"] and state["now"] >= previous["now"],
                 "A2A_GATE_STATE_ROLLBACK")
            need(state["revision"] != previous["revision"] or state_hash == previous["hash"],
                 "A2A_GATE_STATE_EQUIVOCATION")
        stamp = {"revision": state["revision"], "now": state["now"], "hash": state_hash}
        if previous != stamp:
            self.store.append("A2A_GATE_STATE", self.service, stamp)
        return state, state_hash

    def _authorize(self, agreement, caller, state):
        reference = agreement_id(agreement)
        need(agreement["service"] == self.service and agreement["policy"] == self.policy_id,
             "A2A_GATE_SERVICE_SCOPE")
        need(agreement["caller"] == caller, "A2A_GATE_CALLER")
        expected = state["agreements"].get(reference)
        need(expected is not None and canonical(expected) == canonical(agreement),
             "A2A_GATE_AGREEMENT_NOT_PINNED")
        need(reference not in state["revoked_agreements"], "A2A_GATE_AGREEMENT_REVOKED")
        need(agreement["valid_from"] <= state["now"] <= agreement["valid_until"],
             "A2A_GATE_AGREEMENT_EXPIRED")
        grant = state["grants"].get(agreement["grant"])
        need(grant is not None, "A2A_GATE_GRANT_MISSING")
        need(grant_id(grant) == agreement["grant"], "A2A_GATE_GRANT_CHANGED")
        need(not grant["revoked"], "A2A_GATE_GRANT_REVOKED")
        need(all(grant[field] == agreement[field] for field in
                 ("service", "policy", "tenant", "caller")), "A2A_GATE_GRANT_SCOPE")
        need(grant["valid_from"] <= state["now"] <= grant["valid_until"],
             "A2A_GATE_GRANT_EXPIRED")
        need(agreement["operation"] in grant["operations"] and
             agreement["request"] in grant["requests"], "A2A_GATE_GRANT_SCOPE")
        caps = {(row["resource"], row["unit"]): row["quantity"] for row in grant["resources"]}
        for row in agreement["resources"]:
            resource = (row["resource"], row["unit"])
            need(resource in caps and row["quantity"] <= caps[resource], "A2A_GATE_RESOURCE_CAP")
        return reference

    def _records(self):
        records = {}
        for event in self.store.events():
            body = event["body"]
            if body["kind"] in ("A2A_GATE_STARTED", "A2A_GATE_FINISHED"):
                records[body["task"]] = deepcopy(body["value"])
        return records

    def _task(self, record):
        completed = record["outcome"] == "COMPLETED_RECORDED"
        result = deepcopy(record.get("result", {}))
        body = {"version": RECEIPT_VERSION, "service": self.service, "policy": self.policy_id,
                "tenant": record["tenant"], "caller": record["caller"],
                "agreement": record["agreement_id"], "request": record["request"],
                "task": record["task"], "outcome": record["outcome"],
                "result_sha256": hashlib.sha256(_bounded(result)).hexdigest(),
                "state_revision": record["state_revision"], "state_hash": record["state_hash"],
                "grant": record["agreement"]["grant"], "now": record["now"]}
        evidence = {"body": body, "signer": self.receipt_signer,
                    "signature": None if self.receipt_key is None else
                    sign(self.receipt_key, RECEIPT_LABEL, body)}
        data = {"receipt": evidence, "execution_result": result,
                "payment_verified": False, "counterparty_acceptance_verified": False,
                "external_truth_verified": False}
        part = (_encode_raw(data, RECEIPT_MEDIA_TYPE) if _raw_carrier(record["params"])
                else {"data": data})
        return {"task": {"id": record["task"], "contextId": record["context"],
                         "status": {"state": "TASK_STATE_COMPLETED" if completed else
                                    "TASK_STATE_INPUT_REQUIRED"},
                         "artifacts": [{"artifactId": "covenant-execution-receipt",
                                        "parts": [part]}],
                         "metadata": {"covenantOutcome": record["outcome"],
                                      "agreement": record["agreement_id"]}}}

    def dispatch(self, method, params, *, caller, active_extensions):
        """Transport must authenticate caller and parse extension activation first."""
        verification_key(caller)
        need(type(caller) is str, "A2A_GATE_ED25519_PROFILE")
        need(type(active_extensions) in (list, tuple) and
             list(active_extensions) == [EXTENSION_URI], "A2A_GATE_EXTENSION_REQUIRED")
        need(method in ("SendMessage", "GetTask"), "A2A_GATE_METHOD_UNSUPPORTED")
        params = deepcopy(params)
        with self._thread_lock, self.store.exclusive():
            state, state_hash = self._state()
            records = self._records()
            if method == "GetTask":
                _bounded(params)
                need(type(params) is dict and {"id", "tenant"} <= set(params) and
                     set(params) <= {"id", "tenant", "historyLength"}, "A2A_GATE_PARAMS")
                _text(params["id"])
                _text(params["tenant"])
                if "historyLength" in params:
                    integer(params["historyLength"])
                    need(params["historyLength"] <= 100, "A2A_GATE_HISTORY_LENGTH")
                record = records.get(params["id"])
                need(record is not None and record["caller"] == caller and
                     record["tenant"] == params["tenant"], "A2A_GATE_TASK_NOT_AVAILABLE")
                self._authorize(record["agreement"], caller, state)
                return self._task(record)["task"]
            message, operation, envelope = _params(params)
            agreement = envelope["agreement"]
            reference = self._authorize(agreement, caller, state)
            need(params["tenant"] == agreement["tenant"], "A2A_GATE_TENANT_SCOPE")
            request = request_digest(params)
            need(request == agreement["request"], "A2A_GATE_REQUEST_MISMATCH")
            need(operation["operation"] == agreement["operation"] and
                 canonical(operation["resources"]) == canonical(agreement["resources"]),
                 "A2A_GATE_OPERATION_SCOPE")
            verify_agreement(agreement, envelope["assents"],
                             expected_agreement=state["agreements"][reference])
            task = digest("COVENANT-REQUIRED-A2A-TASK-0.1",
                          {"service": self.service, "policy": self.policy_id,
                           "tenant": agreement["tenant"], "caller": caller,
                           "agreement": reference, "request": request})
            if task in records:
                return self._task(records[task])
            record = {"task": task, "context": message.get("contextId", task),
                      "tenant": agreement["tenant"], "caller": caller,
                      "agreement_id": reference, "agreement": deepcopy(agreement),
                      "request": request, "state_revision": state["revision"],
                      "state_hash": state_hash, "now": state["now"],
                      "params": deepcopy(params), "assents": deepcopy(envelope["assents"]),
                      "grant": deepcopy(state["grants"][agreement["grant"]]),
                      "outcome": "UNKNOWN_EXTERNAL_OUTCOME"}
            self.store.append("A2A_GATE_STARTED", task, record)
            verified = {"profile": VERSION, "agreement": deepcopy(agreement),
                        "agreement_id": reference, "request": request,
                        "params": deepcopy(params), "operation": deepcopy(operation),
                        "caller": caller, "tenant": agreement["tenant"],
                        "state_revision": state["revision"], "state_hash": state_hash,
                        "now": state["now"], "task": task}
            try:
                result = deepcopy(self.execute(verified))
                need(type(result) is dict, "A2A_GATE_RESULT_OBJECT")
                _bounded(result, MAX_EXACT_RESULT if _raw_carrier(params) else MAX_REQUEST)
                record["result"] = result
                record["outcome"] = "COMPLETED_RECORDED"
            except Exception:
                # Neither a timeout nor a malformed response proves no effect.
                # Do not log secrets/exceptions or rerun the owner callback.
                record["result"] = {}
            self.store.append("A2A_GATE_FINISHED", task, record)
            return self._task(record)


def demo_fixture(*, service="covenant-local-demo", policy_id="owner-policy-1",
                 tenant="demo-tenant", operation="deliver", payload=None,
                 resources=None, now=100):
    """Synthetic deterministic keys and state for examples/tests, NEVER real funds."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    customer = Ed25519PrivateKey.from_private_bytes(bytes([71]) * 32)
    provider = Ed25519PrivateKey.from_private_bytes(bytes([72]) * 32)
    caller = public_key(customer)
    resources = deepcopy([] if resources is None else resources)
    params = {"tenant": tenant, "message": {
        "messageId": "demo-invocation-1", "role": "ROLE_USER",
        "extensions": [EXTENSION_URI],
        "parts": [{"data": {"operation": operation,
                            "payload": {"need": "Deliver an agreed document"} if payload is None else
                            deepcopy(payload), "resources": resources}}]}}
    request = request_digest(params)
    grant = {"version": GRANT_VERSION, "service": service, "policy": policy_id,
             "tenant": tenant, "caller": caller, "operations": [operation],
             "requests": [request], "resources": deepcopy(resources),
             "valid_from": now - 1, "valid_until": now + 100, "revoked": False}
    grant_ref = grant_id(grant)
    agreement = {"version": VERSION, "service": service, "policy": policy_id,
                 "tenant": tenant, "operation": operation, "request": request,
                 "resources": deepcopy(resources),
                 "required_signers": sorted([caller, public_key(provider)]),
                 "caller": caller, "grant": grant_ref, "valid_from": now - 1,
                 "valid_until": now + 100, "nonce": "7" * 64,
                 "terms": "Deliver exact requested output; recorded execution is not payment or acceptance."}
    reference = agreement_id(agreement)
    signatures = sorted([assent(agreement, customer), assent(agreement, provider)],
                        key=lambda row: row["signer"])
    params["metadata"] = {METADATA_KEY: {"agreement": agreement, "assents": signatures}}
    state = {"revision": 1, "now": now, "agreements": {reference: deepcopy(agreement)},
             "grants": {grant_ref: deepcopy(grant)}, "revoked_agreements": []}
    return {"service": service, "policy_id": policy_id, "caller": caller,
            "params": params, "state": state, "agreement": agreement,
            "agreement_id": reference, "request": request, "grant_id": grant_ref,
            "receipt_key": provider, "customer_key": customer, "provider_key": provider,
            "active_extensions": [EXTENSION_URI]}
