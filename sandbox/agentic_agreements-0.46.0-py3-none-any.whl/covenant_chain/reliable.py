"""Opt-in durable submissions and recipient-pinned certified-history continuity.

No RPC response establishes finality. A request keeps its original signed bytes;
uncertain submission never creates another occurrence or silently changes nonce.
Custody is local POSIX SQLite under a private, operator-controlled directory.
"""
from covenant_chain.crypto import genesis_id
from contextlib import contextmanager
from copy import deepcopy
import os
from pathlib import Path
import re
import sqlite3
import stat

from .crypto import canonical, digest, integer, key, loads, need
from .app import transaction_id
from .proofs import verify_history
from .world_sdk import WorldClient

VERSION = 'covenant-submission-journal/0.1'
REQUEST = re.compile(r'[A-Za-z0-9._:-]{1,128}\Z')


class SubmissionJournal:
    """One pinned domain, many actors; one uncertified request per actor.

    The containing filesystem and its ancestors must be trusted. This is not
    distributed signing custody, encrypted storage, or Internet freshness.
    """

    def __init__(self, directory, genesis, expected_chain, *, minimum_height=0):
        key(expected_chain)
        integer(minimum_height)
        need(genesis_id(genesis) == expected_chain, 'GENESIS_PIN')
        self.genesis = deepcopy(genesis)
        self.chain = expected_chain
        self.profile = genesis['protocol']
        self.minimum_height = minimum_height
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        need(hasattr(os, 'O_NOFOLLOW') and hasattr(os, 'O_DIRECTORY'), 'JOURNAL_POSIX_REQUIRED')
        fd = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            need(stat.S_IMODE(os.fstat(fd).st_mode) & 0o077 == 0, 'JOURNAL_PRIVATE_DIRECTORY')
            try:
                dbfd = os.open('requests.sqlite', os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_NONBLOCK,
                               0o600, dir_fd=fd)
            except FileExistsError:
                dbfd = None
            if dbfd is not None:
                try:
                    os.fsync(dbfd)
                finally:
                    os.close(dbfd)
            # Closing an independently opened existing database would release
            # SQLite locks held by another connection in this same process.
            info = os.stat('requests.sqlite', dir_fd=fd, follow_symlinks=False)
            need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid()
                 and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'JOURNAL_PRIVATE_DATABASE')
            os.fsync(fd)
        finally:
            os.close(fd)
        self.db = sqlite3.connect(self.directory / 'requests.sqlite', timeout=10, isolation_level=None)
        try:
            current = os.stat(self.directory / 'requests.sqlite', follow_symlinks=False)
            need((current.st_dev, current.st_ino) == (info.st_dev, info.st_ino), 'JOURNAL_STORAGE_CHANGED')
            self.db.execute('PRAGMA journal_mode=WAL')
            self.db.execute('PRAGMA synchronous=FULL')
            self.db.execute('CREATE TABLE IF NOT EXISTS metadata (id INTEGER PRIMARY KEY CHECK(id=1), value BLOB NOT NULL)')
            self.db.execute('CREATE TABLE IF NOT EXISTS requests '
                            '(id TEXT PRIMARY KEY, actor TEXT NOT NULL, intent TEXT NOT NULL, '
                            'nonce INTEGER NOT NULL, envelope BLOB NOT NULL, transaction_id TEXT NOT NULL UNIQUE, '
                            'status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, '
                            'UNIQUE(actor,nonce))')
            with self._write():
                row = self.db.execute('SELECT value FROM metadata WHERE id=1').fetchone()
                if row:
                    meta = loads(row[0])
                    need(meta['version'] == VERSION and meta['chain'] == self.chain
                         and meta['profile'] == self.profile, 'JOURNAL_CONTEXT')
                else:
                    meta = dict(version=VERSION, chain=self.chain, profile=self.profile,
                                height=0, head='0'*64, state_root=None)
                    self.db.execute('INSERT INTO metadata VALUES (1,?)', (canonical(meta),))
        except BaseException:
            self.db.close()
            raise

    @contextmanager
    def _write(self):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def checkpoint(self):
        return loads(self.db.execute('SELECT value FROM metadata WHERE id=1').fetchone()[0])

    def request(self, request_id):
        need(type(request_id) is str and REQUEST.fullmatch(request_id) is not None, 'REQUEST_ID')
        row = self.db.execute('SELECT actor,intent,envelope,transaction_id,status,attempts,nonce '
                              'FROM requests WHERE id=?', (request_id,)).fetchone()
        if row is None:
            return None
        actor, intent, raw, tid, status, attempts, nonce = row
        tx = loads(raw)
        body = tx['body']
        need(transaction_id(tx) == tid and body['chain'] == self.chain and body['v'] == self.profile
             and body['actor'] == actor and body['nonce'] == nonce, 'JOURNAL_RECORD_CHANGED')
        expected = digest('COVENANT-REQUEST-INTENT-0.1', dict(chain=self.chain, profile=self.profile,
                          actor=actor, op=body['op'], payload=body['payload']))
        need(expected == intent and status in {'PREPARED','SENT','CERTIFIED','SUPERSEDED'},
             'JOURNAL_RECORD_CHANGED')
        return dict(request=request_id, actor=actor, intent=intent, transaction=tid,
                    status=status, attempts=attempts, envelope=tx,
                    finality='CERTIFIED_AT_LOCAL_FLOOR' if status == 'CERTIFIED' else 'NOT_ESTABLISHED')

    def prepare(self, request_id, actor, operation, payload, factory):
        need(type(request_id) is str and REQUEST.fullmatch(request_id) is not None, 'REQUEST_ID')
        key(actor)
        need(type(operation) is str and 0 < len(operation) <= 256 and type(payload) is dict, 'SDK_OPERATION')
        payload = deepcopy(payload)
        intent = digest('COVENANT-REQUEST-INTENT-0.1', dict(chain=self.chain, profile=self.profile,
                                                        actor=actor, op=operation, payload=payload))
        with self._write():
            old = self.request(request_id)
            if old is not None:
                need(old['actor'] == actor and old['intent'] == intent, 'REQUEST_CONTENT_CHANGED')
                return old
            pending = self.db.execute("SELECT id FROM requests WHERE actor=? AND status IN ('PREPARED','SENT')",
                                      (actor,)).fetchone()
            need(pending is None, 'ACTOR_HAS_UNCERTIFIED_REQUEST')
            # Serialize preparation across processes sharing this private journal.
            tx = deepcopy(factory())
            body = tx['body']
            need(body['actor'] == actor and body['chain'] == self.chain and body['v'] == self.profile
                 and body['op'] == operation and canonical(body['payload']) == canonical(payload), 'JOURNAL_ENVELOPE')
            integer(body['nonce'])
            tid = transaction_id(tx)
            try:
                self.db.execute('INSERT INTO requests(id,actor,intent,nonce,envelope,transaction_id,status) '
                                "VALUES (?,?,?,?,?,?,'PREPARED')",
                                (request_id, actor, intent, body['nonce'], canonical(tx), tid))
            except sqlite3.IntegrityError as exc:
                raise ValueError('JOURNAL_NONCE_REUSE') from exc
            return self.request(request_id)

    def attempted(self, request_id, *, acknowledged):
        need(type(acknowledged) is bool, 'JOURNAL_ACK')
        with self._write():
            row = self.request(request_id)
            need(row is not None, 'REQUEST_MISSING')
            status = row['status']
            if acknowledged and status == 'PREPARED':
                status = 'SENT'
            self.db.execute('UPDATE requests SET status=?,attempts=attempts+1 WHERE id=?',
                            (status, request_id))

    def observe(self, history):
        """Replay certificates and transitions, enforce ancestry, advance the floor.

        A certified head establishes historical state under the adopted committee
        assumptions. It does not establish that no newer head exists.
        """
        before = self.checkpoint()
        verified = verify_history(self.genesis, history, self.chain,
                                  max(self.minimum_height, before['height']))
        with self._write():
            current = self.checkpoint()
            need(verified['height'] >= max(self.minimum_height, current['height']), 'HISTORY_ROLLBACK')
            if current['height']:
                prior = digest('COVENANT_CHAIN_BLOCK', history[current['height']-1]['block'])
                need(prior == current['head'], 'HISTORY_DIVERGENCE')
            meta = dict(version=VERSION, chain=self.chain, profile=self.profile,
                        height=verified['height'], head=verified['head'], state_root=verified['state_root'])
            self.db.execute('UPDATE metadata SET value=? WHERE id=1', (canonical(meta),))
            state = verified['state']
            for request_id, actor, nonce, tid in self.db.execute(
                    "SELECT id,actor,nonce,transaction_id FROM requests WHERE status != 'CERTIFIED'").fetchall():
                if tid in state['events']:
                    self.db.execute("UPDATE requests SET status='CERTIFIED' WHERE id=?", (request_id,))
                elif state['nonces'].get(actor, 0) > nonce:
                    # Another certified occurrence took this nonce. Never replace
                    # the old request with an automatically re-signed occurrence.
                    self.db.execute("UPDATE requests SET status='SUPERSEDED' WHERE id=?", (request_id,))
        return verified

    def close(self):
        self.db.close()


class ReliableWorldClient(WorldClient):
    """Existing SDK plus explicit durable request identifiers; no new wire rules."""

    def __init__(self, client, private_key, journal, **kwargs):
        self.journal = journal
        super().__init__(client, private_key, journal.chain, protocol=journal.profile, **kwargs)

    def submit_once(self, request_id, operation, payload, *, wait=False):
        record = self.journal.prepare(request_id, self.actor, operation, payload,
                                      lambda: self.prepare(operation, payload))
        need(record['status'] != 'SUPERSEDED', 'REQUEST_SUPERSEDED_REQUIRES_REVIEW')
        if record['status'] == 'CERTIFIED':
            return record
        acknowledged = False
        try:
            self.submit_prepared(record['envelope'], wait=wait)
            acknowledged = True
        finally:
            # A timeout, lost reply or RPC rejection does not prove nonexecution.
            self.journal.attempted(request_id, acknowledged=acknowledged)
        return self.journal.request(request_id)

    def reconcile(self, history):
        return self.journal.observe(history)
