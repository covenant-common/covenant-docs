"""AAP-compatible certificates derived from passing AAP Connect conformance reports.

A certificate is a signed, verifiable mark: issuer key, subject key, the exact
adapter release (manifest, kind, implementation hash), the suite and results
hashes, the assessment level, a validity window and the mark text. Three
assessment levels are kept apart, as the compatibility programme requires:

* SELF_TEST: the subject ran the public suite itself and signs its own mark.
* PROJECT_ASSESSMENT: an assessor for the project reran the suite on the same
  release and got the same results hash.
* INDEPENDENT_ASSESSMENT: as above, by an assessor who is neither the subject
  nor the publisher.

Paying for assessment cannot buy a pass: issue() refuses unless a signed
report passed and, for assessments, the issuer's own rerun reproduces it.
Current status comes only from a fresh status record the issuer signed and
the holder staples; without one, status is UNKNOWN and a verifier that
requires status refuses. This module issues verifiable attestations, not an
official badge: an official badge needs the mark holder's written permission
(TRADEMARK.md), and no accreditation is claimed.

The Verified Agent Gateway reads these certificates under policy
covenant-agent-gateway-policy/0.6 (gateway_code below).
"""
from copy import deepcopy
import re

from . import connect
from .connect import CONTRACT, ConnectError, check
from .connect_conformance import bound, open_report, reproduced
from .crypto import canonical, digest, integer, public_key, sign, verification_key, verify

CERTIFICATE = 'urn:aap:connect-certificate:0.1'
CERTIFICATE_LABEL = 'AAP-CONNECT-CERTIFICATE-0.1'
STATUS = 'urn:aap:connect-certificate-status:0.1'
STATUS_LABEL = 'AAP-CONNECT-CERTIFICATE-STATUS-0.1'
REQUEST = 'urn:aap:connect-certification-request:0.1'
REQUEST_LABEL = 'AAP-CONNECT-CERTIFICATION-REQUEST-0.1'
CREDENTIALS = 'urn:aap:connect-credentials:0.1'
REQUIREMENT = 'urn:aap:connect-gateway-requirement:0.1'
ASSESSMENTS = ('SELF_TEST', 'PROJECT_ASSESSMENT', 'INDEPENDENT_ASSESSMENT')
STATUSES = ('ACTIVE', 'SUSPENDED', 'WITHDRAWN')
MAX_VALIDITY = 2 * 366 * 86400
MAX_STATUS_AGE = 366 * 86400
_HEX = re.compile(r'[0-9a-f]{64}\Z')
GATEWAY_CODES = {
    'CONNECT_CERT_FORMAT': 'GATEWAY_CERTIFICATE_INVALID', 'CONNECT_CERT_SIGNATURE': 'GATEWAY_CERTIFICATE_INVALID',
    'CONNECT_CERT_ISSUER': 'GATEWAY_CERTIFICATE_ISSUER', 'CONNECT_CERT_SUBJECT': 'GATEWAY_CERTIFICATE_SUBJECT',
    'CONNECT_CERT_SCOPE': 'GATEWAY_CERTIFICATE_SCOPE', 'CONNECT_CERT_ASSESSMENT': 'GATEWAY_CERTIFICATE_SCOPE',
    'CONNECT_CERT_NOT_YET_VALID': 'GATEWAY_CERTIFICATE_EXPIRED', 'CONNECT_CERT_EXPIRED': 'GATEWAY_CERTIFICATE_EXPIRED',
    'CONNECT_CERT_STATUS_UNKNOWN': 'GATEWAY_CERTIFICATE_STATUS_UNKNOWN',
    'CONNECT_CERT_REVOKED': 'GATEWAY_CERTIFICATE_REVOKED',
}


def _key(value, code):
    try:
        verification_key(value)
    except ValueError:
        raise ConnectError(code) from None
    check(type(value) is str, code)


def _hex(value, code, nullable=False):
    check((nullable and value is None) or (type(value) is str and _HEX.fullmatch(value) is not None), code)


def _int(value, code):
    try:
        integer(value)
    except ValueError:
        raise ConnectError(code) from None


def _open(envelope, label, validate, code):
    check(type(envelope) is dict and set(envelope) == {'body', 'signature'}, code)
    body = validate(envelope['body'])
    signer = body['issuer'] if 'issuer' in body else body['subject']
    try:
        verify(signer, label, body, envelope['signature'])
    except ValueError:
        raise ConnectError('CONNECT_CERT_SIGNATURE' if code != 'CONNECT_CERT_REQUEST' else code) from None
    return digest(label, body), body


# Requests ------------------------------------------------------------------------------

def _request_body(body):
    check(type(body) is dict and set(body) == {'version', 'subject', 'manifest', 'report', 'nonce', 'issued_at'} and
          body['version'] == REQUEST, 'CONNECT_CERT_REQUEST')
    _key(body['subject'], 'CONNECT_CERT_REQUEST')
    for name in ('manifest', 'report', 'nonce'):
        _hex(body[name], 'CONNECT_CERT_REQUEST')
    _int(body['issued_at'], 'CONNECT_CERT_REQUEST')
    return body


def request(subject, manifest_id, report_id, nonce, issued_at):
    """The unsigned request; the subject key signs it to prove it holds that key."""
    body = _request_body({'version': REQUEST, 'subject': subject, 'manifest': manifest_id, 'report': report_id,
                          'nonce': nonce, 'issued_at': issued_at})
    return {'id': digest(REQUEST_LABEL, body), 'body': body, 'signing_payload': {'label': REQUEST_LABEL, 'body': deepcopy(body)},
            'required_signers': [subject], 'signature_created': False, 'execution_authorized': False}


def sign_request(body, private_key):
    _request_body(body)
    check(public_key(private_key) == body['subject'], 'CONNECT_CERT_REQUEST')
    return {'body': deepcopy(body), 'signature': sign(private_key, REQUEST_LABEL, body)}


# Certificates --------------------------------------------------------------------------

def _certificate_body(body):
    check(type(body) is dict and set(body) == set(
        'version issuer subject assessment manifest kind name release implementation publisher contract suite '
        'report results rerun request issued_at expires mark'.split()), 'CONNECT_CERT_FORMAT')
    check(body['version'] == CERTIFICATE and body['contract'] == CONTRACT and body['assessment'] in ASSESSMENTS and
          body['kind'] in connect.KIND_SPECS, 'CONNECT_CERT_FORMAT')
    for name in ('issuer', 'subject', 'publisher'):
        _key(body[name], 'CONNECT_CERT_FORMAT')
    for name in ('manifest', 'implementation', 'suite', 'report', 'results', 'request'):
        _hex(body[name], 'CONNECT_CERT_FORMAT')
    _hex(body['rerun'], 'CONNECT_CERT_FORMAT', nullable=True)
    check(type(body['name']) is str and connect._NAME.fullmatch(body['name']) is not None and
          type(body['release']) is str and connect._SEMVER.fullmatch(body['release']) is not None, 'CONNECT_CERT_FORMAT')
    _int(body['issued_at'], 'CONNECT_CERT_FORMAT')
    _int(body['expires'], 'CONNECT_CERT_FORMAT')
    check(body['issued_at'] < body['expires'] <= body['issued_at'] + MAX_VALIDITY, 'CONNECT_CERT_FORMAT')
    self_test = body['assessment'] == 'SELF_TEST'
    check(self_test == (body['issuer'] == body['subject']) and self_test == (body['rerun'] is None), 'CONNECT_CERT_FORMAT')
    check(body['assessment'] != 'INDEPENDENT_ASSESSMENT' or body['issuer'] != body['publisher'], 'CONNECT_CERT_FORMAT')
    check(body['mark'] == mark_text(body), 'CONNECT_CERT_FORMAT')
    try:
        check(len(canonical(body)) <= 8192, 'CONNECT_CERT_FORMAT')
    except ValueError:
        raise ConnectError('CONNECT_CERT_FORMAT') from None
    return body


def mark_text(body):
    """The mark wording: accurate, versioned and never an official badge or accreditation claim."""
    who = ('self-tested' if body['assessment'] == 'SELF_TEST' else
           ('project assessment by ' if body['assessment'] == 'PROJECT_ASSESSMENT' else 'independent assessment by ')
           + body['issuer'][:16])
    return ('AAP-compatible (' + who + '): ' + body['kind'] + ' adapter ' + body['name'] + ' ' + body['release'] +
            ', AAP Connect 0.1 suite ' + body['suite'][:12] + ', report ' + body['report'][:12] +
            '. Not an official badge; no accreditation claimed.')


def issue(request_envelope, manifest, report, *, issuer_key, assessment, issued_at, expires, rerun=None):
    """The issuer's explicit act. A pass is derived from signed evidence, never bought."""
    request_id, asked = _open(request_envelope, REQUEST_LABEL, _request_body, 'CONNECT_CERT_REQUEST')
    opened = connect.open_manifest(manifest)
    checked = open_report(report)
    try:
        bound(opened['body'], checked)
    except ConnectError:
        raise ConnectError('CONNECT_CERT_ASSESSMENT') from None
    check(asked['manifest'] == opened['id'] and asked['report'] == checked['id'], 'CONNECT_CERT_REQUEST')
    check(assessment in ASSESSMENTS, 'CONNECT_CERT_SCOPE')
    issuer = public_key(issuer_key)
    body = opened['body']
    if assessment == 'SELF_TEST':
        check(issuer == asked['subject'] == checked['body']['tester'] and rerun is None, 'CONNECT_CERT_ASSESSMENT')
        rerun_id = None
    else:
        check(rerun is not None and issuer != asked['subject'], 'CONNECT_CERT_ASSESSMENT')
        again = open_report(rerun, expected_tester=issuer)
        check(reproduced(report, rerun), 'CONNECT_CERT_ASSESSMENT')
        check(assessment != 'INDEPENDENT_ASSESSMENT' or issuer != body['publisher'], 'CONNECT_CERT_ASSESSMENT')
        rerun_id = again['id']
    certificate = {'version': CERTIFICATE, 'issuer': issuer, 'subject': asked['subject'], 'assessment': assessment,
                   'manifest': opened['id'], 'kind': body['kind'], 'name': body['name'], 'release': body['release'],
                   'implementation': body['implementation'], 'publisher': body['publisher'], 'contract': CONTRACT,
                   'suite': body['conformance']['suite'], 'report': checked['id'],
                   'results': body['conformance']['results'], 'rerun': rerun_id, 'request': request_id,
                   'issued_at': issued_at, 'expires': expires}
    certificate['mark'] = mark_text(certificate)
    _certificate_body(certificate)
    signed = {'body': certificate, 'signature': sign(issuer_key, CERTIFICATE_LABEL, certificate)}
    return {'certificate': signed, 'id': digest(CERTIFICATE_LABEL, certificate), 'mark': certificate['mark'],
            'official_badge': False, 'accreditation': 'NONE_CLAIMED', 'execution_authorized': False}


def open_certificate(envelope):
    ident, body = _open(envelope, CERTIFICATE_LABEL, _certificate_body, 'CONNECT_CERT_FORMAT')
    return {'id': ident, 'body': deepcopy(body)}


# Status ----------------------------------------------------------------------------------

def _status_body(body):
    check(type(body) is dict and set(body) == {'version', 'certificate', 'issuer', 'status', 'as_of', 'reason_sha256'} and
          body['version'] == STATUS and body['status'] in STATUSES, 'CONNECT_CERT_FORMAT')
    _hex(body['certificate'], 'CONNECT_CERT_FORMAT')
    _key(body['issuer'], 'CONNECT_CERT_FORMAT')
    _int(body['as_of'], 'CONNECT_CERT_FORMAT')
    _hex(body['reason_sha256'], 'CONNECT_CERT_FORMAT', nullable=True)
    return body


def status_record(certificate_id, status, as_of, issuer_key, reason_sha256=None):
    """The issuer's signed current-status statement, for the holder to staple."""
    body = _status_body({'version': STATUS, 'certificate': certificate_id, 'issuer': public_key(issuer_key),
                         'status': status, 'as_of': as_of, 'reason_sha256': reason_sha256})
    return {'body': body, 'signature': sign(issuer_key, STATUS_LABEL, body)}


def _status(envelope, certificate_id, issuer, now, max_age):
    if envelope is None:
        return 'UNKNOWN'
    _, body = _open(envelope, STATUS_LABEL, _status_body, 'CONNECT_CERT_FORMAT')
    check(body['certificate'] == certificate_id and body['issuer'] == issuer, 'CONNECT_CERT_FORMAT')
    if body['status'] != 'ACTIVE':
        raise ConnectError('CONNECT_CERT_REVOKED')
    fresh = body['as_of'] <= now and (max_age is None or now - body['as_of'] <= max_age)
    return 'ACTIVE' if fresh else 'UNKNOWN'


# Verification ------------------------------------------------------------------------------

def presented(certificate, status=None):
    """What a holder attaches: the certificate and, when it has one, a fresh status."""
    return {'certificate': deepcopy(certificate), 'status': deepcopy(status)}


def verify_certificate(value, *, now, trusted_issuers=(), assessments=ASSESSMENTS[1:], kinds=None, subject=None,
                       require_status=False, max_status_age=None):
    """Check a presented certificate against the verifier's own pins. Unknown status is never ACTIVE."""
    check(type(value) is dict and set(value) == {'certificate', 'status'}, 'CONNECT_CERT_FORMAT')
    _int(now, 'CONNECT_CERT_FORMAT')
    check(type(trusted_issuers) in (list, tuple) and len(trusted_issuers) <= 64 and
          type(assessments) in (list, tuple) and set(assessments) <= set(ASSESSMENTS), 'CONNECT_CERT_SCOPE')
    check(max_status_age is None or (type(max_status_age) is int and 0 <= max_status_age <= MAX_STATUS_AGE),
          'CONNECT_CERT_SCOPE')
    opened = open_certificate(value['certificate'])
    body = opened['body']
    check(body['assessment'] in assessments, 'CONNECT_CERT_SCOPE')
    check(kinds is None or body['kind'] in kinds, 'CONNECT_CERT_SCOPE')
    if body['assessment'] != 'SELF_TEST':
        check(body['issuer'] in trusted_issuers, 'CONNECT_CERT_ISSUER')
    check(subject is None or body['subject'] == subject, 'CONNECT_CERT_SUBJECT')
    check(now >= body['issued_at'], 'CONNECT_CERT_NOT_YET_VALID')
    check(now < body['expires'], 'CONNECT_CERT_EXPIRED')
    current = _status(value['status'], opened['id'], body['issuer'], now, max_status_age)
    check(not require_status or current == 'ACTIVE', 'CONNECT_CERT_STATUS_UNKNOWN')
    return {'certificate': opened['id'], 'subject': body['subject'], 'issuer': body['issuer'],
            'assessment': body['assessment'], 'kind': body['kind'], 'manifest': body['manifest'],
            'release': body['release'], 'mark': body['mark'], 'valid_from': body['issued_at'],
            'expires': body['expires'], 'current_status': current, 'status_checked': value['status'] is not None,
            'official_badge': False, 'accreditation': 'NONE_CLAIMED', 'execution_authorized': False}


# Gateway policy /0.6 -----------------------------------------------------------------------

def validate_requirement(block):
    """The certification block of a covenant-agent-gateway-policy/0.6 policy."""
    check(type(block) is dict and set(block) == {'version', 'issuers', 'assessments', 'kinds', 'max_status_age'} and
          block['version'] == REQUIREMENT, 'CONNECT_CERT_SCOPE')
    issuers, assessments, kinds = block['issuers'], block['assessments'], block['kinds']
    check(type(issuers) is list and len(issuers) <= 16 and issuers == sorted(set(issuers)), 'CONNECT_CERT_SCOPE')
    for value in issuers:
        _key(value, 'CONNECT_CERT_SCOPE')
    check(type(assessments) is list and 1 <= len(assessments) <= 3 and assessments == sorted(set(assessments)) and
          set(assessments) <= set(ASSESSMENTS), 'CONNECT_CERT_SCOPE')
    check(set(assessments) == {'SELF_TEST'} or issuers, 'CONNECT_CERT_SCOPE')
    check(type(kinds) is list and 1 <= len(kinds) <= len(connect.KINDS) and kinds == sorted(set(kinds)) and
          set(kinds) <= set(connect.KINDS), 'CONNECT_CERT_SCOPE')
    check(block['max_status_age'] is None or (type(block['max_status_age']) is int and
                                              0 <= block['max_status_age'] <= MAX_STATUS_AGE), 'CONNECT_CERT_SCOPE')
    return block


def requirement(*, kinds, issuers=(), assessments=('PROJECT_ASSESSMENT', 'INDEPENDENT_ASSESSMENT'), max_status_age=None):
    return validate_requirement({'version': REQUIREMENT, 'issuers': sorted(set(issuers)),
                                 'assessments': sorted(set(assessments)), 'kinds': sorted(set(kinds)),
                                 'max_status_age': max_status_age})


def credentials(*, certificate, status=None, identity=None):
    """The /0.6 gateway identity slot: an optional identity statement beside a presented certificate."""
    return {'version': CREDENTIALS, 'identity': deepcopy(identity), 'certificate': deepcopy(certificate),
            'status': deepcopy(status)}


def is_credentials(value):
    return type(value) is dict and value.get('version') == CREDENTIALS


def split_credentials(value):
    """(identity, presented certificate) from a credentials bundle; malformed bundles refuse."""
    check(is_credentials(value) and set(value) == {'version', 'identity', 'certificate', 'status'}, 'CONNECT_CERT_FORMAT')
    return value['identity'], presented(value['certificate'], value['status'])


def gateway_code(value, block, counterparty, now):
    """None when the presented certificate satisfies the policy, else the gateway refusal code. Pure."""
    try:
        verify_certificate(value, now=now, trusted_issuers=block['issuers'], assessments=block['assessments'],
                           kinds=block['kinds'], subject=counterparty, require_status=block['max_status_age'] is not None,
                           max_status_age=block['max_status_age'])
    except ConnectError as error:
        return GATEWAY_CODES.get(error.code, 'GATEWAY_CERTIFICATE_INVALID')
    except (ValueError, TypeError, KeyError):
        return 'GATEWAY_CERTIFICATE_INVALID'
    return None
