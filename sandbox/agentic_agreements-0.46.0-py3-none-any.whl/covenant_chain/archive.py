"""Bounded segmented public-history recovery, independently pinned by SHA-512."""
import hashlib,json,zipfile
from pathlib import Path
from covenant_language.safe_io import atomic_stream
from .crypto import canonical,loads,need,integer
from .proofs import verify_history

def anchor(path):
    h=hashlib.sha512()
    with open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

# Shapes that only exist off chain: plaintext plus its salts or openings, and
# payloads encrypted to named recipients. A permanent public archive is the
# wrong place for them even when a history row happens to carry one.
OFF_CHAIN_VERSIONS={'covenant-private-annex/0.1','covenant-erasable-store/0.1'}
OFF_CHAIN_KEYSETS=(frozenset({'salt','text'}),frozenset({'name','value','salt'}))

def _off_chain_shape(value):
    keys=frozenset(value)
    if keys in OFF_CHAIN_KEYSETS:return True
    version=value.get('version')
    if type(version) is not str:return False
    if version in OFF_CHAIN_VERSIONS:return True
    if version=='covenant-salted-terms/1.0' and 'salts' in value and 'terms' in value:return True
    return version=='covenant-disclosure/0.1' and keys=={'version','manifest','grant','envelope'}

def off_chain_payloads(values,known=()):
    """Paths of known off-chain payloads inside ``values``.

    ``known`` is SHA-256 hex of off-chain documents the caller holds, such as
    covenant_agent.erasure.ErasableStore.known_payloads(). A string, or the
    canonical bytes of an object, with one of those hashes is refused too.
    """
    known={k for k in known};found=[]
    for k in known:need(type(k) is str and len(k)==64 and all(c in '0123456789abcdef' for c in k),'ARCHIVE_OFF_CHAIN_KNOWN')
    stack=[(value,'/'+str(i)) for i,value in enumerate(values)]
    while stack:
        value,where=stack.pop()
        if type(value) is dict:
            if _off_chain_shape(value) or (known and hashlib.sha256(canonical(value)).hexdigest() in known):found.append(where);continue
            stack.extend((item,where+'/'+str(name)) for name,item in value.items())
        elif type(value) is list:
            stack.extend((item,where+'/'+str(i)) for i,item in enumerate(value))
        elif type(value) is str and known and hashlib.sha256(value.encode('utf-8')).hexdigest() in known:
            found.append(where)
    return sorted(found)

def refuse_off_chain(genesis,entries,off_chain=()):
    """Raise ARCHIVE_OFF_CHAIN_PAYLOAD when history carries a known off-chain payload."""
    need(not off_chain_payloads([genesis,*entries],off_chain),'ARCHIVE_OFF_CHAIN_PAYLOAD')
    return True

def pack(path,genesis,entries,expected_chain):
    """Refuses off-chain payload shapes before writing; archive bytes are otherwise unchanged.

    Callers holding local off-chain documents also run refuse_off_chain with
    their hashes first (portable.archive_anchor does when given ``off_chain``).
    """
    need(len(entries)<=100000,'ARCHIVE_ENTRIES')
    refuse_off_chain(genesis,entries)
    report=verify_history(genesis,entries,expected_chain)
    blobs={'genesis.json':canonical(genesis)}
    for i,entry in enumerate(entries,1):blobs[f'history/{i:010d}.json']=canonical(entry)
    manifest={'version':'covenant-native-archive/0.1','chain':expected_chain,'height':report['height'],'head':report['head'],
              'files':{name:{'bytes':len(data),'sha512':hashlib.sha512(data).hexdigest()} for name,data in blobs.items()}}
    manifest_bytes=canonical(manifest)
    need(all(len(data)<=4000000 for data in blobs.values()) and len(manifest_bytes)<=4000000 and sum(map(len,blobs.values()))+len(manifest_bytes)<=256*1024*1024,'ARCHIVE_LIMIT')
    # Fixed metadata and stored bytes avoid clock/deflate-version dependent pins.
    # Old ZIP archives remain readable; historical anchors never get reassigned.
    # The archive appears whole or not at all; its bytes are unchanged.
    with atomic_stream(path) as out,zipfile.ZipFile(out,'w',zipfile.ZIP_STORED) as z:
        for name,data in sorted({**blobs,'manifest.json':manifest_bytes}.items()):
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_STORED;info.create_system=3
            info.external_attr=0o100644 << 16
            z.writestr(info,data)
    return {'anchor_sha512':anchor(path),'manifest':manifest}

def restore(path,expected_anchor,expected_chain,minimum_height=0):
    need(type(expected_anchor) is str and len(expected_anchor)==128 and anchor(path)==expected_anchor,'ARCHIVE_ANCHOR')
    with zipfile.ZipFile(path) as z:
        names=z.namelist();need(len(names)==len(set(names)) and len(names)<=100002,'ARCHIVE_ENTRIES')
        need(all(i.file_size<=4000000 for i in z.infolist()) and sum(i.file_size for i in z.infolist())<=256*1024*1024,'ARCHIVE_LIMIT')
        m=loads(z.read('manifest.json'));need(m['version']=='covenant-native-archive/0.1' and m['chain']==expected_chain,'ARCHIVE_CONTEXT')
        integer(m['height']);need(m['height']<=100000,'ARCHIVE_ENTRIES')
        required={'genesis.json'}|{f'history/{i:010d}.json' for i in range(1,m['height']+1)}
        need(set(m['files'])==required and set(names)==required|{'manifest.json'},'ARCHIVE_LAYOUT')
        blobs={}
        for name,meta in m['files'].items():
            raw=z.read(name);need(len(raw)==meta['bytes'] and hashlib.sha512(raw).hexdigest()==meta['sha512'],'ARCHIVE_BYTES');blobs[name]=raw
        report=verify_history(loads(blobs['genesis.json']),[loads(blobs[f'history/{i:010d}.json']) for i in range(1,m['height']+1)],expected_chain,minimum_height)
        need(report['head']==m['head'],'ARCHIVE_HEAD');return report

def quantum_attestation(path,key_id,secret_key):
    """Sign a fresh digest of all archive bytes; keep public key separately adopted."""
    from covenant_language.quantum import attest
    message=canonical({'version':'covenant-native-archive-renewal/0.1','sha512':anchor(path)})
    return attest(message,key_id=key_id,secret_key=secret_key)

def verify_quantum_attestation(path,proof,keys):
    from covenant_language.quantum import verify_attestation
    message=canonical({'version':'covenant-native-archive-renewal/0.1','sha512':anchor(path)})
    return verify_attestation(message,proof,keys={name:{'suite':'ML-DSA-65','public_key':pub} for name,pub in keys.items()})

def erasure_encode(data,*,scheme=None):
    """10-of-30 shards of an archive body. Does not change pack() or its ZIP layout.

    Returns the shard list, as on release. The default scheme is
    covenant-erasure-cauchy/0.2; each of its rows carries a 'scheme' tag, which
    records the scheme and which a release/0.15-rc peer cannot decode. Pass
    scheme='covenant-erasure-vandermonde/0.1' for untagged rows a release peer
    decodes; that matrix is not MDS for every 10-shard subset.
    """
    from .scale.erasure import SCHEME,encode
    return encode(data,scheme=SCHEME if scheme is None else scheme)

def erasure_decode(encoded,*,expected_chunk=None):
    """Decode a shard list, or erasure_encode output whose recorded scheme must match its rows."""
    from .scale.erasure import SCHEME,LEGACY_SCHEME,_tagged,decode
    shards=encoded
    if type(encoded) is dict:
        need(set(encoded)=={'scheme','shards'} and encoded['scheme'] in (SCHEME,LEGACY_SCHEME),'SCALE_SHARD_SCHEME')
        shards=encoded['shards']
        need(type(shards) is list and _tagged(shards)==(encoded['scheme']==SCHEME),'SCALE_SHARD_SCHEME')
    return decode(shards,expected_chunk=expected_chunk)

def erasure_assign(holders):
    from .scale.erasure import assign
    return assign(holders)
