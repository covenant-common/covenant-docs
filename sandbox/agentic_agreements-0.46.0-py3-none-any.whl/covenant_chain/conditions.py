"""Bounded three-valued conditions over recipient-verified observations.

Markets are inputs, never sources of authority. Price is an explicitly defined
trade statistic, not objective probability. A final outcome is procedural state,
not proof of world truth. Unknown information never becomes permission.
"""
from copy import deepcopy
from dataclasses import dataclass

from .crypto import canonical, exact, integer, key, need
from .proofs import verify_history
from .prediction import terms_id

VERSION = 'covenant-conditions/0.1'
FORMULA_VERSION = 'covenant-conditions/0.2'
PLUGIN_VERSION = 'covenant-conditions/0.3'  # Explicit formula + adopted extension semantics.
SATISFIED, UNSATISFIED, UNKNOWN = 'SATISFIED', 'UNSATISFIED', 'UNKNOWN'
AGREEMENT_TABLES = {'agreements', 'multilateral', 'review_cases', 'service_jobs', 'prediction_markets', 'effects'}
DISTINCT = {'independence_key', 'adapter', 'source_class'}
OPERATORS = {'EQ', 'GE', 'GT', 'LE', 'LT', 'TRUE'}
PLUGIN_KINDS = frozenset({'test'})


def _name(value):
    need(type(value) is str and 1 <= len(value) <= 64 and all(32 <= ord(c) <= 126 for c in value), 'CONDITION_NAME')


def _bps(value):
    integer(value);need(value <= 10000, 'CONDITION_BPS')


def _operator(value):
    need(value in OPERATORS, 'CONDITION_OPERATOR')


def _claim_value(value):
    if type(value) is int:integer(value)
    elif type(value) is str:_name(value)
    else:need(type(value) is bool, 'CONDITION_VALUE')


def _predicate(value):
    if value is None:return
    exact(value, 'field operator value');_name(value['field']);need(value['operator'] in {'EQ', 'GE', 'GT', 'LE', 'LT'}, 'CONDITION_OPERATOR')
    integer(value['value'])


def _sample(value):
    exact(value, 'value path independence_key source_class confidence_bps')
    integer(value['value']);_bps(value['confidence_bps']);_name(value['independence_key']);_name(value['source_class'])
    need(type(value['path']) is list and len(value['path']) <= 64, 'CONDITION_MERKLE')
    for step in value['path']:
        exact(step, 'side hash');key(step['hash']);need(step['side'] in {'LEFT', 'RIGHT'}, 'CONDITION_MERKLE')


def _merkle(value):
    if value is None:return
    exact(value, 'root count samples');key(value['root']);integer(value['count'], True)
    need(value['count'] <= 4096, 'CONDITION_MERKLE')
    need(type(value['samples']) is list and 1 <= len(value['samples']) <= 32, 'CONDITION_MERKLE')
    need(len(value['samples']) <= value['count'], 'CONDITION_MERKLE')
    for sample in value['samples']:_sample(sample)


class Snapshot:
    """Always reconstruct from raw evidence and independently supplied pins."""
    def __init__(self, genesis, history, chain, minimum_height=0):
        self.__history = deepcopy(history)
        self.__verified = verify_history(genesis,self.__history,chain,minimum_height)

    @property
    def state(self):
        return deepcopy(self.__verified['state'])

    @property
    def history(self):
        return deepcopy(self.__history)

    @property
    def head(self):
        return {k:self.__verified[k] for k in ('chain','height','head','state_root')}


@dataclass
class Context:
    sources: dict
    effects: dict
    verifiers: dict = None
    evidence: dict = None
    now: int = 0
    # Host-installed handlers for extension kinds, e.g. acceptance_tests.plugin()
    # for 'test'. Absent, an extension leaf stays UNSUPPORTED_CONDITION.
    plugins: dict = None
    formula: dict = None
    profile: str = VERSION

    def __post_init__(self):
        if self.verifiers is None:self.verifiers={}
        if self.evidence is None:self.evidence={}
        if self.plugins is not None:
            need(type(self.plugins) is dict and len(self.plugins)<=len(PLUGIN_KINDS) and
                 all(k in PLUGIN_KINDS and callable(v) for k,v in self.plugins.items()),'CONDITION_PLUGINS')
        need(type(self.sources) is dict and len(self.sources)<=16 and
             all(type(k) is str and type(v) is Snapshot for k,v in self.sources.items()),'CONDITION_SOURCES')
        need(type(self.effects) is dict and len(self.effects)<=1024,'CONDITION_EFFECTS')
        need(type(self.verifiers) is dict and len(self.verifiers)<=32,'CONDITION_VERIFIERS')
        need(type(self.evidence) is dict and len(self.evidence)<=4096,'CONDITION_EVIDENCE')
        need(type(self.now) is int and not type(self.now) is bool and 0<=self.now<=2**53-1,'CONDITION_TIME')
        need(self.profile in (VERSION, FORMULA_VERSION, PLUGIN_VERSION),'CONDITION_VERSION')
        if self.formula is None:self.formula={}
        need(type(self.formula) is dict and set(self.formula)<={'bindings','facts','clock'},'CONDITION_FORMULA')
        for name in ('bindings','facts','clock'):
            if name in self.formula:need(type(self.formula[name]) is dict,'CONDITION_FORMULA')


def validate(expression, *, profile=VERSION, _depth=0, _budget=None):
    need(profile in (VERSION, FORMULA_VERSION, PLUGIN_VERSION),'CONDITION_VERSION')
    budget=[128] if _budget is None else _budget
    budget[0]-=1
    need(_depth<=16 and budget[0]>=0 and type(expression) is dict,'CONDITION_LIMIT')
    kind=expression.get('kind')
    need(type(kind) is str and len(kind)<=128,'CONDITION_KIND')
    if kind in {'ALL','ANY'}:
        exact(expression,'kind conditions')
        need(type(expression['conditions']) is list and 1<=len(expression['conditions'])<=32,'CONDITION_CHILDREN')
        for child in expression['conditions']:validate(child,profile=profile,_depth=_depth+1,_budget=budget)
    elif kind=='NOT':
        exact(expression,'kind condition');validate(expression['condition'],profile=profile,_depth=_depth+1,_budget=budget)
    elif kind=='ALWAYS':
        exact(expression,'kind value');need(type(expression['value']) is bool,'CONDITION_BOOLEAN')
    elif kind=='market.finalized':
        exact(expression,'kind source chain market terms result')
        for f in ('chain','market','terms'):key(expression[f])
        need(type(expression['source']) is str,'CONDITION_SOURCE')
        exact(expression['result'],'status value')
        need(expression['result']['status'] in {'VALUE','VOID'} and
             (expression['result']['value'] is None if expression['result']['status']=='VOID'
              else type(expression['result']['value']) in (str,int)),'CONDITION_RESULT')
    elif kind=='market.price':
        exact(expression,'kind source chain market terms outcome window_blocks min_trades min_participants min_shares operator threshold_bps')
        for f in ('chain','market','terms'):key(expression[f])
        need(type(expression['source']) is str and type(expression['outcome']) is str,'CONDITION_SOURCE')
        for f in ('window_blocks','min_trades','min_participants','min_shares'):integer(expression[f],True)
        need(expression['window_blocks']<=100000 and expression['min_trades']<=10000
             and expression['min_participants']<=10000,'CONDITION_PRICE_BOUNDS')
        need(expression['operator'] in {'GT','GE','LT','LE'},'CONDITION_OPERATOR')
        integer(expression['threshold_bps']);need(expression['threshold_bps']<=10000,'CONDITION_PRICE_BOUNDS')
    elif kind=='task.effect':
        exact(expression,'kind task output_hash');key(expression['task']);key(expression['output_hash'])
    elif kind=='observation':
        exact(expression,'kind source context asset query adapter max_age predicate')
        key(expression['source']);key(expression['context']);key(expression['adapter']);integer(expression['max_age'])
        need(type(expression['asset']) is dict and type(expression['query']) is dict,'CONDITION_OBSERVATION')
        _predicate(expression['predicate'])
    elif kind=='proof':
        exact(expression,'kind verifier statement context')
        key(expression['verifier']);key(expression['context']);need(type(expression['statement']) is dict,'CONDITION_PROOF')
    elif kind=='attestation':
        need(expression.get('mode') in {'resolution','identity'},'CONDITION_ATTESTATION')
        if expression['mode']=='resolution':
            exact(expression,'kind mode expect')
            need(expression['expect'] in {'SUPPORTED','REFUTED','INDETERMINATE'},'CONDITION_ATTESTATION')
        else:
            exact(expression,'kind mode provider');key(expression['provider'])
    elif kind=='concept':
        exact(expression,'kind root');key(expression['root'])
    elif kind=='evidence':
        exact(expression,'kind adapter claim_field operator value max_age min_confidence_bps')
        key(expression['adapter']);_name(expression['claim_field']);_operator(expression['operator'])
        if expression['operator']=='TRUE':need(expression['value'] is None,'CONDITION_EVIDENCE')
        else:_claim_value(expression['value'])
        integer(expression['max_age']);_bps(expression['min_confidence_bps'])
    elif kind=='agreement.state':
        exact(expression,'kind source chain table id field equals')
        need(type(expression['source']) is str and expression['source']!='','CONDITION_SOURCE')
        key(expression['chain']);key(expression['id']);_name(expression['field'])
        need(expression['table'] in AGREEMENT_TABLES,'CONDITION_TABLE')
        if type(expression['equals']) is int:integer(expression['equals'])
        elif type(expression['equals']) is str:need(1<=len(expression['equals'])<=256 and all(32<=ord(c)<=126 for c in expression['equals']),'CONDITION_EQUALS')
        else:need(type(expression['equals']) in (bool,type(None)),'CONDITION_EQUALS')
    elif kind=='AT_LEAST':
        exact(expression,'kind k conditions distinct_by')
        integer(expression['k'],True)
        need(type(expression['conditions']) is list and 1<=len(expression['conditions'])<=32,'CONDITION_CHILDREN')
        need(expression['k']<=len(expression['conditions']),'CONDITION_QUORUM')
        need(expression['distinct_by'] is None or expression['distinct_by'] in DISTINCT,'CONDITION_DISTINCT')
        for child in expression['conditions']:validate(child,profile=profile,_depth=_depth+1,_budget=budget)
    elif kind=='AGGREGATE':
        exact(expression,'kind method inputs min_sources max_spread output fallback phantoms band quorum merkle distinct_by')
        need(expression['method']=='MEDIAN','CONDITION_AGGREGATE')
        need(expression['output'] in {'value','release_bps'},'CONDITION_AGGREGATE')
        need(type(expression['inputs']) is list and len(expression['inputs'])<=32,'CONDITION_CHILDREN')
        integer(expression['min_sources'],True);integer(expression['max_spread'])
        if expression['fallback'] is not None:integer(expression['fallback'])
        need(type(expression['phantoms']) is list and len(expression['phantoms'])<=8,'CONDITION_AGGREGATE')
        for phantom in expression['phantoms']:integer(phantom)
        if expression['band'] is not None:integer(expression['band'])
        if expression['quorum'] is not None:integer(expression['quorum'],True)
        need((expression['band'] is None)==(expression['quorum'] is None),'CONDITION_AGGREGATE')
        need(expression['distinct_by'] is None or expression['distinct_by'] in DISTINCT,'CONDITION_DISTINCT')
        _merkle(expression['merkle'])
        if expression['merkle'] is None:
            need(1<=len(expression['inputs'])<=32,'CONDITION_CHILDREN')
        else:
            need(expression['inputs']==[],'CONDITION_AGGREGATE')
        for child in expression['inputs']:validate(child,profile=profile,_depth=_depth+1,_budget=budget)
    elif kind=='expr.condition' and profile in (FORMULA_VERSION, PLUGIN_VERSION):
        from covenant_language.expr_covenant import validate_leaf
        validate_leaf(expression)
    elif kind=='expr.amount' and profile in (FORMULA_VERSION, PLUGIN_VERSION):
        raise ValueError('CONDITION_AMOUNT_NOT_A_LEAF')
    else:
        # Preserve extension syntax as data, but never assume its evaluation.
        from .json_bounds import validate_json
        validate_json(expression)
    return True


def _binds(value,digest_value):
    if value==digest_value:return True
    if type(value) is dict:return any(_binds(item,digest_value) for item in value.values())
    if type(value) is list:return any(_binds(item,digest_value) for item in value)
    return False


def _collapse(rows,distinct):
    groups={}
    for index,(status,meta) in enumerate(rows):
        key=('row',index)
        if distinct:
            found=meta.get(distinct)
            if type(found) is str:key=found
        previous=groups.get(key)
        if previous is None:groups[key]=status
        elif previous!=status:
            groups[key]=UNKNOWN if SATISFIED in (previous,status) and UNSATISFIED in (previous,status) else SATISFIED if SATISFIED in (previous,status) else UNKNOWN
    return groups


def evaluate(expression,context):
    need(type(context) is Context,'CONDITION_CONTEXT');validate(expression,profile=context.profile)
    observations=[]
    def finish(status,meta=None):return status,{} if meta is None else meta
    def leaf(status,reason,meta=None,**facts):
        observations.append(dict(status=status,reason=reason,**facts));return finish(status,meta)
    def pinset(name):
        raw=context.verifiers.get(name) or ()
        return set(raw)
    def visit(e):
        kind=e['kind']
        if kind=='ALWAYS':return finish(SATISFIED if e['value'] else UNSATISFIED)
        if kind in {'ALL','ANY'}:
            values=[status for status,_ in (visit(x) for x in e['conditions'])]
            if kind=='ALL':
                return finish(UNSATISFIED if UNSATISFIED in values else UNKNOWN if UNKNOWN in values else SATISFIED)
            return finish(SATISFIED if SATISFIED in values else UNKNOWN if UNKNOWN in values else UNSATISFIED)
        if kind=='NOT':
            status,_=visit(e['condition']);return finish({SATISFIED:UNSATISFIED,UNSATISFIED:SATISFIED,UNKNOWN:UNKNOWN}[status])
        if kind=='AT_LEAST':
            groups=_collapse([visit(x) for x in e['conditions']],e['distinct_by']);values=list(groups.values())
            satisfied=values.count(SATISFIED);unknown=values.count(UNKNOWN)
            status=SATISFIED if satisfied>=e['k'] else UNSATISFIED if satisfied+unknown<e['k'] else UNKNOWN
            return leaf(status,'AT_LEAST',k=e['k'],satisfied=satisfied,unknown=unknown,groups=len(groups))
        if kind=='AGGREGATE':return _aggregate(e)
        if kind=='task.effect':
            row=context.effects.get(e['task'])
            if row is None or row.get('status')!='OBSERVED':return leaf(UNKNOWN,'DEPENDENCY_NOT_OBSERVED',task=e['task'])
            return leaf(SATISFIED if row.get('output_hash')==e['output_hash'] else UNSATISFIED,
                        'DEPENDENCY_CONTENT',task=e['task'])
        if kind=='observation':return _observation(e)
        if kind=='proof':return _proof(e)
        if kind=='attestation':return _attestation(e)
        if kind=='concept':return _concept(e)
        if kind=='evidence':return _evidence(e)
        if kind=='agreement.state':return _agreement(e)
        if context.profile==PLUGIN_VERSION and kind in PLUGIN_KINDS and context.plugins is not None and kind in context.plugins:return _plugin(e)
        if kind=='expr.condition' and context.profile in (FORMULA_VERSION, PLUGIN_VERSION):
            from covenant_language.expr_covenant import evaluate_condition
            report=evaluate_condition(e,bindings=context.formula.get('bindings'),
                                      facts=context.formula.get('facts'),clock=context.formula.get('clock'))
            return leaf(report['status'],report['reason'],capsule=report['capsule'],steps=report['steps'])
        if kind not in {'market.finalized','market.price'}:
            return leaf(UNKNOWN,'UNSUPPORTED_CONDITION',kind=kind)
        source=context.sources.get(e['source'])
        if source is None:return leaf(UNKNOWN,'SOURCE_NOT_ADOPTED',source=e['source'])
        need(source.head['chain']==e['chain'],'CONDITION_CHAIN')
        state=source.state
        market=state.get('prediction_markets',{}).get(e['market'])
        if market is None:return leaf(UNKNOWN,'MARKET_NOT_PRESENT',market=e['market'])
        need(terms_id(market['terms'])==e['terms'],'CONDITION_MARKET_TERMS')
        if kind=='market.finalized':
            if market['status']!='FINAL':return leaf(UNKNOWN,'MARKET_NOT_FINAL',market=e['market'])
            actual=market['settled']['result']
            return leaf(SATISFIED if actual==e['result'] else UNSATISFIED,'FINAL_MARKET_RESULT',
                        market=e['market'],result=deepcopy(actual),world_truth='NOT_ESTABLISHED',as_of=source.head)
        t=market['terms']
        need(t['outcomes']==['YES','NO'] and e['outcome'] in t['outcomes'],'CONDITION_BINARY_PRICE')
        if market['status']!='OPEN' or source.head['height']>=t['close_height']:
            return leaf(UNKNOWN,'MARKET_NOT_OPEN',market=e['market'])
        trades=[];participants=set();quantity=0;value=0
        floor=max(1,source.head['height']-e['window_blocks']+1)
        for entry in source.history[floor-1:]:
            for tx in entry['block']['txs']:
                if tx['body']['op']!='PREDICTION_TRADE':continue
                order=tx['body']['payload']['order']
                if order['market']!=e['market'] or order['outcome']!=e['outcome']:continue
                trades.append(order);participants.update((order['buyer'],order['seller']))
                quantity+=order['quantity'];value+=order['quantity']*order['price']
        if len(trades)<e['min_trades'] or len(participants)<e['min_participants'] or quantity<e['min_shares']:
            return leaf(UNKNOWN,'INSUFFICIENT_TRADE_INFORMATION',trades=len(trades),participants=len(participants),shares=quantity)
        # Compare rationals exactly, without a rounded float or hidden probability assumption.
        left=value*10000;right=e['threshold_bps']*quantity*t['payout_per_unit']
        passes={'GT':left>right,'GE':left>=right,'LT':left<right,'LE':left<=right}[e['operator']]
        return leaf(SATISFIED if passes else UNSATISFIED,'CERTIFIED_TRADE_VWAP',market=e['market'],
                    statistic='VOLUME_WEIGHTED_AVERAGE_PRICE',price_numerator=value,
                    price_denominator=quantity,payout_per_unit=t['payout_per_unit'],trades=len(trades),
                    participants=len(participants),participant_independence='NOT_ESTABLISHED',
                    probability='NOT_ESTABLISHED',as_of=source.head)
    def _plugin(e):
        # A host-installed handler; its answer is checked, never trusted as permission.
        try:result=context.plugins[e['kind']](deepcopy(e),leaf)
        except (ValueError,TypeError,KeyError):return leaf(UNKNOWN,'PLUGIN_ERROR',kind=e['kind'])
        if type(result) is not tuple or len(result)!=2 or result[0] not in {SATISFIED,UNSATISFIED,UNKNOWN} or type(result[1]) is not dict:
            return leaf(UNKNOWN,'PLUGIN_RESULT',kind=e['kind'])
        return result
    def _observation(e):
        from .resource_observations import VERSION as observation_version,verify_observation
        matches=[item for item in context.evidence.values() if type(item) is dict and type(item.get('body')) is dict
                 and item['body'].get('version')==observation_version and item['body'].get('source')==e['source'] and item['body'].get('context')==e['context']]
        if len(matches)!=1:return leaf(UNKNOWN,'OBSERVATION_NOT_ADOPTED' if not matches else 'OBSERVATION_AMBIGUOUS',source=e['source'])
        if e['adapter'] not in pinset('pinned'):return leaf(UNKNOWN,'ADAPTER_NOT_PINNED',adapter=e['adapter'])
        expected=(context.verifiers.get('keys') or {}).get(e['source'],matches[0]['body']['source_key'])
        try:report=verify_observation(matches[0],e['asset'],e['query'],e['context'],e['source'],expected,context.now,e['max_age'],e['predicate'])
        except ValueError as exc:
            return leaf(UNSATISFIED if str(exc) in {'SIGNATURE','RESOURCE_EXPECTATION_MISMATCH'} else UNKNOWN,'OBSERVATION_REJECTED',source=e['source'])
        if report['status']=='SATISFIED':status=SATISFIED
        elif report['status']=='UNSATISFIED':status=UNSATISFIED
        elif report['status']=='OBSERVED' and e['predicate'] is None:status=SATISFIED
        else:status=UNKNOWN
        manifest=(context.verifiers.get('manifests') or {}).get(e['adapter']) or {}
        number=report['claim'].get(e['predicate']['field']) if e['predicate'] is not None else None
        meta={'independence_key':manifest.get('independence_key') or e['source'],'adapter':e['adapter'],
              'source_class':manifest.get('source_class') or 'SENSOR','confidence_bps':manifest.get('max_confidence_bps',10000),
              'number':number if type(number) is int else None}
        return leaf(status,'SIGNED_OBSERVATION',meta,source=e['source'],fresh=report['fresh_at_asserted_time'],world_truth='NOT_ESTABLISHED')
    def _proof(e):
        registry=context.verifiers.get('proofs')
        if registry is None or e['verifier'] not in pinset('pinned_verifiers'):return leaf(UNKNOWN,'VERIFIER_NOT_PINNED',verifier=e['verifier'])
        matches=[item for item in context.evidence.values() if type(item) is dict and item.get('context')==e['context']
                 and type(item.get('statement')) is dict and canonical(item['statement'])==canonical(e['statement'])]
        if len(matches)!=1:return leaf(UNKNOWN,'PROOF_NOT_ADOPTED' if not matches else 'PROOF_AMBIGUOUS',verifier=e['verifier'])
        try:report=registry.verify(matches[0],e['verifier'],e['context'],e['statement'])
        except ValueError:return leaf(UNKNOWN,'PROOF_NOT_CHECKABLE',verifier=e['verifier'])
        if report.get('status')=='UNKNOWN_VERIFIER':return leaf(UNKNOWN,'VERIFIER_NOT_INSTALLED',verifier=e['verifier'])
        status=SATISFIED if report.get('verified') else UNSATISFIED if report.get('status')=='INVALID' else UNKNOWN
        return leaf(status,'PROOF',verifier=e['verifier'],proof_status=report.get('status'),world_truth='NOT_ESTABLISHED',execution_note='NOT_AUTHORIZED')
    def _attestation(e):
        if e['mode']=='resolution':
            from .private_covenant import verify_resolution
            rows=[item for item in context.evidence.values() if type(item) is dict and item.get('version')=='covenant-attestation-ref/0.1' and item.get('mode')=='resolution']
            if len(rows)!=1:return leaf(UNKNOWN,'ATTESTATION_NOT_ADOPTED' if not rows else 'ATTESTATION_AMBIGUOUS')
            row=rows[0]
            try:
                report=verify_resolution(row['agreement'],row['resolution'],expected_context=row['expected_context'],expected_parties=row['expected_parties'],expected_id=row['expected_id'])
            except ValueError as exc:
                return leaf(UNKNOWN if str(exc) in {'PRIVATE_FIELDS','PRIVATE_RESOLUTION'} else UNSATISFIED,'ATTESTATION_REJECTED')
            return leaf(SATISFIED if report['result']==e['expect'] else UNSATISFIED,'PRIVATE_RESOLUTION',result=report['result'],true=False,world_truth='NOT_ESTABLISHED')
        desk=context.verifiers.get('identity')
        if desk is None or e['provider'] not in pinset('pinned_verifiers'):return leaf(UNKNOWN,'VERIFIER_NOT_PINNED',provider=e['provider'])
        rows=[item for item in context.evidence.values() if type(item) is dict and item.get('version')=='covenant-attestation-ref/0.1' and item.get('mode')=='identity' and item.get('provider')==e['provider']]
        if len(rows)!=1:return leaf(UNKNOWN,'ATTESTATION_NOT_ADOPTED' if not rows else 'ATTESTATION_AMBIGUOUS',provider=e['provider'])
        row=rows[0]
        try:accepted=desk._verify(e['provider'],row['context'],row['evidence']) is True
        except Exception:return leaf(UNKNOWN,'ATTESTATION_NOT_CHECKABLE',provider=e['provider'])
        return leaf(SATISFIED if accepted else UNSATISFIED,'IDENTITY_RULE',provider=e['provider'],true=False,world_truth='NOT_ESTABLISHED')
    def _concept(e):
        from covenant_language.frame_concepts import evaluate as concept_evaluate
        bundle=(context.verifiers.get('concepts') or {}).get(e['root'])
        if type(bundle) is not dict:return leaf(UNKNOWN,'CONCEPT_NOT_ADOPTED',root=e['root'])
        try:report=concept_evaluate(e['root'],bundle['concepts'],bundle.get('frames') or [],bundle.get('artifacts') or [])
        except ValueError:return leaf(UNKNOWN,'CONCEPT_NOT_CHECKABLE',root=e['root'])
        status={'TRUE':SATISFIED,'FALSE':UNSATISFIED}.get(report['status'],UNKNOWN)
        return leaf(status,'CONCEPT_RESULT',root=e['root'],concept_status=report['status'],stipulated=True,world_truth='NOT_ESTABLISHED')
    def _evidence(e):
        from .evidence import VERSION as evidence_version,authenticate,effective_confidence,self_written_oracle
        from .proof_facility import inspect as proof_inspect
        matches=[item for item in context.evidence.values() if type(item) is dict and item.get('version')==evidence_version and item.get('adapter')==e['adapter']]
        if len(matches)!=1:return leaf(UNKNOWN,'EVIDENCE_NOT_ADOPTED' if not matches else 'EVIDENCE_AMBIGUOUS',adapter=e['adapter'])
        if e['adapter'] not in pinset('pinned'):return leaf(UNKNOWN,'ADAPTER_NOT_PINNED',adapter=e['adapter'])
        envelope=matches[0]
        try:authenticate(envelope)
        except ValueError:return leaf(UNKNOWN,'EVIDENCE_NOT_CHECKABLE',adapter=e['adapter'])
        oracle=self_written_oracle(envelope)
        fresh=envelope['observed_at']<=envelope['reported_at']<=context.now and context.now-envelope['observed_at']<=e['max_age']
        flags=[];proofs=context.verifiers.get('proofs')
        for item in envelope['provenance']:
            ok=False
            if item['proof'] is not None and proofs is not None and item['verifier'] in pinset('pinned_verifiers'):
                proof=None
                for candidate in context.evidence.values():
                    if type(candidate) is not dict or candidate.get('context')!=envelope['context'] or 'statement' not in candidate:continue
                    try:
                        if proof_inspect(candidate)['id']==item['proof']:proof=candidate;break
                    except ValueError:continue
                if proof is not None and _binds(proof.get('statement'),envelope['blob']['sha256']):
                    try:ok=proofs.verify(proof,item['verifier'],envelope['context'],proof['statement']).get('verified') is True
                    except ValueError:ok=False
            flags.append(ok)
        if envelope['provenance'] and not all(flags):
            return leaf(UNKNOWN,'PROVENANCE_NOT_VERIFIED',adapter=e['adapter'],true=False if oracle else None,self_written_oracle=oracle)
        if not fresh:return leaf(UNKNOWN,'EVIDENCE_STALE',adapter=e['adapter'],self_written_oracle=oracle)
        manifest=(context.verifiers.get('manifests') or {}).get(e['adapter'])
        confidence=effective_confidence(envelope,manifest,provenance_verified=flags,fresh=fresh)
        if confidence<e['min_confidence_bps']:return leaf(UNKNOWN,'CONFIDENCE_BELOW_MINIMUM',adapter=e['adapter'],confidence_bps=confidence,self_written_oracle=oracle)
        claim=envelope['claim']
        if claim['field']!=e['claim_field']:return leaf(UNKNOWN,'CLAIM_FIELD',adapter=e['adapter'])
        actual=claim['value']
        if e['operator']=='TRUE':holds=actual is True
        elif type(actual) is not type(e['value']):return leaf(UNKNOWN,'CLAIM_TYPE',adapter=e['adapter'])
        else:holds={'EQ':actual==e['value'],'GE':actual>=e['value'],'GT':actual>e['value'],'LE':actual<=e['value'],'LT':actual<e['value']}[e['operator']]
        meta={'independence_key':(manifest or {}).get('independence_key') or e['adapter'],'adapter':e['adapter'],'source_class':envelope['source_class'],
              'confidence_bps':confidence,'number':actual if type(actual) is int else None,'true':False if oracle else actual is True}
        status=SATISFIED if holds else UNSATISFIED
        release=None
        if status==SATISFIED:
            from .aggregation import recommend_release
            release=recommend_release([{'confidence_bps':confidence,'independence_key':meta['independence_key'],'source_class':meta['source_class'],'adapter':e['adapter']}],context.verifiers.get('policy'))
        meta['release']=release
        return leaf(status,'EVIDENCE_CLAIM',meta,adapter=e['adapter'],confidence_bps=confidence,true=meta['true'],
                    self_written_oracle=oracle,release_bps=None if release is None else release['release_bps'],
                    level_required=None if release is None else release['level_required'],world_truth='NOT_ESTABLISHED')
    def _agreement(e):
        source=context.sources.get(e['source'])
        if source is None:return leaf(UNKNOWN,'SOURCE_NOT_ADOPTED',source=e['source'])
        need(source.head['chain']==e['chain'],'CONDITION_CHAIN')
        table=source.state.get(e['table']) if hasattr(source.state,'get') else None
        row=table.get(e['id']) if hasattr(table,'get') else None
        if type(row) is not dict or e['field'] not in row:return leaf(UNKNOWN,'AGREEMENT_NOT_PRESENT',table=e['table'])
        actual=row[e['field']]
        if type(actual) not in (str,int,bool,type(None)):return leaf(UNKNOWN,'FIELD_NOT_SCALAR',field=e['field'])
        return leaf(SATISFIED if type(actual) is type(e['equals']) and actual==e['equals'] else UNSATISFIED,'AGREEMENT_STATE',table=e['table'],field=e['field'],world_truth='NOT_ESTABLISHED')
    def _aggregate(e):
        from .aggregation import median_rule,recommend_release
        from .evidence import merkle_member
        readings=[];unknowns=0
        if e['merkle'] is None:
            for index,(status,meta) in enumerate(visit(child) for child in e['inputs']):
                if status!=SATISFIED:
                    if status==UNKNOWN:unknowns+=1
                    continue
                number=meta.get('confidence_bps') if e['output']=='release_bps' else meta.get('number')
                if type(number) is not int:
                    unknowns+=1;continue
                key=meta.get(e['distinct_by']) if e['distinct_by'] else ('row',index)
                if type(key) is not str:key=('row',index)
                readings.append({'independence_key':key,'adapter':meta.get('adapter') or key,'source_class':meta.get('source_class') or 'DOCUMENT',
                                 'confidence_bps':meta.get('confidence_bps') if type(meta.get('confidence_bps')) is int else 0,'number':number})
        else:
            root=e['merkle']['root']
            for sample in e['merkle']['samples']:
                record={name:sample[name] for name in ('value','independence_key','source_class','confidence_bps')}
                if not merkle_member(root,record,sample['path']):return leaf(UNKNOWN,'MERKLE_SPOT_CHECK_FAILED',root=root)
                readings.append({'independence_key':sample['independence_key'],'adapter':sample['independence_key'],'source_class':sample['source_class'],
                                 'confidence_bps':sample['confidence_bps'],'number':sample['confidence_bps'] if e['output']=='release_bps' else sample['value']})
        collapsed={}
        for row in readings:
            collapsed.setdefault(row['independence_key'],row)
        opened=list(collapsed.values())
        if e['merkle'] is not None and e['merkle']['count']<e['min_sources']:
            return leaf(UNSATISFIED,'AGGREGATE_POPULATION',opened=len(opened),count=e['merkle']['count'])
        if len(opened)<e['min_sources']:
            pending=unknowns or (e['merkle'] is not None and e['merkle']['count']>len(opened))
            return leaf(UNKNOWN if pending else UNSATISFIED,'AGGREGATE_SOURCES',opened=len(opened))
        numbers=[row['number'] for row in opened]
        if max(numbers)-min(numbers)>e['max_spread']:return leaf(UNKNOWN,'AGGREGATE_SPREAD',opened=len(opened))
        try:rule=median_rule(numbers,fallback=e['fallback'],phantoms=e['phantoms'],band=e['band'],quorum=e['quorum'])
        except ValueError:return leaf(UNKNOWN,'AGGREGATE_NOT_CHECKABLE')
        if rule['decisive'] is False:return leaf(UNKNOWN,'AGGREGATE_SPLIT',median=rule['median'],value=rule['median'])
        release=recommend_release([{'confidence_bps':row['confidence_bps'],'independence_key':row['independence_key'],'source_class':row['source_class'],'adapter':row['adapter']} for row in opened],context.verifiers.get('policy')) if e['output']=='release_bps' else None
        return leaf(SATISFIED,'AGGREGATE_MEDIAN',{'value':rule['median'],'release':release},median=rule['median'],
                    release_bps=None if release is None else release['release_bps'],consensus_applied=False,
                    population_not_fully_read=e['merkle'] is not None,world_truth='NOT_ESTABLISHED')
    status,meta=visit(expression)
    return dict(version=context.profile,status=status,value=meta.get('value'),release=meta.get('release'),satisfied=status==SATISFIED,
                observations=observations,latest_head_known=False,execution_authorized=False)
