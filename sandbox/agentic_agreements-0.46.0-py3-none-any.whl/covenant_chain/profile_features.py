"""Node-host features of each protocol version, in one table.

The validator host used to repeat multi-version set literals for every rule
that depends on the genesis protocol. This table names those rules once. It
describes the host (transport limits, proof export, committee hand-off). It
does not change consensus: ``app.py`` keeps its own checks, and every lookup
here equals the literal set it replaced (see tests/test_profile_features.py).

A new protocol version gets a new row. An existing row never changes meaning.
"""
from . import app

# 0.2+: authenticated tables, so /proof can export a state-record proof.
STATE_PROOFS = 'state_proofs'
# 0.3+: 64 KiB transaction transport profile.
TX_64K = 'tx_64k'
# 0.3+: committee succession; the host tracks the next validator set.
COMMITTEE_HANDOFF = 'committee_handoff'
# 0.3+: light-client epoch transition index for /light-proof bundles.
LIGHT_TRANSITIONS = 'light_transitions'
# 0.6+: discovery reads ``service_offers`` instead of ``world_services``.
SERVICE_OFFERS = 'service_offers'
# 0.7+: federation transaction and block byte limits.
FEDERATION_LIMITS = 'federation_limits'
# 0.11+: continuity transaction and block byte limits.
CONTINUITY_LIMITS = 'continuity_limits'

FEATURES = frozenset({STATE_PROOFS, TX_64K, COMMITTEE_HANDOFF, LIGHT_TRANSITIONS,
                      SERVICE_OFFERS, FEDERATION_LIMITS, CONTINUITY_LIMITS})

# Oldest first. Each version keeps every feature of the versions before it.
_ADDED = (
    (app.VERSION, ()),
    (app.NEXT_VERSION, (STATE_PROOFS,)),
    (app.LIFECYCLE_VERSION, (TX_64K, COMMITTEE_HANDOFF, LIGHT_TRANSITIONS)),
    (app.SHIELDED_VERSION, ()),
    (app.ECOSYSTEM_VERSION, ()),
    (app.MISSION_VERSION, (SERVICE_OFFERS,)),
    (app.FEDERATION_VERSION, (FEDERATION_LIMITS,)),
    (app.EXTENSIBLE_VERSION, ()),
    (app.ECONOMIC_VERSION, ()),
    (app.CONFIDENTIAL_VERSION, ()),
    (app.CONTINUITY_VERSION, (CONTINUITY_LIMITS,)),
    (app.MARKET_VERSION, ()),
    (app.REVIEW_VERSION, ()),
    (app.PREDICTION_VERSION, ()),
    (app.UPGRADE_VERSION, ()),
    (app.MIGRATION_VERSION, ()),
)


def _table():
    table, carried = {}, frozenset()
    for version, added in _ADDED:
        carried = carried | frozenset(added)
        table[version] = carried
    return table


PROFILE_FEATURES = _table()
KNOWN_VERSIONS = tuple(PROFILE_FEATURES)


def features(protocol):
    """Named host features of one protocol version. An unknown version has none."""
    return PROFILE_FEATURES.get(protocol, frozenset())


def has(protocol, feature):
    """True when the protocol version has the named host feature.

    Raises ``PROFILE_FEATURE_UNKNOWN`` for a feature name the table does not
    define, so a typo cannot silently read as False.
    """
    if feature not in FEATURES:
        raise ValueError('PROFILE_FEATURE_UNKNOWN')
    return feature in features(protocol)
