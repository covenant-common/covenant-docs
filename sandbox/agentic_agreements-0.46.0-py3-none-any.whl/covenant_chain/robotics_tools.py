"""Keyless robot mission preparation. No installation, connections or actuation."""
from . import robotics as r
from .cooperation_interface import HASH, INT, OBJECT


def spec():
    return ('covenant_robotics',
        'Prepare exact robot missions and adopted adapter descriptions. Inspect supplied status only. '
        'No signing, deployment, controller authority, network or robot control.', True, [
        ('spec', {}, ()),
        ('binding', {'robot': {'type': 'string', 'minLength': 1, 'maxLength': 256}, 'protocol': {'type': 'string', 'minLength': 1, 'maxLength': 256}, 'interface': OBJECT, 'implementation': HASH},
                    ('robot', 'protocol', 'interface', 'implementation')),
        ('draft', {'robot': {'type': 'string', 'minLength': 1, 'maxLength': 256}, 'adapter': HASH, 'capability': {'type': 'string', 'minLength': 1, 'maxLength': 256}, 'arguments': OBJECT,
                   'valid_from': INT, 'valid_until': INT, 'nonce': HASH, 'context': OBJECT},
                  ('robot', 'adapter', 'capability', 'arguments', 'valid_from', 'valid_until', 'nonce')),
        ('review', {'mission': OBJECT, 'expected_id': HASH}, ('mission', 'expected_id')),
        ('massrobotics_status', {'raw': {'type': 'string', 'maxLength': 65536}, 'expected_robot': {'type': 'string', 'minLength': 1, 'maxLength': 256},
             'expected_datum': {'type': 'string', 'minLength': 1, 'maxLength': 256}, 'now': INT, 'max_age': INT}, ('raw', 'expected_robot', 'expected_datum', 'now')),
    ])


def instructions():
    return {'profile': r.MISSION,
        'adapters': [
            {'protocol': 'rosbridge-action/2.0', 'operations': ['goal', 'feedback', 'result', 'cancel'],
             'transport': 'owner authenticated persistent rosbridge JSON connection'},
            {'protocol': 'vda5050-order/3.0.0', 'operations': ['released-route', 'state', 'cancelOrder'],
             'transport': 'owner MQTT publisher and authenticated fresh state queue'},
            {'protocol': 'massrobotics-status', 'operations': ['inspect-status-subset'], 'control': False},
            {'protocol': 'owner-defined', 'operations': ['validate', 'submit', 'observe', 'cancel'],
             'examples': ['Open-RMF fleet API', 'native ROS 2', 'vendor SDK', 'future protocol'],
             'bundled_protocol_implementation': False}],
        'journey': ['Owner pins adapter, code, robot, frames, units and permitted goal schema/limits.',
                    'Draft exact mission; put it in a chosen exact agreement and obtain required assent.',
                    'Owner installs A2A AgreementGate with RobotRuntime.a2a_executor and live authorizer.',
                    'Authenticated dispatch checks current grant, robot authority and controller interlocks.',
                    'Journal intent before send; observe original ID after uncertainty; cancellation is a request.',
                    'Keep independent physical delivery evidence and payment settlement checks.'],
        'number_codec': 'Explicit {$f64: decimal-string} becomes bounded binary64 only at the robot boundary.',
        'safety': 'Robot/controller owns collision avoidance, emergency stop and watchdogs. '
                  'One exclusive gateway per robot; no distributed fencing or safety certification.',
        'privacy': 'Owner journal uses private file permissions, not encryption. Use adopted encrypted custody '
                   'and evidence export policies for sensitive work; do not place telemetry on a public ledger.',
        'installed': False, 'execution_authorized': False, 'hardware_qualified': False}


def call(action, parameters):
    if action == 'spec': return instructions()
    if action == 'binding':
        value = r.binding(**parameters)
        return {'binding': value, 'id': r.binding_id(value), 'installed': False, 'execution_authorized': False}
    if action == 'draft': return r.draft(**parameters)
    if action == 'review': return r.review(**parameters)
    if action == 'massrobotics_status':
        from .robotics_adapters import massrobotics_status
        return massrobotics_status(**parameters)
    raise ValueError('ROBOT_TOOL_ACTION')
