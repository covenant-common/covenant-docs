"""Fee rebates and the integrator retro round.

Both are claims against pools the fee split already funded. Neither mints.
"""
from .crypto import integer, need
from .kept_promises import honour_bps
from .tokenomics_config import live_meter, live_policy


def _body(state):
    body = live_policy(state)
    need(body is not None, 'SCALE_PROFILE_REQUIRED')
    return body


def rebate_entitlement(state, account, height=None):
    body = _body(state)
    meter = live_meter(state) or {}
    if honour_bps(state, account) < body['scale']['rebates']['honour_bps']:
        accrued = 0
    else:
        accrued = 0
        receipts = state.get('fee_receipts') or {}
        for receipt in receipts.values():
            if receipt.get('payer') != account:
                continue
            scale = receipt.get('scale') or {}
            accrued += scale.get('giveback', 0)
        accrued = accrued * body['scale']['rebates']['token_rebate_bps'] // 10000
    claimed = (meter.get('rebate_claimed') or {}).get(account, 0)
    integer(claimed)
    return {'account': account, 'accrued': accrued, 'claimed': claimed, 'claimable': max(0, accrued - claimed),
            'honour_bps': honour_bps(state, account), 'execution_authorized': False, 'token_issuance': 0}


def integrator_entitlement(state, integrator, height):
    """Retro share of withheld cuts on settled, attributed covenants.

    One owner counts once per integrator. Each counterparty pair is capped.
    Cuts older than two rounds fall out of the entitlement and can be swept.
    """
    body = _body(state)
    meter = live_meter(state) or {}
    integer(height)
    window = body['scale']['window']
    config = body['scale']['integrator']
    horizon = config['round_blocks'] * 2
    owners = set()
    pairs = {}
    total = 0
    counted = 0
    for event in meter.get('events') or []:
        cut = 0
        if event.get('integrator') == integrator:
            cut += event.get('integrator_cut', 0)
        if event.get('referrer') == integrator:
            cut += event.get('referral_cut', 0)
        if cut <= 0:
            continue
        if height - event['height'] >= horizon:
            continue
        if event['principal'] == integrator or event['principal'] == event['counterparty']:
            continue
        pair = tuple(sorted((event['principal'], event['counterparty'])))
        if pairs.get(pair, 0) >= window['pair_cap']:
            continue
        if event['principal'] not in owners:
            if len(owners) >= config['per_owner_cap']:
                continue
            owners.add(event['principal'])
        pairs[pair] = pairs.get(pair, 0) + 1
        total += cut
        counted += 1
    paid = (meter.get('integrator_paid') or {}).get(integrator, 0)
    return {'integrator': integrator, 'earned': total, 'paid': paid, 'claimable': max(0, total - paid),
            'owners': len(owners), 'settlements': counted, 'execution_authorized': False, 'token_issuance': 0}


def unpaid_integrator_total(state, height):
    meter = live_meter(state) or {}
    _body(state)
    payees = set()
    for event in meter.get('events') or []:
        if event.get('integrator'):
            payees.add(event['integrator'])
        if event.get('referrer'):
            payees.add(event['referrer'])
    return sum(integrator_entitlement(state, who, height)['claimable'] for who in payees)


def sweepable(state, height):
    """Pool cash above still-claimable retro entitlements. Expired cuts are included."""
    body = _body(state)
    meter = live_meter(state) or {}
    pool = body['scale']['accounts']['integrator_pool']
    resource = body['resource']
    available = state.get('authority_available')
    cash = available[pool].get(resource, 0) if available is not None and pool in available else 0
    outstanding = unpaid_integrator_total(state, height)
    return {'pool': pool, 'resource': resource, 'cash': cash, 'outstanding': outstanding,
            'sweepable': max(0, cash - outstanding), 'execution_authorized': False}
