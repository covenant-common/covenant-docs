"""Signed introductions with bounded transitive trust and introducer accountability.

AAP application profile ``covenant-introductions/0.1``. An agent that has a
fulfilled outcome with another agent may sign a scoped introduction of it. A
principal's ranking may follow introductions outward from the principal's own
trusted contacts for a few hops, losing weight at every hop. The trust amount
(120 complete, 60 partial) and the depth an introducer lets its endorsement
travel follow the OpenPGP trust-signature model (RFC 4880 section 5.2.3.13,
RFC 9580 section 5.2.3.21), without its packet format.

Accountability: when an introduced agent later receives anchored failure
evidence, the introducer's weight as an introducer falls, and the reputation
profile also discounts the introducer's own standing. Introductions are
signed, so an introducer cannot deny vouching for a Sybil.

Signatures are attribution. Nothing here fetches, contacts, pays, installs or
authorizes anyone. The clock, contacts and resolvers belong to the caller.
"""
from copy import deepcopy

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify
from . import portable_trust

VERSION = 'covenant-introductions/0.1'
LABEL = 'COVENANT-INTRODUCTIONS-0.1'
FIELDS = {
    'INTRODUCTION': 'introducer subject task_class amount depth basis issued_at expires nonce',
    'WITHDRAWAL': 'introducer introductions withdrawn_at nonce',
}
COMPLETE = 120          # OpenPGP trust amount for complete trust; 60 is partial.
MAX_AMOUNT = 255
MAX_DEPTH = 3
DEFAULT_DEPTH = 2
DEFAULT_DECAY_BPS = 5000
PENALTY_STEP_BPS = 2500
MAX_SEED_WEIGHT = 10000
MAX_SEEDS = 64
MAX_RECORDS = 1024
MAX_RECEIPTS = 1024
MAX_RECORD_BYTES = 16384
MAX_WALK_ROWS = 65536
MAX_INPUT_BYTES = 4_000_000

REMEDIATION = {
    'INTRO_FIELDS': 'Use the exact field set of the record kind from describe().',
    'INTRO_PROFILE': 'Use version covenant-introductions/0.1; other versions are separate profiles.',
    'INTRO_KIND': 'Use kind INTRODUCTION or WITHDRAWAL.',
    'INTRO_TEXT': 'Use 1 to 80 printable ASCII characters for task_class.',
    'INTRO_SELF': 'An agent cannot introduce itself; choose a different subject.',
    'INTRO_AMOUNT': 'Use an integer trust amount from 1 to 255; 120 is complete and 60 is partial.',
    'INTRO_DEPTH': 'Use an integer depth from 0 to 3; 0 introduces the subject only.',
    'INTRO_BASIS': 'Cite 1 to 32 distinct sorted outcome receipt ids for outcomes you had with the subject.',
    'INTRO_WINDOW': 'Use integer times with issued_at strictly before expires.',
    'INTRO_LIST': 'List 1 to 256 distinct sorted introduction ids.',
    'INTRO_SIZE': 'Shrink the record or the batch below the documented byte and count bounds.',
    'INTRO_COMPLEXITY': 'Flatten the input; nesting and node counts are bounded.',
    'INTRO_JSON_TYPE': 'Use JSON objects, arrays, strings, integers, booleans or null.',
    'INTRO_SIGNATURE': 'Obtain a fresh signature by the named introducer over the unchanged body.',
    'INTRO_ENVELOPE': 'Pass {"body": ..., "signature": <128 hex>} exactly.',
    'INTRO_SEEDS': 'Pass 1 to 64 trusted contacts as {key: weight} with integer weights 1 to 10000.',
    'INTRO_WALK_POLICY': 'Use max_depth 0 to 3 and decay_bps 1 to 10000.',
    'INTRO_PENALTY': 'Penalties are integers from 0 to 10000 basis points keyed by introducer key.',
    'INTRO_SCOPE': 'The introduction names another task class than the one requested.',
    'INTRO_BASIS_MISSING': 'Supply the cited outcome receipts; an uncited or unverifiable basis does not count.',
    'INTRO_BASIS_UNFULFILLED': 'Only a verified FULFILLED outcome in the same task class, between the introducer and the subject, before the introduction, counts as basis.',
    'INTRO_DUPLICATE': 'Each record id may appear once.',
    'INTRO_FAILURES': 'Pass failure rows as {subject, at, weight, cluster} with integer weight 0 to 30000.',
    'TRUST_FIELDS': 'An outcome proof is not an object with a body object, so it was left out of the count. Pass each outcome record exactly as its signers issued it.',
    'TRUST_RECORD_KIND': 'A record passed as an outcome proof is another kind of record (not OUTCOME), so it was left out. Pass only signed OUTCOME records here.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Inspect describe() and supply the exact documented shape.')


def _bounded(value, limit=MAX_INPUT_BYTES, prefix='INTRO'):
    """Bound untrusted JSON-like input before any canonicalization or signature check."""
    stack = [(value, 0)]; nodes = 0; size = 0
    while stack:
        item, depth = stack.pop(); nodes += 1
        need(depth <= 24 and nodes <= 200000, prefix + '_COMPLEXITY')
        if type(item) is str:
            size += len(item) + 2
        elif type(item) in (int, bool) or item is None:
            size += 24
        elif type(item) in (list, dict):
            need(len(item) <= 4096, prefix + '_COMPLEXITY'); size += len(item) + 2
            if type(item) is dict:
                for name, child in item.items():
                    need(type(name) is str, prefix + '_FIELDS'); size += len(name) + 2
                    stack.append((child, depth + 1))
            else:
                stack.extend((child, depth + 1) for child in item)
        else:
            raise ValueError(prefix + '_JSON_TYPE')
        need(size <= limit, prefix + '_SIZE')


def _text(value, maximum=80):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value), 'INTRO_TEXT')


def _keyed(value):
    need(type(value) is str, 'KEY'); verification_key(value)


def _ids(values, minimum, maximum, code):
    need(type(values) is list and minimum <= len(values) <= maximum, code)
    for value in values:
        key(value)
    need(values == sorted(set(values)), code)


def _validate(body):
    _bounded(body, MAX_RECORD_BYTES)
    need(type(body) is dict and type(body.get('kind')) is str and body['kind'] in FIELDS, 'INTRO_KIND')
    need(type(body) is dict and set(body) == set(('version kind ' + FIELDS[body['kind']]).split()), 'INTRO_FIELDS')
    need(body['version'] == VERSION, 'INTRO_PROFILE')
    _keyed(body['introducer']); key(body['nonce'])
    if body['kind'] == 'INTRODUCTION':
        _keyed(body['subject']); need(body['subject'] != body['introducer'], 'INTRO_SELF')
        _text(body['task_class'])
        need(type(body['amount']) is int and 1 <= body['amount'] <= MAX_AMOUNT, 'INTRO_AMOUNT')
        need(type(body['depth']) is int and 0 <= body['depth'] <= MAX_DEPTH, 'INTRO_DEPTH')
        _ids(body['basis'], 1, 32, 'INTRO_BASIS')
        integer(body['issued_at']); integer(body['expires'])
        need(body['issued_at'] < body['expires'], 'INTRO_WINDOW')
    else:
        _ids(body['introductions'], 1, 256, 'INTRO_LIST')
        integer(body['withdrawn_at'])
    need(len(canonical(body)) <= MAX_RECORD_BYTES, 'INTRO_SIZE')
    return body


def record_id(body):
    _validate(body)
    return digest(LABEL, body)


def _prepare(kind, **fields):
    body = {'version': VERSION, 'kind': kind, **deepcopy(fields)}
    return {'id': record_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [body['introducer']], 'signature_created': False, 'execution_authorized': False}


def introduction(introducer, subject, task_class, amount, depth, basis, issued_at, expires, nonce):
    """Prepare an unsigned introduction. ``basis`` cites your outcome receipts with the subject."""
    return _prepare('INTRODUCTION', introducer=introducer, subject=subject, task_class=task_class,
                    amount=amount, depth=depth, basis=basis, issued_at=issued_at, expires=expires, nonce=nonce)


def withdrawal(introducer, introductions, withdrawn_at, nonce):
    """Prepare an unsigned withdrawal of earlier introductions by the same introducer."""
    return _prepare('WITHDRAWAL', introducer=introducer, introductions=introductions,
                    withdrawn_at=withdrawn_at, nonce=nonce)


def sign_record(body, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body['introducer'], 'INTRO_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}


def open_record(envelope, kind=None):
    _bounded(envelope, MAX_RECORD_BYTES * 2)
    need(type(envelope) is dict and set(envelope) == {'body', 'signature'}, 'INTRO_ENVELOPE')
    body = _validate(envelope['body'])
    need(kind is None or body['kind'] == kind, 'INTRO_KIND')
    try:
        verify(body['introducer'], LABEL, body, envelope['signature'])
    except ValueError:
        raise ValueError('INTRO_SIGNATURE') from None
    return {'id': digest(LABEL, body), 'body': deepcopy(body)}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL,
            'kinds': {kind: ('version kind ' + fields).split() for kind, fields in FIELDS.items()},
            'trust_amount': {'complete': COMPLETE, 'partial': COMPLETE // 2, 'maximum': MAX_AMOUNT,
                             'model': 'OPENPGP_TRUST_SIGNATURE_AMOUNT_AND_DEPTH_RFC4880_5.2.3.13'},
            'walk': 'BOUNDED_DEPTH_FROM_PRINCIPAL_TRUSTED_CONTACTS_MAX_PATH_NOT_SUM',
            'depth_limit': MAX_DEPTH, 'basis': 'VERIFIED_FULFILLED_OUTCOME_WITH_SUBJECT_BEFORE_INTRODUCTION',
            'accountability': 'ANCHORED_FAILURES_OF_INTRODUCED_SUBJECTS_REDUCE_INTRODUCER_WEIGHT',
            'independence': 'EVERYTHING_REACHED_THROUGH_ONE_TRUSTED_CONTACT_IS_ONE_CLUSTER',
            'limits': {'seeds': MAX_SEEDS, 'records': MAX_RECORDS, 'receipts': MAX_RECEIPTS,
                       'walk_rows': MAX_WALK_ROWS, 'record_bytes': MAX_RECORD_BYTES, 'input_bytes': MAX_INPUT_BYTES},
            'remediation': dict(REMEDIATION), 'global_score': False, 'world_truth_verified': False,
            'network_accessed': False, 'execution_authorized': False}


def _seeds(trusted_contacts):
    need(type(trusted_contacts) is dict and 1 <= len(trusted_contacts) <= MAX_SEEDS, 'INTRO_SEEDS')
    for contact, weight in trusted_contacts.items():
        _keyed(contact)
        need(type(weight) is int and 1 <= weight <= MAX_SEED_WEIGHT, 'INTRO_SEEDS')
    return dict(trusted_contacts)


def _policy(max_depth, decay_bps):
    need(type(max_depth) is int and 0 <= max_depth <= MAX_DEPTH and type(decay_bps) is int
         and 1 <= decay_bps <= 10000, 'INTRO_WALK_POLICY')


def _penalties(penalties):
    if penalties is None:
        return {}
    need(type(penalties) is dict and len(penalties) <= MAX_RECORDS, 'INTRO_PENALTY')
    for name, value in penalties.items():
        key(name); need(type(value) is int and 0 <= value <= 10000, 'INTRO_PENALTY')
    return penalties


def verify_outcome_receipts(receipts, adopted_resolvers=None):
    """Verify portable-trust OUTCOME records once; return {id: body} and exclusions."""
    need(type(receipts) is list and len(receipts) <= MAX_RECEIPTS, 'INTRO_SIZE')
    _bounded(receipts)
    verified = {}; excluded = []
    for record in receipts:
        try:
            need(type(record) is dict and type(record.get('body')) is dict, 'TRUST_FIELDS')
            body = record['body']
            ref = portable_trust.record_id(body)
            need(body['kind'] == 'OUTCOME', 'TRUST_RECORD_KIND')
            portable_trust.verify_outcome(record, ref, body['agreement'], body['context'], body['subject'], adopted_resolvers)
            verified[ref] = deepcopy(body)
        except (ValueError, KeyError, TypeError) as error:
            excluded.append({'kind': 'OUTCOME', 'status': 'EXCLUDED', 'reason': _code(error)})
    return verified, excluded


def _code(error):
    text = str(error.args[0]) if getattr(error, 'args', None) else ''
    return text if text and text.replace('_', '').isalnum() and text.isupper() else 'INTRO_FIELDS'


def edges(introductions, receipts, task_class, now, *, withdrawals=(), adopted_resolvers=None, verified_receipts=None):
    """Verify introductions; return walkable rows and exclusions.

    ``task_class`` None keeps every class: anchoring a witness needs an accountable
    agent, while competence in a class comes from that class's receipts. Every
    row keeps its signed window and withdrawal time so accountability can
    attribute later failures. Inactive rows are returned separately.
    """
    if task_class is not None:
        _text(task_class)
    integer(now)
    need(type(introductions) is list and len(introductions) <= MAX_RECORDS, 'INTRO_SIZE')
    need(type(withdrawals) in (list, tuple) and len(withdrawals) <= MAX_RECORDS, 'INTRO_SIZE')
    _bounded(introductions); _bounded(list(withdrawals))
    if verified_receipts is None:
        verified_receipts, _ = verify_outcome_receipts(receipts, adopted_resolvers)
    withdrawn = {}; excluded = []
    for envelope in withdrawals:
        try:
            opened = open_record(envelope, 'WITHDRAWAL')
        except ValueError as error:
            excluded.append({'kind': 'WITHDRAWAL', 'status': 'EXCLUDED', 'reason': _code(error)})
            continue
        for ref in opened['body']['introductions']:
            # Keyed by signer: a withdrawal signed by anyone else never stops an introduction.
            slot = (ref, opened['body']['introducer'])
            when = opened['body']['withdrawn_at']
            withdrawn[slot] = min(withdrawn.get(slot, when), when)
    active, inactive, seen = [], [], set()
    for envelope in introductions:
        try:
            opened = open_record(envelope, 'INTRODUCTION'); body = opened['body']
            need(opened['id'] not in seen, 'INTRO_DUPLICATE'); seen.add(opened['id'])
            need(task_class is None or body['task_class'] == task_class, 'INTRO_SCOPE')
            for ref in body['basis']:
                need(ref in verified_receipts, 'INTRO_BASIS_MISSING')
            good = [ref for ref in body['basis'] if _basis_ok(verified_receipts[ref], body)]
            need(bool(good), 'INTRO_BASIS_UNFULFILLED')
            stop = body['expires']
            if (opened['id'], body['introducer']) in withdrawn:
                stop = min(stop, withdrawn[(opened['id'], body['introducer'])])
            row = {'id': opened['id'], 'introducer': body['introducer'], 'subject': body['subject'],
                   'task_class': body['task_class'], 'amount': body['amount'], 'depth': body['depth'],
                   'issued_at': body['issued_at'], 'until': stop, 'basis': good}
            if body['issued_at'] <= now < stop:
                active.append(row)
            else:
                inactive.append({**row, 'status': 'WITHDRAWN' if stop < body['expires'] and now >= stop else 'OUTSIDE_WINDOW'})
        except ValueError as error:
            excluded.append({'kind': 'INTRODUCTION', 'status': 'EXCLUDED', 'reason': _code(error)})
    return {'active': active, 'inactive': inactive, 'excluded': excluded}


def _basis_ok(outcome, body):
    parties = set(outcome['parties'])
    return (outcome['outcome'] == 'FULFILLED' and outcome['context'] == body['task_class']
            and {body['introducer'], body['subject']} <= parties and outcome['issued_at'] <= body['issued_at'])


def _better(left, right):
    """Higher weight, then more remaining depth, then shorter, then lexically smaller path."""
    if right is None:
        return True
    a = (left[0], left[1], -len(left[2])); b = (right[0], right[1], -len(right[2]))
    return a > b if a != b else left[2] < right[2]


def _walk_from(seed, weight, adjacency, seeds, max_depth, decay_bps, penalties):
    """Best state per (node, remaining depth) on paths rooted at one trusted contact."""
    start = (weight, max_depth, (seed,), None)
    best = {(seed, max_depth): start}
    frontier = dict(best)
    for _hop in range(max_depth):
        following = {}
        for (node, remaining), (value, _, path, _via) in sorted(frontier.items()):
            if remaining < 1:
                continue
            keep = 10000 - penalties.get(node, 0)
            if keep <= 0:
                continue
            for row in adjacency.get(node, ()):
                subject = row['subject']
                # A principal's own weight for a direct contact is never overridden by others.
                if subject in path or subject in seeds:
                    continue
                carried = value * min(row['amount'], COMPLETE) // COMPLETE * decay_bps // 10000 * keep // 10000
                if carried <= 0:
                    continue
                left = min(remaining - 1, row['depth'])
                candidate = (carried, left, path + (subject,), row['id'])
                state = (subject, left)
                if _better(candidate, following.get(state)) and _better(candidate, best.get(state)):
                    following[state] = candidate
        for state, candidate in following.items():
            if _better(candidate, best.get(state)):
                best[state] = candidate
        frontier = following
    return best


def walk(trusted_contacts, rows, max_depth=DEFAULT_DEPTH, decay_bps=DEFAULT_DECAY_BPS, penalties=None, principal=None):
    """Pure bounded walk over already verified introduction rows.

    A path's weight is the seed weight times min(amount, 120)/120 times the decay
    per hop, reduced by each introducer's penalty. Each node keeps its best path
    and, per trusted contact (root), the best weight reaching it through that
    root. Parallel paths are never summed, so extra Sybil paths add nothing.
    ``principal`` adds the principal's own key as one more full-weight root, so its
    own receipts count once as its own independent evidence.
    """
    seeds = _seeds(trusted_contacts); _policy(max_depth, decay_bps); penalties = _penalties(penalties)
    if principal is not None:
        _keyed(principal); seeds.setdefault(principal, MAX_SEED_WEIGHT)
    need(type(rows) is list and len(rows) <= MAX_WALK_ROWS, 'INTRO_SIZE')
    adjacency = {}
    for row in rows:
        adjacency.setdefault(row['introducer'], []).append(row)
    for values in adjacency.values():
        values.sort(key=lambda row: (row['subject'], row['id']))
    reached = {}; roots = {}
    for seed, weight in sorted(seeds.items()):
        for (node, _remaining), candidate in _walk_from(seed, weight, adjacency, seeds, max_depth,
                                                       decay_bps, penalties).items():
            if _better(candidate, reached.get(node)):
                reached[node] = candidate
            slot = roots.setdefault(node, {})
            slot[seed] = max(slot.get(seed, 0), candidate[0])
    result = {}
    for node, (weight, remaining, path, via) in sorted(reached.items()):
        # Independence root: everything reached through one trusted contact relies on that
        # contact's judgement (and its introducees'), so each root can be credited once.
        result[node] = {'weight': weight, 'depth': len(path) - 1, 'remaining': remaining, 'path': list(path),
                        'seed': path[0], 'cluster': path[0], 'roots': dict(sorted(roots[node].items())),
                        'via': via}
    return result


def accountability(rows, failures, step_bps=PENALTY_STEP_BPS):
    """Introducer penalties from anchored failures of the subjects they introduced.

    ``failures`` are verified rows {subject, at, weight, cluster}. A failure counts
    against an introducer when it happened inside the introduction's signed window
    and before any withdrawal. One cluster counts once per subject.
    """
    need(type(failures) is list and len(failures) <= MAX_RECEIPTS * 2, 'INTRO_FAILURES')
    need(type(step_bps) is int and 0 <= step_bps <= 10000, 'INTRO_PENALTY')
    for row in failures:
        need(type(row) is dict and set(row) == {'subject', 'at', 'weight', 'cluster'}, 'INTRO_FAILURES')
        need(type(row['weight']) is int and 0 <= row['weight'] <= 30000 and type(row['at']) is int, 'INTRO_FAILURES')
    liability = {}
    for intro in rows:
        counted = {}
        for failure in failures:
            if failure['subject'] != intro['subject'] or failure['weight'] <= 0:
                continue
            if not intro['issued_at'] <= failure['at'] < intro['until']:
                continue
            cluster = failure['cluster']
            counted[cluster] = max(counted.get(cluster, 0), min(10000, failure['weight']))
        if not counted:
            continue
        entry = liability.setdefault(intro['introducer'], {'subjects': {}, 'penalty_bps': 0})
        previous = entry['subjects'].get(intro['subject'], {})
        for cluster, weight in counted.items():
            previous[cluster] = max(previous.get(cluster, 0), weight)
        entry['subjects'][intro['subject']] = previous
    penalties = {}; report = {}
    for introducer, entry in sorted(liability.items()):
        total = sum(step_bps * weight // 10000 for clusters in entry['subjects'].values() for weight in clusters.values())
        penalties[introducer] = min(10000, total)
        report[introducer] = {'failed_subjects': sorted(entry['subjects']), 'penalty_bps': penalties[introducer]}
    return penalties, report


def reach(trusted_contacts, introductions, receipts, task_class, now, *, withdrawals=(), adopted_resolvers=None,
          max_depth=DEFAULT_DEPTH, decay_bps=DEFAULT_DECAY_BPS, penalties=None):
    """Verify signed introductions and walk them from the principal's trusted contacts."""
    rows = edges(introductions, receipts, task_class, now, withdrawals=withdrawals, adopted_resolvers=adopted_resolvers)
    reached = walk(trusted_contacts, rows['active'], max_depth, decay_bps, penalties)
    return {'version': VERSION, 'task_class': task_class, 'reached': reached,
            'introductions': {'active': len(rows['active']), 'inactive': rows['inactive'], 'excluded': rows['excluded']},
            'max_depth': max_depth, 'basis': 'OWNER_TRUSTED_CONTACTS_AND_SIGNED_INTRODUCTIONS_ONLY',
            'paths_summed': False, 'global_score': False, 'world_truth_verified': False,
            'network_accessed': False, 'execution_authorized': False}
