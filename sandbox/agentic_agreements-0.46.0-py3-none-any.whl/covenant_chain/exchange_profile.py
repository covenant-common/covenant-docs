"""Demand exchange profile urn:aap:exchange:0.1: demand posts, firm offers and the award rule.

A deal is a promise both sides sign. Proof shows it was kept. If it wasn't, there
is a fair way to fix it. Here one requester posts a demand (for example a $500K
business loan); eligible offerors answer with firm offers, each signed and bound
to the exact request digest, with an expiry and typed conditions. Offers are
normalised into exact comparable numbers and ranked only by the award rule the
requester signed before offers opened: no paid placement, no hidden factor, and
a per-term explanation for every rank.

Every record here is data. A request, an offer, a ranking or a comparison grants
no authority to sign, lend, pay, release escrow or contact anyone. Clocks and
submission times are caller or book statements; unknown never becomes eligible.
"""
from copy import deepcopy
from fractions import Fraction
from functools import lru_cache, wraps
from importlib.resources import files
import json
import re

from covenant_agent.errors import NativeError

from . import exchange_credit as credit
from . import exchange_dossier as dossier
from .crypto import canonical, digest, sign, verification_key, verify

PROFILE = 'urn:aap:exchange:0.1'
VERTICALS_VERSION = 'urn:aap:exchange-verticals:0.1'
FIELDS_NORMALISER = 'urn:aap:exchange-normaliser:fields:0.1'
LABELS = {'REQUEST': 'AAP-EXCHANGE-REQUEST-0.1', 'OFFER': 'AAP-EXCHANGE-OFFER-0.1', 'SEAL': 'AAP-EXCHANGE-SEAL-0.1',
          'WITHDRAW': 'AAP-EXCHANGE-WITHDRAW-0.1', 'DECLINE': 'AAP-EXCHANGE-DECLINE-0.1',
          'AWARD': 'AAP-EXCHANGE-AWARD-0.1', 'EVIDENCE': 'AAP-EXCHANGE-EVIDENCE-0.1',
          'DECISION': 'AAP-EXCHANGE-DECISION-0.1', 'CLOSE': 'AAP-EXCHANGE-CLOSE-0.1',
          'NOTICE': 'AAP-EXCHANGE-NOTICE-0.1', 'REACCEPT': 'AAP-EXCHANGE-REACCEPT-0.1',
          'VENUE': 'AAP-EXCHANGE-VENUE-0.1', 'RELAY': 'AAP-EXCHANGE-RELAY-0.1'}
COMMITMENT_LABEL = 'AAP-EXCHANGE-SEAL-COMMITMENT-0.1'
ELIGIBILITY_LABEL = 'AAP-EXCHANGE-ELIGIBILITY-0.1'
RULE_LABEL = 'AAP-EXCHANGE-RULE-0.1'
PACK_LABEL = 'AAP-EXCHANGE-VERTICAL-0.1'
COMPARISON_LABEL = 'AAP-EXCHANGE-COMPARISON-0.1'
REFERENCE = 'docs/DEMAND_EXCHANGE.html#refusals'
MODES = ('SEALED', 'OPEN')
ROLES = ('REQUESTER', 'OFFEROR')
PAYERS = ('REQUESTER', 'OFFEROR', 'NONE')
EVIDENCE = ('SD_JWT_PRINCIPAL_KYB', 'SD_JWT_DOSSIER_FIELDS', 'FILING_RECORD', 'SIGNED_DOCUMENT', 'DOCUMENT',
            'ATTESTATION', 'OUTCOME_CHECK_RECORD', 'PAYMENT_OBSERVATION', 'DEPOSIT_RECEIPT')
SD_JWT_EVIDENCE = ('SD_JWT_PRINCIPAL_KYB', 'SD_JWT_DOSSIER_FIELDS')
WITHDRAW_REASONS = ('OFFEROR_CHOICE', 'CAPACITY', 'TERMS_CHANGED', 'ERROR', 'OTHER')
VAGUE_REASONS = ('INTERNAL_STANDARDS', 'POLICY', 'SCORE_TOO_LOW', 'NOT_QUALIFIED', 'OTHER')
OPS = {'LE': lambda a, b: a <= b, 'LT': lambda a, b: a < b, 'GE': lambda a, b: a >= b,
       'GT': lambda a, b: a > b, 'EQ': lambda a, b: a == b}
SPEC_KINDS = ('MONEY', 'INTEGER', 'TIME', 'DURATION', 'ENUM', 'TEXT', 'HASH', 'UNIT', 'BOOLEAN')
NUMERIC = ('MONEY', 'INTEGER', 'TIME', 'DURATION', 'BOOLEAN')
MAX = 2**53 - 1
MAX_RECORD_BYTES = 65536
MAX_PRESENTATION = 32768
MAX_SUBMISSIONS = 256
HASH = re.compile(r'[0-9a-f]{64}\Z')
NAME = re.compile(r'[a-z][a-z0-9_-]{0,63}\Z')
CODE = re.compile(r'[A-Z][A-Z0-9_]{1,63}\Z')
UNIT = re.compile(r'[A-Z0-9][A-Z0-9-]{0,15}\Z')
FLAGS = {'execution_authorized': False, 'payment_authorized': False, 'signature_created': False,
         'network': False, 'paid_placement': False}
JOBS = {'Find and be found': ['request'], 'Make a deal': ['offer', 'compare', 'award'],
        'Keep records': ['checklist', 'record']}
RETRY = {'NO': 'no; the same input fails again', 'AFTER_FIX': 'yes, after the fix',
         'LATER': 'yes, later; nothing is wrong with the input', 'SAFE': 'yes; the identical call is idempotent'}

# What happened, what to do next and whether retrying helps, per refusal code.
WHAT = {
    'EXCHANGE_FIELDS': 'The record does not have the exact field set this profile defines.',
    'EXCHANGE_KEY': 'A key or digest is not a 64-character lowercase hex value.',
    'EXCHANGE_INTEGER': 'A number is not an integer inside its documented range.',
    'EXCHANGE_TEXT': 'A text field is empty, too long or not printable ASCII.',
    'EXCHANGE_SIZE': 'The record is larger or deeper than the profile allows.',
    'EXCHANGE_PROFILE': 'The record names a different profile version.',
    'EXCHANGE_KIND': 'The record kind does not fit this step.',
    'EXCHANGE_VERTICAL': 'The vertical pack is unknown or does not match the digest the request pinned.',
    'EXCHANGE_VERTICAL_PACK': 'The supplied vertical pack is malformed.',
    'EXCHANGE_WANT': 'The demand does not match the vertical pack.',
    'EXCHANGE_TERMS': 'The offer terms do not match the vertical pack.',
    'EXCHANGE_ELIGIBILITY_POLICY': 'The eligibility rule is malformed.',
    'EXCHANGE_PLAN': 'The disclosure plan is not four cumulative stages of known dossier fields.',
    'EXCHANGE_TEASER': 'The public teaser does not match the PUBLIC_TEASER stage.',
    'EXCHANGE_WINDOW': 'The offer window or close deadline is out of order.',
    'EXCHANGE_MODE': 'The mode is not SEALED or OPEN.',
    'EXCHANGE_RULE': 'The award rule is malformed or scores against the requester.',
    'EXCHANGE_CONDITIONS': 'A condition template is malformed.',
    'EXCHANGE_DISPUTE': 'The dispute procedure is malformed.',
    'EXCHANGE_FEES': 'The fee disclosure is malformed.',
    'EXCHANGE_VENUES': 'The venue list is malformed.',
    'EXCHANGE_SIGNATURE': 'A signature does not verify over the exact record.',
    'EXCHANGE_PERMISSION': 'The agent has no verified permission from the principal for this request.',
    'EXCHANGE_REQUEST_MISMATCH': 'The offer is bound to a different request digest.',
    'EXCHANGE_REQUEST_CHANGED': 'The request is not the one you pinned.',
    'EXCHANGE_SELF_OFFER': 'The requester cannot offer on its own demand.',
    'EXCHANGE_OFFER_VALIDITY': 'The offer would expire before the window closes plus the minimum validity.',
    'EXCHANGE_DEPOSIT': 'The commitment deposit is malformed.',
    'EXCHANGE_SEAL_MISMATCH': 'The revealed offer and salt do not open this seal.',
    'EXCHANGE_SALT': 'The seal salt is not 64 lowercase hex characters.',
    'EXCHANGE_SEALED_UNTIL_CLOSE': 'Sealed offers cannot be opened or compared before the window closes.',
    'EXCHANGE_WITHDRAWAL': 'The withdrawal is malformed or names another offer.',
    'EXCHANGE_DECLINE': 'The decline is malformed.',
    'EXCHANGE_DECLINE_REASON_NOT_SPECIFIC': 'A decline reason is too vague to explain the decision.',
    'EXCHANGE_INELIGIBLE': 'The offeror did not prove the eligibility the request requires.',
    'EXCHANGE_SUBMISSIONS': 'The submissions list is malformed.',
    'EXCHANGE_DETAIL': 'The detail level is unknown.',
    'EXCHANGE_ACTION': 'The tool action is unknown.',
    'EXCHANGE_COMPARISON': 'The comparison does not match the request, rule and offers.',
    'EXCHANGE_NOT_RANKED': 'This offer is not the best remaining offer under the declared rule.',
    'EXCHANGE_APPROVAL_REQUIRED': "The award is above the owner's limit and has no owner approval.",
    'EXCHANGE_APPROVAL_INVALID': 'The owner approval does not bind this exact award, amount and payee.',
    'EXCHANGE_APPROVAL_EXPIRED': 'The owner approval has expired.',
    'EXCHANGE_APPROVAL_POLICY': 'The owner approval policy does not constrain this agent.',
    'EXCHANGE_APPROVAL_METHOD_UNSUPPORTED': 'This approval method is not supported for exchange awards.',
    'EXCHANGE_AWARD': 'The award record is malformed or does not match its agreement.',
    'EXCHANGE_AWARD_EXISTS': 'This request already has a different award.',
    'EXCHANGE_EVIDENCE': "The evidence does not fit the condition's evidence type.",
    'EXCHANGE_CONDITION_UNKNOWN': "The condition is not on this award's checklist.",
    'EXCHANGE_NOT_SUPPLIER': "Only the condition's supplier can submit its evidence.",
    'EXCHANGE_NOT_BENEFICIARY': "Only the condition's beneficiary can accept, fail or waive it.",
    'EXCHANGE_OUTCOME_RECORD': 'The outcome check record is malformed or bound to another spec or artifact.',
    'EXCHANGE_CHECKLIST_INCOMPLETE': 'Not every condition is satisfied or waived.',
    'EXCHANGE_CLOSE': 'The close receipt is malformed or contradicts the records.',
    'EXCHANGE_CLOSE_SIGNATURES': 'The close receipt lacks a required party signature.',
    'EXCHANGE_RETRADE_UNACCEPTED': 'The final terms are worse for the requester than the firm offer and were not re-accepted.',
    'EXCHANGE_REACCEPTANCE': 'The re-acceptance does not match the exact change.',
    'EXCHANGE_NOTICE': 'The notice is malformed.',
    'EXCHANGE_UNKNOWN_REQUEST': 'This book holds no such request.',
    'EXCHANGE_WINDOW_NOT_OPEN': 'The offer window has not opened yet.',
    'EXCHANGE_WINDOW_CLOSED': 'The offer window has closed.',
    'EXCHANGE_REVEAL_LATE': 'The reveal deadline has passed.',
    'EXCHANGE_DUPLICATE_OFFER': 'This offeror or credential already has an offer on this request.',
    'EXCHANGE_OFFER_LIMIT': 'The request already holds its maximum number of offers.',
    'EXCHANGE_SEAL_MISSING': 'No seal was recorded for this offeror.',
    'EXCHANGE_RULE_CHANGED_AFTER_OPENING': 'The award rule cannot change once offers opened.',
    'EXCHANGE_REQUEST_LOCKED': 'The request cannot change once offers opened.',
    'EXCHANGE_VENUE': 'The venue rules record is malformed.',
    'EXCHANGE_VENUE_RULES': "The request breaks this venue's published rules.",
    'EXCHANGE_VENUE_SIGNATURE': 'The venue or relay record does not verify against the operator key.',
    'EXCHANGE_JOURNAL_HEAD': 'The book journal is not at the head you retained.',
    'EXCHANGE_STORAGE': 'The book storage could not confirm the write.',
    'EXCHANGE_CONFIG': 'The book configuration is invalid.',
    'EXCHANGE_RECORDS': 'The receipt list is malformed.',
    'CREDIT_WANT': 'The loan request is malformed.',
    'CREDIT_CURRENCY': 'The currency is not a three-letter code.',
    'CREDIT_TERMS': 'The term sheet is malformed or its schedule cannot amortise.',
    'CREDIT_RATE': 'The rate is malformed.',
    'CREDIT_FEES': 'A fee is malformed.',
    'CREDIT_PREPAYMENT': 'The prepayment terms are malformed.',
    'CREDIT_APR': 'The APR input is malformed.',
    'CREDIT_APR_NEGATIVE': 'The payments total less than the amount financed.',
    'CREDIT_APR_RANGE': 'The APR is above 1200 percent.',
    'CREDIT_DISCLOSURE_PACK': 'The disclosure pack is unknown or malformed.',
    'DOSSIER_FIELD': 'A dossier field name, value or list is malformed.',
    'DOSSIER_FIELD_FILLED': 'That dossier field is already filled.',
    'DOSSIER_FIELD_MISSING': 'The dossier has no such field.',
    'DOSSIER_PLAN': 'The disclosure plan is malformed.',
    'DOSSIER_STAGE': 'The stage is unknown.',
    'DOSSIER_ISSUER': 'The issuer, issuer pins or credential lifetime are invalid.',
    'DOSSIER_ISSUER_NOT_PINNED': 'The credential issuer is not pinned by the verifier.',
    'DOSSIER_CREDENTIAL': 'The credential or holder key does not fit this dossier.',
    'DOSSIER_ATTESTATION': 'The SD-JWT attestation does not verify.',
    'DOSSIER_KEY_BINDING': 'The key binding is missing, stale or bound to another release.',
    'DOSSIER_CONSENT': 'The consent receipt is malformed.',
    'DOSSIER_CONSENT_SIGNATURE': 'The consent receipt signature does not verify.',
    'DOSSIER_CONSENT_EXPIRED': 'The consent has expired or is not yet valid.',
    'DOSSIER_CONSENT_REVOKED': 'The holder revoked this consent.',
    'DOSSIER_REVOCATION': 'The revocation record is malformed or unsigned.',
    'DOSSIER_RELEASE': 'The release is malformed, unsigned or does not match its consent.',
    'DOSSIER_BEYOND_CONSENT': 'The release asks for more fields than the consent or the stage allows.',
}
REMEDIATION = {
    'EXCHANGE_FIELDS': 'Send exactly the documented fields; extra fields such as sponsored placement are refused.',
    'EXCHANGE_KEY': 'Pass the Ed25519 public key or SHA-256 digest as 64 lowercase hex characters.',
    'EXCHANGE_INTEGER': 'Send an exact integer in minor units or seconds; floats and booleans are refused.',
    'EXCHANGE_TEXT': 'Shorten it to printable ASCII; put long prose in a document and send its SHA-256.',
    'EXCHANGE_SIZE': 'Shrink the record below 64 KiB and the documented list limits.',
    'EXCHANGE_PROFILE': 'Use urn:aap:exchange:0.1; never relabel a signed record.',
    'EXCHANGE_KIND': 'Send a REQUEST, OFFER, SEAL, WITHDRAW or DECLINE record where each is expected.',
    'EXCHANGE_VERTICAL': 'Name a shipped vertical, or supply the exact pack whose digest the request signed.',
    'EXCHANGE_VERTICAL_PACK': 'Fix the pack: typed flat fields, numeric metrics, bindings and condition templates.',
    'EXCHANGE_WANT': 'Fill every field the vertical asks for with its declared type.',
    'EXCHANGE_TERMS': 'Fill every term the vertical defines with its declared type and range.',
    'EXCHANGE_ELIGIBILITY_POLICY': 'List required claims (verified_agent, principal_kyb) with 1 to 8 pinned issuer keys, or none.',
    'EXCHANGE_PLAN': 'List fields for PUBLIC_TEASER, ELIGIBLE, SHORTLIST and AWARD; each stage keeps the earlier ones.',
    'EXCHANGE_TEASER': 'Give a bounded value for exactly the PUBLIC_TEASER fields.',
    'EXCHANGE_WINDOW': 'Use created_at <= opens < closes <= reveal_by < close_by; OPEN mode uses reveal_by = closes.',
    'EXCHANGE_MODE': 'Choose SEALED (commit, then reveal after close) or OPEN.',
    'EXCHANGE_RULE': 'Declare hard limits, 1 to 8 weighted metrics with best and worst bounds, and a tie-break ending in OFFER_ID.',
    'EXCHANGE_CONDITIONS': 'Give each condition an id, kind, evidence type, distinct supplier and beneficiary, due time and issuer pins for SD-JWT evidence.',
    'EXCHANGE_DISPUTE': 'Name a procedure and optional resolver and appeal keys.',
    'EXCHANGE_FEES': 'Say who pays the operator, and disclose any adviser fee, unit and conflicts.',
    'EXCHANGE_VENUES': 'List up to 8 venue rule digests in sorted order, or none for peer to peer.',
    'EXCHANGE_SIGNATURE': 'Obtain a fresh signature over the unchanged body; never edit terms to fit an old signature.',
    'EXCHANGE_PERMISSION': "Attach the principal's signed mandate chain naming this agent, action, vertical and amount.",
    'EXCHANGE_REQUEST_MISMATCH': 'Make a fresh offer bound to this exact request digest.',
    'EXCHANGE_REQUEST_CHANGED': 'Re-read the request and pin its current digest before comparing or awarding.',
    'EXCHANGE_SELF_OFFER': 'Use a distinct offeror key.',
    'EXCHANGE_OFFER_VALIDITY': 'Make the offer firm until at least closes + min_validity.',
    'EXCHANGE_DEPOSIT': 'Give amount, unit and payer, or null for no deposit.',
    'EXCHANGE_SEAL_MISMATCH': 'Reveal the exact signed offer and salt that were committed.',
    'EXCHANGE_SALT': 'Use 32 random bytes as hex and keep them secret until close.',
    'EXCHANGE_SEALED_UNTIL_CLOSE': 'Wait until the close time; nobody can read a sealed offer earlier.',
    'EXCHANGE_WITHDRAWAL': 'Sign a withdrawal for your own offer or seal, with a listed reason.',
    'EXCHANGE_DECLINE': 'Sign a decline with 1 to 4 listed reason codes for this vertical.',
    'EXCHANGE_DECLINE_REASON_NOT_SPECIFIC': 'Give the principal specific reasons (12 CFR 1002.9(b)(2) style); internal standards alone are not a reason.',
    'EXCHANGE_INELIGIBLE': 'Present a fresh credential from a pinned issuer with the required claims, bound to this request.',
    'EXCHANGE_SUBMISSIONS': 'Send up to 256 {offer, submitted_at} rows recorded by the book.',
    'EXCHANGE_DETAIL': 'Use SUMMARY or FULL.',
    'EXCHANGE_ACTION': 'Call describe to list the actions under their jobs.',
    'EXCHANGE_COMPARISON': 'Recompute the comparison from the stored request and offers, then award from it.',
    'EXCHANGE_NOT_RANKED': 'Award the top remaining offer, or record why each higher offer dropped out.',
    'EXCHANGE_APPROVAL_REQUIRED': 'Ask the owner to approve this exact award with the adopted method, then retry.',
    'EXCHANGE_APPROVAL_INVALID': 'Request a fresh owner approval for the exact award.',
    'EXCHANGE_APPROVAL_EXPIRED': 'Request a fresh owner approval.',
    'EXCHANGE_APPROVAL_POLICY': 'Install the owner-signed policy that names this agent key.',
    'EXCHANGE_APPROVAL_METHOD_UNSUPPORTED': 'Use an OWNER_KEY approval policy; passkey approval for awards is not implemented.',
    'EXCHANGE_AWARD': 'Prepare the award again from the request, offer and comparison.',
    'EXCHANGE_AWARD_EXISTS': 'Withdraw or close the existing award first; one award per request.',
    'EXCHANGE_EVIDENCE': 'Send the evidence type the condition names, signed by its supplier.',
    'EXCHANGE_CONDITION_UNKNOWN': 'Use a condition id from the checklist.',
    'EXCHANGE_NOT_SUPPLIER': 'Have the named supplier sign the evidence.',
    'EXCHANGE_NOT_BENEFICIARY': 'Have the beneficiary sign the decision.',
    'EXCHANGE_OUTCOME_RECORD': 'Supply the outcome check result for the agreed spec and the delivered artifact digest.',
    'EXCHANGE_CHECKLIST_INCOMPLETE': 'Satisfy or waive each open condition before closing.',
    'EXCHANGE_CLOSE': 'Prepare the close receipt again from the award, checklist and final terms.',
    'EXCHANGE_CLOSE_SIGNATURES': 'Collect the signatures the outcome needs: both parties to close, the beneficiary for a failed condition.',
    'EXCHANGE_RETRADE_UNACCEPTED': 'The requester must sign a re-acceptance of the exact change, or refuse and use the dispute procedure.',
    'EXCHANGE_REACCEPTANCE': 'Sign a re-acceptance for this offer, award, final terms and change digest.',
    'EXCHANGE_NOTICE': 'Prepare the notice from the recorded comparison.',
    'EXCHANGE_UNKNOWN_REQUEST': 'Post the signed request to this book first.',
    'EXCHANGE_WINDOW_NOT_OPEN': 'Submit after the opens time.',
    'EXCHANGE_WINDOW_CLOSED': 'Nothing can be added; watch for a new request.',
    'EXCHANGE_REVEAL_LATE': 'The unrevealed seal is recorded as not revealed.',
    'EXCHANGE_DUPLICATE_OFFER': 'Withdraw the first offer before any new one; one offer per offeror and credential.',
    'EXCHANGE_OFFER_LIMIT': 'Watch for a new request; withdrawals do not reopen a slot.',
    'EXCHANGE_SEAL_MISSING': 'Seal during the window; a reveal without a seal is refused.',
    'EXCHANGE_RULE_CHANGED_AFTER_OPENING': 'Keep the signed rule, or close this request and post a new one.',
    'EXCHANGE_REQUEST_LOCKED': 'Close this request and post a new one.',
    'EXCHANGE_VENUE': 'Publish venue rules with eligibility, stages, rule limits and a declared fee.',
    'EXCHANGE_VENUE_RULES': 'Change the request to meet the venue rules, or post it elsewhere or peer to peer.',
    'EXCHANGE_VENUE_SIGNATURE': 'Obtain an unmodified record signed by the venue operator.',
    'EXCHANGE_JOURNAL_HEAD': 'Restore the backup that matches your retained head; never accept a rolled-back book.',
    'EXCHANGE_STORAGE': 'Retry the identical call; replays are idempotent and the outcome is otherwise unknown.',
    'EXCHANGE_CONFIG': 'Construct the book with a private directory, a clock and optional pinned hooks.',
    'EXCHANGE_RECORDS': 'Send up to 4096 signed exchange records.',
    'CREDIT_WANT': 'Give product, amount, currency, purpose, term range, offered collateral and jurisdiction.',
    'CREDIT_CURRENCY': 'Use an ISO 4217 code such as USD.',
    'CREDIT_TERMS': 'Use the documented term sheet: principal, rate, fees, term, amortisation, collateral, guarantees and covenants.',
    'CREDIT_RATE': 'Use FIXED bps, or INDEX_PLUS_MARGIN with the index value at offer, margin, floor and cap.',
    'CREDIT_FEES': 'Name each fee once with amount and timing; only fees at funding may be outside the finance charge.',
    'CREDIT_PREPAYMENT': 'Use NONE, REMAINING_INTEREST or PERCENT_OF_BALANCE with bps and months.',
    'CREDIT_APR': 'Pass the amount financed and 1 to 360 non-negative integer payments.',
    'CREDIT_APR_NEGATIVE': 'Check the schedule; a negative APR is not a loan this profile prices.',
    'CREDIT_APR_RANGE': 'Check the payments; the solver stops at 1200 percent.',
    'CREDIT_DISCLOSURE_PACK': 'Use us-ca-commercial-financing or us-ny-cfdl; packs are data and need legal review.',
    'DOSSIER_FIELD': 'Use lowercase field names in sorted order and values under 8 KiB.',
    'DOSSIER_FIELD_FILLED': 'Fill each field once; build a new dossier to change a value.',
    'DOSSIER_FIELD_MISSING': 'Fill the field or attach its credential first.',
    'DOSSIER_PLAN': 'Use the four cumulative stages.',
    'DOSSIER_STAGE': 'Use PUBLIC_TEASER, ELIGIBLE, SHORTLIST or AWARD.',
    'DOSSIER_ISSUER': 'Pin 1 to 16 issuer keys; credentials last at most 90 days.',
    'DOSSIER_ISSUER_NOT_PINNED': 'Present a credential from an issuer the request or condition pinned.',
    'DOSSIER_CREDENTIAL': 'Use a credential issued to this holder key and disclose only claims it holds.',
    'DOSSIER_ATTESTATION': 'Present an unmodified, unexpired credential of type urn:aap:vct:business-dossier:0.1.',
    'DOSSIER_KEY_BINDING': 'Create a fresh presentation for this recipient, request and stage.',
    'DOSSIER_CONSENT': 'Name holder, recipient, request, stage, fields, purpose, retention and expiry.',
    'DOSSIER_CONSENT_SIGNATURE': 'The holder must sign the exact consent receipt.',
    'DOSSIER_CONSENT_EXPIRED': 'Ask the holder for a new consent.',
    'DOSSIER_CONSENT_REVOKED': 'Stop using the data and delete it under the consent terms.',
    'DOSSIER_REVOCATION': 'Use the holder-signed revocation of the exact consent.',
    'DOSSIER_RELEASE': 'Use the unmodified release the holder made for you.',
    'DOSSIER_BEYOND_CONSENT': 'Release only the fields the plan allows at this stage and the holder consented to.',
}
RETRY_POLICY = {
    'EXCHANGE_FIELDS': 'AFTER_FIX',
    'EXCHANGE_KEY': 'AFTER_FIX',
    'EXCHANGE_INTEGER': 'AFTER_FIX',
    'EXCHANGE_TEXT': 'AFTER_FIX',
    'EXCHANGE_SIZE': 'AFTER_FIX',
    'EXCHANGE_PROFILE': 'NO',
    'EXCHANGE_KIND': 'AFTER_FIX',
    'EXCHANGE_VERTICAL': 'AFTER_FIX',
    'EXCHANGE_VERTICAL_PACK': 'AFTER_FIX',
    'EXCHANGE_WANT': 'AFTER_FIX',
    'EXCHANGE_TERMS': 'AFTER_FIX',
    'EXCHANGE_ELIGIBILITY_POLICY': 'AFTER_FIX',
    'EXCHANGE_PLAN': 'AFTER_FIX',
    'EXCHANGE_TEASER': 'AFTER_FIX',
    'EXCHANGE_WINDOW': 'AFTER_FIX',
    'EXCHANGE_MODE': 'AFTER_FIX',
    'EXCHANGE_RULE': 'AFTER_FIX',
    'EXCHANGE_CONDITIONS': 'AFTER_FIX',
    'EXCHANGE_DISPUTE': 'AFTER_FIX',
    'EXCHANGE_FEES': 'AFTER_FIX',
    'EXCHANGE_VENUES': 'AFTER_FIX',
    'EXCHANGE_SIGNATURE': 'NO',
    'EXCHANGE_PERMISSION': 'AFTER_FIX',
    'EXCHANGE_REQUEST_MISMATCH': 'NO',
    'EXCHANGE_REQUEST_CHANGED': 'NO',
    'EXCHANGE_SELF_OFFER': 'NO',
    'EXCHANGE_OFFER_VALIDITY': 'AFTER_FIX',
    'EXCHANGE_DEPOSIT': 'AFTER_FIX',
    'EXCHANGE_SEAL_MISMATCH': 'NO',
    'EXCHANGE_SALT': 'AFTER_FIX',
    'EXCHANGE_SEALED_UNTIL_CLOSE': 'LATER',
    'EXCHANGE_WITHDRAWAL': 'AFTER_FIX',
    'EXCHANGE_DECLINE': 'AFTER_FIX',
    'EXCHANGE_DECLINE_REASON_NOT_SPECIFIC': 'AFTER_FIX',
    'EXCHANGE_INELIGIBLE': 'AFTER_FIX',
    'EXCHANGE_SUBMISSIONS': 'AFTER_FIX',
    'EXCHANGE_DETAIL': 'AFTER_FIX',
    'EXCHANGE_ACTION': 'AFTER_FIX',
    'EXCHANGE_COMPARISON': 'NO',
    'EXCHANGE_NOT_RANKED': 'NO',
    'EXCHANGE_APPROVAL_REQUIRED': 'AFTER_FIX',
    'EXCHANGE_APPROVAL_INVALID': 'NO',
    'EXCHANGE_APPROVAL_EXPIRED': 'AFTER_FIX',
    'EXCHANGE_APPROVAL_POLICY': 'AFTER_FIX',
    'EXCHANGE_APPROVAL_METHOD_UNSUPPORTED': 'NO',
    'EXCHANGE_AWARD': 'AFTER_FIX',
    'EXCHANGE_AWARD_EXISTS': 'NO',
    'EXCHANGE_EVIDENCE': 'AFTER_FIX',
    'EXCHANGE_CONDITION_UNKNOWN': 'AFTER_FIX',
    'EXCHANGE_NOT_SUPPLIER': 'NO',
    'EXCHANGE_NOT_BENEFICIARY': 'NO',
    'EXCHANGE_OUTCOME_RECORD': 'AFTER_FIX',
    'EXCHANGE_CHECKLIST_INCOMPLETE': 'LATER',
    'EXCHANGE_CLOSE': 'AFTER_FIX',
    'EXCHANGE_CLOSE_SIGNATURES': 'AFTER_FIX',
    'EXCHANGE_RETRADE_UNACCEPTED': 'AFTER_FIX',
    'EXCHANGE_REACCEPTANCE': 'NO',
    'EXCHANGE_NOTICE': 'AFTER_FIX',
    'EXCHANGE_UNKNOWN_REQUEST': 'AFTER_FIX',
    'EXCHANGE_WINDOW_NOT_OPEN': 'LATER',
    'EXCHANGE_WINDOW_CLOSED': 'NO',
    'EXCHANGE_REVEAL_LATE': 'NO',
    'EXCHANGE_DUPLICATE_OFFER': 'NO',
    'EXCHANGE_OFFER_LIMIT': 'NO',
    'EXCHANGE_SEAL_MISSING': 'NO',
    'EXCHANGE_RULE_CHANGED_AFTER_OPENING': 'NO',
    'EXCHANGE_REQUEST_LOCKED': 'NO',
    'EXCHANGE_VENUE': 'AFTER_FIX',
    'EXCHANGE_VENUE_RULES': 'AFTER_FIX',
    'EXCHANGE_VENUE_SIGNATURE': 'NO',
    'EXCHANGE_JOURNAL_HEAD': 'NO',
    'EXCHANGE_STORAGE': 'SAFE',
    'EXCHANGE_CONFIG': 'AFTER_FIX',
    'EXCHANGE_RECORDS': 'AFTER_FIX',
    'CREDIT_WANT': 'AFTER_FIX',
    'CREDIT_CURRENCY': 'AFTER_FIX',
    'CREDIT_TERMS': 'AFTER_FIX',
    'CREDIT_RATE': 'AFTER_FIX',
    'CREDIT_FEES': 'AFTER_FIX',
    'CREDIT_PREPAYMENT': 'AFTER_FIX',
    'CREDIT_APR': 'AFTER_FIX',
    'CREDIT_APR_NEGATIVE': 'NO',
    'CREDIT_APR_RANGE': 'NO',
    'CREDIT_DISCLOSURE_PACK': 'AFTER_FIX',
    'DOSSIER_FIELD': 'AFTER_FIX',
    'DOSSIER_FIELD_FILLED': 'NO',
    'DOSSIER_FIELD_MISSING': 'AFTER_FIX',
    'DOSSIER_PLAN': 'AFTER_FIX',
    'DOSSIER_STAGE': 'AFTER_FIX',
    'DOSSIER_ISSUER': 'AFTER_FIX',
    'DOSSIER_ISSUER_NOT_PINNED': 'NO',
    'DOSSIER_CREDENTIAL': 'AFTER_FIX',
    'DOSSIER_ATTESTATION': 'NO',
    'DOSSIER_KEY_BINDING': 'AFTER_FIX',
    'DOSSIER_CONSENT': 'AFTER_FIX',
    'DOSSIER_CONSENT_SIGNATURE': 'NO',
    'DOSSIER_CONSENT_EXPIRED': 'AFTER_FIX',
    'DOSSIER_CONSENT_REVOKED': 'NO',
    'DOSSIER_REVOCATION': 'AFTER_FIX',
    'DOSSIER_RELEASE': 'NO',
    'DOSSIER_BEYOND_CONSENT': 'AFTER_FIX',
}
REFUSALS = {code: (WHAT[code], REMEDIATION[code], RETRY_POLICY[code]) for code in REMEDIATION}
_INNER = {'FIELDS': 'EXCHANGE_FIELDS', 'KEY': 'EXCHANGE_KEY', 'PUBLIC_KEY': 'EXCHANGE_KEY', 'INTEGER': 'EXCHANGE_INTEGER',
          'INTEGER_RANGE': 'EXCHANGE_INTEGER', 'SIGNATURE': 'EXCHANGE_SIGNATURE', 'SIGNATURE_ENCODING': 'EXCHANGE_SIGNATURE',
          'ASCII_PROFILE': 'EXCHANGE_TEXT', 'SIZE_LIMIT': 'EXCHANGE_SIZE', 'DEPTH_LIMIT': 'EXCHANGE_SIZE',
          'ARRAY_LIMIT': 'EXCHANGE_SIZE', 'MAP_LIMIT': 'EXCHANGE_SIZE', 'MAP_KEY': 'EXCHANGE_FIELDS', 'TYPE': 'EXCHANGE_FIELDS'}


class ExchangeError(NativeError):
    """A refusal that says what happened, what to do next, whether retrying helps and where to read more."""

    def __init__(self, code):
        what = WHAT.get(code, 'The input was refused.')
        fix = REMEDIATION.get(code, 'Correct the named input and retry.')
        retry = RETRY_POLICY.get(code, 'AFTER_FIX')
        super().__init__(code, f'{what} Fix: {fix} Retry: {RETRY[retry]}. Reference: {REFERENCE}')
        self.what, self.fix, self.retry, self.reference = what, fix, retry, REFERENCE


def explain(code):
    need(type(code) is str and code in REFUSALS, 'EXCHANGE_FIELDS')
    what, fix, retry = REFUSALS[code]
    return {'code': code, 'what': what, 'fix': fix, 'retry': retry, 'retry_helps': RETRY[retry], 'reference': REFERENCE}


def refusal(exc):
    """Translate a ValueError code from a lower layer into a teaching refusal."""
    if isinstance(exc, ExchangeError):
        return exc
    code = str(exc)
    return ExchangeError(_INNER.get(code, code if CODE.fullmatch(code) else 'EXCHANGE_FIELDS'))


def teaching(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except ExchangeError:
            raise
        except ValueError as exc:
            raise refusal(exc) from None
        except (TypeError, KeyError, AttributeError, IndexError):
            # A malformed untrusted shape fails closed with a code, never a traceback.
            raise ExchangeError('EXCHANGE_FIELDS') from None
    return wrapped


def need(ok, code):
    if not ok:
        raise ExchangeError(code)


def _int(value, code='EXCHANGE_INTEGER', minimum=0, maximum=MAX):
    need(type(value) is int and minimum <= value <= maximum, code)
    return value


def _text(value, code='EXCHANGE_TEXT', maximum=128):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _hash(value, code='EXCHANGE_KEY'):
    need(type(value) is str and HASH.fullmatch(value) is not None, code)
    return value


def _key(value, code='EXCHANGE_KEY'):
    need(type(value) is str and HASH.fullmatch(value) is not None, code)
    try:
        verification_key(value)
    except ValueError:
        raise ExchangeError(code) from None
    return value


def _exact(value, names, code='EXCHANGE_FIELDS'):
    need(type(value) is dict and set(value) == set(names.split()), code)
    return value


def _bounded(value, limit=MAX_RECORD_BYTES):
    try:
        raw = canonical(value)
    except ValueError as exc:
        raise ExchangeError({'ASCII_PROFILE': 'EXCHANGE_TEXT', 'INTEGER_RANGE': 'EXCHANGE_INTEGER',
                             'TYPE': 'EXCHANGE_FIELDS'}.get(str(exc), 'EXCHANGE_SIZE')) from None
    need(len(raw) <= limit, 'EXCHANGE_SIZE')
    return value


def record_id(kind, body):
    need(kind in LABELS, 'EXCHANGE_KIND')
    _bounded(body, MAX_RECORD_BYTES + MAX_PRESENTATION)
    return digest(LABELS[kind], body)


@teaching
def sign_record(kind, body, private_key):
    """Explicit local owner action; no tool exposes it. Returns {body, signature}."""
    record_id(kind, body)
    return {'body': deepcopy(body), 'signature': sign(private_key, LABELS[kind], body)}


def _signed(kind, envelope, signer_field, names='body signature'):
    _exact(envelope, names)
    body = envelope['body']
    need(type(body) is dict and body.get('version') == PROFILE, 'EXCHANGE_PROFILE')
    need(body.get('kind') == kind, 'EXCHANGE_KIND')
    ref = record_id(kind, body)
    _key(body.get(signer_field))
    try:
        verify(body[signer_field], LABELS[kind], body, envelope['signature'])
    except ValueError:
        raise ExchangeError('EXCHANGE_SIGNATURE') from None
    return body, ref


# --- vertical packs ------------------------------------------------------------

@lru_cache(maxsize=1)
def _shipped():
    raw = files('covenant_chain').joinpath('data/exchange_verticals.json').read_bytes()
    need(len(raw) <= 262144, 'EXCHANGE_VERTICAL_PACK')
    data = json.loads(raw)
    need(type(data) is dict and data.get('profile') == VERTICALS_VERSION and type(data.get('verticals')) is dict,
         'EXCHANGE_VERTICAL_PACK')
    for ident, pack in data['verticals'].items():
        validate_vertical(pack)
        need(pack['id'] == ident, 'EXCHANGE_VERTICAL_PACK')
    return data


def shipped_verticals():
    return deepcopy(_shipped())


def _spec(spec):
    need(type(spec) is dict and spec.get('kind') in SPEC_KINDS, 'EXCHANGE_VERTICAL_PACK')
    kind = spec['kind']
    if kind == 'INTEGER':
        _exact(spec, 'kind min max', 'EXCHANGE_VERTICAL_PACK')
        _int(spec['min'], 'EXCHANGE_VERTICAL_PACK')
        _int(spec['max'], 'EXCHANGE_VERTICAL_PACK', spec['min'])
    elif kind == 'ENUM':
        _exact(spec, 'kind values', 'EXCHANGE_VERTICAL_PACK')
        values = spec['values']
        need(type(values) is list and 1 <= len(values) <= 32 and values == sorted(set(values))
             and all(type(v) is str and CODE.fullmatch(v) for v in values), 'EXCHANGE_VERTICAL_PACK')
    elif kind == 'TEXT':
        _exact(spec, 'kind max', 'EXCHANGE_VERTICAL_PACK')
        _int(spec['max'], 'EXCHANGE_VERTICAL_PACK', 1, 1024)
    else:
        _exact(spec, 'kind', 'EXCHANGE_VERTICAL_PACK')


def _typed(spec, value, code):
    kind = spec['kind']
    if kind in ('MONEY', 'TIME', 'DURATION'):
        _int(value, code)
    elif kind == 'INTEGER':
        _int(value, code, spec['min'], spec['max'])
    elif kind == 'ENUM':
        need(type(value) is str and value in spec['values'], code)
    elif kind == 'TEXT':
        _text(value, code, spec['max'])
    elif kind == 'HASH':
        _hash(value, code)
    elif kind == 'UNIT':
        need(type(value) is str and UNIT.fullmatch(value) is not None, code)
    else:
        need(type(value) is bool, code)
    return value


def validate_condition(row, code='EXCHANGE_CONDITIONS'):
    _exact(row, 'id kind evidence supplier beneficiary due_after_award issuers', code)
    need(type(row['id']) is str and NAME.fullmatch(row['id']) is not None, code)
    need(type(row['kind']) is str and CODE.fullmatch(row['kind']) is not None and row['evidence'] in EVIDENCE, code)
    need(row['supplier'] in ROLES and row['beneficiary'] in ROLES and row['supplier'] != row['beneficiary'], code)
    _int(row['due_after_award'], code, 0, 366 * 86400)
    pins = row['issuers']
    need(type(pins) is dict and len(pins) <= 8, code)
    for name, value in pins.items():
        _text(name, code, 128)
        _key(value, code)
    need(bool(pins) == (row['evidence'] in SD_JWT_EVIDENCE), code)
    return row


def _conditions(rows, limit=16):
    need(type(rows) is list and len(rows) <= limit, 'EXCHANGE_CONDITIONS')
    for row in rows:
        validate_condition(row)
    need(len({row['id'] for row in rows}) == len(rows), 'EXCHANGE_CONDITIONS')
    return rows


@teaching
def validate_vertical(pack):
    _exact(pack, 'id title species maturity normaliser amount want terms bindings metrics decline_reasons '
                 'dossier_fields disclosure_packs', 'EXCHANGE_VERTICAL_PACK')
    _bounded(pack)
    need(type(pack['id']) is str and NAME.fullmatch(pack['id']) is not None, 'EXCHANGE_VERTICAL_PACK')
    _text(pack['title'], 'EXCHANGE_VERTICAL_PACK', 128)
    need(pack['species'] in ('credit', 'service', 'exchange', 'licence', 'risk')
         and pack['maturity'] in ('experimental', 'beta', 'stable'), 'EXCHANGE_VERTICAL_PACK')
    _exact(pack['amount'], 'want_amount want_unit term_amount term_unit', 'EXCHANGE_VERTICAL_PACK')
    metrics = pack['metrics']
    need(type(metrics) is dict and 1 <= len(metrics) <= 16, 'EXCHANGE_VERTICAL_PACK')
    if pack['normaliser'] == credit.NORMALISER:
        need(pack['want'] == pack['terms'] == pack['bindings'] == 'CODE', 'EXCHANGE_VERTICAL_PACK')
        need(set(metrics) == set(credit.DIRECTIONS), 'EXCHANGE_VERTICAL_PACK')
        for name, row in metrics.items():
            _exact(row, 'field direction unit', 'EXCHANGE_VERTICAL_PACK')
            need(row['field'] is None and row['direction'] == credit.DIRECTIONS[name], 'EXCHANGE_VERTICAL_PACK')
    else:
        need(pack['normaliser'] == FIELDS_NORMALISER, 'EXCHANGE_VERTICAL_PACK')
        for part in ('want', 'terms'):
            specs = pack[part]
            need(type(specs) is dict and 1 <= len(specs) <= 24, 'EXCHANGE_VERTICAL_PACK')
            for name, spec in specs.items():
                need(type(name) is str and NAME.fullmatch(name) is not None, 'EXCHANGE_VERTICAL_PACK')
                _spec(spec)
        amount = pack['amount']
        need(pack['want'].get(amount['want_amount'], {}).get('kind') == 'MONEY'
             and pack['terms'].get(amount['term_amount'], {}).get('kind') == 'MONEY'
             and pack['want'].get(amount['want_unit'], {}).get('kind') == 'UNIT'
             and pack['terms'].get(amount['term_unit'], {}).get('kind') == 'UNIT', 'EXCHANGE_VERTICAL_PACK')
        bindings = pack['bindings']
        need(type(bindings) is list and len(bindings) <= 16, 'EXCHANGE_VERTICAL_PACK')
        for row in bindings:
            _exact(row, 'term rule want', 'EXCHANGE_VERTICAL_PACK')
            need(row['term'] in pack['terms'] and row['want'] in pack['want']
                 and row['rule'] in ('EQUALS_WANT', 'AT_MOST_WANT', 'AT_LEAST_WANT'), 'EXCHANGE_VERTICAL_PACK')
            if row['rule'] != 'EQUALS_WANT':
                need(pack['terms'][row['term']]['kind'] in NUMERIC and pack['want'][row['want']]['kind'] in NUMERIC,
                     'EXCHANGE_VERTICAL_PACK')
        for name, row in metrics.items():
            _exact(row, 'field direction unit', 'EXCHANGE_VERTICAL_PACK')
            need(NAME.fullmatch(name) is not None and row['field'] in pack['terms']
                 and pack['terms'][row['field']]['kind'] in NUMERIC
                 and row['direction'] in ('LOWER', 'HIGHER', 'UNKNOWN'), 'EXCHANGE_VERTICAL_PACK')
    for name, row in metrics.items():
        need(type(row['unit']) is str and CODE.fullmatch(row['unit']) is not None, 'EXCHANGE_VERTICAL_PACK')
    reasons = pack['decline_reasons']
    need(type(reasons) is list and 1 <= len(reasons) <= 32 and reasons == sorted(set(reasons))
         and all(type(r) is str and CODE.fullmatch(r) and r not in VAGUE_REASONS for r in reasons), 'EXCHANGE_VERTICAL_PACK')
    fields = pack['dossier_fields']
    need(type(fields) is list and len(fields) <= 32 and fields == sorted(set(fields))
         and all(type(f) is str and dossier.NAME.fullmatch(f) for f in fields), 'EXCHANGE_VERTICAL_PACK')
    packs = pack['disclosure_packs']
    need(type(packs) is list and len(packs) <= 8 and all(type(p) is str for p in packs), 'EXCHANGE_VERTICAL_PACK')
    return pack


@teaching
def pack_id(pack):
    validate_vertical(pack)
    return digest(PACK_LABEL, pack)


def vertical_ref(ident, packs=()):
    """The {id, pack} reference a request signs; pins the exact pack bytes."""
    return {'id': ident, 'pack': pack_id(resolve_vertical({'id': ident, 'pack': None}, packs, pinned=False))}


def resolve_vertical(ref, packs=(), pinned=True):
    _exact(ref, 'id pack', 'EXCHANGE_VERTICAL')
    need(type(packs) in (list, tuple) and len(packs) <= 8, 'EXCHANGE_VERTICAL')
    found = [deepcopy(p) for p in packs if type(p) is dict and p.get('id') == ref['id']]
    if not found and ref['id'] in _shipped()['verticals']:
        found = [deepcopy(_shipped()['verticals'][ref['id']])]
    need(len(found) == 1, 'EXCHANGE_VERTICAL')
    pack = found[0]
    if pinned:
        _hash(ref['pack'], 'EXCHANGE_VERTICAL')
        need(pack_id(pack) == ref['pack'], 'EXCHANGE_VERTICAL')
    return pack


def _fields_check(specs, value, code):
    need(type(value) is dict and set(value) == set(specs), code)
    for name, spec in specs.items():
        _typed(spec, value[name], code)
    return value


@teaching
def validate_want(pack, want):
    if pack['want'] == 'CODE':
        try:
            return credit.validate_want(want)
        except ValueError as exc:
            raise ExchangeError(str(exc) if str(exc) in REFUSALS else 'EXCHANGE_WANT') from None
    return _fields_check(pack['want'], want, 'EXCHANGE_WANT')


@teaching
def validate_terms(pack, terms):
    _bounded(terms)
    if pack['terms'] == 'CODE':
        try:
            return credit.validate_terms(terms)
        except ValueError as exc:
            raise ExchangeError(str(exc) if str(exc) in REFUSALS else 'EXCHANGE_TERMS') from None
    return _fields_check(pack['terms'], terms, 'EXCHANGE_TERMS')


def amount_of(pack, terms):
    """MONEY {amount, unit} of an offer: principal or price, in minor units."""
    ref = pack['amount']
    return {'kind': 'MONEY', 'amount': terms[ref['term_amount']], 'unit': terms[ref['term_unit']]}


def want_amount(pack, want):
    ref = pack['amount']
    return {'kind': 'MONEY', 'amount': want[ref['want_amount']], 'unit': want[ref['want_unit']]}


@teaching
def normalise(pack, want, terms, detail='SUMMARY'):
    """Exact integer metrics per vertical plus the computation that produced them."""
    need(detail in ('SUMMARY', 'FULL'), 'EXCHANGE_DETAIL')
    validate_want(pack, want)
    validate_terms(pack, terms)
    if pack['normaliser'] == credit.NORMALISER:
        try:
            made = credit.normalise(terms, want, detail)
        except ValueError as exc:
            raise ExchangeError(str(exc) if str(exc) in REFUSALS else 'CREDIT_TERMS') from None
        return made
    metrics = {}
    for name, row in pack['metrics'].items():
        value = terms[row['field']]
        metrics[name] = int(value) if type(value) is bool else value
    binding = []
    for row in pack['bindings']:
        term, wanted = terms[row['term']], want[row['want']]
        ok = (term == wanted if row['rule'] == 'EQUALS_WANT' else term <= wanted if row['rule'] == 'AT_MOST_WANT'
              else term >= wanted)
        if not ok:
            binding.append(row['rule'] + ':' + row['term'])
    return {'vertical': pack['id'], 'normaliser': FIELDS_NORMALISER, 'metrics': metrics,
            'computation': {'method': 'DECLARED_TERM_FIELDS_AS_METRICS', 'fields': {n: r['field'] for n, r in pack['metrics'].items()}},
            'binding': binding}


# --- award rule -------------------------------------------------------------------

@teaching
def validate_rule(pack, rule):
    _exact(rule, 'hard score tie_break shortlist', 'EXCHANGE_RULE')
    metrics = pack['metrics']
    need(type(rule['hard']) is list and len(rule['hard']) <= 16, 'EXCHANGE_RULE')
    for row in rule['hard']:
        _exact(row, 'metric op value', 'EXCHANGE_RULE')
        need(type(row['metric']) is str and row['metric'] in metrics and type(row['op']) is str and row['op'] in OPS,
             'EXCHANGE_RULE')
        _int(row['value'], 'EXCHANGE_RULE')
    score = rule['score']
    need(type(score) is list and 1 <= len(score) <= 8, 'EXCHANGE_RULE')
    for row in score:
        _exact(row, 'metric weight best worst', 'EXCHANGE_RULE')
        need(type(row['metric']) is str and row['metric'] in metrics, 'EXCHANGE_RULE')
        _int(row['weight'], 'EXCHANGE_RULE', 1, 1000)
        _int(row['best'], 'EXCHANGE_RULE')
        _int(row['worst'], 'EXCHANGE_RULE')
        need(row['best'] != row['worst'], 'EXCHANGE_RULE')
        declared = metrics[row['metric']]['direction']
        # Best terms mean best for the requester: a rule may not reward the worse direction.
        need(declared == 'UNKNOWN' or (declared == 'LOWER') == (row['best'] < row['worst']), 'EXCHANGE_RULE')
    need(len({row['metric'] for row in score}) == len(score), 'EXCHANGE_RULE')
    ties = rule['tie_break']
    need(type(ties) is list and 1 <= len(ties) <= 6 and ties[-1] == 'OFFER_ID' and len(set(ties)) == len(ties), 'EXCHANGE_RULE')
    for item in ties:
        if item in ('OFFER_ID', 'EARLIEST_SUBMISSION'):
            continue
        parts = item.split(':') if type(item) is str else []
        need(len(parts) == 3 and parts[0] == 'METRIC' and parts[1] in metrics and parts[2] in ('LOWER', 'HIGHER'),
             'EXCHANGE_RULE')
        declared = metrics[parts[1]]['direction']
        need(declared in ('UNKNOWN', parts[2]), 'EXCHANGE_RULE')
    _int(rule['shortlist'], 'EXCHANGE_RULE', 1, 32)
    return rule


def rule_id(rule):
    return digest(RULE_LABEL, rule)


def evaluate(rule, metrics):
    """Hard limits, then the declared weighted score as an exact Fraction in [0, 1]."""
    violations = [f"HARD:{row['metric']}:{row['op']}:{row['value']}" for row in rule['hard']
                  if not OPS[row['op']](metrics[row['metric']], row['value'])]
    total_weight = sum(row['weight'] for row in rule['score'])
    score, parts = Fraction(0), []
    for row in rule['score']:
        value = metrics[row['metric']]
        span = row['worst'] - row['best']
        raw = Fraction(row['worst'] - value, span)
        part = min(max(raw, Fraction(0)), Fraction(1))
        weighted = part * row['weight'] / total_weight
        score += weighted
        parts.append({'metric': row['metric'], 'value': value, 'best': row['best'], 'worst': row['worst'],
                      'weight': row['weight'], 'better': 'LOWER' if row['best'] < row['worst'] else 'HIGHER',
                      'points_ppm': weighted.numerator * 10**6 // weighted.denominator})
    return {'passed': not violations, 'violations': violations, 'score': score,
            'score_ppm': score.numerator * 10**6 // score.denominator, 'parts': parts}


def _tie_key(rule, row):
    key = [-row['score']]
    for item in rule['tie_break']:
        if item == 'OFFER_ID':
            key.append(row['offer'])
        elif item == 'EARLIEST_SUBMISSION':
            key.append(row['submitted_at'])
        else:
            _, metric, better = item.split(':')
            key.append(row['metrics'][metric] if better == 'LOWER' else -row['metrics'][metric])
    return tuple(key)


def rank(rule, rows):
    """Order only by the declared rule; nothing else (no fee, sponsor or identity) enters the key."""
    ordered = sorted(rows, key=lambda row: _tie_key(rule, row))
    for index, row in enumerate(ordered, 1):
        row['rank'] = index
    return ordered


# --- request (the demand post) -------------------------------------------------------

def _accreditation_policy(value):
    return type(value) is dict and value.get('version') in ('covenant-agent-accreditation-policy/0.2',
                                                            'covenant-agent-accreditation-policy/0.1')


def _eligibility(value):
    _exact(value, 'require issuers max_offers requirement', 'EXCHANGE_ELIGIBILITY_POLICY')
    # A signed qualification requirement. An agent_accreditation acceptance policy is checked by the
    # default hook; any other object is opaque data for an owner-installed hook (UNKNOWN without one).
    requirement = value['requirement']
    need(requirement is None or (type(requirement) is dict and 0 < len(requirement) <= 32
         and len(canonical(requirement)) <= 4096), 'EXCHANGE_ELIGIBILITY_POLICY')
    need(requirement is None or not value['require'], 'EXCHANGE_ELIGIBILITY_POLICY')
    if _accreditation_policy(requirement):
        from . import agent_accreditation
        try:
            agent_accreditation.policy_id(requirement)
        except ValueError:
            raise ExchangeError('EXCHANGE_ELIGIBILITY_POLICY') from None
    require = value['require']
    need(type(require) is list and require == sorted(set(require))
         and all(item in ('principal_kyb', 'verified_agent') for item in require), 'EXCHANGE_ELIGIBILITY_POLICY')
    pins = value['issuers']
    need(type(pins) is dict and len(pins) <= 8 and bool(pins) == bool(require), 'EXCHANGE_ELIGIBILITY_POLICY')
    for name, pin in pins.items():
        _text(name, 'EXCHANGE_ELIGIBILITY_POLICY', 256)
        _key(pin, 'EXCHANGE_ELIGIBILITY_POLICY')
    _int(value['max_offers'], 'EXCHANGE_ELIGIBILITY_POLICY', 1, MAX_SUBMISSIONS)


def _fees(value, unit):
    _exact(value, 'operator adviser', 'EXCHANGE_FEES')
    _exact(value['operator'], 'payer', 'EXCHANGE_FEES')
    need(value['operator']['payer'] in PAYERS, 'EXCHANGE_FEES')
    adviser = value['adviser']
    if adviser is not None:
        _exact(adviser, 'adviser payer bps flat unit conflicts', 'EXCHANGE_FEES')
        _key(adviser['adviser'], 'EXCHANGE_FEES')
        need(adviser['payer'] in ('REQUESTER', 'OFFEROR') and adviser['unit'] == unit, 'EXCHANGE_FEES')
        _int(adviser['bps'], 'EXCHANGE_FEES', 0, 1000)
        _int(adviser['flat'], 'EXCHANGE_FEES')
        conflicts = adviser['conflicts']
        need(type(conflicts) is list and 1 <= len(conflicts) <= 4, 'EXCHANGE_FEES')
        for item in conflicts:
            _text(item, 'EXCHANGE_FEES', 256)


@teaching
def validate_request(body, packs=()):
    _bounded(body)
    _exact(body, 'version kind vertical principal agent want eligibility disclosure_plan teaser window mode '
                 'award_rule conditions close_by dispute fees venues supersedes created_at nonce')
    need(body['version'] == PROFILE, 'EXCHANGE_PROFILE')
    need(body['kind'] == 'REQUEST', 'EXCHANGE_KIND')
    pack = resolve_vertical(body['vertical'], packs)
    _key(body['principal'])
    _key(body['agent'])
    validate_want(pack, body['want'])
    _eligibility(body['eligibility'])
    try:
        plan = dossier.validate_plan(body['disclosure_plan'])
    except ValueError:
        raise ExchangeError('EXCHANGE_PLAN') from None
    need(all(set(plan[stage]) <= set(pack['dossier_fields']) for stage in dossier.STAGES), 'EXCHANGE_PLAN')
    teaser = body['teaser']
    need(type(teaser) is dict and set(teaser) == set(plan['PUBLIC_TEASER']), 'EXCHANGE_TEASER')
    for value in teaser.values():
        need(len(canonical(value)) <= 1024, 'EXCHANGE_TEASER')
    window = body['window']
    _exact(window, 'opens closes reveal_by min_validity', 'EXCHANGE_WINDOW')
    for name in ('opens', 'closes', 'reveal_by'):
        _int(window[name], 'EXCHANGE_WINDOW')
    _int(window['min_validity'], 'EXCHANGE_WINDOW', 0, 366 * 86400)
    _int(body['created_at'])
    _int(body['close_by'], 'EXCHANGE_WINDOW')
    need(body['mode'] in MODES, 'EXCHANGE_MODE')
    need(body['created_at'] <= window['opens'] < window['closes'] <= window['reveal_by'] < body['close_by'], 'EXCHANGE_WINDOW')
    need(body['mode'] == 'SEALED' or window['reveal_by'] == window['closes'], 'EXCHANGE_WINDOW')
    validate_rule(pack, body['award_rule'])
    _conditions(body['conditions'])
    dispute_value = body['dispute']
    _exact(dispute_value, 'procedure resolver appeal', 'EXCHANGE_DISPUTE')
    _text(dispute_value['procedure'], 'EXCHANGE_DISPUTE', 128)
    for name in ('resolver', 'appeal'):
        need(dispute_value[name] is None or _key(dispute_value[name], 'EXCHANGE_DISPUTE'), 'EXCHANGE_DISPUTE')
    _fees(body['fees'], want_amount(pack, body['want'])['unit'])
    venues = body['venues']
    need(type(venues) is list and len(venues) <= 8 and venues == sorted(set(venues)), 'EXCHANGE_VENUES')
    for venue in venues:
        _hash(venue, 'EXCHANGE_VENUES')
    need(body['supersedes'] is None or _hash(body['supersedes']), 'EXCHANGE_FIELDS')
    _hash(body['nonce'])
    return pack


@teaching
def request(*, vertical, principal, agent, want, eligibility, disclosure_plan, teaser, window, mode, award_rule,
            conditions, close_by, dispute, fees, created_at, nonce, venues=(), supersedes=None, packs=()):
    """The exact unsigned demand post. The agent signs it; a permission chain links the agent to the principal."""
    ref = vertical if type(vertical) is dict else vertical_ref(vertical, packs)
    body = {'version': PROFILE, 'kind': 'REQUEST', 'vertical': deepcopy(ref), 'principal': principal, 'agent': agent,
            'want': deepcopy(want), 'eligibility': deepcopy(eligibility), 'disclosure_plan': deepcopy(disclosure_plan),
            'teaser': deepcopy(teaser), 'window': deepcopy(window), 'mode': mode, 'award_rule': deepcopy(award_rule),
            'conditions': deepcopy(conditions), 'close_by': close_by, 'dispute': deepcopy(dispute), 'fees': deepcopy(fees),
            'venues': sorted(venues), 'supersedes': supersedes, 'created_at': created_at, 'nonce': nonce}
    validate_request(body, packs)
    return {'label': LABELS['REQUEST'], 'body': body, 'id': record_id('REQUEST', body),
            'rule': rule_id(award_rule), 'required_signer': agent, **FLAGS}


@teaching
def verify_request(envelope, *, packs=(), revocation_history=None, expected=None):
    """Signature by the agent, plus the principal's mandate chain when the agent is not the principal."""
    body, ref = _signed('REQUEST', envelope, 'agent', 'body signature permission')
    pack = validate_request(body, packs)
    if expected is not None:
        need(ref == expected, 'EXCHANGE_REQUEST_CHANGED')
    records = envelope['permission']
    need(type(records) is list and len(records) <= 16, 'EXCHANGE_PERMISSION')
    authority = {'principal': body['principal'], 'agent': body['agent'], 'mandate': None,
                 'revocation': 'NOT_APPLICABLE_PRINCIPAL_SIGNED'}
    if body['agent'] != body['principal']:
        need(bool(records), 'EXCHANGE_PERMISSION')
        from .portable_trust import check_capability
        money = want_amount(pack, body['want'])
        try:
            checked = check_capability(records, body['principal'], body['agent'], 'EXCHANGE_REQUEST',
                                       'exchange:' + pack['id'], PROFILE, {money['unit']: money['amount']},
                                       body['created_at'], revocation_history=revocation_history)
        except ValueError:
            raise ExchangeError('EXCHANGE_PERMISSION') from None
        need(not checked['revoked'], 'EXCHANGE_PERMISSION')
        authority.update(mandate=checked['capability'], revocation=checked['revocation'])
    else:
        need(not records, 'EXCHANGE_PERMISSION')
    return {'body': body, 'id': ref, 'vertical': pack, 'rule': rule_id(body['award_rule']), 'authority': authority}


# --- offers, seals, withdrawals and declines ---------------------------------------

def _deposit(value, unit):
    if value is None:
        return
    _exact(value, 'amount unit payer', 'EXCHANGE_DEPOSIT')
    _int(value['amount'], 'EXCHANGE_DEPOSIT', 1)
    need(value['unit'] == unit and value['payer'] in ('REQUESTER', 'OFFEROR'), 'EXCHANGE_DEPOSIT')


@teaching
def validate_offer(body, request_body, request_ref, packs=()):
    _bounded(body, MAX_RECORD_BYTES + MAX_PRESENTATION)
    _exact(body, 'version kind request offeror terms valid_until conditions eligibility deposit created_at nonce')
    need(body['version'] == PROFILE, 'EXCHANGE_PROFILE')
    need(body['kind'] == 'OFFER', 'EXCHANGE_KIND')
    _hash(body['request'])
    need(body['request'] == request_ref, 'EXCHANGE_REQUEST_MISMATCH')
    pack = resolve_vertical(request_body['vertical'], packs)
    _key(body['offeror'])
    need(body['offeror'] not in (request_body['principal'], request_body['agent']), 'EXCHANGE_SELF_OFFER')
    validate_terms(pack, body['terms'])
    _int(body['valid_until'])
    _int(body['created_at'])
    window = request_body['window']
    need(body['valid_until'] >= window['closes'] + window['min_validity'], 'EXCHANGE_OFFER_VALIDITY')
    _conditions(body['conditions'], 8)
    need(not {row['id'] for row in body['conditions']} & {row['id'] for row in request_body['conditions']},
         'EXCHANGE_CONDITIONS')
    presented = body['eligibility']
    need(presented is None or (type(presented) is str and 0 < len(presented) <= MAX_PRESENTATION and presented.isascii())
         or (type(presented) is dict and 0 < len(canonical(presented)) <= MAX_PRESENTATION), 'EXCHANGE_INELIGIBLE')
    _deposit(body['deposit'], amount_of(pack, body['terms'])['unit'])
    _hash(body['nonce'])
    return pack


@teaching
def offer(request_record, *, offeror, terms, valid_until, created_at, nonce, conditions=(), eligibility=None,
          deposit=None, packs=()):
    """The exact unsigned firm offer, bound to the request digest. The offeror signs it."""
    request_body = request_record['body']
    ref = record_id('REQUEST', request_body)
    body = {'version': PROFILE, 'kind': 'OFFER', 'request': ref, 'offeror': offeror, 'terms': deepcopy(terms),
            'valid_until': valid_until, 'conditions': deepcopy(list(conditions)), 'eligibility': eligibility,
            'deposit': deepcopy(deposit), 'created_at': created_at, 'nonce': nonce}
    validate_offer(body, request_body, ref, packs)
    return {'label': LABELS['OFFER'], 'body': body, 'id': record_id('OFFER', body), 'required_signer': offeror, **FLAGS}


@teaching
def verify_offer(envelope, request_body, request_ref, packs=()):
    body, ref = _signed('OFFER', envelope, 'offeror')
    validate_offer(body, request_body, request_ref, packs)
    return body, ref


@teaching
def commitment(request_ref, offer_ref, salt):
    _hash(request_ref)
    _hash(offer_ref)
    _hash(salt, 'EXCHANGE_SALT')
    return digest(COMMITMENT_LABEL, {'request': request_ref, 'offer': offer_ref, 'salt': salt})


@teaching
def seal(request_ref, offeror, sealed, created_at):
    """A signed commitment to a full signed offer; reveals nothing about its terms."""
    body = {'version': PROFILE, 'kind': 'SEAL', 'request': request_ref, 'offeror': offeror, 'commitment': sealed,
            'created_at': created_at}
    _seal_body(body)
    return {'label': LABELS['SEAL'], 'body': body, 'id': record_id('SEAL', body), 'required_signer': offeror, **FLAGS}


def _seal_body(body):
    _exact(body, 'version kind request offeror commitment created_at')
    _hash(body['request'])
    _key(body['offeror'])
    _hash(body['commitment'])
    _int(body['created_at'])


@teaching
def verify_seal(envelope, request_ref):
    body, ref = _signed('SEAL', envelope, 'offeror')
    _seal_body(body)
    need(body['request'] == request_ref, 'EXCHANGE_REQUEST_MISMATCH')
    return body, ref


@teaching
def open_seal(seal_body, offer_envelope, salt, request_body, request_ref, packs=()):
    body, ref = verify_offer(offer_envelope, request_body, request_ref, packs)
    need(body['offeror'] == seal_body['offeror'], 'EXCHANGE_SEAL_MISMATCH')
    need(commitment(request_ref, ref, salt) == seal_body['commitment'], 'EXCHANGE_SEAL_MISMATCH')
    return body, ref


@teaching
def withdrawal(request_ref, offeror, target, reason, created_at):
    body = {'version': PROFILE, 'kind': 'WITHDRAW', 'request': request_ref, 'offeror': offeror, 'target': target,
            'reason': reason, 'created_at': created_at}
    _withdraw_body(body)
    return {'label': LABELS['WITHDRAW'], 'body': body, 'id': record_id('WITHDRAW', body), 'required_signer': offeror, **FLAGS}


def _withdraw_body(body):
    _exact(body, 'version kind request offeror target reason created_at', 'EXCHANGE_WITHDRAWAL')
    _hash(body['request'])
    _key(body['offeror'])
    _hash(body['target'], 'EXCHANGE_WITHDRAWAL')
    need(body['reason'] in WITHDRAW_REASONS, 'EXCHANGE_WITHDRAWAL')
    _int(body['created_at'])


@teaching
def verify_withdrawal(envelope, request_ref):
    body, ref = _signed('WITHDRAW', envelope, 'offeror')
    _withdraw_body(body)
    need(body['request'] == request_ref, 'EXCHANGE_REQUEST_MISMATCH')
    return body, ref


@teaching
def decline(request_ref, offeror, reasons, created_at, detail_sha256=None, *, pack=None):
    body = {'version': PROFILE, 'kind': 'DECLINE', 'request': request_ref, 'offeror': offeror, 'reasons': list(reasons),
            'detail_sha256': detail_sha256, 'created_at': created_at}
    _decline_body(body, pack)
    return {'label': LABELS['DECLINE'], 'body': body, 'id': record_id('DECLINE', body), 'required_signer': offeror, **FLAGS}


def _decline_body(body, pack=None):
    _exact(body, 'version kind request offeror reasons detail_sha256 created_at', 'EXCHANGE_DECLINE')
    _hash(body['request'])
    _key(body['offeror'])
    reasons = body['reasons']
    need(type(reasons) is list and 1 <= len(reasons) <= 4 and len(set(reasons)) == len(reasons)
         and all(type(r) is str and CODE.fullmatch(r) for r in reasons), 'EXCHANGE_DECLINE')
    need(not set(reasons) & set(VAGUE_REASONS), 'EXCHANGE_DECLINE_REASON_NOT_SPECIFIC')
    if pack is not None:
        need(set(reasons) <= set(pack['decline_reasons']), 'EXCHANGE_DECLINE')
    need(body['detail_sha256'] is None or _hash(body['detail_sha256'], 'EXCHANGE_DECLINE'), 'EXCHANGE_DECLINE')
    need('OTHER_SPECIFIC' not in reasons or body['detail_sha256'] is not None, 'EXCHANGE_DECLINE_REASON_NOT_SPECIFIC')
    _int(body['created_at'])


@teaching
def verify_decline(envelope, request_body, request_ref, packs=()):
    body, ref = _signed('DECLINE', envelope, 'offeror')
    _decline_body(body, resolve_vertical(request_body['vertical'], packs))
    need(body['request'] == request_ref, 'EXCHANGE_REQUEST_MISMATCH')
    return body, ref


# --- eligibility: a plain callable hook, defaulting to pinned SD-JWT credentials ----------
#
# Contract: hook(request_body, request_ref, offer_body, at) -> {status, reasons, issuer,
# checked_at, freshness, nullifier}. status is ELIGIBLE, NOT_REQUIRED, INELIGIBLE or UNKNOWN.
# freshness is {kind, snapshot, as_of, expires_at}: the status snapshot the check relied on,
# so an accreditation or status-list backend can report how current its answer is.
# Anything else, or an exception, is UNKNOWN; UNKNOWN is never eligible.

def eligibility_nonce(request_ref, offeror):
    return digest(ELIGIBILITY_LABEL, {'request': request_ref, 'offeror': offeror})


def eligibility_audience(request_ref):
    return 'urn:aap:exchange:' + request_ref


def eligibility_result(status, *, reasons=(), issuer=None, checked_at, freshness=None, nullifier=None):
    """The hook result shape; owner hooks may build it with this helper."""
    return {'status': status, 'reasons': list(reasons), 'issuer': issuer, 'checked_at': checked_at,
            'freshness': deepcopy(freshness) if freshness is not None else
            {'kind': 'NOT_REPORTED', 'snapshot': None, 'as_of': None, 'expires_at': None},
            'nullifier': nullifier}


def default_eligibility(request_body, request_ref, offer_body, at):
    """hidden_credentials.verify_presentation with the request's pinned issuers and required claims."""
    rule = request_body['eligibility']
    if _accreditation_policy(rule['requirement']):
        return _accredited(rule['requirement'], request_ref, offer_body, at)
    if rule['requirement'] is not None:
        return eligibility_result('UNKNOWN', reasons=['REQUIREMENT_NEEDS_OWNER_HOOK'], checked_at=at)
    if not rule['require']:
        return eligibility_result('NOT_REQUIRED', checked_at=at)
    presented = offer_body['eligibility']
    if presented is None:
        return eligibility_result('INELIGIBLE', reasons=['CREDENTIAL_MISSING'], checked_at=at)
    if type(presented) is not str:
        return eligibility_result('INELIGIBLE', reasons=['FORMAT_NEEDS_OWNER_HOOK'], checked_at=at)
    from . import hidden_credentials
    try:
        policy = hidden_credentials.make_policy(issuers=rule['issuers'], require=rule['require'],
                                                audience=eligibility_audience(request_ref))
        checked = hidden_credentials.verify_presentation(presented, policy,
                                                         nonce=eligibility_nonce(request_ref, offer_body['offeror']), now=at)
    except ValueError as exc:
        return eligibility_result('INELIGIBLE', reasons=[str(exc)[:80]], checked_at=at)
    return eligibility_result('ELIGIBLE', issuer=checked['issuer'], checked_at=at, nullifier=checked['nullifier'],
                              freshness={'kind': 'EXPIRY_ONLY_NO_STATUS_LIST', 'snapshot': None, 'as_of': None,
                                         'expires_at': None})


def _accredited(policy, request_ref, offer_body, at, store=None):
    """agent_accreditation: pinned issuer, signed status snapshot, challenge bound to this request and offeror.

    With the owner's durable VerifierStore (qualified_eligibility, the book's default) the challenge is
    consumed and newer status retained (verify_presentation: replay and rollback protection); without one
    the check is read-only (inspect_presentation) and the book's journal still allows one credential per
    request.
    """
    presented = offer_body['eligibility']
    if type(presented) is not dict:
        return eligibility_result('INELIGIBLE', reasons=['ACCREDITATION_PACKET_MISSING'], checked_at=at)
    from . import agent_accreditation
    nonce = eligibility_nonce(request_ref, offer_body['offeror'])
    try:
        if store is None:
            result = agent_accreditation.inspect_presentation(presented, policy, nonce=nonce, now=at, offline=True)
        else:
            result = agent_accreditation.verify_presentation(presented, policy, nonce=nonce, now=at, store=store,
                                                             offline=True)
    except (ValueError, KeyError, TypeError) as exc:
        return eligibility_result('INELIGIBLE', reasons=[str(exc)[:80] if isinstance(exc, ValueError) else 'ACCREDITATION_PACKET'],
                                  checked_at=at)
    if result['holder_key'] != offer_body['offeror']:
        return eligibility_result('INELIGIBLE', reasons=['HOLDER_NOT_OFFEROR'], checked_at=at)
    return eligibility_result('ELIGIBLE', issuer=result['issuer'], checked_at=at, nullifier=result['credential'],
                              freshness={'kind': 'ACCREDITATION_STATUS_SNAPSHOT', 'snapshot': result['status_snapshot'],
                                         'as_of': result['status_as_of'], 'expires_at': result['status_expires_at']})


def _hooked(hook, request_body, request_ref, offer_body, at):
    unknown = eligibility_result('UNKNOWN', reasons=['HOOK_RESULT_INVALID'], checked_at=at)
    try:
        result = (hook or default_eligibility)(request_body, request_ref, offer_body, at)
    except Exception:  # an owner hook that fails is UNKNOWN, never eligible
        return eligibility_result('UNKNOWN', reasons=['HOOK_FAILED'], checked_at=at)
    if (type(result) is not dict or result.get('status') not in ('ELIGIBLE', 'NOT_REQUIRED', 'INELIGIBLE', 'UNKNOWN')
            or set(result) != {'status', 'reasons', 'issuer', 'checked_at', 'freshness', 'nullifier'}):
        return unknown
    nullifier, reasons = result['nullifier'], result['reasons']
    if nullifier is not None and (type(nullifier) is not str or HASH.fullmatch(nullifier) is None):
        return unknown
    if (type(reasons) is not list or len(reasons) > 8 or not all(type(r) is str and 0 < len(r) <= 80 for r in reasons)
            or type(result['checked_at']) is not int or type(result['freshness']) is not dict):
        return unknown
    if result['issuer'] is not None and (type(result['issuer']) is not str or len(result['issuer']) > 256):
        return unknown
    reasons = [r for r in reasons if r.isascii() and r.isprintable()]
    if result['status'] in ('INELIGIBLE', 'UNKNOWN') and not reasons:
        reasons = ['UNSPECIFIED']
    return {'status': result['status'], 'reasons': reasons, 'issuer': result['issuer'],
            'checked_at': result['checked_at'], 'freshness': deepcopy(result['freshness']), 'nullifier': nullifier}


# --- comparison --------------------------------------------------------------------

def _fees_view(request_body, pack, terms):
    fees = request_body['fees']
    view = {'operator_payer': fees['operator']['payer'], 'adviser': None}
    adviser = fees['adviser']
    if adviser is not None:
        money = amount_of(pack, terms)
        view['adviser'] = {'adviser': adviser['adviser'], 'payer': adviser['payer'], 'unit': adviser['unit'],
                           'amount': money['amount'] * adviser['bps'] // 10000 + adviser['flat'],
                           'basis': '%d bps of the offer amount plus %d flat' % (adviser['bps'], adviser['flat']),
                           'conflicts': list(adviser['conflicts'])}
    return view


@teaching
def compare(request_envelope, submissions, *, at, expected_request=None, packs=(), eligibility=None,
            withdrawals=(), detail='SUMMARY', revocation_history=None):
    """Verify, normalise and rank firm offers under the request's own signed rule.

    ``submissions`` rows are {offer, submitted_at}; submitted_at is the book's
    statement of when the seal (SEALED) or offer (OPEN) arrived. A foreign or
    malformed offer is refused; expired, late, withdrawn, ineligible, conflicting
    or non-binding offers are listed as excluded with their reasons.
    """
    need(detail in ('SUMMARY', 'FULL'), 'EXCHANGE_DETAIL')
    checked = verify_request(request_envelope, packs=packs, revocation_history=revocation_history,
                             expected=expected_request)
    body, ref, pack = checked['body'], checked['id'], checked['vertical']
    _int(at)
    window = body['window']
    sealed = body['mode'] == 'SEALED'
    need(not sealed or at >= window['closes'], 'EXCHANGE_SEALED_UNTIL_CLOSE')
    need(type(submissions) is list and len(submissions) <= MAX_SUBMISSIONS, 'EXCHANGE_SUBMISSIONS')
    need(type(withdrawals) in (list, tuple) and len(withdrawals) <= MAX_SUBMISSIONS, 'EXCHANGE_SUBMISSIONS')
    withdrawn = {}
    for envelope in withdrawals:
        item, _ = verify_withdrawal(envelope, ref)
        if item['created_at'] <= at:
            withdrawn.setdefault(item['offeror'], set()).add(item['target'])
    seen, by_offeror = {}, {}
    for row in submissions:
        _exact(row, 'offer submitted_at', 'EXCHANGE_SUBMISSIONS')
        _int(row['submitted_at'], 'EXCHANGE_SUBMISSIONS')
        offer_body, offer_ref = verify_offer(row['offer'], body, ref, packs)
        if offer_ref in seen:
            continue
        seen[offer_ref] = (offer_body, row['submitted_at'])
        by_offeror.setdefault(offer_body['offeror'], []).append(offer_ref)
    candidates, excluded, nullifiers = [], [], {}
    for offer_ref, (offer_body, submitted_at) in sorted(seen.items(), key=lambda item: (item[1][1], item[0])):
        reasons = []
        if len(by_offeror[offer_body['offeror']]) > 1:
            reasons.append('CONFLICTING_OFFERS')
        if offer_ref in withdrawn.get(offer_body['offeror'], ()):
            reasons.append('WITHDRAWN')
        if not window['opens'] <= submitted_at < window['closes']:
            reasons.append('LATE')
        if offer_body['valid_until'] < at:
            reasons.append('EXPIRED')
        gate = _hooked(eligibility, body, ref, offer_body, submitted_at)
        if gate['status'] == 'INELIGIBLE':
            reasons.append('INELIGIBLE:' + gate['reasons'][0])
        elif gate['status'] == 'UNKNOWN':
            reasons.append('ELIGIBILITY_UNKNOWN:' + gate['reasons'][0])
        elif gate['nullifier'] is not None:
            if gate['nullifier'] in nullifiers:
                reasons.append('SHARED_CREDENTIAL')
            nullifiers.setdefault(gate['nullifier'], offer_ref)
        made = normalise(pack, body['want'], offer_body['terms'], detail)
        reasons += ['BINDING:' + reason for reason in made['binding']]
        verdict = evaluate(body['award_rule'], made['metrics'])
        reasons += verdict['violations']
        row = {'offer': offer_ref, 'offeror': offer_body['offeror'], 'submitted_at': submitted_at,
               'valid_until': offer_body['valid_until'], 'metrics': made['metrics'], 'score': verdict['score'],
               'score_ppm': verdict['score_ppm'], 'explanation': verdict['parts'],
               'eligibility': {k: gate[k] for k in ('status', 'issuer', 'checked_at', 'freshness')},
               'fees': _fees_view(body, pack, offer_body['terms'])}
        if detail == 'FULL':
            row['computation'] = made['computation']
            if 'schedule' in made:
                row['schedule'] = made['schedule']
        if reasons:
            excluded.append({'offer': offer_ref, 'offeror': offer_body['offeror'], 'reasons': sorted(set(reasons))})
        else:
            candidates.append(row)
    ranked = rank(body['award_rule'], candidates)
    for index, row in enumerate(ranked):
        following = ranked[index + 1] if index + 1 < len(ranked) else None
        if following is None:
            row['versus_next'] = None
        else:
            gains = {part['metric']: part['points_ppm'] for part in row['explanation']}
            for part in following['explanation']:
                gains[part['metric']] -= part['points_ppm']
            lead = max(sorted(gains), key=lambda name: gains[name])
            row['versus_next'] = {'offer': following['offer'], 'score_ppm_gap': row['score_ppm'] - following['score_ppm'],
                                  'largest_gain': lead, 'tied_on_score': row['score'] == following['score']}
        row['score'] = {'numerator': row['score'].numerator, 'denominator': row['score'].denominator}
    core = {'request': ref, 'rule': checked['rule'], 'at': at,
            'ranked': [[row['offer'], row['rank'], row['score']['numerator'], row['score']['denominator']] for row in ranked],
            'excluded': [[row['offer'], row['reasons']] for row in sorted(excluded, key=lambda r: r['offer'])]}
    return {'version': PROFILE, 'id': digest(COMPARISON_LABEL, core), 'request': ref, 'rule': checked['rule'],
            'vertical': pack['id'], 'at': at, 'final': at >= window['closes'], 'mode': body['mode'],
            'ranked': ranked, 'excluded': sorted(excluded, key=lambda r: r['offer']),
            'shortlist': [row['offer'] for row in ranked[:body['award_rule']['shortlist']]],
            'authority': checked['authority'], 'core': core,
            'ordering': 'DECLARED_RULE_ONLY; NO_FEE_SPONSOR_OR_IDENTITY_INPUT',
            'submission_times': 'BOOK_STATEMENTS_NOT_ATTESTED_UNLESS_RELAY_RECEIPTS_ARE_SUPPLIED',
            'unverified': ['offeror capacity to fund or perform', 'truth of self-declared terms beyond signatures',
                           'current authority beyond the supplied mandate and revocation inputs'], **FLAGS}


def comparison_core(comparison):
    """Recompute a comparison id from its core; awards bind to this id."""
    core = comparison['core']
    need(type(core) is dict and digest(COMPARISON_LABEL, core) == comparison['id'], 'EXCHANGE_COMPARISON')
    return core


def describe():
    return {'version': PROFILE, 'model': 'A deal is a promise both sides sign. Proof shows it was kept. '
                                         'If it wasn\'t, there is a fair way to fix it.',
            'golden_path': ['propose', 'accept', 'settle'], 'jobs': deepcopy(JOBS),
            'records': {kind: label for kind, label in LABELS.items()}, 'modes': list(MODES),
            'verticals': sorted(_shipped()['verticals']),
            'next_verticals': [row['id'] for row in _shipped()['next_verticals']],
            'promises': {'real_offers': 'firm, signed, bound to the request digest, expiring, typed conditions; withdrawals recorded',
                         'best_terms': 'exact normalised metrics ranked only by the rule signed before offers opened',
                         'certainty_of_close': 'conditions checklist with evidence slots and deadlines; close records from signed receipts'},
            'refusal_reference': REFERENCE, 'refusal_codes': len(REFUSALS), **FLAGS}
