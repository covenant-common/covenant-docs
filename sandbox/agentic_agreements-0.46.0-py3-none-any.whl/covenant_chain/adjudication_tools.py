"""Keyless agent tool for outside adjudicators, ERC-8183 jobs, ERC-7710 delegations and AAA filing aids.

Every action drafts, checks, maps or renders. None signs, submits, bonds, pays, redeems a delegation,
releases escrow, fetches a chain or files a case: published outcomes and chain events arrive as bytes the
owner supplies, and they stay evidence for the AAP ladder the parties signed.
"""
import base64
import binascii
from copy import deepcopy

from .cooperation_interface import HASH, INT, schema
from .crypto import FieldError

NAME = 'covenant_adjudication'
OBJECT = {'type': 'object', 'maxProperties': 64}
OBJECTS = {'type': 'array', 'maxItems': 256, 'items': OBJECT}
ADDRESS = {'type': 'string', 'pattern': '^0x[0-9a-fA-F]{40}$'}
NETWORK = {'type': 'string', 'pattern': '^eip155:[1-9][0-9]{0,18}$'}
WORD = {'type': 'string', 'pattern': '^0x[0-9a-fA-F]{64}$'}
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 512}
BIG = {'type': 'integer', 'minimum': 0, 'maximum': 2**53 - 1}
ROLE = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
BYTES = {'type': 'string', 'maxLength': 22_369_624, 'description': 'Standard base64 of the exact bytes as received.'}
LADDER = schema({'kind': {'enum': ['PROCEDURE', 'PANEL']}, 'id': HASH, 'stage': {'type': 'string', 'minLength': 1, 'maxLength': 64}},
                ('kind', 'id', 'stage'))
SIGNATURES = {'type': 'array', 'maxItems': 3, 'items': OBJECT,
              'description': 'Role signatures over the exact terms or binding, made by each party outside this tool.'}
EVIDENCE = {'type': 'array', 'minItems': 1, 'maxItems': 64, 'items': OBJECT,
            'description': 'Owner-supplied chain evidence: {kind: RECEIPT_PROOF | BLOCK_RECEIPTS | LOGS | TRANSACTION_PROOF | '
                           'BLOCK_TRANSACTIONS, network, ...} or one {kind: GENLAYER_RPC, receipt, details, verdict}. Never fetched.'}
PINS = {'type': 'array', 'maxItems': 1024, 'items': WORD,
        'description': 'Block hashes the owner pinned from its own node or an adopted witness; nothing else proves inclusion.'}
ACTIONS = ('terms_draft', 'request', 'outcome', 'ladder_step', 'panel_step', 'erc8183_binding', 'erc8183_calls', 'erc8183_job',
           'erc8183_evaluation', 'erc8183_record', 'erc8183_ladder_step', 'erc8183_release', 'erc8183_conformance',
           'erc7710_map', 'erc7710_execution', 'aaa_packet', 'aaa_verify')


def spec():
    ladder_args = {'policy': OBJECT, 'adoptions': OBJECTS, 'events': OBJECTS}
    binding_args = {'binding': OBJECT, 'signatures': SIGNATURES, 'order': OBJECT, 'policy': OBJECT}
    return ('covenant_adjudication',
        'Name an outside adjudicator (Internet Court on GenLayer, the Kleros court, UMA\'s optimistic oracle) as one stage of an AAP '
        'dispute ladder before any dispute; build the exact request it needs; read its published decision from owner-supplied chain '
        'bytes as evidence for that stage only. Bind a work order to an ERC-8183 job with an AAP appeal before release; map an '
        'ERC-7710 delegation onto a narrower AAP mandate; export an AAA filing aid from a ladder at its final stage. Nothing here '
        'signs, submits, pays, redeems, releases escrow, fetches or files.', True, [
        ('terms_draft', {'ladder': LADDER, 'parties': OBJECT, 'adjudicator': OBJECT, 'case': OBJECT,
                         'options': {'type': 'array', 'minItems': 2, 'maxItems': 16, 'items': OBJECT},
                         'required_assurance': {'enum': ['INCLUDED_UNDER_PINNED_BLOCK', 'OWNER_SUPPLIED_UNPROVEN', 'GENLAYER_RPC_UNPROVEN']}},
         ('ladder', 'parties', 'adjudicator', 'case', 'options')),
        ('request', {'terms': OBJECT, 'signatures': SIGNATURES, 'policy': OBJECT, 'chain_terms': OBJECT}, ('terms', 'signatures')),
        ('outcome', {'terms': OBJECT, 'signatures': SIGNATURES, 'evidence': EVIDENCE, 'trusted_blocks': PINS,
                     'policy': OBJECT, 'chain_terms': OBJECT}, ('terms', 'signatures', 'evidence')),
        ('ladder_step', {'terms': OBJECT, 'signatures': SIGNATURES, 'record': OBJECT, 'expected_record': HASH, **ladder_args,
                         'actor': ROLE, 'at': INT, 'bond_receipt': HASH},
         ('terms', 'signatures', 'record', 'expected_record', 'policy', 'adoptions', 'events', 'actor', 'at')),
        ('panel_step', {'terms': OBJECT, 'signatures': SIGNATURES, 'record': OBJECT, 'expected_record': HASH, 'chain_terms': OBJECT,
                        'chain': HASH}, ('terms', 'signatures', 'record', 'expected_record', 'chain_terms', 'chain')),
        ('erc8183_binding', {'order': OBJECT, 'order_id': HASH, 'abi': {'enum': ['erc-8183/reference@a078cab5', 'erc-8183/base-contracts@142e669c']},
                             'contract': ADDRESS, 'client': ADDRESS, 'evaluator': ADDRESS, 'expired_at': BIG, 'hook': ADDRESS,
                             'evaluator_key': HASH, 'appeal': OBJECT, 'provider_agent_id': BIG,
                             'required_assurance': {'enum': ['INCLUDED_UNDER_PINNED_BLOCK', 'OWNER_SUPPLIED_UNPROVEN']}},
         ('order', 'order_id', 'abi', 'contract', 'client', 'evaluator', 'expired_at')),
        ('erc8183_calls', {**binding_args, 'job_id': {**BIG, 'minimum': 1}, 'deliverable': WORD}, ('binding', 'signatures', 'order')),
        ('erc8183_job', {**binding_args, 'evidence': EVIDENCE, 'trusted_blocks': PINS, 'job_id': {**BIG, 'minimum': 1}},
         ('binding', 'signatures', 'order', 'evidence')),
        ('erc8183_evaluation', {**binding_args, 'job_id': {**BIG, 'minimum': 1}, 'decision': {'enum': ['COMPLETE', 'REJECT']},
                                'deliverable': WORD, 'reason': WORD},
         ('binding', 'signatures', 'order', 'job_id', 'decision', 'deliverable', 'reason')),
        ('erc8183_record', {**binding_args, 'evaluation': OBJECT}, ('binding', 'signatures', 'order', 'evaluation', 'policy')),
        ('erc8183_ladder_step', {**binding_args, 'record': OBJECT, 'expected_record': HASH, 'adoptions': OBJECTS, 'events': OBJECTS,
                                 'actor': ROLE, 'at': INT, 'bond_receipt': HASH},
         ('binding', 'signatures', 'order', 'record', 'expected_record', 'policy', 'adoptions', 'events', 'actor', 'at')),
        ('erc8183_release', {**binding_args, 'adoptions': OBJECTS, 'events': OBJECTS, 'job_id': {**BIG, 'minimum': 1},
                             'expected_head': HASH}, ('binding', 'signatures', 'order', 'policy', 'adoptions', 'events', 'job_id')),
        ('erc8183_conformance', {**binding_args, 'evidence': EVIDENCE, 'adoptions': OBJECTS, 'events': OBJECTS,
                                 'trusted_blocks': PINS, 'job_id': {**BIG, 'minimum': 1}, 'expected_head': HASH},
         ('binding', 'signatures', 'order', 'evidence', 'policy', 'adoptions', 'events')),
        ('erc7710_map', {'context': {'anyOf': [{'type': 'string', 'maxLength': 2_097_154}, {'type': 'array', 'maxItems': 16, 'items': OBJECT}]},
                         'network': NETWORK, 'manager': ADDRESS,
                         'enforcers': {'type': 'object', 'maxProperties': 256, 'description': 'Your pinned table {address: enforcer kind}.'},
                         'principals': {'type': 'object', 'maxProperties': 64, 'description': '{address: AAP verification key} for the root delegator and leaf delegate.'},
                         'nonce': HASH, 'scope': OBJECT, 'parent': OBJECT, 'expected_parent_id': HASH, 'may_delegate': {'type': 'boolean'},
                         'require_signatures': {'type': 'boolean'}},
         ('context', 'network', 'manager', 'enforcers', 'principals', 'nonce')),
        ('erc7710_execution', {'execution': {'type': 'string', 'maxLength': 2_097_154}, 'network': NETWORK, 'mode': WORD},
         ('execution', 'network')),
        ('aaa_packet', {**ladder_args, 'claimant': ROLE, 'agreement': OBJECT, 'legal_context_base64': BYTES, 'terms_base64': BYTES,
                        'clause': {'type': 'string', 'minLength': 1, 'maxLength': 8000}, 'particulars': OBJECT, 'award': OBJECT,
                        'evidence_files': {'type': 'array', 'maxItems': 64, 'items': OBJECT}, 'expected_head': HASH},
         ('policy', 'adoptions', 'events', 'claimant', 'agreement', 'legal_context_base64', 'terms_base64', 'clause', 'particulars')),
        ('aaa_verify', {'archive_base64': BYTES, 'expected_id': HASH}, ('archive_base64', 'expected_id'))])


def describe():
    from . import aaa_filing, erc7710_delegations, erc8183_jobs, external_adjudication, evm_evidence
    return {'tool': NAME, 'guide': 'docs/ADJUDICATION_GRAFTS.html', 'actions': list(ACTIONS),
            'adjudication': {name: value for name, value in external_adjudication.describe().items() if name != 'remediation'},
            'erc8183': {name: value for name, value in erc8183_jobs.describe().items() if name != 'remediation'},
            'erc7710': {name: value for name, value in erc7710_delegations.describe().items() if name != 'remediation'},
            'aaa': {name: value for name, value in aaa_filing.describe().items() if name != 'remediation'},
            'evidence': {name: value for name, value in evm_evidence.describe().items() if name != 'remediation'},
            'never': ['sign', 'submit or broadcast', 'bond, pay or release escrow', 'redeem a delegation', 'fetch a chain or service',
                      'file, serve or pay a fee with the AAA'],
            'execution_authorized': False, 'network_accessed': False}


def remediation(code):
    from . import aaa_filing, erc7710_delegations, erc8183_jobs, external_adjudication
    for table in (aaa_filing.REMEDIATION, erc7710_delegations.REMEDIATION, erc8183_jobs.REMEDIATION):
        if code in table:
            return table[code]
    hint = external_adjudication.remediation(code)
    return None if hint.startswith('Correct the input;') else hint


def _bytes(text, code):
    try:
        return base64.b64decode(text, validate=True)
    except (binascii.Error, ValueError):
        raise FieldError(code, '/parameters', 'standard base64', 'Pass the exact bytes as standard base64.') from None


def _packet_reply(out):
    return {'packet': out['packet'], 'id': out['id'], 'files': sorted(out['files']), 'archive_base64': base64.b64encode(out['archive']).decode('ascii'),
            'archive_sha256': out['archive_sha256'], **{name: out[name] for name in ('status', 'filed', 'fee_paid', 'served', 'aaa_contacted',
                                                                                       'legal_advice', 'network_accessed', 'execution_authorized')}}


def call(action, p):
    """Refusals keep their stable code and carry the module's remediation as the next action."""
    try:
        return _call(action, deepcopy(p))
    except FieldError:
        raise
    except ValueError as exc:
        code = str(exc).partition(':')[0]
        hint = remediation(code)
        if hint is None:
            raise
        raise FieldError(code, '/parameters', 'See next_action.', hint) from None


def _call(action, p):
    from . import aaa_filing, erc7710_delegations, erc8183_jobs, external_adjudication as adj
    if action == 'terms_draft':
        return adj.terms_draft(ladder=p['ladder'], parties=p['parties'], adjudicator=p['adjudicator'], case=p['case'],
                               options=p['options'], required_assurance=p.get('required_assurance'))
    if action == 'request':
        return adj.request(p['terms'], p['signatures'], policy=p.get('policy'), chain_terms=p.get('chain_terms'))
    if action == 'outcome':
        return adj.outcome(p['terms'], p['signatures'], p['evidence'], policy=p.get('policy'), chain_terms=p.get('chain_terms'),
                           trusted_blocks=p.get('trusted_blocks', []))
    if action == 'ladder_step':
        return adj.ladder_step(p['terms'], p['signatures'], p['record'], p['expected_record'], p['policy'], p['adoptions'], p['events'],
                               actor=p['actor'], at=p['at'], bond_receipt=p.get('bond_receipt'))
    if action == 'panel_step':
        return adj.panel_step(p['terms'], p['signatures'], p['record'], p['expected_record'], p['chain_terms'], chain=p['chain'])
    if action.startswith('erc8183_'):
        triple = (p['binding'], p['signatures'], p['order']) if action != 'erc8183_binding' else None
        if action == 'erc8183_binding':
            return erc8183_jobs.binding_draft(p['order'], p['order_id'], abi=p['abi'], contract=p['contract'], client=p['client'],
                                              evaluator=p['evaluator'], expired_at=p['expired_at'], hook=p.get('hook', erc8183_jobs.ZERO),
                                              evaluator_key=p.get('evaluator_key'), appeal=p.get('appeal'),
                                              provider_agent_id=p.get('provider_agent_id'),
                                              required_assurance=p.get('required_assurance', 'INCLUDED_UNDER_PINNED_BLOCK'))
        if action == 'erc8183_calls':
            return erc8183_jobs.calls(*triple, job_id=p.get('job_id'), deliverable=p.get('deliverable'), policy=p.get('policy'))
        if action == 'erc8183_job':
            return erc8183_jobs.job(*triple, p['evidence'], trusted_blocks=p.get('trusted_blocks', []), job_id=p.get('job_id'),
                                    policy=p.get('policy'))
        if action == 'erc8183_evaluation':
            return erc8183_jobs.evaluation_payload(*triple, job_id=p['job_id'], decision=p['decision'], deliverable=p['deliverable'],
                                                   reason=p['reason'], policy=p.get('policy'))
        if action == 'erc8183_record':
            return erc8183_jobs.evaluation_record(*triple, p['evaluation'], policy=p['policy'])
        if action == 'erc8183_ladder_step':
            return erc8183_jobs.ladder_step(*triple, p['record'], p['expected_record'], p['policy'], p['adoptions'], p['events'],
                                            actor=p['actor'], at=p['at'], bond_receipt=p.get('bond_receipt'))
        if action == 'erc8183_release':
            return erc8183_jobs.release(*triple, p['policy'], p['adoptions'], p['events'], job_id=p['job_id'],
                                        expected_head=p.get('expected_head'))
        if action == 'erc8183_conformance':
            return erc8183_jobs.conformance(*triple, p['evidence'], p['policy'], p['adoptions'], p['events'],
                                            trusted_blocks=p.get('trusted_blocks', []), job_id=p.get('job_id'),
                                            expected_head=p.get('expected_head'))
    if action == 'erc7710_map':
        return erc7710_delegations.map_delegation(p['context'], network=p['network'], manager=p['manager'], enforcers=p['enforcers'],
                                                  principals=p['principals'], nonce=p['nonce'], scope=p.get('scope'), parent=p.get('parent'),
                                                  expected_parent_id=p.get('expected_parent_id'), may_delegate=p.get('may_delegate', False),
                                                  require_signatures=p.get('require_signatures', False))
    if action == 'erc7710_execution':
        return erc7710_delegations.execution_request(p['execution'], network=p['network'], mode=p.get('mode', '0x' + '00' * 32))
    if action == 'aaa_packet':
        award = p.get('award')
        if award is not None:
            award = {'award': award.get('award'), 'pdf': _bytes(award.get('pdf_base64', ''), 'AAA_AWARD'), 'detached': award.get('detached', [])}
        out = aaa_filing.packet(policy=p['policy'], adoptions=p['adoptions'], events=p['events'], claimant=p['claimant'],
                                agreement=p['agreement'], legal_context=_bytes(p['legal_context_base64'], 'AAA_LEGAL_CONTEXT'),
                                terms_document=_bytes(p['terms_base64'], 'AAA_TERMS'), clause=p['clause'], particulars=p['particulars'],
                                award=award, evidence_files=p.get('evidence_files', []), expected_head=p.get('expected_head'))
        return _packet_reply(out)
    if action == 'aaa_verify':
        return aaa_filing.verify(aaa_filing.read_archive(_bytes(p['archive_base64'], 'AAA_PACKET')), p['expected_id'])
    raise ValueError('ADJUDICATION_ACTION')
