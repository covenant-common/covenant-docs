"""AAP dual-format awards: one canonical JSON award and its deterministic PDF.

TAKE-AND-IMPROVE from the Agentic Arbitration Protocol's RFC 003, which hashes
the JSON without the PDF hash and asks a PDF to print its own hash. Here the
award body is AAP canonical JSON; ``render`` turns it into PDF 1.4 bytes
(an ISO 32000-1 subset: standard Times-Roman, one size, no dependency, no
clock). The JSON award each tribunal member signs binds the PDF's SHA-256,
and each member also gives a detached JWS over the exact PDF bytes (RFC 7515
appendix F, RFC 7797 unencoded payload, RFC 8037 EdDSA). Anyone can render
the body again and compare bytes, so the machine copy and the court copy
cannot drift apart.

Not claimed: PDF/A conformance (the standard font is not embedded), PAdES,
qualified electronic signatures or timestamps, or recognition by any court.
A signed award is a signed statement; AAP's terms and ladder decide escrow.
"""
from copy import deepcopy
import base64
import hashlib
import json
import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verify as verify_signature

VERSION = 'urn:aap:award:0.1'
BODY_LABEL = 'AAP-AWARD-BODY-0.1'
AWARD_LABEL = 'AAP-AWARD-0.1'
RENDERER = 'urn:aap:award-pdf:0.1'
METHODS = ('BINDING_ARBITRATION', 'EXPERT_DETERMINATION', 'HYBRID', 'MEDIATION')
BASES = ('OTHER', 'PANEL', 'PROCEDURE')
MAX_PDF = 16_777_216
PAGE = (595, 842)  # ISO 216 A4 in points
MARGIN = 72
SIZE = 11
LEADING = '12.76'  # 1.16 x 11 pt
_RFC3339 = re.compile(r'([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})Z\Z', re.ASCII)
# Adobe Core 14 Times-Roman advance widths, WinAnsiEncoding codes 32-126, 1/1000 em.
_WIDTHS = dict(zip(map(chr, range(32, 127)), (
    250, 333, 408, 500, 500, 833, 778, 180, 333, 333, 500, 564, 250, 333, 250, 278,
    500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 278, 278, 564, 564, 564, 444,
    921, 722, 667, 667, 722, 611, 556, 722, 722, 333, 389, 722, 611, 889, 722, 722,
    556, 722, 667, 556, 611, 722, 722, 944, 722, 722, 611, 333, 278, 333, 469, 500,
    333, 444, 500, 444, 500, 444, 333, 500, 500, 278, 278, 500, 278, 778, 500, 500,
    500, 500, 333, 389, 278, 500, 500, 722, 500, 500, 444, 480, 200, 480, 541)))

REMEDIATION = {
    'AWARD_TEXT': 'Use printable ASCII without line breaks; put each paragraph in its own list entry.',
    'AWARD_FIELDS': 'Use the exact award body fields: version case title issued seat method parties tribunal threshold basis agreement sections outcome escrow_effect.',
    'AWARD_VERSION': 'Use urn:aap:award:0.1; a meaning change needs a new version string.',
    'AWARD_ISSUED': 'State issued as an RFC 3339 UTC date-time such as 2026-10-25T12:00:00Z.',
    'AWARD_PARTIES': 'Name 2 to 16 parties with distinct roles and distinct 64-hex keys.',
    'AWARD_TRIBUNAL': 'Name 1 to 16 tribunal members with distinct keys and a threshold from a majority to all of them.',
    'AWARD_SECTIONS': 'Give 1 to 32 sections, each with a heading and 1 to 64 paragraphs.',
    'AWARD_BASIS': 'Name the AAP ladder the award comes from: PROCEDURE, PANEL or OTHER with 64-hex references.',
    'AWARD_SIZE': 'Shorten the award; the canonical body is capped at 262144 bytes.',
    'AWARD_PDF_SIZE': 'Pass the PDF as bytes of at most 16 MiB.',
    'AWARD_PDF_HASH': 'The PDF bytes differ from the SHA-256 the signed award binds; obtain the original file.',
    'AWARD_PDF_RENDERING': 'The PDF is not the canonical rendering of the body; render the body again with urn:aap:award-pdf:0.1.',
    'AWARD_BODY_ID': 'The body id does not match the body; obtain the unmodified award.',
    'AWARD_SIGNER': 'Only tribunal members named in the body may sign, once each.',
    'AWARD_SIGNATURES': 'Collect signatures from at least the threshold of tribunal members over the unchanged award.',
    'AWARD_DETACHED': 'Pass compact detached JWS strings (header..signature) with EdDSA, b64 false and crit [b64].',
    'AWARD_PDF_SIGNATURES': 'Collect detached PDF signatures from at least the threshold of members who signed the JSON award.',
    'AWARD_DETACHED_SIGNATURE': 'A detached signature does not cover these exact PDF bytes under the named member key.',
}


def _text(value, limit, code='AWARD_TEXT'):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _keys(rows, limit, code):
    need(type(rows) is list and 1 <= len(rows) <= limit, code)
    for row in rows: key(row['key'])
    need(len({row['key'] for row in rows}) == len(rows), code)


def validate_body(body):
    """Exact award body; prose stays data and never changes the machine outcome."""
    need(type(body) is dict and set(body) == set(('version case title issued seat method parties tribunal threshold '
                                                  'basis agreement sections outcome escrow_effect').split()), 'AWARD_FIELDS')
    need(body['version'] == VERSION, 'AWARD_VERSION')
    _text(body['case'], 128); _text(body['title'], 200)
    need(type(body['issued']) is str and _RFC3339.match(body['issued']) is not None, 'AWARD_ISSUED')
    if body['seat'] is not None: _text(body['seat'], 128)
    need(body['method'] in METHODS, 'AWARD_FIELDS')
    parties = body['parties']
    need(type(parties) is list and 2 <= len(parties) <= 16, 'AWARD_PARTIES')
    for row in parties:
        need(type(row) is dict and set(row) == {'role', 'name', 'key'}, 'AWARD_PARTIES')
        _text(row['role'], 64, 'AWARD_PARTIES'); _text(row['name'], 128, 'AWARD_PARTIES')
    _keys(parties, 16, 'AWARD_PARTIES')
    need(len({row['role'] for row in parties}) == len(parties), 'AWARD_PARTIES')
    tribunal = body['tribunal']
    need(type(tribunal) is list and all(type(row) is dict and set(row) == {'name', 'key'} for row in tribunal), 'AWARD_TRIBUNAL')
    for row in tribunal: _text(row['name'], 128, 'AWARD_TRIBUNAL')
    _keys(tribunal, 16, 'AWARD_TRIBUNAL')
    integer(body['threshold'], True)
    need(len(tribunal) // 2 + 1 <= body['threshold'] <= len(tribunal), 'AWARD_TRIBUNAL')
    need(not {row['key'] for row in tribunal} & {row['key'] for row in parties}, 'AWARD_TRIBUNAL')
    basis = body['basis']
    need(type(basis) is dict and set(basis) == {'kind', 'reference', 'head'} and basis['kind'] in BASES, 'AWARD_BASIS')
    key(basis['reference'])
    if basis['head'] is not None: key(basis['head'])
    agreement = body['agreement']
    need(type(agreement) is dict and set(agreement) == {'reference', 'clause'}, 'AWARD_FIELDS')
    key(agreement['reference']); _text(agreement['clause'], 2000)
    sections = body['sections']
    need(type(sections) is list and 1 <= len(sections) <= 32, 'AWARD_SECTIONS')
    for row in sections:
        need(type(row) is dict and set(row) == {'heading', 'paragraphs'}, 'AWARD_SECTIONS')
        _text(row['heading'], 120)
        need(type(row['paragraphs']) is list and 1 <= len(row['paragraphs']) <= 64, 'AWARD_SECTIONS')
        for paragraph in row['paragraphs']: _text(paragraph, 4000)
    need(type(body['outcome']) is dict and 0 < len(body['outcome']) <= 32, 'AWARD_FIELDS')
    need(body['escrow_effect'] == 'DECIDED_BY_AAP_TERMS_AND_LADDER', 'AWARD_FIELDS')
    need(len(canonical(body)) <= 262144, 'AWARD_SIZE')
    return body


def body_id(body):
    return digest(BODY_LABEL, validate_body(body))


# Deterministic PDF ----------------------------------------------------------

def _width(text):
    return sum(_WIDTHS[c] for c in text) * SIZE / 1000


def _wrap(text, width, indent=''):
    lines, line = [], ''
    for word in text.split(' '):
        if not word: continue
        candidate = indent + word if not line else line + ' ' + word
        if _width(candidate) <= width:
            line = candidate; continue
        if line: lines.append(line)
        while _width(indent + word) > width:
            cut = len(word) - 1
            while cut > 1 and _width(indent + word[:cut]) > width: cut -= 1
            lines.append(indent + word[:cut]); word = word[cut:]
        line = indent + word
    if line: lines.append(line)
    return lines or ['']


def _lines(body, ident):
    width = PAGE[0] - 2 * MARGIN
    out = []

    def say(text, indent=''):
        out.extend(_wrap(text, width, indent))
    say('ARBITRATION AWARD'); say(body['title']); out.append('')
    say('Award body id: ' + ident)
    say('Case: ' + body['case'])
    say('Issued: ' + body['issued'])
    say('Seat: ' + (body['seat'] if body['seat'] is not None else 'not stated'))
    say('Resolution method: ' + body['method'])
    say('Arbitration agreement: ' + body['agreement']['reference'])
    say(body['agreement']['clause'], '    ')
    out.append(''); say('Parties')
    for row in body['parties']: say('%s: %s (key %s)' % (row['role'], row['name'], row['key']), '    ')
    say('Tribunal (signatures required: %d of %d)' % (body['threshold'], len(body['tribunal'])))
    for row in body['tribunal']: say('%s (key %s)' % (row['name'], row['key']), '    ')
    basis = body['basis']
    say('Basis: %s %s%s' % (basis['kind'], basis['reference'], '' if basis['head'] is None else ' at head ' + basis['head']))
    for row in body['sections']:
        out.append(''); say(row['heading'])
        for paragraph in row['paragraphs']: say(paragraph); out.append('')
    say('Decision (machine-readable): ' + json.dumps(body['outcome'], sort_keys=True, separators=(', ', ': ')))
    say('Escrow effect: decided by the parties\' signed AAP terms and ladder, not by this document.')
    out.append(''); say('Verification')
    say('This file is the deterministic rendering %s of the award body identified above. The signed JSON award '
        'binds the SHA-256 of these exact bytes, and the signing tribunal members also sign them with detached JWS signatures. '
        'To check, recompute the body id, render the body again and compare the bytes.' % RENDERER)
    return out


def _escape(text):
    return text.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')


def _pdf_date(issued):
    match = _RFC3339.match(issued)
    return 'D:' + ''.join(match.groups()) + "Z00'00'"


def render(body):
    """PDF 1.4 bytes, a pure function of the body: same body, same bytes."""
    ident = body_id(body)
    lines = _lines(body, ident)
    per_page = int((PAGE[1] - 2 * MARGIN) / float(LEADING))
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[]]
    objects = []
    kids = ' '.join('%d 0 R' % (4 + 2 * i) for i in range(len(pages)))
    objects.append(b'<< /Type /Catalog /Pages 2 0 R >>')
    objects.append(('<< /Type /Pages /Kids [%s] /Count %d >>' % (kids, len(pages))).encode('ascii'))
    objects.append(b'<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman /Encoding /WinAnsiEncoding >>')
    top = PAGE[1] - MARGIN - SIZE
    for number, page in enumerate(pages, 1):
        text = ['0.5 w', '%d %d %d %d re S' % (MARGIN - SIZE, MARGIN - SIZE, PAGE[0] - 2 * MARGIN + 2 * SIZE, PAGE[1] - 2 * MARGIN + 2 * SIZE), 'BT', '/F1 %d Tf' % SIZE, '%s TL' % LEADING, '%d %d Td' % (MARGIN, top)]
        for index, line in enumerate(page):
            if index: text.append('T*')
            text.append('(%s) Tj' % _escape(line))
        text += ['ET', 'BT', '/F1 %d Tf' % SIZE, '%d %d Td' % (MARGIN, MARGIN // 2),
                 '(%s) Tj' % _escape('Award %s - page %d of %d' % (ident[:16], number, len(pages))), 'ET']
        stream = '\n'.join(text).encode('ascii')
        objects.append(('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d %d] /Resources << /Font << /F1 3 0 R >> >> '
                        '/Contents %d 0 R >>' % (PAGE[0], PAGE[1], 5 + 2 * (number - 1))).encode('ascii'))
        objects.append(b'<< /Length %d >>\nstream\n' % len(stream) + stream + b'\nendstream')
    objects.append(('<< /Title (%s) /Producer (%s) /CreationDate (%s) >>' % (
        _escape(body['title']), RENDERER, _pdf_date(body['issued']))).encode('ascii'))
    out = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offsets = []
    for number, item in enumerate(objects, 1):
        offsets.append(len(out))
        out += b'%d 0 obj\n' % number + item + b'\nendobj\n'
    start = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objects) + 1)
    for offset in offsets: out += b'%010d 00000 n \n' % offset
    out += ('trailer\n<< /Size %d /Root 1 0 R /Info %d 0 R /ID [<%s> <%s>] >>\nstartxref\n%d\n%%%%EOF\n' % (
        len(objects) + 1, len(objects), ident[:32], ident[:32], start)).encode('ascii')
    return bytes(out)


# Signed JSON award and detached PDF signatures --------------------------------

def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _detached_header(signer):
    return {'alg': 'EdDSA', 'b64': False, 'crit': ['b64'], 'kid': signer}


def detached_signature(private_key, pdf):
    """Explicit signer action: compact JWS with detached unencoded payload over the PDF bytes."""
    need(isinstance(private_key, Ed25519PrivateKey) and type(pdf) is bytes and 0 < len(pdf) <= MAX_PDF, 'AWARD_DETACHED')
    head = _b64(json.dumps(_detached_header(public_key(private_key)), separators=(',', ':'), sort_keys=True).encode('ascii'))
    return head + '..' + _b64(private_key.sign(head.encode('ascii') + b'.' + pdf))


def verify_detached(token, pdf):
    """Return the member key that signed these exact bytes."""
    need(type(token) is str and len(token) <= 1024 and token.count('.') == 2, 'AWARD_DETACHED')
    head, middle, tail = token.split('.')
    need(middle == '' and re.fullmatch('[A-Za-z0-9_-]+', head) and re.fullmatch('[A-Za-z0-9_-]{86}', tail), 'AWARD_DETACHED')
    try:
        header = json.loads(base64.urlsafe_b64decode(head + '=' * (-len(head) % 4)))
    except ValueError as exc:
        raise ValueError('AWARD_DETACHED') from exc
    need(type(header) is dict and type(header.get('kid')) is str and header == _detached_header(header['kid']), 'AWARD_DETACHED')
    need(_b64(json.dumps(header, separators=(',', ':'), sort_keys=True).encode('ascii')) == head, 'AWARD_DETACHED')
    key(header['kid'])
    signature = base64.urlsafe_b64decode(tail + '==')
    need(_b64(signature) == tail and type(pdf) is bytes and 0 < len(pdf) <= MAX_PDF, 'AWARD_DETACHED')
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(header['kid'])).verify(signature, head.encode('ascii') + b'.' + pdf)
    except (InvalidSignature, ValueError):
        raise ValueError('AWARD_DETACHED_SIGNATURE') from None
    return header['kid']


def prepare(body):
    """The unsigned award: body, its id and the PDF binding each member signs."""
    pdf = render(body)
    award = {'version': VERSION, 'body': deepcopy(body), 'body_id': body_id(body),
             'pdf': {'sha256': hashlib.sha256(pdf).hexdigest(), 'bytes': len(pdf), 'media_type': 'application/pdf',
                     'renderer': RENDERER}}
    return {'award': award, 'id': digest(AWARD_LABEL, award), 'pdf': pdf,
            'signing_payload': {'label': AWARD_LABEL, 'body': deepcopy(award)},
            'required_signers': [row['key'] for row in body['tribunal']], 'threshold': body['threshold'],
            'execution_authorized': False}


def issue(body, private_keys):
    """Explicit tribunal action: sign the JSON award and the PDF bytes with each member key."""
    prepared = prepare(body)
    need(type(private_keys) is list and 1 <= len(private_keys) <= 16, 'AWARD_SIGNER')
    award = prepared['award']
    signatures = [{'signer': public_key(secret), 'signature': sign(secret, AWARD_LABEL, award)} for secret in private_keys]
    signed = {**deepcopy(award), 'signatures': signatures}
    detached = [detached_signature(secret, prepared['pdf']) for secret in private_keys]
    report = verify(signed, prepared['pdf'], detached=detached)
    return {'award': signed, 'id': prepared['id'], 'pdf': prepared['pdf'], 'detached': detached, 'verification': report}


def verify(award, pdf, detached=()):
    """Check the binding both ways: signed JSON -> PDF hash, and body -> exact PDF bytes."""
    exact(award, 'version body body_id pdf signatures')
    need(award['version'] == VERSION, 'AWARD_VERSION')
    body = validate_body(award['body'])
    need(award['body_id'] == body_id(body), 'AWARD_BODY_ID')
    exact(award['pdf'], 'sha256 bytes media_type renderer')
    key(award['pdf']['sha256']); integer(award['pdf']['bytes'], True)
    need(award['pdf']['media_type'] == 'application/pdf' and award['pdf']['renderer'] == RENDERER, 'AWARD_FIELDS')
    need(type(pdf) is bytes and 0 < len(pdf) <= MAX_PDF, 'AWARD_PDF_SIZE')
    need(hashlib.sha256(pdf).hexdigest() == award['pdf']['sha256'] and len(pdf) == award['pdf']['bytes'], 'AWARD_PDF_HASH')
    need(render(body) == pdf, 'AWARD_PDF_RENDERING')
    unsigned = {name: award[name] for name in ('version', 'body', 'body_id', 'pdf')}
    members = {row['key'] for row in body['tribunal']}
    signatures = award['signatures']
    need(type(signatures) is list and 1 <= len(signatures) <= 16, 'AWARD_SIGNATURES')
    signed = set()
    for row in signatures:
        exact(row, 'signer signature')
        need(row['signer'] in members and row['signer'] not in signed, 'AWARD_SIGNER')
        verify_signature(row['signer'], AWARD_LABEL, unsigned, row['signature'])
        signed.add(row['signer'])
    need(len(signed) >= body['threshold'], 'AWARD_SIGNATURES')
    need(type(detached) in (list, tuple) and len(detached) <= 16, 'AWARD_DETACHED')
    pdf_signers = set()
    for token in detached:
        member = verify_detached(token, pdf)
        need(member in signed and member not in pdf_signers, 'AWARD_SIGNER')
        pdf_signers.add(member)
    need(len(pdf_signers) >= body['threshold'], 'AWARD_PDF_SIGNATURES')
    return {'version': VERSION, 'id': digest(AWARD_LABEL, unsigned), 'body_id': award['body_id'],
            'pdf_sha256': award['pdf']['sha256'], 'pdf': 'BOUND_AND_CANONICAL_RENDERING',
            'json_signers': sorted(signed), 'pdf_signers': sorted(pdf_signers), 'threshold': body['threshold'],
            'outcome': deepcopy(body['outcome']), 'pdf_a': 'NOT_CLAIMED', 'pades': 'NOT_CLAIMED',
            'legal_effect': 'NOT_ESTABLISHED; SEE docs/ARBITRATION_INTEROP.html LEGAL RECOGNITION',
            'escrow_effect': 'DECIDED_BY_AAP_TERMS_AND_LADDER', 'execution_authorized': False}
