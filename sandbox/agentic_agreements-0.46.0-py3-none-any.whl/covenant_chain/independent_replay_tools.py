"""Agent-facing exact verification, never a node, signer or connector installer."""
from .cooperation_interface import HASH, INT, OBJECT


def spec():
    return ('covenant_independent_replay',
            'Independently reconstruct covered native0.16 histories with a vendored JavaScript engine. '
            'Read describe for its exact unsupported features and local verifier pin. Verify requires '
            'recipient-retained chain, height and verifier pins; an optional head pin prevents a sibling fork. '
            'No network, signing, installation, payment or submission. Unsupported features refuse; '
            'a local unsigned report is not full-profile qualification or world truth. Node permission-capable runtime required.', True, [
        ('describe', {}, ()),
        ('demo', {}, ()),
        ('inspect_genesis', {'genesis': OBJECT, 'expected_verifier': HASH}, ('genesis', 'expected_verifier')),
        ('verify', {'genesis': OBJECT, 'entries': {'type': 'array', 'maxItems': 256, 'items': OBJECT},
                    'expected_chain': HASH, 'minimum_height': INT, 'expected_head': HASH,
                    'expected_verifier': HASH}, ('genesis', 'entries', 'expected_chain', 'minimum_height', 'expected_verifier')),
    ])


def call(action, parameters):
    from . import independent_replay
    functions = {'describe': independent_replay.describe, 'demo': independent_replay.demo, 'inspect_genesis': independent_replay.inspect_genesis,
                 'verify': independent_replay.verify}
    if action not in functions:
        raise ValueError('INDEPENDENT_ACTION')
    return functions[action](**parameters)
