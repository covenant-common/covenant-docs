"""Optional LCP buyer gate: one principal annex for LCP purchases and native deals.

Maturity: experimental. Off unless the host passes ``enabled=True`` (host flag
``lcp_buyer``). The gate runs in the host before any signature or settlement and
never opens a socket: the caller supplies the bytes it already holds, an offline
copy included. Declines follow the LCP buyer gate: ``link-not-https``,
``atr-unfetchable``, ``atr-too-large``, ``hash-mismatch``.

The annex binds buyer fields to an existing reliance mandate (``reliance.wallet_id``)
and is signed by that mandate's principal. Caps are the mandate's per-action
caps for the offer's unit, as ``reliance.draft_intent`` checks them. Above the
annex approval limit for that unit, a purchase needs a recorded principal
``APPROVE`` covering the amount, the ``ABOVE_LIMIT`` rule of covenant_agent/hire.py;
a recorded ``DECLINE`` always blocks the counterparty. The gate never signs,
reserves or pays: an approval is permission to proceed to the separate signing
step, not execution.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847). PR 80 took
``min(caps)`` across units and returned a bare ``principal_approval`` flag; both
were replaced by the reliance and hire rules above.
"""
from __future__ import annotations

import base64
import hashlib
import json
from copy import deepcopy
from pathlib import Path

from .atr import ATR_MAX_BYTES, hash_bytes, hash_equals, is_https_link, normalize
from .crypto import digest, exact, integer, need, sign, verification_key, verify

ANNEX_VERSION = 'covenant-lcp-buyer-annex/0.1'
ANNEX_LABEL = 'COVENANT-LCP-BUYER-ANNEX-0.1'
DECISION_VERSION = 'covenant-lcp-buyer-decision/0.1'
DECISION_LABEL = 'COVENANT-LCP-BUYER-DECISION-0.1'
APPROVAL_RULE = 'ABOVE_LIMIT'
DECLINES = ('hash-mismatch', 'atr-unfetchable', 'link-not-https', 'atr-too-large')
LEVELS = (1, 2, 3, 4)
MAX_DECISIONS = 64


def _token(value, code, limit=128):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _text_list(value, code, limit=32):
    need(type(value) is list and 1 <= len(value) <= limit, code)
    for item in value:
        _token(item, code)
    need(len(set(value)) == len(value), code)


def _policy(policy):
    from .reliance import validate_policy, wallet_id
    validate_policy(policy)
    return wallet_id(policy)


def _annex_body(policy, fields):
    mandate = _policy(policy)
    exact(fields, 'level jurisdictions methods approval_limits max_bytes')
    need(fields['level'] in LEVELS and type(fields['level']) is int, 'BUYER_LEVEL')
    _text_list(fields['jurisdictions'], 'BUYER_JURISDICTION')
    _text_list(fields['methods'], 'BUYER_METHOD')
    limits = fields['approval_limits']
    need(type(limits) is dict and set(limits) == set(policy['per_action']), 'BUYER_APPROVAL_LIMITS')
    for unit, amount in limits.items():
        integer(amount)
        need(amount <= policy['per_action'][unit], 'BUYER_APPROVAL_LIMITS')
    integer(fields['max_bytes'], True)
    need(fields['max_bytes'] <= ATR_MAX_BYTES, 'atr-too-large')
    return {'version': ANNEX_VERSION, 'mandate': mandate, 'principal': deepcopy(policy['principal']),
            'level': fields['level'], 'jurisdictions': list(fields['jurisdictions']),
            'methods': list(fields['methods']), 'approval_limits': dict(limits),
            'max_bytes': fields['max_bytes']}


def annex_id(body):
    return digest(ANNEX_LABEL, body)


def annex(policy, fields):
    """Bind buyer fields to an existing mandate. Unsigned: the principal signs ``payload``."""
    body = _annex_body(policy, fields)
    ref = annex_id(body)
    return {'id': ref, 'annex': body, 'payload': {'label': ANNEX_LABEL, 'body': {'annex': ref, 'mandate': body['mandate']}},
            'execution_authorized': False}


def sign_annex(principal_key, record):
    """Owner-side: the principal's signature over an annex record from ``annex``."""
    payload = record['payload']
    return {'annex': deepcopy(record['annex']), 'signature': sign(principal_key, payload['label'], payload['body'])}


def adopt_mandate(mandate):
    """Verify a signed reliance policy and a signed annex once, for a host to install.

    ``mandate`` is ``{'policy': {'policy', 'signature'}, 'annex': {'annex', 'signature'}}``.
    Both signatures are the policy principal's. BUYER_MANDATE otherwise.
    """
    from .reliance import policy_payload
    exact(mandate, 'policy annex')
    envelope, signed = mandate['policy'], mandate['annex']
    exact(envelope, 'policy signature')
    exact(signed, 'annex signature')
    policy = envelope['policy']
    payload = policy_payload(policy)
    try:
        verify(policy['principal'], payload['label'], payload['body'], envelope['signature'])
    except ValueError:
        raise ValueError('BUYER_MANDATE') from None
    body = signed['annex']
    exact(body, 'version mandate principal level jurisdictions methods approval_limits max_bytes')
    need(body['version'] == ANNEX_VERSION, 'BUYER_ANNEX_VERSION')
    rebuilt = _annex_body(policy, {name: body[name] for name in
                                   ('level', 'jurisdictions', 'methods', 'approval_limits', 'max_bytes')})
    need(rebuilt == body, 'BUYER_MANDATE')
    ref = annex_id(body)
    try:
        verify(policy['principal'], ANNEX_LABEL, {'annex': ref, 'mandate': body['mandate']}, signed['signature'])
    except ValueError:
        raise ValueError('BUYER_MANDATE') from None
    return {'policy': deepcopy(policy), 'annex': deepcopy(body), 'annex_id': ref, 'mandate': body['mandate']}


def decision(principal_key, adopted, counterparty, unit, amount, choice, *, atr_hash=None):
    """Owner-side: a principal APPROVE or DECLINE for one counterparty, recorded like hire.py's."""
    _token(counterparty, 'BUYER_COUNTERPARTY', 256)
    _token(unit, 'BUYER_UNIT')
    integer(amount, True)
    need(choice in ('APPROVE', 'DECLINE'), 'BUYER_DECISION')
    body = {'version': DECISION_VERSION, 'policy': APPROVAL_RULE, 'annex': adopted['annex_id'],
            'mandate': adopted['mandate'], 'principal': deepcopy(adopted['policy']['principal']),
            'counterparty': counterparty, 'unit': unit, 'amount': amount,
            'atr_hash': None if atr_hash is None else normalize(atr_hash), 'decision': choice}
    row = {'body': body, 'signature': sign(principal_key, DECISION_LABEL, body)}
    verify(body['principal'], DECISION_LABEL, body, row['signature'])
    return row


def _decisions(adopted, rows):
    need(type(rows) in (list, tuple) and len(rows) <= MAX_DECISIONS, 'BUYER_DECISION')
    checked = []
    for row in rows:
        try:
            exact(row, 'body signature')
            body = row['body']
            exact(body, 'version policy annex mandate principal counterparty unit amount atr_hash decision')
            need(body['version'] == DECISION_VERSION and body['policy'] == APPROVAL_RULE, 'BUYER_DECISION')
            need(body['annex'] == adopted['annex_id'] and body['mandate'] == adopted['mandate'], 'BUYER_DECISION')
            need(body['principal'] == adopted['policy']['principal'], 'BUYER_DECISION')
            need(body['decision'] in ('APPROVE', 'DECLINE'), 'BUYER_DECISION')
            _token(body['counterparty'], 'BUYER_DECISION', 256)
            _token(body['unit'], 'BUYER_DECISION')
            integer(body['amount'], True)
            need(body['atr_hash'] is None or normalize(body['atr_hash']) == body['atr_hash'], 'BUYER_DECISION')
            verify(body['principal'], DECISION_LABEL, body, row['signature'])
        except ValueError:
            raise ValueError('BUYER_DECISION') from None
        checked.append(body)
    return checked


def _result(*, approved=False, decline=None, reason=None, principal_approval=False, approval=None):
    return {'refused': not approved, 'approved': approved, 'decline': decline, 'reason': reason,
            'principal_approval': principal_approval, 'approval': approval, 'signed': False, 'fetches': 0,
            'execution_authorized': False}


def _offer(offer):
    exact(offer, 'kind amount unit counterparty level jurisdiction method link served hash')
    need(offer['kind'] in ('lcp', 'native'), 'BUYER_KIND')
    integer(offer['amount'], True)
    _token(offer['unit'], 'BUYER_UNIT')
    _token(offer['counterparty'], 'BUYER_COUNTERPARTY', 256)
    if offer['kind'] == 'native':
        need(all(offer[name] is None for name in ('level', 'jurisdiction', 'method', 'link', 'served', 'hash')),
             'BUYER_KIND')
        return
    need(offer['level'] in LEVELS and type(offer['level']) is int, 'BUYER_LEVEL')
    _token(offer['jurisdiction'], 'BUYER_JURISDICTION')
    _token(offer['method'], 'BUYER_METHOD')


def gate(adopted, offer, *, decisions=(), enabled=False):
    """Decide one purchase against an adopted mandate. Never fetches, signs or pays."""
    if not enabled:
        return {**_result(), 'code': 'plugin/disabled'}
    exact(adopted, 'policy annex annex_id mandate')
    body, policy = adopted['annex'], adopted['policy']
    _offer(offer)
    rows = _decisions(adopted, decisions)
    if offer['kind'] == 'lcp':
        if not is_https_link(offer['link']):
            return _result(decline='link-not-https')
        served = offer['served']
        if type(served) is not bytes:
            return _result(decline='atr-unfetchable')
        if len(served) > body['max_bytes'] or len(served) > ATR_MAX_BYTES:
            return _result(decline='atr-too-large')
        if not hash_equals(offer['hash'], hash_bytes(served)):
            return _result(decline='hash-mismatch')
        # Outside the annex: the principal widens the annex itself; no decision overrides it here.
        if offer['level'] < body['level']:
            return _result(reason='level')
        if offer['jurisdiction'] not in body['jurisdictions']:
            return _result(reason='jurisdiction')
        if offer['method'] not in body['methods']:
            return _result(reason='method')
    target = None if offer['kind'] == 'native' else normalize(offer['hash'])
    for row in rows:
        if row['decision'] == 'DECLINE' and row['counterparty'] == offer['counterparty'] and \
                row['atr_hash'] in (None, target):
            return _result(reason='principal-declined')
    cap = policy['per_action'].get(offer['unit'])
    if cap is None:
        return _result(reason='unit')
    if offer['amount'] > cap:
        return _result(reason='cap')
    if offer['amount'] <= body['approval_limits'][offer['unit']]:
        return _result(approved=True)
    for row in rows:
        if (row['decision'] == 'APPROVE' and row['counterparty'] == offer['counterparty'] and
                row['unit'] == offer['unit'] and row['amount'] >= offer['amount'] and row['atr_hash'] in (None, target)):
            return _result(approved=True, approval=digest(DECISION_LABEL, row))
    return _result(reason='principal-approval', principal_approval=True)


def _implementation():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def register_verifier(registry):
    """ProofRegistry check ``atr-hash/1``: the proof bytes hash to the statement's atrHash."""
    from .proof_facility import binary
    manifest = {
        'system': 'atr-hash/1',
        'semantics': digest('COVENANT-ATR-HASH-VERIFIER-0.1', {'compares': 'sha256-bytes'}),
        'implementation': _implementation(),
        'scope': 'SHA-256 of the served ATR bytes equals atrHash. Not assent, legal effect or payment.',
        'trust': 'LOCAL_HASH_COMPARE',
    }

    def callback(envelope):
        statement = envelope['statement']
        exact(statement, 'atrHash')
        raw = binary(envelope['proof'], ATR_MAX_BYTES)
        return hash_equals(statement['atrHash'], hash_bytes(raw))

    return registry.register(manifest, callback)


def install_identity(desk, name, issuer):
    """IdentityDesk provider whose only claim is that an ATR hash matches served bytes."""
    from covenant_language import mechanism_plans as plans
    from .identity_facility import IMPLEMENTATION, provider
    verification_key(issuer)
    manifest = provider(
        name, 'SIGNED_ATTESTATION', plans._id('COVENANT-ATR-ISSUER-0.1', issuer), IMPLEMENTATION,
        plans._id('COVENANT-ATR-HASH-RULE-0.1', {'claim': 'ATR_HASH'}), ['ATR_HASH'],
        config={'issuer_key': issuer},
        assumptions=['Hash equality of served bytes. Not legal identity or authority.'],
    )['manifest']

    def check(challenge, proof, now):
        exact(proof, 'atrHash served')
        need(type(proof['served']) is str and len(proof['served']) <= 4 * ((ATR_MAX_BYTES + 2) // 3), 'hash-mismatch')
        try:
            raw = base64.b64decode(proof['served'], validate=True)
        except ValueError:
            raise ValueError('hash-mismatch') from None
        need(base64.b64encode(raw).decode('ascii') == proof['served'], 'hash-mismatch')
        need(hash_equals(proof['atrHash'], hash_bytes(raw)), 'hash-mismatch')
        return {'ATR_HASH': normalize(proof['atrHash'])}

    return desk.register(manifest, check)


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='LCP buyer gate. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    args = parser.parse_args(argv)
    print(json.dumps({'plugin': 'lcp_buyer', 'enabled': bool(args.enabled), 'declines': list(DECLINES),
                      'approval_rule': APPROVAL_RULE, 'maturity': 'experimental', 'execution_authorized': False},
                     sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
