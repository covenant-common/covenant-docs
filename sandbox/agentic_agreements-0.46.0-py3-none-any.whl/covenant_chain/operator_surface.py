"""Operator-facing version and install location.

The package version is the ``project.version`` field in ``pyproject.toml``.
``covenant_language._version`` reads that file. Preflight, the testnet kit,
and ``pip install .`` all name this same string.
"""
from __future__ import annotations

import os
import sys
import sysconfig


def release_id():
    from covenant_language._version import __version__
    return 'covenant-package/' + __version__


def console_path_hint(path_env=None):
    """Where ``pip install --user`` places ``covenant-*``, when that directory is off PATH."""
    scripts = sysconfig.get_path('scripts', 'posix_user')
    if not scripts:
        return None
    raw = os.environ.get('PATH', '') if path_env is None else path_env
    if scripts in raw.split(os.pathsep):
        return None
    return (
        'covenant-* commands install to ' + scripts + ', which is not on PATH. '
        + 'export PATH="' + scripts + ':$PATH"'
    )


def announce_console_path():
    hint = console_path_hint()
    if hint:
        print(hint, file=sys.stderr)
