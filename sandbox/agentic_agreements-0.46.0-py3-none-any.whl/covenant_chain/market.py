"""Opt-in native 0.12: protected proposals, bounded prices and service bonds.

No automatic code download, token minting, guaranteed yield or stake voting.
Resource and service truth outside the ledger remains an adopted assumption.

STAKE_OPEN, STAKE_EXIT, STAKE_WITHDRAW, STAKE_CLAIM and STAKE_SLASH are the only
stake state machine. Rewards leave the reserve pot (market_rewards), never a mint.
GOV_VETO is the founder's native power. A later economics profile must not open
a second stake ledger or a second veto.
"""
from .profile import MIGRATION_VERSION
from copy import deepcopy
from .crypto import exact,need,key,integer,digest,canonical,verify,sign,public_key,verification_key
from .market_audit import check_accounting_deltas
from .market_meter import price_view, projected_meter
from .state import Table
VERSION='covenant-market/0.1'
NATIVE='covenant-native/0.12'
TABLES=('market_config','market_meter','market_reserve','market_rewards','market_held',
        'governance_proposals','service_stakes','stake_evidence','stake_reward_services')
APPROVAL='COVENANT-NETWORK-READY-0.1'
CHECKPOINT='COVENANT-BONDED-CHECKPOINT-0.1'
STAKE_OPS=('STAKE_OPEN','STAKE_EXIT','STAKE_WITHDRAW','STAKE_CLAIM','STAKE_SLASH')
OPEN_FIELDS='operator quantity acceptance'
ACCEPTANCE_FIELDS='version policy generation controller_epoch operational guardians'


def require_fields(obj, names, label):
    """Reject a shape mismatch and name the first missing or unexpected field."""
    wanted = names.split()
    if type(obj) is not dict:
        raise ValueError('FIELDS:' + label)
    missing = [name for name in wanted if name not in obj]
    if missing:
        raise ValueError('FIELDS:' + missing[0])
    extra = sorted(name for name in obj if name not in set(wanted))
    if extra:
        raise ValueError('FIELDS:' + extra[0])
FOUNDER_POWER='GOV_VETO'
RESERVE_POT='market_reserve'

def checkpoint(private,chain,position,operator,slot,content):
    """One immutable bonded service head per slot; a revision needs a NEW slot."""
    body={'chain':chain,'position':position,'operator':operator,'slot':slot,'content':content}
    return {'body':body,'signature':sign(private,CHECKPOINT,body)}

def config_id(p):return digest('COVENANT-MARKET-POLICY-0.1',p)

def validate(p,s):
    exact(p,'version governance pricing reserve staking');need(p['version']==VERSION,'MARKET_VERSION')
    g=p['governance'];exact(g,'founder council threshold notice lifetime')
    key(g['founder']);need(g['founder'] in s['continuity_policies'],'GOVERNANCE_FOUNDER_PROTECTED')
    council=g['council'];need(type(council) is list and 1<=len(council)<=8 and council==sorted(set(council)),'GOVERNANCE_COUNCIL')
    need(g['founder'] not in council,'GOVERNANCE_SEPARATION')
    for who in council:key(who);need(who in s['continuity_policies'],'GOVERNANCE_COUNCIL_PROTECTED')
    integer(g['threshold'],True);integer(g['notice'],True);integer(g['lifetime'],True)
    need(g['threshold']<=len(council) and 2<=g['notice']<=10000 and g['notice']<g['lifetime']<=100000,'GOVERNANCE_BOUNDS')
    q=p['pricing'];exact(q,'target_work target_kib max_work max_kib step_bps min_bps max_bps smoothing work_units')
    for f in q:
        if f!='work_units':integer(q[f],True)
    need(q['target_work']<=q['max_work']<=1000000 and q['target_kib']<=q['max_kib']<=768,'MARKET_CAPACITY')
    need(q['step_bps']<=1250 and q['min_bps']<=10000<=q['max_bps']<=1000000 and q['smoothing']<=100,'MARKET_PRICING_BOUNDS')
    need(type(q['work_units']) is dict and len(q['work_units'])<=64,'MARKET_WORK_UNITS')
    for op,u in q['work_units'].items():need(type(op) is str and 0<len(op)<=80,'MARKET_OPERATION');integer(u,True);need(u<=q['max_work'],'MARKET_WORK_UNITS')
    r=p['reserve'];exact(r,'resource account floor initial source epoch_length epoch_budget recovery_bps')
    need(r['resource'] in s['resources'],'MARKET_RESOURCE');key(r['account']);key(r['source'])
    for f in ('floor','initial','epoch_length','epoch_budget','recovery_bps'):integer(r[f],True if f in {'floor','epoch_length','epoch_budget'} else False)
    need(r['epoch_length']<=100000 and 10000<r['recovery_bps']<=20000,'MARKET_RESERVE_BOUNDS')
    b=p['staking'];exact(b,'resource reward_resource min_term max_term exit_delay reward_delay slash_bps reward_bps max_reward')
    need(b['resource'] in s['resources'] and b['reward_resource']==r['resource'],'STAKE_RESOURCES')
    for f in ('min_term','max_term','exit_delay','reward_delay','slash_bps','reward_bps','max_reward'):integer(b[f],True)
    need(b['min_term']<b['max_term']<=100000 and max(b['exit_delay'],b['reward_delay'])<=100000 and b['slash_bps']<=10000 and b['reward_bps']<=10000,'STAKE_BOUNDS')
    # The genesis bond asset is limited to its disclosed domestic issuance.
    # Foreign claims use separate lineage IDs; bridging cannot inflate this asset.
    need(all(b['resource'] not in source['resource_map'].values() for source in s['bridge_sources'].values()),'STAKE_IMPORTED_ISSUANCE_UNSUPPORTED')
    veto_separation(s, g['founder'])
    return p

def veto_separation(s, founder):
    """On 0.15 and 0.16 the veto key is not a one-guardian continuity policy.

    Older profiles keep a threshold-1 founder. The check runs at genesis, on a
    MARKET_POLICY successor, and again when the veto is exercised.
    """
    from .profile import RESOLUTION_VERSION
    if s.get('protocol') not in {RESOLUTION_VERSION,MIGRATION_VERSION}:
        return
    row = s.get('continuity_policies', {}).get(founder)
    need(type(row) is dict, 'GOVERNANCE_VETO_SEPARATION')
    body = row['body']
    guardians = body['guardians']
    need(type(guardians) is dict and body['threshold'] >= 2 and len(guardians) >= 2, 'GOVERNANCE_VETO_SEPARATION')
    material = {founder}
    controller = s.get('controllers', {}).get(founder, founder)
    if type(controller) is str:
        material.add(controller)
    elif type(controller) is dict and type(controller.get('key')) is str:
        material.add(controller['key'])
    for name, pk in guardians.items():
        need(type(name) is str and name not in material, 'GOVERNANCE_VETO_SEPARATION')
        key_hex = pk.get('key') if type(pk) is dict else None
        need(type(key_hex) is str and key_hex not in material, 'GOVERNANCE_VETO_SEPARATION')

def initialize(s,g):
    for table in TABLES:s[table]=Table()
    p=validate(g['market'],s)
    s['market_config']['active']={'body':deepcopy(p),'id':config_id(p),'epoch':0}
    s['market_config']['pending']=None
    s['market_meter']['active']={'height':0,'work':0,'kib':0,'work_ema':0,'kib_ema':0,'work_bps':10000,'kib_bps':10000}
    s['market_held'].update({rid:0 for rid in s['resources']})
    rid=p['reserve']['resource'];s['market_reserve'][rid]={'available':0,'epoch':0,'spent':0,'mode':'CONSTRAINED'}
    s['market_rewards'][rid]=0
    if p['reserve']['initial']:hold(s,p['reserve']['source'],rid,p['reserve']['initial']);s['market_reserve'][rid]['available']=p['reserve']['initial']
    routes(g['economics']['fee_policy'],p)

def routes(policy,p):
    rows=policy['beneficiaries'];need(policy['resource']==p['reserve']['resource'],'MARKET_FEE_RESOURCE')
    need(any(r['purpose']=='MAINTENANCE' and r['account']==p['reserve']['account'] for r in rows),'MARKET_MAINTENANCE_ROUTE')
    need(all(r['account']==p['reserve']['account'] for r in rows if r['purpose'] in {'MAINTENANCE','SERVICE_REWARDS'}),'MARKET_ROUTE_CONTEXT')

def hold(s,who,rid,qty):
    from .balances import amount, add
    integer(qty,True);need(amount(s['authority_available'],who,rid)>=qty,'MARKET_FUNDS')
    for table in ('balances','authority_available'):add(s[table],who,rid,-qty)
    s['market_held'][rid]=s['market_held'].get(rid,0)+qty

def release(s,who,rid,qty):
    from .balances import add
    integer(qty);need(s['market_held'].get(rid,0)>=qty,'MARKET_HELD')
    s['market_held'][rid]-=qty
    for table in ('balances','authority_available'):add(s[table],who,rid,qty)

def begin(s,height):
    integer(height,True)
    if s['market_meter']['active']['height']==height:return s
    s=deepcopy(s);s['market_meter']['active']=projected_meter(s,height)
    pending=s['market_config'].get('pending')
    if pending and height>=pending['effective']:
        s['market_config']['active']=deepcopy(pending);s['market_config']['pending']=None
        q=pending['body']['pricing'];m=s['market_meter']['active']
        for name in ('work','kib'):m[name+'_bps']=max(q['min_bps'],min(q['max_bps'],m[name+'_bps']))
    r=s['market_config']['active']['body']['reserve'];a=s['market_reserve'][r['resource']]
    epoch=(height-1)//r['epoch_length']
    if a['epoch']!=epoch:a.update(epoch=epoch,spent=0)
    if a['available']<r['floor']:a['mode']='CONSTRAINED'
    elif a['available']*10000>=r['floor']*r['recovery_bps']:a['mode']='NORMAL'
    return s

def measured(tx,p):
    op=tx['body']['op'];private=op in {'CONFIDENTIAL_CLAIM','CONFIDENTIAL_TRANSFER'}
    kib=8 if private else (len(canonical(tx))+1023)//1024
    # Count bounded hash-approval work as well as adopted operation work units.
    work=p['pricing']['work_units'].get(op,1);stack=[tx];count=0
    while stack:
        x=stack.pop();count+=1;need(count<=50000,'MARKET_METER_BOUND')
        if type(x) is dict:
            if x.get('version')=='covenant-controller-and-hash/0.1' and type(x.get('guardians')) is list:work+=25*len(x['guardians'])
            stack.extend(x.values())
        elif type(x) is list:stack.extend(x)
    integer(work,True);return work,kib

def meter(s,tx):
    p=s['market_config']['active']['body'];work,kib=measured(tx,p);m=s['market_meter']['active']
    m['work']+=work;m['kib']+=kib
    need(m['work']<=p['pricing']['max_work'] and m['kib']<=p['pricing']['max_kib'],'MARKET_BLOCK_CAPACITY')

def allocation(s,account,rid,qty,purpose):
    from .fee_credit import allocation as credit
    return credit(s,account,rid,qty,purpose)

def ready_signature(private,chain,proposal,epoch,member):
    b={'chain':chain,'proposal':proposal,'epoch':epoch,'member':member}
    return sign(private,APPROVAL,b)

def _proposal(s,p):
    key(p['proposal']);need(p['proposal'] in s['governance_proposals'],'GOVERNANCE_PROPOSAL')
    a=s['governance_proposals'][p['proposal']];cfg=s['market_config']['active']
    need(a['status']=='OPEN' and a['epoch']==cfg['epoch'],'GOVERNANCE_STALE');return a,cfg

def _validate_change(s,kind,change,height=None,not_before=None,scheduling=False):
    from .economics import validate_policy,policy_id
    if kind in {'UPGRADE','PARAMETER','MODULE','HANDOVER','PAUSE'}:
        from .governance import validate_change
        validate_change(s,kind,change,height,not_before,scheduling)
        return
    if kind=='FEE_POLICY':
        exact(change,'previous policy');key(change['previous']);validate_policy(change['policy'],s['resources'])
        need(change['policy']['version']=='covenant-economics/0.2','MARKET_ECONOMIC_VERSION')
        routes(change['policy'],s['market_config']['active']['body'])
    elif kind=='RELEASE':
        exact(change,'release_hash test_hash migration_hash profile');key(change['release_hash']);key(change['test_hash']);key(change['migration_hash'])
        need(type(change['profile']) is str and 0<len(change['profile'])<=80,'GOVERNANCE_PROFILE')
    elif kind=='RESERVE_PAY':
        exact(change,'recipient quantity purpose');key(change['recipient']);integer(change['quantity'],True)
        need(change['purpose'] in {'ARCHIVE','VALIDATOR','SECURITY','EXPERIMENT'},'RESERVE_PURPOSE')
    elif kind=='STAKE_REWARD':
        exact(change,'operator service positions quantity');key(change['operator']);key(change['service']);integer(change['quantity'],True)
        rows=change['positions'];need(type(rows) is list and 1<=len(rows)<=64 and rows==sorted(set(rows)),'STAKE_REWARD_SET')
        for rid in rows:key(rid)
    elif kind=='MARKET_POLICY':
        exact(change,'previous policy');key(change['previous']);validate(change['policy'],s)
        old=s['market_config']['active']['body'];new=change['policy']
        need(all(old['reserve'][f]==new['reserve'][f] for f in ('resource','account','source','initial')) and
             all(old['staking'][f]==new['staking'][f] for f in ('resource','reward_resource')),'MARKET_ASSET_SUCCESSION')
        routes(s['economic_policy']['active']['body'],new)
        if s['economic_policy'].get('pending'):routes(s['economic_policy']['pending']['body'],new)
    elif kind=='COMMITTEE':
        if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION}:raise ValueError('USE_DOMAIN_SUCCESSION')
        exact(change,'epoch validators faults acceptances');integer(change['epoch'],True);integer(change['faults'],True)
        need(change['epoch']==s['domain']['active']['epoch']+1,'EPOCH_BOUNDARY')
        members=change['validators'];need(type(members) is dict and len(members)==3*change['faults']+1 and len(members)<=64,'COMMITTEE_SIZE')
        for name,pub in members.items():need(type(name) is str and 0<len(name)<=80,'MEMBER_NAME');verification_key(pub)
        need(len({digest('COVENANT-VALIDATOR-KEY',pub) for pub in members.values()})==len(members),'DUPLICATE_VALIDATOR')
        from .lifecycle import approved
        body={'chain':s['chain'],'epoch':change['epoch'],'validators':members,'faults':change['faults']}
        approved(change['acceptances'],set(members),2*change['faults']+1,'COVENANT-MARKET-COMMITTEE-ACCEPT-0.1',body,lambda who:members[who])
    else:raise ValueError('GOVERNANCE_CHANGE_UNSUPPORTED')

def preflight(s,op):
    # 0.15 validator-set changes use DOMAIN_SUCCESSION. Earlier market
    # profiles keep that op refused and use the COMMITTEE proposal kind.
    if op=='DOMAIN_SUCCESSION' and s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION}:return
    need(op not in {'ECON_FEE_SCHEDULE','DOMAIN_SUCCESSION'},'USE_PROTECTED_NETWORK_PROPOSAL')

def apply(s,previous,op,p,actor,tid,height):
    from .app import controller
    cfg=s['market_config']['active'];policy=cfg['body'];g=policy['governance']
    if op=='GOV_PROPOSE':
        from .governance import UPGRADE_KINDS, lock_deposit, stamp_proposal
        upgrade=s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and p.get('kind') in UPGRADE_KINDS
        exact(p,'kind change not_before expiry epoch rationale deposit' if upgrade else 'kind change not_before expiry epoch rationale')
        integer(p['epoch']);integer(p['not_before'],True);integer(p['expiry'],True);key(p['rationale'])
        need(p['epoch']==cfg['epoch'] and height+g['notice']<=p['not_before']<p['expiry']<=height+g['lifetime'],'GOVERNANCE_NOTICE')
        _validate_change(s,p['kind'],p['change'],height,p['not_before'],scheduling=True)
        if upgrade:lock_deposit(s,actor,p['deposit'])
        s['governance_proposals'][tid]={**deepcopy(p),'proposer':actor,'status':'OPEN','approvals':[],
            'acceptances':[],'approval_contexts':{},'readiness':[],'created':height,'domain_epoch':s['domain']['active']['epoch']}
        stamp_proposal(s,s['governance_proposals'][tid])
        return []
    if op in {'GOV_APPROVE','GOV_ACCEPT','GOV_VETO','GOV_READY','GOV_EXECUTE'}:
        if op=='GOV_VETO' and s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and isinstance(s.get('upgrade'),dict) and s['upgrade'].get('veto') is False:
            raise ValueError('VETO_RELEASED')
        exact(p,'proposal member signature' if op=='GOV_READY' else 'proposal');a,cfg=_proposal(s,p)
        need(height<=a['expiry'],'GOVERNANCE_EXPIRED')
        need(a['domain_epoch']==s['domain']['active']['epoch'],'GOVERNANCE_COMMITTEE_STALE')
        if op=='GOV_APPROVE':
            need(actor in [g['founder'],*g['council']] and actor not in a['approvals'],'GOVERNANCE_APPROVER')
            a['approvals']=sorted([*a['approvals'],actor]);a['approval_contexts'][actor]=digest('COVENANT-GOVERNOR-CONTEXT',controller(s,actor));return [p['proposal']]
        if op=='GOV_ACCEPT':
            need(a['kind']=='MARKET_POLICY','GOVERNANCE_ACCEPTANCE_SCOPE');new=a['change']['policy']['governance']
            need(actor in [new['founder'],*new['council']] and actor not in a['acceptances'],'GOVERNANCE_ACCEPTOR')
            a['acceptances']=sorted([*a['acceptances'],actor]);a['approval_contexts'][actor]=digest('COVENANT-GOVERNOR-CONTEXT',controller(s,actor));return [p['proposal']]
        if op=='GOV_VETO':
            need(actor==g['founder'],'GOVERNANCE_VETO')
            veto_separation(s, g['founder'])
            a.update(status='VETOED',decision=tid);return [p['proposal']]
        if op=='GOV_READY':
            active=s['domain']['active'];member=p['member'];need(type(member) is str and member in active['validators'] and member not in a['readiness'],'GOVERNANCE_VALIDATOR')
            body={'chain':s['chain'],'proposal':p['proposal'],'epoch':cfg['epoch'],'member':member}
            verify(active['validators'][member],APPROVAL,body,p['signature'])
            a['readiness']=sorted([*a['readiness'],member]);return [p['proposal']]
        need(height>=a['not_before'] and g['founder'] in a['approvals'] and len(set(g['council'])&set(a['approvals']))>=g['threshold'],'GOVERNANCE_APPROVAL_REQUIRED')
        need(all(digest('COVENANT-GOVERNOR-CONTEXT',controller(s,who))==a['approval_contexts'][who] for who in [*a['approvals'],*a['acceptances']]),'GOVERNANCE_AUTHORITY_STALE')
        from .governance import UPGRADE_KINDS, execute, readiness_met
        need(readiness_met(s,a),'GOVERNANCE_READINESS')
        change=a['change'];kind=a['kind'];_validate_change(s,kind,change,height,a['not_before'],scheduling=False)
        if kind in UPGRADE_KINDS:
            execute(s,a,p['proposal'],height)
            a.update(status='EXECUTED' if kind in {'HANDOVER','PAUSE'} else 'SCHEDULED',decision=tid)
            return [p['proposal']]
        if kind=='FEE_POLICY':
            from .economics import policy_id
            need(s['economic_policy'].get('pending') is None and s['economic_policy']['active']['id']==change['previous'],'FEE_SCHEDULE_STATE')
            s['economic_policy']['pending']={'body':deepcopy(change['policy']),'id':policy_id(change['policy']),'effective':height+1,'event':tid}
        elif kind=='RESERVE_PAY':
            r=policy['reserve'];pool=s['market_reserve'][r['resource']];qty=change['quantity']
            need(pool['spent']+qty<=r['epoch_budget'] and qty<=pool['available'],'RESERVE_BUDGET')
            if change['purpose']=='EXPERIMENT':need(pool['mode']=='NORMAL' and pool['available']-qty>=r['floor'],'RESERVE_PRESERVATION')
            pool['available']-=qty;pool['spent']+=qty;release(s,change['recipient'],r['resource'],qty)
        elif kind=='STAKE_REWARD':_reward(s,change,tid,height,policy['staking'])
        elif kind=='MARKET_POLICY':
            new=change['policy']['governance']
            need(new['founder'] in a['acceptances'] and len(set(new['council'])&set(a['acceptances']))>=new['threshold'],'GOVERNANCE_SUCCESSOR_ACCEPTANCE')
            need(cfg['id']==change['previous'] and s['market_config'].get('pending') is None,'MARKET_POLICY_STALE')
            s['market_config']['pending']={'body':deepcopy(change['policy']),'id':config_id(change['policy']),
                'epoch':cfg['epoch']+1,'effective':height+1,'event':tid}
        elif kind=='COMMITTEE':
            need(height>=s['domain']['active']['activation'],'EPOCH_BOUNDARY')
            s['domain']['active']={'epoch':change['epoch'],'activation':height+1,'validators':deepcopy(change['validators']),
                'faults':change['faults'],'event':tid}
        # RELEASE is an authenticated authorization record, not executable code.
        a.update(status='AUTHORIZED_RELEASE' if kind=='RELEASE' else 'EXECUTED',decision=tid)
        return [p['proposal']]
    if op=='MARKET_FUND':
        exact(p,'quantity destination');integer(p['quantity'],True);need(p['destination'] in {'MAINTENANCE','SERVICE_REWARDS'},'MARKET_DESTINATION')
        rid=policy['reserve']['resource'];hold(s,actor,rid,p['quantity'])
        if p['destination']=='MAINTENANCE':s['market_reserve'][rid]['available']+=p['quantity']
        else:s['market_rewards'][rid]+=p['quantity']
        return []
    if op=='STAKE_OPEN':
        exact(p,'operator quantity acceptance');key(p['operator']);integer(p['quantity'],True)
        body={'chain':s['chain'],'owner':actor,'operator':p['operator'],'quantity':p['quantity'],'policy':cfg['id']}
        need(p['operator'] in s['continuity_policies'],'STAKE_OPERATOR_PROTECTED')
        require_fields(p['acceptance'], ACCEPTANCE_FIELDS, 'acceptance')
        descriptor=controller(s,p['operator']);verify(descriptor,'COVENANT-STAKE-ACCEPT-0.1',body,p['acceptance'])
        b=policy['staking'];hold(s,actor,b['resource'],p['quantity'])
        s['service_stakes'][tid]={'owner':actor,'operator':p['operator'],'operator_key':deepcopy(descriptor),
            'resource':b['resource'],'reward_resource':b['reward_resource'],'amount':p['quantity'],
            'opened':height,'min_until':height+b['min_term'],'exit_delay':b['exit_delay'],
            'max_until':height+b['max_term'],
            'exit':None,'closed':False,'slashed':False,'slash_bps':b['slash_bps'],
            'claimable':0,'reward_after':0,'policy':cfg['id']}
        return []
    if op in {'STAKE_EXIT','STAKE_WITHDRAW','STAKE_CLAIM','STAKE_SLASH'}:
        exact(p,'position proofs' if op=='STAKE_SLASH' else 'position');key(p['position']);need(p['position'] in s['service_stakes'],'STAKE_POSITION')
        a=s['service_stakes'][p['position']];need(not a['closed'],'STAKE_CLOSED')
        if op!='STAKE_SLASH':need(actor==a['owner'],'STAKE_OWNER')
        if op=='STAKE_EXIT':
            need(height>=a['min_until'] and a['exit'] is None,'STAKE_TERM');a['exit']=min(height+a['exit_delay'],a['max_until']+a['exit_delay'])
        elif op=='STAKE_WITHDRAW':
            end=a['exit'] if a['exit'] is not None else a['max_until']+a['exit_delay']
            need(height>end and a['claimable']==0,'STAKE_EXIT_DELAY')
            release(s,actor,a['resource'],a['amount']);a['amount']=0;a['closed']=True
        elif op=='STAKE_CLAIM':
            need(a['claimable']>0 and height>a['reward_after'],'STAKE_REWARD_DELAY')
            release(s,actor,a['reward_resource'],a['claimable']);a['claimable']=0
        else:_slash(s,p,a,tid,height)
        return [p['position']]
    if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and op=='GOV_HOLD':
        exact(p,'proposal');a,cfg=_proposal(s,p)
        from .governance import add_holder
        add_holder(s,a,actor);return [p['proposal']]
    if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and op=='GOV_REFUND':
        exact(p,'proposal');key(p['proposal']);need(p['proposal'] in s['governance_proposals'],'GOVERNANCE_PROPOSAL')
        a=s['governance_proposals'][p['proposal']]
        need(actor==a['proposer'] and a.get('deposit') and a.get('deposit_settled') is False,'DEPOSIT')
        if a['status']=='OPEN':a['status']='CANCELLED'
        else:need(a['status'] in {'SCHEDULED','ACTIVE','VETOED','EXPIRED','EXECUTED'},'DEPOSIT')
        from .governance import unlock_deposit
        unlock_deposit(s,actor,a['deposit']);a['deposit_settled']=True;return [p['proposal']]
    if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and op=='GOV_RATIFY':
        exact(p,'kind member signature');need(type(p['member']) is str,'GOVERNANCE_VALIDATOR')
        active=s['domain']['active'];need(p['member'] in active['validators'],'GOVERNANCE_VALIDATOR')
        body={'chain':s['chain'],'pause':p['kind'],'member':p['member']}
        verify(active['validators'][p['member']],'COVENANT-PAUSE-RATIFY-1',body,p['signature'])
        from .governance import extend_pause, note_pause_signal
        if note_pause_signal(s,p['kind'],p['member']):extend_pause(s['upgrade']['pauses'][p['kind']],height)
        return []
    return None

def _reward(s,p,tid,height,b):
    service=p['service'];need(service in s['service_jobs'] and service not in s['stake_reward_services'],'STAKE_SERVICE')
    j=s['service_jobs'][service];need(j['state']=='SETTLED' and j['provider']==p['operator'] and j['delivered']>0,'STAKE_PERFORMANCE')
    if service in s.get('review_jobs',{}):
        from .review import performance_confirmed
        need(performance_confirmed(s,service),'STAKE_REVIEW_PERFORMANCE_UNCONFIRMED')
    paid=j['delivered']*j['unit_price'];need(j['settlement_resource']==b['reward_resource'],'STAKE_REWARD_RESOURCE')
    qty=p['quantity'];need(qty<=min(b['max_reward'],paid*b['reward_bps']//10000) and qty<=s['market_rewards'][b['reward_resource']],'STAKE_FUNDED_REWARD')
    positions=[]
    for rid in p['positions']:
        need(rid in s['service_stakes'],'STAKE_POSITION');a=s['service_stakes'][rid]
        need(not a['closed'] and not a['slashed'] and a['exit'] is None and height<=a['max_until'] and a['operator']==p['operator'] and a['opened']<s['events'][service]['height'],'STAKE_REWARD_ELIGIBILITY')
        positions.append(a)
    total=sum(a['amount'] for a in positions);need(total>0,'STAKE_AMOUNT')
    shares=[qty*a['amount']//total for a in positions];rest=qty-sum(shares)
    order=sorted(range(len(positions)),key=lambda i:(-(qty*positions[i]['amount']%total),p['positions'][i]))
    for i in order[:rest]:shares[i]+=1
    for a,value in zip(positions,shares):a['claimable']+=value;a['reward_after']=max(a['reward_after'],height+b['reward_delay'])
    s['market_rewards'][b['reward_resource']]-=qty;s['stake_reward_services'][service]=tid

def _slash(s,p,a,tid,height):
    proofs=p['proofs'];need(type(proofs) is list and len(proofs)==2 and not a['slashed'],'STAKE_EVIDENCE')
    bodies=[]
    for proof in proofs:
        exact(proof,'body signature');x=proof['body'];exact(x,'chain operator position slot content')
        need(x['chain']==s['chain'] and x['operator']==a['operator'] and x['position']==p['position'],'STAKE_CHECKPOINT_CONTEXT')
        integer(x['slot'],True);key(x['content']);need(a['opened']<=x['slot']<=min(height,a['max_until']) and (a['exit'] is None or x['slot']<=a['exit']),'STAKE_EVIDENCE_WINDOW')
        verify(a['operator_key'],CHECKPOINT,x,proof['signature']);bodies.append(x)
    need(bodies[0]['slot']==bodies[1]['slot'] and bodies[0]['content']!=bodies[1]['content'],'STAKE_NOT_EQUIVOCATION')
    loss=(a['amount']*a['slash_bps']+9999)//10000;a['amount']-=loss;a['slashed']=True
    # Slash proceeds are a protocol reserve, never a discretionary claimant prize.
    rid=a['resource']
    if rid not in s['market_reserve']:s['market_reserve'][rid]={'available':0,'epoch':0,'spent':0,'mode':'CONSTRAINED'}
    s['market_reserve'][rid]['available']+=loss
    if a['claimable']:
        s['market_rewards'][a['reward_resource']]+=a['claimable'];a['claimable']=0
    s['stake_evidence'][tid]={'position':p['position'],'slot':bodies[0]['slot'],'loss':loss,'proofs':deepcopy(proofs)}
