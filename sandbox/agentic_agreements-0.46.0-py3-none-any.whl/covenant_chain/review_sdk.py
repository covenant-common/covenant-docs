"""Explicit opt-in review SDK; RPC state and acknowledgements are advisory."""
from .world_sdk import WorldClient
from .app import REVIEW_VERSION

class ReviewClient(WorldClient):
    def __init__(self,client,private_key,chain,*,fee_policy,max_fee,actor=None,sponsor=None,protocol=REVIEW_VERSION):
        super().__init__(client,private_key,chain,actor=actor,protocol=protocol,
                         fee_policy=fee_policy,max_fee=max_fee,sponsor=sponsor)
    def adopt_review(self,payload):return self.submit('REVIEW_ADOPT',payload)
    def file(self,case,argument,evidence):
        return self.submit('REVIEW_FILE',dict(case=case,argument=argument,evidence=evidence))
    def respond(self,case,phase,argument,evidence):
        return self.submit('REVIEW_ARGUMENT',dict(case=case,phase=phase,argument=argument,evidence=evidence))
    def acknowledge_access(self,case,phase,manifest):
        """Caller must actually check access; a hash alone establishes no access."""
        return self.submit('REVIEW_ACK',dict(case=case,phase=phase,manifest=manifest))
    def acknowledge_verified_access(self,genesis,history,minimum_height,case,documents):
        from .review import verified_access
        from .crypto import need
        need(type(genesis) is dict,'FIELDS:genesis');need(type(history) is list,'FIELDS:history')
        receipt=verified_access(genesis,history,self.chain,minimum_height,case,documents)
        return self.submit('REVIEW_ACK',receipt)
    def vote(self,case,phase,result,units,manifest,reasons):
        return self.submit('REVIEW_VOTE',dict(case=case,phase=phase,result=result,units=units,manifest=manifest,reasons=reasons))
    def appeal(self,case,argument,evidence):
        return self.submit('REVIEW_APPEAL',dict(case=case,argument=argument,evidence=evidence))
    def finalize(self,case):return self.submit('REVIEW_FINALIZE',dict(case=case))
    def correct(self,payload):return self.submit('REVIEW_CORRECT',payload)


from .world_sdk import bind_agent_methods
bind_agent_methods(ReviewClient)
