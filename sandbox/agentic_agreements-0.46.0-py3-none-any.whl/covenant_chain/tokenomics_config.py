"""Published, config-driven parameters for Covenant's scale-economies profile.

Nothing here mints tokens, moves balances, or changes a 0.1 or 0.2 network.
The illustrative numbers are a starting schedule a genesis can adopt. They are
not a price, a yield, or a promise that the integers exist as balances.
"""
from .crypto import exact, integer, key, need

SCALE_VERSION = 'covenant-economics/0.3'
MODEL = 'covenant-scale-economies-shared/0.1'
PLANNING_PROFILE = 'covenant-service-economics/0.2'
AD_SHARE_VERSION = 'covenant-ad-share/0.1'
# Protocol constant: governance cannot configure a founder protocol fee above this.
FOUNDER_FEE_ABSOLUTE_CAP_BPS = 500
SUPPLY_UNIT = 'COV'

# Starting a network on SCALE_VERSION is a new consensus profile. See CONSENSUS.
CONSENSUS = (
    'covenant-economics/0.3 is selected only in the genesis of a covenant-native/0.15 network. '
    'Native 0.9 through 0.14 keep their existing fee profile. An existing 0.1 or 0.2 fee policy '
    'cannot be rewritten into 0.3: ECON_FEE_SCHEDULE still requires version 0.1 on those networks.',
    'A validator that does not run this code rejects a 0.3 genesis. Joining that network is '
    'a coordinated upgrade, not a compatible extension of a live chain.',
    'On a network whose active policy is not 0.3, the new operations fail with the historical '
    'UNKNOWN_ECONOMIC_OPERATION error, so a mixed 0.1 deployment does not fork.',
    'Once a 0.3 network is running, bonds, pledge claims, points claims, vest, clawback, '
    'rebates, integrator pay, the ad-subsidy hook, and ECON_COST_REPORT are consensus transitions. Every '
    'validator must run them. Take caps on that network can only fall. A measured unit-cost drop '
    'returns at least half to users as a lower fee, and that ceiling does not rise.',
    'Serving rewards, the archive endowment and offline allowance bonds are consensus transitions '
    'on this profile. They move units only through economics.apply.',
    'No operation mints supply. The published split caps funded claims; it does not create balances.',
    'Fee amounts computed for covenant-economics/0.1 and 0.2 are unchanged.',
)

OPEN_PARAMETERS = (
    'supply total and the 52/20/15/8/5 split, including the community genesis/emissions cut',
    'measured fixed cost per window, variable cost per transaction, reference price, reference notional',
    'margin cap and max take (both can only fall), founder fee cap up to the absolute 5% ceiling',
    'volume tiers and the qualified-volume thresholds that select them',
    'window length, blocks per day, per-pair cap, participant multiplier',
    'customer, ecosystem, founder, and operator surplus shares',
    'archive endowment divisor 64, host cap 625 bps, serve holdback 25 percent for 30 epochs',
    'free fetches per key per epoch, and an offline allowance at most equal to the bond',
    'reserve target, integrator fee share, retro round length, per-owner cap',
    'rebate honour threshold and token rebate fraction',
    'ad CPA split and the minimum distinct counterparties before a subsidy is accepted',
    'emission epoch length, epoch budget, decay, points-to-token rate, loyalty multiplier, minimum bond',
    'pledge templates (kind, minimum, profile), retention, vest unlock fraction and length',
    'team cliff, vest length, milestone fraction, and the usage thresholds',
    'robustness band and the long notice delay',
)


def _bps(value, name):
    integer(value)
    need(value <= 10000, name)


def _list(value, limit, name):
    need(type(value) is list and 1 <= len(value) <= limit, name)


def illustrative_supply(total=1_000_000_000):
    """Ossified illustrative split. Community 52 is emissions 30, pledge-claim 10, fee rebates 5, ad share 2, integrator retro 5."""
    integer(total, True)
    return {'unit': SUPPLY_UNIT, 'total': total, 'community_bps': 5200, 'team_bps': 2000,
            'foundation_bps': 1500, 'ecosystem_bps': 800, 'liquidity_bps': 500,
            'emissions_bps': 3000, 'pledge_claim_bps': 1000, 'fee_rebate_bps': 500,
            'ad_share_bps': 200, 'integrator_retro_bps': 500}


def illustrative_milestones():
    return [
        {'settled_per_day': 10_000, 'distinct_counterparties': 1_000, 'unlock_bps': 3333},
        {'settled_per_day': 100_000, 'distinct_counterparties': 10_000, 'unlock_bps': 3333},
        {'settled_per_day': 1_000_000, 'distinct_counterparties': 100_000, 'unlock_bps': 3334},
    ]


def illustrative_tiers():
    """Take in basis points of the reference notional: 0.30%, 0.20%, 0.10%, 0.05%."""
    return [
        {'min_qualified_volume': 0, 'take_bps': 30},
        {'min_qualified_volume': 1_000, 'take_bps': 20},
        {'min_qualified_volume': 10_000, 'take_bps': 10},
        {'min_qualified_volume': 100_000, 'take_bps': 5},
    ]


def validate_supply(supply):
    exact(supply, 'unit total community_bps team_bps foundation_bps ecosystem_bps liquidity_bps emissions_bps pledge_claim_bps fee_rebate_bps ad_share_bps integrator_retro_bps')
    need(type(supply['unit']) is str and 0 < len(supply['unit']) <= 16, 'SUPPLY_UNIT')
    integer(supply['total'], True)
    parts = ('community_bps', 'team_bps', 'foundation_bps', 'ecosystem_bps', 'liquidity_bps')
    for name in parts:
        _bps(supply[name], 'SUPPLY_BPS')
    need(sum(supply[name] for name in parts) == 10000, 'SUPPLY_BPS')
    inner = ('emissions_bps', 'pledge_claim_bps', 'fee_rebate_bps', 'ad_share_bps', 'integrator_retro_bps')
    for name in inner:
        _bps(supply[name], 'SUPPLY_BPS')
    need(sum(supply[name] for name in inner) == supply['community_bps'], 'SUPPLY_COMMUNITY')
    return supply


def validate_scale(scale):
    exact(scale, 'model planning_profile bps_do_not_set_the_take shariah_mode cost caps tiers window shares accounts supply vesting points rebates integrator governance pledges ads')
    need(scale['shariah_mode'] in {True, False}, 'SHARIAH_MODE')
    need(scale['model'] == MODEL and scale['planning_profile'] == PLANNING_PROFILE, 'SCALE_MODEL')
    need(scale['bps_do_not_set_the_take'] is True, 'SCALE_BPS_ARE_NOT_THE_TAKE')
    exact(scale['cost'], 'fixed_cost_per_window variable_cost_per_unit reference_notional')
    for name in scale['cost']:
        integer(scale['cost'][name])
    integer(scale['cost']['reference_notional'], True)
    exact(scale['caps'], 'margin_cap_bps max_take_bps founder_fee_cap_bps')
    for name in scale['caps']:
        _bps(scale['caps'][name], 'SCALE_CAP')
    need(scale['caps']['founder_fee_cap_bps'] <= FOUNDER_FEE_ABSOLUTE_CAP_BPS, 'FOUNDER_FEE_CAP')
    need(scale['caps']['margin_cap_bps'] <= scale['caps']['max_take_bps'], 'SCALE_MARGIN_CAP')
    _list(scale['tiers'], 8, 'SCALE_TIERS')
    previous = -1
    previous_take = 10001
    for row in scale['tiers']:
        exact(row, 'min_qualified_volume take_bps')
        integer(row['min_qualified_volume'])
        _bps(row['take_bps'], 'SCALE_TIER')
        need(row['min_qualified_volume'] > previous and row['take_bps'] <= previous_take, 'SCALE_TIERS')
        previous, previous_take = row['min_qualified_volume'], row['take_bps']
    need(scale['tiers'][0]['min_qualified_volume'] == 0, 'SCALE_TIERS')
    exact(scale['window'], 'window_blocks pair_cap blocks_per_day participant_multiplier')
    for name in scale['window']:
        integer(scale['window'][name], True)
    need(scale['window']['pair_cap'] <= 10000 and scale['window']['participant_multiplier'] <= 10000, 'SCALE_WINDOW')
    exact(scale['shares'], 'customer ecosystem founder operator')
    for name, value in scale['shares'].items():
        _bps(value, 'SCALE_SHARES')
    need(scale['shares']['customer'] > 0, 'SCALE_CUSTOMER_SHARE')
    need(sum(scale['shares'].values()) <= 10000, 'SCALE_SHARES')
    need(scale['shares']['founder'] <= scale['caps']['founder_fee_cap_bps'], 'FOUNDER_FEE_CAP')
    exact(scale['accounts'], 'maintenance rebate_pool reserve integrator_pool founder ecosystem bond_escrow operators archive_pool stake_pool stake_escrow founder_vest waqf burn')
    seen = set()
    for name, value in scale['accounts'].items():
        key(value)
        seen.add((name, value))
    exact(scale['supply'], 'unit total community_bps team_bps foundation_bps ecosystem_bps liquidity_bps emissions_bps pledge_claim_bps fee_rebate_bps ad_share_bps integrator_retro_bps resource')
    body = {k: v for k, v in scale['supply'].items() if k != 'resource'}
    validate_supply(body)
    need(type(scale['supply']['resource']) is str and 0 < len(scale['supply']['resource']) <= 80, 'SUPPLY_RESOURCE')
    exact(scale['vesting'], 'cliff_days duration_days milestone_fraction_bps milestones start_height')
    integer(scale['vesting']['cliff_days'], True)
    integer(scale['vesting']['duration_days'], True)
    need(scale['vesting']['cliff_days'] < scale['vesting']['duration_days'] <= 4000, 'VESTING_LENGTH')
    _bps(scale['vesting']['milestone_fraction_bps'], 'VESTING_FRACTION')
    integer(scale['vesting']['start_height'])
    _list(scale['vesting']['milestones'], 8, 'VESTING_MILESTONES')
    unlock = 0
    previous_day = -1
    for row in scale['vesting']['milestones']:
        exact(row, 'settled_per_day distinct_counterparties unlock_bps')
        integer(row['settled_per_day'], True)
        integer(row['distinct_counterparties'], True)
        _bps(row['unlock_bps'], 'VESTING_MILESTONE')
        need(row['settled_per_day'] > previous_day, 'VESTING_MILESTONES')
        previous_day = row['settled_per_day']
        unlock += row['unlock_bps']
    need(unlock == 10000, 'VESTING_MILESTONES')
    exact(scale['points'], 'season_blocks decay_after_seasons decay_bps epoch_blocks epoch_emission emission_decay_bps halving_blocks tokens_per_point_num tokens_per_point_den log_scale loyalty_bps min_bond retention_blocks diversity_cap wash_earns_zero vest_unlock_bps vest_blocks pagerank_damping_bps pledge_stake_bps')
    for name in ('season_blocks', 'decay_after_seasons', 'epoch_blocks', 'epoch_emission', 'halving_blocks', 'tokens_per_point_num', 'tokens_per_point_den', 'log_scale', 'retention_blocks', 'diversity_cap', 'vest_blocks'):
        integer(scale['points'][name], True)
    integer(scale['points']['min_bond'])
    for name in ('decay_bps', 'emission_decay_bps', 'vest_unlock_bps', 'pagerank_damping_bps'):
        _bps(scale['points'][name], 'POINTS_BPS')
    # Loyalty is a multiplier, so it starts at 1x and may sit above 10000. 20000 is 2x.
    integer(scale['points']['loyalty_bps'])
    need(10000 <= scale['points']['loyalty_bps'] <= 20000, 'POINTS_LOYALTY')
    need(scale['points']['diversity_cap'] <= 256 and scale['points']['pagerank_damping_bps'] <= 9500, 'POINTS_BOUNDS')
    need(scale['points']['wash_earns_zero'] in {True, False}, 'POINTS_WASH')
    _bps(scale['points']['pledge_stake_bps'], 'PLEDGE_STAKE')
    exact(scale['rebates'], 'honour_bps token_rebate_bps')
    _bps(scale['rebates']['honour_bps'], 'REBATE_BPS')
    _bps(scale['rebates']['token_rebate_bps'], 'REBATE_BPS')
    exact(scale['integrator'], 'fee_bps round_blocks per_owner_cap')
    _bps(scale['integrator']['fee_bps'], 'INTEGRATOR_FEE')
    integer(scale['integrator']['round_blocks'], True)
    integer(scale['integrator']['per_owner_cap'], True)
    exact(scale['governance'], 'min_increase_delay change_reason destination robustness_min_bps robustness_max_bps reserve_target')
    integer(scale['governance']['min_increase_delay'], True)
    need(scale['governance']['min_increase_delay'] >= 2, 'SCALE_NOTICE')
    need(type(scale['governance']['change_reason']) is str, 'SCALE_REASON')
    need(type(scale['governance']['destination']) is str and len(scale['governance']['destination']) >= 80, 'SCALE_DESTINATION')
    integer(scale['governance']['robustness_min_bps'])
    integer(scale['governance']['robustness_max_bps'])
    need(scale['governance']['robustness_min_bps'] <= scale['governance']['robustness_max_bps'], 'SCALE_BAND')
    integer(scale['governance']['reserve_target'])
    _list(scale['pledges'], 8, 'PLEDGE_TEMPLATES')
    kinds = set()
    for row in scale['pledges']:
        exact(row, 'id kind minimum profile')
        key(row['id'])
        need(row['kind'] in {'RUN_NODE', 'BRING_AGENTS'} and row['kind'] not in kinds, 'PLEDGE_TEMPLATE')
        kinds.add(row['kind'])
        integer(row['minimum'], True)
        need(type(row['profile']) is str and 0 < len(row['profile']) <= 80, 'PLEDGE_PROFILE')
    exact(scale['ads'], 'owner_bps integrator_bps subsidy_bps exchange_bps min_counterparties')
    total = 0
    for name in ('owner_bps', 'integrator_bps', 'subsidy_bps', 'exchange_bps'):
        _bps(scale['ads'][name], 'AD_SPLIT')
        total += scale['ads'][name]
    need(total == 10000, 'AD_SPLIT')
    integer(scale['ads']['min_counterparties'], True)
    need(scale['ads']['min_counterparties'] <= 10000, 'AD_SPLIT')
    return scale


def live_policy(state):
    """Active 0.3 policy body, or None when this chain is not running the profile."""
    policy = state.get('economic_policy') if type(state) is dict or hasattr(state, 'get') else None
    if not policy or 'active' not in policy:
        return None
    body = policy['active'].get('body') or {}
    if body.get('version') != SCALE_VERSION:
        return None
    return body


def live_meter(state):
    policy = state.get('economic_policy') if type(state) is dict or hasattr(state, 'get') else None
    if not policy or 'scale' not in policy:
        return None
    return policy['scale']


def apportion(total, weights):
    """Largest-remainder split. `weights` is a list of positive integers."""
    integer(total)
    need(type(weights) is list and len(weights) >= 1, 'APPORTION')
    denominator = sum(weights)
    need(denominator > 0, 'APPORTION')
    shares = [total * weight // denominator for weight in weights]
    rest = total - sum(shares)
    order = sorted(range(len(weights)), key=lambda i: (-(total * weights[i] % denominator), i))
    for index in order[:rest]:
        shares[index] += 1
    need(sum(shares) == total, 'APPORTION')
    return shares
