"""Owner-adopted persistent discovery, separate from historical bounded networks.

Signed publishers assert metadata, not facts or authority. Private records stay
local; this module never fetches endpoints. The owner OS and database are trusted;
retain an index head to detect rollback. Public withdrawal cannot retract copies.
"""
from collections import Counter, defaultdict
from contextlib import contextmanager
from copy import deepcopy
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import threading
import time
import unicodedata

from .crypto import canonical, digest, exact, integer, key, need, verification_key, verify

VERSION = 'urn:aap:indexed-discovery:0.1'
LABEL = 'AAP-INDEXED-DISCOVERY-0.1'
MAX_ENTRIES = 100000
MAX_RECORDS = 250000
MAX_BYTES = 256 * 1024 * 1024
FLAGS = {'execution_authorized': False, 'network_accessed': False, 'rank_is_authority': False,
         'external_facts_verified': False, 'globally_latest': False}


def _json(value):
    pending=[(value,0)];count=0
    while pending:
        v,d=pending.pop();count+=1
        need(count<=4096 and d<=16,'INDEX_COMPLEXITY')
        if v is None or type(v) is bool:continue
        if type(v) is int:integer(abs(v));continue
        if type(v) is str:
            try:need(len(v.encode('utf8'))<=8192,'INDEX_TEXT')
            except UnicodeError:raise ValueError('INDEX_UTF8') from None
        elif type(v) is list:
            need(len(v)<=128,'INDEX_ARRAY');pending.extend((x,d+1) for x in v)
        elif type(v) is dict:
            need(len(v)<=64 and all(type(k) is str and len(k)<=80 for k in v),'INDEX_OBJECT')
            pending.extend((x,d+1) for pair in v.items() for x in pair)
        else:raise ValueError('INDEX_JSON_TYPE')
    raw=json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
    need(len(raw)<=16384,'INDEX_RECORD_BOUND');return raw


def _payload(value):
    exact(value,'title summary tags endpoints metadata')
    for field,maximum in (('title',256),('summary',2048)):
        need(type(value[field]) is str and 0<len(value[field])<=maximum,'INDEX_TEXT')
    for field,maximum in (('tags',16),('endpoints',8)):
        need(type(value[field]) is list and len(value[field])<=maximum and
             all(type(x) is str and 0<len(x)<=512 for x in value[field]),'INDEX_METADATA')
        need(len(set(value[field]))==len(value[field]),'INDEX_DUPLICATE_METADATA')
    need(type(value['metadata']) is dict,'INDEX_METADATA');_json(value)


def _tokens(value):
    return re.findall(r'[^\W_]+',unicodedata.normalize('NFKC',value).casefold(),re.UNICODE)[:512]


def prepare(*,context,publisher,subject,title,summary,tags=None,endpoints=None,metadata=None,
            revision=0,previous=None,issued_at=0,expires=1,visibility='PUBLIC'):
    data={'title':title,'summary':summary,'tags':[] if tags is None else deepcopy(tags),
          'endpoints':[] if endpoints is None else deepcopy(endpoints),'metadata':{} if metadata is None else deepcopy(metadata)}
    _payload(data)
    body={'version':VERSION,'context':context,'publisher':publisher,'subject':deepcopy(subject),
          'revision':revision,'previous':[] if previous is None else deepcopy(previous),'issued_at':issued_at,
          'expires':expires,'visibility':visibility,'payload':base64.b64encode(_json(data)).decode('ascii')}
    _body(body)
    return {'body':body,'id':identifier(body),'assent_payload':{'label':LABEL,'body':deepcopy(body)},
            'status':'UNSIGNED_METADATA_ASSERTION',**FLAGS}


def _body(body):
    exact(body,'version context publisher subject revision previous issued_at expires visibility payload')
    need(body['version']==VERSION,'INDEX_PROFILE');key(body['context']);verification_key(body['publisher'])
    need(type(body['publisher']) is str,'INDEX_ED25519_ONLY')
    exact(body['subject'],'kind id');key(body['subject']['id'])
    kind=body['subject']['kind'];need(type(kind) is str and re.fullmatch('[A-Za-z][A-Za-z0-9_.:-]{0,79}',kind),'INDEX_SUBJECT')
    integer(body['revision']);integer(body['issued_at']);integer(body['expires'])
    need(body['issued_at']<body['expires'],'INDEX_WINDOW')
    parents=body['previous'];need(type(parents) is list and len(parents)<=16,'INDEX_PARENTS')
    for ref in parents:key(ref)
    need(parents==sorted(set(parents)) and ((body['revision']==0)==(not parents)),'INDEX_PARENTS')
    need(body['visibility'] in ('PUBLIC','OWNER_PRIVATE','WITHDRAWN'),'INDEX_VISIBILITY')
    try:
        need(type(body['payload']) is str and len(body['payload'])<=24000,'INDEX_PAYLOAD')
        raw=base64.b64decode(body['payload'],validate=True);data=json.loads(raw)
        need(_json(data)==raw and base64.b64encode(raw).decode('ascii')==body['payload'],'INDEX_PAYLOAD')
    except (ValueError,UnicodeError,RecursionError):raise ValueError('INDEX_PAYLOAD') from None
    _payload(data);canonical(body);return data


def identifier(body):
    _body(body);return digest(LABEL,body)


def verify_record(record,*,context,trusted_publishers,now):
    exact(record,'body signature');integer(now);key(context)
    need(type(trusted_publishers) is list and 0<len(trusted_publishers)<=256,'INDEX_PUBLISHERS')
    for publisher in trusted_publishers:verification_key(publisher)
    body=record['body'];data=_body(body)
    need(body['context']==context,'INDEX_CONTEXT')
    need(body['publisher'] in trusted_publishers,'INDEX_PUBLISHER_NOT_ADOPTED')
    need(body['issued_at']<=now<body['expires'],'INDEX_EXPIRED_OR_FUTURE')
    verify(body['publisher'],LABEL,body,record['signature'])
    return {'id':identifier(body),'subject':deepcopy(body['subject']),'data':data,
            'signature':'VERIFIED_PUBLISHER_ASSERTION','source_independence':'NOT_ESTABLISHED',**FLAGS}


def _logical(body):
    return digest('AAP-INDEX-LOGICAL-0.1',{k:body[k] for k in ('context','publisher','subject')})


class DiscoveryIndex:
    """Bounded SQLite index; independent instances serialize with BEGIN IMMEDIATE.

    Hash-chained record ids preserve a retained owner head. No encryption, peer
    consensus, automatic federation, DNS lookup or private-record publication.
    """
    def __init__(self,directory,*,context,trusted_publishers,expected_head=None,clock=None):
        key(context);need(type(trusted_publishers) is list and 0<len(trusted_publishers)<=256,'INDEX_PUBLISHERS')
        for publisher in trusted_publishers:verification_key(publisher)
        self.context=context;self.publishers=sorted(set(trusted_publishers));self._lock=threading.RLock();self._fd=None
        need(clock is None or callable(clock),'INDEX_CLOCK');self._clock=time.time if clock is None else clock
        policy=digest('AAP-INDEX-POLICY-0.1',{'context':context,'publishers':self.publishers})
        if directory is None:
            self.path=None;path=':memory:'
        else:
            from .request_workspace import _directory
            self.path,self._fd=_directory(directory);path=str(self.path/'index.sqlite')
            try:
                info=os.stat('index.sqlite',dir_fd=self._fd,follow_symlinks=False)
            except FileNotFoundError:
                try:
                    fd=os.open('index.sqlite',os.O_CREAT|os.O_EXCL|os.O_RDWR|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=self._fd)
                    try:info=os.fstat(fd)
                    finally:os.close(fd)
                except BaseException:
                    os.close(self._fd);self._fd=None;raise
            try:
                need(stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1 and stat.S_IMODE(info.st_mode)&0o077==0,'INDEX_PRIVATE_FILE')
                self._inode=(info.st_dev,info.st_ino)
            except BaseException:
                os.close(self._fd);self._fd=None;raise
        try:
            self._files()
            self.db=sqlite3.connect(path,isolation_level=None,check_same_thread=False,timeout=10)
            self._files()
            from covenant_language.safe_io import durable_sqlite
            journal=self.db.execute('PRAGMA journal_mode').fetchone()[0].upper()
            durable_sqlite(self.db,journal='DELETE' if self.path is None else journal)
            self._files();self.db.execute('PRAGMA temp_store=MEMORY')
            self.db.executescript('''CREATE TABLE IF NOT EXISTS meta(policy TEXT,head TEXT,count INTEGER,bytes INTEGER);
CREATE TABLE IF NOT EXISTS records(seq INTEGER PRIMARY KEY,id TEXT UNIQUE,logical TEXT,revision INTEGER,record BLOB,previous TEXT,head TEXT);
CREATE TABLE IF NOT EXISTS current(logical TEXT PRIMARY KEY,revision INTEGER,heads TEXT,conflict INTEGER);
CREATE TABLE IF NOT EXISTS terms(token TEXT,id TEXT,weight INTEGER,PRIMARY KEY(token,id));
CREATE INDEX IF NOT EXISTS index_token ON terms(token,id);
CREATE INDEX IF NOT EXISTS index_logical ON records(logical,revision);
CREATE INDEX IF NOT EXISTS index_record_id ON records(id);''')
            self.db.execute('BEGIN IMMEDIATE')
            row=self.db.execute('SELECT policy,head FROM meta').fetchone()
            if row is None:self.db.execute('INSERT INTO meta VALUES (?,?,0,0)',(policy,'0'*64))
            else:need(row[0]==policy,'INDEX_OWNER_POLICY_CHANGED')
            self.db.commit()
            self._files()
            if expected_head is not None:need(self.head()==expected_head,'INDEX_ROLLBACK_OR_FORK')
        except BaseException:
            if hasattr(self,'db'):self.db.close()
            if self._fd is not None:os.close(self._fd);self._fd=None
            raise

    def now(self):
        value=self._clock();need(type(value) in (int,float) and value>=0 and value<2**53,'INDEX_CLOCK');return int(value)

    def close(self):
        self.db.close()
        if self._fd is not None:os.close(self._fd);self._fd=None

    def _files(self):
        if self.path is None:return
        if getattr(self,'db',None) is not None:
            mode=self.db.execute('PRAGMA journal_mode').fetchone()[0].upper()
            need(mode in ('WAL','DELETE','TRUNCATE','PERSIST'),'INDEX_NONATOMIC_JOURNAL')
        need((os.stat(self.path,follow_symlinks=False).st_dev,os.stat(self.path,follow_symlinks=False).st_ino)==
             (os.fstat(self._fd).st_dev,os.fstat(self._fd).st_ino),'INDEX_DIRECTORY_REPLACED')
        for name in ('index.sqlite','index.sqlite-journal','index.sqlite-wal','index.sqlite-shm'):
            try:info=os.stat(name,dir_fd=self._fd,follow_symlinks=False)
            except FileNotFoundError:
                need(name!='index.sqlite','INDEX_FILE_REPLACED');continue
            need(stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1 and
                 stat.S_IMODE(info.st_mode)&0o077==0,'INDEX_PRIVATE_FILE')
            if name=='index.sqlite':need((info.st_dev,info.st_ino)==self._inode,'INDEX_FILE_REPLACED')

    def head(self):
        with self._lock:
            self._files();return self.db.execute('SELECT head FROM meta').fetchone()[0]

    @contextmanager
    def _snapshot(self):
        # A Python lock serializes one instance only. SQLite must bind the head,
        # candidates and signed records to one view across independent instances.
        self.db.execute('BEGIN')
        try:
            yield
        finally:
            self.db.rollback()

    def ingest(self,record,*,now):
        integer(now)
        record=deepcopy(record);raw=canonical(record);need(len(raw)<=32768,'INDEX_RECORD_BOUND')
        body=record['body'];ref=identifier(body);logical=_logical(body)
        # A retained exact retry is not a new freshness/admission decision.
        with self._lock:
            self._files();retained=self.db.execute('SELECT record FROM records WHERE id=?',(ref,)).fetchone()
            if retained is not None:
                verify_record(record,context=self.context,trusted_publishers=self.publishers,now=body['issued_at'])
                need(retained[0]==raw,'INDEX_RETAINED_RECORD_CHANGED')
                return {'id':ref,'status':'ALREADY_RETAINED','head':self.head(),'usable_at_supplied_time':body['issued_at']<=now<body['expires'],**FLAGS}
        checked=verify_record(record,context=self.context,trusted_publishers=self.publishers,now=now)
        with self._lock:
            self._files();self.db.execute('BEGIN IMMEDIATE')
            try:
                if self.db.execute('SELECT 1 FROM records WHERE id=?',(ref,)).fetchone():
                    self.db.rollback();return {'id':ref,'status':'ALREADY_RETAINED','head':self.head(),**FLAGS}
                previous,count,size=self.db.execute('SELECT head,count,bytes FROM meta').fetchone()
                need(count<MAX_RECORDS and size+len(raw)<=MAX_BYTES,'INDEX_STORAGE_QUOTA')
                current=self.db.execute('SELECT revision,heads,conflict FROM current WHERE logical=?',(logical,)).fetchone()
                conflict=False;heads=[ref]
                if current is None:
                    need(body['revision']==0,'INDEX_PARENT_REQUIRED')
                    need(self.db.execute('SELECT count(*) FROM current').fetchone()[0]<MAX_ENTRIES,'INDEX_ENTRY_QUOTA')
                else:
                    revision,oldheads,_=current;oldheads=json.loads(oldheads)
                    if body['revision']<=revision:
                        ancestor=self.db.execute('SELECT record FROM records WHERE logical=? AND revision=? ORDER BY seq LIMIT 1',(logical,body['revision'])).fetchone()
                        need(ancestor is not None and body['previous']==json.loads(ancestor[0])['body']['previous'],'INDEX_DIVERGENT_ANCESTRY')
                        heads=sorted(set(oldheads+[ref]));need(len(heads)<=16,'INDEX_EQUIVOCATION_BOUND');conflict=True
                    else:need(body['revision']==revision+1 and body['previous']==sorted(oldheads),'INDEX_PARENT_OR_REVISION')
                head=digest('AAP-INDEX-HEAD-0.1',{'previous':previous,'record':ref,'sequence':count+1})
                self.db.execute('INSERT INTO records VALUES (?,?,?,?,?,?,?)',(count+1,ref,logical,body['revision'],raw,previous,head))
                if current:
                    for oldref in json.loads(current[1]):self.db.execute('DELETE FROM terms WHERE id=?',(oldref,))
                self.db.execute('INSERT OR REPLACE INTO current VALUES (?,?,?,?)',(logical,max(body['revision'],current[0]) if current else body['revision'],json.dumps(heads),int(conflict)))
                if not conflict and body['visibility']!='WITHDRAWN':
                    data=checked['data'];weights=Counter()
                    for text,weight in ((data['title'],3),(data['summary'],1),(' '.join(data['tags']),4)):
                        for token in set(_tokens(text)):weights[token]+=weight
                    self.db.executemany('INSERT INTO terms VALUES (?,?,?)',[(t,ref,w) for t,w in weights.items()])
                self.db.execute('UPDATE meta SET head=?,count=?,bytes=?',(head,count+1,size+len(raw)))
                self._files();self.db.commit()
                return {'id':ref,'status':'QUARANTINED_EQUIVOCATION' if conflict else 'INDEXED','head':head,**FLAGS}
            except BaseException:self.db.rollback();raise

    def search(self,query,*,now,limit=20,cursor=None,public_only=True):
        need(type(query) is str and len(query)<=512,'INDEX_QUERY');integer(now)
        need(type(limit) is int and 1<=limit<=100 and type(public_only) is bool,'INDEX_PAGE_BOUND')
        with self._lock, self._snapshot():
            self._files();head=self.head();tokens=sorted(set(_tokens(query)))[:32]
            selector=digest('AAP-INDEX-QUERY-0.1',{'query':base64.b64encode(query.encode('utf8')).decode(),'now':now,'public_only':public_only,'context':self.context})
            after=0
            if cursor is not None:
                exact(cursor,'head query offset as_of');need(cursor['head']==head and cursor['query']==selector,'INDEX_STALE_CURSOR')
                integer(cursor['offset']);need(cursor['offset']<=MAX_ENTRIES,'INDEX_CURSOR');after=cursor['offset']
            # SQL bounds candidate memory. Verify signed records before returning; database is owner-local.
            if tokens:
                placeholders=','.join('?' for _ in tokens)
                sql=f"SELECT r.id,r.logical,r.revision,SUM(t.weight) AS score FROM terms t JOIN records r ON r.id=t.id JOIN current c ON c.logical=r.logical WHERE c.conflict=0 AND json_array_length(c.heads)=1 AND json_extract(c.heads,'$[0]')=r.id AND t.token IN ({placeholders}) GROUP BY r.id ORDER BY score DESC,r.id LIMIT ? OFFSET ?"
                candidates=self.db.execute(sql,(*tokens,MAX_ENTRIES,0))
            else:
                candidates=self.db.execute('SELECT r.id,r.logical,r.revision,0 FROM current c JOIN records r ON r.id=json_extract(c.heads,\'$[0]\') WHERE c.conflict=0 ORDER BY r.id')
            rows=[];eligible=0;more=False
            for ref,logical,revision,score in candidates:
                raw=self.db.execute('SELECT record FROM records WHERE id=?',(ref,)).fetchone()[0]
                record=json.loads(raw);body=record['body']
                if not body['issued_at']<=now<body['expires'] or body['visibility']=='WITHDRAWN' or public_only and body['visibility']!='PUBLIC':continue
                checked=verify_record(record,context=self.context,trusted_publishers=self.publishers,now=now)
                need(checked['id']==ref and _logical(body)==logical and body['revision']==revision,'INDEX_STORED_RECORD_CHANGED')
                if tokens:
                    data=checked['data'];actual=0
                    for text,weight in ((data['title'],3),(data['summary'],1),(' '.join(data['tags']),4)):
                        actual+=len(set(_tokens(text))&set(tokens))*weight
                    need(actual==score,'INDEX_SCORE_CHANGED')
                if eligible<after:eligible+=1;continue
                if len(rows)==limit:more=True;break
                rows.append({'id':checked['id'],'subject':checked['subject'],'publisher':body['publisher'],
                    'revision':body['revision'],'score':score,'title':checked['data']['title'],'summary':checked['data']['summary'],
                    'record':record});eligible+=1
            return {'results':rows,'head':head,'next_cursor':{'head':head,'query':selector,'offset':after+len(rows),'as_of':now} if more else None,
                    'as_of':now,'clock_basis':'CALLER_SELECTED_METADATA_SNAPSHOT; NOT_PROOF_OF_CURRENTNESS',
                    'ranking':'LEXICAL_METADATA_RELEVANCE; SOURCE_ASSERTIONS_ONLY','public_only':public_only,
                    'privacy':'OWNER_LOCAL_PLAINTEXT; PUBLIC_EXPORT_ONLY_BY_DEFAULT',**FLAGS}


def search_preview(records,query,*,context,trusted_publishers,now,limit=20):
    need(type(records) is list and len(records)<=256,'INDEX_PREVIEW_BOUND')
    index=DiscoveryIndex(None,context=context,trusted_publishers=trusted_publishers)
    try:
        for record in records:index.ingest(record,now=now)
        return index.search(query,now=now,limit=limit)
    finally:index.close()


def sparse_rank(nodes,edges,seeds,*,damping_bps=8500,iterations=30,edge_budget=500000,limit=100,offset=0):
    """Sparse deterministic fixed-point personalized PageRank, not reputation truth.

    Bounded separately from historical 256-node rank. Exact unit mass is conserved
    each step; dangling mass returns only to adopted seeds. Equal distribution
    uses deterministic quotient/remainder, with no floating-point comparison.
    """
    need(type(nodes) is list and 0<len(nodes)<=100000 and all(type(n) is str for n in nodes) and nodes==sorted(set(nodes)),'INDEX_RANK_NODES')
    need(type(limit) is int and 1<=limit<=1000 and type(offset) is int and 0<=offset<=len(nodes),'INDEX_RANK_PAGE')
    for node in nodes:key(node)
    need(type(seeds) is dict and 0<len(seeds)<=256 and set(seeds)<=set(nodes),'INDEX_RANK_SEEDS')
    for value in seeds.values():integer(value,True)
    need(type(edge_budget) is int and 1<=edge_budget<=500000 and type(edges) is list and len(edges)<=edge_budget,'INDEX_RANK_EDGES')
    need(type(iterations) is int and 1<=iterations<=100 and type(damping_bps) is int and 0<=damping_bps<=9500,'INDEX_RANK_BUDGET')
    need(len(nodes)*iterations+len(edges)*iterations<=10000000,'INDEX_RANK_WORK_BOUND')
    adjacency=defaultdict(set);population=set(nodes)
    for edge in edges:
        need(type(edge) is list and len(edge)==2 and all(type(n) is str and n in population for n in edge),'INDEX_RANK_EDGE')
        if edge[0]!=edge[1]:adjacency[edge[0]].add(edge[1])
    from .discovery_rank import allocate
    mass=allocate(10**9,seeds);seed_weights=dict(seeds);prior={}
    for _ in range(iterations):
        nxt=defaultdict(int);restart=0
        for source,amount in sorted(mass.items()):
            continuation=amount*damping_bps//10000;restart+=amount-continuation;targets=sorted(adjacency[source])
            if not targets:restart+=continuation;continue
            quotient,remainder=divmod(continuation,len(targets))
            for i,target in enumerate(targets):nxt[target]+=quotient+(i<remainder)
        for target,amount in allocate(restart,seed_weights).items():nxt[target]+=amount
        prior=mass;mass=dict(nxt);need(sum(mass.values())==10**9,'INDEX_RANK_MASS')
    difference=sum(abs(mass.get(n,0)-prior.get(n,0)) for n in set(mass)|set(prior))
    ordered=sorted(nodes,key=lambda n:(-mass.get(n,0),n));selected=ordered[offset:offset+limit]
    hasher=hashlib.sha256(b'AAP-SPARSE-RANK-REQUEST-0.1\0')
    for chunk in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=True).iterencode({'nodes':nodes,'edges':edges,'seeds':seeds,'damping_bps':damping_bps,'iterations':iterations}):
        hasher.update(chunk.encode('ascii'))
    graph=hasher.hexdigest()
    return {'profile':VERSION,'graph':graph,'mass':{n:mass.get(n,0) for n in selected},'mass_total':10**9,'iterations':iterations,
            'nodes':len(nodes),'offset':offset,'next_offset':offset+len(selected) if offset+len(selected)<len(nodes) else None,
            'omitted_mass':10**9-sum(mass.get(n,0) for n in selected),
            'last_step_l1_ppb':difference,'converged':difference==0,'rank_is_reputation':False,
            'source_independence':'NOT_ESTABLISHED','seeds':'OWNER_ADOPTED; NO_UNANCHORED_RING_REACHABILITY',**FLAGS}


def describe():
    return {'version':VERSION,'signature_label':LABEL,'entry':'prepare then owner-sign exact label/body; ingest through owner SDK DiscoveryIndex',
        'payload_fields':['title','summary','tags','endpoints','metadata'],'visibility':['PUBLIC','OWNER_PRIVATE','WITHDRAWN'],
        'records':'Exact revision parents; conflicting signed siblings quarantine subject until successor covers every retained head.',
        'index_bounds':{'logical_entries':MAX_ENTRIES,'signed_records':MAX_RECORDS,'stored_record_bytes':MAX_BYTES,'page_size':100},
        'rank_bounds':{'nodes':100000,'edges':500000,'work_units':10000000},
        'tool_carrier_bounds':'JSON tools: at most 100000 edges and 100000 graph nodes; the combined 16 MB / 500000 JSON-node limits may bind earlier. The SDK supports larger separately bounded graphs.',
        'boundary':'LOCAL_PERSISTENT_INDEX_AND_SPARSE_RANK; NOT_DHT_OR_GLOBAL_REPUTATION_CONSENSUS; NO_ENDPOINT_FETCH',**FLAGS}
