"""Owner-adopted mandate wallet and atomic local resource reservations.

This successor application profile changes no native ledger rules. One private
SQLite custody domain serializes all participating agents. External providers,
other wallets and other hosts do not join its transaction. The owner must route
every protected action through the gate, provide a trusted clock/current grant
state, and retain independent checkpoints. No key or credential is stored here.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib

from . import access_mechanisms as access
from .adapters import manifest_id
from .crypto import exact, integer, key, need, verification_key, verify
from .workflow_store import WorkflowStore, canonical, identifier

VERSION = 'covenant-mandate-wallet/0.1'
INTENT = 'covenant-reliance-intent/0.1'
RECOVERY = 'covenant-reliance-recovery/0.1'
WALLET_LABEL = 'COVENANT-MANDATE-WALLET-0.1'
INTENT_LABEL = 'COVENANT-RELIANCE-INTENT-0.1'
RECOVERY_LABEL = 'COVENANT-RELIANCE-RECOVERY-0.1'
OPERATION = 'reliance.execute'
ZERO = '0' * 64


def _amounts(value, positive=False):
    need(type(value) is dict and 1 <= len(value) <= 32, 'RELIANCE_RESOURCES')
    for resource, amount in value.items():
        need(type(resource) is str and 0 < len(resource) <= 128, 'RELIANCE_RESOURCE')
        integer(amount, positive)


def _obligations(value):
    need(type(value) in (tuple,list) and len(value) <= 128, 'RELIANCE_OBLIGATIONS')
    for item in value:
        exact(item, 'agreement obligation evidence deadline status')
        for field in ('agreement','obligation'): key(item[field])
        need(type(item['evidence']) is list and len(item['evidence']) <= 32, 'RELIANCE_EVIDENCE')
        for ref in item['evidence']: key(ref)
        integer(item['deadline']); need(item['status'] in {'OPEN','DISPUTED','CLAIMED_COMPLETE'}, 'RELIANCE_OBLIGATION_STATUS')


def validate_policy(value):
    canonical(value)
    exact(value, 'version domain principal not_before expires limits per_action adapters nonce')
    need(value['version'] == VERSION, 'RELIANCE_POLICY_VERSION')
    key(value['domain']); key(value['nonce'])
    from .crypto import resolve_party
    resolve_party(value['principal'], 'policy.principal')
    integer(value['not_before']); integer(value['expires'], True)
    need(value['not_before'] < value['expires'], 'RELIANCE_INTERVAL')
    _amounts(value['limits'], True); _amounts(value['per_action'], True)
    need(set(value['per_action']) == set(value['limits']) and all(
        value['per_action'][r] <= amount for r, amount in value['limits'].items()), 'RELIANCE_PER_ACTION')
    need(type(value['adapters']) is list and 1 <= len(value['adapters']) <= 32
         and value['adapters'] == sorted(set(value['adapters'])), 'RELIANCE_ADAPTERS')
    for ref in value['adapters']: key(ref)
    return True


def wallet_id(policy):
    validate_policy(policy)
    return identifier(WALLET_LABEL, policy)


def policy_payload(policy):
    return {'label': WALLET_LABEL, 'body': {'wallet': wallet_id(policy), 'domain': policy['domain']},
            'execution_authorized': False}


def validate_intent(value):
    canonical(value)
    exact(value, 'version wallet subject adapter effect request_hash allocations not_before expires nonce')
    need(value['version'] == INTENT, 'RELIANCE_INTENT_VERSION')
    for name in ('wallet', 'adapter', 'effect', 'request_hash', 'nonce'): key(value[name])
    verification_key(value['subject']); _amounts(value['allocations'], True)
    integer(value['not_before']); integer(value['expires'], True)
    need(value['not_before'] < value['expires'], 'RELIANCE_INTERVAL')
    return True


def intent_id(value):
    validate_intent(value)
    return identifier(INTENT_LABEL, value)


def intent_payload(value):
    return {'label': INTENT_LABEL, 'body': {'intent': intent_id(value), 'wallet': value['wallet']},
            'execution_authorized': False}


def draft_intent(policy, subject, adapter, effect, request_hash, allocations, not_before, expires, nonce):
    from .crypto import FieldError, resolve_party
    resolve_party(subject, 'subject')
    value = dict(version=INTENT, wallet=wallet_id(policy), subject=deepcopy(subject), adapter=adapter,
                 effect=effect, request_hash=request_hash, allocations=deepcopy(allocations),
                 not_before=not_before, expires=expires, nonce=nonce)
    for resource, amount in value['allocations'].items():
        cap = policy['per_action'].get(resource)
        if cap is None or amount > cap:
            shown = 'absent' if cap is None else cap
            raise FieldError(
                'RELIANCE_PER_ACTION', f'allocations.{resource}',
                f'integer 1..{cap}' if cap is not None else 'a resource named in policy.per_action',
                f'Refuse this intent. allocations.{resource} is {amount} and the per-action cap is {shown}. '
                f'Lower the allocation. MandateWallet.reserve is what holds funds, and it will not hold an over-cap intent.')
    return {'intent': value, 'id': intent_id(value), **intent_payload(value),
            'grant_target': {'kind': 'mandate-wallet', 'id': wallet_id(policy)},
            'grant_operation': OPERATION, 'capability': 'adapter:' + adapter}


def _verify_policy(envelope):
    exact(envelope, 'policy signature')
    policy = envelope['policy']; payload = policy_payload(policy)
    verify(policy['principal'], payload['label'], payload['body'], envelope['signature'])
    return policy


def _verify_intent(envelope):
    exact(envelope, 'intent signature')
    value = envelope['intent']; payload = intent_payload(value)
    verify(value['subject'], payload['label'], payload['body'], envelope['signature'])
    return value


def _authority(policy, intent, chain, now, view):
    need(intent['wallet'] == wallet_id(policy) and intent['adapter'] in policy['adapters'], 'RELIANCE_SCOPE')
    need(policy['not_before'] <= now < policy['expires'] and intent['not_before'] <= now < intent['expires']
         and policy['not_before'] <= intent['not_before'] and intent['expires'] <= policy['expires'], 'RELIANCE_EXPIRED')
    exact(view, 'as_of valid_until revoked successors')
    integer(view['as_of']); integer(view['valid_until'])
    need(view['as_of'] <= now < view['valid_until'], 'RELIANCE_REVOCATION_STALE')
    access.verify_chain(chain, context=policy['domain'], target={'kind':'mandate-wallet','id':wallet_id(policy)},
        operation=OPERATION, subject=intent['subject'], capability='adapter:' + intent['adapter'],
        trusted_issuers=[policy['principal']], now=now, revoked=view['revoked'], successors=view['successors'])


def _state(history, policy):
    """Replay the sole source of balances; there is no mutable balance cache."""
    rows = {}; nonces = set(); clock = 0
    for event in history:
        body = event['body']; exact(body, 'kind task value')
        kind, ref, value = body['kind'], body['task'], body['value']
        need(kind in {'RELIANCE_RESERVE', 'RELIANCE_START', 'RELIANCE_OBSERVE', 'RELIANCE_CANCEL'},
             'RELIANCE_HISTORY_KIND')
        exact(value, 'at data'); integer(value['at'])
        need(value['at'] >= clock, 'RELIANCE_CLOCK_REWIND'); clock = value['at']
        data = value['data']
        if kind == 'RELIANCE_RESERVE':
            exact(data, 'envelope chain grant_state')
            intent = _verify_intent(data['envelope'])
            _authority(policy, intent, data['chain'], value['at'], data['grant_state'])
            need(intent_id(intent) == ref and ref not in rows and intent['nonce'] not in nonces,
                 'RELIANCE_HISTORY_REPLAY')
            need(not any(r['intent']['effect'] == intent['effect'] and r['state'] != 'CANCELLED'
                         for r in rows.values()), 'RELIANCE_EFFECT_CONFLICT')
            nonces.add(intent['nonce'])
            rows[ref] = dict(intent=intent, chain=deepcopy(data['chain']), state='HELD', receipt=None)
        else:
            need(ref in rows, 'RELIANCE_HISTORY_MISSING'); row = rows[ref]
            if kind == 'RELIANCE_START':
                need(row['state'] == 'HELD', 'RELIANCE_HISTORY_TRANSITION')
                _authority(policy, row['intent'], row['chain'], value['at'], data)
                row['state'] = 'STARTED'
            elif kind == 'RELIANCE_CANCEL':
                need(row['state'] == 'HELD' and data == {}, 'RELIANCE_HISTORY_TRANSITION')
                row['state'] = 'CANCELLED'
            else:
                need(row['state'] in {'STARTED', 'UNKNOWN', 'OBSERVED'}, 'RELIANCE_HISTORY_TRANSITION')
                exact(data, 'status output_hash assurance receipt_hash')
                need(type(data['status']) is str and type(data['assurance']) is str, 'RELIANCE_RECEIPT')
                key(data['receipt_hash'])
                if data['output_hash'] is not None: key(data['output_hash'])
                need(data['status'] != 'OBSERVED' or data['output_hash'] is not None, 'RELIANCE_RECEIPT')
                # An observed outcome cannot be downgraded or silently replaced.
                if row['state'] == 'OBSERVED':
                    need(data['status'] == 'OBSERVED' and data['output_hash'] == row['receipt']['output_hash'],
                         'RELIANCE_OBSERVED_CHANGED')
                row['state'] = 'OBSERVED' if data['status'] == 'OBSERVED' else 'UNKNOWN'
                row['receipt'] = deepcopy(data)
    return rows, clock


def _balances(policy, rows):
    used = {r: 0 for r in policy['limits']}
    for row in rows.values():
        intent = row['intent']
        need(intent['wallet'] == wallet_id(policy) and intent['adapter'] in policy['adapters'], 'RELIANCE_SCOPE')
        for resource, amount in intent['allocations'].items():
            need(resource in used and amount <= policy['per_action'][resource], 'RELIANCE_ALLOCATION')
            if row['state'] != 'CANCELLED': used[resource] += amount
    need(all(used[r] <= limit for r, limit in policy['limits'].items()), 'RELIANCE_BUDGET_EXCEEDED')
    return {r: {'limit': limit, 'allocated': used[r], 'available': limit - used[r]}
            for r, limit in policy['limits'].items()}


class MandateWallet:
    """Trusted owner API. Only the GatedAdapter belongs on an execution route.

    current_state() is owner installed and returns a time-bounded revocation view.
    The caller must ensure completeness. This code cannot discover hidden grants
    or detect a wholesale database rollback without an independent retained head.
    Resource amounts are owner-attested exposure; they are not bank balances.
    """
    def __init__(self, directory, envelope, *, domain, clock, current_state, adapters):
        self.envelope = deepcopy(envelope); self.policy = deepcopy(_verify_policy(envelope))
        key(domain); need(self.policy['domain'] == domain, 'RELIANCE_DOMAIN')
        need(callable(clock) and callable(current_state), 'RELIANCE_OWNER_STATE')
        self.id = wallet_id(self.policy); self.clock = clock; self.current_state = current_state
        self.adapters = adapters
        need(all(ref in adapters.describe() for ref in self.policy['adapters']), 'RELIANCE_ADAPTER_NOT_INSTALLED')
        self._pin = self.id
        self.store = WorkflowStore(directory, {'wallet': self.id, 'domain': domain, 'version': VERSION})

    def _now(self, previous=0):
        need(wallet_id(self.policy) == self._pin, 'RELIANCE_POLICY_CHANGED')
        now = self.clock(); integer(now)
        need(now >= previous, 'RELIANCE_CLOCK_REWIND')
        return now

    def _authorize(self, intent, chain, now):
        view = deepcopy(self.current_state())
        _authority(self.policy, intent, chain, now, view)
        return view

    @contextmanager
    def _transaction(self):
        self.store.db.execute('BEGIN IMMEDIATE')
        try:
            history = self.store.events(); rows, previous = _state(history, self.policy)
            _balances(self.policy, rows)
            yield history, rows, self._now(previous)
            self.store.db.execute('COMMIT')
        except BaseException:
            self.store.db.execute('ROLLBACK'); raise

    def _append(self, history, kind, ref, at, data):
        body = dict(kind='RELIANCE_' + kind, task=ref, value=dict(at=at, data=deepcopy(data)))
        raw = canonical(body); seq = len(history) + 1; prior = history[-1]['id'] if history else ZERO
        need(seq <= 20000 and sum(len(canonical(e['body'])) for e in history) + len(raw) <= 128*1024*1024,
             'RELIANCE_STORAGE_QUOTA')
        event = dict(sequence=seq, previous=prior, body=body)
        ref = identifier('COVENANT-WORKFLOW-EVENT-0.1', event)
        self.store.db.execute('INSERT INTO events VALUES (?,?,?,?)', (seq, prior, ref, raw))

    def reserve(self, envelope, chain):
        envelope = deepcopy(envelope); chain = deepcopy(chain); intent = _verify_intent(envelope)
        ref = intent_id(intent)
        with self._transaction() as (history, rows, now):
            if ref in rows:
                need(rows[ref]['state'] != 'CANCELLED', 'RELIANCE_CANCELLED')
                return {'id':ref, 'state':rows[ref]['state'], 'replayed':True}
            grant_state = self._authorize(intent, chain, now)
            need(not any(r['intent']['nonce'] == intent['nonce'] for r in rows.values()), 'RELIANCE_NONCE_REPLAY')
            need(not any(r['intent']['effect'] == intent['effect'] and r['state'] != 'CANCELLED'
                         for r in rows.values()), 'RELIANCE_EFFECT_CONFLICT')
            rows[ref] = dict(intent=intent, chain=chain, state='HELD', receipt=None)
            balances = _balances(self.policy, rows)
            self._append(history, 'RESERVE', ref, now, dict(envelope=envelope, chain=chain, grant_state=grant_state))
        return {'id':ref, 'state':'HELD', 'balances':balances, 'replayed':False}

    def cancel(self, ref):
        """Owner-only release before dispatch. Never releases STARTED/UNKNOWN."""
        key(ref)
        with self._transaction() as (history, rows, now):
            need(ref in rows, 'RELIANCE_MISSING')
            if rows[ref]['state'] == 'CANCELLED': return {'id':ref, 'state':'CANCELLED'}
            need(rows[ref]['state'] == 'HELD', 'RELIANCE_CANNOT_RELEASE_AFTER_START')
            self._append(history, 'CANCEL', ref, now, {})
        return {'id':ref, 'state':'CANCELLED'}

    def execute(self, envelope, chain, effect, request, *, crash=None):
        """Commit START before dispatch; retries only observe, even after a crash."""
        request = deepcopy(request)
        intent = deepcopy(_verify_intent(envelope)); key(effect)
        need(intent['effect'] == effect and intent['request_hash'] == hashlib.sha256(canonical(request)).hexdigest(),
             'RELIANCE_REQUEST_CHANGED')
        ref = intent_id(intent); self.reserve(envelope, chain)
        dispatch = False
        with self._transaction() as (history, rows, now):
            row = rows[ref]; need(row['state'] != 'CANCELLED', 'RELIANCE_CANCELLED')
            if row['state'] == 'HELD':
                grant_state = self._authorize(intent, row['chain'], now)
                self._append(history, 'START', ref, now, grant_state); dispatch = True
        if not dispatch: return self.observe(ref)
        # Deliberate crash seam: absence of an effect does not grant retry rights.
        if crash == 'before_dispatch': raise RuntimeError('RELIANCE_INJECTED_BEFORE_DISPATCH')
        receipt = self.adapters.get(intent['adapter']).execute(effect, deepcopy(request), crash=crash)
        self._record(ref, receipt)
        return receipt

    def _record(self, ref, receipt):
        need(type(receipt) is dict and type(receipt.get('status')) is str, 'RELIANCE_RECEIPT')
        compact = dict(status=receipt['status'], output_hash=receipt.get('output_hash'),
                       assurance=receipt.get('assurance', 'OWNER_ADAPTER_OBSERVATION'),
                       receipt_hash=identifier('COVENANT-RELIANCE-RECEIPT-0.1', receipt))
        # Validate before mutation, including strict output-hash typing.
        if compact['output_hash'] is not None: key(compact['output_hash'])
        need(type(compact['assurance']) is str and (compact['status'] != 'OBSERVED' or compact['output_hash'] is not None),
             'RELIANCE_RECEIPT')
        with self._transaction() as (history, rows, now):
            need(ref in rows and rows[ref]['state'] in {'STARTED','UNKNOWN','OBSERVED'}, 'RELIANCE_NOT_STARTED')
            row = rows[ref]
            if row['state'] == 'OBSERVED':
                need(compact['status'] == 'OBSERVED' and compact['output_hash'] == row['receipt']['output_hash'],
                     'RELIANCE_OBSERVED_CHANGED')
                return
            self._append(history, 'OBSERVE', ref, now, compact)

    def observe(self, ref):
        """Owner-authorized inspection can continue after a grant expires."""
        key(ref)
        with self._transaction() as (_, rows, _now):
            need(ref in rows and rows[ref]['state'] in {'STARTED','UNKNOWN','OBSERVED'}, 'RELIANCE_NOT_STARTED')
            intent = deepcopy(rows[ref]['intent'])
        receipt = self.adapters.get(intent['adapter']).observe(intent['effect'])
        self._record(ref, receipt)
        return receipt

    def inspect(self):
        with self._transaction() as (history, rows, now):
            return {'wallet':self.id, 'at':now, 'head':history[-1]['id'] if history else ZERO,
                    'balances':_balances(self.policy, rows), 'actions':deepcopy(rows),
                    'scope':'SINGLE_ADOPTED_LOCAL_CUSTODY_DOMAIN', 'execution_authorized':False}

    def recovery(self, obligations=()):
        """Draft portable checkpoint; its independent attestor must sign it."""
        _obligations(obligations)
        with self._transaction() as (history, rows, now):
            packet = dict(version=RECOVERY, wallet=deepcopy(self.envelope), at=now,
                          head=history[-1]['id'] if history else ZERO, history=history,
                          obligations=deepcopy(list(obligations)), balances=_balances(self.policy, rows))
            canonical(packet)
        return {'packet':packet, **recovery_payload(packet), 'contains_private_keys':False,
                'live_import_authorized':False, 'obligation_status':'CALLER_DECLARED_NOT_PROVED'}

    def close(self): self.store.close()


def recovery_payload(packet):
    return {'label':RECOVERY_LABEL, 'body':{'packet':identifier(RECOVERY_LABEL, packet)}, 'execution_authorized':False}


def verify_recovery(envelope, *, expected_wallet, expected_head, attestor, now, max_age):
    """Independent expected head and attestor are mandatory; never inferred."""
    exact(envelope, 'packet signature'); packet = envelope['packet']; canonical(packet)
    exact(packet, 'version wallet at head history obligations balances')
    need(packet['version'] == RECOVERY, 'RELIANCE_RECOVERY_VERSION')
    _obligations(packet['obligations'])
    key(expected_wallet); key(expected_head); verification_key(attestor); integer(now); integer(max_age)
    policy = _verify_policy(packet['wallet']); need(wallet_id(policy) == expected_wallet, 'RELIANCE_RECOVERY_WALLET')
    payload = recovery_payload(packet); verify(attestor, payload['label'], payload['body'], envelope['signature'])
    integer(packet['at']); need(packet['at'] <= now and now-packet['at'] <= max_age, 'RELIANCE_RECOVERY_STALE')
    need(type(packet['history']) is list and len(packet['history']) <= 20000, 'RELIANCE_HISTORY_LIMIT')
    previous = ZERO
    for i, event in enumerate(packet['history'], 1):
        exact(event, 'sequence previous id body')
        need(type(event['sequence']) is int and event['sequence'] == i and event['previous'] == previous
             and event['id'] == identifier('COVENANT-WORKFLOW-EVENT-0.1',
                 {k:event[k] for k in ('sequence','previous','body')}), 'RELIANCE_HISTORY_CHANGED')
        previous = event['id']
    need(previous == packet['head'] == expected_head, 'RELIANCE_CHECKPOINT_MISMATCH')
    rows, last_time = _state(packet['history'], policy)
    need(last_time <= packet['at'] and canonical(_balances(policy, rows)) == canonical(packet['balances']),
         'RELIANCE_RECOVERY_BALANCES')
    return {'wallet':expected_wallet, 'head':expected_head, 'actions':rows, 'balances':deepcopy(packet['balances']),
            'obligations':deepcopy(packet['obligations']), 'obligation_status':'CALLER_DECLARED_NOT_PROVED',
            'status':'VERIFIED_CHECKPOINT_NOT_LIVE_AUTHORITY', 'current_revocation_checked':False,
            'resume':'CONNECT_TO_ORIGINAL_COORDINATOR_WITH_FRESH_AUTHORITY; STARTED_ACTIONS_OBSERVE_ONLY',
            'live_import_authorized':False, 'execution_authorized':False}


class GatedAdapter:
    """Owner installs this instead of the raw adapter on protected workflows.

    authorize(effect, request) returns the exact signed intent and grant chain.
    charge(request) is owner code deriving required resource exposure from the
    real request. Delegate-asserted costs cannot lower that exposure. Callbacks
    are trusted code, not downloaded modules or model-generated execution.
    """
    def __init__(self, wallet, adapter, authorize, charge):
        self.wallet = wallet; self.adapter = adapter; self.authorize = authorize; self.charge = charge
        self.inner = manifest_id(adapter.manifest)
        need(self.inner in wallet.policy['adapters'] and callable(authorize) and callable(charge), 'RELIANCE_GATE_CONFIG')
        self.manifest = deepcopy(adapter.manifest)
        self.manifest.update(name='mandate-gated:' + adapter.manifest['name'],
            instance=identifier('COVENANT-MANDATE-GATE-0.1', {'wallet':wallet.id,'adapter':self.inner}),
            recovery='OBSERVE_ONLY')
        self.manifest['requirements'] = {**self.manifest['requirements'],
            'mandate':'EXACT_SIGNED_INTENT_AND_CURRENT_DELEGATION; ATOMIC_LOCAL_RESOURCE_RESERVATION'}
        self._pin = manifest_id(self.manifest)

    def _check(self):
        need(manifest_id(self.manifest) == self._pin and manifest_id(self.adapter.manifest) == self.inner,
             'RELIANCE_GATE_CHANGED')

    def execute(self, effect_id, request, *, crash=None):
        self._check()
        required = deepcopy(self.charge(deepcopy(request))); _amounts(required, True)
        authorization = deepcopy(self.authorize(effect_id, deepcopy(request)))
        exact(authorization, 'envelope chain'); intent = _verify_intent(authorization['envelope'])
        need(intent['adapter'] == self.inner and canonical(required) == canonical(intent['allocations']),
             'RELIANCE_CHARGE_MISMATCH')
        return self.wallet.execute(authorization['envelope'], authorization['chain'], effect_id, request, crash=crash)

    def observe(self, effect_id):
        self._check()
        view = self.wallet.inspect()
        rows = [(ref,row) for ref,row in view['actions'].items()
                if row['intent']['effect'] == effect_id and row['intent']['adapter'] == self.inner and row['state'] != 'CANCELLED']
        if not rows: return {'status':'NOT_OBSERVED','output_hash':None,'assurance':'MANDATE_GATE_NOT_STARTED'}
        ref, row = rows[0]
        if row['state'] == 'HELD': return {'status':'NOT_OBSERVED','output_hash':None,'assurance':'MANDATE_GATE_NOT_STARTED'}
        return self.wallet.observe(ref)


def gated_registry(wallet, routes):
    """Create an execution catalog containing only protected routes.

    Keep wallet.adapters private: exposing its raw adapters in the workflow's
    catalog would let a task choose a route without the additional mandate gate.
    Existing native booking and output approvals still apply to the new manifest.
    """
    from .adapters import AdapterRegistry
    need(type(routes) is dict and set(routes) == set(wallet.policy['adapters']), 'RELIANCE_GATE_ROUTES')
    registry = AdapterRegistry(); mapping = {}
    for inner, route in routes.items():
        exact(route, 'authorize charge')
        gate = GatedAdapter(wallet, wallet.adapters.get(inner), route['authorize'], route['charge'])
        mapping[inner] = registry.register(gate)
    return registry, mapping


def buyer_policy_annex(policy, fields):
    """Unsigned LCP buyer annex bound to this mandate's wallet id (lcp_buyer.annex). Experimental."""
    from .lcp_buyer import annex
    return annex(policy, fields)
