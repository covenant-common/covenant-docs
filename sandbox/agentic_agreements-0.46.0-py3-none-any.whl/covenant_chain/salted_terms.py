"""Salted terms.

Two APIs share this module. The profile packet (`prepare`, `verify_packet`) is
the #27 covenant-salted-terms/1.0 record. The commitment helpers
(`commit_terms`, `seal_description`, `accept_say`, `accept_show`) are the #24
chain feature: they stay idle until genesis `features.salted_terms` is active.
Native terms_hash on 0.1 through 0.14 is untouched.

Commitments reuse mechanism field salts, the selective-input projection, the
proof-facility salted opening, and a WITHHELD mechanism step. Plaintext and
salts stay in the packet. A new version needs fresh controller assent; an
assent over the previous id does not cover the successor.
"""
from copy import deepcopy
import base64

from covenant_language import mechanism_plans as plans
from .crypto import canonical, digest, exact, key, need, verification_key, verify
from .proof_facility import commitment as proof_commitment
from .selected_inputs import prepare_selected

VERSION = 'covenant-salted-terms/1.0'
LABEL = 'COVENANT-SALTED-TERMS-ASSENT-1.0'
STEP = 'terms'


def applies_to(version):
    """Only this profile. Disclosure 0.1 and every native version keep their own hashes."""
    return version == VERSION


def _controllers(controllers):
    need(type(controllers) is list and 1 <= len(controllers) <= 8 and controllers == sorted(set(controllers)), 'SALTED_TERMS_CONTROLLERS')
    for controller in controllers:
        verification_key(controller)
    return controllers


def prepare(terms, salts, context, controllers, target, supersedes=None):
    need(applies_to(VERSION), 'SALTED_TERMS_VERSION')
    plans.ref(context)
    _controllers(controllers)
    if supersedes is not None:
        key(supersedes)
    need(type(terms) is dict and type(salts) is dict and salts, 'SALTED_TERMS_FIELDS')
    fields = sorted(salts)
    prepared = prepare_selected(STEP, target, terms, fields, salts, context, visibility='WITHHELD')
    step = prepared['step']
    need(step['visibility'] == 'WITHHELD' and not step['recipients'] and not step['protection'], 'SALTED_TERMS_WITHHELD')
    plan = plans.plan(context, target, controllers, [step], purpose='Salted terms withheld from the public record')
    openings = plans.commit_fields(terms, fields, salts, context, STEP)['commitments']
    need(openings == step['commitments'], 'MECHANISM_FIELD_OPENING')
    envelope_salt = salts[fields[0]]
    envelope = proof_commitment(base64.b64encode(plans.canonical(terms)).decode('ascii'), envelope_salt, context)
    public = {
        'version': VERSION, 'context': context, 'controllers': deepcopy(controllers),
        'commitments': openings, 'envelope': envelope, 'supersedes': supersedes, 'step': STEP,
    }
    canonical(public)
    packet = {
        'version': VERSION, 'terms': deepcopy(terms), 'salts': deepcopy(salts), 'context': context,
        'target': deepcopy(target), 'plan': plan['plan'], 'plan_id': plan['id'], 'public': public,
        'id': digest('COVENANT-SALTED-TERMS-1.0', public),
    }
    verify_packet(packet)
    return packet


def public_record(packet):
    verify_packet(packet)
    record = deepcopy(packet['public'])
    record['id'] = packet['id']
    need('terms' not in record and 'salts' not in record, 'SALTED_TERMS_PUBLIC')
    return record


def verify_packet(packet):
    exact(packet, 'version terms salts context target plan plan_id public id')
    need(packet['version'] == VERSION and applies_to(packet['version']), 'SALTED_TERMS_VERSION')
    public = packet['public']
    exact(public, 'version context controllers commitments envelope supersedes step')
    need(public['version'] == VERSION and public['context'] == packet['context'] and public['step'] == STEP, 'SALTED_TERMS_VERSION')
    need('terms' not in public and 'salts' not in public, 'SALTED_TERMS_PUBLIC')
    plans.validate(packet['plan'])
    need(packet['plan_id'] == plans.identifier(packet['plan']) and len(packet['plan']['steps']) == 1, 'SALTED_TERMS_PLAN')
    step = packet['plan']['steps'][0]
    need(step['id'] == STEP and step['visibility'] == 'WITHHELD', 'SALTED_TERMS_WITHHELD')
    fields = sorted(packet['salts'])
    openings = plans.commit_fields(packet['terms'], fields, packet['salts'], packet['context'], STEP)['commitments']
    need(openings == public['commitments'] == step['commitments'], 'MECHANISM_FIELD_OPENING')
    selected = plans.select(packet['terms'], fields)
    for path, value in selected.items():
        need(plans.field_commitment(value, packet['salts'][path], packet['context'], STEP, path) == public['commitments'][path], 'MECHANISM_FIELD_OPENING')
    envelope = proof_commitment(base64.b64encode(plans.canonical(packet['terms'])).decode('ascii'), packet['salts'][fields[0]], packet['context'])
    need(envelope == public['envelope'], 'SALTED_TERMS_ENVELOPE')
    need(packet['id'] == digest('COVENANT-SALTED-TERMS-1.0', public), 'SALTED_TERMS_ID')
    return True


def assent_body(packet):
    verify_packet(packet)
    return {'id': packet['id'], 'version': VERSION, 'context': packet['context']}


def verify_assents(packet, approvals):
    body = assent_body(packet)
    controllers = packet['public']['controllers']
    need(type(approvals) is list and len(approvals) == len(controllers), 'SALTED_TERMS_ASSENT')
    eligible = {canonical(controller) for controller in controllers}
    seen = set()
    for approval in approvals:
        exact(approval, 'controller signature')
        encoded = canonical(approval['controller'])
        need(encoded in eligible and encoded not in seen, 'SALTED_TERMS_ASSENT')
        verify(approval['controller'], LABEL, body, approval['signature'])
        seen.add(encoded)
    return {'id': packet['id'], 'fresh_assent': True, 'execution_authorized': False}


def verify_transition(before, after, approvals):
    """Scope change requires assent over the new id. Signatures over the old id are not reused."""
    verify_packet(before)
    verify_packet(after)
    need(after['public']['supersedes'] == before['id'], 'SALTED_TERMS_SUPERSEDES')
    need(before['context'] == after['context'], 'SALTED_TERMS_CONTEXT')
    need(canonical(before['public']['controllers']) == canonical(after['public']['controllers']), 'SALTED_TERMS_CONTROLLERS')
    need(before['id'] != after['id'], 'SALTED_TERMS_UNCHANGED')
    result = verify_assents(after, approvals)
    return {**result, 'previous': before['id'], 'current': after['id'], 'native_terms_hash_changed': False,
            'prior_assent_reused': False}


# Chain commitments from the remainder profile. Inactive unless features.salted_terms is on.
import os
import re

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .crypto import loads
from .feature_gate import SALTED, active

TERMS_LABEL = 'COVENANT-TERMS-SALT-1'
DESCRIPTION_LABEL = 'COVENANT-DESCRIPTION-SALT-1'
DESCRIPTION_AAD = b'COVENANT-DESCRIPTION-1'
MAX_DESCRIPTION = 8000
MAX_CIPHERTEXT = 4096
MAX_SUBJECT = 80
DESTINATION = re.compile(r'[A-Za-z0-9:._/@+-]{1,128}\Z')
EMAIL = re.compile(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}')
PHONE = re.compile(r'(?:\+|00)?[0-9][0-9 ()\-]{8,}[0-9]')
CARD = re.compile(r'(?:\d[ \-]?){13,19}')


def commit_terms(document, salt):
    """Salted commitment. ``salt`` is hex and stays with the parties."""
    key(salt)
    return digest(TERMS_LABEL, {'document': document, 'salt': salt})


def open_terms(commitment, document, salt):
    need(commit_terms(document, salt) == commitment, 'TERMS_OPENING')
    return document


def fresh_salt():
    return os.urandom(32).hex()


def seal_description(text, key_hex, salt=None):
    """Return the chain fields plus the salt and key the parties must keep."""
    need(type(text) is str and 0 < len(text) <= MAX_DESCRIPTION, 'DESCRIPTION')
    need(type(key_hex) is str and re.fullmatch(r'[0-9a-f]{64}', key_hex) is not None, 'DESCRIPTION_KEY')
    if salt is None:
        salt = fresh_salt()
    key(salt)
    description_hash = digest(DESCRIPTION_LABEL, {'salt': salt, 'text': text})
    nonce = os.urandom(12)
    body = canonical({'salt': salt, 'text': text})
    ciphertext = AESGCM(bytes.fromhex(key_hex)).encrypt(nonce, body, DESCRIPTION_AAD)
    encrypted = (nonce + ciphertext).hex()
    need(len(bytes.fromhex(encrypted)) <= MAX_CIPHERTEXT, 'DESCRIPTION_CIPHERTEXT')
    return {'description_hash': description_hash, 'encrypted': encrypted, 'salt': salt, 'key': key_hex}


def open_description(encrypted, key_hex, description_hash=None):
    need(type(encrypted) is str and re.fullmatch(r'[0-9a-f]+', encrypted) is not None, 'DESCRIPTION_CIPHERTEXT')
    need(type(key_hex) is str and re.fullmatch(r'[0-9a-f]{64}', key_hex) is not None, 'DESCRIPTION_KEY')
    raw = bytes.fromhex(encrypted)
    need(12 < len(raw) <= MAX_CIPHERTEXT, 'DESCRIPTION_CIPHERTEXT')
    body = AESGCM(bytes.fromhex(key_hex)).decrypt(raw[:12], raw[12:], DESCRIPTION_AAD)
    opened = loads(body)
    exact(opened, 'salt text')
    if description_hash is not None:
        need(digest(DESCRIPTION_LABEL, {'salt': opened['salt'], 'text': opened['text']}) == description_hash, 'DESCRIPTION_OPENING')
    return opened['text']


def read_description(record):
    """Compatibility view. Legacy rows still carry plaintext."""
    if type(record) is dict and 'description' in record and 'description_hash' not in record:
        return {'kind': 'legacy', 'description': record['description']}
    need(type(record) is dict and 'description_hash' in record, 'DESCRIPTION')
    out = {'kind': 'commitment', 'description_hash': record['description_hash']}
    if 'encrypted' in record:
        out['encrypted'] = record['encrypted']
    return out


def pii_lint(text):
    """Report likely contact or payment numbers in text that must stay off chain."""
    need(type(text) is str and len(text) <= 100000, 'DESCRIPTION')
    findings = []
    for kind, pattern in (('email', EMAIL), ('phone', PHONE), ('card', CARD)):
        for match in pattern.finditer(text):
            findings.append({'kind': kind, 'start': match.start(), 'end': match.end()})
    return findings


def destination_ok(state, terms, height):
    destination = terms['destination']
    if not active(state, SALTED, height):
        need(type(destination) is str and 0 < len(destination) <= 256, 'EFFECT')
        return
    need(type(destination) is str and DESTINATION.fullmatch(destination) is not None, 'EFFECT')


def _ciphertext(value):
    need(type(value) is str and re.fullmatch(r'[0-9a-f]+', value) is not None and len(value) % 2 == 0, 'DESCRIPTION_CIPHERTEXT')
    need(12 < len(value) // 2 <= MAX_CIPHERTEXT, 'DESCRIPTION_CIPHERTEXT')


def accept_say(state, payload, height):
    """Handle a salted SAY. Return False so the caller keeps the legacy rule."""
    if not active(state, SALTED, height):
        return False
    fields = set(payload)
    allowed = {'subject', 'content_hash', 'description_hash', 'parents'}
    need(fields == allowed or fields == allowed | {'encrypted'}, 'FIELDS')
    need('description' not in payload, 'FREE_TEXT')
    key(payload['content_hash'])
    key(payload['description_hash'])
    need(type(payload['subject']) is str and 0 < len(payload['subject']) <= MAX_SUBJECT, 'CLAIM')
    if 'encrypted' in payload:
        _ciphertext(payload['encrypted'])
    parents = payload['parents']
    need(type(parents) is list and parents == sorted(set(parents)) and len(parents) <= 32, 'PARENTS')
    need(all(item in state['events'] for item in parents), 'MISSING_PARENT')
    return True


def accept_show(state, payload, height):
    """Handle a salted SHOW. Return False so the caller keeps the legacy rule."""
    if not active(state, SALTED, height):
        return False
    fields = set(payload)
    allowed = {'agreement', 'content_hash', 'description_hash'}
    need(fields == allowed or fields == allowed | {'encrypted'}, 'FIELDS')
    need('description' not in payload, 'FREE_TEXT')
    key(payload['content_hash'])
    key(payload['description_hash'])
    if 'encrypted' in payload:
        _ciphertext(payload['encrypted'])
    return True
