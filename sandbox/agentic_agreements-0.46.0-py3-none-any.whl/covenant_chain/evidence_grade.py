"""Grade evidence at the assurance the agreement actually accepted.

Corroboration is optional: a quorum of one is a single source. Each row is
labelled with what the bytes really are.

``SELF_ASSERTED``
    Unsigned EXIF, a self-report, or a signature by a key the agreement did not pin.
``PARTY_SIGNED``
    A signature that verifies, and the signer is one of the parties.
``THIRD_PARTY_SIGNED``
    A signature that verifies, and the signer was pinned and is not a party.
``CRYPTOGRAPHICALLY_VERIFIED``
    DKIM verified against DNS or the pinned domain key, or a zkTLS proof the
    installed verifier accepted. A signature over a statement is not that proof.

The signed provenance body includes the terms hash. The same signature does not
grade under a second hash. ``bindings`` records a blob the grader already
accepted, so those bytes cannot be graded again for another agreement.

Nothing here moves escrow. ``execution_authorized`` stays false.
"""
import hashlib
from .crypto import exact, integer, key, need, public_key, sign, verify

ASSURANCE = ('SELF_ASSERTED', 'PARTY_SIGNED', 'THIRD_PARTY_SIGNED', 'CRYPTOGRAPHICALLY_VERIFIED')
PROVENANCE_LABEL = 'COVENANT-EVIDENCE-PROVENANCE-0.1'
KINDS = ('EXIF', 'DEVICE', 'WITNESS', 'DKIM', 'ZKTLS', 'TLSNOTARY', 'C2PA', 'SELF_REPORTED')
SIGNED = {'DEVICE', 'WITNESS', 'DKIM', 'ZKTLS', 'TLSNOTARY', 'C2PA'}
PROOFS = {'ZKTLS', 'TLSNOTARY'}
PROFILE = 'covenant-evidence-grade/0.1'


def _token(value, limit, code='EVIDENCE_FIELDS'):
    need(type(value) is str and 1 <= len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _rank(level):
    need(level in ASSURANCE, 'EVIDENCE_ASSURANCE')
    return ASSURANCE.index(level)


def assurance_of(*, signer, parties, pinned, cryptographic):
    """The label the bytes support. A failed named check is not upgraded."""
    if cryptographic:
        return 'CRYPTOGRAPHICALLY_VERIFIED'
    if type(signer) is str and signer in parties:
        return 'PARTY_SIGNED'
    if type(signer) is str and signer in pinned:
        return 'THIRD_PARTY_SIGNED'
    return 'SELF_ASSERTED'


def envelope_assurance(envelope, flags, proofs=None, parties=(), pinned=()):
    """Label a covenant-evidence/0.1 envelope from the checks that actually ran."""
    return assurance_of(signer=envelope['signature']['signer'], parties=set(parties), pinned=set(pinned),
                        cryptographic=_envelope_crypto(envelope, flags, proofs))


def _scope(proofs, verifier):
    entries = getattr(proofs, 'entries', None)
    if type(entries) is not dict or verifier not in entries:
        return ''
    return entries[verifier][0].get('scope') or ''


def _envelope_crypto(envelope, flags, proofs):
    items = envelope['provenance']
    if not items or len(flags) != len(items) or not all(flags):
        return False
    for item in items:
        method = item['method']
        scope = _scope(proofs, item['verifier'])
        if method in PROOFS:
            if 'NOT_A_PROOF' in scope or 'NOT_A_ZK' in scope:
                return False
        elif method == 'DKIM':
            if 'DKIM_PINNED_KEY' not in scope and 'DKIM_DNS' not in scope:
                return False
        elif method != 'CHAIN_PROOF':
            return False
    return True


def provenance_body(adapter, blob_sha256, mime, kind, terms_hash, *, domain=None, selector=None, manifest_hash=None):
    body = {'adapter': adapter, 'blob_sha256': blob_sha256, 'kind': kind, 'mime': mime, 'terms_hash': terms_hash}
    if kind == 'DKIM':
        _token(domain, 253, 'EVIDENCE_DKIM')
        _token(selector, 64, 'EVIDENCE_DKIM')
        body['domain'] = domain
        body['selector'] = selector
    if kind == 'C2PA':
        key(manifest_hash)
        body['manifest_hash'] = manifest_hash
    return body


def sign_provenance(signer, *, adapter, blob, mime, kind, terms_hash, domain=None, selector=None, manifest_hash=None):
    """Sign provenance bound to one terms hash. The blob stays outside the body."""
    blob_sha256 = _blob_sha(blob)
    body = provenance_body(adapter, blob_sha256, mime, kind, terms_hash, domain=domain, selector=selector, manifest_hash=manifest_hash)
    provenance = dict(body)
    provenance['signer'] = public_key(signer)
    provenance['signature'] = sign(signer, PROVENANCE_LABEL, body)
    return provenance


def _blob_sha(blob):
    if type(blob) is bytes:
        need(1 <= len(blob) <= 1_000_000, 'EVIDENCE_BLOB')
        return hashlib.sha256(blob).hexdigest()
    exact(blob, 'sha256 bytes')
    key(blob['sha256'])
    integer(blob['bytes'], True)
    need(blob['bytes'] <= 512 * 1024 * 1024, 'EVIDENCE_BLOB')
    return blob['sha256']


def _keys(values, code):
    need(type(values) in (list, tuple, set) and len(values) <= 32, code)
    for value in values:
        key(value)
    return set(values)


def _floor(policy):
    chosen = 'ABSENT' if policy is None else policy.get('assurance_required', 'ABSENT')
    need(chosen in (*ASSURANCE, 'ABSENT'), 'EVIDENCE_ASSURANCE')
    return 'THIRD_PARTY_SIGNED' if chosen == 'ABSENT' else chosen


def _dkim_keys(policy):
    raw = policy.get('dkim_keys') or {}
    need(type(raw) is dict and len(raw) <= 32, 'EVIDENCE_DKIM')
    out = {}
    for domain, selectors in raw.items():
        _token(domain, 253, 'EVIDENCE_DKIM')
        need(type(selectors) is dict and 1 <= len(selectors) <= 8, 'EVIDENCE_DKIM')
        out[domain] = {}
        for selector, pubkey in selectors.items():
            _token(selector, 64, 'EVIDENCE_DKIM')
            key(pubkey)
            out[domain][selector] = pubkey
    return out


def grade(policy, submissions, *, terms_hash, quantity=None, parties=(), dns=None, bindings=None, zktls_verify=None):
    """Score submissions. A source below the accepted assurance does not pay.

    ``quorum`` may be 1. That is a single source, not a hidden second witness.
    An omitted ``assurance_required`` accepts third-party signatures and
    cryptographic checks, and does not pay self-asserted or party-signed bytes.
    The parties lower that default by writing the level into the policy.
    """
    key(terms_hash)
    need(type(policy) is dict, 'EVIDENCE_POLICY')
    quorum = policy.get('quorum', 1)
    floor_bps = policy.get('grade_floor_bps', 0)
    integer(quorum, True)
    integer(floor_bps)
    need(1 <= quorum <= 16 and floor_bps <= 10000, 'EVIDENCE_POLICY')
    adapters = policy.get('adapters')
    need(type(adapters) is list and 1 <= len(adapters) <= 16 and len(set(adapters)) == len(adapters), 'EVIDENCE_POLICY')
    for adapter in adapters:
        _token(adapter, 128, 'EVIDENCE_ADAPTER')
    assurance_required = _floor(policy)
    pinned = _keys(policy.get('pinned_signers') or (), 'EVIDENCE_PIN')
    party_keys = _keys(parties, 'EVIDENCE_PARTY')
    dkim_keys = _dkim_keys(policy)
    if dns is not None:
        need(callable(dns), 'EVIDENCE_DKIM')
    if zktls_verify is not None:
        need(callable(zktls_verify), 'EVIDENCE_ZKTLS')
    if quantity is not None:
        integer(quantity)
        need(quantity <= 2**53 - 1, 'EVIDENCE_FIELDS')
    need(type(submissions) is list and 1 <= len(submissions) <= 32, 'EVIDENCE_FIELDS')
    bound = {} if bindings is None else dict(bindings)
    for previous in bound.values():
        key(previous)
    notes = []
    rows = []
    for submission in submissions:
        rows.append(_one(submission, terms_hash, set(adapters), pinned, party_keys, dkim_keys, dns, zktls_verify, assurance_required, bound, notes))
    grouped = {}
    for row in rows:
        if not row['graded']:
            continue
        previous = grouped.get(row['source'])
        if previous is None or row['confidence_bps'] > previous['confidence_bps']:
            grouped[row['source']] = row
    supporters = [grouped[name] for name in sorted(grouped)]
    confidence = 0 if not supporters else sum(row['confidence_bps'] for row in supporters) // len(supporters)
    met = len(supporters) >= quorum
    pay_bps = confidence if met and confidence >= floor_bps else 0
    amount = None if quantity is None else quantity * pay_bps // 10000
    return {'profile': PROFILE, 'terms_hash': terms_hash, 'met': met, 'supporters': len(supporters), 'quorum': quorum,
            'confidence_bps': confidence, 'assurance_required': assurance_required, 'rows': rows, 'notes': notes,
            'bindings': bound, 'graded_settlement': {'interface': 'economics.graded_settlement', 'pay_bps': pay_bps,
            'amount': amount, 'quantity': quantity, 'floor_bps': floor_bps, 'applied': False,
            'consensus_changed': False, 'execution_authorized': False},
            'corroboration': 'OPTIONAL', 'protocol_gate': False, 'consensus_changed': False, 'applied': False,
            'execution_authorized': False}


def _note(notes, text):
    if text not in notes:
        notes.append(text)


def _row(submission, blob_sha256, kind, assurance, confidence, *, claim_matched, graded, reason):
    return {'adapter': submission.get('adapter') if type(submission.get('adapter')) is str else '',
            'source': submission.get('source') if type(submission.get('source')) is str else '',
            'mime': submission.get('mime') if type(submission.get('mime')) is str else '',
            'blob_sha256': blob_sha256, 'provenance_kind': kind, 'assurance': assurance,
            'confidence_bps': confidence if graded else 0, 'claimed_confidence_bps': confidence,
            'claim_matched': claim_matched, 'graded': graded, 'supports': graded, 'reason': reason}


def _signature_ok(provenance, body):
    try:
        verify(provenance.get('signer'), PROVENANCE_LABEL, body, provenance.get('signature'))
    except ValueError:
        return False
    return True


def _one(submission, terms_hash, adapters, pinned, parties, dkim_keys, dns, zktls_verify, assurance_required, bindings, notes):
    need(type(submission) is dict, 'EVIDENCE_FIELDS')
    adapter = submission.get('adapter')
    source = submission.get('source')
    mime = submission.get('mime')
    provenance = submission.get('provenance')
    _token(source, 128)
    _token(mime, 256)
    blob_sha256 = _blob_sha(submission.get('blob'))
    need(type(provenance) is dict and provenance.get('kind') in KINDS, 'EVIDENCE_KIND')
    kind = provenance['kind']
    claim_matched = submission.get('claim_matched') is True
    confidence = submission.get('confidence_bps', 0)
    integer(confidence)
    need(confidence <= 10000, 'EVIDENCE_BPS')
    if adapter not in adapters:
        return _row(submission, blob_sha256, kind, 'SELF_ASSERTED', confidence, claim_matched=claim_matched, graded=False, reason='NOT_PINNED')
    if provenance.get('terms_hash') != terms_hash:
        return _row(submission, blob_sha256, kind, 'SELF_ASSERTED', confidence, claim_matched=claim_matched, graded=False, reason='TERMS')
    if not claim_matched:
        return _row(submission, blob_sha256, kind, 'SELF_ASSERTED', confidence, claim_matched=False, graded=False, reason='CLAIM')
    previous = bindings.get(blob_sha256)
    if previous is not None and previous != terms_hash:
        return _row(submission, blob_sha256, kind, 'SELF_ASSERTED', confidence, claim_matched=True, graded=False, reason='EVIDENCE_REUSED')
    signer = provenance.get('signer')
    signed_ok = False
    cryptographic = False
    if kind in SIGNED:
        body = provenance_body(adapter, blob_sha256, mime, kind, terms_hash, domain=provenance.get('domain'),
                               selector=provenance.get('selector'), manifest_hash=provenance.get('manifest_hash'))
        signed_ok = _signature_ok(provenance, body)
        if not signed_ok:
            return _row(submission, blob_sha256, kind, 'SELF_ASSERTED', confidence, claim_matched=True, graded=False, reason='PROVENANCE')
        if kind == 'C2PA' and provenance.get('manifest_hash') != blob_sha256:
            return _row(submission, blob_sha256, kind, 'SELF_ASSERTED', confidence, claim_matched=True, graded=False, reason='PROVENANCE')
        if kind == 'C2PA':
            _note(notes, 'C2PA_MANIFEST_HASH_NOT_A_JUMBF_PARSER')
    if kind == 'DKIM':
        cryptographic, note = _dkim(provenance, signer, dkim_keys, dns)
        _note(notes, note)
        if not cryptographic:
            label = assurance_of(signer=signer, parties=parties, pinned=pinned, cryptographic=False)
            return _row(submission, blob_sha256, kind, label, confidence, claim_matched=True, graded=False, reason='DKIM')
    elif kind in PROOFS:
        proved = False
        if zktls_verify is not None:
            try:
                proved = zktls_verify(submission) is True
            except Exception:
                proved = False
        if proved:
            cryptographic = True
            _note(notes, 'ZKTLS_PROOF_VERIFIED')
        else:
            _note(notes, 'ZKTLS_SIGNATURE_OF_STATEMENT_NOT_A_ZK_PROOF')
            label = assurance_of(signer=signer, parties=parties, pinned=pinned, cryptographic=False)
            return _row(submission, blob_sha256, kind, label, confidence, claim_matched=True, graded=False, reason='ZKTLS')
    label = assurance_of(signer=signer if signed_ok else None, parties=parties, pinned=pinned, cryptographic=cryptographic)
    if _rank(label) < _rank(assurance_required):
        return _row(submission, blob_sha256, kind, label, confidence, claim_matched=True, graded=False, reason='ASSURANCE')
    bindings[blob_sha256] = terms_hash
    return _row(submission, blob_sha256, kind, label, confidence, claim_matched=True, graded=True, reason='OK')


def _dkim(provenance, signer, dkim_keys, dns):
    domain = provenance.get('domain')
    selector = provenance.get('selector')
    _token(domain, 253, 'EVIDENCE_DKIM')
    _token(selector, 64, 'EVIDENCE_DKIM')
    pinned = dkim_keys.get(domain, {}).get(selector)
    looked = None
    if dns is not None:
        try:
            looked = dns(domain, selector)
        except Exception as exc:
            raise ValueError('EVIDENCE_DKIM') from exc
        if looked is not None:
            key(looked)
    if pinned is not None and looked is not None and pinned != looked:
        return False, 'DKIM_KEY_MISMATCH'
    if pinned is not None and signer == pinned:
        return True, 'DKIM_PINNED_KEY'
    if looked is not None and signer == looked:
        return True, 'DKIM_DNS'
    if pinned is None and dns is None:
        return False, 'DKIM_DNS_NOT_QUERIED'
    return False, 'DKIM_KEY_MISMATCH'
