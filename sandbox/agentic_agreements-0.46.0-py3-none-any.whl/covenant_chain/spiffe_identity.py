"""SPIFFE workload identities bound to an AAP key by signatures, checked offline.

AAP application profile ``covenant-spiffe-binding/0.1``. An enterprise that runs
SPIFFE/SPIRE already names each workload ``spiffe://<trust-domain>/<path>``. A
BINDING lets the Verified Agent Gateway accept that name beside the agent's
did:aap key, so its audit log names both. The binding body names the did:aap,
its key, the SPIFFE ID, the SVID type and hash, the relying audience and a
window, and is signed by the AAP key. Nothing else creates a binding.

* X.509-SVID (SPIFFE X509-SVID sections 2-5): the DER chain, leaf first, is
  validated with RFC 5280 path validation (the ``cryptography`` verifier) to an
  X.509 authority of the leaf's trust domain that the owner adopted, plus the
  SPIFFE leaf rules. The SVID's own key also signs the binding body, so a public
  certificate cannot be claimed by another AAP key. Everything is replayable.
* JWT-SVID (SPIFFE JWT-SVID sections 2-4, 7): compact JWS with an RFC 7518
  algorithm from sections 3.3-3.5, ``sub`` a SPIFFE ID, exactly the adopted
  audience in ``aud``, and ``exp`` no later than the adopted lifetime. A JWT-SVID
  is a bearer token, so the gateway logs its signing input and the hash of its
  signature, never the token; the signature check is recorded at admission, and
  one token binds to one AAP key.

Trust bundles are SPIFFE bundles (RFC 7517 JWK sets, Trust Domain and Bundle
section 4) adopted by the owner into the gateway policy. A trust domain without
an adopted bundle is untrusted. Nothing is fetched; clocks are the caller's.
"""
from copy import deepcopy
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import re

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
from cryptography.x509 import verification as xv
from cryptography.x509.oid import ExtendedKeyUsageOID

from .crypto import canonical, digest, integer, key, need, public_key, sign, verification_key, verify
from . import interop_codec as codec

VERSION = 'covenant-spiffe-binding/0.1'
LABEL = 'COVENANT-SPIFFE-BINDING-0.1'
FIELDS = 'version did key spiffe_id svid_type svid_sha256 audience issued_at expires nonce'
SVID_TYPES = ('JWT', 'X509')
JWT_ALGORITHMS = ('ES256', 'ES384', 'ES512', 'PS256', 'PS384', 'PS512', 'RS256', 'RS384', 'RS512')
PROOF_ALGORITHMS = ('ES256', 'ES384', 'ES512', 'EdDSA', 'PS256', 'RS256')
CURVES = {'P-256': (ec.SECP256R1, 32, 'ES256'), 'P-384': (ec.SECP384R1, 48, 'ES384'),
          'P-521': (ec.SECP521R1, 66, 'ES512')}
HASHES = {'256': hashes.SHA256, '384': hashes.SHA384, '512': hashes.SHA512}
ADMISSION = ('SIGNATURE_VERIFIED', 'SIGNATURE_INVALID')
MAX_ID = 2048
MAX_TRUST_DOMAINS = 16
MAX_AUTHORITIES = 16
MAX_CHAIN = 4
MAX_DER = 8192
MAX_TOKEN = 8192
MAX_JWT_TTL = 86400
DEFAULT_JWT_TTL = 300
TRUST_DOMAIN = re.compile(r'[a-z0-9._-]{1,255}\Z')
SEGMENT = re.compile(r'[A-Za-z0-9._-]+\Z')

REMEDIATION = {
    'SPIFFE_ID': 'Use spiffe://<lowercase trust domain>/<path> with letters, digits, dot, dash and underscore only.',
    'SPIFFE_ID_PATH': 'A workload SVID names a non-root path, for example spiffe://example.org/ns/prod/sa/buyer.',
    'SPIFFE_BUNDLE': 'Supply a SPIFFE bundle: a JWK set with keys of use x509-svid (x5c) or jwt-svid (kid).',
    'SPIFFE_BUNDLE_EMPTY': 'The bundle has no usable keys; SPIFFE treats every SVID of that trust domain as untrusted.',
    'SPIFFE_JWK': 'Use an RSA (2048 to 8192 bits) or EC P-256, P-384 or P-521 public JWK without private members.',
    'SPIFFE_ADOPTION': 'Adopt at most 16 trust domains with an audience, SVID types and a JWT lifetime from 1 to 86400.',
    'SPIFFE_TRUST_DOMAIN_NOT_ADOPTED': 'Adopt the bundle of this trust domain yourself; an SVID cannot nominate its own authority.',
    'SPIFFE_TYPE_NOT_ADOPTED': 'This policy does not accept that SVID type.',
    'SPIFFE_X509': 'Supply the X.509-SVID as 1 to 4 padded base64 DER certificates, leaf first.',
    'SPIFFE_X509_LEAF': 'The leaf needs exactly one SPIFFE URI SAN, cA false and a critical key usage with digitalSignature only for signing.',
    'SPIFFE_X509_CHAIN': 'The chain does not validate to an adopted X.509 authority at the supplied time.',
    'SPIFFE_POSSESSION': 'Sign the binding body with the SVID private key using the JOSE algorithm of that key.',
    'SPIFFE_JWT': 'Supply one compact JWS with header alg, kid and optional typ JWT or JOSE only.',
    'SPIFFE_JWT_ALGORITHM': 'Use RS256/384/512, PS256/384/512 or ES256/384/512 matching the authority key.',
    'SPIFFE_JWT_KEY': 'The kid does not name a jwt-svid authority adopted for this trust domain.',
    'SPIFFE_JWT_CLAIMS': 'Set sub to a SPIFFE ID, aud to exactly the adopted audience and exp; nbf and iat must not be in the future.',
    'SPIFFE_JWT_EXPIRED': 'The JWT-SVID has expired or outlives the adopted lifetime; fetch a fresh one.',
    'SPIFFE_JWT_SIGNATURE': 'The JWT-SVID signature does not verify under the adopted authority.',
    'SPIFFE_FIELDS': 'Use the exact binding fields from describe().',
    'SPIFFE_PROFILE': 'Use version covenant-spiffe-binding/0.1.',
    'SPIFFE_DID': 'Name the did:aap (or did:covenant) of the same account key.',
    'SPIFFE_AUDIENCE': 'The binding must name the adopted audience of this relying party.',
    'SPIFFE_WINDOW': 'Use integer times with issued_at strictly before expires, and present the binding inside them.',
    'SPIFFE_SIGNATURE': 'The binding must be signed by the AAP key it names.',
    'SPIFFE_SUBJECT': 'The SVID names another SPIFFE ID or hash than the binding.',
    'SPIFFE_COUNTERPARTY': 'The binding key is not the caller key of this request.',
    'SPIFFE_REPLAY': 'This JWT-SVID is already bound to another AAP key; a bearer token binds to one key only.',
    'SPIFFE_SHAPE': 'Send {"body", "signature", "svid"} with svid {"type":"X509","x5c","proof"} or {"type":"JWT","token"}.',
    'SPIFFE_ADMISSION': 'The JWT-SVID signature was not verified at admission.',
}


def remediation(code):
    return REMEDIATION.get(code, codec.remediation(code))


def parse_id(text):
    """SPIFFE-ID sections 2-2.3: scheme, lowercase trust domain, clean path, no query or fragment."""
    need(type(text) is str and 0 < len(text) <= MAX_ID and text.isascii() and text.startswith('spiffe://'), 'SPIFFE_ID')
    rest = text[len('spiffe://'):]
    domain, slash, path = rest.partition('/')
    need(TRUST_DOMAIN.fullmatch(domain) is not None and '%' not in text and '?' not in text and '#' not in text, 'SPIFFE_ID')
    segments = path.split('/') if slash else []
    need(all(SEGMENT.fullmatch(part) and part not in ('.', '..') for part in segments), 'SPIFFE_ID')
    return {'id': text, 'trust_domain': domain, 'path': '/' + path if slash else ''}


def _int(raw):
    return int.from_bytes(raw, 'big')


def _jwk_key(jwk):
    """A public key from an RSA or EC JWK (RFC 7518 sections 6.2-6.3)."""
    need(type(jwk) is dict and jwk.get('kty') in ('EC', 'RSA') and not {'d', 'p', 'q', 'dp', 'dq', 'qi', 'oth'} & set(jwk),
         'SPIFFE_JWK')
    try:
        if jwk['kty'] == 'EC':
            need(jwk.get('crv') in CURVES, 'SPIFFE_JWK')
            curve, size, _ = CURVES[jwk['crv']]
            x = codec.b64url_decode(jwk.get('x'), size); y = codec.b64url_decode(jwk.get('y'), size)
            need(len(x) == size and len(y) == size, 'SPIFFE_JWK')
            return ec.EllipticCurvePublicNumbers(_int(x), _int(y), curve()).public_key()
        n = codec.b64url_decode(jwk.get('n'), 1024); e = codec.b64url_decode(jwk.get('e'), 8)
        need(n[:1] not in (b'', b'\0') and e[:1] not in (b'', b'\0') and 2048 <= _int(n).bit_length() <= 8192
             and _int(e) % 2 == 1 and 3 <= _int(e) < 2**32, 'SPIFFE_JWK')
        return rsa.RSAPublicNumbers(_int(e), _int(n)).public_key()
    except (ValueError, TypeError) as error:
        raise ValueError(str(error) if str(error).startswith('SPIFFE_') else 'SPIFFE_JWK') from None


def _normal_jwk(jwk):
    _jwk_key(jwk)
    names = ('kty', 'crv', 'x', 'y') if jwk['kty'] == 'EC' else ('kty', 'n', 'e')
    return {name: jwk[name] for name in names}


@lru_cache(maxsize=256)
def _certificate(der):
    try:
        return x509.load_der_x509_certificate(der)
    except ValueError:
        raise ValueError('SPIFFE_X509') from None


def _der(text):
    try:
        raw = codec.b64_decode(text, MAX_DER)
    except ValueError:
        raise ValueError('SPIFFE_X509') from None
    _certificate(raw)
    return raw


def adopt_bundle(trust_domain, bundle):
    """Normalise a SPIFFE bundle (JWK set text or object) into the form a gateway policy adopts.

    Unknown key types and uses are ignored (Trust Domain and Bundle section 4.1.3);
    x509-svid entries keep their first x5c certificate (X509-SVID section 6.2).
    """
    domain = parse_id('spiffe://' + trust_domain if type(trust_domain) is str else trust_domain)['trust_domain']
    if type(bundle) in (str, bytes):
        try:
            bundle = codec.parse(bundle, 262144)
        except ValueError:
            raise ValueError('SPIFFE_BUNDLE') from None
    need(type(bundle) is dict and type(bundle.get('keys')) is list and len(bundle['keys']) <= 64, 'SPIFFE_BUNDLE')
    sequence = bundle.get('spiffe_sequence')
    need(sequence is None or (type(sequence) is int and 0 <= sequence <= 2**53 - 1), 'SPIFFE_BUNDLE')
    authorities, jwt = set(), {}
    for entry in bundle['keys']:
        if type(entry) is not dict or entry.get('kty') not in ('EC', 'RSA', 'OKP') or entry.get('use') not in ('x509-svid', 'jwt-svid'):
            continue
        if entry['use'] == 'x509-svid':
            chain = entry.get('x5c')
            if type(chain) is not list or not chain:
                continue
            certificate = _certificate(_der(chain[0]))
            constraints = certificate.extensions.get_extension_for_class(x509.BasicConstraints).value \
                if any(e.oid == x509.OID_BASIC_CONSTRAINTS for e in certificate.extensions) else None
            need(constraints is not None and constraints.ca, 'SPIFFE_BUNDLE')
            authorities.add(chain[0])
        else:
            need(type(entry.get('kid')) is str and 0 < len(entry['kid']) <= 256 and entry['kid'].isascii()
                 and entry['kid'].isprintable() and entry['kid'] not in jwt, 'SPIFFE_BUNDLE')
            if entry['kty'] == 'OKP':
                continue  # JWT-SVID section 2.1 admits no EdDSA algorithm; such a key can never verify.
            jwt[entry['kid']] = _normal_jwk(entry)
    need(len(authorities) <= MAX_AUTHORITIES and len(jwt) <= MAX_AUTHORITIES, 'SPIFFE_BUNDLE')
    need(bool(authorities) or bool(jwt), 'SPIFFE_BUNDLE_EMPTY')
    return {'trust_domain': domain, 'x509_authorities': sorted(authorities), 'jwt_authorities': dict(sorted(jwt.items())),
            'sequence': sequence}


def adoption(audience, svid_types, trust_domains, max_jwt_ttl=DEFAULT_JWT_TTL):
    """The ``spiffe`` block of a gateway policy: owner-chosen audience, SVID types and adopted bundles."""
    block = {'audience': audience, 'svid_types': sorted(svid_types), 'max_jwt_ttl': max_jwt_ttl,
             'trust_domains': sorted(deepcopy(trust_domains), key=lambda row: row.get('trust_domain', '') if type(row) is dict else '')}
    return validate_adoption(block)


def validate_adoption(block):
    need(type(block) is dict and set(block) == {'audience', 'svid_types', 'max_jwt_ttl', 'trust_domains'}, 'SPIFFE_ADOPTION')
    need(type(block['audience']) is str and 0 < len(block['audience']) <= 256 and block['audience'].isascii()
         and block['audience'].isprintable(), 'SPIFFE_ADOPTION')
    need(type(block['svid_types']) is list and block['svid_types'] and block['svid_types'] == sorted(set(block['svid_types']))
         and set(block['svid_types']) <= set(SVID_TYPES), 'SPIFFE_ADOPTION')
    need(type(block['max_jwt_ttl']) is int and 1 <= block['max_jwt_ttl'] <= MAX_JWT_TTL, 'SPIFFE_ADOPTION')
    rows = block['trust_domains']
    need(type(rows) is list and len(rows) <= MAX_TRUST_DOMAINS, 'SPIFFE_ADOPTION')
    names = []
    for row in rows:
        need(type(row) is dict and set(row) == {'trust_domain', 'x509_authorities', 'jwt_authorities', 'sequence'}, 'SPIFFE_ADOPTION')
        names.append(parse_id('spiffe://' + str(row['trust_domain']))['trust_domain'])
        need(type(row['x509_authorities']) is list and len(row['x509_authorities']) <= MAX_AUTHORITIES
             and row['x509_authorities'] == sorted(set(row['x509_authorities'])), 'SPIFFE_ADOPTION')
        for text in row['x509_authorities']:
            _der(text)
        need(type(row['jwt_authorities']) is dict and len(row['jwt_authorities']) <= MAX_AUTHORITIES, 'SPIFFE_ADOPTION')
        for kid, jwk in row['jwt_authorities'].items():
            need(type(kid) is str and 0 < len(kid) <= 256 and kid.isascii() and kid.isprintable() and jwk == _normal_jwk(jwk),
                 'SPIFFE_ADOPTION')
        need(row['sequence'] is None or (type(row['sequence']) is int and 0 <= row['sequence'] <= 2**53 - 1), 'SPIFFE_ADOPTION')
    need(names == sorted(set(names)), 'SPIFFE_ADOPTION')
    canonical(block)
    return block


def summary(block):
    """What a trust mark may disclose: trust domains, audience, SVID types and the adoption hash."""
    validate_adoption(block)
    return {'audience': block['audience'], 'svid_types': list(block['svid_types']), 'max_jwt_ttl': block['max_jwt_ttl'],
            'trust_domains': [row['trust_domain'] for row in block['trust_domains']],
            'adoption_sha256': hashlib.sha256(canonical(block)).hexdigest()}


def _domain(block, trust_domain):
    for row in block['trust_domains']:
        if row['trust_domain'] == trust_domain:
            return row
    raise ValueError('SPIFFE_TRUST_DOMAIN_NOT_ADOPTED')


def _ee_extensions(_policy, certificate, extension):
    """X509-SVID sections 4.1-4.4 and 5.2 for the leaf, beside RFC 5280 path validation."""
    value = getattr(extension, 'value', extension)
    if isinstance(value, x509.BasicConstraints):
        need(not value.ca, 'SPIFFE_X509_LEAF')
    elif isinstance(value, x509.KeyUsage):
        need(value.digital_signature and not value.key_cert_sign and not value.crl_sign, 'SPIFFE_X509_LEAF')
    elif isinstance(value, x509.ExtendedKeyUsage):
        need(ExtendedKeyUsageOID.SERVER_AUTH in value and ExtendedKeyUsageOID.CLIENT_AUTH in value, 'SPIFFE_X509_LEAF')
    elif isinstance(value, x509.SubjectAlternativeName):
        need(len(value.get_values_for_type(x509.UniformResourceIdentifier)) == 1, 'SPIFFE_X509_LEAF')


def _ca_extensions(_policy, certificate, extension):
    value = getattr(extension, 'value', extension)
    if isinstance(value, x509.BasicConstraints):
        need(value.ca, 'SPIFFE_X509_CHAIN')
    elif isinstance(value, x509.KeyUsage):
        need(value.key_cert_sign, 'SPIFFE_X509_CHAIN')


def _verifier(roots, now):
    criticality = xv.Criticality
    ee = (xv.ExtensionPolicy.permit_all()
          .require_present(x509.KeyUsage, criticality.CRITICAL, _ee_extensions)
          .require_present(x509.SubjectAlternativeName, criticality.AGNOSTIC, _ee_extensions)
          .may_be_present(x509.BasicConstraints, criticality.AGNOSTIC, _ee_extensions)
          .may_be_present(x509.ExtendedKeyUsage, criticality.AGNOSTIC, _ee_extensions))
    ca = (xv.ExtensionPolicy.permit_all()
          .require_present(x509.BasicConstraints, criticality.AGNOSTIC, _ca_extensions)
          .require_present(x509.KeyUsage, criticality.AGNOSTIC, _ca_extensions))
    return (xv.PolicyBuilder().store(xv.Store(roots)).time(datetime.fromtimestamp(now, timezone.utc))
            .max_chain_depth(MAX_CHAIN).extension_policies(ca_policy=ca, ee_policy=ee).build_client_verifier())


def verify_x509_svid(x5c, block, now):
    """Validate an X.509-SVID chain offline against the adopted authorities of its trust domain."""
    integer(now); validate_adoption(block)
    need('X509' in block['svid_types'], 'SPIFFE_TYPE_NOT_ADOPTED')
    need(type(x5c) is list and 1 <= len(x5c) <= MAX_CHAIN, 'SPIFFE_X509')
    ders = [_der(text) for text in x5c]
    leaf = _certificate(ders[0])
    try:
        names = leaf.extensions.get_extension_for_class(x509.SubjectAlternativeName)
    except x509.ExtensionNotFound:
        raise ValueError('SPIFFE_X509_LEAF') from None
    uris = names.value.get_values_for_type(x509.UniformResourceIdentifier)
    need(len(uris) == 1, 'SPIFFE_X509_LEAF')
    identity = parse_id(uris[0])
    need(identity['path'] != '', 'SPIFFE_ID_PATH')
    need(len(leaf.subject) > 0 or names.critical, 'SPIFFE_X509_LEAF')
    row = _domain(block, identity['trust_domain'])
    need(bool(row['x509_authorities']), 'SPIFFE_TRUST_DOMAIN_NOT_ADOPTED')
    roots = [_certificate(codec.b64_decode(text, MAX_DER)) for text in row['x509_authorities']]
    try:
        _verifier(roots, now).verify(leaf, [_certificate(der) for der in ders[1:]])
    except xv.VerificationError as error:
        raise ValueError('SPIFFE_X509_LEAF' if 'SPIFFE_X509_LEAF' in str(error) else 'SPIFFE_X509_CHAIN') from None
    except ValueError as error:
        raise ValueError(str(error) if str(error).startswith('SPIFFE_') else 'SPIFFE_X509_CHAIN') from None
    return {'spiffe_id': identity['id'], 'trust_domain': identity['trust_domain'],
            'svid_sha256': hashlib.sha256(ders[0]).hexdigest(), 'public_key': leaf.public_key(),
            'not_after': int(leaf.not_valid_after_utc.timestamp())}


def _jose_verify(algorithm, public, message, signature):
    """Verify a JOSE signature (RFC 7518 sections 3.3-3.5, RFC 8037 section 3.1) under one key."""
    try:
        if algorithm == 'EdDSA':
            need(isinstance(public, ed25519.Ed25519PublicKey) and len(signature) == 64, 'SPIFFE_POSSESSION')
            public.verify(signature, message)
        elif algorithm.startswith('ES'):
            need(isinstance(public, ec.EllipticCurvePublicKey), 'SPIFFE_JWT_ALGORITHM')
            curve = {'ES256': 'secp256r1', 'ES384': 'secp384r1', 'ES512': 'secp521r1'}[algorithm]
            size = {'ES256': 32, 'ES384': 48, 'ES512': 66}[algorithm]
            need(public.curve.name == curve and len(signature) == 2 * size, 'SPIFFE_JWT_ALGORITHM')
            der = encode_dss_signature(_int(signature[:size]), _int(signature[size:]))
            public.verify(der, message, ec.ECDSA(HASHES[algorithm[2:]]()))
        else:
            need(isinstance(public, rsa.RSAPublicKey) and public.key_size >= 2048, 'SPIFFE_JWT_ALGORITHM')
            chosen = HASHES[algorithm[2:]]()
            scheme = padding.PKCS1v15() if algorithm.startswith('RS') else padding.PSS(
                mgf=padding.MGF1(chosen), salt_length=chosen.digest_size)
            public.verify(signature, message, scheme, chosen)
    except InvalidSignature:
        return False
    return True


def _numeric(value):
    return type(value) in (int, float) and value == value and abs(value) <= 2**53


def _jwt_parts(token):
    need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.count('.') == 2, 'SPIFFE_JWT')
    head, body, signature = token.split('.')
    try:
        header = codec.parse(codec.b64url_decode(head, 1024), 1024, 4, 32)
        claims = codec.parse(codec.b64url_decode(body, 4096), 4096, 8, 256)
        raw = codec.b64url_decode(signature, 1024)
    except ValueError:
        raise ValueError('SPIFFE_JWT') from None
    need(type(header) is dict and type(claims) is dict, 'SPIFFE_JWT')
    return head + '.' + body, header, claims, raw


def _jwt_claims(header, claims, block, now):
    """Header and claim rules of JWT-SVID sections 2-3 and Appendix A; returns (identity, row)."""
    need(set(header) <= {'alg', 'kid', 'typ'} and type(header.get('kid')) is str and header.get('typ', 'JWT') in ('JWT', 'JOSE'),
         'SPIFFE_JWT')
    need(header.get('alg') in JWT_ALGORITHMS, 'SPIFFE_JWT_ALGORITHM')
    identity = parse_id(claims.get('sub'))
    audience = claims.get('aud')
    audiences = [audience] if type(audience) is str else audience
    need(type(audiences) is list and audiences == [block['audience']], 'SPIFFE_JWT_CLAIMS')
    need(_numeric(claims.get('exp')) and all(_numeric(claims[name]) and claims[name] <= now
                                             for name in ('nbf', 'iat') if name in claims), 'SPIFFE_JWT_CLAIMS')
    need(now < claims['exp'] <= now + block['max_jwt_ttl'], 'SPIFFE_JWT_EXPIRED')
    row = _domain(block, identity['trust_domain'])
    need(header['kid'] in row['jwt_authorities'], 'SPIFFE_JWT_KEY')
    return identity, row


def verify_jwt_svid(token, block, now):
    """Validate a JWT-SVID offline against the adopted jwt-svid authorities of its trust domain."""
    integer(now); validate_adoption(block)
    need('JWT' in block['svid_types'], 'SPIFFE_TYPE_NOT_ADOPTED')
    signing_input, header, claims, signature = _jwt_parts(token)
    identity, row = _jwt_claims(header, claims, block, now)
    public = _jwk_key(row['jwt_authorities'][header['kid']])
    need(_jose_verify(header['alg'], public, signing_input.encode('ascii'), signature), 'SPIFFE_JWT_SIGNATURE')
    return {'spiffe_id': identity['id'], 'trust_domain': identity['trust_domain'], 'kid': header['kid'],
            'algorithm': header['alg'], 'svid_sha256': hashlib.sha256(signing_input.encode('ascii')).hexdigest(),
            'expires': claims['exp'], 'bearer_token': True}


def _validate(body):
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'SPIFFE_FIELDS')
    need(body['version'] == VERSION, 'SPIFFE_PROFILE')
    need(type(body['key']) is str, 'SPIFFE_FIELDS'); verification_key(body['key'])
    from .scale.identity import resolve_did
    try:
        _, account = resolve_did(body['did'])
    except ValueError:
        raise ValueError('SPIFFE_DID') from None
    need(account == body['key'], 'SPIFFE_DID')
    parse_id(body['spiffe_id'])
    need(body['svid_type'] in SVID_TYPES, 'SPIFFE_FIELDS')
    key(body['svid_sha256']); key(body['nonce'])
    need(type(body['audience']) is str and 0 < len(body['audience']) <= 256 and body['audience'].isascii()
         and body['audience'].isprintable(), 'SPIFFE_AUDIENCE')
    integer(body['issued_at']); integer(body['expires'])
    need(body['issued_at'] < body['expires'], 'SPIFFE_WINDOW')
    return body


def binding_id(body):
    _validate(body)
    return digest(LABEL, body)


def binding(did, spiffe_id, svid_type, svid_sha256, audience, issued_at, expires, nonce):
    """Prepare an unsigned binding; the AAP key named by ``did`` signs it, and an X.509-SVID key co-signs."""
    from .scale.identity import resolve_did
    try:
        account = resolve_did(did)[1]
    except ValueError:
        raise ValueError('SPIFFE_DID') from None
    body = {'version': VERSION, 'did': did, 'key': account, 'spiffe_id': spiffe_id, 'svid_type': svid_type,
            'svid_sha256': svid_sha256, 'audience': audience, 'issued_at': issued_at, 'expires': expires, 'nonce': nonce}
    return {'id': binding_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'possession_payload': possession_payload(body).hex() if svid_type == 'X509' else None,
            'required_signers': [account], 'signature_created': False, 'execution_authorized': False}


def possession_payload(body):
    """Bytes the X.509-SVID private key signs: the same domain-separated message the AAP key signs."""
    _validate(body)
    return LABEL.encode('ascii') + b'\0' + canonical(body)


def sign_binding(body, private_key):
    """Explicit local owner action with the AAP key. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body['key'], 'SPIFFE_SIGNATURE')
    return sign(private_key, LABEL, body)


def sign_possession(body, svid_private_key):
    """Explicit local workload action with the X.509-SVID key; returns the JOSE-style proof object."""
    message = possession_payload(body)
    if isinstance(svid_private_key, ec.EllipticCurvePrivateKey):
        algorithm = {'secp256r1': 'ES256', 'secp384r1': 'ES384', 'secp521r1': 'ES512'}[svid_private_key.curve.name]
        from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
        size = {'ES256': 32, 'ES384': 48, 'ES512': 66}[algorithm]
        r, s = decode_dss_signature(svid_private_key.sign(message, ec.ECDSA(HASHES[algorithm[2:]]())))
        raw = r.to_bytes(size, 'big') + s.to_bytes(size, 'big')
    elif isinstance(svid_private_key, rsa.RSAPrivateKey):
        algorithm, raw = 'RS256', svid_private_key.sign(message, padding.PKCS1v15(), hashes.SHA256())
    else:
        algorithm, raw = 'EdDSA', svid_private_key.sign(message)
    return {'alg': algorithm, 'signature': codec.b64url(raw)}


def _check_body(record, block, now, counterparty):
    need(type(record) is dict and set(record) == {'body', 'signature', 'svid'} and type(record['svid']) is dict, 'SPIFFE_SHAPE')
    body = _validate(record['body'])
    need(body['audience'] == block['audience'], 'SPIFFE_AUDIENCE')
    need(body['svid_type'] in block['svid_types'], 'SPIFFE_TYPE_NOT_ADOPTED')
    need(body['issued_at'] <= now < body['expires'], 'SPIFFE_WINDOW')
    need(counterparty is None or body['key'] == counterparty, 'SPIFFE_COUNTERPARTY')
    try:
        verify(body['key'], LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('SPIFFE_SIGNATURE') from None
    return body


def _x509(record, block, now, body):
    svid = record['svid']
    need(set(svid) == {'type', 'x5c', 'proof'} and svid['type'] == 'X509' and body['svid_type'] == 'X509', 'SPIFFE_SHAPE')
    found = verify_x509_svid(svid['x5c'], block, now)
    need(found['spiffe_id'] == body['spiffe_id'] and found['svid_sha256'] == body['svid_sha256'], 'SPIFFE_SUBJECT')
    proof = svid['proof']
    need(type(proof) is dict and set(proof) == {'alg', 'signature'} and proof['alg'] in PROOF_ALGORITHMS, 'SPIFFE_POSSESSION')
    try:
        raw = codec.b64url_decode(proof['signature'], 1024)
    except ValueError:
        raise ValueError('SPIFFE_POSSESSION') from None
    try:
        ok = _jose_verify(proof['alg'], found['public_key'], possession_payload(body), raw)
    except ValueError:
        ok = False
    need(ok, 'SPIFFE_POSSESSION')
    return found


def verify_binding(record, block, now, counterparty=None):
    """Full offline check of a caller-supplied binding: AAP signature, SVID, and (X.509) key possession."""
    integer(now); validate_adoption(block)
    body = _check_body(record, block, now, counterparty)
    if body['svid_type'] == 'X509':
        found = _x509(record, block, now, body)
        assurance = 'X509_SVID_CHAIN_KEY_POSSESSION_AND_AAP_KEY_SIGNATURE'
    else:
        svid = record['svid']
        need(set(svid) == {'type', 'token'} and svid['type'] == 'JWT', 'SPIFFE_SHAPE')
        found = verify_jwt_svid(svid['token'], block, now)
        need(found['spiffe_id'] == body['spiffe_id'] and found['svid_sha256'] == body['svid_sha256'], 'SPIFFE_SUBJECT')
        assurance = 'JWT_SVID_BEARER_TOKEN_AND_AAP_KEY_SIGNATURE'
    return {'binding': binding_id(body), 'did': body['did'], 'key': body['key'], 'spiffe_id': body['spiffe_id'],
            'trust_domain': found['trust_domain'], 'svid_type': body['svid_type'], 'svid_sha256': body['svid_sha256'],
            'assurance': assurance, 'clock': 'CALLER_ASSERTION', 'network_accessed': False, 'execution_authorized': False}


def _refused(identity, code):
    try:
        reference = hashlib.sha256(canonical(identity)).hexdigest()
    except ValueError:
        reference = None
    return {'version': VERSION, 'refused': code, 'identity_sha256': reference}


def is_binding(identity):
    """True for a SPIFFE binding (caller or logged form) or its refusal record; False for other identity kinds."""
    return type(identity) is dict and ('svid' in identity or identity.get('refused') is not None
                                       and identity.get('version') == VERSION)


def admission_form(identity, block):
    """What a gateway logs. X.509 bindings are kept whole; a JWT-SVID keeps its signing input and the
    hash of its signature, with the signature result recorded here, and the bearer token is dropped.
    A logged form or any other shape supplied by a caller is replaced by a refusal record."""
    validate_adoption(block)
    if not is_binding(identity):
        return deepcopy(identity)
    svid = identity.get('svid') if type(identity) is dict else None
    if type(svid) is not dict or set(identity) != {'body', 'signature', 'svid'}:
        return _refused(identity, 'SPIFFE_SHAPE')
    if svid.get('type') == 'X509' and set(svid) == {'type', 'x5c', 'proof'}:
        return deepcopy(identity)
    if svid.get('type') != 'JWT' or set(svid) != {'type', 'token'}:
        return _refused(identity, 'SPIFFE_SHAPE')
    try:
        signing_input, header, claims, signature = _jwt_parts(svid['token'])
    except ValueError:
        return _refused(identity, 'SPIFFE_JWT')
    admission = 'SIGNATURE_INVALID'
    try:
        identity_row = _domain(block, parse_id(claims.get('sub'))['trust_domain'])
        jwk = identity_row['jwt_authorities'].get(header.get('kid')) if type(header.get('kid')) is str else None
        if 'JWT' in block['svid_types'] and jwk is not None and header.get('alg') in JWT_ALGORITHMS and \
                _jose_verify(header['alg'], _jwk_key(jwk), signing_input.encode('ascii'), signature):
            admission = 'SIGNATURE_VERIFIED'
    except ValueError:
        admission = 'SIGNATURE_INVALID'
    return {'body': deepcopy(identity['body']), 'signature': identity['signature'],
            'svid': {'type': 'JWT', 'signing_input': signing_input,
                     'signature_sha256': hashlib.sha256(signature).hexdigest(), 'admission': admission}}


def check_logged(identity, block, counterparty, now, pins=None):
    """Pure gateway rule over a logged binding; returns (code or None, names). The gateway and replay call it.

    ``pins`` maps a JWT-SVID signing-input hash to the AAP key it first bound to.
    """
    try:
        validate_adoption(block); integer(now)
        need(type(identity) is dict and identity.get('refused') is None, 'SPIFFE_SHAPE')
        body = _check_body(identity, block, now, counterparty)
        if body['svid_type'] == 'X509':
            found = _x509(identity, block, now, body)
        else:
            svid = identity['svid']
            need(set(svid) == {'type', 'signing_input', 'signature_sha256', 'admission'} and svid['type'] == 'JWT'
                 and svid['admission'] in ADMISSION, 'SPIFFE_SHAPE')
            key(svid['signature_sha256'])
            need(type(svid['signing_input']) is str and len(svid['signing_input']) <= MAX_TOKEN
                 and svid['signing_input'].count('.') == 1, 'SPIFFE_JWT')
            signing_input, header, claims, _ = _jwt_parts(svid['signing_input'] + '.' + codec.b64url(b'\0' * 64))
            identity_found, _ = _jwt_claims(header, claims, block, now)
            need('JWT' in block['svid_types'], 'SPIFFE_TYPE_NOT_ADOPTED')
            digest_ = hashlib.sha256(signing_input.encode('ascii')).hexdigest()
            need(identity_found['id'] == body['spiffe_id'] and digest_ == body['svid_sha256'], 'SPIFFE_SUBJECT')
            need(svid['admission'] == 'SIGNATURE_VERIFIED', 'SPIFFE_ADMISSION')
            pinned = (pins or {}).get(digest_)
            need(pinned is None or pinned == body['key'], 'SPIFFE_REPLAY')
            found = {'trust_domain': identity_found['trust_domain']}
        return None, {'did': body['did'], 'key': body['key'], 'spiffe_id': body['spiffe_id'],
                      'trust_domain': found['trust_domain'], 'svid_type': body['svid_type'], 'svid_sha256': body['svid_sha256']}
    except ValueError as error:
        code = str(error)
        return (code if code in REMEDIATION or code in codec.REMEDIATION else 'SPIFFE_SHAPE'), None


def names(identity):
    """The did:aap and SPIFFE ID a logged binding names, without verifying it (for audit listings)."""
    if not is_binding(identity) or identity.get('refused') is not None or type(identity.get('body')) is not dict:
        return None
    body = identity['body']
    return {'did': body.get('did'), 'spiffe_id': body.get('spiffe_id'), 'svid_type': body.get('svid_type')}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL,
            'binding_fields': FIELDS.split(), 'svid_types': list(SVID_TYPES), 'jwt_algorithms': list(JWT_ALGORITHMS),
            'possession_algorithms': list(PROOF_ALGORITHMS),
            'x509': 'RFC5280_PATH_VALIDATION_TO_ADOPTED_AUTHORITY_PLUS_X509_SVID_LEAF_RULES_AND_KEY_POSSESSION',
            'jwt': 'BEARER_TOKEN_EXACT_ADOPTED_AUDIENCE_BOUNDED_LIFETIME_ONE_TOKEN_ONE_KEY_NOT_LOGGED',
            'bundles': 'OWNER_ADOPTED_SPIFFE_JWK_SETS_ONLY',
            'limits': {'trust_domains': MAX_TRUST_DOMAINS, 'authorities': MAX_AUTHORITIES, 'chain': MAX_CHAIN,
                       'der_bytes': MAX_DER, 'token_bytes': MAX_TOKEN, 'jwt_ttl': MAX_JWT_TTL},
            'remediation': dict(REMEDIATION), 'clock': 'CALLER_ASSERTION', 'network_accessed': False,
            'execution_authorized': False}
