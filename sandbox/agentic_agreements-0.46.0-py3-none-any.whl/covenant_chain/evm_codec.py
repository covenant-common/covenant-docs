"""Ethereum wire primitives for optional AAP payment and export legs. Maturity: experimental.

Bytes only. Nothing here opens a socket, holds a key, submits a transaction or
reads a chain. The owner signs and broadcasts, or does not.

* Solidity contract ABI (docs.soliditylang.org, "Contract ABI Specification",
  0.8.x): head/tail encoding and strict decoding of address, bool, uint<M>,
  int<M>, bytes<M>, bytes, string, T[k], T[] and tuples, plus the non-standard
  packed mode (abi.encodePacked) for atomic, bytes and string values. Decoding
  re-encodes and refuses any input that is not the canonical encoding.
* EIP-712 (Final; ethereum/EIPs EIPS/eip-712.md at 0b06de5): encodeType with
  referenced structs sorted by name, encodeData, hashStruct, arrays as the hash
  of their encoded members, the EIP712Domain field order and the
  0x1901 || domainSeparator || hashStruct(message) digest.
* EIP-55 mixed-case address checksums; secp256k1 public-key recovery for
  low-s and, where a protocol asks for it, high-s signatures.

Curve arithmetic over public values reuses covenant_chain.trust.passport;
signing goes through the cryptography package (RFC 6979, low-s).
"""
import re

from .anchor import keccak256
from .crypto import need
from .trust import passport as _curve

MAX_DATA = 1 << 20
MAX_ITEMS = 1024
MAX_DEPTH = 8
MAX_TEXT = 65536
ZERO_ADDRESS = '0x' + '00' * 20
ADDRESS = re.compile(r'0x[0-9a-fA-F]{40}\Z')
HEX = re.compile(r'0x(?:[0-9a-fA-F]{2})*\Z')
IDENTIFIER = re.compile(r'[A-Za-z_][A-Za-z0-9_]{0,63}\Z')
_ATOMIC = re.compile(r'(address|bool|string|bytes(?:3[0-2]|[12][0-9]|[1-9])?|u?int(?:[1-9][0-9]{0,2}))(?![A-Za-z0-9_])')
DOMAIN_FIELDS = (('name', 'string'), ('version', 'string'), ('chainId', 'uint256'),
                 ('verifyingContract', 'address'), ('salt', 'bytes32'))

REMEDIATION = {
    'EVM_ADDRESS': 'Use a 0x-prefixed 20-byte hex address; mixed case must carry a valid EIP-55 checksum.',
    'EVM_ABI_TYPE': 'Use a canonical Solidity type: address, bool, uint8..uint256, int8..int256, bytes1..bytes32, bytes, string, T[k], T[] or a tuple.',
    'EVM_ABI_VALUE': 'Pass a value of the declared type within its range: int for integers, bytes for bytes, str for strings, list for arrays and tuples.',
    'EVM_ABI_DATA': 'The bytes are not the canonical ABI encoding of the declared types. Request the exact encoded data again.',
    'EVM_ABI_LIMIT': 'Keep ABI data within 1 MiB, arrays within 1024 items and nesting within 8 levels.',
    'EVM_HEX': 'Pass 0x-prefixed hex with an even number of digits.',
    'EVM_TYPED_DATA': 'Pass EIP-712 typed data {types, primaryType, domain, message} with exactly the declared fields and no cyclic types.',
    'EVM_TYPED_DOMAIN': 'Declare EIP712Domain with fields from name, version, chainId, verifyingContract, salt in that order and supply exactly those values.',
    'EVM_SIGNATURE': 'Pass a 65-byte r || s || v secp256k1 signature, v 27 or 28 (0 or 1 accepted), r and s in range.',
    'EVM_RECOVERY': 'The signature does not recover a public key for this digest. Ask the signer to sign the exact digest again.',
    'EVM_KEY': 'Pass a cryptography secp256k1 private key loaded by the owner from its keystore.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the input against the documented format.')


def keccak(data):
    return keccak256(bytes(data))


def selector(signature):
    """The 4-byte function selector of a canonical signature such as transfer(address,uint256)."""
    need(type(signature) is str and 0 < len(signature) <= 512 and signature.isascii() and ' ' not in signature, 'EVM_ABI_TYPE')
    return keccak(signature.encode('ascii'))[:4]


def topic(signature):
    need(type(signature) is str and 0 < len(signature) <= 512 and signature.isascii() and ' ' not in signature, 'EVM_ABI_TYPE')
    return keccak(signature.encode('ascii'))


def address(value):
    """Lowercase 0x address; a mixed-case input must be a valid EIP-55 checksum."""
    need(type(value) is str and ADDRESS.fullmatch(value) is not None, 'EVM_ADDRESS')
    body = value[2:]
    if body != body.lower() and body != body.upper():
        need(checksum(body.lower()) == '0x' + body, 'EVM_ADDRESS')
    return '0x' + body.lower()


def checksum(value):
    """EIP-55: uppercase each hex letter whose keccak256 nibble of the lowercase address is 8 or more."""
    body = value[2:] if type(value) is str and value[:2] in ('0x', '0X') else value
    need(type(body) is str and len(body) == 40 and re.fullmatch(r'[0-9a-fA-F]{40}', body) is not None, 'EVM_ADDRESS')
    body = body.lower()
    hashed = keccak(body.encode('ascii')).hex()
    return '0x' + ''.join(c.upper() if c.isalpha() and int(hashed[i], 16) >= 8 else c for i, c in enumerate(body))


def unhex(value, size=None, code='EVM_HEX'):
    need(type(value) is str and len(value) <= 2 + 2 * MAX_DATA and HEX.fullmatch(value) is not None, code)
    raw = bytes.fromhex(value[2:])
    need(size is None or len(raw) == size, code)
    return raw


def word(value):
    return int(value).to_bytes(32, 'big')


# Solidity ABI types --------------------------------------------------------

def parse_type(text):
    """('address',) ('bool',) ('uint', M) ('int', M) ('fixed', M) ('bytes',) ('string',) ('array', T, k|None) ('tuple', [T...])."""
    need(type(text) is str and 0 < len(text) <= 1024 and text.isascii(), 'EVM_ABI_TYPE')
    parsed, end = _type(text, 0, 0)
    need(end == len(text), 'EVM_ABI_TYPE')
    return parsed


def _type(text, at, depth):
    need(depth <= MAX_DEPTH, 'EVM_ABI_TYPE')
    if text.startswith('(', at):
        parts, at = [], at + 1
        if text.startswith(')', at):
            at += 1
        else:
            while True:
                part, at = _type(text, at, depth + 1)
                parts.append(part)
                need(len(parts) <= 64, 'EVM_ABI_TYPE')
                if text.startswith(',', at):
                    at += 1
                    continue
                need(text.startswith(')', at), 'EVM_ABI_TYPE')
                at += 1
                break
        base = ('tuple', parts)
    else:
        found = _ATOMIC.match(text, at)
        need(found is not None, 'EVM_ABI_TYPE')
        name, at = found.group(1), found.end()
        if name in ('address', 'bool', 'string', 'bytes'):
            base = (name,)
        elif name.startswith('bytes'):
            base = ('fixed', int(name[5:]))
        else:
            bits = int(name[4:] if name.startswith('uint') else name[3:])
            need(bits % 8 == 0 and 8 <= bits <= 256, 'EVM_ABI_TYPE')
            base = ('uint' if name.startswith('uint') else 'int', bits)
    while text.startswith('[', at):
        found = re.compile(r'\[([1-9][0-9]{0,3})?\]').match(text, at)
        need(found is not None, 'EVM_ABI_TYPE')
        size = int(found.group(1)) if found.group(1) else None
        need(size is None or size <= MAX_ITEMS, 'EVM_ABI_TYPE')
        base, at, depth = ('array', base, size), found.end(), depth + 1
        need(depth <= MAX_DEPTH, 'EVM_ABI_TYPE')
    return base, at


def _dynamic(kind):
    if kind[0] in ('bytes', 'string'):
        return True
    if kind[0] == 'array':
        return kind[2] is None or _dynamic(kind[1])
    if kind[0] == 'tuple':
        return any(_dynamic(part) for part in kind[1])
    return False


def _static_size(kind):
    if kind[0] == 'array':
        return kind[2] * _static_size(kind[1])
    if kind[0] == 'tuple':
        return sum(_static_size(part) for part in kind[1])
    return 32


def _atom(kind, value):
    name = kind[0]
    if name == 'address':
        return b'\0' * 12 + bytes.fromhex(address(value)[2:])
    if name == 'bool':
        need(type(value) is bool, 'EVM_ABI_VALUE')
        return word(1 if value else 0)
    if name == 'uint':
        need(type(value) is int and 0 <= value < 2 ** kind[1], 'EVM_ABI_VALUE')
        return word(value)
    if name == 'int':
        need(type(value) is int and -2 ** (kind[1] - 1) <= value < 2 ** (kind[1] - 1), 'EVM_ABI_VALUE')
        return (value % 2 ** 256).to_bytes(32, 'big')
    need(type(value) is bytes and len(value) == kind[1], 'EVM_ABI_VALUE')
    return value + b'\0' * (32 - kind[1])


def _encode(kind, value, depth=0):
    need(depth <= MAX_DEPTH, 'EVM_ABI_LIMIT')
    if kind[0] in ('bytes', 'string'):
        if kind[0] == 'string':
            need(type(value) is str and len(value) <= MAX_DATA, 'EVM_ABI_VALUE')
            value = value.encode('utf-8')
        need(type(value) is bytes and len(value) <= MAX_DATA, 'EVM_ABI_VALUE')
        return word(len(value)) + value + b'\0' * (-len(value) % 32)
    if kind[0] == 'array':
        need(type(value) in (list, tuple) and len(value) <= MAX_ITEMS, 'EVM_ABI_VALUE')
        need(kind[2] is None or len(value) == kind[2], 'EVM_ABI_VALUE')
        body = _encode_tuple([kind[1]] * len(value), value, depth + 1)
        return body if kind[2] is not None else word(len(value)) + body
    if kind[0] == 'tuple':
        need(type(value) in (list, tuple) and len(value) == len(kind[1]), 'EVM_ABI_VALUE')
        return _encode_tuple(kind[1], value, depth + 1)
    return _atom(kind, value)


def _encode_tuple(kinds, values, depth=0):
    heads, tails = [], []
    offset = sum(32 if _dynamic(kind) else _static_size(kind) for kind in kinds)
    for kind, value in zip(kinds, values):
        encoded = _encode(kind, value, depth)
        if _dynamic(kind):
            heads.append(word(offset))
            tails.append(encoded)
            offset += len(encoded)
        else:
            heads.append(encoded)
    out = b''.join(heads + tails)
    need(len(out) <= MAX_DATA, 'EVM_ABI_LIMIT')
    return out


def encode(types, values):
    """abi.encode(values) for canonical type strings."""
    need(type(types) in (list, tuple) and type(values) in (list, tuple) and len(types) == len(values) <= 64, 'EVM_ABI_VALUE')
    return _encode_tuple([parse_type(text) for text in types], values)


def call(signature, types, values):
    """Function selector followed by the ABI-encoded arguments."""
    return selector(signature) + encode(types, values)


def _read_word(data, at):
    need(0 <= at and at + 32 <= len(data), 'EVM_ABI_DATA')
    return int.from_bytes(data[at:at + 32], 'big')


def _decode(kind, data, at, depth):
    need(depth <= MAX_DEPTH, 'EVM_ABI_LIMIT')
    name = kind[0]
    if name in ('bytes', 'string'):
        size = _read_word(data, at)
        need(size <= len(data) - at - 32, 'EVM_ABI_DATA')
        raw = data[at + 32:at + 32 + size]
        if name == 'bytes':
            return raw
        try:
            return raw.decode('utf-8')
        except UnicodeError:
            raise ValueError('EVM_ABI_DATA') from None
    if name == 'array':
        if kind[2] is None:
            count = _read_word(data, at)
            need(count <= MAX_ITEMS, 'EVM_ABI_LIMIT')
            return _decode_tuple([kind[1]] * count, data, at + 32, depth + 1)
        return _decode_tuple([kind[1]] * kind[2], data, at, depth + 1)
    if name == 'tuple':
        return _decode_tuple(kind[1], data, at, depth + 1)
    raw = data[at:at + 32]
    need(len(raw) == 32, 'EVM_ABI_DATA')
    number = int.from_bytes(raw, 'big')
    if name == 'address':
        need(raw[:12] == b'\0' * 12, 'EVM_ABI_DATA')
        return '0x' + raw[12:].hex()
    if name == 'bool':
        need(number in (0, 1), 'EVM_ABI_DATA')
        return number == 1
    if name == 'uint':
        need(number < 2 ** kind[1], 'EVM_ABI_DATA')
        return number
    if name == 'int':
        value = number - 2 ** 256 if number >= 2 ** 255 else number
        need(-2 ** (kind[1] - 1) <= value < 2 ** (kind[1] - 1), 'EVM_ABI_DATA')
        return value
    need(raw[kind[1]:] == b'\0' * (32 - kind[1]), 'EVM_ABI_DATA')
    return raw[:kind[1]]


def _decode_tuple(kinds, data, start, depth):
    values, at = [], start
    for kind in kinds:
        if _dynamic(kind):
            offset = _read_word(data, at)
            need(offset < len(data), 'EVM_ABI_DATA')
            values.append(_decode(kind, data, start + offset, depth))
            at += 32
        else:
            values.append(_decode(kind, data, at, depth))
            at += _static_size(kind)
    return values


def decode(types, data):
    """Strict abi.decode: the input must be exactly the canonical encoding of the decoded values."""
    need(type(data) is bytes and len(data) <= MAX_DATA, 'EVM_ABI_LIMIT')
    need(type(types) in (list, tuple) and len(types) <= 64, 'EVM_ABI_TYPE')
    kinds = [parse_type(text) for text in types]
    try:
        values = _decode_tuple(kinds, data, 0, 0)
    except RecursionError:
        raise ValueError('EVM_ABI_LIMIT') from None
    need(_encode_tuple(kinds, values) == data, 'EVM_ABI_DATA')
    return values


def decode_call(signature, types, data):
    need(type(data) is bytes and len(data) >= 4 and data[:4] == selector(signature), 'EVM_ABI_DATA')
    return decode(types, data[4:])


def encode_packed(types, values):
    """Solidity non-standard packed mode for atomic, bytes and string values (no arrays or tuples)."""
    need(type(types) in (list, tuple) and type(values) in (list, tuple) and len(types) == len(values) <= 64, 'EVM_ABI_VALUE')
    out = b''
    for text, value in zip(types, values):
        kind = parse_type(text)
        name = kind[0]
        need(name not in ('array', 'tuple'), 'EVM_ABI_TYPE')
        if name == 'address':
            out += bytes.fromhex(address(value)[2:])
        elif name == 'bool':
            need(type(value) is bool, 'EVM_ABI_VALUE')
            out += b'\1' if value else b'\0'
        elif name in ('uint', 'int'):
            out += _atom(kind, value)[32 - kind[1] // 8:]
        elif name == 'fixed':
            out += _atom(kind, value)[:kind[1]]
        elif name == 'string':
            need(type(value) is str and len(value) <= MAX_DATA, 'EVM_ABI_VALUE')
            out += value.encode('utf-8')
        else:
            need(type(value) is bytes and len(value) <= MAX_DATA, 'EVM_ABI_VALUE')
            out += value
        need(len(out) <= MAX_DATA, 'EVM_ABI_LIMIT')
    return out


# EIP-712 typed structured data ----------------------------------------------

def _typed_value(kind, value):
    """A JSON typed-data value as the Python value _atom expects."""
    name = kind[0]
    if name in ('uint', 'int'):
        if type(value) is str:
            need(re.fullmatch(r'-?(0|[1-9][0-9]{0,77})', value) is not None, 'EVM_TYPED_DATA')
            value = int(value)
        need(type(value) is int, 'EVM_TYPED_DATA')
        return value
    if name in ('fixed', 'bytes'):
        return unhex(value, kind[1] if name == 'fixed' else None, 'EVM_TYPED_DATA')
    if name == 'address':
        need(type(value) is str, 'EVM_TYPED_DATA')
    if name == 'string':
        need(type(value) is str and len(value) <= MAX_TEXT, 'EVM_TYPED_DATA')
    if name == 'bool':
        need(type(value) is bool, 'EVM_TYPED_DATA')
    return value


def _struct_name(text):
    """The struct named by a member type, or None for an atomic or dynamic type."""
    base = text.split('[', 1)[0]
    return None if re.fullmatch(r'address|bool|string|bytes(3[0-2]|[12][0-9]|[1-9])?|u?int[0-9]{1,3}', base) else base


def _check_types(types):
    need(type(types) is dict and 0 < len(types) <= 64, 'EVM_TYPED_DATA')
    for name, fields in types.items():
        need(type(name) is str and IDENTIFIER.fullmatch(name) is not None, 'EVM_TYPED_DATA')
        need(type(fields) is list and len(fields) <= 64, 'EVM_TYPED_DATA')
        seen = set()
        for field in fields:
            need(type(field) is dict and set(field) == {'name', 'type'} and type(field['name']) is str
                 and IDENTIFIER.fullmatch(field['name']) is not None and field['name'] not in seen
                 and type(field['type']) is str, 'EVM_TYPED_DATA')
            seen.add(field['name'])
            struct = _struct_name(field['type'])
            if struct is None:
                parse_type(field['type'])
            else:
                need(struct in types and re.fullmatch(IDENTIFIER.pattern[:-2] + r'(\[([1-9][0-9]{0,3})?\])*\Z',
                                                      field['type']) is not None, 'EVM_TYPED_DATA')


def _dependencies(primary, types, found=None, depth=0):
    need(depth <= MAX_DEPTH and primary in types, 'EVM_TYPED_DATA')
    found = set() if found is None else found
    if primary in found:
        return found
    found.add(primary)
    for field in types[primary]:
        struct = _struct_name(field['type'])
        if struct is not None:
            _dependencies(struct, types, found, depth + 1)
    return found


def encode_type(primary, types):
    _check_types(types)
    rest = sorted(_dependencies(primary, types) - {primary})
    return ''.join(name + '(' + ','.join(f['type'] + ' ' + f['name'] for f in types[name]) + ')' for name in [primary] + rest)


def type_hash(primary, types):
    return keccak(encode_type(primary, types).encode('ascii'))


def _field(text, types, value, depth):
    need(depth <= MAX_DEPTH, 'EVM_TYPED_DATA')
    if text.endswith(']'):
        inner, _, size = text[:-1].rpartition('[')
        need(type(value) is list and len(value) <= MAX_ITEMS and (not size or len(value) == int(size)), 'EVM_TYPED_DATA')
        return keccak(b''.join(_field(inner, types, item, depth + 1) for item in value))
    if text in types:
        return hash_struct(text, types, value, depth + 1)
    kind = parse_type(text)
    if kind[0] in ('bytes', 'string'):
        raw = unhex(value, None, 'EVM_TYPED_DATA') if kind[0] == 'bytes' else _typed_value(kind, value).encode('utf-8')
        return keccak(raw)
    try:
        return _atom(kind, _typed_value(kind, value))
    except ValueError:
        raise ValueError('EVM_TYPED_DATA') from None


def encode_data(primary, types, value, depth=0):
    need(primary in types and type(value) is dict and set(value) == {f['name'] for f in types[primary]}, 'EVM_TYPED_DATA')
    return type_hash(primary, types) + b''.join(_field(f['type'], types, value[f['name']], depth) for f in types[primary])


def hash_struct(primary, types, value, depth=0):
    need(depth <= MAX_DEPTH, 'EVM_TYPED_DATA')
    return keccak(encode_data(primary, types, value, depth))


def _domain(types, domain):
    fields = types.get('EIP712Domain')
    need(type(fields) is list and fields, 'EVM_TYPED_DOMAIN')
    allowed = [{'name': name, 'type': kind} for name, kind in DOMAIN_FIELDS]
    order = [allowed.index(field) if field in allowed else -1 for field in fields]
    need(-1 not in order and order == sorted(set(order)), 'EVM_TYPED_DOMAIN')
    need(type(domain) is dict and set(domain) == {field['name'] for field in fields}, 'EVM_TYPED_DOMAIN')


def domain_separator(types, domain):
    _check_types(types)
    _domain(types, domain)
    return hash_struct('EIP712Domain', types, domain)


def typed_data_digest(typed):
    """keccak256(0x19 0x01 || domainSeparator || hashStruct(message)) for eth_signTypedData_v4 JSON."""
    need(type(typed) is dict and set(typed) == {'types', 'primaryType', 'domain', 'message'}, 'EVM_TYPED_DATA')
    types, primary = typed['types'], typed['primaryType']
    need(type(primary) is str and primary != 'EIP712Domain', 'EVM_TYPED_DATA')
    separator = domain_separator(types, typed['domain'])
    return keccak(b'\x19\x01' + separator + hash_struct(primary, types, typed['message']))


# secp256k1 -----------------------------------------------------------------

N = _curve._N


def address_of(private_key):
    """The lowercase Ethereum address of an owner-held secp256k1 key."""
    try:
        return _curve.ethereum_address(_curve.public_point(private_key))
    except ValueError:
        raise ValueError('EVM_KEY') from None


def sign_digest(private_key, digest):
    """Owner action: a deterministic (RFC 6979) low-s signature {r, s, v, bytes} over a 32-byte digest."""
    need(type(digest) is bytes and len(digest) == 32, 'EVM_SIGNATURE')
    address_of(private_key)
    return _curve._sign_digest(private_key, digest)


def split_signature(value):
    """(v, r, s) from 65 bytes or 0x hex; v 0/1 is read as 27/28."""
    raw = unhex(value, 65, 'EVM_SIGNATURE') if type(value) is str else value
    need(type(raw) is bytes and len(raw) == 65, 'EVM_SIGNATURE')
    v = raw[64] + 27 if raw[64] in (0, 1) else raw[64]
    need(v in (27, 28), 'EVM_SIGNATURE')
    return v, int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:64], 'big')


def recover_point(digest, recovery, r, s, *, low_s=True):
    """The public point that signed digest, for recovery id 0-3. high-s only when the protocol allows it."""
    need(type(digest) is bytes and len(digest) == 32, 'EVM_SIGNATURE')
    need(type(recovery) is int and 0 <= recovery <= 3, 'EVM_SIGNATURE')
    need(type(r) is int and type(s) is int and 1 <= r < N and 1 <= s < N, 'EVM_SIGNATURE')
    need(not low_s or s <= N // 2, 'EVM_SIGNATURE')
    x = r + N * (recovery >> 1)
    need(x < _curve._P, 'EVM_RECOVERY')
    y2 = (pow(x, 3, _curve._P) + 7) % _curve._P
    y = pow(y2, (_curve._P + 1) // 4, _curve._P)
    need(y * y % _curve._P == y2, 'EVM_RECOVERY')
    if y % 2 != recovery & 1:
        y = _curve._P - y
    inverse = _curve._inv(r, N)
    message = int.from_bytes(digest, 'big') % N
    point = _curve._add(_curve._mul(-message * inverse % N, _curve._G), _curve._mul(s * inverse % N, (x, y)))
    need(point is not None, 'EVM_RECOVERY')
    return point


def recover(digest, signature):
    """The lowercase address that produced a low-s r || s || v signature over digest."""
    v, r, s = split_signature(signature)
    return _curve.ethereum_address(recover_point(digest, v - 27, r, s))


def compress(point):
    return bytes([2 + (point[1] & 1)]) + point[0].to_bytes(32, 'big')


def describe():
    return {'abi': 'Solidity contract ABI 0.8.x: head/tail and packed modes; strict canonical decoding',
            'typed_data': 'EIP-712 (Final): encodeType, encodeData, hashStruct, domain separator, 0x1901 digest',
            'addresses': 'EIP-55 checksums', 'curve': 'secp256k1 recovery; signing via cryptography, RFC 6979 low-s',
            'limits': {'data_bytes': MAX_DATA, 'items': MAX_ITEMS, 'depth': MAX_DEPTH},
            'network_contacted': False, 'submitted': False, 'execution_authorized': False}
