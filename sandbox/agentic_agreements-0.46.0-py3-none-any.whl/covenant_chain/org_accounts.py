"""Organisation accounts: an org identity that owns agents and delegates roles.

An org is a did:aap account. Its role log is an append-only, hash-linked list
of signed entries:

- ORG_CREATE, signed by the org account key, names the first admins, the admin
  quorum for role changes, and the approval quorum for spends above an agent's
  own limit.
- ROLE_GRANT and ROLE_REVOKE, each signed by an admin quorum. A grant names one
  member key, one role (admin, approver, agent, auditor), limits and an expiry
  height. A revoke names the grant entry it ends.

Roles map onto native authority:
- agent: ``give_payloads`` returns one native GIVE per spend limit, issued by the
  org account to the agent key (delegate false). The reducer then enforces the
  limit itself. ``principal_policy`` narrows that grant further with the
  existing principal-override profile.
- approver: may approve a spend above an agent's limit, up to the approver's own
  approve limit. ``spend_decision`` checks the quorum; the approved amount is a
  separate one-off GIVE.
- auditor: may request ``audit_export``; it never signs authority.
- admin: signs role changes with the other admins.
A revoke maps to native REVOKE for every grant the revoked role produced.

What this proves: the log is internally consistent, every change carries the
signatures its quorum requires, and a role in force at the log head is exactly
what the entries say. It does not prove the log is complete (an org can keep a
second log), that the org account key is safe, or that an off-chain approval was
honoured; only native GIVE limits are enforced by consensus. Anchor the log head
with SAY to timestamp it.
"""
from copy import deepcopy
import re

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify
from .scale.identity import did

VERSION = 'covenant-org-account/0.1'
ENTRY_LABEL = 'COVENANT-ORG-ENTRY-0.1'
APPROVAL_LABEL = 'COVENANT-ORG-SPEND-APPROVAL-0.1'
EXPORT_LABEL = 'COVENANT-ORG-AUDIT-EXPORT-0.1'
ROLES = ('admin', 'approver', 'agent', 'auditor')
KINDS = ('ORG_CREATE', 'ROLE_GRANT', 'ROLE_REVOKE')
EFFECTS = ('AUTHORIZE', 'CONSUME', 'TRANSFER')
MAX_ENTRIES = 4096
LABEL = re.compile(r'[A-Za-z0-9._-]{1,80}\Z')


def _limits(value):
    need(type(value) is dict and len(value) <= 8, 'ORG_LIMITS')
    for resource, amount in value.items():
        need(type(resource) is str and LABEL.fullmatch(resource) is not None, 'ORG_LIMITS')
        integer(amount, True)
    return value


def _labels(value, allowed=None):
    need(type(value) is list and value and value == sorted(set(value)) and len(value) <= 16, 'ORG_SCOPE')
    need(all(type(v) is str and LABEL.fullmatch(v) for v in value), 'ORG_SCOPE')
    if allowed is not None:
        need(set(value) <= set(allowed), 'ORG_SCOPE')
    return value


def create_body(org, chain, admins, *, admin_quorum=1, approval_quorum=1, note=''):
    key(org)
    key(chain)
    need(type(admins) is list and 1 <= len(admins) <= 16 and admins == sorted(set(admins)), 'ORG_ADMINS')
    for admin in admins:
        verification_key(admin)
        need(admin != org, 'ORG_ADMIN_IS_ORG')
    integer(admin_quorum, True)
    integer(approval_quorum, True)
    need(admin_quorum <= len(admins) and approval_quorum <= 16, 'ORG_QUORUM')
    need(type(note) is str and len(note) <= 512, 'ORG_NOTE')
    return {'version': VERSION, 'org': org, 'chain': chain, 'sequence': 0, 'previous': None, 'kind': 'ORG_CREATE',
            'change': {'admins': list(admins), 'admin_quorum': admin_quorum, 'approval_quorum': approval_quorum,
                       'note': note}}


def grant_change(member, role, *, expiry, spend=None, approve=None, effects=None, profiles=None, note=''):
    """One role assignment. Spend limits apply to agents, approve limits to approvers."""
    verification_key(member)
    need(role in ROLES, 'ORG_ROLE')
    integer(expiry, True)
    spend = _limits(deepcopy(spend or {}))
    approve = _limits(deepcopy(approve or {}))
    need(bool(spend) == (role == 'agent'), 'ORG_ROLE_LIMITS')
    need(bool(approve) == (role == 'approver'), 'ORG_ROLE_LIMITS')
    if role == 'agent':
        effects = _labels(effects or ['TRANSFER'], EFFECTS)
        profiles = _labels(profiles or [])
    else:
        need(effects is None and profiles is None, 'ORG_ROLE_LIMITS')
    need(type(note) is str and len(note) <= 512, 'ORG_NOTE')
    return {'member': member, 'role': role, 'expiry': expiry, 'spend': spend, 'approve': approve,
            'effects': effects, 'profiles': profiles, 'note': note}


def next_body(log, kind, change):
    """The body admins sign for the next entry of ``log``."""
    need(kind in ('ROLE_GRANT', 'ROLE_REVOKE'), 'ORG_KIND')
    need(type(change) is dict, 'ORG_CHANGE')
    state = replay(log)
    if kind == 'ROLE_GRANT':
        checked = grant_change(change.get('member', ''), change.get('role'), expiry=change.get('expiry'),
                               spend=change.get('spend'), approve=change.get('approve'),
                               effects=change.get('effects'), profiles=change.get('profiles'),
                               note=change.get('note', ''))
        need(checked == change, 'ORG_CHANGE')
    else:
        exact(change, 'grant reason')
        key(change['grant'])
        need(type(change['reason']) is str and len(change['reason']) <= 512, 'ORG_NOTE')
    return {'version': VERSION, 'org': state['org'], 'chain': state['chain'], 'sequence': len(log),
            'previous': state['head'], 'kind': kind, 'change': deepcopy(change)}


def entry(body, signers):
    """Wrap a body with signatures from (public, private) pairs."""
    need(type(signers) is list and signers, 'ORG_SIGNERS')
    signatures = [{'signer': public_key(private), 'signature': sign(private, ENTRY_LABEL, body)} for private in signers]
    signatures.sort(key=lambda row: row['signer'])
    return {'id': digest(ENTRY_LABEL, body), 'body': deepcopy(body), 'signatures': signatures}


def _active(state, member, role, height=None):
    for ref, row in state['grants'].items():
        if row['member'] == member and row['role'] == role and not row['revoked']:
            if height is None or height <= row['expiry']:
                return ref, row
    return None, None


def replay(log, *, height=None):
    """Verify every entry and return the role state at the log head."""
    need(type(log) is list and 1 <= len(log) <= MAX_ENTRIES, 'ORG_LOG')
    if height is not None:
        integer(height)
    canonical(log)
    state = None
    for index, item in enumerate(log):
        need(type(item) is dict and set(item) == {'id', 'body', 'signatures'}, 'ORG_ENTRY')
        body = item['body']
        exact(body, 'version org chain sequence previous kind change')
        need(body['version'] == VERSION and body['kind'] in KINDS, 'ORG_ENTRY')
        need(type(body['sequence']) is int and body['sequence'] == index, 'ORG_SEQUENCE')
        need(item['id'] == digest(ENTRY_LABEL, body), 'ORG_ENTRY_ID')
        rows = item['signatures']
        need(type(rows) is list and rows and len({r.get('signer') for r in rows if type(r) is dict}) == len(rows),
             'ORG_SIGNERS')
        for row in rows:
            exact(row, 'signer signature')
            verify(row['signer'], ENTRY_LABEL, body, row['signature'])
        signers = {row['signer'] for row in rows}
        if index == 0:
            need(body['kind'] == 'ORG_CREATE' and body['previous'] is None, 'ORG_CREATE_FIRST')
            change = body['change']
            again = create_body(body['org'], body['chain'], change.get('admins'), admin_quorum=change.get('admin_quorum'),
                                approval_quorum=change.get('approval_quorum'), note=change.get('note', ''))
            need(again == body, 'ORG_CREATE')
            need(signers == {body['org']}, 'ORG_CREATE_SIGNER')
            state = {'org': body['org'], 'chain': body['chain'], 'admin_quorum': change['admin_quorum'],
                     'approval_quorum': change['approval_quorum'], 'grants': {}, 'head': item['id'],
                     'created': item['id']}
            for admin in change['admins']:
                state['grants'][digest('COVENANT-ORG-FOUNDING-ADMIN-0.1', {'org': body['org'], 'admin': admin})] = {
                    'member': admin, 'role': 'admin', 'expiry': 2 ** 53 - 1, 'spend': {}, 'approve': {},
                    'effects': None, 'profiles': None, 'note': 'founding admin', 'revoked': False, 'entry': item['id']}
            continue
        need(body['kind'] != 'ORG_CREATE', 'ORG_CREATE_FIRST')
        need(body['org'] == state['org'] and body['chain'] == state['chain'], 'ORG_CONTEXT')
        need(body['previous'] == state['head'], 'ORG_CHAIN')
        admins = {row['member'] for row in state['grants'].values()
                  if row['role'] == 'admin' and not row['revoked']
                  and (height is None or height <= row['expiry'])}
        need(signers <= admins and len(signers) >= state['admin_quorum'], 'ORG_ADMIN_QUORUM')
        change = body['change']
        if body['kind'] == 'ROLE_GRANT':
            checked = grant_change(change.get('member', ''), change.get('role'), expiry=change.get('expiry'),
                                   spend=change.get('spend'), approve=change.get('approve'),
                                   effects=change.get('effects'), profiles=change.get('profiles'),
                                   note=change.get('note', ''))
            need(checked == change and change['member'] != state['org'], 'ORG_CHANGE')
            need(_active(state, change['member'], change['role'])[0] is None, 'ORG_ROLE_ALREADY_HELD')
            state['grants'][item['id']] = {**deepcopy(change), 'revoked': False, 'entry': item['id']}
        else:
            exact(change, 'grant reason')
            target = state['grants'].get(change['grant'])
            need(target is not None and not target['revoked'], 'ORG_REVOKE_TARGET')
            target['revoked'] = True
            target['revoked_by'] = item['id']
            remaining = [row for row in state['grants'].values() if row['role'] == 'admin' and not row['revoked']]
            need(len(remaining) >= state['admin_quorum'], 'ORG_LAST_ADMINS')
        state['head'] = item['id']
    return state


def roles(log, *, height=None):
    state = replay(log, height=height)
    live = []
    for ref, row in sorted(state['grants'].items()):
        if row['revoked'] or (height is not None and height > row['expiry']):
            continue
        live.append({'grant': ref, 'member': row['member'], 'role': row['role'], 'expiry': row['expiry'],
                     'spend': row['spend'], 'approve': row['approve']})
    return {'org': did(state['org'], state['chain']), 'head': state['head'], 'admin_quorum': state['admin_quorum'],
            'approval_quorum': state['approval_quorum'], 'roles': live, 'execution_authorized': False}


def give_payloads(log, member, height):
    """Native GIVE payloads, issued by the org account, for one agent role in force."""
    integer(height)
    state = replay(log, height=height)
    ref, row = _active(state, member, 'agent', height)
    need(row is not None, 'ORG_NOT_AN_AGENT')
    out = []
    for resource, limit in sorted(row['spend'].items()):
        out.append({'role_grant': ref, 'actor': state['org'], 'op': 'GIVE',
                    'payload': {'parent': None, 'holder': member, 'resource': resource, 'limit': limit,
                                'expiry': row['expiry'], 'effects': list(row['effects']),
                                'profiles': list(row['profiles']), 'delegate': False}})
    return {'org': state['org'], 'member': member, 'gives': out, 'signed': False, 'execution_authorized': False}


def principal_policy(log, member, *, grant, permit, action, context, counterparties, window, height, spend=None):
    """Narrow a committed org GIVE with the existing principal-override profile."""
    from . import principal
    state = replay(log, height=height)
    ref, row = _active(state, member, 'agent', height)
    need(row is not None, 'ORG_NOT_AN_AGENT')
    spend = deepcopy(spend if spend is not None else row['spend'])
    need(all(resource in row['spend'] and amount <= row['spend'][resource] for resource, amount in spend.items()),
         'ORG_SPEND_ABOVE_ROLE')
    return principal.draft(state['org'], member, grant, permit, action, context, spend, row['expiry'],
                           row['effects'], row['profiles'], counterparties, window)


def spend_request(log, agent, *, resource, amount, counterparty, purpose, height):
    integer(amount, True)
    integer(height)
    key(counterparty)
    need(type(resource) is str and LABEL.fullmatch(resource), 'ORG_LIMITS')
    need(type(purpose) is str and 0 < len(purpose) <= 512, 'ORG_NOTE')
    state = replay(log, height=height)
    _, row = _active(state, agent, 'agent', height)
    need(row is not None, 'ORG_NOT_AN_AGENT')
    return {'version': VERSION, 'org': state['org'], 'head': state['head'], 'agent': agent, 'resource': resource,
            'amount': amount, 'counterparty': counterparty, 'purpose': purpose, 'height': height}


def approve(request, approver_private):
    return {'approver': public_key(approver_private), 'signature': sign(approver_private, APPROVAL_LABEL, request)}


def spend_decision(log, request, approvals):
    """Within the agent's own limit: allowed. Above it: needs the approval quorum.

    An allowed spend above the limit is returned as a one-off GIVE the org key must sign.
    """
    exact(request, 'version org head agent resource amount counterparty purpose height')
    rebuilt = spend_request(log, request['agent'], resource=request['resource'], amount=request['amount'],
                            counterparty=request['counterparty'], purpose=request['purpose'], height=request['height'])
    need(request['org'] == rebuilt['org'] and request['head'] == rebuilt['head'], 'ORG_REQUEST_STALE')
    need(canonical(rebuilt) == canonical(request), 'ORG_REQUEST')
    state = replay(log, height=request['height'])
    need(request['org'] == state['org'] and request['head'] == state['head'], 'ORG_REQUEST_STALE')
    _, row = _active(state, request['agent'], 'agent', request['height'])
    need(row is not None, 'ORG_NOT_AN_AGENT')
    own = row['spend'].get(request['resource'], 0)
    if request['amount'] <= own:
        return {'decision': 'WITHIN_AGENT_LIMIT', 'approvals_needed': 0, 'give': None,
                'native_limit_enforced': 'ONLY_WITH_A_SEPARATELY_ADOPTED_VALID_NATIVE_GRANT',
                'snapshot_currentness': 'CALLER_SUPPLIED_LOG_AND_HEIGHT_NOT_INDEPENDENTLY_CHECKED',
                'execution_authorized': False}
    need(type(approvals) is list and len({a.get('approver') for a in approvals if type(a) is dict}) == len(approvals),
         'ORG_APPROVALS')
    counted = []
    for row_ in approvals:
        exact(row_, 'approver signature')
        ref, grant = _active(state, row_['approver'], 'approver', request['height'])
        need(grant is not None, 'ORG_NOT_AN_APPROVER')
        need(row_['approver'] != request['agent'], 'ORG_SELF_APPROVAL')
        need(grant['approve'].get(request['resource'], 0) >= request['amount'], 'ORG_APPROVER_LIMIT')
        verify(row_['approver'], APPROVAL_LABEL, request, row_['signature'])
        counted.append(row_['approver'])
    need(len(counted) >= state['approval_quorum'], 'ORG_APPROVAL_QUORUM')
    give = {'parent': None, 'holder': request['agent'], 'resource': request['resource'], 'limit': request['amount'],
            'expiry': min(row['expiry'], request['height'] + 1000), 'effects': list(row['effects']),
            'profiles': list(row['profiles']), 'delegate': False}
    return {'decision': 'APPROVED_ABOVE_AGENT_LIMIT', 'approvals': sorted(counted), 'give': give,
            'native_limit_enforced': 'ONLY_AFTER_THE_ORG_KEY_SIGNS_THIS_GIVE', 'execution_authorized': False}


def revoke_payloads(log, revoke_entry, native_grants):
    """Native REVOKE payloads for every committed grant that a revoked role produced.

    ``native_grants`` maps a native grant id to the role grant entry it came from
    (the owner keeps this map when it submits each GIVE).
    """
    state = replay(log)
    target = next((item for item in log if item['id'] == revoke_entry), None)
    need(target is not None and target['body']['kind'] == 'ROLE_REVOKE', 'ORG_REVOKE_TARGET')
    role_grant = target['body']['change']['grant']
    need(type(native_grants) is dict, 'ORG_NATIVE_GRANTS')
    out = []
    for grant, source in sorted(native_grants.items()):
        key(grant)
        if source == role_grant:
            out.append({'actor': state['org'], 'op': 'REVOKE', 'payload': {'grant': grant}})
    return {'role_grant': role_grant, 'revokes': out, 'signed': False, 'execution_authorized': False}


def audit_export(log, requester, signature, *, as_of, height=None):
    """Verify an export signature; role expiry needs a separate caller height.

    Historical as_of is an export timestamp, not a chain height. Without a
    supplied height this checks unrevoked role membership, with expiry UNKNOWN.
    Neither timestamp nor height establishes independent currentness.
    """
    integer(as_of)
    if height is not None:
        integer(height)
    state = replay(log)
    request = {'version': VERSION, 'org': state['org'], 'head': state['head'], 'as_of': as_of, 'requester': requester}
    need(_active(state, requester, 'auditor', height)[0] is not None or _active(state, requester, 'admin', height)[0] is not None,
         'ORG_AUDIT_ROLE')
    verify(requester, EXPORT_LABEL, request, signature)
    rows = []
    for item in log:
        body = item['body']
        rows.append({'sequence': body['sequence'], 'id': item['id'], 'kind': body['kind'],
                     'signers': [row['signer'] for row in item['signatures']], 'change': deepcopy(body['change'])})
    document = {'version': VERSION, 'org': did(state['org'], state['chain']), 'head': state['head'],
                'entries': rows, 'roles': roles(log, height=height)['roles'], 'request': request,
                'role_expiry': 'UNKNOWN_WITHOUT_HEIGHT' if height is None else 'CHECKED_AT_CALLER_HEIGHT',
                'currentness': 'CALLER_SUPPLIED_LOG_AND_HEIGHT_NOT_INDEPENDENTLY_OBSERVED',
                'log_sha256': digest(EXPORT_LABEL, log),
                'limits': ['complete only for this log; a second log is not detectable here',
                           'off-chain approvals are not enforced by consensus; native GIVE limits are'],
                'execution_authorized': False}
    return document


def export_request(log, requester, *, as_of):
    state = replay(log)
    verification_key(requester)
    integer(as_of)
    return {'version': VERSION, 'org': state['org'], 'head': state['head'], 'as_of': as_of, 'requester': requester}


def profile():
    return {'version': VERSION, 'roles': list(ROLES), 'entries': list(KINDS),
            'signed_by': {'ORG_CREATE': 'org account key', 'ROLE_GRANT': 'admin quorum', 'ROLE_REVOKE': 'admin quorum'},
            'maps_to': {'agent': 'native GIVE (limit enforced by consensus) + principal-override policy',
                        'approver': 'quorum approval for a one-off GIVE above the agent limit',
                        'auditor': 'signed audit export', 'revoke': 'native REVOKE of every grant the role produced'},
            'does_not_prove': ['that the log is the only log of this org', 'that off-chain approvals were honoured',
                               'that the org account key is safe; protect it with continuity guardians'],
            'consensus_change': None, 'execution_authorized': False}
