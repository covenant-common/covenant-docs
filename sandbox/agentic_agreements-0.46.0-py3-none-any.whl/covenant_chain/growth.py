"""Growth incentives as views and existing escrows.

The named rule set is ``covenant-native/0.15`` (``network-incentives``). It
does not add a reducer operation. Payouts are ``ECON_REWARD_CREATE`` leaves.
A governor may also adopt one ``REFERRAL`` beneficiary row inside the existing
10,000 basis points, the same route PR #23 uses. That row does not set the
size. The size is the quality weight.

A referral is one level. It is paid only after the referred owner has three
settled covenants with three trusted counterparties inside the 90-block
window. Twenty percent is held until the next epoch and omitted if the
covenant is overturned. Clicks, raw shares, streaks, activity badges, quests
and points are not paid.
"""
from copy import deepcopy
import secrets

from . import webauthn
from .crypto import canonical, digest, exact, integer, key, need, verify
from .economics import allocation_manifest, validate_policy
from .incentives import (
    CONSENSUS_CHANGE, DIVERSITY_CAP, HOLDBACK_BPS, REFERRAL_MIN_SETTLED, REFERRAL_MIN_TRUSTED,
    REFERRAL_WINDOW, RULE_NAME, RULE_SET, SUNSET_BLOCKS, WINDOW_LABEL, demand_sponsor,
    guarantee_amount, healthy_epoch, holdback_split, quality_weight, short_side,
)

VERSION = 'covenant-growth/0.1'
ATTRIBUTION_LABEL = 'COVENANT-GROWTH-ATTRIBUTION-0.1'
SYBIL = {'PASSKEY', 'PERSONHOOD', 'STAKE'}
OUTCOMES = {'KEPT', 'KEPT_LATE', 'PARTIAL', 'SILENT', 'CHALLENGED_WON', 'CHALLENGED_LOST',
            'DEFAULTED', 'RELEASED_UNDECIDED', 'OPEN'}
DEFAULT_POLICY = {
    'resource': 'payment',
    'signup_bonus': 5,
    'per_owner_cap': 1000,
    'max_tail': 10000,
    'trust_star': 1,
    'weight_unit': 10000,
    'epoch_blocks': 90,
    'referral_route_bps': 500,
    'collusion_jaccard_bps': 8000,
    'guarantee': 100,
    'unit_fee': 1,
    'sybil': None,
    'height_windows_are': WINDOW_LABEL,
}


def _policy(policy):
    exact(policy, ' '.join(DEFAULT_POLICY))
    need(type(policy['resource']) is str and 0 < len(policy['resource']) <= 80, 'GROWTH_RESOURCE')
    for name in ('signup_bonus', 'per_owner_cap', 'max_tail', 'trust_star', 'weight_unit',
                 'epoch_blocks', 'referral_route_bps', 'guarantee', 'unit_fee'):
        integer(policy[name], True)
    integer(policy['collusion_jaccard_bps'])
    need(policy['collusion_jaccard_bps'] <= 10000, 'GROWTH_BPS')
    need(policy['referral_route_bps'] <= 5000, 'GROWTH_BENEFICIARY')
    need(1 <= policy['epoch_blocks'] <= 100000, 'GROWTH_EPOCH')
    need(policy['sybil'] is None or policy['sybil'] in SYBIL, 'GROWTH_SYBIL')
    need(policy['height_windows_are'] == WINDOW_LABEL, 'GROWTH_WINDOWS')
    canonical(policy)
    return policy


def payout_resource(token_policy, fallback):
    """Prefer the adopted token. Do not mint one."""
    if token_policy is None:
        need(type(fallback) is str and 0 < len(fallback) <= 80, 'GROWTH_RESOURCE')
        return {'resource': fallback, 'preference': 'FEE_RESOURCE', 'mint': False,
                'general_access_requires_token': False}
    from .payment_rails import token_benefits
    benefits = token_benefits(token_policy)
    return {'resource': benefits['resource'], 'preference': 'TOKEN', 'mint': False,
            'benefits': benefits, 'general_access_requires_token': False}


def placement_boundary():
    """Ads stay explicit escrow. This layer does not weight discovery rank."""
    return {
        'native_ad_op': False,
        'rank_weight': 'NOT_ADJUSTED',
        'sponsored_placement': 'EXPLICIT_ESCROW_ONLY',
        'escrows': ['ECON_SPONSOR_CREATE', 'ECON_REWARD_CREATE'],
        'promote_signal': 'EXISTING_FORUM_SIGNAL_NOT_A_PAYMENT',
        'pr19': 'NOT_ON_MAIN_SO_THIS_LAYER_DOES_NOT_FORK_DESIRE_OR_RANK',
        'execution_authorized': False,
    }


def share_card(receipt, *, opt_in, referrer, platforms):
    """Opt-in redacted preview. The card itself is not a payment."""
    need(opt_in is True, 'SHARE_OPT_IN_REQUIRED')
    key(referrer)
    exact(receipt, 'chain agreement status terms_hash role quantity parties')
    key(receipt['chain'])
    key(receipt['agreement'])
    key(receipt['terms_hash'])
    need(receipt['status'] in {'BOUND', 'SETTLED'}, 'SHARE_STATUS')
    need(receipt['role'] in {'COUNTERPARTY', 'RESOLVER', 'APPEAL_RESOLVER', 'AGENT', 'PARTY'}, 'SHARE_ROLE')
    integer(receipt['quantity'], True)
    need(type(receipt['parties']) is list and 1 <= len(receipt['parties']) <= 4, 'SHARE_PARTIES')
    for party in receipt['parties']:
        key(party)
    need(type(platforms) is list and 1 <= len(platforms) <= 5, 'SHARE_PLATFORM')
    allowed = {'open_graph', 'opengraph', 'x', 'linkedin', 'farcaster', 'telegram'}
    need(len(platforms) == len(set(platforms)) and set(platforms) <= allowed, 'SHARE_PLATFORM')
    redacted_parties = [party[:8] + '...' for party in receipt['parties']]
    public = {
        'chain': receipt['chain'],
        'agreement': receipt['agreement'],
        'status': receipt['status'],
        'terms_hash': receipt['terms_hash'],
        'role': receipt['role'],
        'parties': redacted_parties,
    }
    ident = digest('COVENANT-GROWTH-SHARE-0.1', {'referrer': referrer, 'public': public})
    link = 'covenant:share/' + ident + '?ref=' + referrer
    title = 'Covenant ' + receipt['status'].lower() + ' receipt'
    description = 'Redacted receipt ' + receipt['agreement'][:8] + '. Quantity and full keys are omitted.'
    previews = {}
    for name in platforms:
        previews[name] = {
            'title': title,
            'description': description,
            'url': link,
            'image': None,
            'fetched': False,
        }
    if 'open_graph' in previews:
        previews['open_graph']['type'] = 'article'
    if 'farcaster' in previews:
        previews['farcaster']['embeds'] = []
    card = {
        'version': VERSION,
        'id': ident,
        'referrer': referrer,
        'public': public,
        'omitted': ['quantity', 'full_party_keys', 'terms_body', 'fees'],
        'platforms': previews,
        'attribution': link,
        'reward': None,
        'payment': 'NOT_FOR_THE_SHARE_OR_THE_CLICK',
        'execution_authorized': False,
    }
    canonical(card)
    return card


def attribution(principal_key, *, agent, referee, share, grant=None):
    """The principal signs. An agent who is not the principal needs a grant id."""
    from .crypto import public_key, sign
    principal = public_key(principal_key)
    key(agent)
    key(referee)
    key(share)
    if agent == principal:
        need(grant is None, 'GROWTH_GRANT')
    else:
        key(grant)
    body = {'version': VERSION, 'principal': principal, 'agent': agent, 'referee': referee,
            'share': share, 'grant': grant}
    canonical(body)
    return {'body': body, 'signature': sign(principal_key, ATTRIBUTION_LABEL, body),
            'principal_answerable': True, 'execution_authorized': False}


def verify_attribution(record):
    exact(record, 'body signature principal_answerable execution_authorized')
    body = record['body']
    exact(body, 'version principal agent referee share grant')
    need(body['version'] == VERSION and record['principal_answerable'] is True, 'GROWTH_ATTRIBUTION')
    need(record['execution_authorized'] is False, 'GROWTH_ATTRIBUTION')
    verify(body['principal'], ATTRIBUTION_LABEL, body, record['signature'])
    if body['agent'] != body['principal']:
        key(body['grant'])
    else:
        need(body['grant'] is None, 'GROWTH_GRANT')
    return deepcopy(body)


def referral_row(policy, account, resources, bps=None):
    """PR #23 route: purpose ``REFERRAL`` inside the same 10,000. The bps do not set the payout."""
    route = DEFAULT_POLICY['referral_route_bps'] if bps is None else bps
    updated = fit_beneficiary(policy, account, route, 'REFERRAL', resources)
    return updated


def fit_beneficiary(policy, account, bps, purpose, resources):
    """One referral row inside the existing 10,000. Not a second split."""
    key(account)
    integer(bps, True)
    need(bps <= 5000, 'GROWTH_BENEFICIARY')
    need(type(purpose) is str and 0 < len(purpose) <= 80, 'GROWTH_BENEFICIARY')
    updated = deepcopy(policy)
    rows = updated['beneficiaries']
    need(all((row['account'], row['purpose']) != (account, purpose) for row in rows), 'GROWTH_BENEFICIARY')
    need(len(rows) < 16, 'FEE_BENEFICIARIES')
    host = max(rows, key=lambda row: (row['bps'], row['account']))
    need(host['bps'] > bps, 'GROWTH_BENEFICIARY')
    host['bps'] -= bps
    rows.append({'account': account, 'bps': bps, 'purpose': purpose})
    validate_policy(updated, resources)
    return updated


def _jaccard(left, right):
    if not left and not right:
        return 0
    return len(left & right) * 10000 // len(left | right)


class GrowthDesk:
    def __init__(self, chain, policy=None, token_policy=None, *, state=None):
        key(chain)
        self.chain = chain
        self.policy = _policy(deepcopy(policy or DEFAULT_POLICY))
        chosen = payout_resource(token_policy, self.policy['resource'])
        self.resource = chosen['resource']
        self.token = chosen
        self.state = state
        self.signups = {}
        self.shares = {}
        self.facts = []
        self.attributions = {}
        self.excluded = {}
        self.published = set()
        self.credited = {}
        self.personhood = set()
        self.trust = {}
        self.holdbacks = []
        self.niches = {}
        self.passkeys = webauthn.RelyingParty()

    def register_passkey(self, credential_id, public_key, *, rp_id, origin, user_verification=False, sign_count=0):
        """Keep the credential record from this desk owner's WebAuthn registration ceremony.

        A PASSKEY sign-up is checked against this record (WebAuthn Level 3
        section 7.2), never against a key or a credential id sent with it.
        """
        return self.passkeys.register(credential_id, public_key, rp_id=rp_id, origin=origin,
                                      user_verification=user_verification, sign_count=sign_count)

    def passkey_challenge(self, actor):
        """A random single-use challenge the actor's passkey signs before a PASSKEY sign-up."""
        key(actor)
        return {'actor': actor, 'challenge': self.passkeys.challenge(actor), 'execution_authorized': False}

    def allow_personhood(self, digest_id):
        key(digest_id)
        self.personhood.add(digest_id)

    def set_trust(self, actor, mass):
        """Pagerank mass for one counterparty. Zero mass adds no diversity."""
        key(actor)
        integer(mass)
        self.trust[actor] = mass

    def record_share(self, card):
        need(card.get('payment') == 'NOT_FOR_THE_SHARE_OR_THE_CLICK', 'SHARE_NOT_PAYABLE')
        need(card['reward'] is None, 'SHARE_NOT_PAYABLE')
        self.shares[card['id']] = {
            'referrer': card['referrer'], 'agreement': card['public']['agreement'], 'clicks': 0,
        }
        return {'id': card['id'], 'reward': None, 'clicks_paid': False, 'execution_authorized': False}

    def record_click(self, share_id):
        key(share_id)
        need(share_id in self.shares, 'SHARE_UNKNOWN')
        self.shares[share_id]['clicks'] += 1
        return {'id': share_id, 'clicks': self.shares[share_id]['clicks'], 'reward': None,
                'payment': 'NOT_FOR_THE_CLICK', 'execution_authorized': False}

    def signup(self, actor, *, height, method, subject, share=None, referrer=None,
               credential=None, agent=None, attestation=None):
        """Record one sign-up. For PASSKEY, ``credential`` is the actor's WebAuthn get() assertion.

        The assertion must sign this desk's ``passkey_challenge(actor)`` with a
        credential registered here (``register_passkey``); one credential signs
        up one actor. A bare credential string is refused.
        """
        key(actor)
        integer(height, True)
        need(actor not in self.signups, 'GROWTH_SIGNUP_EXISTS')
        need(method in SYBIL or method == 'NONE', 'GROWTH_SYBIL')
        key(subject)
        if share is not None:
            key(share)
            need(share in self.shares, 'SHARE_UNKNOWN')
            need(referrer == self.shares[share]['referrer'], 'GROWTH_REFERRER')
        if referrer is not None:
            key(referrer)
            need(referrer != actor, 'GROWTH_SELF_REFERRAL')
        passkey = None
        if method == 'PASSKEY':
            passkey = self.passkeys.verify(actor, credential)
        if method == 'PERSONHOOD':
            key(subject)
            need(subject in self.personhood, 'GROWTH_PERSONHOOD')
        if agent is not None:
            key(agent)
            need(attestation is not None, 'GROWTH_PRINCIPAL')
        if attestation is not None:
            body = verify_attribution(attestation)
            need(body['referee'] == actor and body['share'] == share, 'GROWTH_ATTRIBUTION')
            if agent is not None:
                need(body['agent'] == agent, 'GROWTH_ATTRIBUTION')
            if self.state is not None and body['grant'] is not None:
                from .app import live_grant
                grant = live_grant(self.state, body['grant'], height)
                need(grant['holder'] == body['agent'] and grant['principal'] == body['principal'], 'GRANT_HOLDER')
        if passkey is not None:
            # WebAuthn Level 3 section 7.2 step 24, after every other check of this sign-up passed.
            credential = self.passkeys.commit(passkey)['credential_id']
        if attestation is not None:
            self.attributions[actor] = body
        self.signups[actor] = {
            'height': height, 'method': method, 'subject': subject, 'share': share,
            'referrer': referrer, 'credential': credential, 'bound': False, 'settled': False,
        }
        return {'actor': actor, 'bonus': 'LOCKED_UNTIL_FIRST_SETTLED_COVENANT', 'execution_authorized': False}

    def activity(self, fact):
        body = dict(fact)
        outcome = body.pop('outcome', None)
        exact(body, 'actor counterparty agreement value height disputed settled')
        key(body['actor'])
        key(body['counterparty'])
        key(body['agreement'])
        integer(body['value'])
        integer(body['height'], True)
        need(type(body['disputed']) is bool and type(body['settled']) is bool, 'GROWTH_FACT')
        need(body['actor'] != body['counterparty'], 'DISTINCT_PARTIES')
        need(body['agreement'] not in {row['agreement'] for row in self.facts}, 'GROWTH_AGREEMENT_REUSE')
        if body['settled']:
            need(body['value'] > 0, 'GROWTH_VALUE')
        if outcome is None:
            outcome = 'KEPT' if body['settled'] else 'OPEN'
        need(outcome in OUTCOMES, 'GROWTH_OUTCOME')
        if not body['settled']:
            need(outcome == 'OPEN', 'GROWTH_OUTCOME')
        body['outcome'] = outcome
        body['overturned'] = False
        self.facts.append(body)
        row = self.signups.get(fact['actor'])
        if row is not None and fact['settled']:
            row['settled'] = True
        if row is not None and fact['height'] >= row['height']:
            row['bound'] = True
        return {'recorded': True, 'reward': None, 'execution_authorized': False}

    def note_bound(self, actor):
        key(actor)
        need(actor in self.signups, 'GROWTH_SIGNUP')
        self.signups[actor]['bound'] = True
        return {'actor': actor, 'bound': True, 'bonus_locked': not self.signups[actor]['settled'],
                'execution_authorized': False}

    def clawback(self, actor, reason, *, published=False):
        key(actor)
        need(type(reason) is str and 0 < len(reason) <= 80, 'GROWTH_CLAWBACK')
        if published or actor in self.published:
            return {
                'enforced': False, 'actor': actor,
                'reason': 'ALREADY_IN_PUBLISHED_MANIFEST',
                'reclaim': 'ECON_REWARD_RECLAIM_UNCLAIMED_AFTER_EXPIRY',
                'execution_authorized': False,
            }
        self.excluded[actor] = reason
        return {'enforced': True, 'actor': actor, 'reason': reason, 'execution_authorized': False}

    def note_published(self, actors):
        need(type(actors) is list and len(actors) <= 256, 'GROWTH_PUBLISHED')
        for actor in actors:
            key(actor)
            self.published.add(actor)
        return {'published': sorted(self.published), 'execution_authorized': False}

    def _facts(self, actor):
        return [row for row in self.facts if row['actor'] == actor]

    def _counterparties(self, actor):
        return {row['counterparty'] for row in self._facts(actor) if row['settled']}

    def _realised(self, actor, *, start=None, end=None):
        rows = []
        for fact in self._facts(actor):
            if not fact['settled'] or fact['overturned']:
                continue
            if start is not None and fact['height'] < start:
                continue
            if end is not None and fact['height'] > end:
                continue
            rows.append(fact)
        return rows

    def _sybil_ok(self, actor):
        required = self.policy['sybil']
        if required is None:
            return True
        row = self.signups.get(actor)
        if row is None or row['method'] != required:
            return False
        if required == 'STAKE':
            return self._staked(actor)
        if required == 'PERSONHOOD':
            return row['subject'] in self.personhood
        return row['credential'] is not None

    def _staked(self, actor):
        stakes = (self.state or {}).get('service_stakes') or {}
        for position in stakes.values():
            if position.get('owner') == actor and not position.get('closed') and position.get('amount', 0) > 0:
                return True
        return False

    def quality(self, actor):
        key(actor)
        rows = self._realised(actor)
        scored = quality_weight(rows, self.trust, trust_star=self.policy['trust_star'])
        trusted = {row['counterparty'] for row in rows if self.trust.get(row['counterparty'], 0) > 0}
        return {
            'actor': actor,
            'quality': scored['weight'],
            'realised_value': sum(row['value'] for row in rows),
            'log_value_milli': scored['log_value_milli'],
            'trust_neff': scored['trust_neff'],
            'capped_neff': scored['capped_neff'],
            'lb_bps': scored['lb_bps'],
            'repeat_bps': scored['repeat_bps'],
            'trusted_counterparties': len(trusted),
            'formula': 'LOG2_VALUE_X_TRUST_NEFF_X_WILSON_LB_X_RETENTION',
            'diversity_cap': DIVERSITY_CAP,
            'transferable': False,
            'badges': False,
            'streaks': False,
            'points': False,
            'view': 'QUALITY_NOT_A_BALANCE',
            'rule_set': RULE_SET,
            'feeds_discovery_rank': 'CALLER_MAY_ENDORSE_THIS_VIEW_DOES_NOT_WRITE_THE_FORUM',
            'execution_authorized': False,
        }

    def _direct_referrer(self, actor):
        """One level. The referrer's own referrer is not paid."""
        referrer = self.signups.get(actor, {}).get('referrer')
        if referrer is None:
            return None
        return referrer

    def _referral_ready(self, actor):
        row = self.signups.get(actor)
        if row is None or row['referrer'] is None:
            return False
        window = self._realised(actor, start=row['height'], end=row['height'] + REFERRAL_WINDOW)
        trusted = {fact['counterparty'] for fact in window if self.trust.get(fact['counterparty'], 0) > 0}
        return len(window) >= REFERRAL_MIN_SETTLED and len(trusted) >= REFERRAL_MIN_TRUSTED

    def _colluding(self, left, right):
        if left is None or right is None:
            return False
        referrer_of = {actor: row['referrer'] for actor, row in self.signups.items()}
        if referrer_of.get(left) == right and referrer_of.get(right) == left:
            return True
        return _jaccard(self._counterparties(left), self._counterparties(right)) >= self.policy['collusion_jaccard_bps']

    def _room(self, actor, running):
        return self.policy['per_owner_cap'] - self.credited.get(actor, 0) - running.get(actor, 0)

    def _add(self, grants, running, actor, amount, purpose, receipt, unlock):
        if actor in self.excluded or not self._sybil_ok(actor):
            return
        room = self._room(actor, running)
        amount = min(amount, room, self.policy['max_tail'])
        if amount <= 0:
            return
        integer(amount, True)
        grants.append({
            'domain': None,
            'recipient': actor,
            'amount': amount,
            'unlock': unlock,
            'receipt': receipt,
            'purpose': digest('COVENANT-GROWTH-PURPOSE-0.1', purpose),
            'salt': None,
        })
        running[actor] = running.get(actor, 0) + amount

    def _campaign(self, grants, *, as_of, domain, salts, weighted_by):
        if salts is None:
            salts = [secrets.token_hex(32) for _ in grants]
        need(type(salts) is list and len(salts) == len(grants), 'GROWTH_SALTS')
        for grant, salt in zip(grants, salts):
            key(salt)
            grant['domain'] = domain
            grant['salt'] = salt
        manifest = None
        payload = None
        if grants:
            manifest = allocation_manifest(self.chain, domain, grants)
            payload = {
                'operation': 'ECON_REWARD_CREATE',
                'payload': {
                    'domain': domain,
                    'resource': self.resource,
                    'root': manifest['root'],
                    'expiry': as_of + self.policy['epoch_blocks'],
                    'eligibility': 'APPROVED',
                },
                'pot': 'EXISTING_REWARD_ESCROW',
                'new_treasury': False,
                'mint': False,
                'token_preference': self.token['preference'],
                'weighted_by': weighted_by,
                'eligibility_note': 'VIEW_CHECKED_SETTLEMENT_APPROVED_BECAUSE_SETTLED_SERVICE_NEEDS_A_SERVICE_JOB',
                'clicks_paid': False,
                'rule_set': RULE_SET,
            }
        return manifest, payload

    def qualify(self, *, as_of, domain, salts=None):
        """Signup bonus plus one-level referral. The 20 percent holdback is not in this manifest."""
        integer(as_of, True)
        key(domain)
        policy = self.policy
        grants = []
        running = {}
        self.holdbacks = [row for row in self.holdbacks if row['released']]
        for actor, row in sorted(self.signups.items()):
            if actor in self.excluded or not self._sybil_ok(actor):
                continue
            realised = self._realised(actor)
            if not realised:
                continue
            first = min(realised, key=lambda fact: (fact['height'], fact['agreement']))
            self._add(grants, running, actor, policy['signup_bonus'], 'signup-bonus',
                      first['agreement'], first['height'])
            referrer = self._direct_referrer(actor)
            if (referrer is None or referrer in self.excluded or not self._referral_ready(actor)
                    or self._colluding(actor, referrer) or not self._sybil_ok(referrer)):
                continue
            scored = quality_weight(
                self._realised(actor, start=row['height'], end=row['height'] + REFERRAL_WINDOW),
                self.trust, trust_star=policy['trust_star'])
            gross = min(scored['weight'] // policy['weight_unit'], policy['max_tail'], self._room(referrer, running))
            payable, held = holdback_split(gross)
            self._add(grants, running, referrer, payable, 'referral-' + actor, first['agreement'], as_of)
            already = any(row['released'] and row['receipt'] == first['agreement'] and row['recipient'] == referrer
                          for row in self.holdbacks)
            if held > 0 and not already:
                self.holdbacks.append({
                    'recipient': referrer, 'amount': held, 'receipt': first['agreement'],
                    'unlock': as_of + policy['epoch_blocks'], 'purpose': 'referral-holdback-' + actor,
                    'released': False,
                })
        manifest, payload = self._campaign(
            grants, as_of=as_of, domain=domain, salts=salts,
            weighted_by='LOG2_VALUE_X_TRUST_NEFF_X_WILSON_LB_X_RETENTION')
        return {
            'version': VERSION,
            'rule_set': RULE_SET,
            'rule_name': RULE_NAME,
            'one_level': True,
            'multi_level': False,
            'holdback_bps': HOLDBACK_BPS,
            'holdbacks': [deepcopy(row) for row in self.holdbacks if not row['released']],
            'grants': grants,
            'manifest': manifest,
            'campaign': payload,
            'resource': self.resource,
            'calendar': policy['height_windows_are'],
            'window_blocks': REFERRAL_WINDOW,
            'window_label': '90d',
            'consensus_operation_added': CONSENSUS_CHANGE is not None,
            'execution_authorized': False,
            'submitted': False,
        }

    def release_holdbacks(self, *, as_of, domain, salts=None):
        """Pay the held 20 percent once the epoch has passed and the covenant still stands."""
        integer(as_of, True)
        key(domain)
        grants = []
        running = {}
        chosen = []
        for row in self.holdbacks:
            if row['released'] or row['unlock'] > as_of:
                continue
            if any(fact['agreement'] == row['receipt'] and fact['overturned'] for fact in self.facts):
                continue
            before = len(grants)
            self._add(grants, running, row['recipient'], row['amount'], row['purpose'], row['receipt'], row['unlock'])
            if len(grants) > before:
                chosen.append(row)
        for row in chosen:
            row['released'] = True
        manifest, payload = self._campaign(
            grants, as_of=as_of, domain=domain, salts=salts, weighted_by='HOLDBACK_AFTER_EPOCH')
        return {
            'rule_set': RULE_SET, 'grants': grants, 'manifest': manifest, 'campaign': payload,
            'holdback_bps': HOLDBACK_BPS, 'execution_authorized': False, 'submitted': False,
        }

    def overturn(self, agreement):
        """Drop an unpublished holdback. A published one is reclaimed after expiry."""
        key(agreement)
        found = False
        for fact in self.facts:
            if fact['agreement'] == agreement:
                fact['overturned'] = True
                found = True
        need(found, 'GROWTH_AGREEMENT')
        clawed = 0
        kept = []
        published = False
        for row in self.holdbacks:
            if row['receipt'] != agreement or row['released']:
                if row['receipt'] == agreement and row['released']:
                    published = True
                kept.append(row)
                continue
            clawed += row['amount']
        self.holdbacks = kept
        return {
            'agreement': agreement, 'clawed': clawed, 'enforced': not published,
            'reclaim': 'ECON_REWARD_RECLAIM_UNCLAIMED_AFTER_EXPIRY' if published else None,
            'rule_set': RULE_SET, 'execution_authorized': False,
        }

    def open_niche(self, niche, *, height, sponsor, unit_fee=None, guarantee=None):
        key(niche)
        key(sponsor)
        integer(height)
        need(niche not in self.niches, 'INCENTIVE_NICHE')
        fee = self.policy['unit_fee'] if unit_fee is None else unit_fee
        floor = self.policy['guarantee'] if guarantee is None else guarantee
        integer(fee, True)
        integer(floor)
        self.niches[niche] = {
            'opened': height, 'sponsor': sponsor, 'unit_fee': fee, 'guarantee': floor,
            'healthy': 0, 'closed': False, 'reason': None, 'pool': None, 'side': None,
        }
        return {'niche': niche, 'sunset_blocks': SUNSET_BLOCKS, 'label': '90d',
                'calendar': WINDOW_LABEL, 'rule_set': RULE_SET, 'execution_authorized': False}

    def note_subsidy_pool(self, niche, pool):
        key(niche)
        key(pool)
        row = self.niches.get(niche)
        need(row is not None, 'INCENTIVE_NICHE')
        row['pool'] = pool
        return {'niche': niche, 'pool': pool, 'execution_authorized': False}

    def observe_niche(self, niche, *, fill_bps, utilisation_bps, height):
        key(niche)
        integer(height)
        row = self.niches.get(niche)
        need(row is not None, 'INCENTIVE_NICHE')
        if row['closed']:
            return self._niche_status(niche, row, height, None)
        if height >= row['opened'] + SUNSET_BLOCKS:
            row['closed'] = True
            row['reason'] = 'SUNSET_90D'
            return self._niche_status(niche, row, height, None)
        if healthy_epoch(fill_bps, utilisation_bps):
            row['healthy'] += 1
            if row['healthy'] >= 4:
                row['closed'] = True
                row['reason'] = 'FOUR_HEALTHY_EPOCHS'
                return self._niche_status(niche, row, height, None)
        else:
            row['healthy'] = 0
        row['side'] = short_side(fill_bps, utilisation_bps)
        return self._niche_status(niche, row, height, row['side'])

    def _niche_status(self, niche, row, height, side):
        close = None
        if row['closed'] and row['pool'] is not None:
            close = {'operation': 'ECON_SPONSOR_CLOSE', 'payload': {'sponsor': row['pool']},
                     'pot': 'EXISTING_SPONSOR_ESCROW'}
        return {
            'niche': niche, 'live': not row['closed'], 'reason': row['reason'], 'side': side,
            'healthy_epochs': row['healthy'], 'age_blocks': height - row['opened'],
            'sunset_blocks': SUNSET_BLOCKS, 'close': close, 'rule_set': RULE_SET,
            'execution_authorized': False,
        }

    def supply_subsidy(self, niche, *, provider, earned, accepted, matched, settled, trusted, funding_source=None):
        """Pay the provider when supply is the short side. L1 and an 80 percent accept rate are required."""
        key(niche)
        key(provider)
        integer(settled)
        integer(trusted)
        row = self.niches.get(niche)
        need(row is not None and not row['closed'] and row['side'] == 'SUPPLY', 'INCENTIVE_NICHE')
        need(provider != row['sponsor'], 'INCENTIVE_SELF_DEALING')
        if funding_source is not None:
            key(funding_source)
            need(funding_source != provider, 'INCENTIVE_SELF_DEALING')
        if settled < REFERRAL_MIN_SETTLED or trusted < REFERRAL_MIN_TRUSTED:
            return {'amount': 0, 'reason': 'BELOW_L1', 'campaign': None, 'execution_authorized': False}
        gross = guarantee_amount(row['guarantee'], earned, accepted=accepted, matched=matched)
        payable, held = holdback_split(gross)
        return {
            'amount': payable, 'holdback': held, 'holdback_bps': HOLDBACK_BPS,
            'reason': 'SUPPLY_GUARANTEE' if payable or held else 'NOTHING_DUE',
            'eligibility': 'APPROVED', 'pot': 'EXISTING_REWARD_ESCROW', 'new_treasury': False,
            'rule_set': RULE_SET, 'execution_authorized': False,
        }

    def demand_subsidy(self, niche, owners, *, expiry):
        """Sponsor the first five BINDs when demand is the short side."""
        key(niche)
        integer(expiry, True)
        row = self.niches.get(niche)
        need(row is not None and not row['closed'] and row['side'] == 'DEMAND', 'INCENTIVE_NICHE')
        payload = demand_sponsor(resource=self.resource, actors=sorted(owners), unit_fee=row['unit_fee'], expiry=expiry)
        payload['sponsor'] = row['sponsor']
        return payload

    def leaderboard(self, actors, *, limit=32):
        integer(limit, True)
        need(limit <= 64, 'GROWTH_BOARD')
        need(type(actors) is list and len(actors) <= 256, 'GROWTH_BOARD')
        rows = [self.quality(actor) for actor in actors]
        rows.sort(key=lambda row: (-row['quality'], row['actor']))
        return {
            'rows': rows[:limit],
            'transferable': False,
            'ordered_by': 'QUALITY_THEN_ACTOR',
            'volume_is_not_the_rank': True,
            'execution_authorized': False,
        }

    def transfer_status(self, source, dest):
        key(source)
        key(dest)
        raise ValueError('GROWTH_STATUS_NONTRANSFERABLE')
