"""Optional receipt DAG: attribution/causality only, never authority or finality.

Direct signing keys are receipt issuers, not native principal/controller identities.
Two contradictory assertions may coexist. No receipt consumes any resource.
"""
from copy import deepcopy
import sqlite3
from covenant_language.safe_io import durable_sqlite
from .crypto import canonical, loads, exact, need, key, digest, sign, verify

PROFILE = 'covenant-causal-receipts/0.1'
MAX_EVENT = 16 * 1024
MAX_PARENTS = 32

def event_id(body):
    return digest('COVENANT-CAUSAL-RECEIPT-0.1', body)

def receipt(private, domain, kind, content_hash, parents=()):
    from .crypto import public_key
    body = {'profile': PROFILE, 'domain': domain, 'kind': kind,
            'issuer': public_key(private), 'content_hash': content_hash,
            'parents': sorted(parents)}
    return {'body': body, 'signature': sign(private, 'COVENANT-CAUSAL-SIGN-0.1', body)}

def validate(event, domain):
    need(len(canonical(event)) <= MAX_EVENT, 'CAUSAL_EVENT_SIZE')
    exact(event, 'body signature'); b = event['body']
    exact(b, 'profile domain kind issuer content_hash parents')
    key(domain); need(b['profile'] == PROFILE and b['domain'] == domain, 'CAUSAL_CONTEXT')
    need(b['kind'] in {'SAY', 'SHOW'}, 'CAUSAL_NONBINDING_ONLY'); key(b['content_hash'])
    p = b['parents']; need(type(p) is list and len(p) <= MAX_PARENTS, 'CAUSAL_PARENTS')
    for parent in p: key(parent)
    need(p == sorted(set(p)), 'CAUSAL_PARENT_ORDER')
    verify(b['issuer'], 'COVENANT-CAUSAL-SIGN-0.1', b, event['signature'])
    return event_id(b)

class ReceiptDAG:
    """Bounded durable union of authenticated receipts; no global sequence.

Caller supplies access/admission policy. Capacity exhaustion fails closed; no
silent eviction of causal parents. Export is dependency-ordered for transport,
not a claim that independent events happened in that order.
"""
    def __init__(self, path, domain, max_events=10000, max_bytes=64*1024*1024):
        key(domain)
        need(type(max_events) is int and max_events > 0 and type(max_bytes) is int and max_bytes > 0, 'CAUSAL_QUOTA')
        self.domain, self.max_events, self.max_bytes = domain, max_events, max_bytes
        self.db = durable_sqlite(sqlite3.connect(path, check_same_thread=False))
        self.db.execute('CREATE TABLE IF NOT EXISTS receipt (id TEXT PRIMARY KEY, raw BLOB NOT NULL, depth INTEGER NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS context (domain TEXT NOT NULL)')
        pinned = self.db.execute('SELECT domain FROM context').fetchone()
        if pinned and pinned[0] != domain:
            self.db.close()
            raise ValueError('CAUSAL_DATABASE_CONTEXT')
        else: self.db.execute('INSERT INTO context VALUES (?)', (domain,))
        self.db.commit()
    def close(self): self.db.close()
    def get(self, identifier):
        key(identifier)
        row = self.db.execute('SELECT raw FROM receipt WHERE id=?', (identifier,)).fetchone()
        need(row is not None, 'CAUSAL_MISSING')
        event = loads(row[0]); need(validate(event, self.domain) == identifier, 'CAUSAL_STORAGE_CORRUPTION')
        return event
    def merge(self, events):
        need(type(events) is list and len(events) <= 256, 'CAUSAL_BATCH')
        # Validate entire batch before mutation. Copy to detach caller-owned objects.
        pending = {validate(e, self.domain): deepcopy(e) for e in events}
        inserted = []
        try:
            self.db.execute('BEGIN IMMEDIATE')
            count, size = self.db.execute('SELECT count(*), coalesce(sum(length(raw)),0) FROM receipt').fetchone()
            while pending:
                progress = False
                for identifier, event in list(pending.items()):
                    if self.db.execute('SELECT 1 FROM receipt WHERE id=?', (identifier,)).fetchone():
                        # Recheck stored content even on duplicate delivery.
                        self.get(identifier); del pending[identifier]; progress = True; continue
                    depths = [self.db.execute('SELECT depth FROM receipt WHERE id=?', (p,)).fetchone()
                              for p in event['body']['parents']]
                    if any(d is None for d in depths): continue
                    raw = canonical(event)
                    need(count + 1 <= self.max_events and size + len(raw) <= self.max_bytes, 'CAUSAL_CAPACITY')
                    depth = 1 + max((d[0] for d in depths), default=-1)
                    self.db.execute('INSERT INTO receipt VALUES (?,?,?)', (identifier, raw, depth))
                    count += 1; size += len(raw); inserted.append(identifier)
                    del pending[identifier]; progress = True
                need(progress, 'CAUSAL_MISSING_PARENT_OR_CYCLE')
            self.db.commit()
        except BaseException:
            self.db.rollback(); raise
        return {'inserted': sorted(inserted), 'assurance': 'SIGNED_ATTRIBUTION_ONLY',
                'authority': 'NOT_ESTABLISHED', 'finality': 'NONE', 'resource_effect': 'NONE'}
    def export(self):
        rows = self.db.execute('SELECT id FROM receipt ORDER BY depth,id').fetchall()
        return [self.get(row[0]) for row in rows]
    def fingerprint(self):
        # Set identity independent of arrival order; not a finality certificate.
        return digest('COVENANT-CAUSAL-SET-0.1', sorted(row[0] for row in self.db.execute('SELECT id FROM receipt')))
