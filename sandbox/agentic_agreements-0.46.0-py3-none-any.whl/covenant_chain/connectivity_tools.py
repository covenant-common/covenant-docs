"""Pure owner preparation for optional carriers. No radio, network or keys."""
from . import crypto as c, offline as o, offline_ble as b, offline_forwarding as f
from .cooperation_interface import HASH, INT, OBJECT, TEXT


def spec():
    return ('covenant_connectivity',
        'Plan BLE/store-and-forward delivery and verify supplied hop receipts. Prepare inert '
        'carrier descriptors; never scan, pair, connect, advertise, forward, sign or pay.', True, [
        ('spec', {}, ()),
        ('descriptor', {'name': TEXT, 'carrier': TEXT, 'peer': HASH, 'max_packet': INT,
                        'relay': {'type': 'boolean'}, 'cost_units': INT, 'interface': OBJECT},
                       ('name', 'carrier', 'peer', 'max_packet')),
        ('plan', {'packet': OBJECT, 'mtu': INT}, ('packet',)),
        ('verify_hop', {'receipt': OBJECT, 'packet': OBJECT, 'expected_peer': HASH, 'now': INT},
                       ('receipt', 'packet', 'expected_peer', 'now')),
    ])


def call(action, parameters):
    if action == 'spec':
        return {'ble_profile': b.VERSION, 'link_profile': f.LINK, 'receipt_profile': f.HOP,
            'journey': ['Owner independently pins original sender, scope and carrier peer.',
                        'Keep the exact signed/encrypted envelope in an encrypted OfflineStore.',
                        'Owner connects a BLE client or installs another carrier callback.',
                        'Checkpoint received windows; retry exact bytes after interruption.',
                        'Verify the signed custody assertion; forward through another adopted carrier.',
                        'Obtain the separate native recipient receipt; explicitly verify or execute later.'],
            'satellite': 'Owner-provided IP/modem/SMS callback only. No Starlink/AST service API, '
                         'subscription, coverage, hardware or direct-to-device qualification.',
            'limits': {'gatt_write_bytes_default': 20, 'gatt_write_bytes_max': 244,
                       'window_frames': b.WINDOW, 'packet_bytes': o.MAX_PACKET,
                       'default_inbox_packet_bytes': 8192},
            'standards': 'Custom Covenant GATT courier; not Bluetooth Mesh. The same packet can also '
                         'travel as a BPv7 (RFC 9171) bundle through dtn_bundle.',
            'privacy': 'Existing AEAD envelope and encrypted local vault. Routing metadata visible; '
                       'owner selects BLE pairing and OS permissions. No forward secrecy or ZK.',
            'authority': 'A hop receipt is a signed peer assertion of custody. It never authorizes '
                         'agreement acceptance, robot movement, settlement or an exclusive offline spend.',
            'execution_authorized': False, 'payment_verified': False}
    if action == 'descriptor':
        value = f.descriptor(**parameters)
        return {'descriptor': value, 'id': f.link_id(value), 'installed': False}
    if action == 'plan':
        packet = parameters['packet']; o.packet_id(packet)
        raw = c.canonical(packet); pieces = b.frames(raw, mtu=parameters.get('mtu', 20))
        return {'packet': o.packet_id(packet), 'application_bytes': len(raw), 'frames': len(pieces),
                'gatt_data_bytes': sum(map(len, pieces)),
                'checkpoint_windows': (len(pieces)+b.WINDOW-1)//b.WINDOW,
                'control_and_receipt_bytes_included': False, 'duration_estimated': False,
                'transmitted': False, 'execution_authorized': False}
    if action == 'verify_hop': return f.verify_hop_receipt(**parameters)
    raise ValueError('CONNECTIVITY_ACTION')
