"""Genesis drop claimed by binding a pledge covenant.

The Merkle campaign is the existing reward engine. This module adds the gate:
the claim counts only while the pledge is kept, and a broken pledge is the
condition for sending the unvested remainder back to that campaign's escrow.
"""
from .crypto import integer, need
from .kept_promises import distinct_counterparties, honoured_rows, tokens_for
from .kept_promises import score_rows
from .tokenomics_config import live_meter


PLEDGE_ELIGIBILITY = {'PLEDGE_COVENANT', 'POINTS_SEASON', 'INTEGRATOR_RETRO'}


def _template(cfg, purpose):
    for row in cfg['pledges']:
        if row['id'] == purpose:
            return row
    need(False, 'PLEDGE_TEMPLATE')


def pledge_kept(state, actor, grant, height, cfg):
    template = _template(cfg, grant['purpose'])
    need(grant['receipt'] in state['agreements'], 'PLEDGE_MISSING')
    agreement = state['agreements'][grant['receipt']]
    terms = agreement['terms']
    need(terms['profile'] == template['profile'], 'PLEDGE_PROFILE')
    need(actor in {terms['principal'], terms['agent']}, 'PLEDGE_PARTY')
    decision = agreement.get('decision') or {}
    if agreement.get('state') == 'RELEASED' or decision.get('result') == 'REFUTED':
        return False
    if agreement.get('state') not in {'BOUND', 'AUTHORIZED'}:
        return False
    if template['kind'] == 'RUN_NODE':
        if agreement.get('state') != 'AUTHORIZED' and terms.get('timeout') == 'RELEASE_IF_UNDECIDED' and height > terms['deadline']:
            return False
        return True
    if template['kind'] == 'BRING_AGENTS':
        rows = honoured_rows(state, height)
        found = distinct_counterparties(rows, actor, height, cfg['points']['retention_blocks'])
        return len(found) >= template['minimum']
    return False


def _claimed(state, eligibility, account=None, epoch=None, epoch_blocks=None):
    total = 0
    claims = state.get('reward_claims') or {}
    campaigns = state.get('reward_campaigns') or {}
    for claim in claims.values():
        campaign = campaigns.get(claim['campaign'])
        if not campaign or campaign.get('eligibility') != eligibility:
            continue
        if account is not None and claim.get('recipient') != account:
            continue
        if epoch is not None:
            claimed_at = claim.get('height', 0)
            if claimed_at // epoch_blocks != epoch:
                continue
        total += claim.get('unlocked', 0) + claim.get('held_total', claim.get('amount', 0))
    return total


def prepare_claim(state, campaign, grant, actor, height, cfg):
    """Return the unlocked and escrowed halves. Does not move funds."""
    eligibility = campaign['eligibility']
    need(eligibility in PLEDGE_ELIGIBILITY, 'REWARD_ELIGIBILITY')
    amount = grant['amount']
    integer(amount, True)
    points = cfg['points']
    supply = cfg['supply']
    need(campaign['resource'] == supply['resource'], 'SUPPLY_RESOURCE')
    meter = live_meter(state) or {}
    bonds = meter.get('bonds') or {}
    if eligibility == 'PLEDGE_COVENANT':
        need(pledge_kept(state, actor, grant, height, cfg), 'PLEDGE_BROKEN')
        need(bonds.get(actor, 0) >= points['min_bond'], 'PLEDGE_BOND')
        template = _template(cfg, grant['purpose'])
        if template['kind'] == 'RUN_NODE':
            need(bonds.get(actor, 0) >= template['minimum'], 'PLEDGE_BOND')
        need(grant['receipt'] not in (meter.get('pledges_used') or []), 'PLEDGE_REUSED')
        required = amount * points.get('pledge_stake_bps', 0) // 10000
        if required:
            position = (meter.get('positions') or {}).get(actor) or {}
            mature = 0
            if position and not position.get('unbonding') and position.get('locked_at', height) < height:
                mature = position.get('amount', 0)
            need(mature >= required, 'PLEDGE_STAKE')
        cap = supply['total'] * supply['pledge_claim_bps'] // 10000
        need(_claimed(state, eligibility) + amount <= cap, 'GENESIS_BUDGET')
        pledge = grant['receipt']
    elif eligibility == 'POINTS_SEASON':
        rows = honoured_rows(state, height)
        scored = score_rows(rows, height, points, bonds, cfg['integrator'])
        account = scored['accounts'].get(actor, {'points': 0})
        entitled = tokens_for(account['points'], bonds.get(actor, 0), points)
        already = _claimed(state, eligibility, account=actor)
        need(amount <= max(0, entitled - already), 'POINTS_UNEARNT')
        epoch = height // points['epoch_blocks']
        used = _claimed(state, eligibility, epoch=epoch, epoch_blocks=points['epoch_blocks'])
        from .kept_promises import epoch_budget
        budget = epoch_budget(height, points)['budget']
        cap = meter.get('emission_cap')
        if type(cap) is int and cap < budget:
            budget = cap
        need(used + amount <= budget, 'EMISSION_EPOCH')
        cap = supply['total'] * supply['emissions_bps'] // 10000
        need(_claimed(state, eligibility) + amount <= cap, 'EMISSION_BUDGET')
        pledge = None
    else:
        from .token_rebates import integrator_entitlement
        claimable = integrator_entitlement(state, actor, height)['claimable']
        already = _claimed(state, eligibility, account=actor)
        need(amount <= max(0, claimable - already), 'INTEGRATOR_UNEARNT')
        pledge = None
    pay = amount * points['vest_unlock_bps'] // 10000
    held = amount - pay
    return {'pay': pay, 'held': held, 'pledge': pledge}


def vest_release(claim, height, vest_blocks):
    integer(height)
    integer(vest_blocks, True)
    need(not claim.get('clawed'), 'REWARD_CLAWED')
    elapsed = height - claim['height']
    if elapsed <= 0:
        return 0
    released = claim['held_total'] * min(elapsed, vest_blocks) // vest_blocks
    return max(0, released - claim.get('released', 0))


def clawback_due(state, claim, campaign, height, cfg):
    need(not claim.get('clawed'), 'REWARD_CLAWED')
    eligibility = campaign['eligibility']
    if eligibility == 'PLEDGE_COVENANT':
        grant = {'purpose': claim['purpose'], 'receipt': claim['receipt'], 'amount': claim['amount']}
        if not pledge_kept(state, claim['recipient'], grant, height, cfg):
            return True
        bond = ((live_meter(state) or {}).get('bonds') or {}).get(claim['recipient'], 0)
        if bond < cfg['points']['min_bond']:
            return True
        required = claim['amount'] * cfg['points'].get('pledge_stake_bps', 0) // 10000
        if required:
            position = ((live_meter(state) or {}).get('positions') or {}).get(claim['recipient']) or {}
            mature = position.get('amount', 0) if position and not position.get('unbonding') else 0
            if mature < required:
                return True
        return False
    if eligibility == 'POINTS_SEASON':
        rows = honoured_rows(state, height)
        scored = score_rows(rows, height, cfg['points'], (live_meter(state) or {}).get('bonds') or {}, cfg['integrator'])
        account = scored['accounts'].get(claim['recipient'], {'points': 0})
        bond = ((live_meter(state) or {}).get('bonds') or {}).get(claim['recipient'], 0)
        entitled = tokens_for(account['points'], bond, cfg['points'])
        reserved = claim.get('unlocked', 0) + claim.get('held_total', 0)
        return entitled < reserved
    if eligibility == 'INTEGRATOR_RETRO':
        from .token_rebates import integrator_entitlement
        # Paid amounts already reduced the claimable figure, so compare with the original earned total.
        earned = integrator_entitlement(state, claim['recipient'], height)['earned']
        return earned < claim.get('unlocked', 0) + claim.get('held_total', 0)
    return False
