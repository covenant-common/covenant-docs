"""Signed verb-scoped mandates with per-request caps and rolling-window spend limits.

covenant-scoped-mandate/0.1 is the successor of the MANDATE record of
covenant-portable-trust/0.1, whose bytes and meaning are unchanged. A mandate
names verb-level scopes (covenant-verb-scope/0.1) instead of separate action
and resource lists, an optional list of counterparties, per-request caps and
rolling windows. A MANDATE window caps everything spent in a unit under that
mandate within the last ``window`` seconds; a COUNTERPARTY window caps it for
each counterparty separately. Delegation may only narrow scopes,
counterparties, time, caps and windows, and a child keeps every window of its
parent for each unit it may still spend.

check() verifies signatures, attenuation, the request and the root's signed,
optionally witnessed revocation snapshots (the portable-trust helpers, so a
revocation snapshot revokes either kind of record). It returns the windows of
every mandate in the chain. A window is enforced only by a ledger that charges
it, such as covenant_chain.spend_windows; check() itself is per request. No
function here signs for an agent, transmits, spends or executes.
"""
from copy import deepcopy
import re

from . import portable_trust as trust, verb_scopes
from .crypto import digest, exact, integer, key, need, public_key, sign, verify

VERSION = 'covenant-scoped-mandate/0.1'
LABEL = 'COVENANT-SCOPED-MANDATE-0.1'
FIELDS = ('version root issuer recipient parent scopes audience counterparties per_request windows '
          'not_before expires may_delegate nonce')
PER = ('COUNTERPARTY', 'MANDATE')
MAX_CHAIN = 16
MAX_UNITS = 16
MAX_WINDOWS = 16
MAX_COUNTERPARTIES = 64
MAX_WINDOW = 31622400
UNIT = re.compile(r'[\x21-\x7e]{1,80}\Z')
REMEDIATION = {
    'SCOPED_PROFILE': 'Use version covenant-scoped-mandate/0.1; a covenant-portable-trust/0.1 mandate keeps its own checker.',
    'SCOPED_DELEGATION': 'The issuer and recipient must differ and may_delegate must be a boolean.',
    'SCOPED_ROOT_ISSUER': 'A root mandate has no parent and is issued by the root key itself.',
    'SCOPED_COUNTERPARTIES': 'Give null for any counterparty, or 1 to 64 distinct printable identifiers in sorted order.',
    'SCOPED_UNITS': 'Give 1 to 16 per-request caps, each a printable unit and an integer amount.',
    'SCOPED_WINDOWS': 'Give at most 16 windows, each per MANDATE or COUNTERPARTY, a unit with a per-request cap, an integer amount and 1 to 31622400 seconds, sorted and distinct.',
    'SCOPED_SIGNATURE': 'Obtain the issuer\'s own signature over the exact mandate body.',
    'SCOPED_EXPECTED_RECORD': 'The mandate is not the one you pinned. Obtain the exact pinned record.',
    'SCOPED_DELEGATION_CHAIN': 'Delegate only from a parent that allows delegation, as its recipient, under the same root.',
    'SCOPED_AUDIENCE': 'A delegated mandate keeps its parent\'s audience.',
    'SCOPED_COUNTERPARTY_ESCALATION': 'A delegated mandate may only name counterparties its parent allows.',
    'SCOPED_TIME_ESCALATION': 'A delegated mandate must start no earlier and end no later than its parent.',
    'SCOPED_LIMIT_ESCALATION': 'A delegated per-request cap may only lower a unit its parent caps.',
    'SCOPED_WINDOW_ESCALATION': 'Keep every parent window for each unit the child may spend, with an amount no higher than the parent\'s.',
    'SCOPED_CHAIN_DEPTH': 'Present the chain from the root mandate to the recipient, 1 to 16 records.',
    'SCOPED_ROOT_PIN': 'The chain must start at the root key the owner adopted.',
    'SCOPED_TIME': 'Every mandate in the chain must be valid at the owner clock.',
    'SCOPED_REQUEST': 'The request must name the leaf mandate\'s recipient and audience.',
    'SCOPED_USAGE': 'Give usage as at most 16 units with integer amounts.',
    'SCOPED_USAGE_UNITS': 'Spend only units the leaf mandate caps.',
    'SCOPED_REQUEST_LIMIT': 'Lower the amount to the leaf mandate\'s per-request cap.',
    'SCOPED_COUNTERPARTY_REQUIRED': 'Name the counterparty: this chain limits counterparties or has counterparty windows.',
    'SCOPED_COUNTERPARTY_DENIED': 'Deal only with a counterparty the leaf mandate lists.',
}


def _counterparties(value):
    if value is None:
        return
    need(type(value) is list and 1 <= len(value) <= MAX_COUNTERPARTIES, 'SCOPED_COUNTERPARTIES')
    for item in value:
        need(type(item) is str and 0 < len(item) <= 256 and item.isascii() and item.isprintable(), 'SCOPED_COUNTERPARTIES')
    need(value == sorted(set(value)), 'SCOPED_COUNTERPARTIES')


def _units(value, code, minimum=1):
    need(type(value) is dict and minimum <= len(value) <= MAX_UNITS, code)
    for unit, amount in value.items():
        need(type(unit) is str and UNIT.fullmatch(unit) is not None, code)
        need(type(amount) is int and 0 <= amount <= 2**53 - 1, code)


def _windows(value, caps):
    need(type(value) is list and len(value) <= MAX_WINDOWS, 'SCOPED_WINDOWS')
    for row in value:
        need(type(row) is dict and set(row) == {'per', 'unit', 'amount', 'window'} and row['per'] in PER and
             row['unit'] in caps and type(row['amount']) is int and 0 <= row['amount'] <= 2**53 - 1 and
             type(row['window']) is int and 1 <= row['window'] <= MAX_WINDOW, 'SCOPED_WINDOWS')
    order = [(row['per'], row['unit'], row['window']) for row in value]
    need(order == sorted(set(order)), 'SCOPED_WINDOWS')


def validate(body):
    """An exact mandate body; it carries no authority until its issuer's signature verifies."""
    trust._bounded(body)
    exact(body, FIELDS)
    need(body['version'] == VERSION, 'SCOPED_PROFILE')
    for name in ('root', 'issuer', 'recipient'):
        trust._key(body[name])
    if body['parent'] is not None:
        key(body['parent'])
    verb_scopes.scopes(body['scopes'])
    trust._text(body['audience'], 256)
    _counterparties(body['counterparties'])
    _units(body['per_request'], 'SCOPED_UNITS')
    _windows(body['windows'], body['per_request'])
    trust._window(body['not_before'], body['expires'])
    key(body['nonce'])
    need(type(body['may_delegate']) is bool and body['issuer'] != body['recipient'], 'SCOPED_DELEGATION')
    if body['parent'] is None:
        need(body['issuer'] == body['root'], 'SCOPED_ROOT_ISSUER')
    return body


def mandate_id(body):
    validate(body)
    return digest(LABEL, body)


def _prepare(body):
    validate(body)
    return {'id': mandate_id(body), 'body': deepcopy(body), 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [body['issuer']], 'signature_created': False, 'execution_authorized': False}


def mandate(issuer, recipient, scopes, audience, per_request, not_before, expires, nonce, *, windows=(),
            counterparties=None, may_delegate=False):
    """An unsigned root mandate for the issuer to sign."""
    return _prepare({'version': VERSION, 'root': issuer, 'issuer': issuer, 'recipient': recipient, 'parent': None,
                     'scopes': deepcopy(scopes), 'audience': audience, 'counterparties': deepcopy(counterparties),
                     'per_request': deepcopy(per_request), 'windows': deepcopy(list(windows)),
                     'not_before': not_before, 'expires': expires, 'may_delegate': may_delegate, 'nonce': nonce})


def sign_record(body, private_key):
    """Explicit local issuer action. Not exposed as a tool; no permission is inferred."""
    validate(body)
    need(public_key(private_key) == body['issuer'], 'SCOPED_SIGNATURE')
    return {'body': deepcopy(body), 'signatures': [{'signer': body['issuer'], 'signature': sign(private_key, LABEL, body)}]}


def _record(record, expected_id=None):
    trust._bounded(record)
    exact(record, 'body signatures')
    body = validate(record['body'])
    ref = digest(LABEL, body)
    if expected_id is not None:
        key(expected_id)
        need(ref == expected_id, 'SCOPED_EXPECTED_RECORD')
    rows = record['signatures']
    need(type(rows) is list and len(rows) == 1, 'SCOPED_SIGNATURE')
    exact(rows[0], 'signer signature')
    need(rows[0]['signer'] == body['issuer'], 'SCOPED_SIGNATURE')
    try:
        verify(body['issuer'], LABEL, body, rows[0]['signature'])
    except ValueError:
        raise ValueError('SCOPED_SIGNATURE') from None
    return body, ref


def _attenuation(parent, child, parent_id):
    need(parent['may_delegate'] is True and child['parent'] == parent_id and child['issuer'] == parent['recipient']
         and child['root'] == parent['root'], 'SCOPED_DELEGATION_CHAIN')
    need(child['audience'] == parent['audience'], 'SCOPED_AUDIENCE')
    verb_scopes.narrows(child['scopes'], parent['scopes'])
    need(parent['counterparties'] is None or (child['counterparties'] is not None and
         set(child['counterparties']) <= set(parent['counterparties'])), 'SCOPED_COUNTERPARTY_ESCALATION')
    need(parent['not_before'] <= child['not_before'] < child['expires'] <= parent['expires'], 'SCOPED_TIME_ESCALATION')
    need(set(child['per_request']) <= set(parent['per_request']) and all(
        amount <= parent['per_request'][unit] for unit, amount in child['per_request'].items()), 'SCOPED_LIMIT_ESCALATION')
    held = {(row['per'], row['unit'], row['window']): row['amount'] for row in child['windows']}
    for row in parent['windows']:
        if row['unit'] in child['per_request']:
            kept = held.get((row['per'], row['unit'], row['window']))
            need(kept is not None and kept <= row['amount'], 'SCOPED_WINDOW_ESCALATION')


def delegate(parent, expected_parent_id, recipient, scopes, per_request, not_before, expires, nonce, *, windows=(),
             counterparties=None, may_delegate=False):
    """An unsigned child mandate that only narrows its signed parent."""
    body, ref = _record(parent, expected_parent_id)
    prepared = _prepare({'version': VERSION, 'root': body['root'], 'issuer': body['recipient'], 'recipient': recipient,
                         'parent': ref, 'scopes': deepcopy(scopes), 'audience': body['audience'],
                         'counterparties': deepcopy(counterparties), 'per_request': deepcopy(per_request),
                         'windows': deepcopy(list(windows)), 'not_before': not_before, 'expires': expires,
                         'may_delegate': may_delegate, 'nonce': nonce})
    _attenuation(body, prepared['body'], ref)
    return prepared


def check(records, root_key, recipient, scope, audience, usage, now, *, counterparty=None, revocation_history=None,
          witness=None, minimum_revocation_sequence=0):
    """Verify one concrete request against a signed chain; return every window a ledger must charge."""
    need(type(records) is list and 1 <= len(records) <= MAX_CHAIN, 'SCOPED_CHAIN_DEPTH')
    trust._bounded(records)
    trust._key(root_key)
    trust._key(recipient)
    verb_scopes.parse(scope, concrete=True)
    trust._text(audience, 256)
    integer(now)
    _units(usage, 'SCOPED_USAGE', 0)
    if counterparty is not None:
        _counterparties([counterparty])
    ids, chain = [], []
    for index, record in enumerate(records):
        body, ref = _record(record)
        need(body['root'] == root_key, 'SCOPED_ROOT_PIN')
        if index == 0:
            need(body['parent'] is None and body['issuer'] == root_key, 'SCOPED_ROOT_ISSUER')
        else:
            _attenuation(chain[-1], body, ids[-1])
        need(body['not_before'] <= now < body['expires'], 'SCOPED_TIME')
        ids.append(ref)
        chain.append(body)
    leaf = chain[-1]
    need(leaf['recipient'] == recipient and leaf['audience'] == audience, 'SCOPED_REQUEST')
    grant = verb_scopes.permitted(leaf['scopes'], scope)
    named = any(level['counterparties'] is not None or any(row['per'] == 'COUNTERPARTY' for row in level['windows'])
                for level in chain)
    need(counterparty is not None or not named, 'SCOPED_COUNTERPARTY_REQUIRED')
    need(leaf['counterparties'] is None or counterparty in leaf['counterparties'], 'SCOPED_COUNTERPARTY_DENIED')
    need(set(usage) <= set(leaf['per_request']), 'SCOPED_USAGE_UNITS')
    for unit, amount in usage.items():
        need(amount <= leaf['per_request'][unit], 'SCOPED_REQUEST_LIMIT')
    revocation, revoked = trust.revocation_status(ids, root_key, now, revocation_history, witness,
                                                  minimum_revocation_sequence)
    windows = [{'mandate': ref, **deepcopy(row)} for ref, level in zip(ids, chain) for row in level['windows']
               if row['unit'] in usage]
    return {'mandate': ids[-1], 'chain': ids, 'root': root_key, 'recipient': recipient, 'scope': scope, 'grant': grant,
            'audience': audience, 'counterparty': counterparty, 'usage': deepcopy(usage), 'windows': windows,
            'scope_and_signatures_verified': True, 'revocation': revocation, 'revoked': revoked,
            'eligible_in_supplied_scope': revocation == 'NOT_REVOKED_IN_FRESH_OWNER_ADOPTED_WITNESSED_SNAPSHOT',
            'limits': 'PER_REQUEST_CHECKED; ROLLING_WINDOWS_ENFORCED_ONLY_BY_A_CHARGING_LEDGER',
            'global_latest': 'UNKNOWN', 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'label': LABEL, 'predecessor': trust.VERSION + ' MANDATE (unchanged)',
            'scopes': verb_scopes.VERSION, 'windows': list(PER), 'max_window_seconds': MAX_WINDOW,
            'delegation': 'NARROW_ONLY; CHILD_KEEPS_PARENT_WINDOWS', 'revocation': 'PORTABLE_TRUST_REVOCATIONS',
            'aggregate_enforcement': 'covenant-spend-windows/0.1 LEDGER', 'execution_authorized': False}
