"""Bitcoin wire primitives for optional AAP escrow legs. Maturity: experimental.

Bytes only: nothing here holds a key it was not handed, opens a socket or
broadcasts. Owners sign with their own wallets (or through the owner-held key
objects passed in) and broadcast themselves.

* BIP 173 (bech32) and BIP 350 (bech32m), including BOLT 11's longer strings.
* BIP 141 witness programs and BIP 143 signature hashes for version 0 witness
  scripts (SIGHASH_ALL only), strict DER (BIP 66) and low-s (BIP 146 policy).
* BIP 174 PSBT version 0 and BIP 370 version 2: strict parsing with unique
  keys, the version inclusion and exclusion rules, unknown keys preserved,
  finalisation of witness inputs and transaction extraction.
* BIP 380 descriptor checksums and BIP 383 multi(); the escrow's optional
  timeout branch is the BIP 379 (Draft) miniscript
  or_d(multi(2,B,S,A),and_v(v:pk(B),older(N))), whose script is
  [multi] IFDUP NOTIF [v:pk(B)] [older(N)] ENDIF. Only these fixed templates
  are produced; this is not a general miniscript compiler.
"""
import base64
import hashlib
import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed, decode_dss_signature

from .crypto import need

CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l'
BECH32, BECH32M = 1, 0x2bc830a3
_GENERATOR = (0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
NETWORKS = {'bc': 'bitcoin', 'tb': 'testnet-or-signet', 'bcrt': 'regtest'}
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
SIGHASH_ALL = 1
OP_0, OP_PUSHDATA1, OP_PUSHDATA2 = 0x00, 0x4c, 0x4d
OP_IFDUP, OP_NOTIF, OP_ENDIF = 0x73, 0x64, 0x68
OP_CHECKSIGVERIFY, OP_CHECKMULTISIG, OP_CSV = 0xad, 0xae, 0xb2
MAX_PSBT = 1 << 20
MAX_IO = 256
MAX_PAIRS = 512
MAX_SCRIPT = 10000
DUST = 546
MAGIC = b'psbt\xff'
# BIP 174 / BIP 370 key types.
G_UNSIGNED_TX, G_XPUB, G_TX_VERSION, G_FALLBACK_LOCKTIME, G_INPUT_COUNT, G_OUTPUT_COUNT, G_TX_MODIFIABLE, G_VERSION = 0, 1, 2, 3, 4, 5, 6, 0xFB
I_NON_WITNESS_UTXO, I_WITNESS_UTXO, I_PARTIAL_SIG, I_SIGHASH, I_REDEEM_SCRIPT, I_WITNESS_SCRIPT = 0, 1, 2, 3, 4, 5
I_BIP32, I_FINAL_SCRIPTSIG, I_FINAL_WITNESS = 6, 7, 8
I_PREVIOUS_TXID, I_OUTPUT_INDEX, I_SEQUENCE, I_TIME_LOCKTIME, I_HEIGHT_LOCKTIME = 0x0e, 0x0f, 0x10, 0x11, 0x12
O_REDEEM_SCRIPT, O_WITNESS_SCRIPT, O_BIP32, O_AMOUNT, O_SCRIPT = 0, 1, 2, 3, 4
_V2_GLOBAL = {G_TX_VERSION, G_FALLBACK_LOCKTIME, G_INPUT_COUNT, G_OUTPUT_COUNT, G_TX_MODIFIABLE}
_V2_INPUT = {I_PREVIOUS_TXID, I_OUTPUT_INDEX, I_SEQUENCE, I_TIME_LOCKTIME, I_HEIGHT_LOCKTIME}
_V2_OUTPUT = {O_AMOUNT, O_SCRIPT}
# Key types whose key is the type byte alone, per map (BIP 174 / BIP 370 tables).
_BARE = ({G_UNSIGNED_TX, G_VERSION} | _V2_GLOBAL,
         {I_NON_WITNESS_UTXO, I_WITNESS_UTXO, I_SIGHASH, I_REDEEM_SCRIPT, I_WITNESS_SCRIPT,
          I_FINAL_SCRIPTSIG, I_FINAL_WITNESS} | _V2_INPUT,
         {O_REDEEM_SCRIPT, O_WITNESS_SCRIPT} | _V2_OUTPUT)
INPUT_CHARSET = "0123456789()[],'/*abcdefgh@:$%{}IJKLMNOPQRSTUVWXYZ&+-.;<=>?!^_|~ijklmnopqrstuvwxyzABCDEFGH`#\"\\ "
_DESCRIPTOR_GENERATOR = (0xf5dee51989, 0xa9fdca3312, 0x1bab10e32d, 0x3706b1677a, 0x644d626ffd)

REMEDIATION = {
    'BTC_BECH32': 'Pass a bech32 or bech32m string: one case, a 1 separator, valid characters and checksum.',
    'BTC_ADDRESS': 'Pass a native segwit address (bech32 for version 0, bech32m for version 1 and above) for the pinned network, or the output script as hex.',
    'BTC_NETWORK': 'Use network bc (bitcoin), tb (testnet or signet) or bcrt (regtest).',
    'BTC_PUBKEY': 'Pass a 33-byte compressed secp256k1 public key as hex; segwit version 0 policy refuses uncompressed keys.',
    'BTC_SCRIPT': 'Keep scripts within 10000 bytes and pushes minimal.',
    'BTC_TX': 'Pass a transaction {version, locktime, inputs: [{txid, vout, sequence}], outputs: [{value, script}]} with in-range fields.',
    'BTC_TX_BYTES': 'The transaction bytes are truncated, non-minimal or carry trailing data.',
    'BTC_SIGHASH': 'Only SIGHASH_ALL (1) is produced or accepted.',
    'BTC_DER': 'Pass a strict DER (BIP 66) ECDSA signature with low s, followed by its sighash byte.',
    'BTC_KEY': 'Pass a cryptography secp256k1 private key loaded by the owner from its keystore.',
    'BTC_PSBT': 'Pass a BIP 174 (version 0) or BIP 370 (version 2) PSBT as bytes or base64, with unique keys and the required fields of its version.',
    'BTC_PSBT_VERSION': 'Use PSBT version 0 or 2; a version 0 PSBT must not carry version 2 fields and the reverse.',
    'BTC_PSBT_LIMIT': 'Keep a PSBT within 1 MiB, 256 inputs and outputs and 512 key-value pairs per map.',
    'BTC_DESCRIPTOR': 'Pass a descriptor whose characters are in the BIP 380 input set, with a correct 8-character checksum.',
    'BTC_OLDER': 'Use a block-based relative timelock older(n) with 1 <= n <= 65535.',
    'BTC_FINAL': 'The input lacks the signatures or script its template needs to finalise.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the input against the documented format.')


def sha256(data):
    return hashlib.sha256(data).digest()


def hash256(data):
    return sha256(sha256(data))


# bech32 / bech32m (BIP 173, BIP 350) ---------------------------------------

def _polymod(values):
    check = 1
    for value in values:
        top = check >> 25
        check = (check & 0x1ffffff) << 5 ^ value
        for i in range(5):
            check ^= _GENERATOR[i] if (top >> i) & 1 else 0
    return check


def _expand(hrp):
    return [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp]


def bech32_encode(hrp, data, spec=BECH32):
    need(type(hrp) is str and 1 <= len(hrp) <= 83 and all(33 <= ord(c) <= 126 for c in hrp) and hrp == hrp.lower(), 'BTC_BECH32')
    need(spec in (BECH32, BECH32M) and all(type(d) is int and 0 <= d < 32 for d in data), 'BTC_BECH32')
    polymod = _polymod(_expand(hrp) + list(data) + [0] * 6) ^ spec
    checksum = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + '1' + ''.join(CHARSET[d] for d in list(data) + checksum)


def bech32_decode(text, limit=90):
    """(hrp, 5-bit data, BECH32 or BECH32M). limit None allows longer strings, as BOLT 11 does."""
    need(type(text) is str and 8 <= len(text) <= (limit or 8192), 'BTC_BECH32')
    need(all(33 <= ord(c) <= 126 for c in text) and (text == text.lower() or text == text.upper()), 'BTC_BECH32')
    text = text.lower()
    at = text.rfind('1')
    need(1 <= at <= 83 and at + 7 <= len(text) and all(c in CHARSET for c in text[at + 1:]), 'BTC_BECH32')
    hrp, data = text[:at], [CHARSET.find(c) for c in text[at + 1:]]
    spec = _polymod(_expand(hrp) + data)
    need(spec in (BECH32, BECH32M), 'BTC_BECH32')
    return hrp, data[:-6], spec


def convertbits(data, frombits, tobits, pad=True):
    acc = bits = 0
    out = []
    maxv = (1 << tobits) - 1
    for value in data:
        need(type(value) is int and 0 <= value < 1 << frombits, 'BTC_BECH32')
        acc = (acc << frombits) | value
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            out.append((acc >> bits) & maxv)
    if pad:
        if bits:
            out.append((acc << (tobits - bits)) & maxv)
    else:
        need(bits < frombits and not (acc << (tobits - bits)) & maxv, 'BTC_BECH32')
    return out


def segwit_address(network, version, program):
    need(network in NETWORKS, 'BTC_NETWORK')
    need(type(version) is int and 0 <= version <= 16 and type(program) is bytes and 2 <= len(program) <= 40, 'BTC_ADDRESS')
    need(version != 0 or len(program) in (20, 32), 'BTC_ADDRESS')
    return bech32_encode(network, [version] + convertbits(program, 8, 5), BECH32 if version == 0 else BECH32M)


def decode_address(network, text):
    """(witness version, program) of a native segwit address for the pinned network."""
    need(network in NETWORKS, 'BTC_NETWORK')
    try:
        hrp, data, spec = bech32_decode(text, 90)
        program = bytes(convertbits(data[1:], 5, 8, False))
    except (ValueError, IndexError):
        raise ValueError('BTC_ADDRESS') from None
    need(hrp == network and data and 0 <= data[0] <= 16 and 2 <= len(program) <= 40, 'BTC_ADDRESS')
    need(data[0] != 0 or len(program) in (20, 32), 'BTC_ADDRESS')
    need(spec == (BECH32 if data[0] == 0 else BECH32M), 'BTC_ADDRESS')
    return data[0], program


def witness_output(version, program):
    return bytes([OP_0 if version == 0 else 0x50 + version]) + push(program)


def output_script(network, destination):
    """The scriptPubKey of {'address': segwit address} or {'script': hex}."""
    need(type(destination) is dict and len(destination) == 1, 'BTC_ADDRESS')
    if 'address' in destination:
        return witness_output(*decode_address(network, destination['address']))
    text = destination.get('script')
    need(type(text) is str and 0 < len(text) <= 2 * MAX_SCRIPT and re.fullmatch(r'(?:[0-9a-f]{2})+', text) is not None, 'BTC_ADDRESS')
    return bytes.fromhex(text)


# Scripts -------------------------------------------------------------------

def push(data):
    need(type(data) is bytes and len(data) <= 520, 'BTC_SCRIPT')
    if len(data) < OP_PUSHDATA1:
        return bytes([len(data)]) + data
    if len(data) <= 0xff:
        return bytes([OP_PUSHDATA1, len(data)]) + data
    return bytes([OP_PUSHDATA2]) + len(data).to_bytes(2, 'little') + data


def number(value):
    """Minimal script number push (OP_0, OP_1..OP_16 or a CScriptNum)."""
    need(type(value) is int and 0 <= value < 2 ** 31, 'BTC_SCRIPT')
    if value == 0:
        return bytes([OP_0])
    if value <= 16:
        return bytes([0x50 + value])
    raw = value.to_bytes((value.bit_length() + 8) // 8, 'little')
    return push(raw)


def pubkey(value):
    """33 compressed bytes from hex, checked on the curve."""
    need(type(value) is str and re.fullmatch(r'0[23][0-9a-f]{64}', value) is not None, 'BTC_PUBKEY')
    raw = bytes.fromhex(value)
    try:
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256K1(), raw)
    except ValueError:
        raise ValueError('BTC_PUBKEY') from None
    return raw


def escrow_script(keys, refund_older=None):
    """multi(2,B,S,A), or or_d(multi(2,B,S,A),and_v(v:pk(B),older(n))) when refund_older is set."""
    need(type(keys) in (list, tuple) and len(keys) == 3 and len(set(keys)) == 3, 'BTC_PUBKEY')
    raw = [pubkey(key) for key in keys]
    script = number(2) + b''.join(push(key) for key in raw) + number(3) + bytes([OP_CHECKMULTISIG])
    if refund_older is not None:
        need(type(refund_older) is int and 1 <= refund_older <= 0xffff, 'BTC_OLDER')
        script += bytes([OP_IFDUP, OP_NOTIF]) + push(raw[0]) + bytes([OP_CHECKSIGVERIFY]) + number(refund_older) + bytes([OP_CSV, OP_ENDIF])
    return script


def escrow_descriptor(keys, refund_older=None):
    multi = 'multi(2,' + ','.join(keys) + ')'
    body = multi if refund_older is None else f'or_d({multi},and_v(v:pk({keys[0]}),older({refund_older})))'
    escrow_script(keys, refund_older)
    return add_checksum('wsh(' + body + ')')


def p2wsh(script):
    need(type(script) is bytes and 0 < len(script) <= MAX_SCRIPT, 'BTC_SCRIPT')
    return witness_output(0, sha256(script))


# BIP 380 descriptor checksum -------------------------------------------------

def _descriptor_polymod(symbols):
    check = 1
    for value in symbols:
        top = check >> 35
        check = (check & 0x7ffffffff) << 5 ^ value
        for i in range(5):
            check ^= _DESCRIPTOR_GENERATOR[i] if (top >> i) & 1 else 0
    return check


def _expand_descriptor(text):
    groups, symbols = [], []
    for c in text:
        need(c in INPUT_CHARSET, 'BTC_DESCRIPTOR')
        v = INPUT_CHARSET.find(c)
        symbols.append(v & 31)
        groups.append(v >> 5)
        if len(groups) == 3:
            symbols.append(groups[0] * 9 + groups[1] * 3 + groups[2])
            groups = []
    if len(groups) == 1:
        symbols.append(groups[0])
    elif len(groups) == 2:
        symbols.append(groups[0] * 3 + groups[1])
    return symbols


def add_checksum(text):
    need(type(text) is str and 0 < len(text) <= 16384, 'BTC_DESCRIPTOR')
    checksum = _descriptor_polymod(_expand_descriptor(text) + [0] * 8) ^ 1
    return text + '#' + ''.join(CHARSET[(checksum >> (5 * (7 - i))) & 31] for i in range(8))


def check_descriptor(text):
    """The descriptor body when its BIP 380 checksum is correct."""
    need(type(text) is str and 10 <= len(text) <= 16384 and text[-9] == '#', 'BTC_DESCRIPTOR')
    need(all(c in CHARSET for c in text[-8:]), 'BTC_DESCRIPTOR')
    need(_descriptor_polymod(_expand_descriptor(text[:-9]) + [CHARSET.find(c) for c in text[-8:]]) == 1, 'BTC_DESCRIPTOR')
    return text[:-9]


# Transactions ----------------------------------------------------------------

def compact_size(value):
    need(type(value) is int and 0 <= value < 2 ** 64, 'BTC_TX')
    if value < 0xfd:
        return bytes([value])
    if value <= 0xffff:
        return b'\xfd' + value.to_bytes(2, 'little')
    if value <= 0xffffffff:
        return b'\xfe' + value.to_bytes(4, 'little')
    return b'\xff' + value.to_bytes(8, 'little')


class _Reader:
    def __init__(self, data, code):
        self.data, self.at, self.code = data, 0, code

    def take(self, size):
        need(size >= 0 and self.at + size <= len(self.data), self.code)
        out = self.data[self.at:self.at + size]
        self.at += size
        return out

    def integer(self, size):
        return int.from_bytes(self.take(size), 'little')

    def compact(self):
        first = self.integer(1)
        if first < 0xfd:
            return first
        size = {0xfd: 2, 0xfe: 4, 0xff: 8}[first]
        value = self.integer(size)
        need(value >= {2: 0xfd, 4: 0x10000, 8: 0x100000000}[size], self.code)  # minimal encoding
        return value

    def done(self):
        return self.at == len(self.data)


def _hex32(value, code='BTC_TX'):
    need(type(value) is str and re.fullmatch(r'[0-9a-f]{64}', value) is not None, code)
    return bytes.fromhex(value)


def _check_tx(tx):
    need(type(tx) is dict and set(tx) == {'version', 'locktime', 'inputs', 'outputs'}, 'BTC_TX')
    need(type(tx['version']) is int and -2 ** 31 <= tx['version'] < 2 ** 31, 'BTC_TX')
    need(type(tx['locktime']) is int and 0 <= tx['locktime'] < 2 ** 32, 'BTC_TX')
    need(type(tx['inputs']) is list and len(tx['inputs']) <= MAX_IO and type(tx['outputs']) is list
         and len(tx['outputs']) <= MAX_IO, 'BTC_TX')
    for row in tx['inputs']:
        need(type(row) is dict and set(row) == {'txid', 'vout', 'sequence'}, 'BTC_TX')
        _hex32(row['txid'])
        need(type(row['vout']) is int and 0 <= row['vout'] < 2 ** 32 and type(row['sequence']) is int
             and 0 <= row['sequence'] < 2 ** 32, 'BTC_TX')
    for row in tx['outputs']:
        need(type(row) is dict and set(row) == {'value', 'script'}, 'BTC_TX')
        need(type(row['value']) is int and 0 <= row['value'] <= 21 * 10 ** 14, 'BTC_TX')
        need(type(row['script']) is str and len(row['script']) <= 2 * MAX_SCRIPT
             and re.fullmatch(r'(?:[0-9a-f]{2})*', row['script']) is not None, 'BTC_TX')
    return tx


def _outpoint(row):
    return bytes.fromhex(row['txid'])[::-1] + row['vout'].to_bytes(4, 'little')


def _output(row):
    script = bytes.fromhex(row['script'])
    return row['value'].to_bytes(8, 'little') + compact_size(len(script)) + script


def serialize_tx(tx, witnesses=None):
    """Network serialisation; with witnesses (one stack per input) the BIP 144 format."""
    _check_tx(tx)
    body = compact_size(len(tx['inputs'])) + b''.join(_outpoint(row) + b'\0' + row['sequence'].to_bytes(4, 'little')
                                                       for row in tx['inputs'])
    body += compact_size(len(tx['outputs'])) + b''.join(_output(row) for row in tx['outputs'])
    version = (tx['version'] % 2 ** 32).to_bytes(4, 'little')
    locktime = tx['locktime'].to_bytes(4, 'little')
    if witnesses is None:
        return version + body + locktime
    need(type(witnesses) is list and len(witnesses) == len(tx['inputs']), 'BTC_TX')
    stacks = b''.join(compact_size(len(stack)) + b''.join(compact_size(len(item)) + item for item in stack)
                      for stack in witnesses)
    return version + b'\x00\x01' + body + stacks + locktime


def parse_unsigned_tx(raw):
    """The unsigned transaction a version 0 PSBT carries: empty scriptSigs, no witness, nothing trailing."""
    need(type(raw) is bytes and 10 <= len(raw) <= MAX_PSBT, 'BTC_TX_BYTES')
    reader = _Reader(raw, 'BTC_TX_BYTES')
    version = int.from_bytes(reader.take(4), 'little', signed=True)
    count = reader.compact()
    need(count <= MAX_IO, 'BTC_PSBT_LIMIT')
    inputs = []
    for _ in range(count):
        txid = reader.take(32)[::-1].hex()
        vout = reader.integer(4)
        need(reader.compact() == 0, 'BTC_PSBT')  # scriptSig must be empty
        inputs.append({'txid': txid, 'vout': vout, 'sequence': reader.integer(4)})
    count = reader.compact()
    need(count <= MAX_IO, 'BTC_PSBT_LIMIT')
    outputs = []
    for _ in range(count):
        value = reader.integer(8)
        size = reader.compact()
        need(size <= MAX_SCRIPT, 'BTC_TX_BYTES')
        outputs.append({'value': value, 'script': reader.take(size).hex()})
    tx = {'version': version, 'inputs': inputs, 'outputs': outputs, 'locktime': reader.integer(4)}
    need(reader.done(), 'BTC_TX_BYTES')
    _check_tx(tx)
    need(serialize_tx(tx) == raw, 'BTC_TX_BYTES')
    return tx


def txid(tx):
    return hash256(serialize_tx(tx))[::-1].hex()


def bip143_sighash(tx, index, script_code, amount, sighash=SIGHASH_ALL):
    """BIP 143 signature hash of input index for a version 0 witness script (SIGHASH_ALL)."""
    _check_tx(tx)
    need(sighash == SIGHASH_ALL, 'BTC_SIGHASH')
    need(type(index) is int and 0 <= index < len(tx['inputs']), 'BTC_TX')
    need(type(script_code) is bytes and 0 < len(script_code) <= MAX_SCRIPT, 'BTC_SCRIPT')
    need(type(amount) is int and 0 <= amount <= 21 * 10 ** 14, 'BTC_TX')
    row = tx['inputs'][index]
    preimage = ((tx['version'] % 2 ** 32).to_bytes(4, 'little') +
                hash256(b''.join(_outpoint(item) for item in tx['inputs'])) +
                hash256(b''.join(item['sequence'].to_bytes(4, 'little') for item in tx['inputs'])) +
                _outpoint(row) + compact_size(len(script_code)) + script_code + amount.to_bytes(8, 'little') +
                row['sequence'].to_bytes(4, 'little') + hash256(b''.join(_output(item) for item in tx['outputs'])) +
                tx['locktime'].to_bytes(4, 'little') + sighash.to_bytes(4, 'little'))
    return hash256(preimage)


# Strict DER ECDSA (BIP 66) with low s (BIP 146 policy) ------------------------

def der_encode(r, s):
    def integer(value):
        raw = value.to_bytes((value.bit_length() + 7) // 8 or 1, 'big')
        if raw[0] & 0x80:
            raw = b'\0' + raw
        return b'\x02' + bytes([len(raw)]) + raw
    body = integer(r) + integer(s)
    return b'\x30' + bytes([len(body)]) + body


def der_decode(signature):
    """(r, s) of strict DER bytes without the sighash byte."""
    need(type(signature) is bytes and 8 <= len(signature) <= 72 and signature[0] == 0x30
         and signature[1] == len(signature) - 2, 'BTC_DER')
    values, at = [], 2
    for _ in range(2):
        need(at + 2 <= len(signature) and signature[at] == 0x02, 'BTC_DER')
        size = signature[at + 1]
        raw = signature[at + 2:at + 2 + size]
        need(1 <= size <= 33 and len(raw) == size and not raw[0] & 0x80, 'BTC_DER')
        need(size == 1 or raw[0] != 0 or raw[1] & 0x80, 'BTC_DER')
        values.append(int.from_bytes(raw, 'big'))
        at += 2 + size
    need(at == len(signature) and 1 <= values[0] < N and 1 <= values[1] <= N // 2, 'BTC_DER')
    return values[0], values[1]


def public_bytes(private_key):
    need(isinstance(private_key, ec.EllipticCurvePrivateKey) and private_key.curve.name == 'secp256k1', 'BTC_KEY')
    return private_key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.CompressedPoint)


def ecdsa_sign(private_key, digest, sighash=SIGHASH_ALL):
    """Owner action: deterministic (RFC 6979) low-s DER signature plus the sighash byte."""
    public_bytes(private_key)
    need(type(digest) is bytes and len(digest) == 32 and sighash == SIGHASH_ALL, 'BTC_SIGHASH')
    r, s = decode_dss_signature(private_key.sign(digest, ec.ECDSA(Prehashed(hashes.SHA256()), deterministic_signing=True)))
    if s > N // 2:
        s = N - s
    return der_encode(r, s) + bytes([sighash])


def ecdsa_verify(public, digest, signature):
    """True for a strict-DER low-s signature by the 33-byte public key over the 32-byte digest."""
    need(type(digest) is bytes and len(digest) == 32, 'BTC_DER')
    r, s = der_decode(signature)
    try:
        key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256K1(), public)
        key.verify(der_encode(r, s), digest, ec.ECDSA(Prehashed(hashes.SHA256())))
        return True
    except (InvalidSignature, ValueError):
        return False


# PSBT (BIP 174, BIP 370) -------------------------------------------------------

def _keytype(key):
    reader = _Reader(key, 'BTC_PSBT')
    kind = reader.compact()
    return kind, key[reader.at:]


def _read_map(reader):
    pairs, seen = [], set()
    while True:
        size = reader.compact()
        if size == 0:
            return pairs
        need(size <= 1024 and len(pairs) < MAX_PAIRS, 'BTC_PSBT_LIMIT')
        key = reader.take(size)
        value = reader.take(reader.compact())
        need(key not in seen, 'BTC_PSBT')
        seen.add(key)
        pairs.append((key, value))


def _index(pairs, scope):
    """{keytype: [(keydata, value)]} after the per-type key-length rules."""
    out = {}
    for key, value in pairs:
        kind, data = _keytype(key)
        if kind in _BARE[scope]:
            need(data == b'', 'BTC_PSBT')
        if (scope, kind) in ((1, I_PARTIAL_SIG), (1, I_BIP32), (2, O_BIP32)):
            need(len(data) in (33, 65), 'BTC_PSBT')
        if (scope, kind) == (0, G_XPUB):
            need(len(data) == 78, 'BTC_PSBT')
        out.setdefault(kind, []).append((data, value))
    return out


def _one(index, kind, size=None):
    rows = index.get(kind)
    if rows is None:
        return None
    value = rows[0][1]
    need(size is None or len(value) == size, 'BTC_PSBT')
    return value


def decode_psbt(raw):
    """{'version', 'global', 'inputs', 'outputs'}: ordered key-value pairs per map, unknown keys kept."""
    if type(raw) is str:
        need(0 < len(raw) <= 4 * MAX_PSBT // 3 + 4, 'BTC_PSBT_LIMIT')
        try:
            raw = base64.b64decode(raw, validate=True)
        except ValueError:
            raise ValueError('BTC_PSBT') from None
    need(type(raw) is bytes and len(raw) <= MAX_PSBT, 'BTC_PSBT_LIMIT')
    need(raw.startswith(MAGIC), 'BTC_PSBT')
    reader = _Reader(raw[5:], 'BTC_PSBT')
    global_pairs = _read_map(reader)
    found = _index(global_pairs, 0)
    version_raw = _one(found, G_VERSION, 4)
    version = 0 if version_raw is None else int.from_bytes(version_raw, 'little')
    need(version in (0, 2), 'BTC_PSBT_VERSION')
    if version == 0:
        need(not set(found) & _V2_GLOBAL and G_UNSIGNED_TX in found, 'BTC_PSBT_VERSION')
        tx = parse_unsigned_tx(found[G_UNSIGNED_TX][0][1])
        counts = len(tx['inputs']), len(tx['outputs'])
    else:
        need(G_UNSIGNED_TX not in found and {G_TX_VERSION, G_INPUT_COUNT, G_OUTPUT_COUNT} <= set(found), 'BTC_PSBT_VERSION')
        _one(found, G_TX_VERSION, 4)
        counts = []
        for kind in (G_INPUT_COUNT, G_OUTPUT_COUNT):
            counter = _Reader(_one(found, kind), 'BTC_PSBT')
            counts.append(counter.compact())
            need(counter.done(), 'BTC_PSBT')
        for kind, size in ((G_FALLBACK_LOCKTIME, 4), (G_TX_MODIFIABLE, 1)):
            _one(found, kind, size)
    need(counts[0] <= MAX_IO and counts[1] <= MAX_IO, 'BTC_PSBT_LIMIT')
    inputs = [_read_map(reader) for _ in range(counts[0])]
    outputs = [_read_map(reader) for _ in range(counts[1])]
    need(reader.done(), 'BTC_PSBT')
    for pairs in inputs:
        index = _index(pairs, 1)
        if version == 0:
            need(not set(index) & _V2_INPUT, 'BTC_PSBT_VERSION')
        else:
            need({I_PREVIOUS_TXID, I_OUTPUT_INDEX} <= set(index), 'BTC_PSBT_VERSION')
            for kind, size in ((I_PREVIOUS_TXID, 32), (I_OUTPUT_INDEX, 4), (I_SEQUENCE, 4), (I_TIME_LOCKTIME, 4), (I_HEIGHT_LOCKTIME, 4)):
                _one(index, kind, size)
            if I_TIME_LOCKTIME in index:
                need(int.from_bytes(_one(index, I_TIME_LOCKTIME), 'little') >= 500000000, 'BTC_PSBT')
            if I_HEIGHT_LOCKTIME in index:
                need(0 < int.from_bytes(_one(index, I_HEIGHT_LOCKTIME), 'little') < 500000000, 'BTC_PSBT')
        if I_SIGHASH in index:
            _one(index, I_SIGHASH, 4)
    for pairs in outputs:
        index = _index(pairs, 2)
        if version == 0:
            need(not set(index) & _V2_OUTPUT, 'BTC_PSBT_VERSION')
        else:
            need({O_AMOUNT, O_SCRIPT} <= set(index), 'BTC_PSBT_VERSION')
            _one(index, O_AMOUNT, 8)
    return {'version': version, 'global': global_pairs, 'inputs': inputs, 'outputs': outputs}


def encode_psbt(psbt):
    def write(pairs):
        return b''.join(compact_size(len(key)) + key + compact_size(len(value)) + value for key, value in pairs) + b'\x00'
    raw = MAGIC + write(psbt['global']) + b''.join(write(pairs) for pairs in psbt['inputs']) + \
        b''.join(write(pairs) for pairs in psbt['outputs'])
    need(len(raw) <= MAX_PSBT, 'BTC_PSBT_LIMIT')
    return raw


def psbt_base64(psbt):
    return base64.b64encode(encode_psbt(psbt)).decode('ascii')


def key(kind, data=b''):
    return compact_size(kind) + data


def get(pairs, kind, data=b''):
    wanted = key(kind, data)
    return next((value for k, value in pairs if k == wanted), None)


def put(pairs, kind, value, data=b''):
    """Replace or append one key-value pair, keeping map order otherwise."""
    wanted = key(kind, data)
    kept = [(k, v) for k, v in pairs if k != wanted]
    return kept + [(wanted, value)]


def unsigned_tx(psbt):
    """The transaction both PSBT versions describe (BIP 370 lock-time rule for version 2)."""
    if psbt['version'] == 0:
        return parse_unsigned_tx(get(psbt['global'], G_UNSIGNED_TX))
    inputs, times, heights = [], [], []
    for pairs in psbt['inputs']:
        sequence = get(pairs, I_SEQUENCE)
        inputs.append({'txid': get(pairs, I_PREVIOUS_TXID)[::-1].hex(), 'vout': int.from_bytes(get(pairs, I_OUTPUT_INDEX), 'little'),
                       'sequence': 0xffffffff if sequence is None else int.from_bytes(sequence, 'little')})
        time, height = get(pairs, I_TIME_LOCKTIME), get(pairs, I_HEIGHT_LOCKTIME)
        times.append(None if time is None else int.from_bytes(time, 'little'))
        heights.append(None if height is None else int.from_bytes(height, 'little'))
    locktime = get(psbt['global'], G_FALLBACK_LOCKTIME)
    locktime = 0 if locktime is None else int.from_bytes(locktime, 'little')
    constrained = [i for i in range(len(inputs)) if times[i] is not None or heights[i] is not None]
    if constrained:
        if all(heights[i] is not None for i in constrained):
            locktime = max(heights[i] for i in constrained)
        else:
            need(all(times[i] is not None for i in constrained), 'BTC_PSBT')
            locktime = max(times[i] for i in constrained)
    outputs = [{'value': int.from_bytes(get(pairs, O_AMOUNT), 'little', signed=True), 'script': get(pairs, O_SCRIPT).hex()}
               for pairs in psbt['outputs']]
    tx = {'version': int.from_bytes(get(psbt['global'], G_TX_VERSION), 'little', signed=True), 'inputs': inputs,
          'outputs': outputs, 'locktime': locktime}
    return _check_tx(tx)


def make_psbt(tx, input_fields, version=0):
    """A PSBT for tx; input_fields is one list of (keytype, value) per input."""
    _check_tx(tx)
    need(version in (0, 2) and type(input_fields) is list and len(input_fields) == len(tx['inputs']), 'BTC_PSBT_VERSION')
    if version == 0:
        global_pairs = [(key(G_UNSIGNED_TX), serialize_tx(tx))]
        inputs = [[(key(kind), value) for kind, value in fields] for fields in input_fields]
        outputs = [[] for _ in tx['outputs']]
    else:
        global_pairs = [(key(G_TX_VERSION), (tx['version'] % 2 ** 32).to_bytes(4, 'little')),
                        (key(G_FALLBACK_LOCKTIME), tx['locktime'].to_bytes(4, 'little')),
                        (key(G_INPUT_COUNT), compact_size(len(tx['inputs']))),
                        (key(G_OUTPUT_COUNT), compact_size(len(tx['outputs']))),
                        (key(G_VERSION), (2).to_bytes(4, 'little'))]
        inputs = [[(key(I_PREVIOUS_TXID), bytes.fromhex(row['txid'])[::-1]),
                   (key(I_OUTPUT_INDEX), row['vout'].to_bytes(4, 'little')),
                   (key(I_SEQUENCE), row['sequence'].to_bytes(4, 'little'))] + [(key(kind), value) for kind, value in fields]
                  for row, fields in zip(tx['inputs'], input_fields)]
        outputs = [[(key(O_AMOUNT), row['value'].to_bytes(8, 'little')), (key(O_SCRIPT), bytes.fromhex(row['script']))]
                   for row in tx['outputs']]
    psbt = {'version': version, 'global': global_pairs, 'inputs': inputs, 'outputs': outputs}
    return decode_psbt(encode_psbt(psbt))


def witness_utxo(amount, script):
    need(type(amount) is int and 0 <= amount <= 21 * 10 ** 14 and type(script) is bytes, 'BTC_TX')
    return amount.to_bytes(8, 'little') + compact_size(len(script)) + script


def read_witness_utxo(value):
    reader = _Reader(value, 'BTC_PSBT')
    amount = reader.integer(8)
    script = reader.take(reader.compact())
    need(reader.done(), 'BTC_PSBT')
    return amount, script


def partial_signatures(pairs):
    """{pubkey hex: signature bytes} of one input."""
    out = {}
    for k, value in pairs:
        kind, data = _keytype(k)
        if kind == I_PARTIAL_SIG:
            out[data.hex()] = value
    return out


def finalize(psbt, index, stack):
    """BIP 174 Input Finalizer: keep UTXO and unknown fields, set PSBT_IN_FINAL_SCRIPTWITNESS."""
    need(type(stack) is list and all(type(item) is bytes and len(item) <= MAX_SCRIPT for item in stack), 'BTC_FINAL')
    known = {I_PARTIAL_SIG, I_SIGHASH, I_REDEEM_SCRIPT, I_WITNESS_SCRIPT, I_BIP32, I_FINAL_SCRIPTSIG, I_FINAL_WITNESS}
    kept = [(k, v) for k, v in psbt['inputs'][index] if _keytype(k)[0] not in known]
    witness = compact_size(len(stack)) + b''.join(compact_size(len(item)) + item for item in stack)
    inputs = list(psbt['inputs'])
    inputs[index] = kept + [(key(I_FINAL_WITNESS), witness)]
    return {**psbt, 'inputs': inputs}


def extract(psbt):
    """Transaction Extractor: the signed transaction bytes once every input is finalised."""
    tx = unsigned_tx(psbt)
    stacks = []
    for pairs in psbt['inputs']:
        raw = get(pairs, I_FINAL_WITNESS)
        need(raw is not None, 'BTC_FINAL')
        reader = _Reader(raw, 'BTC_FINAL')
        stack = [reader.take(reader.compact()) for _ in range(reader.compact())]
        need(reader.done(), 'BTC_FINAL')
        stacks.append(stack)
    return serialize_tx(tx, stacks)


def describe():
    return {'addresses': 'BIP 173 bech32 and BIP 350 bech32m native segwit', 'signature_hash': 'BIP 143, SIGHASH_ALL',
            'signatures': 'strict DER (BIP 66), low s (BIP 146 policy)', 'psbt': 'BIP 174 version 0 and BIP 370 version 2',
            'descriptors': 'BIP 380 checksum, BIP 383 multi(), BIP 379 (Draft) or_d/and_v/older template',
            'limits': {'psbt_bytes': MAX_PSBT, 'inputs_or_outputs': MAX_IO, 'pairs_per_map': MAX_PAIRS},
            'network_contacted': False, 'broadcast': False, 'execution_authorized': False}
