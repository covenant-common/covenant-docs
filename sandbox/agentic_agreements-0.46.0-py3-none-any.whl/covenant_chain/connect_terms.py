"""Machine-readable integrator terms: how a plugged-in rail, forum, registry or tool earns today.

Everything here is read from economics that already ship: the scale fee
policy defaults (INTEGRATOR, REFERRAL and FEE_REBATE rows and the integrator
retro round), the ads CPA split, native panel fees and the arbitrator roster,
the builder programme and a rail's own posted fee schedule. Numbers are
computed from that code at call time, so this page cannot drift from it. They
are defaults: the fee policy a live chain adopted governs, so read it there
before quoting. Nothing here is an offer, a contract or a payment.

Where the existing economics do not reach (a per-kind revenue share, automatic
integrator attribution for adopted adapters, a fee for off-chain fair-fix
stages, certification pricing), the terms say so under owner_decisions instead
of inventing a number.
"""
from . import connect
from .crypto import digest

TERMS = 'urn:aap:connect-integrator-terms:0.1'
POOLS = ('maintenance', 'rebate_pool', 'reserve', 'integrator_pool', 'founder', 'ecosystem', 'bond_escrow', 'operators',
         'archive_pool', 'stake_pool', 'stake_escrow', 'founder_vest', 'waqf', 'burn')
BY_KIND = {
    'payment_rail': ('rail_fees', 'integrator_share', 'referral_share', 'fee_rebate', 'builder_programme'),
    'adjudicator': ('panel_fees', 'integrator_share', 'referral_share', 'fee_rebate', 'builder_programme'),
    'identity_provider': ('integrator_share', 'referral_share', 'fee_rebate', 'builder_programme'),
    'discovery_source': ('integrator_share', 'referral_share', 'ad_cpa_integrator_share', 'fee_rebate', 'builder_programme'),
    'evidence_source': ('integrator_share', 'referral_share', 'fee_rebate', 'builder_programme'),
    'transport': ('integrator_share', 'referral_share', 'fee_rebate', 'builder_programme'),
    'registry_export': ('integrator_share', 'referral_share', 'ad_cpa_integrator_share', 'fee_rebate', 'builder_programme'),
}


def _defaults():
    from .scale_fees import make_policy
    pools = {name: digest('AAP-CONNECT-TERMS-POOL', {'pool': name}) for name in POOLS}
    policy = make_policy('fee', digest('AAP-CONNECT-TERMS-GOVERNOR', {}), pools)
    rows = {}
    for row in policy['beneficiaries']:
        rows[row['purpose']] = rows.get(row['purpose'], 0) + row['bps']
    return policy['scale'], rows


def _streams():
    from .ads.constants import MAX_EXCHANGE_BPS, MIN_FEE_REDUCTION_BPS
    from .ads.split import DEFAULT_SPLIT
    from .arbitration import MODES, REMEDIES
    scale, rows = _defaults()
    integrator, window = scale['integrator'], scale['window']
    eligibility = [
        'The agreement settled: EXECUTE after the challenge window, and the agreement was honoured.',
        'The integrator is not the principal, the agent or the counterparty of that agreement.',
        'Counting this deal, the principal dealt with at least %d distinct counterparties in the window.'
        % scale['ads']['min_counterparties'],
        'The principal and counterparty have fewer than %d earlier settlements together in the window.' % window['pair_cap'],
        'A noted integrator earns once its note is at least %d blocks old; one named on the EXECUTE envelope earns when '
        'the principal has a settlement at least that old.' % scale['points']['retention_blocks'],
        'No referral cycle back to someone who already referred this principal.']
    return [
        {'id': 'integrator_share', 'who': 'Any account named as the integrator of a settled agreement: the rail, forum, '
                                          'registry, wallet, gateway or tool that brought the deal.',
         'summary': '%d basis points of the protocol unit price on each settled deal it is named on, booked to the '
                    'integrator pool and claimed with ECON_INTEGRATOR_PAY.' % integrator['fee_bps'],
         'how_named': ['ECON_INTEGRATOR_NOTE, sent by a party while the agreement is BOUND',
                       'fee.integrator on the EXECUTE envelope'],
         'amount': {'bps_of_protocol_unit_price': integrator['fee_bps'], 'per': 'settled agreement',
                    'source': 'carved from the protocol fee surplus above measured cost; zero when there is no surplus'},
         'fee_split_row': {'purpose': 'INTEGRATOR', 'bps': rows.get('INTEGRATOR', 0),
                           'meaning': 'ROUTES_THE_CUT_TO_THE_INTEGRATOR_POOL; ROW_BPS_DO_NOT_SET_ITS_SIZE'},
         'eligibility': eligibility,
         'claim': {'operation': 'ECON_INTEGRATOR_PAY', 'round_blocks': integrator['round_blocks'], 'horizon_rounds': 2,
                   'per_owner_cap': integrator['per_owner_cap']},
         'unclaimed': 'Cuts older than two rounds can be swept to the FEE_REBATE pool (ECON_INTEGRATOR_SWEEP).',
         'ineligible': 'A named integrator who is not eligible earns nothing; that share goes to the fee rebate row.',
         'profile': 'covenant-native/0.15 economics/0.3 scale fee policy',
         'modules': ['covenant_chain/scale_fees.py', 'covenant_chain/token_rebates.py']},
        {'id': 'referral_share', 'who': 'An account named as referrer of a settled agreement; never the same account as its integrator.',
         'summary': '%d basis points of the protocol unit price on each settled deal it referred, booked to the '
                    'integrator pool and claimed the same way.' % integrator['fee_bps'],
         'how_named': ['fee.referrer on the EXECUTE envelope'],
         'amount': {'bps_of_protocol_unit_price': integrator['fee_bps'], 'per': 'settled agreement',
                    'source': 'carved from the same surplus after the integrator share'},
         'fee_split_row': {'purpose': 'REFERRAL', 'bps': rows.get('REFERRAL', 0),
                           'meaning': 'ROUTES_THE_CUT_TO_THE_INTEGRATOR_POOL; ROW_BPS_DO_NOT_SET_ITS_SIZE'},
         'eligibility': eligibility, 'claim': {'operation': 'ECON_INTEGRATOR_PAY'},
         'profile': 'covenant-native/0.15 economics/0.3 scale fee policy', 'modules': ['covenant_chain/scale_fees.py']},
        {'id': 'fee_rebate', 'who': 'Any account that paid protocol fees and keeps its promises.',
         'summary': 'A payer that keeps at least %d basis points of its promises claims its accrued give-back from the '
                    'fee rebate pool with ECON_REBATE_CLAIM.' % scale['rebates']['honour_bps'],
         'amount': {'fee_split_row': {'purpose': 'FEE_REBATE', 'bps': rows.get('FEE_REBATE', 0),
                                      'meaning': 'ROUTES_THE_CUSTOMER_SHARE; ROW_BPS_DO_NOT_SET_ITS_SIZE'},
                    'customer_share_of_distributable_surplus_bps': scale['shares']['customer'],
                    'claimable_bps_of_accrued_giveback': scale['rebates']['token_rebate_bps']},
         'eligibility': ['The payer\'s kept-promise rate is at least %d basis points.' % scale['rebates']['honour_bps']],
         'claim': {'operation': 'ECON_REBATE_CLAIM'}, 'profile': 'covenant-native/0.15 economics/0.3 scale fee policy',
         'modules': ['covenant_chain/token_rebates.py']},
        {'id': 'ad_cpa_integrator_share', 'who': 'The integrator whose surface carried an ad that led to a settled conversion.',
         'summary': '%d of 10,000 of each settled cost-per-action conversion; the owner gets %d, fee reduction at least '
                    '%d and the exchange at most %d.' % (DEFAULT_SPLIT['integrator_bps'], DEFAULT_SPLIT['owner_bps'],
                                                         MIN_FEE_REDUCTION_BPS, MAX_EXCHANGE_BPS),
         'amount': {'bps_of_settled_cpa': DEFAULT_SPLIT['integrator_bps'], 'owner_bps': DEFAULT_SPLIT['owner_bps'],
                    'fee_reduction_bps_minimum': MIN_FEE_REDUCTION_BPS, 'exchange_bps_maximum': MAX_EXCHANGE_BPS,
                    'without_integrator': 'the integrator share is added to fee reduction, never to the exchange'},
         'settlement': 'CPA after the challenge window; organic ranking never depends on spend',
         'modules': ['covenant_chain/ads/split.py', 'covenant_chain/ad_revenue.py']},
        {'id': 'panel_fees', 'who': 'Arbitrators seated on a native panel case (covenant-panel/1, after panel_arbitration activates).',
         'summary': 'The panel fee both parties signed into the deal (paid by the loser or split), paid to the members '
                    'who voted with the decision; drawn panels come from the staked arbitrator roster.',
         'amount': {'set_by': 'the panel fee both parties signed into the terms: payer loser or split, amount and resource',
                    'paid_to': 'members who voted with the decision, otherwise every seated member'},
         'case_flow': ['named: the parties list the arbitrators', 'drawn: chosen from the ARBITRATOR_JOIN roster, active, '
                       'staked, in the case category, at or above min_reputation, without conflict and not struck',
                       'standing: a registered standing panel'],
         'modes': sorted(MODES), 'remedies': sorted(REMEDIES),
         'risk': 'Joining stakes value; proven misconduct can be slashed.',
         'external_forums': 'An AAP Connect adjudicator (for example an external court or arbitration service) earns this fee only '
                            'when seated on the native panel; on off-chain ladders its fee is agreed per deal.',
         'modules': ['covenant_chain/arbitration.py']},
        {'id': 'builder_programme', 'who': 'Builders of applications and tools selected in a sponsor-signed programme.',
         'summary': 'Explicit tariffs, shares of a disclosed coordination fee and one-time awards in a programme a '
                    'sponsor signed; no automatic dependency royalty.',
         'amount': {'set_by': 'explicit application tariffs, beneficiary shares of a disclosed coordination fee, and one-time '
                              'BOUNTY or MAINTENANCE awards', 'dependency_royalty': 'NONE_UNLESS_EXPLICITLY_SELECTED'},
         'settlement': 'ECON_CLEAR with every affected account\'s approval; a quote is a proposal, not funding',
         'modules': ['covenant_chain/builder_programme_runtime.py', 'covenant_language/builder_programme.py']},
        {'id': 'rail_fees', 'who': 'A payment rail, through its own posted fee schedule (covenant-network-fee/0.1).',
         'summary': 'The rail\'s own posted fee, fixed plus basis points between a minimum and a maximum; AAP adds no '
                    'surcharge.',
         'amount': {'set_by': 'the rail: fixed plus basis points between a minimum and a maximum, paid to the rail\'s beneficiary',
                    'aap_surcharge': 'NONE; the protocol fee is separate and quoted separately'},
         'modules': ['covenant_chain/payment_rails.py']},
    ]


def terms(kind=None):
    """The integrator terms, or the slice that applies to one adapter kind."""
    connect.check(kind is None or kind in connect.KIND_SPECS, 'CONNECT_KIND')
    streams = _streams()
    if kind is not None:
        streams = [row for row in streams if row['id'] in BY_KIND[kind]]
    from .licence_royalty import rate_card
    card = rate_card()['models']['percent_of_fees']
    return {
        'version': TERMS, 'kind': kind, 'basis': 'EXISTING_CODE_DEFAULTS_ONLY',
        'governing_values': 'The fee policy adopted on the chain in use; these are the defaults the code ships.',
        'streams': streams, 'by_kind': {name: list(BY_KIND[name]) for name in connect.KINDS} if kind is None else
        {kind: list(BY_KIND[kind])},
        'free': ['The MIT core: no royalty and no badge requirement for using, selling or self-hosting it.',
                 'The conformance suite: local, offline and rerunnable by anyone.',
                 'Discovery: publish signed manifests through any carrier; there is no listing fee or registry operator.',
                 'A self-test certificate: signed by the subject itself.'],
        'costs': [{'id': 'optional_commercial_licence', 'when': 'Only a host that wants a negotiated commercial licence '
                   '(for example white label); never required to plug in.',
                   'rate_card_percent_of_fees_bps': {'low': card['low_bps'], 'default': card['default_bps'],
                                                     'high': card['high_bps']},
                   'module': 'covenant_chain/licence_royalty.py'}],
        'structural': [
            'One contract per kind: implement it once and every AAP owner can adopt the same release.',
            'The suite is deterministic, so anyone can rerun it and get the same results hash; a compatibility claim becomes checkable.',
            'A signed manifest travels through every signed-discovery carrier owners already read.',
            'A certificate satisfies gateways that require one (policy /0.6), so certified counterparties can reach those operators.',
            'The integrator share follows the settled deal, not the rail or forum used, and an ineligible share goes to users, '
            'never to a competitor.',
            'Output is evidence, never authority: an adapter is never the party that releases or decides.',
            'No exclusivity: a rail keeps its own fee schedule and an arbitrator keeps the panel fee the parties agreed.'],
        'owner_decisions': [
            {'id': 'per_kind_share', 'gap': 'No fee-split row pays an adapter kind as such; adapters earn as named integrators or '
                                            'referrers, or by their own agreed fees.',
             'needs': 'A new fee policy version and steward review (scale_fees.py is frozen consensus).'},
            {'id': 'adapter_attribution', 'gap': 'Adopting an adapter does not name its publisher as integrator; each agreement must '
                                                 'name one (ECON_INTEGRATOR_NOTE or fee.integrator).',
             'needs': 'An owner decision on default attribution for adopted adapters.'},
            {'id': 'off_chain_forum_fee', 'gap': 'Off-chain fair-fix ladders (urn:aap:agreement-procedure:0.1) carry stage bonds but '
                                                 'no adjudicator fee.', 'needs': 'An owner decision on a forum fee profile.'},
            {'id': 'certification_pricing', 'gap': 'Assessment fees, the issuer (placeholder supplier unconfirmed), the status '
                                                   'service and any official badge licence are not operative.',
             'needs': 'Owner, issuer and legal decisions; see docs/COMPATIBILITY_PROGRAMME.html.'},
            {'id': 'adapter_rebates', 'gap': 'No rebate is specific to adapter operators beyond the generic payer fee rebate.',
             'needs': 'An owner economics decision.'}],
        'ranking': 'Certification and payments buy no ranking; a counterparty may require a certificate, nobody can buy placement.',
        'binding': False, 'offer': False, 'execution_authorized': False}
