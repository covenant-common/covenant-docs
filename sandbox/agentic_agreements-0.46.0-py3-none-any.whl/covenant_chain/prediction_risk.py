"""Opt-in recipient admission and exact fallback exposure for prediction markets.

This does not repair native 0.14's appeal-availability incentive. It makes that
property machine-visible and refuses it by default. Historical rules stay fixed.
"""
from copy import deepcopy
from dataclasses import dataclass
from . import app, prediction
from .crypto import integer, key, need
from .proofs import verify_history


@dataclass(frozen=True)
class PredictionAcceptancePolicy:
    resource: str
    accepted_source_policies: tuple
    allow_public_metadata: bool = False
    accept_unanswered_appeal_void: bool = False
    minimum_panel_threshold: int = 2
    max_history_blocks: int = 10000

    def __post_init__(self):
        need(type(self.resource) is str and 0 < len(self.resource) <= 128, 'PREDICTION_RISK_POLICY')
        need(type(self.accepted_source_policies) is tuple and len(self.accepted_source_policies) <= 64,
             'PREDICTION_RISK_POLICY')
        for ref in self.accepted_source_policies:
            key(ref)
        need(type(self.allow_public_metadata) is bool and type(self.accept_unanswered_appeal_void) is bool,
             'PREDICTION_RISK_POLICY')
        need(type(self.minimum_panel_threshold) is int and 1 <= self.minimum_panel_threshold <= 8,
             'PREDICTION_RISK_POLICY')
        need(type(self.max_history_blocks) is int and 1 <= self.max_history_blocks <= 1000000,
             'PREDICTION_RISK_POLICY')


def fallback_exposure(terms, shares, primary_result):
    """Exact portfolio difference between primary payout and unanswered-appeal VOID.

    A positive difference exposes an incentive conditional on appeal failure.
    It is not a forecast of failure, net profit, or a judgment of factual truth.
    """
    prediction.validate_terms(terms, 0)
    need(type(shares) is dict and set(shares) == set(terms['outcomes']), 'PREDICTION_RISK_SHARES')
    for qty in shares.values():
        integer(qty)
    primary = prediction.payouts(terms, primary_result)
    void = prediction.payouts(terms, {'status':'VOID','value':None})
    initial_value = sum(shares[o]*primary[o] for o in shares)
    fallback_value = sum(shares[o]*void[o] for o in shares)
    return dict(resource=terms['resource'], primary_value=initial_value,
                unanswered_appeal_value=fallback_value, difference=fallback_value-initial_value,
                benefits_if_appeal_unanswered=fallback_value > initial_value,
                fees_and_other_positions_included=False, appeal_failure_probability='NOT_ESTABLISHED')


def assess_prediction_market(genesis, history, expected_chain, minimum_height, market, policy,
                             documents, *, holder=None):
    need(type(policy) is PredictionAcceptancePolicy, 'PREDICTION_RISK_POLICY')
    need(genesis['protocol'] in {app.PREDICTION_VERSION, app.UPGRADE_VERSION,app.MIGRATION_VERSION}, 'PREDICTION_PROFILE')
    need(type(history) is list and len(history) <= policy.max_history_blocks, 'PREDICTION_HISTORY_LIMIT')
    key(market)
    if holder is not None:
        key(holder)
    verified = verify_history(genesis, history, expected_chain, minimum_height)
    state = verified['state']
    need(market in state['prediction_markets'], 'PREDICTION_MISSING')
    m = state['prediction_markets'][market]
    t = m['terms']
    materials = prediction.verify_materials(t, documents)
    checks = []
    def check(code, ok, next_action):
        checks.append(dict(code=code, passed=bool(ok), next_action=None if ok else next_action))
    check('RESOURCE_NOT_ADOPTED', t['resource'] == policy.resource, 'Select a market in the adopted settlement unit.')
    check('SOURCE_POLICY_NOT_ADOPTED', t['source_policy'] in policy.accepted_source_policies,
          'Read and independently adopt the exact source, revision and ambiguity policy.')
    check('PUBLIC_METADATA', policy.allow_public_metadata, 'Explicitly permit public positions and relationships or decline.')
    check('UNANSWERED_APPEAL_VOID', policy.accept_unanswered_appeal_void,
          'Decline this profile or explicitly accept that an unavailable appeal panel changes payout to equal-share VOID.')
    check('PANEL_THRESHOLD', min(t[p]['threshold'] for p in ('primary','appeal')) >= policy.minimum_panel_threshold,
          'Select an adopted panel threshold; distinct keys do not prove independent operators.')
    check('TRADING_CLOSED', m['status'] == 'OPEN' and verified['height'] < t['close_height'],
          'Do not start a new trade after close or after resolution has begun.')
    exposure = None
    if holder is not None and m['primary'] is not None:
        rows = [p for p in state['prediction_positions'].values() if p['market'] == market and p['owner'] == holder]
        shares = {o: sum(p['shares'][o] for p in rows) for o in t['outcomes']}
        exposure = fallback_exposure(t, shares, m['primary']['result'])
    missing = [x['code'] for x in checks if not x['passed']]
    return dict(version='covenant-prediction-risk/0.1', market=market, chain=expected_chain,
                height=verified['height'], state_root=verified['state_root'],
                eligible_to_consider=not missing, missing=missing, checks=checks,
                materials=materials, fallback_exposure=exposure,
                assurance=dict(mechanism='UNANSWERED_APPEAL_VOID_RISK_REMAINS',
                               source_independence='NOT_ESTABLISHED', world_truth='NOT_ESTABLISHED',
                               privacy='PUBLIC', automatically_traded=False,
                               freshness='RECIPIENT_HEIGHT_FLOOR_ONLY'))
