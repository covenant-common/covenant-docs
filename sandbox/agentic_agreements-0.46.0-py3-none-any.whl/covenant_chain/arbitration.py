"""Panel resolver for covenant-native/0.15.

A covenant may name a panel instead of one referee. The panel is signed into
the terms by both parties at BIND, and only after `panel_arbitration` is
active. The pin on that covenant is what later votes consult. Review panels
and prediction panels are separate procedures and are not used here.

A met threshold settles the escrow in the same transaction. A missed panel
deadline is the silent-referee refund: RELEASE returns the escrow, and the
same path is refused for an INDETERMINATE ruling. This module does not open
a second court.
"""
from copy import deepcopy

from .crypto import digest, exact, integer, key, need, verify

PROFILE = 'covenant-panel/1'
BALLOT_LABEL = 'COVENANT-PANEL-BALLOT-1'
SEAT_LABEL = 'COVENANT-PANEL-SEAT-1'
MODES = {'named', 'tahkim', 'zabla', 'drawn', 'standing'}
REMEDIES = {'release', 'refund', 'split', 'penalty', 'redeliver'}
FORMATS = {'hash', 'attestation', 'show'}
NAME = __import__('re').compile(r'[a-z0-9-]{1,32}\Z')
PANEL_FIELDS = 'v mode threshold scope evidence stages fees confidentiality on_miss appeal selection'
SELECTION_FIELDS = 'arbitrators third third_blocks category min_reputation strikes strikes_each body seats'
OPS = {
    'ARBITRATOR_JOIN', 'ARBITRATOR_EXIT', 'ARBITRATOR_WITHDRAW', 'PANEL_STAND',
    'PANEL_OPEN', 'PANEL_SEAT', 'PANEL_DRAW', 'PANEL_STRIKE', 'PANEL_EVIDENCE',
    'PANEL_VOTE', 'PANEL_APPEAL', 'PANEL_CLOSE', 'PANEL_SLASH',
}


def stake_policy(state):
    """Market staking bounds when that module is installed, otherwise a local floor."""
    market = None
    config = state.get('market_config')
    if isinstance(config, dict) or config is not None:
        try:
            market = config['active']['body']['staking']
        except (KeyError, TypeError):
            market = None
    if isinstance(market, dict) and market.get('resource') in state.get('resources', {}):
        return {'resource': market['resource'], 'slash_bps': market['slash_bps'],
                'min_term': market['min_term'], 'exit_delay': market['exit_delay'],
                'min_stake': 1, 'source': 'market.staking'}
    resource = next(iter(state['resources']))
    return {'resource': resource, 'slash_bps': 1000, 'min_term': 1, 'exit_delay': 1,
            'min_stake': 1, 'source': 'local'}


def panel_id(panel):
    return digest('COVENANT-PANEL-1', panel)


def appeal_id(panel):
    return digest('COVENANT-PANEL-APPEAL-1', panel)


def _keys(rows, limit, empty_ok=False):
    need(type(rows) is list and rows == sorted(set(rows)) and len(rows) <= limit, 'PANEL_KEYS')
    if not empty_ok:
        need(len(rows) >= 1, 'PANEL_KEYS')
    for item in rows:
        key(item)


def _blocks(value):
    integer(value, True)
    need(value <= 10000, 'PANEL_DURATION')


def _name_in(value, options):
    """Membership for caller values: a list or dict is refused with a code, not a TypeError."""
    return type(value) is str and value in options


def validate_panel(panel):
    """Shape only. Registry and conflict checks need the chain."""
    exact(panel, PANEL_FIELDS)
    need(panel['v'] == PROFILE, 'PANEL_VERSION')
    need(_name_in(panel['mode'], MODES), 'PANEL_MODE')
    integer(panel['threshold'], True)
    scope = panel['scope']
    exact(scope, 'remedies penalty_cap')
    remedies = scope['remedies']
    need(type(remedies) is list and remedies and all(_name_in(r, REMEDIES) for r in remedies)
         and remedies == sorted(set(remedies)), 'PANEL_SCOPE')
    integer(scope['penalty_cap'])
    evidence = panel['evidence']
    exact(evidence, 'formats')
    formats = evidence['formats']
    need(type(formats) is list and formats and all(_name_in(f, FORMATS) for f in formats)
         and formats == sorted(set(formats)), 'PANEL_EVIDENCE')
    stages = panel['stages']
    exact(stages, 'evidence_blocks deliberation_blocks vote_blocks')
    for name in ('evidence_blocks', 'deliberation_blocks', 'vote_blocks'):
        _blocks(stages[name])
    fees = panel['fees']
    exact(fees, 'payer amount resource')
    need(_name_in(fees['payer'], {'loser', 'split'}), 'PANEL_FEE')
    integer(fees['amount'])
    need(type(fees['resource']) is str and fees['resource'], 'PANEL_FEE')
    if fees['payer'] == 'split':
        need(fees['amount'] % 2 == 0, 'PANEL_FEE')
    need(_name_in(panel['confidentiality'], {'panel', 'public'}), 'PANEL_CONFIDENTIALITY')
    need(panel['on_miss'] == 'silent_refund', 'PANEL_MISS')
    selection = panel['selection']
    exact(selection, SELECTION_FIELDS)
    mode = panel['mode']
    _keys(selection['arbitrators'], 16, empty_ok=mode in {'drawn', 'standing'})
    _keys(selection['strikes'], 32, empty_ok=True)
    integer(selection['strikes_each'])
    need(selection['strikes_each'] <= 8, 'PANEL_STRIKES')
    integer(selection['min_reputation'])
    need(-1000 <= selection['min_reputation'] <= 1000, 'PANEL_REPUTATION')
    integer(selection['third_blocks'])
    integer(selection['seats'], True)
    need(selection['seats'] <= 16, 'PANEL_SEATS')
    if mode in {'named', 'tahkim'}:
        need(selection['seats'] == len(selection['arbitrators']), 'PANEL_SEATS')
        need(selection['third'] is None and selection['third_blocks'] == 0, 'PANEL_SELECTION')
        need(selection['category'] is None and selection['body'] is None, 'PANEL_SELECTION')
        need(selection['strikes'] == [] and selection['strikes_each'] == 0 and selection['min_reputation'] == 0, 'PANEL_SELECTION')
    elif mode == 'zabla':
        need(len(selection['arbitrators']) == 2 and selection['seats'] == 3, 'PANEL_SELECTION')
        key(selection['third'])
        need(selection['third'] not in selection['arbitrators'] and selection['third_blocks'] >= 1, 'PANEL_SELECTION')
        need(selection['category'] is None and selection['body'] is None, 'PANEL_SELECTION')
        need(selection['strikes'] == [] and selection['strikes_each'] == 0, 'PANEL_SELECTION')
    elif mode == 'drawn':
        need(selection['arbitrators'] == [] and selection['third'] is None and selection['third_blocks'] == 0, 'PANEL_SELECTION')
        need(selection['body'] is None and type(selection['category']) is str and bool(NAME.fullmatch(selection['category'])), 'PANEL_CATEGORY')
    else:
        key(selection['body'])
        need(selection['arbitrators'] == [] and selection['third'] is None and selection['third_blocks'] == 0, 'PANEL_SELECTION')
        need(selection['category'] is None and selection['strikes'] == [] and selection['strikes_each'] == 0, 'PANEL_SELECTION')
    need(1 <= panel['threshold'] <= selection['seats'], 'PANEL_THRESHOLD')
    appeal = panel['appeal']
    if appeal is not None:
        exact(appeal, 'arbitrators threshold bond blocks')
        _keys(appeal['arbitrators'], 16)
        integer(appeal['threshold'], True)
        integer(appeal['bond'])
        _blocks(appeal['blocks'])
        need(1 <= appeal['threshold'] <= len(appeal['arbitrators']), 'PANEL_THRESHOLD')
        need(len(appeal['arbitrators']) > selection['seats'], 'PANEL_APPEAL_SIZE')
        need(not set(appeal['arbitrators']) & set(selection['arbitrators']), 'PANEL_APPEAL_OVERLAP')
        if selection['third'] is not None:
            need(selection['third'] not in appeal['arbitrators'], 'PANEL_APPEAL_OVERLAP')
    return panel


def _active_feature(state):
    from .governance import feature_active
    need(feature_active(state, 'panel_arbitration'), 'FEATURE_INACTIVE')


def _row(state, member):
    need(member in state['arbitrators'], 'ARBITRATOR_UNKNOWN')
    row = state['arbitrators'][member]
    need(row['active'] and row['stake'] > 0 and row['exit'] is None, 'ARBITRATOR_INACTIVE')
    return row


def _parties(terms):
    return {terms['principal'], terms['agent'], terms['counterparty']}


def _conflict(state, member, terms):
    if member in _parties(terms):
        return True
    row = state['arbitrators'].get(member) if 'arbitrators' in state else None
    if row is not None and set(row['affiliations']) & _parties(terms):
        return True
    return False


def _require_member(state, member, terms):
    _row(state, member)
    need(not _conflict(state, member, terms), 'PANEL_CONFLICT')


def validate_terms_panel(state, terms, height):
    _active_feature(state)
    panel = validate_panel(terms['panel'])
    need(terms['resolver'] == panel_id(panel), 'PANEL_RESOLVER')
    need(terms['appeal_resolver'] == appeal_id(panel), 'PANEL_RESOLVER')
    need(panel['fees']['resource'] in state['resources'], 'PANEL_FEE')
    need(panel['scope']['penalty_cap'] <= terms['quantity'], 'PANEL_SCOPE')
    span = sum(panel['stages'].values()) + panel['selection']['third_blocks']
    if panel['appeal'] is not None:
        span += panel['appeal']['blocks']
    need(terms['deadline'] > height + span, 'PANEL_DEADLINE')
    selection = panel['selection']
    for member in selection['arbitrators']:
        _require_member(state, member, terms)
    if selection['third'] is not None:
        _require_member(state, selection['third'], terms)
    if panel['appeal'] is not None:
        for member in panel['appeal']['arbitrators']:
            _require_member(state, member, terms)
    if panel['mode'] == 'standing':
        body = state['standing_panels'].get(selection['body'])
        need(body is not None and len(body['members']) == selection['seats'], 'STANDING_PANEL')
        for member in body['members']:
            _require_member(state, member, terms)
    return panel


def _lock(state, who, resource, quantity, pool):
    from .app import add, amount
    if quantity == 0:
        return
    need(amount(state['authority_available'], who, resource) >= quantity, 'ARBITRATION_FUNDS')
    add(state['balances'], who, resource, -quantity)
    add(state['authority_available'], who, resource, -quantity)
    state[pool][resource] = state[pool][resource] + quantity


def _unlock(state, who, resource, quantity, pool):
    from .app import add
    if quantity == 0:
        return
    need(state[pool][resource] >= quantity, 'ARBITRATION_HELD')
    state[pool][resource] = state[pool][resource] - quantity
    add(state['balances'], who, resource, quantity)
    add(state['authority_available'], who, resource, quantity)


def accept_bind(state, agreement, height):
    terms = agreement['terms']
    panel = validate_terms_panel(state, terms, height)
    fees = panel['fees']
    deposit = fees['amount'] if fees['payer'] == 'loser' else fees['amount'] // 2
    locked = {}
    for party in (terms['agent'], terms['counterparty']):
        _lock(state, party, fees['resource'], deposit, 'arbitration_held')
        locked[party] = deposit
    roster = []
    if panel['mode'] == 'standing':
        roster = list(state['standing_panels'][panel['selection']['body']]['members'])
    agreement['panel_case'] = {
        'status': 'READY', 'seated': [], 'roster': roster, 'third': None,
        'votes': {}, 'voids': [], 'decision': None, 'appeal': None, 'settlement': None,
        'fee': {'resource': fees['resource'], 'locked': locked, 'payer': fees['payer'], 'settled': False},
        'opened': None, 'evidence_until': None, 'deliberation_until': None, 'vote_until': None,
        'constitute_until': None, 'strikes': {}, 'struck': [], 'redeliveries': 0, 'miss_settled': False,
    }


def _case(agreement):
    need('panel' in agreement['terms'], 'PANEL_PROCEDURE')
    from .governance import obligation_active
    need(obligation_active(agreement, 'panel_arbitration'), 'PANEL_PIN')
    case = agreement.get('panel_case')
    need(isinstance(case, dict), 'PANEL_CASE')
    return case


def _seat(state, agreement, members):
    case = agreement['panel_case']
    ident = None
    for member in members:
        row = _row(state, member)
        need(not _conflict(state, member, agreement['terms']), 'PANEL_CONFLICT')
        if ident is None:
            ident = digest('COVENANT-AGREEMENT-0.1', agreement['terms'])
        if ident not in row['cases']:
            need(len(row['cases']) < 32, 'ARBITRATOR_CASE_LIMIT')
            row['cases'].append(ident)
            row['cases'] = sorted(row['cases'])
    case['seated'] = sorted(set(members))


def _release_seat(state, agreement):
    ident = digest('COVENANT-AGREEMENT-0.1', agreement['terms'])
    for member in agreement['panel_case'].get('seated') or []:
        row = state['arbitrators'].get(member)
        if row is not None and ident in row['cases']:
            row['cases'] = [item for item in row['cases'] if item != ident]


def _slash(state, agreement, member, reason, event):
    row = state['arbitrators'].get(member)
    if row is None or row['stake'] <= 0 or row.get('slashed_events', []).count(event):
        return 0
    loss = (row['stake'] * row['slash_bps'] + 9999) // 10000
    if loss <= 0:
        return 0
    if loss > row['stake']:
        loss = row['stake']
    resource = row['resource']
    need(state['arbitrator_stake'][resource] >= loss, 'ARBITRATOR_STAKE')
    state['arbitrator_stake'][resource] = state['arbitrator_stake'][resource] - loss
    row['stake'] -= loss
    row['slashed'] += 1
    row.setdefault('slashed_events', []).append(event)
    if row['stake'] == 0:
        row['active'] = False
    terms = agreement['terms']
    left = loss // 2
    from .app import add
    add(state['balances'], terms['principal'], resource, left)
    add(state['authority_available'], terms['principal'], resource, left)
    rest = loss - left
    add(state['balances'], terms['counterparty'], resource, rest)
    add(state['authority_available'], terms['counterparty'], resource, rest)
    row.setdefault('slash_log', []).append({'reason': reason, 'loss': loss, 'event': event})
    return loss


def _pay_panel(state, resource, quantity, members):
    if quantity == 0 or not members:
        return
    share = quantity // len(members)
    rest = quantity - share * len(members)
    ordered = sorted(members)
    for index, member in enumerate(ordered):
        _unlock(state, member, resource, share + (1 if index < rest else 0), 'arbitration_held')


def _refund_fees(state, agreement):
    case = agreement['panel_case']
    fee = case['fee']
    if fee['settled']:
        return
    for party, quantity in list(fee['locked'].items()):
        _unlock(state, party, fee['resource'], quantity, 'arbitration_held')
        fee['locked'][party] = 0
    fee['settled'] = True


def _shares(quantity, remedy, payee_bps, penalty, cap):
    if remedy == 'release':
        need(payee_bps == 10000 and penalty == 0, 'PANEL_BALLOT')
        return 0, quantity, 0
    if remedy == 'refund':
        need(payee_bps == 0 and penalty == 0, 'PANEL_BALLOT')
        return quantity, 0, 0
    if remedy == 'split':
        need(0 < payee_bps < 10000 and penalty == 0, 'PANEL_BALLOT')
        payee = quantity * payee_bps // 10000
        return quantity - payee, payee, 0
    if remedy == 'penalty':
        need(0 < penalty <= cap and penalty <= quantity and payee_bps == 0, 'PANEL_BALLOT')
        return penalty, quantity - penalty, 0
    need(remedy == 'redeliver' and payee_bps == 0 and penalty == 0, 'PANEL_BALLOT')
    return None


def _move_escrow(state, agreement, principal_share, payee_share, consumed_share):
    from .app import add
    terms = agreement['terms']
    resource = terms['resource']
    if principal_share:
        add(state['balances'], terms['principal'], resource, principal_share)
        add(state['authority_available'], terms['principal'], resource, principal_share)
    if terms['effect'] == 'TRANSFER':
        if payee_share:
            add(state['balances'], terms['counterparty'], resource, payee_share)
            add(state['authority_available'], terms['counterparty'], resource, payee_share)
    elif payee_share:
        state['consumed'][resource] += payee_share
        consumed_share = payee_share
        payee_share = 0
    agreement['held'] = False
    agreement['settlement'] = {'principal': principal_share, 'counterparty': payee_share, 'consumed': consumed_share}
    agreement['panel_case']['settlement'] = agreement['settlement']


def _reverse(state, agreement):
    from .app import add, amount
    terms = agreement['terms']
    resource = terms['resource']
    settlement = agreement['panel_case']['settlement']
    need(settlement is not None, 'PANEL_SETTLEMENT')
    if settlement['principal']:
        need(amount(state['authority_available'], terms['principal'], resource) >= settlement['principal'], 'APPEAL_FUNDS')
        add(state['balances'], terms['principal'], resource, -settlement['principal'])
        add(state['authority_available'], terms['principal'], resource, -settlement['principal'])
    if settlement['counterparty']:
        need(amount(state['authority_available'], terms['counterparty'], resource) >= settlement['counterparty'], 'APPEAL_FUNDS')
        add(state['balances'], terms['counterparty'], resource, -settlement['counterparty'])
        add(state['authority_available'], terms['counterparty'], resource, -settlement['counterparty'])
    if settlement['consumed']:
        need(state['consumed'][resource] >= settlement['consumed'], 'APPEAL_FUNDS')
        state['consumed'][resource] -= settlement['consumed']
    agreement['held'] = True
    agreement['panel_case']['settlement'] = None
    agreement['settlement'] = None


def _settle_fees(state, agreement, ballot):
    case = agreement['panel_case']
    fee = case['fee']
    if fee['settled']:
        return
    terms = agreement['terms']
    settlement = case['settlement']
    resource = fee['resource']
    if ballot['remedy'] == 'redeliver' or settlement is None:
        return
    voters = [member for member, vote in case['votes'].items()
              if (vote['remedy'], vote['payee_bps'], vote['penalty'], vote['reasons']) ==
              (ballot['remedy'], ballot['payee_bps'], ballot['penalty'], ballot['reasons'])]
    if fee['payer'] == 'split':
        pot = sum(fee['locked'].values())
        fee['locked'] = {party: 0 for party in fee['locked']}
        _pay_panel(state, resource, pot, voters or case['seated'])
    else:
        principal_share = settlement['principal']
        payee_share = settlement['counterparty'] + settlement['consumed']
        if principal_share == payee_share:
            _refund_fees(state, agreement)
            return
        loser = terms['principal'] if principal_share < payee_share else terms['counterparty']
        winner = terms['counterparty'] if loser == terms['principal'] else terms['principal']
        # The fee depositors are the agent and the counterparty. The principal
        # is the loser when the agent is the principal, which is the common case.
        if loser not in fee['locked']:
            loser = terms['agent'] if principal_share < payee_share else terms['counterparty']
            winner = terms['counterparty'] if loser == terms['agent'] else terms['agent']
        pot = fee['locked'].get(loser, 0)
        back = fee['locked'].get(winner, 0)
        fee['locked'] = {party: 0 for party in fee['locked']}
        _unlock(state, winner, resource, back, 'arbitration_held')
        _pay_panel(state, resource, pot, voters or case['seated'])
    fee['settled'] = True


def _apply_ballot(state, agreement, ballot, tid, height):
    case = agreement['panel_case']
    terms = agreement['terms']
    panel = terms['panel']
    need(ballot['remedy'] in panel['scope']['remedies'], 'PANEL_SCOPE')
    shares = _shares(terms['quantity'], ballot['remedy'], ballot['payee_bps'], ballot['penalty'], panel['scope']['penalty_cap'])
    if shares is None:
        need(case['redeliveries'] < 1, 'PANEL_REDELIVER')
        stages = panel['stages']
        case['redeliveries'] += 1
        case['votes'] = {}
        case['voids'] = []
        case['status'] = 'OPEN'
        case['decision'] = None
        case['opened'] = height
        case['evidence_until'] = height + stages['evidence_blocks']
        case['deliberation_until'] = case['evidence_until'] + stages['deliberation_blocks']
        case['vote_until'] = case['deliberation_until'] + stages['vote_blocks']
        agreement['state'] = 'BOUND'
        agreement['decision'] = None
        agreement['held'] = True
        return
    _move_escrow(state, agreement, *shares)
    _settle_fees(state, agreement, ballot)
    _release_seat(state, agreement)
    agreement['state'] = 'RELEASED' if shares[1] == 0 and shares[2] == 0 else 'SETTLED'
    agreement['decision'] = {'result': 'REFUTED' if shares[1] == 0 and shares[2] == 0 else 'SUPPORTED',
                             'evidence': [], 'actor': terms['resolver'], 'event': tid, 'height': height,
                             'remedy': ballot['remedy'], 'reasons': ballot['reasons'],
                             'payee_bps': ballot['payee_bps'], 'penalty': ballot['penalty']}
    case['decision'] = deepcopy(agreement['decision'])
    case['status'] = 'SETTLED'
    agreement['history'].append(tid)


def _ballot_body(state, agreement_id, phase, payload):
    return {'chain': state['chain'], 'agreement': agreement_id, 'phase': phase,
            'remedy': payload['remedy'], 'payee_bps': payload['payee_bps'],
            'penalty': payload['penalty'], 'reasons': payload['reasons']}


def panel_missed(state, agreement, height):
    terms = agreement.get('terms') or {}
    if 'panel' not in terms or not agreement.get('held') or agreement.get('decision') is not None:
        return False
    if agreement.get('state') == 'INDETERMINATE':
        return False
    from .governance import obligation_active
    if not obligation_active(agreement, 'panel_arbitration'):
        return False
    if terms['panel'].get('on_miss') != 'silent_refund' or terms.get('timeout') != 'HOLD_FOR_RESOLUTION':
        return False
    case = agreement.get('panel_case')
    if not isinstance(case, dict) or case.get('appeal') or case.get('status') in {'SETTLED', 'FINAL', 'MISSED'}:
        return False
    if case.get('opened') is None:
        return height > terms['deadline']
    if case.get('status') == 'CONSTITUTING' and case.get('constitute_until') is not None and height > case['constitute_until']:
        if len(case.get('seated') or []) < terms['panel']['selection']['seats']:
            return True
    if terms['panel']['mode'] == 'drawn' and not case.get('seated') and case.get('evidence_until') is not None and height > case['evidence_until']:
        return True
    limit = case.get('vote_until')
    return limit is not None and height > limit and case.get('decision') is None


def settle_miss(state, agreement, tid, height):
    case = agreement['panel_case']
    if case.get('miss_settled'):
        return
    if case.get('status') == 'CONSTITUTING' or (agreement['terms']['panel']['mode'] == 'drawn' and not case.get('seated')):
        targets = list(case.get('seated') or [])
    else:
        voted = set(case.get('votes') or {})
        targets = [member for member in case.get('seated') or [] if member not in voted]
    for member in targets:
        _slash(state, agreement, member, 'deadline', tid)
    _refund_fees(state, agreement)
    _release_seat(state, agreement)
    case['miss_settled'] = True
    case['status'] = 'MISSED'


def _draw_pool(state, agreement, blocked):
    panel = agreement['terms']['panel']
    selection = panel['selection']
    appeal = panel['appeal']['arbitrators'] if panel['appeal'] else []
    rows = []
    for member, row in sorted(state['arbitrators'].items()):
        if member in blocked or member in selection['strikes'] or member in appeal:
            continue
        if not row['active'] or row['stake'] <= 0 or row['exit'] is not None:
            continue
        if selection['category'] not in row['categories']:
            continue
        if row['reputation'] < selection['min_reputation']:
            continue
        if _conflict(state, member, agreement['terms']):
            continue
        rows.append(member)
    return rows


def _draw(eligible, seats, seed):
    pool = list(eligible)
    chosen = []
    counter = 0
    while len(chosen) < seats:
        need(pool, 'DRAW_SHORT')
        material = digest('COVENANT-PANEL-DRAW-1', {'seed': seed, 'n': counter})
        index = int(material[:8], 16) % len(pool)
        chosen.append(pool.pop(index))
        counter += 1
    return sorted(chosen)


def _reputation(state, votes, original, adopted):
    overturned = original != adopted
    for member, vote in votes.items():
        row = state['arbitrators'].get(member)
        if row is None:
            continue
        matched = (vote['remedy'], vote['payee_bps'], vote['penalty']) == original
        if overturned and matched:
            row['reputation'] -= 1
        elif not overturned and matched:
            row['reputation'] += 1
        if row['reputation'] > 1000:
            row['reputation'] = 1000
        if row['reputation'] < -1000:
            row['reputation'] = -1000


def apply(state, previous, op, payload, actor, tid, height):
    if op not in OPS:
        return None
    _active_feature(state)
    from .app import agreement_id, controller
    if op == 'ARBITRATOR_JOIN':
        exact(payload, 'categories affiliations quantity')
        policy = stake_policy(state)
        categories = payload['categories']
        need(type(categories) is list and 1 <= len(categories) <= 8 and categories == sorted(set(categories)), 'ARBITRATOR_CATEGORY')
        for name in categories:
            need(type(name) is str and bool(NAME.fullmatch(name)), 'ARBITRATOR_CATEGORY')
        _keys(payload['affiliations'], 16, empty_ok=True)
        integer(payload['quantity'], True)
        need(payload['quantity'] >= policy['min_stake'], 'ARBITRATOR_STAKE')
        need(actor not in state['arbitrators'], 'ARBITRATOR_EXISTS')
        _lock(state, actor, policy['resource'], payload['quantity'], 'arbitrator_stake')
        state['arbitrators'][actor] = {
            'member': actor, 'categories': list(categories), 'affiliations': list(payload['affiliations']),
            'stake': payload['quantity'], 'resource': policy['resource'], 'reputation': 0, 'cases': [],
            'active': True, 'exit': None, 'opened': height, 'min_until': height + policy['min_term'],
            'exit_delay': policy['exit_delay'], 'slash_bps': policy['slash_bps'], 'slashed': 0,
            'source': policy['source'],
        }
        return []
    if op == 'ARBITRATOR_EXIT':
        exact(payload, '')
        row = _row(state, actor)
        need(height >= row['min_until'] and not row['cases'], 'ARBITRATOR_TERM')
        row['exit'] = height + row['exit_delay']
        row['active'] = False
        return []
    if op == 'ARBITRATOR_WITHDRAW':
        exact(payload, '')
        need(actor in state['arbitrators'], 'ARBITRATOR_UNKNOWN')
        row = state['arbitrators'][actor]
        need(row['exit'] is not None and height > row['exit'] and row['stake'] > 0, 'ARBITRATOR_EXIT_DELAY')
        _unlock(state, actor, row['resource'], row['stake'], 'arbitrator_stake')
        row['stake'] = 0
        return []
    if op == 'PANEL_STAND':
        exact(payload, 'members threshold category')
        _keys(payload['members'], 16)
        integer(payload['threshold'], True)
        need(1 <= payload['threshold'] <= len(payload['members']), 'PANEL_THRESHOLD')
        need(type(payload['category']) is str and bool(NAME.fullmatch(payload['category'])), 'PANEL_CATEGORY')
        for member in payload['members']:
            _row(state, member)
        ident = digest('COVENANT-STANDING-PANEL-1', {'chain': state['chain'], 'members': payload['members'],
                                                     'threshold': payload['threshold'], 'category': payload['category']})
        need(ident not in state['standing_panels'], 'STANDING_PANEL')
        state['standing_panels'][ident] = {'members': list(payload['members']), 'threshold': payload['threshold'],
                                            'category': payload['category'], 'registrar': actor, 'height': height}
        return [ident]
    key(payload.get('agreement'))
    need(payload['agreement'] in state['agreements'], 'AGREEMENT')
    agreement = state['agreements'][payload['agreement']]
    case = _case(agreement)
    terms = agreement['terms']
    panel = terms['panel']
    if op == 'PANEL_OPEN':
        exact(payload, 'agreement')
        need(actor in {terms['agent'], terms['counterparty']}, 'PANEL_PARTY')
        need(case['status'] == 'READY' and agreement['state'] == 'BOUND' and agreement['held'], 'PANEL_STATE')
        stages = panel['stages']
        case['opened'] = height
        case['evidence_until'] = height + stages['evidence_blocks']
        case['deliberation_until'] = case['evidence_until'] + stages['deliberation_blocks']
        case['vote_until'] = case['deliberation_until'] + stages['vote_blocks']
        if panel['mode'] in {'named', 'tahkim'}:
            _seat(state, agreement, panel['selection']['arbitrators'])
            case['status'] = 'OPEN'
        elif panel['mode'] == 'standing':
            _seat(state, agreement, case['roster'])
            case['status'] = 'OPEN'
        elif panel['mode'] == 'zabla':
            _seat(state, agreement, panel['selection']['arbitrators'])
            case['status'] = 'CONSTITUTING'
            case['constitute_until'] = height + panel['selection']['third_blocks']
        else:
            case['status'] = 'OPEN'
        agreement['history'].append(tid)
        return [agreement['formation']]
    if op == 'PANEL_SEAT':
        exact(payload, 'agreement third ballot')
        need(panel['mode'] == 'zabla' and case['status'] == 'CONSTITUTING', 'PANEL_STATE')
        key(payload['third'])
        body = {'chain': state['chain'], 'agreement': payload['agreement'], 'third': payload['third'], 'action': 'SEAT'}
        picks = panel['selection']['arbitrators']
        if height <= case['constitute_until']:
            need(actor in picks, 'PANEL_SEAT')
            other = picks[0] if picks[1] == actor else picks[1]
            verify(controller(state, other), SEAT_LABEL, body, payload['ballot'])
        else:
            need(actor in {terms['agent'], terms['counterparty']}, 'PANEL_PARTY')
            need(payload['third'] == panel['selection']['third'], 'PANEL_FALLBACK')
            verify(controller(state, actor), SEAT_LABEL, body, payload['ballot'])
        _require_member(state, payload['third'], terms)
        need(payload['third'] not in case['seated'], 'PANEL_SEAT')
        _seat(state, agreement, list(case['seated']) + [payload['third']])
        case['third'] = payload['third']
        case['status'] = 'OPEN'
        return [agreement['formation']]
    if op == 'PANEL_DRAW':
        exact(payload, 'agreement')
        need(panel['mode'] == 'drawn' and case['status'] == 'OPEN' and not case['seated'], 'PANEL_STATE')
        need(case['opened'] is not None and height <= case['evidence_until'], 'PANEL_WINDOW')
        seed = digest('COVENANT-PANEL-DRAW-1', {'chain': state['chain'], 'agreement': payload['agreement'],
                                                'formation': agreement['formation'], 'height': height, 'strike': 0})
        chosen = _draw(_draw_pool(state, agreement, set()), panel['selection']['seats'], seed)
        _seat(state, agreement, chosen)
        return [agreement['formation']]
    if op == 'PANEL_STRIKE':
        exact(payload, 'agreement strikes')
        need(panel['mode'] == 'drawn' and case['seated'] and not case['votes'], 'PANEL_STATE')
        need(actor in {terms['agent'], terms['counterparty']} and actor not in case['strikes'], 'PANEL_STRIKE')
        need(height <= case['deliberation_until'], 'PANEL_WINDOW')
        strikes = payload['strikes']
        _keys(strikes, panel['selection']['strikes_each'])
        need(len(strikes) <= panel['selection']['strikes_each'], 'PANEL_STRIKES')
        need(set(strikes) <= set(case['seated']), 'PANEL_STRIKE')
        blocked = set(case['struck']) | set(strikes) | set(case['seated'])
        seed = digest('COVENANT-PANEL-DRAW-1', {'chain': state['chain'], 'agreement': payload['agreement'],
                                                'formation': agreement['formation'], 'height': height,
                                                'strike': len(case['strikes']) + 1})
        replacements = _draw(_draw_pool(state, agreement, blocked), len(strikes), seed)
        _release_seat(state, agreement)
        case['struck'] = sorted(set(case['struck']) | set(strikes))
        case['strikes'][actor] = list(strikes)
        remaining = [member for member in case['seated'] if member not in strikes]
        _seat(state, agreement, remaining + replacements)
        return [agreement['formation']]
    if op == 'PANEL_EVIDENCE':
        exact(payload, 'agreement format content_hash description attestation')
        need(actor in {terms['agent'], terms['counterparty']} and agreement['held'], 'PANEL_PARTY')
        need(case['opened'] is not None and height <= case['evidence_until'], 'PANEL_WINDOW')
        need(payload['format'] in panel['evidence']['formats'], 'PANEL_EVIDENCE')
        key(payload['content_hash'])
        need(type(payload['description']) is str and len(payload['description']) <= 2000, 'PANEL_EVIDENCE')
        if panel['confidentiality'] == 'panel':
            need(payload['description'] == 'SEALED', 'PANEL_CONFIDENTIALITY')
        if payload['format'] == 'attestation':
            attestation = payload['attestation']
            exact(attestation, 'signer signature')
            need(_name_in(attestation['signer'], {terms['agent'], terms['counterparty']}), 'PANEL_ATTESTATION')
            verify(controller(state, attestation['signer']), 'COVENANT-PANEL-EVIDENCE-1',
                   {'chain': state['chain'], 'agreement': payload['agreement'], 'content_hash': payload['content_hash']},
                   attestation['signature'])
        else:
            need(payload['attestation'] is None, 'PANEL_EVIDENCE')
        state['evidence'][tid] = {'agreement': payload['agreement'], 'content_hash': payload['content_hash'],
                                  'description': payload['description'], 'actor': actor, 'height': height,
                                  'format': payload['format']}
        agreement['evidence'].append(tid)
        agreement['history'].append(tid)
        return [agreement['formation']]
    if op == 'PANEL_VOTE':
        exact(payload, 'agreement phase remedy payee_bps penalty reasons ballot')
        need(_name_in(payload['phase'], {'PRIMARY', 'APPEAL'}), 'PANEL_PHASE')
        need(_name_in(payload['remedy'], REMEDIES), 'PANEL_SCOPE')
        integer(payload['payee_bps'])
        integer(payload['penalty'])
        need(0 <= payload['payee_bps'] <= 10000, 'PANEL_BALLOT')
        key(payload['reasons'])
        body = _ballot_body(state, payload['agreement'], payload['phase'], payload)
        verify(controller(state, actor), BALLOT_LABEL, body, payload['ballot'])
        if payload['phase'] == 'PRIMARY':
            need(case['status'] in {'OPEN', 'CONSTITUTING'} and agreement['held'] and case['decision'] is None, 'PANEL_STATE')
            need(len(case['seated']) == panel['selection']['seats'], 'PANEL_UNSEATED')
            need(case['deliberation_until'] < height <= case['vote_until'], 'PANEL_WINDOW')
            need(actor in case['seated'] and actor not in case['votes'] and actor not in case['voids'], 'PANEL_VOTE')
            in_scope = payload['remedy'] in panel['scope']['remedies']
            try:
                if in_scope:
                    _shares(terms['quantity'], payload['remedy'], payload['payee_bps'], payload['penalty'], panel['scope']['penalty_cap'])
            except ValueError:
                in_scope = False
            if not in_scope:
                _slash(state, agreement, actor, 'scope', tid)
                case['voids'].append(actor)
                return [agreement['formation']]
            case['votes'][actor] = {'remedy': payload['remedy'], 'payee_bps': payload['payee_bps'],
                                    'penalty': payload['penalty'], 'reasons': payload['reasons'], 'event': tid}
            matching = [vote for vote in case['votes'].values()
                        if (vote['remedy'], vote['payee_bps'], vote['penalty'], vote['reasons']) ==
                        (payload['remedy'], payload['payee_bps'], payload['penalty'], payload['reasons'])]
            if len(matching) >= panel['threshold'] and payload['remedy'] != 'redeliver':
                _apply_ballot(state, agreement, payload, tid, height)
            elif len(matching) >= panel['threshold']:
                _apply_ballot(state, agreement, payload, tid, height)
            return [agreement['formation']]
        appeal = case.get('appeal')
        need(appeal is not None and case['status'] == 'APPEAL', 'PANEL_APPEAL')
        need(appeal['opened'] < height <= appeal['until'], 'PANEL_WINDOW')
        need(actor in appeal['seated'] and actor not in appeal['votes'] and actor not in appeal.get('voids', []), 'PANEL_VOTE')
        in_scope = payload['remedy'] in panel['scope']['remedies']
        try:
            if in_scope:
                _shares(terms['quantity'], payload['remedy'], payload['payee_bps'], payload['penalty'], panel['scope']['penalty_cap'])
        except ValueError:
            in_scope = False
        if not in_scope:
            _slash(state, agreement, actor, 'scope', tid)
            appeal.setdefault('voids', []).append(actor)
            return [agreement['formation']]
        appeal['votes'][actor] = {'remedy': payload['remedy'], 'payee_bps': payload['payee_bps'],
                                  'penalty': payload['penalty'], 'reasons': payload['reasons'], 'event': tid}
        matching = [vote for vote in appeal['votes'].values()
                    if (vote['remedy'], vote['payee_bps'], vote['penalty'], vote['reasons']) ==
                    (payload['remedy'], payload['payee_bps'], payload['penalty'], payload['reasons'])]
        if len(matching) >= panel['appeal']['threshold']:
            original = (case['decision']['remedy'], case['decision']['payee_bps'], case['decision']['penalty'])
            adopted = (payload['remedy'], payload['payee_bps'], payload['penalty'])
            primary = dict(case['votes'])
            _reputation(state, primary, original, adopted)
            _reverse(state, agreement)
            case['votes'] = appeal['votes']
            _apply_ballot(state, agreement, payload, tid, height)
            overturned = adopted != original
            _bond(state, agreement, actor_back=appeal['appellant'] if overturned else None,
                  winners=None if overturned else list(primary))
            if case['status'] != 'OPEN':
                case['status'] = 'FINAL'
        return [agreement['formation']]
    if op == 'PANEL_APPEAL':
        exact(payload, 'agreement')
        need(actor in {terms['agent'], terms['counterparty']}, 'PANEL_PARTY')
        open_appeal(state, agreement, actor, tid, height)
        return [agreement['formation']]
    if op == 'PANEL_CLOSE':
        exact(payload, 'agreement')
        appeal = case.get('appeal')
        need(case['status'] == 'APPEAL' and appeal is not None and height > appeal['until'], 'PANEL_APPEAL')
        _bond(state, agreement, actor_back=None, winners=list(case['votes']))
        case['status'] = 'FINAL'
        return [agreement['formation']]
    if op == 'PANEL_SLASH':
        exact(payload, 'agreement member ballots')
        key(payload['member'])
        ballots = payload['ballots']
        need(type(ballots) is list and len(ballots) == 2, 'PANEL_SLASH')
        bodies = []
        for item in ballots:
            exact(item, 'body signature')
            body = item['body']
            exact(body, 'chain agreement phase remedy payee_bps penalty reasons')
            need(body['chain'] == state['chain'] and body['agreement'] == payload['agreement'], 'PANEL_SLASH')
            need(_name_in(body['phase'], {'PRIMARY', 'APPEAL'}), 'PANEL_SLASH')
            verify(controller(state, payload['member']), BALLOT_LABEL, body, item['signature'])
            bodies.append(body)
        need(bodies[0]['phase'] == bodies[1]['phase'] and bodies[0] != bodies[1], 'PANEL_SLASH')
        # One equivocation is one offence: the same agreement and phase slash a
        # member once, however many conflicting pairs or resubmissions follow.
        need(payload['member'] in state['arbitrators'], 'ARBITRATOR_UNKNOWN')
        row = state['arbitrators'][payload['member']]
        offence = digest('COVENANT-PANEL-EQUIVOCATION-1', {'agreement': payload['agreement'],
                                                           'phase': bodies[0]['phase']})
        need(offence not in row.get('equivocations', []), 'PANEL_SLASH_REPEAT')
        _slash(state, agreement, payload['member'], 'collusion', tid)
        row.setdefault('equivocations', []).append(offence)
        return [agreement['formation']]
    raise ValueError('ARBITRATION_OPERATION')


def _bond(state, agreement, actor_back, winners):
    appeal = agreement['panel_case'].get('appeal')
    if appeal is None or appeal.get('settled'):
        return
    resource = agreement['terms']['panel']['fees']['resource']
    quantity = appeal['bond']
    if actor_back is not None:
        _unlock(state, actor_back, resource, quantity, 'arbitration_held')
    else:
        _pay_panel(state, resource, quantity, winners or appeal['seated'])
    appeal['settled'] = True


class ArbiterAdapter:
    """Silence ladder: the chosen arbiter, then a recruited protocol panel.

    A seated panel is required only when the agreement already has panel state.
    This ladder does not require that case. A silent chosen arbiter falls
    through to ``search_arbitrators``. ``panel_missed`` and ``settle_miss``
    run only when the caller already has a live case. Nothing is submitted.
    """

    def __init__(self, chosen, registry=(), *, category=None, exclude=(), seats=1):
        self.chosen = chosen
        self.registry = list(registry or [])
        self.category = category
        self.exclude = tuple(exclude)
        self.seats = seats

    def escalate(self, *, state=None, agreement=None, height=1, tid=None):
        from .arbitration_sdk import search_arbitrators
        ladder = [{'rung': 'chosen_arbiter', 'identity': self.chosen, 'outcome': 'SILENT'}]
        missed = False
        if state is not None and agreement is not None:
            missed = panel_missed(state, agreement, height)
        if missed and tid is not None:
            settle_miss(state, agreement, tid, height)
            ladder.append({'rung': 'existing_panel', 'outcome': 'MISSED', 'members': []})
            panel = 'SETTLED_BY_CALLER'
        else:
            found = search_arbitrators(
                self.registry, category=self.category, exclude=self.exclude)
            members = [row['member'] for row in found[:self.seats]]
            panel = 'RECRUITED' if members else 'NOT_SEATED'
            ladder.append({
                'rung': 'protocol_panel',
                'outcome': panel,
                'members': members,
            })
        return {
            'panel': panel, 'ladder': ladder, 'submitted': False,
            'execution_authorized': False,
        }


def open_appeal(state, agreement, actor, tid, height):
    """Called from PANEL_APPEAL once the window is known from the decision height."""
    case = agreement['panel_case']
    panel = agreement['terms']['panel']
    appeal_terms = panel['appeal']
    need(case['status'] == 'SETTLED' and case['appeal'] is None, 'PANEL_APPEAL')
    opened = case['decision']['height']
    need(opened < height <= opened + appeal_terms['blocks'], 'PANEL_APPEAL')
    for member in appeal_terms['arbitrators']:
        _require_member(state, member, agreement['terms'])
        need(member not in case['seated'], 'PANEL_APPEAL_OVERLAP')
    resource = panel['fees']['resource']
    _lock(state, actor, resource, appeal_terms['bond'], 'arbitration_held')
    case['appeal'] = {'appellant': actor, 'bond': appeal_terms['bond'], 'opened': height,
                      'until': height + panel['stages']['vote_blocks'], 'votes': {},
                      'seated': list(appeal_terms['arbitrators']), 'settled': False}
    case['status'] = 'APPEAL'
    agreement['history'].append(tid)
