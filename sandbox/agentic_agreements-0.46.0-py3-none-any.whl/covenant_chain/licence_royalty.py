"""Commercial licence royalties, negotiated deal by deal.

The published rate card is the opening offer and the fallback when no
licence is in force. A counter uses the cooperation offer/counter flow.
The negotiated rate is sealed to the licensor and the host. The public
ledger stores a commitment and the attestation, then the founder bands
and the burn share of that collected income.
"""
from copy import deepcopy

from covenant_language.agentic import object_id
from covenant_language.quantum import recipient_keypair

from .cooperation import counteroffer, draft_service, file_publication
from .crypto import digest, integer, key, need, public_key, sign, verify
from .founder_share import split as founder_split
from .privacy_scopes import ENCRYPTED, LABEL as SCOPE_LABEL, PrivacyDesk, draft as scope_draft, identifier as scope_id
from .revenue_ledger import record
from .token_invariants import BURN_SHARE_FLOOR_BPS, onaah_holds

VERSION = 'covenant-commercial-licence/0.1'
CARD_VERSION = 'covenant-licence-rate-card/0.1'
ATTEST_VERSION = 'covenant-licence-attestation/0.1'
ATTEST_LABEL = 'COVENANT-LICENCE-ATTESTATION-0.1'
RATE_LABEL = 'COVENANT-LICENCE-RATE-0.1'
CARD_LABEL = 'COVENANT-LICENCE-CARD-0.1'
WHITE_LABEL = ('NONE', 'NAME', 'PRODUCT', 'FULL')
MODELS = ('percent_of_fees', 'per_deal', 'flat', 'tiered', 'hybrid')

# Illustrative. The high end of each range is the ona'ah reference: a
# negotiated figure may not clear that high end by more than one sixth.
RATE_CARD = {
    'version': CARD_VERSION,
    'models': {
        'percent_of_fees': {'low_bps': 50, 'default_bps': 200, 'high_bps': 250},
        'per_deal': {'low': 1, 'default': 5, 'high': 10},
        'flat': {'low': 100, 'default': 500, 'high': 1000},
        'tiered': {'bands': [
            {'up_to': 10_000, 'low_bps': 150, 'default_bps': 200, 'high_bps': 250},
            {'up_to': None, 'low_bps': 50, 'default_bps': 100, 'high_bps': 150},
        ]},
        'hybrid': {
            'percent': {'low_bps': 25, 'default_bps': 100, 'high_bps': 150},
            'flat': {'low': 0, 'default': 100, 'high': 500},
        },
    },
    'minimum': {'low': 0, 'default': 0, 'high': 100},
    'maximum': {'low': 0, 'default': None, 'high': 100_000},
    'term_blocks': {'low': 1, 'default': 1000, 'high': 5_000_000},
    'territory': 'WORLD',
    'exclusivity': False,
    'white_label': 'NONE',
}


def rate_card():
    """The published card. Callers may read it. They may not replace it."""
    return deepcopy(RATE_CARD)


def _card_rate():
    card = RATE_CARD
    return {
        'model': 'percent_of_fees',
        'bps': card['models']['percent_of_fees']['default_bps'],
        'per_deal': card['models']['per_deal']['default'],
        'flat': card['models']['flat']['default'],
        'tiers': [{'up_to': band['up_to'], 'bps': band['default_bps']}
                  for band in card['models']['tiered']['bands']],
        'minimum': card['minimum']['default'],
        'maximum': card['maximum']['default'],
    }


def _bounds(price, high):
    """True when price does not clear `high` by more than the ona'ah sixth."""
    if high is None:
        return True
    integer(price)
    integer(high)
    return onaah_holds(price, high)


def _check_rate(rate):
    need(type(rate) is dict, 'LICENCE_RATE')
    need(set(rate) == {'model', 'bps', 'per_deal', 'flat', 'tiers', 'minimum', 'maximum'}, 'LICENCE_RATE')
    need(rate['model'] in MODELS, 'LICENCE_MODEL')
    integer(rate['bps'])
    integer(rate['per_deal'])
    integer(rate['flat'])
    integer(rate['minimum'])
    need(rate['maximum'] is None or type(rate['maximum']) is int, 'LICENCE_CAP')
    if rate['maximum'] is not None:
        integer(rate['maximum'])
    card = RATE_CARD
    model = rate['model']
    if model == 'percent_of_fees':
        need(_bounds(rate['bps'], card['models']['percent_of_fees']['high_bps']), 'LICENCE_CAP')
    elif model == 'per_deal':
        need(_bounds(rate['per_deal'], card['models']['per_deal']['high']), 'LICENCE_CAP')
    elif model == 'flat':
        need(_bounds(rate['flat'], card['models']['flat']['high']), 'LICENCE_CAP')
    elif model == 'hybrid':
        need(_bounds(rate['bps'], card['models']['hybrid']['percent']['high_bps']), 'LICENCE_CAP')
        need(_bounds(rate['flat'], card['models']['hybrid']['flat']['high']), 'LICENCE_CAP')
    else:
        bands = card['models']['tiered']['bands']
        need(type(rate['tiers']) is list and len(rate['tiers']) == len(bands), 'LICENCE_TIERS')
        for got, published in zip(rate['tiers'], bands):
            need(type(got) is dict and set(got) == {'up_to', 'bps'}, 'LICENCE_TIERS')
            need(got['up_to'] == published['up_to'], 'LICENCE_TIERS')
            integer(got['bps'])
            need(_bounds(got['bps'], published['high_bps']), 'LICENCE_CAP')
    if model != 'tiered':
        need(type(rate['tiers']) is list, 'LICENCE_TIERS')
    need(_bounds(rate['minimum'], card['minimum']['high']), 'LICENCE_CAP')
    if rate['maximum'] is not None:
        need(_bounds(rate['maximum'], card['maximum']['high']), 'LICENCE_CAP')
    return rate


def _territory(value):
    need(type(value) is str and 1 <= len(value) <= 32 and value.isascii() and value.isupper(), 'LICENCE_TERRITORY')
    need(all(c.isalnum() or c in '._-' for c in value), 'LICENCE_TERRITORY')


def _term(blocks):
    integer(blocks, True)
    window = RATE_CARD['term_blocks']
    need(window['low'] <= blocks <= window['high'], 'LICENCE_TERM')


def _terms(licensor, host, rate, opens, expires, territory, exclusivity, white_label, mfn):
    key(licensor)
    key(host)
    need(licensor != host, 'LICENCE_PARTIES')
    _check_rate(rate)
    integer(opens)
    integer(expires, True)
    need(expires > opens, 'LICENCE_TERM')
    _term(expires - opens)
    _territory(territory)
    need(type(exclusivity) is bool, 'LICENCE_EXCLUSIVITY')
    need(white_label in WHITE_LABEL, 'LICENCE_WHITE_LABEL')
    need(type(mfn) is bool, 'LICENCE_MFN')
    body = {
        'version': VERSION, 'licensor': licensor, 'host': host, 'rate': deepcopy(rate),
        'opens': opens, 'expires': expires, 'territory': territory, 'exclusivity': exclusivity,
        'white_label': white_label, 'mfn': mfn, 'card': CARD_VERSION,
    }
    return body


def default_terms(licensor, host, height):
    """Starting offer: the published card, for one default term."""
    integer(height)
    term = RATE_CARD['term_blocks']['default']
    return _terms(licensor, host, _card_rate(), height, height + term,
                  RATE_CARD['territory'], RATE_CARD['exclusivity'], RATE_CARD['white_label'], False)


def _service_frame(licensor, host, resolver, world, height, terms):
    parties = sorted({licensor, host, resolver})
    offer = {
        'capability': 'commercial-licence', 'capacity_resource': 'commercial-licence',
        'capacity_mode': 'RELEASE', 'settlement_resource': 'fee',
        'unit_price': _unit_price(terms['rate']), 'expiry': terms['expires'], 'practice': None,
    }
    book = {
        'world': world, 'revision': 0, 'units': 1, 'resolver': resolver, 'appeal_resolver': None,
        'deadline': terms['expires'], 'challenge_blocks': 0, 'appeal_blocks': 1,
        'uncertainty': 'REFUND',
    }
    return parties, offer, book


def _unit_price(rate):
    model = rate['model']
    if model == 'percent_of_fees':
        return rate['bps']
    if model == 'per_deal':
        return rate['per_deal']
    if model == 'flat':
        return rate['flat']
    if model == 'hybrid':
        return rate['bps'] + rate['flat']
    return rate['tiers'][0]['bps']


def opening_offer(licensor, host, resolver, world, height):
    """One cooperation proposal whose agreement is the published card."""
    key(resolver)
    key(world)
    terms = default_terms(licensor, host, height)
    parties, offer, book = _service_frame(licensor, host, resolver, world, height, terms)
    proposal = draft_service(
        b'Commercial licence. The rate card is the opening offer.',
        parties, terms, offer, book, file_publication(b'covenant-commercial-licence'),
    )
    return {'proposal': proposal, 'terms': terms, 'card': rate_card(), 'source': 'CARD'}


def _merge(terms, changes, height):
    need(type(changes) is dict and changes and set(changes) <= {
        'rate', 'term_blocks', 'territory', 'exclusivity', 'white_label', 'mfn', 'renew_from',
    }, 'LICENCE_COUNTER')
    rate = deepcopy(changes['rate']) if 'rate' in changes else deepcopy(terms['rate'])
    territory = changes.get('territory', terms['territory'])
    exclusivity = changes.get('exclusivity', terms['exclusivity'])
    white_label = changes.get('white_label', terms['white_label'])
    mfn = changes.get('mfn', terms['mfn'])
    if 'renew_from' in changes:
        integer(height)
        start = changes['renew_from']
        integer(start)
        need(start == terms['expires'] or start == height, 'LICENCE_RENEWAL')
        _term(changes['term_blocks'])
        expires = start + changes['term_blocks']
        opens = terms['opens']
        # A renewal's own term is what the card bounds. The life of the
        # licence may run longer than one published term.
        body = deepcopy(terms)
        body.update(rate=rate, territory=territory, exclusivity=exclusivity,
                    white_label=white_label, mfn=mfn, expires=expires)
        _check_rate(body['rate'])
        _territory(body['territory'])
        need(type(body['exclusivity']) is bool, 'LICENCE_EXCLUSIVITY')
        need(body['white_label'] in WHITE_LABEL, 'LICENCE_WHITE_LABEL')
        need(type(body['mfn']) is bool, 'LICENCE_MFN')
        need(body['expires'] > height or body['expires'] > terms['expires'], 'LICENCE_RENEWAL')
        integer(body['expires'], True)
        return body
    if 'term_blocks' in changes:
        _term(changes['term_blocks'])
        expires = terms['opens'] + changes['term_blocks']
    else:
        expires = terms['expires']
    return _terms(terms['licensor'], terms['host'], rate, terms['opens'], expires,
                  territory, exclusivity, white_label, mfn)


def counter_licence(proposal, changes, *, height):
    """Counter the opening offer. A rate over the ona'ah cap is refused."""
    current = proposal['meaning']['terms']['agreement']
    updated = _merge(current, changes, height)
    offer = deepcopy(proposal['meaning']['offer'])
    offer['unit_price'] = _unit_price(updated['rate'])
    offer['expiry'] = updated['expires']
    book = deepcopy(proposal['meaning']['book'])
    book['deadline'] = updated['expires']
    replied = counteroffer(proposal, agreement=updated, offer=offer, book=book)
    return replied


def renew(proposal, term_blocks, height):
    """Extend a live licence, or start the next term at `height` once it has lapsed."""
    current = proposal['meaning']['terms']['agreement']
    start = current['expires'] if height < current['expires'] else height
    return counter_licence(proposal, {'term_blocks': term_blocks, 'renew_from': start}, height=height)


def _commitment(rate):
    return digest(RATE_LABEL, rate)


def attest(proposal, licensor_key, host_key, *, recipient_publics, chain):
    """Seal the rate to the two parties and sign an attestation of the agreement."""
    terms = proposal['meaning']['terms']['agreement']
    need(terms['version'] == VERSION, 'LICENCE_VERSION')
    need(public_key(licensor_key) == terms['licensor'], 'LICENCE_PARTIES')
    need(public_key(host_key) == terms['host'], 'LICENCE_PARTIES')
    need(set(recipient_publics) == {'licensor', 'host'}, 'LICENCE_RECIPIENTS')
    key(chain)
    controllers = [terms['licensor'], terms['host']]
    policy = scope_draft(
        chain, controllers, {'licensor': recipient_publics['licensor'], 'host': recipient_publics['host']},
        ['/rate'], 'Commercial licence rate, visible to the licensor and the host', ENCRYPTED,
    )['policy']
    pid = scope_id(policy)
    approvals = [
        {'controller': terms['licensor'], 'signature': sign(licensor_key, SCOPE_LABEL, policy)},
        {'controller': terms['host'], 'signature': sign(host_key, SCOPE_LABEL, policy)},
    ]
    desk = PrivacyDesk()
    delivery = desk.protect({'rate': terms['rate'], 'other': 'not sealed'}, policy, approvals, pid, controllers)
    body = {
        'version': ATTEST_VERSION, 'agreement': object_id(proposal), 'commitment': _commitment(terms['rate']),
        'scope': pid, 'opens': terms['opens'], 'expires': terms['expires'],
        'licensor': terms['licensor'], 'host': terms['host'], 'mfn': terms['mfn'],
        'territory': terms['territory'], 'exclusivity': terms['exclusivity'],
        'white_label': terms['white_label'], 'seal': delivery,
    }
    signatures = [
        {'signer': terms['licensor'], 'signature': sign(licensor_key, ATTEST_LABEL, body)},
        {'signer': terms['host'], 'signature': sign(host_key, ATTEST_LABEL, body)},
    ]
    return {
        'credential': {'body': body, 'signatures': signatures},
        'scope': {'policy': policy, 'approvals': approvals, 'controllers': controllers},
    }


def _verify_credential(credential):
    need(type(credential) is dict and set(credential) == {'body', 'signatures'}, 'LICENCE_ATTESTATION')
    body = credential['body']
    need(type(body) is dict and body.get('version') == ATTEST_VERSION, 'LICENCE_ATTESTATION')
    need(type(credential['signatures']) is list and len(credential['signatures']) == 2, 'LICENCE_ATTESTATION')
    seen = set()
    for row in credential['signatures']:
        need(type(row) is dict and set(row) == {'signer', 'signature'}, 'LICENCE_ATTESTATION')
        verify(row['signer'], ATTEST_LABEL, body, row['signature'])
        seen.add(row['signer'])
    need(seen == {body['licensor'], body['host']}, 'LICENCE_ATTESTATION')
    return body


def open_rate(credential, scope, desk, recipient):
    """Parties open the sealed rate. The commitment must match what was signed."""
    body = _verify_credential(credential)
    opened = desk.open(body['seal'], scope['policy'], scope['approvals'], body['scope'], scope['controllers'], recipient)
    rate = opened['selected']['/rate']
    need(_commitment(rate) == body['commitment'], 'LICENCE_COMMITMENT')
    _check_rate(rate)
    return rate


def _tiered(tiers, fees):
    left = fees
    cursor = 0
    total = 0
    for band in tiers:
        width = left if band['up_to'] is None else min(left, band['up_to'] - cursor)
        if width > 0:
            total += width * band['bps'] // 10000
            left -= width
            cursor = band['up_to'] if band['up_to'] is not None else cursor + width
        if left <= 0:
            break
    return total


def _apply_mfn(rate, comparisons):
    if not comparisons:
        return rate
    nxt = deepcopy(rate)
    same = [item for item in comparisons if item.get('model') == rate['model']]
    if rate['model'] == 'percent_of_fees':
        nxt['bps'] = min([rate['bps'], *[item['bps'] for item in same]])
    elif rate['model'] == 'per_deal':
        nxt['per_deal'] = min([rate['per_deal'], *[item['per_deal'] for item in same]])
    elif rate['model'] == 'flat':
        nxt['flat'] = min([rate['flat'], *[item['flat'] for item in same]])
    elif rate['model'] == 'hybrid':
        nxt['bps'] = min([rate['bps'], *[item['bps'] for item in same]])
        nxt['flat'] = min([rate['flat'], *[item['flat'] for item in same]])
    elif rate['model'] == 'tiered' and same:
        for index, band in enumerate(nxt['tiers']):
            band['bps'] = min([band['bps'], *[item['tiers'][index]['bps'] for item in same]])
    return nxt


def royalty_amount(rate, fees, deals):
    integer(fees)
    integer(deals)
    model = rate['model']
    if model == 'percent_of_fees':
        raw = fees * rate['bps'] // 10000
    elif model == 'per_deal':
        raw = rate['per_deal'] * deals
    elif model == 'flat':
        raw = rate['flat']
    elif model == 'tiered':
        raw = _tiered(rate['tiers'], fees)
    else:
        raw = fees * rate['bps'] // 10000 + rate['flat']
    if raw < rate['minimum']:
        raw = rate['minimum']
    if rate['maximum'] is not None and raw > rate['maximum']:
        raw = rate['maximum']
    return raw


def _route(amount, prior_gross):
    """Founder bands, then the burn floor on what remains. Nothing is minted."""
    line = founder_split(amount, 'licence_royalty', prior_gross)
    remainder = amount - line['founder']
    burned = remainder * BURN_SHARE_FLOOR_BPS // 10000
    licensor_net = remainder - burned
    line.update(burn=burned, licensor=licensor_net, burn_floor_bps=BURN_SHARE_FLOOR_BPS)
    return line


def _public(commitment, attestation, agreement, source, amount, routed, height):
    """Ledger view. The rate object is not a field here."""
    return {
        'commitment': commitment, 'attestation': attestation, 'agreement': agreement,
        'source': source, 'gross': amount, 'founder': routed['founder'], 'burn': routed['burn'],
        'licensor': routed['licensor'], 'flow': 'licence_royalty', 'height': height,
    }


def collect(meter, *, fees, deals, height, prior_gross=0, credential=None, scope=None,
            desk=None, recipient=None, comparisons=None):
    """Collect the negotiated royalty, or the card when no licence is presented."""
    integer(height)
    if credential is None:
        rate = _card_rate()
        amount = royalty_amount(rate, fees, deals)
        routed = _route(amount, prior_gross)
        record(meter, height, 'licence_royalty', 'CARD', amount, 0, routed['founder'], 0,
               routed['licensor'], 0, 0)
        return _public(digest(CARD_LABEL, RATE_CARD), None, None, 'CARD', amount, routed, height)
    body = _verify_credential(credential)
    need(height >= body['opens'], 'LICENCE_NOT_OPEN')
    need(height < body['expires'], 'LICENCE_EXPIRED')
    rate = open_rate(credential, scope, desk, recipient)
    if body['mfn']:
        rate = _apply_mfn(rate, comparisons or [])
        _check_rate(rate)
    amount = royalty_amount(rate, fees, deals)
    routed = _route(amount, prior_gross)
    attestation = digest(ATTEST_LABEL, body)
    record(meter, height, 'licence_royalty', attestation, amount, 0, routed['founder'], 0,
           routed['licensor'], 0, 0)
    public = _public(body['commitment'], attestation, body['agreement'], 'NEGOTIATED', amount, routed, height)
    need('rate' not in public and 'bps' not in public, 'LICENCE_PRIVATE')
    return public


def fresh_recipients():
    """One ML-KEM pair for each party. Secrets stay with the desk that opens."""
    made = {}
    for name in ('licensor', 'host'):
        public, secret = recipient_keypair()
        made[name] = {'public': public, 'secret': secret}
    return made
