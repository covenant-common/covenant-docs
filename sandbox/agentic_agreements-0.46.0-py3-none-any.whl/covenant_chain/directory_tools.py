"""MCP actions for the signed directory. Reads never sign. Writes use the local forum key."""
from .cooperation_interface import HASH, INT, OBJECT, schema
from .crypto import need
from .directory_network import (
    KINDS, document_id, publish_service, replicate, report_abuse, service_listing, sign_document, api,
)

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 256}
DOCS = {'type': 'array', 'maxItems': 256, 'items': OBJECT}
STAKE = {'type': 'array', 'maxItems': 64, 'items': schema({'actor': HASH, 'units': INT}, ('actor', 'units'))}
HEADS = {'type': 'array', 'maxItems': 64, 'items': HASH}
SEARCH = {
    'documents': DOCS, 'settlements': DOCS, 'stake': STAKE, 'group': HASH,
    'query': {'type': 'string', 'maxLength': 256}, 'capability': TEXT, 'max_price': INT,
    'min_positive': INT, 'availability': {'enum': ['AVAILABLE', 'LIMITED', 'UNAVAILABLE']},
    'domain': TEXT, 'sponsored': {'type': 'array', 'maxItems': 16, 'items': OBJECT},
    'boost': INT, 'policy': OBJECT, 'split': OBJECT,
    'receipts': {'type': 'array', 'maxItems': 4096, 'items': OBJECT},
    'newcomers': {'type': 'array', 'maxItems': 256, 'items': OBJECT},
    'exploration_seed': HASH, 'operator': HASH, 'price_elsewhere': INT,
}
BUNDLE = ('documents', 'settlements', 'stake', 'group')


def read_spec():
    return ('covenant_directory',
            'Read signed agent, person and organisation profiles, search them, and draft a BIND. '
            'Organic order is relevance 50, seeded trust mass 20 and outcome lower bound 30. '
            'Sponsored cards, boosts, the operator and a price elsewhere stay out of that order. '
            'One shown slot in eight can hold a clean newcomer without moving the organic list. '
            'No login, no spend, no signature, and no stored reputation balance.',
            True, [
                ('search', SEARCH, ()),
                ('profile', {**{name: SEARCH[name] for name in BUNDLE}, 'identity': HASH}, ('identity',)),
                ('feed', {name: SEARCH[name] for name in BUNDLE}, ()),
                ('graph', {name: SEARCH[name] for name in BUNDLE}, ()),
                ('page', {**{name: SEARCH[name] for name in BUNDLE}, 'identity': HASH, 'referrer': HASH}, ('identity',)),
                ('index', SEARCH, ()),
                ('draft', {**{name: SEARCH[name] for name in BUNDLE}, 'job': HASH, 'bid': HASH, 'listing': OBJECT}, ()),
                ('share', {**{name: SEARCH[name] for name in BUNDLE}, 'agreement': HASH, 'referrer': HASH,
                           'opt_in': {'const': True}, 'platforms': {'type': 'array', 'maxItems': 8, 'items': TEXT}},
                 ('agreement', 'referrer', 'opt_in')),
            ])


def write_spec():
    return ('covenant_directory_write',
            'Sign a directory document with the local forum key, accept a profile the caller already signed, '
            'copy a forum-signed document into the forum as an ordinary POST, '
            'publish a marketplace listing, or file abuse with the founder feedback desk. '
            'A keyless host uses a disposable forum key, not a principal seed. '
            'Caller-supplied stake is ignored. Nothing here submits a BIND or moves funds.',
            False, [
                ('sign', {'kind': {'enum': sorted(KINDS)}, 'revision': {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
                          'payload': OBJECT, 'replicate': {'type': 'boolean'}, 'request': TEXT, 'group': HASH,
                          'expected_heads': HEADS}, ('kind', 'revision', 'payload')),
                ('accept', {'envelope': OBJECT}, ('envelope',)),
                ('replicate', {'envelope': OBJECT, 'request': TEXT, 'group': HASH, 'expected_heads': HEADS},
                 ('envelope', 'request', 'group')),
                ('report', {'domain': HASH, 'owner': HASH, 'target': HASH, 'reason': {'type': 'string', 'minLength': 1, 'maxLength': 400},
                            'related': {'type': 'array', 'maxItems': 16, 'items': HASH}}, ('domain', 'owner', 'target', 'reason')),
                ('listing', {'market': HASH, 'title': TEXT, 'price': {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
                             'payment_asset': OBJECT, 'capability': TEXT, 'quantity': {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1},
                             'replicate': {'type': 'boolean'}, 'request': TEXT, 'group': HASH, 'expected_heads': HEADS},
                 ('market', 'title', 'price', 'payment_asset')),
            ])


def call(exchange, name, action, parameters):
    if name == 'covenant_directory_write':
        return _write(exchange, action, parameters)
    need(name == 'covenant_directory', 'DIRECTORY_TOOL')
    return api({'action': action, 'parameters': _with_board(exchange, parameters)}, network=exchange.network)


def _with_board(exchange, parameters):
    board = getattr(exchange, 'board', None)
    if board is None:
        return parameters
    shared = board.documents()
    if not shared:
        return parameters
    parameters = dict(parameters)
    parameters['documents'] = list(shared) + list(parameters.get('documents') or [])
    return parameters


def _signer(exchange):
    network = exchange.network
    if network is not None:
        return network.signer, network.domain, network
    board = getattr(exchange, 'board', None)
    need(board is not None and board.signer is not None, 'DIRECTORY_NETWORK')
    return board.signer, board.chain, None


def _share(exchange, chain, envelope):
    board = getattr(exchange, 'board', None)
    if board is None or chain != board.chain:
        return False
    board.accept(envelope)
    return True


def _write(exchange, action, parameters):
    if action == 'accept':
        board = getattr(exchange, 'board', None)
        need(board is not None, 'DIRECTORY_NETWORK')
        stored = board.accept(parameters['envelope'])
        return {'id': stored['id'], 'accepted': True, 'stored': stored['stored'], 'signed_by': 'caller',
                'replicated': False, 'submitted': False, 'execution_authorized': False, 'caller_stake_ignored': True}
    signer, chain, network = _signer(exchange)
    if action == 'sign':
        envelope = sign_document(signer, chain, parameters['kind'], parameters['revision'], parameters['payload'])
        result = {'envelope': envelope, 'id': document_id(envelope), 'replicated': False,
                  'submitted': False, 'execution_authorized': False, 'caller_stake_ignored': True,
                  'shared': _share(exchange, chain, envelope)}
        if parameters.get('replicate') is True:
            need(network is not None and 'request' in parameters and 'group' in parameters, 'DIRECTORY_REPLICATE')
            result.update(replicate(network, parameters['request'], parameters['group'], envelope,
                                    expected_heads=parameters.get('expected_heads')))
        return result
    if action == 'replicate':
        need(network is not None, 'DIRECTORY_NETWORK')
        return replicate(network, parameters['request'], parameters['group'], parameters['envelope'],
                         expected_heads=parameters.get('expected_heads'))
    if action == 'report':
        return report_abuse(signer, parameters['domain'], parameters['owner'], parameters['target'],
                            parameters['reason'], related=tuple(parameters.get('related') or ()))
    if action == 'listing':
        made = service_listing(signer, parameters['market'], parameters['title'], parameters['price'],
                               parameters['payment_asset'], parameters.get('capability') or 'General',
                               parameters.get('quantity') or 1)
        if parameters.get('replicate') is True:
            need(network is not None and 'request' in parameters and 'group' in parameters, 'DIRECTORY_REPLICATE')
            made['publication'] = publish_service(network, parameters['request'], parameters['group'], made['listing'],
                                                  expected_heads=parameters.get('expected_heads'))
            made['published'] = True
        made['caller_stake_ignored'] = True
        return made
    raise ValueError('DIRECTORY_ACTION')
