"""covenant_connect: read-only AAP Connect checks for agents.

An agent can read the seven adapter contracts and the integrator terms, check
a signed adapter manifest, conformance report or AAP-compatible certificate,
and find adapters offered through signed discovery. Nothing here signs,
adopts, installs, pays or contacts anyone: adoption is the owner's explicit
pin, and every record checked is data, never an instruction.
"""
from copy import deepcopy

from . import connect
from .connect import ConnectError
from .cooperation_interface import HASH, INT
from .crypto import FieldError

NAME = 'covenant_connect'
KIND = {'enum': list(connect.KINDS)}
SIGNED = {'type': 'object', 'required': ['body', 'signature'], 'additionalProperties': False,
          'properties': {'body': {'type': 'object', 'maxProperties': 32},
                         'signature': {'type': 'string', 'pattern': '^[0-9a-f]{128}$'}}}
ASSESSMENT = {'enum': ['SELF_TEST', 'PROJECT_ASSESSMENT', 'INDEPENDENT_ASSESSMENT']}


def spec():
    return ('covenant_connect',
        'Plug outside systems into AAP: read the adapter contract for a payment method, fair-fix forum, identity '
        'provider, directory, proof source, carrier or registry; read how adapters earn; check a signed adapter '
        'manifest, conformance report or AAP-compatible certificate against your own pins; find adapters offered '
        'through signed discovery. Output is evidence, never authority. No signing, adoption, installation, '
        'payment or network access.', True, [
        ('describe', {}, ()),
        ('contract', {'kind': KIND}, ('kind',)),
        ('terms', {'kind': KIND}, ()),
        ('check_manifest', {'manifest': SIGNED, 'expected_id': HASH, 'report': SIGNED}, ('manifest',)),
        ('check_report', {'report': SIGNED, 'expected_tester': HASH}, ('report',)),
        ('check_certificate', {'certificate': SIGNED, 'status': SIGNED, 'now': INT,
                               'trusted_issuers': {'type': 'array', 'maxItems': 16, 'items': HASH},
                               'assessments': {'type': 'array', 'minItems': 1, 'maxItems': 3, 'items': ASSESSMENT},
                               'kinds': {'type': 'array', 'minItems': 1, 'maxItems': 7, 'items': KIND},
                               'subject': HASH, 'max_status_age': INT}, ('certificate', 'now')),
        ('find', {'sources': {'type': 'array', 'maxItems': 32, 'items': {'type': 'object', 'maxProperties': 16}},
                  'manifests': {'type': 'array', 'maxItems': 64, 'items': SIGNED}, 'now': INT, 'kind': KIND},
         ('sources', 'manifests', 'now'))])


def describe():
    return {**connect.describe(), 'tool': NAME,
            'actions': ['contract', 'terms', 'check_manifest', 'check_report', 'check_certificate', 'find'],
            'owner_only': [connect.COMMAND + ' new', connect.COMMAND + ' manifest', connect.COMMAND + ' certify',
                           'connect_registry.ConnectRegistry.adopt', 'connect_registry.ConnectRegistry.bind'],
            'adoption': 'EXPLICIT_OWNER_PIN_REQUIRED'}


def _call(action, p):
    if action == 'describe':
        return describe()
    if action == 'contract':
        return connect.contract(p['kind'])
    if action == 'terms':
        from .connect_terms import terms
        return terms(p.get('kind'))
    if action == 'check_manifest':
        opened = connect.open_manifest(p['manifest'], expected_id=p.get('expected_id'))
        bound = None
        if 'report' in p:
            from .connect_conformance import bound as report_bound, open_report
            bound = report_bound(opened['body'], open_report(p['report']))
        return {'manifest': opened['id'], 'urn': opened['urn'], 'body': opened['body'], 'signature_verified': True,
                'report_bound': bound, 'adopted': False, 'installed': False, 'execution_authorized': False}
    if action == 'check_report':
        from .connect_conformance import open_report
        opened = open_report(p['report'], expected_tester=p.get('expected_tester'))
        body = opened['body']
        return {'report': opened['id'], 'kind': body['kind'], 'subject': body['subject'], 'verdict': body['verdict'],
                'summary': body['summary'], 'tester': body['tester'], 'results_sha256': body['results_sha256'],
                'failed': [row['id'] for row in body['results'] if row['status'] == 'FAIL'],
                'assurance': 'TESTER_STATEMENT_RERUN_TO_REPRODUCE', 'execution_authorized': False}
    if action == 'check_certificate':
        from .connect_certification import presented, verify_certificate
        options = {'now': p['now'], 'trusted_issuers': p.get('trusted_issuers', []),
                   'require_status': 'max_status_age' in p, 'max_status_age': p.get('max_status_age'),
                   'kinds': p.get('kinds'), 'subject': p.get('subject')}
        if 'assessments' in p:
            options['assessments'] = p['assessments']
        return verify_certificate(presented(p['certificate'], p.get('status')), **options)
    if action == 'find':
        from .connect_registry import find
        from .signed_discovery import gather
        return find(gather(deepcopy(p['sources']), p['now']), p['manifests'], kind=p.get('kind'))
    raise ConnectError('CONNECT_METHOD')


def call(action, p):
    try:
        return _call(action, p)
    except ConnectError as error:
        # Carry the contract's fix text to the agent through the shared refusal shape.
        raise FieldError(error.code, '/parameters', 'see next_action', connect.refusal(error.code)['fix']) from None
