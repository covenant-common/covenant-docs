"""Persistent authenticated tables for the explicitly adopted native 0.2 profile.

Individual keys/values remain bounded wire objects. Table size is not a wire
message limit. A transaction forks roots and copies only records it reads.
"""
from collections.abc import MutableMapping
from copy import deepcopy
from dataclasses import dataclass
from .crypto import digest, canonical
EMPTY = digest('COVENANT-TABLE-EMPTY-0.2', {})

@dataclass(frozen=True)
class Branch:
    key: str
    value: object
    priority: str
    left: object
    right: object
    root: str

def branch(k,v,left=None,right=None):
    return Branch(k,v,digest('COVENANT-TABLE-PRIORITY-0.2',k),left,right,
        digest('COVENANT-TABLE-NODE-0.2',{'key':k,'value':v,
          'left':left.root if left else EMPTY,'right':right.root if right else EMPTY}))

def put(n,k,v):
    if n is None:return branch(k,v)
    if k==n.key:return branch(k,v,n.left,n.right)
    if k<n.key:
        l=put(n.left,k,v);n=branch(n.key,n.value,l,n.right)
        if (l.priority,l.key)<(n.priority,n.key):
            return branch(l.key,l.value,l.left,branch(n.key,n.value,l.right,n.right))
    else:
        r=put(n.right,k,v);n=branch(n.key,n.value,n.left,r)
        if (r.priority,r.key)<(n.priority,n.key):
            return branch(r.key,r.value,branch(n.key,n.value,n.left,r.left),r.right)
    return n

def lookup(n,k):
    while n:
        if k==n.key:return n.value
        n=n.left if k<n.key else n.right
    raise KeyError(k)

def pairs(n):
    stack=[]
    while stack or n:
        while n:stack.append(n);n=n.left
        n=stack.pop();yield n.key,n.value;n=n.right

def pairs_after(n,after):
    """Read-only sorted seek; skip a prefix without materializing table keys.

    Expected seek cost follows authenticated treap depth; record traversal is
    incremental. This does not change priorities, roots or hash semantics.
    """
    stack=[]
    while n:
        if n.key>after:stack.append(n);n=n.left
        else:n=n.right
    while stack:
        n=stack.pop();yield n.key,n.value;n=n.right
        while n:stack.append(n);n=n.left

class Table(MutableMapping):
    def __init__(self,values=None,root=None):
        self.root=root;self.dirty={}
        if values:
            for k,v in values.items():self[k]=v
            self.seal()
    def __deepcopy__(self,memo):
        self.seal();return Table(root=self.root)
    def __getitem__(self,k):
        if k not in self.dirty:self.dirty[k]=deepcopy(lookup(self.root,k))
        return self.dirty[k]
    def __setitem__(self,k,v):
        canonical(k);canonical(v);self.dirty[k]=deepcopy(v)
    def setdefault(self,k,default=None):
        if k not in self:self[k]=default
        return self[k]
    def __delitem__(self,k):raise TypeError('use an explicit tombstone')
    def __iter__(self):return iter(sorted(set(k for k,_ in pairs(self.root))|set(self.dirty)))
    def __len__(self):return sum(1 for _ in self)
    def __contains__(self,k):
        if k in self.dirty:return True
        try:lookup(self.root,k);return True
        except KeyError:return False
    def get_raw(self,k,default=None):
        try:return lookup(self.root,k)
        except KeyError:return default
    def changes(self):
        return [(k,self.get_raw(k),v) for k,v in self.dirty.items() if self.get_raw(k)!=v]
    def seal(self):
        for k,v in self.dirty.items():
            canonical(v)
            if self.get_raw(k)!=v:self.root=put(self.root,k,deepcopy(v))
        self.dirty.clear()
        return self.root.root if self.root else EMPTY
    def plain(self):
        out={k:deepcopy(v) for k,v in pairs(self.root)};out.update(deepcopy(self.dirty));return out

def clone_state(value, memo=None):
    """Isolation-identical copy of a chain state.

    Dict and list nodes are new objects. Immutable leaves are shared. A
    repeated identity stays one object in the copy, as ``deepcopy`` does.
    ``Table`` seals and shares its root, which is what ``Table.__deepcopy__``
    does. Sharing an uncopied nested dict would alias the previous state:
    in-place writes such as ``balances[actor][rid] = amount`` mutate the
    object ``__getitem__`` returned. The walk is still linear in the state,
    and on CPython it is slower than ``deepcopy``, so ``apply_transaction``
    keeps ``deepcopy``.
    """
    if memo is None: memo = {}
    oid = id(value)
    if oid in memo: return memo[oid]
    if isinstance(value, Table):
        value.seal()
        out = Table(root=value.root)
        memo[oid] = out
        return out
    kind = type(value)
    if kind is dict:
        out = {}
        memo[oid] = out
        for key, item in value.items():
            out[clone_state(key, memo)] = clone_state(item, memo)
        return out
    if kind is list:
        out = []
        memo[oid] = out
        out.extend(clone_state(item, memo) for item in value)
        return out
    if value is None or kind in (str, int, bool, float): return value
    return deepcopy(value, memo)


def materialize(state):
    return {k:v.plain() if isinstance(v,Table) else deepcopy(v) for k,v in state.items()}

def seal(state):
    return {k:v.seal() if isinstance(v,Table) else v for k,v in state.items()}

def check_deltas(state):
    """Check conservation over changed records, relative to certified predecessor."""
    from collections import defaultdict
    from .crypto import need
    resources=defaultdict(int);authority=defaultdict(int)
    for who,old,new in state['balances'].changes():
        for rid in set(old or {})|set(new):
            d=new.get(rid,0)-(old or {}).get(rid,0)
            resources[rid]+=d;authority[(who,rid)]-=d
    for who,old,new in state['authority_available'].changes():
        for rid in set(old or {})|set(new):authority[(who,rid)]+=new.get(rid,0)-(old or {}).get(rid,0)
    for _,old,new in state['grants'].changes():
        for v,sign in [(old,-1),(new,1)]:
            if v:authority[(v['principal'],v['resource'])]+=sign*v['remaining']
    for _,old,new in state['agreements'].changes():
        for v,sign in [(old,-1),(new,1)]:
            if v and v['held']:resources[v['terms']['resource']]+=sign*v['terms']['quantity']
    for rid,old,new in state['consumed'].changes():resources[rid]+=new-(old or 0)
    for rid,old,new in state['supply'].changes():resources[rid]-=new-(old or 0)
    from .native_custody import add_deltas
    from .custody import balanced
    add_deltas(state,resources)
    balanced(resources)
    balanced(authority,'AUTHORITY_CONSERVATION')

def prove_record(state,table,key):
    """Public membership proof; does not establish head freshness or finality."""
    from .crypto import need
    need(type(table) is str and type(key) is str and isinstance(state.get(table),Table),'PROOF_TABLE_KEY')
    descriptor=seal(state);n=state[table].root;path=[]
    while n:
        path.append({'key':n.key,'value':deepcopy(n.value),'left':n.left.root if n.left else EMPTY,'right':n.right.root if n.right else EMPTY})
        if key==n.key:return {'descriptor':descriptor,'table':table,'key':key,'path':path}
        n=n.left if key<n.key else n.right
    raise KeyError(key)

def verify_record(proof,expected_state_root):
    from .crypto import need,exact
    exact(proof,'descriptor table key path')
    need(digest('COVENANT-STATE-'+proof['descriptor']['protocol'].split('/')[-1],proof['descriptor'])==expected_state_root,'STATE_ROOT')
    path=proof['path'];need(type(path) is list and 0<len(path)<=256,'PROOF_PATH')
    expected=proof['descriptor'][proof['table']]
    for i,node in enumerate(path):
        exact(node,'key value left right')
        need(digest('COVENANT-TABLE-NODE-0.2',node)==expected,'RECORD_PROOF')
        if proof['key']==node['key']:
            need(i==len(path)-1,'EXTRA_PROOF_NODES');return deepcopy(node['value'])
        expected=node['left'] if proof['key']<node['key'] else node['right']
    raise ValueError('INCOMPLETE_PROOF')
