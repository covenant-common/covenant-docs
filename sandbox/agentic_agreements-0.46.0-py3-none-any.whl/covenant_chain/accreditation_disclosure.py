"""Selective disclosure for portable agent qualifications (covenant-agent-accreditation-sd/0.1).

The claims of ``covenant-agent-accreditation/0.1``, with the same meanings and
the same validation, carried as an SD-JWT VC (draft-ietf-oauth-sd-jwt-vc-22;
SD-JWT, RFC 9901) through the existing ``hidden_credentials`` machinery:
``typ`` ``dc+sd-jwt``, EdDSA, and a Key Binding JWT over the relying party's
audience and challenge. The holder reveals only the claims a check needs;
everything else stays behind 128-bit salted digests and decoys.

Always visible (never disclosable, as SD-JWT VC section 2.2.2.3 requires for
``iss``, ``nbf``, ``exp``, ``cnf``, ``vct`` and ``status``): the issuer name,
validity, holder key, the ``status`` reference into a Token Status List
(draft-ietf-oauth-status-list-21 section 6.2), the issuer key version and a
TEST flag. Disclosable: the /0.1 claims (subject, artifact, profile,
qualification, scope, criteria, evidence, outcome) and the fields /0.1 lacks:
principal binding, type ``details``, ``evaluator``, ``assumptions``,
``exclusions``, ``conflicts`` of interest, ``coverage`` (domain, deployment,
reliance terms, jurisdictions, value and risk limits), ``method``,
``assessed_at`` and untrusted ``extensions`` (bounded, returned inert).

Checks follow the relying party's adopted ``covenant-agent-accreditation-policy``
exactly as ``agent_accreditation.inspect_presentation`` does, with the same
refusal codes. Status comes from the issuer's map snapshot or from the same
snapshot as a Token Status List or W3C pair (``accreditation_status``). Durable
verification uses the owner's existing ``VerifierStore``: status is retained
first, known revocations stay revoked and a challenge is consumed once, shared
with /0.1 presentations. Selective disclosure is not anonymity: the issuer,
holder key and status index are visible and linkable.
"""
from copy import deepcopy
import hashlib
import hmac
import os
import re

from . import agent_accreditation as accreditation
from .agent_accreditation import REMEDIATION as ACCREDITATION_REMEDIATION  # the shared ACCREDITATION_* codes
from . import accreditation_status as status_lists_check
from . import status_lists as lists
from .crypto import digest, integer, key, need, public_key, verification_key
from .hidden_credentials import (DIGEST_SLOTS, KB_TYP, SALT_BYTES, SD_ALG, TYP, _b64, _disclosure_digest, _json,
                                 _jwk, _jwk_public, _jws, _open_jws, _unb64, _wire)

VERSION = 'covenant-agent-accreditation-sd/0.1'
VCT = 'urn:aap:vct:agent-accreditation:0.1'
TEST_PREFIX = 'aap-test-issuer'
BASE = ('subject', 'artifact', 'profile', 'qualification', 'scope', 'criteria', 'evidence', 'outcome')
EXTRA = ('principal', 'details', 'evaluator', 'assumptions', 'exclusions', 'conflicts', 'coverage', 'method',
         'assessed_at', 'extensions')
CLAIMS = BASE + EXTRA
POLICY_CLAIMS = ('artifact', 'profile', 'qualification', 'scope', 'outcome')
PAYLOAD = frozenset(('iss', 'iat', 'nbf', 'exp', 'vct', 'cnf', 'status', 'aap_key_version', 'aap_profile', 'aap_test',
                     '_sd', '_sd_alg'))
RISKS = ('LOW', 'MEDIUM', 'HIGH')
DID = re.compile(r'did:(?:aap|covenant):[0-9a-f]{64}:[0-9a-f]{64}\Z')
JURISDICTION = re.compile(r'[A-Z]{2}(?:-[A-Z0-9]{1,3})?\Z')
DETAIL_NAME = re.compile(r'[a-z][a-z0-9_]{0,47}\Z')
METHOD = re.compile(r'[A-Z][A-Z0-9_]{1,63}\Z')
MAX_PRESENTATION = 98304
MAX_DISCLOSURE = 24576
MAX_EXTENSIONS = 4096

ERRORS = {
    'ACCREDITATION_SD_FORMAT': ('The presentation is not an SD-JWT with disclosures and a key-binding JWT.',
                                'Send the presentation exactly as the holder produced it.', False),
    'ACCREDITATION_SD_SIZE': ('The presentation or one disclosure is larger than the bound.',
                              'Keep presentations under 96 KiB and each disclosure under 24 KiB.', False),
    'ACCREDITATION_DISCLOSURE': ('A disclosure is unknown, repeated, malformed or not among the issuer-signed digests.',
                                 'Present only disclosures the issuer produced, once each.', False),
    'ACCREDITATION_CLAIM_WITHHELD': ('A claim the relying party\'s policy or requirement checks was not disclosed.',
                                     'Disclose the named claims, or decline the request.', True),
    'ACCREDITATION_TEST_ISSUER': ('The credential comes from a TEST issuer.',
                                  'Test credentials are synthetic; accept them only under an explicit test check.', False),
    'ACCREDITATION_SD_CLAIM': ('A claim value does not have the documented shape or bounds.',
                               'Read describe() for each claim\'s shape.', False),
    'ACCREDITATION_STATUS_REFERENCE': ('The status reference is not {"status_list": {"idx", "uri"}}.',
                                       'Allocate a list index before issuing.', False),
}

# What happened, then what to do, for each code raised here that agent_accreditation.REMEDIATION does not
# explain: the plain-text form tools/production_readiness.py reads. ERRORS keeps the retry hints.
REMEDIATION = {
    'ACCREDITATION_SD_FORMAT':
        'The presentation is not an SD-JWT with disclosures and a key-binding JWT. Send the presentation '
        'exactly as the holder produced it.',
    'ACCREDITATION_STATUS_REFERENCE':
        'The status reference is not {"status_list": {"idx", "uri"}}. Allocate a list index before issuing.',
    'ACCREDITATION_SD_CLAIM':
        "A claim value does not have the documented shape or bounds. Read describe() for each claim's shape.",
    'ACCREDITATION_DISCLOSURE':
        'A disclosure is unknown, repeated, malformed or not among the issuer-signed digests. Present only '
        'disclosures the issuer produced, once each.',
    'ACCREDITATION_TEST_ISSUER':
        'The credential comes from a TEST issuer. Test credentials are synthetic; accept them only under an '
        'explicit test check.',
    'ACCREDITATION_SD_SIZE':
        'The presentation or one disclosure is larger than the bound. Keep presentations under 96 KiB and '
        'each disclosure under 24 KiB.',
    'ACCREDITATION_CLAIM_WITHHELD':
        "A claim the relying party's policy or requirement checks was not disclosed. Disclose the named "
        'claims, or decline the request.',
    'ACCREDITATION_KEY_VERSION_WITHDRAWN':
        'The issuer withdrew the key version that signed this credential. Ask the holder for a credential '
        're-issued under a current key.',
}


def explain(code):
    row = ERRORS.get(code)
    if row is None:
        return status_lists_check.explain(code)
    happened, fix, retry = row
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/AGENT_ACCREDITATION.html#' + code}


def credential_id(credential):
    """The 64-hex id a map snapshot uses for this credential: SHA-256 of the issuer-signed JWT."""
    token = credential['sd_jwt'] if type(credential) is dict else credential
    need(type(token) is str and token.isascii() and token.count('.') == 2, 'ACCREDITATION_SD_FORMAT')
    return hashlib.sha256(token.encode('ascii')).hexdigest()


def status_reference(index, list_uri):
    need(type(index) is int and 0 <= index < lists.MAX_ENTRIES, 'ACCREDITATION_STATUS_REFERENCE')
    lists.uri(list_uri, 'ACCREDITATION_STATUS_REFERENCE')
    return {'status_list': {'idx': index, 'uri': list_uri}}


def _status_reference(value):
    need(type(value) is dict and set(value) == {'status_list'} and type(value['status_list']) is dict
         and set(value['status_list']) == {'idx', 'uri'}, 'ACCREDITATION_STATUS_REFERENCE')
    return status_reference(value['status_list']['idx'], value['status_list']['uri'])


# Claims /0.1 lacks, each bounded.

def _text(value, maximum=256):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value),
         'ACCREDITATION_SD_CLAIM')
    return value


def _texts(value, maximum_items, maximum=512):
    need(type(value) is list and len(value) <= maximum_items and len(set(value)) == len(value), 'ACCREDITATION_SD_CLAIM')
    for item in value:
        _text(item, maximum)
    return value


def _jurisdiction(value):
    need(type(value) is str and JURISDICTION.fullmatch(value) is not None, 'ACCREDITATION_SD_CLAIM')
    return value


def _details(value):
    """Type-specific details as flat data; market_accreditation gives them meaning per type."""
    need(type(value) is dict and 0 < len(value) <= 16, 'ACCREDITATION_SD_CLAIM')
    for name, item in value.items():
        need(type(name) is str and DETAIL_NAME.fullmatch(name) is not None, 'ACCREDITATION_SD_CLAIM')
        if type(item) is list:
            need(1 <= len(item) <= 32 and item == sorted(set(item)), 'ACCREDITATION_SD_CLAIM')
            for entry in item:
                _text(entry)
        elif type(item) is int:
            need(0 <= item <= 2**53 - 1, 'ACCREDITATION_SD_CLAIM')
        elif type(item) is not bool:
            _text(item)
    return value


def _evaluator(value):
    need(type(value) is dict and {'name', 'independent'} <= set(value) <= {'name', 'key', 'role', 'independent'}
         and type(value['independent']) is bool, 'ACCREDITATION_SD_CLAIM')
    _text(value['name'], 160)
    if value.get('key') is not None:
        verification_key(value['key'])
    if value.get('role') is not None:
        _text(value['role'], 160)
    return value


def _coverage(value):
    need(type(value) is dict and set(value) == {'domain', 'deployment', 'reliance', 'jurisdictions', 'limits'},
         'ACCREDITATION_SD_CLAIM')
    _text(value['domain'])
    if value['deployment'] is not None:
        _text(value['deployment'])
    _text(value['reliance'], 1024)
    places = value['jurisdictions']
    need(type(places) is list and len(places) <= 64 and places == sorted(set(places)), 'ACCREDITATION_SD_CLAIM')
    for place in places:
        _jurisdiction(place)
    limits = value['limits']
    need(type(limits) is dict and set(limits) == {'max_value', 'risk'}, 'ACCREDITATION_SD_CLAIM')
    money = limits['max_value']
    if money is not None:
        need(type(money) is dict and set(money) == {'amount', 'unit'} and type(money['amount']) is int
             and 0 < money['amount'] <= 2**53 - 1, 'ACCREDITATION_SD_CLAIM')
        _text(money['unit'], 32)
    need(limits['risk'] is None or limits['risk'] in RISKS, 'ACCREDITATION_SD_CLAIM')
    return value


def coverage(*, domain, reliance, jurisdictions=(), deployment=None, max_value=None, risk=None):
    """Where and for what the assessment holds: the limits actually assessed, nothing broader."""
    return _coverage({'domain': domain, 'deployment': deployment, 'reliance': reliance,
                      'jurisdictions': sorted(jurisdictions), 'limits': {'max_value': deepcopy(max_value), 'risk': risk}})


def _extensions(value):
    need(type(value) is dict and len(value) <= 16 and all(type(n) is str and n.startswith('x-') for n in value),
         'ACCREDITATION_SD_CLAIM')
    try:
        need(len(_wire(value)) <= MAX_EXTENSIONS, 'ACCREDITATION_SD_CLAIM')
    except ValueError:
        raise ValueError('ACCREDITATION_SD_CLAIM') from None
    return value


def _extra(name, value):
    if name == 'principal':
        need(type(value) is str and (DID.fullmatch(value) is not None or re.fullmatch(r'[0-9a-f]{64}', value) is not None),
             'ACCREDITATION_SD_CLAIM')
    elif name == 'details':
        _details(value)
    elif name == 'evaluator':
        _evaluator(value)
    elif name in ('assumptions', 'exclusions'):
        _texts(value, 16)
    elif name == 'conflicts':
        _texts(value, 8)
    elif name == 'coverage':
        _coverage(value)
    elif name == 'method':
        need(type(value) is str and METHOD.fullmatch(value) is not None, 'ACCREDITATION_SD_CLAIM')
    elif name == 'assessed_at':
        need(type(value) is int and 0 <= value <= 2**53 - 1, 'ACCREDITATION_SD_CLAIM')
    elif name == 'extensions':
        _extensions(value)
    else:
        raise ValueError('ACCREDITATION_DISCLOSURE')
    return value


def _base(name, value):
    """The /0.1 validators, unchanged: same claim, same meaning, same bounds."""
    if name in ('subject', 'profile', 'qualification'):
        accreditation._text(value)
    elif name in ('artifact', 'criteria'):
        key(value)
    elif name == 'scope':
        accreditation._strings(value)
    elif name == 'evidence':
        need(type(value) is list and len(value) <= 32 and value == sorted(set(value)), 'ACCREDITATION_EVIDENCE')
        for item in value:
            key(item)
    else:
        need(type(value) is str and value in ('PASS', 'FAIL', 'INCOMPLETE'), 'ACCREDITATION_OUTCOME')
    return value


def _claim(name, value):
    return _base(name, value) if name in BASE else _extra(name, value)


def issue(issuer_private, *, issuer, key_version, subject, holder_key, artifact, profile, qualification, scope,
          criteria, evidence, issued_at, not_before, expires_at, status, outcome='PASS', extra=None, test=False):
    """Owner-side issuer signing: the /0.1 claims plus optional extras, each salted for selective disclosure."""
    lists.issuer_name(issuer, 'ACCREDITATION_TEXT')
    verification_key(holder_key)
    body = dict(version=accreditation.VERSION, issuer=issuer, issuer_key=public_key(issuer_private),
                key_version=key_version, subject=subject, holder_key=holder_key, artifact=artifact, profile=profile,
                qualification=qualification, scope=deepcopy(scope), criteria=criteria, evidence=deepcopy(evidence),
                outcome=outcome, issued_at=issued_at, not_before=not_before, expires_at=expires_at,
                nonce=os.urandom(32).hex())
    accreditation._credential(body)
    status = _status_reference(status)
    need(type(test) is bool and test == issuer.startswith(TEST_PREFIX), 'ACCREDITATION_TEST_ISSUER')
    extra = {} if extra is None else extra
    need(type(extra) is dict and set(extra) <= set(EXTRA), 'ACCREDITATION_DISCLOSURE')
    rows = [[name, deepcopy(body[name])] for name in BASE]
    rows += [[name, deepcopy(_extra(name, extra[name]))] for name in EXTRA if name in extra]
    disclosures = [_b64(_wire([_b64(os.urandom(SALT_BYTES)), name, value])) for name, value in rows]
    need(all(len(item) <= MAX_DISCLOSURE for item in disclosures), 'ACCREDITATION_SD_SIZE')
    digests = [_disclosure_digest(item) for item in disclosures]
    # Decoys hide how many claims this credential carries (RFC 9901 section 4.2.5).
    digests += [_b64(hashlib.sha256(os.urandom(32)).digest()) for _ in range(DIGEST_SLOTS - len(digests))]
    payload = {'iss': issuer, 'iat': issued_at, 'nbf': not_before, 'exp': expires_at, 'vct': VCT,
               'cnf': {'jwk': _jwk(holder_key)}, 'status': status, 'aap_key_version': key_version,
               'aap_profile': VERSION, 'aap_test': test, '_sd': sorted(digests), '_sd_alg': SD_ALG}
    token = _jws(issuer_private, {'alg': 'EdDSA', 'typ': TYP}, payload)
    return {'version': VERSION, 'holder_key': holder_key, 'sd_jwt': token, 'disclosures': disclosures,
            'credential_id': credential_id(token), 'issuer': issuer, 'key_version': key_version,
            'status': deepcopy(status), 'test': test, 'execution_authorized': False}


def present(credential, holder_private, *, disclose, audience, nonce, now):
    """Holder side: reveal only the named claims, bound to the relying party's audience and challenge."""
    need(type(credential) is dict and {'holder_key', 'sd_jwt', 'disclosures'} <= set(credential), 'ACCREDITATION_SD_FORMAT')
    need(public_key(holder_private) == credential['holder_key'], 'ACCREDITATION_HOLDER')
    need(type(disclose) in (list, tuple) and len(set(disclose)) == len(disclose) and set(disclose) <= set(CLAIMS),
         'ACCREDITATION_DISCLOSURE')
    accreditation._text(audience); accreditation._text(nonce, 256); integer(now)
    chosen = []
    need(type(credential['disclosures']) is list and len(credential['disclosures']) <= DIGEST_SLOTS, 'ACCREDITATION_SD_FORMAT')
    for item in credential['disclosures']:
        row = _json(_unb64(item, MAX_DISCLOSURE))
        need(type(row) is list and len(row) == 3 and type(row[1]) is str, 'ACCREDITATION_SD_FORMAT')
        if row[1] in disclose:
            chosen.append(item)
    need(len(chosen) == len(disclose), 'ACCREDITATION_CLAIM_WITHHELD')
    issued = credential['sd_jwt'] + '~' + ''.join(item + '~' for item in chosen)
    sd_hash = _b64(hashlib.sha256(issued.encode('ascii')).digest())
    return issued + _jws(holder_private, {'alg': 'EdDSA', 'typ': KB_TYP},
                         {'iat': now, 'aud': audience, 'nonce': nonce, 'sd_hash': sd_hash})


def _split(presentation):
    need(type(presentation) is str and presentation.isascii(), 'ACCREDITATION_SD_FORMAT')
    need(0 < len(presentation) <= MAX_PRESENTATION, 'ACCREDITATION_SD_SIZE')
    parts = presentation.split('~')
    need(len(parts) >= 2 and parts[-1] != '' and all(parts[1:-1]), 'ACCREDITATION_SD_FORMAT')
    return parts[0], parts[1:-1], parts[-1]


def peek(presentation):
    """Unverified issuer, key version and TEST flag, only to choose the pinned key. Never a result."""
    issuer_jwt, _, _ = _split(presentation)
    try:
        payload = _json(_unb64(issuer_jwt.split('.')[1]))
    except (ValueError, IndexError):
        raise ValueError('ACCREDITATION_SD_FORMAT') from None
    need(type(payload) is dict and type(payload.get('iss')) is str and type(payload.get('aap_key_version')) is str,
         'ACCREDITATION_SD_FORMAT')
    return {'issuer': payload['iss'], 'key_version': payload['aap_key_version'], 'test': payload.get('aap_test') is True}


def _open(presentation, accepted, *, nonce, now, accept_test, require):
    accreditation._policy(accepted); accreditation._text(nonce, 256); integer(now)
    need(type(require) in (list, tuple) and set(require) <= set(CLAIMS), 'ACCREDITATION_DISCLOSURE')
    seen = peek(presentation)
    issuer_jwt, disclosures, bound = _split(presentation)
    issuers = accepted['issuers']
    need(seen['issuer'] in issuers and seen['key_version'] in issuers[seen['issuer']], 'ACCREDITATION_ISSUER_NOT_ADOPTED')
    try:
        payload = _open_jws(issuer_jwt, issuers[seen['issuer']][seen['key_version']], TYP)
    except ValueError as error:
        raise ValueError('SIGNATURE' if str(error) == 'CREDENTIAL_SIGNATURE' else 'ACCREDITATION_SD_FORMAT') from None
    need(set(payload) == PAYLOAD and payload['vct'] == VCT and payload['aap_profile'] == VERSION
         and payload['_sd_alg'] == SD_ALG, 'ACCREDITATION_SD_FORMAT')
    need(payload['iss'] == seen['issuer'] and payload['aap_key_version'] == seen['key_version'], 'ACCREDITATION_SD_FORMAT')
    need(type(payload['aap_test']) is bool and payload['aap_test'] == payload['iss'].startswith(TEST_PREFIX),
         'ACCREDITATION_SD_FORMAT')
    need(accept_test or not payload['aap_test'], 'ACCREDITATION_TEST_ISSUER')
    for name in ('iat', 'nbf', 'exp'):
        integer(payload[name])
    need(payload['iat'] <= payload['nbf'] < payload['exp'] and payload['exp'] - payload['iat'] <= accreditation.MAX_LIFETIME,
         'ACCREDITATION_VALIDITY')
    need(payload['nbf'] <= now < payload['exp'], 'ACCREDITATION_EXPIRED')
    reference = _status_reference(payload['status'])
    need(type(payload['cnf']) is dict and set(payload['cnf']) == {'jwk'}, 'ACCREDITATION_HOLDER')
    try:
        holder = _jwk_public(payload['cnf']['jwk'])
    except ValueError:
        raise ValueError('ACCREDITATION_HOLDER') from None
    sd = payload['_sd']
    need(type(sd) is list and len(sd) == DIGEST_SLOTS and len(set(sd)) == DIGEST_SLOTS
         and all(type(value) is str and len(value) == 43 for value in sd), 'ACCREDITATION_SD_FORMAT')
    # The holder signed this issuer JWT plus exactly these disclosures, for this audience and challenge.
    issued = issuer_jwt + '~' + ''.join(item + '~' for item in disclosures)
    try:
        holder_body = _open_jws(bound, holder, KB_TYP)
    except ValueError:
        raise ValueError('ACCREDITATION_PRESENTATION_BINDING') from None
    need(set(holder_body) == {'iat', 'aud', 'nonce', 'sd_hash'}, 'ACCREDITATION_PRESENTATION_BINDING')
    need(holder_body['aud'] == accepted['audience'] and type(holder_body['nonce']) is str
         and holder_body['nonce'].isascii()
         and hmac.compare_digest(holder_body['nonce'].encode('ascii'), nonce.encode('ascii')), 'ACCREDITATION_CHALLENGE')
    integer(holder_body['iat'])
    need(holder_body['iat'] <= now and now - holder_body['iat'] <= accepted['maximum_presentation_age'],
         'ACCREDITATION_PRESENTATION_STALE')
    need(holder_body['sd_hash'] == _b64(hashlib.sha256(issued.encode('ascii')).digest()),
         'ACCREDITATION_PRESENTATION_BINDING')
    claims, hashes = {}, set()
    for item in disclosures:
        need(len(item) <= MAX_DISCLOSURE, 'ACCREDITATION_SD_SIZE')
        hashed = _disclosure_digest(item)
        need(hashed in sd and hashed not in hashes, 'ACCREDITATION_DISCLOSURE')
        hashes.add(hashed)
        try:
            row = _json(_unb64(item, MAX_DISCLOSURE))
        except ValueError:
            raise ValueError('ACCREDITATION_DISCLOSURE') from None
        need(type(row) is list and len(row) == 3 and type(row[0]) is str and len(row[0]) >= 22
             and row[1] in CLAIMS and row[1] not in claims, 'ACCREDITATION_DISCLOSURE')
        claims[row[1]] = _claim(row[1], row[2])
    needed = set(POLICY_CLAIMS) | set(require) | ({'criteria'} if accepted.get('criteria') is not None else set())
    need(needed <= set(claims), 'ACCREDITATION_CLAIM_WITHHELD')
    need(claims['artifact'] == accepted['artifact'] and claims['profile'] == accepted['profile']
         and claims['qualification'] == accepted['qualification']
         and set(accepted['scope']).issubset(claims['scope']), 'ACCREDITATION_SCOPE_MISMATCH')
    need(accepted.get('criteria') is None or claims['criteria'] == accepted['criteria'], 'ACCREDITATION_CRITERIA_MISMATCH')
    return payload, claims, holder, reference, credential_id(issuer_jwt)


def _map_status(snapshot, accepted, payload, cid, now, known=()):
    sid = accreditation.status_id(snapshot); body = snapshot['status']
    accreditation._adopted(body['issuer'], body['key_version'], body['issuer_key'], accepted)
    need(body['issuer'] == payload['iss'], 'ACCREDITATION_STATUS_ISSUER')
    need(body['issued_at'] <= now < body['expires_at'] and now - body['issued_at'] <= accepted['maximum_status_age'],
         'ACCREDITATION_STATUS_STALE')
    need(body['issued_at'] >= payload['iat'], 'ACCREDITATION_STATUS_PREDATES_CREDENTIAL')
    status = 'REVOKED' if cid in known else body['entries'].get(cid, 'UNKNOWN')
    return {'status': status, 'status_format': 'COVENANT_STATUS_MAP', 'status_snapshot': sid,
            'status_sequence': body['sequence'], 'status_as_of': body['issued_at'], 'status_expires_at': body['expires_at'],
            'status_label': accreditation.status_label(body['issued_at'], now)}


def _list_status(evidence, accepted, payload, reference, now, known=()):
    opened = status_lists_check.open_snapshot(evidence, accepted, list_uri=reference['status_list']['uri'])
    need(opened['issuer'] == payload['iss'], 'ACCREDITATION_STATUS_ISSUER')
    assessed = status_lists_check.assess(opened, reference['status_list']['idx'], accepted, now=now,
                                         credential_key_version=payload['aap_key_version'], known_revoked=known)
    need(assessed['status'] != 'REVOKED', 'ACCREDITATION_STATUS_REVOKED')
    need(assessed['status'] != 'KEY_VERSION_WITHDRAWN', 'ACCREDITATION_KEY_VERSION_WITHDRAWN')
    need(assessed['freshness'] == 'FRESH', 'ACCREDITATION_STATUS_STALE')
    need(opened['issued_at'] >= payload['iat'], 'ACCREDITATION_STATUS_PREDATES_CREDENTIAL')
    return {'status': assessed['status'], 'status_format': opened['format'], 'status_snapshot': opened['id'],
            'status_sequence': opened['snapshot']['sequence'], 'status_as_of': opened['issued_at'],
            'status_expires_at': opened['expires'], 'status_label': assessed['label'],
            'status_index': reference['status_list']['idx'], 'status_list': opened['list']}


def _is_map(evidence):
    return type(evidence) is dict and set(evidence) == {'status', 'signature'}


def _result(payload, claims, holder, cid, state, accepted, offline):
    extras = {name: deepcopy(claims[name]) for name in EXTRA if name in claims and name != 'extensions'}
    return dict(version=VERSION, form='SD-JWT VC', accepted=False, credential=cid, issuer=payload['iss'],
                key_version=payload['aap_key_version'], holder_key=holder, subject=claims.get('subject'),
                artifact=claims['artifact'], profile=claims['profile'], qualification=claims['qualification'],
                scope=deepcopy(accepted['scope']), outcome=claims['outcome'], criteria=claims.get('criteria'),
                evidence=deepcopy(claims.get('evidence')), criteria_checked=accepted.get('criteria') is not None,
                disclosed=sorted(claims), withheld_digests=DIGEST_SLOTS - len(claims), claims=extras,
                extensions=deepcopy(claims.get('extensions', {})), extensions_effect='NONE; UNTRUSTED_DATA_CARRIED_INERT',
                **state, offline=offline, test=payload['aap_test'], issued_at=payload['iat'],
                current_global_status='NOT_ESTABLISHED', authority_verified=False, execution_authorized=False,
                identity_verified=False, funds_verified=False, external_accreditation=False, replay_checked=False,
                assurance='PINNED_ISSUER_SELECTIVELY_DISCLOSED_CLAIMS_AGAINST_ADOPTED_SNAPSHOT')


def inspect_presentation(presentation, accepted, *, nonce, now, status, offline=False, require=(), accept_test=False):
    """Read-only check, without replay or rollback protection (as agent_accreditation.inspect_presentation)."""
    need(type(offline) is bool, 'ACCREDITATION_OFFLINE')
    payload, claims, holder, reference, cid = _open(presentation, accepted, nonce=nonce, now=now,
                                                    accept_test=accept_test, require=require)
    state = (_map_status(status, accepted, payload, cid, now) if _is_map(status)
             else _list_status(status, accepted, payload, reference, now))
    need(state['status'] == 'ACTIVE', 'ACCREDITATION_STATUS_' + state['status'])
    need(claims['outcome'] == 'PASS', 'ACCREDITATION_NOT_PASSED')
    result = _result(payload, claims, holder, cid, state, accepted, offline)
    result['accepted'] = True
    result['replay_or_rollback_protection'] = 'NOT_CHECKED_USE_OWNER_VERIFIER_STORE'
    return result


def verify_presentation(presentation, accepted, *, nonce, now, status, store, offline=False, require=(),
                        accept_test=False):
    """Retain the status first, then check and consume the challenge once in the owner's VerifierStore."""
    need(isinstance(store, accreditation.VerifierStore), 'ACCREDITATION_VERIFIER_STORE_REQUIRED')
    need(type(offline) is bool, 'ACCREDITATION_OFFLINE')
    accreditation._policy(accepted)
    need(store.audience == accepted['audience'], 'ACCREDITATION_STORE_AUDIENCE')
    if _is_map(status):
        accreditation.adopt_status(status, accepted, now=now, store=store)
        with store._lock:
            known = store._state['snapshots'].get(status['status']['issuer'], {}).get('revoked', [])
    else:
        opened = status_lists_check.open_snapshot(status, accepted)
        known = status_lists_check.adopt(opened, accepted, now=now, store=store)['revoked']
    payload, claims, holder, reference, cid = _open(presentation, accepted, nonce=nonce, now=now,
                                                    accept_test=accept_test, require=require)
    state = (_map_status(status, accepted, payload, cid, now, known) if _is_map(status)
             else _list_status(status, accepted, payload, reference, now, known))
    with store._lock:
        need(not store._closed, 'ACCREDITATION_STORE_CLOSED')
        need(state['status'] == 'ACTIVE', 'ACCREDITATION_STATUS_' + state['status'])
        need(claims['outcome'] == 'PASS', 'ACCREDITATION_NOT_PASSED')
        challenge = digest(accreditation.HOLDER_LABEL, {'audience': accepted['audience'], 'nonce': nonce})
        need(challenge not in store._state['consumed'], 'ACCREDITATION_PRESENTATION_REPLAY')
        need(len(store._state['consumed']) < accreditation.MAX_CONSUMED, 'ACCREDITATION_STORE_QUOTA')
        need(now >= store._state['last_now'], 'ACCREDITATION_CLOCK_ROLLBACK')
        store._state['consumed'][challenge] = now
        store._state['last_now'] = now
        store._file.save(store._state)
    result = _result(payload, claims, holder, cid, state, accepted, offline)
    result.update(accepted=True, replay_checked=True, verifier_checkpoint=store.checkpoint(),
                  replay_or_rollback_protection='DURABLE_LOCAL_STATE_RETAIN_EXTERNAL_CHECKPOINT_FOR_FULL_RESTORE_DETECTION')
    return result


def describe():
    return {'version': VERSION, 'extends': accreditation.VERSION, 'vct': VCT,
            'format': 'SD-JWT VC (draft-ietf-oauth-sd-jwt-vc-22; RFC 9901) with a Key Binding JWT, EdDSA',
            'always_visible': sorted(PAYLOAD - {'_sd', '_sd_alg'}), 'disclosable': list(CLAIMS),
            'claims_of_0_1': list(BASE), 'claims_added': list(EXTRA), 'policy_requires_disclosed': list(POLICY_CLAIMS),
            'policy': 'covenant-agent-accreditation-policy/0.2 (or /0.1), unchanged',
            'status': ['covenant-agent-accreditation-status/0.1 map snapshot by credential id',
                       'Token Status List or W3C pair by index (accreditation_status)'],
            'store': 'agent_accreditation.VerifierStore; challenges shared with /0.1 presentations',
            'privacy': 'SELECTIVE_DISCLOSURE_NOT_ANONYMITY; ISSUER_HOLDER_KEY_AND_STATUS_INDEX_VISIBLE',
            'limits': {'presentation_characters': MAX_PRESENTATION, 'disclosure_characters': MAX_DISCLOSURE,
                       'digest_slots': DIGEST_SLOTS, 'lifetime_seconds': accreditation.MAX_LIFETIME},
            'test_issuers': 'issuer names starting ' + TEST_PREFIX + ' carry aap_test true and refuse unless accepted',
            'network_accessed': False, 'execution_authorized': False}
