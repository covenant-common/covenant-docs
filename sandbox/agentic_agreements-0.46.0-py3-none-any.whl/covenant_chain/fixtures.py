"""Fresh-key local fixtures, not production genesis authority."""
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from .crypto import public_key,digest
from .app import VERSION

def fresh_fixture(protocol=VERSION):
    names=['owner','agent','worker','resolver','appeal','executor','stranger','v0','v1','v2','v3']
    keys={n:Ed25519PrivateKey.generate() for n in names};pubs={n:public_key(k) for n,k in keys.items()}
    genesis={'protocol':protocol,'name':'Covenant commitment devnet','validators':{n:pubs[n] for n in ['v0','v1','v2','v3']},'faults':1,'accounts':{pubs['owner']:{'compute':100,'data':10,'instrument':1,'payment':100}},'resources':{n:{'unit':u} for n,u in [('compute','compute-unit'),('data','access-ticket'),('instrument','exclusive-session'),('payment','test-payment-unit')]},'profiles':{'task-v1':{'description':'Exact bilateral terms; evidence; independent resolver and appeal; ledger-height deadlines.'}}}
    return keys,pubs,genesis

def economy_fixture():
    """Synthetic, disposable units and keys; not production economics."""
    from .app import ECONOMIC_VERSION
    from .economics import VERSION as ECONOMICS
    keys,pubs,g=fresh_fixture(ECONOMIC_VERSION)
    g['shielded']={};g['sources']={}
    g['accounts']={pubs['owner']:{'payment':1000000,'compute':100,'data':10,'instrument':1}}
    policy={'version':ECONOMICS,'resource':'payment','base_fee':3,'per_kib':1,'work_fees':{},
            'beneficiaries':[{'account':pubs[n],'bps':bps,'purpose':purpose} for n,bps,purpose in
                            [('v0',4000,'operators'),('v1',3000,'archives'),('v2',2000,'maintenance'),('v3',1000,'founder')]],
            'governors':[pubs['owner']],'threshold':1,'change_delay':5}
    g['economics']={'fee_policy':policy}
    return keys,pubs,g

def terms(p,chain,grant=None,resource='compute',quantity=10,effect='CONSUME',deadline=10000,description='Compute job'):
    return {'chain':chain,'principal':p['owner'],'agent':p['agent'] if grant else p['owner'],'counterparty':p['worker'],'mandate':grant,'profile':'task-v1','resource':resource,'quantity':quantity,'effect':effect,'destination':'sandbox:'+resource,'executor':p['executor'],'resolver':p['resolver'],'appeal_resolver':p['appeal'],'deadline':deadline,'challenge_blocks':2,'timeout':'HOLD_FOR_RESOLUTION','terms_hash':digest('COVENANT-DEV-TERMS',{'description':description})}


def confidential_fixture():
    """Test-only confidential compute allocation domain, never production keys."""
    from . import app, shielded, confidential
    keys,pubs,g=economy_fixture()
    g['protocol']=app.CONFIDENTIAL_VERSION
    g['accounts'][pubs['owner']]['compute']=1000000
    g['economics']['fee_policy']['resource']='compute'
    g['shielded']={'compute':shielded.descriptor()}
    g['confidential']={'compute':confidential.descriptor()}
    g['confidential_admission']={'compute':{'funders':[pubs['owner']], 'reserved_limit':1024}}
    return keys,pubs,g


def market_fixture():
    """Fresh keys and imaginary COV units; no supply/price recommendation."""
    from . import app,continuity,defense,market
    keys,pubs,g=economy_fixture();g.update(protocol=app.MARKET_VERSION,confidential={},confidential_admission={})
    g['resources']['COV']={'unit':'disposable-sandbox-service-bond'}
    for name in ('owner','worker','resolver','appeal','agent','stranger'):
        g['accounts'][pubs[name]]={'payment':1000000,'COV':100000,'compute':1000}
    secrets={};policies={}
    for name in ('owner','resolver','worker'):
        pk,sk=defense.keypair();secrets[name]={'guardian':sk}
        policies[pubs[name]]=continuity.make_policy(pubs[name],{'guardian':{'suite':defense.HASH,'key':pk.hex()}})
    g['continuity']={'version':continuity.VERSION,'policies':policies}
    reserve=digest('COVENANT-SANDBOX-RESERVE',pubs['owner'])
    p=g['economics']['fee_policy'];p['version']='covenant-economics/0.2'
    p['beneficiaries']=[{'account':reserve,'bps':4000,'purpose':'MAINTENANCE'},
        {'account':reserve,'bps':4000,'purpose':'SERVICE_REWARDS'},{'account':pubs['v0'],'bps':2000,'purpose':'OPERATORS'}]
    g['market']={'version':market.VERSION,
        'governance':{'founder':pubs['owner'],'council':[pubs['resolver']],'threshold':1,'notice':2,'lifetime':1000},
        'pricing':{'target_work':100,'target_kib':96,'max_work':10000,'max_kib':768,'step_bps':1000,
            'min_bps':1000,'max_bps':100000,'smoothing':4,'work_units':{'CONFIDENTIAL_CLAIM':250,'CONFIDENTIAL_TRANSFER':250}},
        'reserve':{'resource':'payment','account':reserve,'floor':1000,'initial':5000,'source':pubs['owner'],
            'epoch_length':100,'epoch_budget':2000,'recovery_bps':12000},
        'staking':{'resource':'COV','reward_resource':'payment','min_term':3,'max_term':1000,'exit_delay':3,'reward_delay':2,
            'slash_bps':1000,'reward_bps':1000,'max_reward':1000}}
    return keys,pubs,g,secrets


def review_fixture():
    """Disposable panel actors; distinct keys do not prove real independence."""
    from .app import REVIEW_VERSION
    keys,pubs,g,secrets=market_fixture();g['protocol']=REVIEW_VERSION
    for n in ('j0','j1','j2','a0','a1','a2','claim_adv','def_adv'):
        keys[n]=Ed25519PrivateKey.generate();pubs[n]=public_key(keys[n])
        g['accounts'][pubs[n]]={'payment':100000,'compute':10}
    return keys,pubs,g,secrets


def prediction_fixture():
    """Disposable prediction domain; never production economics or panel identity."""
    from .app import PREDICTION_VERSION
    keys,pubs,g,secrets=review_fixture();g['protocol']=PREDICTION_VERSION
    return keys,pubs,g,secrets


def ensure_founder_quorum(g, secrets, role='owner', guardian='backup-guardian'):
    """Give a 0.15 founder a second guardian so the veto key is not the quorum.

    ``backup-guardian`` satisfies the separation check without arming the five
    resolution rules. ``arm_veto_separation`` uses the name ``veto-guardian``,
    which is the mark those rules look for.
    """
    from . import continuity, defense
    entity = g['market']['governance']['founder']
    policy = g['continuity']['policies'][entity]
    guardians = dict(policy.get('guardians') or {})
    if policy.get('threshold', 1) >= 2 and len(guardians) >= 2:
        return g, secrets
    public, secret = defense.keypair()
    guardians[guardian] = {'suite': defense.HASH, 'key': public.hex()}
    policy['guardians'] = guardians
    policy['threshold'] = 2
    continuity.validate_policy(policy, entity)
    secrets[role] = dict(secrets[role])
    secrets[role][guardian] = secret
    return g, secrets


def arm_veto_separation(g, secrets, role='owner'):
    """Arm native 0.15 resolution rules by naming the second guardian veto-guardian."""
    return ensure_founder_quorum(g, secrets, role=role, guardian='veto-guardian')


def resolution_fixture():
    """Same disposable domain pinned to native 0.15. 0.14 fixtures stay 0.14."""
    from .app import RESOLUTION_VERSION
    keys, pubs, g, secrets = prediction_fixture()
    g['protocol'] = RESOLUTION_VERSION
    arm_veto_separation(g, secrets)
    return keys, pubs, g, secrets
