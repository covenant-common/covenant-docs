"""Owner-only reference replication transport and failover SDK.

Peer listener is literal loopback HTTP behind an owner trust boundary, with a
required 256-bit bearer secret. It is not a public production peer transport.
The client additionally supports independently configured HTTPS owner proxies.
Full-history proofs contain all accounts' raw command records. Never expose
these endpoints or credentials to a party entitled to only one account's data.
"""
from collections import deque, OrderedDict
from copy import deepcopy
import base64
import hmac
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.client import HTTPConnection
import ipaddress
import re
import secrets
import socket
import threading
import time
from urllib.parse import urlsplit
import urllib.request

from . import crypto as c
from . import observability
from . import resource_provider as p
from . import provider_replication as r
from .agent_tools import decode
from .connector_harness import ConnectorHarness
from .workflow_store import WorkflowStore, canonical, identifier

MAX_RPC = 700000
MAX_CONNECTIONS = 32
MAX_CONNECTION_SECONDS = 3


class _BoundedServer(ThreadingHTTPServer):
    """Bound accepted workers; shutdown interrupts reads and drains workers."""
    daemon_threads = False
    request_queue_size = 2*MAX_CONNECTIONS

    def __init__(self,address,handler,limit=MAX_CONNECTIONS):
        self._slots = threading.BoundedSemaphore(limit)
        self._active = set(); self._active_lock = threading.Lock()
        super().__init__(address,handler)

    def process_request(self,request,client_address):
        if not self._slots.acquire(blocking=False):
            self.shutdown_request(request); return
        with self._active_lock: self._active.add(request)
        try: super().process_request(request,client_address)
        except BaseException:
            with self._active_lock: self._active.discard(request)
            self._slots.release(); raise

    def process_request_thread(self,request,client_address):
        try: super().process_request_thread(request,client_address)
        finally:
            with self._active_lock: self._active.discard(request)
            self._slots.release()

    def server_close(self):
        # serve_forever is stopped first by ReplicaService.close. Closing each
        # accepted socket wakes stalled header/body reads before worker joins.
        with self._active_lock: active = tuple(self._active)
        for request in active:
            try: request.shutdown(socket.SHUT_RDWR)
            except OSError: pass
        super().server_close()


def _token(token):
    c.need(type(token) is str and re.fullmatch('[0-9a-f]{64}',token), 'REPLICA_OWNER_TOKEN')


HOST_SCOPES = ('command', 'history', 'message')
HOST_ROUTES = {'/replica/history': 'history', '/replica/message': 'message', '/replica/command': 'command'}


class _TokenBucket:
    """Per-token admission. Membership is the configured host map, not the caller population."""
    def __init__(self, rate, burst):
        self.rate, self.burst = rate, burst
        self.tokens = float(burst)
        self.updated = time.monotonic()

    def take(self):
        now = time.monotonic()
        self.tokens = min(self.burst, self.tokens + max(0, now - self.updated) * self.rate)
        self.updated = now
        if self.tokens < 1: return False
        self.tokens -= 1
        return True


def _host_record(record):
    c.exact(record, 'host scopes rate burst')
    c.need(type(record['host']) is str and 0 < len(record['host']) <= 80, 'REPLICA_HOST')
    scopes = record['scopes']
    c.need(type(scopes) is list and bool(scopes) and scopes == sorted(set(scopes)) and set(scopes) <= set(HOST_SCOPES), 'REPLICA_HOST_SCOPE')
    c.integer(record['rate']); c.integer(record['burst'])
    c.need(record['rate'] <= 1000 and record['burst'] <= 1000, 'REPLICA_HOST_RATE')
    return {'host': record['host'], 'scopes': list(scopes), 'rate': record['rate'], 'burst': record['burst']}


def _host_tokens(value, owner, account_tokens):
    """Scoped bearers for one replica process. Not a ledger object."""
    if value is None: return {}
    c.need(type(value) is dict and len(value) <= 32, 'REPLICA_HOST_TOKENS')
    out = {}
    for token, record in value.items():
        _token(token)
        c.need(token != owner and token not in account_tokens, 'REPLICA_HOST_TOKENS')
        out[token] = _host_record(record)
    c.need(len({item['host'] for item in out.values()}) == len(out), 'REPLICA_HOST')
    return out


def peer_bearer(token, tokens, name):
    """The historical single bearer, or that peer's own host token when a map is supplied."""
    if tokens is None: return token
    c.need(type(tokens) is dict and name in tokens, 'REPLICA_HOST_TOKENS')
    _token(tokens[name])
    return tokens[name]


def _endpoint(endpoint, insecure=False):
    c.need(type(endpoint) is str, 'REPLICA_ENDPOINT')
    u = urlsplit(endpoint)
    c.need(u.path == '/replica' and u.hostname and not u.username and not u.password and
           not u.query and not u.fragment, 'REPLICA_ENDPOINT')
    if u.scheme != 'https':
        try: local = ipaddress.ip_address(u.hostname).is_loopback
        except ValueError: local = False
        c.need(insecure is True and u.scheme == 'http' and local, 'REPLICA_HTTPS_REQUIRED')
    return u


class ReplicaService:
    """Reference loopback service. Each peer must have its own live replica,
    directory and validator key. No private key or partition-control RPC exists.
    Peers are pinned literal loopback URLs; remote deployment needs an adopted
    authenticated transport and independently operated storage/keys.
    """
    def __init__(self, replica, *, peers, token, port=0, account_tokens=None, host_tokens=None):
        _token(token); c.need(type(peers) is dict and set(peers) <= set(replica.spec['validators']), 'REPLICA_PEERS')
        for endpoint in peers.values():
            u = _endpoint(endpoint,True)
            c.need(u.scheme == 'http' and ipaddress.ip_address(u.hostname).is_loopback, 'REPLICA_LOOPBACK_PEERS')
        self.replica = replica; self.peers = dict(peers); self.token = token
        self.account_tokens = {}
        if account_tokens is not None:
            c.need(hasattr(replica,'rpc_command') and type(account_tokens) is dict and len(account_tokens)<=128,'PRIVATE_PROVIDER_ACCOUNT_TOKENS')
            for account_token,wallet in account_tokens.items():
                _token(account_token); c.key(wallet)
                c.need(account_token != token and wallet in replica.spec['provider']['accounts'],'PRIVATE_PROVIDER_ACCOUNT_TOKENS')
            self.account_tokens = dict(account_tokens)
        self.host_tokens = _host_tokens(host_tokens, token, self.account_tokens)
        self.host_buckets = {secret: _TokenBucket(record['rate'], record['burst']) for secret, record in self.host_tokens.items()}
        self.host_lock = threading.Lock()
        self.stopping = threading.Event(); self.threads = []; self.errors = deque(maxlen=32)
        self.blocked = set()  # in-process fixture/owner control; never an RPC
        self.queues = {member:deque() for member in peers}; self.queue_bytes = {member:0 for member in peers}
        self.queue_keys = {member:set() for member in peers}
        self.seen_messages = OrderedDict()
        self.queue_lock = threading.Lock(); service = self
        self.ops = observability.Ops('replica', routes=set(HOST_ROUTES) | {'/replica/command'})
        engine_failed = lambda: getattr(getattr(replica, 'engine', None), 'failed', False)
        self.ops.health.add('replica', lambda: not (getattr(replica, 'failed', False) or engine_failed()) or 'REPLICA_FAILED')
        self.ops.health.add('threads', lambda: (bool(self.threads) and all(t.is_alive() for t in self.threads)) or 'REPLICA_THREAD_STOPPED')
        self.ops.queue('peer_messages', lambda: sum(len(queue) for queue in list(self.queues.values())))
        self.ops.queue('pending_commands', lambda: len(getattr(replica, 'pending', ())))
        if getattr(replica, 'directory', None) is not None:
            self.ops.storage('replica', [replica.directory])
        self.ops.metrics.gauge('aap_replica_recent_errors', 'Exceptions retained in the bounded error window.',
                               fn=lambda: len(self.errors))
        class Handler(observability.Instrumented, BaseHTTPRequestHandler):
            ops = self.ops
            def setup(self):
                self.request.settimeout(1)
                super().setup()
                self._deadline = threading.Timer(MAX_CONNECTION_SECONDS,self.expire)
                self._deadline.daemon = True; self._deadline.start()
            def expire(self):
                try:self.request.shutdown(socket.SHUT_RDWR)
                except OSError:pass
            def finish(self):
                try:super().finish()
                finally:self._deadline.cancel()
            def log_message(self,*args): pass
            def reply(self,status,value):
                raw = canonical(value); c.need(len(raw) <= MAX_RPC, 'REPLICA_RPC_REPLY_LIMIT')
                try:
                    self.send_response(status); self.send_header('Content-Type','application/json')
                    self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store')
                    self.send_header('Connection','close'); self.end_headers(); self.wfile.write(raw)
                except OSError: pass
                self.close_connection = True
            def do_POST(self):
                try:
                    self.connection.settimeout(2)
                    auth = self.headers.get_all('Authorization',[])
                    c.need(len(auth) == 1,'REPLICA_OWNER_AUTH_REQUIRED')
                    owner = hmac.compare_digest(auth[0],'Bearer '+service.token)
                    wallet = next((account for secret,account in service.account_tokens.items()
                                   if hmac.compare_digest(auth[0],'Bearer '+secret)),None)
                    host_secret, host_record = service.match_host(auth[0])
                    c.need(owner or wallet is not None or host_record is not None,'REPLICA_OWNER_AUTH_REQUIRED')
                    if not owner and wallet is not None:
                        c.need(self.path == '/replica/command','PRIVATE_PROVIDER_ACCOUNT_SCOPE')
                    if not owner and wallet is None and host_record is not None:
                        c.need(HOST_ROUTES.get(self.path) in host_record['scopes'],'REPLICA_HOST_SCOPE')
                        # A host bearer is admission for this process. It is not the owner
                        # and it is not an account token, so it cannot present wallet=None
                        # to a private command.
                        c.need(self.path != '/replica/command' or not hasattr(service.replica,'rpc_command'),'PRIVATE_PROVIDER_ACCOUNT_SCOPE')
                        c.need(service.take_host(host_secret),'REPLICA_HOST_RATE')
                    c.need(self.headers.get_all('Host',[]) == ['127.0.0.1:'+str(service.server.server_port)], 'REPLICA_HTTP_HOST')
                    c.need(not any(self.headers.get(x) is not None for x in ('Origin','Transfer-Encoding','Expect')), 'REPLICA_HTTP_HEADERS')
                    c.need(self.headers.get_all('Content-Type',[]) == ['application/json'], 'REPLICA_HTTP_TYPE')
                    lengths = self.headers.get_all('Content-Length',[])
                    c.need(len(lengths) == 1 and re.fullmatch('[0-9]{1,6}',lengths[0]) and 0 < int(lengths[0]) <= MAX_RPC, 'REPLICA_HTTP_LENGTH')
                    size = int(lengths[0]); raw = self.rfile.read(size)
                    c.need(len(raw) == size, 'REPLICA_HTTP_INCOMPLETE'); value = decode(raw)
                    if self.path == '/replica/command':
                        result = service.replica.rpc_command(value,wallet=None if owner else wallet) if hasattr(service.replica,'rpc_command') else service.replica.submit(value)
                        self.reply(200 if result else 202,result or {'status':'PENDING_NOT_FINAL'})
                    elif self.path == '/replica/message':
                        service.ingest(value); self.reply(200,{'accepted':True})
                    elif self.path == '/replica/history':
                        c.exact(value,'start'); self.reply(200,{'history':service.replica.history(value['start'])})
                    else: raise ValueError('REPLICA_HTTP_ROUTE')
                except (ValueError,TypeError,KeyError,UnicodeError,RecursionError,OverflowError) as exc:
                    code = str(exc)
                    self.reply(400,{'error':code if re.fullmatch('(REPLICA|PROVIDER|PRIVATE_PROVIDER)_[A-Z_0-9]{1,80}',code) else 'REPLICA_REQUEST_REFUSED'})
                except Exception:
                    self.reply(503,{'error':'REPLICA_UNAVAILABLE'})
            def do_GET(self): self.reply(405,{'error':'REPLICA_POST_REQUIRED'})
        self.server = _BoundedServer(('127.0.0.1',port),Handler)
        self.server.timeout = .2
        self.endpoint = 'http://127.0.0.1:'+str(self.server.server_port)+'/replica'

    def configure_peers(self,peers):
        c.need(not self.threads, 'REPLICA_SERVICE_STARTED')
        c.need(type(peers) is dict and set(peers) <= set(self.replica.spec['validators']), 'REPLICA_PEERS')
        for endpoint in peers.values():
            u = _endpoint(endpoint,True)
            c.need(u.scheme == 'http' and ipaddress.ip_address(u.hostname).is_loopback,'REPLICA_LOOPBACK_PEERS')
        self.peers = dict(peers); self.queues = {who:deque() for who in peers}; self.queue_bytes = {who:0 for who in peers}
        self.queue_keys = {who:set() for who in peers}

    def set_account_tokens(self,account_tokens):
        """Explicit local owner rotation/revocation; never a network tool."""
        c.need(hasattr(self.replica,'rpc_command') and type(account_tokens) is dict and len(account_tokens)<=128,'PRIVATE_PROVIDER_ACCOUNT_TOKENS')
        for token,wallet in account_tokens.items():
            _token(token); c.key(wallet)
            c.need(token != self.token and wallet in self.replica.spec['provider']['accounts'],'PRIVATE_PROVIDER_ACCOUNT_TOKENS')
        self.account_tokens = dict(account_tokens)

    def match_host(self, authorization):
        for secret, record in self.host_tokens.items():
            if hmac.compare_digest(authorization, 'Bearer '+secret): return secret, record
        return None, None

    def take_host(self, secret):
        with self.host_lock: return self.host_buckets[secret].take()

    def set_host_tokens(self, host_tokens):
        """Local rotation or revocation of per-host bearers. Never a consensus operation."""
        parsed = _host_tokens(host_tokens, self.token, self.account_tokens)
        with self.host_lock:
            self.host_tokens = parsed
            self.host_buckets = {secret: _TokenBucket(record['rate'], record['burst']) for secret, record in parsed.items()}

    def rotate_host_token(self, host, scopes, rate=16, burst=32):
        """Drop every bearer for this host and install one replacement."""
        raw = secrets.token_hex(32)
        kept = {token: record for token, record in self.host_tokens.items() if record['host'] != host}
        kept[raw] = {'host': host, 'scopes': sorted(set(scopes)), 'rate': rate, 'burst': burst}
        self.set_host_tokens(kept)
        return raw

    def publish(self, messages):
        with self.queue_lock:
            for msg in messages:
                raw = canonical(msg)
                if len(raw) > MAX_RPC: continue
                for who,queue in self.queues.items():
                    if raw not in self.queue_keys[who] and len(queue) < 128 and self.queue_bytes[who]+len(raw) <= 2000000:
                        queue.append(raw); self.queue_bytes[who] += len(raw)
                        self.queue_keys[who].add(raw)

    def ingest(self,message):
        """Deduplicate only successfully authenticated ingress in its original
        local height/round. A future vote ignored here must be retried after
        catch-up; a cache entry is never authorization or a persisted vote.
        """
        ref = hashlib.sha256(canonical(message)).digest()
        with self.replica.lock:
            self.replica._healthy()
            phase = (self.replica.engine.s['height'],self.replica.engine.s['round'],ref)
            if phase in self.seen_messages: return
            out = self.replica.receive(message)
            self.seen_messages[phase] = True
            while len(self.seen_messages)>4096:self.seen_messages.popitem(last=False)
        self.publish(out)

    def _post(self,opener,endpoint,path,value):
        raw = value if type(value) is bytes else canonical(value)
        request = urllib.request.Request(endpoint+path,data=raw,headers={'Content-Type':'application/json',
            'Authorization':'Bearer '+self.token},method='POST')
        with opener.open(request,timeout=.4) as reply:
            data = reply.read(MAX_RPC+1); c.need(len(data) <= MAX_RPC,'REPLICA_RPC_REPLY_LIMIT')
            return decode(data)

    def _peer(self,who,endpoint):
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,*args): return None
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
        last_sync = -1
        while not self.stopping.is_set():
            if who in self.blocked:
                self.stopping.wait(.05); continue
            try:
                if time.monotonic()-last_sync >= .3:
                    last_sync = time.monotonic()
                    with self.replica.lock:
                        start = self.replica.height+1; pending = list(self.replica.pending.values())[:16]
                    result = self._post(opener,endpoint,'/history',{'start':start})
                    c.exact(result,'history')
                    c.need(type(result['history']) is list and len(result['history']) <= getattr(self.replica,'history_page_limit',r.MAX_COMMITS), 'REPLICA_HISTORY_LIMIT')
                    for entry in result['history']:
                        self.publish(self.replica.receive({'kind':'commit',**entry}))
                    for command in pending:
                        try: self._post(opener,endpoint,'/command',command)
                        except Exception as exc: self.errors.append(type(exc).__name__)
                with self.queue_lock:
                    raw = self.queues[who].popleft() if self.queues[who] else None
                    if raw is not None:
                        self.queue_bytes[who] -= len(raw); self.queue_keys[who].discard(raw)
                if raw is not None: self._post(opener,endpoint,'/message',raw)
            except Exception as exc:
                self.errors.append(type(exc).__name__)
            self.stopping.wait(.005)

    def _tick(self):
        while not self.stopping.is_set():
            try: self.publish(self.replica.tick(time.monotonic()))
            except Exception as exc:
                self.errors.append(type(exc).__name__)
                if self.replica.failed or (self.replica.engine and self.replica.engine.failed): return
            self.stopping.wait(.025)

    def start(self):
        c.need(not self.threads, 'REPLICA_SERVICE_STARTED')
        tasks = [(self.server.serve_forever,()),(self._tick,())]+[(self._peer,(who,url)) for who,url in self.peers.items()]
        for fn,args in tasks:
            thread = threading.Thread(target=fn,args=args,daemon=True); self.threads.append(thread); thread.start()
        return self

    def close(self):
        self.stopping.set()
        self.ops.close()
        if self.threads: self.server.shutdown()
        self.server.server_close()
        for thread in self.threads: thread.join(timeout=3)
        self.threads = []


def fetch_peer_histories(spec,peers,token,*,timeout=2,protocol=r,scan_seconds=10,tokens=None):
    """Advisory prior-use evidence, never a proof that a key is unused.

    Read adopted loopback peers round-robin within 10 seconds, 2 MB total,
    and at most 32 pages per peer (one complete page for historical 0.1).
    Unreachable/truncated/malformed peers leave an incomplete check. Do not
    reuse a key with uncertain signing storage even if the result is empty.
    """
    protocol.validate_spec(spec); _token(token)
    c.need(type(timeout) in (int,float) and 0<timeout<=2 and type(scan_seconds) in (int,float) and 0<scan_seconds<=10,'REPLICA_PEER_TIMEOUT')
    c.need(type(peers) is dict and set(peers)<=set(spec['validators']),'REPLICA_PEERS')
    for endpoint in peers.values():
        u = _endpoint(endpoint,True)
        c.need(u.scheme=='http' and ipaddress.ip_address(u.hostname).is_loopback,'REPLICA_LOOPBACK_PEERS')
    records = {name:[] for name in peers}; starts = {name:1 for name in peers}
    deadline = time.monotonic()+scan_seconds; remaining = 2000000
    page_limit = getattr(protocol,'PAGE_LIMIT',r.MAX_COMMITS)
    for _ in range(32 if hasattr(protocol,'PAGE_LIMIT') else 1):
        if not starts: break
        for name,start in tuple(starts.items()):
            if time.monotonic()>=deadline or remaining<=0: return [v for v in records.values() if v]
            u = _endpoint(peers[name],True)
            connection = HTTPConnection(u.hostname,u.port or 80,timeout=min(timeout,max(.01,deadline-time.monotonic())))
            watchdog = None
            try:
                connection.connect(); stream = connection.sock
                def expire(stream=stream):
                    try: stream.shutdown(socket.SHUT_RDWR)
                    except OSError: pass
                watchdog = threading.Timer(max(.001,deadline-time.monotonic()),expire)
                watchdog.daemon = True; watchdog.start()
                connection.request('POST','/replica/history',body=canonical({'start':start}),
                    headers={'Content-Type':'application/json','Authorization':'Bearer '+peer_bearer(token,tokens,name)})
                reply = connection.getresponse()
                try:
                    c.need(reply.status==200,'REPLICA_PEER_REPLY')
                    raw = reply.read(min(MAX_RPC,remaining)+1)
                finally: reply.close()
                if len(raw)>min(MAX_RPC,remaining): starts.pop(name); continue
                remaining -= len(raw); value = decode(raw); c.exact(value,'history'); page = value['history']
                c.need(type(page) is list and len(page)<=page_limit,'REPLICA_PEER_HISTORIES')
                records[name].extend(page)
                heights = [entry['block']['height'] for entry in page]
                c.need(heights and all(type(h) is int and h==start+i for i,h in enumerate(heights)),'REPLICA_PEER_PAGE')
                starts[name] = heights[-1]+1
            except Exception: starts.pop(name,None)
            finally:
                if watchdog is not None: watchdog.cancel()
                connection.close()
    return [v for v in records.values() if v]


class ReplicatedProviderClient:
    """Owner SDK with exact-envelope retry across adopted endpoints. Certificates
    and application replay, not the first HTTP success, establish an outcome.
    No local allocation or different provider is used on loss of quorum.
    """
    def __init__(self,directory,*,spec,endpoints,token,wallet,controller,epoch,lease_expires,clock,
                 allow_insecure_loopback=False,timeout=10,minimum_head=p.ZERO):
        r.validate_spec(spec); _token(token); c.key(wallet); c.integer(epoch); c.integer(lease_expires); c.key(minimum_head)
        c.need(wallet in spec['provider']['accounts'] and callable(clock), 'REPLICA_CLIENT_SCOPE')
        c.need(type(endpoints) is dict and 1 <= len(endpoints) <= len(spec['validators']) and
               set(endpoints) <= set(spec['validators']), 'REPLICA_CLIENT_ENDPOINTS')
        c.need(type(timeout) in (int,float) and 0 < timeout <= 30, 'REPLICA_CLIENT_TIMEOUT')
        self.spec = deepcopy(spec); self.provider = p.provider_id(spec['provider']); self.wallet = wallet
        self.controller = controller; self.epoch = epoch; self.lease_expires = lease_expires; self.clock = clock; self.timeout = timeout
        self._pin = identifier('REPLICA-CLIENT-SCOPE',{'cluster':r.cluster_id(spec),'wallet':wallet})
        routes = {}
        for who,endpoint in endpoints.items():
            u = _endpoint(endpoint,allow_insecure_loopback)
            routes[who] = {'origin':u.scheme+'://'+u.netloc,'methods':['POST'],'path_prefix':'/replica/command',
                           'headers':{'Content-Type':'application/json','Authorization':'Bearer '+token}}
        self.store = WorkflowStore(directory,{'scope':self._pin,'minimum_head':minimum_head})
        self.minimum_head = minimum_head
        self.transport = ConnectorHarness(self.store.directory/'transport',http_routes=routes,timeout=.5,
                                          max_request_bytes=MAX_RPC,max_response_bytes=1000000)
        self.routes = tuple(routes)

    def prepare(self,operation,parameters,*,nonce=None,ttl=30):
        c.integer(ttl,True); c.need(ttl <= 300,'REPLICA_CLIENT_TTL'); now = self.clock(); c.integer(now)
        return r.draft_command(self.spec,self.wallet,c.public_key(self.controller),self.epoch,operation,parameters,
                               now,now+ttl,nonce or secrets.token_hex(32))

    def send(self,envelope):
        c.need(self._pin == identifier('REPLICA-CLIENT-SCOPE',{'cluster':r.cluster_id(self.spec),'wallet':self.wallet}) and
               self.provider == p.provider_id(self.spec['provider']), 'REPLICA_CLIENT_SCOPE_CHANGED')
        command = r.verify_command(envelope,self.spec)
        c.need(command['provider'] == self.provider and command['wallet'] == self.wallet, 'REPLICA_CLIENT_SCOPE')
        deadline = time.monotonic()+self.timeout
        while time.monotonic() < deadline:
            for who in self.routes:
                if time.monotonic() >= deadline: break
                request = {'protocol':'HTTP','operation':who,'parameters':{'path':'/replica/command','method':'POST',
                    'body_base64':base64.b64encode(canonical(envelope)).decode('ascii')}}
                # A 202 or lost reply is not an effect result. A fresh transport
                # attempt retries the SAME signed command, never a new nonce.
                try:
                    observed = self.transport.execute(secrets.token_hex(32),request)
                    if observed['status'] != 'OBSERVED': continue
                    response = observed['value']['response']
                    if response['status'] != 200: continue
                    value = decode(base64.b64decode(response['body_base64'],validate=True))
                    with self.store.exclusive():
                        events = self.store.events(); floor = events[-1]['body']['value']['head'] if events else self.minimum_head
                        receipt = r.verify_receipt(value,command,spec=self.spec,minimum_head=floor)
                        head = r.verify_history(self.spec,value['history'])['head']
                        self.store.append('REPLICA_CHECKPOINT',receipt['request'],{'head':head})
                    return value
                except (ValueError,KeyError,TypeError): continue
            time.sleep(.025)
        raise ValueError('REPLICA_OUTCOME_UNKNOWN')

    def call(self,operation,parameters):
        draft = self.prepare(operation,parameters)
        return self.send({'cluster':draft['cluster'],'command':draft['command'],
                          'signature':c.sign(self.controller,draft['label'],draft['body'])})

    def close(self):
        self.transport.close(); self.store.close()


from .provider_connector import ProviderAdapter


class ReplicatedProviderAdapter(ProviderAdapter):
    """Adopted adapter meaning pins the committee as well as the inventory."""
    def __init__(self,client,*,hold_seconds=30):
        super().__init__(client,hold_seconds=hold_seconds)
        self.manifest['instance'] = identifier('COVENANT-REPLICATED-PROVIDER-ADAPTER-0.1',
            {'cluster':r.cluster_id(client.spec),'provider':client.provider,'wallet':client.wallet,
             'hold_seconds':hold_seconds,'protocol':r.VERSION})
        self.manifest['requirements']['resources'] = 'QUORUM_CERTIFIED_PROVIDER_LOGICAL_INVENTORY'
        self.manifest['privacy'] = ['OWNER_ONLY_ALL_ACCOUNT_HISTORY','PRIVATE_VALIDATOR_REPLICATION']
        self._cluster = r.cluster_id(client.spec)

    def observe(self,effect_id):
        c.need(r.cluster_id(self.client.spec) == self._cluster,'REPLICA_ADAPTER_SCOPE_CHANGED')
        return super().observe(effect_id)
