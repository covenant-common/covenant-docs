"""What backs an offline trade, checked offline, and what reconciliation can claim.

Preallocated allowance with backing OFFLINE_VALUE uses the existing
offline_value rule set on covenant-native/0.15: the issuer's bond moves into a
per-book escrow, a certified spend pays the payee, and a second signature for
the same serial slashes the book. The recipient checks a committee-certified
light proof of the book (light.verify_light_bundle) against a genesis it
adopted, and the buyer's device signature over the ledger's own spend body.

Two older paths are fenced, not reused: ECON_OFFLINE_* (scale_fees) moves no
principal for a spend inside the allowance and lets one bond back several
allowances in full, and SCALE_CHANNEL_SETTLE records a signed net without
moving balances. Neither is offline cash; assurance() names what each gives.

Local issuer credit is an issuer-signed credit line the trade pins; a local
quorum is a group the recipient adopted whose members co-sign the slot.
Stripe Terminal offline collection is recorded as unconfirmed until the
provider authorises it after reconnection. Nothing here moves value.
"""
from copy import deepcopy

from . import crypto as c, offline_trade as trade
from .offline_trade_freshness import TradeError, confirmations, group_id, need, when

INSTRUCTION_VERSION = 'covenant-offline-trade-instruction/0.1'
LINE_VERSION = 'covenant-offline-trade-credit-line/0.1'
LINE_LABEL = 'COVENANT-OFFLINE-TRADE-CREDIT-LINE-0.1'
PROVIDER_VERSION = 'covenant-provider-offline-collection/0.1'
PROVIDER_LABEL = 'COVENANT-PROVIDER-OFFLINE-COLLECTION-0.1'
LOCAL_ASSURANCE = 'LOCAL_REDUCER_NOT_CONSENSUS'
# Confirmed from Stripe's documentation on 28 October 2026 (docs.stripe.com/terminal/features/
# operate-offline/collect-card-payments): authorisation is only attempted after connectivity is
# restored and the payment is forwarded; the user assumes all decline and tamper risk; the
# Stripe-enforced offline maximum is 10,000 USD or equivalent; PaymentIntents created offline
# have a null id; with automatic capture a confirmed offline PaymentIntent shows SUCCEEDED
# before it is forwarded. The Charge records payment_method_details.card_present.offline
# with stored_at and type deferred.
PROVIDERS = {
    'stripe-terminal': {
        'authorisation': 'AFTER_RECONNECTION_WHEN_FORWARDED',
        'decline_and_tamper_risk': 'MERCHANT',
        'source': 'https://docs.stripe.com/terminal/features/operate-offline/collect-card-payments',
        'offline_maximum': {'usd': 1000000},
    },
}
PROVIDER_STATES = {'requires_capture': 'AUTHORISED_NOT_CAPTURED', 'succeeded': 'CAPTURED'}
# What each leg can honestly claim after reconciliation.
ASSURANCE = {
    'RECORD_ONLY': 'PROMISE_RECORDED_NO_VALUE_MOVED',
    'ISSUER_CREDIT': 'ISSUER_PROMISE_UNTIL_THE_ISSUER_PAYS',
    'LOCAL_QUORUM': 'LOCAL_CONFIRMATION_NOT_GLOBAL_FINALITY',
    'OFFLINE_VALUE': 'ESCROW_PAYS_WHEN_THE_LEDGER_CONFIRMS',
    'OWNER_VERIFIED': 'AS_STRONG_AS_THE_OWNER_VERIFIER',
    'PROVIDER_OFFLINE': 'UNCONFIRMED_UNTIL_THE_PROVIDER_AUTHORISES',
    'ECON_OFFLINE_SPEND': 'ACCOUNTING_ONLY_PRINCIPAL_NOT_PAID',
    'SCALE_CHANNEL_SETTLE': 'SIGNED_NET_RECORDED_NO_BALANCE_MOVED',
}


def assurance(leg):
    need(type(leg) is str and leg in ASSURANCE, 'TRADE_CHECK_FAILED')
    return ASSURANCE[leg]


def _risk(bundle):
    trade.terms_id(bundle)
    need(bundle['version'] == trade.VERSION_0_2, 'TRADE_SUCCESSOR_REQUIRED')
    return bundle['terms']['risk']['terms']


def _ledger_terms(bundle):
    risk = _risk(bundle)
    terms = bundle['terms']
    need(terms['policy']['mode'] == 'PREALLOCATED_CLAIM' and risk['backing'] == 'OFFLINE_VALUE',
         'TRADE_NOT_BOND_BACKED')
    claim = terms['policy']['reservation']
    return risk, claim, int(claim['serial'])


# Preallocated allowance on offline_value --------------------------------------

def ledger_backing(bundle, *, genesis, minimum_height=1, proof=None):
    """Check a committee-certified proof of the reserved escrow book, offline."""
    from . import light
    risk, claim, counter = _ledger_terms(bundle)
    terms = bundle['terms']
    if proof is None:
        found = trade.attached(bundle, 'RESERVATION')
        need(len(found) == 1, 'TRADE_BACKING_PROOF')
        proof = found[0]
    need(type(genesis) is dict, 'TRADE_CHAIN_NOT_ADOPTED')
    try:
        adopted = c.genesis_id(genesis)
    except (ValueError, KeyError, TypeError):
        raise TradeError('TRADE_CHAIN_NOT_ADOPTED') from None
    need(adopted == risk['chain'], 'TRADE_CHAIN_NOT_ADOPTED')
    table = 'offline_vouchers' if risk['kind'] == 'VOUCHER' else 'offline_allowances'
    try:
        verified = light.verify_light_bundle(genesis, proof, risk['chain'], minimum_height, table, claim['reference'])
    except (ValueError, KeyError, TypeError):
        raise TradeError('TRADE_BACKING_PROOF') from None
    row = verified['value']
    quantity = terms['resource']['quantity']
    need(type(row) is dict and row.get('rule') == 'offline_value' and row.get('kind') == risk['kind'] and
         row.get('issuer') == claim['issuer'] and row.get('device') == terms['parties']['buyer'] and
         row.get('resource') == terms['resource']['unit'], 'TRADE_BACKING_MISMATCH')
    if risk['kind'] == 'VOUCHER':
        need(counter < row['serials'] and row['amount'] == quantity, 'TRADE_BACKING_MISMATCH')
    else:
        need(quantity <= row['remaining'], 'TRADE_BACKING_MISMATCH')
    need(row['status'] == 'OPEN' and str(counter) not in row['spent'], 'TRADE_BACKING_CLOSED')
    return {'backing': 'OFFLINE_VALUE', 'chain': risk['chain'], 'book': claim['reference'], 'kind': risk['kind'],
            'counter': counter, 'escrow': row['escrow'], 'issuer': row['issuer'], 'remaining': row['remaining'],
            'height': verified['height'], 'expiry_height': row.get('expiry', row.get('valid_until')),
            'assurance': verified['assurance'], 'freshness': 'AS_OF_CERTIFIED_HEIGHT_ONLY',
            'words': 'escrow %s held %d %s at ledger height %d, certified by the adopted committee; later spends '
                     'by other payees are not visible offline' % (row['escrow'][:16], row['remaining'],
                                                                  row['resource'], verified['height']),
            'payment_verified': False, 'ledger_confirmed': False}


def reservation_verifier(*, genesis, proof, minimum_height=1):
    """A reservation_verifier for offline_trade.inspect: True only for a valid certified escrow proof."""
    captured = deepcopy(proof)

    def check(context):
        bundle = {'version': trade.VERSION_0_2, 'terms': context['terms'], 'assents': [], 'events': [],
                  'attachments': []}
        try:
            ledger_backing(bundle, genesis=genesis, minimum_height=minimum_height, proof=captured)
        except (ValueError, KeyError, TypeError):
            return False  # fail closed: an unproven reservation is not accepted
        return True
    return check


def spend_instruction(device_key, bundle):
    """The buyer device's offline_value spend signature for this trade, ready for the ledger."""
    from .scale.offline import SPEND_LABEL, spend_body
    risk, claim, counter = _ledger_terms(bundle)
    terms = bundle['terms']
    need(c.public_key(device_key) == terms['parties']['buyer'], 'TRADE_INSTRUCTION_SIGNATURE')
    body = spend_body(risk['chain'], claim['reference'], risk['kind'], counter, terms['parties']['supplier'],
                      terms['resource']['quantity'])
    return {'version': INSTRUCTION_VERSION, 'trade': trade.terms_id(bundle), 'chain': risk['chain'],
            'book': claim['reference'], 'kind': risk['kind'], 'counter': counter,
            'payee': terms['parties']['supplier'], 'amount': terms['resource']['quantity'],
            'signature': c.sign(device_key, SPEND_LABEL, body)}


def instruction_id(instruction):
    return c.digest('COVENANT-OFFLINE-TRADE-INSTRUCTION-0.1', instruction)


def check_instruction(bundle, instruction=None):
    """The spend instruction matches the trade and carries the device's ledger signature."""
    from .scale.offline import SPEND_LABEL, spend_body
    risk, claim, counter = _ledger_terms(bundle)
    terms = bundle['terms']
    if instruction is None:
        found = trade.attached(bundle, 'INSTRUCTION')
        need(len(found) >= 1, 'TRADE_INSTRUCTION')
        instruction = found[0]
    need(type(instruction) is dict and set(instruction) == {'version', 'trade', 'chain', 'book', 'kind', 'counter',
         'payee', 'amount', 'signature'} and instruction['version'] == INSTRUCTION_VERSION, 'TRADE_INSTRUCTION')
    expected = {'trade': trade.terms_id(bundle), 'chain': risk['chain'], 'book': claim['reference'],
                'kind': risk['kind'], 'counter': counter, 'payee': terms['parties']['supplier'],
                'amount': terms['resource']['quantity']}
    need(all(instruction[k] == v for k, v in expected.items()), 'TRADE_INSTRUCTION')
    try:
        c.verify(terms['parties']['buyer'], SPEND_LABEL,
                 spend_body(risk['chain'], claim['reference'], risk['kind'], counter,
                            instruction['payee'], instruction['amount']), instruction['signature'])
    except ValueError:
        raise TradeError('TRADE_INSTRUCTION_SIGNATURE') from None
    return deepcopy(instruction)


# Collateral aggregation --------------------------------------------------------

def collateral(bundle):
    """The bucket every claim on the same collateral is counted in, and the amount claimed."""
    trade.terms_id(bundle)
    terms = bundle['terms']; policy = terms['policy']; quantity = terms['resource']['quantity']
    if policy['reservation'] is not None:
        claim = policy['reservation']
        bucket = c.digest('COVENANT-OFFLINE-TRADE-COLLATERAL-0.1', {'issuer': claim['issuer'],
                          'reference': claim['reference'], 'unit': terms['resource']['unit']})
        return {'bucket': bucket, 'kind': 'RESERVATION', 'amount': quantity}
    if bundle['version'] == trade.VERSION_0_2 and policy['mode'] == 'ISSUER_CREDIT':
        risk = terms['risk']['terms']
        bucket = c.digest('COVENANT-OFFLINE-TRADE-COLLATERAL-0.1', {'issuer': risk['issuer'], 'line': risk['line'],
                                                                     'unit': terms['resource']['unit']})
        return {'bucket': bucket, 'kind': 'CREDIT_LINE', 'amount': quantity, 'issuer': risk['issuer']}
    return None


def shared_backing(limit, bond, claims):
    """Never count one bond as full backing for several allowances: share it in proportion."""
    for value in (limit, bond, claims):
        c.integer(value)
    need(limit <= claims or claims == 0, 'TRADE_CHECK_FAILED')
    if claims <= bond:
        return limit
    return limit * bond // claims


def econ_coverage(meter, actor, height):
    """Fence for frozen ECON_OFFLINE_ALLOWANCE: report one bond claimed by several allowances.

    That operation checks each new limit against the whole bond, so the same
    bond can back several devices in full, and a spend inside the limit pays no
    principal. This read-only report never treats such an allowance as backing.
    """
    c.integer(height); c.key(actor)
    need(type(meter) is dict, 'TRADE_CHECK_FAILED')
    bond = (meter.get('bonds') or {}).get(actor, 0)
    rows = [row for row in (meter.get('offline_allowances') or {}).values()
            if type(row) is dict and row.get('actor') == actor and not row.get('slashed') and
            height <= row.get('until', 0)]
    claimed = sum(row.get('limit', 0) for row in rows)
    return {'bond': bond, 'allowances': len(rows), 'claimed': claimed, 'overcommitted': claimed > bond,
            'coverage_bps': 10000 if claimed <= bond else bond * 10000 // claimed,
            'principal_paid_inside_limit': False, 'assurance': ASSURANCE['ECON_OFFLINE_SPEND'],
            'accepted_as_offline_backing': False}


# Local issuer credit ---------------------------------------------------------

def credit_line(issuer_key, *, holder, unit, limit, issued_at, expires_at, sequence):
    """Explicit issuer action: a bounded promise to honour notes from this holder."""
    body = {'version': LINE_VERSION, 'issuer': c.public_key(issuer_key), 'holder': holder, 'unit': unit,
            'limit': limit, 'issued_at': issued_at, 'expires_at': expires_at, 'sequence': sequence}
    _line(body)
    return {'body': body, 'signature': c.sign(issuer_key, LINE_LABEL, body)}


def _line(body):
    need(type(body) is dict and set(body) == {'version', 'issuer', 'holder', 'unit', 'limit', 'issued_at',
         'expires_at', 'sequence'} and body['version'] == LINE_VERSION, 'TRADE_CREDIT_LINE')
    try:
        for name in ('issuer', 'holder'):
            c.verification_key(body[name])
        c.integer(body['limit'], True); c.integer(body['issued_at']); c.integer(body['expires_at'])
        c.integer(body['sequence'], True)
    except ValueError:
        raise TradeError('TRADE_CREDIT_LINE') from None
    need(type(body['unit']) is str and 0 < len(body['unit']) <= 256 and body['issued_at'] < body['expires_at'],
         'TRADE_CREDIT_LINE')


def line_id(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'TRADE_CREDIT_LINE')
    _line(record['body'])
    try:
        c.verify(record['body']['issuer'], LINE_LABEL, record['body'], record['signature'])
    except ValueError:
        raise TradeError('TRADE_CREDIT_LINE') from None
    return c.digest(LINE_LABEL, record['body'])


def check_credit(bundle, *, now, line=None):
    """The issuer's signed line exists, names this buyer and unit, is current and covers the note."""
    risk = _risk(bundle); c.integer(now)
    terms = bundle['terms']
    need(terms['policy']['mode'] == 'ISSUER_CREDIT', 'TRADE_CREDIT_LINE')
    if line is None:
        found = trade.attached(bundle, 'CREDIT_LINE')
        need(len(found) == 1, 'TRADE_CREDIT_LINE')
        line = found[0]
    need(line_id(line) == risk['line'], 'TRADE_CREDIT_LINE')
    body = line['body']
    need(body['issuer'] == risk['issuer'] and body['holder'] == terms['parties']['buyer'] and
         body['unit'] == terms['resource']['unit'] and body['issued_at'] <= now < body['expires_at'],
         'TRADE_CREDIT_LINE')
    need(terms['resource']['quantity'] <= body['limit'], 'TRADE_CREDIT_LIMIT')
    return {'backing': 'ISSUER_CREDIT', 'issuer': body['issuer'], 'line': risk['line'], 'limit': body['limit'],
            'matures_at': risk['matures_at'], 'loss': risk['loss'],
            'words': 'credit line from issuer %s: up to %d %s for this buyer until %s; payable from %s'
                     % (body['issuer'][:16], body['limit'], body['unit'], when(body['expires_at']),
                        when(risk['matures_at'])),
            'issuer_solvency_verified': False, 'payment_verified': False}


# Connected local quorum -------------------------------------------------------

def check_quorum(bundle, *, groups):
    """k of n members of the adopted group co-signed this trade's slot."""
    risk = _risk(bundle)
    need(bundle['terms']['policy']['mode'] == 'LOCAL_QUORUM', 'TRADE_QUORUM_GROUP')
    need(type(groups) is dict and risk['group'] in groups, 'TRADE_QUORUM_GROUP')
    value = groups[risk['group']]
    need(group_id(value) == risk['group'] and len(value['members']) == risk['members'] and
         value['threshold'] == risk['threshold'], 'TRADE_QUORUM_GROUP')
    _gid, seen = confirmations(bundle, value)
    need(len(seen) >= value['threshold'], 'TRADE_QUORUM_UNCONFIRMED')
    return {'backing': 'LOCAL_QUORUM', 'group': risk['group'], 'confirmed_by': sorted(seen),
            'threshold': value['threshold'], 'members': len(value['members']),
            'words': '%d of %d members of group %s confirmed this slot locally'
                     % (len(seen), len(value['members']), value['name']),
            'global_finality': False, 'assurance': ASSURANCE['LOCAL_QUORUM']}


# Provider offline collection (Stripe Terminal) --------------------------------

def provider_collection(merchant_key, *, trade_id, provider, reference, amount, currency, collected_at):
    """The merchant's record of a card payment collected while the reader was offline.

    reference is the merchant's own identifier, also placed in the
    PaymentIntent metadata, because an offline PaymentIntent has no id yet.
    """
    body = {'version': PROVIDER_VERSION, 'trade': trade_id, 'merchant': c.public_key(merchant_key),
            'provider': provider, 'reference': reference, 'amount': amount, 'currency': currency,
            'collected_at': collected_at, 'status': 'COLLECTED_OFFLINE_UNCONFIRMED'}
    _collection(body)
    return {'body': body, 'signature': c.sign(merchant_key, PROVIDER_LABEL, body)}


def _collection(body):
    need(type(body) is dict and set(body) == {'version', 'trade', 'merchant', 'provider', 'reference', 'amount',
         'currency', 'collected_at', 'status'} and body['version'] == PROVIDER_VERSION and
         body['status'] == 'COLLECTED_OFFLINE_UNCONFIRMED', 'TRADE_PROVIDER_RECORD')
    need(type(body['provider']) is str and body['provider'] in PROVIDERS, 'TRADE_PROVIDER_RECORD')
    need(type(body['reference']) is str and 0 < len(body['reference']) <= 64 and
         all(ch.isalnum() or ch in '-_.' for ch in body['reference']) and body['reference'].isascii(),
         'TRADE_PROVIDER_RECORD')
    need(type(body['currency']) is str and len(body['currency']) == 3 and body['currency'].isascii() and
         body['currency'].isalpha() and body['currency'].islower(), 'TRADE_PROVIDER_RECORD')
    try:
        c.key(body['trade']); c.verification_key(body['merchant'])
        c.integer(body['amount'], True); c.integer(body['collected_at'])
    except ValueError:
        raise TradeError('TRADE_PROVIDER_RECORD') from None
    ceiling = PROVIDERS[body['provider']]['offline_maximum'].get(body['currency'])
    # Only the documented USD figure is enforced; "or equivalent" in other currencies is not.
    need(ceiling is None or body['amount'] <= ceiling, 'TRADE_PROVIDER_LIMIT')


def check_collection(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'TRADE_PROVIDER_RECORD')
    _collection(record['body'])
    try:
        c.verify(record['body']['merchant'], PROVIDER_LABEL, record['body'], record['signature'])
    except ValueError:
        raise TradeError('TRADE_PROVIDER_RECORD') from None
    body = record['body']; terms = PROVIDERS[body['provider']]
    return {'provider': body['provider'], 'reference': body['reference'], 'amount': body['amount'],
            'currency': body['currency'], 'collected_at': body['collected_at'],
            'state': 'UNCONFIRMED_UNTIL_RECONNECTION', 'authorisation': terms['authorisation'],
            'decline_and_tamper_risk': terms['decline_and_tamper_risk'], 'source': terms['source'],
            'words': 'card payment collected offline at %s; not authorised yet. The provider attempts '
                     'authorisation only after the reader reconnects and forwards it; the merchant bears decline '
                     'and tamper risk. A SUCCEEDED status shown before forwarding is not an authorisation.'
                     % when(body['collected_at']),
            'payment_verified': False}


def observe_collection(record, outcome, *, verifier=None):
    """Classify the provider result seen after reconnection; authenticated only by an owner verifier."""
    checked = check_collection(record)
    need(type(outcome) is dict and set(outcome) == {'forwarded', 'payment_intent', 'status', 'error', 'observed_at'},
         'TRADE_PROVIDER_OUTCOME')
    need(type(outcome['forwarded']) is bool and
         (outcome['payment_intent'] is None or (type(outcome['payment_intent']) is str and
                                                0 < len(outcome['payment_intent']) <= 255)) and
         (outcome['status'] is None or (type(outcome['status']) is str and len(outcome['status']) <= 64)) and
         (outcome['error'] is None or (type(outcome['error']) is str and len(outcome['error']) <= 255)),
         'TRADE_PROVIDER_OUTCOME')
    try:
        c.integer(outcome['observed_at'])
    except ValueError:
        raise TradeError('TRADE_PROVIDER_OUTCOME') from None
    if not outcome['forwarded']:
        state = 'UNCONFIRMED_NOT_FORWARDED'
    elif outcome['error'] is not None:
        state = 'DECLINED_OR_FAILED'
    else:
        state = PROVIDER_STATES.get(outcome['status'], 'UNKNOWN')
    authenticated = False
    if verifier is not None:
        need(callable(verifier), 'TRADE_PROVIDER_OUTCOME')
        result = verifier(deepcopy(outcome))
        need(type(result) is bool, 'TRADE_PROVIDER_OUTCOME')
        authenticated = result
    return {**checked, 'state': state if authenticated or state.startswith('UNCONFIRMED') else 'PARTY_REPORTED_' + state,
            'authenticated': authenticated, 'payment_verified': authenticated and state == 'CAPTURED',
            'merchant_bears_loss': state == 'DECLINED_OR_FAILED'}


# A reference settlement leg for local journeys and tests -------------------------

class LocalLedgerLeg:
    """Apply offline_value spends to a local copy of ledger state.

    Labelled LOCAL_REDUCER_NOT_CONSENSUS: it moves balances only in this copy.
    A real deployment submits the same transaction to adopted validators and
    reads a certified result. A request already applied for the same note is
    reported as such, so a retried request never pays twice.
    """
    def __init__(self, state, *, submitter_key, height, fee):
        c.integer(height, True)
        need(type(state) is dict and callable(fee), 'TRADE_SETTLEMENT_LEG')
        self.state, self.key, self.height, self.fee = state, submitter_key, height, fee
        self.submitter = c.public_key(submitter_key)

    def _apply(self, op, payload):
        from . import app
        tx = app.make_transaction(self.key, self.state['chain'], self.state['nonces'].get(self.submitter, 0), op,
                                  payload, protocol=self.state.get('protocol', app.SCALE_VERSION),
                                  actor=self.submitter, fee=self.fee(self.state, self.height))
        # The reducer returns a new state or refuses: a refusal here is definite, not an unknown outcome.
        self.state = app.apply_transaction(self.state, tx, self.height)
        self.height += 1
        return app.transaction_id(tx)

    def _refused(self, error):
        return {'status': 'REFUSED', 'code': str(error)[:96], 'assurance': LOCAL_ASSURANCE, 'ledger_confirmed': False}

    def __call__(self, request):
        need(type(request) is dict and request.get('instruction') is not None, 'TRADE_SETTLEMENT_LEG')
        item = request['instruction']
        table = self.state['offline_vouchers' if item['kind'] == 'VOUCHER' else 'offline_allowances']
        row = table.get(item['book'])
        if row is None:
            return {'status': 'REFUSED', 'code': 'OFFLINE_MISSING', 'assurance': LOCAL_ASSURANCE, 'ledger_confirmed': False}
        spent = row['spent'].get(str(item['counter']))
        same = spent is not None and spent['payee'] == item['payee'] and spent['amount'] == item['amount']
        if request['action'] == 'SETTLE':
            if same:
                return {'status': 'APPLIED_LOCALLY', 'reference': None, 'repeat': True, 'assurance': LOCAL_ASSURANCE,
                        'ledger_confirmed': False}
            if spent is not None or row['status'] != 'OPEN':
                return {'status': 'CONFLICT', 'winner': deepcopy(spent), 'assurance': LOCAL_ASSURANCE,
                        'ledger_confirmed': False}
            field = 'voucher' if item['kind'] == 'VOUCHER' else 'allowance'
            op = 'SCALE_OFFLINE_REDEEM' if item['kind'] == 'VOUCHER' else 'SCALE_OFFLINE_SPEND'
            try:
                reference = self._apply(op, {field: item['book'], 'counter': item['counter'], 'payee': item['payee'],
                                             'amount': item['amount'], 'signature': item['signature']})
            except ValueError as error:
                return self._refused(error)
            return {'status': 'APPLIED_LOCALLY', 'reference': reference, 'repeat': False,
                    'assurance': LOCAL_ASSURANCE, 'ledger_confirmed': False}
        need(request['action'] == 'SLASH', 'TRADE_SETTLEMENT_LEG')
        if row['status'] == 'SLASHED':
            slash = row.get('slash') or {}
            repeat = slash.get('payee') == item['payee'] and slash.get('counter') == item['counter']
            return {'status': 'SLASHED_LOCALLY' if repeat else 'REFUSED', 'code': None if repeat else 'OFFLINE_STATUS',
                    'repeat': repeat, 'paid': slash.get('paid', 0), 'assurance': LOCAL_ASSURANCE, 'ledger_confirmed': False}
        try:
            reference = self._apply('SCALE_OFFLINE_EQUIVOCATE', {'book': item['book'], 'kind': item['kind'],
                                    'counter': item['counter'], 'payee': item['payee'], 'amount': item['amount'],
                                    'signature': item['signature']})
        except ValueError as error:
            return self._refused(error)
        slash = self.state['offline_vouchers' if item['kind'] == 'VOUCHER' else 'offline_allowances'][item['book']]['slash']
        return {'status': 'SLASHED_LOCALLY', 'reference': reference, 'repeat': False, 'paid': slash['paid'],
                'burned': slash['burned'], 'assurance': LOCAL_ASSURANCE, 'ledger_confirmed': False}


def describe():
    return {'instruction': INSTRUCTION_VERSION, 'credit_line': LINE_VERSION, 'provider_collection': PROVIDER_VERSION,
            'providers': {name: dict(row) for name, row in PROVIDERS.items()}, 'assurance': dict(ASSURANCE),
            'ledger_backing': 'offline_value escrow via a committee-certified light proof',
            'fenced': ['ECON_OFFLINE_SPEND', 'SCALE_CHANNEL_SETTLE'], 'moves_value': False,
            'execution_authorized': False}
