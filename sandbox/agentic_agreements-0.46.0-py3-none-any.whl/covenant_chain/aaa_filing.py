"""AAA filing packet: the final ladder stage exports a filing aid for the AAA route LCP names.

IMPROVE. The Legal Context Protocol 1.0 (github.com/legal-context-protocol/
legal-context-protocol, spec/legal-context-protocol-v1.md, 24 June 2026, commit
c8df26dd04; Apache-2.0) lets a service name its dispute route in
/.well-known/legal-context.json (disputeResolution: method, jurisdiction,
contact, clauseId, source, catalog) and fingerprints its terms as atrHash, the
SHA-256 of the exact terms bytes (section 2.5). It defines no filing packet;
Appendix A.6 and section E.4 list the evidence a forum needs. When an AAP
dispute ladder has reached its final stage, ``packet`` assembles for the
American Arbitration Association route what AAA Commercial Rule R-4 (Rules
amended and effective 1 September 2022) asks a claimant to file: the demand
particulars of R-4(a)(iv) and a copy of the arbitration agreement, plus AAP's
own record: the terms fingerprint, the replayed ladder, the evidence index and
the dual-format award.

It is a FILING AID, NOT A FILED CASE. Nothing here files, serves, pays a fee,
contacts the AAA or the respondent, or gives legal advice. The claimant or
counsel reviews it, files through an AAA channel (R-4(b)(i)), pays the filing
fee and sends the respondent copies at the same time (R-4(b)(ii)). The AAA
publishes no LCP clause catalog, so the route in a discovery document is the
service's own statement; the operative clause must be in the agreement itself
(LCP section E.4).
"""
from copy import deepcopy
from decimal import Decimal
import base64
import hashlib
import io
import json
import re
import zipfile

from . import atr
from .crypto import canonical, key, need

VERSION = 'urn:aap:aaa-filing-packet:0.1'
LABEL = 'AAP-AAA-FILING-PACKET-0.1'
STATUS = 'FILING_AID_NOT_FILED'
NOTICE = ('FILING AID - NOT A FILED CASE. AAP software assembled this packet from the parties\' own records. Nothing has '
          'been filed with, sent to or paid to the American Arbitration Association, and nothing has been served on the '
          'respondent. To start an arbitration the claimant must file a Demand for Arbitration, the administrative filing '
          'fee and a copy of the arbitration agreement (AAA Commercial Rule R-4(a)) through an AAA channel (R-4(b)(i)), and '
          'send the Demand and supporting documents to the respondent at the same time (R-4(b)(ii)). The claimant or '
          'counsel must review every statement before filing. This is not legal advice.')
RULES = {'provider': 'American Arbitration Association', 'rules': 'Commercial Arbitration Rules',
         'version': 'Amended and Effective September 1, 2022',
         'source': 'https://adr.org/media/ueonklrv/2026_commercial-arbitration-rules-mediation-procedures.pdf',
         'filing_rule': 'R-4', 'demand_form': 'https://adr.org/media/4j5jmnwv/2025_commercial_demand_for_arbitration.pdf',
         'channels': ['AAA online filing at www.adr.org (File Online / WebFile)', 'any AAA office',
                      'email to casefiling@adr.org, payment as the AAA directs'],
         'fee_schedule': 'https://www.adr.org/feeschedule'}
LCP = {'name': 'Legal Context Protocol', 'version': '1.0', 'repository': 'https://github.com/legal-context-protocol/legal-context-protocol',
       'file': 'spec/legal-context-protocol-v1.md', 'commit': 'c8df26dd04', 'licence': 'Apache-2.0',
       'fields': ['method', 'jurisdiction', 'contact', 'clauseId', 'source', 'catalog']}
# USD thresholds in the Commercial Rules: R-1(c) expedited, E-6 documents only, R-1(d) large complex, R-10 mediation.
EXPEDITED_MAX = Decimal(100000)
DOCUMENTS_ONLY_MAX = Decimal(25000)
LARGE_COMPLEX_MIN = Decimal(1000000)
MAX_FILE = 16_777_216
MAX_TOTAL = 67_108_864
MAX_TERMS = 1_048_576
MAX_DISCOVERY = 65536
DATE = re.compile(r'([0-9]{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])\Z')
TITLE = re.compile(r'[A-Za-z0-9][A-Za-z0-9 ._-]{0,47}\Z')
SAFE = re.compile(r'[A-Za-z0-9][A-Za-z0-9 ._-]*\Z')
CLAUSE_ID = re.compile(r'sha256:0x[0-9a-fA-F]{64}\Z')
# AAA WebFile Electronic Case Filing Guidelines (2023): file types, 100 characters, no & ' @ ^ $ ! ( ) % # ;
MEDIA = {'application/pdf': '.pdf', 'text/plain': '.txt', 'text/html': '.html', 'image/jpeg': '.jpg', 'image/gif': '.gif',
         'image/bmp': '.bmp', 'application/msword': '.doc',
         'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx', 'application/json': '.json'}
TERMS_FORMATS = {'json': ('application/json', '.json'), 'plain': ('text/plain', '.txt'), 'markdown': ('text/plain', '.txt'),
                 'html': ('text/html', '.html'), 'pdf': ('application/pdf', '.pdf')}
AGREEMENTS = ('covenant-bilateral/0.3', 'urn:aap:agreement-application:0.1')
CHECKLIST = ('Check that the arbitration agreement covers this dispute and names the AAA and its Commercial Rules',
             'Complete the AAA Demand for Arbitration from the particulars and review every statement',
             'File through an AAA channel and pay the administrative filing fee (R-4(a)(i), R-4(b)(i))',
             'Send the Demand and supporting documents to the respondent at the same time (R-4(b)(ii))',
             'Meet any conditions precedent and time limits in the agreement before filing (R-4(b)(v))')
FLAGS = {'status': STATUS, 'filed': False, 'fee_paid': False, 'served': False, 'aaa_contacted': False,
         'legal_advice': False, 'network_accessed': False, 'execution_authorized': False}

REMEDIATION = {
    'AAA_LADDER_NOT_FINAL': 'Export only after the ladder reached its final stage and closed: FINAL_ATTESTED_OUTCOME or CLOSED_UNRESOLVED there.',
    'AAA_CLAIMANT': 'Name the filing party as one of the two ladder disputants by role.',
    'AAA_AGREEMENT': 'Pass {profile, document} for the AAP agreement whose id is the ladder context: covenant-bilateral/0.3 or urn:aap:agreement-application:0.1.',
    'AAA_LEGAL_CONTEXT': 'Pass the retained legal-context.json bytes (one JSON object, at most 64 KiB) with an https terms link and a disputeResolution object.',
    'AAA_TERMS': 'Pass the exact terms document bytes (1 byte to 1 MiB); they must hash to the discovery atrHash when it has one.',
    'AAA_TERMS_FINGERPRINT': 'The terms bytes do not hash to the atrHash the service published; obtain the byte-identical terms.',
    'AAA_CLAUSE': 'Pass the arbitration clause as printable text naming the American Arbitration Association.',
    'AAA_CLAUSE_NOT_IN_AGREEMENT': 'The clause must appear word for word in the terms document or the AAP agreement; a route stated only in legal-context.json is not an agreement (LCP E.4).',
    'AAA_PARTICULARS': 'Give the R-4(a)(iv) particulars: claimant and respondent {name, address, phone, email}, representatives, nature_of_claim, relief_sought, amount, locale_requested, arbitrators_requested, prepared_on.',
    'AAA_AMOUNT': 'Give the amount as {currency (ISO 4217 letters), minor (integer), exponent 0..18}, or null.',
    'AAA_AWARD': 'Pass the verified AAP dual-format award {award, pdf, detached} whose basis is this ladder and whose outcome is its final outcome.',
    'AAA_EVIDENCE': 'Evidence files are {reference, title, media_type, content_base64} whose SHA-256 is a reference the ladder cites.',
    'AAA_FILE': 'Each file must be an accepted type, at most 16 MiB, with a WebFile-safe title; the packet is capped at 64 MiB.',
    'AAA_PACKET': 'The files do not match the manifest or its id; rebuild the packet from the retained records.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Correct the input; nothing was filed, sent or paid.')


def packet_id(manifest):
    """SHA-256 of the label and the manifest as sorted, compact ASCII JSON (addresses and claims keep their line breaks)."""
    raw = json.dumps(manifest, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)
    return hashlib.sha256(LABEL.encode('ascii') + b'\0' + raw.encode('ascii')).hexdigest()


def _text(value, limit, code, lines=False):
    allowed = (lambda c: 32 <= ord(c) <= 126 or (lines and c == '\n'))
    need(type(value) is str and 0 < len(value) <= limit and all(allowed(c) for c in value), code)
    return value


def _optional(value, limit, code):
    return None if value is None else _text(value, limit, code)


def _contact(value, code, representative=False):
    names = ('name', 'firm', 'address', 'phone', 'email') if representative else ('name', 'address', 'phone', 'email')
    need(type(value) is dict and set(value) == set(names), code)
    _text(value['name'], 200, code); _text(value['address'], 400, code, lines=True)
    for field in names[2:] if not representative else ('firm', 'phone', 'email'):
        _optional(value[field], 200, code)
    return deepcopy(value)


def _amount(value):
    if value is None:
        return None
    need(type(value) is dict and set(value) == {'currency', 'minor', 'exponent'} and type(value['currency']) is str
         and re.fullmatch('[A-Z]{3}', value['currency']) is not None and type(value['minor']) is int
         and 0 <= value['minor'] <= 2**53 - 1 and type(value['exponent']) is int and 0 <= value['exponent'] <= 18, 'AAA_AMOUNT')
    return {**value, 'decimal': str(Decimal(value['minor']).scaleb(-value['exponent']))}


def _particulars(value):
    names = {'claimant', 'respondent', 'representatives', 'nature_of_claim', 'relief_sought', 'amount',
             'locale_requested', 'arbitrators_requested', 'prepared_on'}
    need(type(value) is dict and set(value) == names, 'AAA_PARTICULARS')
    reps = value['representatives']
    need(type(reps) is dict and set(reps) == {'claimant', 'respondent'}, 'AAA_PARTICULARS')
    found = DATE.fullmatch(value['prepared_on']) if type(value['prepared_on']) is str else None
    need(found is not None, 'AAA_PARTICULARS')
    need(value['arbitrators_requested'] in (None, 1, 3), 'AAA_PARTICULARS')
    return {'claimant': _contact(value['claimant'], 'AAA_PARTICULARS'),
            'respondent': _contact(value['respondent'], 'AAA_PARTICULARS'),
            'representatives': {side: None if reps[side] is None else _contact(reps[side], 'AAA_PARTICULARS', True)
                                for side in ('claimant', 'respondent')},
            'nature_of_claim': _text(value['nature_of_claim'], 4000, 'AAA_PARTICULARS', lines=True),
            'relief_sought': _text(value['relief_sought'], 2000, 'AAA_PARTICULARS', lines=True),
            'amount': _amount(value['amount']), 'locale_requested': _optional(value['locale_requested'], 200, 'AAA_PARTICULARS'),
            'arbitrators_requested': value['arbitrators_requested'], 'prepared_on': value['prepared_on']}


def track(amount):
    """Which Commercial Rules procedures an amount points to. Only USD amounts are compared."""
    if amount is None or amount['currency'] != 'USD':
        return {'basis': 'NO_USD_AMOUNT_STATED; THE_AAA_DETERMINES_THE_TRACK', 'expedited': None,
                'documents_only': None, 'large_complex': None, 'mediation': None}
    value = Decimal(amount['minor']).scaleb(-amount['exponent'])
    return {'basis': 'STATED_CLAIM_ONLY; COUNTERCLAIMS_INTEREST_AND_FEES_EXCLUDED; THE_AAA_DETERMINES_THE_TRACK',
            'expedited': value <= EXPEDITED_MAX, 'documents_only': value <= DOCUMENTS_ONLY_MAX,
            'large_complex': value >= LARGE_COMPLEX_MIN, 'mediation': value > EXPEDITED_MAX,
            'rules': {'expedited': 'R-1(c): no claim or counterclaim over $100,000', 'documents_only': 'E-6: no claim over $25,000',
                      'large_complex': 'R-1(d): a claim or counterclaim of at least $1,000,000',
                      'mediation': 'R-10: mediation in cases over $100,000 unless a party opts out'}}


# Inputs --------------------------------------------------------------------------

def _agreement(agreement, context):
    need(type(agreement) is dict and set(agreement) == {'profile', 'document'} and agreement['profile'] in AGREEMENTS, 'AAA_AGREEMENT')
    document = agreement['document']
    try:
        if agreement['profile'] == 'covenant-bilateral/0.3':
            from covenant_agent import open_work
            need(type(document) is dict, 'AAA_AGREEMENT')
            ident = document.get('id')
            info = open_work.inspect(document, ident)
            need(info['status'] == 'BOUND', 'AAA_AGREEMENT')
        else:
            from covenant_language.agreement_application import identifier
            ident = identifier(document)
    except (ValueError, KeyError, TypeError):
        raise ValueError('AAA_AGREEMENT') from None
    need(ident == context, 'AAA_AGREEMENT')
    return ident


def _discovery(raw):
    from .lcp_emit import strict_loads
    need(type(raw) is bytes and 0 < len(raw) <= MAX_DISCOVERY, 'AAA_LEGAL_CONTEXT')
    try:
        document = strict_loads(raw, MAX_DISCOVERY)
    except ValueError:
        raise ValueError('AAA_LEGAL_CONTEXT') from None
    need(type(document) is dict and atr.is_https_link(document.get('terms')), 'AAA_LEGAL_CONTEXT')
    route = document.get('disputeResolution')
    need(type(route) is dict and len(route) <= 32, 'AAA_LEGAL_CONTEXT')
    for name in LCP['fields']:
        if name in route:
            need(type(route[name]) is str and 0 < len(route[name]) <= 2048, 'AAA_LEGAL_CONTEXT')
    need('clauseId' not in route or CLAUSE_ID.fullmatch(route['clauseId']) is not None, 'AAA_LEGAL_CONTEXT')
    if 'atrHash' in document:
        need(atr.decode(document['atrHash']) is not None, 'AAA_LEGAL_CONTEXT')
    fmt = document.get('termsFormat', 'plain')
    need(type(fmt) is str and len(fmt) <= 32, 'AAA_LEGAL_CONTEXT')
    return document, {name: route[name] for name in LCP['fields'] if name in route}


def _strings(value, out, depth=0):
    if type(value) is str:
        out.append(value)
    elif type(value) is dict and depth < 32:
        for item in value.values(): _strings(item, out, depth + 1)
    elif type(value) is list and depth < 32:
        for item in value: _strings(item, out, depth + 1)
    return out


def _clause(clause, terms_raw, agreement_document, route):
    _text(clause, 8000, 'AAA_CLAUSE', lines=True)
    need('american arbitration association' in clause.lower(), 'AAA_CLAUSE')
    try:
        terms_text = terms_raw.decode('utf-8')
    except UnicodeError:
        terms_text = ''
    in_terms = clause in terms_text
    in_agreement = any(clause in text for text in _strings(agreement_document, []))
    need(in_terms or in_agreement, 'AAA_CLAUSE_NOT_IN_AGREEMENT')
    computed = 'sha256:0x' + hashlib.sha256(clause.encode('ascii')).hexdigest()
    published = route.get('clauseId')
    return {'text_sha256': computed, 'found_in': (['terms_document'] if in_terms else []) + (['aap_agreement'] if in_agreement else []),
            'clause_id': published,
            'clause_id_check': ('NOT_PUBLISHED' if published is None else
                                'MATCHES_SHA256_OF_CLAUSE_TEXT' if published.lower() == computed else
                                'DIFFERS; LCP_DOES_NOT_DEFINE_THE_HASH_INPUT')}


def _ladder(policy, adoptions, events, expected_head, claimant):
    from covenant_language import agreement_procedures as procedures
    state = procedures.replay(policy, adoptions, events, expected_head)
    need(policy['kind'] == 'ESCALATION', 'AAA_LADDER_NOT_FINAL')
    configuration = policy['configuration']
    last = len(configuration['stages']) - 1
    need(state['round'] == last and state['status'] in ('FINAL_ATTESTED_OUTCOME', 'CLOSED_UNRESOLVED'), 'AAA_LADDER_NOT_FINAL')
    need(type(claimant) is str and claimant in configuration['disputants'], 'AAA_CLAIMANT')
    respondent = next(role for role in configuration['disputants'] if role != claimant)
    from covenant_language.agreement_application import content_id
    cited = {}
    for event in events:
        body, arguments = event['body'], event['arguments']
        ident = content_id('AAP-PROCEDURE-EVENT-0.1', body)
        for name in ('claim', 'evidence'):
            if body['action'] in ('OPEN', 'CHALLENGE') and name in arguments:
                cited.setdefault(arguments[name], []).append(ident)
    return state, respondent, cited


def _award(award, policy_id, state):
    if award is None:
        return None
    from . import award_documents
    need(state['status'] == 'FINAL_ATTESTED_OUTCOME', 'AAA_AWARD')
    need(type(award) is dict and set(award) == {'award', 'pdf', 'detached'} and type(award['pdf']) is bytes, 'AAA_AWARD')
    try:
        report = award_documents.verify(award['award'], award['pdf'], award['detached'])
    except (ValueError, KeyError, TypeError):
        raise ValueError('AAA_AWARD') from None
    body = award['award']['body']
    need(body['basis']['kind'] == 'PROCEDURE' and body['basis']['reference'] == policy_id
         and body['basis']['head'] in (None, state['head']) and canonical(body['outcome']) == canonical(state['outcome']), 'AAA_AWARD')
    return report


def _name(date, title, extension):
    name = '%s %s%s' % (date, title, extension)
    need(SAFE.fullmatch(title) is not None and len(name) <= 100 and not re.search(r"[&'@^$!()%#;]", name), 'AAA_FILE')
    return name


def _json(value):
    return json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True).encode('ascii') + b'\n'


def _evidence(files, cited, date):
    need(type(files) in (list, tuple) and len(files) <= 64, 'AAA_EVIDENCE')
    out = {}
    for item in files:
        need(type(item) is dict and set(item) == {'reference', 'title', 'media_type', 'content_base64'}, 'AAA_EVIDENCE')
        key(item['reference'])
        need(item['reference'] in cited and item['media_type'] in MEDIA and type(item['content_base64']) is str
             and len(item['content_base64']) <= 4 * MAX_FILE // 3 + 4, 'AAA_EVIDENCE')
        try:
            content = base64.b64decode(item['content_base64'], validate=True)
        except ValueError:
            raise ValueError('AAA_EVIDENCE') from None
        need(0 < len(content) <= MAX_FILE and hashlib.sha256(content).hexdigest() == item['reference'], 'AAA_EVIDENCE')
        need(type(item['title']) is str and TITLE.fullmatch(item['title']) is not None, 'AAA_FILE')
        name = _name(date, 'Evidence %s %s' % (item['reference'][:12], item['title']), MEDIA[item['media_type']])
        need(name not in out, 'AAA_EVIDENCE')
        out[name] = (content, item['media_type'], item['reference'])
    return out


# The packet ------------------------------------------------------------------------

def _archive(files):
    """A deterministic ZIP: sorted names, stored entries, fixed time and permissions."""
    with io.BytesIO() as buffer:
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_STORED) as archive:
            for name in sorted(files):
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                archive.writestr(info, files[name])
        return buffer.getvalue()


def _cover(record, particulars, names):
    rows = ['FILING AID - NOT A FILED CASE', '', NOTICE, '',
            'Route: %s, %s (%s), filing rule %s.' % (RULES['provider'], RULES['rules'], RULES['version'], RULES['filing_rule']),
            'Demand form: %s' % RULES['demand_form'], 'Fee schedule: %s' % RULES['fee_schedule'], '',
            'R-4(a)(iv) particulars as supplied by the claimant:']
    for side in ('claimant', 'respondent'):
        party = particulars[side]
        rows.append('%s: %s; %s; phone %s; email %s' % (side.capitalize(), party['name'], party['address'].replace('\n', ', '),
                                                       party['phone'] or 'not known', party['email'] or 'not known'))
        rep = particulars['representatives'][side]
        rows.append('%s representative: %s' % (side.capitalize(), 'none named' if rep is None else '%s, %s; %s; phone %s; email %s' % (
            rep['name'], rep['firm'] or 'no firm', rep['address'].replace('\n', ', '), rep['phone'] or 'not known', rep['email'] or 'not known')))
    amount = particulars['amount']
    rows += ['Nature of the claim: ' + particulars['nature_of_claim'].replace('\n', ' '),
             'Relief sought: ' + particulars['relief_sought'].replace('\n', ' '),
             'Amount involved: ' + ('not stated' if amount is None else '%s %s' % (amount['currency'], amount['decimal'])),
             'Locale requested: ' + (particulars['locale_requested'] or 'as the arbitration agreement provides'),
             'Arbitrators requested: ' + ('not stated (R-17(a): one unless the AAA decides otherwise)'
                                         if particulars['arbitrators_requested'] is None else str(particulars['arbitrators_requested'])),
             '', 'AAP record:',
             'Agreement %s (%s); terms fingerprint atrHash %s.' % (record['agreement']['id'], record['agreement']['profile'],
                                                                 record['terms_fingerprint']['atrHash']),
             'Dispute ladder %s ended at stage %s with status %s, head %s.' % (
                 record['ladder']['policy'], record['ladder']['final_stage'], record['ladder']['status'], record['ladder']['head']),
             '', 'Before filing, the claimant or counsel must:'] + ['- ' + step for step in CHECKLIST] + [
             '', 'Other files in this packet (SHA-256):'] + ['- %s  %s' % (row['sha256'], row['name']) for row in names]
    return ('\n'.join(rows) + '\n').encode('ascii')


def packet(*, policy, adoptions, events, claimant, agreement, legal_context, terms_document, clause, particulars,
           award=None, evidence_files=(), expected_head=None):
    """Assemble the AAA filing aid from a ladder at its final stage. Nothing is filed, sent or paid."""
    from covenant_language import agreement_procedures as procedures
    state, respondent, cited = _ladder(policy, adoptions, events, expected_head, claimant)
    policy_id = procedures.identifier(policy)
    agreement_id = _agreement(agreement, policy['context'])
    discovery, route = _discovery(legal_context)
    need(type(terms_document) is bytes and 0 < len(terms_document) <= MAX_TERMS, 'AAA_TERMS')
    fingerprint = atr.atr_hash(terms_document)
    if 'atrHash' in discovery:
        need(atr.hash_equals(discovery['atrHash'], fingerprint), 'AAA_TERMS_FINGERPRINT')
    clause_report = _clause(clause, terms_document, agreement['document'], route)
    facts = _particulars(particulars)
    report = _award(award, policy_id, state)
    date = facts['prepared_on']
    media, extension = TERMS_FORMATS.get(discovery.get('termsFormat', 'plain'), ('text/plain', '.txt'))
    files = {}

    def add(title, extension, content, media_type):
        name = _name(date, title, extension)
        need(type(content) is bytes and 0 < len(content) <= MAX_FILE and name not in files, 'AAA_FILE')
        files[name] = (content, media_type)
        return name
    agreement_file = add('Arbitration Agreement Clause', '.txt', (clause.rstrip('\n') + '\n').encode('ascii'), 'text/plain')
    terms_file = add('Terms Document LCP', extension, terms_document, media)
    discovery_file = add('Legal Context Discovery Snapshot', '.json', legal_context, 'application/json')
    record_file = add('AAP Agreement Record', '.json', _json({'profile': agreement['profile'], 'id': agreement_id,
                                                               'document': agreement['document']}), 'application/json')
    ladder_file = add('AAP Dispute Ladder Record', '.json', _json({'policy': policy, 'policy_id': policy_id, 'adoptions': adoptions,
                                                                   'events': events, 'head': state['head']}), 'application/json')
    award_files = []
    if report is not None:
        award_files = [add('AAP Award', '.json', _json(award['award']), 'application/json'),
                       add('AAP Award', '.pdf', award['pdf'], 'application/pdf'),
                       add('AAP Award Detached Signatures', '.txt', ('\n'.join(award['detached']) + '\n').encode('ascii'), 'text/plain')]
    evidence = _evidence(evidence_files, cited, date)
    for name, (content, media_type, _) in evidence.items():
        need(name not in files, 'AAA_FILE'); files[name] = (content, media_type)
    supplied = {reference for _, _, reference in evidence.values()}
    record = {
        'legal_context': {'protocol': deepcopy(LCP), 'disputeResolution': route, 'terms': discovery['terms'],
                          'file': discovery_file, 'sha256': hashlib.sha256(legal_context).hexdigest(),
                          'standing': 'SERVICE_STATEMENT_NOT_TERMS (LCP 2.5, E.4)'},
        'agreement': {'profile': agreement['profile'], 'id': agreement_id, 'file': record_file, 'clause_file': agreement_file,
                      'clause': clause_report},
        'terms_fingerprint': {'atrHash': fingerprint, 'lcp': atr.to_lcp_string(fingerprint), 'file': terms_file,
                              'published_atrHash': discovery.get('atrHash')},
        'ladder': {'policy': policy_id, 'head': state['head'], 'status': state['status'],
                   'final_stage': policy['configuration']['stages'][state['round']]['name'],
                   'outcome': deepcopy(state['outcome']), 'claimant_role': claimant, 'respondent_role': respondent,
                   'file': ladder_file}}

    def listing():
        return [{'name': name, 'media_type': files[name][1], 'sha256': hashlib.sha256(files[name][0]).hexdigest(),
                 'bytes': len(files[name][0])} for name in sorted(files)]
    add('Claimant Filing Aid Cover Sheet', '.txt', _cover(record, facts, listing()), 'text/plain')
    need(sum(len(content) for content, _ in files.values()) <= MAX_TOTAL, 'AAA_FILE')
    manifest = {
        'version': VERSION, 'status': STATUS, 'notice': NOTICE, 'route': deepcopy(RULES), **record,
        'demand': {'parties': {'claimant': facts['claimant'], 'respondent': facts['respondent']},
                   'representatives': facts['representatives'], 'nature_of_claim': facts['nature_of_claim'],
                   'relief_sought': facts['relief_sought'], 'amount': facts['amount'],
                   'locale_requested': facts['locale_requested'], 'arbitrators_requested': facts['arbitrators_requested'],
                   'rule': 'R-4(a)(iv) a-e; number of arbitrators R-17(a)'},
        'track': track(facts['amount']),
        'evidence': [{'reference': reference, 'cited_by': sorted(set(ids)), 'supplied': reference in supplied}
                     for reference, ids in sorted(cited.items())],
        'award': None if report is None else {'id': report['id'], 'body_id': report['body_id'], 'pdf_sha256': report['pdf_sha256'],
                                              'files': award_files, 'legal_effect': 'NOT_ESTABLISHED'},
        'files': listing(), 'checklist': list(CHECKLIST),
        'prepared_on': date, **{name: value for name, value in FLAGS.items() if name != 'status'}}
    out = {name: content for name, (content, _) in files.items()}
    out[_name(date, 'AAP Filing Packet Manifest', '.json')] = _json(manifest)
    archive = _archive(out)
    return {'packet': manifest, 'id': packet_id(manifest), 'files': out, 'archive': archive,
            'archive_sha256': hashlib.sha256(archive).hexdigest(), **FLAGS}


def verify(files, expected_id):
    """Re-check a packet: the manifest id, the notice and every listed file's bytes."""
    key(expected_id)
    need(type(files) is dict and 0 < len(files) <= 128, 'AAA_PACKET')
    manifests = [name for name in files if name.endswith(' AAP Filing Packet Manifest.json')]
    need(len(manifests) == 1, 'AAA_PACKET')
    try:
        manifest = json.loads(files[manifests[0]].decode('ascii'))
    except (UnicodeError, ValueError, RecursionError):
        raise ValueError('AAA_PACKET') from None
    need(type(manifest) is dict and manifest.get('version') == VERSION and manifest.get('status') == STATUS
         and manifest.get('notice') == NOTICE and packet_id(manifest) == expected_id and type(manifest.get('files')) is list, 'AAA_PACKET')
    for row in manifest['files']:
        need(type(row) is dict and type(row.get('name')) is str, 'AAA_PACKET')
        content = files.get(row['name'])
        need(type(content) is bytes and hashlib.sha256(content).hexdigest() == row.get('sha256') and len(content) == row.get('bytes'), 'AAA_PACKET')
    need(set(files) == {row['name'] for row in manifest['files']} | {manifests[0]}, 'AAA_PACKET')
    return {'id': expected_id, 'files_verified': len(manifest['files']), 'ladder': manifest['ladder']['policy'],
            'terms_fingerprint': manifest['terms_fingerprint']['atrHash'], **FLAGS}


def read_archive(raw):
    """The files of a packet archive, bounded; nothing in it is executed."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_TOTAL + 1_048_576, 'AAA_PACKET')
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            rows = archive.infolist()
            need(len(rows) <= 128 and sum(row.file_size for row in rows) <= MAX_TOTAL, 'AAA_PACKET')
            need(all(row.compress_type == zipfile.ZIP_STORED and not row.is_dir() for row in rows), 'AAA_PACKET')
            files = {row.filename: archive.read(row) for row in rows}
    except ValueError as exc:
        if str(exc) == 'AAA_PACKET':
            raise
        raise ValueError('AAA_PACKET') from None
    except (zipfile.BadZipFile, zipfile.LargeZipFile, RuntimeError, NotImplementedError, EOFError, OSError, KeyError):
        raise ValueError('AAA_PACKET') from None
    need(len(files) == len(rows), 'AAA_PACKET')  # a repeated name would hide one file behind another
    return files


def describe():
    return {'version': VERSION, 'decision': 'IMPROVE', 'status': STATUS, 'notice': NOTICE, 'route': deepcopy(RULES),
            'legal_context_protocol': deepcopy(LCP),
            'requires': ['an AAP escalation ladder closed at its final stage', 'the AAP agreement whose id is the ladder context',
                         'the retained legal-context.json bytes and the exact terms document',
                         'an arbitration clause naming the AAA that appears in the terms or the AAP agreement',
                         'the claimant\'s R-4(a)(iv) particulars'],
            'contents': ['cover sheet', 'clause', 'terms document', 'discovery snapshot', 'AAP agreement record',
                         'ladder record', 'dual-format award when the ladder decided', 'cited evidence files', 'manifest'],
            'webfile': 'Names "YYYY-MM-DD Title.ext", at most 100 characters, none of & \' @ ^ $ ! ( ) % # ; (AAA WebFile guidelines 2023)',
            'not_done': ['filing', 'fee payment', 'service on the respondent', 'legal review', 'AAA acceptance'],
            'remediation': deepcopy(REMEDIATION), **FLAGS}
