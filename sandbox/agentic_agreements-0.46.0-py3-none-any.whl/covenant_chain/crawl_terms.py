"""Licence terms to agreement: RSL, TDMRep and ai.txt into typed AAP crawl terms.

GRAFT: supplied bytes are read under their own specifications, unchanged and
never fetched: RSL 1.0 licence XML and the robots.txt ``License`` directive,
TDMRep (``/.well-known/tdmrep.json`` and its ODRL TDM Policy), the ai.txt
Internet-Draft draft-car-ai-txt-wellknown-00 and the Legal Context Protocol
``disputeResolution`` object. Paths match as robots.txt rules do (RFC 9309
section 2.2.3).

TAKE-AND-IMPROVE: none of those documents is signed by both sides. Parsing
gives a proposal; the publisher signs typed ``urn:aap:crawl-terms:0.1`` terms
(permitted and prohibited uses, price model, attribution duty, limits, the
agreed dispute route) and the crawler operator assents to them through the
existing agreement_application meaning echoes and exact assent. A use the
publisher did not sign is not granted; a reservation never becomes a grant.

Nothing here fetches, signs, pays or grants access. Legal title, domain
control and enforceability are not established.
"""
from copy import deepcopy
import hashlib
import json
import re
from urllib.parse import urlsplit
import xml.etree.ElementTree as ElementTree

from covenant_language import agreement_application as app
from .crypto import exact, integer, key, need, verify
from . import interop_codec

PROFILE = 'urn:aap:crawl-terms:0.1'
LABEL = 'AAP-CRAWL-TERMS-0.1'
PROPOSAL = 'urn:aap:crawl-terms-proposal:0.1'
USES = ('AI_INDEX', 'AI_INPUT', 'AI_TRAIN', 'ARCHIVE', 'SEARCH')
MODELS = ('ATTRIBUTION', 'FREE', 'PER_CRAWL', 'PER_USE', 'PURCHASE', 'SUBSCRIPTION')
PAID = ('PER_CRAWL', 'PER_USE', 'PURCHASE', 'SUBSCRIPTION')
SOURCES = ('AI_TXT', 'LCP_DISCOVERY', 'ROBOTS_TXT', 'RSL_XML', 'TDMREP_JSON', 'TDM_POLICY')
FIELDS = 'version publisher origin content permits prohibits price attribution limits dispute sources opens expires nonce'
TERM_NAMES = ('attribution bot_keys content dispute expires limits opens origin permits period price price_model '
              'profile prohibits terms terms_id')
FLAGS = {'execution_authorized': False, 'access_authorized': False, 'payment_authorized': False,
         'legal_rights_established': False, 'world_truth': 'NOT_ESTABLISHED'}
MICRO = 10 ** 6
MAX_SOURCE = 65536
MAX_TERMS = 16384
MAX_PATTERNS = 32
REFERENCE = 'docs/CRAWL_LICENSING.html#'
PATTERN = re.compile(r'/[!-~]{0,511}\Z')
TEMPLATE = ('AAP crawl licence {{profile}} for publisher-signed terms {{terms_id}}: {{terms}}. Origin {{origin}}; '
            'licensed content {{content}}; permitted uses {{permits}}; prohibited uses {{prohibits}}. Price {{price}} '
            '({{price_model}}, period {{period}} seconds); attribution required {{attribution}}; limits {{limits}}. '
            'Dispute route {{dispute}}. Receipts are signed by the crawler bot keys {{bot_keys}}. Window {{opens}} to '
            '{{expires}}. RSL, TDMRep, ai.txt and LCP documents are sources, not permission: only these signed typed '
            'terms bind both sides, and no access, payment or legal title follows from them.')

# Every refusal: what happened, what to do next, and whether an unchanged retry can help.
ERRORS = {
    'CRAWL_TERMS_SOURCE': ('The source document is empty, too large or not the expected kind.',
                           'Pass the exact received bytes (at most 64 KiB) and the kind they were served as.', False),
    'CRAWL_TERMS_XML': ('The RSL document is not well-formed, uses a DTD or entity, or nests too deeply.',
                        'Send the RSL XML exactly as published; DOCTYPE and entity declarations are refused.', False),
    'CRAWL_TERMS_RSL': ('The RSL document does not follow the RSL 1.0 structure this reader accepts.',
                        'Check the element and attribute names against RSL 1.0; unknown values are refused, not guessed.', False),
    'CRAWL_TERMS_JSON': ('The JSON source is malformed, repeats a member name or exceeds the bounds.',
                         'Send one strict UTF-8 JSON value without duplicate names, as served.', False),
    'CRAWL_TERMS_TDMREP': ('The tdmrep.json rows or the TDM Policy do not follow the TDMRep report.',
                           'Use rows {location, tdm-reservation 0 or 1, optional tdm-policy} and an ODRL Offer with tdm:mine.', False),
    'CRAWL_TERMS_AI_TXT': ('The ai.txt file does not follow draft-car-ai-txt-wellknown-00.',
                           'Use its Key: Value lines and value sets; other ai.txt dialects stay uninterpreted pins.', False),
    'CRAWL_TERMS_LCP': ('The LCP discovery document or its disputeResolution object is malformed.',
                        'Send the exact /.well-known/legal-context.json bytes with a disputeResolution method.', False),
    'CRAWL_TERMS_URL': ('A URL is not an absolute https URL of the licensed origin.',
                        'Use https URLs without user information, fragments, backslashes or dot segments.', False),
    'CRAWL_TERMS_ORIGIN': ('The origin is not a bare https origin, or a URL belongs to another origin.',
                           'Name the origin as https://host with no path, and keep every URL on it.', False),
    'CRAWL_TERMS_PATTERN': ('A content pattern is not a robots.txt path rule.',
                            "Start with '/', use '*' for any characters and '$' only at the end (RFC 9309 2.2.3).", False),
    'CRAWL_TERMS_USES': ('Permitted or prohibited uses are unknown, unsorted, repeated, overlapping or empty.',
                         'Use sorted subsets of AI_INDEX, AI_INPUT, AI_TRAIN, ARCHIVE and SEARCH; permit at least one.', False),
    'CRAWL_TERMS_PRICE': ('The price does not fit its model.',
                          'FREE and ATTRIBUTION cost 0; paid models need a positive amount; only SUBSCRIPTION has a period.', False),
    'CRAWL_TERMS_CURRENCY': ('The currency is not a three-letter ISO 4217 code.', 'Use the code as published, for example USD.', False),
    'CRAWL_TERMS_AMOUNT': ('The amount is not an exact decimal of at most six fraction digits.',
                           'Write the amount as published, for example 0.01; amounts become integer micro-units.', False),
    'CRAWL_TERMS_UNIT': ('The money unit is not an ISO 4217 code with -micro.', 'Use a unit such as USD-micro.', False),
    'CRAWL_TERMS_ATTRIBUTION': ('The attribution duty is malformed or missing where the model requires it.',
                                'Give {required, text, standard}; the ATTRIBUTION model requires required true.', False),
    'CRAWL_TERMS_LIMITS': ('The limits are malformed.',
                           'Give {fetches, rate, users, geo}: a count, {count, window}, RSL user classes, {permits, prohibits} codes, or nulls.',
                           False),
    'CRAWL_TERMS_DISPUTE': ('The dispute route is malformed.',
                            'Give {ladder, forum, bond_cap, escrow}: 64-hex ids or null, an LCP forum or null, a bond cap.', False),
    'CRAWL_TERMS_SOURCES': ('A source pin is malformed or repeated.', 'Pin each source once as {kind, url, sha256, bytes}.', False),
    'CRAWL_TERMS_WINDOW': ('The licence window is empty or not integers.', 'Give integer opens before expires.', False),
    'CRAWL_TERMS_FIELDS': ('The terms carry missing or extra fields.', 'Build terms with crawl_terms.terms and send them unchanged.', False),
    'CRAWL_TERMS_SIZE': ('The terms are larger than 16 KiB.', 'Shorten patterns, notes or sources.', False),
    'CRAWL_TERMS_PUBLISHER': ('The publisher key is not a valid Ed25519 verification key.',
                              'Use the 64-hex Ed25519 key the publisher signs with.', False),
    'CRAWL_TERMS_SIGNATURE': ('The publisher signature does not verify over these exact terms.',
                              'Ask the publisher to sign the unchanged terms body; never edit terms to fit an old signature.', False),
    'CRAWL_TERMS_PARTIES': ('The crawler and publisher keys are missing, equal or invalid.',
                            'Use two different 64-hex Ed25519 keys, crawler and publisher.', False),
    'CRAWL_TERMS_BOT_KEYS': ('The bot key list is malformed.', 'List 1 to 8 sorted, distinct 64-hex Ed25519 keys.', False),
    'CRAWL_TERMS_APPLICATION': ('The agreement application is not the exact one these terms produce.',
                                'Draft the agreement again from the signed terms; do not edit typed terms.', False),
    'CRAWL_TERMS_ASSENT_UNKNOWN': ('No adoption record was supplied, so assent is unknown.',
                                   'Pass {echoes, approvals, expected_closure} from both parties.', True),
    'CRAWL_TERMS_MODEL': ('The finite agreement model did not rehearse as safe.', 'Report this; the terms profile is fixed.', False),
}


def explain(code):
    """Plain refusal: code, what happened, what to do next, whether retrying helps and its reference entry."""
    what, fix, retry = ERRORS.get(code, ('Unrecognised refusal.', 'Read the reference page.', False))
    return {'code': code, 'what': what, 'fix': fix, 'retry': retry, 'reference': REFERENCE + code}


def _text(value, code, limit=256):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _url(value, origin=None):
    _text(value, 'CRAWL_URL', 1024)
    need('\\' not in value and '%' not in value and all(ord(c) > 32 for c in value), 'CRAWL_URL')
    try:
        parsed = urlsplit(value)
    except ValueError:
        raise ValueError('CRAWL_URL') from None
    need(parsed.scheme == 'https' and parsed.netloc and parsed.hostname == parsed.netloc and not parsed.fragment
         and not any(piece in ('.', '..') for piece in parsed.path.split('/')), 'CRAWL_URL')
    need(len(parsed.hostname) <= 253 and all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label)
                                             for label in parsed.hostname.split('.')), 'CRAWL_URL')
    if origin is not None:
        need(value.startswith(origin + '/') and parsed.netloc == urlsplit(origin).netloc, 'CRAWL_ORIGIN')
    return parsed


def _origin(value):
    parsed = _url(value)
    need(not parsed.path and not parsed.query, 'CRAWL_ORIGIN')


def _checked(function, code, *args):
    try:
        return function(*args)
    except ValueError:
        raise ValueError(code) from None


def origin_of(value):
    """The bare https origin of a licence, or CRAWL_TERMS_ORIGIN."""
    _checked(_origin, 'CRAWL_TERMS_ORIGIN', value)
    return value


def money(currency, amount):
    """Exact published decimal to integer micro-units: ('USD', '0.01') -> 10000 USD-micro. Never a float."""
    need(type(currency) is str and re.fullmatch('[A-Z]{3}', currency) is not None, 'CRAWL_TERMS_CURRENCY')
    found = re.fullmatch(r'(0|[1-9][0-9]{0,8})(?:\.([0-9]{1,6}))?', amount) if type(amount) is str else None
    need(found is not None, 'CRAWL_TERMS_AMOUNT')
    return {'amount': int(found[1]) * MICRO + int((found[2] or '').ljust(6, '0')), 'unit': currency + '-micro'}


def unit(value):
    need(type(value) is str and re.fullmatch('[A-Z]{3}-micro', value) is not None, 'CRAWL_TERMS_UNIT')
    return value


def pattern(value):
    need(type(value) is str and PATTERN.fullmatch(value) is not None and '#' not in value
         and '$' not in value[:-1] and value.count('*') <= 16, 'CRAWL_TERMS_PATTERN')
    return value


def matches(rule, target):
    """robots.txt path matching (RFC 9309 section 2.2.3): '*' is any sequence, a final '$' ends the match.

    Linear left-to-right placement of the literal pieces; no regular expression, so no backtracking.
    """
    anchored = rule.endswith('$')
    pieces = (rule[:-1] if anchored else rule).split('*')
    if len(pieces) == 1:
        return target == pieces[0] if anchored else target.startswith(pieces[0])
    if not target.startswith(pieces[0]):
        return False
    position = len(pieces[0])
    for piece in pieces[1:-1]:
        found = target.find(piece, position)
        if found < 0:
            return False
        position = found + len(piece)
    last = pieces[-1]
    if anchored:
        return target.endswith(last) and len(target) - len(last) >= position
    return target.find(last, position) >= 0


def resource(value, origin):
    """A fetched URL on the licensed origin, normalised as RFC 3986 section 6.2.2 and RFC 9309 compare it.

    Percent-encoded unreserved octets are decoded and other hex is upper-cased (UTF-8 octets stay encoded); an
    encoded '/', '?', '#', '%', '\\', control octet or a dot segment is refused, because a server could resolve it
    to another path.
    Returns (url, path) where path is the path plus any query, the text rules match.
    """
    origin_of(origin)
    need(type(value) is str and 0 < len(value) <= 2048 and all(33 <= ord(c) <= 126 for c in value)
         and '\\' not in value, 'CRAWL_TERMS_URL')
    try:
        parsed = urlsplit(value)
    except ValueError:
        raise ValueError('CRAWL_TERMS_URL') from None
    need(parsed.scheme == 'https' and parsed.netloc == urlsplit(origin).netloc and not parsed.fragment
         and '#' not in value, 'CRAWL_TERMS_ORIGIN')

    def clean(text):
        out, index = [], 0
        while index < len(text):
            char = text[index]
            if char == '%':
                code = text[index + 1:index + 3]
                need(re.fullmatch('[0-9A-Fa-f]{2}', code) is not None, 'CRAWL_TERMS_URL')
                octet = int(code, 16)
                need(octet > 32 and octet != 127 and chr(octet) not in '/?#%\\', 'CRAWL_TERMS_URL')
                decoded = chr(octet)
                out.append(decoded if octet < 127 and (decoded.isalnum() or decoded in '-._~') else '%' + code.upper())
                index += 3
            else:
                out.append(char); index += 1
        return ''.join(out)
    path, query = clean(parsed.path or '/'), clean(parsed.query) if parsed.query else ''
    need(path[:1] == '/' and not any(piece in ('.', '..') for piece in path.split('/')), 'CRAWL_TERMS_URL')
    target = path + ('?' + query if query else '')
    return origin + target, target


def _uses(value, allow_empty):
    need(type(value) is list and len(value) <= len(USES) and (allow_empty or value)
         and all(item in USES for item in value) and value == sorted(set(value)), 'CRAWL_TERMS_USES')


def _key(value, code):
    need(type(value) is str, code)
    try:
        key(value); interop_codec.okp_jwk(value)
    except ValueError:
        raise ValueError(code) from None


def _pin(value):
    exact(value, 'kind url sha256 bytes')
    need(value['kind'] in SOURCES, 'CRAWL_TERMS_SOURCES')
    _checked(_url, 'CRAWL_TERMS_SOURCES', value['url'])
    need(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None
         and type(value['bytes']) is int and 0 < value['bytes'] <= MAX_SOURCE, 'CRAWL_TERMS_SOURCES')


def source_pin(kind, url, raw):
    """SHA-256 pin of exact supplied bytes. The pin records a source; it is never consent."""
    need(kind in SOURCES and type(raw) is bytes and 0 < len(raw) <= MAX_SOURCE, 'CRAWL_TERMS_SOURCE')
    pin = {'kind': kind, 'url': url, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    _pin(pin)
    return pin


def _forum(value):
    exact(value, 'method jurisdiction clause source catalog')
    _text(value['method'], 'CRAWL_TERMS_DISPUTE', 256)
    if value['jurisdiction'] is not None:
        _text(value['jurisdiction'], 'CRAWL_TERMS_DISPUTE', 256)
    need(value['clause'] is None or type(value['clause']) is str
         and re.fullmatch('sha256:0x[0-9a-f]{64}', value['clause']) is not None, 'CRAWL_TERMS_DISPUTE')
    for name in ('source', 'catalog'):
        if value[name] is not None:
            _checked(_url, 'CRAWL_TERMS_DISPUTE', value[name])


def _dispute(value):
    exact(value, 'ladder forum bond_cap escrow')
    for name in ('ladder', 'escrow'):
        need(value[name] is None or type(value[name]) is str and re.fullmatch('[0-9a-f]{64}', value[name]) is not None,
             'CRAWL_TERMS_DISPUTE')
    if value['forum'] is not None:
        _checked(_forum, 'CRAWL_TERMS_DISPUTE', value['forum'])
    need(type(value['bond_cap']) is int and 0 <= value['bond_cap'] <= 2 ** 53 - 1, 'CRAWL_TERMS_DISPUTE')


RSL_USERS = ('commercial', 'education', 'government', 'non-commercial', 'personal')
GEO = re.compile(r'(?:[A-Z]{2})\Z')


def _limits(value):
    exact(value, 'fetches rate users geo')
    users, geo = value['users'], value['geo']
    need(users is None or type(users) is list and 1 <= len(users) <= len(RSL_USERS)
         and all(item in RSL_USERS for item in users) and users == sorted(set(users)), 'CRAWL_TERMS_LIMITS')
    if geo is not None:
        need(type(geo) is dict and set(geo) == {'permits', 'prohibits'}, 'CRAWL_TERMS_LIMITS')
        for codes in geo.values():
            need(type(codes) is list and len(codes) <= 256
                 and all(type(code) is str and GEO.fullmatch(code) is not None for code in codes)
                 and codes == sorted(set(codes)), 'CRAWL_TERMS_LIMITS')
        need((geo['permits'] or geo['prohibits']) and not set(geo['permits']) & set(geo['prohibits']), 'CRAWL_TERMS_LIMITS')
    need(value['fetches'] is None or type(value['fetches']) is int and 1 <= value['fetches'] <= 2 ** 53 - 1,
         'CRAWL_TERMS_LIMITS')
    if value['rate'] is not None:
        rate = value['rate']
        need(type(rate) is dict and set(rate) == {'count', 'window'} and type(rate['count']) is int
             and type(rate['window']) is int and 1 <= rate['count'] <= 10 ** 9 and 1 <= rate['window'] <= 31536000,
             'CRAWL_TERMS_LIMITS')


def _attribution(value, model):
    exact(value, 'required text standard')
    need(type(value['required']) is bool and (model != 'ATTRIBUTION' or value['required']), 'CRAWL_TERMS_ATTRIBUTION')
    for name in ('text', 'standard'):
        if value[name] is not None:
            _text(value[name], 'CRAWL_TERMS_ATTRIBUTION', 512)


def _price(value):
    exact(value, 'model amount unit period')
    need(value['model'] in MODELS, 'CRAWL_TERMS_PRICE')
    unit(value['unit'])
    need(type(value['amount']) is int and type(value['period']) is int and 0 <= value['amount'] <= 2 ** 53 - 1
         and 0 <= value['period'] <= 31622400, 'CRAWL_TERMS_PRICE')
    paid = value['model'] in PAID
    need((value['amount'] > 0) == paid and (value['period'] > 0) == (value['model'] == 'SUBSCRIPTION'), 'CRAWL_TERMS_PRICE')


def validate(body):
    """Typed crawl terms, bounded and exact. Raises a CRAWL_TERMS_* code."""
    try:
        size = len(app.canonical(body))
    except ValueError as error:
        raise ValueError('CRAWL_TERMS_SIZE' if str(error) == 'APPLICATION_SIZE' else 'CRAWL_TERMS_FIELDS') from None
    need(size <= MAX_TERMS, 'CRAWL_TERMS_SIZE')
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'CRAWL_TERMS_FIELDS')
    need(body['version'] == PROFILE, 'CRAWL_TERMS_FIELDS')
    _key(body['publisher'], 'CRAWL_TERMS_PUBLISHER')
    origin_of(body['origin'])
    need(type(body['content']) is list and 1 <= len(body['content']) <= MAX_PATTERNS
         and all(type(item) is str for item in body['content'])
         and body['content'] == sorted(set(body['content'])), 'CRAWL_TERMS_PATTERN')
    for item in body['content']:
        pattern(item)
    _uses(body['permits'], False); _uses(body['prohibits'], True)
    need(not set(body['permits']) & set(body['prohibits']), 'CRAWL_TERMS_USES')
    _checked(_price, 'CRAWL_TERMS_PRICE', body['price'])
    need(type(body['attribution']) is dict, 'CRAWL_TERMS_ATTRIBUTION')
    _checked(_attribution, 'CRAWL_TERMS_ATTRIBUTION', body['attribution'], body['price']['model'])
    _checked(_limits, 'CRAWL_TERMS_LIMITS', body['limits'])
    _checked(_dispute, 'CRAWL_TERMS_DISPUTE', body['dispute'])
    need(type(body['sources']) is list and len(body['sources']) <= 8, 'CRAWL_TERMS_SOURCES')
    for row in body['sources']:
        _checked(_pin, 'CRAWL_TERMS_SOURCES', row)
    need(len({(row['kind'], row['sha256']) for row in body['sources']}) == len(body['sources']), 'CRAWL_TERMS_SOURCES')
    need(type(body['opens']) is int and type(body['expires']) is int and 0 <= body['opens'] < body['expires'] <= 2 ** 53 - 1,
         'CRAWL_TERMS_WINDOW')
    need(type(body['nonce']) is str and re.fullmatch('[0-9a-f]{64}', body['nonce']) is not None, 'CRAWL_TERMS_FIELDS')
    return body


def terms(*, publisher, origin, content, permits, prohibits=(), price=None, attribution=None, limits=None,
          dispute=None, sources=(), opens, expires, nonce):
    """Typed terms for the publisher to sign. Defaults: free, no attribution, no limits, no dispute route."""
    for values, code in ((content, 'CRAWL_TERMS_PATTERN'), (permits, 'CRAWL_TERMS_USES'), (prohibits, 'CRAWL_TERMS_USES')):
        need(type(values) in (list, tuple) and len(values) <= 64 and all(type(item) is str for item in values), code)
    need(type(sources) in (list, tuple) and len(sources) <= 8 and all(
        type(row) is dict and type(row.get('kind')) is str and type(row.get('sha256')) is str for row in sources),
        'CRAWL_TERMS_SOURCES')
    body = {'version': PROFILE, 'publisher': publisher, 'origin': origin, 'content': sorted(set(content)),
            'permits': sorted(set(permits)), 'prohibits': sorted(set(prohibits)),
            'price': deepcopy(price) if price is not None else {'model': 'FREE', 'amount': 0, 'unit': 'USD-micro', 'period': 0},
            'attribution': deepcopy(attribution) if attribution is not None else {'required': False, 'text': None, 'standard': None},
            'limits': deepcopy(limits) if limits is not None else {'fetches': None, 'rate': None, 'users': None, 'geo': None},
            'dispute': deepcopy(dispute) if dispute is not None else {'ladder': None, 'forum': None, 'bond_cap': 0, 'escrow': None},
            'sources': sorted((deepcopy(row) for row in sources), key=lambda row: (row['kind'], row['sha256'])),
            'opens': opens, 'expires': expires, 'nonce': nonce}
    return validate(body)


def terms_id(body):
    return app.content_id(LABEL, validate(body))


def terms_payload(body):
    """What the publisher signs. Preparing it signs nothing."""
    validate(body)
    return {'label': LABEL, 'body': deepcopy(body), 'id': app.content_id(LABEL, body),
            'next': 'The publisher signs body under label; the crawler operator then drafts the agreement.', **FLAGS}


def verify_terms(signed):
    """(body, id) of publisher-signed terms, or CRAWL_TERMS_SIGNATURE."""
    need(type(signed) is dict and set(signed) == {'body', 'signature'}, 'CRAWL_TERMS_FIELDS')
    body = validate(signed['body'])
    _checked(verify, 'CRAWL_TERMS_SIGNATURE', body['publisher'], LABEL, body, signed['signature'])
    return body, app.content_id(LABEL, body)


def _bot_keys(value, crawler):
    keys = [crawler] if value is None else value
    need(type(keys) is list and 1 <= len(keys) <= 8 and all(type(item) is str for item in keys)
         and keys == sorted(set(keys)), 'CRAWL_TERMS_BOT_KEYS')
    for item in keys:
        _key(item, 'CRAWL_TERMS_BOT_KEYS')
    return keys


def _canonical_text(value):
    return app.canonical(value).decode('ascii')


def _application(signed, crawler, context, bot_keys):
    body, ident = verify_terms(signed)
    _key(crawler, 'CRAWL_TERMS_PARTIES')
    need(crawler != body['publisher'], 'CRAWL_TERMS_PARTIES')
    need(type(context) is str and re.fullmatch('[0-9a-f]{64}', context) is not None, 'CRAWL_TERMS_PARTIES')
    keys = _bot_keys(bot_keys, crawler)
    price = body['price']
    typed = {'profile': {'kind': 'TEXT', 'value': PROFILE}, 'terms_id': {'kind': 'HASH', 'value': ident},
             'terms': {'kind': 'TEXT', 'value': _canonical_text(signed)},
             'origin': {'kind': 'TEXT', 'value': body['origin']},
             'price': {'kind': 'MONEY', 'amount': price['amount'], 'unit': price['unit']},
             'price_model': {'kind': 'TEXT', 'value': price['model']},
             'period': {'kind': 'INTEGER', 'value': price['period']},
             'attribution': {'kind': 'BOOLEAN', 'value': body['attribution']['required']},
             'bot_keys': {'kind': 'TEXT', 'value': _canonical_text(keys)},
             'opens': {'kind': 'INTEGER', 'value': body['opens']}, 'expires': {'kind': 'INTEGER', 'value': body['expires']}}
    for name in ('content', 'permits', 'prohibits', 'limits', 'dispute'):
        typed[name] = {'kind': 'TEXT', 'value': _canonical_text(body[name])}
    machine = {'states': ['ACTIVE', 'CLOSED'], 'initial': 'ACTIVE', 'terminals': ['CLOSED'],
               'events': {'CLOSE': ['crawler', 'publisher']}, 'facts': [],
               'transitions': [{'from': 'ACTIVE', 'event': 'CLOSE', 'to': 'CLOSED', 'guard': {}, 'release': []}]}
    norms = [app.norm('crawler_stop', 'POWER', 'crawler', 'CLOSE'), app.norm('publisher_stop', 'POWER', 'publisher', 'CLOSE')]
    made = app.draft('AAP crawl licence', {'crawler': crawler, 'publisher': body['publisher']}, context, norms, machine,
                     {'amount': 0, 'unit': price['unit']},
                     {'scope': {'kind': 'HASH', 'value': app.content_id('AAP-CRAWL-TERMS-SCOPE-0.1', body)}},
                     TEMPLATE, terms=typed)
    return made, body, ident, keys


def draft_agreement(signed, crawler, context, bot_keys=None):
    """The exact AAP agreement both sides sign: meaning echoes first, then exact assent. Signs nothing."""
    made, _body, ident, _keys = _application(signed, crawler, context, bot_keys)
    application = made['application']
    report = app.rehearse(application)
    need(report['status'] == 'SAFE_WITHIN_MODEL', 'CRAWL_TERMS_MODEL')
    return {**made, 'profile': PROFILE, 'terms': ident, 'rehearsal': report,
            'echo_payloads': {role: app.echo_payload(application, role, application['acceptance'])
                              for role in ('crawler', 'publisher')},
            'next': 'Both roles sign their meaning echo, call agreement_application.prepare, then sign the exact '
                    'assent payload. The publisher signature on the terms is already required; no access follows.',
            **FLAGS}


def licence(signed, application, agreement, adoption):
    """The verified licence both sides assented to, or a refusal. Recomputed from the signatures every time."""
    need(type(application) is dict and type(application.get('terms')) is dict and type(application.get('parties')) is dict,
         'CRAWL_TERMS_APPLICATION')
    need(application['terms'].get('profile') == {'kind': 'TEXT', 'value': PROFILE}
         and set(application['terms']) == set(TERM_NAMES.split()), 'CRAWL_TERMS_APPLICATION')
    try:
        keys = json.loads(application['terms']['bot_keys']['value'])
    except (TypeError, ValueError, KeyError):
        raise ValueError('CRAWL_TERMS_APPLICATION') from None
    crawler = application['parties'].get('crawler')
    made, body, ident, keys = _application(signed, crawler, application.get('context'), keys)
    need(app.canonical(application) == app.canonical(made['application']), 'CRAWL_TERMS_APPLICATION')
    need(adoption is not None, 'CRAWL_TERMS_ASSENT_UNKNOWN')
    need(type(adoption) is dict and set(adoption) == {'echoes', 'approvals', 'expected_closure'}, 'CRAWL_TERMS_ASSENT_UNKNOWN')
    checked = app.verify(application, adoption['echoes'], adoption['approvals'], agreement, adoption['expected_closure'])
    return {'profile': PROFILE, 'terms': ident, 'body': deepcopy(body), 'application': checked['application'],
            'agreement': agreement, 'crawler': crawler, 'publisher': body['publisher'], 'bot_keys': keys,
            'assent': 'BOTH_PARTIES_VERIFIED', 'currentness': 'UNKNOWN; CALLER_RETAINED_ONLY', **FLAGS}


def scope(body, url, use, at):
    """IN_SCOPE only when the signed content, uses and window all cover this event; otherwise every reason."""
    validate(body)
    need(use in USES, 'CRAWL_TERMS_USES')
    integer(at)
    return _scope(body, url, use, at)


def _scope(body, url, use, at):
    reasons = []
    try:
        _url_text, target = resource(url, body['origin'])
    except ValueError as error:
        return {'status': 'OUT_OF_SCOPE', 'reasons': [str(error)]}
    if not any(matches(rule, target) for rule in body['content']):
        reasons.append('CONTENT_NOT_LICENSED')
    if use in body['prohibits']:
        reasons.append('USE_PROHIBITED')
    elif use not in body['permits']:
        reasons.append('USE_NOT_GRANTED')
    if not body['opens'] <= at < body['expires']:
        reasons.append('OUTSIDE_WINDOW')
    return {'status': 'OUT_OF_SCOPE' if reasons else 'IN_SCOPE', 'reasons': reasons}


# Sources. Each returns pins and proposals; a proposal is data for the publisher to review and sign.

def _proposal(source, content, permits, prohibits, *, price=None, attribution=None, limits=None, notes=(), links=()):
    """Data for the publisher to review. Prohibitions win over permits (RSL 1.0 sections 3.5-3.6)."""
    return {'version': PROPOSAL, 'source': source, 'content': sorted(set(content)),
            'permits': sorted(set(permits) - set(prohibits)), 'prohibits': sorted(set(prohibits)), 'price': price,
            'attribution': attribution or {'required': False, 'text': None, 'standard': None},
            'limits': limits or {'fetches': None, 'rate': None, 'users': None, 'geo': None}, 'notes': sorted(set(notes)),
            'links': sorted(set(links)), 'status': 'PROPOSAL_NOT_AGREEMENT; PUBLISHER_SIGNATURE_AND_CRAWLER_ASSENT_REQUIRED'}


def _json(raw, code):
    need(type(raw) is bytes and 0 < len(raw) <= MAX_SOURCE, 'CRAWL_TERMS_SOURCE')
    try:
        return interop_codec.parse(raw, MAX_SOURCE, 16, 4096, 4096)
    except ValueError:
        raise ValueError(code) from None


def _path_of(location, origin, code):
    """A TDMRep location or ai.txt glob as a path rule on the origin."""
    need(type(location) is str and 0 < len(location) <= 512, code)
    if location.startswith('https://'):
        need(location.startswith(origin + '/'), code)
        location = location[len(origin):]
    try:
        return pattern(location)
    except ValueError:
        raise ValueError(code) from None


def from_tdmrep(raw, url, origin, *, policy=None, policy_url=None):
    """TDMRep tdmrep.json (TDMRep CG final report, 10 May 2024, section 6.1) and an optional TDM Policy (section 7).

    A reservation (tdm-reservation 1) is recorded, never turned into a grant, and 0 is not a grant either.
    A supplied TDM Policy is an ODRL Offer of tdm:mine; it becomes an AI_TRAIN proposal whose duties
    (compensate, obtainConsent) and purpose constraint stay notes the publisher prices and signs.
    """
    origin_of(origin)
    rows = _json(raw, 'CRAWL_TERMS_TDMREP')
    pin = _checked(source_pin, 'CRAWL_TERMS_TDMREP', 'TDMREP_JSON', url, raw)
    need(type(rows) is list and 1 <= len(rows) <= 64, 'CRAWL_TERMS_TDMREP')
    reservations, policies = [], set()
    for row in rows:
        need(type(row) is dict and {'location', 'tdm-reservation'} <= set(row) <= {'location', 'tdm-reservation', 'tdm-policy'},
             'CRAWL_TERMS_TDMREP')
        need(type(row['tdm-reservation']) is int and row['tdm-reservation'] in (0, 1), 'CRAWL_TERMS_TDMREP')
        link = row.get('tdm-policy')
        if link is not None:
            _checked(_url, 'CRAWL_TERMS_TDMREP', link)
            policies.add(link)
        reservations.append({'pattern': _path_of(row['location'], origin, 'CRAWL_TERMS_TDMREP'),
                             'reserved': row['tdm-reservation'] == 1, 'policy': link})
    proposals, pins = [], [pin]
    if policy is not None:
        need(policy_url in policies, 'CRAWL_TERMS_TDMREP')
        offer = _json(policy, 'CRAWL_TERMS_TDMREP')
        pins.append(_checked(source_pin, 'CRAWL_TERMS_TDMREP', 'TDM_POLICY', policy_url, policy))
        need(type(offer) is dict and offer.get('@type') == 'Offer' and offer.get('profile') == 'http://www.w3.org/ns/tdmrep'
             and type(offer.get('uid')) is str and type(offer.get('permission')) is list and 1 <= len(offer['permission']) <= 16
             and 'assigner' in offer, 'CRAWL_TERMS_TDMREP')
        notes = ['TDM_POLICY_OFFER']
        for grant in offer['permission']:
            need(type(grant) is dict and grant.get('action') == 'tdm:mine', 'CRAWL_TERMS_TDMREP')
            duties, constraints = grant.get('duty', []), grant.get('constraint', [])
            need(type(duties) is list and type(constraints) is list and len(duties) <= 8 and len(constraints) <= 8,
                 'CRAWL_TERMS_TDMREP')
            for duty in duties:
                need(type(duty) is dict and duty.get('action') in ('compensate', 'obtainConsent'), 'CRAWL_TERMS_TDMREP')
                notes.append('DUTY_' + duty['action'].upper())
            for constraint in constraints:
                need(type(constraint) is dict and constraint.get('leftOperand') == 'purpose' and constraint.get('operator') == 'eq'
                     and constraint.get('rightOperand') in ('tdm:research', 'tdm:non-research'), 'CRAWL_TERMS_TDMREP')
                notes.append('PURPOSE_' + constraint['rightOperand'].split(':')[1].upper().replace('-', '_'))
        covered = [row['pattern'] for row in reservations if row['policy'] == policy_url]
        proposals.append(_proposal('TDM_POLICY', covered, ['AI_TRAIN'], [], notes=notes))
    return {'kind': 'TDMREP_JSON', 'sources': pins, 'reservations': reservations, 'proposals': proposals,
            'grants': 'NONE_FROM_A_RESERVATION_VALUE', **FLAGS}


RSL_NS = 'https://rslstandard.org/rsl'
# RSL 1.0 section 3.4.1.1. Prohibiting "all" also prohibits archiving (any automated processing); permitting
# "all" grants only the uses RSL names, so archiving is never assumed from it.
RSL_USAGE = {'search': ('SEARCH',), 'ai-train': ('AI_TRAIN',), 'ai-input': ('AI_INPUT',), 'ai-index': ('AI_INDEX',),
             'ai-all': ('AI_INDEX', 'AI_INPUT', 'AI_TRAIN'), 'all': ('AI_INDEX', 'AI_INPUT', 'AI_TRAIN', 'SEARCH')}
# RSL 1.0 section 3.7 payment types. "training" is paid per training use; "contribution" has no fixed price.
RSL_PAYMENTS = {'free': 'FREE', 'attribution': 'ATTRIBUTION', 'crawl': 'PER_CRAWL', 'use': 'PER_USE',
                'training': 'PER_USE', 'purchase': 'PURCHASE', 'subscription': 'SUBSCRIPTION', 'contribution': None}
RSL_LEGAL = {'warranty': ('authority', 'no-infringement', 'no-malware', 'ownership', 'privacy-consent'),
             'disclaimer': ('as-is', 'no-indemnity', 'no-liability', 'no-warranty'),
             'attestation': ('false', 'true'), 'contact': None, 'proof': None}
QNAME = re.compile(r'[A-Za-z_][A-Za-z0-9_.-]*:[A-Za-z_][A-Za-z0-9_.-]*\Z')
DATETIME = re.compile(r'-?[0-9]{4,}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:[0-9]{2})?\Z')
DECIMAL = re.compile(r'\+?([0-9]*)(?:\.([0-9]*))?\Z')


def _xml(raw):
    """Well-formed XML 1.0 without DTDs or entity declarations, at most 64 KiB, depth 16 and 2048 elements."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_SOURCE, 'CRAWL_TERMS_SOURCE')
    folded = raw.lower()
    need(b'<!doctype' not in folded and b'<!entity' not in folded, 'CRAWL_TERMS_XML')
    try:
        parser = ElementTree.XMLParser()
        parser.feed(raw)
        root = parser.close()
    except (ElementTree.ParseError, ValueError, UnicodeError):
        raise ValueError('CRAWL_TERMS_XML') from None
    pending, count = [(root, 0)], 0
    while pending:
        node, depth = pending.pop()
        count += 1
        need(depth <= 16 and count <= 2048, 'CRAWL_TERMS_XML')
        pending.extend((child, depth + 1) for child in node)
    return root


def _rsl_children(element, allowed):
    """RSL children by local name. Other namespaces are extensions and ignored (RSL 1.0 section 3, errata
    2026-08-07); an unknown RSL-namespace element makes the document non-conformant."""
    found = []
    for child in element:
        if type(child.tag) is str and child.tag.startswith('{' + RSL_NS + '}'):
            name = child.tag[len(RSL_NS) + 2:]
            need(name in allowed, 'CRAWL_TERMS_RSL')
            found.append((name, child))
    return found


def _rsl_attributes(element, allowed, required=(), foreign=False):
    for name in element.attrib:
        need(name in allowed or foreign and name.startswith('{'), 'CRAWL_TERMS_RSL')
    need(all(name in element.attrib for name in required), 'CRAWL_TERMS_RSL')


def _rsl_text(element, limit=2048):
    text = (element.text or '').strip()
    need(len(text) <= limit and all(32 <= ord(c) <= 126 or c in '\t\r\n' for c in text), 'CRAWL_TERMS_RSL')
    return text


def _rsl_tokens(element, kind):
    tokens = _rsl_text(element).split()
    need(1 <= len(tokens) <= 64, 'CRAWL_TERMS_RSL')
    for token in tokens:
        if kind == 'geo':
            need(GEO.fullmatch(token) is not None, 'CRAWL_TERMS_RSL')
        else:
            known = RSL_USAGE if kind == 'usage' else RSL_USERS
            need(token in known or QNAME.fullmatch(token) is not None, 'CRAWL_TERMS_RSL')
    return tokens


def _rsl_amount(currency, text):
    found = DECIMAL.fullmatch(text)
    need(found is not None and (found[1] or found[2]), 'CRAWL_TERMS_AMOUNT')
    whole, fraction = found[1].lstrip('0') or '0', (found[2] or '').rstrip('0')
    return money(currency, whole + ('.' + fraction if fraction else ''))


def _rsl_licence(element, rule, links, notes, copyright_name):
    _rsl_attributes(element, ())
    kids = _rsl_children(element, ('permits', 'prohibits', 'payment', 'reporting', 'legal'))
    grants, bans, legal = {}, {}, {}
    notes, links = list(notes), list(links)
    for name, child in kids:
        if name in ('permits', 'prohibits'):
            _rsl_attributes(child, ('type',), ('type',))
            kind = child.get('type')
            need(kind in ('usage', 'user', 'geo'), 'CRAWL_TERMS_RSL')
            target = grants if name == 'permits' else bans
            need(kind not in target, 'CRAWL_TERMS_RSL')
            target[kind] = _rsl_tokens(child, kind)
        elif name == 'legal':
            _rsl_attributes(child, ('type',), ('type',))
            kind = child.get('type')
            need(kind in RSL_LEGAL and kind not in legal, 'CRAWL_TERMS_RSL')
            values = _rsl_text(child).split()
            need(values and (RSL_LEGAL[kind] is None or all(value in RSL_LEGAL[kind] for value in values))
                 and (kind not in ('attestation', 'contact') or len(values) == 1), 'CRAWL_TERMS_RSL')
            legal[kind] = values
        elif name == 'reporting':
            _rsl_attributes(child, ('type', 'profile', 'endpoint'), ('type', 'profile'))
            need(child.get('type') in ('audit', 'provenance', 'telemetry') and 0 < len(child.get('profile')) <= 1024
                 and ':' in child.get('profile'), 'CRAWL_TERMS_RSL')
            endpoint = child.get('endpoint')
            need(endpoint is None or re.fullmatch(r'https://[!-~]{1,1016}', endpoint) is not None, 'CRAWL_TERMS_RSL')
            notes.append('REPORTING_' + child.get('type').upper() + '_REQUIRED')
            links.append(child.get('profile'))
    payments = [child for name, child in kids if name == 'payment']
    need(len(payments) <= 1, 'CRAWL_TERMS_RSL')
    price, attribution = None, {'required': False, 'text': None, 'standard': None}
    if not payments:
        price = {'model': 'FREE', 'amount': 0, 'unit': 'USD-micro', 'period': 0}
        notes.append('RSL_NO_PAYMENT_MEANS_FREE')
    else:
        payment = payments[0]
        _rsl_attributes(payment, ('type',))
        kind = payment.get('type')
        need(kind is None or kind in RSL_PAYMENTS or QNAME.fullmatch(kind) is not None, 'CRAWL_TERMS_RSL')
        parts = _rsl_children(payment, ('standard', 'custom', 'amount', 'accepts'))
        need(len({name for name, _child in parts}) == len(parts), 'CRAWL_TERMS_RSL')
        part = dict(parts)
        amount = None
        if 'amount' in part:
            _rsl_attributes(part['amount'], ('currency',), ('currency',))
            amount = _rsl_amount(part['amount'].get('currency'), _rsl_text(part['amount'], 64))
        for name in ('standard', 'custom'):
            if name in part:
                _rsl_attributes(part[name], ())
                value = _rsl_text(part[name], 1024)
                need(value, 'CRAWL_TERMS_RSL')
                links.append(value)
        if 'accepts' in part:
            _rsl_attributes(part['accepts'], ('type',), ('type',))
            need(re.fullmatch(r'[a-z]+/[!-~]{1,126}', part['accepts'].get('type')) is not None, 'CRAWL_TERMS_RSL')
            notes.append('ACCEPTS ' + part['accepts'].get('type'))
        model = RSL_PAYMENTS.get(kind)
        if kind is None:
            notes.append('RSL_PAYMENT_TYPE_ABSENT_PRICE_NOT_ASSUMED')
        elif kind not in RSL_PAYMENTS:
            notes.append('RSL_PAYMENT_EXTENSION_NOT_INTERPRETED')
        elif kind == 'contribution':
            notes.append('RSL_CONTRIBUTION_PRICE_FOR_PUBLISHER')
        elif model in ('FREE', 'ATTRIBUTION'):
            price = {'model': model, 'amount': 0, 'unit': amount['unit'] if amount else 'USD-micro', 'period': 0}
            if model == 'ATTRIBUTION':
                attribution = {'required': True, 'text': copyright_name,
                               'standard': _rsl_text(part['standard'], 512) if 'standard' in part else None}
        elif amount is None or amount['amount'] == 0:
            notes.append('RSL_AMOUNT_ABSENT_PRICE_FOR_PUBLISHER')
        else:
            price = {'model': model, 'amount': amount['amount'], 'unit': amount['unit'], 'period': None if model == 'SUBSCRIPTION' else 0}
            if kind == 'training':
                notes.append('RSL_TRAINING_PRICED_PER_TRAINING_USE')
            if model == 'SUBSCRIPTION':
                notes.append('RSL_SUBSCRIPTION_PERIOD_FOR_PUBLISHER')
    permits, prohibits = set(), set()
    if 'usage' in grants:
        for token in grants['usage']:
            permits.update(RSL_USAGE.get(token, ()))
            if token not in RSL_USAGE:
                notes.append('RSL_PERMIT_EXTENSION_NOT_INTERPRETED')
    else:
        notes.append('RSL_NO_USAGE_PERMITS_NOTHING_GRANTED')
    for token in bans.get('usage', ()):
        prohibits.update(RSL_USAGE.get(token, ()))
        if token == 'all':
            prohibits.add('ARCHIVE')
        elif token not in RSL_USAGE:
            notes.append('RSL_PROHIBITION_EXTENSION_NOT_INTERPRETED')
    if 'all' in grants.get('usage', ()):
        notes.append('RSL_ALL_DOES_NOT_GRANT_ARCHIVE')
    users = None
    if 'user' in grants or 'user' in bans:
        allowed = set(grants['user']) & set(RSL_USERS) if 'user' in grants else set(RSL_USERS)
        users = sorted(allowed - set(bans.get('user', ())))
        if users == []:
            notes.append('RSL_NO_USER_CLASS_REMAINS')
        users = users or None
    geo = None
    if 'geo' in grants or 'geo' in bans:
        geo = {'permits': sorted(set(grants.get('geo', ())) - set(bans.get('geo', ()))), 'prohibits': sorted(set(bans.get('geo', ())))}
    for kind, values in sorted(legal.items()):
        if kind in ('warranty', 'disclaimer'):
            notes.extend(kind.upper() + ' ' + value for value in values)
        elif kind == 'attestation' and values == ['true']:
            notes.append('LEGAL_ATTESTATION')
        elif kind in ('contact', 'proof'):
            links.extend(values)
    return _proposal('RSL_XML', [rule], permits, prohibits, price=price, attribution=attribution,
                     limits={'fetches': None, 'rate': None, 'users': users, 'geo': geo}, notes=notes, links=links)


def from_rsl(raw, url, origin):
    """RSL 1.0 licence XML (RSL-SPEC-1.0, published 2025-12-10, errata to 2026-08-07) as proposals.

    One proposal per <content> and <license>: several licences in one content are alternatives. Usage tokens map
    search, ai-train, ai-input and ai-index to SEARCH, AI_TRAIN, AI_INPUT and AI_INDEX; a prohibition wins. A
    licence with no usage permits grants nothing here (RSL 1.0 leaves that default open). Extension tokens,
    reporting profiles, licence servers (OLP) and legal statements are kept as notes and links, never executed.
    """
    origin_of(origin)
    root = _xml(raw)
    pin = _checked(source_pin, 'CRAWL_TERMS_RSL', 'RSL_XML', url, raw)
    need(root.tag == '{' + RSL_NS + '}rsl', 'CRAWL_TERMS_RSL')
    _rsl_attributes(root, ('max-age',), foreign=True)
    age = root.get('max-age')
    need(age is None or re.fullmatch('[1-9][0-9]{0,5}', age) is not None, 'CRAWL_TERMS_RSL')
    proposals = []
    for _name, content in _rsl_children(root, ('content',)):
        _rsl_attributes(content, ('url', 'server', 'encrypted', 'lastmod'), ('url',))
        rule = _path_of(content.get('url'), origin, 'CRAWL_TERMS_RSL')
        notes, links = ['RSL_1_0'], []
        server, encrypted = content.get('server'), content.get('encrypted', 'false')
        need(encrypted in ('true', 'false') and (encrypted == 'false' or server is not None), 'CRAWL_TERMS_RSL')
        if server is not None:
            _checked(_url, 'CRAWL_TERMS_RSL', server)
            notes.append('RSL_OLP_LICENCE_SERVER_TOKEN_REQUIRED'); links.append(server)
        if encrypted == 'true':
            notes.append('RSL_EMS_ENCRYPTED')
        need(content.get('lastmod') is None or DATETIME.fullmatch(content.get('lastmod')) is not None, 'CRAWL_TERMS_RSL')
        kids = _rsl_children(content, ('license', 'alternate', 'schema', 'copyright', 'terms'))
        names = [name for name, _child in kids]
        need('license' in names and all(names.count(name) <= 1 for name in ('schema', 'copyright', 'terms')), 'CRAWL_TERMS_RSL')
        copyright_name = None
        for name, child in kids:
            if name == 'copyright':
                _rsl_attributes(child, ('type', 'contactEmail', 'contactUrl'))
                need(child.get('type') in (None, 'person', 'organization'), 'CRAWL_TERMS_RSL')
                copyright_name = _rsl_text(child, 512) or None
            elif name == 'terms':
                _rsl_attributes(child, ())
                links.append(_rsl_text(child, 1024))
            elif name == 'schema':
                _rsl_attributes(child, ('type',))
                need(child.get('type') in (None, 'application/ld+json'), 'CRAWL_TERMS_RSL')
            elif name == 'alternate':
                _rsl_attributes(child, ('type',))
        for name, child in kids:
            if name == 'license':
                proposals.append(_rsl_licence(child, rule, links, notes, copyright_name))
    return {'kind': 'RSL_XML', 'version': 'RSL 1.0', 'namespace': RSL_NS, 'sources': [pin], 'proposals': proposals,
            'max_age_days': int(age) if age is not None else 30, 'grants': 'NONE_UNTIL_PUBLISHER_SIGNS', **FLAGS}


def robots_licences(raw, url, *, agent=None):
    """RSL 1.0 section 4.4: License lines in robots.txt. A line inside the User-agent group a crawler selects
    (RFC 9309 section 2.2.1) replaces the global ones for that crawler. Nothing is fetched or allowed by it."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_SOURCE, 'CRAWL_TERMS_SOURCE')
    pin = _checked(source_pin, 'CRAWL_TERMS_SOURCE', 'ROBOTS_TXT', url, raw)
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('CRAWL_TERMS_SOURCE') from None
    need(agent is None or type(agent) is str and re.fullmatch(r'[A-Za-z_-]{1,64}', agent) is not None, 'CRAWL_TERMS_SOURCE')
    lines = text.split('\n')
    need(len(lines) <= 8192, 'CRAWL_TERMS_SOURCE')
    general, groups, current = [], [], None
    for line in lines:
        name, separator, value = line.split('#', 1)[0].partition(':')
        name, value = name.strip().lower(), value.strip()
        if not separator:
            continue
        if name == 'user-agent':
            if current is None or current['rules']:
                current = {'agents': set(), 'licences': [], 'rules': False}
                groups.append(current)
            current['agents'].add(value.lower())
        elif name == 'license':
            _checked(_url, 'CRAWL_TERMS_SOURCE', value)
            (general if current is None else current['licences']).append(value)
            if current is not None:
                current['rules'] = True
        elif current is not None and name in ('allow', 'disallow'):
            current['rules'] = True
    token = None if agent is None else agent.lower()
    chosen = [group for group in groups if token is not None and token in group['agents']] or \
             [group for group in groups if '*' in group['agents']]
    scoped = sorted({link for group in chosen for link in group['licences']})
    return {'licences': scoped or sorted(set(general)), 'scope': 'GROUP' if scoped else 'GLOBAL' if general else 'NONE',
            'source': pin, 'fetched': False, **FLAGS}


AI_TXT_FIELDS = {'Training': ('allow', 'deny', 'conditional'), 'Scraping': ('allow', 'deny'),
                 'Indexing': ('allow', 'deny'), 'Caching': ('allow', 'deny')}
AI_TXT_USES = {'Training': 'AI_TRAIN', 'Scraping': 'AI_INPUT', 'Indexing': 'SEARCH', 'Caching': 'ARCHIVE'}
AI_TXT_DEFAULTS = {'Training': 'deny', 'Scraping': 'allow', 'Indexing': 'allow', 'Caching': 'allow'}
AI_TXT_SITE = frozenset(('Spec-Version', 'Generated-At', 'Site-Name', 'Site-URL', 'Description', 'Contact', 'Policy-URL',
                         'Training-License', 'Training-Fee', 'Attribution', 'AI-Disclosure', 'Audit', 'Audit-Format'))
AI_TXT_WINDOWS = {'second': 1, 'minute': 60, 'hour': 3600, 'day': 86400}


def from_ai_txt(raw, url, origin, *, agent=None):
    """ai.txt as draft-car-ai-txt-wellknown-00 (12 June 2026) sections 2.3-2.9 define it. Other ai.txt dialects
    share the name but not the syntax; pin them with source_pin and read nothing from them.

    Training, Scraping, Indexing and Caching map to AI_TRAIN, AI_INPUT, SEARCH and ARCHIVE; an Agent block for
    the crawler's User-Agent token (case-insensitive, section 2.7) overrides the site defaults. The file is a
    declared preference (section 4.2), so the result is a proposal the publisher still signs.
    """
    origin_of(origin)
    need(type(raw) is bytes and 0 < len(raw) <= MAX_SOURCE, 'CRAWL_TERMS_SOURCE')
    pin = _checked(source_pin, 'CRAWL_TERMS_AI_TXT', 'AI_TXT', url, raw)
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('CRAWL_TERMS_AI_TXT') from None
    need(agent is None or type(agent) is str and re.fullmatch(r'[!-~]{1,64}', agent) is not None, 'CRAWL_TERMS_AI_TXT')
    site, blocks, allow, deny, current, seen = {}, {}, [], [], None, set()
    lines = text.split('\n')
    need(len(lines) <= 4096, 'CRAWL_TERMS_AI_TXT')
    for line in lines:
        line = line.rstrip('\r')
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        indented = line[:1] in (' ', '\t')
        name, separator, value = line.strip().partition(':')
        need(separator == ':' and re.fullmatch('[A-Za-z][A-Za-z-]{0,31}', name) is not None, 'CRAWL_TERMS_AI_TXT')
        value = value.strip()
        need(0 < len(value) <= 512 and all(32 <= ord(c) <= 126 for c in value), 'CRAWL_TERMS_AI_TXT')
        if name == 'Agent':
            need(not indented and value.lower() not in blocks, 'CRAWL_TERMS_AI_TXT')
            current = value.lower(); blocks[current] = {}
        elif indented:
            need(current is not None and name in ('Training', 'Scraping', 'Indexing', 'Caching', 'Rate-Limit')
                 and name not in blocks[current], 'CRAWL_TERMS_AI_TXT')
            blocks[current][name] = value
        elif name in ('Training-Allow', 'Training-Deny'):
            current = None
            (allow if name == 'Training-Allow' else deny).append(_path_of(value, origin, 'CRAWL_TERMS_AI_TXT'))
        else:
            current = None
            need((name in AI_TXT_FIELDS or name in AI_TXT_SITE) and name not in seen, 'CRAWL_TERMS_AI_TXT')
            seen.add(name); site[name] = value
    for scope_values in [site, *blocks.values()]:
        for name, allowed in AI_TXT_FIELDS.items():
            need(name not in scope_values or scope_values[name] in allowed, 'CRAWL_TERMS_AI_TXT')
    for name, allowed in (('Attribution', ('required', 'recommended', 'none')), ('AI-Disclosure', ('required', 'recommended', 'none')),
                          ('Audit', ('required', 'optional', 'none'))):
        need(name not in site or site[name] in allowed, 'CRAWL_TERMS_AI_TXT')
    if 'Training-Fee' in site:
        _checked(_url, 'CRAWL_TERMS_AI_TXT', site['Training-Fee'])
    chosen = blocks.get(agent.lower()) if agent is not None and agent.lower() in blocks else blocks.get('*', {})
    effective = {name: chosen.get(name, site.get(name, AI_TXT_DEFAULTS[name])) for name in AI_TXT_FIELDS}
    limits = None
    rate = chosen.get('Rate-Limit')
    if rate is not None:
        found = re.fullmatch(r'([1-9][0-9]{0,8})/(second|minute|hour|day)', rate)
        need(found is not None, 'CRAWL_TERMS_AI_TXT')
        limits = {'fetches': None, 'rate': {'count': int(found[1]), 'window': AI_TXT_WINDOWS[found[2]]}, 'users': None, 'geo': None}
    attribution = {'required': site.get('Attribution') == 'required', 'text': None, 'standard': site.get('Training-License')}
    permits = {AI_TXT_USES[name] for name, value in effective.items() if value == 'allow'}
    prohibits = {AI_TXT_USES[name] for name, value in effective.items() if value == 'deny'}
    notes = ['AI_TXT_DECLARED_PREFERENCE']
    if site.get('Audit') == 'required':
        notes.append('AUDIT_REQUIRED')
    if 'Training-Fee' in site:
        notes.append('TRAINING_FEE_SEE_SOURCE')
    proposals = [_proposal('AI_TXT', ['/'], permits, prohibits, attribution=attribution, limits=limits, notes=notes)]
    if effective['Training'] == 'conditional':
        # Section 2.5: conditional training is decided per glob; the site rule grants none.
        if allow:
            proposals.append(_proposal('AI_TXT', allow, permits | {'AI_TRAIN'}, prohibits, attribution=attribution,
                                       limits=limits, notes=notes + ['TRAINING_ALLOW_GLOBS']))
        if deny:
            proposals.append(_proposal('AI_TXT', deny, permits, prohibits | {'AI_TRAIN'}, attribution=attribution,
                                       limits=limits, notes=notes + ['TRAINING_DENY_GLOBS']))
    return {'kind': 'AI_TXT', 'dialect': 'draft-car-ai-txt-wellknown-00', 'sources': [pin], 'agent': agent,
            'effective': effective, 'proposals': proposals, 'grants': 'NONE_UNTIL_PUBLISHER_SIGNS', **FLAGS}


def forum_from_lcp(raw, url):
    """The LCP disputeResolution object (LCP v1.0 discovery document, Level 4) as the licence's forum.

    Validated by the existing LCP reader (lcp_emit) and pinned; the forum is a route both sides sign,
    never an instruction to file anything.
    """
    from . import lcp_emit
    need(type(raw) is bytes and 0 < len(raw) <= lcp_emit.DISCOVERY_MAX_BYTES, 'CRAWL_TERMS_SOURCE')
    try:
        document = lcp_emit.strict_loads(raw, lcp_emit.DISCOVERY_MAX_BYTES)
    except ValueError:
        raise ValueError('CRAWL_TERMS_LCP') from None
    emitted = lcp_emit.emit_discovery(document, enabled=True)
    need(not emitted['refused'] and 'disputeResolution' in emitted['document'], 'CRAWL_TERMS_LCP')
    found = emitted['document']['disputeResolution']
    need('method' in found, 'CRAWL_TERMS_LCP')
    clause = found.get('clauseId')
    forum = {'method': found['method'], 'jurisdiction': found.get('jurisdiction'),
             'clause': None if clause is None else 'sha256:0x' + clause[9:].lower(),
             'source': found.get('source'), 'catalog': found.get('catalog')}
    _checked(_forum, 'CRAWL_TERMS_LCP', forum)
    return {'forum': forum, 'source': _checked(source_pin, 'CRAWL_TERMS_LCP', 'LCP_DISCOVERY', url, raw),
            'filing': 'NOT_FILED; NO_NETWORK', **FLAGS}


def describe():
    return {'profile': PROFILE, 'label': LABEL, 'proposal': PROPOSAL, 'uses': list(USES), 'models': list(MODELS),
            'sources': list(SOURCES), 'units': 'ISO_4217_MICRO_UNITS', 'matching': 'RFC9309_SECTION_2.2.3',
            'grafts': {'RSL_XML': 'RSL 1.0', 'ROBOTS_TXT': 'RSL License directive', 'TDMREP_JSON': 'TDMRep CG report 2024-05-10',
                       'TDM_POLICY': 'TDMRep CG report 2024-05-10 section 7', 'AI_TXT': 'draft-car-ai-txt-wellknown-00',
                       'LCP_DISCOVERY': 'Legal Context Protocol v1.0 disputeResolution'},
            'errors': {code: explain(code) for code in sorted(ERRORS)}, **FLAGS}
