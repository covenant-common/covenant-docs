"""Adoptable TLS transport; authority still comes from native signed messages.

Static literal-IP endpoints and explicit leaf-certificate pins avoid DNS/proxy
ambiguity. This is a transport candidate, not end-to-end PQ confidentiality.
"""
from __future__ import annotations

import hashlib
import hmac
import http.client
import math
import re
import ssl
import urllib.parse
import urllib.request
from pathlib import Path

from .crypto import need, loads, exact
from .launch_security import NoRedirect, literal_ip, read_signing_key, validate_peers
from .security import openssl_status


def require_tls_backend():
    status = openssl_status(ssl.OPENSSL_VERSION)
    need(status['acceptable'],
         'UNAPPROVED_TLS_BACKEND: Python ssl reports ' + str(status.get('openssl'))
         + '; accepted OpenSSL branches are ' + str(status.get('accepted', ''))
         + '. Install a Python linked to an accepted, independently verified build. Version strings alone do not establish vendor backport status or patch provenance. The signing backend is checked separately.')
    return status


def validate_https_peers(peers):
    need(type(peers) is dict and 1 <= len(peers) <= 64, 'TLS_PEERS')
    for name, endpoint in peers.items():
        need(type(name) is str and 0 < len(name) <= 80 and all(33 <= ord(c) <= 126 for c in name), 'TLS_MEMBER')
        need(type(endpoint) is str and len(endpoint) <= 256 and all(33 <= ord(c) <= 126 for c in endpoint), 'TLS_ENDPOINT')
        try:
            uri = urllib.parse.urlsplit(endpoint)
            literal_ip(uri.hostname or '')
            port = uri.port
        except ValueError as exc:
            raise ValueError('TLS_LITERAL_IP') from exc
        need(uri.scheme == 'https' and port is not None and 1 <= port <= 65535 and
             uri.username is None and uri.password is None and uri.path in ('', '/') and
             not uri.query and not uri.fragment, 'TLS_ENDPOINT')


def validate_pins(pins, members=None):
    need(type(pins) is dict and 1 <= len(pins) <= 64, 'TLS_PINS')
    if members is not None:
        need(set(pins) == set(members), 'TLS_PIN_MEMBERS')
    used = set()
    for member, values in pins.items():
        need(type(member) is str and 0 < len(member) <= 80, 'TLS_MEMBER')
        need(type(values) is list and 1 <= len(values) <= 2 and len(set(values)) == len(values), 'TLS_PIN_ROTATION')
        for pin in values:
            need(type(pin) is str and re.fullmatch('[0-9a-f]{64}', pin) is not None, 'TLS_PIN_ENCODING')
            need(pin not in used, 'TLS_PIN_SHARED_IDENTITY')
            used.add(pin)
    return pins


def read_config(path):
    with Path(path).open('rb') as handle:
        raw = handle.read(65537)
    need(len(raw) <= 65536, 'TLS_CONFIG_LIMIT')
    config = loads(raw)
    exact(config, 'ca_file cert_file key_file pins')
    validate_pins(config['pins'])
    for name in ('ca_file', 'cert_file', 'key_file'):
        need(type(config[name]) is str and Path(config[name]).is_absolute(), 'TLS_FILE_PATH')
    return config


def tls_context(config, *, server=False, mutual=False):
    """No system CA fallback, environment key logging, or classical downgrade.

    Version admission is intentionally separate and enforced by every CLI and
    outbound builder. Low-level context construction is also used by local tests.
    File parents/host administration remain trusted; restart adopts pin rotation.
    """
    read_signing_key(config['key_file'])
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER if server else ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.verify_flags |= ssl.VERIFY_X509_STRICT
    context.keylog_filename = None
    context.set_alpn_protocols(['http/1.1'])
    context.options |= ssl.OP_NO_COMPRESSION
    if server:
        context.num_tickets = 0
        context.verify_mode = ssl.CERT_REQUIRED if mutual else ssl.CERT_NONE
    context.load_verify_locations(cafile=config['ca_file'])
    context.load_cert_chain(certfile=config['cert_file'], keyfile=config['key_file'])
    return context


def checked_client_context(context):
    need(isinstance(context, ssl.SSLContext) and context.verify_mode == ssl.CERT_REQUIRED and
         context.check_hostname and context.minimum_version >= ssl.TLSVersion.TLSv1_3 and
         context.keylog_filename is None, 'TLS_CLIENT_CONTEXT')
    return context


class PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, *args, pins, **kwargs):
        self.pins = pins
        super().__init__(*args, **kwargs)

    def connect(self):
        super().connect()
        if self.pins:
            actual = hashlib.sha256(self.sock.getpeercert(binary_form=True)).hexdigest()
            if not any(hmac.compare_digest(actual, pin) for pin in self.pins):
                self.close()
                raise ssl.SSLCertVerificationError('TLS_LEAF_PIN_MISMATCH')


class PinnedHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, context, endpoints):
        super().__init__(context=context)
        self.endpoints = endpoints

    def https_open(self, req):
        uri = urllib.parse.urlsplit(req.full_url)
        origin = (uri.hostname, uri.port or 443)
        need(origin in self.endpoints, 'TLS_UNADOPTED_ENDPOINT')
        pins = self.endpoints[origin]
        return self.do_open(lambda *a, **kw: PinnedHTTPSConnection(*a, pins=pins, **kw),
                            req, context=self._context)


def https_opener(context, endpoints):
    require_tls_backend()
    checked_client_context(context)
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                                       PinnedHTTPSHandler(context, endpoints))


def peer_opener(peers, config):
    require_tls_backend()
    validate_https_peers(peers)
    validate_pins(config['pins'], peers)
    context = tls_context(config)
    endpoints = {}
    for member, url in peers.items():
        uri = urllib.parse.urlsplit(url)
        origin = (uri.hostname, uri.port)
        need(origin not in endpoints, 'TLS_DUPLICATE_ENDPOINT')
        endpoints[origin] = config['pins'][member]
    return https_opener(context, endpoints)


def client_opener(url, context=None, pin=None):
    uri = urllib.parse.urlsplit(url)
    need(type(url) is str and len(url) <= 512 and all(33 <= ord(c) <= 126 for c in url) and
         uri.username is None and uri.password is None and uri.path in ('', '/') and
         not uri.query and not uri.fragment, 'RPC_ENDPOINT')
    if uri.scheme == 'http':
        validate_peers({'rpc': url})
        need(context is None and pin is None, 'RPC_TLS_REQUIRED')
        return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    need(uri.scheme == 'https' and uri.hostname, 'RPC_TLS_REQUIRED')
    if pin is not None:
        need(type(pin) is str and re.fullmatch('[0-9a-f]{64}', pin) is not None, 'TLS_PIN_ENCODING')
    if context is None:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.load_default_certs()
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.keylog_filename = None
    return https_opener(context, {(uri.hostname, uri.port or 443): [pin] if pin else []})
