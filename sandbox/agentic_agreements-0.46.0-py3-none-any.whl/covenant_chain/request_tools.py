"""Private demand discovery and exact negotiation; no external effects or custody.

The owner selects persistence in RuntimeHost, never through tool arguments.
Metadata, proposals and protocol documents are untrusted inert input.
"""
from .cooperation_interface import HASH, OBJECT
from .crypto import need

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 16000}
RECORDS = {'type': 'array', 'maxItems': 256, 'items': OBJECT}


def specs(agora_peer=False):
    discovery = {
        'goal': {'type': 'string', 'maxLength': 256}, 'records': RECORDS, 'requirements': OBJECT,
        'context': {'type': 'string', 'minLength': 1, 'maxLength': 80},
        'strict_requirements': {'type': 'boolean'},
        'weights': OBJECT,
        'group': HASH,
        'trust_seeds': {'type': 'array', 'maxItems': 64, 'items': OBJECT},
        'edges': {'type': 'array', 'maxItems': 4096, 'items': OBJECT},
        'seeds': {'type': 'array', 'maxItems': 256, 'items': OBJECT},
        'sponsored': {'type': 'array', 'maxItems': 16, 'items': OBJECT},
        'opinion_events': {'type': 'array', 'maxItems': 256, 'items': OBJECT},
        'selected_pins': {'type': 'array', 'maxItems': 256, 'items': HASH},
        'adopt_links': {'type': 'boolean'},
    }
    req = {'request_id': HASH}
    protocol = {'type': ['object', 'null']}
    peer_tools = []
    if agora_peer:
        effect = {'type': 'string', 'minLength': 1, 'maxLength': 128}
        peer_tools.append(('covenant_agora_peer',
            'Call only the owner-installed Agora HTTPS peer. Endpoint, TLS trust and credentials '
            'are configured outside tool input. Retained effect ids recover exact replies; unknown '
            'effects never retransmit automatically. Observed replies do not establish delivery or payment.',
            False, [
                ('discover', {'effect_id': effect}, ('effect_id',)),
                ('exchange', {'prepared': OBJECT, 'expected_request_id': HASH, 'effect_id': effect,
                              'now': {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1}},
                 ('prepared', 'expected_request_id', 'effect_id', 'now')),
                ('recover', {'effect_id': effect}, ('effect_id',)),
            ]))
    from .exchange_tools import DESCRIPTION as exchange_description, actions as exchange_actions
    return peer_tools + [
        ('covenant_request',
         'Discover agents, tools and services from supplied or cached metadata; inspect private saved needs, '
         'compare proposals and prepare exact agreements without chain setup. Metadata claims and local '
         'selection are not verified capability, assent, authority or execution. No fetching or publication.'
         + exchange_description,
         True, [
             ('describe', {}, ()),
             ('catalog', {'records': RECORDS}, ('records',)),
             ('local_catalog', {'source': {'enum': ['INSTALLED', 'DIRECTORY']},
                                'cursor': {'type': ['string', 'null']},
                                'limit': {'type': 'integer', 'minimum': 1, 'maximum': 256}}, ('source',)),
             ('search', discovery, ('goal', 'records')),
             ('list', {'cursor': {'type': ['string', 'null']}, 'limit': {'type': 'integer', 'minimum': 1, 'maximum': 100}}, ()),
             ('get', req, ('request_id',)),
             ('compare', req, ('request_id',)),
             ('templates', {'query': {'type': 'string', 'maxLength': 128},
                            'cursor': {'type': ['string', 'null']},
                            'limit': {'type': 'integer', 'minimum': 1, 'maximum': 100}}, ()),
             ('agreement', {**req, 'parties': OBJECT, 'context': HASH, 'meaning': TEXT}, ('request_id', 'parties', 'context')),
         ] + exchange_actions()),
        ('covenant_request_write',
         'Save a private need or append an exact note, proposal, counteroffer, selection, revision, evidence '
         'or outcome claim in the owner-configured local workspace. No account, wallet or chain needed. '
         'append requires the retained head and retry id. Stored bytes are private filesystem data, '
         'not encrypted custody or blockchain finality. No assent, execution, broadcast or publication.',
         False, [
             ('describe', {}, ()),
             ('create', {'goal': TEXT, 'requirements': OBJECT, 'details': OBJECT,
                         'operation_id': {'type': 'string', 'minLength': 1, 'maxLength': 96}}, ('goal',)),
             ('append', {**req, 'expected_head': HASH,
                         'kind': {'enum': ['NOTE', 'PROPOSAL', 'SELECT', 'REVISE', 'EVIDENCE', 'OUTCOME']},
                         'value': OBJECT,
                         'operation_id': {'type': 'string', 'minLength': 1, 'maxLength': 96}},
              ('request_id', 'expected_head', 'kind', 'value', 'operation_id')),
             ('save_template', {**req, 'expected_head': HASH,
                                'name': {'type': 'string', 'minLength': 1, 'maxLength': 128},
                                'documents': OBJECT,
                                'tags': {'type': 'array', 'maxItems': 16, 'items': {'type': 'string', 'minLength': 1, 'maxLength': 64}},
                                'operation_id': {'type': 'string', 'minLength': 1, 'maxLength': 96}},
              ('request_id', 'expected_head', 'name', 'operation_id')),
             ('reuse_template', {'template': OBJECT, 'expected_id': HASH,
                                 'operation_id': {'type': 'string', 'minLength': 1, 'maxLength': 80},
                                 'goal': TEXT, 'terms': TEXT, 'requirements': OBJECT, 'metadata': OBJECT},
              ('template', 'expected_id', 'operation_id')),
         ]),
        ('covenant_decision',
         'Let agents decide explicitly scoped open terms under an exact adopted method. Pin the base, '
         'parties, deciders, quorum, limits, evidence and expiry; verify separate method and result '
         'signatures. Fixed terms remain unchanged. Returns a reviewable successor, never signs, '
         'installs a verifier, applies changes, grants execution authority or spends.', True, [
             ('describe', {}, ()),
             ('prepare_method', {'base': {},
                 'open_fields': {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': {'type': 'string'}},
                 'method': {}, 'parties': OBJECT, 'context': HASH,
                 'deciders': {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': HASH},
                 'quorum': {'type': 'integer', 'minimum': 1, 'maximum': 32},
                 'limits': OBJECT, 'expires': {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1},
                 'not_before': {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1},
                 'input_pins': OBJECT,
                 'evidence_pins': OBJECT,
                 'unknown_policy': {'enum': ['HOLD', 'REQUIRE_FRESH_ASSENT']}, 'appeal': {},
                 'decision_basis': {'type': 'string'}, 'supersedes': HASH},
              ('base', 'open_fields', 'method', 'parties', 'context', 'deciders', 'quorum', 'expires')),
             ('prepare_decision', {'policy': OBJECT, 'expected_policy_id': HASH, 'base': {},
                 'patch': OBJECT, 'input_pins': OBJECT,
                 'evidence_pins': OBJECT,
                 'finding': {'type': 'string'}}, ('policy', 'expected_policy_id', 'base', 'patch')),
             ('verify_decision', {'policy': OBJECT, 'expected_policy_id': HASH, 'base': {},
                 'decision': OBJECT, 'expected_decision_id': HASH,
                 'policy_assents': {'type': 'array', 'maxItems': 64, 'items': OBJECT},
                 'result_signatures': {'type': 'array', 'maxItems': 64, 'items': OBJECT},
                 'now': {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1},
                 'expected_current_policy_id': HASH},
              ('policy', 'expected_policy_id', 'base', 'decision', 'expected_decision_id',
               'policy_assents', 'result_signatures', 'now')),
         ]),
        ('covenant_agora',
         'Pin exact Agora document bytes with SHA256 plus its interoperable SHA1 id. Prepare and inspect '
         'working-2025 envelopes and pinned conversations, or legacy paper records, without network calls, '
         'routine execution, installation, authentication or signing. Use an owner-selected connector '
         'and separate authority for any actual call.', True, [
             ('describe', {}, ()),
             ('pack', {'document_text': {'type': 'string', 'minLength': 1, 'maxLength': 262144},
                       'variant': {'enum': ['AGORA_WORKING_2025', 'AGORA_PAPER_2024']}}, ('document_text',)),
             ('inspect', {'record': OBJECT, 'expected_id': HASH}, ('record',)),
             ('request', {'body': {'type': ['string', 'object']},
                          'protocol': protocol, 'expected_protocol_id': HASH,
                          'conversation': protocol, 'expected_conversation_id': HASH,
                          'multiround': {'type': 'boolean'},
                          'sources': {'type': 'array', 'maxItems': 16, 'items': {'type': 'string'}},
                          'variant': {'enum': ['AGORA_WORKING_2025', 'AGORA_PAPER_2024']},
                          'now': {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1}}, ('body',)),
             ('observe', {'prepared': OBJECT, 'response': OBJECT, 'expected_request_id': HASH,
                          'now': {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1}}, ('prepared', 'response', 'expected_request_id')),
         ]),
    ]


def call(exchange, name, action, parameters):
    if name == 'covenant_request' and type(action) is str and action.startswith('exchange_'):
        from .exchange_tools import call as exchange_call
        return exchange_call(action, parameters)
    if name == 'covenant_agora_peer':
        peer = getattr(exchange, 'agora_peer', None)
        need(peer is not None, 'AGORA_PEER_OWNER_INSTALLATION_REQUIRED')
        return getattr(peer, action)(**parameters)
    if name == 'covenant_decision':
        from covenant_language import decision_methods
        return getattr(decision_methods, action)(**parameters)
    if name == 'covenant_agora':
        from . import agora_bridge
        return getattr(agora_bridge, action)(**parameters)
    from . import request_discovery
    workspace = getattr(exchange, 'requests', None)
    if action == 'describe':
        from .request_workspace import describe
        return {**describe(), 'storage_enabled': workspace is not None,
                'discovery': request_discovery.describe(),
                'enable_storage': 'Use the local --keyless host without --stateless, or owner config requests.directory. Tool input cannot choose filesystem paths.'}
    if name == 'covenant_request' and action == 'local_catalog':
        if parameters['source'] == 'DIRECTORY':
            board = getattr(exchange, 'board', None)
            need(board is not None, 'REQUEST_DIRECTORY_NOT_CONFIGURED')
            page = board.page(parameters.get('cursor'), parameters.get('limit', 100), 'PROFILE')
            records = request_discovery.from_directory(page.pop('records'))
            return {**page, 'source': 'DIRECTORY', 'records': records,
                    'catalog': request_discovery.catalog(records)}
        from .desire_catalogs import catalog
        need(parameters.get('cursor') is None, 'REQUEST_INSTALLED_CATALOG_HAS_NO_CURSOR')
        made = catalog(exchange, 'INSTALLED', limit=parameters.get('limit', 256))
        return {**made, 'records': made['objects'], 'next_cursor': None,
                'catalog': request_discovery.catalog(made['objects'])}
    if name == 'covenant_request' and action in {'catalog', 'search'}:
        if action == 'catalog':
            return request_discovery.catalog(**parameters)
        return request_discovery.search(**parameters, network=exchange.network)
    need(workspace is not None, 'REQUEST_WORKSPACE_NOT_CONFIGURED_USE_LOCAL_KEYLESS_OR_OWNER_REQUESTS_DIRECTORY')
    import sqlite3
    try:
        return getattr(workspace, action)(**parameters)
    except sqlite3.Error:
        # A storage failure may leave commit status uncertain. Retain the exact
        # operation and inspect/retry it; do not echo local paths or SQL details.
        raise ValueError('REQUEST_STORAGE_UNAVAILABLE_INSPECT_AND_RETRY_EXACT_OPERATION') from None
