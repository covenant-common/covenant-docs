"""Private provider 0.2 owner launch; retained signing storage is mandatory."""
import argparse
from pathlib import Path
import signal
import threading
import time
from . import observability
from .agent_tools import decode
from .backup import refuse_pending_restore
from .crypto import exact,load_private
from .provider_replica_node import private_file
from . import private_provider
from .private_provider import ProviderReplica
from .private_provider_rpc import ReplicaService
from .provider_replica_rpc import fetch_peer_histories


def arguments():
    """The private replica's command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True); parser.add_argument('--initialize',action='store_true')
    observability.add_arguments(parser)
    return parser


def main():
    args = arguments().parse_args(); cfg = decode(private_file(args.config))
    exact(cfg,'spec member key_file privacy_key_file token_file directory port peers account_tokens minimum_checkpoint')
    refuse_pending_restore(cfg['directory'])
    key = load_private(private_file(cfg['key_file']))
    privacy_key = bytes.fromhex(private_file(cfg['privacy_key_file']).strip())
    token = private_file(cfg['token_file']).strip()
    histories = []
    if args.initialize and not Path(cfg['directory'],'consensus.sqlite3').exists():
        histories = fetch_peer_histories(cfg['spec'],cfg['peers'],token,protocol=private_provider)
        print('private replica initialize: advisory peer scan cannot establish an unused key; latest intact signing storage remains required for recovery',flush=True)
    replica = ProviderReplica(cfg['directory'],cfg['spec'],cfg['member'],key,privacy_key=privacy_key,
        clock=lambda:int(time.time()),initialize=args.initialize,minimum_checkpoint=cfg['minimum_checkpoint'],base_timeout=.25,peer_histories=histories)
    service = None; stopping = threading.Event()
    def stop(*_): stopping.set()
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    try:
        service = ReplicaService(replica,peers=cfg['peers'],token=token,port=cfg['port'],account_tokens=cfg['account_tokens']).start()
        observability.start(service.ops, args)
        print('private replica ready '+cfg['member'],flush=True); stopping.wait()
    finally:
        if service is not None: service.close()
        replica.close()


if __name__ == '__main__': main()
