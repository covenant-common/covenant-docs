"""Serving rewards for covenant-native/0.15. Integer, illustrative, no mint.

The consensus weight is the left-to-right formula in the p2p hosting spec.
`stored_kib * pass_bps` before the `// 10000` steps is the spec's 9.87e9 check.
It is not the weight the pool pays on.
"""
from .crypto import exact, integer, key, need

SHRINKAGE = 8
AGE_FLOOR_BPS = 2500
AGE_STEP_BPS = 250
AGE_FULL_BPS = 10000
DIVERSITY_FULL_BPS = 10000
DIVERSITY_THIN_BPS = 2000
HOST_CAP_BPS = 625
HOLDBACK_PAID_NUM = 3
HOLDBACK_PAID_DEN = 4
VEST_EPOCHS = 30
ENDOWMENT_DIVISOR = 64
FREE_QUOTA = 8
BATCH_LIMIT = 64
BANDWIDTH_DIVISOR = 4
ROLES = ('ARCHIVE', 'RELAY', 'LIGHT_PROOF')
FETCH_OPS = ('ECON_LIGHT_FETCH', 'ECON_RELAY_FETCH')

PARAMETERS = {
    'shrinkage': SHRINKAGE,
    'age_floor_bps': AGE_FLOOR_BPS,
    'age_step_bps': AGE_STEP_BPS,
    'diversity_full_bps': DIVERSITY_FULL_BPS,
    'diversity_thin_bps': DIVERSITY_THIN_BPS,
    'host_cap_bps': HOST_CAP_BPS,
    'holdback_paid_num': HOLDBACK_PAID_NUM,
    'holdback_paid_den': HOLDBACK_PAID_DEN,
    'vest_epochs': VEST_EPOCHS,
    'endowment_divisor': ENDOWMENT_DIVISOR,
    'free_quota': FREE_QUOTA,
    'bandwidth_divisor': BANDWIDTH_DIVISOR,
}


def pass_bps(passes, audits):
    integer(passes)
    integer(audits)
    need(passes <= audits, 'SERVE_AUDITS')
    return 10000 * passes // (audits + SHRINKAGE)


def age_bps(epochs):
    integer(epochs)
    return min(AGE_FULL_BPS, AGE_FLOOR_BPS + AGE_STEP_BPS * epochs)


def diversity_bps(operator_shards, archive_shards):
    integer(operator_shards)
    integer(archive_shards, True)
    if operator_shards * 3 <= archive_shards:
        return DIVERSITY_FULL_BPS
    return DIVERSITY_THIN_BPS


def storage_weight(stored_kib, passes, audits, epochs, operator_shards, archive_shards):
    """Left to right, as written: kib, then pass, then diversity, then age."""
    integer(stored_kib)
    weight = stored_kib * pass_bps(passes, audits) // 10000
    weight = weight * diversity_bps(operator_shards, archive_shards) // 10000
    return weight * age_bps(epochs) // 10000


def host_weight(stored_kib, passes, audits, epochs, operator_shards, archive_shards, bandwidth):
    integer(bandwidth)
    return storage_weight(stored_kib, passes, audits, epochs, operator_shards, archive_shards) + bandwidth // BANDWIDTH_DIVISOR


def water_fill(pool, weights, cap_bps=HOST_CAP_BPS):
    """Proportional shares. A host over the cap is fixed there and the rest is redrawn.

    Dust goes to the largest remaining weight that still has room under the cap.
    The pays sum to at most `pool`.
    """
    integer(pool)
    integer(cap_bps)
    need(type(weights) is list and len(weights) <= BATCH_LIMIT, 'SERVE_BATCH')
    pays = [0] * len(weights)
    if pool <= 0 or not weights:
        return pays
    for weight in weights:
        integer(weight)
    cap = pool * cap_bps // 10000
    if cap <= 0:
        return pays
    active = [index for index, weight in enumerate(weights) if weight > 0]
    left = pool
    while active and left > 0:
        total = sum(weights[index] for index in active)
        if total <= 0:
            break
        shares = {index: left * weights[index] // total for index in active}
        rest = left - sum(shares.values())
        for index in sorted(active, key=lambda item: (-weights[item], item)):
            if rest <= 0:
                break
            if shares[index] < cap:
                shares[index] += 1
                rest -= 1
        capped = [index for index in active if shares[index] > cap]
        if not capped:
            for index in active:
                pays[index] = shares[index]
            break
        for index in capped:
            pays[index] = cap
            left -= cap
            active.remove(index)
        if left < 0:
            left = 0
    need(sum(pays) <= pool, 'SERVE_CONSERVATION')
    need(all(pay <= cap for pay in pays), 'SERVE_CAP')
    return pays


def holdback(pay):
    integer(pay)
    paid_now = pay * HOLDBACK_PAID_NUM // HOLDBACK_PAID_DEN
    return paid_now, pay - paid_now


def release_per_epoch(remaining):
    """Geometric endowment. The locked remainder stays. Nothing is minted."""
    integer(remaining)
    return remaining // ENDOWMENT_DIVISOR


def bandwidth_credit(receipts, cap_r, ring_quota):
    """Bytes from anchored retrievers, capped per retriever.

    A pair that serves each other above `ring_quota` contributes nothing.
    """
    integer(cap_r)
    integer(ring_quota)
    need(type(receipts) is list and len(receipts) <= BATCH_LIMIT, 'SERVE_RECEIPTS')
    per_retriever = {}
    reverse = {}
    anchored = {}
    for row in receipts:
        exact(row, 'retriever bytes anchored reverse')
        key(row['retriever'])
        integer(row['bytes'])
        integer(row['reverse'])
        need(row['anchored'] in {True, False}, 'SERVE_ANCHORED')
        who = row['retriever']
        per_retriever[who] = per_retriever.get(who, 0) + row['bytes']
        reverse[who] = reverse.get(who, 0) + row['reverse']
        anchored[who] = anchored.get(who, False) or row['anchored']
    total = 0
    for who, amount in per_retriever.items():
        if not anchored[who]:
            continue
        if amount > ring_quota and reverse[who] > ring_quota:
            continue
        total += min(amount, cap_r)
    integer(total)
    return total


def under_free_quota(used):
    integer(used)
    return used < FREE_QUOTA
