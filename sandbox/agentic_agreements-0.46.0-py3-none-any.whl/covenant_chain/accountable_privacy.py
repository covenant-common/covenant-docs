"""Accountable privacy: a pseudonymous agent whose principal k of n independent authorities can disclose.

TAKE-AND-IMPROVE from Concordium's anonymity revokers, which reveal an account
holder only when a threshold of revokers act on a due-process request. AAP
rebuilds the idea from older, separately specified parts and ties disclosure to
the dispute ladder the parties themselves adopted:

1. The principal signs a /0.3 hidden-credential request naming a disclosure
   policy: n authorities (an Ed25519 signing key, an X25519 sealing key and the
   witnessed journal each logs to), the threshold k, the ladder stages allowed to
   order disclosure and how long the escrow may be opened. No authority is added
   silently.
2. The issuer, which already checked the principal, seals the binding (the
   principal's own signed request naming the one-time holder key, the pseudonym)
   under a fresh key K with AES-256-GCM and HKDF-SHA256 (RFC 5869), splits K with
   secret_sharing (Shamir 1979, Feldman 1987, HPKE RFC 9180) and signs the escrow.
   The credential carries the escrow id as aap_escrow, so a verifier learns the
   pseudonym is accountable, and to whom, without learning who it is.
3. Disclosure needs an order: the replayed ESCALATION ladder
   (covenant_language.agreement_procedures) adopted by every party, the pseudonym
   among the disputants, finalised at a stage whose mode the escrow allows, with
   the pre-agreed outcome {remedy: DISCLOSE_PRINCIPAL, escrow, recipient}. The
   recipient disputant signs a request naming the X25519 key that receives shares.
4. Each authority checks escrow, order and request, opens its share, checks it
   against the Feldman commitments, re-seals it to the recipient, signs the
   release and appends the release id to its witnessed journal (C2SP checkpoints,
   witness_journal.py). The release leaves the authority only once a fresh
   witness quorum has cosigned that entry; otherwise it is withheld and logged.
5. The recipient checks every release (authority signature, journal inclusion
   under a quorum-cosigned checkpoint, Feldman check), combines k shares, opens
   the binding and checks the principal's own signature over the request naming
   the pseudonym. The result names the k authorities and their journal entries.

Fewer than k authorities learn nothing about K beyond K*G (their shares fit every
key), and no authority sees the binding: shares travel sealed to the recipient.
The issuer knew the binding when it issued; accountability adds a path that does
not depend on the issuer later. Nothing here sends, fetches or decides a dispute.
"""
from copy import deepcopy

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from covenant_language import agreement_procedures as procedures
from .crypto import canonical, digest, integer, key, loads, need, public_key, sign, verify
from . import hidden_credentials as hc
from . import secret_sharing as sharing
from .secret_sharing import REMEDIATION as SHARING_REMEDIATION
from . import witness_journal as journals
from .disclosure_escrow import (BINDING_KEY_INFO, BINDING_VERSION, ESCROW_LABEL, ESCROW_VERSION, MAX_RETENTION,  # noqa: F401
                               MODES, POLICY_LABEL, POLICY_VERSION, _aead_key, _authority, _b64, _checked_request,
                               _header, _request_id, _unb64, check_credential_escrow, create_escrow,
                               escrow_for_credential, open_escrow, policy, policy_id, validate_policy)
from .scale.identity import did

ORDER_VERSION = 'covenant-disclosure-order/0.1'
REQUEST_VERSION = 'covenant-disclosure-request/0.1'
RELEASE_VERSION = 'covenant-disclosure-release/0.1'
ACK_VERSION = 'covenant-disclosure-ack/0.1'
ORDER_LABEL = 'COVENANT-DISCLOSURE-ORDER-0.1'
REQUEST_LABEL = 'COVENANT-DISCLOSURE-REQUEST-0.1'
RELEASE_LABEL = 'COVENANT-DISCLOSURE-RELEASE-0.1'
ACK_LABEL = 'COVENANT-DISCLOSURE-ACK-0.1'
RELEASE_INFO = b'AAP-DISCLOSURE-RELEASE-0.1'
REMEDY = 'DISCLOSE_PRINCIPAL'
MAX_RELEASES = 16

REMEDIATION = {
    'DISCLOSURE_POLICY': 'Use the exact disclosure policy fields from describe().',
    'DISCLOSURE_AUTHORITIES': 'Name 2 to 16 authorities with distinct names, signing keys, sealing keys and journals.',
    'DISCLOSURE_THRESHOLD': 'Use a threshold k with 2 <= k <= the number of authorities.',
    'DISCLOSURE_ORDER_RULE': 'Allow ladder modes from NEGOTIATION, OPTIMISTIC and JUDGMENT, a minimum quorum of 1 or more and sorted judge keys.',
    'DISCLOSURE_RETENTION': 'Use a retention from 1 second to 20 years.',
    'DISCLOSURE_REQUEST': 'Escrow only a /0.3 request for one holder key that names this disclosure policy.',
    'DISCLOSURE_ESCROW': 'Use the escrow record exactly as the issuer signed it: policy, body and signature.',
    'DISCLOSURE_ESCROW_SIGNATURE': 'The escrow must be signed by the issuer key it names.',
    'DISCLOSURE_ESCROW_MISMATCH': 'The escrow is for another pseudonym, request, policy or issuer.',
    'DISCLOSURE_ESCROW_EXPIRED': 'The escrow is past its retention; authorities no longer open it.',
    'DISCLOSURE_ORDER': 'Supply the order: escrow id, the ESCALATION policy, every adoption, the events and the head.',
    'DISCLOSURE_ORDER_NOT_FINAL': 'Disclosure needs a finalised ladder outcome, not a provisional or open one.',
    'DISCLOSURE_ORDER_MODE': 'The deciding stage\'s mode is not one this escrow allows to order disclosure.',
    'DISCLOSURE_ORDER_QUORUM': 'The deciding stage needs at least the escrow\'s minimum quorum of deciders.',
    'DISCLOSURE_ORDER_JUDGES': 'Every decider of the deciding stage must be one of the escrow\'s judges.',
    'DISCLOSURE_ORDER_OUTCOME': 'The final outcome must be {remedy: DISCLOSE_PRINCIPAL, escrow: this escrow, recipient: role}.',
    'DISCLOSURE_ORDER_PSEUDONYM': 'The pseudonym (credential holder key) must be exactly one disputant of the ladder.',
    'DISCLOSURE_ORDER_RECIPIENT': 'The recipient must be the other disputant, never the pseudonym.',
    'DISCLOSURE_REQUEST_FIELDS': 'Use the exact disclosure request fields from describe().',
    'DISCLOSURE_REQUEST_SIGNATURE': 'The recipient party key from the ladder policy must sign the request.',
    'DISCLOSURE_NOT_AUTHORITY': 'This key is not one of the escrow\'s disclosure authorities.',
    'DISCLOSURE_SHARE_INVALID': 'A share failed the Feldman check; the signed escrow or release is evidence of who dealt or released it.',
    'DISCLOSURE_RELEASE': 'Use releases exactly as authorities signed them, each with its journal proof.',
    'DISCLOSURE_RELEASE_SIGNATURE': 'A release must be signed by the authority key it names.',
    'DISCLOSURE_RELEASE_UNWITNESSED': 'A release counts only with an inclusion proof under a fresh, quorum-cosigned checkpoint.',
    'DISCLOSURE_THRESHOLD_UNMET': 'Fewer than k valid, witnessed releases: nothing can be disclosed.',
    'DISCLOSURE_BINDING': 'The binding did not open or does not carry the principal\'s signed request for this pseudonym.',
    'DISCLOSURE_RECIPIENT_KEY': 'Open releases with the X25519 key named in the signed request.',
    'DISCLOSURE_AUTHORITY_SETUP': 'Give the authority its Ed25519 and X25519 keys, a witness gate and the matching journal policy.',
    'DISCLOSURE_ACK': 'Use acknowledgements exactly as authorities signed them.',
}


def remediation(code):
    return REMEDIATION.get(code) or SHARING_REMEDIATION.get(code) or sharing.remediation(code)


# The disclosure policy the principal consents to and the escrow the issuer deals live in
# disclosure_escrow (L0) and are re-exported above unchanged.


# Orders from the agreed ladder, and the recipient's request.

def disclosure_outcome(escrow_id, recipient_role):
    """The typed outcome parties pre-agree in their ESCALATION policy to allow ordering this disclosure."""
    key(escrow_id)
    procedures.name(recipient_role)
    return {'remedy': {'kind': 'TEXT', 'value': REMEDY}, 'escrow': {'kind': 'HASH', 'value': escrow_id},
            'recipient': {'kind': 'ROLE', 'value': recipient_role}}


def order(escrow_id, ladder_policy, adoptions, events, head):
    key(escrow_id)
    return {'version': ORDER_VERSION, 'escrow': escrow_id, 'policy': deepcopy(ladder_policy),
            'adoptions': deepcopy(adoptions), 'events': deepcopy(events), 'head': head}


def check_order(order_record, record):
    """Replay the ladder and check it ordered this disclosure at a stage the escrow allows."""
    escrow = open_escrow(record)
    need(type(order_record) is dict and set(order_record) == {'version', 'escrow', 'policy', 'adoptions', 'events', 'head'}
         and order_record['version'] == ORDER_VERSION, 'DISCLOSURE_ORDER')
    need(order_record['escrow'] == escrow['id'], 'DISCLOSURE_ORDER_OUTCOME')
    ladder = order_record['policy']
    need(type(ladder) is dict and ladder.get('kind') == 'ESCALATION', 'DISCLOSURE_ORDER')
    state = procedures.replay(ladder, order_record['adoptions'], order_record['events'], order_record['head'])
    need(state['status'] == 'FINAL_ATTESTED_OUTCOME', 'DISCLOSURE_ORDER_NOT_FINAL')
    configuration = ladder['configuration']
    stage = configuration['stages'][state['round']]
    rule = escrow['policy']['order']
    need(stage['mode'] in rule['modes'], 'DISCLOSURE_ORDER_MODE')
    if stage['mode'] == 'JUDGMENT':
        need(stage['quorum'] >= rule['minimum_quorum'], 'DISCLOSURE_ORDER_QUORUM')
        if rule['judges']:
            need(all(ladder['parties'][role] in rule['judges'] for role in stage['deciders']), 'DISCLOSURE_ORDER_JUDGES')
    outcome = state['outcome']
    need(type(outcome) is dict and set(outcome) == {'remedy', 'escrow', 'recipient'}
         and outcome['remedy'] == {'kind': 'TEXT', 'value': REMEDY}
         and outcome['escrow'] == {'kind': 'HASH', 'value': escrow['id']}
         and outcome['recipient'].get('kind') == 'ROLE', 'DISCLOSURE_ORDER_OUTCOME')
    disputants = configuration['disputants']
    held = [role for role in disputants if ladder['parties'][role] == escrow['body']['pseudonym']]
    need(len(held) == 1, 'DISCLOSURE_ORDER_PSEUDONYM')
    recipient = outcome['recipient']['value']
    need(recipient in disputants and recipient != held[0], 'DISCLOSURE_ORDER_RECIPIENT')
    order_id = digest(ORDER_LABEL, {'escrow': escrow['id'], 'policy': procedures.identifier(ladder), 'head': state['head']})
    return {'order': order_id, 'escrow': escrow['id'], 'ladder': procedures.identifier(ladder), 'head': state['head'],
            'stage': stage['name'], 'mode': stage['mode'], 'deciders': list(stage['deciders']),
            'recipient_role': recipient, 'recipient_key': ladder['parties'][recipient], 'pseudonym_role': held[0],
            'decided_at': state['last_at'], 'execution_authorized': False}


def disclosure_request(order_record, record, recipient_sealing_key, nonce):
    """The unsigned request the recipient party signs; shares come back sealed to ``recipient_sealing_key``."""
    checked = check_order(order_record, record)
    sharing._holder(recipient_sealing_key)
    key(nonce)
    body = {'version': REQUEST_VERSION, 'escrow': checked['escrow'], 'order': checked['order'],
            'recipient_role': checked['recipient_role'], 'recipient_sealing_key': recipient_sealing_key, 'nonce': nonce}
    return {'body': body, 'signing_payload': {'label': REQUEST_LABEL, 'body': deepcopy(body)},
            'required_signers': [checked['recipient_key']], 'signature_created': False, 'execution_authorized': False}


def sign_request(body, private_key):
    """Explicit local action of the recipient party. Not exposed as a tool."""
    return {'body': deepcopy(body), 'signature': sign(private_key, REQUEST_LABEL, body)}


def _open_request(request_record, checked):
    need(type(request_record) is dict and set(request_record) == {'body', 'signature'}, 'DISCLOSURE_REQUEST_FIELDS')
    body = request_record['body']
    need(type(body) is dict and set(body) == {'version', 'escrow', 'order', 'recipient_role', 'recipient_sealing_key',
                                              'nonce'} and body['version'] == REQUEST_VERSION, 'DISCLOSURE_REQUEST_FIELDS')
    need(body['escrow'] == checked['escrow'] and body['order'] == checked['order']
         and body['recipient_role'] == checked['recipient_role'], 'DISCLOSURE_REQUEST_FIELDS')
    sharing._holder(body['recipient_sealing_key']); key(body['nonce'])
    try:
        verify(checked['recipient_key'], REQUEST_LABEL, body, request_record['signature'])
    except ValueError:
        raise ValueError('DISCLOSURE_REQUEST_SIGNATURE') from None
    return digest(REQUEST_LABEL, body), body


def _release_info(escrow_id, order_id, request_id, index):
    return RELEASE_INFO + b'\0' + canonical({'escrow': escrow_id, 'order': order_id, 'request': request_id, 'index': index})


# Authorities.

class DisclosureAuthority:
    """One independent authority: releases its share only on a valid order, logged and witnessed first."""

    def __init__(self, name, signing_key, sealing_key, gate, journal_policy, *, clock):
        need(isinstance(signing_key, Ed25519PrivateKey) and isinstance(sealing_key, X25519PrivateKey)
             and isinstance(gate, journals.Gate) and callable(clock), 'DISCLOSURE_AUTHORITY_SETUP')
        need(journals.policy_hash(journal_policy) == gate.rules['hash'], 'DISCLOSURE_AUTHORITY_SETUP')
        self.name, self._signing, self._sealing, self.gate, self._clock = name, signing_key, sealing_key, gate, clock
        self.journal_policy = deepcopy(journal_policy)
        self.descriptor = {'name': name, 'signing_key': public_key(signing_key),
                           'sealing_key': sharing.x25519_public(sealing_key), 'journal': deepcopy(journal_policy)}
        _authority(self.descriptor)

    def __repr__(self):
        return f'DisclosureAuthority({self.name!r})'

    def _now(self):
        now = self._clock()
        integer(now)
        return now

    def _index(self, escrow):
        rows = escrow['policy']['authorities']
        found = [index for index, row in enumerate(rows, start=1) if row == self.descriptor]
        need(len(found) == 1, 'DISCLOSURE_NOT_AUTHORITY')
        return found[0]

    def acknowledge(self, record):
        """Open and check this authority's share at escrow time, and sign that it did (optional)."""
        escrow = open_escrow(record)
        index = self._index(escrow)
        sharing.open_share(escrow['body']['deal'], index, self._sealing)
        body = {'version': ACK_VERSION, 'escrow': escrow['id'], 'authority': self.descriptor['signing_key'],
                'index': index, 'deal': sharing.deal_id(escrow['body']['deal']), 'acknowledged_at': self._now()}
        return {'body': body, 'signature': sign(self._signing, ACK_LABEL, body)}

    def release(self, record, order_record, request_record):
        """RELEASED with the signed release and its journal proof, or WITHHELD_UNWITNESSED (logged, not returned)."""
        escrow = open_escrow(record)
        index = self._index(escrow)
        now = self._now()
        need(now <= escrow['body']['not_after'], 'DISCLOSURE_ESCROW_EXPIRED')
        checked = check_order(order_record, record)
        request_id, request = _open_request(request_record, checked)
        tag = 'disclosure:' + digest(RELEASE_LABEL, {'escrow': escrow['id'], 'order': checked['order'],
                                                     'request': request_id})
        journal = self.gate.journal
        logged = journal.tagged(tag)
        if logged:
            position = logged[0]
            stored = loads(journal.body(position))
        else:
            share = sharing.open_share(escrow['body']['deal'], index, self._sealing)
            sealed = sharing.seal(request['recipient_sealing_key'], share.to_bytes(32, 'big'),
                                  _release_info(escrow['id'], checked['order'], request_id, index))
            body = {'version': RELEASE_VERSION, 'escrow': escrow['id'], 'order': checked['order'], 'request': request_id,
                    'authority': self.descriptor['signing_key'], 'index': index, 'sealed_share': sealed,
                    'released_at': now}
            stored = {'body': body, 'signature': sign(self._signing, RELEASE_LABEL, body)}
            # The release is on the journal before anything leaves this authority.
            position = journal.append(digest(RELEASE_LABEL, body), canonical(stored), tag)
        entry = digest(RELEASE_LABEL, stored['body'])
        verdict = self.gate.check(position + 1)
        if verdict['status'] != journals.VERIFIED:
            return {'status': 'WITHHELD_UNWITNESSED', 'entry': entry, 'logged': True, 'codes': verdict['codes'],
                    'order': checked['order'], 'execution_authorized': False}
        return {'status': 'RELEASED', 'release': stored, 'proof': self.gate.proof(position), 'entry': entry,
                'order': checked['order'], 'execution_authorized': False}


def check_acknowledgements(record, acknowledgements):
    """Distinct authorities that signed they opened and checked their share of this escrow."""
    escrow = open_escrow(record)
    need(type(acknowledgements) is list and len(acknowledgements) <= sharing.MAX_HOLDERS, 'DISCLOSURE_ACK')
    keys = {row['signing_key']: index for index, row in enumerate(escrow['policy']['authorities'], start=1)}
    found = set()
    for item in acknowledgements:
        need(type(item) is dict and set(item) == {'body', 'signature'}, 'DISCLOSURE_ACK')
        body = item['body']
        need(type(body) is dict and set(body) == {'version', 'escrow', 'authority', 'index', 'deal', 'acknowledged_at'}
             and body['version'] == ACK_VERSION and body['escrow'] == escrow['id']
             and keys.get(body['authority']) == body['index']
             and body['deal'] == sharing.deal_id(escrow['body']['deal']), 'DISCLOSURE_ACK')
        try:
            verify(body['authority'], ACK_LABEL, body, item['signature'])
        except ValueError:
            raise ValueError('DISCLOSURE_ACK') from None
        found.add(body['authority'])
    return {'escrow': escrow['id'], 'acknowledged': len(found), 'of': len(keys),
            'threshold': escrow['policy']['threshold'], 'execution_authorized': False}


# The recipient combines releases.

def disclose(record, order_record, request_record, releases, *, recipient_key, now):
    """Check k witnessed releases, rebuild K, open the binding and check the principal's own signature.

    A release that fails its signature, witness proof or Feldman check is listed in
    ``faulty`` with the authority that signed it, and does not count.
    """
    escrow = open_escrow(record)
    checked = check_order(order_record, record)
    request_id, request = _open_request(request_record, checked)
    need(isinstance(recipient_key, X25519PrivateKey)
         and sharing.x25519_public(recipient_key) == request['recipient_sealing_key'], 'DISCLOSURE_RECIPIENT_KEY')
    integer(now)
    need(type(releases) is list and len(releases) <= MAX_RELEASES, 'DISCLOSURE_RELEASE')
    authorities = {row['signing_key']: (index, row) for index, row in enumerate(escrow['policy']['authorities'], start=1)}
    deal = escrow['body']['deal']
    shares, used, faulty = {}, [], []
    for item in releases:
        need(type(item) is dict and {'release', 'proof'} <= set(item), 'DISCLOSURE_RELEASE')
        stored = item['release']
        need(type(stored) is dict and set(stored) == {'body', 'signature'} and type(stored['body']) is dict, 'DISCLOSURE_RELEASE')
        body = stored['body']
        need(set(body) == {'version', 'escrow', 'order', 'request', 'authority', 'index', 'sealed_share', 'released_at'}
             and body['version'] == RELEASE_VERSION and body['escrow'] == escrow['id'] and body['order'] == checked['order']
             and body['request'] == request_id and body['authority'] in authorities
             and authorities[body['authority']][0] == body['index'], 'DISCLOSURE_RELEASE')
        index, row = authorities[body['authority']]
        if index in shares:
            continue
        entry = digest(RELEASE_LABEL, body)
        try:
            verify(body['authority'], RELEASE_LABEL, body, stored['signature'])
        except ValueError:
            faulty.append({'authority': row['name'], 'index': index, 'reason': 'DISCLOSURE_RELEASE_SIGNATURE'})
            continue
        try:
            proof = journals.verify_proof(item['proof'], row['journal'], now, entry=entry)
        except ValueError as error:
            proof = {'status': journals.REFUSED, 'included': False, 'codes': [str(error) if str(error).isupper()
                                                                              else 'WITNESS_BUNDLE']}
        if proof['status'] != journals.VERIFIED or not proof['included']:
            faulty.append({'authority': row['name'], 'index': index, 'reason': 'DISCLOSURE_RELEASE_UNWITNESSED',
                           'codes': proof['codes'], 'entry': entry})
            continue
        try:
            raw = sharing.unseal(recipient_key, body['sealed_share'], _release_info(escrow['id'], checked['order'],
                                                                                   request_id, index))
            share = int.from_bytes(raw, 'big')
            need(len(raw) == 32, 'SHARING_SEALED')
            sharing.check_share(deal, index, share)
        except ValueError as error:
            # A signed, witnessed release whose share fails is evidence against the authority that released it.
            faulty.append({'authority': row['name'], 'index': index, 'reason': 'DISCLOSURE_SHARE_INVALID',
                           'detail': str(error) if str(error).isupper() else 'SHARING_SEALED', 'entry': entry,
                           'release': deepcopy(stored)})
            continue
        shares[index] = share
        used.append({'authority': row['name'], 'signing_key': body['authority'], 'index': index, 'entry': entry,
                     'journal_origin': proof['origin'], 'checkpoint_size': proof['size'],
                     'witnesses': proof['witnesses'], 'released_at': body['released_at']})
    need(len(shares) >= escrow['policy']['threshold'], 'DISCLOSURE_THRESHOLD_UNMET')
    secret = sharing.combine(deal, shares)
    context = deal['context']
    try:
        plaintext = AESGCM(_aead_key(secret, context)).decrypt(_unb64(escrow['body']['binding']['nonce']),
                                                              _unb64(escrow['body']['binding']['ciphertext']),
                                                              _header(escrow['body']))
        binding = loads(plaintext)
    except (InvalidTag, ValueError):
        raise ValueError('DISCLOSURE_BINDING') from None
    need(type(binding) is dict and set(binding) == {'version', 'request', 'signature'}
         and binding['version'] == BINDING_VERSION, 'DISCLOSURE_BINDING')
    principal_request = binding['request']
    try:
        _checked_request(principal_request, binding['signature'], escrow['body']['policy'])
    except ValueError:
        raise ValueError('DISCLOSURE_BINDING') from None
    need(_request_id(principal_request) == escrow['body']['request']
         and principal_request['holder_keys'] == [escrow['body']['pseudonym']], 'DISCLOSURE_BINDING')
    return {'status': 'DISCLOSED', 'principal': did(principal_request['account'], principal_request['chain']),
            'account': principal_request['account'], 'pseudonym': escrow['body']['pseudonym'],
            'issuer': escrow['body']['issuer'], 'escrow': escrow['id'], 'order': checked['order'],
            'stage': checked['stage'], 'request': request_id, 'authorities': used, 'faulty': faulty,
            'principal_signature': 'VERIFIED_PRINCIPAL_SIGNED_THE_REQUEST_NAMING_THE_PSEUDONYM',
            'attributable': True, 'execution_authorized': False}


def describe():
    return {'versions': [POLICY_VERSION, ESCROW_VERSION, BINDING_VERSION, ORDER_VERSION, REQUEST_VERSION,
                         RELEASE_VERSION, ACK_VERSION], 'status': 'EXPERIMENTAL_OPTIONAL',
            'idea': 'Concordium anonymity revokers, rebuilt from Shamir 1979, Feldman 1987, HPKE RFC 9180, AES-256-GCM and HKDF RFC 5869',
            'credential': hc.ATTRIBUTE_VERSION + ' with aap_escrow', 'order': 'FINALISED_AGREED_ESCALATION_LADDER_ONLY',
            'release': 'LOGGED_THEN_RETURNED_ONLY_UNDER_A_FRESH_QUORUM_COSIGNED_CHECKPOINT',
            'disclosure_outcome': {'remedy': REMEDY, 'escrow': 'HASH of the escrow', 'recipient': 'ROLE of the other disputant'},
            'hiding': 'FEWER_THAN_K_AUTHORITIES_LEARN_ONLY_K_TIMES_G; AUTHORITIES_NEVER_SEE_THE_BINDING',
            'attribution': 'SIGNED_RELEASES_WITH_JOURNAL_INCLUSION; PRINCIPAL_SIGNATURE_OVER_THE_PSEUDONYM',
            'limits': ['the issuer knows the binding at issuance and is trusted to deal correctly; a bad deal is evidence against it',
                       'authority independence is an operational fact this code cannot establish',
                       'a ladder outcome is an authenticated statement under an adopted procedure, not a court order',
                       'one holder key per escrowed request; BATCH credentials are not escrowed'],
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
