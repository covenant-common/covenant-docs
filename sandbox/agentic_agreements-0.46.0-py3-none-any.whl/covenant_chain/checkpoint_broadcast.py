"""One-way checkpoint broadcast: light-client material where nobody can ask again.

A broadcaster (a satellite data carousel, a radio net, a file passed hand to
hand) sends committee-certified light checkpoints, witness-cosigned Merkle
checkpoints, signed revocation snapshots and release (update) metadata. The
document travels as broadcast_fec chunks, so any k of the n chunks rebuild it.

A broadcast never grants authority. The broadcaster is not trusted and signs
nothing that matters. Each item is checked against the receiver's own pinned
genesis, witness keys, revocation roots and release signers; a kind the
receiver did not pin is refused, never assumed. A verified item is a fact
about signatures, not about the latest state, payment or settlement.
"""
from copy import deepcopy
import hashlib
import re

from . import broadcast_fec as fec, crypto as c

VERSION = 'covenant-checkpoint-broadcast/0.1'
MAX_ITEMS = 64
KINDS = {'LIGHT_CHECKPOINT': 'kind table key bundle', 'WITNESS_CHECKPOINT': 'kind record entry_ids',
         'REVOCATIONS': 'kind root history', 'RELEASE': 'kind manifest'}
_CODE = re.compile(r'[A-Z][A-Z0-9_]{1,80}')


def light_item(bundle, table, key):
    return {'kind': 'LIGHT_CHECKPOINT', 'table': table, 'key': key, 'bundle': deepcopy(bundle)}


def witness_item(record, entry_ids):
    return {'kind': 'WITNESS_CHECKPOINT', 'record': deepcopy(record), 'entry_ids': list(entry_ids)}


def revocations_item(root, history):
    return {'kind': 'REVOCATIONS', 'root': root, 'history': deepcopy(history)}


def release_item(manifest):
    return {'kind': 'RELEASE', 'manifest': deepcopy(manifest)}


def _shape(item):
    c.need(type(item) is dict and type(item.get('kind')) is str and item['kind'] in KINDS, 'BROADCAST_ITEM_KIND')
    c.exact(item, KINDS[item['kind']])


def document(chain, items, *, sequence, issued_at):
    """Canonical bytes of one broadcast. sequence and issued_at are the sender's assertions."""
    c.key(chain)
    c.integer(sequence)
    c.integer(issued_at)
    c.need(type(items) is list and 1 <= len(items) <= MAX_ITEMS, 'BROADCAST_ITEMS')
    for item in items:
        _shape(item)
    raw = c.canonical({'version': VERSION, 'chain': chain, 'sequence': sequence, 'issued_at': issued_at,
                       'items': items})
    c.need(len(raw) <= fec.MAX_PAYLOAD, 'BROADCAST_PAYLOAD_SIZE')
    return raw


def broadcast(chain, items, *, sequence, issued_at, symbol_size=1024, repair=None):
    return fec.encode_chunks(document(chain, items, sequence=sequence, issued_at=issued_at),
                             symbol_size=symbol_size, repair=repair)


def _pins(witness, revocation_roots, release_signers):
    if witness is not None:
        c.exact(witness, 'log keys quorum max_age')
        c.need(type(witness['keys']) is list and 1 <= len(witness['keys']) <= 32 and
               witness['log'] not in witness['keys'], 'BROADCAST_WITNESS_PIN')
        for item in [witness['log'], *witness['keys']]:
            c.need(type(item) is str, 'BROADCAST_WITNESS_PIN')
            c.verification_key(item)
        c.integer(witness['quorum'], True)
        c.integer(witness['max_age'], True)
        c.need(witness['quorum'] <= len(witness['keys']), 'BROADCAST_WITNESS_PIN')
    c.need(type(revocation_roots) in (list, tuple) and len(revocation_roots) <= 64, 'BROADCAST_REVOCATION_PIN')
    for item in revocation_roots:
        c.need(type(item) is str, 'BROADCAST_REVOCATION_PIN')
        c.verification_key(item)
    if release_signers is not None:
        c.need(type(release_signers) in (list, tuple) and len(set(release_signers)) == len(release_signers) == 5,
               'BROADCAST_RELEASE_PIN')
        for item in release_signers:
            c.key(item)


def _verify(item, genesis, chain, now, minimum_height, witness, revocation_roots, release_signers, light_client):
    from . import fork_defence, light, portable_trust as trust
    _shape(item)
    kind = item['kind']
    if kind == 'LIGHT_CHECKPOINT':
        c.need(type(item['table']) is str and type(item['key']) is str, 'BROADCAST_LIGHT_RECORD')
        if light_client is not None:
            report = light_client.assess(item['bundle'], minimum_height, item['table'], item['key'])
        else:
            report = light.verify_light_bundle(genesis, item['bundle'], chain, minimum_height, item['table'],
                                               item['key'])
        return {'table': item['table'], 'key': item['key'], 'value': report['value'], 'height': report['height'],
                'head': report['head'], 'epoch': report['epoch'], 'assurance': report['assurance'],
                'freshness': report['freshness']}
    if kind == 'WITNESS_CHECKPOINT':
        c.need(witness is not None, 'BROADCAST_NOT_PINNED')
        report = trust.verify_witness(item['entry_ids'], item['record'], None, witness['log'], witness['keys'],
                                      witness['quorum'], now, witness['max_age'])
        return {name: report[name] for name in ('checkpoint', 'log', 'size', 'witnesses', 'consistency',
                                                'currentness', 'fresh')}
    if kind == 'REVOCATIONS':
        c.need(item['root'] in revocation_roots, 'BROADCAST_NOT_PINNED')
        report = trust.verify_revocations(item['history'], item['root'], now)
        return {name: report[name] for name in ('root', 'head', 'sequence', 'revoked', 'currentness')}
    c.need(release_signers is not None, 'BROADCAST_NOT_PINNED')
    manifest = item['manifest']
    release = fork_defence.verify_release(manifest)
    c.need(manifest['signers'] == sorted(release_signers), 'BROADCAST_RELEASE_SIGNERS')
    c.need(release['genesis'] == chain, 'RELEASE_GENESIS')
    return {'release_version': manifest['version'], 'digest': manifest['digest'], 'quorum': release['quorum'],
            'installed': False}


def verify_document(payload, *, genesis, now, minimum_height=1, witness=None, revocation_roots=(),
                    release_signers=None, light_client=None):
    """Check every item against the receiver's own pins. Refusals are listed, not fatal.

    witness is {'log', 'keys', 'quorum', 'max_age'}; release_signers is the
    pinned 3-of-5 release seat list. An optional LightClient keeps its own
    durable height floor across broadcasts.
    """
    from .crypto import genesis_id
    c.need(type(payload) is bytes and 0 < len(payload) <= fec.MAX_PAYLOAD, 'BROADCAST_PAYLOAD_SIZE')
    value = c.loads(payload)
    c.need(c.canonical(value) == payload, 'BROADCAST_CANONICAL')
    c.exact(value, 'version chain sequence issued_at items')
    c.need(value['version'] == VERSION, 'BROADCAST_VERSION')
    chain = genesis_id(genesis)
    c.need(value['chain'] == chain, 'BROADCAST_CHAIN_PIN')
    c.integer(value['sequence'])
    c.integer(value['issued_at'])
    c.integer(now)
    c.integer(minimum_height)
    c.need(type(value['items']) is list and 1 <= len(value['items']) <= MAX_ITEMS, 'BROADCAST_ITEMS')
    _pins(witness, revocation_roots, release_signers)
    verified, refused = [], []
    for index, item in enumerate(value['items']):
        kind = item.get('kind') if type(item) is dict and type(item.get('kind')) is str else None
        try:
            report = _verify(item, genesis, chain, now, minimum_height, witness, revocation_roots,
                             release_signers, light_client)
        except (ValueError, KeyError, TypeError, IndexError) as exc:
            named = isinstance(exc, ValueError) and _CODE.fullmatch(str(exc))
            code = str(exc) if named else 'BROADCAST_ITEM_INVALID'
            refused.append({'index': index, 'kind': kind, 'code': code})
            continue
        verified.append({'index': index, 'kind': kind, **report, 'execution_authorized': False})
    return {'version': VERSION, 'payload_sha256': hashlib.sha256(payload).hexdigest(), 'chain': chain,
            'sequence_asserted': value['sequence'], 'issued_at_asserted': value['issued_at'],
            'verified': verified, 'refused': refused, 'currentness': 'UNKNOWN_ONE_WAY_BROADCAST',
            'authority_granted': False, 'execution_authorized': False, 'payment_verified': False,
            'ledger_confirmed': False}


def receive(chunks, **pins):
    """broadcast_fec.decode_chunks, then verify_document."""
    return verify_document(fec.decode_chunks(chunks), **pins)
