"""Normalize existing local catalogs into arbitrary typed discovery objects.

No decryption, URL retrieval, installation or publication occurs. Attributes
are authenticated declarations or owner installation, never performance proof.
"""
from copy import deepcopy
from .crypto import need
SOURCES=('INSTALLED','MARKETPLACE','FORUM','AGENTS')

def catalog(exchange,source='INSTALLED',group=None,market=None,packets=None,query='',limit=256):
    need(source in SOURCES and type(query) is str and len(query)<=256 and type(limit) is int and 1<=limit<=256,'DESIRE_CATALOG_ARGUMENTS');objects=[]
    if source=='INSTALLED':
        registry=getattr(exchange,'adapters',None) or getattr(getattr(exchange,'workflow',None),'adapters',None)
        objects=exchange.mechanisms.objects();adapters={} if registry is None else registry.describe()
        execution_adapters=set(adapters)
        if getattr(exchange,'applications',None) is not None:
            for row in exchange.applications.describe()['applications']:
                manifest=row['manifest']
                objects.append({'target':{'kind':'application','id':row['id']},'title':manifest['name']+' '+manifest['release'],
                    'description':'Owner-adopted signed application '+ ' '.join(manifest['routes']),
                    'attributes':{'family':'application','installed':True,'publisher':manifest['publisher'],'level':row['level'],'economics':manifest['economics'],'security_inherited':False},
                    'links':[{'kind':'application','id':r} for r in manifest['dependencies']+([] if manifest['parent'] is None else [manifest['parent']])]})
        for ref,entry in exchange.mechanisms.describe().items():
            for operation,description in entry['operations'].items():
                if description['adapter'] is not None:adapters[description['adapter']]=deepcopy(exchange.mechanisms.get(ref,operation)[1].manifest)
        for ref,m in adapters.items():
            row={'target':{'kind':'connector','id':ref},'title':m['name'],'description':m['effect'],'attributes':{'family':'connector','installed':True,'capability':m['capability'],'recovery':m['recovery']},'links':[]}
            from .a2a_connector import A2AConnector,PROTOCOL_VERSION
            if ref in execution_adapters and isinstance(registry.get(ref),A2AConnector):
                row['title']='A2A '+PROTOCOL_VERSION+' owner-installed agent connector'
                row['description']='A2A JSONRPC discovery, messages, task lookup and cancellation. Separate workflow approval required.'
                row['attributes'].update(protocol='A2A',protocol_version=PROTOCOL_VERSION,binding='JSONRPC')
            objects.append(row)
    else:
        need(exchange.network is not None,'DESIRE_NETWORK_REQUIRED')
        if source=='MARKETPLACE':
            from .marketplace_book import catalog as market_catalog
            view=market_catalog(exchange.network,group=group,market=market,objects=packets,query=query,limit=256);need(not view['truncated'],'DESIRE_CATALOG_SCOPE_TOO_WIDE')
            for row in view['records']:
                if row['status']!='CURRENT_DECLARATION':continue
                record=row['record'];d=record['data'];links=[]
                for key in ('market','listing','archetype'):
                    if d.get(key) is not None:links.append({'kind':'marketplace-'+{'market':'market','listing':'listing','archetype':'archetype'}[key],'id':d[key]})
                objects.append({'target':row['target'],'title':record['title'],'description':record['kind']+' '+d.get('mechanism','')+' '+d.get('category',''),
                    'attributes':{'family':record['kind'].lower(),'mechanism':d.get('mechanism'),'author':record['author'],'group':row['group'],'status':row['status']},'links':links})
        elif source=='AGENTS':
            for actor in sorted(exchange.network.peers):objects.append({'target':{'kind':'agent','id':actor},'title':'Admitted peer '+actor,'description':'Owner-admitted signed forum peer; admission is not reputation.',
                'attributes':{'family':'agent','admitted_peer':True,'local_actor':actor==exchange.network.actor},'links':[]})
        else:
            from .agent_network import unpack
            from .crypto import key
            if group is not None:key(group)
            for ref,event in sorted(exchange.network.events().items()):
                b=event['body']
                if group is not None and ref!=group and b['group']!=group:continue
                value=unpack(b);title=value.get('name',value.get('title',b['kind'])) if type(value) is dict else b['kind']
                objects.append({'target':{'kind':'forum-event','id':ref},'title':str(title)[:256] or b['kind'],'description':str(value)[:4096],
                    'attributes':{'family':'forum-event','kind':b['kind'],'author':b['actor'],'group':b['group'],'omitted_parent_links':max(0,len(b['parents'])-64)},'links':[{'kind':'forum-event','id':p} for p in b['parents'][:64]]})
    for obj in objects:
        excerpted=False
        for field,budget in (('title',512),('description',4096)):
            encoded=obj[field].encode('utf-8')
            if len(encoded)>budget:obj[field]=encoded[:budget].decode('utf-8',errors='ignore');excerpted=True
        if excerpted:obj['attributes']['excerpted']=True
    objects=[o for o in objects if query.casefold() in (o['title']+' '+o['description']+' '+str(o['attributes'])).casefold()]
    return {'source':source,'objects':objects[:limit],'total_matching':len(objects),'truncated':len(objects)>limit,'claims':'OWNER_INSTALLATION_OR_AUTHENTICATED_DECLARATIONS_NOT_EXTERNAL_PERFORMANCE','privacy':'LOCAL_SELECTED_REPLICA_NO_DECRYPTION_OR_AUTOMATIC_PUBLICATION','execution_authorized':False}

def identify(kind,reference,salt=None,context=None):
    from covenant_language import mechanism_plans as p
    p.text(kind,80);value={'kind':kind,'reference':deepcopy(reference)}
    if salt is None:
        need(context is None,'DESIRE_REFERENCE_CONTEXT_WITHOUT_SALT');ref=p._id('COVENANT-DISCOVERY-REFERENCE-0.1',value);mode='EXACT_PUBLIC_REFERENCE_HASH'
    else:
        need(context is not None,'DESIRE_REFERENCE_SALT_REQUIRES_CONTEXT');ref=p.field_commitment(value,salt,context,'discovery-reference','');mode='CONTEXT_BOUND_SECRET_SALTED_REFERENCE'
    return {'target':{'kind':kind,'id':ref},'identity_scope':mode,'ownership_truth_or_execution':'NOT_ESTABLISHED','reference_salt_and_plaintext_returned':False,'execution_authorized':False}
