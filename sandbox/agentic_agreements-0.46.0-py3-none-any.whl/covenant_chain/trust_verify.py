"""Offline checks of agreement-terms hashes and signed receipts (experimental).

Ported from PR 73 (WP-19, trust_read.py). The checks are covenant_portable_trust
actions because covenant_verify is the agent-native work-order verb.

- ATR hash: SHA-256 of the exact agreement-terms bytes, the LCP atrHash rule.
  An x402 v2 legalContext.atrHash value is the same digest.
- opencovenant-receipt/0.1: Ed25519 over this tree's domain-separated canonical
  bytes, the construction published for open-covenant Guard. Interop is
  unverified: no external test vectors exist and the canonical bytes are not
  proven identical to Guard's. Portions derived from open-covenant/covenant,
  Copyright 2026 Covenant contributors, Apache-2.0; see NOTICE.
- causal receipt: an existing covenant-causal-receipts/0.1 SAY or SHOW event.

The expected hash, the signer keys and the credential policy are pins the
caller adopted. A valid signature by an unpinned key is SIGNER_NOT_PINNED,
never VERIFIED. No network, credentials, keys or storage; a one-byte change fails.
"""
import base64
from copy import deepcopy
import hashlib
import re
import time

from . import parity_ids as ids
from .crypto import canonical, digest, exact, key, need, public_key, sign, verify

MAX_TERMS = 262144
MAX_ASCII = 65536
MAX_BASE64 = 4 * ((MAX_TERMS + 2) // 3)
MAX_RECEIPT = 65536
MAX_SIGNERS = 32
HEX = re.compile(r'[0-9a-f]{64}\Z')
CODE = re.compile(r'[A-Z][A-Z0-9_]{0,63}\Z')
_READ = {'offline': True, 'network_requests': 0, 'execution_authorized': False}


def _result(code, kind, **extra):
    out = {'ok': code == ids.CODE_VERIFIED, 'code': code, 'kind': kind, **extra, **_READ}
    if code != ids.CODE_VERIFIED:
        out['next_action'] = ids.remediation(code)
    return out


def _signers(signers):
    need(type(signers) in (list, tuple) and 1 <= len(signers) <= MAX_SIGNERS
         and all(type(s) is str and HEX.fullmatch(s) for s in signers)
         and len(set(signers)) == len(signers), 'TRUST_SIGNERS')
    return tuple(signers)


def atr_hash(raw):
    """SHA-256 of the exact terms bytes: the LCP atrHash and x402 legalContext.atrHash value."""
    need(type(raw) is bytes and 0 < len(raw) <= MAX_TERMS, 'TRUST_ATR_SIZE')
    return hashlib.sha256(raw).hexdigest()


def _atr_bytes(document):
    """Exact bytes from bytes_ascii or canonical bytes_base64; never both."""
    need(type(document) is dict, 'TRUST_ATR_FIELDS')
    carried = set(document) - {'atr_hash'}
    need(len(carried) == 1 and carried <= {'bytes_ascii', 'bytes_base64'}, 'TRUST_ATR_FIELDS')
    if 'bytes_ascii' in document:
        text = document['bytes_ascii']
        need(type(text) is str and 0 < len(text) <= MAX_ASCII and text.isascii(), 'TRUST_ATR_BYTES')
        return text.encode('ascii')
    encoded = document['bytes_base64']
    need(type(encoded) is str and 0 < len(encoded) <= MAX_BASE64, 'TRUST_ATR_BYTES')
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError) as exc:
        raise ValueError('TRUST_ATR_BYTES') from exc
    need(base64.b64encode(raw).decode('ascii') == encoded, 'TRUST_ATR_BYTES')
    return raw


def atr_document(raw):
    """The carried form of exact terms bytes: ASCII text when possible, else base64."""
    hashed = atr_hash(raw)
    if raw.isascii() and len(raw) <= MAX_ASCII:
        return {'atr_hash': hashed, 'bytes_ascii': raw.decode('ascii')}
    return {'atr_hash': hashed, 'bytes_base64': base64.b64encode(raw).decode('ascii')}


def hash_terms(document):
    need(type(document) is dict and 'atr_hash' not in document, 'TRUST_ATR_FIELDS')
    raw = _atr_bytes(document)
    return {'atr_hash': atr_hash(raw), 'bytes': len(raw), 'version': ids.ATR_VERSION, **_READ}


def verify_atr(document):
    raw = _atr_bytes(document)
    claimed = document.get('atr_hash')
    need(type(claimed) is str and HEX.fullmatch(claimed), 'TRUST_ATR_HASH')
    actual = atr_hash(raw)
    code = ids.CODE_VERIFIED if actual == claimed else ids.CODE_BYTE_MISMATCH
    return _result(code, 'atr', atr_hash=actual, bytes=len(raw), version=ids.ATR_VERSION)


def sign_opencovenant_receipt(private, body):
    """Host and test helper. The agent tool never holds the attestor key."""
    need(type(body) is dict and len(canonical(body)) <= MAX_RECEIPT, 'TRUST_RECEIPT')
    public = public_key(private)
    need(type(public) is str, 'TRUST_RECEIPT')
    return {'version': ids.OPENCOVENANT_RECEIPT_VERSION, 'body': deepcopy(body), 'public': public,
            'signature': sign(private, ids.OPENCOVENANT_RECEIPT_DOMAIN, body)}


def verify_opencovenant_receipt(receipt, signers):
    pins = _signers(signers)
    exact(receipt, 'version body public signature')
    need(receipt['version'] == ids.OPENCOVENANT_RECEIPT_VERSION, 'TRUST_RECEIPT_VERSION')
    body, public = receipt['body'], receipt['public']
    need(type(body) is dict and len(canonical(body)) <= MAX_RECEIPT
         and type(public) is str and HEX.fullmatch(public), 'TRUST_RECEIPT')
    profile = {'profile': ids.OPENCOVENANT_RECEIPT_VERSION, 'interop': ids.OPENCOVENANT_INTEROP}
    try:
        verify(public, ids.OPENCOVENANT_RECEIPT_DOMAIN, body, receipt['signature'])
    except ValueError as exc:
        if str(exc) != 'SIGNATURE':
            raise
        return _result(ids.CODE_SIGNATURE_INVALID, 'opencovenant_receipt', **profile)
    found = digest(ids.OPENCOVENANT_RECEIPT_DOMAIN, body)
    code = ids.CODE_VERIFIED if public in pins else ids.CODE_SIGNER_NOT_PINNED
    return _result(code, 'opencovenant_receipt', receipt_id=found, signer=public, **profile)


def verify_causal_receipt(document, signers):
    """One causal SAY or SHOW receipt, its domain, a pinned issuer and an optional expected id."""
    from .causal import PROFILE, validate
    pins = _signers(signers)
    need(type(document) is dict and {'domain', 'event'} <= set(document) <= {'domain', 'event', 'expected_id'},
         'FIELDS')
    key(document['domain'])
    expected = document.get('expected_id')
    if expected is not None:
        key(expected)
    try:
        found = validate(document['event'], document['domain'])
    except ValueError as exc:
        if str(exc) != 'SIGNATURE':
            raise
        return _result(ids.CODE_SIGNATURE_INVALID, 'causal_receipt', profile=PROFILE)
    body = document['event']['body']
    issuer = body['issuer']
    if issuer not in pins:
        code = ids.CODE_SIGNER_NOT_PINNED
    elif expected is not None and expected != found:
        code = ids.CODE_BYTE_MISMATCH
    else:
        code = ids.CODE_VERIFIED
    return _result(code, 'causal_receipt', receipt_id=found, signer=issuer if type(issuer) is str else None,
                   receipt_kind=body['kind'], content_hash=body['content_hash'], profile=PROFILE)


def _credential(part):
    """The SD-JWT presentation check of covenant_credential.verify, reported as one bundle part."""
    from .hidden_credentials import verify_presentation
    need(type(part) is dict and set(part) == {'presentation', 'policy', 'nonce', 'now'}, 'TRUST_BUNDLE')
    try:
        found = verify_presentation(part['presentation'], part['policy'], nonce=part['nonce'], now=part['now'])
    except ValueError as exc:
        code = str(exc) if CODE.fullmatch(str(exc)) else 'CREDENTIAL_INVALID'
        return {'ok': False, 'code': code}, None
    return {'ok': True, 'code': ids.CODE_VERIFIED}, found


def verify_trust_bundle(document, signers):
    """Causal receipt, ATR hash and an optional credential in one offline call."""
    need(type(document) is dict and {'receipt', 'atr'} <= set(document) <= {'receipt', 'atr', 'credential'},
         'TRUST_BUNDLE')
    parts = {'receipt': verify_causal_receipt(document['receipt'], signers), 'atr': verify_atr(document['atr'])}
    extra = {}
    if 'credential' in document:
        parts['credential'], found = _credential(document['credential'])
        if found is not None:
            extra['credential'] = found
    ok = all(part['ok'] for part in parts.values())
    return _result(ids.CODE_VERIFIED if ok else ids.CODE_BUNDLE_PART_FAILED, 'bundle',
                   parts={name: part['code'] for name, part in parts.items()},
                   receipt_id=parts['receipt'].get('receipt_id'), atr_hash=parts['atr']['atr_hash'], **extra)


def verify_document(kind, document, *, signers=None):
    """PR 73's single entry point: kind is atr, opencovenant, receipt or bundle. Adds elapsed_ms."""
    started = time.perf_counter()
    if kind == 'atr':
        result = verify_atr(document)
    elif kind == 'opencovenant':
        result = verify_opencovenant_receipt(document, signers)
    elif kind == 'receipt':
        result = verify_causal_receipt(document, signers)
    elif kind == 'bundle':
        result = verify_trust_bundle(document, signers)
    else:
        raise ValueError('TRUST_KIND')
    result['elapsed_ms'] = round((time.perf_counter() - started) * 1000, 3)
    return result


def call(action, parameters):
    """covenant_portable_trust receipt actions. Deterministic: no timing in the result."""
    need(type(parameters) is dict, 'FIELDS')
    p = parameters
    if action == 'atr_hash':
        return hash_terms(p)
    if action == 'verify_atr':
        return verify_atr(p)
    need('signers' in p, 'TRUST_SIGNERS')
    rest = {name: value for name, value in p.items() if name != 'signers'}
    if action == 'verify_opencovenant_receipt':
        need(set(rest) == {'receipt'}, 'FIELDS')
        return verify_opencovenant_receipt(rest['receipt'], p['signers'])
    if action == 'verify_causal_receipt':
        return verify_causal_receipt(rest, p['signers'])
    if action == 'verify_trust_bundle':
        return verify_trust_bundle(rest, p['signers'])
    raise ValueError('TRUST_TOOL_ACTION')


def describe():
    from .causal import PROFILE
    return {'actions': list(ids.VERIFY_ACTIONS), 'maturity': 'experimental',
            'atr': {'version': ids.ATR_VERSION, 'rule': 'SHA-256 of the exact terms bytes', 'max_bytes': MAX_TERMS},
            'opencovenant': {'version': ids.OPENCOVENANT_RECEIPT_VERSION, 'domain': ids.OPENCOVENANT_RECEIPT_DOMAIN,
                             'interop': ids.OPENCOVENANT_INTEROP},
            'causal': {'version': PROFILE, 'kinds': ['SAY', 'SHOW']},
            'pins': 'CALLER_ADOPTED_HASH_SIGNERS_AND_CREDENTIAL_POLICY',
            'unpinned_valid_signature': ids.CODE_SIGNER_NOT_PINNED, **_READ}
