"""Keyless READ proposals/reviews; no wallet adoption, reservation or execution."""
from . import reliance, reliance_review
from .agent_tools import _fields
from .crypto import need


def _shape(names, required=None):
    return {'type':'object','properties':names,'required':list(names if required is None else required),'additionalProperties':False}


def definition():
    obj={'type':'object'}; text={'type':'string','minLength':1,'maxLength':2048}
    ref={'type':'string','minLength':64,'maxLength':64}
    number={'type':'integer','minimum':0,'maximum':2**53-1}
    array={'type':'array','items':obj,'maxItems':256}
    actions={
        'policy':_shape({'policy':obj}),
        'intent':_shape({'policy':obj,'subject':{},'adapter':ref,'effect':ref,'request_hash':ref,
                        'allocations':obj,'not_before':number,'expires':number,'nonce':ref}),
        'recover':_shape({'envelope':obj,'expected_wallet':ref,'expected_head':ref,'attestor':{},'now':number,'max_age':number}),
        'plan':_shape({'goal':text,'steps':array,'observations':obj,'available':obj}, ['goal','steps']),
        'outcomes':_shape({'subjects':{'type':'array','items':ref,'maxItems':256},'reports':array,
                          'context':text,'seeds':obj,'edges':{'type':'array','items':{'type':'array','items':ref,'maxItems':2},'maxItems':4096}},
                          ['subjects','reports','context','seeds']),
        'qualification':_shape({'subject':ref,'implementation':ref,'cases':array,
                               'required_categories':{'type':'array','items':text,'maxItems':32}}, ['subject','implementation','cases'])}
    return {'name':'covenant_reliance','description':'Draft exact mandate/intent signing payloads, plan dependencies, verify independently pinned recovery checkpoints, and inspect contextual outcome or qualification declarations. READ only: no adoption, signatures, holds, execution or evidence truth is conferred.',
            'inputSchema':{'type':'object','oneOf':[_shape({'action':{'const':action},'parameters':parameters}) for action,parameters in actions.items()]},
            'outputSchema':{'type':'object'},'annotations':{'readOnlyHint':True,'destructiveHint':False,'idempotentHint':True,'openWorldHint':False}}


def call(arguments):
    _fields(arguments, ('action','parameters')); action=arguments['action']; p=arguments['parameters']
    need(type(action) is str and type(p) is dict, 'RELIANCE_TOOL_ARGUMENTS')
    variants={v['properties']['action']['const']:v['properties']['parameters'] for v in definition()['inputSchema']['oneOf']}
    need(action in variants,'RELIANCE_TOOL_ACTION'); shape=variants[action]
    _fields(p, shape['required'], set(shape['properties'])-set(shape['required']))
    if action=='policy':
        policy = p.get('policy')
        if type(policy) is not dict or not policy:
            from .surface import not_committed
            return not_committed('FIELDS')
        return {'id':reliance.wallet_id(policy),**reliance.policy_payload(policy),
                               'adopted':False,'resource_backing':'OWNER_ATTESTATION_REQUIRED'}
    if action=='intent':return reliance.draft_intent(**p)
    if action=='recover':return reliance.verify_recovery(**p)
    return getattr(reliance_review,action)(**p)
