"""Read-only composition of owner-installed finance capabilities and observations.

The tools argument is an ExchangeTools-like owner with workflow.adapters. No
function invokes execute, signs, funds, reserves, or changes an existing profile.

payments items: {id, adapter, effect_id, obligation?}, optionally pinned by
expected_context, expected_head (escrow), and expected_output_hash. Obligations:
{id, agreement, payer, payee, asset, amount, label?, context?}. agreement_ids is
an allowlist supplied by the caller, normally the unified review's VERIFIED
agreements; this helper never authenticates an agreement merely from its hash.
Monetary mappings and declared amounts remain CALLER_DECLARED_BASIS. Only
recognized actual owner observations can reduce the supplied-scope remainder.
Unknown future rails remain admissible, with unknown numeric reconciliation.
"""
from copy import deepcopy
import hashlib
import json

from covenant_language.agentic import canonical
from covenant_language import marketplace, market_blueprints, frame_concepts
from .adapters import manifest_id
from .crypto import need, key, integer, digest, verify
from .payment_rails import DemoPaymentRail, quote_fee, validate_fees
from .escrow_desk import DemoEscrowDesk

VERSION = 'covenant-coordination-finance/0.1'
MAX = 2**53 - 1
MAX_ITEMS = 128

_SAFE_ERRORS = frozenset(['ADAPTER_ALREADY_INSTALLED', 'ADAPTER_IMPLEMENTATION', 'ADAPTER_INPUT_SIZE', 'ADAPTER_MANIFEST', 'ADAPTER_MANIFEST_CHANGED', 'ADAPTER_NAMESPACE', 'ADAPTER_NOT_INSTALLED', 'ADAPTER_PRIVATE_DIRECTORY', 'ADAPTER_PRIVATE_INSTANCE', 'ADAPTER_REQUEST_CHANGED', 'ADAPTER_STORAGE_CHANGED', 'ADAPTER_TEXT', 'ADOPT_A_SUPPORTED_READ_ONLY_BALANCE_AND_FEE_INTERFACE', 'ADOPT_EXACT_TERMS_AND_AUTHORITY_SEPARATELY', 'ALL_PARTICIPANTS_FUND_ASSENT_THEN_EXACT_PAYOUT_QUORUM', 'ARRAY_LIMIT', 'ASCII_PROFILE', 'AUDITED_LOCAL_ESCROW_ALLOCATION', 'BEGIN', 'BOOK_EACH_POLICY_WITH_ADOPTED_EXECUTION_AUTHORITY', 'CALLER_ASSERTION_NOT_CERTIFIED', 'CALLER_CHOSEN_SPLIT_SUMS_TO_EXACT_DEBT', 'CALLER_DECLARED_BASIS', 'CERTIFIED_SERVICE_BOOKING_AND_PROVIDER_APPROVAL', 'COMMIT', 'CONDITIONAL_RIGHT', 'COORDINATION_ADAPTER_CHANGED', 'COORDINATION_ASSET_ADAPTER', 'COORDINATION_BALANCE_OVERFLOW', 'COORDINATION_CONTEXT_CONFLICT', 'COORDINATION_CONTROLLERS', 'COORDINATION_CREDIT_ACTION', 'COORDINATION_CREDIT_ADVANCE', 'COORDINATION_CREDIT_REPAYMENT', 'COORDINATION_CREDIT_SPEC_ID', 'COORDINATION_DISTINCT_PARTIES', 'COORDINATION_DUPLICATE_AGREEMENT', 'COORDINATION_DUPLICATE_EFFECT', 'COORDINATION_DUPLICATE_OBLIGATION', 'COORDINATION_DUPLICATE_PAYMENT_ITEM', 'COORDINATION_ESCROW_ASSENT_INTERFACE', 'COORDINATION_ESCROW_JOURNAL_EFFECT', 'COORDINATION_ESCROW_OBSERVATION_CHANGED', 'COORDINATION_ESCROW_POLICY', 'COORDINATION_ESCROW_POLICY_ID', 'COORDINATION_EXPECTED_OUTPUT_HASH', 'COORDINATION_EXPECTED_OUTPUT_NOT_OBSERVED', 'COORDINATION_EXPLICIT_QUORUM', 'COORDINATION_FEE_POLICY_PIN', 'COORDINATION_FINANCE_TEXT', 'COORDINATION_HEAD_PIN_UNSUPPORTED', 'COORDINATION_MILESTONES', 'COORDINATION_MILESTONE_LABELS', 'COORDINATION_OBLIGATION_FIELDS', 'COORDINATION_OBSERVATION_INTERFACE', 'COORDINATION_PAYMENT_ACTION', 'COORDINATION_PAYMENT_ASSET', 'COORDINATION_PAYMENT_ASSURANCE', 'COORDINATION_PAYMENT_CONTEXT_NOT_ESTABLISHED', 'COORDINATION_PAYMENT_FEE', 'COORDINATION_PAYMENT_ITEM_FIELDS', 'COORDINATION_PAYMENT_LOAN_REQUIRED', 'COORDINATION_PAYMENT_PARTIES', 'COORDINATION_PAYMENT_RECEIPT_FIELDS', 'COORDINATION_PAYMENT_UNIT', 'COORDINATION_PLANNED_CREDIT_OVERPAYMENT', 'COORDINATION_PLANNED_INVENTORY_SHORTFALL', 'COORDINATION_PREVIEW_AUTHORITY', 'COORDINATION_RECEIPT_EFFECT', 'COORDINATION_RECEIPT_HASH', 'COORDINATION_RECEIPT_REUSE', 'COORDINATION_RECEIPT_VALUE', 'COORDINATION_REQUEST', 'COORDINATION_REQUESTS', 'COORDINATION_REQUEST_FIELDS', 'COORDINATION_REVIEW_SCOPE', 'COORDINATION_SERVICE_RESERVATION', 'COORDINATION_SERVICE_RESERVATION_PRICE', 'COORDINATION_UNEXPECTED_SERVICE_RESERVATION', 'COORDINATION_UNKNOWN_OBLIGATION', 'COORDINATION_UNOBSERVED_HASH', 'COORDINATION_UNVERIFIED_AGREEMENT', 'COST_PREVIEW_DOES_NOT_VERIFY_APPROVALS_OR_GRANT_AUTHORITY', 'COVERED_WITHIN_SUPPLIED_SCOPE', 'CREDIT_ALREADY_ORIGINATED', 'CREDIT_ASSET_NOT_THIS_RAIL', 'CREDIT_BORROWER', 'CREDIT_COLLATERAL', 'CREDIT_DEMO_UNSECURED_SINGLE_ASSET_ONLY', 'CREDIT_EXACT_PARTY_ASSENT', 'CREDIT_INTEGER', 'CREDIT_KIND', 'CREDIT_LENDER', 'CREDIT_LOAN_UNKNOWN', 'CREDIT_OVERPAYMENT', 'CREDIT_PARTIES', 'CREDIT_PREVIEW_ADAPTER_CHANGED', 'CREDIT_PREVIEW_ASSENT_INTERFACE', 'CREDIT_PREVIEW_EXACT_INTEGER', 'CREDIT_PREVIEW_FEE_POLICY_PIN', 'CREDIT_PREVIEW_REPAYMENTS_MUST_SUM_TO_DEBT', 'CREDIT_PREVIEW_REPAYMENT_PLAN', 'CREDIT_PREVIEW_UNSUPPORTED_FEE_INTERFACE', 'CREDIT_TERMS', 'CREDIT_UNSECURED_SINGLE_ASSET_ONLY', 'CUSTOM_OWNER_MANIFEST_AND_READ_ONLY_INTERFACES_ARE_TRUST_BOUNDARY', 'CUSTOM_OWNER_RECEIPT_NUMERIC_SEMANTICS_NOT_ADOPTED_BY_THIS_REVIEW', 'DECLARED_ZERO', 'DELETE', 'DEPTH_LIMIT', 'DRAFT_EFFECT_IDS_ARE_NOT_BOOKED_WORKFLOW_EFFECT_IDS', 'DRAFT_ONLY_NO_AUTOMATIC_REVERSAL', 'DUPLICATE_KEY', 'EACH_POLICY_NEEDS_ITS_OWN_ALL_PARTICIPANT_FUND_ASSENT_AND_PAYOUT_QUORUM', 'EARLIER_REQUEST_REQUIRES_RESOLUTION', 'ESCROW_ACTION', 'ESCROW_ADAPTER_UNSUPPORTED', 'ESCROW_ALLOCATION_NOT_CONSERVED', 'ESCROW_ALREADY_FUNDED', 'ESCROW_ASSET_OR_CONNECTOR', 'ESCROW_BALANCES_CHANGED', 'ESCROW_CONFIG', 'ESCROW_CONTRACTS_CHANGED', 'ESCROW_EXPECTED_HEAD', 'ESCROW_EXPLICIT_QUORUM', 'ESCROW_FUNDING_IS_LOCKED_CUSTODY_NOT_PAYMENT_TO_PAYEE', 'ESCROW_INPUT_SIZE', 'ESCROW_INSUFFICIENT_BALANCE', 'ESCROW_JOURNAL_ALLOCATION', 'ESCROW_JOURNAL_BALANCE', 'ESCROW_JOURNAL_CHAIN', 'ESCROW_JOURNAL_DOUBLE_FUND', 'ESCROW_JOURNAL_DUPLICATE', 'ESCROW_JOURNAL_ENCODING', 'ESCROW_JOURNAL_HASH', 'ESCROW_JOURNAL_INTENT', 'ESCROW_JOURNAL_PARTY', 'ESCROW_JOURNAL_QUORUM', 'ESCROW_JOURNAL_QUOTA', 'ESCROW_JOURNAL_RECEIPT', 'ESCROW_JOURNAL_RELEASE', 'ESCROW_JOURNAL_SIGNER', 'ESCROW_NOT_LOCKED', 'ESCROW_PAYOUTS', 'ESCROW_PAYOUT_PARTY', 'ESCROW_POLICY', 'ESCROW_QUORUM', 'ESCROW_RECEIPTS_CHANGED', 'ESCROW_RETRY_CHANGED', 'ESCROW_SIGNER', 'ESCROW_UNKNOWN', 'ESCROW_UNSUPPORTED_AUTOMATIC_RULES', 'EXACT_ALL_PARTICIPANT_FUND_ASSENT_THEN_ADOPTED_PAYOUT_QUORUM', 'EXACT_BOTH_PARTY_CREDIT_ASSENT_AND_SEPARATE_WORKFLOW_AUTHORITY', 'EXACT_HASH_OR_ADOPTED_JUDGMENT', 'EXACT_QUORUM', 'EXISTING_NATIVE_FUNDED_SERVICE_BOND_PROFILE_REQUIRES_EXPLICIT_ADOPTION', 'EXPECTED_BALANCE_DIFFERS_FROM_OBSERVED_START', 'FEES_ADDITIONAL_TO_PAYMENT_OR_DEBT_REPAYMENT', 'FIELDS', 'FIXED', 'FUND', 'GENERIC_MANIFEST_DOES_NOT_ESTABLISH_RECEIPT_NUMERIC_SEMANTICS', 'HYPOTHETICAL_PREVIEW', 'IDEMPOTENT_KEY', 'INSTALLED_NOT_EXECUTION_AUTHORITY', 'INSUFFICIENT_OBSERVED_STARTING_FUNDS_FOR_ORDERED_OUTFLOWS', 'INTEGER', 'INTEGER_RANGE', 'INVALID_JSON', 'JSON_BOM', 'JUDGED', 'KEY', 'LIMITED_BY_ACTUAL_ADAPTER_INVENTORY_AND_EXACT_AUTHORITY', 'LOCAL_CONTENT', 'LOCAL_DISPOSABLE_BALANCES_AND_POSTED_SERVICE_INVENTORY', 'LOCAL_DISPOSABLE_BALANCES_ONLY', 'LOCAL_DISPOSABLE_CREDITS_ONLY', 'LOCAL_DISPOSABLE_CREDIT_LEDGER', 'LOCAL_DISPOSABLE_CREDIT_LEDGER_NOT_EXTERNAL_PAYMENT', 'LOCAL_DISPOSABLE_CUSTODY', 'LOCAL_DISPOSABLE_CUSTODY_ONLY', 'LOCAL_DISPOSABLE_QUORUM_ESCROW', 'LOCAL_SQLITE_RECORD', 'LOCAL_WRITE_ONCE_FILE', 'LOCKED', 'MAP_KEY', 'MAP_LIMIT', 'MARKET_ASSET', 'MARKET_ASSETS', 'MARKET_ASSET_FIELDS', 'MARKET_EXTENSIONS', 'MARKET_FIELDS', 'MARKET_PARTICIPANTS', 'MARKET_PROOF_REQUIREMENTS', 'MARKET_REFERENCE', 'MARKET_RULES', 'MARKET_TEXT', 'MARKET_TRANSFER_TERMS', 'MARKET_VERSION', 'NATIVE_BOOKING_ESCROWS', 'NONE', 'NONINTEGER_NUMBER', 'NOT_ASSIGNED_BY_THIS_PREVIEW', 'NOT_ESTABLISHED', 'NOT_ESTABLISHED_BY_SELECTED_SCOPE', 'NOT_ESTABLISHED_BY_THIS_PREVIEW', 'NOT_INFERRED', 'NOT_INFERRED_ACROSS_ASSETS_OR_RAILS', 'NOT_OBSERVED', 'NOT_OBSERVED_DOES_NOT_ESTABLISH_GLOBAL_NONPAYMENT', 'NOT_PERFORMED', 'NOT_PREVIEWED_AFTER_UNRESOLVED_REQUEST', 'NOT_PROMISED', 'NOT_RESERVED', 'NOT_RESERVED_OR_ESTABLISHED', 'NOT_SUPPLIED', 'NOT_VERIFIED', 'NO_AUTOMATIC_DELIVERY_OR_DISPUTE_JUDGMENT', 'NO_RECEIPT_OBSERVED_FOR_THIS_EFFECT_AT_LOCAL_READ', 'NUMERIC_CASHFLOW_NOT_IMPLEMENTED_FOR_THIS_OWNER_INTERFACE', 'OBSERVED', 'OBSERVED_EFFECT', 'OBSERVED_EFFECT_WITH_CONTENT_HASH', 'OBSERVE_DO_NOT_ASSUME_FAILURE', 'OBSERVE_ONLY', 'OBTAIN_EXACT_ASSENT_FOR_ANY_NEW_PAYMENT_OR_REMAINING_OBLIGATION', 'ONE_COMPLETE_ALLOCATION_OF_THIS_POLICY_RESERVE', 'ONE_FULL_REPAYMENT', 'ONE_TERM_SIMPLE_CEILING_NOT_APR', 'ONE_WHOLE_RESERVE_ALLOCATION_PER_POLICY', 'ONLY_ACTUAL_ADOPTED_SERVICE_PAYMENTS_NO_PROMISED_APR', 'ONLY_SUPPLIED_AGREEMENT_ALLOWLIST_OBLIGATIONS_AND_OWNER_OBSERVED_EFFECTS', 'OPEN_CREDIT', 'OUTSTANDING', 'OWNER_INSTALLED_ADAPTER_OBSERVE', 'OWNER_INSTALLED_NO_REMOTE_CODE', 'OWNER_OBSERVED_LOCAL_TRANSFER_WITHOUT_AGREEMENT_OR_CONTEXT_BINDING', 'PAST_DUE_AT_ASSERTED_HEIGHT', 'PAYER_FUNDS_NOT_READY_AT_LOCAL_READ', 'PAYMENT_ACTION', 'PAYMENT_BALANCES', 'PAYMENT_CONSERVATION', 'PAYMENT_FEE_CAP', 'PAYMENT_FEE_POLICY', 'PAYMENT_FUNDS', 'PAYMENT_INVENTORY', 'PAYMENT_RAIL', 'PAYMENT_RAIL_CHANGED', 'PAYMENT_RAIL_NOT_INSTALLED', 'PAYMENT_RETRY_CHANGED', 'PAYMENT_UNIT_NO_AUTOMATIC_FX', 'PAYOUT', 'PLANNED_INCOMING_VALUE_NOT_COUNTED_AS_OBSERVED_FUNDS', 'PQ_PUBLIC_KEY', 'PQ_SIGNATURE_ENCODING', 'PRESERVED_AS_DATA_NEVER_EXECUTED', 'PUBLIC_KEY', 'PUBLIC_LEDGER_METADATA', 'READ_ONLY_REQUEST_PREVIEW_NOT_INSTALLED', 'RECHECK_ACTUAL_BALANCE_AND_FEE_POLICY_BEFORE_EXECUTION', 'RECHECK_LIVE_BALANCE_DEBT_INVENTORY_AND_EXACT_APPROVALS_BEFORE_EXECUTION', 'REDEEM_CREDIT', 'REMAINS_WITHIN_SUPPLIED_SCOPE', 'REPAID', 'REPAY_CREDIT', 'REQUEST_EXCEEDS_ADOPTED_FEE_CAP', 'REQUEST_NOT_SUPPORTED_OR_READY', 'REQUIRES_EXACT_OWNER_INSTALLED_ADAPTERS_AND_PARTY_APPROVALS', 'RESOLVE_UNKNOWN_AUTHORITY_CONTEXT_ASSET_OR_OBSERVATION_LINKS', 'RESOLVE_UNSUPPORTED_REQUESTS_AND_FUNDING_GAPS', 'RETAIN_EXPECTED_HEAD_OUTSIDE_THIS_HOST', 'REVIEW_ITEM_WARNINGS_BEFORE_RELYING_ON_NUMERIC_REMAINDERS', 'ROLLBACK', 'SEPARATE_EXPLICIT_COMMITMENT', 'SERVICE_RESERVATION_DOES_NOT_ESTABLISH_SERVICE_FULFILLMENT', 'SETTLED', 'SIGNATURE', 'SIGNATURE_ENCODING', 'SINGLE_EXACT_ASSET_NO_FX', 'SIZE_LIMIT', 'SPEC_NOT_SUPPORTED_BY_INSTALLED_INTERFACES', 'TERM_CREDIT', 'THIS_ADOPTED_POSTED_FEE_SCHEDULE_WHEN_ITS_UNIT_IS_THE_TOKEN', 'TOKEN_CREDITS', 'TOKEN_CREDIT_UNKNOWN', 'TOKEN_POLICY', 'TOKEN_REDEMPTION_UNIT', 'TOKEN_SERVICE_INVENTORY', 'TRANSFER', 'TYPE', 'UNAVAILABLE', 'UNKNOWN', 'UNRECONCILED', 'UNSECURED', 'UNSECURED_NO_AUTOMATIC_RECOVERY', 'UNSECURED_OBLIGATION', 'UNSUPPORTED_OR_REFUSED', 'UNSUPPORTED_SIGNATURE_SUITE', 'UPDATE', 'WORKFLOW_DEPENDENCIES', 'WORKFLOW_DUPLICATE_DEPENDENCY', 'WORKFLOW_EFFECT_PROFILE', 'WORKFLOW_NOT_CONFIGURED', 'WORKFLOW_REQUEST_BINDING', 'WORKFLOW_RIGHT_KIND'])

_SAFE_ERRORS = _SAFE_ERRORS | frozenset({
    'COORDINATION_AUTHORIZATION_ACTION', 'COORDINATION_AUTHORIZATION_AGREEMENT',
    'COORDINATION_AUTHORIZATION_DISABLED', 'COORDINATION_AUTHORIZATION_DOMAIN',
    'COORDINATION_AUTHORIZATION_DOMAIN_REQUIRED', 'COORDINATION_AUTHORIZATION_EFFECT',
    'COORDINATION_AUTHORIZATION_EFFECT_NOT_OBSERVED', 'COORDINATION_AUTHORIZATION_FEE_CAP',
    'COORDINATION_AUTHORIZATION_FIELDS', 'COORDINATION_AUTHORIZATION_INTENT',
    'COORDINATION_AUTHORIZATION_LABEL', 'COORDINATION_AUTHORIZATION_OPTIONS',
    'COORDINATION_AUTHORIZATION_PARTIES', 'COORDINATION_AUTHORIZATION_PAYMENT',
    'COORDINATION_AUTHORIZATION_SCOPE', 'COORDINATION_AUTHORIZATION_SCOPE_PROFILE',
    'COORDINATION_AUTHORIZATION_SCOPES', 'COORDINATION_AUTHORIZATION_SIGNATURE',
    'COORDINATION_AUTHORIZATION_UNSUPPORTED_OWNER'})

_AUTHORIZATION_LABEL = 'COVENANT-TRIAL-PAYMENT-AUTHORIZATION-0.2'
_AUTHORIZATION_ITEM_FIELDS = frozenset({
    'authorization', 'authorization_agreement', 'expected_authorization_domain'})


def _error(error):
    value = str(error)
    return value if value in _SAFE_ERRORS else "COORDINATION_FINANCE_CHECK_FAILED"


def _copy(value):
    canonical(value)  # bounded, strictly typed JSON before copying
    return deepcopy(value)


def _text(value):
    need(type(value) is str and 0 < len(value.encode('utf-8')) <= 256,
         'COORDINATION_FINANCE_TEXT')


def _total(values):
    result = sum(values)
    integer(result)
    return result


def _signed(value):
    need(type(value) is int and abs(value) <= MAX, 'COORDINATION_BALANCE_OVERFLOW')
    return value


def _base():
    return {'version': VERSION, 'execution_authorized': False,
            'trust_boundary': 'OWNER_INSTALLED_CODE_AND_LOCAL_CUSTODY; NO_GLOBAL_FRESHNESS_OR_EXTERNAL_SETTLEMENT_INFERRED'}


def _owner(tools, ref):
    key(ref)
    workflow = getattr(tools, 'workflow', None)
    registry = getattr(tools, 'adapters', None) or getattr(workflow, 'adapters', None)
    if registry is None:
        return None, None, 'WORKFLOW_NOT_CONFIGURED'
    try:
        owner = registry.get(ref)
        manifest = _copy(owner.manifest)
        need(manifest_id(manifest) == ref, 'ADAPTER_MANIFEST_CHANGED')
        return owner, manifest, None
    except Exception as exc:
        return None, None, _error(exc)


def _interfaces(owner):
    return {name: callable(getattr(owner, name, None)) for name in
            ('observe', 'preview', 'credit_assent', 'credit', 'snapshot', 'audit', 'assent_payload')}


def preflight(tools, adapter, spec=None, request=None):
    """Inspect installed capabilities and exact spec/request readiness before assent.

    A custom owner's read-only preview contract is a trust boundary, not remote
    code discovery. Malformed JSON is refused; an unavailable capability is
    reported so a future rail can still be adopted separately.
    """
    spec = _copy(spec)
    request = _copy(request)
    owner, manifest, error = _owner(tools, adapter)
    result = {**_base(), 'adapter': adapter, 'installed': owner is not None,
              'manifest': manifest, 'interfaces': _interfaces(owner),
              'readiness': 'UNAVAILABLE' if error else 'INSTALLED_NOT_EXECUTION_AUTHORITY',
              'constraints': [], 'warnings': [error] if error else [],
              'credit_preview': None, 'request_preview': None}
    if owner is None:
        return result
    if type(owner) is DemoPaymentRail:
        result['constraints'] = ['LOCAL_DISPOSABLE_CREDITS_ONLY', 'SINGLE_EXACT_ASSET_NO_FX',
                                 'CREDIT_UNSECURED_SINGLE_ASSET_ONLY',
                                 'EXACT_BOTH_PARTY_CREDIT_ASSENT_AND_SEPARATE_WORKFLOW_AUTHORITY',
                                 'FEES_ADDITIONAL_TO_PAYMENT_OR_DEBT_REPAYMENT']
    elif type(owner) is DemoEscrowDesk:
        result['constraints'] = ['LOCAL_DISPOSABLE_CUSTODY_ONLY',
                                 'ONE_WHOLE_RESERVE_ALLOCATION_PER_POLICY',
                                 'ALL_PARTICIPANTS_FUND_ASSENT_THEN_EXACT_PAYOUT_QUORUM',
                                 'NO_AUTOMATIC_DELIVERY_OR_DISPUTE_JUDGMENT']
    else:
        result['constraints'] = ['CUSTOM_OWNER_MANIFEST_AND_READ_ONLY_INTERFACES_ARE_TRUST_BOUNDARY',
                                 'GENERIC_MANIFEST_DOES_NOT_ESTABLISH_RECEIPT_NUMERIC_SEMANTICS']
    if spec is not None:
        info = market_blueprints.inspect(spec)
        result['spec_id'] = info['id']
        try:
            from .credit_preview import preview
            result['credit_preview'] = preview(owner, spec)
        except Exception as exc:
            result['warnings'].append(_error(exc))
            result['readiness'] = 'SPEC_NOT_SUPPORTED_BY_INSTALLED_INTERFACES'
    if request is not None:
        need(type(request) is dict, 'COORDINATION_REQUEST')
        if callable(getattr(owner, 'preview', None)):
            try:
                result['request_preview'] = _copy(owner.preview(request))
                need(result['request_preview'].get('execution_authorized') is False,
                     'COORDINATION_PREVIEW_AUTHORITY')
                if result['request_preview'].get('within_requested_fee_cap') is False:
                    result['warnings'].append('REQUEST_EXCEEDS_ADOPTED_FEE_CAP')
                    result['readiness'] = 'REQUEST_NOT_SUPPORTED_OR_READY'
                if result['request_preview'].get('sufficient_balance_at_local_read') is False:
                    result['warnings'].append('PAYER_FUNDS_NOT_READY_AT_LOCAL_READ')
                    result['readiness'] = 'REQUEST_NOT_SUPPORTED_OR_READY'
            except Exception as exc:
                result['warnings'].append(_error(exc))
                result['readiness'] = 'REQUEST_NOT_SUPPORTED_OR_READY'
        elif type(owner) is DemoEscrowDesk:
            raw = {key: value for key, value in request.items() if key != 'approvals'}
            try:
                result['request_preview'] = _copy(owner.assent_payload('0' * 64, raw))
                result['warnings'].append('ESCROW_PREVIEW_EFFECT_IS_A_PLACEHOLDER; ACTUAL_BOOKED_EFFECT_REQUIRES_NEW_EXACT_ASSENT')
            except Exception as exc:
                result['warnings'].append(_error(exc))
                result['readiness'] = 'REQUEST_NOT_SUPPORTED_OR_READY'
        else:
            result['warnings'].append('READ_ONLY_REQUEST_PREVIEW_NOT_INSTALLED')
    # The registry's exact manifest pin must still hold after owner callbacks.
    fresh, _, changed = _owner(tools, adapter)
    need(fresh is owner and changed is None, 'COORDINATION_ADAPTER_CHANGED')
    result['next_actions'] = ['ADOPT_EXACT_TERMS_AND_AUTHORITY_SEPARATELY',
                              'RECHECK_ACTUAL_BALANCE_AND_FEE_POLICY_BEFORE_EXECUTION']
    return result


def milestones(tools, name, payer, payee, asset, amounts, controllers, threshold,
               context, adapter, labels=None):
    """Prepare separate existing WHOLE_RESERVE escrow policies, not partial escrow.

    Every item has raw fund_request and execution_request_template (empty
    approvals). proposed_effect_id is a deterministic draft placeholder; workflow
    booking must derive its actual effect and fresh exact controller signatures.
    """
    inputs = _copy(dict(name=name, payer=payer, payee=payee, asset=asset, amounts=amounts,
                       controllers=controllers, threshold=threshold, context=context,
                       adapter=adapter, labels=labels))
    _text(name)
    for value in (payer, payee, context, adapter):
        key(value)
    need(payer != payee, 'COORDINATION_DISTINCT_PARTIES')
    market_blueprints.validate_asset(asset)
    need(type(amounts) is list and 1 <= len(amounts) <= 64, 'COORDINATION_MILESTONES')
    for amount in amounts:
        integer(amount, True)
    total = _total(amounts)
    need(type(controllers) is list and 2 <= len(controllers) <= 8,
         'COORDINATION_CONTROLLERS')
    for controller in controllers:
        key(controller)
    need(len(set(controllers)) == len(controllers), 'COORDINATION_CONTROLLERS')
    integer(threshold, True)
    need(2 <= threshold <= len(controllers) and payer in controllers and payee in controllers,
         'COORDINATION_EXPLICIT_QUORUM')
    if labels is None:
        labels = [f'Milestone {index + 1}' for index in range(len(amounts))]
    need(type(labels) is list and len(labels) == len(amounts), 'COORDINATION_MILESTONE_LABELS')
    for label in labels:
        _text(label)
    owner, manifest, error = _owner(tools, adapter)
    need(owner is not None, error or 'ADAPTER_NOT_INSTALLED')
    need(manifest.get('capability') == 'payment.escrow', 'ESCROW_ADAPTER_UNSUPPORTED')
    need(asset['adapter'] == adapter, 'COORDINATION_ASSET_ADAPTER')
    rows = []
    for index, (amount, label) in enumerate(zip(amounts, labels)):
        policy_name = f'{name}: {index + 1}. {label}'
        _text(policy_name)
        policy = marketplace.escrow_policy(policy_name, payer, asset, amount, payer, payee,
            controllers, threshold, context, release={'mode': 'EXACT_QUORUM'},
            refund={'mode': 'EXACT_QUORUM'}, connector=adapter)['record']
        raw = {'action': 'FUND', 'policy': policy}
        effect = hashlib.sha256(b'COVENANT-MILESTONE-DRAFT-EFFECT-0.1\0' +
            canonical({'input': inputs, 'index': index})).hexdigest()
        assent = None
        if callable(getattr(owner, 'assent_payload', None)):
            assent = _copy(owner.assent_payload(effect, raw))
            need(assent.get('execution_authorized') is False and
                 canonical(assent.get('request')) == canonical(raw),
                 'COORDINATION_ESCROW_ASSENT_INTERFACE')
        rows.append({'index': index, 'label': label, 'amount': amount,
                     'policy_id': marketplace.identifier(policy), 'policy': policy,
                     'fund_request': raw, 'execution_request_template': {**raw, 'approvals': []},
                     'proposed_effect_id': effect, 'draft_assent_preview': assent,
                     'reserve_semantics': 'ONE_COMPLETE_ALLOCATION_OF_THIS_POLICY_RESERVE'})
    fresh, _, changed = _owner(tools, adapter)
    need(fresh is owner and changed is None, 'COORDINATION_ADAPTER_CHANGED')
    body = {'name': name, 'context': context, 'adapter': adapter, 'milestones': rows}
    return {**_base(), **body,
            'id': hashlib.sha256(b'COVENANT-MILESTONE-BUNDLE-0.1\0' + canonical(body)).hexdigest(),
            'manifest': manifest, 'total': total, 'unit': asset['unit'],
            'funding': 'NOT_RESERVED', 'signatures_created': False,
            'cross_policy_atomicity': 'NOT_ESTABLISHED',
            'warnings': ['DRAFT_EFFECT_IDS_ARE_NOT_BOOKED_WORKFLOW_EFFECT_IDS',
                         'EACH_POLICY_NEEDS_ITS_OWN_ALL_PARTICIPANT_FUND_ASSENT_AND_PAYOUT_QUORUM'],
            'next_actions': ['BOOK_EACH_POLICY_WITH_ADOPTED_EXECUTION_AUTHORITY',
                             'SIGN_EXACT_ACTUAL_EFFECT_IDS; DO_NOT_REUSE_DRAFT_SIGNATURES']}


def _rail_snapshot(owner, actor):
    with owner.store.exclusive():
        owner.db.execute('BEGIN')
        try:
            # Read only the requested actor rather than copying an unbounded
            # future account/receipt table into a review or implying a rail head.
            row = owner.db.execute('SELECT amount FROM rail_balances WHERE account=?', (actor,)).fetchone()
            balance = row[0] if row else 0
            integer(balance)
            count = owner.db.execute('SELECT count(*) FROM rail_receipts').fetchone()[0]
            integer(count)
            pin = hashlib.sha256(canonical({'actor': actor, 'balance': balance,
                                           'unit': owner.unit, 'receipt_count': count})).hexdigest()
            owner.db.execute('COMMIT')
        except BaseException:
            owner.db.execute('ROLLBACK')
            raise
    return {'balances': {actor: balance}, 'snapshot_hash': pin, 'receipt_count': count,
            'scope': 'SINGLE_ACTOR_BALANCE_AND_RECEIPT_COUNT_AT_A_LOCAL_READ; NOT_A_RAIL_AUDIT_HEAD',
            'source': 'LOCAL_OWNER_SQLITE_READ; NO_PAYMENT_RAIL_HASH_CHAIN_OR_GLOBAL_FRESHNESS'}


def _request_shape(request):
    need(type(request) is dict, 'COORDINATION_REQUEST')
    fields = {'TRANSFER': {'action', 'payer', 'recipient', 'unit', 'amount', 'maximum_fee'},
              'REDEEM_CREDIT': {'action', 'payer', 'unit', 'service', 'units', 'maximum_fee'},
              'OPEN_CREDIT': {'action', 'payer', 'unit', 'spec', 'approvals', 'maximum_fee'},
              'REPAY_CREDIT': {'action', 'payer', 'unit', 'loan', 'amount', 'maximum_fee'}}
    need(request.get('action') in fields and set(request) == fields[request['action']],
         'COORDINATION_REQUEST_FIELDS')
    key(request['payer'])
    integer(request['maximum_fee'])


def cashflow(tools, adapter, actor, requests, expected_balance=None):
    """Preview fee-inclusive ordered requests without treating plans as funds.

    projected_balance_if_all_succeed is a hypothetical scenario. Conservative
    availability starts with an actual supported snapshot and subtracts planned
    outflows; planned incoming transfers/credit never increase available funds.
    expected_balance is an optional equality pin, never a replacement snapshot.
    """
    requests = _copy(requests)
    key(actor)
    need(type(requests) is list and len(requests) <= MAX_ITEMS, 'COORDINATION_REQUESTS')
    if expected_balance is not None:
        integer(expected_balance)
    owner, manifest, error = _owner(tools, adapter)
    result = {**_base(), 'adapter': adapter, 'actor': actor, 'manifest': manifest,
              'starting_balance': None, 'expected_balance': expected_balance,
              'expected_balance_matches': None, 'snapshot': None, 'requests': [],
              'warnings': ([error] if error else []) + ['COST_PREVIEW_DOES_NOT_VERIFY_APPROVALS_OR_GRANT_AUTHORITY'],
              'balance_model': 'HYPOTHETICAL_ORDERED_REQUESTS; PLANNED_INFLOWS_ARE_NOT_OBSERVED_FUNDS'}
    if type(owner) is not DemoPaymentRail:
        result['warnings'].append('NUMERIC_CASHFLOW_NOT_IMPLEMENTED_FOR_THIS_OWNER_INTERFACE')
        result['next_actions'] = ['ADOPT_A_SUPPORTED_READ_ONLY_BALANCE_AND_FEE_INTERFACE']
        return result
    validate_fees(owner.policy)
    need(owner.manifest['requirements'].get('fee_policy') ==
         hashlib.sha256(b'COVENANT-NETWORK-FEE-0.1\0' + canonical(owner.policy)).hexdigest(),
         'COORDINATION_FEE_POLICY_PIN')
    snapshot = _rail_snapshot(owner, actor)
    start = snapshot['balances'].get(actor, 0)
    result.update(starting_balance=start, snapshot=snapshot,
                  expected_balance_matches=None if expected_balance is None else start == expected_balance)
    if expected_balance is not None and start != expected_balance:
        result['warnings'].append('EXPECTED_BALANCE_DIFFERS_FROM_OBSERVED_START')
    scenario, conservative = start, start
    debt_plans, inventory_plans = {}, {}
    for index, request in enumerate(requests):
        _request_shape(request)
        row = {'index': index, 'request_hash': hashlib.sha256(canonical(request)).hexdigest(),
               'action': request['action'], 'preview': None, 'warnings': [],
               'observed_funding_or_receipt': False, 'status': 'UNKNOWN'}
        try:
            preview = owner.preview(request)
            canonical(preview)
            amount, fee = preview['amount'], preview['network_fee']['amount']
            integer(amount, True)
            integer(fee)
            total = _total([amount, fee])
            action = request['action']
            recipient = (request['recipient'] if action == 'TRANSFER' else
                         request['spec']['rules']['borrower'] if action == 'OPEN_CREDIT' else
                         owner.credit(request['loan'])['spec']['rules']['lender'] if action == 'REPAY_CREDIT' else
                         owner.policy['beneficiary'])
            if action == 'REPAY_CREDIT':
                remaining = debt_plans.get(request['loan'], preview['remaining_debt'])
                need(amount <= remaining, 'COORDINATION_PLANNED_CREDIT_OVERPAYMENT')
                debt_plans[request['loan']] = remaining - amount
            if action == 'REDEEM_CREDIT':
                service = request['service']
                remaining = inventory_plans.get(service, preview['service_inventory_at_local_read'])
                need(request['units'] <= remaining, 'COORDINATION_PLANNED_INVENTORY_SHORTFALL')
                inventory_plans[service] = remaining - request['units']
            outflow = total if request['payer'] == actor else 0
            inflow = _total([amount if recipient == actor else 0,
                             fee if owner.policy['beneficiary'] == actor else 0])
            before_conservative = conservative
            scenario = _signed(scenario + inflow - outflow)
            conservative = _signed(conservative - outflow)
            row.update(preview=preview, actor_outflow=outflow, hypothetical_actor_inflow=inflow,
                       projected_balance_if_all_succeed=scenario,
                       conservative_available_after_planned_outflows=conservative,
                       affordable_from_observed_start_before_this_request=before_conservative >= outflow,
                       within_fee_cap=preview['within_requested_fee_cap'], status='HYPOTHETICAL_PREVIEW')
            if inflow:
                row['warnings'].append('PLANNED_INCOMING_VALUE_NOT_COUNTED_AS_OBSERVED_FUNDS')
            if before_conservative < outflow:
                row['warnings'].append('INSUFFICIENT_OBSERVED_STARTING_FUNDS_FOR_ORDERED_OUTFLOWS')
            if not preview['within_requested_fee_cap']:
                row['warnings'].append('REQUEST_EXCEEDS_ADOPTED_FEE_CAP')
            if not preview['sufficient_balance_at_local_read']:
                row['warnings'].append('PAYER_FUNDS_NOT_READY_AT_LOCAL_READ')
        except Exception as exc:
            row['warnings'].append(_error(exc))
            row['status'] = 'UNSUPPORTED_OR_REFUSED'
            # Later affordability cannot safely ignore an unknown earlier outflow.
            row['projected_balance_if_all_succeed'] = None
            row['conservative_available_after_planned_outflows'] = None
            result['requests'].append(row)
            for later_index in range(index + 1, len(requests)):
                result['requests'].append({'index': later_index, 'status': 'NOT_PREVIEWED_AFTER_UNRESOLVED_REQUEST',
                                           'warnings': ['EARLIER_REQUEST_REQUIRES_RESOLUTION']})
            break
        result['requests'].append(row)
    result['next_actions'] = ['RESOLVE_UNSUPPORTED_REQUESTS_AND_FUNDING_GAPS',
                              'RECHECK_LIVE_BALANCE_DEBT_INVENTORY_AND_EXACT_APPROVALS_BEFORE_EXECUTION']
    fresh, _, changed = _owner(tools, adapter)
    need(fresh is owner and changed is None, 'COORDINATION_ADAPTER_CHANGED')
    return result


def _escrow_facts(owner, effect, expected_head=None):
    with owner.store.exclusive():
        owner.db.execute('BEGIN')
        try:
            audit = owner._audit(expected_head)
            found = None
            for encoded, in owner.db.execute('SELECT entry FROM escrow_journal ORDER BY sequence'):
                entry = json.loads(encoded)
                if entry['effect'] == effect:
                    found = entry
                    break
            need(found is not None, 'COORDINATION_ESCROW_JOURNAL_EFFECT')
            escrow = found['receipt']['escrow']
            row = owner.db.execute('SELECT body,status FROM escrow_contracts WHERE id=?', (escrow,)).fetchone()
            need(row is not None, 'COORDINATION_ESCROW_POLICY')
            policy = json.loads(row[0])
            data = owner._policy(policy)
            need(marketplace.identifier(policy) == escrow, 'COORDINATION_ESCROW_POLICY_ID')
            owner.db.execute('COMMIT')
        except BaseException:
            owner.db.execute('ROLLBACK')
            raise
    return {'audit': audit, 'policy': policy, 'policy_id': escrow,
            'authorization': found['authorization'], 'receipt': found['receipt'],
            'payer': data['payer'], 'payee': data['payee'], 'asset': data['asset'],
            'context': data['context'], 'state': row[1]}


def _payment_authorization(item, receipt, agreement_ids, agreement_scopes, authorization_domain):
    """Verify the exact issued arena v0.2 authorization without changing a receipt.

    agreement_scopes is supplied only after the outer agreements were actually
    verified. A bare caller-provided hash or this helper alone is not evidence
    that an agreement was assented to. Supported scopes are the existing Frame
    Concept common assent body plus its verified root party map; other signing
    profiles are not silently normalized into this one.
    """
    need({'authorization', 'authorization_agreement'} <= set(item),
         'COORDINATION_AUTHORIZATION_FIELDS')
    proof = item['authorization']
    need(type(proof) is dict and set(proof) == {'label', 'body', 'signature'},
         'COORDINATION_AUTHORIZATION_FIELDS')
    need(proof['label'] == _AUTHORIZATION_LABEL, 'COORDINATION_AUTHORIZATION_LABEL')
    body = proof['body']
    need(type(body) is dict and set(body) == {'domain', 'agreement', 'closure', 'effect', 'payment', 'context'},
         'COORDINATION_AUTHORIZATION_FIELDS')
    for field in ('domain', 'agreement', 'closure', 'effect', 'context'):
        key(body[field])
    need(authorization_domain is not None, 'COORDINATION_AUTHORIZATION_DOMAIN_REQUIRED')
    key(authorization_domain)
    if 'expected_authorization_domain' in item:
        key(item['expected_authorization_domain'])
        need(item['expected_authorization_domain'] == authorization_domain,
             'COORDINATION_AUTHORIZATION_DOMAIN')
    need(body['domain'] == authorization_domain, 'COORDINATION_AUTHORIZATION_DOMAIN')
    key(item['authorization_agreement'])
    outer = item['authorization_agreement']
    need(outer in agreement_ids and type(agreement_scopes) is dict and outer in agreement_scopes,
         'COORDINATION_AUTHORIZATION_AGREEMENT')
    scope = agreement_scopes[outer]
    need(type(scope) is dict and set(scope) == {'root', 'closure', 'context', 'semantics', 'parties'},
         'COORDINATION_AUTHORIZATION_SCOPE_PROFILE')
    need(scope['semantics'] == frame_concepts.SEMANTICS, 'COORDINATION_AUTHORIZATION_SCOPE_PROFILE')
    for field in ('root', 'closure', 'context'):
        key(scope[field])
    need((body['agreement'], body['closure'], body['context']) ==
         (scope['root'], scope['closure'], scope['context']), 'COORDINATION_AUTHORIZATION_SCOPE')
    need(body['effect'] == item['effect_id'] == receipt['effect'], 'COORDINATION_AUTHORIZATION_EFFECT')
    payment = body['payment']
    need(type(payment) is dict and set(payment) == {'action', 'payer', 'recipient', 'unit', 'amount', 'maximum_fee'},
         'COORDINATION_AUTHORIZATION_PAYMENT')
    need(payment['action'] == receipt['action'] == 'TRANSFER', 'COORDINATION_AUTHORIZATION_ACTION')
    for field in ('payer', 'recipient'):
        key(payment[field])
    integer(payment['amount'], True)
    integer(payment['maximum_fee'])
    need(all(payment[field] == receipt[field] for field in ('payer', 'recipient', 'unit', 'amount')),
         'COORDINATION_AUTHORIZATION_PAYMENT')
    parties = scope['parties']
    need(type(parties) is dict and 2 <= len(parties) <= 64, 'COORDINATION_AUTHORIZATION_PARTIES')
    for role in parties:
        _text(role)
    identities = {canonical(value) for value in parties.values()}
    need(len(identities) >= 2 and payment['payer'] != payment['recipient'] and
         canonical(payment['payer']) in identities and canonical(payment['recipient']) in identities,
         'COORDINATION_AUTHORIZATION_PARTIES')
    need(receipt['network_fee']['amount'] <= payment['maximum_fee'], 'COORDINATION_AUTHORIZATION_FEE_CAP')
    need(digest('COVENANT-PAYMENT-INTENT-0.1', payment) == receipt['intent'],
         'COORDINATION_AUTHORIZATION_INTENT')
    try:
        verify(payment['payer'], proof['label'], body, proof['signature'])
    except (ValueError, KeyError, TypeError):
        raise ValueError('COORDINATION_AUTHORIZATION_SIGNATURE') from None
    return {'status': 'PAYER_SIGNATURE_AND_EXACT_SCOPE_BINDING_VERIFIED',
            'authorization_hash': hashlib.sha256(canonical(proof)).hexdigest(),
            'label': _AUTHORIZATION_LABEL, 'authorization_agreement': outer,
            'signed_agreement': body['agreement'], 'signed_closure': body['closure'],
            'domain': body['domain'], 'binding_context': body['context'],
            'payer': payment['payer'], 'payee': payment['recipient'],
            'effect_id': body['effect'], 'payment_intent': receipt['intent'],
            'maximum_fee': payment['maximum_fee'],
            'binding_source': 'EXPLICIT_PAYER_SIGNED_AUTHORIZATION_V0_2; NOT_A_NATIVE_RECEIPT_FIELD',
            'scope_allowlist_basis': 'SUPPLIED_VERIFIED_OUTER_AGREEMENT_ROOT_CLOSURE_CONTEXT_AND_ROOT_PARTIES',
            'native_receipt_context': None, 'native_receipt_context_status': 'ABSENT_FROM_EXISTING_NATIVE_RECEIPT_PROFILE',
            'native_receipt_changed': False, 'execution_authorized': False}


def payments(tools, items, obligations, agreement_ids, allow_authorizations=False,
             agreement_scopes=None, authorization_domain=None):
    """Join caller-declared obligations to exact read-only owner observations.

    Reductions are only within this explicitly supplied observation scope. An
    unknown rail, wrong identity/unit/context, or unavailable observation makes
    that obligation's numeric remainder unknown rather than settled/zero debt.

    With explicit allow_authorizations=True, a row may additionally carry
    authorization={label,body,signature}, authorization_agreement (a VERIFIED
    outer agreement ID), and optional expected_authorization_domain. The
    independently supplied agreement_scopes map and authorization_domain are
    required for that binding; no native receipt gains a context field.
    """
    need(type(allow_authorizations) is bool, 'COORDINATION_AUTHORIZATION_OPTIONS')
    if allow_authorizations and agreement_scopes is not None:
        agreement_scopes = _copy(agreement_scopes)
        need(type(agreement_scopes) is dict and len(agreement_scopes) <= MAX_ITEMS,
             'COORDINATION_AUTHORIZATION_SCOPES')
    items, obligations, agreement_ids = _copy([items, obligations, agreement_ids])
    need(type(items) is list and len(items) <= MAX_ITEMS and type(obligations) is list and
         len(obligations) <= MAX_ITEMS and type(agreement_ids) is list and
         len(agreement_ids) <= MAX_ITEMS, 'COORDINATION_REVIEW_SCOPE')
    for identifier in agreement_ids:
        key(identifier)
    need(len(agreement_ids) == len(set(agreement_ids)), 'COORDINATION_DUPLICATE_AGREEMENT')
    declared = {}
    for obligation in obligations:
        need(type(obligation) is dict and {'id', 'agreement', 'payer', 'payee', 'asset', 'amount'} <= set(obligation)
             and set(obligation) <= {'id', 'agreement', 'payer', 'payee', 'asset', 'amount', 'label', 'context'},
             'COORDINATION_OBLIGATION_FIELDS')
        _text(obligation['id'])
        need(obligation['id'] not in declared, 'COORDINATION_DUPLICATE_OBLIGATION')
        key(obligation['agreement'])
        need(obligation['agreement'] in agreement_ids, 'COORDINATION_UNVERIFIED_AGREEMENT')
        for field in ('payer', 'payee'):
            key(obligation[field])
        need(obligation['payer'] != obligation['payee'], 'COORDINATION_DISTINCT_PARTIES')
        market_blueprints.validate_asset(obligation['asset'])
        integer(obligation['amount'])
        if 'label' in obligation:
            _text(obligation['label'])
        if 'context' in obligation:
            key(obligation['context'])
        declared[obligation['id']] = {**obligation, 'basis': 'CALLER_DECLARED_BASIS',
            'agreement_allowlist_basis': 'SUPPLIED_BY_CALLER; HASH_ALONE_IS_NOT_ASSENT_VERIFICATION',
            'observed_paid_in_supplied_scope': 0, 'remaining_in_supplied_scope': obligation['amount'],
            'observation_items': [], 'warnings': [], 'unknown': False}
    seen_effects, seen_items, seen_receipts = set(), set(), {}
    observations, warnings = [], []
    for item in items:
        allowed = {'id', 'adapter', 'effect_id', 'obligation', 'expected_context', 'expected_head', 'expected_output_hash'}
        if allow_authorizations:
            allowed |= _AUTHORIZATION_ITEM_FIELDS
        need(type(item) is dict and {'id', 'adapter', 'effect_id'} <= set(item) and
             set(item) <= allowed,
             'COORDINATION_PAYMENT_ITEM_FIELDS')
        _text(item['id'])
        need(item['id'] not in seen_items, 'COORDINATION_DUPLICATE_PAYMENT_ITEM')
        seen_items.add(item['id'])
        for field in ('adapter', 'effect_id', 'expected_context', 'expected_head', 'expected_output_hash'):
            if field in item:
                key(item[field])
        pair = (item['adapter'], item['effect_id'])
        need(pair not in seen_effects, 'COORDINATION_DUPLICATE_EFFECT')
        seen_effects.add(pair)
        obligation = None
        if item.get('obligation') is not None:
            _text(item['obligation'])
            need(item['obligation'] in declared, 'COORDINATION_UNKNOWN_OBLIGATION')
            obligation = declared[item['obligation']]
            obligation['observation_items'].append(item['id'])
        owner, manifest, error = _owner(tools, item['adapter'])
        authorization_requested = bool(set(item) & _AUTHORIZATION_ITEM_FIELDS)
        public_item = {field: value for field, value in item.items() if field not in _AUTHORIZATION_ITEM_FIELDS}
        row = {**public_item, 'manifest': manifest, 'observed': None, 'source': 'OWNER_INSTALLED_ADAPTER_OBSERVE',
               'numeric_semantics': 'UNKNOWN', 'attributed_payment': None, 'warnings': [error] if error else []}
        if authorization_requested:
            row['authorization_review'] = {'status': 'NOT_VERIFIED', 'authorization_bytes': 'OMITTED_FROM_DEFAULT_REVIEW'}
            if 'authorization' in item:
                row['authorization_review']['authorization_hash'] = hashlib.sha256(canonical(item['authorization'])).hexdigest()
        if owner is None:
            if obligation is not None:
                obligation['unknown'] = True
            observations.append(row)
            continue
        try:
            if authorization_requested:
                need(allow_authorizations, 'COORDINATION_AUTHORIZATION_DISABLED')
                need({'authorization', 'authorization_agreement'} <= set(item),
                     'COORDINATION_AUTHORIZATION_FIELDS')
            observation = _copy(owner.observe(item['effect_id']))
            row['observed'] = observation
            need(type(observation) is dict and observation.get('status') in ('OBSERVED', 'NOT_OBSERVED'),
                 'COORDINATION_OBSERVATION_INTERFACE')
            if observation['status'] == 'NOT_OBSERVED':
                need(not authorization_requested, 'COORDINATION_AUTHORIZATION_EFFECT_NOT_OBSERVED')
                need(observation.get('output_hash') is None, 'COORDINATION_UNOBSERVED_HASH')
                need('expected_output_hash' not in item, 'COORDINATION_EXPECTED_OUTPUT_NOT_OBSERVED')
                if 'expected_head' in item:
                    need(type(owner) is DemoEscrowDesk, 'COORDINATION_HEAD_PIN_UNSUPPORTED')
                    row['audit'] = owner.audit(item['expected_head'])
                need('expected_context' not in item and
                     not (obligation is not None and 'context' in obligation),
                     'COORDINATION_PAYMENT_CONTEXT_NOT_ESTABLISHED')
                row['numeric_semantics'] = 'NO_RECEIPT_OBSERVED_FOR_THIS_EFFECT_AT_LOCAL_READ'
                row['warnings'].append('NOT_OBSERVED_DOES_NOT_ESTABLISH_GLOBAL_NONPAYMENT')
                if type(owner) not in (DemoPaymentRail, DemoEscrowDesk) and obligation is not None:
                    obligation['unknown'] = True
                observations.append(row)
                continue
            receipt = observation.get('value')
            need(type(receipt) is dict, 'COORDINATION_RECEIPT_VALUE')
            output_hash = observation.get('output_hash')
            key(output_hash)
            need(hashlib.sha256(canonical(receipt)).hexdigest() == output_hash,
                 'COORDINATION_RECEIPT_HASH')
            need(receipt.get('effect') == item['effect_id'], 'COORDINATION_RECEIPT_EFFECT')
            if 'expected_output_hash' in item:
                need(item['expected_output_hash'] == output_hash, 'COORDINATION_EXPECTED_OUTPUT_HASH')
            receipt_key = (item['adapter'], output_hash)
            need(receipt_key not in seen_receipts, 'COORDINATION_RECEIPT_REUSE')
            seen_receipts[receipt_key] = item['id']
            payer = payee = asset = context = None
            binding_context = None
            paid = None
            if type(owner) is DemoEscrowDesk:
                facts = _escrow_facts(owner, item['effect_id'], item.get('expected_head'))
                need(canonical(facts['receipt']) == canonical(receipt), 'COORDINATION_ESCROW_OBSERVATION_CHANGED')
                row.update(audit=facts['audit'], policy_id=facts['policy_id'], policy=facts['policy'],
                           observed_authorization=facts['authorization'], state=facts['state'])
                payer, payee, asset, context = (facts[field] for field in ('payer', 'payee', 'asset', 'context'))
                row['numeric_semantics'] = 'AUDITED_LOCAL_ESCROW_ALLOCATION'
                if receipt['action'] == 'PAYOUT':
                    paid = receipt['payouts'].get(payee, 0)
                    integer(paid)
                    row['payer_refund_not_counted'] = receipt['payouts'].get(payer, 0)
                else:
                    row['warnings'].append('ESCROW_FUNDING_IS_LOCKED_CUSTODY_NOT_PAYMENT_TO_PAYEE')
                    paid = 0
            elif type(owner) is DemoPaymentRail:
                need(set(receipt) == {'effect', 'intent', 'unit', 'amount', 'network_fee', 'payer', 'recipient', 'action',
                                      'loan', 'service_reservation', 'assurance'}, 'COORDINATION_PAYMENT_RECEIPT_FIELDS')
                need(receipt['unit'] == owner.unit, 'COORDINATION_PAYMENT_UNIT')
                need(receipt['action'] in ('TRANSFER', 'OPEN_CREDIT', 'REPAY_CREDIT', 'REDEEM_CREDIT'),
                     'COORDINATION_PAYMENT_ACTION')
                integer(receipt['amount'], True)
                key(receipt['intent'])
                need(receipt['assurance'] == 'LOCAL_DISPOSABLE_CREDIT_LEDGER_NOT_EXTERNAL_PAYMENT',
                     'COORDINATION_PAYMENT_ASSURANCE')
                payer, payee = receipt['payer'], receipt['recipient']
                key(payer)
                key(payee)
                asset = market_blueprints.asset('covenant-disposable', owner.unit, owner.unit, item['adapter'])
                paid = receipt['amount']
                need(canonical(receipt['network_fee']) == canonical(quote_fee(owner.policy, paid, owner.unit)),
                     'COORDINATION_PAYMENT_FEE')
                row['numeric_semantics'] = 'OWNER_OBSERVED_LOCAL_TRANSFER_WITHOUT_AGREEMENT_OR_CONTEXT_BINDING'
                row['network_fee_not_counted_as_payee_payment'] = receipt['network_fee']['amount']
                row['warnings'].append('PAYMENT_RAIL_HAS_NO_AUDITED_HASH_CHAIN; HOST_CUSTODY_IS_TRUSTED')
                if receipt['loan'] is not None:
                    key(receipt['loan'])
                    row['loan_snapshot'] = _copy(owner.credit(receipt['loan']))
                    info = market_blueprints.inspect(row['loan_snapshot']['spec'])
                    need(info['id'] == receipt['loan'], 'COORDINATION_CREDIT_SPEC_ID')
                    rules = info['spec']['rules']
                    need(receipt['action'] in ('OPEN_CREDIT', 'REPAY_CREDIT'), 'COORDINATION_CREDIT_ACTION')
                    if receipt['action'] == 'OPEN_CREDIT':
                        need(payer == rules['lender'] and payee == rules['borrower'] and
                             paid == rules['principal'], 'COORDINATION_CREDIT_ADVANCE')
                    else:
                        need(payer == rules['borrower'] and payee == rules['lender'] and
                             paid <= info['cashflows']['total_due'], 'COORDINATION_CREDIT_REPAYMENT')
                else:
                    need(receipt['action'] in ('TRANSFER', 'REDEEM_CREDIT'), 'COORDINATION_PAYMENT_LOAN_REQUIRED')
                if receipt['action'] == 'REDEEM_CREDIT':
                    reservation = receipt['service_reservation']
                    need(type(reservation) is dict and set(reservation) == {'service', 'units', 'fulfilled'} and
                         reservation['fulfilled'] is False, 'COORDINATION_SERVICE_RESERVATION')
                    integer(reservation['units'], True)
                    need(reservation['service'] in owner.policy['token']['credit_prices'] and
                         paid == _total([reservation['units'] * owner.policy['token']['credit_prices'][reservation['service']]]),
                         'COORDINATION_SERVICE_RESERVATION_PRICE')
                    row['warnings'].append('SERVICE_RESERVATION_DOES_NOT_ESTABLISH_SERVICE_FULFILLMENT')
                else:
                    need(receipt['service_reservation'] is None, 'COORDINATION_UNEXPECTED_SERVICE_RESERVATION')
            else:
                row['warnings'].append('CUSTOM_OWNER_RECEIPT_NUMERIC_SEMANTICS_NOT_ADOPTED_BY_THIS_REVIEW')
                if obligation is not None:
                    obligation['unknown'] = True
            if authorization_requested:
                need(type(owner) is DemoPaymentRail, 'COORDINATION_AUTHORIZATION_UNSUPPORTED_OWNER')
                binding = _payment_authorization(item, receipt, agreement_ids, agreement_scopes, authorization_domain)
                row['authorization_review'] = binding
                binding_context = binding['binding_context']
                row['binding_context'] = binding_context
                row['context_binding_source'] = binding['binding_source']
                row['native_receipt_context'] = None
                row['native_receipt_context_status'] = 'ABSENT_FROM_EXISTING_NATIVE_RECEIPT_PROFILE'
                row['numeric_semantics'] = 'OWNER_OBSERVED_TRANSFER_WITH_EXPLICIT_PAYER_SIGNED_SCOPE_BINDING'
            row.update(payer=payer, payee=payee, asset=asset, unit=asset['unit'] if asset else None,
                       context=context, observed_payee_amount=paid)
            if 'expected_head' in item and type(owner) is not DemoEscrowDesk:
                need(False, 'COORDINATION_HEAD_PIN_UNSUPPORTED')
            expected_context = item.get('expected_context', obligation.get('context') if obligation is not None else None)
            if 'expected_context' in item and obligation is not None and 'context' in obligation:
                need(item['expected_context'] == obligation['context'], 'COORDINATION_CONTEXT_CONFLICT')
            if expected_context is not None:
                checked_context = binding_context if binding_context is not None else context
                need(checked_context is not None and checked_context == expected_context, 'COORDINATION_PAYMENT_CONTEXT_NOT_ESTABLISHED')
            fresh, _, changed = _owner(tools, item['adapter'])
            need(fresh is owner and changed is None, 'COORDINATION_ADAPTER_CHANGED')
            if paid is not None and obligation is not None:
                need(obligation['payer'] == payer and obligation['payee'] == payee,
                     'COORDINATION_PAYMENT_PARTIES')
                need(canonical(obligation['asset']) == canonical(asset), 'COORDINATION_PAYMENT_ASSET')
                obligation['observed_paid_in_supplied_scope'] = _total([obligation['observed_paid_in_supplied_scope'], paid])
                row['attributed_payment'] = paid
                row['attribution_basis'] = ('CALLER_DECLARED_OBLIGATION_MAPPING; OWNER_OBSERVED_TRANSFER_AND_EXPLICIT_PAYER_SIGNED_SCOPE_BINDING'
                    if binding_context is not None else 'CALLER_DECLARED_OBLIGATION_MAPPING; OWNER_OBSERVED_AMOUNT_AND_PARTIES')
        except Exception as exc:
            code = _error(exc)
            row['warnings'].append(code)
            if authorization_requested and row['authorization_review']['status'] == 'NOT_VERIFIED':
                row['authorization_review'].update(status='REFUSED', code=code)
            row['numeric_semantics'] = 'UNRECONCILED'
            row['attributed_payment'] = None
            if obligation is not None:
                obligation['unknown'] = True
        observations.append(row)
    for obligation in declared.values():
        paid = obligation['observed_paid_in_supplied_scope']
        if paid > obligation['amount']:
            obligation['warnings'].append('OBSERVED_PAYMENTS_EXCEED_DECLARED_AMOUNT; NO_UNDECLARED_REFUND_INFERRED')
        obligation['remaining_in_supplied_scope'] = None if obligation['unknown'] else max(0, obligation['amount'] - paid)
        obligation['status'] = ('UNKNOWN' if obligation['unknown'] else 'DECLARED_ZERO' if obligation['amount'] == 0 else
                                'COVERED_WITHIN_SUPPLIED_SCOPE' if paid >= obligation['amount'] else
                                'REMAINS_WITHIN_SUPPLIED_SCOPE')
        obligation['global_debt_or_all_obligations'] = 'NOT_ESTABLISHED_BY_SELECTED_SCOPE'
    if any(row['warnings'] for row in observations):
        warnings.append('REVIEW_ITEM_WARNINGS_BEFORE_RELYING_ON_NUMERIC_REMAINDERS')
    return {**_base(), 'declared_obligations': list(declared.values()), 'observations': observations,
            'warnings': warnings, 'scope': 'ONLY_SUPPLIED_AGREEMENT_ALLOWLIST_OBLIGATIONS_AND_OWNER_OBSERVED_EFFECTS',
            'next_actions': ['RESOLVE_UNKNOWN_AUTHORITY_CONTEXT_ASSET_OR_OBSERVATION_LINKS',
                             'OBTAIN_EXACT_ASSENT_FOR_ANY_NEW_PAYMENT_OR_REMAINING_OBLIGATION']}
