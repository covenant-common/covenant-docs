"""Read-only developer planning facade; owner installation stays outside MCP."""
from covenant_language import developer_apps as a,developer_economics as e
from .cooperation_interface import HASH,INT,TEXT,OBJECT
from .developer_runtime import native_fee_policy,sponsor,prepare_application_effect
from .developer_sdk import scaffold


def spec():
    arr={'type':'array','maxItems':64};auth={'plan':OBJECT,'approvals':arr,'expected_id':HASH,'expected_controllers':{'type':'array','minItems':1,'maxItems':8}}
    return ('covenant_developer','Build portable signed applications, compose pinned parent/dependency layers, discover installed releases, price service calls and prepare exact assent and native settlement. COV discounts, developer revenue shares and scoped sponsor budgets are optional adopted terms. No code loading, signing, payment, installation or inherited rollup security.',True,[
      ('draft',{'name':TEXT,'release':TEXT,'publisher':HASH,'routes':OBJECT,'economics':HASH,'parent':HASH,'dependencies':arr,'security':OBJECT,'metadata':OBJECT,'supersedes':HASH},('name','release','publisher','routes','economics')),
      ('inspect',{'manifest':OBJECT},('manifest',)),('resolve',{'root':HASH,'manifests':arr},('root','manifests')),
      ('policy',{'name':TEXT,'resource':TEXT,'unit_price':INT,'shares':arr,'token_resource':TEXT,'token_discount_bps':INT},('name','resource','unit_price','shares')),
      ('quote',{'policy':OBJECT,'units':INT},('policy','units')),('installed_quote',{'application':HASH,'units':INT},('application','units')),
      ('scenario',{'plan':OBJECT},('plan',)),('service_model',{'plan':OBJECT},('plan',)),('scaffold',{'name':TEXT,'kind':{'enum':['application','connector']}},('name',)),
      ('native_fee_policy',{'resource':TEXT,'base_fee':INT,'per_kib':INT,'beneficiaries':arr,'governors':arr,'threshold':INT,'change_delay':INT,'work_fees':OBJECT,'market_profile':{'type':'boolean'}},('resource','base_fee','per_kib','beneficiaries','governors','threshold','change_delay')),
      ('sponsor',{'resource':TEXT,'budget':INT,'actors':arr,'operations':arr,'per_actor_cap':INT,'expiry':INT},('resource','budget','actors','operations','per_actor_cap','expiry')),
      ('grant_manifest',{'chain':HASH,'domain':HASH,'grants':{'type':'array','minItems':1,'maxItems':256,'items':OBJECT}},('chain','domain','grants')),
      ('installed',{},()),('export',{'application':HASH},('application',)),('prepare',{'application':HASH,'operation':TEXT,'arguments':{},'context':HASH,'controllers':{'type':'array','minItems':1,'maxItems':8},'units':INT,'request_salt':TEXT},('application','operation','arguments','context','controllers')),
      ('settlement',{'call':OBJECT,'payer':HASH},('call','payer')),
      ('prepare_effect',{**auth,'adapter':HASH,'step':TEXT,'binding':INT,'payload':OBJECT,'request_salt':TEXT,'evidence':OBJECT,'previous':OBJECT,'expected_previous':HASH},(*auth,'adapter','step','binding','payload','request_salt')),
      ('announcement',{'manifest':OBJECT},('manifest',))])


def call(exchange,action,parameters):
    if action in ('draft','inspect','resolve'):return getattr(a,action)(**parameters)
    if action=='policy':return e.draft(**parameters)
    if action in ('quote','scenario'):return getattr(e,action)(**parameters)
    if action=='service_model':
        from covenant_language.service_economics import evaluate
        return evaluate(**parameters)
    if action=='scaffold':return scaffold(**parameters)
    if action=='native_fee_policy':return native_fee_policy(**parameters)
    if action=='sponsor':return sponsor(**parameters)
    if action=='grant_manifest':
        from .economics import allocation_manifest
        return {**allocation_manifest(**parameters),'publication':'NOT_PUBLISHED; OPENINGS_CONTAIN_PRIVATE_GRANT_AMOUNTS_RECIPIENTS_AND_SALTS','funding':'NOT_RESERVED; NATIVE_REWARD_CREATE_MUST_FUND_ROOT_AMOUNT','execution_authorized':False}
    if action=='announcement':
        manifest=parameters['manifest'];ref=a.identifier(manifest)
        return {'target':{'kind':'application','id':ref},'title':manifest['name']+' '+manifest['release'],'description':'Publisher-declared application release; signature and owner installation are separate.','attributes':{'family':'application','publisher':manifest['publisher'],'economics':manifest['economics'],'installed':False,'security_inherited':False},'links':[{'kind':'application','id':r} for r in manifest['dependencies']+([] if manifest['parent'] is None else [manifest['parent']])],'publication':'NOT_PUBLISHED; USE_EXISTING_EXPLICIT_PUBLIC_OR_PRIVATE_RECORD_WORKFLOW','execution_authorized':False}
    a.need(exchange.applications is not None,'APPLICATION_OWNER_REGISTRY_REQUIRED');registry=exchange.applications
    if action=='installed':return registry.describe()
    if action=='installed_quote':return registry.quote(**parameters)
    if action in ('prepare','settlement','export'):return getattr(registry,action)(**parameters)
    if action=='prepare_effect':
        a.need(exchange.workflow is not None,'APPLICATION_WORKFLOW_REQUIRED');parameters=dict(parameters);ref=parameters.pop('adapter');adapter=exchange.workflow.adapters.get(ref)
        result=prepare_application_effect(registry,adapter,**parameters);result['adapter']=ref;return result
    raise ValueError('APPLICATION_ACTION')
