"""Frozen common-language 0.1 set, plus the written native version boundary.

The frozen files are the Python core, the JavaScript verifier, and the Rust
verifier. Conformance vectors stay in examples/common/. Native work past
covenant-native/0.14 is a new version string and a new module, not another
elif in the 0.1 kernel and not a comment that freezes app.py while ops are added.
"""
import json
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ROOT = Path(__file__).resolve().parents[1]
FROZEN_VERSION = 'covenant-common/0.1'
SIGNING = b'COVENANT-COMMON-SIGN-0.1\0'
OBJECT = b'COVENANT-COMMON-OBJECT-0.1\0'
NATIVE_BOUNDARY = 'covenant-native/0.14'
NATIVE_KERNEL = 'covenant-native/0.1'
BOUNDARY = ROOT / 'docs' / 'NATIVE_VERSION_BOUNDARY.md'
SOURCES = {
    'python': ROOT / 'covenant_language' / 'core.py',
    'javascript': ROOT / 'implementations' / 'js' / 'verify.mjs',
    'rust': ROOT / 'implementations' / 'rust' / 'common-verify' / 'src' / 'lib.rs',
}


def pins():
    from covenant_language.core import OBJECT as object_label
    from covenant_language.core import SIGNING as signing_label
    from covenant_language.core import VERSION
    javascript = SOURCES['javascript'].read_text(encoding='utf-8')
    rust = SOURCES['rust'].read_text(encoding='utf-8')
    return {
        'version': VERSION,
        'signing': signing_label.decode('ascii').rstrip('\0'),
        'object': object_label.decode('ascii').rstrip('\0'),
        'javascript_version': 'covenant-common/0.1' if "const V='covenant-common/0.1';" in javascript else '',
        'javascript_signing': 'COVENANT-COMMON-SIGN-0.1' if 'COVENANT-COMMON-SIGN-0.1' in javascript else '',
        'javascript_object': 'COVENANT-COMMON-OBJECT-0.1' if 'COVENANT-COMMON-OBJECT-0.1' in javascript else '',
        'rust_version': 'covenant-common/0.1' if 'const VERSION: &str = "covenant-common/0.1";' in rust else '',
        'rust_signing': 'COVENANT-COMMON-SIGN-0.1' if 'COVENANT-COMMON-SIGN-0.1' in rust else '',
        'native_boundary': NATIVE_BOUNDARY,
        'native_kernel': NATIVE_KERNEL,
        'conformance': 'examples/common/',
    }


def assert_frozen():
    found = pins()
    expected = {
        'version': FROZEN_VERSION,
        'signing': 'COVENANT-COMMON-SIGN-0.1',
        'object': 'COVENANT-COMMON-OBJECT-0.1',
        'javascript_version': FROZEN_VERSION,
        'javascript_signing': 'COVENANT-COMMON-SIGN-0.1',
        'javascript_object': 'COVENANT-COMMON-OBJECT-0.1',
        'rust_version': FROZEN_VERSION,
        'rust_signing': 'COVENANT-COMMON-SIGN-0.1',
        'native_boundary': NATIVE_BOUNDARY,
        'native_kernel': NATIVE_KERNEL,
        'conformance': 'examples/common/',
    }
    if found != expected:
        raise AssertionError(found)
    from covenant_chain.app import PREDICTION_VERSION, VERSION as native
    if PREDICTION_VERSION != NATIVE_BOUNDARY or native != NATIVE_KERNEL:
        raise AssertionError((native, PREDICTION_VERSION))
    kernel = (ROOT / 'covenant_chain' / 'app.py').read_text(encoding='utf-8')
    if 'covenant-native/0.15' in kernel:
        raise AssertionError('native version moved without a written boundary')
    text = BOUNDARY.read_text(encoding='utf-8')
    for phrase in (NATIVE_BOUNDARY, 'elif op==', 'covenant_language/core.py', 'verify.mjs', 'common-verify', 'examples/common/'):
        if phrase not in text:
            raise AssertionError(phrase)
    for name in ('vectors.json', 'bundle.json', 'named_objects.json', 'trust.json'):
        if not (ROOT / 'examples' / 'common' / name).is_file():
            raise AssertionError(name)
    return found


def historical_record():
    vectors = json.loads((ROOT / 'examples' / 'common' / 'vectors.json').read_text(encoding='utf-8'))
    trust = json.loads((ROOT / 'examples' / 'common' / 'trust.json').read_text(encoding='utf-8'))
    record = vectors[0]['bundle']['records'][0]
    return record, trust


def verify_common_signature(record, trust, label=SIGNING):
    """Byte check: the 0.1 label verifies. A renamed 1.0 label does not."""
    from covenant_language.core import canonical
    body = record['body']
    public = trust['keys'][body['actor']]
    Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(
        bytes.fromhex(record['signature']), label + canonical(body))
    return True
