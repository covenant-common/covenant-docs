"""Pluggable at-rest keys for host blobs (experimental).

Ported from PR 73 (WP-23). The seal, open and rotate shape follows the at-rest
KeyProvider interface of ymow/acp-server, Copyright (c) 2026 Ymow Wu, MIT; see
NOTICE. No ymow source is vendored.

LocalKeyProvider seals with AES-256-GCM under a host-held 32-byte key and keeps
the conventions of onboarding.seal_identity: a random 96-bit nonce stored with
the blob, hex fields, and canonical associated data. That associated data binds
the profile version, the cipher, the key id and the caller's context bytes, so a
relabelled blob fails to open (PR 73 authenticated only the caller's bytes).
KmsKeyProvider is an interface over an owner-injected client exposing
encrypt(key_id, plaintext, aad) and decrypt(key_id, token, aad). It builds no
client, URL or connection; the client owns credentials and timeouts, and the
tests use mocks only. rotate() re-seals under a successor provider.

Journal.save never calls this. storage.seal_host_blob is the host entry point.
"""
import hmac
import os
import re

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import parity_ids as ids
from .crypto import canonical, exact, need

LOCAL_CIPHER = 'AES-256-GCM'
KMS_CIPHER = 'KMS'
KEY_ID_LABEL = b'COVENANT-HOST-KEY-ID-0.1'
MAX_PLAINTEXT = 1_000_000
MAX_AAD = 4096
MAX_TOKEN = 2_000_000
HEX = re.compile(r'(?:[0-9a-f]{2})*\Z')


def _key(raw):
    need(type(raw) is bytes and len(raw) == 32, 'KEY_PROVIDER_KEY')
    return raw


def _key_id(value):
    need(type(value) is str and 0 < len(value) <= 128 and value.isascii() and value.isprintable(), 'KEY_PROVIDER_KEY_ID')
    return value


def _inputs(plaintext, aad):
    need(type(plaintext) is bytes and len(plaintext) <= MAX_PLAINTEXT, 'KEY_PROVIDER_PLAINTEXT')
    need(type(aad) is bytes and len(aad) <= MAX_AAD, 'KEY_PROVIDER_AAD')


def _bound(cipher, key_id, aad):
    """Associated data: version, cipher and key id travel with the caller's context bytes."""
    return canonical({'version': ids.KEY_PROVIDER_VERSION, 'cipher': cipher, 'key_id': key_id, 'aad': aad.hex()})


def _header(sealed, fields, cipher, key_id, aad):
    exact(sealed, fields)
    need(sealed['version'] == ids.KEY_PROVIDER_VERSION, 'KEY_PROVIDER_VERSION')
    need(sealed['cipher'] == cipher, 'KEY_PROVIDER_FORMAT')
    need(sealed['key_id'] == key_id, 'KEY_PROVIDER_KEY_ID')
    need(type(aad) is bytes and len(aad) <= MAX_AAD and sealed['aad'] == aad.hex(), 'KEY_PROVIDER_AAD')


def _successor(value, build):
    if callable(getattr(value, 'seal', None)):
        return value
    try:
        return build(value)
    except ValueError as exc:
        raise ValueError('KEY_PROVIDER_SUCCESSOR') from exc


class LocalKeyProvider:
    """AES-256-GCM under a 32-byte host key. The default key id is an HMAC of the key, never the key."""

    def __init__(self, key, *, key_id=None):
        self._key = _key(key)
        self.key_id = _key_id(key_id) if key_id is not None else hmac.new(self._key, KEY_ID_LABEL, 'sha256').hexdigest()
        self.version = ids.KEY_PROVIDER_VERSION

    def __repr__(self):
        return f'LocalKeyProvider(key_id={self.key_id!r})'

    def seal(self, plaintext, *, aad=b''):
        _inputs(plaintext, aad)
        nonce = os.urandom(12)
        ciphertext = AESGCM(self._key).encrypt(nonce, plaintext, _bound(LOCAL_CIPHER, self.key_id, aad))
        return {'version': self.version, 'cipher': LOCAL_CIPHER, 'key_id': self.key_id, 'nonce': nonce.hex(),
                'ciphertext': ciphertext.hex(), 'aad': aad.hex()}

    def open(self, sealed, *, aad=b''):
        _header(sealed, 'version cipher key_id nonce ciphertext aad', LOCAL_CIPHER, self.key_id, aad)
        nonce, raw = sealed['nonce'], sealed['ciphertext']
        need(type(nonce) is str and len(nonce) == 24 and HEX.fullmatch(nonce)
             and type(raw) is str and 32 <= len(raw) <= 2 * (MAX_PLAINTEXT + 16) and HEX.fullmatch(raw),
             'KEY_PROVIDER_FORMAT')
        try:
            return AESGCM(self._key).decrypt(bytes.fromhex(nonce), bytes.fromhex(raw), _bound(LOCAL_CIPHER, self.key_id, aad))
        except InvalidTag as exc:
            raise ValueError('KEY_PROVIDER_OPEN') from exc

    def rotate(self, successor, sealed, *, aad=b''):
        """Open under this key, then seal under ``successor``: a provider or 32 new key bytes."""
        target = _successor(successor, LocalKeyProvider)
        return target.seal(self.open(sealed, aad=aad), aad=aad)


class KmsKeyProvider:
    """Envelope sealing through an owner-injected KMS client. Opens no connection itself."""

    def __init__(self, client, *, key_id):
        need(callable(getattr(client, 'encrypt', None)) and callable(getattr(client, 'decrypt', None)),
             'KEY_PROVIDER_KMS')
        self.client = client
        self.key_id = _key_id(key_id)
        self.version = ids.KEY_PROVIDER_VERSION

    def __repr__(self):
        return f'KmsKeyProvider(key_id={self.key_id!r})'

    def seal(self, plaintext, *, aad=b''):
        _inputs(plaintext, aad)
        try:
            token = self.client.encrypt(self.key_id, plaintext, _bound(KMS_CIPHER, self.key_id, aad))
        except Exception as exc:
            # A failed or timed-out KMS call seals nothing; it is never reported as sealed.
            raise ValueError('KEY_PROVIDER_KMS') from exc
        need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.isascii(), 'KEY_PROVIDER_KMS_TOKEN')
        return {'version': self.version, 'cipher': KMS_CIPHER, 'key_id': self.key_id, 'token': token,
                'aad': aad.hex()}

    def open(self, sealed, *, aad=b''):
        _header(sealed, 'version cipher key_id token aad', KMS_CIPHER, self.key_id, aad)
        token = sealed['token']
        need(type(token) is str and 0 < len(token) <= MAX_TOKEN and token.isascii(), 'KEY_PROVIDER_KMS_TOKEN')
        try:
            plaintext = self.client.decrypt(self.key_id, token, _bound(KMS_CIPHER, self.key_id, aad))
        except Exception as exc:
            raise ValueError('KEY_PROVIDER_OPEN') from exc
        need(type(plaintext) is bytes and len(plaintext) <= MAX_PLAINTEXT, 'KEY_PROVIDER_OPEN')
        return plaintext

    def rotate(self, successor, sealed, *, aad=b''):
        """Open under this key id, then seal under ``successor``: a provider or a new KMS key id."""
        target = _successor(successor, lambda key_id: KmsKeyProvider(self.client, key_id=key_id))
        return target.seal(self.open(sealed, aad=aad), aad=aad)
