"""The escrow half of accountable privacy: the disclosure policy a principal consents to and the
issuer's sealed, split binding.

Matter (L0): canonical bytes, keys, AES-256-GCM with HKDF-SHA256 (RFC 5869) and the Shamir/Feldman
shares of secret_sharing. hidden_credentials embeds an escrow id in a /0.3 credential and a verifier
checks that the credential is accountable, both without the dispute ladder; ordering, witnessed
releases and disclosure stay in accountable_privacy, which re-exports everything here unchanged.
"""
import base64
from copy import deepcopy
import os

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .crypto import canonical, digest, integer, key, need, public_key, sign, verification_key, verify
from . import hidden_credentials as hc
from . import secret_sharing as sharing
from . import witness_journal as journals

POLICY_VERSION = 'covenant-disclosure-policy/0.1'
ESCROW_VERSION = 'covenant-disclosure-escrow/0.1'
BINDING_VERSION = 'covenant-disclosure-binding/0.1'
POLICY_LABEL = 'COVENANT-DISCLOSURE-POLICY-0.1'
ESCROW_LABEL = 'COVENANT-DISCLOSURE-ESCROW-0.1'
BINDING_KEY_INFO = b'AAP-DISCLOSURE-BINDING-KEY-0.1'
MODES = ('NEGOTIATION', 'OPTIMISTIC', 'JUDGMENT')
MAX_RETENTION = 20 * 365 * 86400

# The same words as accountable_privacy.REMEDIATION for the codes raised here.
REMEDIATION = {
    'DISCLOSURE_POLICY': 'Use the exact disclosure policy fields from describe().',
    'DISCLOSURE_AUTHORITIES': 'Name 2 to 16 authorities with distinct names, signing keys, sealing keys and journals.',
    'DISCLOSURE_THRESHOLD': 'Use a threshold k with 2 <= k <= the number of authorities.',
    'DISCLOSURE_ORDER_RULE': 'Allow ladder modes from NEGOTIATION, OPTIMISTIC and JUDGMENT, a minimum quorum of 1 or more and sorted judge keys.',
    'DISCLOSURE_RETENTION': 'Use a retention from 1 second to 20 years.',
    'DISCLOSURE_REQUEST': 'Escrow only a /0.3 request for one holder key that names this disclosure policy.',
    'DISCLOSURE_ESCROW': 'Use the escrow record exactly as the issuer signed it: policy, body and signature.',
    'DISCLOSURE_ESCROW_SIGNATURE': 'The escrow must be signed by the issuer key it names.',
    'DISCLOSURE_ESCROW_MISMATCH': 'The escrow is for another pseudonym, request, policy or issuer.',
    'DISCLOSURE_ESCROW_EXPIRED': 'The escrow is past its retention; authorities no longer open it.',
}


def remediation(code):
    return REMEDIATION.get(code, sharing.remediation(code))


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _unb64(text, maximum=65536):
    need(type(text) is str and 0 < len(text) <= maximum and all(c.isalnum() or c in '-_' for c in text), 'DISCLOSURE_ESCROW')
    try:
        raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    except ValueError:
        raise ValueError('DISCLOSURE_ESCROW') from None
    need(_b64(raw) == text, 'DISCLOSURE_ESCROW')
    return raw


def _authority(value):
    need(type(value) is dict and set(value) == {'name', 'signing_key', 'sealing_key', 'journal'}, 'DISCLOSURE_AUTHORITIES')
    need(type(value['name']) is str and 0 < len(value['name']) <= 128 and all(33 <= ord(c) <= 126 for c in value['name']),
         'DISCLOSURE_AUTHORITIES')
    need(type(value['signing_key']) is str, 'DISCLOSURE_AUTHORITIES')
    verification_key(value['signing_key'])
    sharing._holder(value['sealing_key'])
    return journals.validate_policy(value['journal'])


def policy(authorities, threshold, *, modes=('JUDGMENT',), minimum_quorum=1, judges=(), retention=7 * 365 * 86400):
    """A disclosure policy body: who can disclose, how many must act, and which ladder stages may order it."""
    body = {'version': POLICY_VERSION, 'authorities': deepcopy(list(authorities)), 'threshold': threshold,
            'order': {'modes': sorted(set(modes)), 'minimum_quorum': minimum_quorum, 'judges': sorted(judges)},
            'retention': retention}
    validate_policy(body)
    return body


def validate_policy(body):
    need(type(body) is dict and set(body) == {'version', 'authorities', 'threshold', 'order', 'retention'}, 'DISCLOSURE_POLICY')
    need(body['version'] == POLICY_VERSION, 'DISCLOSURE_POLICY')
    rows = body['authorities']
    need(type(rows) is list and 2 <= len(rows) <= sharing.MAX_HOLDERS, 'DISCLOSURE_AUTHORITIES')
    rules = [_authority(row) for row in rows]
    for field in ('name', 'signing_key', 'sealing_key'):
        need(len({row[field] for row in rows}) == len(rows), 'DISCLOSURE_AUTHORITIES')
    need(len({rule['origin'] for rule in rules}) == len(rows) and len({rule['log']['public'] for rule in rules}) == len(rows),
         'DISCLOSURE_AUTHORITIES')
    need(type(body['threshold']) is int and 2 <= body['threshold'] <= len(rows), 'DISCLOSURE_THRESHOLD')
    rule = body['order']
    need(type(rule) is dict and set(rule) == {'modes', 'minimum_quorum', 'judges'}, 'DISCLOSURE_ORDER_RULE')
    need(type(rule['modes']) is list and 1 <= len(rule['modes']) <= 3 and rule['modes'] == sorted(set(rule['modes']))
         and set(rule['modes']) <= set(MODES), 'DISCLOSURE_ORDER_RULE')
    need(type(rule['minimum_quorum']) is int and 1 <= rule['minimum_quorum'] <= 16, 'DISCLOSURE_ORDER_RULE')
    need(type(rule['judges']) is list and len(rule['judges']) <= 16 and rule['judges'] == sorted(set(rule['judges'])),
         'DISCLOSURE_ORDER_RULE')
    for judge in rule['judges']:
        verification_key(judge)
    need(type(body['retention']) is int and 0 < body['retention'] <= MAX_RETENTION, 'DISCLOSURE_RETENTION')
    canonical(body)
    return body


def policy_id(body):
    validate_policy(body)
    return digest(POLICY_LABEL, body)


def _request_id(request):
    return digest(hc.REQUEST_LABEL, request)


def _checked_request(request, signature, policy_hash):
    need(type(request) is dict and request.get('version') == hc.ATTRIBUTE_VERSION, 'DISCLOSURE_REQUEST')
    checked = hc.attribute_request(request.get('chain', ''), request.get('account', ''), request.get('holder_keys'),
                                   mode=request.get('mode'), scope=request.get('scope'), nonce=request.get('nonce', ''),
                                   disclosure=request.get('disclosure'))
    need(checked == request and request['disclosure'] == policy_hash and len(request['holder_keys']) == 1
         and request['mode'] == 'SCOPED', 'DISCLOSURE_REQUEST')
    verify(request['account'], hc.REQUEST_LABEL, request, signature)
    return request


def _aead_key(secret, context):
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=bytes.fromhex(context),
                info=BINDING_KEY_INFO).derive(secret.to_bytes(32, 'big'))


def _header(body):
    return canonical({name: value for name, value in body.items() if name != 'binding'})


def create_escrow(policy_body, request, signature, *, issuer_id, issuer_key, now):
    """Issuer side: seal the principal's signed request for its one holder key and split the key among authorities."""
    policy_hash = policy_id(policy_body)
    _checked_request(request, signature, policy_hash)
    need(type(issuer_id) is str and 0 < len(issuer_id) <= 256 and issuer_id.isascii(), 'DISCLOSURE_ESCROW')
    need(isinstance(issuer_key, Ed25519PrivateKey), 'DISCLOSURE_ESCROW_SIGNATURE')
    integer(now)
    context = os.urandom(32).hex()
    deal, secret = sharing.deal(policy_body['threshold'], [row['sealing_key'] for row in policy_body['authorities']],
                                context=context)
    body = {'version': ESCROW_VERSION, 'policy': policy_hash, 'issuer': issuer_id, 'issuer_key': public_key(issuer_key),
            'pseudonym': request['holder_keys'][0], 'request': _request_id(request), 'issued_at': now,
            'not_after': now + policy_body['retention'], 'deal': deal}
    plaintext = canonical({'version': BINDING_VERSION, 'request': deepcopy(request), 'signature': signature})
    nonce = os.urandom(12)
    sealed = AESGCM(_aead_key(secret, context)).encrypt(nonce, plaintext, _header(body))
    body['binding'] = {'nonce': _b64(nonce), 'ciphertext': _b64(sealed)}
    return {'policy': deepcopy(policy_body), 'body': body, 'signature': sign(issuer_key, ESCROW_LABEL, body)}


def open_escrow(record):
    """Structure, issuer signature and policy of a published escrow; the binding stays sealed."""
    need(type(record) is dict and set(record) == {'policy', 'body', 'signature'}, 'DISCLOSURE_ESCROW')
    body = record['body']
    need(type(body) is dict and set(body) == {'version', 'policy', 'issuer', 'issuer_key', 'pseudonym', 'request',
                                              'issued_at', 'not_after', 'deal', 'binding'}, 'DISCLOSURE_ESCROW')
    need(body['version'] == ESCROW_VERSION and body['policy'] == policy_id(record['policy']), 'DISCLOSURE_ESCROW')
    need(type(body['issuer']) is str and type(body['issuer_key']) is str, 'DISCLOSURE_ESCROW')
    verification_key(body['issuer_key']); verification_key(body['pseudonym']); key(body['request'])
    integer(body['issued_at']); integer(body['not_after'])
    need(body['issued_at'] < body['not_after'], 'DISCLOSURE_ESCROW')
    sharing.validate(body['deal'])
    need(body['deal']['threshold'] == record['policy']['threshold']
         and body['deal']['holders'] == [row['sealing_key'] for row in record['policy']['authorities']], 'DISCLOSURE_ESCROW')
    need(type(body['binding']) is dict and set(body['binding']) == {'nonce', 'ciphertext'}
         and len(_unb64(body['binding']['nonce'])) == 12, 'DISCLOSURE_ESCROW')
    _unb64(body['binding']['ciphertext'])
    try:
        verify(body['issuer_key'], ESCROW_LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('DISCLOSURE_ESCROW_SIGNATURE') from None
    return {'id': digest(ESCROW_LABEL, body), 'body': body, 'policy': record['policy']}


def escrow_for_credential(record, *, request, signature, holder, issuer_key):
    """The escrow id an issuer embeds as aap_escrow, after checking it seals this request for this holder."""
    opened = open_escrow(record)
    body = opened['body']
    _checked_request(request, signature, body['policy'])
    need(body['pseudonym'] == holder and body['request'] == _request_id(request) and body['issuer_key'] == issuer_key,
         'DISCLOSURE_ESCROW_MISMATCH')
    return opened['id']


def check_credential_escrow(record, presented, accepted_policies):
    """Verifier side: the presented /0.3 credential is accountable under one of the accepted policies."""
    opened = open_escrow(record)
    body = opened['body']
    need(type(presented) is dict and presented.get('escrow') == opened['id'], 'DISCLOSURE_ESCROW_MISMATCH')
    need(body['policy'] in accepted_policies, 'DISCLOSURE_ESCROW_MISMATCH')
    need(body['pseudonym'] == presented.get('holder') and body['issuer'] == presented.get('issuer')
         and body['issuer_key'] == presented.get('issuer_key'), 'DISCLOSURE_ESCROW_MISMATCH')
    need(type(presented.get('expires')) is int and body['not_after'] >= presented['expires'], 'DISCLOSURE_ESCROW_EXPIRED')
    return {'status': 'ACCOUNTABLE', 'escrow': opened['id'], 'policy': body['policy'],
            'authorities': [row['name'] for row in opened['policy']['authorities']],
            'threshold': opened['policy']['threshold'], 'order_modes': list(opened['policy']['order']['modes']),
            'not_after': body['not_after'], 'identity_revealed': False, 'execution_authorized': False}
