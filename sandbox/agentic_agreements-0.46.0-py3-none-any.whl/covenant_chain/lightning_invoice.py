"""BOLT 11 Lightning invoices for AAP hash-locked escrow. Maturity: experimental.

Implements BOLT #11 "Invoice Protocol for Lightning Payments" as published in
lightning/bolts (11-payment-encoding.md at 1914628, 19 October 2026, and the
test vectors in bolt11/invoice-test.json at e7291fa): bech32 without the
90-character limit (BIP 173), the human-readable prefix and amount
multipliers, the tagged fields p, s, d, h, n, x, c, m, f, r and 9, the
compact secp256k1 signature over SHA-256(hrp || data), payee recovery, the
low-s rule when n is present, BOLT #1 UTF-8 validation for d, and BOLT #9
feature parity (unknown even bits refuse; unknown odd bits are ignored).

An invoice is a statement by the payee's node key. It is evidence for an AAP
condition, never assent, payment or release. Nothing here contacts a node.
BOLT #12 offers are not implemented.
"""
import hashlib
import re
import unicodedata

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import Prehashed, decode_dss_signature, encode_dss_signature

from . import bitcoin_codec as btc
from . import evm_codec as evm
from .crypto import need

SPEC = 'BOLT #11 (lightning/bolts 11-payment-encoding.md, 1914628, 2026-10-19)'
CURRENCIES = ('bcrt', 'tbs', 'bc', 'tb')
UNITS = {'': 10 ** 11, 'm': 10 ** 8, 'u': 10 ** 5, 'n': 10 ** 2}
TAGS = {'p': 1, 's': 16, 'd': 13, 'm': 27, 'n': 19, 'h': 23, 'x': 6, 'c': 24, 'f': 9, 'r': 3, '9': 5}
NAMES = {value: name for name, value in TAGS.items()}
FIXED = {'p': 52, 's': 52, 'h': 52, 'n': 53}
# BOLT #9 features allowed in invoices (context 9) and the ASSUMED ones writers still set.
KNOWN_FEATURES = {8, 9, 14, 15, 16, 17, 24, 25, 36, 37, 48, 49}
DEFAULT_EXPIRY = 3600
DEFAULT_CLTV = 18
MAX_INVOICE = 8192
MAX_MSAT = 21 * 10 ** 17

REMEDIATION = {
    'BOLT11_ENCODING': 'Pass the invoice as one bech32 string (one case), with or without a lightning: prefix.',
    'BOLT11_PREFIX': 'Use an ln prefix with currency bc, tb, tbs or bcrt.',
    'BOLT11_AMOUNT': 'Encode the amount as a positive decimal with no leading zero and an optional m, u, n or p multiplier; p needs a final 0.',
    'BOLT11_FIELD': 'Each tagged field must fit the data; p, s and h are 52 words, n is 53, and x, c and 9 use the minimal length.',
    'BOLT11_REQUIRED': 'Include exactly one p, exactly one s, and exactly one of d or h.',
    'BOLT11_DESCRIPTION': 'The d field must be valid UTF-8 without control, format, private-use, surrogate or line/paragraph separator characters.',
    'BOLT11_FEATURE': 'The invoice requires an unknown even feature bit; do not pay it.',
    'BOLT11_SIGNATURE': 'The signature does not verify for the payee key (n requires low s). Ask the payee for a correctly signed invoice.',
    'BOLT11_KEY': 'Sign with the payee node secp256k1 key held by its owner.',
}


def remediation(code):
    return REMEDIATION.get(code, 'Check the invoice against BOLT #11.')


def _int(words):
    value = 0
    for word in words:
        value = value << 5 | word
    return value


def _words(value, minimum=1):
    out = []
    while value:
        out.append(value & 31)
        value >>= 5
    return list(reversed(out)) or [0] * minimum


def _bytes(words):
    try:
        return bytes(btc.convertbits(words, 5, 8, False))
    except ValueError:
        raise ValueError('BOLT11_FIELD') from None


def _amount(text):
    if text == '':
        return None
    found = re.fullmatch(r'([1-9][0-9]{0,19})([munp]?)', text)
    need(found is not None, 'BOLT11_AMOUNT')
    digits, unit = int(found.group(1)), found.group(2)
    if unit == 'p':
        need(digits % 10 == 0, 'BOLT11_AMOUNT')
        msat = digits // 10
    else:
        msat = digits * UNITS[unit]
    need(0 < msat <= MAX_MSAT, 'BOLT11_AMOUNT')
    return msat


def amount_text(msat):
    """The shortest amount, using the largest multiplier that keeps the number whole."""
    need(type(msat) is int and 0 < msat <= MAX_MSAT, 'BOLT11_AMOUNT')
    for unit in ('', 'm', 'u', 'n'):
        if msat % UNITS[unit] == 0:
            return str(msat // UNITS[unit]) + unit
    return str(msat * 10) + 'p'


def _prefix(hrp):
    need(hrp.startswith('ln'), 'BOLT11_PREFIX')
    for currency in CURRENCIES:
        rest = hrp[2 + len(currency):]
        if hrp[2:].startswith(currency) and (rest == '' or rest[0].isdigit()):
            return currency, _amount(rest)
    raise ValueError('BOLT11_PREFIX')


def _description(raw):
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        raise ValueError('BOLT11_DESCRIPTION') from None
    need(all(unicodedata.category(c) not in ('Cc', 'Cf', 'Cs', 'Co') and c not in '  ' for c in text),
         'BOLT11_DESCRIPTION')
    return text


def _minimal(words):
    need(words and words[0] != 0, 'BOLT11_FIELD')


def _field(name, words, out):
    if name in FIXED:
        need(len(words) == FIXED[name], 'BOLT11_FIELD')
        raw = _bytes(words)
        key = {'p': 'payment_hash', 's': 'payment_secret', 'h': 'description_hash', 'n': 'payee'}[name]
        out.setdefault(key, raw.hex())
    elif name == 'd':
        out.setdefault('description', _description(_bytes(words)))
    elif name in ('x', 'c'):
        _minimal(words)
        out.setdefault('expiry' if name == 'x' else 'min_final_cltv_expiry_delta', _int(words))
    elif name == '9':
        _minimal(words)
        bits = _int(words)
        unknown_even = [bit for bit in range(bits.bit_length()) if bits >> bit & 1 and bit % 2 == 0 and bit not in KNOWN_FEATURES]
        need(not unknown_even, 'BOLT11_FEATURE')
        out['features'] = sorted(bit for bit in range(bits.bit_length()) if bits >> bit & 1)
    elif name == 'm':
        out.setdefault('metadata', _bytes(words).hex())
    elif name == 'f':
        need(words, 'BOLT11_FIELD')
        if words[0] <= 18:  # unknown versions 19-31 are skipped
            out.setdefault('fallbacks', []).append({'version': words[0], 'program': _bytes(words[1:]).hex()})
    elif name == 'r':
        raw = _bytes(words)
        need(raw and len(raw) % 51 == 0, 'BOLT11_FIELD')
        out.setdefault('routes', []).append([{'pubkey': raw[i:i + 33].hex(), 'short_channel_id': raw[i + 33:i + 41].hex(),
                                              'fee_base_msat': int.from_bytes(raw[i + 41:i + 45], 'big'),
                                              'fee_proportional_millionths': int.from_bytes(raw[i + 45:i + 49], 'big'),
                                              'cltv_expiry_delta': int.from_bytes(raw[i + 49:i + 51], 'big')}
                                             for i in range(0, len(raw), 51)])


def decode(invoice):
    """Every BOLT 11 reader check; returns the verified fields and the payee node key."""
    need(type(invoice) is str and 0 < len(invoice) <= MAX_INVOICE, 'BOLT11_ENCODING')
    text = invoice[10:] if invoice.lower().startswith('lightning:') else invoice
    try:
        hrp, words, spec = btc.bech32_decode(text, None)
    except ValueError:
        raise ValueError('BOLT11_ENCODING') from None
    need(spec == btc.BECH32 and len(words) >= 7 + 104, 'BOLT11_ENCODING')
    currency, msat = _prefix(hrp)
    data, signature = words[:-104], _bytes(words[-104:])
    out = {'currency': currency, 'amount_msat': msat, 'timestamp': _int(data[:7])}
    fields, counts, at = [], {}, 7
    while at < len(data):
        need(at + 3 <= len(data), 'BOLT11_FIELD')
        kind, size = data[at], data[at + 1] << 5 | data[at + 2]
        payload = data[at + 3:at + 3 + size]
        need(len(payload) == size, 'BOLT11_FIELD')
        name = NAMES.get(kind)
        fields.append({'type': kind, 'words': payload})
        if name is not None:
            counts[name] = counts.get(name, 0) + 1
            _field(name, payload, out)
        at += 3 + size
    need(counts.get('p') == 1 and counts.get('s') == 1, 'BOLT11_REQUIRED')
    need((counts.get('d', 0), counts.get('h', 0)) in ((1, 0), (0, 1)), 'BOLT11_REQUIRED')
    digest = hashlib.sha256(hrp.encode('utf-8') + bytes(btc.convertbits(data, 5, 8, True))).digest()
    r, s, recovery = int.from_bytes(signature[:32], 'big'), int.from_bytes(signature[32:64], 'big'), signature[64]
    need(1 <= r < evm.N and 1 <= s < evm.N and recovery <= 3, 'BOLT11_SIGNATURE')
    if 'payee' in out:
        need(s <= evm.N // 2, 'BOLT11_SIGNATURE')
        try:
            key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256K1(), bytes.fromhex(out['payee']))
            key.verify(encode_dss_signature(r, s), digest, ec.ECDSA(Prehashed(hashes.SHA256())))
        except (InvalidSignature, ValueError):
            raise ValueError('BOLT11_SIGNATURE') from None
        signer = 'N_FIELD'
    else:
        try:
            out['payee'] = evm.compress(evm.recover_point(digest, recovery, r, s, low_s=False)).hex()
        except ValueError:
            raise ValueError('BOLT11_SIGNATURE') from None
        signer = 'RECOVERED'
    out.setdefault('expiry', DEFAULT_EXPIRY)
    out.setdefault('min_final_cltv_expiry_delta', DEFAULT_CLTV)
    out.setdefault('features', [])
    return {**out, 'hrp': hrp, 'fields': fields, 'signature': signature.hex(), 'signing_hash': digest.hex(),
            'payee_key_source': signer, 'expires_at': out['timestamp'] + out['expiry'], 'spec': SPEC,
            'payment_authorized': False, 'execution_authorized': False}


def field(name, value):
    """One tagged field {type, words} from a typed value: hex for p/s/h/n/m, text for d, int for x/c, bit list for 9."""
    need(name in TAGS and name not in ('f', 'r'), 'BOLT11_FIELD')
    if name in FIXED or name == 'm':
        need(type(value) is str and re.fullmatch(r'(?:[0-9a-f]{2})+', value) is not None, 'BOLT11_FIELD')
        raw = bytes.fromhex(value)
        need(name not in FIXED or len(raw) == (33 if name == 'n' else 32), 'BOLT11_FIELD')
        words = btc.convertbits(raw, 8, 5, True)
    elif name == 'd':
        need(type(value) is str, 'BOLT11_DESCRIPTION')
        _description(value.encode('utf-8'))
        words = btc.convertbits(value.encode('utf-8'), 8, 5, True)
    elif name in ('x', 'c'):
        need(type(value) is int and 0 < value < 2 ** 40, 'BOLT11_FIELD')
        words = _words(value)
    else:
        need(type(value) is list and value and all(type(bit) is int and 0 <= bit < 5 * 1023 for bit in value), 'BOLT11_FIELD')
        words = _words(sum(1 << bit for bit in set(value)))
    need(len(words) < 1024, 'BOLT11_FIELD')
    return {'type': TAGS[name], 'words': words}


def encode(currency, amount_msat, timestamp, fields, private_key):
    """Owner action for a payee's node key: a signed invoice (RFC 6979, low s) over the given ordered fields."""
    need(currency in CURRENCIES and type(timestamp) is int and 0 <= timestamp < 2 ** 35, 'BOLT11_PREFIX')
    need(isinstance(private_key, ec.EllipticCurvePrivateKey) and private_key.curve.name == 'secp256k1', 'BOLT11_KEY')
    hrp = 'ln' + currency + ('' if amount_msat is None else amount_text(amount_msat))
    data = [0] * (7 - len(_words(timestamp))) + _words(timestamp)
    for row in fields:
        need(type(row) is dict and set(row) == {'type', 'words'} and type(row['type']) is int and 0 <= row['type'] < 32
             and type(row['words']) is list and len(row['words']) < 1024
             and all(type(w) is int and 0 <= w < 32 for w in row['words']), 'BOLT11_FIELD')
        data += [row['type'], len(row['words']) >> 5, len(row['words']) & 31] + row['words']
    digest = hashlib.sha256(hrp.encode('utf-8') + bytes(btc.convertbits(data, 5, 8, True))).digest()
    r, s = decode_dss_signature(private_key.sign(digest, ec.ECDSA(Prehashed(hashes.SHA256()), deterministic_signing=True)))
    if s > evm.N // 2:
        s = evm.N - s
    payee = btc.public_bytes(private_key)
    recovery = next(rid for rid in range(4) if _recovers(digest, rid, r, s, payee))
    signature = r.to_bytes(32, 'big') + s.to_bytes(32, 'big') + bytes([recovery])
    invoice = btc.bech32_encode(hrp, data + btc.convertbits(signature, 8, 5, True))
    decode(invoice)
    return invoice


def _recovers(digest, recovery, r, s, payee):
    try:
        return evm.compress(evm.recover_point(digest, recovery, r, s, low_s=False)) == payee
    except ValueError:
        return False


def describe():
    return {'spec': SPEC, 'fields': sorted(TAGS), 'known_features': sorted(KNOWN_FEATURES),
            'defaults': {'expiry': DEFAULT_EXPIRY, 'min_final_cltv_expiry_delta': DEFAULT_CLTV},
            'bolt12': 'NOT_IMPLEMENTED', 'network_contacted': False, 'payment_authorized': False,
            'execution_authorized': False}
