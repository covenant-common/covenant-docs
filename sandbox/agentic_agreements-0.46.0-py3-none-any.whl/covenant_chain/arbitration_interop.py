"""Map AAP dispute ladders to and from the Agentic Arbitration Protocol.

GRAFT through ``agentic_arbitration``. Both disputants sign interop terms
(``urn:aap:arbitration-interop:0.1``) naming the ladder stage an external
award may inform: a JUDGMENT or OPTIMISTIC stage of an adopted escalation
procedure, or the PRIMARY or APPEAL phase of a chain panel. The terms also
fix the resolution method, the pinned arbitrator and service keys, how AAP
integer amounts map to decimal values, and an explicit table from external
decisions (outcome, liability) to AAP results. Nothing is inferred from prose.

Outbound, a replayed procedure or settled panel becomes DisputeFiling,
DisputeResponse, EvidenceSubmission and ArbitrationAward messages that pass
the pinned schemas; the extension member ``x-agentic-agreements`` carries
the exact AAP references back. Inbound, messages map to AAP roles, amounts
and references, and an external award becomes an evidence record for the
agreed stage only. The ladder still decides: deciders vote and the principal
finalizes, or a chain panel reaches its threshold. Nothing here signs,
submits, pays or releases escrow.
"""
from copy import deepcopy
from decimal import Decimal, InvalidOperation
import hashlib
import re

from . import agentic_arbitration as wire
from .crypto import canonical, digest, key, need, verification_key, verify

VERSION = 'urn:aap:arbitration-interop:0.1'
LABEL = 'AAP-ARBITRATION-INTEROP-0.1'
RECORD = 'urn:aap:arbitration-award-evidence:0.1'
EXTENSION = 'x-agentic-agreements'
FIELDS = ('version ladder parties service award_sender rules_version resolution_method signature_date '
          'claim_type money outcomes arbitrators service_keys required_assurance')
ASSURANCE = ('PANEL_SIGNATURES_VERIFIED', 'HASHES_VERIFIED_PANEL_INCOMPLETE')
REMEDIES = ('penalty', 'redeliver', 'refund', 'release', 'split')
PLACEHOLDER = 'e30.e30.e30'
_NAME = re.compile(r'[A-Za-z][A-Za-z0-9_.:-]{0,63}\Z')
FLAGS = {'authority': 'EVIDENCE_ONLY', 'escrow_effect': 'DECIDED_BY_AAP_TERMS_AND_LADDER',
         'execution_authorized': False, 'submitted': False, 'network_accessed': False}

REMEDIATION = {
    'INTEROP_TERMS': 'Use the exact interop terms fields and printable ASCII values from terms_draft.',
    'INTEROP_VERSION': 'Use urn:aap:arbitration-interop:0.1; a meaning change needs a new version.',
    'INTEROP_LADDER': 'Name a PROCEDURE policy id and stage, or a PANEL agreement id and PRIMARY or APPEAL, and pass that ladder.',
    'INTEROP_STAGE': 'The agreed procedure stage must exist and be JUDGMENT or OPTIMISTIC.',
    'INTEROP_PARTIES': 'Claimant and respondent must be the two disputants (procedure) or agent and counterparty (panel) with their exact keys.',
    'INTEROP_URI': 'Use agent:// and org:// URIs for parties and an RFC 3986 URI for the service.',
    'INTEROP_MONEY': 'Give money as {unit, currency (ISO 4217 letters), exponent 0..18}.',
    'INTEROP_MONEY_AMBIGUOUS': 'A result may hold at most one MONEY item in the terms unit.',
    'INTEROP_AMOUNT_PRECISION': 'The amount cannot be written exactly as an ECMAScript number; lower the exponent or amount.',
    'INTEROP_OUTCOMES': 'List 1 to 8 rows {outcome, liability, result}, each pair and result once, results among the ladder outcomes.',
    'INTEROP_OUTCOME': 'Every mapped result must be one of the adopted procedure outcomes or an allowed panel remedy.',
    'INTEROP_ARBITRATORS': 'List 1 to 16 arbitrators {judge_id, type AI or HUMAN, key: SPKI SHA-256 pin}, each once.',
    'INTEROP_SIGNATURES': 'Supply exactly one signature from each of claimant and respondent over the exact terms.',
    'INTEROP_POLICY_REQUIRED': 'Pass the adopted escalation policy the terms name.',
    'INTEROP_AGREEMENT_REQUIRED': 'Pass the bound chain covenant terms the terms name.',
    'INTEROP_NOT_OPENED': 'The ladder has no OPEN event yet; the claimant opens it in AAP first.',
    'INTEROP_CLAIMANT': 'Only the claimant named in the terms may have opened the ladder for a filing.',
    'INTEROP_NO_RESPONSE': 'The respondent has not yet agreed or challenged in the ladder.',
    'INTEROP_EVIDENCE_UNKNOWN': 'Map only evidence references that appear in the ladder events.',
    'INTEROP_EVENT': 'Name an OPEN or CHALLENGE event id from the supplied ladder.',
    'INTEROP_NO_FINAL_DECISION': 'Only a FINAL_ATTESTED_OUTCOME reached at the agreed stage can be exported as an award.',
    'INTEROP_UNMAPPED_RESULT': 'The final result has no row in the terms outcome table.',
    'INTEROP_PANEL': 'The award panel must be exactly the arbitrators the terms list, with their types.',
    'INTEROP_PANEL_STATE': 'The chain panel has not settled at the agreed phase.',
    'INTEROP_DOCUMENT': 'Pass the verified AAP award document whose outcome and basis match the ladder.',
    'INTEROP_MESSAGE_TERMS': 'The message names different parties, agreement, method or claim type from the signed terms.',
    'INTEROP_EXTENSION_MISMATCH': 'The x-agentic-agreements member contradicts the message body; it is not trusted.',
    'INTEROP_KEY_NOT_IN_TERMS': 'Pass only keys whose SPKI SHA-256 pins appear in the signed terms.',
    'INTEROP_METHOD': 'The award uses a different resolution method from the signed terms.',
    'INTEROP_ASSURANCE': 'The award does not reach the assurance the parties required in the terms.',
    'INTEROP_CUSTODY_AWARD': 'The custody chain has no AWARD_ISSUED event for this award.',
    'INTEROP_RECORD': 'Pass the exact evidence record award_evidence returned and its id.',
    'INTEROP_LADDER_NOT_OPEN': 'Open the AAP ladder first; an external award never opens it.',
    'INTEROP_STAGE_NOT_NEXT': 'Climb the earlier stages first; the parties decide each challenge.',
    'INTEROP_STAGE_ENTERED': 'The OPTIMISTIC stage already holds a result; the principal finalizes after the window unless challenged.',
    'INTEROP_STAGE_PASSED': 'The ladder has moved past the agreed stage; the award can no longer inform it.',
    'INTEROP_UNMAPPED_OUTCOME': 'This stage needs a result and the award decision has no row in the terms table.',
    'INTEROP_PANEL_FORMAT': 'The chain panel clause must accept hash evidence for an award record.',
    'ARBITRATION_INTEROP_ACTION': 'Use one of the actions covenant_arbitration_interop lists; none signs or submits.',
    'AGENTIC_ARBITRATION_TYPE': 'This arbitration message type is not mapped onto the deal\'s fair fix; only DisputeFiling, DisputeResponse and EvidenceSubmission are. Send one of those types; other messages stay unread evidence.',
}


def _text(value, limit, code='INTEROP_TERMS'):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def _name(value, code):
    need(type(value) is str and _NAME.match(value) is not None, code)


def _same(left, right):
    return canonical(left) == canonical(right)


def _amount(result, unit):
    """The one MONEY amount in the terms unit a procedure result carries, or None."""
    rows = [item for item in result.values() if type(item) is dict and item.get('kind') == 'MONEY' and item.get('unit') == unit]
    need(len(rows) <= 1, 'INTEROP_MONEY_AMBIGUOUS')
    return rows[0]['amount'] if rows else None


def to_value(amount, exponent):
    """AAP integer minor units to the exact decimal value an ECMAScript number holds."""
    exact = Decimal(amount).scaleb(-exponent)
    if exact == exact.to_integral_value():
        value = int(exact)
        need(abs(value) <= 2**53 - 1, 'INTEROP_AMOUNT_PRECISION')
        return value
    value = float(exact)
    need(Decimal(repr(value)) == exact, 'INTEROP_AMOUNT_PRECISION')
    return value


def to_minor(value, exponent):
    """A received decimal value back to AAP integer minor units, exactly or not at all."""
    try:
        exact = (Decimal(repr(value)) if type(value) is float else Decimal(value)).scaleb(exponent)
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError('INTEROP_AMOUNT_PRECISION') from None
    need(exact == exact.to_integral_value() and exact >= 0, 'INTEROP_AMOUNT_PRECISION')
    return int(exact)


# Interop terms ----------------------------------------------------------------

def validate_terms(terms):
    need(type(terms) is dict and set(terms) == set(FIELDS.split()), 'INTEROP_TERMS')
    need(terms['version'] == VERSION, 'INTEROP_VERSION')
    ladder = ladder_reference(terms['ladder'])
    parties = terms['parties']
    need(type(parties) is dict and set(parties) == {'claimant', 'respondent'}, 'INTEROP_PARTIES')
    for side in parties.values():
        need(type(side) is dict and set(side) == {'role', 'key', 'agent', 'organization', 'external_key'}, 'INTEROP_PARTIES')
        _name(side['role'], 'INTEROP_PARTIES')
        need(type(side['key']) is str, 'INTEROP_PARTIES'); verification_key(side['key'])
        need(wire.valid_uri(side['agent']) and side['agent'].startswith('agent://'), 'INTEROP_URI')
        need(wire.valid_uri(side['organization']) and side['organization'].startswith('org://'), 'INTEROP_URI')
        if side['external_key'] is not None: key(side['external_key'])
    claimant, respondent = parties['claimant'], parties['respondent']
    need(claimant['role'] != respondent['role'] and claimant['key'] != respondent['key']
         and claimant['agent'] != respondent['agent'], 'INTEROP_PARTIES')
    if ladder['kind'] == 'PANEL':
        need({claimant['role'], respondent['role']} == {'agent', 'counterparty'}, 'INTEROP_PARTIES')
    need(wire.valid_uri(terms['service']) and len(terms['service']) <= 512, 'INTEROP_URI')
    need(wire.valid_uri(terms['award_sender']) and terms['award_sender'].startswith('agent://'), 'INTEROP_URI')
    _text(terms['rules_version'], 128)
    need(terms['resolution_method'] in wire.METHODS and terms['claim_type'] in wire.CLAIM_TYPES, 'INTEROP_TERMS')
    need(type(terms['signature_date']) is str and wire.instant(terms['signature_date']) is not None, 'INTEROP_TERMS')
    money = terms['money']
    need(type(money) is dict and set(money) == {'unit', 'currency', 'exponent'}, 'INTEROP_MONEY')
    _text(money['unit'], 128, 'INTEROP_MONEY')
    need(type(money['currency']) is str and re.fullmatch('[A-Z]{3}', money['currency']) is not None
         and type(money['exponent']) is int and 0 <= money['exponent'] <= 18, 'INTEROP_MONEY')
    rows = terms['outcomes']
    need(type(rows) is list and 1 <= len(rows) <= 8, 'INTEROP_OUTCOMES')
    for row in rows:
        need(type(row) is dict and set(row) == {'outcome', 'liability', 'result'} and row['outcome'] in wire.OUTCOMES
             and row['liability'] in wire.LIABILITY and type(row['result']) is dict, 'INTEROP_OUTCOMES')
        ladder_result(ladder['kind'], row['result'], 'INTEROP_OUTCOMES')
        if ladder['kind'] == 'PROCEDURE': _amount(row['result'], money['unit'])
    need(len({(row['outcome'], row['liability']) for row in rows}) == len(rows), 'INTEROP_OUTCOMES')
    need(len({canonical(row['result']) for row in rows}) == len(rows), 'INTEROP_OUTCOMES')
    judges = terms['arbitrators']
    need(type(judges) is list and 1 <= len(judges) <= 16, 'INTEROP_ARBITRATORS')
    for row in judges:
        need(type(row) is dict and set(row) == {'judge_id', 'type', 'key'} and row['type'] in ('AI', 'HUMAN'), 'INTEROP_ARBITRATORS')
        _text(row['judge_id'], 128, 'INTEROP_ARBITRATORS'); key(row['key'])
    need(len({row['judge_id'] for row in judges}) == len(judges) and len({row['key'] for row in judges}) == len(judges), 'INTEROP_ARBITRATORS')
    pins = terms['service_keys']
    need(type(pins) is list and len(pins) <= 8 and len(set(pins)) == len(pins), 'INTEROP_TERMS')
    for pin in pins: key(pin)
    need(terms['required_assurance'] in ASSURANCE, 'INTEROP_TERMS')
    need(len(canonical(terms)) <= 65536, 'INTEROP_TERMS')
    return terms


def terms_id(terms):
    return digest(LABEL, validate_terms(terms))


def terms_draft(*, ladder, parties, service, award_sender, rules_version, resolution_method, signature_date,
                claim_type, money, outcomes, arbitrators, service_keys=(), required_assurance=ASSURANCE[0]):
    """The exact terms both disputants sign. Preparing them signs and sends nothing."""
    terms = {'version': VERSION, 'ladder': deepcopy(ladder), 'parties': deepcopy(parties), 'service': service,
             'award_sender': award_sender, 'rules_version': rules_version, 'resolution_method': resolution_method,
             'signature_date': signature_date, 'claim_type': claim_type, 'money': deepcopy(money),
             'outcomes': deepcopy(outcomes), 'arbitrators': deepcopy(arbitrators), 'service_keys': list(service_keys),
             'required_assurance': required_assurance}
    ident = terms_id(terms)
    return {'terms': terms, 'id': ident, 'signing_payload': {'label': LABEL, 'body': deepcopy(terms)},
            'required_signers': [parties['claimant']['key'], parties['respondent']['key']], **FLAGS}


def _stage(policy, name):
    return next((index for index, row in enumerate(policy['configuration']['stages']) if row['name'] == name), None)


# Ladder binding shared by every adapter that turns an outside decision into AAP evidence ------

def ladder_reference(ladder):
    """The stage an outside decision may inform: a procedure stage by name, or a chain panel phase."""
    need(type(ladder) is dict and set(ladder) == {'kind', 'id', 'stage'} and ladder['kind'] in ('PROCEDURE', 'PANEL'), 'INTEROP_LADDER')
    key(ladder['id'])
    if ladder['kind'] == 'PANEL': need(ladder['stage'] in ('PRIMARY', 'APPEAL'), 'INTEROP_LADDER')
    else: _name(ladder['stage'], 'INTEROP_LADDER')
    return ladder


def ladder_result(kind, result, code):
    """A result in the form the ladder decides: a typed map (procedure) or remedy, payee_bps, penalty (panel)."""
    if kind == 'PANEL':
        need(type(result) is dict and set(result) == {'remedy', 'payee_bps', 'penalty'} and result['remedy'] in REMEDIES
             and type(result['payee_bps']) is int and 0 <= result['payee_bps'] <= 10000
             and type(result['penalty']) is int and 0 <= result['penalty'] <= 2**53 - 1, code)
    else:
        from covenant_language.agreement_application import typed_map
        typed_map(result)
    return result


def check_ladder(ladder, parties, results, *, policy=None, chain_terms=None):
    """The named stage exists and decides with its own signatures.

    ``parties`` maps claimant and respondent to at least {role, key}; they must
    be the ladder's two disputants with their exact keys, and every mapped
    result must be one the ladder can reach. The ladder, never the outside
    decision, then decides.
    """
    if ladder['kind'] == 'PROCEDURE':
        need(policy is not None, 'INTEROP_POLICY_REQUIRED')
        from covenant_language import agreement_procedures as procedures
        need(procedures.identifier(policy) == ladder['id'] and policy['kind'] == 'ESCALATION', 'INTEROP_LADDER')
        configuration = policy['configuration']
        index = _stage(policy, ladder['stage'])
        need(index is not None and configuration['stages'][index]['mode'] in ('OPTIMISTIC', 'JUDGMENT'), 'INTEROP_STAGE')
        need({parties['claimant']['role'], parties['respondent']['role']} == set(configuration['disputants']), 'INTEROP_PARTIES')
        for side in parties.values():
            need(_same(policy['parties'][side['role']], side['key']), 'INTEROP_PARTIES')
        for result in results:
            need(any(_same(result, item) for item in configuration['outcomes']), 'INTEROP_OUTCOME')
    else:
        need(type(chain_terms) is dict and type(chain_terms.get('panel')) is dict, 'INTEROP_AGREEMENT_REQUIRED')
        from .arbitration import _shares
        from .ledger_base import agreement_id
        need(agreement_id(chain_terms) == ladder['id'], 'INTEROP_LADDER')
        panel = chain_terms['panel']
        need(ladder['stage'] == 'PRIMARY' or panel.get('appeal') is not None, 'INTEROP_LADDER')
        for side in parties.values():
            need(chain_terms.get(side['role']) == side['key'], 'INTEROP_PARTIES')
        for result in results:
            need(result['remedy'] in panel['scope']['remedies'], 'INTEROP_OUTCOME')
            try:
                _shares(chain_terms['quantity'], result['remedy'], result['payee_bps'], result['penalty'], panel['scope']['penalty_cap'])
            except ValueError:
                raise ValueError('INTEROP_OUTCOME') from None
    return ladder


def procedure_step(ladder, reference, mapped, policy, adoptions, events, *, actor, at, bond_receipt=None):
    """The one procedure event an evidence record supports at the agreed stage, unsigned.

    Entering the stage is a disputant's CHALLENGE citing the record; inside a
    JUDGMENT stage it is a decider's VOTE. The actor still signs, and the
    procedure's own replay refuses anything its policy does not allow.
    """
    from covenant_language import agreement_procedures as procedures
    need(ladder['kind'] == 'PROCEDURE', 'INTEROP_LADDER')
    need(procedures.identifier(policy) == ladder['id'], 'INTEROP_LADDER')
    state = procedures.replay(policy, adoptions, events)
    index = _stage(policy, ladder['stage'])
    need(index is not None, 'INTEROP_STAGE')
    stage = policy['configuration']['stages'][index]
    need(state['round'] is not None, 'INTEROP_LADDER_NOT_OPEN')
    need(state['round'] <= index, 'INTEROP_STAGE_PASSED')
    need(state['round'] >= index - 1, 'INTEROP_STAGE_NOT_NEXT')
    if state['round'] == index - 1:
        need(stage['mode'] != 'OPTIMISTIC' or mapped is not None, 'INTEROP_UNMAPPED_OUTCOME')
        action = 'CHALLENGE'
        arguments = {'evidence': reference, 'bond_receipt': bond_receipt,
                     'result': deepcopy(mapped) if stage['mode'] == 'OPTIMISTIC' else None}
    else:
        need(stage['mode'] == 'JUDGMENT', 'INTEROP_STAGE_ENTERED')
        need(mapped is not None, 'INTEROP_UNMAPPED_OUTCOME')
        action, arguments = 'VOTE', {'result': deepcopy(mapped)}
    payload = procedures.event_payload(policy, adoptions, events, actor, action, arguments, at)
    return {'event_payload': payload, 'action': action, 'stage': stage['name'], 'record': reference,
            'decides_escrow': False, 'note': 'The actor signs this event; FINALIZE by the principal still follows the ladder.', **FLAGS}


def panel_evidence_step(ladder, reference, mapped, chain_terms, *, chain, description):
    """PANEL_EVIDENCE citing the record, and the ballot body a seated arbitrator may choose to sign."""
    from .arbitration_sdk import ballot_body, evidence_payload
    need(ladder['kind'] == 'PANEL', 'INTEROP_LADDER')
    panel = chain_terms['panel']
    need('hash' in panel['evidence']['formats'], 'INTEROP_PANEL_FORMAT')
    agreement = ladder['id']
    evidence = evidence_payload(agreement, reference, format='hash',
                                description='SEALED' if panel['confidentiality'] == 'panel' else description)
    body = None if mapped is None else ballot_body(chain, agreement, ladder['stage'], mapped['remedy'],
                                                    mapped['payee_bps'], mapped['penalty'], reference)
    return {'op': 'PANEL_EVIDENCE', 'payload': evidence, 'ballot_body': body,
            'ballot_label': 'COVENANT-PANEL-BALLOT-1' if body is not None else None, 'record': reference,
            'decides_escrow': False, 'note': 'Each seated arbitrator decides; the panel threshold settles escrow.', **FLAGS}


def adopt(terms, signatures, *, policy=None, chain_terms=None):
    """Both disputants' signatures over the exact terms, checked against the ladder they name."""
    ident = terms_id(terms)
    need(type(signatures) is list and len(signatures) == 2, 'INTEROP_SIGNATURES')
    signed = set()
    for row in signatures:
        need(type(row) is dict and set(row) == {'side', 'signature'} and row['side'] in ('claimant', 'respondent')
             and row['side'] not in signed, 'INTEROP_SIGNATURES')
        verify(terms['parties'][row['side']]['key'], LABEL, terms, row['signature'])
        signed.add(row['side'])
    ladder = terms['ladder']
    check_ladder(ladder, terms['parties'], [row['result'] for row in terms['outcomes']], policy=policy, chain_terms=chain_terms)
    return {'terms': deepcopy(terms), 'id': ident, 'signed_by': sorted(signed), 'ladder': deepcopy(ladder), **FLAGS}


# Reading an adopted procedure --------------------------------------------------

def _procedure(terms, signatures, policy, adoptions, events):
    from covenant_language import agreement_procedures as procedures
    from covenant_language.agreement_application import content_id
    adopted = adopt(terms, signatures, policy=policy)
    state = procedures.replay(policy, adoptions, events)
    rows, round_ = [], None
    for event in events:
        body = event['body']
        if body['action'] == 'OPEN': round_ = 0
        elif body['action'] == 'CHALLENGE': round_ += 1
        rows.append({'id': content_id('AAP-PROCEDURE-EVENT-0.1', body), 'actor': body['actor'], 'action': body['action'],
                     'arguments': event['arguments'], 'at': body['at'], 'round': round_})
    return adopted, state, rows


def _side(terms, role):
    return next(side for side, row in terms['parties'].items() if row['role'] == role)


def _envelope(kind, sender, terms, message_id, timestamp, payload):
    message = {'@context': wire.CONTEXT, '@type': kind, 'messageId': message_id, 'timestamp': timestamp,
               'sender': sender, 'recipient': terms['service'], 'payload': payload}
    probe = deepcopy(message); probe['signature'] = PLACEHOLDER
    if kind == 'EvidenceSubmission': probe['payload']['evidence']['signature'] = PLACEHOLDER
    wire.validate(probe, kind)
    return message


def _evidence_items(refs, evidence):
    """Caller descriptions for references the ladder actually carries."""
    need(type(evidence) in (list, tuple) and len(evidence) <= 32, 'INTEROP_EVIDENCE_UNKNOWN')
    out = []
    for item in evidence:
        need(type(item) is dict and set(item) == {'reference', 'type', 'id', 'description'}
             and item['reference'] in refs and item['type'] in wire.EVIDENCE_TYPES, 'INTEROP_EVIDENCE_UNKNOWN')
        _text(item['id'], 128, 'INTEROP_EVIDENCE_UNKNOWN'); _text(item['description'], 2000, 'INTEROP_EVIDENCE_UNKNOWN')
        out.append({'evidenceId': item['id'], 'evidenceType': item['type'], 'contentHash': 'sha256:' + item['reference'],
                    'storageUri': wire.ni_uri(item['reference']), 'description': item['description']})
    return out


def _result_text(result):
    return 'result:' + wire.stringify(result)


def filing_message(terms, signatures, policy, adoptions, events, *, message_id, timestamp, evidence=()):
    """The claimant's OPEN as an unsigned DisputeFiling; seal() signs it with the claimant's key."""
    adopted, state, rows = _procedure(terms, signatures, policy, adoptions, events)
    opened = next((row for row in rows if row['action'] == 'OPEN'), None)
    need(opened is not None, 'INTEROP_NOT_OPENED')
    claimant, respondent = terms['parties']['claimant'], terms['parties']['respondent']
    need(opened['actor'] == claimant['role'], 'INTEROP_CLAIMANT')
    result = opened['arguments']['result']
    money = terms['money']
    amount = _amount(result, money['unit'])
    refs = {opened['arguments']['claim']} | {row['arguments']['evidence'] for row in rows
                                              if row['action'] == 'CHALLENGE' and row['actor'] == claimant['role']}
    payload = {'claimant': {'agentId': claimant['agent'], 'organizationId': claimant['organization']},
               'respondent': {'agentId': respondent['agent'], 'organizationId': respondent['organization']},
               'claim': {'claimType': terms['claim_type'],
                         'claimAmount': {'value': to_value(amount or 0, money['exponent']), 'currency': money['currency']}},
               'arbitrationAgreement': {'agreementId': adopted['id'], 'rulesVersion': terms['rules_version'],
                                        'resolutionMethod': terms['resolution_method'], 'signatureDate': terms['signature_date']},
               EXTENSION: {'terms': adopted['id'], 'ladder': deepcopy(terms['ladder']), 'event': opened['id'],
                           'claim': opened['arguments']['claim'], 'result': deepcopy(result)}}
    items = _evidence_items(refs, evidence)
    if items: payload['evidence'] = items
    message = _envelope('DisputeFiling', claimant['agent'], terms, message_id, timestamp, payload)
    return {'message': message, 'signer': 'claimant', 'event': opened['id'], **FLAGS}


def response_message(terms, signatures, policy, adoptions, events, *, case_id, message_id, timestamp, evidence=()):
    """The respondent's first AGREE or CHALLENGE as an unsigned DisputeResponse."""
    adopted, state, rows = _procedure(terms, signatures, policy, adoptions, events)
    respondent = terms['parties']['respondent']
    opened = next((row for row in rows if row['action'] == 'OPEN'), None)
    need(opened is not None, 'INTEROP_NOT_OPENED')
    reply = next((row for row in rows if row['actor'] == respondent['role'] and row['action'] in ('AGREE', 'CHALLENGE')), None)
    need(reply is not None, 'INTEROP_NO_RESPONSE')
    _text(case_id, 256, 'INTEROP_TERMS')
    if reply['action'] == 'AGREE':
        response, refs = {'admissions': [_result_text(reply['arguments']['result'])]}, set()
    else:
        response = {'denials': [_result_text(opened['arguments']['result'])]}
        if reply['arguments']['result'] is not None:
            response['narrative'] = 'proposed ' + _result_text(reply['arguments']['result'])
        refs = {reply['arguments']['evidence']}
    payload = {'caseId': case_id, 'respondent': {'agentId': respondent['agent'], 'organizationId': respondent['organization']},
               'response': response,
               EXTENSION: {'terms': adopted['id'], 'ladder': deepcopy(terms['ladder']), 'event': reply['id'],
                           'action': reply['action'], 'result': deepcopy(reply['arguments']['result'])}}
    items = _evidence_items(refs, evidence)
    if items: payload['evidence'] = items
    message = _envelope('DisputeResponse', respondent['agent'], terms, message_id, timestamp, payload)
    return {'message': message, 'signer': 'respondent', 'event': reply['id'], **FLAGS}


def evidence_message(terms, signatures, policy, adoptions, events, *, event, case_id, item, message_id, timestamp):
    """One ladder evidence reference (OPEN claim or CHALLENGE evidence) as EvidenceSubmission."""
    adopted, state, rows = _procedure(terms, signatures, policy, adoptions, events)
    row = next((row for row in rows if row['id'] == event and row['action'] in ('OPEN', 'CHALLENGE')), None)
    need(row is not None, 'INTEROP_EVENT')
    reference = row['arguments']['claim'] if row['action'] == 'OPEN' else row['arguments']['evidence']
    side = _side(terms, row['actor'])
    _text(case_id, 256, 'INTEROP_TERMS')
    need(type(item) is dict and set(item) == {'type', 'id', 'description'} and item['type'] in wire.EVIDENCE_TYPES, 'INTEROP_EVIDENCE_UNKNOWN')
    _text(item['id'], 128, 'INTEROP_EVIDENCE_UNKNOWN'); _text(item['description'], 2000, 'INTEROP_EVIDENCE_UNKNOWN')
    entry = {'evidenceId': item['id'], 'evidenceType': item['type'], 'description': item['description'],
             'contentHash': 'sha256:' + reference, 'storageUri': wire.ni_uri(reference), 'signature': PLACEHOLDER}
    payload = {'caseId': case_id, 'submittedBy': side, 'evidence': entry,
               EXTENSION: {'terms': adopted['id'], 'ladder': deepcopy(terms['ladder']), 'event': row['id'], 'reference': reference}}
    message = _envelope('EvidenceSubmission', terms['parties'][side]['agent'], terms, message_id, timestamp, payload)
    return {'message': message, 'signer': side, 'event': row['id'], **FLAGS}


def seal(message, private_key, kid=None):
    """Explicit caller action with the caller's ES256/ES384 key; evidence signs its contentHash."""
    message = deepcopy(message)
    if message.get('@type') == 'EvidenceSubmission' and message['payload']['evidence'].get('signature') == PLACEHOLDER:
        message['payload']['evidence']['signature'] = wire.jws_sign(
            private_key, message['payload']['evidence']['contentHash'].encode('ascii'), kid)
    return wire.seal(message, private_key, kid)


# Awards out of AAP ---------------------------------------------------------------

def _row_for(terms, result):
    row = next((row for row in terms['outcomes'] if _same(row['result'], result)), None)
    need(row is not None, 'INTEROP_UNMAPPED_RESULT')
    return row


def _document(document, *, outcome, reference, head):
    from . import award_documents
    need(type(document) is dict and set(document) == {'award', 'pdf', 'detached'}, 'INTEROP_DOCUMENT')
    report = award_documents.verify(document['award'], document['pdf'], document['detached'])
    body = document['award']['body']
    need(_same(body['outcome'], outcome) and body['basis']['reference'] == reference
         and (head is None or body['basis']['head'] == head), 'INTEROP_DOCUMENT')
    return report, body


def _award_payload(terms, ident, *, award_id, case_id, issued_at, row, damages, body, report, extension):
    _text(award_id, 256, 'INTEROP_TERMS'); _text(case_id, 256, 'INTEROP_TERMS')
    sections = body['sections']
    decision = {'outcome': row['outcome'], 'liability': row['liability'],
                'findings': '\n'.join(sections[0]['paragraphs']),
                'reasoning': '\n'.join(p for section in sections[1:] for p in section['paragraphs']) or sections[0]['heading'],
                'remedy': _result_text(row['result'])}
    if damages is not None: decision['damages'] = damages
    return {'awardId': award_id, 'caseId': case_id, 'issuedAt': issued_at, 'resolutionMethod': terms['resolution_method'],
            'panel': [{'judgeId': judge['judge_id'], 'judgeType': judge['type']} for judge in terms['arbitrators']],
            'decision': decision,
            EXTENSION: {**extension, 'terms': ident, 'ladder': deepcopy(terms['ladder']),
                        'award_document': {'id': report['id'], 'body_id': report['body_id'], 'pdf_sha256': report['pdf_sha256']}}}


def procedure_award(terms, signatures, policy, adoptions, events, document, *, award_id, case_id, message_id):
    """A FINAL procedure outcome at the agreed stage, wrapped as an ArbitrationAward.

    ``document`` is the verified AAP dual-format award ({award, pdf, detached}).
    The result is unsigned; ``seal_award`` adds RFC 003 formats and JWS.
    """
    adopted, state, rows = _procedure(terms, signatures, policy, adoptions, events)
    index = _stage(policy, terms['ladder']['stage'])
    stage = policy['configuration']['stages'][index]
    need(state['status'] == 'FINAL_ATTESTED_OUTCOME' and state['round'] == index, 'INTEROP_NO_FINAL_DECISION')
    need(stage['mode'] != 'JUDGMENT' or set(stage['deciders']) == {row['judge_id'] for row in terms['arbitrators']}, 'INTEROP_PANEL')
    row = _row_for(terms, state['outcome'])
    report, body = _document(document, outcome=state['outcome'], reference=adopted['ladder']['id'], head=None)
    amount = _amount(state['outcome'], terms['money']['unit'])
    damages = None if amount is None else {'value': to_value(amount, terms['money']['exponent']), 'currency': terms['money']['currency']}
    votes = [item['id'] for item in rows if item['action'] == 'VOTE' and item['round'] == index]
    payload = _award_payload(terms, adopted['id'], award_id=award_id, case_id=case_id, issued_at=body['issued'], row=row,
                             damages=damages, body=body, report=report,
                             extension={'head': state['head'], 'votes': votes, 'result': deepcopy(state['outcome'])})
    return _prepared_award(terms, message_id, body['issued'], payload, document['pdf'])


def panel_award(terms, signatures, chain_terms, agreement, document, *, award_id, case_id, message_id):
    """A settled chain panel decision at the agreed phase, wrapped as an ArbitrationAward."""
    adopted = adopt(terms, signatures, chain_terms=chain_terms)
    case = agreement.get('panel_case') if type(agreement) is dict else None
    decision = agreement.get('decision') if type(agreement) is dict else None
    need(type(case) is dict and type(decision) is dict and decision.get('remedy') in REMEDIES
         and _same(agreement.get('terms'), chain_terms), 'INTEROP_PANEL_STATE')
    result = {'remedy': decision['remedy'], 'payee_bps': decision['payee_bps'], 'penalty': decision['penalty']}
    if terms['ladder']['stage'] == 'APPEAL':
        appeal = case.get('appeal')
        agreed = [vote for vote in (appeal or {}).get('votes', {}).values()
                  if {name: vote[name] for name in result} == result and vote['reasons'] == decision['reasons']]
        need(case['status'] == 'FINAL' and len(agreed) >= chain_terms['panel']['appeal']['threshold'], 'INTEROP_PANEL_STATE')
        seated = appeal['seated']
    else:
        need(case['status'] in ('SETTLED', 'FINAL') and case.get('appeal') is None, 'INTEROP_PANEL_STATE')
        seated = case['seated']
    need(set(seated) == {row['judge_id'] for row in terms['arbitrators']}, 'INTEROP_PANEL')
    row = _row_for(terms, result)
    report, body = _document(document, outcome=result, reference=adopted['ladder']['id'], head=None)
    payload = _award_payload(terms, adopted['id'], award_id=award_id, case_id=case_id, issued_at=body['issued'], row=row,
                             damages=None, body=body, report=report,
                             extension={'event': decision['event'], 'reasons': decision['reasons'], 'result': result})
    return _prepared_award(terms, message_id, body['issued'], payload, document['pdf'])


def _prepared_award(terms, message_id, timestamp, payload, pdf):
    pdf_hash = hashlib.sha256(pdf).hexdigest()
    envelope = {'@context': wire.CONTEXT, '@type': 'ArbitrationAward', 'messageId': message_id, 'timestamp': timestamp,
                'sender': terms['award_sender'], 'recipient': terms['service']}
    probe = {**deepcopy(envelope), 'signature': PLACEHOLDER, 'payload': {
        **deepcopy(payload), 'signatures': [],
        'formats': {'json': {'contentHash': 'sha256:' + '0' * 64, 'signature': PLACEHOLDER},
                    'pdf': {'documentUri': wire.ni_uri(pdf_hash), 'contentHash': 'sha256:' + pdf_hash, 'signature': PLACEHOLDER}}}}
    wire.validate(probe, 'ArbitrationAward')
    return {'envelope': envelope, 'payload': payload, 'pdf': pdf, 'document_uri': wire.ni_uri(pdf_hash), **FLAGS}


def seal_award(prepared, *, judges, service_key, sender_key):
    """Explicit caller action: judges, service and sender sign with their own keys."""
    payload = wire.seal_award(prepared['payload'], judges=judges, service_key=service_key, pdf=prepared['pdf'],
                              document_uri=prepared['document_uri'])
    return wire.seal({**deepcopy(prepared['envelope']), 'payload': payload}, sender_key)


# Messages into AAP -----------------------------------------------------------------

def _document_bytes(message):
    if type(message) in (bytes, str):
        received = wire.read(message)
        return received['document'], received['sha256']
    wire.bounded(message)
    return message, hashlib.sha256(wire.stringify(message).encode('utf-8')).hexdigest()


def _role_of(terms, block):
    for side, row in terms['parties'].items():
        if row['agent'] == block['agentId']:
            need(row['organization'] == block['organizationId'], 'INTEROP_MESSAGE_TERMS')
            return side
    raise ValueError('INTEROP_MESSAGE_TERMS')


def _extension(payload, ident, terms):
    ext = payload.get(EXTENSION)
    if ext is None: return None
    need(type(ext) is dict and ext.get('terms') == ident and ext.get('ladder') == terms['ladder'], 'INTEROP_EXTENSION_MISMATCH')
    return ext


def message_view(terms, signatures, message, *, policy=None, chain_terms=None):
    """Map a received filing, response or evidence submission onto AAP roles and references.

    The proposal is an unsigned suggestion for the named AAP actor; the
    extension member is cross-checked against the body, never trusted alone.
    """
    adopted = adopt(terms, signatures, policy=policy, chain_terms=chain_terms)
    document, sha = _document_bytes(message)
    kind = wire.validate(document)
    payload = document['payload']
    ident = adopted['id']
    ext = _extension(payload, ident, terms)
    money = terms['money']
    view = {'kind': kind, 'terms': ident, 'message_sha256': sha, 'aap_extension': ext is not None, **FLAGS}
    if kind == 'DisputeFiling':
        claimant, respondent = _role_of(terms, payload['claimant']), _role_of(terms, payload['respondent'])
        agreement = payload['arbitrationAgreement']
        need(claimant == 'claimant' and respondent == 'respondent' and agreement['agreementId'] == ident
             and agreement['resolutionMethod'] == terms['resolution_method'] and payload['claim']['claimType'] == terms['claim_type']
             and payload['claim']['claimAmount']['currency'] == money['currency'], 'INTEROP_MESSAGE_TERMS')
        amount = to_minor(payload['claim']['claimAmount']['value'], money['exponent'])
        if ext is not None:
            need(set(ext) == {'terms', 'ladder', 'event', 'claim', 'result'} and (_amount(ext['result'], money['unit']) or 0) == amount,
                 'INTEROP_EXTENSION_MISMATCH')
            result, claim = ext['result'], ext['claim']
        else:
            rows = [row['result'] for row in terms['outcomes'] if row['outcome'] == 'CLAIMANT_PREVAILS'
                    and terms['ladder']['kind'] == 'PROCEDURE' and (_amount(row['result'], money['unit']) or 0) == amount]
            result, claim = (rows[0] if len(rows) == 1 else None), sha
        if terms['ladder']['kind'] == 'PANEL':
            from .arbitration_sdk import open_payload
            proposal = {'op': 'PANEL_OPEN', 'payload': open_payload(terms['ladder']['id'])}
        else:
            proposal = None if result is None else {'action': 'OPEN', 'arguments': {'claim': claim, 'result': deepcopy(result), 'bond_receipt': None}}
        view.update(actor=terms['parties']['claimant']['role'], amount=amount,
                    evidence=[item['contentHash'][7:] for item in payload.get('evidence', [])], proposal=proposal)
        return view
    if kind == 'DisputeResponse':
        need(_role_of(terms, payload['respondent']) == 'respondent', 'INTEROP_MESSAGE_TERMS')
        response = payload['response']
        refs = [item['contentHash'][7:] for item in payload.get('evidence', [])]
        if ext is not None:
            need(set(ext) == {'terms', 'ladder', 'event', 'action', 'result'} and ext['action'] in ('AGREE', 'CHALLENGE'), 'INTEROP_EXTENSION_MISMATCH')
            text = response.get('admissions' if ext['action'] == 'AGREE' else 'denials')
            need(type(text) is list and len(text) == 1 and (ext['action'] != 'AGREE' or text[0] == _result_text(ext['result'])),
                 'INTEROP_EXTENSION_MISMATCH')
            proposal = ({'action': 'AGREE', 'arguments': {'result': deepcopy(ext['result'])}} if ext['action'] == 'AGREE' else
                        {'action': 'CHALLENGE', 'arguments': {'evidence': refs[0] if refs else sha, 'bond_receipt': None,
                                                              'result': deepcopy(ext['result'])}})
        else:
            contested = bool(response.get('denials') or response.get('affirmativeDefenses') or response.get('counterClaim'))
            proposal = {'action': 'CHALLENGE', 'arguments': {'evidence': sha, 'bond_receipt': None, 'result': None}} if contested else None
        view.update(actor=terms['parties']['respondent']['role'], case=payload['caseId'], evidence=refs,
                    contested=proposal is not None and proposal['action'] == 'CHALLENGE',
                    proposal=proposal if terms['ladder']['kind'] == 'PROCEDURE' else None)
        return view
    need(kind == 'EvidenceSubmission', 'AGENTIC_ARBITRATION_TYPE')
    side = payload['submittedBy']
    need(document['sender'] == terms['parties'][side]['agent'], 'INTEROP_MESSAGE_TERMS')
    reference = payload['evidence']['contentHash'][7:]
    if ext is not None:
        need(ext.get('reference') == reference, 'INTEROP_EXTENSION_MISMATCH')
    view.update(actor=terms['parties'][side]['role'], case=payload['caseId'], reference=reference,
                evidence_type=payload['evidence']['evidenceType'])
    if terms['ladder']['kind'] == 'PANEL':
        from .arbitration_sdk import evidence_payload
        confidential = chain_terms['panel']['confidentiality'] == 'panel'
        view['panel_payload'] = {'op': 'PANEL_EVIDENCE', 'payload': evidence_payload(
            terms['ladder']['id'], reference, format='hash',
            description='SEALED' if confidential else 'Agentic Arbitration Protocol evidence ' + payload['evidence']['evidenceType'])}
    return view


# External awards as evidence for the agreed stage -------------------------------------

def _pinned(terms, keys):
    need(type(keys) is dict and set(keys) <= {'judges', 'service', 'parties'}, 'INTEROP_KEY_NOT_IN_TERMS')
    judges = keys.get('judges') or {}
    service = list(keys.get('service') or [])
    parties = keys.get('parties') or {}
    need(type(judges) is dict and type(parties) is dict and len(service) <= 8, 'INTEROP_KEY_NOT_IN_TERMS')
    allowed = {row['judge_id']: row['key'] for row in terms['arbitrators']}
    for judge, pem in judges.items():
        need(allowed.get(judge) == wire.key_pin(pem), 'INTEROP_KEY_NOT_IN_TERMS')
    for pem in service:
        need(wire.key_pin(pem) in terms['service_keys'], 'INTEROP_KEY_NOT_IN_TERMS')
    actors = {}
    for side, pem in parties.items():
        need(side in terms['parties'] and terms['parties'][side]['external_key'] == wire.key_pin(pem), 'INTEROP_KEY_NOT_IN_TERMS')
        actors[terms['parties'][side]['agent']] = pem
    return judges, service, actors


def record_id(record):
    from covenant_language.agreement_application import content_id
    return content_id(RECORD, record)


def award_evidence(terms, signatures, award, *, keys, pdf=None, custody=None, policy=None, chain_terms=None):
    """Verify an external award against the signed terms and make it an evidence record.

    The record is what a party cites at the agreed stage. Its mapped result is
    the parties' own table row for the award's decision, or None. It moves no
    escrow: the procedure or panel decides with its own signatures.
    """
    adopted = adopt(terms, signatures, policy=policy, chain_terms=chain_terms)
    document, sha = _document_bytes(award)
    judges, service, actors = _pinned(terms, keys)
    report = wire.verify_award(document, judges=judges, service_keys=service, pdf=pdf,
                               require_all_judges=terms['required_assurance'] == 'PANEL_SIGNATURES_VERIFIED')
    need(ASSURANCE.index(report['assurance']) <= ASSURANCE.index(terms['required_assurance']), 'INTEROP_ASSURANCE')
    payload = document['payload']
    # An explicit AAP context claim must agree with the adopted terms, just as
    # it must for filings and responses. Absence is still legacy-compatible.
    _extension(payload, adopted['id'], terms)
    need(payload['resolutionMethod'] == terms['resolution_method'], 'INTEROP_METHOD')
    need(sorted((row['judgeId'], row['judgeType']) for row in payload['panel']) ==
         sorted((row['judge_id'], row['type']) for row in terms['arbitrators']), 'INTEROP_PANEL')
    chain = None
    if custody is not None:
        checked = wire.verify_custody(custody, keys=actors, service_keys=service, case=payload['caseId'])
        need('AWARD_ISSUED' in checked['event_types'], 'INTEROP_CUSTODY_AWARD')
        chain = {'head': checked['head'], 'events': checked['events'], 'status': checked['status']}
    decision = payload['decision']
    row = next((row for row in terms['outcomes'] if (row['outcome'], row['liability']) == (decision['outcome'], decision['liability'])), None)
    mapping, damages = 'MAPPED', None
    if 'damages' in decision and set(decision['damages']) == {'value', 'currency'}:
        try:
            damages = {'minor': to_minor(decision['damages']['value'], terms['money']['exponent']),
                       'currency': decision['damages']['currency']}
        except ValueError:
            mapping = 'DAMAGES_UNREPRESENTABLE'
    if row is None:
        mapping = 'UNMAPPED_OUTCOME'
    elif mapping == 'MAPPED' and terms['ladder']['kind'] == 'PROCEDURE':
        amount = _amount(row['result'], terms['money']['unit'])
        stated = None if damages is None else damages['minor']
        if damages is not None and (damages['currency'] != terms['money']['currency'] or stated != (amount or 0)):
            mapping = 'DAMAGES_MISMATCH'
        elif damages is None and amount:
            mapping = 'DAMAGES_NOT_STATED'
    record = {'version': RECORD, 'terms': adopted['id'], 'ladder': deepcopy(terms['ladder']),
              'award': {'id': payload['awardId'], 'case': payload['caseId'], 'issued_at': payload['issuedAt'],
                        'message_sha256': sha, 'json_hash': report['json_hash'], 'pdf_hash': report['pdf_hash'],
                        'pdf': report['pdf']},
              'decision': {'outcome': decision['outcome'], 'liability': decision['liability'], 'damages': damages},
              'mapping': mapping, 'mapped_result': deepcopy(row['result']) if row is not None and mapping == 'MAPPED' else None,
              'assurance': report['assurance'], 'judges_verified': report['judges_verified'], 'custody': chain}
    ident = record_id(record)
    return {'record': record, 'id': ident, 'evidence_reference': ident, 'verification': report, **FLAGS}


def _checked_record(terms, record, expected):
    need(type(record) is dict and record.get('version') == RECORD and record_id(record) == expected, 'INTEROP_RECORD')
    need(record['terms'] == terms_id(terms) and record['ladder'] == terms['ladder'], 'INTEROP_RECORD')
    return expected


def ladder_step(terms, signatures, record, expected_record, policy, adoptions, events, *, actor, at, bond_receipt=None):
    """Prepare the one AAP procedure event the record supports at the agreed stage, unsigned.

    Entering the stage is a disputant's CHALLENGE citing the record; inside a
    JUDGMENT stage it is a decider's VOTE. The actor still signs, and the
    procedure's own replay refuses anything its policy does not allow.
    """
    adopt(terms, signatures, policy=policy)
    ident = _checked_record(terms, record, expected_record)
    return procedure_step(terms['ladder'], ident, record['mapped_result'], policy, adoptions, events,
                          actor=actor, at=at, bond_receipt=bond_receipt)


def panel_step(terms, signatures, record, expected_record, chain_terms, *, chain):
    """PANEL_EVIDENCE citing the record, and the ballot body a seated arbitrator may choose to sign."""
    adopt(terms, signatures, chain_terms=chain_terms)
    ident = _checked_record(terms, record, expected_record)
    return panel_evidence_step(terms['ladder'], ident, record['mapped_result'], chain_terms, chain=chain,
                               description='Agentic Arbitration Protocol award evidence record')


def describe():
    return {'version': VERSION, 'record': RECORD, 'label': LABEL, 'decision': 'GRAFT', 'extension': EXTENSION,
            'mapping': {
                'DisputeFiling': 'procedure OPEN by the terms claimant (claim reference, result, amount via money)',
                'DisputeResponse': 'respondent AGREE (admissions) or CHALLENGE (denials, evidence, proposed result)',
                'EvidenceSubmission': 'OPEN claim or CHALLENGE evidence reference; PANEL_EVIDENCE for a chain panel',
                'ArbitrationAward': 'FINAL procedure outcome at the agreed stage or settled panel decision, out; '
                                    'evidence record for the agreed stage, in'},
            'escrow': 'AAP terms and ladder only; an external award never releases or moves escrow',
            'remediation': deepcopy(REMEDIATION), **FLAGS}
