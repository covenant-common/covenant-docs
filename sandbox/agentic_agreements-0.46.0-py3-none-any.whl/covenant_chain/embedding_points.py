"""Embedding points: one AAP reference in each protocol's own designated extension point.

Plugging in should be the cheapest integration anyone can make. With one
optional field, a transaction in someone else's protocol names the AAP
agreement behind it, so it becomes provable and gains AAP recourse, and the
receipts it earns count wherever AAP is used. The field carries a reference
(``covenant_chain.aap_reference``, profile ``urn:aap:ref:0.1``): a pointer to
evidence, never permission.

Each placement uses only the extension point its specification designates,
with the version, section and field cited in ``PLACEMENTS``. A field the
specification reserves for something else is never used. Where a first-class
field would serve better, a draft proposal for its stewards is in
``proposals/upstream/``; the drafts are for the owner, and nothing is submitted.

For every placement:

* ``place`` returns a new carrier with the reference in the designated field.
  The input is never mutated. A different reference already in that field is
  refused, never overwritten; the same reference is a no-op, so retries are safe.
* ``extract`` reads that field only. Everything else in the carrier is inert:
  never read, interpreted or reported as a reference. A value there that names
  a newer profile is reported as unsupported and left alone; a malformed value
  is reported as refused.
* ``verify`` requires exactly one distinct reference, checks it against the
  agreement, receipt and keys the caller holds, and runs the carrier's own
  binding check where the protocol has one (x402 echo, MPP challenge binding,
  AP2 checkout hash, ERC-8183 deliverable, LCP atrHash).

Nothing here opens a socket, resolves a name, fetches a locator, signs, pays,
installs a connector or contacts anyone. A verified reference shows that you
hold the referenced bytes. Whether both parties assented, and whether anything
was paid or delivered, are separate checks.
"""
import argparse
import base64
from copy import deepcopy
import hashlib
import json
import re
import sys
from xml.parsers import expat
import xml.etree.ElementTree as ElementTree

from . import aap_reference, atr, erc8004_bridge, interop_codec
from .aap_reference import FLAGS, PROFILE, REMEDIATION as REFERENCE_REMEDIATION
from .crypto import need
from .registry_records import OASF_VERSIONS, oasf_cid
from covenant_x402 import mpp

VERSION = 'urn:aap:embedding-points:0.1'
MATURITY = 'experimental'
MAX_CARRIER = 262144
MAX_DEPTH = 32
MAX_NODES = 20000
MAX_HEADER = 16384
MAX_ITEMS = 256
MAX_DNS_LINES = 1000
MAX_DESCRIPTION = 4096

X402_KEY = 'aap-ref'
MPP_KEY = 'aap-ref'
A2A_URI = PROFILE
A2A_DESCRIPTION = ('Attaches an AAP reference (urn:aap:ref:0.1) naming the agreement behind a task or message. '
                   'Evidence, never authority.')
MCP_KEY = 'io.github.covenant-common/aap-ref'
ACP_KEY = 'aap_ref'
UCP_TYPE = 'io.github.covenant-common.policy.aap_ref'
UCP_MEMBER = 'aap_ref'
UCP_DESCRIPTION = ('AAP agreement reference: the content id of the agreement both parties signed for this '
                   'purchase. A pointer to evidence; it grants no authority.')
AP2_VCT = 'mandate.checkout.1'
ERC8004_TYPE = 'https://eips.ethereum.org/EIPS/eip-8004#registration-v1'
ERC8004_SERVICE = 'AAP'
ERC8004_FEEDBACK_MEMBER = 'aap'
ERC8004_METADATA_KEY = 'aap-ref'
LCP_MEMBER = 'aapRef'
RSL_NAMESPACE = 'https://rslstandard.org/rsl'
AAP_XML_NAMESPACE = PROFILE
LINK_RELATION = 'https://covenant-common.github.io/covenant-docs/rel/agreement'
PROPOSED_LINK_RELATION = 'agreement'
PROPOSED_DNS_NAME = '_aap'
SCHEMA_ORG_PROPERTY = PROFILE
OASF_KEY = 'io.github.covenant-common/aap-ref'
MCP_KEY_RULE = re.compile(r'([A-Za-z]([A-Za-z0-9-]*[A-Za-z0-9])?\.)*[A-Za-z]([A-Za-z0-9-]*[A-Za-z0-9])?/'
                          r'[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?\Z')
TOKEN = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+")
COMPACT_TOKEN = re.compile(r'urn:aap:ref:[^\s"<>\\]*')
TXT_TYPE = re.compile(r'(?:^|\s)TXT\s', re.IGNORECASE)
LICENCE_END = re.compile(rb'</([A-Za-z_][A-Za-z0-9_.-]*:)?license[ \t\r\n]*>')

GUIDANCE = {
    'EMBED_PROTOCOL': 'Name one of the placements listed by placements(); each is one protocol\'s designated extension point.',
    'EMBED_CARRIER': 'Pass the carrier in the shape the cited specification defines (see placements() for the version and field).',
    'EMBED_CONFLICT': 'The designated field already holds a different AAP reference. Keep it, or remove it deliberately before placing another.',
    'EMBED_ABSENT': 'The carrier has no AAP reference in its designated field. Ask the counterparty to place one.',
    'EMBED_AMBIGUOUS': 'The carrier names more than one distinct AAP reference. Ask for one reference per carrier.',
    'EMBED_REFUSED': 'The designated field holds a malformed AAP reference. Obtain the carrier again from its sender; do not repair it yourself.',
    'EMBED_NOT_DESIGNATED': 'That message has no designated extension point in the cited specification. Place the reference in a message that has one.',
    'EMBED_BINDING': 'The carrier\'s own binding does not match. For MPP, mint the challenge with the server secret; for AP2, hash the exact checkout JWT; for ERC-8183, submit the referenced receipt digest.',
    'EMBED_ECHO': 'The echoed reference differs from the advertised one. The sender changed it; obtain the original exchange again.',
    'EMBED_SIZE': 'Shrink the carrier below the documented byte, depth and item bounds.',
    'EMBED_XML': 'Pass RSL as one UTF-8 XML 1.0 document without a DOCTYPE or entity declarations, within 262144 bytes.',
    'EMBED_HEADER': 'Pass Link header field values as RFC 8288 section 3 defines them: <target>; rel="relation".',
    'EMBED_DNS': 'Pass TXT records as lists of character-strings of at most 255 bytes, or as zone presentation lines.',
    'EMBED_OPTION': 'Use only the options documented for this placement and operation, with the documented types.',
}
HAPPENED = {
    'EMBED_PROTOCOL': 'The protocol name is not one of the supported placements.',
    'EMBED_CARRIER': 'The carrier does not have the shape its specification defines.',
    'EMBED_CONFLICT': 'A different AAP reference already occupies the designated field.',
    'EMBED_ABSENT': 'No AAP reference was found in the designated field.',
    'EMBED_AMBIGUOUS': 'More than one distinct AAP reference was found.',
    'EMBED_REFUSED': 'The designated field holds a value that is not a valid AAP reference.',
    'EMBED_NOT_DESIGNATED': 'This message type has no designated extension point.',
    'EMBED_BINDING': 'The carrier\'s binding (challenge id, checkout hash or deliverable) does not match its content.',
    'EMBED_ECHO': 'An echoed copy of the reference differs from the advertised copy.',
    'EMBED_SIZE': 'The carrier exceeds a size, depth or count bound.',
    'EMBED_XML': 'The XML is malformed, declares a DOCTYPE or entities, or is too large.',
    'EMBED_HEADER': 'The Link header value is malformed or too large.',
    'EMBED_DNS': 'The TXT record set is malformed or holds a string longer than 255 bytes.',
    'EMBED_OPTION': 'An option is unknown for this operation or has the wrong type.',
}


def remediation(code):
    return GUIDANCE[code] if code in GUIDANCE else REFERENCE_REMEDIATION.get(code, aap_reference.remediation(code))


def explain(code):
    """Code, what happened, the fix, whether retrying helps and the reference entry."""
    if code in aap_reference.REMEDIATION:
        return aap_reference.explain(code)
    need(code in GUIDANCE, 'EMBED_PROTOCOL')
    return {'code': code, 'what_happened': HAPPENED[code], 'fix': GUIDANCE[code], 'retry_helps': False,
            'reference': aap_reference.REFERENCE_DOC}


# -- shared helpers

def _bounded(value):
    pending = [(value, 0)]
    nodes = 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        need(nodes <= MAX_NODES and depth <= MAX_DEPTH, 'EMBED_SIZE')
        if type(item) is dict:
            need(all(type(name) is str for name in item), 'EMBED_CARRIER')
            pending.extend((child, depth + 1) for child in item.values())
        elif type(item) is list:
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is str:
            need(len(item) <= MAX_CARRIER, 'EMBED_SIZE')
        else:
            need(item is None or type(item) in (bool, int, float), 'EMBED_CARRIER')
    return value


def _json(raw):
    try:
        return interop_codec.parse(raw, max_bytes=MAX_CARRIER, max_depth=MAX_DEPTH, max_nodes=MAX_NODES)
    except ValueError as error:
        raise ValueError('EMBED_SIZE' if str(error) in ('INTEROP_SIZE', 'INTEROP_DEPTH', 'INTEROP_COMPLEXITY')
                         else 'EMBED_CARRIER') from None


def _object(carrier):
    """A bounded deep copy of a JSON object carrier given as a dict or as JSON text."""
    value = _json(carrier) if type(carrier) in (str, bytes) else carrier
    need(type(value) is dict, 'EMBED_CARRIER')
    return deepcopy(_bounded(value))


def _ref(reference):
    return aap_reference.parse(reference)['reference']


def _compact_of(value):
    return aap_reference.encode(aap_reference.parse(value)['reference'])


def _same(existing, ref):
    """True when the field already holds this reference; a different or malformed value is a conflict."""
    if existing is None:
        return False
    try:
        same = _compact_of(existing) == aap_reference.encode(ref)
    except ValueError:
        same = False
    need(same, 'EMBED_CONFLICT')
    return True


def _map(owner, name):
    value = owner.setdefault(name, {})
    need(type(value) is dict, 'EMBED_CARRIER')
    return value


def _list(owner, name):
    value = owner.setdefault(name, [])
    need(type(value) is list and len(value) < MAX_ITEMS, 'EMBED_CARRIER')
    return value


def _rows(owner, name):
    value = owner.get(name, [])
    need(type(value) is list and len(value) <= MAX_ITEMS, 'EMBED_CARRIER')
    return value


def _host(url):
    if type(url) is not str or not url.startswith(('https://', 'http://')):
        return None
    host = re.split(r'[/?#]', url.split('://', 1)[1], maxsplit=1)[0]
    host = host.rsplit('@', 1)[-1].split(':', 1)[0].lower().rstrip('.')
    return host if re.fullmatch(r'[a-z0-9.-]{1,253}', host) else None


def _base64url_json(text, code='EMBED_CARRIER'):
    try:
        raw = interop_codec.b64url_decode(text, MAX_CARRIER)
    except ValueError:
        raise ValueError(code) from None
    return _object(raw)


# -- 1. x402 v2: the extensions map on PaymentRequired, PaymentPayload and SettlementResponse

def _x402_doc(carrier):
    if type(carrier) is str and not carrier.lstrip().startswith('{'):
        need(0 < len(carrier) <= MAX_HEADER and re.fullmatch(r'[A-Za-z0-9+/]+={0,2}', carrier) is not None, 'EMBED_CARRIER')
        try:
            raw = base64.b64decode(carrier, validate=True)
        except ValueError:
            raise ValueError('EMBED_CARRIER') from None
        return _object(raw), True
    return _object(carrier), False


def _x402_kind(doc):
    if type(doc.get('accepts')) is list:
        kind = 'PaymentRequired'
    elif type(doc.get('accepted')) is dict and type(doc.get('payload')) is dict:
        kind = 'PaymentPayload'
    elif type(doc.get('success')) is bool and 'transaction' in doc and 'network' in doc:
        return 'SettlementResponse'
    else:
        raise ValueError('EMBED_CARRIER')
    need(doc.get('x402Version') == 2, 'EMBED_CARRIER')
    return kind


def x402_header(document):
    """The base64 value of PAYMENT-REQUIRED, PAYMENT-SIGNATURE or PAYMENT-RESPONSE for an x402 v2 object."""
    doc = _object(document)
    _x402_kind(doc)
    return base64.b64encode(json.dumps(doc, separators=(',', ':'), ensure_ascii=False).encode('utf-8')).decode('ascii')


def _x402_place(carrier, ref):
    doc, header = _x402_doc(carrier)
    _x402_kind(doc)
    extensions = _map(doc, 'extensions')
    current = extensions.get(X402_KEY)
    if not _same(current.get('info') if type(current) is dict else current, ref):
        extensions[X402_KEY] = {'info': ref, 'schema': aap_reference.json_schema()}
    return x402_header(doc) if header else doc


def _x402_found(carrier):
    doc, _ = _x402_doc(carrier)
    kind = _x402_kind(doc)
    extensions = doc.get('extensions', {})
    need(type(extensions) is dict, 'EMBED_CARRIER')
    resource = doc.get('resource') if type(doc.get('resource')) is dict else {}
    context = {'message': kind, 'host': _host(resource.get('url'))}
    if X402_KEY not in extensions:
        return [], context
    entry = extensions[X402_KEY]
    return [('extensions.' + X402_KEY + '.info', entry.get('info') if type(entry) is dict else entry)], context


def _x402_checks(carrier, compact, advertised=None):
    if advertised is None:
        return {'echo': 'NOT_CHECKED'}
    found, context = _x402_found(advertised)
    need(context['message'] == 'PaymentRequired' and len(found) == 1, 'EMBED_ECHO')
    try:
        same = _compact_of(found[0][1]) == compact
    except ValueError:
        same = False
    need(same, 'EMBED_ECHO')
    return {'echo': 'MATCHES_ADVERTISED'}


# -- 2. MPP: the opaque correlation map of a Payment challenge, inside its challenge binding

def _mpp_opaque(params):
    if 'opaque' not in params:
        return {}
    try:
        raw = mpp.b64url_decode(params['opaque'], 4096)
    except ValueError:
        raise ValueError('EMBED_CARRIER') from None
    value = _object(raw)
    need(all(type(item) is str for item in value.values()) and mpp.jcs(value) == raw, 'EMBED_CARRIER')
    return value


def mpp_header(params):
    """A WWW-Authenticate value for one Payment challenge, every auth-param quoted (RFC 9110 section 11.2)."""
    need(type(params) is dict and all(type(k) is str and type(v) is str for k, v in params.items()), 'EMBED_CARRIER')
    order = ['id', 'realm', 'method', 'intent', 'header', 'expires', 'digest', 'description', 'opaque', 'request']
    names = [n for n in order if n in params] + sorted(n for n in params if n not in order)
    for name in names:
        need(TOKEN.fullmatch(name) is not None and all(32 <= ord(c) < 127 and c not in '"\\' for c in params[name]),
             'EMBED_CARRIER')
    return 'Payment ' + ', '.join('%s="%s"' % (name, params[name]) for name in names)


def _mpp_place(carrier, ref, secret=None):
    need(isinstance(secret, (bytes, bytearray)), 'EMBED_BINDING')
    need(type(carrier) is dict and all(type(k) is str and type(v) is str for k, v in carrier.items()), 'EMBED_CARRIER')
    params = {name: value for name, value in carrier.items() if name != 'id'}
    opaque = _mpp_opaque(params)
    if not _same(opaque.get(MPP_KEY), ref):
        opaque[MPP_KEY] = aap_reference.encode(ref)
    params['opaque'] = mpp.b64url(mpp.jcs(opaque))
    try:
        params['id'] = mpp.binding_id(params, bytes(secret))
        mpp.challenge(params)
    except ValueError as error:
        raise ValueError('EMBED_BINDING' if str(error).startswith('MPP_BINDING') else 'EMBED_CARRIER') from None
    return params


def _mpp_params(carrier):
    """(challenge parameters, kind) from a WWW-Authenticate value, a credential or a parameter map."""
    try:
        if type(carrier) is str:
            need(len(carrier) <= MAX_HEADER, 'EMBED_SIZE')
            credential = re.fullmatch(r'Payment ([A-Za-z0-9_-]+)', carrier.strip())
            if credential is None:
                return mpp.select(carrier)['params'], 'challenge'
            carrier = _base64url_json(credential.group(1))
        need(type(carrier) is dict, 'EMBED_CARRIER')
        if type(carrier.get('challenge')) is dict:
            echoed = carrier['challenge']
            need(all(type(k) is str and type(v) is str for k, v in echoed.items()), 'EMBED_CARRIER')
            return echoed, 'credential'
        return mpp.challenge(carrier)['params'], 'challenge'
    except ValueError as error:
        raise ValueError(str(error) if str(error) in GUIDANCE else 'EMBED_CARRIER') from None


def _mpp_found(carrier):
    params, kind = _mpp_params(carrier)
    opaque = _mpp_opaque(params)
    realm = params.get('realm')
    host = realm.lower() if type(realm) is str and re.fullmatch(r'[A-Za-z0-9.-]{1,253}', realm) else None
    return ([('opaque.' + MPP_KEY, opaque[MPP_KEY])] if MPP_KEY in opaque else []), {'message': kind, 'host': host}


def _mpp_checks(carrier, compact, secret=None, challenge=None):
    out = {'challenge_binding': 'NOT_CHECKED_SERVER_SECRET_REQUIRED', 'echo': 'NOT_CHECKED'}
    params, _ = _mpp_params(carrier)
    if secret is not None:
        need(isinstance(secret, (bytes, bytearray)), 'EMBED_OPTION')
        try:
            mpp.verify_binding({'params': params}, bytes(secret))
        except (ValueError, KeyError):
            raise ValueError('EMBED_BINDING') from None
        out['challenge_binding'] = 'VERIFIED_UNDER_SERVER_SECRET'
    if challenge is not None:
        original, _ = _mpp_params(challenge)
        need(original.get('opaque') == params.get('opaque') and original.get('id') == params.get('id'), 'EMBED_ECHO')
        out['echo'] = 'MATCHES_CHALLENGE'
    return out


# -- 3. A2A: the AgentCard extension declaration; Message, Artifact and Task metadata keyed by the URI

def _a2a_unwrap(doc):
    if 'jsonrpc' not in doc:
        return doc, ''
    if type(doc.get('params')) is dict and type(doc['params'].get('message')) is dict:
        return doc['params']['message'], 'params.message.'
    result = doc.get('result')
    need(type(result) is dict, 'EMBED_CARRIER')
    for name in ('task', 'message'):
        if type(result.get(name)) is dict:
            return result[name], 'result.' + name + '.'
    return result, 'result.'


def _a2a_kind(obj):
    if type(obj.get('capabilities')) is dict or (type(obj.get('skills')) is list and 'name' in obj):
        need(type(obj.get('capabilities', {})) is dict, 'EMBED_CARRIER')
        return 'card'
    if 'role' in obj and type(obj.get('parts')) is list:
        return 'message'
    if 'artifactId' in obj and type(obj.get('parts')) is list:
        return 'artifact'
    if type(obj.get('id')) is str and type(obj.get('status')) is dict:
        return 'task'
    raise ValueError('EMBED_CARRIER')


def _a2a_place(carrier, ref):
    doc = _object(carrier)
    obj, _ = _a2a_unwrap(doc)
    kind = _a2a_kind(obj)
    if kind == 'card':
        entries = _list(_map(obj, 'capabilities'), 'extensions')
        mine = [row for row in entries if type(row) is dict and row.get('uri') == A2A_URI]
        need(len(mine) <= 1, 'EMBED_AMBIGUOUS')
        if not mine or not _same(mine[0].get('params'), ref):
            entries.append({'uri': A2A_URI, 'description': A2A_DESCRIPTION, 'required': False, 'params': ref})
        return doc
    metadata = _map(obj, 'metadata')
    if not _same(metadata.get(A2A_URI), ref):
        metadata[A2A_URI] = ref
    if kind in ('message', 'artifact'):
        uris = _list(obj, 'extensions')
        if A2A_URI not in uris:
            uris.append(A2A_URI)
    return doc


def _a2a_found(carrier):
    doc = _object(carrier)
    obj, path = _a2a_unwrap(doc)
    kind = _a2a_kind(obj)
    if kind == 'card':
        entries = _rows(obj.get('capabilities', {}), 'extensions')
        found = [(path + 'capabilities.extensions[%d].params' % i, row.get('params'))
                 for i, row in enumerate(entries) if type(row) is dict and row.get('uri') == A2A_URI]
        interfaces = obj.get('supportedInterfaces') if type(obj.get('supportedInterfaces')) is list else []
        hosts = [_host(row.get('url')) for row in interfaces[:MAX_ITEMS] if type(row) is dict]
        return found, {'message': 'AgentCard', 'host': next((h for h in hosts if h), _host(obj.get('url')))}
    holders = [(path, obj)]
    if kind == 'task':
        if type(obj['status'].get('message')) is dict:
            holders.append((path + 'status.message.', obj['status']['message']))
        for name in ('artifacts', 'history'):
            holders += [(path + '%s[%d].' % (name, i), row) for i, row in enumerate(_rows(obj, name)) if type(row) is dict]
    found = []
    for where, holder in holders:
        metadata = holder.get('metadata')
        if type(metadata) is dict and A2A_URI in metadata:
            found.append((where + 'metadata["' + A2A_URI + '"]', metadata[A2A_URI]))
    return found, {'message': kind}


# -- 4. MCP: _meta under a vendor prefix on requests, results and tool definitions

def _mcp_holder(doc):
    if 'jsonrpc' in doc:
        if 'method' in doc:
            return _map(doc, 'params'), 'params.'
        need(type(doc.get('result')) is dict, 'EMBED_CARRIER')
        return doc['result'], 'result.'
    return doc, ''


def _mcp_place(carrier, ref):
    doc = _object(carrier)
    holder, _ = _mcp_holder(doc)
    meta = _map(holder, '_meta')
    if not _same(meta.get(MCP_KEY), ref):
        meta[MCP_KEY] = ref
    return doc


def _mcp_found(carrier):
    doc = _object(carrier)
    holder, path = _mcp_holder(doc)
    holders = [(path, holder)]
    if type(holder.get('tools')) is list:
        holders += [(path + 'tools[%d].' % i, tool) for i, tool in enumerate(_rows(holder, 'tools')) if type(tool) is dict]
    found = []
    for where, item in holders:
        meta = item.get('_meta')
        if type(meta) is dict and MCP_KEY in meta:
            found.append((where + '_meta["' + MCP_KEY + '"]', meta[MCP_KEY]))
    method = doc.get('method')
    return found, {'message': method if type(method) is str else ('result' if 'jsonrpc' in doc else 'object')}


def mcp_capability():
    """The capabilities.extensions entry that advertises the reference (MCP 2026-07-28, Extension Negotiation)."""
    return {'extensions': {MCP_KEY: {'profiles': [PROFILE]}}}


# -- 5. ACP: CheckoutSession and CheckoutSessionCreateRequest metadata

def _acp_message(message):
    need(message in ('session', 'create_request', 'update_request'), 'EMBED_OPTION')
    need(message != 'update_request', 'EMBED_NOT_DESIGNATED')


def _acp_place(carrier, ref, message='session'):
    _acp_message(message)
    doc = _object(carrier)
    need(type(doc.get('id')) is str if message == 'session' else type(doc.get('line_items')) is list, 'EMBED_CARRIER')
    metadata = _map(doc, 'metadata')
    if not _same(metadata.get(ACP_KEY), ref):
        metadata[ACP_KEY] = aap_reference.encode(ref)
    return doc


def _acp_found(carrier, message='session'):
    _acp_message(message)
    doc = _object(carrier)
    metadata = doc.get('metadata', {})
    need(type(metadata) is dict, 'EMBED_CARRIER')
    return ([('metadata.' + ACP_KEY, metadata[ACP_KEY])] if ACP_KEY in metadata else []), {'message': message}


# -- 6. UCP: a policies[] entry whose type is an AAP name in the open reverse-DNS vocabulary

def _ucp_place(carrier, ref):
    doc = _object(carrier)
    need(type(doc.get('id')) is str and type(doc.get('ucp', {})) is dict, 'EMBED_CARRIER')
    policies = _list(doc, 'policies')
    mine = [row for row in policies if type(row) is dict and row.get('type') == UCP_TYPE]
    need(len(mine) <= 1, 'EMBED_AMBIGUOUS')
    if not mine or not _same(mine[0].get(UCP_MEMBER), ref):
        policies.append({'type': UCP_TYPE, 'description': {'plain': UCP_DESCRIPTION}, UCP_MEMBER: aap_reference.encode(ref)})
    return doc


def _ucp_found(carrier):
    doc = _object(carrier)
    found = [('policies[%d].%s' % (i, UCP_MEMBER), row.get(UCP_MEMBER)) for i, row in enumerate(_rows(doc, 'policies'))
             if type(row) is dict and row.get('type') == UCP_TYPE]
    return found, {'message': 'order' if 'checkout_id' in doc else 'checkout'}


# -- 7. AP2: inside the merchant-signed Checkout Object, bound by the Checkout Mandate's checkout_hash

def ap2_checkout_hash(checkout_jwt):
    """checkout_hash of a Checkout Mandate: base64url SHA-256 of the checkout_jwt value (no _sd_alg present)."""
    need(type(checkout_jwt) is str and 0 < len(checkout_jwt) <= MAX_CARRIER and checkout_jwt.isascii(), 'EMBED_CARRIER')
    return mpp.b64url(hashlib.sha256(checkout_jwt.encode('ascii')).digest())


def _ap2_payload(carrier):
    doc = _object(carrier)
    need(doc.get('vct') == AP2_VCT and type(doc.get('checkout_jwt')) is str and type(doc.get('checkout_hash')) is str,
         'EMBED_CARRIER')
    need(doc.get('_sd_alg') in (None, 'sha-256'), 'EMBED_BINDING')
    need(ap2_checkout_hash(doc['checkout_jwt']) == doc['checkout_hash'], 'EMBED_BINDING')
    parts = doc['checkout_jwt'].split('.')
    need(len(parts) == 3, 'EMBED_CARRIER')
    return _base64url_json(parts[1])


def _ap2_place(carrier, ref, checkout='ucp'):
    need(checkout in ('ucp', 'acp'), 'EMBED_OPTION')
    return _ucp_place(carrier, ref) if checkout == 'ucp' else _acp_place(carrier, ref)


def _ap2_found(carrier):
    payload = _ap2_payload(carrier)
    found = []
    for reader in (_ucp_found, _acp_found):
        try:
            rows, _ = reader(payload)
        except ValueError:
            continue
        found += [('checkout_jwt.payload.' + where, value) for where, value in rows]
    return found, {'message': 'CheckoutMandate', 'checkout_hash': 'MATCHES_CHECKOUT_JWT',
                   'merchant_signature': 'NOT_VERIFIED_HERE'}


# -- 8. ERC-8183: the job description (a scope reference) and the submitted deliverable

def _erc8183_job(carrier):
    doc = _object(carrier)
    need(type(doc.get('description')) is str and len(doc['description']) <= MAX_DESCRIPTION and 'evaluator' in doc
         and type(doc.get('expiredAt')) is int and doc['expiredAt'] >= 0, 'EMBED_CARRIER')
    try:
        erc8004_bridge.address(doc['evaluator'])
        if doc.get('provider') is not None:
            erc8004_bridge.address(doc['provider'])
    except ValueError:
        raise ValueError('EMBED_CARRIER') from None
    return doc


def _erc8183_place(carrier, ref):
    doc = _erc8183_job(carrier)
    tokens = COMPACT_TOKEN.findall(doc['description'])
    need(len(set(tokens)) <= 1, 'EMBED_AMBIGUOUS')
    if not tokens or not _same(tokens[0], ref):
        doc['description'] = (doc['description'].rstrip() + ' ' + aap_reference.encode(ref)).strip()
        need(len(doc['description']) <= MAX_DESCRIPTION, 'EMBED_SIZE')
    return doc


def _erc8183_found(carrier):
    doc = _erc8183_job(carrier)
    return [('description', token) for token in COMPACT_TOKEN.findall(doc['description'])], {'message': 'job'}


def erc8183_deliverable(reference):
    """The bytes32 deliverable naming the referenced receipt: 0x and the receipt's SHA-256 digest."""
    ref = _ref(reference)
    need('receipt' in ref, 'REF_RECEIPT_MISMATCH')
    return '0x' + aap_reference.digest_of(ref['receipt'])


def _erc8183_checks(carrier, compact):
    doc = _object(carrier)
    if 'deliverable' not in doc:
        return {'deliverable': 'NOT_SUBMITTED'}
    ref = _ref(compact)
    need('receipt' in ref and type(doc['deliverable']) is str
         and doc['deliverable'].lower() == '0x' + aap_reference.digest_of(ref['receipt']), 'EMBED_BINDING')
    return {'deliverable': 'NAMES_REFERENCED_RECEIPT'}


# -- 9. ERC-8004: a services[] entry of the registration file; an extra member of a feedback file

def _erc8004_kind(doc):
    if doc.get('type') == ERC8004_TYPE:
        _rows(doc, 'services')
        return 'registration'
    need(all(name in doc for name in ('agentRegistry', 'agentId', 'clientAddress', 'createdAt', 'value',
                                      'valueDecimals')), 'EMBED_CARRIER')
    try:
        erc8004_bridge.registry(doc['agentRegistry'])
    except ValueError:
        raise ValueError('EMBED_CARRIER') from None
    need(type(doc['agentId']) is int and doc['agentId'] >= 0, 'EMBED_CARRIER')
    return 'feedback'


def _erc8004_place(carrier, ref):
    doc = _object(carrier)
    if _erc8004_kind(doc) == 'registration':
        services = _list(doc, 'services')
        mine = [row for row in services if type(row) is dict and row.get('name') == ERC8004_SERVICE]
        need(len(mine) <= 1, 'EMBED_AMBIGUOUS')
        if not mine or not _same(mine[0].get('endpoint'), ref):
            services.append({'name': ERC8004_SERVICE, 'endpoint': aap_reference.encode(ref), 'version': '0.1'})
    elif not _same(doc.get(ERC8004_FEEDBACK_MEMBER), ref):
        doc[ERC8004_FEEDBACK_MEMBER] = ref
    return doc


def _erc8004_found(carrier):
    doc = _object(carrier)
    if _erc8004_kind(doc) == 'registration':
        services = _rows(doc, 'services')
        found = [('services[%d].endpoint' % i, row.get('endpoint')) for i, row in enumerate(services)
                 if type(row) is dict and row.get('name') == ERC8004_SERVICE]
        hosts = [_host(row.get('endpoint')) for row in services if type(row) is dict]
        return found, {'message': 'registration', 'host': next((h for h in hosts if h), None)}
    created = doc.get('createdAt')
    day = created[:10] if type(created) is str and re.match(r'\d{4}-\d{2}-\d{2}T', created) else None
    found = [(ERC8004_FEEDBACK_MEMBER, doc[ERC8004_FEEDBACK_MEMBER])] if ERC8004_FEEDBACK_MEMBER in doc else []
    return found, {'message': 'feedback', 'day': day}


def erc8004_metadata(reference):
    """setMetadata arguments for optional on-chain metadata: key aap-ref, value the compact form as bytes. Not posted."""
    return {'metadataKey': ERC8004_METADATA_KEY, 'metadataValue': '0x' + _compact_of(reference).encode('ascii').hex(),
            'posted': False}


# -- 10. LCP: an extension member of legal-context.json (section 2.5: the field set is extensible)

def _lcp_doc(carrier):
    doc = _object(carrier)
    need(type(doc.get('terms')) is str and atr.is_https_link(doc['terms']), 'EMBED_CARRIER')
    return doc


def _lcp_place(carrier, ref):
    doc = _lcp_doc(carrier)
    if not _same(doc.get(LCP_MEMBER), ref):
        doc[LCP_MEMBER] = aap_reference.encode(ref)
    return doc


def _lcp_found(carrier):
    doc = _lcp_doc(carrier)
    return ([(LCP_MEMBER, doc[LCP_MEMBER])] if LCP_MEMBER in doc else []), {'message': 'legal-context',
                                                                           'host': _host(doc['terms'])}


def _lcp_checks(carrier, compact):
    doc = _lcp_doc(carrier)
    if atr.decode(doc.get('atrHash')) is None:
        return {'atr_hash': 'ABSENT'}
    same = atr.hash_equals(doc['atrHash'], aap_reference.atr_hash(_ref(compact)))
    return {'atr_hash': 'NAMES_THE_REFERENCED_AGREEMENT' if same else 'NAMES_ANOTHER_DOCUMENT'}


# -- 11. RSL 1.0: a foreign-namespace extension element inside <license>

def _rsl_bytes(carrier):
    need(type(carrier) in (str, bytes), 'EMBED_XML')
    raw = carrier.encode('utf-8') if type(carrier) is str else carrier
    need(0 < len(raw) <= MAX_CARRIER, 'EMBED_XML')
    lowered = raw.lower()
    need(b'<!doctype' not in lowered and b'<!entity' not in lowered, 'EMBED_XML')
    return raw


def _rsl_root(raw):
    try:
        parser = ElementTree.XMLParser(target=ElementTree.TreeBuilder(insert_comments=True, insert_pis=True))
        parser.feed(raw)
        root = parser.close()
    except (ElementTree.ParseError, ValueError):
        raise ValueError('EMBED_XML') from None
    need(root.tag == '{%s}rsl' % RSL_NAMESPACE, 'EMBED_CARRIER')
    need(sum(1 for _ in root.iter()) <= MAX_NODES, 'EMBED_SIZE')
    return root


def _rsl_licences(root, content):
    rows = []
    for item in root.findall('{%s}content' % RSL_NAMESPACE):
        if content is None or item.get('url') == content:
            rows += [(item.get('url'), index, licence)
                     for index, licence in enumerate(item.findall('{%s}license' % RSL_NAMESPACE))]
    return rows


def _rsl_end_of_first_licence(raw, content):
    """Byte offset of the end tag of the first chosen <license>, found by expat in the original bytes."""
    parser = expat.ParserCreate(namespace_separator='}')
    state = {'stack': [], 'chosen': False, 'offset': None}

    def start(name, attributes):
        state['stack'].append(name)
        if len(state['stack']) == 2 and name == RSL_NAMESPACE + '}content':
            state['chosen'] = content is None or attributes.get('url') == content

    def end(name):
        stack = state['stack']
        if (state['offset'] is None and state['chosen'] and len(stack) == 3
                and name == RSL_NAMESPACE + '}license' and stack[1] == RSL_NAMESPACE + '}content'):
            state['offset'] = parser.CurrentByteIndex
        if len(stack) == 2:
            state['chosen'] = False
        stack.pop()

    def refuse(*_):
        raise ValueError('EMBED_XML')

    parser.StartElementHandler, parser.EndElementHandler = start, end
    parser.StartDoctypeDeclHandler = parser.EntityDeclHandler = refuse
    try:
        parser.Parse(raw, True)
    except expat.ExpatError:
        raise ValueError('EMBED_XML') from None
    offset = state['offset']
    need(offset is not None and LICENCE_END.match(raw, offset) is not None, 'EMBED_CARRIER')
    return offset


def _rsl_place(carrier, ref, content=None):
    need(content is None or type(content) is str, 'EMBED_OPTION')
    raw = _rsl_bytes(carrier)
    licences = _rsl_licences(_rsl_root(raw), content)
    need(bool(licences), 'EMBED_CARRIER')
    present = licences[0][2].findall('{%s}ref' % AAP_XML_NAMESPACE)
    need(len(present) <= 1, 'EMBED_AMBIGUOUS')
    if present and _same((present[0].text or '').strip(), ref):
        return carrier
    offset = _rsl_end_of_first_licence(raw, content)
    element = ('<ref xmlns="%s">%s</ref>' % (AAP_XML_NAMESPACE, aap_reference.encode(ref))).encode('ascii')
    out = raw[:offset] + element + raw[offset:]
    _rsl_root(out)
    return out.decode('utf-8') if type(carrier) is str else out


def _rsl_found(carrier, content=None):
    need(content is None or type(content) is str, 'EMBED_OPTION')
    root = _rsl_root(_rsl_bytes(carrier))
    found = []
    for url, index, licence in _rsl_licences(root, content):
        for element in licence:
            if type(element.tag) is str and element.tag.startswith('{' + aap_reference.FAMILY):
                where = 'content[url=%s].license[%d].%s' % (url, index, element.tag)
                namespace = element.tag[1:].split('}')[0]
                found.append((where, (element.text or '').strip() if namespace == AAP_XML_NAMESPACE
                              else {'profile': namespace}))
    return found, {'message': 'rsl'}


# -- 12. HTTP: a Link header with an extension relation type (RFC 8288 sections 3 and 2.1.2)

def link_value(reference):
    return '<%s>; rel="%s"' % (_compact_of(reference), LINK_RELATION)


def parse_link(value):
    """RFC 8288 Appendix B.2, bounded: [(target, {parameter: value})]. Names are lower-cased; first wins."""
    if type(value) in (list, tuple):
        need(len(value) <= 64 and all(type(item) is str for item in value), 'EMBED_HEADER')
        value = ', '.join(value)
    need(type(value) is str and len(value) <= MAX_HEADER and value.isascii(), 'EMBED_HEADER')
    links, i, n = [], 0, len(value)
    while i < n:
        while i < n and value[i] in ' \t,':
            i += 1
        if i >= n:
            break
        need(value[i] == '<' and len(links) < 64, 'EMBED_HEADER')
        end = value.find('>', i)
        need(end > i, 'EMBED_HEADER')
        target, i, params = value[i + 1:end], end + 1, {}
        while True:
            while i < n and value[i] in ' \t':
                i += 1
            if i >= n or value[i] == ',':
                break
            need(value[i] == ';' and len(params) < 16, 'EMBED_HEADER')
            i += 1
            while i < n and value[i] in ' \t':
                i += 1
            found = TOKEN.match(value, i)
            need(found is not None, 'EMBED_HEADER')
            name, i = found.group(0).lower(), found.end()
            while i < n and value[i] in ' \t':
                i += 1
            item = ''
            if i < n and value[i] == '=':
                i += 1
                while i < n and value[i] in ' \t':
                    i += 1
                if i < n and value[i] == '"':
                    i += 1
                    chars = []
                    while i < n and value[i] != '"':
                        if value[i] == '\\' and i + 1 < n:
                            i += 1
                        chars.append(value[i])
                        i += 1
                    need(i < n, 'EMBED_HEADER')
                    i += 1
                    item = ''.join(chars)
                else:
                    found = TOKEN.match(value, i)
                    need(found is not None, 'EMBED_HEADER')
                    item, i = found.group(0), found.end()
            params.setdefault(name, item)
        links.append((target, params))
    return links


def _link_place(carrier, ref):
    need(carrier is None or type(carrier) in (str, list, tuple), 'EMBED_HEADER')
    joined = ', '.join(carrier) if type(carrier) in (list, tuple) else (carrier or '')
    found, _ = _link_found(joined) if joined.strip() else ([], {})
    need(len({value for _, value in found}) <= 1, 'EMBED_AMBIGUOUS')
    if found and _same(found[0][1], ref):
        return joined
    return (joined + ', ' if joined.strip() else '') + link_value(ref)


def _link_found(carrier, proposed=False):
    need(type(proposed) is bool, 'EMBED_OPTION')
    wanted = {LINK_RELATION} | ({PROPOSED_LINK_RELATION} if proposed else set())
    found = []
    for index, (target, params) in enumerate(parse_link(carrier)):
        relations = {item.lower() for item in params.get('rel', '').split()}
        if relations & wanted and 'anchor' not in params:
            found.append(('link[%d]' % index, target))
    return found, {'message': 'Link'}


# -- 13. DNS: one TXT character-string at the name the reference concerns (RFC 1035 sections 3.3, 3.3.14)

def _txt_strings(text):
    strings, i, n = [], 0, len(text)
    while i < n:
        if text[i] in ' \t()':
            i += 1
            continue
        if text[i] == ';':
            break
        quoted = text[i] == '"'
        i += 1 if quoted else 0
        out = bytearray()
        while i < n and ((text[i] != '"') if quoted else (text[i] not in ' \t;()')):
            if text[i] == '\\':
                need(i + 1 < n, 'EMBED_DNS')
                digits = text[i + 1:i + 4]
                if len(digits) == 3 and digits.isdigit():
                    need(int(digits) <= 255, 'EMBED_DNS')
                    out.append(int(digits))
                    i += 4
                    continue
                i += 1
            out += text[i].encode('utf-8')
            i += 1
        if quoted:
            need(i < n, 'EMBED_DNS')
            i += 1
        need(len(out) <= 255 and len(strings) < 64, 'EMBED_DNS')
        strings.append(bytes(out))
    return strings


def txt_records(presentation):
    """[(owner name or None, [character-string bytes])] from zone presentation lines (RFC 1035 section 5.1)."""
    need(type(presentation) is str and len(presentation) <= MAX_CARRIER, 'EMBED_DNS')
    lines = presentation.splitlines()
    need(len(lines) <= MAX_DNS_LINES, 'EMBED_DNS')
    records = []
    for line in lines:
        body = line.strip()
        found = TXT_TYPE.search(body) if body and not body.startswith(';') else None
        if found is None:
            continue
        owner = line.split()[0] if line[:1] not in ' \t' else None
        strings = _txt_strings(body[found.end():])
        if strings:
            records.append((owner.lower() if owner and owner.upper() not in ('IN', 'TXT') else None, strings))
    return records


def _dns_records(carrier):
    if type(carrier) is str:
        return [strings for _, strings in txt_records(carrier)]
    need(type(carrier) in (list, tuple) and len(carrier) <= MAX_DNS_LINES, 'EMBED_DNS')
    out = []
    for record in carrier:
        need(type(record) in (list, tuple) and 0 < len(record) <= 64, 'EMBED_DNS')
        strings = []
        for item in record:
            raw = item.encode('utf-8') if type(item) is str else item
            need(type(raw) in (bytes, bytearray) and len(raw) <= 255, 'EMBED_DNS')
            strings.append(bytes(raw))
        out.append(strings)
    return out


def _dns_place(carrier, ref):
    records = _dns_records(carrier if carrier is not None else [])
    found, _ = _dns_found(records)
    need(len({value for _, value in found}) <= 1, 'EMBED_AMBIGUOUS')
    if found and _same(found[0][1], ref):
        return records
    return records + [[aap_reference.encode(ref).encode('ascii')]]


def _dns_found(carrier):
    found = []
    for index, strings in enumerate(_dns_records(carrier)):
        if not b''.join(strings).startswith(aap_reference.FAMILY.encode('ascii')):
            continue
        need(len(strings) == 1, 'EMBED_DNS')
        try:
            found.append(('txt[%d]' % index, strings[0].decode('ascii')))
        except UnicodeDecodeError:
            raise ValueError('EMBED_DNS') from None
    return found, {'message': 'TXT'}


def dns_record(name, reference, ttl=3600):
    """One zone presentation line: <name> <ttl> IN TXT "<compact>"."""
    need(type(name) is str and len(name) <= 254 and re.fullmatch(r'([A-Za-z0-9_][A-Za-z0-9_-]{0,62}\.)+', name)
         is not None, 'EMBED_DNS')
    need(type(ttl) is int and 0 <= ttl <= 2**31 - 1, 'EMBED_DNS')
    return '%s %d IN TXT "%s"' % (name, ttl, _compact_of(reference))


# -- 14. schema.org: identifier as a PropertyValue whose propertyID names the profile

def _schema_nodes(doc):
    if '@graph' in doc:
        return [('@graph[%d].' % i, node) for i, node in enumerate(_rows(doc, '@graph')) if type(node) is dict]
    return [('', doc)]


def _schema_found_in(node, path):
    values = node.get('identifier')
    values = values if type(values) is list else [] if values is None else [values]
    need(len(values) <= MAX_ITEMS, 'EMBED_CARRIER')
    found = []
    for i, item in enumerate(values):
        where = path + 'identifier[%d]' % i
        if type(item) is str and item.startswith(aap_reference.FAMILY):
            found.append((where, item))
        elif type(item) is dict and item.get('propertyID') == SCHEMA_ORG_PROPERTY:
            kinds = item.get('@type')
            if kinds == 'PropertyValue' or (type(kinds) is list and 'PropertyValue' in kinds):
                found.append((where + '.value', item.get('value')))
    return found


def _schema_place(carrier, ref):
    doc = _object(carrier)
    nodes = _schema_nodes(doc)
    need(bool(nodes), 'EMBED_CARRIER')
    node = nodes[0][1]
    found = _schema_found_in(node, '')
    need(len({str(value) for _, value in found}) <= 1, 'EMBED_AMBIGUOUS')
    if found and _same(found[0][1], ref):
        return doc
    value = {'@type': 'PropertyValue', 'propertyID': SCHEMA_ORG_PROPERTY, 'value': aap_reference.encode(ref)}
    current = node.get('identifier')
    node['identifier'] = value if current is None else (current if type(current) is list else [current]) + [value]
    return doc


def _schema_found(carrier):
    doc = _object(carrier)
    found, host = [], None
    for path, node in _schema_nodes(doc):
        found += _schema_found_in(node, path)
        host = host or _host(node.get('url'))
    return found, {'message': 'JSON-LD', 'host': host}


# -- 15. OASF: a record annotation (annotations is the record's string map of additional metadata)

def _oasf_record(carrier):
    doc = _object(carrier)
    need(all(name in doc for name in ('name', 'version', 'schema_version', 'description', 'authors', 'created_at',
                                      'skills')) and doc['schema_version'] in OASF_VERSIONS, 'EMBED_CARRIER')
    annotations = doc.get('annotations', {})
    need(type(annotations) is dict and all(type(v) is str for v in annotations.values()), 'EMBED_CARRIER')
    return doc


def _oasf_place(carrier, ref):
    doc = _oasf_record(carrier)
    annotations = _map(doc, 'annotations')
    if not _same(annotations.get(OASF_KEY), ref):
        annotations[OASF_KEY] = aap_reference.encode(ref)
    return doc


def _oasf_found(carrier):
    doc = _oasf_record(carrier)
    annotations = doc.get('annotations', {})
    found = [('annotations["' + OASF_KEY + '"]', annotations[OASF_KEY])] if OASF_KEY in annotations else []
    return found, {'message': 'record', 'record_cid': oasf_cid(doc)}


# -- the table

def _row(protocol, name, spec, field, sections, form, proposed, licence, fixture, why, codec, options=None):
    place, found, checks = codec
    return {'id': protocol, 'name': name, 'spec': spec, 'field': field, 'sections': sections, 'status': 'DESIGNATED',
            'form': form, 'proposal': 'proposals/upstream/%s.md' % protocol, 'proposal_status': 'DRAFT_NOT_SUBMITTED',
            'proposed_field': proposed, 'licence': licence, 'fixture': fixture, 'why': why,
            'options': {stage: list(names) for stage, names in (options or {}).items()},
            '_place': place, '_found': found, '_checks': checks}


PLACEMENTS = (
    _row('x402', 'x402', 'x402 Protocol Version 2, specs/x402-specification-v2.md (x402-foundation/x402 at e4a0868)',
         'extensions["aap-ref"] = {info: JSON form, schema: JSON Schema} on PaymentRequired, echoed in '
         'PaymentPayload; SettlementResponse may carry it with the receipt',
         'sections 5.1.2 (Extensions object), 5.2.2, 5.3.2; not accepts[].extra, whose keys are reserved '
         '(assetTransferMethod, paymentFlow, section 6.1) or scheme-specific',
         'JSON form', 'register aap-ref as an x402 extension under specs/extensions/',
         'Apache-2.0', 'tests/fixtures/embedding/x402_payment_required.json',
         'The extensions map is namespaced by extension key and carried on challenge, payload and receipt; '
         'a client must echo the info it received.', (_x402_place, _x402_found, _x402_checks),
         {'check': ('advertised',)}),
    _row('mpp', 'MPP (the Payment HTTP authentication scheme)',
         'draft-httpauth-payment-01 (9 September 2026; tempoxyz/mpp-specs)',
         'opaque = base64url(JCS({"aap-ref": compact, ...})) on the Payment challenge, echoed in the credential',
         'section 5.1.2 opaque (server-defined correlation data, a flat string map), 5.1.2.1 challenge binding, '
         '5.2 credential echo', 'compact form', 'a documented opaque key, or an agreement parameter inside the binding',
         'IETF Trust; code components Revised BSD', 'tests/fixtures/commerce/mpp_vectors.json',
         'opaque is the server-defined slot inside the challenge binding; clients return it unchanged.',
         (_mpp_place, _mpp_found, _mpp_checks), {'place': ('secret',), 'check': ('secret', 'challenge')}),
    _row('a2a', 'A2A (Agent2Agent)', 'A2A 1.0 (a2aproject/A2A tag v1.0.1: docs/specification.md, specification/a2a.proto)',
         'AgentCard capabilities.extensions[] {uri: "urn:aap:ref:0.1", params: JSON form}; Message, Artifact and '
         'Task metadata["urn:aap:ref:0.1"] = JSON form, with the URI listed in extensions',
         'sections 4.6.1 Extension Declaration, 4.6.2 Extension Points, 3.2.5 Metadata, 3.2.6 A2A-Extensions',
         'JSON form', 'an official A2A extension for agreement references',
         'Apache-2.0', 'tests/fixtures/embedding/a2a_agent_card.json',
         'Extensions are identified by URI and put their data in metadata keyed by that URI.',
         (_a2a_place, _a2a_found, None)),
    _row('mcp', 'MCP (Model Context Protocol)',
         'MCP 2026-07-28 (modelcontextprotocol/modelcontextprotocol at 9850cae: basic/index.mdx, basic/versioning.mdx)',
         '_meta["io.github.covenant-common/aap-ref"] = JSON form on tools/call params, results and tool '
         'definitions; advertised in capabilities.extensions under the same identifier',
         'basic, General fields: _meta (key format, reserved prefixes); versioning, Extension Negotiation',
         'JSON form', 'an MCP extension (SEP) for agreement references',
         'Apache-2.0 (specification), CC-BY-4.0 (documentation)', 'tests/fixtures/embedding/mcp_tools_call.json',
         'Third-party _meta keys use their own reverse-DNS prefix whose second label is not mcp or modelcontextprotocol.',
         (_mcp_place, _mcp_found, None)),
    _row('acp', 'ACP (Agentic Commerce Protocol)',
         'ACP 2026-04-17 (agentic-commerce-protocol at 7fdd78d: spec/2026-04-17/openapi/openapi.agentic_checkout.yaml)',
         'metadata["aap_ref"] = compact on CheckoutSession and CheckoutSessionCreateRequest',
         'CheckoutSessionBase.metadata and CheckoutSessionCreateRequest.metadata ("Arbitrary metadata for merchant '
         'use", additionalProperties true); the released JSON Schema closes the top level (additionalProperties false); '
         'CheckoutSessionUpdateRequest has no metadata',
         'compact form', 'a third-party extension io.github.covenant-common.aap-ref (rfc.extensions.md section 3.6)',
         'Apache-2.0', 'tests/fixtures/commerce/acp_checkout_ready.json',
         'metadata is open; a new top-level field fails the released schema.', (_acp_place, _acp_found, None),
         {'place': ('message',), 'read': ('message',)}),
    _row('ucp', 'UCP (Universal Commerce Protocol)',
         'UCP v2026-08-25 (Universal-Commerce-Protocol/ucp: source/schemas/common/types/policy.json, '
         'shopping/checkout.json, shopping/order.json)',
         'policies[] entry {type: "io.github.covenant-common.policy.aap_ref", description: {plain}, aap_ref: compact} '
         'on checkout and order',
         'Policy: type is an open reverse-DNS vocabulary ("Businesses MAY define custom types"; "Platforms MUST '
         'tolerate unknown values"); additionalProperties true',
         'compact form', 'a well-known policy type dev.ucp.shopping.policy.agreement',
         'Apache-2.0', 'tests/fixtures/commerce/ucp_checkout.json',
         'policies is in the base schema, so it needs no negotiated capability.', (_ucp_place, _ucp_found, None)),
    _row('ap2', 'AP2 (Agent Payments Protocol)',
         'AP2 v0.2.0 (google-agentic-commerce/AP2: docs/ap2/specification.md, code/sdk/schemas/ap2/checkout_mandate.json)',
         'inside the merchant-signed Checkout Object (UCP policies[] or ACP metadata), bound by the Checkout '
         'Mandate checkout_hash and the Payment Mandate transaction_id',
         'Extension Points, Checkout Object ("AP2 is agnostic to the contents of the merchant-signed Checkout JWT"); '
         'checkout_mandate.json checkout_jwt and checkout_hash',
         'compact form', 'a Mandate Constraint type limiting a payment to one referenced agreement',
         'Apache-2.0', 'tests/fixtures/commerce/ap2_checkout.json',
         'Mandate schemas are closed; the checkout object is the designated open point and is hash-bound.',
         (_ap2_place, _ap2_found, None), {'place': ('checkout',)}),
    _row('erc-8183', 'ERC-8183 (Agentic Commerce)', 'ERC-8183 Draft (ethereum/ERCs ERCS/erc-8183.md, last changed a078cab)',
         'the job description carries the compact form as one whitespace-separated token; submit(jobId, '
         'deliverable) names the receipt digest as bytes32',
         'Job Data (description: "e.g. job brief, scope reference"); Core Functions (deliverable: "a reference to '
         'submitted work")', 'compact form', 'an optional agreementRef (bytes32) set at createJob and emitted in JobCreated',
         'CC0-1.0', 'tests/fixtures/embedding/erc8183_job.json',
         'description is the creation-time scope reference; deliverable is a 32-byte reference.',
         (_erc8183_place, _erc8183_found, _erc8183_checks)),
    _row('erc-8004', 'ERC-8004 (Trustless Agents)', 'ERC-8004 Draft (ethereum/ERCs ERCS/erc-8004.md, last changed 503591a)',
         'registration file services[] {name: "AAP", endpoint: compact, version: "0.1"}; feedback file member '
         '"aap" = JSON form naming the receipt; optional on-chain metadata key aap-ref',
         'Agent Registration File ("The number and type of endpoints are fully customizable"); Off-Chain Feedback '
         'File Structure (other fields MAY appear); On-chain metadata (agentWallet is reserved)',
         'compact form (registration), JSON form (feedback)', 'a registered AAP service name and feedback member',
         'CC0-1.0', 'tests/fixtures/embedding/erc8004_registration.json',
         'Services are customizable and feedback files admit other fields.', (_erc8004_place, _erc8004_found, None)),
    _row('lcp', 'LCP (Legal Context Protocol)',
         'LCP 1.0 (legal-context-protocol at c8df26d: spec/legal-context-protocol-v1.md; @integraledger/lcp 0.5.0 current)',
         'legal-context.json member "aapRef" = compact',
         'section 2.5: "The field set is extensible. Implementations SHOULD ignore fields they do not recognize."',
         'compact form', 'a registered optional field agreementRef beside atrHash',
         'Apache-2.0', 'third_party/integraledger-lcp/examples/level-2-provable.json',
         'LCP readers ignore an extra member; atrHash and the reference name the same bytes when the ATR is the agreement.',
         (_lcp_place, _lcp_found, _lcp_checks)),
    _row('rsl', 'RSL (Really Simple Licensing)', 'RSL 1.0 (RSL-SPEC-1.0, Recommendation, 2025-12-10)',
         '<ref xmlns="urn:aap:ref:0.1">compact</ref> as an extension element inside <license>',
         'section 1.2 Scope and Extensibility: elements from other namespaces are extensions, ignored when '
         'unrecognised, and must not change RSL meaning',
         'compact form', 'an RSL extension profile for agreement references',
         'CC BY-ND 4.0 (specification text; no example text is copied)', 'tests/fixtures/embedding/rsl_license.xml',
         'Foreign-namespace elements are the designated extension and never change license evaluation.',
         (_rsl_place, _rsl_found, None), {'place': ('content',), 'read': ('content',)}),
    _row('http-link', 'HTTP Link header', 'RFC 8288 (Web Linking)',
         'Link: <compact>; rel="https://covenant-common.github.io/covenant-docs/rel/agreement"',
         'section 3 (Link header), 3.1 target, 3.3 relation types, 2.1.2 extension relation types; links with an '
         'anchor are ignored (section 3.2)', 'compact form',
         'register the relation type agreement (section 2.1.1.1; Specification Required, Expert Review)',
         'IETF Trust', 'tests/fixtures/embedding/http_link.txt',
         'An extension relation type is a URI under the definer\'s control and needs no registration.',
         (_link_place, _link_found, None), {'read': ('proposed',)}),
    _row('dns', 'DNS TXT', 'RFC 1035 sections 3.3 and 3.3.14; RFC 8552 for the proposed _aap name',
         'one TXT character-string holding the compact form, at the name the reference concerns; one per name',
         'RFC 1035 section 3.3 (a character-string is at most 255 octets) and 3.3.14 (TXT semantics depend on the '
         'name where it is found)', 'compact form',
         'register the underscored node name _aap for TXT (RFC 8552 section 4.1, Expert Review)',
         'IETF Trust', 'tests/fixtures/embedding/dns_zone.txt',
         'A domain owner defines TXT semantics at its own names; the compact form fits one character-string.',
         (_dns_place, _dns_found, None)),
    _row('schema-org', 'schema.org JSON-LD', 'schema.org v30.1 (2026-09-15)',
         'identifier: {"@type": "PropertyValue", "propertyID": "urn:aap:ref:0.1", "value": compact}',
         'identifier (domain Thing; range PropertyValue, Text, URL); PropertyValue.propertyID ("a URL indicating '
         'the type of the property" or a prefixed string)', 'compact form',
         'a property agreement on Order, Invoice, Offer, Demand, Service and TradeAction',
         'CC BY-SA 3.0 (vocabulary); Apache-2.0 (repository)', 'tests/fixtures/embedding/schema_org_order.json',
         'identifier applies to every Thing and admits a typed property value.', (_schema_place, _schema_found, None)),
    _row('oasf', 'OASF (Open Agentic Schema Framework)',
         'OASF v1.1.0 (agntcy/oasf: schema/objects/record.json, schema/dictionary.json)',
         'record annotations["io.github.covenant-common/aap-ref"] = compact',
         'record.annotations: "Additional metadata associated with this record" (typed_map_t of string_t)',
         'compact form', 'an OASF module integration/aap (modules are a registered class family)',
         'Apache-2.0', 'tests/fixtures/identity_discovery/oasf_record_100.json',
         'annotations is the record\'s free-form string map; a module would need registration first.',
         (_oasf_place, _oasf_found, None)),
)
BY_ID = {row['id']: row for row in PLACEMENTS}


def placements():
    """The public table: one row per protocol, without the codec functions."""
    return [{name: deepcopy(value) for name, value in row.items() if not name.startswith('_')} for row in PLACEMENTS]


def _placement(protocol):
    need(type(protocol) is str and protocol in BY_ID, 'EMBED_PROTOCOL')
    return BY_ID[protocol]


def _accept(row, stage, options):
    allowed = set(row['options'].get(stage, ()))
    need(set(options) <= allowed, 'EMBED_OPTION')
    return dict(options)


def place(protocol, carrier, reference, **options):
    """A new carrier with the reference in the protocol's designated field. The input is never mutated."""
    row = _placement(protocol)
    return row['_place'](carrier, _ref(reference), **_accept(row, 'place', options))


def _read(rows):
    good, unsupported, refused = [], [], []
    for location, raw in rows:
        try:
            read = aap_reference.parse(raw)
        except ValueError as error:
            (unsupported if str(error) == 'REF_PROFILE' else refused).append({'location': location, 'code': str(error)})
            continue
        good.append({'location': location, 'reference': aap_reference.encode(read['reference']),
                     'ignored': read['ignored']})
    return good, unsupported, refused


def extract(protocol, carrier, **options):
    """Read the designated field only; everything else in the carrier is inert."""
    row = _placement(protocol)
    rows, context = row['_found'](carrier, **_accept(row, 'read', options))
    good, unsupported, refused = _read(rows)
    distinct = sorted({item['reference'] for item in good})
    return {'protocol': protocol, 'field': row['field'], 'status': row['status'], 'found': good,
            'distinct': distinct, 'reference': distinct[0] if len(distinct) == 1 else None,
            'unsupported': unsupported, 'refused': refused, 'context': context,
            'inert': 'EVERYTHING_OUTSIDE_THE_DESIGNATED_FIELD', 'version': VERSION, **FLAGS}


def verify(protocol, carrier, *, agreement=None, receipt=None, keys=None, require_signature=False, **options):
    """Exactly one reference from the carrier, checked against what the caller holds and the carrier's own binding."""
    row = _placement(protocol)
    read_names = set(row['options'].get('read', ()))
    check_names = set(row['options'].get('check', ()))
    need(set(options) <= read_names | check_names, 'EMBED_OPTION')
    result = extract(protocol, carrier, **{k: v for k, v in options.items() if k in read_names})
    need(not result['refused'], 'EMBED_REFUSED')
    need(bool(result['distinct']), 'EMBED_ABSENT')
    need(len(result['distinct']) == 1, 'EMBED_AMBIGUOUS')
    report = aap_reference.verify(result['reference'], agreement=agreement, receipt=receipt, keys=keys,
                                  require_signature=require_signature)
    checks = {}
    if row['_checks'] is not None:
        checks = row['_checks'](carrier, result['reference'], **{k: v for k, v in options.items() if k in check_names})
    report['ignored'] = sorted({name for item in result['found'] for name in item['ignored']})
    return {**report, 'protocol': protocol, 'field': row['field'], 'locations': [i['location'] for i in result['found']],
            'carrier_checks': {**result['context'], **checks}, 'unsupported': result['unsupported'],
            'placement_status': row['status'], 'version': VERSION}


def describe():
    return {'module': 'covenant_chain.embedding_points', 'version': VERSION, 'maturity': MATURITY,
            'reference_profile': PROFILE, 'job': 'Keep records: show, export, verify',
            'placements': placements(), 'errors': {code: explain(code) for code in GUIDANCE},
            'boundary': 'A placed reference is evidence. It never signs, pays, releases escrow, installs a connector, '
                        'fetches a locator or contacts anyone.', **FLAGS}


TEXT_CARRIERS = ('rsl', 'http-link', 'dns', 'mpp')


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_chain.embedding_points',
                                     description='Read the AAP reference a carrier holds in its designated field.')
    parser.add_argument('protocol', nargs='?', choices=sorted(BY_ID))
    parser.add_argument('carrier', nargs='?', help='path of the carrier document (JSON, XML, header or zone text)')
    parser.add_argument('--agreement', help='path of the exact agreement bytes to compare')
    parser.add_argument('--describe', action='store_true', help='print the placement table and error guide')
    args = parser.parse_args(argv)
    try:
        if args.describe or args.protocol is None:
            result = describe()
        else:
            need(args.carrier is not None, 'EMBED_CARRIER')
            with open(args.carrier, 'rb') as handle:
                raw = handle.read(MAX_CARRIER + 1)
            need(len(raw) <= MAX_CARRIER, 'EMBED_SIZE')
            carrier = raw.decode('utf-8') if args.protocol in TEXT_CARRIERS else _json(raw)
            agreement = None
            if args.agreement:
                with open(args.agreement, 'rb') as handle:
                    agreement = handle.read(aap_reference.MAX_RECORD + 1)
            result = verify(args.protocol, carrier, agreement=agreement) if agreement is not None \
                else extract(args.protocol, carrier)
    except (ValueError, OSError, UnicodeError) as error:
        code = str(error) if str(error) in GUIDANCE or str(error) in aap_reference.REMEDIATION else 'EMBED_CARRIER'
        print(json.dumps({'status': 'REFUSED', **explain(code)}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
