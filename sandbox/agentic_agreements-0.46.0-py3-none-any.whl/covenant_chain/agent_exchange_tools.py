"""Agent-facing composition of discourse, mechanisms, proofs and payment plans."""
from copy import deepcopy
from covenant_language import economic_games as games,contracts,market_blueprints
from covenant_language.market_design import bid_commitment,reveal_matches,aggregate_forecasts
from .cooperation_interface import schema,tool,HASH,INT,TEXT,OBJECT
from .agent_tools import _fields,bound_call,validate_json
from .crypto import need,integer,key
from .proof_facility import ProofRegistry,pack as pack_proof,inspect as inspect_proof,commitment
from .payment_rails import quote_fee,token_benefits,validate_fees
from .adapters import manifest_id

from .tool_input import validate_schema
from .social_tool_shapes import FORUM,ROLE,ARBITRATION

def _with_read(actions):
    """A parameter-free describe action is the first sample an agent can call."""
    if any(row[0] == 'describe' for row in actions):
        return actions
    return [('describe', {}, ())] + list(actions)


def _assign_shape():
    """covenant_credit.assign_preview: the receivable-sale preview, behind the factoring host flag."""
    from .settlement_plugins.tools import ASSIGN
    return deepcopy(ASSIGN)


def action_schema(actions):
    return {'type':'object','oneOf':[schema({'action':{'const':name},'parameters':schema(properties,required)},('action','parameters'))
        for name,properties,required in actions]}


def _navigation_specs():
    """Read-only drafting and navigation. Qualifiers live on the catalogue ids."""
    sentence = {'type': 'string', 'minLength': 1, 'maxLength': 2000}
    short = {'type': 'string', 'minLength': 1, 'maxLength': 80}
    party = {'type': 'string', 'minLength': 1, 'maxLength': 400}
    return [
        ('covenant_find', 'Find tasks by ordinary words; task_routes lead to covenant_onboard guide. Other matches use chain:, language:, network: or tool: ids. Suggestions grant no authority.', True, [
            ('search', {'query': {**sentence, 'maxLength': 400}}, ('query',))]),
        ('covenant_explain', 'Describe one qualified action id. A bare name that exists in two families is returned as ambiguous. A tool: id also returns its exact nested parameters_schema; credit/legal ids add a runnable synthetic example. The MCP host additionally returns the exact installed schema and covenant_call template for tools and actions.', True, [
            ('action', {'id': {'type': 'string', 'minLength': 1, 'maxLength': 120}}, ('id',))]),
        ('covenant_draft', 'Turn one sentence into a draft and compile it onto the human agreement, external draft, studio charter and concept modules. No model is called.', True, [
            ('sentence', {'text': sentence, 'as_of': {'type': 'string', 'minLength': 10, 'maxLength': 10}, 'template': short}, ('text',))]),
        ('covenant_lint', 'Lint a draft for a missing deadline, no referee, unbounded liability, ambiguity, conflicting clauses or an unreachable state.', True, [
            ('check', {'document': OBJECT}, ('document',))]),
        ('covenant_simulate', 'Show who is paid if the work is delivered, late, disputed, or the referee stays silent. No funds move.', True, [
            ('run', {'document': OBJECT}, ('document',))]),
        ('covenant_counter', 'Counter a draft. The diff and the new terms hash are a new version of the same compiled records.', True, [
            ('propose', {'document': OBJECT, 'changes': OBJECT, 'party': party}, ('document', 'changes', 'party'))]),
    ]


def _navigation_call(name, parameters):
    """Dispatch the drafting tools. Imports stay local so the catalog can load alone."""
    if name == 'covenant_find':
        from covenant_agent.navigate import find
        return find(parameters['query'])
    if name == 'covenant_explain':
        from covenant_agent.navigate import explain
        return explain(parameters['id'])
    from covenant_agent.drafting import counter, draft, lint, simulate
    if name == 'covenant_draft':
        return draft(parameters['text'], as_of=parameters.get('as_of'), template=parameters.get('template'))
    if name == 'covenant_lint':
        return lint(parameters['document'])
    if name == 'covenant_simulate':
        return simulate(parameters['document'])
    return counter(parameters['document'], parameters['changes'], party=parameters['party'])


def _feedback_specs():
    """Read-only report, dashboard, and issue template. Storage stays on the owner inbox."""
    note = {'type': 'string', 'minLength': 1, 'maxLength': 4000}
    kind = {'enum': ['bug', 'friction', 'feature request', 'feature_request', 'docs', 'security', 'abuse']}
    fields = {
        'category': kind,
        'severity': {'enum': ['low', 'medium', 'high', 'critical']},
        'tool': {'type': 'string', 'minLength': 1, 'maxLength': 80},
        'text': note,
        'steps': note,
        'reference': {'type': 'string', 'pattern': '^[0-9a-f]{64}$'},
        'agent': {'type': 'string', 'minLength': 1, 'maxLength': 80},
    }
    required = ('category', 'severity', 'tool', 'text')
    return [('covenant_feedback',
             'Redact and describe a bug, friction, feature, docs, security, or abuse report. The public dashboard omits security and abuse text. Nothing is filed to GitHub and nothing is paid.',
             True, [
                 ('report', fields, required),
                 ('issue', fields, required),
                 ('dashboard', {}, ()),
             ])]


def _feedback_call(action, parameters):
    from .feedback_intake import aggregate, compose, issue_template, share
    if action == 'dashboard':
        return aggregate([])
    made = share(compose(**parameters))
    if action == 'report':
        return made
    return issue_template(made)

class ExchangeTools:
    def __init__(self,*,network=None,workflow=None,markets=None,fee_policy=None,proofs=None,privacy=None,mechanisms=None,access_desks=(),identity_desks=(),reviewer_acceptances=(),applications=None,adapters=None,builders=None,local_keys=None,evidence_signer=None,board=None,requests=None,plugins=None,settlement_flags=None,crawl_licensing=None,agora_peer=None,navigation=None,discovery_index=None):
        self.network=network;self.workflow=workflow;self.markets=markets;self.fee_policy=deepcopy(fee_policy)
        self.evidence_signer=evidence_signer;self.board=board
        self.requests=requests
        self.agora_peer=agora_peer
        self.navigation=navigation
        self.discovery_index=discovery_index
        if discovery_index is not None:
            from .scalable_discovery import DiscoveryIndex
            need(isinstance(discovery_index,DiscoveryIndex),'HOST_DISCOVERY_INDEX')
        # Optional settlement plugins stay off unless the host owner passed flags.
        from .settlement_plugins.flags import HostFlags
        need(settlement_flags is None or isinstance(settlement_flags,HostFlags),'SETTLEMENT_FLAGS')
        self.settlement_flags=settlement_flags if settlement_flags is not None else HostFlags()
        need(adapters is None or workflow is None or adapters is workflow.adapters,'EXCHANGE_ADAPTER_REGISTRY_MISMATCH')
        self._read_adapters=adapters
        if fee_policy is not None:validate_fees(fee_policy)
        self.proofs=proofs or ProofRegistry()
        from .privacy_scopes import PrivacyDesk
        self.privacy=privacy or PrivacyDesk()
        from .mechanism_runtime import MechanismRegistry
        if applications is not None:
            need(mechanisms is None or mechanisms is applications.mechanisms,'APPLICATION_MECHANISM_REGISTRY_MISMATCH')
            mechanisms=applications.mechanisms
        if builders is not None:
            need(applications is None or applications is builders.applications,'BUILDER_APPLICATION_REGISTRY_MISMATCH')
            applications=builders.applications
            need(mechanisms is None or mechanisms is applications.mechanisms,'APPLICATION_MECHANISM_REGISTRY_MISMATCH')
            mechanisms=applications.mechanisms
        self.applications=applications
        self.builders=builders
        self.mechanisms=mechanisms if mechanisms is not None else MechanismRegistry(self.privacy.keys,self.proofs)
        self.access_desks={}
        for desk in access_desks:
            ref=desk.install(self.mechanisms);self.access_desks[ref]=desk
        self.identity_desks={}
        for desk in identity_desks:
            for provider in desk.entries:
                ref=desk.install(self.mechanisms,provider);self.identity_desks[ref]=(desk,provider)
        self.reviewer_acceptances=deepcopy(list(reviewer_acceptances))
        self.local_keys=local_keys
        # Optional legal-evidence plugins (experimental): owner flags, keys and pins, all off by default.
        from .host_flags import host_plugins
        self.plugins=host_plugins(plugins)
        if crawl_licensing is not None:
            from .crawl_licensing import CrawlLicenceDesk
            need(isinstance(crawl_licensing,CrawlLicenceDesk),'CRAWL_OWNER_DESK')
        self.crawl_licensing=crawl_licensing
    @property
    def adapters(self):
        """Owner-installed read interfaces do not imply a certified workflow."""
        return self.workflow.adapters if self.workflow is not None else self._read_adapters
    def _agreement_owner_status(self,packet):
        from covenant_language.mechanism_plans import canonical
        def item(value,name):return value.get(name) if type(value) is dict else None
        job=item(item(packet,'terms'),'job');payment=item(item(job,'payment'),'adapter');provider_pin=item(item(job,'identity'),'provider');payments={};providers={}
        if self.adapters is not None and payment is not None:
            try:
                adapter=self.adapters.get(payment);m=adapter.manifest
                if m['capability'] in ('payment.transfer','payment.escrow'):payments[payment]={'name':m['name'],'capability':m['capability'],'scope':'LOCAL_DEMO_ONLY' if 'LOCAL_DISPOSABLE' in m['requirements'].get('resources','') else 'OWNER_INSTALLED'}
            except ValueError:pass
        for desk,provider in self.identity_desks.values():
            if provider!=provider_pin:continue
            try:desk._fresh();m,_=desk._provider(provider)
            except ValueError:continue
            providers[provider]={'name':m['name'],'scope':'OFFLINE_VERIFIER_ONLY'}
        acceptances=[deepcopy(row) for row in self.reviewer_acceptances if type(row) is dict and row.get('context')==item(packet,'context') and row.get('procedure')==item(item(job,'dispute'),'procedure') and canonical(row.get('reviewer'))==canonical(item(item(job,'dispute'),'reviewer'))]
        return {'payment_adapters':payments,'identity_providers':providers,'reviewer_acceptances':acceptances[:64]}
    def describe(self):
        from .crypto import digest
        return {'tools':[t['name'] for t in self.tools()],
            'forum_domain':self.network.domain if self.network else None,
            'local_forum_actor':self.network.actor if self.network else None,
            'admitted_forum_peers':len(self.network.peers) if self.network else 0,
            'native_wagers_enabled':self.markets is not None,
            'posted_fee_policy':digest('COVENANT-NETWORK-FEE-0.1',self.fee_policy) if self.fee_policy else None,
            'proof_verifiers':self.proofs.describe(),'mechanisms':self.mechanisms.describe(),
            'developer_applications_enabled':self.applications is not None,
            'builder_programmes_enabled':self.builders is not None,
            'private_saved_requests_enabled':self.requests is not None,
            'access_policies':{ref:deepcopy(desk.policy) for ref,desk in self.access_desks.items()},
            'start_by_purpose':{'one_review':'covenant_review.start FOR_ANY_EXACT_SOURCE THEN role assent AND review; existing packets can use case directly','flexible_private_or_public_steps':'covenant_mechanism.templates THEN prepare_step AND plan AND exact controller assent','desired_mechanism_or_any_object':'covenant_desire.search WITH_QUERY_REQUIREMENTS_CONTEXT_AND_ADOPTED_SEEDS','credit':'covenant_credit.create THEN assent AND workflow approvals',
                'arbitrary_market':'covenant_marketplace.market THEN listing OR use_archetype','simple_trade':'covenant_marketplace.quick_trade WITH_EXPLICIT_PARTIES_AND_CONTEXT','arbitrary_proof':'covenant_proof.pack THEN exact installed verifier',
                'negotiate_contract':'covenant_contract.draft THEN compare changes AND exact assent',
                'define_context':'covenant_frame.dimensions THEN slot AND draft',
                'simple_agreement':'covenant_concept.simple WITH_TERMS_AND_PARTIES THEN prepare',
                'externally_authored_draft':'covenant_external_draft.pack ANY_EXACT_BYTES THEN prepare AND explicit all-role assent; open_boundary checks legacy source bytes',
                'human_work_agreement':'covenant_agreement.prepare THEN review AND optional private_copy; checkout_repair requires client and freelancer role keys',
                'compose_agreement':'covenant_concept.spec THEN draft AND resolve AND assent_payload',
                'build_application':'covenant_developer.scaffold OR draft THEN publisher signature AND owner installation; prepare exact call and assent',
                'earn_as_builder':'covenant_builder.spec THEN draft; owner adopts signed programme, quote complete price, obtain exact assent, deliver, accept and prepare settlement',
                'standards_integration':'covenant_standards.blueprints THEN draft AND inspect; selected source and advertised capability are not verified authority',
                'mathematical_structure':'covenant_permutation.spec OR covenant_concept.pack_math WITH_EXACT_SEMANTICS',
                'discover':'covenant_discovery.search WITH_CONTEXT_IF_NETWORK_CONFIGURED',
                'first_covenant':'covenant_onboard.start THEN preview; identity evidence and sharing are optional. Owner adopts signing custody separately; BIND is native and unsent',
                'share_receipt':'covenant_growth.card OPT_IN_ONLY; clicks are not paid',
                'find_an_agent':'covenant_directory.search THEN covenant_directory.draft; profiles are signed documents and reputation is a view',
                'offline_trust_check':'covenant_portable_trust.verify_trust_bundle OR verify_atr, verify_causal_receipt, verify_opencovenant_receipt WITH_PINNED_SIGNERS; covenant_credential.verify AND covenant_portable_trust.local_reputation; offline, no credentials',
                'save_a_need':'covenant_request_write.create THEN append PROPOSAL AND compare AND explicit SELECT; prepare exact external agreement separately',
                'find_a_service':'covenant_request.local_catalog OR catalog THEN search; cached metadata and contextual scores are not authority',
                'reusable_protocol':'covenant_agora.pack THEN request AND observe with retained pins; execution uses owner-adopted connector',
                'let_agents_decide':'covenant_decision.prepare_method THEN exact party adoption AND scoped decider result signatures; fixed terms and owner execution authority remain separate',
                'optional_identity':'covenant_credential.profile OR covenant_signin.profile; provider trust, disclosure and custody require separate owner choices',
                'shared_directory':'covenant_directory.search READS_THE_SHARED_BOARD; covenant_directory_write.sign OR accept A_CALLER_SIGNED_PROFILE',
                'a2a':'covenant_a2a.installed DEFAULT_LOOPBACK_ADAPTER_DOES_NOT_DIAL'},
            'automatic_assent':False,'external_payment_connectors':'OWNER_INSTALLATION_REQUIRED'}
    def tools(self):
        arr={'type':'array','maxItems':128};boolean={'type':'boolean'}
        asset_text={'type':'string','minLength':1,'maxLength':256}
        asset_shape=schema({'namespace':asset_text,'identifier':asset_text,'unit':asset_text,'adapter':{**HASH,'type':['string','null']},'transfer_terms':OBJECT},('namespace','identifier','unit'))
        asset_shape['description']='Named resource; adapter and transfer_terms default to null and {}. Naming never proves title, custody or transfer.'
        leg_shape={'type':'array','maxItems':16,'items':schema({'asset':asset_shape,'amount':{'type':'integer','minimum':1,'maximum':2**53-1}},('asset','amount'))}
        bidder_shape={'type':'string','minLength':1,'maxLength':128}
        bid_shape=schema({'bidder':bidder_shape,'value':INT},('bidder','value'))
        concept_approval=schema({'concept':HASH,'party':{'type':'string','minLength':1,'maxLength':80,'pattern':'^[A-Za-z][A-Za-z0-9_.:-]{0,79}$','description':'Exact role name from prepared.assent_payload.required_assents, such as buyer or seller; this is not the public key.'},'signature':{'description':'Signature over required_assents[i].body using assent_payload.label and required_assents[i].identity.'}},('concept','party','signature'))
        auction_rules=schema({'mode':{'enum':['FIRST_PRICE','SECOND_PRICE','UNIFORM_PRICE','POSTED_PRICE']},'side':{'enum':['BUY','SELL']},'reserve':INT,'quantity':{'type':'integer','minimum':1,'maximum':256},'tie_seed':bidder_shape,'eligible':{'type':'array','minItems':1,'maxItems':64,'items':bidder_shape},'unit':bidder_shape,'terms':{'type':'string','minLength':1,'maxLength':4096}},('mode','side','reserve','quantity','tie_seed','eligible','unit','terms'))
        auction_rules['description']='Exact auction terms. BUY means lower asks win and reserve is the maximum payment; SELL means higher bids win and reserve is a floor. SECOND_PRICE requires quantity=1. tie_seed is declared before bidding; no clock, bidder independence, funding or award authority is inferred.'
        intent_text = {'type':'string','minLength':1,'maxLength':4096,'description':'At most 4096 UTF-8 bytes; criteria are limited to 2048 bytes.'}
        intent_request = schema({'version':{'const':'covenant-intent-market/0.1'},'kind':{'const':'REQUEST'},'sponsor':HASH,'objective':intent_text,'asset':asset_shape,'maximum_price':INT,'bid_deadline':INT,'deliver_by':INT,'criteria':{'type':'array','minItems':1,'maxItems':32,'items':{**intent_text,'maxLength':2048}},'context':HASH,'privacy':{'enum':['PRIVATE','PUBLIC_OPT_IN']},'procedure':schema({k:intent_text for k in ('acceptance','dispute','cancellation','selection')},('acceptance','dispute','cancellation','selection'))},('version','kind','sponsor','objective','asset','maximum_price','bid_deadline','deliver_by','criteria','context','privacy','procedure'))
        intent_bid = schema({'version':{'const':'covenant-intent-market/0.1'},'kind':{'const':'BID'},'request':HASH,'solver':HASH,'price':INT,'deliver_by':INT,'proposal':intent_text,'evidence':{'type':'array','maxItems':32,'items':HASH}},('version','kind','request','solver','price','deliver_by','proposal','evidence'))
        create_intent = {k:v for k,v in intent_request['properties'].items() if k not in ('version','kind')}
        specs=_navigation_specs()+_feedback_specs()+[
          ('covenant_intent_market','Post a problem as an unsigned private draft, collect solver quotes and prepare the chosen exact order for separate party signatures. Local calculations; no provider, blockchain, discovery service, submission-time enforcement, publication or payment. Inspect snapshots before trusting claims.',True,[
            ('create',create_intent,tuple(k for k in create_intent if k!='privacy')),
            ('bid',{'request':intent_request,'solver':HASH,'price':INT,'deliver_by':INT,'proposal':intent_text,'evidence':{'type':'array','maxItems':32,'items':HASH}},('request','solver','price','deliver_by','proposal')),
            ('inspect',{'record':{'oneOf':[intent_request,intent_bid]}},('record',)),
            ('compare',{'request':intent_request,'bids':{'type':'array','maxItems':256,'items':intent_bid},'expected_request':HASH,'as_of':INT},('request','bids','expected_request','as_of')),
            ('prepare',{'request':intent_request,'quote':intent_bid,'expected_request':HASH,'expected_bid':HASH,'as_of':INT,'selection_reason':intent_text},('request','quote','expected_request','expected_bid','as_of','selection_reason'))]),
          ('covenant_auction','Define immutable auction rules, calculate allocations and seal/reveal bids. Allocation is a proposal; funding and close-time enforcement require separately adopted execution.',True,[
            ('create',{'name':bidder_shape,'purpose':TEXT,'rules':auction_rules},('name','purpose','rules')),
            ('allocate',{'spec':OBJECT,'bids':{'type':'array','maxItems':64,'items':bid_shape}},('spec','bids')),
            ('commit_bid',{'market_id':bidder_shape,'bid':bid_shape,'salt':{'type':'string','minLength':32,'maxLength':256}},('market_id','bid','salt')),
            ('check_reveal',{'commitment':{'type':'string'},'market_id':bidder_shape,'bid':bid_shape,'salt':{'type':'string','minLength':32,'maxLength':256}},('commitment','market_id','bid','salt'))]),
          ('covenant_game','Define finite payoff tables or preserve arbitrary rule systems. Analyze pure Nash equilibria and profitable unilateral deviations; no automatic settlement.',True,[
            ('create',{'kind':{'enum':['NORMAL_FORM','CUSTOM_RULES']},'name':TEXT,'purpose':TEXT,'rules':OBJECT},('kind','name','purpose','rules')),
            ('analyze',{'spec':OBJECT},('spec',)),('play',{'spec':OBJECT,'actions':arr},('spec','actions'))]),
          ('covenant_contract','Draft arbitrary clauses, preserve amendment ancestry, compare exact changes, and render an escaped HTML draft. Never supplies assent.',True,[
            ('draft',{'title':TEXT,'parties':{'type':'array','maxItems':64,'items':{'type':'string','minLength':1,'maxLength':128}},'clauses':{'type':'array','maxItems':128,'items':schema({'id':{'type':'string','minLength':1,'maxLength':80},'title':{'type':'string','maxLength':256},'text':{'type':'string','maxLength':16000}},('id','title','text'))},'conditions':arr,'settlement':OBJECT,'dispute':OBJECT,'extensions':OBJECT},('title','parties','clauses')),
            ('inspect',{'body':OBJECT},('body',)),('amend',{'body':OBJECT,'changes':OBJECT},('body','changes')),
            ('compare',{'before':OBJECT,'after':OBJECT},('before','after')),('render',{'body':OBJECT},('body',))]),
          ('covenant_credit','Define exact term credit in the token or any named adapter asset; inspect cashflows and collateral assumptions. Actual local disposable loans require the installed payment adapter and both exact party signatures.',True,[
            ('create',{'name':TEXT,'assets':arr,'participants':arr,'rules':OBJECT,'settlement':OBJECT,'proof_requirements':arr,'extensions':OBJECT},('name','assets','participants','rules','settlement')),
            ('inspect',{'spec':OBJECT},('spec',)),('preview_cost',{'adapter':HASH,'spec':OBJECT,'repayments':{'type':'array','minItems':1,'maxItems':128,'items':{'type':'integer','minimum':1,'maximum':2**53-1}}},('adapter','spec')),('assent',{'adapter':HASH,'spec':OBJECT,'maximum_fee':INT},('adapter','spec','maximum_fee')),('observe_local',{'adapter':HASH,'loan':HASH,'height':INT},('adapter','loan')),
            ('assign_preview',_assign_shape(),('face','price','variant','rail'))]),
          ('covenant_market_blueprint','Describe arbitrary market mechanisms, asset adapters, settlement and proof requirements. Unknown rules remain portable data; external atomicity is never inferred.',True,[
            ('asset',{'namespace':TEXT,'identifier':TEXT,'unit':TEXT,'adapter':HASH,'transfer_terms':OBJECT},('namespace','identifier','unit')),
            ('create',{'kind':TEXT,'name':TEXT,'assets':arr,'participants':arr,'rules':OBJECT,'settlement':OBJECT,'proof_requirements':arr,'extensions':OBJECT},('kind','name','assets','participants','rules','settlement')),
            ('inspect',{'spec':OBJECT},('spec',))]),
          ('covenant_proof','Pack any proof system; verify only with an exact installed verifier and expected statement/context. Built-ins: salted SHA256 opening, domain signature, binary Merkle path. Unknown proofs never become valid by transport.',True,[
            ('list_verifiers',{},()),('pack',{'system':TEXT,'statement':OBJECT,'proof':{'type':'string'},'context':HASH},('system','statement','proof','context')),
            ('inspect',{'envelope':OBJECT},('envelope',)),('verify',{'envelope':OBJECT,'verifier':HASH,'expected_context':HASH,'expected_statement':OBJECT},('envelope','verifier','expected_context','expected_statement')),
            ('commitment',{'data':{'type':'string'},'salt':{'type':'string'},'context':HASH},('data','salt','context'))]),
          ('covenant_prediction','Score forecasts and inspect adopted native markets and exact payout exposure, including equal-share VOID. Price and signed reports are not world truth.',True,[
            ('score',{'probability_bps':INT,'outcome':boolean},('probability_bps','outcome')),
            ('aggregate',{'reports':arr},('reports',)),('inspect',{'market':HASH},('market',)),
            ('preview_trade',{'market':HASH,'outcome':TEXT,'seller':HASH,'buyer':HASH,'quantity':INT,'price':INT,'expiry':INT,'salt':HASH},('market','outcome','seller','buyer','quantity','price','expiry','salt'))]),
          ('covenant_exchange','List owner-installed transfer/effect adapters, quote an adopted fee schedule, or prepare an exact payment request for the approval-based workflow. Never downloads a connector or initiates payment.',True,[
            ('adapters',{},()),('quote_fee',{'amount':INT,'unit':TEXT},('amount','unit')),
            ('preview_payment',{'adapter':HASH,'request':OBJECT},('adapter','request')),
            ('prepare',{'adapter':HASH,'request':OBJECT},('adapter','request'))]),
          ('covenant_token','Inspect actual adopted token utility: posted fee discounts and finite service-credit redemption prices. No APR, price floor or universal token access mandate.',True,[('benefits',{},()),
            ('credit_quote',{'service':TEXT,'units':INT},('service','units'))])]
        from .developer_tools import spec as developer_spec
        specs.append(developer_spec())
        from .builder_tools import spec as builder_spec
        specs.append(builder_spec())
        from .standards_tools import spec as standards_spec
        specs.append(standards_spec())
        from .a2a_agreement_tools import spec as a2a_agreement_spec
        specs.append(a2a_agreement_spec())
        from .offline_tools import spec as offline_spec
        specs.append(offline_spec())
        from .connectivity_tools import spec as connectivity_spec
        specs.append(connectivity_spec())
        from .robotics_tools import spec as robotics_spec
        specs.append(robotics_spec())
        from .coordination_tools import spec as coordination_spec
        specs.append(coordination_spec())
        from .portable_agreement_tools import spec as portable_agreement_spec
        specs.append(portable_agreement_spec())
        from .portable_trust_tools import spec as portable_trust_spec
        specs.append(portable_trust_spec())
        from .network_trust_tools import spec as network_trust_spec
        specs.append(network_trust_spec())
        from .identity_discovery_tools import spec as identity_discovery_spec
        specs.append(identity_discovery_spec())
        from .trust_evidence_tools import spec as trust_evidence_spec
        specs.append(trust_evidence_spec())
        from .independent_replay_tools import spec as independent_replay_spec
        specs.append(independent_replay_spec())
        from .roadmap_tools import spec as roadmap_spec
        specs.append(roadmap_spec())
        from .update_tools import spec as update_spec
        specs.append(update_spec())
        from .commerce_tools import spec as commerce_spec
        specs.append(commerce_spec())
        if self.crawl_licensing is not None:
            from .crawl_licensing_tools import spec as crawl_licence_spec
            specs.append(crawl_licence_spec())
        from .contract_application_tools import specs as contract_application_specs
        specs.extend(contract_application_specs())
        from .extension_tools import specs as extension_specs
        specs.extend(extension_specs(index_enabled=self.discovery_index is not None))
        from .arbitration_interop_tools import spec as arbitration_interop_spec
        specs.append(arbitration_interop_spec())
        from .connect_tools import spec as connect_spec
        specs.append(connect_spec())
        from .adjudication_tools import spec as adjudication_spec
        specs.append(adjudication_spec())
        boundary_id={'type':'string','pattern':'^[0-9a-f]{128}$','minLength':128,'maxLength':128}
        raw_bytes={'type':'string','maxLength':349528,'description':'Canonical base64 of exact source bytes; up to 262144 raw bytes. No decoding as text or source execution.'}
        specs.append(('covenant_external_draft','Draft with any tool, language or file format, then adopt exact bytes through existing immutable capsules and role-qualified concept assent. Chunked inline bytes, whole-file opening, selected meaning and fresh successor signatures. open_boundary checks legacy proposal SHA512 IDs, actual source bytes and typed context. Currentness uses only a caller-retained reference. No signing, retrieval, publication, ledger append or effects.',True,[
            ('spec',{},()),('context_reference',{'value':{}},('value',)),
            ('pack',{'source_base64':raw_bytes,'title':TEXT,'media_type':TEXT,'language':TEXT,'semantics':HASH},('source_base64',)),
            ('inspect',{'document':OBJECT,'expected_id':HASH,'source_base64':raw_bytes},('document','expected_id')),
            ('prepare',{'documents':{**OBJECT,'description':'Map ASCII local aliases to exact .document objects returned by pack, not complete pack responses.'},'parties':OBJECT,'context':HASH,'title':TEXT,'meaning':{'type':'string','minLength':1,'maxLength':4096},'previous':OBJECT},('documents','parties','context')),
            ('verify',{'bundle':OBJECT,'context':HASH,'approvals':arr,'expected_id':HASH,'expected_closure':HASH,'expected_current_id':HASH},('bundle','context','approvals','expected_id','expected_closure')),
            ('boundary_assent_payload',{'proposal':OBJECT,'context':OBJECT,'expected_proposal_id':boundary_id},('proposal','context','expected_proposal_id')),
            ('open_boundary',{'proposal':OBJECT,'source_base64':raw_bytes,'expected_proposal_id':boundary_id,'proofs':arr,'expected_context':OBJECT,'expected_current_id':boundary_id},('proposal','source_base64','expected_proposal_id','proofs','expected_context'))]))
        specs.append(('covenant_contract_design','Optional exact contract charters: choose neutral drafting prompts with templates, or custom terms and authorities. Preserve provisions, competing interpretations, scoped precedence, evidence and remedies. Sources and provenance are explicit audit views. Verify assent or attach a fresh agreement successor. No automatic legal approval, source retrieval, signing or execution.',True,[
            ('templates',{},()),('sources',{},()),('provenance',{'charter':OBJECT},('charter',)),('draft',{'title':TEXT,'context':HASH,'agreement':OBJECT,'parties':OBJECT,'templates':{'type':'array','maxItems':3,'items':TEXT,'description':'Choose essentials, evidence_and_custom, finance_and_risk; inspect templates for prompts. Explicit historical template IDs remain accepted for compatibility.'},'sources':OBJECT,'terms':OBJECT,'relationships':arr,'questions':arr,'features':OBJECT},('title','context','agreement','parties')),
            ('inspect',{'charter':OBJECT},('charter',)),('review',{'charter':OBJECT,'previous':OBJECT},('charter',)),
            ('amend',{'charter':OBJECT,'changes':OBJECT},('charter','changes')),('compare',{'before':OBJECT,'after':OBJECT},('before','after')),
            ('assent_payload',{'charter':OBJECT},('charter',)),('verify_assents',{'charter':OBJECT,'approvals':arr,'expected_id':HASH},('charter','approvals','expected_id')),
            ('attach',{'body':OBJECT,'charter':OBJECT},('body','charter')),('attach_work',{'packet':OBJECT,'charter':OBJECT},('packet','charter')),('render',{'charter':OBJECT,'include_audit':boolean},('charter',))]))
        specs.extend([
          ('covenant_marketplace','Create a general market, listing or reusable transaction archetype. quick_trade prepares the complete simple agreement in one call. Every record carries seven question dimensions. Credit/escrow/custom terms require adopted execution; no funds or inventory are inferred.',True,[
            ('templates',{},()),
            ('asset',asset_shape['properties'],('namespace','identifier','unit')),
            ('market',{'name':TEXT,'owner':HASH,'description':{'type':'string','maxLength':4096},'categories':arr,'mechanisms':arr,'members':arr,'policy':OBJECT,'frame':OBJECT},('name','owner')),
            ('archetype',{'name':TEXT,'author':HASH,'mechanism':TEXT,'settlement':OBJECT,'clauses':OBJECT,'defaults':OBJECT,'links':arr,'frame':OBJECT},('name','author')),
            ('listing',{'market':HASH,'seller':HASH,'title':TEXT,'offer':leg_shape,'want':leg_shape,'mechanism':TEXT,'category':TEXT,'quantity':INT,'settlement':OBJECT,'archetype':HASH,'custom':OBJECT,'frame':OBJECT},('market','seller','title','offer','want')),
            ('credit_listing',{'market':HASH,'lender':HASH,'title':TEXT,'asset':asset_shape,'principal':INT,'interest_bps':INT,'due_height':INT,'origination_fee':INT,'collateral':arr,'recourse':TEXT,'transferability':TEXT,'settlement':OBJECT,'frame':OBJECT},('market','lender','title','asset','principal','interest_bps','due_height')),
            ('quote_credit',{'listing':OBJECT,'borrower':HASH,'context':HASH},('listing','borrower','context')),
            ('simple_listing',{'market':HASH,'seller':HASH,'title':TEXT,'price':{**INT,'description':'Payment units per lot, not per asset unit.'},'payment_asset':asset_shape,'item':asset_shape,'item_amount':{'type':'integer','minimum':1,'maximum':2**53-1,'description':'Asset units in one lot; default 1. Example: item.unit=kg, item_amount=500, quantity=1 sells one 500kg lot.'},'quantity':{'type':'integer','minimum':1,'maximum':2**53-1,'description':'Available lots; default 1. It is not kilograms or item amount. quote.units is the number of lots bought.'},'category':TEXT,'frame':OBJECT},('market','seller','title','price','payment_asset')),
            ('quick_trade',{'seller':HASH,'buyer':HASH,'description':TEXT,'amount':INT,'payment_asset':asset_shape,'context':HASH,'archetype':OBJECT,'compact':boolean,'terms':{**OBJECT,'description':'Optional exact inspection, correction, return or other terms adopted in this first offer.'},'settlement':{**OBJECT,'description':'Optional explicit settlement terms. A pinned archetype settlement may be repeated exactly, but cannot be silently replaced.'}},('seller','buyer','description','amount','payment_asset','context')),
            ('use_archetype',{'archetype':OBJECT,'market':HASH,'seller':HASH,'title':TEXT,'offer':leg_shape,'want':leg_shape,'quantity':INT,'category':TEXT,'frame':OBJECT},('archetype','market','seller','title','offer','want')),
            ('inspect',{'record':OBJECT},('record',)),('amend',{'record':OBJECT,'changes':OBJECT},('record','changes')),
            ('quote',{'listing':OBJECT,'buyer':HASH,'context':HASH,'units':{**INT,'minimum':1,'description':'Number of lots. Each offer/want leg amount is multiplied by this value.'},'terms':OBJECT},('listing','buyer','context')),
            ('counter',{'order':OBJECT,'changes':{**schema({'give':leg_shape,'receive':leg_shape,'settlement':OBJECT,'terms':OBJECT},()),'description':'Nonempty whole-field replacements: give, receive, settlement and/or terms. A quick-trade price is give[0].amount, not a top-level amount patch. Copy any unrelated terms or asset fields you want preserved. Term-credit orders require a fresh quote.'}},('order','changes')),('compare',{'before':OBJECT,'after':OBJECT},('before','after')),
            ('order_review',{'order':OBJECT},('order',)),('verify_order',{'order':OBJECT,'approvals':{'type':'array','minItems':2,'maxItems':2,'items':concept_approval,'description':'Two exact concept/role signatures; sign each required_assents body, not the entire payload or the order.'},'expected_id':HASH,'expected_current_id':{**HASH,'description':'Optional separately retained order reference; mismatch is historical signature validity, not global latest knowledge.'}},('order','approvals','expected_id')),
            ('escrow_policy',{'name':TEXT,'author':HASH,'asset':asset_shape,'amount':INT,'payer':HASH,'payee':HASH,'controllers':arr,'threshold':INT,'context':HASH,'release':OBJECT,'refund':OBJECT,'connector':HASH,'frame':OBJECT},('name','author','asset','amount','payer','payee','controllers','threshold','context')),
            ('private_notice',{'record':OBJECT,'salt':{'type':'string'},'context':HASH,'delivery':OBJECT,'market':HASH},('record','salt','context','delivery')),
            ('verify_private',{'record':OBJECT,'salt':{'type':'string'},'notice':{**OBJECT,'description':'Exact private notice, or the unmodified complete private_notice response containing .notice.'}},('record','salt','notice'))]),
          ('covenant_ads','Prepare a labelled sponsored directory record, a promotion signal, or an explicit escrow. Spend is WORLD_SPEND, a service job, or a payment-rail quote. Nothing here signs, posts a native AD operation, or changes organic rank.',True,[
            ('directory',{'market':HASH,'seller':HASH,'title':TEXT,'price':INT,'category':TEXT},('market','seller','title','price')),
            ('promote',{'kind':TEXT,'id':HASH,'origin':HASH,'context':TEXT},('kind','id','origin')),
            ('escrow',{'instrument':{'enum':['WORLD_SPEND','SERVICE_JOB','PAYMENT_RAIL']},'role':HASH,'destination':HASH,'quantity':INT,'resource':TEXT},('instrument','quantity'))]),
          ('covenant_frame','Define who, what, which, where, when, why, how or custom questions about any object. Preserve exact scoped answers, unknown/withheld/disputed states and evidence references; no inference of truth or authority.',True,[
            ('dimensions',{},()),('cover',{'target':OBJECT,'answers':OBJECT,'withheld':arr,'title':TEXT},('target',)),
            ('answer',{'value':{},'stated_by':OBJECT,'evidence':{'type':'array','maxItems':32,'items':OBJECT}},('value',)),
            ('slot',{'id':TEXT,'dimension':TEXT,'question':{'type':'string','minLength':1,'maxLength':4096},'definition':{'type':'string','minLength':1,'maxLength':4096},'status':{'enum':['UNKNOWN','ASSERTED','EVIDENCE_LINKED','DISPUTED','WITHHELD','NOT_APPLICABLE']},'answers':{'type':'array','maxItems':32,'items':OBJECT},'reason':{'type':'string','minLength':1,'maxLength':4096}},('id','dimension','question')),
            ('draft',{'title':TEXT,'slots':{'type':'array','minItems':1,'maxItems':64,'items':OBJECT},'target':OBJECT,'links':{'type':'array','maxItems':64,'items':OBJECT},'extensions':OBJECT},('title','slots')),
            ('inspect',{'frame':OBJECT,'required_dimensions':{'type':'array','maxItems':64,'items':TEXT}},('frame',)),
            ('amend',{'frame':OBJECT,'changes':OBJECT},('frame','changes')),
            ('compare',{'before':OBJECT,'after':OBJECT},('before','after'))]),
          ('covenant_permutation','Exact finite permutations for roles, turns, allocations or agreement structure: compose, invert, apply, rank/unrank up to size 128. Deterministic mathematics supplies neither randomness nor fairness or authority.',True,[
            ('spec',{},()),('permutation',{'images':{'type':'array','maxItems':128,'items':INT}},('images',)),
            ('inspect',{'permutation':OBJECT},('permutation',)),('compose',{'left':OBJECT,'right':OBJECT},('left','right')),
            ('inverse',{'permutation':OBJECT},('permutation',)),('apply',{'permutation':OBJECT,'items':arr},('permutation','items')),
            ('rank',{'permutation':OBJECT},('permutation',)),('unrank',{'size':{'type':'integer','minimum':0,'maximum':128},'index':{'type':'string','pattern':'^(0|[1-9][0-9]{0,215})$','maxLength':216}},('size','index'))]),
          ('covenant_concept','Start with simple exact terms and parties; add frames, conditions, relationships, mathematics and nested concepts when needed. Prepare checks the same full meaning closure and qualified all-party assent at every scale. Custom mathematical source remains inert. Declared criteria never prove world truth or grant execution.',True,[
            ('spec',{},()),
            ('simple',{'terms':{'type':'string','minLength':1,'maxLength':4096},'parties':OBJECT,'title':TEXT},('terms',)),
            ('review',{'bundle':OBJECT,'context':HASH},('bundle','context')),
            ('open_review',{'review':OBJECT,'expected_id':HASH},('review','expected_id')),
            ('prepare',{'concept':OBJECT,'context':HASH,'concepts':{'type':'array','maxItems':63,'items':OBJECT},'frames':{'type':'array','maxItems':128,'items':OBJECT},'artifacts':{'type':'array','maxItems':128,'items':OBJECT}},('concept','context')),
            ('draft',{'title':TEXT,'meaning':{'type':'string','minLength':1,'maxLength':4096},'rules':OBJECT,'root':TEXT,'parties':OBJECT,'frames':OBJECT,'concepts':OBJECT,'artifacts':OBJECT,'relations':OBJECT,'extensions':OBJECT},('title','meaning','rules','root')),
            ('inspect',{'concept':OBJECT},('concept',)),('amend',{'concept':OBJECT,'changes':OBJECT},('concept','changes')),
            ('compare',{'before':OBJECT,'after':OBJECT},('before','after')),
            ('artifact_id',{'kind':TEXT,'value':{}},('kind','value')),
            ('pack_math',{'language':TEXT,'source':{'type':'string','maxLength':65536},'semantics':HASH,'dependencies':{'type':'array','maxItems':32,'items':HASH}},('language','source','semantics')),
            *[(action,{'root':HASH,'concepts':{'type':'array','minItems':1,'maxItems':64,'items':OBJECT},'frames':{'type':'array','maxItems':128,'items':OBJECT},'artifacts':{'type':'array','maxItems':128,'items':OBJECT},**extras},required) for action,extras,required in [
                ('resolve',{},('root','concepts','frames')),('evaluate',{},('root','concepts','frames')),
                ('assent_payload',{'context':HASH},('root','concepts','frames','context')),
                ('verify_assents',{'context':HASH,'approvals':arr,'expected_id':HASH,'expected_closure':HASH},('root','concepts','frames','context','approvals','expected_id','expected_closure'))]]]),
          ('covenant_legal','Compose recursive legal modules from obligations, permissions, logic, delegations, guarantees, arbitration and custom concepts. node returns a wrapper: put its .node value into draft.definitions, then reference definitions in roots. Reference immutable modules; no draft grants authority or collateral.',True,[
            ('node',{'kind':TEXT,'arguments':OBJECT,'references':arr},('kind',)),
            ('draft',{'title':TEXT,'parties':OBJECT,'resources':OBJECT,'definitions':{**OBJECT,'description':'Map local term names to raw legal node objects: use the .node member returned by covenant_legal.node, not the complete tool response.'},'roots':arr,'extensions':OBJECT,'supersedes':HASH},('title','parties','resources','definitions','roots')),
            ('inspect',{'module':OBJECT},('module',)),('assent_payload',{'module':OBJECT,'context':HASH},('module','context')),('verify_assents',{'module':OBJECT,'context':HASH,'approvals':arr,'expected_id':HASH},('module','context','approvals','expected_id')),('compose',{'root':HASH,'modules':{'type':'array','maxItems':256,'items':OBJECT},'maximum_terms':INT},('root','modules'))]),
          ('covenant_resource','Name any adapter-backed commodity, data, right or resource. Verify signed source observations against exact asset/query/source/key/context/freshness; prepare acquisition through owner-installed adapters.',True,[
            ('identify',{'asset':asset_shape},('asset',)),('prepare',{'adapter':HASH,'asset':asset_shape,'query':OBJECT,'context':HASH},('adapter','asset','query','context')),
            ('verify_observation',{'envelope':OBJECT,'expected_asset':asset_shape,'expected_query':OBJECT,'expected_context':HASH,'expected_source':HASH,'expected_key':{},'now':INT,'max_age':INT,'predicate':{**schema({'field':{'type':'string'},'operator':{'enum':['EQ','GE','GT','LE','LT']},'value':{'type':'integer','minimum':-(2**53-1),'maximum':2**53-1}},('field','operator','value')),'description':'Numeric integer comparison only. Boolean/string/title claims need a separately adopted custom verifier; a matching observation alone never establishes title or releases payment.'}},('envelope','expected_asset','expected_query','expected_context','expected_source','expected_key','now','max_age'))]),
          ('covenant_rank','Compute personalized PageRank for any typed objects using an explicitly chosen bounded graph and seed policy. Rank creates no ownership, truth or authority.',True,[
            ('compute',{'nodes':{'type':'array','maxItems':256},'edges':{'type':'array','maxItems':4096},'seeds':{'type':'array','maxItems':256},'damping_bps':INT,'iterations':INT},('nodes','edges','seeds'))])])
        plan_auth={'plan':OBJECT,'approvals':arr,'expected_id':HASH,'expected_controllers':{'type':'array','minItems':1,'maxItems':8}}
        auth_required=('plan','approvals','expected_id','expected_controllers')
        continuation={'evidence':OBJECT,'previous':OBJECT,'expected_previous':HASH}
        target_shape=schema({'kind':{'type':'string','minLength':1,'maxLength':80},'id':HASH},('kind','id'))
        selector_shape={'type':'array','maxItems':32,'items':{'type':'string','maxLength':256}}
        binding_shape=schema({'mechanism':HASH,'operation':{'type':'string','minLength':1,'maxLength':64},'parameters':OBJECT},('mechanism','operation','parameters'))
        step_options={'visibility':{'enum':['PUBLIC','PRIVATE','WITHHELD']},'recipients':{'type':'object','maxProperties':64,'additionalProperties':{'type':'object','minProperties':1},'description':'Name to nonempty adopted recipient descriptor. Built-in ML-KEM uses {name: {"ML-KEM-768": lowercase_public_hex}}; public key is 1184 bytes / 2368 hex characters. Other owner-installed methods retain their own descriptor; Ed25519 signing keys are not encryption keys.'},'protection':{'type':'array','maxItems':8,'items':schema({'mechanism':HASH,'seal':TEXT,'open':TEXT,'parameters':OBJECT},('mechanism','seal','open','parameters'))},'mechanisms':{'type':'array','maxItems':32,'items':binding_shape},'gates':{'type':'array','maxItems':32,'items':schema({'binding':INT,'expected':{}},('binding','expected'))},'depends_on':{'type':'array','maxItems':64,'items':TEXT},'frame':OBJECT}
        desire_shape=schema({'query':{'type':'string','maxLength':256},'context':TEXT,'requirements':OBJECT,'strict_requirements':boolean,'weights':schema({k:INT for k in ('relevance','pagerank','reputation')},('relevance','pagerank','reputation')),'trust_seeds':{'type':'array','maxItems':256}},())
        discovery_object=schema({'target':target_shape,'title':{'type':'string','minLength':1,'maxLength':512},'description':{'type':'string','maxLength':4096},'attributes':OBJECT,'links':{'type':'array','maxItems':64,'items':target_shape}},('target','title','description','attributes','links'))
        nullable_text=lambda limit=256:{'type':['string','null'],'minLength':1,'maxLength':limit}
        nullable_hash={**HASH,'type':['string','null']}
        nullable_int={**INT,'type':['integer','null']}
        lines={'type':'array','maxItems':32,'items':{'type':'string','minLength':1,'maxLength':4096}}
        job_shape=schema({'title':{'type':'string','minLength':1,'maxLength':256},'scope':{'type':'string','maxLength':4096},'deliverables':lines,'acceptance_checks':lines,
            'price':{'oneOf':[{'type':'null'},{'type':'string','minLength':1,'maxLength':80,'description':'Exact GBP120, GBP 120.50, £120, EUR/€, USD or JPY; no inferred exchange rate.'},schema({'amount_minor':INT,'currency':{'type':'string','pattern':'^[A-Z][A-Z0-9_]{0,31}$'},'minor_unit_digits':{'type':'integer','minimum':0,'maximum':18}},())]},
            'payment':schema({'service':nullable_text(),'adapter':nullable_hash,'release_rule':nullable_text(1024),'escrow':{'enum':['NOT_REQUESTED','REQUESTED']}},()),
            'schedule':schema({'delivery_deadline':nullable_text(),**{k:nullable_int for k in ('review_window_hours','correction_window_hours','dispute_window_hours')}},()),
            'revisions':schema({'included':nullable_int},()),
            'identity':schema({'mode':{'type':'string','minLength':1,'maxLength':128},'provider':nullable_hash,'subject':{},'requirements':OBJECT},()),
            'privacy':schema({'readers':{'type':'array','minItems':1,'maxItems':16,'items':{'type':'string','minLength':1,'maxLength':256}},'publication':{'enum':['NONE','SELECTED','FULL']},'recording':{'enum':['NONE','LOCAL_PRIVATE','PRIVATE_ENCRYPTED','PUBLIC_SELECTED','PUBLIC_FULL']},'public_fields':{'type':'array','maxItems':32,'items':{'type':'string','minLength':1,'maxLength':256}}},()),
            'dispute':schema({'required':boolean,'reviewer':{},'procedure':nullable_hash},()),'extensions':OBJECT},())
        specs.extend([
          ('covenant_agreement','Prepare a plain-language work agreement and one compact review of scope, exact price, dummy acceptance checks, revisions, evidence, intended readers and recording choice. Track missing party signatures and an explicitly supplied current-revision reference. Working packets stay local and WITHHELD; never signs, connects an app, publishes or moves money.',True,[
            ('prepare',{'parties':{**OBJECT,'description':'Map 2–8 role names to valid signing identities. With template checkout_repair, include exact roles client and freelancer. Generic agreements may use any role names.'},'job':job_shape,'context':HASH,'target':target_shape,'template':{'enum':['checkout_repair'],'description':'Proposed checkout defaults; requires parties.client and parties.freelancer. Review each default before assent.'}},('parties','job')),
            ('review',{'packet':OBJECT,'approvals':arr,'current_id':HASH,'previous':OBJECT},('packet',)),
            ('revise',{'packet':OBJECT,'changes':job_shape,'remove':{'type':'array','maxItems':32,'items':{'type':'string','minLength':1,'maxLength':256},'description':'Explicit JSON pointers to extension object members, e.g. /extensions/delegation. Removes draft terms in a fresh successor only; does not revoke an external grant or erase prior copies. Empty objects still recursively merge. Arrays must be replaced explicitly in changes.'}},('packet','changes')),
            ('private_copy',{'packet':OBJECT,'approvals':arr,'current_id':HASH,'previous':OBJECT},('packet',)),
            ('reopen',{'content':{'type':'string','minLength':1,'maxLength':1000000},'expected_id':HASH,'current_id':HASH},('content','expected_id'))]),
          ('covenant_identity','Choose any agreed identity/evidence mode, from declarations, documents and witnesses to official/payment apps, email, OIDC or future providers. Definitions do not install or call a provider. Exact adopted rules distinguish acceptance from external verification. Prepare optional public/private immutable record bytes; no automatic publication or authority.',True,[
            ('blueprints',{},()),('installed',{},()),
            ('provider_manifest',{'name':TEXT,'family':TEXT,'issuer':TEXT,'implementation':HASH,'semantics':HASH,'claim_kinds':{'type':'array','minItems':1,'maxItems':32,'items':TEXT},'config':OBJECT,'assumptions':arr},('name','family','issuer','implementation','semantics','claim_kinds')),
            ('binding',{'mechanism':HASH,'provider':HASH,'subject':{},'audience':TEXT,'claim_kind':TEXT,'requirements':OBJECT,'request_hash':HASH,'holder_binding':{'enum':['SUBJECT_SIGNATURE','AGREED_EVIDENCE']}},('mechanism','provider','subject','audience','claim_kind','requirements','request_hash','holder_binding')),
            ('attest_payload',{'challenge':OBJECT,'issuer':{},'assertions':OBJECT,'not_before':INT,'expires':INT},('challenge','issuer','assertions','not_before','expires')),
            ('open_record',{'storage_request':OBJECT,'expected_id':HASH},('storage_request','expected_id')),
            ('record_packet',{**plan_auth,'step':TEXT,'delivery':OBJECT,'expected_delivery':HASH,'previous':OBJECT,'expected_previous':HASH,'plan_disclosure':{'enum':['REFERENCE_ONLY','FULL']}},(*auth_required,'step','delivery','expected_delivery'))]),
          ('covenant_connector','Inspect owner-installed MCP, HTTP/API/website, file, socket and custom transport aliases, or validate/prepare an exact effect request. No network, file, tool callback or effect is invoked through this interface. Every external call requires separate workflow approval.',True,[
            ('installed',{},()),('prepare',{'adapter':HASH,'request':schema({'protocol':TEXT,'operation':TEXT,'parameters':OBJECT},('protocol','operation','parameters'))},('adapter','request'))]),
          ('covenant_a2a','Inspect an untrusted A2A Agent Card or owner-installed A2A 1.0 JSON-RPC clients, and prepare exact discovery, message, task lookup or cancellation requests. params_json preserves external JSON bytes and numbers. No network, credential exchange, endpoint installation, agreement assent, payment or execution occurs through this interface.',True,[
            ('installed',{},()),
            ('inspect_card',{'card_json':{'type':'string','minLength':1,'maxLength':262144},'expected_url':TEXT},('card_json',)),
            ('prepare',{'adapter':HASH,'agent':TEXT,'method':{'enum':['Discover','SendMessage','GetTask','CancelTask']},'request_id':TEXT,'params_json':{'type':'string','minLength':1,'maxLength':262144}},('adapter','agent','method','request_id'))]),
          ('covenant_access','Draft exact signed delegation grants for any typed purpose, inspect/amend unsigned grant data, or read owner-adopted access state. Capabilities, expiration, redelegation and successor meaning are explicit. Drafts grant no authority; password enrollment, revocation and issuer policy remain owner custody.',True,[
            ('installed',{},()),('state',{'mechanism':HASH},('mechanism',)),
            ('grant',{'context':HASH,'target':target_shape,'operation':TEXT,'issuer':{},'delegate':{},'capabilities':{'type':'array','minItems':1,'maxItems':32,'items':TEXT},'not_before':INT,'expires':INT,'nonce':HASH,'delegable':boolean,'parent':HASH,'supersedes':HASH},('context','target','operation','issuer','delegate','capabilities','not_before','expires','nonce')),
            ('inspect',{'record':OBJECT},('record',)),('amend',{'before':OBJECT,'changes':OBJECT},('before','changes'))]),
          ('covenant_mechanism','Define exact modular mechanisms and per-step public/private/withheld plans. Any proof, promise, encryption, escrow or external service can be named; actual calls require an installed pinned implementation. Field commitments preserve exact selectively disclosed values; every scope revision needs fresh controller assent.',True,[
            ('templates',{},()),('installed',{},()),
            ('methodology',{'name':TEXT,'family':TEXT,'specification':{},'operations':OBJECT,'implementation':HASH,'assurances':OBJECT,'assumptions':arr},('name','family','specification','operations')),
            ('manifest',{'name':TEXT,'family':TEXT,'semantics':HASH,'implementation':HASH,'operations':OBJECT,'assurances':OBJECT,'assumptions':arr,'frame':OBJECT},('name','family','semantics','implementation','operations')),
            ('binding',{'mechanism':HASH,'operation':TEXT,'parameters':OBJECT},('mechanism','operation')),
            ('protection',{'mechanism':HASH,'seal':TEXT,'open':TEXT,'parameters':OBJECT},('mechanism',)),
            ('commit_fields',{'value':{},'fields':selector_shape,'salts':OBJECT,'context':HASH,'step':TEXT},('value','fields','salts','context','step')),
            ('prepare_step',{'id':TEXT,'target':target_shape,'value':{},'fields':selector_shape,'salts':OBJECT,'context':HASH,**step_options},('id','target','value','fields','salts','context')),
            ('prepare_selected',{'id':TEXT,'target':target_shape,'value':{},'fields':selector_shape,'salts':OBJECT,'context':HASH,**step_options},('id','target','value','fields','salts','context')),
            ('step',{'id':TEXT,'target':target_shape,'fields':selector_shape,'commitments':OBJECT,**step_options},('id','target','fields','commitments')),
            ('plan',{'context':HASH,'subject':target_shape,'controllers':{'type':'array','minItems':1,'maxItems':8},'steps':{'type':'array','minItems':1,'maxItems':64,'items':OBJECT},'purpose':TEXT,'supersedes':HASH,'frame':OBJECT},('context','subject','controllers','steps')),
            ('inspect',{'record':OBJECT},('record',)),('assent_payload',{'plan':OBJECT},('plan',)),
            ('verify_assents',plan_auth,auth_required),('amend',{'plan':OBJECT,'changes':OBJECT},('plan','changes')),
            ('compare',{'before':OBJECT,'after':OBJECT},('before','after')),
            ('verify_transition',{'before':OBJECT,'after':OBJECT,'approvals':arr,'expected_before':HASH,'expected_after':HASH},('before','after','approvals','expected_before','expected_after')),
            ('readiness',{'plan':OBJECT},('plan',))]),
          ('covenant_disclosure','Protect/open any agreed field or step under an exact mechanism plan. PUBLIC is explicit plaintext; PRIVATE uses adopted ordered protections and recipient descriptors; WITHHELD emits no value. Opening verifies each field against controller-assented commitments. Old plaintext cannot be recalled. Owner host/custody remains trusted.',True,[
            ('protect',{**plan_auth,'step':TEXT,'value':{},'salts':OBJECT,**continuation},(*auth_required,'step')),
            ('open',{**plan_auth,'step':TEXT,'delivery':OBJECT,'expected_delivery':HASH,'recipient':TEXT},(*auth_required,'step','delivery','expected_delivery'))]),
          ('covenant_mechanism_call','Call a pinned owner-installed LOCAL mechanism under exact plan assent and gates, or prepare a committed EFFECT input for a separately approved workflow. Never installs code, picks URLs/key paths or executes effects through this read interface.',True,[
            ('local',{**plan_auth,'step':TEXT,'binding':INT,'payload':{},**continuation},(*auth_required,'step','binding','payload')),
            ('prepare_effect',{**plan_auth,'adapter':HASH,'step':TEXT,'binding':INT,'payload':{},'request_salt':TEXT,**continuation},(*auth_required,'adapter','step','binding','payload','request_salt'))]),
          ('covenant_desire','Find and rank any typed objects for an explicit desire. Search installed mechanisms/connectors or an adopted catalog; combine lexical relevance, exact requirements, caller-seeded PageRank and contextual authenticated reputation. Recommendations/promotions/use do not become performance evidence or authority.',True,[
            ('installed',{},()),('identify',{'kind':TEXT,'reference':{},'salt':TEXT,'context':HASH},('kind','reference')),('catalog',{'source':{'enum':['INSTALLED','MARKETPLACE','FORUM','AGENTS']},'group':HASH,'market':HASH,'packets':arr,'query':{'type':'string','maxLength':256},'limit':{'type':'integer','minimum':1,'maximum':256}},()),('search',{'sources':{'type':'array','maxItems':4,'items':{'enum':['INSTALLED','MARKETPLACE','FORUM','AGENTS']}},'market':HASH,'packets':arr,'desire':desire_shape,'objects':{'type':'array','maxItems':256,'items':discovery_object},'include_installed':boolean,'edges':{'type':'array','maxItems':4096},'seeds':{'type':'array','maxItems':256},'group':HASH},('desire',))])])
        specs.append(('covenant_privacy','Choose plaintext or adopted encryption, scope selected fields/recipients, and require fresh unanimous scope assent for changes. Supports optional owner-installed schemes; never erases prior plaintext or automatically hides metadata.',True,[
            ('suites',{},()),('draft',{'context':HASH,'controllers':{'type':'array','maxItems':8},'recipients':{'type':'object','maxProperties':8,'propertyNames':{'type':'string','minLength':1,'maxLength':64},'additionalProperties':{'type':'string','pattern':'^[0-9a-f]{2368}$','minLength':2368,'maxLength':2368},'description':'Name to ML-KEM-768 public key: 1184 bytes as 2368 lowercase hex characters. This scope uses a bare hex value, unlike mechanism-plan descriptors. Owner keeps each 2400-byte recipient secret in private custody. Ed25519 signing public keys are not accepted.'},'fields':{'type':'array','maxItems':32,'items':TEXT},'purpose':{'type':'string','maxLength':4096},'suite':TEXT,'supersedes':HASH},('context','controllers','recipients','fields','purpose')),
            ('verify_transition',{'before':OBJECT,'after':OBJECT,'approvals':arr,'expected_before':HASH,'expected_after':HASH},('before','after','approvals','expected_before','expected_after')),('inspect',{'policy':OBJECT},('policy',)),('amend',{'policy':OBJECT,'changes':OBJECT},('policy','changes')),
            ('protect',{'value':OBJECT,'policy':OBJECT,'approvals':arr,'expected_id':HASH,'expected_controllers':arr,'padding':INT},('value','policy','approvals','expected_id','expected_controllers')),
            ('open',{'delivery':OBJECT,'policy':OBJECT,'approvals':arr,'expected_id':HASH,'expected_controllers':arr,'recipient':TEXT},('delivery','policy','approvals','expected_id','expected_controllers'))]))
        if self.network:
            common={'request':TEXT,'content':OBJECT,'group':HASH,'parents':{'type':'array','maxItems':65,'items':HASH,'description':'Additional causal references. Current group frontier and actor predecessor are also included. This never selects a past snapshot.'},'expected_heads':{'type':'array','maxItems':64,'items':HASH,'description':'Optional exact sorted local global heads returned by preflight. Reject publication if observations changed; this is not a historical snapshot selector.'}}
            specs.extend([
              ('covenant_marketplace_read','Search authenticated marketplace records in a local signed replica, inspect archetype use or render a storefront. Accepted orders are not payments or exclusive stock reservations.',True,[('rank',{'seeds':arr,'group':HASH,'market':HASH,'include_usage':{'type':'boolean'},'objects':arr},('seeds',)),('catalog',{'group':HASH,'market':HASH,'query':{'type':'string','maxLength':256},'limit':{'type':'integer','minimum':1,'maximum':256},'objects':arr},()),('render',{'group':HASH,'market':HASH,'query':{'type':'string','maxLength':256},'limit':{'type':'integer','minimum':1,'maximum':256},'objects':arr},())]),
              ('covenant_marketplace_publish','Explicitly publish public market records or a salted private commitment through the signed forum. Private content stays outside the public event. No automatic payments.',False,[
                ('publish',{'request':TEXT,'group':HASH,'record':OBJECT,'disclosure':{'const':'PUBLIC_PLAINTEXT'},'reference_only':{'type':'boolean'},'objects':arr,'approvals':arr,'expected_heads':{'type':'array','maxItems':64,'items':HASH}},('request','group','record','disclosure')),
                ('publish_private',{'request':TEXT,'group':HASH,'notice':OBJECT,'objects':arr,'acknowledge_public_metadata':{'const':True},'expected_heads':{'type':'array','maxItems':64,'items':HASH}},('request','group','notice','acknowledge_public_metadata'))]),
              ('covenant_forum_read','Read signed local forum/guild replicas or export their event DAG. Attribution is not truth; admitted replicas see plaintext. Preflight kinds are network: events, not chain:RESOLVE or chain:DECIDE.',True,[('view',{'group':HASH,'query':{'type':'string','maxLength':256}},()),('event',{'reference':HASH,'compact':{'type':'boolean'}},('reference',)),('timeline',{'group':HASH,'query':{'type':'string','maxLength':256},'limit':{'type':'integer','minimum':1,'maximum':256}},()),('preflight',{'kind':{'enum':sorted([*FORUM,*['ROLE_PROPOSE','ROLE_ACCEPT','ROLE_REVOKE','DISPUTE','DISPUTE_ACCEPT','RESOLVE']]),'description':'Network event kind. Qualify it as network:<KIND>. network:RESOLVE is not chain:RESOLVE, chain:DECIDE or language:DECIDE.'},'group':HASH,'parents':{'type':'array','maxItems':65,'items':HASH}},('kind',)),('export',{},())]),
              ('covenant_forum_write','Create groups/guilds, publish threads, corrections, moderation or typed links; or merge signed replica bundles. No external delivery or global consensus.',False,[
                  *[('emit',{'kind':{'const':kind},**common,'content':content},('kind','request','content')) for kind,content in FORUM.items()],
                  ('import',{'bundle':OBJECT},('bundle',))]),
              ('covenant_roles','Propose, accept or revoke exact group-local roles. Changes require holder acceptance; arbitrary labels grant no native spending authority.',False,[
                  (action,{**common,'content':content},('request','content','group')) for action,content in ROLE.items()]),
              ('covenant_arbitration','Record disputes, exact all-party procedure acceptance and an adopted arbitrator finding. The resolve action emits network:RESOLVE, which is not chain:RESOLVE. Claims remain distinct from findings; no automatic transfers.',False,[
                  (action,{**common,'content':content},('request','content','group')) for action,content in ARBITRATION.items()]),
              ('covenant_discovery','Find relevant posts and agents using contextual owner-seeded PageRank. Duplicate endorsements do not multiply graph links.',True,[('search',{'context':TEXT,'query':{'type':'string','maxLength':256},'group':HASH},('context',))]),
              ('covenant_reputation','Inspect contextual signed opinions and conflicting evidence origins separately from graph ranking. Pending disputes create no automatic penalties.',True,[('inspect',{'context':TEXT,'subject':HASH,'group':HASH},('context',))])])
        if self.network:
            specs.extend([
              ('covenant_vote','Create signed proposals and weighted plurality/approval/IRV ballots on any typed target. Tally an explicit causal snapshot; quorum and votes confer no spending authority and external closing policy needs adoption.',False,[
                ('create',{'request':TEXT,'group':HASH,'poll':schema({'target':target_shape,'question':{'type':'string','minLength':1,'maxLength':2048},'options':{'type':'array','minItems':2,'maxItems':32,'items':{'type':'string','minLength':1,'maxLength':80}},'rule':{'enum':['PLURALITY','APPROVAL','IRV']},'electorate':{'type':'array','minItems':1,'maxItems':64,'items':schema({'actor':HASH,'weight':{'type':'integer','minimum':1,'maximum':2**53-1}},('actor','weight'))},'quorum_bps':{'type':'integer','minimum':0,'maximum':10000},'closing':{**OBJECT,'description':'Explicit adopted closing policy; no clock enforcement is inferred.'},'tie_policy':{'const':'REPORT_TIE_OR_LEXICOGRAPHIC_LOW_ELIMINATION'}},('target','question','options','rule','electorate','quorum_bps','closing','tie_policy'))},('request','group','poll')),
                ('cast',{'request':TEXT,'group':HASH,'proposal':HASH,'choices':{'type':'array','maxItems':32,'items':TEXT}},('request','group','proposal','choices')),
                ('tally',{'proposal':HASH,'heads':{'type':'array','maxItems':65,'items':HASH}},('proposal',)),('list',{'group':HASH},())]),
              ('covenant_signal','Sign a contextual recommendation, promotion or opinion about any typed target; inspect deduplicated evidence origins. No paid promotion is inferred to be independent evidence.',False,[
                ('emit',{'request':TEXT,'group':HASH,'target':OBJECT,'context':TEXT,'origin':HASH,'signal':{'enum':['RECOMMEND','PROMOTE','POSITIVE','NEGATIVE','UNKNOWN']}},('request','group','target','context','origin','signal')),
                ('inspect',{'context':TEXT,'subject':OBJECT},('context',))])])
        from .arbitration_tools import exchange_actions
        specs.extend(exchange_actions())
        specs.append(('covenant_evidence','Build a covenant-evidence/0.1 hash reference. A JPEG submitted as photo becomes an envelope with its media type, blob hash, any EXIF GPS, and an honest assurance label. The picture bytes stay outside the envelope. Decimal, EXIF, NMEA and geo: URI coordinates become fixed-point microdegrees. A stored level such as L0 is a release recommendation the parties can lift, never a protocol gate.',True,[
            ('spec',{},()),
            ('photo',{'jpeg_base64':{'type':'string','minLength':8,'maxLength':1500000},'agreement':HASH,'context':HASH,'adapter':HASH,'parties':{'type':'array','maxItems':8,'items':HASH},'pinned_signers':{'type':'array','maxItems':8,'items':HASH}},('jpeg_base64','agreement','context','adapter')),
            ('agreement',{'agreement':HASH,'photos':{'type':'array','maxItems':32,'items':OBJECT}},('agreement','photos')),
            ('dispute',{'agreement':HASH,'photos':{'type':'array','maxItems':32,'items':OBJECT},'cited':{'type':'array','maxItems':32,'items':HASH}},('agreement','photos','cited')),
            ('gps',{'lat':{'type':'string','minLength':1,'maxLength':32},'lon':{'type':'string','minLength':1,'maxLength':32},'nmea':{'type':'string','minLength':8,'maxLength':512},'geo':{'type':'string','minLength':5,'maxLength':256},'exif_base64':{'type':'string','minLength':16,'maxLength':120000}},()),
            ('policy',{'level_required':{'enum':['L0','L1','L2','L3','ABSENT']},'on_shortfall':{'enum':['ACCEPT','HOLD','PANEL','ABSENT']},'single_source_release':{'enum':['DEFAULT','ADMITTED','ABSENT']},'model_release':{'enum':['DEFAULT','ADMITTED','ABSENT']},'assurance_required':{'enum':['SELF_ASSERTED','PARTY_SIGNED','THIRD_PARTY_SIGNED','CRYPTOGRAPHICALLY_VERIFIED','ABSENT']}},()),
            ('release',{'readings':{'type':'array','minItems':1,'maxItems':32,'items':schema({'confidence_bps':INT,'independence_key':TEXT,'source_class':TEXT,'adapter':HASH},('confidence_bps','independence_key','source_class','adapter'))},'policy':OBJECT},('readings',)),
            ('reference',{'sha256':HASH,'bytes':{'type':'integer','minimum':1,'maximum':512*1024*1024},'media_type':TEXT},('sha256','bytes','media_type'))]))
        from .delivery_tools import specs as delivery_specs
        specs.extend(row for row in delivery_specs() if row[0] in ('covenant_formula_eval', 'covenant_delivery'))
        from .directory_tools import read_spec, write_spec
        specs.append(read_spec())
        from .public_web_tools import read_spec as public_web_spec
        specs.append(public_web_spec())
        from .request_tools import specs as request_specs
        specs.extend(request_specs(agora_peer=self.agora_peer is not None))
        if self.plugins is not None and self.plugins.tools():
            from .legal_evidence_tools import specs as legal_evidence_specs
            specs.extend(legal_evidence_specs(self.plugins))
        if self.network or (self.board is not None and self.board.signer is not None):
            specs.append(write_spec())
        from .advanced_schemas import enrich_specs
        from .representation_tools import specs as representation_specs
        specs += representation_specs()
        from .secure_execution_mcp import specs as security_specs
        specs += security_specs()
        from .infrastructure_tools import specs as infrastructure_specs
        specs += infrastructure_specs()
        specs=enrich_specs(specs)
        out=[tool(name,description,action_schema(_with_read(actions)),readonly=readonly,idempotent=readonly) for name,description,readonly,actions in specs]
        if self.identity_desks:
            out.append(tool('covenant_identity_challenge','Issue/reuse a short-lived challenge for an exact controller-assented identity-evidence rule and optional holder signature. Mutates challenge state only. External login, token exchange, email sending and record publication require separately approved connectors.',action_schema([
                ('issue',{**plan_auth,'step':TEXT,'binding':INT,'mechanism':HASH,'ttl':{'type':'integer','minimum':1,'maximum':300},'previous':OBJECT,'expected_previous':HASH},(*auth_required,'step','binding','mechanism'))]),readonly=False,idempotent=False))
        if self.access_desks:
            out.append(tool('covenant_access_challenge','Issue a short-lived challenge for an exact controller-assented access binding, or reuse the current unexpired challenge. This may mutate owner challenge state. Forced replacement is owner-only. Verification remains repeatable while current; no password or private key is requested here.',action_schema([
                ('issue',{**plan_auth,'step':TEXT,'binding':INT,'mechanism':HASH,'ttl':{'type':'integer','minimum':1,'maximum':300},'previous':OBJECT,'expected_previous':HASH},(*auth_required,'step','binding','mechanism'))]),readonly=False,idempotent=False))
        if self.adapters is not None:
            escrow_actions=[
                ('assent_payload',{'adapter':HASH,'effect_id':HASH,'request':OBJECT},('adapter','effect_id','request')),
                ('observe_local',{'adapter':HASH,'effect_id':HASH},('adapter','effect_id')),
                ('audit_local',{'adapter':HASH,'expected_head':HASH},('adapter',))]
            if self.workflow is not None:escrow_actions.insert(0,('prepare_for_task',{'adapter':HASH,'task_id':HASH,'request':OBJECT},('adapter','task_id','request')))
            out.append(tool('covenant_escrow','Inspect an owner-installed escrow connector and prepare exact all-party funding or quorum payout signatures. Never signs, funds or releases through this read interface.',action_schema(escrow_actions),readonly=True,idempotent=True))
        if self.proofs.provers:
            out.append(tool('covenant_prove','Generate a proof with an owner-installed prover, then verify the exact statement/context using its pinned verifier. Witness is visible to the calling model/host and trusted prover.',
                schema({'verifier':HASH,'statement':OBJECT,'context':HASH,'witness':OBJECT},('verifier','statement','context','witness'))))
        if self.workflow:
            branch=schema({'action':{'const':'certified_reviews'},'parameters':schema({'subject':HASH,'context':HASH},('subject','context'))},('action','parameters'))
            existing=next((t for t in out if t['name']=='covenant_reputation'),None)
            if existing:existing['inputSchema']['oneOf'].append(branch)
            else:out.append(tool('covenant_reputation','Read contextual native review findings from verified history, preserving pending claims and consensual corrections. Never a universal score.',{'type':'object','oneOf':[branch]},readonly=True,idempotent=True))
        if self.markets:
            # Mature native-runtime parameter checks and party approvals remain authoritative.
            out.append(tool('covenant_wager','Create/fund native prediction markets, place exactly approved positions, challenge, finalize and redeem. Public metadata, oracle panels, VOID and collateral budgets must be explicitly adopted.',
                schema({'action':{'enum':['create','fund','place','report','challenge','finalize','redeem','merge']},'parameters':OBJECT},('action','parameters'))))
        from .adoption_tools import specs as adoption_specs
        out.extend(adoption_specs())
        from .identity_tools import specs as identity_specs
        out.extend(identity_specs())
        from .settlement_plugins.tools import spec as settlement_spec
        out.append(settlement_spec())
        return out
    def call(self,name,arguments):
        validate_json(arguments)
        if name=='covenant_prove':
            _fields(arguments,('verifier','statement','context','witness'));return self.proofs.prove(**arguments)
        _fields(arguments,('action','parameters'));action=arguments['action'];p=deepcopy(arguments['parameters']);need(type(p) is dict,'EXCHANGE_PARAMETERS')
        target=next((t for t in self.tools() if t['name']==name),None);need(target is not None,'EXCHANGE_TOOL')
        # Enforce the same action-specific shape advertised to clients, without a schema dependency.
        root=target['inputSchema']
        validate_schema(arguments,root)
        if 'oneOf' in root:
            branch=next((b for b in root['oneOf'] if b['properties']['action']['const']==action),None);need(branch is not None,'EXCHANGE_ACTION')
            shape=branch['properties']['parameters'];_fields(p,shape['required'],set(shape['properties'])-set(shape['required']))
        else:need(action in root['properties']['action']['enum'],'EXCHANGE_ACTION')
        from .infrastructure_tools import NAMES as infrastructure_names, call as infrastructure_call
        if name in infrastructure_names:
            return infrastructure_call(name, action, p)
        if name in ('covenant_extensions','covenant_index'):
            from .extension_tools import call as extension_call
            return extension_call(self,name,action,p)
        if name in {'covenant_credential','covenant_signin','covenant_recovery','covenant_org'}:
            from .identity_tools import call as identity_call
            return identity_call(name,action,p)
        if name in {'covenant_request','covenant_request_write','covenant_agora','covenant_decision','covenant_agora_peer'}:
            from .request_tools import call as request_call
            return request_call(self,name,action,p)
        if self.plugins is not None and name in self.plugins.tools():
            from .legal_evidence_tools import call as legal_evidence_call
            return legal_evidence_call(self.plugins,name,action,p,root)
        if action == 'describe' and p == {}:
            if name == 'covenant_independent_replay':
                from .independent_replay import describe as independent_describe
                return {'status':'DESCRIBED','tool':name,'schema':deepcopy(root),**independent_describe()}
            if name == 'covenant_deal_review':
                from .contract_application_tools import call as application_call
                return {'status':'DESCRIBED', 'tool':name, 'guide':'docs/DEAL_ASSURANCE.html',
                        'actions':[branch['properties']['action']['const'] for branch in root['oneOf']],
                        'schema_lookup':{'tool':'covenant_explain', 'action':'action',
                                         'id_pattern':'tool:covenant_deal_review.<action>'},
                        **application_call(name, action, p)}
            if name in ('covenant_contract_application', 'covenant_agreement_procedure'):
                from .contract_application_tools import call as application_call
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root),
                        'guide':'docs/AGREEMENT_APPLICATIONS.html',
                        **application_call(name, action, p)}
            if name == 'covenant_arbitration_interop':
                from .arbitration_interop_tools import describe as interop_describe
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root), **interop_describe()}
            if name == 'covenant_adjudication':
                from .adjudication_tools import describe as adjudication_describe
                return {'status':'DESCRIBED', 'schema':deepcopy(root), **adjudication_describe()}
            if name == 'covenant_portable_trust':
                from .portable_trust import describe as trust_describe
                from .trust_verify import describe as receipt_describe
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root),
                        'guide':'docs/PORTABLE_TRUST.html', **trust_describe(),
                        'receipt_checks':{**receipt_describe(), 'guide':'docs/PARITY_GUARDS.html'}}
            if name == 'covenant_network_trust':
                from .network_trust_tools import describe as network_describe
                return {'status':'DESCRIBED', 'schema':deepcopy(root), **network_describe()}
            if name == 'covenant_identity_discovery':
                from .identity_discovery_tools import describe as identity_discovery_describe
                return {'status':'DESCRIBED', 'schema':deepcopy(root), **identity_discovery_describe()}
            if name == 'covenant_trust_evidence':
                from .trust_evidence_tools import describe as trust_evidence_describe
                return {'status':'DESCRIBED', 'schema':deepcopy(root), **trust_evidence_describe()}
            if name == 'covenant_interoperate':
                from .roadmap_tools import call as roadmap_call
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root),
                        'guide':'docs/OPEN_INTEROPERABILITY.html', **roadmap_call('catalog', {})}
            if name == 'covenant_update':
                from .update_tools import call as update_call
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root), **update_call('describe', {})}
            if name == 'covenant_crawl_licence':
                from .crawl_licensing_tools import call as crawl_licence_call
                return {'status':'DESCRIBED','tool':name,'schema':deepcopy(root),
                        **crawl_licence_call(self.crawl_licensing,'describe',{})}
            if name == 'covenant_commerce':
                from .commerce_tools import describe as commerce_describe
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root), **commerce_describe()}
            if name == 'covenant_connect':
                from .connect_tools import describe as connect_describe
                return {'status':'DESCRIBED', 'tool':name, 'schema':deepcopy(root), **connect_describe()}
            if name=='covenant_portable_agreement':
                from .portable_agreements import spec as portable_spec
                return {'status':'DESCRIBED','tool':name,'schema':deepcopy(root),
                        'guide':'docs/PORTABLE_AGREEMENTS.html',**portable_spec()}
            if name=='covenant_intent_market':
                return {'status':'DESCRIBED','tool':name,'schema':deepcopy(root),
                    'workflow':['create request','collect bids through an agreed channel',
                                'compare exact quotes','prepare selected quote after bidding closes',
                                'separately obtain both exact marketplace order signatures'],
                    'timing':'bid_deadline, deliver_by and as_of use an agreed integer clock; as_of is a caller assertion. Do not invent a later time to force selection.',
                    'privacy':'PRIVATE by default; no publication or encryption is performed.',
                    'guide':'docs/INTENT_MARKETS.html','execution_authorized':False}
            if name == 'covenant_representation':
                from .representation_tools import call as representation_call
                return {'status':'DESCRIBED','tool':name,'schema':deepcopy(root),
                        **representation_call('describe',{})}
            if name == 'covenant_execution_security':
                from .secure_execution_mcp import description
                return {'status':'DESCRIBED','tool':name,'schema':deepcopy(root),**description()}
            if name in {'covenant_credit','covenant_legal'}:
                from .advanced_schemas import describe
                return describe(name,root)
            if name=='covenant_settlement':
                from .settlement_plugins.tools import call as settlement_call
                return {'status':'DESCRIBED','tool':name,**settlement_call('describe',{},flags=self.settlement_flags)}
            return {'status':'DESCRIBED','tool':name,'code':'NOT_COMMITTED','execution_authorized':False,
                    'automatic_assent':False,'next_action':'Choose a named action. Nothing was submitted.'}
        if name in ('covenant_formula_eval', 'covenant_delivery'):
            from .delivery_tools import call as delivery_call
            return delivery_call(name, action, p)
        if name=='covenant_evidence':
            import base64
            from .evidence_sdk import submit_jpeg, tool_call
            if action=='photo':
                need(self.evidence_signer is not None,'EVIDENCE_SIGNER_REQUIRED')
                try:raw=base64.b64decode(p['jpeg_base64'],validate=True)
                except Exception as exc:raise ValueError('EVIDENCE_JPEG') from exc
                return submit_jpeg(raw,self.evidence_signer,p['agreement'],p['context'],p['adapter'],parties=p.get('parties') or (),pinned_signers=p.get('pinned_signers') or ())
            return tool_call(action,p)
        if name in {'covenant_find', 'covenant_explain', 'covenant_draft', 'covenant_lint', 'covenant_simulate', 'covenant_counter'}:
            return _navigation_call(name, p)
        if name == 'covenant_feedback':
            return _feedback_call(action, p)
        if name in {'covenant_dispute','covenant_submit_evidence','covenant_panel_vote','covenant_arbitrators_search'}:
            from .arbitration_tools import invoke
            return invoke(name,action,p)
        if name in {'covenant_onboard','covenant_invite','covenant_growth'}:
            from .adoption_tools import dispatch
            return dispatch(self,name,action,p)
        if name in {'covenant_credential','covenant_signin','covenant_recovery','covenant_org'}:
            from .identity_tools import call as identity_call
            return identity_call(name,action,p)
        if name in ('covenant_directory','covenant_directory_write'):
            from .directory_tools import call as directory_call
            return directory_call(self,name,action,p)
        if name == 'covenant_public_web':
            from .public_web_tools import call as public_web_call
            return public_web_call(action,p)
        if name=='covenant_portable_agreement':
            from .portable_agreement_tools import call as portable_call
            return portable_call(action,p)
        if name=='covenant_portable_trust':
            from .portable_trust_tools import call as portable_trust_call
            return portable_trust_call(action,p)
        if name=='covenant_network_trust':
            from .network_trust_tools import call as network_trust_call
            return network_trust_call(action,p)
        if name=='covenant_arbitration_interop':
            from .arbitration_interop_tools import call as arbitration_interop_call
            return arbitration_interop_call(action,p)
        if name=='covenant_adjudication':
            from .adjudication_tools import call as adjudication_call
            return adjudication_call(action,p)
        if name=='covenant_identity_discovery':
            from .identity_discovery_tools import call as identity_discovery_call
            return identity_discovery_call(action,p)
        if name=='covenant_trust_evidence':
            from .trust_evidence_tools import call as trust_evidence_call
            return trust_evidence_call(action,p)
        if name=='covenant_independent_replay':
            from .independent_replay_tools import call as independent_call
            return independent_call(action,p)
        if name=='covenant_interoperate':
            from .roadmap_tools import call as roadmap_call
            return roadmap_call(action,p)
        if name=='covenant_update':
            from .update_tools import call as update_call
            return update_call(action,p)
        if name=='covenant_crawl_licence':
            need(self.crawl_licensing is not None,'CRAWL_OWNER_DESK')
            from .crawl_licensing_tools import call as crawl_licence_call
            return crawl_licence_call(self.crawl_licensing,action,p)
        if name=='covenant_commerce':
            from .commerce_tools import call as commerce_call
            return commerce_call(action,p)
        if name=='covenant_connect':
            from .connect_tools import call as connect_call
            return connect_call(action,p)
        if name in ('covenant_contract_application', 'covenant_agreement_procedure', 'covenant_deal_review'):
            from .contract_application_tools import call as application_call
            return application_call(name,action,p)
        if name=='covenant_external_draft':
            from covenant_language import external_drafts
            return getattr(external_drafts,action)(**p)
        if name=='covenant_review':
            from .coordination_tools import call as review_call
            return review_call(self,action,p)
        if name=='covenant_contract_design':
            from covenant_language import contract_studio as contract_design,contract_sources
            if action=='sources':return contract_sources.catalog()
            result=getattr(contract_design,'attach_contract' if action=='attach' else action)(**p)
            return {'html':result,'execution_authorized':False} if action=='render' else result
        if name=='covenant_developer':
            from .developer_tools import call
            return call(self,action,p)
        if name=='covenant_builder':
            from .builder_tools import call
            return call(self,action,p)
        if name=='covenant_standards':
            from .standards_tools import call
            return call(self,action,p)
        if name=='covenant_a2a_agreement':
            from .a2a_agreement_tools import call
            return call(action,p)
        if name=='covenant_robotics':
            from .robotics_tools import call
            return call(action,p)
        if name=='covenant_offline':
            from .offline_tools import call
            return call(action,p)
        if name=='covenant_connectivity':
            from .connectivity_tools import call
            return call(action,p)
        if name=='covenant_agreement':
            from . import human_agreements as human
            if action in ('private_copy','reopen'):
                from . import human_packet_files
                result=getattr(human_packet_files,action)(**p)
                if action=='reopen':result['review']=human.review(result['packet'],result['approvals'],p.get('current_id'),result['previous'],self._agreement_owner_status(result['packet']))
                return result
            if action=='review':
                human.validate(p['packet']);return human.review(**p,owner_status=self._agreement_owner_status(p['packet']))
            try:
                if action=='revise' and 'remove' in p:
                    from . import agreement_edits
                    result=agreement_edits.revise(**p)
                else:result=getattr(human,action)(**p)
            except ValueError as exc:
                if action in ('prepare','revise') and str(exc) in {'HUMAN_PRICE_USE_EXACT_TEXT_OR_MINOR_UNIT_OBJECT','HUMAN_PRICE_EXACT_TEXT_EXPECTED_NO_AMBIGUOUS_SYMBOL_OR_EXPONENT','HUMAN_PRICE_TOO_MANY_DECIMAL_PLACES','HUMAN_CURRENCY_PRECISION_REQUIRED','HUMAN_CURRENCY_CHANGE_REQUIRES_EXACT_AMOUNT_AND_PRECISION_NO_CONVERSION'}:
                    from .tool_input import ToolInputError
                    raise ToolInputError([{'path':'/parameters/'+('job' if action=='prepare' else 'changes')+'/price','code':'EXACT_PRICE_SYNTAX','guidance':'Use ungrouped exact decimal text with an explicit currency, or integer minor units with explicit precision. No locale guessing or currency conversion is performed.','examples':['EUR 1200.00',{'amount_minor':120000,'currency':'EUR','minor_unit_digits':2}]}]) from None
                raise
            result['review']=human.review(result['packet'],previous=p['packet'] if action=='revise' else None,owner_status=self._agreement_owner_status(result['packet']));return result
        if name=='covenant_identity':
            from . import identity_facility as identity
            if action=='installed':return {'mechanisms':{ref:{'provider':provider,'desk':desk.describe()} for ref,(desk,provider) in self.identity_desks.items()},'execution_authorized':False}
            if action=='binding':
                from covenant_language import mechanism_plans as plans
                mechanism=p.pop('mechanism');identity.subject(p['subject'],p['holder_binding']);identity.requirements(p['requirements']);return plans.binding(mechanism,'verify',p)
            return getattr(identity,'provider' if action=='provider_manifest' else action)(**p)
        if name=='covenant_identity_challenge':
            from . import mechanism_runtime as runtime
            from covenant_language import mechanism_plans as plans
            ref=p['mechanism'];need(ref in self.identity_desks,'IDENTITY_MECHANISM_NOT_INSTALLED');desk,provider=self.identity_desks[ref]
            runtime._assent(p['plan'],p['approvals'],p['expected_id'],p['expected_controllers'],p.get('previous'),p.get('expected_previous'))
            step=runtime._step(p['plan'],p['step']);index=p['binding'];need(type(index) is int and 0<=index<len(step['mechanisms']),'MECHANISM_BINDING_INDEX');binding=step['mechanisms'][index]
            need(binding['mechanism']==ref and binding['operation']=='verify' and binding['parameters'].get('provider')==provider,'IDENTITY_BINDING')
            need(p['plan']['context']==desk.policy['context'] and plans.canonical(step['target'])==plans.canonical(desk.policy['target']),'IDENTITY_SCOPE')
            self.mechanisms.get(ref,'verify','LOCAL');context=runtime._context(p['plan'],step,'mechanism/'+str(index),binding['parameters'])
            return desk.issue_challenge(runtime.call_context(context),**binding['parameters'],ttl=p.get('ttl',60))
        if name=='covenant_a2a':
            from .a2a_connector import A2AConnector,inspect_card
            if action=='inspect_card':return inspect_card(**p)
            registry=self.adapters
            if action=='installed':
                return {'adapters':{} if registry is None else {ref:adapter.describe_requests() for ref in registry.describe() if isinstance((adapter:=registry.get(ref)),A2AConnector)},'execution_authorized':False}
            need(registry is not None,'A2A_ADAPTER_NOT_INSTALLED');adapter=registry.get(p.pop('adapter'))
            need(isinstance(adapter,A2AConnector),'A2A_ADAPTER_REQUIRED')
            return adapter.prepare(**p)
        if name=='covenant_connector':
            from .connector_harness import ConnectorHarness
            if action=='installed':
                entries={} if self.workflow is None else {ref:adapter.describe_requests() for ref in self.workflow.adapters.describe() if isinstance((adapter:=self.workflow.adapters.get(ref)),ConnectorHarness)}
                return {'connectors':entries,'execution_authorized':False}
            need(self.workflow is not None,'CONNECTOR_WORKFLOW_REQUIRED');adapter=self.workflow.adapters.get(p['adapter'])
            need(isinstance(adapter,ConnectorHarness),'CONNECTOR_HARNESS_REQUIRED');checked=adapter.validate_request(p['request'])
            return {'adapter':p['adapter'],'request':p['request'],'request_binding':{'kind':'FIXED','hash':checked['request_hash']},'next':'ADOPT_EXACT_WORKFLOW_BOOKING_AND_PROVIDER_OUTPUT_APPROVALS','execution_authorized':False}
        if name=='covenant_access':
            from . import access_mechanisms as access
            if action=='installed':return {'policies':{ref:{'policy':deepcopy(desk.policy),'state':desk.public_state()} for ref,desk in self.access_desks.items()},'execution_authorized':False}
            if action=='state':
                need(p['mechanism'] in self.access_desks,'ACCESS_POLICY_NOT_INSTALLED');return self.access_desks[p['mechanism']].public_state()
            if action=='inspect':return {'id':access.grant_id(p['record']),'grant':p['record'],**access.grant_payload(p['record']),'signature_verified':False}
            return getattr(access,'amend_grant' if action=='amend' else action)(**p)
        if name=='covenant_access_challenge':
            from . import mechanism_runtime as runtime
            from covenant_language import mechanism_plans as plans
            ref=p['mechanism'];need(ref in self.access_desks,'ACCESS_POLICY_NOT_INSTALLED');desk=self.access_desks[ref]
            runtime._assent(p['plan'],p['approvals'],p['expected_id'],p['expected_controllers'],p.get('previous'),p.get('expected_previous'))
            step=runtime._step(p['plan'],p['step']);index=p['binding'];need(type(index) is int and 0<=index<len(step['mechanisms']),'MECHANISM_BINDING_INDEX');binding=step['mechanisms'][index]
            need(binding['mechanism']==ref and binding['operation'] in ('password','delegation'),'ACCESS_CHALLENGE_BINDING')
            need(p['plan']['context']==desk.policy['context'] and plans.canonical(step['target'])==plans.canonical(desk.policy['target']),'ACCESS_SCOPE_MISMATCH')
            self.mechanisms.get(ref,binding['operation'],'LOCAL')
            context=runtime._context(p['plan'],step,'mechanism/'+str(index),binding['parameters'])
            _fields(binding['parameters'],('subject','capability','request_hash'))
            return desk.issue_challenge(runtime.call_context(context),**binding['parameters'],ttl=p.get('ttl',60))
        if name=='covenant_mechanism':
            if action=='prepare_selected':
                from .selected_inputs import prepare_selected
                return prepare_selected(**p)
            from covenant_language import mechanism_plans
            from . import mechanism_runtime
            if action=='installed':return {'mechanisms':self.mechanisms.describe(),'default_privacy':self.mechanisms.default_privacy,'proof_mechanisms':self.mechanisms.proof_mechanisms,'execution_authorized':False}
            if action=='templates':return mechanism_runtime.templates(self.mechanisms)
            if action=='readiness':return mechanism_runtime.readiness(self.mechanisms,**p)
            if action=='inspect':
                record=p['record']
                if record.get('version')==mechanism_plans.M_VERSION:
                    mechanism_plans.validate_manifest(record);return {'id':mechanism_plans.mechanism_id(record),'manifest':record,'installation':'NOT_IMPLIED','execution_authorized':False}
                return mechanism_plans.inspect(record)
            result=getattr(mechanism_plans,action)(**p)
            return {'step':result,'execution_authorized':False} if action in ('step','prepare_step') else result
        if name=='covenant_disclosure':
            from . import mechanism_runtime
            return getattr(mechanism_runtime,'open_delivery' if action=='open' else action)(self.mechanisms,**p)
        if name=='covenant_mechanism_call':
            from . import mechanism_runtime
            if action=='local':return mechanism_runtime.invoke_local(self.mechanisms,**p)
            need(self.workflow is not None,'MECHANISM_WORKFLOW_REQUIRED');adapter=self.workflow.adapters.get(p['adapter'])
            need(isinstance(adapter,mechanism_runtime.PlanEffectAdapter) and adapter.registry is self.mechanisms,'MECHANISM_WORKFLOW_ADAPTER_REQUIRED')
            return mechanism_runtime.prepare_effect(self.mechanisms,**p)
        if name=='covenant_desire':
            from .desire_discovery import discover
            from .desire_catalogs import catalog,identify
            if action=='identify':return identify(**p)
            if action in ('installed','catalog'):return catalog(self,**p)
            sources=p.pop('sources',None);include=p.pop('include_installed',True)
            if sources is None:sources=['INSTALLED'] if include else []
            need(len(sources)==len(set(sources)),'DESIRE_DUPLICATE_SOURCES');objects=[]
            for source in sources:
                result=catalog(self,source,group=p.get('group'),market=p.get('market'),packets=p.get('packets'));need(not result['truncated'],'DESIRE_CATALOG_SCOPE_TOO_WIDE');objects.extend(result['objects'])
            supplied=p.pop('objects',[]);objects.extend(supplied);p.pop('market',None);p.pop('packets',None)
            return discover(objects,network=self.network,**p)
        if name=='covenant_escrow':
            need(self.adapters is not None,'EXCHANGE_WORKFLOW_REQUIRED');adapter=self.adapters.get(p.pop('adapter'))
            need(adapter.manifest['capability']=='payment.escrow','ESCROW_ADAPTER_UNSUPPORTED')
            if action=='prepare_for_task':
                need(self.workflow is not None,'EXCHANGE_WORKFLOW_REQUIRED')
                from .workflow_store import identifier
                from .cooperation import _meaning
                task=self.workflow.store.get(p['task_id']);need(task['job'] is not None,'ESCROW_BOOK_TASK_FIRST')
                snap=self.workflow.read_snapshot();need(task['job'] in snap.state.get('service_jobs',{}),'ESCROW_BOOKING_NOT_OBSERVED')
                need(_meaning(task['proposal'])['terms']['effect']['adapter']==manifest_id(adapter.manifest),'ESCROW_TASK_ADAPTER_MISMATCH')
                effect=identifier('COVENANT-WORKFLOW-EFFECT-ID-0.1',dict(chain=self.workflow.chain,job=task['job'],slot='primary'))
                return {**adapter.assent_payload(effect,p['request']),'task_id':task['id'],'effect_id':effect,'task_request_unchanged':True,'execution_authorized':False}
            return {**getattr(adapter,{'observe_local':'observe','audit_local':'audit'}.get(action,action))(**p),'execution_authorized':False}
        if name=='covenant_ads':
            from .ads.escrow import prepare_escrow
            from .ads.placement import promote_signal, sponsored_listing
            if action=='directory':return sponsored_listing(**p)
            if action=='promote':return promote_signal(p.pop('kind'), p.pop('id'), p.pop('origin'), **p)
            return prepare_escrow(**p)
        if name=='covenant_marketplace':
            if action in {'private_notice','verify_private'}:
                from . import marketplace_book
                if action=='verify_private' and type(p['notice']) is dict and 'notice' in p['notice']:
                    wrapper=p['notice'];_fields(wrapper,('notice','plaintext_publication','salt_publication','metadata','execution_authorized'))
                    need(wrapper['plaintext_publication'] is False and wrapper['salt_publication'] is False and wrapper['execution_authorized'] is False and wrapper['metadata']=='AUTHOR_CONTEXT_OPTIONAL_MARKET_DELIVERY_REFERENCE_AND_FRAME_ARE_PUBLIC','MARKETPLACE_NOTICE_WRAPPER')
                    p['notice']=wrapper['notice']
                return getattr(marketplace_book,action)(**p)
            from covenant_language import marketplace
            if action=='simple_listing' and 'item_amount' in p:
                amount=p.pop('item_amount');result=marketplace.simple_listing(**p)
                if amount!=1:
                    record=result['record'];data=record['data'];offer=deepcopy(data['offer']);offer[0]['amount']=amount
                    result=marketplace.listing(p['market'],p['seller'],p['title'],offer,data['want'],quantity=data['quantity'],category=data['category'],frame=p.get('frame'))
                return {**result,'lot_review':{'item_amount_per_lot':amount,'available_lots':result['record']['data']['quantity'],'payment_per_lot':p['price'],'meaning':'QUOTE_UNITS_MULTIPLY_EACH_LOT; STOCK_TITLE_DELIVERY_AND_PAYMENT_NOT_ESTABLISHED'}}
            result=getattr(marketplace,action)(**p)
            if action=='compare':
                from .review_changes import paths
                result.update(paths(p['before'],p['after']))
            return result
        if name=='covenant_marketplace_read':
            if action=='rank':
                from .marketplace_book import rank
                return rank(self.network,**p)
            from .marketplace_book import catalog
            result=catalog(self.network,**p)
            if action=='render':
                from .marketplace_view import render
                return {'html':render(result),'catalog':result,'execution_authorized':False}
            return result
        if name=='covenant_marketplace_publish':
            from . import marketplace_book
            return getattr(marketplace_book,action)(self.network,**p)
        if name=='covenant_permutation':
            from covenant_language import permutations
            return getattr(permutations,action)(**p)
        if name=='covenant_concept':
            if action in {'review','open_review'}:
                from covenant_language import agreement_reviews
                return getattr(agreement_reviews,action)(**p)
            if action in {'simple','prepare'}:
                from covenant_language import agreement_builder
                return getattr(agreement_builder,action)(**p)
            from covenant_language import frame_concepts
            result=getattr(frame_concepts,action)(**p)
            return {'id':result,'kind':p['kind'],'execution_authorized':False} if action=='artifact_id' else result
        if name=='covenant_frame':
            if action=='cover':
                from covenant_language.context_frames import cover
                return cover(**p)
            from covenant_language import question_frames
            result=getattr(question_frames,action)(**p)
            return {action:result,'execution_authorized':False} if action in {'answer','slot'} else result
        if name=='covenant_privacy':
            from . import privacy_scopes
            if action=='suites':return self.privacy.suites()
            if action in {'protect','open'}:return getattr(self.privacy,action)(**p)
            return getattr(privacy_scopes,action)(**p)
        if name=='covenant_representation':
            from .representation_tools import call as representation_call
            return representation_call(action,p)
        if name=='covenant_execution_security':
            from .secure_execution_mcp import call as security_call
            return security_call(action,p)
        if name=='covenant_legal':
            from covenant_language import legal_composition
            result=getattr(legal_composition,action)(**p)
            return {'node':result,'execution_authorized':False} if action=='node' else result
        if name=='covenant_resource':
            from covenant_language.marketplace import _asset
            for field in ('asset','expected_asset'):
                if field in p:p[field]=_asset(p[field])
            from .resource_observations import resource_id,verify_observation
            if action=='identify':return {'id':resource_id(**p),'asset':p['asset'],'transfer_or_title':'REQUIRES_ADOPTED_CONNECTOR_EVIDENCE','execution_authorized':False}
            if action=='verify_observation':return verify_observation(**p)
            need(self.workflow is not None,'EXCHANGE_WORKFLOW_REQUIRED');adapter=self.workflow.adapters.get(p.pop('adapter'))
            need(adapter.manifest['capability']=='resource.observe','RESOURCE_CONNECTOR_NOT_INSTALLED')
            return {'adapter':manifest_id(adapter.manifest),'request':p,'next':'EXACT_APPROVAL_WORKFLOW_WITH_FIXED_REQUEST_HASH','execution_authorized':False}
        if name=='covenant_rank':
            from .voting import rank_objects
            return rank_objects(**p)
        if name=='covenant_vote':
            from .voting import tally
            if action=='create':return self.network.emit('PROPOSAL',p['request'],p['poll'],group=p['group'])
            if action=='cast':return self.network.emit('BALLOT',p['request'],{'proposal':p['proposal'],'choices':p['choices']},group=p['group'])
            if action=='tally':return tally(self.network,**p)
            from .agent_network import unpack
            return {'proposals':[{'id':ref,'group':e['body']['group'],'poll':unpack(e['body'])} for ref,e in sorted(self.network.events().items()) if e['body']['kind']=='PROPOSAL' and ('group' not in p or e['body']['group']==p['group'])],'execution_authorized':False}
        if name=='covenant_signal':
            if action=='inspect':
                from .voting import signals
                return signals(self.network,**p)
            request=p.pop('request');group=p.pop('group');return self.network.emit('SIGNAL',request,p,group=group)
        if name=='covenant_intent_market':
            from covenant_language import intent_market
            return getattr(intent_market,action)(**p)
        if name=='covenant_auction':
            if action=='create':return games.create('AUCTION',**p)
            if action=='allocate':return games.auction(**p)
            if action=='commit_bid':return {'commitment':bid_commitment(**p),'execution_authorized':False}
            return {'matches':reveal_matches(**p),'execution_authorized':False}
        if name=='covenant_game':return getattr(games,action)(**p)
        if name=='covenant_contract':
            result=getattr(contracts,action)(**p);return {'html':result,'execution_authorized':False} if action=='render' else result
        if name=='covenant_credit' and action=='assign_preview':
            self.settlement_flags.require('factoring')
            from .credit_preview import assignment_quote
            return assignment_quote(**p)
        if name=='covenant_settlement':
            from .settlement_plugins.tools import call as settlement_call
            return settlement_call(action,p,flags=self.settlement_flags)
        if name in {'covenant_credit','covenant_market_blueprint'}:
            if action in {'observe_local','assent','preview_cost'}:
                need(self.adapters is not None,'EXCHANGE_WORKFLOW_REQUIRED');adapter=self.adapters.get(p.pop('adapter'))
                need(hasattr(adapter,'credit'),'CREDIT_ADAPTER_UNSUPPORTED')
                from .credit_preview import preview,timing
                if action=='preview_cost':return preview(adapter,**p)
                if action=='assent':return adapter.credit_assent(**p)
                result=adapter.credit(**p);result['timing']=timing(result['spec'],p.get('height'));return result
            if name=='covenant_credit' and action=='create':p['kind']='TERM_CREDIT'
            result=getattr(market_blueprints,action)(**p)
            return {'asset':result,'execution_authorized':False} if action=='asset' else result
        if name=='covenant_proof':
            if action=='list_verifiers':return {'verifiers':self.proofs.describe(),'remote_install_allowed':False}
            if action=='pack':return pack_proof(**p)
            if action=='inspect':return inspect_proof(**p)
            if action=='commitment':return {'commitment':commitment(**p),'execution_authorized':False}
            return self.proofs.verify(**p)
        if name=='covenant_forum_read':
            if action=='export':return self.network.export()
            from . import social_views
            return getattr(social_views,action)(self.network,**p)
        if name=='covenant_forum_write':
            if action=='import':return self.network.import_events(**p)
            need(p.get('kind') in {'GROUP','POST','CORRECT','MODERATE','LINK','ENDORSE'},'EXCHANGE_FORUM_KIND')
            from .social_views import guarded_emit
            return guarded_emit(self.network,**p)
        if name in {'covenant_roles','covenant_arbitration'}:
            kinds={'covenant_roles':{'propose':'ROLE_PROPOSE','accept':'ROLE_ACCEPT','revoke':'ROLE_REVOKE'},'covenant_arbitration':{'claim':'DISPUTE','accept':'DISPUTE_ACCEPT','resolve':'RESOLVE'}}
            from .social_views import guarded_emit
            if name=='covenant_arbitration' and action=='claim':
                content=deepcopy(p['content']);parties=content['parties']
                need(len(parties)==len(set(parties)),'NETWORK_ARBITRATION_DUPLICATE_PARTY')
                content['parties']=sorted(parties);p['content']=content
            return guarded_emit(self.network,kind=kinds[name][action],**p)
        if name=='covenant_reputation' and action=='certified_reviews':
            from .review import contextual_view
            snap=self.workflow.read_snapshot()
            return {**contextual_view(snap.state,**p),'certified_as_of':snap.head,'latest_head_known':False,
                'assurance':'COMMITTEE_CERTIFIED_PROCEDURE_AND_ATTRIBUTION','execution_authorized':False}
        if name in {'covenant_reputation','covenant_discovery'}:
            from .discovery_rank import reputation
            view = reputation(self.network, **p)
            view['view'] = True
            view['native_balance'] = False
            view['covenant_score'] = None
            view['qualified_as'] = 'network:reputation' if name == 'covenant_reputation' else 'network:discovery'
            return view
        if name=='covenant_prediction':return self.prediction(action,p)
        if name=='covenant_wager':
            need(not any(k.startswith('_') for k in p) and 'crash' not in p,'EXCHANGE_PRIVATE_PARAMETER')
            if action=='create':
                docs=p.get('documents');need(type(docs) is dict and all(type(v) is str for v in docs.values()),'MARKET_MATERIAL_TEXT')
                p['documents']={k:v.encode('utf-8') for k,v in docs.items()};return bound_call('EXCHANGE_PARAMETERS',self.markets.create,**p)
            if action in {'fund','place'}:return bound_call('EXCHANGE_PARAMETERS',getattr(self.markets,'trade' if action=='place' else action),**p)
            need('action' not in p,'EXCHANGE_PARAMETERS')
            return bound_call('EXCHANGE_PARAMETERS',self.markets.resolve,action=action,**p)
        if name=='covenant_exchange':
            if action=='adapters':return {'adapters':self.adapters.describe() if self.adapters is not None else {},'workflow_configured':self.workflow is not None,'remote_code_loading':False,'external_atomicity':'NOT_INFERRED'}
            if action=='quote_fee':need(self.fee_policy is not None,'EXCHANGE_FEE_POLICY_REQUIRED');return quote_fee(self.fee_policy,**p)
            need(self.adapters is not None,'EXCHANGE_WORKFLOW_REQUIRED');adapter=self.adapters.get(p['adapter']);request=p['request']
            if action=='preview_payment':
                need(hasattr(adapter,'preview'),'PAYMENT_PREVIEW_UNSUPPORTED');return adapter.preview(request)
            import hashlib
            from covenant_language.agentic import canonical
            def input_hash(value):return hashlib.sha256(canonical(value)).hexdigest()
            return {'adapter':p['adapter'],'manifest':deepcopy(adapter.manifest),'request':request,'request_hash':input_hash(request),
                'next':'preview_cooperation WITH_THIS_REQUEST_HASH_THEN_EXACT_APPROVALS_AND_EXECUTE' if self.workflow is not None else 'READ_INTERFACE_ONLY; SEPARATELY_ADOPT_EXACT_OWNER_EXECUTION_AUTHORITY',
                'workflow_configured':self.workflow is not None,'execution_authorized':False}
        if action=='benefits' and self.fee_policy is None:
            return {'adopted':False,'benefits':None,'execution_authorized':False,'assurance':'NO_ADOPTED_FEE_POLICY'}
        need(self.fee_policy is not None,'EXCHANGE_FEE_POLICY_REQUIRED')
        if action=='benefits':return token_benefits(self.fee_policy)
        integer(p['units'],True);need(p['service'] in self.fee_policy['token']['credit_prices'],'TOKEN_CREDIT_UNKNOWN')
        cost=p['units']*self.fee_policy['token']['credit_prices'][p['service']];integer(cost)
        return {'service':p['service'],'units':p['units'],'amount':cost,'unit':self.fee_policy['token']['resource'],
            'inventory':'NOT_RESERVED','execution_authorized':False,'adapter_required':'EXACT_INSTALLED_TOKEN_CREDIT_REDEMPTION'}
    def prediction(self,action,p):
        if action=='score':return games.forecast_score(**p)
        if action=='aggregate':return aggregate_forecasts(**p)
        need(self.markets is not None,'EXCHANGE_MARKET_POLICY_REQUIRED')
        snap=self.markets.workflow.read_snapshot();market=p['market'];m=self.markets._adopted(market,snap)
        if action=='inspect':return {'market':market,'record':deepcopy(m),'certified_as_of':snap.head,'latest_head_known':False,'price_is_probability':False,'world_truth':'NOT_ESTABLISHED'}
        from .prediction_sdk import make_order
        terms=m['terms'];need(p['outcome'] in terms['outcomes'],'PREDICTION_OUTCOME')
        integer(p['quantity'],True);integer(p['price']);integer(p['expiry'],True);need(p['price']<=terms['payout_per_unit'],'PREDICTION_PRICE')
        need(p['seller']!=p['buyer'] and p['expiry']>snap.head['height'],'PREDICTION_ORDER')
        order=make_order(snap.state,**p);cost=p['price']*p['quantity'];integer(cost)
        payout=terms['payout_per_unit']*p['quantity'];integer(payout)
        void=terms['payout_per_unit']//len(terms['outcomes'])*p['quantity']
        return {'order':order,'terms':deepcopy(terms),'buyer_cost':cost,'unit':terms['resource'],
            'buyer_net_by_resolution':{'WIN':payout-cost,'LOSS':-cost,'VOID':void-cost},
            'complete_set_collateral_if_minted':payout,'void_policy':'EQUAL_OUTCOME_SHARES_NOT_PURCHASE_PRICE_REFUND',
            'native_fees':'ADDITIONAL_WITHIN_ADOPTED_BUDGETS','funding':'NOT_RESERVED','execution_authorized':False}
