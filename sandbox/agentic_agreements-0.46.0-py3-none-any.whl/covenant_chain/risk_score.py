"""A deterministic risk score from typed fields, used to ask for more approval, never less.

covenant-risk-score/0.1 computes integer basis points (0 to 10000) from five
typed inputs, never from prose, tool descriptions or names:

- amount: the MONEY amount against the owner's scale for its unit (an unlisted
  unit scores 10000);
- irreversibility: REVERSIBLE 0, COMPENSABLE 5000, IRREVERSIBLE 10000;
- history: fulfilled, failed and disputed counts from verified receipts, with
  additive smoothing, 10000 * (failed + disputed + 2) // (total + 2);
- breadth: covenant-verb-scope/0.1 breadth of the scopes the actor holds;
- novelty: 10000 for a counterparty with no earlier record, else 0.

An input the caller cannot supply is unknown and scores 10000: unknown never
lowers risk. The score is the weighted integer mean under owner weights. An
owner policy compares it with ``above_bps``; in covenant-assent-policy/0.2 a
score above it requires approval in addition to the money threshold, and it can
never waive an approval the money threshold requires. Changing the formula is
a new version.
"""
from copy import deepcopy
import re

from . import verb_scopes
from .crypto import need

VERSION = 'covenant-risk-score/0.1'
FACTORS = ('amount', 'breadth', 'history', 'irreversibility', 'novelty')
IRREVERSIBILITY = {'REVERSIBLE': 0, 'COMPENSABLE': 5000, 'IRREVERSIBLE': 10000}
PRIOR = 2
MAX_BPS = 10000
MAX_COUNT = 2**31 - 1
UNIT = re.compile(r'[\x21-\x7e]{1,80}\Z')
REMEDIATION = {
    'RISK_POLICY': 'Write the risk policy as profile covenant-risk-score/0.1, above_bps 0..10000, an integer weight 0..100 for each of amount, breadth, history, irreversibility and novelty (at least one above 0) and a sorted, distinct amount_scale of positive amounts.',
    'RISK_AMOUNT': 'Give the amount as {"kind": "MONEY", "amount": integer, "unit": printable unit}, or null when unknown.',
    'RISK_IRREVERSIBILITY': 'Give REVERSIBLE, COMPENSABLE or IRREVERSIBLE, or null when unknown.',
    'RISK_HISTORY': 'Give receipt counts as {"fulfilled", "failed", "disputed"} non-negative integers, or null when unknown.',
    'RISK_NOVELTY': 'Give true or false, or null when unknown.',
}


def validate_policy(policy):
    """An owner's risk trigger: profile, threshold, weights and amount scale."""
    need(type(policy) is dict and set(policy) == {'profile', 'above_bps', 'weights', 'amount_scale'}, 'RISK_POLICY')
    need(policy['profile'] == VERSION and type(policy['above_bps']) is int and 0 <= policy['above_bps'] <= MAX_BPS,
         'RISK_POLICY')
    weights = policy['weights']
    need(type(weights) is dict and set(weights) == set(FACTORS) and
         all(type(value) is int and 0 <= value <= 100 for value in weights.values()) and sum(weights.values()) > 0,
         'RISK_POLICY')
    scale = policy['amount_scale']
    need(type(scale) is list and len(scale) <= 16, 'RISK_POLICY')
    for row in scale:
        need(type(row) is dict and set(row) == {'unit', 'amount'} and type(row['unit']) is str and
             UNIT.fullmatch(row['unit']) is not None and type(row['amount']) is int and
             0 < row['amount'] <= 2**53 - 1, 'RISK_POLICY')
    units = [row['unit'] for row in scale]
    need(units == sorted(set(units)), 'RISK_POLICY')
    return policy


def policy(above_bps, weights, amount_scale=()):
    """An exact policy value; ``amount_scale`` maps a unit to the amount that scores 10000."""
    if type(amount_scale) is dict:
        amount_scale = [{'unit': unit, 'amount': amount} for unit, amount in sorted(amount_scale.items())]
    value = {'profile': VERSION, 'above_bps': above_bps, 'weights': deepcopy(weights),
             'amount_scale': deepcopy(list(amount_scale))}
    return validate_policy(value)


def history(value):
    """Typed receipt counts, or None for unknown."""
    if value is None:
        return None
    need(type(value) is dict and set(value) == {'fulfilled', 'failed', 'disputed'} and
         all(type(count) is int and 0 <= count <= MAX_COUNT for count in value.values()), 'RISK_HISTORY')
    return value


def history_from_reputation(reputation):
    """Counts per agreement from portable_trust.local_reputation over verified, owner-trusted receipts."""
    need(type(reputation) is dict and type(reputation.get('agreements')) is list, 'RISK_HISTORY')
    counts = {'fulfilled': 0, 'failed': 0, 'disputed': 0}
    for row in reputation['agreements']:
        need(type(row) is dict and type(row.get('status')) is str, 'RISK_HISTORY')
        status = row['status']
        counts['fulfilled' if status == 'FULFILLED' else 'failed' if status == 'FAILED' else 'disputed'] += 1
    return counts


def irreversibility_of_scope(scope):
    """REVERSIBLE for a read, COMPENSABLE for a write, IRREVERSIBLE for anything else."""
    _, _, verb = verb_scopes.parse(scope, concrete=True)
    found = verb_scopes.verb_class(verb)
    return {'READ': 'REVERSIBLE', 'WRITE': 'COMPENSABLE'}.get(found, 'IRREVERSIBLE')


def score(risk_policy, *, amount=None, irreversibility=None, history_counts=None, scopes=None, novel=None):
    """Integer basis points, the factor values and the unknown inputs. Deterministic; reads nothing else."""
    validate_policy(risk_policy)
    unknown = []
    if amount is None:
        unknown.append('amount')
        amount_bps = MAX_BPS
    else:
        need(type(amount) is dict and set(amount) == {'kind', 'amount', 'unit'} and amount['kind'] == 'MONEY' and
             type(amount['amount']) is int and 0 <= amount['amount'] <= 2**53 - 1 and type(amount['unit']) is str and
             UNIT.fullmatch(amount['unit']) is not None, 'RISK_AMOUNT')
        scale = {row['unit']: row['amount'] for row in risk_policy['amount_scale']}.get(amount['unit'])
        amount_bps = MAX_BPS if scale is None else min(MAX_BPS, amount['amount'] * MAX_BPS // scale)
    if irreversibility is None:
        unknown.append('irreversibility')
    else:
        need(irreversibility in IRREVERSIBILITY, 'RISK_IRREVERSIBILITY')
    counts = history(history_counts)
    if counts is None:
        unknown.append('history')
        history_bps = MAX_BPS
    else:
        bad = counts['failed'] + counts['disputed']
        history_bps = MAX_BPS * (bad + PRIOR) // (counts['fulfilled'] + bad + PRIOR)
    if scopes is None:
        unknown.append('breadth')
    if novel is None:
        unknown.append('novelty')
    else:
        need(type(novel) is bool, 'RISK_NOVELTY')
    factors = {'amount': amount_bps, 'breadth': MAX_BPS if scopes is None else verb_scopes.breadth(scopes),
               'history': history_bps,
               'irreversibility': MAX_BPS if irreversibility is None else IRREVERSIBILITY[irreversibility],
               'novelty': MAX_BPS if novel is None or novel else 0}
    weights = risk_policy['weights']
    bps = sum(weights[name] * factors[name] for name in FACTORS) // sum(weights.values())
    return {'profile': VERSION, 'bps': bps, 'factors': factors, 'unknown': sorted(unknown),
            'above_bps': risk_policy['above_bps'], 'above': bps > risk_policy['above_bps'],
            'basis': 'TYPED_FIELDS_ONLY; UNKNOWN_SCORES_HIGHEST', 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'factors': list(FACTORS), 'irreversibility': deepcopy(IRREVERSIBILITY),
            'history': 'BPS = 10000 * (FAILED + DISPUTED + 2) // (TOTAL + 2)', 'breadth': verb_scopes.VERSION,
            'unknown': 'SCORES_10000', 'combination': 'WEIGHTED_INTEGER_MEAN', 'use': 'ADDITIONAL_APPROVAL_TRIGGER_ONLY',
            'execution_authorized': False}
