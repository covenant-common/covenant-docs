"""Price view for the next block. Economics reads it without importing market."""

from copy import deepcopy

from .crypto import integer, need


def _step(value, ema, target, pricing):
    signed = (ema - target) * pricing['step_bps'] // target
    signed = max(-pricing['step_bps'], min(pricing['step_bps'], signed))
    change = abs(value * signed) // 10000
    if signed and not change:
        change = 1
    out = value + change if signed > 0 else value - change if signed < 0 else value
    return max(pricing['min_bps'], min(pricing['max_bps'], out))


def projected_meter(state, height):
    meter = deepcopy(state['market_meter']['active'])
    integer(height, True)
    if meter['height'] == height:
        return meter
    need(height == meter['height'] + 1, 'MARKET_HEIGHT_CONTINUITY')
    pricing = state['market_config']['active']['body']['pricing']
    if meter['height']:
        for name in ('work', 'kib'):
            meter[name + '_ema'] = ((pricing['smoothing'] - 1) * meter[name + '_ema'] + meter[name]) // pricing['smoothing']
            meter[name + '_bps'] = _step(meter[name + '_bps'], meter[name + '_ema'], pricing['target_' + name], pricing)
    meter.update(height=height, work=0, kib=0)
    return meter


def price_view(state, height):
    meter = projected_meter(state, height)
    pending = state['market_config'].get('pending')
    if pending and height >= pending['effective']:
        pricing = pending['body']['pricing']
        for name in ('work', 'kib'):
            meter[name + '_bps'] = max(pricing['min_bps'], min(pricing['max_bps'], meter[name + '_bps']))
    return {'work_bps': meter['work_bps'], 'kib_bps': meter['kib_bps']}
