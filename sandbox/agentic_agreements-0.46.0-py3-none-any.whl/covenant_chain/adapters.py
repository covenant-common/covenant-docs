"""Owner-installed execution adapters with explicit recovery/assurance contracts.

Descriptors cannot download code. An adapter must be installed under its exact
manifest ID; changed manifests need new agreement. Receipts state actual scope.
"""
from copy import deepcopy
import hashlib
import json
import sqlite3
import os,secrets,stat
from pathlib import Path

from covenant_language.agentic import canonical
from covenant_language.handoff import FileOutbox
from covenant_language.safe_io import atomic_write
from .crypto import exact,integer,key,need
from .workflow_store import WorkflowStore,identifier

VERSION='covenant-adapter/0.1'
EFFECT='covenant-workflow-effect/0.1'


def manifest(name,capability,*,effect,instance,recovery='IDEMPOTENT_KEY',reversible=False,max_bytes=65536):
    integer(max_bytes,True)
    key(instance)
    value=dict(version=VERSION,name=name,capability=capability,effect=effect,instance=instance,recovery=recovery,
               reversible=reversible,max_bytes=max_bytes,privacy=['LOCAL_CONTENT','PUBLIC_LEDGER_METADATA'],
               implementation='OWNER_INSTALLED_NO_REMOTE_CODE',
               requirements=dict(authority='CERTIFIED_SERVICE_BOOKING_AND_PROVIDER_APPROVAL',
                   resources='NATIVE_BOOKING_ESCROWS',input='EXACT_HASH_OR_ADOPTED_JUDGMENT'),
               completion='OBSERVED_EFFECT_WITH_CONTENT_HASH',timeout='OBSERVE_DO_NOT_ASSUME_FAILURE',
               cancellation='DRAFT_ONLY_NO_AUTOMATIC_REVERSAL',compensation='SEPARATE_EXPLICIT_COMMITMENT')
    canonical(value)
    return value


def manifest_id(value):return identifier('COVENANT-ADAPTER-MANIFEST-0.1',value)


class AdapterRegistry:
    def __init__(self):self._entries={}
    def register(self,adapter):
        m=deepcopy(adapter.manifest)
        exact(m,'version name capability effect instance recovery reversible max_bytes privacy implementation requirements completion timeout cancellation compensation')
        need(m['version']==VERSION and m['recovery'] in {'IDEMPOTENT_KEY','OBSERVE_ONLY'}
             and type(m['reversible']) is bool,'ADAPTER_MANIFEST')
        ref=manifest_id(m);need(ref not in self._entries,'ADAPTER_ALREADY_INSTALLED')
        need(callable(adapter.execute) and callable(adapter.observe),'ADAPTER_IMPLEMENTATION')
        self._entries[ref]=(m,adapter);return ref
    def describe(self):return {ref:deepcopy(v[0]) for ref,v in self._entries.items()}
    def get(self,ref):
        need(ref in self._entries,'ADAPTER_NOT_INSTALLED')
        m,adapter=self._entries[ref]
        need(manifest_id(adapter.manifest)==ref,'ADAPTER_MANIFEST_CHANGED')
        return adapter
    def accepts(self,descriptor,capability):
        if type(descriptor) is not dict or descriptor.get('profile')!=EFFECT:return False
        validate_effect(descriptor)
        return capability=='workflow.execute' and descriptor['adapter'] in self._entries


def validate_effect(effect):
    from .conditions import validate
    exact(effect,'profile adapter condition dependencies request_binding')
    need(effect['profile']==EFFECT,'WORKFLOW_EFFECT_PROFILE');key(effect['adapter']);validate(effect['condition'])
    need(type(effect['dependencies']) is list and len(effect['dependencies'])<=32,'WORKFLOW_DEPENDENCIES')
    for d in effect['dependencies']:
        exact(d,'task kind output_hash')
        key(d['task']);key(d['output_hash'])
        need(d['kind'] in {'OBSERVED_EFFECT','CONDITIONAL_RIGHT','UNSECURED_OBLIGATION'},'WORKFLOW_RIGHT_KIND')
    need(len({d['task'] for d in effect['dependencies']})==len(effect['dependencies']),'WORKFLOW_DUPLICATE_DEPENDENCY')
    binding=effect['request_binding'];need(type(binding) is dict,'WORKFLOW_REQUEST_BINDING')
    if binding.get('kind')=='FIXED':exact(binding,'kind hash');key(binding['hash'])
    else:exact(binding,'kind reviewer');need(binding['kind']=='JUDGED','WORKFLOW_REQUEST_BINDING');key(binding['reviewer'])
    return True


def _instance(directory):
    directory=Path(directory);directory.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        need(stat.S_IMODE(os.fstat(fd).st_mode)&0o077==0,'ADAPTER_PRIVATE_DIRECTORY')
        try:atomic_write('adapter-instance',secrets.token_hex(32).encode('ascii'),mode=0o600,exclusive=True,dir_fd=fd)
        except FileExistsError:pass
        f=os.open('adapter-instance',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
        try:
            info=os.fstat(f);need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode)&0o077==0,'ADAPTER_PRIVATE_INSTANCE')
            value=os.read(f,65).decode('ascii');key(value);return value
        finally:os.close(f)
    finally:os.close(fd)


class FileAdapter:
    def __init__(self,directory,max_bytes=65536):
        self.manifest=manifest('file-publication','file.publish',effect='LOCAL_WRITE_ONCE_FILE',instance=_instance(directory),max_bytes=max_bytes)
        self.outbox=FileOutbox(directory)
    def execute(self,effect_id,request,*,crash=None):
        exact(request,'text');need(type(request['text']) is str,'ADAPTER_TEXT')
        raw=request['text'].encode('utf-8');need(len(raw)<=self.manifest['max_bytes'],'ADAPTER_INPUT_SIZE')
        self.outbox.enqueue(effect_id,raw);self.outbox.run(effect_id,crash=crash)
        return self.observe(effect_id)
    def observe(self,effect_id):
        result=self.outbox.observe(effect_id)
        return dict(status=result['status'],output_hash=result.get('content'),
                    assurance='LOCAL_WRITE_ONCE_FILE',details=result)
    def close(self):self.outbox.close()


class RecordAdapter:
    """An actual local SQLite record, with no caller-selected SQL/path/table.

    The configured host controls the database. Keyed records are append-only;
    another resource profile may explicitly model updates as new versions.
    """
    def __init__(self,directory,namespace='records',max_bytes=65536):
        need(type(namespace) is str and 0<len(namespace)<=128,'ADAPTER_NAMESPACE')
        self.manifest=manifest('record-publication:'+namespace,'record.publish',effect='LOCAL_SQLITE_RECORD',instance=_instance(directory),max_bytes=max_bytes)
        self.store=WorkflowStore(directory,dict(adapter=manifest_id(self.manifest)))
        self.db=self.store.db
        self.db.execute('CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,request_hash TEXT NOT NULL,body BLOB NOT NULL)')
    def execute(self,effect_id,request,*,crash=None):
        key(effect_id);raw=canonical(request);need(len(raw)<=self.manifest['max_bytes'],'ADAPTER_INPUT_SIZE')
        ref=hashlib.sha256(raw).hexdigest()
        with self.store.exclusive():
            self.db.execute('BEGIN IMMEDIATE')
            try:
                old=self.db.execute('SELECT request_hash FROM records WHERE id=?',(effect_id,)).fetchone()
                need(old is None or old[0]==ref,'ADAPTER_REQUEST_CHANGED')
                self.db.execute('INSERT OR IGNORE INTO records VALUES (?,?,?)',(effect_id,ref,raw));self.db.execute('COMMIT')
            except BaseException:self.db.execute('ROLLBACK');raise
        if crash=='after_effect':
            from covenant_language.handoff import InjectedCrash
            raise InjectedCrash('after_effect')
        return self.observe(effect_id)
    def observe(self,effect_id):
        key(effect_id);row=self.db.execute('SELECT request_hash,body FROM records WHERE id=?',(effect_id,)).fetchone()
        if row is None:return dict(status='NOT_OBSERVED',output_hash=None,assurance='LOCAL_SQLITE_RECORD')
        need(hashlib.sha256(row[1]).hexdigest()==row[0],'ADAPTER_STORAGE_CHANGED')
        return dict(status='OBSERVED',output_hash=row[0],assurance='LOCAL_SQLITE_RECORD',value=json.loads(row[1]))
    def close(self):self.store.close()
