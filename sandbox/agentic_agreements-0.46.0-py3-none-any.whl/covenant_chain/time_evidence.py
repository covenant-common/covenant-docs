"""covenant-time-evidence/0.1: a conservative time interval from independent sources.

No single clock is trusted. Each source the agreement parties adopt bounds the
moment a bundle of evidence was sealed:

- Roughtime answers chained from the bundle's subject: signed, after the
  subject, upper bound plus the gatherer's declared elapsed seconds;
- witness-cosigned checkpoints and committee-certified block times: signed
  lower bounds only;
- GNSS receiver reports: claims that a spoofed or replayed signal can move.
  A receiver's OSNMA status is its own report; it is not verified here.

The parties' policy names every source, its operator and a threshold k of at
least two. Over distinct counted operators the interval is the k-th largest
lower bound to the k-th smallest upper bound, so fewer than k lying operators
cannot move it past the truth; at least k operators must also overlap inside
it. Too few or only receiver-claim sources, a wider interval than the policy
allows, or a proven Roughtime causality violation give UNKNOWN. A deadline has
passed only when not_before > deadline and has not yet arrived only when
not_after < deadline; otherwise it is UNDETERMINED. Nothing here reads a
clock, signs for a party, installs a source or authorizes execution.
"""
from copy import deepcopy

from . import geo_fix, roughtime as rt
from .crypto import canonical, digest, exact, integer, key, need, sign, verification_key, verify
from .governance import BLOCK_TIME_SKEW

VERSION = 'covenant-time-evidence/0.1'
LABEL = 'COVENANT-TIME-EVIDENCE-0.1'
SOURCE_FIELDS = {
    'ROUGHTIME': 'id kind operator protocol public_key',
    'GNSS': 'id kind operator device_key accuracy_seconds',
    'WITNESS': 'id kind operator log witness_keys quorum skew_seconds',
    'BLOCK': 'id kind operator chain validators faults skew_seconds',
}
OBSERVATIONS = {'ROUGHTIME_CHAIN': 'ROUGHTIME', 'GNSS': 'GNSS', 'WITNESS_CHECKPOINT': 'WITNESS', 'BLOCK_TIME': 'BLOCK'}
RECEIVER_CLAIMS = ('NONE', 'OSNMA_ONLY', 'ALL')
OSNMA = ('AUTHENTICATED', 'NOT_AUTHENTICATED', 'UNAVAILABLE')
MAX_SOURCES = 64
MAX_OBSERVATIONS = 64
MAX_BYTES = 2_000_000
MAX_SECONDS = 2**53 - 1


def _text(value, maximum, code='TIME_TEXT'):
    need(type(value) is str and 0 < len(value) <= maximum and value.isascii() and value.isprintable(), code)


def _ed25519(value, code):
    need(type(value) is str, code)
    try:
        verification_key(value)
    except ValueError:
        raise ValueError(code) from None


def _seconds(value, maximum, code):
    need(type(value) is int and 0 <= value <= maximum, code)


def _source(row):
    need(type(row) is dict and row.get('kind') in SOURCE_FIELDS, 'TIME_SOURCE_KIND')
    need(set(row) == set(SOURCE_FIELDS[row['kind']].split()), 'TIME_SOURCE_FIELDS')
    _text(row['id'], 64, 'TIME_SOURCE_ID'); _text(row['operator'], 128, 'TIME_OPERATOR')
    if row['kind'] == 'ROUGHTIME':
        need(row['protocol'] in rt.PROTOCOLS, 'TIME_ROUGHTIME_PROTOCOL')
        try:
            rt.key_bytes(row['public_key'])
        except ValueError:
            raise ValueError('TIME_ROUGHTIME_KEY') from None
    elif row['kind'] == 'GNSS':
        _ed25519(row['device_key'], 'TIME_GNSS_DEVICE_KEY'); _seconds(row['accuracy_seconds'], 86400, 'TIME_GNSS_ACCURACY')
    elif row['kind'] == 'WITNESS':
        _ed25519(row['log'], 'TIME_WITNESS_KEYS')
        keys = row['witness_keys']
        need(type(keys) is list and 1 <= len(keys) <= 32 and len(set(keys)) == len(keys) and row['log'] not in keys,
             'TIME_WITNESS_KEYS')
        for value in keys:
            _ed25519(value, 'TIME_WITNESS_KEYS')
        need(type(row['quorum']) is int and 1 <= row['quorum'] <= len(keys), 'TIME_WITNESS_QUORUM')
        _seconds(row['skew_seconds'], 86400, 'TIME_SKEW')
    else:
        need(type(row['chain']) is str, 'TIME_BLOCK_CHAIN'); key(row['chain'])
        members = row['validators']
        need(type(members) is dict and 1 <= len(members) <= 64 and len(set(members.values())) == len(members),
             'TIME_BLOCK_COMMITTEE')
        for name, value in members.items():
            _text(name, 64, 'TIME_BLOCK_COMMITTEE'); _ed25519(value, 'TIME_BLOCK_COMMITTEE')
        need(type(row['faults']) is int and 0 <= row['faults'] and len(members) >= 3 * row['faults'] + 1,
             'TIME_BLOCK_COMMITTEE')
        need(type(row['skew_seconds']) is int and BLOCK_TIME_SKEW <= row['skew_seconds'] <= 86400, 'TIME_SKEW')
    return row


def check_policy(value):
    """Validate the parties' policy; returns an independent copy."""
    need(type(value) is dict, 'TIME_POLICY')
    exact(value, 'version kind threshold max_spread_seconds max_elapsed_seconds minimum_signed receiver_claims sources')
    need(value['version'] == VERSION and value['kind'] == 'POLICY', 'TIME_PROFILE')
    sources = value['sources']
    need(type(sources) is list and 2 <= len(sources) <= MAX_SOURCES, 'TIME_POLICY_SOURCES')
    for row in sources:
        _source(row)
    ids = [row['id'] for row in sources]
    need(ids == sorted(set(ids)), 'TIME_POLICY_SOURCES')
    operators = {row['operator'] for row in sources}
    # Never a single trusted clock: at least two distinct operators must agree.
    need(type(value['threshold']) is int and 2 <= value['threshold'] <= len(operators), 'TIME_POLICY_THRESHOLD')
    need(value['max_spread_seconds'] is None or
         (type(value['max_spread_seconds']) is int and 0 <= value['max_spread_seconds'] <= 2**31), 'TIME_POLICY_SPREAD')
    _seconds(value['max_elapsed_seconds'], 3600, 'TIME_POLICY_ELAPSED')
    need(type(value['minimum_signed']) is int and 0 <= value['minimum_signed'] <= value['threshold'], 'TIME_POLICY_SIGNED')
    need(value['receiver_claims'] in RECEIVER_CLAIMS, 'TIME_POLICY_RECEIVER_CLAIMS')
    need(len(canonical(value)) <= MAX_BYTES, 'TIME_SIZE')
    return deepcopy(value)


def policy(sources, threshold, max_spread_seconds, *, max_elapsed_seconds=10, minimum_signed=1, receiver_claims='NONE'):
    """Build the parties' policy. Sources are sorted by id; operators are exact labels."""
    need(type(sources) is list, 'TIME_POLICY_SOURCES')
    return check_policy({'version': VERSION, 'kind': 'POLICY', 'threshold': threshold,
                         'max_spread_seconds': max_spread_seconds, 'max_elapsed_seconds': max_elapsed_seconds,
                         'minimum_signed': minimum_signed, 'receiver_claims': receiver_claims,
                         'sources': sorted(deepcopy(sources), key=lambda row: str(row.get('id')) if type(row) is dict else '')})


def policy_id(value):
    return digest(LABEL + '-POLICY', check_policy(value))


def roughtime_source(id, operator, public_key, protocol=rt.IETF):
    return _source({'id': id, 'kind': 'ROUGHTIME', 'operator': operator, 'protocol': protocol, 'public_key': public_key})


def gnss_source(id, operator, device_key, accuracy_seconds):
    return _source({'id': id, 'kind': 'GNSS', 'operator': operator, 'device_key': device_key,
                    'accuracy_seconds': accuracy_seconds})


def witness_source(id, operator, log, witness_keys, quorum, skew_seconds):
    return _source({'id': id, 'kind': 'WITNESS', 'operator': operator, 'log': log, 'witness_keys': list(witness_keys),
                    'quorum': quorum, 'skew_seconds': skew_seconds})


def block_source(id, operator, chain, validators, faults, skew_seconds=2 * BLOCK_TIME_SKEW):
    return _source({'id': id, 'kind': 'BLOCK', 'operator': operator, 'chain': chain, 'validators': dict(validators),
                    'faults': faults, 'skew_seconds': skew_seconds})


def _check_report(report):
    need(type(report) is dict, 'TIME_GNSS_REPORT')
    exact(report, 'version kind subject sentences osnma')
    need(report['version'] == VERSION and report['kind'] == 'GNSS_REPORT', 'TIME_GNSS_REPORT')
    need(type(report['subject']) is str, 'TIME_SUBJECT'); key(report['subject'])
    need(report['osnma'] in OSNMA, 'TIME_GNSS_OSNMA')
    need(type(report['sentences']) is list and 1 <= len(report['sentences']) <= 8, 'TIME_GNSS_REPORT')
    for sentence in report['sentences']:
        _text(sentence, 120, 'TIME_GNSS_REPORT')
    return report


def gnss_report(subject, sentences, osnma='UNAVAILABLE'):
    """What one receiver reports: exact NMEA sentences and its own OSNMA status."""
    return _check_report({'version': VERSION, 'kind': 'GNSS_REPORT', 'subject': subject,
                          'sentences': list(sentences), 'osnma': osnma})


def sign_report(report, private_key):
    """Explicit local device action. The signature names the reporter, not a true signal."""
    return sign(private_key, LABEL + '-GNSS', _check_report(report))


def gnss_observation(source, report, signature, elapsed_seconds):
    return {'kind': 'GNSS', 'source': source, 'report': deepcopy(report), 'signature': signature,
            'elapsed_seconds': elapsed_seconds}


def witness_observation(source, record):
    return {'kind': 'WITNESS_CHECKPOINT', 'source': source, 'record': deepcopy(record)}


def block_observation(source, block, certificate):
    return {'kind': 'BLOCK_TIME', 'source': source, 'block': deepcopy(block), 'certificate': deepcopy(certificate)}


def roughtime_observation(links):
    return {'kind': 'ROUGHTIME_CHAIN', 'links': deepcopy(links)}


def measure_roughtime(value, subject, servers, **options):
    """Network leg: one chain over an explicit owner list of [source id, host:port].

    Never called by assess or by tests; keys and protocols come from the policy.
    """
    checked = check_policy(value)
    need(type(subject) is str, 'TIME_SUBJECT'); key(subject)
    adopted = {row['id']: row for row in checked['sources'] if row['kind'] == 'ROUGHTIME'}
    need(type(servers) is list and servers and all(type(row) in (list, tuple) and len(row) == 2 and type(row[0]) is str
                                                     and row[0] in adopted for row in servers), 'TIME_ROUGHTIME_SERVERS')
    rows = [{'source': source, 'protocol': adopted[source]['protocol'], 'public_key': adopted[source]['public_key'],
             'address': address} for source, address in servers]
    return roughtime_observation(rt.measure(rows, bytes.fromhex(subject), **options))


def bundle(subject, value, observations):
    need(type(subject) is str, 'TIME_SUBJECT'); key(subject)
    return {'version': VERSION, 'kind': 'BUNDLE', 'subject': subject, 'policy': policy_id(value),
            'observations': deepcopy(observations)}


def _adopted(sources, name, kind):
    row = sources.get(name) if type(name) is str else None
    need(row is not None and row['kind'] == kind, 'TIME_SOURCE_NOT_ADOPTED')
    return row


def _row(source, kind, lower, upper, signed, assurance, **detail):
    need(abs(lower) <= MAX_SECONDS and (upper is None or abs(upper) <= MAX_SECONDS), 'TIME_RANGE')
    return {'source': source['id'], 'operator': source['operator'], 'kind': kind, 'lower': lower, 'upper': upper,
            'signed': signed, 'assurance': assurance, **detail}


def _roughtime(observation, sources, subject, limit):
    exact(observation, 'kind links')
    links = observation['links']
    need(type(links) is list and 1 <= len(links) <= rt.MAX_LINKS, 'TIME_ROUGHTIME_LINKS')
    adopted, decoded = [], []
    for link in links:
        need(type(link) is dict, 'TIME_ROUGHTIME_LINKS'); exact(link, 'source rand request response elapsed_seconds')
        source = _adopted(sources, link['source'], 'ROUGHTIME')
        _seconds(link['elapsed_seconds'], limit, 'TIME_ELAPSED')
        adopted.append(source)
        decoded.append({'protocol': source['protocol'], 'public_key': source['public_key'],
                        'rand': rt.unb64(link['rand'], 64), 'request': rt.unb64(link['request']),
                        'response': rt.unb64(link['response'])})
    checked = rt.verify_chain(decoded, bytes.fromhex(subject))
    rows = [_row(source, 'ROUGHTIME', result['lower'], result['upper'] + link['elapsed_seconds'], True,
                 'ROUGHTIME_SIGNED_AFTER_SUBJECT', signed_upper=result['upper'])
            for source, link, result in zip(adopted, links, checked['links'])]
    proofs = [{'earlier': links[i]['source'], 'later': links[j]['source'],
               'earlier_interval': [checked['links'][i]['lower'], checked['links'][i]['upper']],
               'later_interval': [checked['links'][j]['lower'], checked['links'][j]['upper']]}
              for i, j in checked['violations']]
    return rows, proofs


def _gnss(observation, sources, subject, limit):
    exact(observation, 'kind source report signature elapsed_seconds')
    source = _adopted(sources, observation['source'], 'GNSS')
    report = _check_report(observation['report'])
    need(report['subject'] == subject, 'TIME_SUBJECT')
    _seconds(observation['elapsed_seconds'], limit, 'TIME_ELAPSED')
    try:
        verify(source['device_key'], LABEL + '-GNSS', report, observation['signature'])
    except ValueError:
        raise ValueError('TIME_GNSS_SIGNATURE') from None
    times = [geo_fix.parse_nmea_time(sentence) for sentence in report['sentences']]
    lowest = min(row['utc'] for row in times)
    highest = max(row['utc'] + row['fraction'] for row in times)
    need(highest - lowest <= 2, 'TIME_GNSS_INCONSISTENT')
    accuracy = source['accuracy_seconds']
    authenticated = report['osnma'] == 'AUTHENTICATED'
    return _row(source, 'GNSS', lowest - accuracy, highest + accuracy + observation['elapsed_seconds'], False,
                'RECEIVER_CLAIM_OSNMA_REPORTED' if authenticated else 'RECEIVER_CLAIM_UNAUTHENTICATED',
                osnma=report['osnma'])


def _witness(observation, sources):
    from .portable_trust import _record
    exact(observation, 'kind source record')
    source = _adopted(sources, observation['source'], 'WITNESS')
    body, ref, signers = _record(observation['record'], 'CHECKPOINT', additional_signers=source['witness_keys'])
    need(body['log'] == source['log'], 'TIME_WITNESS_LOG')
    witnesses = sorted(signers & set(source['witness_keys']))
    need(len(witnesses) >= source['quorum'], 'TIME_WITNESS_QUORUM')
    return _row(source, 'WITNESS', body['issued_at'] - source['skew_seconds'], None, True,
                'WITNESS_QUORUM_LOWER_BOUND', checkpoint=ref, witnesses=witnesses)


def _block(observation, sources):
    exact(observation, 'kind source block certificate')
    source = _adopted(sources, observation['source'], 'BLOCK')
    block, certificate = observation['block'], observation['certificate']
    need(type(block) is dict and 'time' in block, 'TIME_BLOCK_UNTIMED')
    exact(block, 'chain height parent txs state_root time')
    need(block['chain'] == source['chain'], 'TIME_BLOCK_CHAIN')
    integer(block['height'], True); integer(block['time'])
    need(type(certificate) is dict, 'TIME_BLOCK_CERTIFICATE'); exact(certificate, 'height round block_id votes')
    block_id = digest('COVENANT_CHAIN_BLOCK', block)
    need(certificate['height'] == block['height'] and certificate['block_id'] == block_id, 'TIME_BLOCK_CERTIFICATE')
    integer(certificate['round'])
    members, votes = source['validators'], certificate['votes']
    need(type(votes) is list and 2 * source['faults'] + 1 <= len(votes) <= len(members), 'TIME_BLOCK_QUORUM')
    expected = {'chain': source['chain'], 'height': block['height'], 'round': certificate['round'], 'block_id': block_id}
    seen = set()
    for vote in votes:
        need(type(vote) is dict, 'TIME_BLOCK_VOTE'); exact(vote, 'kind body signer signature')
        need(type(vote['signer']) is str and vote['signer'] in members and vote['signer'] not in seen, 'TIME_BLOCK_SIGNER')
        need(vote['kind'] == 'precommit' and canonical(vote['body']) == canonical(expected), 'TIME_BLOCK_VOTE')
        try:
            verify(members[vote['signer']], 'COVENANT_CHAIN_PRECOMMIT', expected, vote['signature'])
        except ValueError:
            raise ValueError('TIME_BLOCK_SIGNATURE') from None
        seen.add(vote['signer'])
    return _row(source, 'BLOCK', block['time'] - source['skew_seconds'], None, True,
                'COMMITTEE_CERTIFIED_LOWER_BOUND', height=block['height'], block=block_id)


def _show(lower, upper):
    return '[%d, %s]' % (lower, 'open' if upper is None else upper)


def assess(evidence, value):
    """Verify every observation, then combine distinct operators under the policy.

    Invalid or forged evidence raises a stable code. Valid evidence that does
    not establish an interval returns status UNKNOWN with the reason.
    """
    adopted = check_policy(value)
    need(type(evidence) is dict and len(canonical(evidence)) <= MAX_BYTES, 'TIME_SIZE')
    exact(evidence, 'version kind subject policy observations')
    need(evidence['version'] == VERSION and evidence['kind'] == 'BUNDLE', 'TIME_PROFILE')
    need(type(evidence['subject']) is str, 'TIME_SUBJECT'); key(evidence['subject'])
    identifier = digest(LABEL + '-POLICY', adopted)
    need(evidence['policy'] == identifier, 'TIME_POLICY_MISMATCH')
    observations = evidence['observations']
    need(type(observations) is list and 1 <= len(observations) <= MAX_OBSERVATIONS, 'TIME_OBSERVATIONS')
    sources = {row['id']: row for row in adopted['sources']}
    subject, limit, k = evidence['subject'], adopted['max_elapsed_seconds'], adopted['threshold']
    rows, proofs = [], []
    for observation in observations:
        need(type(observation) is dict and observation.get('kind') in OBSERVATIONS, 'TIME_OBSERVATION_KIND')
        if observation['kind'] == 'ROUGHTIME_CHAIN':
            found, violations = _roughtime(observation, sources, subject, limit)
            rows.extend(found); proofs.extend(violations)
        elif observation['kind'] == 'GNSS':
            rows.append(_gnss(observation, sources, subject, limit))
        elif observation['kind'] == 'WITNESS_CHECKPOINT':
            rows.append(_witness(observation, sources))
        else:
            rows.append(_block(observation, sources))
    mode = adopted['receiver_claims']
    explanation = ['Policy %s: %d distinct operators must agree; up to %d lying operators cannot push the interval '
                   'past the truth.' % (identifier[:16], k, k - 1)]
    groups = {}
    for row in rows:
        row['counted'] = row['signed'] or mode == 'ALL' or (mode == 'OSNMA_ONLY' and row['osnma'] == 'AUTHENTICATED')
        if row['counted']:
            groups.setdefault(row['operator'], []).append(row)
        else:
            explanation.append('%s: GNSS receiver claim, OSNMA %s as the receiver reports it; spoofable and not '
                               'counted under receiver_claims %s.' % (row['source'], row['osnma'], mode))
    operators = []
    for name in sorted(groups):
        group = groups[name]
        lower = max(row['lower'] for row in group)
        uppers = [row['upper'] for row in group if row['upper'] is not None]
        upper = min(uppers) if uppers else None
        entry = {'operator': name, 'lower': lower, 'upper': upper, 'signed': all(row['signed'] for row in group),
                 'sources': sorted({row['source'] for row in group}),
                 'assurance': sorted({row['assurance'] for row in group}), 'agrees': None, 'excluded': None}
        if upper is not None and lower > upper:
            entry['excluded'] = 'TIME_OPERATOR_SELF_INCONSISTENT'
            explanation.append('%s: its own observations do not overlap; excluded.' % name)
        operators.append(entry)
    counted = [entry for entry in operators if entry['excluded'] is None]
    usable = {entry['operator'] for entry in counted}
    signed_upper = {}
    for row in rows:
        if row['kind'] == 'ROUGHTIME' and row['operator'] in usable:
            signed_upper[row['operator']] = min(signed_upper.get(row['operator'], row['signed_upper']), row['signed_upper'])
    existed = sorted(signed_upper.values())
    result = {'version': VERSION, 'status': 'UNKNOWN', 'reason': None, 'not_before': None, 'not_after': None,
              'unit': 'UNIX_SECONDS', 'subject': subject, 'policy': identifier, 'threshold': k, 'assurance': None,
              'subject_existed_by': existed[k - 1] if len(existed) >= k and not proofs else None,
              'operators': operators, 'observations': rows, 'agreeing': [], 'dissenting': [],
              'malfeasance': proofs, 'explanation': explanation, 'single_clock_trusted': False,
              'execution_authorized': False}

    def unknown(reason, text):
        explanation.append('UNKNOWN (%s): %s' % (reason, text))
        result['reason'] = reason
        return result

    if proofs:
        return unknown('TIME_ROUGHTIME_MALFEASANCE', 'a later chained Roughtime answer ends before an earlier one '
                       'begins, a signed proof that a server lied; export the report and measure again without it.')
    if len(counted) < k:
        return unknown('TIME_TOO_FEW_SOURCES', '%d counted operators, %d required.' % (len(counted), k))
    not_before = sorted((entry['lower'] for entry in counted), reverse=True)[k - 1]
    uppers = sorted(entry['upper'] for entry in counted if entry['upper'] is not None)
    not_after = uppers[k - 1] if len(uppers) >= k else None
    ceiling = MAX_SECONDS if not_after is None else not_after

    def covers(point):
        return sum(entry['lower'] <= point and (entry['upper'] is None or point <= entry['upper']) for entry in counted)

    candidates = [not_before] + [entry['lower'] for entry in counted if not_before <= entry['lower'] <= ceiling]
    if not_before > ceiling or max(covers(point) for point in candidates) < k:
        for entry in counted:
            explanation.append('%s: %s.' % (entry['operator'], _show(entry['lower'], entry['upper'])))
        return unknown('TIME_SOURCES_DISAGREE', 'no point inside the bounds is covered by %d operators.' % k)
    for entry in counted:
        entry['agrees'] = entry['lower'] <= ceiling and (entry['upper'] is None or entry['upper'] >= not_before)
        explanation.append('%s: %s from %s (%s); %s.' % (
            entry['operator'], _show(entry['lower'], entry['upper']), ', '.join(entry['sources']),
            ', '.join(entry['assurance']), 'agrees' if entry['agrees'] else 'dissents'))
    result['agreeing'] = [entry['operator'] for entry in counted if entry['agrees']]
    result['dissenting'] = [entry['operator'] for entry in counted if not entry['agrees']]
    spread = adopted['max_spread_seconds']
    if spread is not None and (not_after is None or not_after - not_before > spread):
        return unknown('TIME_SPREAD', 'interval %s is wider than the agreed %d seconds.' % (_show(not_before, not_after), spread))
    signed = sum(entry['signed'] for entry in counted if entry['agrees'])
    if signed < adopted['minimum_signed']:
        return unknown('TIME_WEAK_EVIDENCE', 'only %d agreeing operators are signed sources; %d required. GNSS receiver '
                       'claims are spoofable.' % (signed, adopted['minimum_signed']))
    result.update(status='INTERVAL', not_before=not_before, not_after=not_after,
                  assurance='SIGNED_SOURCES' if signed == len(result['agreeing']) else
                  'RECEIVER_CLAIMS_ONLY' if signed == 0 else 'INCLUDES_RECEIVER_CLAIMS')
    explanation.append('Interval %s agreed by %s. Lower bounds need no freshness; upper bounds add the gatherer\'s '
                       'declared elapsed seconds.' % (_show(not_before, not_after), ', '.join(result['agreeing'])))
    return result


def deadline(assessment, at):
    """PASSED only when not_before > at; NOT_YET only when not_after < at."""
    need(type(at) is int and abs(at) <= MAX_SECONDS, 'TIME_DEADLINE')
    need(type(assessment) is dict and assessment.get('version') == VERSION and
         assessment.get('status') in ('INTERVAL', 'UNKNOWN'), 'TIME_ASSESSMENT')
    status = 'UNDETERMINED'
    if assessment['status'] == 'INTERVAL':
        need(type(assessment['not_before']) is int and
             (assessment['not_after'] is None or type(assessment['not_after']) is int), 'TIME_ASSESSMENT')
        if assessment['not_before'] > at:
            status = 'PASSED'
        elif assessment['not_after'] is not None and assessment['not_after'] < at:
            status = 'NOT_YET'
    return {'deadline': at, 'status': status, 'not_before': assessment['not_before'],
            'not_after': assessment['not_after'], 'basis': assessment['status'], 'reason': assessment['reason'],
            'assurance': assessment['assurance'], 'execution_authorized': False}


def malfeasance_report(observation, value):
    """Section 8.4.1 JSON for a Roughtime chain that proves a causality violation."""
    adopted = check_policy(value)
    exact(observation, 'kind links'); need(observation['kind'] == 'ROUGHTIME_CHAIN', 'TIME_OBSERVATION_KIND')
    sources = {row['id']: row for row in adopted['sources']}
    links = []
    for link in observation['links']:
        source = _adopted(sources, link['source'], 'ROUGHTIME')
        links.append({'protocol': source['protocol'], 'public_key': source['public_key'],
                      'rand': rt.unb64(link['rand'], 64), 'request': rt.unb64(link['request']),
                      'response': rt.unb64(link['response'])})
    return rt.malfeasance_report(links)


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE',
            'sources': {'ROUGHTIME': 'draft-ietf-ntp-roughtime-19 version 1 or 0x8000000c, or Google Roughtime; signed',
                        'WITNESS': 'covenant-portable-trust/0.1 checkpoint with quorum; signed lower bound',
                        'BLOCK': 'committee-certified block time; signed lower bound',
                        'GNSS': 'NMEA RMC/ZDA receiver claim; OSNMA status reported, not verified'},
            'combination': 'K_TH_ORDER_STATISTIC_OVER_DISTINCT_OPERATORS_WITH_K_OVERLAP',
            'minimum_threshold': 2, 'deadline_rule': 'PASSED_IF_NOT_BEFORE_GT_DEADLINE_NOT_YET_IF_NOT_AFTER_LT_DEADLINE',
            'clock_read': False, 'network_in_assess': False, 'single_clock_trusted': False,
            'operator_independence': 'DECLARED_BY_PARTIES_NOT_VERIFIED', 'osnma_verified': False,
            'execution_authorized': False}
