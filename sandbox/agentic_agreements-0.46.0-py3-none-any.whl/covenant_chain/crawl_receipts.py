"""Paid crawls to receipts: Cloudflare Pay Per Crawl and TollBit exchanges as signed AAP crawl receipts.

GRAFT: the rails' own messages are read unchanged and never sent. Cloudflare Pay
Per Crawl: the 402 response's ``crawler-price``, the request's
``crawler-exact-price`` or ``crawler-max-price``, the 200 response's
``crawler-charged`` and ``crawler-error`` (Cloudflare AI Crawl Control docs,
"Crawl pages" and "Error codes", updated 23 April 2026). TollBit: the content
token request (``POST /dev/v2/tokens/content``), the content response ``rate``
and the self-report usage receipts (``POST /dev/v2/transactions/selfReport``).
Web Bot Auth (draft-ietf-webbotauth-httpsig-protocol-00 over RFC 9421) is
checked only through an owner-installed verifier; without one the HTTP
signature is UNKNOWN, never verified.

TAKE-AND-IMPROVE: neither rail gives both sides a receipt they can prove. Each
exchange becomes a ``urn:aap:crawl-receipt:0.1`` receipt bound to the assented
licence, signed by the crawler's bot key (an Ed25519 key whose RFC 7638
thumbprint is its Web Bot Auth keyid) and countersigned by the publisher or
witnessed: receipts live in an append-only RFC 6962 journal whose checkpoints
witnesses cosign (covenant-witness-journal/0.1, C2SP tlog-witness).

A receipt records what the parties assert happened. It never authorises
access, moves money or proves a bank or chain payment.
"""
from copy import deepcopy
import hashlib
import json
import re

from covenant_language import agreement_application as app
from . import crawl_terms
from . import interop_codec
from . import witness_journal
from .crypto import canonical, need, verify

PROFILE = 'urn:aap:crawl-receipt:0.1'
EXCHANGE = 'urn:aap:crawl-exchange:0.1'
LABEL = 'AAP-CRAWL-USE-RECEIPT-0.1'
COUNTER_LABEL = 'AAP-CRAWL-USE-COUNTERSIGN-0.1'
KINDS = ('FETCH', 'PAYMENT', 'USE')
RAILS = ('AAP_OBSERVATION', 'CLOUDFLARE_PAY_PER_CRAWL', 'NONE', 'TOLLBIT')
OUTCOMES = ('CHARGED', 'NOT_SERVED', 'QUOTED', 'REFUSED', 'REPORTED', 'SERVED_UNCHARGED')
FIELDS = ('version agreement terms kind use resource count at sequence previous rail charged period exchange '
          'evidence content attribution bot')
FLAGS = crawl_terms.FLAGS
# Cloudflare Pay Per Crawl error codes and the status each comes with ("Error codes" page).
CLOUDFLARE_ERRORS = {'ConflictingPriceHeaders': 400, 'CrawlerForbidden': 403, 'InternalError': 500,
                     'InvalidContentPrice': 502, 'InvalidCrawlerExactPrice': 402, 'InvalidCrawlerMaxPrice': 402,
                     'InvalidCrawlerPriceValue': 400, 'InvalidSignature': 400, 'MissingCrawlerPrice': 402,
                     'PaymentFailed': 403, 'StrongAuthRequired': 400}
# TollBit standard licences ("Enabling Monetization"): single-use summary, grounding or citation, and a
# one-time full display. Neither permits training. A custom licence is only what the AAP terms say.
TOLLBIT_USES = {'ON_DEMAND_LICENSE': 'AI_INPUT', 'ON_DEMAND_FULL_USE_LICENSE': 'AI_INPUT'}
MAX_JSON = 1 << 20
MAX_RECEIPTS = 1_000_000
REFERENCE = crawl_terms.REFERENCE
TOKEN = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]{1,64}\Z")

ERRORS = {
    'CRAWL_EXCHANGE_MESSAGE': ('An HTTP message is not {method, target_uri, headers} or {status, headers}.',
                               'Pass the exact request and response, with headers as [name, value] pairs.', False),
    'CRAWL_EXCHANGE_HEADER': ('A header is malformed, too large or repeated where only one is allowed.',
                              'Send each header as received; crawler-* price headers appear at most once.', False),
    'CRAWL_EXCHANGE_PRICE': ('A crawler price header is not "<ISO 4217 code> <decimal>".',
                             'Copy the header value exactly, for example "USD 0.01".', False),
    'CRAWL_EXCHANGE_INCONSISTENT': ('The request and response cannot both be true under the rail rules.',
                                    'Check the exchange was copied whole; a charge needs one offer header it satisfies.', False),
    'CRAWL_EXCHANGE_JSON': ('A TollBit JSON message is malformed, repeats a member or exceeds 1 MiB.',
                            'Send the exact response bytes; amounts must be integer micros.', False),
    'CRAWL_EXCHANGE_TOLLBIT': ('A TollBit message lacks a documented field or breaks its own limits.',
                               'Use the documented token request, content rate or self-report receipt fields.', False),
    'CRAWL_EXCHANGE_URL': ('The fetched URL is not an https URL of the licensed origin.',
                           'Use the URL as fetched; encoded slashes and dot segments are refused.', False),
    'CRAWL_RECEIPT_FIELDS': ('The receipt is missing fields, has extra fields or a wrong version.',
                             'Build the receipt with crawl_receipts.receipt_payload and send it unchanged.', False),
    'CRAWL_RECEIPT_BINDING': ('The receipt names another agreement, terms or bot key than this licence.',
                              'Sign receipts only under the assented licence and with a listed bot key.', False),
    'CRAWL_RECEIPT_KIND': ('The kind, use, count, period or attribution do not fit together.',
                           'FETCH and USE name a use; PAYMENT has a period or none; only USE carries attribution.', False),
    'CRAWL_RECEIPT_SEQUENCE': ('The sequence or previous receipt link is malformed.',
                               'Number receipts per bot key from 0 and link each to the previous receipt id.', False),
    'CRAWL_RECEIPT_EVIDENCE': ('An evidence, content or attribution digest is malformed.',
                               'Use 64-hex SHA-256 digests with short upper-case kinds.', False),
    'CRAWL_RECEIPT_SIGNATURE': ('The bot key signature does not verify over this receipt.',
                                'Sign the unchanged body with the bot key it names.', False),
    'CRAWL_RECEIPT_COUNTERSIGNATURE': ('The publisher countersignature does not verify.',
                                       'Ask the publisher to countersign the exact receipt id.', False),
    'CRAWL_RECEIPT_EXCHANGE': ('The supplied exchange is not the one the receipt names, or disagrees with it.',
                               'Pass the exact exchange record the receipt was built from.', False),
    'CRAWL_RECEIPT_REQUEST_CHANGED': ('The supplied HTTP request is not the one the exchange recorded.',
                                      'Pass the exact request the exchange digest covers.', False),
    'CRAWL_RECEIPT_EQUIVOCATION': ('A different receipt already holds this bot key and sequence number.',
                                   'Keep both receipts as evidence; one key signed two histories.', False),
    'CRAWL_RECEIPT_UNKNOWN_LICENCE': ('This book does not hold the licence the receipt names.',
                                      'Open the book with the verified licence view for that agreement.', False),
    'CRAWL_RECEIPT_NOT_FOUND': ('The book holds no receipt with that id.', 'Record the receipt first.', False),
    'CRAWL_RECEIPT_BOOK_FULL': ('The book holds the maximum number of receipts.', 'Start a new book and retain both heads.', False),
    'CRAWL_RECEIPT_BOOK': ('The book configuration is malformed.', 'Pass verified licence views and a callable clock.', False),
}


def explain(code):
    if code in ERRORS:
        what, fix, retry = ERRORS[code]
        return {'code': code, 'what': what, 'fix': fix, 'retry': retry, 'reference': REFERENCE + code}
    return crawl_terms.explain(code)


def _digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _hex(value, code):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, code)
    return value


def _headers(rows):
    pairs = list(rows.items()) if type(rows) is dict else rows
    need(type(pairs) in (list, tuple) and len(pairs) <= 128, 'CRAWL_EXCHANGE_HEADER')
    out, total = [], 0
    for row in pairs:
        need(type(row) in (list, tuple) and len(row) == 2 and type(row[0]) is str and type(row[1]) is str
             and TOKEN.fullmatch(row[0]) is not None and len(row[1]) <= 8192
             and all(c == '\t' or ' ' <= c <= '~' for c in row[1]), 'CRAWL_EXCHANGE_HEADER')
        total += len(row[0]) + len(row[1])
        need(total <= 65536, 'CRAWL_EXCHANGE_HEADER')
        out.append([row[0].lower(), row[1]])
    return out


def _one(headers, name):
    values = [value for header, value in headers if header == name]
    need(len(values) <= 1, 'CRAWL_EXCHANGE_HEADER')
    return values[0].strip(' \t') if values else None


def request_message(value):
    """A request as {method, target_uri, headers}, the shape an RFC 9421 verifier takes."""
    need(type(value) is dict and set(value) <= {'method', 'target_uri', 'headers', 'body'}
         and {'method', 'target_uri', 'headers'} <= set(value) and value.get('body') is None, 'CRAWL_EXCHANGE_MESSAGE')
    need(type(value['method']) is str and TOKEN.fullmatch(value['method']) is not None and len(value['method']) <= 16,
         'CRAWL_EXCHANGE_MESSAGE')
    need(type(value['target_uri']) is str and 0 < len(value['target_uri']) <= 2048, 'CRAWL_EXCHANGE_MESSAGE')
    return {'method': value['method'], 'target_uri': value['target_uri'], 'headers': _headers(value['headers'])}


def _response(value):
    need(type(value) is dict and set(value) <= {'status', 'headers', 'body'} and {'status', 'headers'} <= set(value)
         and type(value['status']) is int and 100 <= value['status'] <= 599, 'CRAWL_EXCHANGE_MESSAGE')
    return {'status': value['status'], 'headers': _headers(value['headers'])}


def price(text):
    """A Pay Per Crawl price header value, "USD 0.01", as integer micro-units."""
    found = re.fullmatch(r'([A-Z]{3}) ([0-9.]{1,32})', text) if type(text) is str else None
    need(found is not None, 'CRAWL_EXCHANGE_PRICE')
    try:
        return crawl_terms.money(found[1], found[2])
    except ValueError:
        raise ValueError('CRAWL_EXCHANGE_PRICE') from None


def _record(rail, kind, url, *, status, outcome, count=1, offer=None, quoted=None, charged=None, error=None,
            licence=None, bot=None, evidence):
    value = {'version': EXCHANGE, 'rail': rail, 'kind': kind, 'url': url, 'status': status, 'outcome': outcome,
             'count': count, 'offer': offer, 'quoted': quoted, 'charged': charged, 'error': error, 'licence': licence,
             'bot': bot or {'signature_agent': None, 'signed': False, 'user_agent': None}, 'evidence': evidence}
    return {**value, 'id': app.content_id(EXCHANGE, value)}


def cloudflare(request, response, *, quote=None):
    """One Pay Per Crawl exchange as a typed record: CHARGED, SERVED_UNCHARGED, QUOTED, REFUSED or NOT_SERVED.

    ``quote`` is the earlier 402 response whose crawler-price the crawler answered. A charge needs exactly
    one offer header: crawler-exact-price equal to the charge, or crawler-max-price at or above it.
    """
    req, res = request_message(request), _response(response)
    exact_text, max_text = _one(req['headers'], 'crawler-exact-price'), _one(req['headers'], 'crawler-max-price')
    offer = None
    if exact_text is not None or max_text is not None:
        offer = {'mode': 'BOTH' if exact_text is not None and max_text is not None else 'EXACT' if exact_text is not None else 'MAX',
                 **price(exact_text if exact_text is not None else max_text)}
        if offer['mode'] == 'BOTH':
            price(max_text)
    charged_text, price_text = _one(res['headers'], 'crawler-charged'), _one(res['headers'], 'crawler-price')
    error = _one(res['headers'], 'crawler-error')
    need(error is None or re.fullmatch('[A-Za-z]{1,64}', error) is not None, 'CRAWL_EXCHANGE_HEADER')
    quoted = price(price_text) if price_text is not None else None
    quote_digest = None
    if quote is not None:
        earlier = _response(quote)
        need(earlier['status'] == 402 and _one(earlier['headers'], 'crawler-error') is None, 'CRAWL_EXCHANGE_INCONSISTENT')
        earlier_price = _one(earlier['headers'], 'crawler-price')
        need(earlier_price is not None, 'CRAWL_EXCHANGE_PRICE')
        quoted = price(earlier_price) if quoted is None else quoted
        need(quoted == price(earlier_price), 'CRAWL_EXCHANGE_INCONSISTENT')
        quote_digest = _digest(earlier)
    charged, status = None, res['status']
    if status == 200 and charged_text is not None:
        charged = price(charged_text)
        need(error is None and offer is not None and offer['mode'] in ('EXACT', 'MAX') and offer['unit'] == charged['unit']
             and (charged['amount'] == offer['amount'] if offer['mode'] == 'EXACT' else charged['amount'] <= offer['amount'])
             and (quoted is None or quoted == charged), 'CRAWL_EXCHANGE_INCONSISTENT')
        outcome = 'CHARGED'
    elif status == 200:
        need(error is None, 'CRAWL_EXCHANGE_INCONSISTENT')
        outcome = 'SERVED_UNCHARGED'
    else:
        need(charged_text is None, 'CRAWL_EXCHANGE_INCONSISTENT')
        if error is not None:
            need(CLOUDFLARE_ERRORS.get(error, status) == status, 'CRAWL_EXCHANGE_INCONSISTENT')
            outcome = 'REFUSED'
        elif status == 402:
            need(quoted is not None, 'CRAWL_EXCHANGE_PRICE')
            outcome = 'QUOTED'
        else:
            outcome = 'NOT_SERVED'
    headers = req['headers']
    bot = {'signature_agent': _one(headers, 'signature-agent'), 'user_agent': _one(headers, 'user-agent'),
           'signed': _one(headers, 'signature-input') is not None and _one(headers, 'signature') is not None}
    for name in ('signature_agent', 'user_agent'):
        need(bot[name] is None or len(bot[name]) <= 512, 'CRAWL_EXCHANGE_HEADER')
    return _record('CLOUDFLARE_PAY_PER_CRAWL', 'FETCH', req['target_uri'], status=status, outcome=outcome, offer=offer,
                   quoted=quoted, charged=charged, error=error, bot=bot,
                   evidence={'request': _digest(req), 'response': _digest(res), 'quote': quote_digest, 'token': None})


def _json(raw):
    need(type(raw) is bytes and 0 < len(raw) <= MAX_JSON, 'CRAWL_EXCHANGE_JSON')
    try:
        return interop_codec.parse(raw, MAX_JSON, 16, 50000, 1 << 20)
    except ValueError:
        raise ValueError('CRAWL_EXCHANGE_JSON') from None


def _micros(value):
    need(type(value) is int and 0 <= value <= 2 ** 53 - 1, 'CRAWL_EXCHANGE_TOLLBIT')
    return {'amount': value, 'unit': 'USD-micro'}


def _tollbit_url(value):
    need(type(value) is str and 0 < len(value) <= 2048, 'CRAWL_EXCHANGE_TOLLBIT')
    return value if value.startswith('https://') else 'https://' + value


def _tollbit_licence(value):
    need(type(value) is dict and {'id', 'licenseType', 'licensePath', 'permissions'} <= set(value)
         and all(type(value[name]) is str and 0 < len(value[name]) <= 512 for name in ('id', 'licenseType', 'licensePath'))
         and type(value['permissions']) is list and len(value['permissions']) <= 32, 'CRAWL_EXCHANGE_TOLLBIT')
    names = []
    for row in value['permissions']:
        need(type(row) is dict and type(row.get('name')) is str and 0 < len(row['name']) <= 128, 'CRAWL_EXCHANGE_TOLLBIT')
        names.append(row['name'])
    return {'type': value['licenseType'], 'id': value['id'], 'path': value['licensePath'], 'permissions': sorted(set(names))}


def _rate(value):
    need(type(value) is dict and type(value.get('price')) is dict and 'license' in value, 'CRAWL_EXCHANGE_TOLLBIT')
    need(value['price'].get('currency') == 'USD', 'CRAWL_EXCHANGE_TOLLBIT')
    return _micros(value['price'].get('priceMicros')), _tollbit_licence(value['license'])


def tollbit_fetch(token_request, content_response, *, token=None):
    """A TollBit content fetch: the token request bounds the price; the content response's rate is the charge.

    The bearer token is a credential: only its SHA-256 is kept, never the token.
    """
    asked = _json(token_request)
    need(type(asked) is dict and {'url', 'userAgent', 'maxPriceMicros', 'currency', 'licenseType'} <= set(asked)
         <= {'url', 'userAgent', 'maxPriceMicros', 'currency', 'licenseType', 'licenseCuid', 'format'}
         and asked['currency'] == 'USD' and type(asked['userAgent']) is str and 0 < len(asked['userAgent']) <= 256
         and type(asked['licenseType']) is str and 0 < len(asked['licenseType']) <= 64, 'CRAWL_EXCHANGE_TOLLBIT')
    need(asked['licenseType'] != 'CUSTOM_LICENSE' or type(asked.get('licenseCuid')) is str, 'CRAWL_EXCHANGE_TOLLBIT')
    ceiling = _micros(asked['maxPriceMicros'])
    served = _json(content_response)
    need(type(served) is dict and type(served.get('content')) is dict and 'metadata' in served, 'CRAWL_EXCHANGE_TOLLBIT')
    parts = served['content']
    need(all(type(parts.get(name)) is str for name in ('header', 'body', 'footer')), 'CRAWL_EXCHANGE_TOLLBIT')
    charged = licence = None
    if served.get('rate') is not None:
        charged, licence = _rate(served['rate'])
        need(charged['amount'] <= ceiling['amount'] and licence['type'] == asked['licenseType'], 'CRAWL_EXCHANGE_INCONSISTENT')
    need(token is None or type(token) is str and 0 < len(token) <= 8192, 'CRAWL_EXCHANGE_TOLLBIT')
    return _record('TOLLBIT', 'FETCH', _tollbit_url(asked['url']), status=200,
                   outcome='CHARGED' if charged is not None and charged['amount'] > 0 else 'SERVED_UNCHARGED',
                   offer={'mode': 'MAX', **ceiling}, quoted=charged, charged=charged, licence=licence,
                   bot={'signature_agent': None, 'signed': False, 'user_agent': asked['userAgent']},
                   evidence={'request': hashlib.sha256(token_request).hexdigest(),
                             'response': hashlib.sha256(content_response).hexdigest(), 'quote': None,
                             'token': None if token is None else hashlib.sha256(token.encode('ascii')).hexdigest()})


def tollbit_usage(report_request, report_response):
    """TollBit self-reported usage and the receipts TollBit returns: one USE record per usage row."""
    asked, answered = _json(report_request), _json(report_response)
    need(type(asked) is dict and {'idempotencyId', 'usage'} <= set(asked) and type(asked['idempotencyId']) is str
         and 0 < len(asked['idempotencyId']) <= 256 and type(asked['usage']) is list and 1 <= len(asked['usage']) <= 256,
         'CRAWL_EXCHANGE_TOLLBIT')
    need(type(answered) is dict and type(answered.get('receipts')) is list
         and len(answered['receipts']) == len(asked['usage']), 'CRAWL_EXCHANGE_TOLLBIT')
    records = []
    for index, (row, receipt) in enumerate(zip(asked['usage'], answered['receipts'])):
        need(type(row) is dict and {'url', 'timesUsed', 'licensePermissions', 'licenseType'} <= set(row)
             and type(row['timesUsed']) is int and 1 <= row['timesUsed'] <= 10 ** 9, 'CRAWL_EXCHANGE_TOLLBIT')
        need(type(receipt) is dict and receipt.get('url') == row['url'] and receipt.get('currency') == 'USD', 'CRAWL_EXCHANGE_TOLLBIT')
        unit_price, total = _micros(receipt.get('perUnitPriceMicros')), _micros(receipt.get('totalUsePriceMicros'))
        licence = _tollbit_licence(receipt.get('license'))
        need(licence['type'] == row['licenseType'], 'CRAWL_EXCHANGE_INCONSISTENT')
        records.append(_record('TOLLBIT', 'USE', _tollbit_url(row['url']), status=None, outcome='REPORTED',
                               count=row['timesUsed'], quoted=unit_price, charged=total, licence=licence,
                               evidence={'request': hashlib.sha256(report_request).hexdigest(),
                                         'response': hashlib.sha256(report_response).hexdigest(),
                                         'quote': None, 'token': None, 'row': index}))
    return records


EXCHANGE_FIELDS = 'version rail kind url status outcome count offer quoted charged error licence bot evidence id'


def _exchange(value):
    """Check an exchange record's whole shape and re-derive its id. The id is only a hash, so a record made
    elsewhere is checked field by field before any field is used."""
    need(type(value) is dict and set(value) == set(EXCHANGE_FIELDS.split()) and value['version'] == EXCHANGE
         and value['rail'] in ('CLOUDFLARE_PAY_PER_CRAWL', 'TOLLBIT') and value['kind'] in ('FETCH', 'USE')
         and value['outcome'] in OUTCOMES and type(value['url']) is str and 0 < len(value['url']) <= 2048
         and (value['status'] is None or type(value['status']) is int) and type(value['count']) is int
         and 1 <= value['count'] <= 10 ** 9 and (value['error'] is None or type(value['error']) is str), 'CRAWL_RECEIPT_EXCHANGE')
    for name in ('quoted', 'charged'):
        _money(value[name], 'CRAWL_RECEIPT_EXCHANGE')
    offer = value['offer']
    need(offer is None or type(offer) is dict and set(offer) == {'mode', 'amount', 'unit'}
         and offer['mode'] in ('BOTH', 'EXACT', 'MAX'), 'CRAWL_RECEIPT_EXCHANGE')
    if offer is not None:
        _money({'amount': offer['amount'], 'unit': offer['unit']}, 'CRAWL_RECEIPT_EXCHANGE')
    need(value['licence'] is None or type(value['licence']) is dict, 'CRAWL_RECEIPT_EXCHANGE')
    bot = value['bot']
    need(type(bot) is dict and set(bot) == {'signature_agent', 'signed', 'user_agent'} and type(bot['signed']) is bool
         and all(bot[name] is None or type(bot[name]) is str and len(bot[name]) <= 512
                 for name in ('signature_agent', 'user_agent')), 'CRAWL_RECEIPT_EXCHANGE')
    evidence = value['evidence']
    need(type(evidence) is dict and {'request', 'response', 'quote', 'token'} <= set(evidence)
         <= {'request', 'response', 'quote', 'token', 'row'}, 'CRAWL_RECEIPT_EXCHANGE')
    for name in ('request', 'response', 'quote', 'token'):
        if name in ('request', 'response') or evidence[name] is not None:
            _hex(evidence[name], 'CRAWL_RECEIPT_EXCHANGE')
    need('row' not in evidence or type(evidence['row']) is int and 0 <= evidence['row'] < 256, 'CRAWL_RECEIPT_EXCHANGE')
    body = {name: value[name] for name in value if name != 'id'}
    try:
        ident = app.content_id(EXCHANGE, body)
    except ValueError:
        raise ValueError('CRAWL_RECEIPT_EXCHANGE') from None
    need(ident == value['id'], 'CRAWL_RECEIPT_EXCHANGE')
    return body


def _money(value, code):
    need(value is None or type(value) is dict and set(value) == {'amount', 'unit'} and type(value['amount']) is int
         and 0 <= value['amount'] <= 2 ** 53 - 1, code)
    if value is not None:
        crawl_terms._checked(crawl_terms.unit, code, value['unit'])


def _body(view, body):
    need(type(body) is dict and set(body) == set(FIELDS.split()) and body['version'] == PROFILE, 'CRAWL_RECEIPT_FIELDS')
    need(body['agreement'] == view['agreement'] and body['terms'] == view['terms'], 'CRAWL_RECEIPT_BINDING')
    need(body['kind'] in KINDS and body['rail'] in RAILS, 'CRAWL_RECEIPT_KIND')
    terms = view['body']
    if body['kind'] == 'PAYMENT':
        need(body['use'] is None and body['resource'] == terms['origin'] and type(body['count']) is int
             and body['count'] == 1 and body['attribution'] is None
             and body['content'] is None and body['charged'] is not None, 'CRAWL_RECEIPT_KIND')
        period = body['period']
        need(period is None or type(period) is dict and set(period) == {'from', 'to'} and type(period['from']) is int
             and type(period['to']) is int and 0 <= period['from'] < period['to'] <= 2 ** 53 - 1, 'CRAWL_RECEIPT_KIND')
    else:
        need(body['use'] in crawl_terms.USES and body['period'] is None and type(body['count']) is int
             and 1 <= body['count'] <= 10 ** 9 and (body['kind'] == 'USE' or body['count'] == 1), 'CRAWL_RECEIPT_KIND')
        need(body['kind'] == 'USE' or body['attribution'] is None, 'CRAWL_RECEIPT_KIND')
        try:
            normal, _target = crawl_terms.resource(body['resource'], terms['origin'])
        except ValueError:
            raise ValueError('CRAWL_EXCHANGE_URL') from None
        need(normal == body['resource'], 'CRAWL_EXCHANGE_URL')
    need(type(body['at']) is int and 0 <= body['at'] <= 2 ** 53 - 1, 'CRAWL_RECEIPT_FIELDS')
    need(type(body['sequence']) is int and 0 <= body['sequence'] <= 2 ** 53 - 1
         and (body['previous'] is None) == (body['sequence'] == 0), 'CRAWL_RECEIPT_SEQUENCE')
    if body['previous'] is not None:
        _hex(body['previous'], 'CRAWL_RECEIPT_SEQUENCE')
    _money(body['charged'], 'CRAWL_RECEIPT_FIELDS')
    need((body['exchange'] is None) == (body['rail'] in ('NONE', 'AAP_OBSERVATION')), 'CRAWL_RECEIPT_KIND')
    if body['exchange'] is not None:
        _hex(body['exchange'], 'CRAWL_RECEIPT_EVIDENCE')
    rows = body['evidence']
    need(type(rows) is list and len(rows) <= 8, 'CRAWL_RECEIPT_EVIDENCE')
    for row in rows:
        need(type(row) is dict and set(row) == {'kind', 'sha256'} and type(row['kind']) is str
             and re.fullmatch('[A-Z][A-Z0-9_]{0,31}', row['kind']) is not None, 'CRAWL_RECEIPT_EVIDENCE')
        _hex(row['sha256'], 'CRAWL_RECEIPT_EVIDENCE')
    need(rows == sorted(rows, key=lambda row: (row['kind'], row['sha256']))
         and len({(row['kind'], row['sha256']) for row in rows}) == len(rows), 'CRAWL_RECEIPT_EVIDENCE')
    if body['content'] is not None:
        need(type(body['content']) is dict and set(body['content']) == {'sha256', 'bytes'} and type(body['content']['bytes']) is int
             and 0 <= body['content']['bytes'] <= 2 ** 53 - 1, 'CRAWL_RECEIPT_EVIDENCE')
        _hex(body['content']['sha256'], 'CRAWL_RECEIPT_EVIDENCE')
    if body['attribution'] is not None:
        given = body['attribution']
        need(type(given) is dict and set(given) == {'url', 'sha256'} and (given['url'] is not None or given['sha256'] is not None),
             'CRAWL_RECEIPT_EVIDENCE')
        if given['url'] is not None:
            crawl_terms._checked(crawl_terms._url, 'CRAWL_RECEIPT_EVIDENCE', given['url'])
        if given['sha256'] is not None:
            _hex(given['sha256'], 'CRAWL_RECEIPT_EVIDENCE')
    bot = body['bot']
    need(type(bot) is dict and set(bot) == {'key', 'keyid', 'agent'} and bot['key'] in view['bot_keys']
         and bot['keyid'] == interop_codec.jwk_thumbprint(bot['key']), 'CRAWL_RECEIPT_BINDING')
    need(bot['agent'] is None or type(bot['agent']) is str and 0 < len(bot['agent']) <= 512
         and all(32 <= ord(c) <= 126 for c in bot['agent']), 'CRAWL_RECEIPT_FIELDS')
    return body


def receipt_payload(view, *, kind, use, resource, at, sequence, previous, bot_key, exchange=None, count=None,
                    charged=None, rail=None, period=None, evidence=(), content=None, attribution=None):
    """The receipt body the crawler's bot key signs. An exchange supplies rail, URL, count, charge and evidence."""
    record = None if exchange is None else _exchange(exchange)
    if record is not None:
        need(record['kind'] == kind and record['outcome'] in ('CHARGED', 'SERVED_UNCHARGED', 'REPORTED'), 'CRAWL_RECEIPT_EXCHANGE')
        need(resource is None and count is None and charged is None and rail is None, 'CRAWL_RECEIPT_EXCHANGE')
        resource, count, charged, rail = record['url'], record['count'], record['charged'], record['rail']
        evidence = [*evidence, *({'kind': 'EXCHANGE_' + name.upper(), 'sha256': digest}
                                 for name, digest in sorted(record['evidence'].items()) if type(digest) is str)]
    need(type(evidence) in (list, tuple) and len(evidence) <= 8 and all(
        type(row) is dict and set(row) == {'kind', 'sha256'} and type(row['kind']) is str and type(row['sha256']) is str
        for row in evidence), 'CRAWL_RECEIPT_EVIDENCE')
    if kind != 'PAYMENT':
        try:
            resource, _target = crawl_terms.resource(resource, view['body']['origin'])
        except ValueError:
            raise ValueError('CRAWL_EXCHANGE_URL') from None
    rows = sorted({(row['kind'], row['sha256']) for row in evidence})
    body = {'version': PROFILE, 'agreement': view['agreement'], 'terms': view['terms'], 'kind': kind, 'use': use,
            'resource': resource, 'count': 1 if count is None else count, 'at': at, 'sequence': sequence, 'previous': previous,
            'rail': rail or 'NONE', 'charged': deepcopy(charged), 'period': deepcopy(period),
            'exchange': None if exchange is None else exchange['id'],
            'evidence': [{'kind': name, 'sha256': digest} for name, digest in rows], 'content': deepcopy(content),
            'attribution': deepcopy(attribution),
            'bot': {'key': bot_key, 'keyid': None, 'agent': None if record is None else (record['bot']['signature_agent'] or
                                                                                      record['bot']['user_agent'])}}
    need(type(bot_key) is str and bot_key in view['bot_keys'], 'CRAWL_RECEIPT_BINDING')
    body['bot']['keyid'] = interop_codec.jwk_thumbprint(bot_key)
    _body(view, body)
    return {'label': LABEL, 'body': body, 'id': app.content_id(LABEL, body), 'signer': bot_key,
            'next': 'The crawler signs body with this bot key; the publisher countersigns the id or the book witnesses it.',
            **FLAGS}


def receipt_id(body):
    return app.content_id(LABEL, body)


def countersign_payload(view, receipt):
    """What the publisher signs after checking the receipt against its own records."""
    checked = verify_receipt(view, receipt)
    return {'label': COUNTER_LABEL, 'body': {'receipt': checked['id'], 'agreement': view['agreement']},
            'signer': view['publisher'], **FLAGS}


def verify_receipt(view, receipt, *, exchange=None):
    """The receipt's bindings and signatures. The charge is what the parties assert, not an observed payment."""
    need(type(receipt) is dict and set(receipt) == {'body', 'signature', 'countersignature'}, 'CRAWL_RECEIPT_FIELDS')
    body = _body(view, receipt['body'])
    ident = app.content_id(LABEL, body)
    crawl_terms._checked(verify, 'CRAWL_RECEIPT_SIGNATURE', body['bot']['key'], LABEL, body, receipt['signature'])
    countersigned = receipt['countersignature'] is not None
    if countersigned:
        crawl_terms._checked(verify, 'CRAWL_RECEIPT_COUNTERSIGNATURE', view['publisher'], COUNTER_LABEL,
                             {'receipt': ident, 'agreement': view['agreement']}, receipt['countersignature'])
    status = 'NOT_SUPPLIED'
    if exchange is not None:
        record = _exchange(exchange)
        need(body['exchange'] == exchange['id'] and record['url'] == body['resource'] and record['kind'] == body['kind']
             and record['count'] == body['count'] and record['charged'] == body['charged'] and record['rail'] == body['rail'],
             'CRAWL_RECEIPT_EXCHANGE')
        status = 'MATCHES'
    return {'id': ident, 'kind': body['kind'], 'body': deepcopy(body), 'bot_signature': 'VERIFIED',
            'countersignature': 'VERIFIED' if countersigned else 'ABSENT', 'exchange': status,
            'assurance': 'COUNTERSIGNED' if countersigned else 'CRAWLER_SIGNED',
            'claim': 'PARTIES_ASSERT_THIS_EVENT; CHARGE_IS_NOT_AN_OBSERVED_PAYMENT', **FLAGS}


def default_verifier():
    """covenant_chain.web_bot_auth.verifier (RFC 9421 with the Web Bot Auth profile) when installed, else None."""
    try:
        from .web_bot_auth import verifier
    except ImportError:
        return None
    return verifier


def bot_signature(receipt, exchange, request, *, verifier=None, keys=None, now=None):
    """Web Bot Auth for the fetch through an RFC 9421 verifier; UNKNOWN without one or without adopted keys.

    ``verifier(message, keys, now)`` returns {status: VERIFIED, thumbprint, covered, parameters} or raises
    ValueError. The owner may install any verifier of that shape (covenant_chain.http_signatures.verify is
    one); without one, covenant_chain.web_bot_auth.verifier is used when it is installed, against the
    owner's adopted ``keys`` only. VERIFIED also needs the receipt's bot keyid, tag web-bot-auth, @authority
    or @target-uri, a Signature-Agent header that the signature covers (draft-ietf-webbotauth-httpsig-protocol-00
    section 5.2.1 and Cloudflare require it), and for a Pay Per Crawl offer its price header (Cloudflare
    "Crawl pages").
    """
    record = _exchange(exchange)
    need(type(receipt) is dict and type(receipt.get('body')) is dict and receipt['body'].get('exchange') == exchange['id'],
         'CRAWL_RECEIPT_EXCHANGE')
    message = request_message(request)
    need(_digest(message) == record['evidence']['request'], 'CRAWL_RECEIPT_REQUEST_CHANGED')
    if verifier is None:
        verifier = default_verifier()
        if verifier is None:
            return {'status': 'UNKNOWN', 'reasons': ['NO_VERIFIER_INSTALLED'], 'keyid': None, 'covered': []}
        if keys is None:
            # The installed verifier checks only keys the owner adopted; none adopted is not a refusal.
            return {'status': 'UNKNOWN', 'reasons': ['NO_KEYS_ADOPTED'], 'keyid': None, 'covered': []}
    need(callable(verifier), 'CRAWL_RECEIPT_BOOK')
    try:
        out = verifier(deepcopy(message), keys, now)
    except ValueError as error:
        return {'status': 'REFUSED', 'reasons': [str(error)[:64]], 'keyid': None, 'covered': []}
    if type(out) is not dict or out.get('status') != 'VERIFIED' or type(out.get('covered')) is not list:
        return {'status': 'UNKNOWN', 'reasons': ['VERIFIER_RESULT_NOT_VERIFIED'], 'keyid': None, 'covered': []}
    names = sorted({item.split(';')[0].strip('"') for item in out['covered'] if type(item) is str})
    parameters = out.get('parameters') if type(out.get('parameters')) is dict else {}
    reasons = []
    if out.get('thumbprint') != receipt['body']['bot']['keyid']:
        reasons.append('BOT_KEY_MISMATCH')
    if parameters.get('tag') != 'web-bot-auth':
        reasons.append('TAG_NOT_WEB_BOT_AUTH')
    if not {'@authority', '@target-uri'} & set(names):
        reasons.append('AUTHORITY_NOT_COVERED')
    if record['bot']['signature_agent'] is None:
        reasons.append('SIGNATURE_AGENT_MISSING')
    elif 'signature-agent' not in names:
        reasons.append('SIGNATURE_AGENT_NOT_COVERED')
    offer = record['offer']
    if record['rail'] == 'CLOUDFLARE_PAY_PER_CRAWL' and offer is not None and \
            ('crawler-exact-price' if offer['mode'] == 'EXACT' else 'crawler-max-price') not in names:
        reasons.append('PRICE_HEADER_NOT_COVERED')
    return {'status': 'REFUSED' if reasons else 'VERIFIED', 'reasons': reasons, 'keyid': out.get('thumbprint'),
            'covered': names, 'check': _digest({'covered': names, 'thumbprint': out.get('thumbprint'),
                                               'parameters': {k: v for k, v in parameters.items() if type(v) in (int, str)}})}


class ReceiptBook:
    """Owner-held receipts in an append-only RFC 6962 journal, one leaf per receipt or countersignature.

    The SQLite file is private (0600, WAL, synchronous FULL); a receipt, its slot (bot key and sequence) and its
    leaf commit in one transaction. ``seal`` publishes a checkpoint signed with the owner's journal key and
    collects witness cosignatures through owner-installed transports (covenant-witness-journal/0.1); ``proof``
    gives the inclusion proof a counterparty verifies offline with witness_journal.verify_proof.
    """

    def __init__(self, path, views, *, verifier=None, keys=None, clock=None):
        need(type(views) is list and 1 <= len(views) <= 1024, 'CRAWL_RECEIPT_BOOK')
        self.views = {}
        for view in views:
            need(type(view) is dict and view.get('profile') == crawl_terms.PROFILE
                 and view.get('assent') == 'BOTH_PARTIES_VERIFIED' and view.get('agreement') not in self.views, 'CRAWL_RECEIPT_BOOK')
            self.views[view['agreement']] = deepcopy(view)
        need(verifier is None or callable(verifier), 'CRAWL_RECEIPT_BOOK')
        need(clock is None or callable(clock), 'CRAWL_RECEIPT_BOOK')
        self.verifier, self.keys, self.clock = verifier, deepcopy(keys), clock
        self.journal = witness_journal.open_journal(path, 'crawl')
        with self.journal.write():
            db = self.journal.db
            db.execute('CREATE TABLE IF NOT EXISTS crawl_slots (agreement TEXT NOT NULL, bot TEXT NOT NULL, '
                       'sequence INTEGER NOT NULL, receipt TEXT NOT NULL, PRIMARY KEY(agreement, bot, sequence)) WITHOUT ROWID')
            db.execute('CREATE TABLE IF NOT EXISTS crawl_countersigned (receipt TEXT PRIMARY KEY, signature TEXT NOT NULL)')
            for table in ('crawl_slots', 'crawl_countersigned'):
                for action in ('UPDATE', 'DELETE'):
                    db.execute(f'CREATE TRIGGER IF NOT EXISTS {table}_{action.lower()}_refused BEFORE {action} ON {table} '
                               "BEGIN SELECT RAISE(ABORT, 'CRAWL_RECEIPT_APPEND_ONLY'); END")

    def close(self):
        self.journal.close()

    def _view(self, receipt):
        need(type(receipt) is dict and type(receipt.get('body')) is dict, 'CRAWL_RECEIPT_FIELDS')
        view = self.views.get(receipt['body'].get('agreement'))
        need(view is not None, 'CRAWL_RECEIPT_UNKNOWN_LICENCE')
        return view

    def _index(self, entry):
        row = self.journal.db.execute('SELECT idx, body FROM crawl_leaves WHERE entry=?', (entry,)).fetchone()
        return None if row is None else (row[0], json.loads(row[1]))

    def record(self, receipt, *, exchange=None, request=None):
        """Verify and append one receipt. An exact retry is IDEMPOTENT; a second history for a slot is refused."""
        view = self._view(receipt)
        checked = verify_receipt(view, {**receipt, 'countersignature': None} if receipt.get('countersignature') else receipt,
                                 exchange=exchange)
        ident, body = checked['id'], checked['body']
        http = {'status': 'UNKNOWN', 'reasons': ['REQUEST_NOT_SUPPLIED'], 'keyid': None, 'covered': []}
        if request is not None:
            need(exchange is not None, 'CRAWL_RECEIPT_EXCHANGE')
            http = bot_signature(receipt, exchange, request, verifier=self.verifier, keys=self.keys,
                                 now=None if self.clock is None else self.clock())
        stored = {'receipt': {'body': body, 'signature': receipt['signature'], 'countersignature': None},
                  'exchange': None if exchange is None else deepcopy(exchange), 'http_signature': http}
        with self.journal.write():
            known = self._index(ident)
            if known is None:
                slot = self.journal.db.execute('SELECT receipt FROM crawl_slots WHERE agreement=? AND bot=? AND sequence=?',
                                               (body['agreement'], body['bot']['key'], body['sequence'])).fetchone()
                need(slot is None, 'CRAWL_RECEIPT_EQUIVOCATION')
                need(self.journal.size() < MAX_RECEIPTS, 'CRAWL_RECEIPT_BOOK_FULL')
                index = self.journal.append(ident, canonical(stored), body['agreement'])
                self.journal.db.execute('INSERT INTO crawl_slots VALUES (?, ?, ?, ?)',
                                        (body['agreement'], body['bot']['key'], body['sequence'], ident))
                status = 'RECORDED'
            else:
                index, status = known[0], 'IDEMPOTENT'
            if receipt.get('countersignature'):
                self._countersign(view, ident, receipt['countersignature'], body['agreement'])
        return {'status': status, 'id': ident, 'index': index, 'http_signature': http['status'],
                'size': self.journal.size(), **FLAGS}

    def _countersign(self, view, ident, signature, agreement):
        crawl_terms._checked(verify, 'CRAWL_RECEIPT_COUNTERSIGNATURE', view['publisher'], COUNTER_LABEL,
                             {'receipt': ident, 'agreement': agreement}, signature)
        if self.journal.db.execute('SELECT 1 FROM crawl_countersigned WHERE receipt=?', (ident,)).fetchone() is not None:
            return
        entry = app.content_id('AAP-CRAWL-COUNTERSIGN-ENTRY-0.1', {'receipt': ident, 'signature': signature})
        self.journal.append(entry, canonical({'countersign': {'receipt': ident, 'signature': signature}}), agreement)
        self.journal.db.execute('INSERT INTO crawl_countersigned VALUES (?, ?)', (ident, signature))

    def countersign(self, receipt_id, signature):
        """Append the publisher's countersignature of a recorded receipt as its own leaf."""
        _hex(receipt_id, 'CRAWL_RECEIPT_NOT_FOUND')
        with self.journal.write():
            known = self._index(receipt_id)
            need(known is not None, 'CRAWL_RECEIPT_NOT_FOUND')
            agreement = known[1]['receipt']['body']['agreement']
            self._countersign(self.views[agreement], receipt_id, signature, agreement)
        return {'status': 'COUNTERSIGNED', 'id': receipt_id, 'size': self.journal.size(), **FLAGS}

    def receipts(self, agreement):
        """Every receipt of one agreement in journal order, with any countersignature attached."""
        _hex(agreement, 'CRAWL_RECEIPT_UNKNOWN_LICENCE')
        signatures = dict(self.journal.db.execute('SELECT receipt, signature FROM crawl_countersigned'))
        out = []
        for index in self.journal.tagged(agreement):
            stored = json.loads(self.journal.body(index))
            if 'receipt' in stored:
                receipt = stored['receipt']
                receipt['countersignature'] = signatures.get(app.content_id(LABEL, receipt['body']))
                out.append({'index': index, 'receipt': receipt, 'exchange': stored['exchange'],
                            'http_signature': stored['http_signature']})
        return out

    def seal(self, gate):
        """Publish this size as a log-signed checkpoint and collect cosignatures; the verdict, never assumed VERIFIED."""
        need(isinstance(gate, witness_journal.Gate) and gate.journal.db is self.journal.db, 'CRAWL_RECEIPT_BOOK')
        return gate.check()

    def proof(self, gate, receipt_id):
        """An RFC 9162 inclusion proof of one receipt under the newest witnessed checkpoint."""
        need(isinstance(gate, witness_journal.Gate) and gate.journal.db is self.journal.db, 'CRAWL_RECEIPT_BOOK')
        _hex(receipt_id, 'CRAWL_RECEIPT_NOT_FOUND')
        known = self._index(receipt_id)
        need(known is not None, 'CRAWL_RECEIPT_NOT_FOUND')
        return gate.proof(known[0])


def describe():
    return {'profile': PROFILE, 'exchange': EXCHANGE, 'label': LABEL, 'countersign_label': COUNTER_LABEL,
            'kinds': list(KINDS), 'rails': list(RAILS), 'outcomes': list(OUTCOMES),
            'cloudflare_errors': dict(CLOUDFLARE_ERRORS), 'tollbit_standard_licences': dict(TOLLBIT_USES),
            'web_bot_auth': 'OWNER_INSTALLED_RFC9421_VERIFIER_ONLY; UNKNOWN_WITHOUT_ONE',
            'journal': witness_journal.PROFILE, 'units': 'ISO_4217_MICRO_UNITS',
            'errors': {code: explain(code) for code in sorted(ERRORS)}, **FLAGS}
