"""Season-end rebate tier by honoured rate: a view, not a claim (economics section 1).

``ECON_REBATE_CLAIM`` (``token_rebates``) already pays a pro-rata give-back
above one honour threshold. This view adds the tiered schedule the design
notes describe: an illustrative 10, 20 or 30 percent of fees paid in the
season, for agents whose honoured rate clears a tier and who lost no dispute.
It is computed only after every challenge window in the season has closed and
it never claims, pays or changes the consensus rebate rule. Adopting tiers
on chain would be a new versioned policy.
"""
from .crypto import integer, need

PROFILE = 'covenant-season-rebate-tier/0.1'
# (minimum honoured rate in bps, rebate in bps of fees paid). Illustrative.
DEFAULT_TIERS = ((9900, 3000), (9500, 2000), (9000, 1000))


def _tiers(tiers):
    need(type(tiers) in (list, tuple) and 0 < len(tiers) <= 8, 'REBATE_TIERS')
    rows = []
    for row in tiers:
        need(type(row) in (list, tuple) and len(row) == 2, 'REBATE_TIERS')
        floor, rebate = row
        integer(floor, True)
        integer(rebate, True)
        need(floor <= 10000 and rebate <= 10000, 'REBATE_TIERS')
        rows.append((floor, rebate))
    floors = [floor for floor, _ in rows]
    rebates = [rebate for _, rebate in rows]
    need(floors == sorted(floors, reverse=True) and len(set(floors)) == len(floors), 'REBATE_TIERS')
    need(rebates == sorted(rebates, reverse=True), 'REBATE_TIERS')
    return rows


def rebate_tier(*, honoured, settled, lost_disputes, fees_paid, season_closed, tiers=DEFAULT_TIERS):
    """Tier and rebate for one agent's season. Integer basis points; the rebate rounds down."""
    for value in (honoured, settled, lost_disputes, fees_paid):
        integer(value)
    need(honoured <= settled, 'REBATE_COUNTS')
    need(type(season_closed) is bool, 'REBATE_SEASON')
    table = _tiers(tiers)
    honour_bps = honoured * 10000 // settled if settled else 0
    tier = None
    rebate_bps = 0
    if not season_closed:
        reason = 'SEASON_OPEN_CHALLENGE_WINDOWS'
    elif lost_disputes:
        reason = 'LOST_DISPUTE'
    elif settled == 0:
        reason = 'NO_SETTLED_COVENANTS'
    else:
        reason = 'BELOW_LOWEST_TIER'
        for index, (floor, bps) in enumerate(table):
            if honour_bps >= floor:
                tier, rebate_bps, reason = index + 1, bps, 'TIER'
                break
    return {
        'profile': PROFILE,
        'honour_bps': honour_bps,
        'tier': tier,
        'rebate_bps': rebate_bps,
        'rebate': fees_paid * rebate_bps // 10000,
        'fees_paid': fees_paid,
        'reason': reason,
        'tiers': [list(row) for row in table],
        'tiers_are': 'ILLUSTRATIVE_UNTIL_ADOPTED',
        'clawback_on_overturn': True,
        'claim_operation': None,
        'consensus_rule': 'ECON_REBATE_CLAIM_UNCHANGED',
        'consensus_changed': False,
        'transfers': False,
        'submitted': False,
        'view': True,
        'execution_authorized': False,
    }
