"""Quorum checks for institution approvals.

The controller lookup is bound by the reducer at import. This module does not
import the reducer, so economics can call it without a cycle.
"""

from .crypto import exact, key, need, verify

LABEL = 'COVENANT-INSTITUTION-APPROVAL-0.1'
_controller = None


def bind_controller(function):
    global _controller
    _controller = function


def approval_body(chain, op, payload):
    return {'chain': chain, 'op': op, 'payload': {k: v for k, v in payload.items() if k != 'approvals'}}


def authorized(state, governors, threshold, proofs, op, payload):
    controller = _controller
    need(controller is not None, 'WORLD_CONTROLLER')
    need(type(proofs) is list and 0 < len(proofs) <= 128, 'WORLD_APPROVALS')
    signed = set()
    body = approval_body(state['chain'], op, payload)
    for proof in proofs:
        exact(proof, 'signer signature')
        who = proof['signer']
        key(who)
        need(who not in signed and who not in state['worlds'], 'WORLD_SIGNER')
        verify(controller(state, who), LABEL, body, proof['signature'])
        signed.add(who)
    memo = {}

    def satisfies(who, trail=()):
        need(len(trail) < 16 and who not in trail, 'WORLD_AUTHORITY_CYCLE')
        if who not in state['worlds']:
            return who in signed
        if who in memo:
            return memo[who]
        need(len(memo) < 1024, 'WORLD_AUTHORITY_SIZE')
        world = state['worlds'][who]
        need(world['status'] == 'ACTIVE', 'WORLD_INACTIVE')
        result = sum(satisfies(governor, trail + (who,)) for governor in world['seed']['governors']) >= world['seed']['threshold']
        memo[who] = result
        return result

    need(sum(satisfies(governor) for governor in governors) >= threshold, 'WORLD_QUORUM')
