"""MCP entry points for hire and principal override. No principal seed is accepted."""
from .crypto import FieldError, public_key, sign

_SECRETS = {'private_key', 'seed', 'principal_seed', 'secret'}


def _no_secrets(parameters):
    if _SECRETS & set(parameters):
        raise FieldError(
            'KEY_MATERIAL_REFUSED', 'parameters', 'no private keys or seeds',
            'Remove private keys from the tool arguments. The hire flow mints a disposable delegate.')


def call_hire(action, parameters):
    _no_secrets(parameters)
    if action != 'run':
        raise FieldError(
            'ARGUMENTS', 'action', 'run',
            'Use action run. Set demo true to play the eight-agent scenario, or pass task, budget, per_agent_cap, and a sentence.')
    from covenant_agent.hire import orchestrate
    custom = ('task', 'budget', 'per_agent_cap', 'sentence', 'approval_policy', 'decisions', 'board')
    if parameters.get('demo') is True and not any(k in parameters for k in custom):
        return orchestrate()
    return orchestrate(
        task=parameters.get('task') or 'Research the named question',
        budget=parameters.get('budget', 800),
        per_agent_cap=parameters.get('per_agent_cap', 100),
        sentence=parameters.get('sentence') or 'Hire eight agents for 100 credits each.',
        approval_policy=parameters.get('approval_policy', 'NEVER_WITHIN_SCOPE'),
        decisions=parameters.get('decisions'),
        board=parameters.get('board'))


def call_principal(action, parameters):
    """Names are refused. A missing live grant is GRANT_MISSING. Nothing is submitted."""
    _no_secrets(parameters)
    from . import principal
    if action in ('describe', 'review'):
        from . import principal_tool_schema
        if action == 'describe':
            from .agent_tools import _fields
            _fields(parameters, ())
            return principal_tool_schema.describe()
        return principal_tool_schema.review(parameters)
    if action == 'draft':
        return principal.draft(
            parameters.get('principal', 'principal'), parameters.get('agent', 'agent'),
            parameters.get('grant', 'ab' * 32), parameters.get('permit', 'cd' * 32),
            parameters.get('action_name', 'reliance.execute'), parameters.get('context', 'ef' * 32),
            parameters.get('spend') or {'credits': 1}, parameters.get('expiry', 10),
            parameters.get('effects') or ['AUTHORIZE'], parameters.get('profiles') or ['11' * 32],
            parameters.get('counterparties') or ['22' * 32], parameters.get('window', 10))
    if action == 'authorize':
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        import hashlib
        def key(label):
            return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(f'covenant-hire-principal:{label}'.encode()).digest())
        principal_key, agent_key, other = key('principal'), key('agent'), key('other')
        policy = principal.draft(
            public_key(principal_key), public_key(agent_key), 'ab' * 32, 'cd' * 32, 'reliance.execute',
            'ef' * 32, {'credits': 1}, 100, ['AUTHORIZE'], ['11' * 32], [public_key(other)], 10)
        signature = sign(principal_key, principal.LABEL, policy)
        terms = {
            'chain': 'aa' * 32, 'principal': policy['principal'], 'agent': policy['agent'],
            'counterparty': public_key(other), 'mandate': None, 'profile': '11' * 32,
            'resource': 'credits', 'quantity': 1, 'effect': 'AUTHORIZE', 'destination': 'desk',
            'executor': policy['agent'], 'resolver': '33' * 32, 'appeal_resolver': '44' * 32,
            'deadline': 10, 'challenge_blocks': 1, 'timeout': 'RELEASE_IF_UNDECIDED', 'terms_hash': '55' * 32,
        }
        try:
            return principal.authorize_bind({}, terms, policy, signature, 1)
        except ValueError as exc:
            if str(exc) != 'GRANT_MISSING':
                raise
            raise FieldError(
                'GRANT_MISSING', 'mandate', 'a live GIVE grant id',
                'Bind a live GIVE grant before the principal override. This call does not submit one.') from exc
    if action == 'narrow':
        from . import reliance
        policy = parameters.get('policy')
        intent = parameters.get('intent')
        remaining = parameters.get('grant_remaining')
        if not isinstance(policy, dict) or not isinstance(intent, dict) or not isinstance(remaining, dict):
            raise FieldError(
                'ARGUMENTS', 'policy', 'a reliance policy, an intent, and grant_remaining',
                'Pass policy, intent, and grant_remaining. This does not reserve or submit.')
        return principal.reliance_narrows(policy, intent, remaining)
    if action == 'kill':
        return {**principal.revoke_before_settlement({'held': True, 'state': 'BOUND'}, parameters.get('reliance_state', 'HELD')),
                'plan_only': True, 'submitted': False, 'state_changed': False}
    raise FieldError(
        'ARGUMENTS', 'action', 'describe, draft, review, authorize, narrow, or kill',
        'Choose describe, draft, review, authorize, narrow, or kill. None of these submit a transaction.')
