"""The AAP Connect adapter registry: signed manifests, explicit owner pins, signed discovery.

A publisher signs a manifest (kind, release, level, maturity, conformance
hash, publisher key) and lists it in its own signed-discovery descriptor, so
any AAP owner can find it through any carrier: a file, a QR code, a
well-known URL, DNS or a log. Finding is not adopting. An owner adopts one
exact manifest id, with the signed conformance report it names; the registry
re-verifies both on every read. Installing code is still the owner's act:
bind() refuses an adapter object whose source differs from the pinned
implementation hash. A newer release is never adopted automatically.

State is one owner-private JSON file, replaced atomically under a lock.
Nothing here fetches, imports code by name or executes an adapter.
"""
from copy import deepcopy
import os
from pathlib import Path
import stat

from . import connect
from .connect import ConnectError, check
from .connect_conformance import bound as _bound, open_report
from .crypto import canonical, loads

STATE = 'urn:aap:connect-registry-state:0.1'
TASK_PREFIX = 'aap-connect.'
MAX_ENTRIES = 512
MAX_STATE = 8_000_000
MAX_DESCRIPTOR_MANIFESTS = 8



def _state_path(directory):
    path = Path(directory)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = os.lstat(path)
    check(stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'CONNECT_REGISTRY_STATE')
    return path / 'connect-registry.json', path / 'connect-registry.lock'


def _verified_entry(ident, row):
    check(type(row) is dict and set(row) == {'manifest', 'report', 'retired'}, 'CONNECT_REGISTRY_STATE')
    opened = connect.open_manifest(row['manifest'], expected_id=ident)
    report = open_report(row['report'])
    _bound(opened['body'], report)
    check(row['retired'] is None or (type(row['retired']) is str and 0 < len(row['retired']) <= 256), 'CONNECT_REGISTRY_STATE')
    return opened


class ConnectRegistry:
    """One owner's adopted adapters. directory=None keeps the pins in memory only."""

    def __init__(self, directory=None):
        self.path = self.lock = None
        if directory is not None:
            check(isinstance(directory, (str, Path)) and str(directory), 'CONNECT_REGISTRY_STATE')
            self.path, self.lock = _state_path(directory)
        self._memory = {'version': STATE, 'entries': {}}

    def _read(self):
        if self.path is None:
            return deepcopy(self._memory)
        try:
            fd = os.open(self.path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            return {'version': STATE, 'entries': {}}
        with os.fdopen(fd, 'rb') as stream:
            info = os.fstat(stream.fileno())
            check(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0 and
                  info.st_size <= MAX_STATE, 'CONNECT_REGISTRY_STATE')
            raw = stream.read(MAX_STATE + 1)
        try:
            state = loads(raw)
        except ValueError:
            raise ConnectError('CONNECT_REGISTRY_STATE') from None
        check(type(state) is dict and set(state) == {'version', 'entries'} and state['version'] == STATE and
              type(state['entries']) is dict and len(state['entries']) <= MAX_ENTRIES, 'CONNECT_REGISTRY_STATE')
        return state

    def _write(self, state):
        raw = canonical(state)
        check(len(raw) <= MAX_STATE, 'CONNECT_REGISTRY_STATE')
        if self.path is None:
            self._memory = deepcopy(state)
            return
        from covenant_language.safe_io import atomic_write
        atomic_write(self.path, raw, mode=0o600, follow_symlinks=False)

    def _locked(self, change):
        if self.path is None:
            state = self._read()
            result = change(state)
            self._write(state)
            return result
        from covenant_language.safe_io import lock_file
        fd = os.open(self.lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            lock_file(fd, timeout=10)
            state = self._read()
            result = change(state)
            self._write(state)
            return result
        finally:
            os.close(fd)

    def adopt(self, manifest, *, expected_id, report):
        """The owner's explicit pin of one manifest id, with the signed report it names."""
        opened = connect.open_manifest(manifest, expected_id=expected_id)
        body = opened['body']
        checked = open_report(report)
        _bound(body, checked)

        def change(state):
            entries = state['entries']
            if expected_id in entries:
                return False
            check(len(entries) < MAX_ENTRIES, 'CONNECT_REGISTRY_STATE')
            for ident, row in entries.items():
                other = row['manifest']['body']
                if (other['publisher'], other['kind'], other['name'], other['release']) == \
                        (body['publisher'], body['kind'], body['name'], body['release']):
                    raise ConnectError('CONNECT_RELEASE_CONFLICT', native=ident)
            if body['previous'] is not None:
                prior = entries.get(body['previous'])
                check(prior is not None and all(prior['manifest']['body'][name] == body[name]
                                                for name in ('publisher', 'kind', 'name')), 'CONNECT_PREVIOUS')
            entries[expected_id] = {'manifest': deepcopy(manifest), 'report': deepcopy(report), 'retired': None}
            return True
        added = self._locked(change)
        return {'manifest': expected_id, 'kind': body['kind'], 'name': body['name'], 'release': body['release'],
                'level': body['level'], 'maturity': body['maturity'], 'publisher': body['publisher'],
                'adopted': True, 'newly_adopted': added, 'installed': False,
                'next': 'bind(manifest_id, adapter) once the exact code is installed', 'execution_authorized': False}

    def retire(self, manifest_id, reason):
        check(type(reason) is str and 0 < len(reason) <= 256 and all(32 <= ord(c) <= 126 for c in reason),
              'CONNECT_REGISTRY_STATE')

        def change(state):
            check(manifest_id in state['entries'], 'CONNECT_NOT_ADOPTED')
            if state['entries'][manifest_id]['retired'] is None:
                state['entries'][manifest_id]['retired'] = reason
            return state['entries'][manifest_id]['retired']
        kept = self._locked(change)
        return {'manifest': manifest_id, 'retired': kept, 'evidence_kept': True, 'execution_authorized': False}

    def entries(self, kind=None):
        check(kind is None or kind in connect.KIND_SPECS, 'CONNECT_KIND')
        rows = []
        for ident, row in sorted(self._read()['entries'].items()):
            body = _verified_entry(ident, row)['body']
            if kind is None or body['kind'] == kind:
                rows.append({'manifest': ident, 'kind': body['kind'], 'name': body['name'], 'release': body['release'],
                             'level': body['level'], 'maturity': body['maturity'], 'publisher': body['publisher'],
                             'report': body['conformance']['report'], 'retired': row['retired']})
        return rows

    def check(self, manifest_id):
        state = self._read()
        check(manifest_id in state['entries'], 'CONNECT_NOT_ADOPTED')
        row = state['entries'][manifest_id]
        opened = _verified_entry(manifest_id, row)
        check(row['retired'] is None, 'CONNECT_RETIRED')
        return opened['body']

    def bind(self, manifest_id, adapter):
        """Attach the owner-installed adapter object to its pin; the source must hash to the pinned implementation."""
        body = self.check(manifest_id)
        check(connect.implementation_sha256(adapter) == body['implementation'], 'CONNECT_IMPLEMENTATION')
        return PinnedAdapter(manifest_id, body, adapter)


class PinnedAdapter:
    """An adopted adapter: every call goes through its kind's contract with the manifest's pinned keys."""

    def __init__(self, manifest_id, body, adapter):
        self.manifest, self.kind, self.adapter = manifest_id, body['kind'], adapter
        self.pins = {'output_keys': list(body['output_keys'])}

    def invoke(self, method, payload):
        return {**connect.invoke(self.kind, self.adapter, method, payload, pins=self.pins), 'manifest': self.manifest}


def publisher_descriptor(publisher, manifests, *, issued_at, expires, name, summary='', sequence=0, previous=None,
                         operator=None):
    """An unsigned signed-discovery descriptor listing up to eight of a publisher's manifests."""
    from .signed_discovery import descriptor
    check(type(manifests) is list and 1 <= len(manifests) <= MAX_DESCRIPTOR_MANIFESTS, 'CONNECT_MANIFEST')
    opened = [connect.open_manifest(row) for row in manifests]
    check(all(row['body']['publisher'] == publisher for row in opened) and
          len({row['id'] for row in opened}) == len(opened), 'CONNECT_MANIFEST')
    classes = sorted({TASK_PREFIX + row['body']['kind'] for row in opened})
    endpoints = [{'transport': 'other', 'uri': row['urn']} for row in sorted(opened, key=lambda row: row['id'])]
    return descriptor(publisher, sequence, previous, issued_at, expires, name, summary, classes, endpoints,
                      operator=operator)


def find(gathered, manifests, *, kind=None, registry=None):
    """Adapters offered through verified discovery whose signed manifests were supplied. Never adopts."""
    check(type(gathered) is dict and type(gathered.get('agents')) is list, 'CONNECT_MANIFEST')
    check(type(manifests) is list and len(manifests) <= 256, 'CONNECT_MANIFEST')
    check(kind is None or kind in connect.KIND_SPECS, 'CONNECT_KIND')
    supplied, excluded = {}, []
    for index, envelope in enumerate(manifests):
        try:
            opened = connect.open_manifest(envelope)
            supplied[opened['id']] = opened['body']
        except ConnectError as error:
            excluded.append({'index': index, 'reason': error.code})
    adopted = {row['manifest']: row for row in registry.entries()} if registry is not None else {}
    candidates = []
    for agent in gathered['agents']:
        if type(agent) is not dict or agent.get('status') != 'SELECTED':
            continue
        for endpoint in agent['descriptor']['endpoints']:
            uri = endpoint.get('uri', '')
            if not uri.startswith(connect.MANIFEST_URN):
                continue
            ident = uri[len(connect.MANIFEST_URN):]
            body = supplied.get(ident)
            if body is None:
                candidates.append({'manifest': ident, 'publisher': agent['key'], 'status': 'MANIFEST_NOT_SUPPLIED'})
                continue
            if body['publisher'] != agent['key']:
                excluded.append({'manifest': ident, 'reason': 'CONNECT_MANIFEST_SIGNATURE'})
                continue
            if kind is not None and body['kind'] != kind:
                continue
            row = adopted.get(ident)
            candidates.append({'manifest': ident, 'status': 'OFFERED', 'kind': body['kind'], 'name': body['name'],
                               'release': body['release'], 'level': body['level'], 'maturity': body['maturity'],
                               'publisher': body['publisher'], 'report': body['conformance']['report'],
                               'adopted': row is not None and row['retired'] is None})
    return {'candidates': candidates, 'excluded': excluded, 'adoption': 'EXPLICIT_OWNER_PIN_REQUIRED',
            'sources_add_trust': False, 'installed': False, 'execution_authorized': False}
