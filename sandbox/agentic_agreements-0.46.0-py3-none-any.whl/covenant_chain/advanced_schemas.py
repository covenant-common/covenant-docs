"""Discoverable credit and legal drafting shapes, preserving historical semantics.

Cross references and arithmetic remain checked by the unchanged language validators.
The node helper deliberately accepts incomplete arguments; only a full draft checks
concept-specific requirements. Open argument maps preserve extension data.
"""
from copy import deepcopy
from .cooperation_interface import HASH, INT, OBJECT, schema

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 256}
STRING = {'type': 'string'}
NAME = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,79}$'}
NULL_OBJECT = {'type': ['object', 'null']}
NULL_HASH = {'oneOf': [HASH, {'type': 'null'}]}


def array(items, minimum=0, maximum=None, **extra):
    value = {'type': 'array', 'items': items, 'minItems': minimum, **extra}
    if maximum is not None:
        value['maxItems'] = maximum
    return value


def mapping(items, **extra):
    return {'type': 'object', 'propertyNames': NAME, 'additionalProperties': items, **extra}


ASSET = schema({'namespace': TEXT, 'identifier': TEXT, 'unit': TEXT,
                'adapter': NULL_HASH, 'transfer_terms': NULL_OBJECT},
               ('namespace', 'identifier', 'unit', 'adapter', 'transfer_terms'))
# validate_asset requires the normalized transfer_terms map, even though asset()
# accepts null as constructor shorthand.
ASSET['properties']['transfer_terms'] = OBJECT
ASSET['description'] = 'Exact asset descriptor; adapter may be null. transfer_terms is an open map of declared terms, not evidence of control.'
REFERENCE = schema({'module': {'oneOf': [{'const': 'SELF'}, HASH]}, 'term': NAME}, ('module', 'term'))
REFERENCE['description'] = 'SELF refers to a definition in this module; otherwise module is the exact immutable module hash.'
COLLATERAL = schema({'asset': {**INT, 'description': 'Zero-based index into assets; must be less than its length.'},
                     'quantity': INT, 'custody_terms': OBJECT}, ('asset', 'quantity', 'custody_terms'))
CREDIT_RULES = schema({'lender': TEXT, 'borrower': TEXT, 'principal': {**INT, 'minimum': 1},
                       'interest_bps': {**INT, 'maximum': 1000000}, 'origination_fee': INT,
                       'due_height': {**INT, 'minimum': 1}, 'collateral': array(COLLATERAL, maximum=32),
                       'recourse': STRING, 'transferability': STRING},
                      ('lender', 'borrower', 'principal', 'interest_bps', 'origination_fee', 'due_height',
                       'collateral', 'recourse', 'transferability'))
CREDIT_RULES['description'] = ('Lender and borrower must be distinct members of participants. Principal uses assets[0]. '
    'Interest is one-term simple ceiling(principal * interest_bps / 10000), not APR. '
    'Total due including the origination fee must fit an exact integer <= 9007199254740991. '
    'due_height is a ledger height; calendar dates need separately adopted timing evidence. Collateral declarations do not reserve or verify property.')
CREDIT_CREATE = {'name': TEXT, 'assets': array(ASSET, 1, 32),
                 'participants': array(TEXT, 1, 64, uniqueItems=True), 'rules': CREDIT_RULES,
                 'settlement': {**OBJECT, 'description': 'Open portable settlement terms; execution requires an adopted adapter.'},
                 'proof_requirements': {'oneOf': [array(HASH, maximum=32), {'type': 'null'}]},
                 'extensions': NULL_OBJECT}


def arguments(properties, required):
    return {'type': 'object', 'properties': properties, 'required': list(required), 'additionalProperties': True}


def term(kind, args, refs=None):
    return schema({'kind': {'const': kind}, 'arguments': args,
                   'references': array(REFERENCE) if refs is None else refs}, ('kind', 'arguments', 'references'))


EMPTY = {'type': 'object', 'maxProperties': 0}
LEGAL_NODE = {'type': 'object', 'oneOf': [
    term('TERM', arguments({'text': STRING}, ('text',))),
    term('ALL', EMPTY, array(REFERENCE, 1)), term('ANY', EMPTY, array(REFERENCE, 1)),
    term('NOT', EMPTY, array(REFERENCE, 1, 1)), term('IF', EMPTY, array(REFERENCE, 2, 3)),
    term('OBLIGATION', arguments({'debtor': NAME, 'creditor': NAME, 'performance': STRING}, ('debtor', 'creditor', 'performance'))),
    term('PERMISSION', arguments({'holder': NAME, 'action': STRING}, ('holder', 'action'))),
    term('DELEGATION', arguments({'grantor': NAME, 'delegate': NAME, 'powers': array(STRING, 1, 32),
                                   'subdelegation': {'type': 'boolean'}}, ('grantor', 'delegate', 'powers', 'subdelegation'))),
    term('GUARANTEE', arguments({'guarantor': NAME, 'beneficiary': NAME, 'resource': NAME, 'maximum': INT},
                                ('guarantor', 'beneficiary', 'resource', 'maximum')), array(REFERENCE, 1)),
    term('ARBITRATION', arguments({'parties': array(NAME, 1, uniqueItems=True),
                                    'arbitrators': array(NAME, 1, uniqueItems=True),
                                    'threshold': {'type': 'integer', 'minimum': 1, 'maximum': 2**53-1},
                                    'procedure': STRING}, ('parties', 'arbitrators', 'threshold', 'procedure'))),
    schema({'kind': {'type': 'string', 'pattern': '^custom:', 'minLength': 8, 'maxLength': 128},
            'arguments': OBJECT, 'references': array(REFERENCE)}, ('kind', 'arguments', 'references')),
]}
LEGAL_NODE['description'] = ('Raw node object, not the node tool response wrapper. Party/resource names must resolve in the module. '
    'Delegation requires different grantor/delegate. Arbitration panel and parties are disjoint; threshold cannot exceed panel size. '
    'IF references are condition, consequent, optional alternative. Custom concepts are preserved without automatic interpretation. '
    'Concept arguments allow additional preserved data except logic nodes, whose arguments must be empty.')
LEGAL_DRAFT = {'title': TEXT, 'parties': mapping(TEXT), 'resources': mapping(ASSET),
               'definitions': mapping(LEGAL_NODE, minProperties=1, maxProperties=64),
               'roots': array(REFERENCE, 1, 64), 'extensions': NULL_OBJECT, 'supersedes': NULL_HASH}
LEGAL_DRAFT['definitions']['description'] = 'Map names to raw node objects; insert node-tool response.node, not its response wrapper.'
MODULE = schema({'version': {'const': 'covenant-legal-module/0.1'}, **LEGAL_DRAFT},
                ('version', 'title', 'parties', 'resources', 'definitions', 'roots', 'extensions', 'supersedes'))
MODULE['properties']['extensions'] = OBJECT


def compact_legal_schema(shape):
    """Lossless standard JSON Schema references for on-demand documentation.

    Executed tool schemas stay expanded for the bounded built-in validator.
    This documentation shares repeated shapes rather than repeating each module
    and node at every action; standard JSON Schema clients resolve local $refs.
    """
    definitions = {'asset': ASSET, 'reference': REFERENCE, 'legal_node': LEGAL_NODE, 'legal_module': MODULE}
    def visit(value, skip=None):
        if type(value) is dict:
            for name, candidate in definitions.items():
                if name != skip and value == candidate:
                    return {'$ref': '#/$defs/' + name}
            return {k: visit(v) for k, v in value.items()}
        if type(value) is list:
            return [visit(v) for v in value]
        return deepcopy(value)
    return {**visit(shape), '$defs': {name: visit(value, name) for name, value in definitions.items()}}


def enrich_specs(specs):
    """Replace only the focused shapes, leaving other tools and actions intact."""
    result = []
    for name, description, readonly, actions in specs:
        enriched = []
        for action, properties, required in actions:
            if name == 'covenant_credit' and action == 'create':
                properties = deepcopy(CREDIT_CREATE)
            if name == 'covenant_legal':
                properties = deepcopy(properties)
                if action == 'draft':
                    properties = deepcopy(LEGAL_DRAFT)
                elif action == 'node':
                    properties = {'kind': {'type': 'string', 'oneOf': [
                        {'enum': ['TERM', 'ALL', 'ANY', 'NOT', 'IF', 'OBLIGATION', 'PERMISSION', 'DELEGATION', 'GUARANTEE', 'ARBITRATION']},
                        {'pattern': '^custom:', 'minLength': 8, 'maxLength': 128}]},
                        'arguments': {**NULL_OBJECT, 'description': 'Constructor accepts incomplete arguments. See describe.input_schema.$defs.legal_node for full per-kind draft requirements; use response.node in definitions.'},
                        'references': {'oneOf': [array(REFERENCE), {'type': 'null'}]}}
                if 'module' in properties:
                    properties['module'] = deepcopy(MODULE)
                if action == 'compose':
                    properties['modules'] = array(MODULE, 1, 256)
                    properties['maximum_terms'] = {'type': 'integer', 'minimum': 1, 'maximum': 4096}
                if action == 'verify_assents':
                    properties['approvals'] = array(schema({'party': NAME, 'signature': {}}, ('party', 'signature')))
            enriched.append((action, properties, required))
        result.append((name, description, readonly, enriched))
    return result


def describe(name, input_schema):
    """Runnable synthetic calls plus full shapes, without keys or implied adoption."""
    cash = {'namespace': 'synthetic', 'identifier': 'GBP', 'unit': 'penny', 'adapter': None, 'transfer_terms': {}}
    grain = {'namespace': 'synthetic', 'identifier': 'grain', 'unit': 'kg', 'adapter': None, 'transfer_terms': {}}
    credit = {'name': 'Synthetic secured farmer loan', 'assets': [cash, grain],
              'participants': ['synthetic-lender', 'synthetic-borrower'],
              'rules': {'lender': 'synthetic-lender', 'borrower': 'synthetic-borrower', 'principal': 125000,
                        'interest_bps': 400, 'origination_fee': 0, 'due_height': 100,
                        'collateral': [{'asset': 1, 'quantity': 1000, 'custody_terms': {'status': 'unverified synthetic declaration'}}],
                        'recourse': 'Declared full recourse', 'transferability': 'Declared nontransferable'},
              'settlement': {}, 'extensions': {'synthetic': True}}
    def raw(kind, args, refs=None):
        return {'kind': kind, 'arguments': args, 'references': refs or []}
    repayment = {'module': 'SELF', 'term': 'repayment'}
    legal = {'title': 'Synthetic repayment and guarantee',
             'parties': {p: 'synthetic-' + p for p in ('lender', 'borrower', 'guarantor', 'reviewer')},
             'resources': {'cash': cash}, 'definitions': {
                 'repayment': raw('OBLIGATION', {'debtor': 'borrower', 'creditor': 'lender', 'performance': 'Repay 130000 pennies at separately agreed maturity.'}),
                 'guarantee': raw('GUARANTEE', {'guarantor': 'guarantor', 'beneficiary': 'lender', 'resource': 'cash', 'maximum': 130000}, [repayment]),
                 'dispute': raw('ARBITRATION', {'parties': ['lender', 'borrower', 'guarantor'], 'arbitrators': ['reviewer'], 'threshold': 1, 'procedure': 'Synthetic proposed review procedure'})},
             'roots': [repayment, {'module': 'SELF', 'term': 'guarantee'}, {'module': 'SELF', 'term': 'dispute'}],
             'extensions': {'synthetic': True}}
    action, parameters = ('create', credit) if name == 'covenant_credit' else ('draft', legal)
    result = {'status': 'DESCRIBED', 'tool': name, 'input_schema': deepcopy(input_schema),
              'examples': [{'tool': name, 'arguments': {'action': action, 'parameters': parameters}}],
              'guide': 'docs/ADVANCED_AGREEMENTS.html',
              'signing_recipe': 'examples/agent_native/secured_credit_and_guarantee.py',
              'synthetic_examples': True, 'execution_authorized': False, 'automatic_assent': False,
              'next_action': 'Run the synthetic example, inspect the returned spec or module, then replace declared terms deliberately. Drafting never grants authority, collateral control or funding.'}
    if name == 'covenant_legal':
        result['input_schema'] = compact_legal_schema(input_schema)
        result['schema_encoding'] = 'STANDARD_JSON_SCHEMA_WITH_LOCAL_REFS; executed tool schemas are also available expanded through discovery.'
        result['node_schema_pointer'] = '/input_schema/$defs/legal_node'
        result['node_usage'] = 'node returns {node: raw_node, execution_authorized: false}; insert only response.node in draft.definitions. roots contains {module: SELF or exact hash, term: definition name} references.'
    else:
        result['execution_boundary'] = 'The local disposable loan adapter supports unsecured single-asset credit; secured multi-asset declarations remain drafts. Dates do not automatically map to ledger heights.'
    return result
