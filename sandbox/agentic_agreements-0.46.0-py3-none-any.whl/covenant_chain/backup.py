"""Crash-safe backup, verification and restore for AAP's durable stores.

    covenant-backup kinds
    covenant-backup backup KIND PATH --out FILE [--online] [--include-keys]
    covenant-backup verify-backup FILE [--expect-sha256 HEX] [--genesis FILE]
    covenant-backup restore FILE PATH [--identity DIGEST] [--service-stopped] [--allow-rollback]
    covenant-backup recover PATH

An archive is one POSIX.1-2001 ustar/pax file (IEEE Std 1003.1, ``tar -xf`` reads it):

    aap-backup/MANIFEST.json   canonical JSON, covenant-backup/1
    aap-backup/SHA256SUMS      ``sha256sum -c`` lines (FIPS 180-4 SHA-256) for MANIFEST.json and each file
    aap-backup/data/...        the store's files; SQLite databases as consistent online-backup snapshots

Anyone can check an archive without AAP code: ``tar -xf FILE && cd aap-backup &&
sha256sum -c SHA256SUMS``. A checksum shows the bytes are unchanged since they
were written, not who wrote them: record the printed archive sha256 somewhere
else and pass it back with ``--expect-sha256``.

A restore verifies everything before it touches the target, never deletes (the
previous store moves to ``<path>.pre-restore-<time>``), and runs from a durable
intent file, so a crash leaves the old store or the new one: ``recover``
finishes an interrupted restore and services refuse to start until it does.
A restore refuses a different chain or instance, a running service, and any
rollback of a validator or replica signing floor. Rolling an append-only store
back needs ``--allow-rollback``. Plaintext key files are left out unless
``--include-keys``; a restore keeps the target's own key files.
"""
import argparse
import fcntl
import fnmatch
import hashlib
import io
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import sqlite3
import stat
import sys
import tempfile
import time

VERSION = 'covenant-backup/1'
INTENT_VERSION = 'covenant-restore-intent/1'
ROOT = 'aap-backup'
MANIFEST = 'MANIFEST.json'
SUMS = 'SHA256SUMS'
INTENT = '.aap-restore.json'
STAGING = '.aap-restore-'
ASIDE = '.pre-restore-'
BLOCK = 512
CHUNK = 1 << 20
MAX_ARCHIVE = 64 * 1024 ** 3
MAX_FILES = 100_000
MAX_MANIFEST = 16 * 1024 * 1024
MAX_PAX = 64 * 1024
MAX_PATH = 400
MAX_DEPTH = 24
SQLITE_MAGIC = b'SQLite format 3\x00'
SIDECARS = ('-wal', '-shm', '-journal')
TEMPORARY = ('.partial', '.pending', '.tmp', '.normalized')
LOCK_NAMES = frozenset({'writer.lock', 'owner.lock', '.welcome.lock', '.handoff.lock', 'library.lock'})
_SEGMENT = re.compile(r'[A-Za-z0-9._@+=,-]{1,128}\Z')
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_MODE = re.compile(r'0[0-7]{3}\Z')

REMEDIATION = {
    'BACKUP_KIND': 'Run covenant-backup kinds and pass one of the listed store kinds.',
    'BACKUP_PATH_MISSING': 'Pass the same path the service uses (its --db, --home, --config directory or file).',
    'BACKUP_SYMLINK': 'Stores never contain symbolic links. Replace the link with the real path and check the host.',
    'BACKUP_UNSAFE_FILE': 'Remove sockets, devices or hard-linked files from the store directory; stores hold regular files only.',
    'BACKUP_SERVICE_RUNNING': 'Stop the service for a cold backup, or pass --online for a snapshot of the running store.',
    'BACKUP_RESTORE_PENDING': 'An interrupted restore is pending. Run covenant-backup recover PATH first.',
    'BACKUP_EXISTS': 'The output file exists. Choose a new name; backups are never overwritten.',
    'BACKUP_OUTPUT_INSIDE_STORE': 'Write the archive outside the store directory, preferably on other media.',
    'BACKUP_SOURCE_CHANGING': 'A file kept changing while it was copied. Stop the service and take a cold backup.',
    'BACKUP_SQLITE': 'SQLite could not snapshot a database. Check permissions and free space; run PRAGMA integrity_check.',
    'BACKUP_SQLITE_INTEGRITY': 'A database failed PRAGMA integrity_check. Do not rely on this copy; restore an older backup.',
    'BACKUP_KEYS_EXCLUDED': 'This store holds only plaintext key material. Pass --include-keys and keep the archive encrypted, or encrypt the key first.',
    'BACKUP_LIMIT': 'The store exceeds the archive limits (files, path depth or size). Split it or raise --max-bytes.',
    'BACKUP_IDENTITY': 'The store has no readable identity row. Open it once with its service, then back it up.',
    'BACKUP_ARCHIVE_FORMAT': 'The file is not a covenant-backup archive or is damaged. Use another copy.',
    'BACKUP_ARCHIVE_MEMBER': 'The archive holds an unexpected, unsafe or reordered member. Do not extract it by hand.',
    'BACKUP_ARCHIVE_TRAILING': 'Data follows the end of the archive. Use an unmodified copy.',
    'BACKUP_ARCHIVE_DIGEST': 'The archive sha256 differs from the recorded value. Treat this copy as tampered with or corrupt.',
    'BACKUP_MANIFEST': 'The manifest is malformed. Use another copy of the backup.',
    'BACKUP_VERSION': 'This archive format is not covenant-backup/1. Use the release that wrote it.',
    'BACKUP_SUMS': 'SHA256SUMS disagrees with the manifest. Use another copy of the backup.',
    'BACKUP_CHECKSUM': 'A file does not match its recorded sha256. The archive is corrupt; use another copy.',
    'BACKUP_IDENTITY_CHANGED': 'The files do not carry the identity the manifest states. Use another copy.',
    'BACKUP_CONTENT_DIGEST': 'A content-addressed file does not hash to its name. The copy is corrupt.',
    'BACKUP_CHAIN_MISMATCH': 'The journal belongs to another chain than --genesis names. Use the backup of this chain.',
    'BACKUP_HISTORY': 'The certified history does not verify against --genesis. Do not restore this journal.',
    'RESTORE_TARGET': 'Pass a target whose parent directory exists and is not a symbolic link.',
    'RESTORE_PENDING': 'An interrupted restore is pending for this target. Run covenant-backup recover PATH.',
    'RESTORE_SERVICE_RUNNING': 'Stop the service that holds the store lock, then restore.',
    'RESTORE_STOP_UNCONFIRMED': 'This store has no lock that proves its users stopped. Stop every process using it, then pass --service-stopped.',
    'RESTORE_IDENTITY_MISMATCH': 'The backup belongs to a different chain, member or instance. Restore the backup of this store.',
    'RESTORE_IDENTITY_UNCONFIRMED': 'The target is empty. Read the identity digest from verify-backup and pass it with --identity.',
    'RESTORE_IDENTITY_DIGEST': 'The --identity digest differs from the backup. Check that this is the backup you meant.',
    'RESTORE_SIGNING_FLOOR_REGRESSION': 'The target signed later than the backup. Restoring would allow conflicting votes; keep the target journal.',
    'RESTORE_HISTORY_REGRESSION': 'The target holds more certified history than the backup. Keep the target or fetch history from peers.',
    'RESTORE_SIGNING_FLOOR_UNKNOWN': 'No target journal shows the signing floor. Only if this key signed nothing after the backup, pass --attest-no-later-signatures; otherwise rotate the key.',
    'RESTORE_WOULD_ROLL_BACK': 'The target holds newer records than the backup. Pass --allow-rollback only after preserving them.',
    'RESTORE_CONTENT_CONFLICT': 'A content-addressed file exists with different bytes. Inspect the target store before merging.',
    'RESTORE_INTENT': 'The restore intent file is damaged. Inspect the .pre-restore and staging paths by hand.',
    'RESTORE_INTENT_CONFLICT': 'Both the staged and the final path exist. Inspect them by hand; nothing was deleted.',
    'RESTORE_NOTHING_PENDING': 'No interrupted restore exists for this path.',
    'BACKUP_IO': 'The operating system refused a read or write. Check the paths, permissions and free space.',
}


class BackupError(ValueError):
    """A refusal with a stable code in args[0] and a remediation message."""

    @property
    def code(self):
        return self.args[0]

    @property
    def remediation(self):
        return REMEDIATION.get(self.code, '')


def _need(ok, code):
    if not ok:
        raise BackupError(code)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def identity_digest(identity):
    """The digest an operator confirms with ``restore --identity``."""
    return hashlib.sha256(b'COVENANT-BACKUP-IDENTITY\0' + canonical(identity)).hexdigest()


def _strict_json(raw, code, limit=MAX_MANIFEST):
    _need(type(raw) is bytes and len(raw) <= limit, code)

    def pairs(items):
        value = {}
        for key, item in items:
            _need(key not in value, code)
            value[key] = item
        return value

    def refuse(_):
        raise BackupError(code)
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_float=refuse, parse_constant=refuse)
    except (UnicodeError, ValueError, RecursionError) as exc:
        if isinstance(exc, BackupError):
            raise
        raise BackupError(code) from None


def _loose_json(raw):
    """A product-owned row: duplicate keys refused, numbers as the product wrote them."""
    if type(raw) is str:
        raw = raw.encode('utf-8')
    _need(type(raw) is bytes and len(raw) <= 256 * 1024 * 1024, 'BACKUP_IDENTITY')

    def pairs(items):
        value = {}
        for key, item in items:
            _need(key not in value, 'BACKUP_IDENTITY')
            value[key] = item
        return value
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)
    except (UnicodeError, ValueError, RecursionError) as exc:
        if isinstance(exc, BackupError):
            raise
        raise BackupError('BACKUP_IDENTITY') from None


def _fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _write_atomic(path, data):
    """temp file + fsync + os.replace + directory fsync; the old or the new bytes, never a mix."""
    path = Path(path)
    temporary = path.with_name(path.name + f'.{secrets.token_hex(6)}.partial')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()
    _fsync_directory(path.parent)


def _safe_relative(path):
    parts = path.split('/')
    _need(0 < len(path) <= MAX_PATH and len(parts) <= MAX_DEPTH, 'BACKUP_LIMIT')
    _need(all(_SEGMENT.fullmatch(part) and part not in ('.', '..') for part in parts), 'BACKUP_ARCHIVE_MEMBER')
    return path


def _mode(info):
    return '0' + format(stat.S_IMODE(info.st_mode) & 0o700, '03o')


# ------------------------------------------------------------------ ustar / pax
def _octal(value, width):
    text = format(value, 'o')
    _need(len(text) < width, 'BACKUP_LIMIT')
    return text.rjust(width - 1, '0').encode('ascii') + b'\0'


def _header(name, size, mode, mtime, typeflag=b'0'):
    prefix = b''
    encoded = name.encode('ascii')
    if len(encoded) > 100:
        cut = encoded.rfind(b'/', 0, 156)
        if 0 < cut and len(encoded) - cut - 1 <= 100:
            prefix, encoded = encoded[:cut], encoded[cut + 1:]
    _need(len(encoded) <= 100 and len(prefix) <= 155, 'BACKUP_LIMIT')
    block = bytearray(BLOCK)
    block[0:len(encoded)] = encoded
    block[100:108] = _octal(mode, 8)
    block[108:116] = _octal(0, 8)
    block[116:124] = _octal(0, 8)
    block[124:136] = _octal(size, 12)
    block[136:148] = _octal(mtime, 12)
    block[148:156] = b' ' * 8
    block[156:157] = typeflag
    block[257:263] = b'ustar\0'
    block[263:265] = b'00'
    block[345:345 + len(prefix)] = prefix
    block[148:156] = format(sum(block), '06o').encode('ascii') + b'\0 '
    return bytes(block)


def _ustar_fits(name):
    encoded = name.encode('ascii')
    if len(encoded) <= 100:
        return True
    cut = encoded.rfind(b'/', 0, 156)
    return 0 < cut and len(encoded) - cut - 1 <= 100


def _pax_record(key, value):
    body = f' {key}={value}\n'.encode('utf-8')
    length = len(body) + 1
    while len(str(length)) + len(body) != length:
        length = len(str(length)) + len(body)
    return str(length).encode('ascii') + body


class ArchiveWriter:
    """Deterministic ustar members, with a pax header only for long paths or large files."""

    def __init__(self, handle, mtime):
        self.handle, self.mtime, self.digest = handle, mtime, hashlib.sha256()

    def _write(self, data):
        self.handle.write(data)
        self.digest.update(data)

    def add(self, name, size, reader, mode=0o600):
        records = b''
        header_name = name
        if not _ustar_fits(name):
            records += _pax_record('path', name)
            header_name = f'{ROOT}/data/pax-path'
        size_field = size
        if size > 0o77777777777:
            records += _pax_record('size', str(size))
            size_field = 0
        if records:
            self._write(_header(f'{ROOT}/PaxHeader', len(records), 0o600, self.mtime, b'x'))
            self._write(records + b'\0' * (-len(records) % BLOCK))
        self._write(_header(header_name, size_field, mode, self.mtime))
        written = 0
        while written < size:
            chunk = reader.read(min(CHUNK, size - written))
            _need(chunk, 'BACKUP_SOURCE_CHANGING')
            self._write(chunk)
            written += len(chunk)
        self._write(b'\0' * (-size % BLOCK))

    def close(self):
        self._write(b'\0' * (2 * BLOCK))


def _number(field):
    text = field.split(b'\0', 1)[0].strip(b' ')
    _need(re.fullmatch(rb'[0-7]{1,12}', text) is not None, 'BACKUP_ARCHIVE_FORMAT')
    return int(text, 8)


def read_members(handle, limit=MAX_ARCHIVE):
    """Yield (name, size, reader) for each regular file of a strict ustar/pax stream.

    Only ustar regular files and pax 'path'/'size' records are accepted; links,
    devices, directories, global headers and data after the end marker are refused.
    """
    consumed = 0
    pending = {}
    while True:
        block = handle.read(BLOCK)
        consumed += len(block)
        _need(len(block) == BLOCK and consumed <= limit, 'BACKUP_ARCHIVE_FORMAT')
        if block == bytes(BLOCK):
            second = handle.read(BLOCK)
            _need(second == bytes(BLOCK) and not pending, 'BACKUP_ARCHIVE_FORMAT')
            while True:
                rest = handle.read(CHUNK)
                if not rest:
                    return
                _need(rest.count(0) == len(rest), 'BACKUP_ARCHIVE_TRAILING')
        stored = _number(block[148:156])
        _need(stored == sum(block[:148]) + 8 * 32 + sum(block[156:]), 'BACKUP_ARCHIVE_FORMAT')
        _need(block[257:263] == b'ustar\0' and block[263:265] == b'00', 'BACKUP_ARCHIVE_FORMAT')
        typeflag = block[156:157]
        size = _number(block[124:136])
        name = block[0:100].split(b'\0', 1)[0]
        prefix = block[345:500].split(b'\0', 1)[0]
        try:
            name = ((prefix + b'/' + name) if prefix else name).decode('ascii')
        except UnicodeError:
            raise BackupError('BACKUP_ARCHIVE_MEMBER') from None
        if typeflag == b'x':
            _need(size <= MAX_PAX and not pending, 'BACKUP_ARCHIVE_FORMAT')
            raw = handle.read(size)
            padding = handle.read(-size % BLOCK)
            consumed += size + (-size % BLOCK)
            _need(len(raw) == size and padding.count(0) == len(padding) == -size % BLOCK, 'BACKUP_ARCHIVE_FORMAT')
            index = 0
            while index < len(raw):
                space = raw.find(b' ', index)
                _need(space > index, 'BACKUP_ARCHIVE_FORMAT')
                length = int(raw[index:space]) if raw[index:space].isdigit() else 0
                record = raw[index:index + length]
                _need(length > space - index and record.endswith(b'\n') and b'=' in record, 'BACKUP_ARCHIVE_FORMAT')
                key, value = record[space - index + 1:-1].split(b'=', 1)
                _need(key in (b'path', b'size') and key.decode() not in pending and value.isascii(), 'BACKUP_ARCHIVE_FORMAT')
                pending[key.decode()] = value.decode('ascii')
                index += length
            continue
        _need(typeflag in (b'0', b'\0'), 'BACKUP_ARCHIVE_MEMBER')
        if 'path' in pending:
            name = pending['path']
        if 'size' in pending:
            _need(pending['size'].isdigit() and size == 0, 'BACKUP_ARCHIVE_FORMAT')
            size = int(pending['size'])
        pending = {}
        _need(consumed + size <= limit, 'BACKUP_LIMIT')
        reader = _Bounded(handle, size)
        yield name, size, reader
        reader.drain()
        padding = handle.read(-size % BLOCK)
        _need(padding.count(0) == len(padding) == -size % BLOCK, 'BACKUP_ARCHIVE_FORMAT')
        consumed += size + len(padding)


class _Bounded:
    def __init__(self, handle, size):
        self.handle, self.left = handle, size

    def read(self, size=-1):
        size = self.left if size < 0 else min(size, self.left)
        data = self.handle.read(size)
        _need(len(data) == size, 'BACKUP_ARCHIVE_FORMAT')
        self.left -= len(data)
        return data

    def drain(self):
        while self.left:
            self.read(min(CHUNK, self.left))


class _Hashing:
    """Reads from a file object while hashing every byte (the whole-archive digest)."""

    def __init__(self, handle):
        self.handle, self.digest = handle, hashlib.sha256()

    def read(self, size):
        data = self.handle.read(size)
        self.digest.update(data)
        return data


# ------------------------------------------------------------------ store views
class View:
    """Read one store's files by archive-relative name; SQLite through snapshots, never the live file."""

    def __init__(self, resolve, scratch, *, live):
        self.resolve, self.scratch, self.live = resolve, Path(scratch), live
        self._open = []

    def exists(self, name):
        path = self.resolve(name)
        return path is not None and os.path.lexists(path)

    def bytes(self, name, limit=MAX_MANIFEST):
        path = self.resolve(name)
        if path is None or not os.path.lexists(path):
            return None
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            data = os.read(fd, limit + 1)
        finally:
            os.close(fd)
        _need(len(data) <= limit, 'BACKUP_LIMIT')
        return data

    def json(self, name, code='BACKUP_IDENTITY'):
        raw = self.bytes(name)
        return None if raw is None else _strict_json(raw, code)

    def sqlite(self, name):
        path = self.resolve(name)
        if path is None or not os.path.isfile(path) or not _is_sqlite(path):
            return None
        if self.live:
            copy = self.scratch / f'view-{secrets.token_hex(6)}.sqlite'
            snapshot(path, copy)
            path = copy
        db = sqlite3.connect(Path(path).absolute().as_uri() + '?mode=ro&immutable=1', uri=True)
        self._open.append(db)
        return db

    def names(self, prefix=''):
        """Regular files below a directory name, relative to the view."""
        base = self.resolve(prefix or '.')
        if base is None or not os.path.isdir(base):
            return []
        found = []
        for root, directories, files in os.walk(base):
            directories[:] = sorted(d for d in directories if not os.path.islink(os.path.join(root, d)))
            for name in sorted(files):
                relative = os.path.relpath(os.path.join(root, name), self.resolve('.'))
                found.append(relative.replace(os.sep, '/'))
                _need(len(found) <= MAX_FILES, 'BACKUP_LIMIT')
        return found

    def close(self):
        for db in self._open:
            db.close()
        self._open.clear()


def _is_sqlite(path):
    try:
        with open(path, 'rb') as handle:
            return handle.read(16) == SQLITE_MAGIC
    except OSError:
        return False


def snapshot(source, destination):
    """A consistent copy of a SQLite database, live or not, through SQLite's online backup API."""
    destination = Path(destination)
    _need(not destination.exists(), 'BACKUP_SQLITE')
    try:
        source_db = sqlite3.connect(Path(source).absolute().as_uri() + '?mode=ro', uri=True, timeout=30)
        try:
            source_db.execute('PRAGMA busy_timeout=30000')
            fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            os.close(fd)
            target = sqlite3.connect(destination)
            try:
                from covenant_language.safe_io import durable_sqlite
                durable_sqlite(target, journal='DELETE')
                source_db.backup(target)
            finally:
                target.close()
        finally:
            source_db.close()
    except sqlite3.Error as exc:
        raise BackupError('BACKUP_SQLITE') from exc
    for tail in SIDECARS:
        sidecar = Path(str(destination) + tail)
        if sidecar.exists():
            sidecar.unlink()


def integrity(path):
    db = sqlite3.connect(Path(path).absolute().as_uri() + '?mode=ro&immutable=1', uri=True)
    try:
        rows = db.execute('PRAGMA integrity_check').fetchall()
    except sqlite3.Error:
        rows = [('error',)]
    finally:
        db.close()
    return rows == [('ok',)]


# ------------------------------------------------------------------ store kinds
def _count(db, sql):
    try:
        return db.execute(sql).fetchone()[0]
    except sqlite3.Error:
        return 0


def _row(db, sql):
    try:
        return db.execute(sql).fetchone()
    except sqlite3.Error:
        return None


def _journal_facts(db):
    row = _row(db, 'SELECT body FROM safety WHERE id=1')
    _need(row is not None, 'BACKUP_IDENTITY')
    safety = _loose_json(row[0])
    _need(type(safety) is dict and type(safety.get('member')) is str and type(safety.get('config')) is str
          and type(safety.get('height')) is int and type(safety.get('round')) is int, 'BACKUP_IDENTITY')
    first = _row(db, 'SELECT body FROM commits WHERE height=1')
    chain = None
    if first is not None:
        block = _loose_json(first[0]).get('block')
        chain = block.get('chain') if type(block) is dict else None
    if chain is None:
        for message in (safety.get('signed') or {}).values():
            chain = (message.get('body') or {}).get('chain') if type(message) is dict else None
            if chain:
                break
    committed = _count(db, 'SELECT COALESCE(MAX(height),0) FROM commits')
    return safety, chain, committed


def _node(view):
    db = view.sqlite('base.sqlite3')
    if db is None:
        raw = view.bytes('base', limit=256 * 1024 * 1024)
        legacy = None if raw is None else _loose_json(raw)
        _need(type(legacy) is dict and 'member' in legacy and 'config' in legacy, 'BACKUP_IDENTITY')
        chain = None
        commits = legacy.get('commits') or []
        if commits:
            chain = commits[0]['block'].get('chain')
        identity = {'chain': chain, 'member': legacy['member']}
        if chain is None:
            identity['config'] = legacy['config']
        return identity, {'config': legacy['config'], 'committed_height': len(commits),
                          'signing_height': legacy.get('height', 0), 'signing_round': legacy.get('round', 0)}
    safety, chain, committed = _journal_facts(db)
    identity = {'chain': chain, 'member': safety['member']}
    if chain is None:
        identity['config'] = safety['config']
    return identity, {'config': safety['config'], 'committed_height': committed,
                      'signing_height': safety['height'], 'signing_round': safety['round']}


def _replica(view):
    marker = view.json('identity.json')
    _need(type(marker) is dict and set(marker) == {'cluster', 'member'}, 'BACKUP_IDENTITY')
    db = view.sqlite('consensus.sqlite3')
    _need(db is not None, 'BACKUP_IDENTITY')
    safety, _chain, committed = _journal_facts(db)
    _need(safety['member'] == marker['member'], 'BACKUP_IDENTITY')
    return dict(marker), {'config': safety['config'], 'committed_height': committed,
                          'signing_height': safety['height'], 'signing_round': safety['round']}


def _settlement(view):
    db = view.sqlite('store')
    _need(db is not None, 'BACKUP_IDENTITY')
    row = _row(db, 'SELECT value FROM reference_state WHERE id=1')
    _need(row is not None, 'BACKUP_IDENTITY')
    value = _strict_json(row[0] if type(row[0]) is bytes else row[0].encode(), 'BACKUP_IDENTITY')
    _need(type(value) is dict and type(value.get('instance')) is str and _HEX.fullmatch(value['instance']), 'BACKUP_IDENTITY')
    # The instance is the authority's identity; the storage format is state, so a migrated ledger
    # still matches its pre-upgrade backup and a rollback is a guarded restore, not a new identity.
    return ({'instance': value['instance']},
            {'storage_format': value.get('storage_format', 'legacy-single-blob'),
             'records': _count(db, 'SELECT COUNT(*) FROM reference_records'),
             'receipts': _count(db, "SELECT COUNT(*) FROM reference_records WHERE kind='receipts'")})


def _public_web(view):
    db = view.sqlite('store')
    _need(db is not None, 'BACKUP_IDENTITY')
    try:
        rows = db.execute('SELECT origin FROM config').fetchall()
    except sqlite3.Error:
        rows = []
    _need(len(rows) == 1, 'BACKUP_IDENTITY')
    return {'origin': rows[0][0]}, {'records': _count(db, 'SELECT COUNT(*) FROM history')}


def _welcome(view):
    record = view.json('preferences.json')
    public = record.get('identity_public') if type(record) is dict else None
    encrypted = view.bytes('keys/identity.enc.json')
    return ({'identity_public': public},
            {'preferences': record is not None, 'encrypted_key': encrypted is not None})


def _handoff(view):
    record = view.json('handoff.json')
    if record is None:
        return {'identity_public': None}, {'generation': 0}
    _need(type(record) is dict and type(record.get('generation')) is int, 'BACKUP_IDENTITY')
    return {'identity_public': record.get('identity_public')}, {'generation': record['generation']}


def _workflow_facts(db):
    if db is None:
        return None, 0, None
    row = _row(db, 'SELECT pin FROM context')
    head = _row(db, 'SELECT id FROM events ORDER BY sequence DESC LIMIT 1')
    return (row[0] if row else None), _count(db, 'SELECT COUNT(*) FROM events'), (head[0] if head else None)


def _workflow(view):
    pin, events, head = _workflow_facts(view.sqlite('workflow.sqlite'))
    _need(pin is not None, 'BACKUP_IDENTITY')
    return {'pin': pin}, {'records': events, 'head': head}


def _requests(view):
    db = view.sqlite('requests.sqlite')
    _need(db is not None, 'BACKUP_IDENTITY')
    first = _row(db, 'SELECT id FROM requests ORDER BY ordinal LIMIT 1')
    return {'first_request': first[0] if first else None}, {'records': _count(db, 'SELECT COUNT(*) FROM events')}


def _keystore(view):
    encrypted = view.bytes('identity.enc.json')
    plain = view.bytes('identity.hex')
    _need(encrypted is None or plain is None, 'BACKUP_IDENTITY')
    if encrypted is not None:
        return {'encrypted_sha256': hashlib.sha256(encrypted).hexdigest()}, {}
    if plain is None:
        return {'public': None}, {}
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    try:
        seed = bytes.fromhex(plain.decode('ascii').strip())
        public = Ed25519PrivateKey.from_private_bytes(seed).public_key().public_bytes_raw().hex()
    except (ValueError, UnicodeError):
        raise BackupError('BACKUP_IDENTITY') from None
    return {'public': public}, {}


def _agent_home(view):
    pin, events, _head = _workflow_facts(view.sqlite('a2a/workflow.sqlite'))
    board = view.bytes('directory.jsonl', limit=64 * 1024 * 1024)
    chain = None
    rows = 0
    if board:
        lines = [line for line in board.split(b'\n') if line.strip()]
        rows = len(lines)
        if lines:
            first = _loose_json(lines[0])
            chain = ((first if type(first) is dict else {}).get('body') or {}).get('chain')
    requests = view.sqlite('requests/requests.sqlite')
    first = _row(requests, 'SELECT id FROM requests ORDER BY ordinal LIMIT 1') if requests else None
    return ({'a2a': pin, 'directory_chain': chain, 'first_request': first[0] if first else None},
            {'records': events + rows + (_count(requests, 'SELECT COUNT(*) FROM events') if requests else 0)})


def _directory_board(view):
    raw = view.bytes('store', limit=64 * 1024 * 1024) or b''
    lines = [line for line in raw.split(b'\n') if line.strip()]
    chain = None
    if lines:
        first = _loose_json(lines[0])
        chain = ((first if type(first) is dict else {}).get('body') or {}).get('chain')
    return {'chain': chain}, {'records': len(lines)}


def _evidence(view):
    shards = [name for name in view.names('shards')]
    manifests = [name for name in view.names('manifests')]
    return {}, {'shards': len(shards), 'manifests': len(manifests)}


def _evidence_integrity(view):
    from .crypto import digest
    from .evidence_store import LABEL
    for name in view.names('shards'):
        _need(hashlib.sha256(view.bytes(name, limit=64 * 1024 * 1024)).hexdigest() == name.rsplit('/', 1)[-1],
              'BACKUP_CONTENT_DIGEST')
    for name in view.names('manifests'):
        body = _strict_json(view.bytes(name), 'BACKUP_CONTENT_DIGEST')
        _need(digest(LABEL, body) == name.rsplit('/', 1)[-1], 'BACKUP_CONTENT_DIGEST')


def _offline(view):
    pin, events, head = _workflow_facts(view.sqlite('vault/workflow.sqlite'))
    _need(pin is not None, 'BACKUP_IDENTITY')
    return {'vault': pin}, {'records': events, 'head': head}


def _tool_calls(view):
    db = view.sqlite('tool-calls.sqlite')
    _need(db is not None, 'BACKUP_IDENTITY')
    row = _row(db, 'SELECT pin, instance FROM context')
    _need(row is not None, 'BACKUP_IDENTITY')
    return {'pin': row[0], 'instance': row[1]}, {'records': _count(db, 'SELECT COUNT(*) FROM events')}


def _feedback(view):
    db = view.sqlite('store')
    _need(db is not None, 'BACKUP_IDENTITY')
    row = _row(db, 'SELECT pin FROM context')
    _need(row is not None, 'BACKUP_IDENTITY')
    return {'pin': row[0]}, {'records': _count(db, 'SELECT COUNT(*) FROM entries')}


class Kind:
    def __init__(self, name, layout, facts, summary, *, lock=None, members=(), keys=(), guard=None,
                 mode='replace', check=None):
        self.name, self.layout, self.facts, self.summary = name, layout, facts, summary
        self.lock, self.members, self.keys, self.guard, self.mode, self.check = lock, members, keys, guard, mode, check


KINDS = {kind.name: kind for kind in (
    Kind('node', 'base', _node, 'validator node journal: the --db base path (.sqlite3, .causal.sqlite3, .feedback.sqlite3)',
         lock='.lock', members=('.sqlite3', '.causal.sqlite3', '.feedback.sqlite3', ''), guard='signing'),
    Kind('replica', 'tree', _replica, 'provider or private provider replica directory (identity.json, consensus.sqlite3)',
         lock='owner.lock', guard='signing'),
    Kind('settlement', 'file', _settlement, 'reference settlement ledger SQLite file (settlement_db)', guard='records'),
    Kind('public-web', 'file', _public_web, 'public web publication database (--db)', guard='records'),
    Kind('welcome', 'tree', _welcome, 'welcome application home (--home): preferences and keys/',
         lock='.welcome.lock', keys=('keys/identity.hex',)),
    Kind('handoff', 'tree', _handoff, 'owner handoff home (--home): handoff.json and identity.hex',
         lock='.handoff.lock', keys=('identity.hex',), guard='generation'),
    Kind('agent-home', 'tree', _agent_home, 'agent server home ($COVENANT_HOME): directory board, a2a/, requests/',
         keys=('forum.key', 'identity.hex', '*/identity.hex'), guard='records'),
    Kind('workflow', 'tree', _workflow, 'any WorkflowStore directory (agent gateway log, a2a, workflow runtime)',
         guard='records'),
    Kind('requests', 'tree', _requests, 'saved request workspace directory (requests.sqlite)', guard='records'),
    Kind('keystore', 'tree', _keystore, 'local key directory (identity.hex or identity.enc.json)', keys=('identity.hex',)),
    Kind('directory-board', 'file', _directory_board, 'directory board JSON Lines file', guard='records'),
    Kind('evidence', 'tree', _evidence, 'evidence bytes store (content-addressed shards/ and manifests/)',
         mode='merge', check=_evidence_integrity),
    Kind('offline', 'tree', _offline, 'offline custody directory (encrypted owner.key and vault/)', guard='records'),
    Kind('tool-calls', 'tree', _tool_calls, 'MCP tool client journal directory (tool-calls.sqlite)', guard='records'),
    Kind('feedback', 'file', _feedback, 'founder feedback desk SQLite file', guard='records'),
)}


def kinds():
    return {name: {'layout': kind.layout, 'summary': kind.summary, 'lifetime_lock': kind.lock is not None,
                   'restore': kind.mode, 'guard': kind.guard} for name, kind in KINDS.items()}


# ------------------------------------------------------------------ enumeration and locks
def intent_path(target):
    target = Path(target)
    return target.with_name(target.name + INTENT)


def refuse_pending_restore(path):
    """Services call this before opening a store: a half-finished restore must be recovered first."""
    if path is not None and intent_path(Path(path).expanduser().absolute()).exists():
        raise ValueError('RESTORE_PENDING')


def _lock_path(kind, target):
    if kind.lock is None:
        return None
    return Path(str(target) + kind.lock) if kind.layout == 'base' else Path(target) / kind.lock


def _try_lock(path):
    """flock EX|NB on a store's lifetime lock: an fd when free, None when a service holds it."""
    if path is None or not path.parent.is_dir():
        return -1
    fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        return None
    return fd


def _unlock(fd):
    if fd is not None and fd >= 0:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _is_key(kind, name):
    return any(fnmatch.fnmatchcase(name, pattern) for pattern in kind.keys)


def _members(kind, target):
    """Archive name -> live path for every file the store keeps (excluding locks, sidecars, temporaries)."""
    target = Path(target)
    if kind.layout == 'base':
        found = {}
        for suffix in kind.members:
            path = Path(str(target) + suffix)
            if os.path.lexists(path):
                found['base' + suffix] = path
        return found
    if kind.layout == 'file':
        return {'store': target} if os.path.lexists(target) else {}
    found = {}
    if not target.is_dir():
        return found
    for root, directories, files in os.walk(target):
        for name in directories:
            _need(not os.path.islink(os.path.join(root, name)), 'BACKUP_SYMLINK')
        directories.sort()
        for name in sorted(files):
            path = Path(root) / name
            relative = path.relative_to(target).as_posix()
            if (name in LOCK_NAMES or name.endswith(TEMPORARY) or name.startswith(STAGING)
                    or (name.endswith(SIDECARS) and _is_sqlite(Path(root) / name.rsplit('-', 1)[0]))):
                continue
            found[relative] = path
            _need(len(found) <= MAX_FILES, 'BACKUP_LIMIT')
    return found


def _directories(target):
    target = Path(target)
    found = []
    for root, directories, _files in os.walk(target):
        for name in sorted(directories):
            path = Path(root) / name
            if name.startswith(STAGING):
                continue
            found.append({'path': _safe_relative(path.relative_to(target).as_posix()), 'mode': _mode(path.lstat())})
    return found


def _copy_stable(source, destination):
    """Copy one regular file; refuse if it changes while being read (three attempts)."""
    for _attempt in range(3):
        before = os.lstat(source)
        _need(stat.S_ISREG(before.st_mode), 'BACKUP_UNSAFE_FILE')
        _need(before.st_nlink == 1, 'BACKUP_UNSAFE_FILE')
        digest = hashlib.sha256()
        fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
        out = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
        try:
            while chunk := os.read(fd, CHUNK):
                digest.update(chunk)
                os.write(out, chunk)
            os.fsync(out)
        finally:
            os.close(fd)
            os.close(out)
        after = os.lstat(source)
        if (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino):
            return digest.hexdigest()
    raise BackupError('BACKUP_SOURCE_CHANGING')


def _file_digest(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        while chunk := handle.read(CHUNK):
            digest.update(chunk)
    return digest.hexdigest()


def _staged_view(data, scratch):
    return View(lambda name: data / name, scratch, live=False)


def _live_view(kind, target, scratch):
    target = Path(target)
    if kind.layout == 'base':
        return View(lambda name: Path(str(target) + name[len('base'):]) if name.startswith('base') else None,
                    scratch, live=True)
    if kind.layout == 'file':
        return View(lambda name: target if name == 'store' else None, scratch, live=True)
    return View(lambda name: target / name, scratch, live=True)


def _facts(kind, view):
    try:
        identity, state = kind.facts(view)
    finally:
        view.close()
    return identity, state


def _now():
    return int(time.time())


def _stamp(now):
    return time.strftime('%Y%m%dT%H%M%SZ', time.gmtime(now))


# ------------------------------------------------------------------ backup
def backup(kind_name, path, out, *, online=False, include_keys=False, max_bytes=MAX_ARCHIVE, now=None):
    """Write one archive. Returns the report printed by the CLI (identity digest, archive sha256)."""
    _need(kind_name in KINDS, 'BACKUP_KIND')
    kind = KINDS[kind_name]
    target = Path(path).expanduser().absolute()
    out = Path(out).expanduser().absolute()
    _need(not target.is_symlink(), 'BACKUP_SYMLINK')
    _need(not intent_path(target).exists(), 'BACKUP_RESTORE_PENDING')
    _need(not os.path.lexists(out), 'BACKUP_EXISTS')
    _need(out.parent.is_dir(), 'BACKUP_PATH_MISSING')
    _need(kind.layout != 'tree' or not out.is_relative_to(target), 'BACKUP_OUTPUT_INSIDE_STORE')
    lock = _try_lock(_lock_path(kind, target))
    _need(lock is not None or online, 'BACKUP_SERVICE_RUNNING')
    service = 'unknown' if lock == -1 else 'stopped' if lock is not None else 'running'
    now = _now() if now is None else now
    staging = None
    try:
        members = _members(kind, target)
        _need(members or (kind.layout == 'tree' and target.is_dir()), 'BACKUP_PATH_MISSING')
        staging = Path(tempfile.mkdtemp(prefix='.covenant-backup-', dir=out.parent))
        data = staging / 'data'
        data.mkdir(mode=0o700)
        files, excluded, total = [], [], 0
        for name in sorted(members):
            source = members[name]
            _safe_relative(name)
            _need(not os.path.islink(source), 'BACKUP_SYMLINK')
            if _is_key(kind, name) and not include_keys:
                excluded.append(name)
                continue
            destination = data / name
            destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            info = os.lstat(source)
            _need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'BACKUP_UNSAFE_FILE')
            if _is_sqlite(source):
                snapshot(source, destination)
                _need(integrity(destination), 'BACKUP_SQLITE_INTEGRITY')
                digest = _file_digest(destination)
            else:
                digest = _copy_stable(source, destination)
            size = destination.stat().st_size
            total += size
            _need(total <= max_bytes, 'BACKUP_LIMIT')
            files.append({'path': name, 'bytes': size, 'sha256': digest, 'mode': _mode(info),
                          'sqlite': _is_sqlite(destination), 'private_key': _is_key(kind, name)})
        _need(files, 'BACKUP_KEYS_EXCLUDED' if excluded else 'BACKUP_PATH_MISSING')
        identity, state = _facts(kind, _staged_view(data, staging))
        if kind.check is not None:
            view = _staged_view(data, staging)
            try:
                kind.check(view)
            finally:
                view.close()
        manifest = {
            'v': VERSION, 'kind': kind.name, 'layout': kind.layout, 'identity': identity,
            'identity_sha256': identity_digest(identity), 'state': state, 'service': service,
            'created': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now)),
            'source_name': target.name, 'files': files,
            'directories': _directories(target) if kind.layout == 'tree' else [],
            'excluded_private_keys': excluded,
            'tool': {'package': _package_version()},
        }
        manifest_bytes = canonical(manifest)
        sums = [f'{hashlib.sha256(manifest_bytes).hexdigest()}  {MANIFEST}']
        sums.extend(f'{item["sha256"]}  data/{item["path"]}' for item in files)
        sums_bytes = ('\n'.join(sums) + '\n').encode('ascii')
        partial = out.with_name(out.name + f'.{secrets.token_hex(6)}.partial')
        fd = os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, 'wb') as handle:
                writer = ArchiveWriter(handle, now)
                writer.add(f'{ROOT}/{MANIFEST}', len(manifest_bytes), io.BytesIO(manifest_bytes))
                writer.add(f'{ROOT}/{SUMS}', len(sums_bytes), io.BytesIO(sums_bytes))
                for item in files:
                    with open(data / item['path'], 'rb') as reader:
                        writer.add(f'{ROOT}/data/{item["path"]}', item['bytes'], reader, int(item['mode'], 8))
                writer.close()
                handle.flush()
                os.fsync(handle.fileno())
            archive_sha256 = writer.digest.hexdigest()
            try:
                os.link(partial, out)
            except FileExistsError:
                raise BackupError('BACKUP_EXISTS') from None
            _fsync_directory(out.parent)
        finally:
            if partial.exists():
                partial.unlink()
        # readiness: not-secret These fields contain relative path names and booleans, never private-key contents.
        return {'archive': str(out), 'sha256': archive_sha256, 'bytes': out.stat().st_size, 'kind': kind.name,
                'identity': identity, 'identity_sha256': manifest['identity_sha256'], 'state': state,
                'service': service, 'files': len(files), 'private_keys': [i['path'] for i in files if i['private_key']],
                'excluded_private_keys': excluded}
    finally:
        _unlock(lock)
        if staging is not None:
            shutil.rmtree(staging, ignore_errors=True)


def _package_version():
    from covenant_language._version import __version__
    return __version__


# ------------------------------------------------------------------ verification
def _validate_manifest(manifest):
    _need(type(manifest) is dict, 'BACKUP_MANIFEST')
    _need(manifest.get('v') == VERSION, 'BACKUP_VERSION')
    _need(set(manifest) == {'v', 'kind', 'layout', 'identity', 'identity_sha256', 'state', 'service', 'created',
                            'source_name', 'files', 'directories', 'excluded_private_keys', 'tool'}, 'BACKUP_MANIFEST')
    _need(manifest['kind'] in KINDS and manifest['layout'] == KINDS[manifest['kind']].layout, 'BACKUP_MANIFEST')
    _need(type(manifest['identity']) is dict and manifest['identity_sha256'] == identity_digest(manifest['identity']),
          'BACKUP_MANIFEST')
    _need(manifest['service'] in ('stopped', 'running', 'unknown') and type(manifest['state']) is dict, 'BACKUP_MANIFEST')
    files = manifest['files']
    _need(type(files) is list and 0 < len(files) <= MAX_FILES, 'BACKUP_MANIFEST')
    names = []
    for item in files:
        _need(type(item) is dict and set(item) == {'path', 'bytes', 'sha256', 'mode', 'sqlite', 'private_key'},
              'BACKUP_MANIFEST')
        _safe_relative(item['path'])
        _need(type(item['bytes']) is int and 0 <= item['bytes'] <= MAX_ARCHIVE and type(item['sha256']) is str
              and _HEX.fullmatch(item['sha256']) and type(item['mode']) is str and _MODE.fullmatch(item['mode'])
              and type(item['sqlite']) is bool and type(item['private_key']) is bool, 'BACKUP_MANIFEST')
        names.append(item['path'])
    _need(names == sorted(set(names)), 'BACKUP_MANIFEST')
    taken = set(names)
    _need(not any(name.rsplit('/', depth)[0] in taken for name in names
                  for depth in range(1, name.count('/') + 1)), 'BACKUP_MANIFEST')
    _need(type(manifest['directories']) is list and len(manifest['directories']) <= MAX_FILES, 'BACKUP_MANIFEST')
    for item in manifest['directories']:
        _need(type(item) is dict and set(item) == {'path', 'mode'} and type(item['mode']) is str
              and _MODE.fullmatch(item['mode']), 'BACKUP_MANIFEST')
        _safe_relative(item['path'])
    _need(type(manifest['excluded_private_keys']) is list, 'BACKUP_MANIFEST')
    return manifest


def _parse_sums(raw):
    try:
        lines = raw.decode('ascii').split('\n')
    except UnicodeError:
        raise BackupError('BACKUP_SUMS') from None
    _need(lines[-1] == '', 'BACKUP_SUMS')
    entries = []
    for line in lines[:-1]:
        match = re.fullmatch(r'([0-9a-f]{64}) [ *](\S+)', line)
        _need(match is not None, 'BACKUP_SUMS')
        entries.append((match.group(2), match.group(1)))
    return entries


def read_archive(path, data=None, *, expect_sha256=None, max_bytes=MAX_ARCHIVE):
    """Check every byte of an archive; with ``data``, extract the store files into that directory."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as raw:
        _need(stat.S_ISREG(os.fstat(raw.fileno()).st_mode), 'BACKUP_ARCHIVE_FORMAT')
        _need(os.fstat(raw.fileno()).st_size <= max_bytes, 'BACKUP_LIMIT')
        handle = _Hashing(raw)
        members = read_members(handle, max_bytes)
        try:
            name, size, reader = next(members)
            _need(name == f'{ROOT}/{MANIFEST}' and size <= MAX_MANIFEST, 'BACKUP_ARCHIVE_MEMBER')
            manifest_bytes = reader.read(size)
            manifest = _validate_manifest(_strict_json(manifest_bytes, 'BACKUP_MANIFEST'))
            _need(canonical(manifest) == manifest_bytes, 'BACKUP_MANIFEST')
            name, size, reader = next(members)
            _need(name == f'{ROOT}/{SUMS}' and size <= MAX_MANIFEST, 'BACKUP_ARCHIVE_MEMBER')
            expected = [(MANIFEST, hashlib.sha256(manifest_bytes).hexdigest())]
            expected += [('data/' + item['path'], item['sha256']) for item in manifest['files']]
            _need(_parse_sums(reader.read(size)) == expected, 'BACKUP_SUMS')
            for item in manifest['files']:
                name, size, reader = next(members)
                _need(name == f'{ROOT}/data/{item["path"]}' and size == item['bytes'], 'BACKUP_ARCHIVE_MEMBER')
                digest = hashlib.sha256()
                out = None
                if data is not None:
                    destination = Path(data) / item['path']
                    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    out = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                  int(item['mode'], 8) | 0o600)
                try:
                    left = size
                    while left:
                        chunk = reader.read(min(CHUNK, left))
                        digest.update(chunk)
                        if out is not None:
                            os.write(out, chunk)
                        left -= len(chunk)
                    if out is not None:
                        os.fsync(out)
                finally:
                    if out is not None:
                        os.close(out)
                _need(digest.hexdigest() == item['sha256'], 'BACKUP_CHECKSUM')
            for _extra in members:
                raise BackupError('BACKUP_ARCHIVE_MEMBER')
        except StopIteration:
            raise BackupError('BACKUP_ARCHIVE_MEMBER') from None
        archive_sha256 = handle.digest.hexdigest()
    if expect_sha256 is not None:
        _need(expect_sha256.lower() == archive_sha256, 'BACKUP_ARCHIVE_DIGEST')
    return manifest, archive_sha256


def _deep_checks(manifest, data, scratch, genesis=None):
    kind = KINDS[manifest['kind']]
    for item in manifest['files']:
        if item['sqlite']:
            _need(integrity(Path(data) / item['path']), 'BACKUP_SQLITE_INTEGRITY')
    identity, state = _facts(kind, _staged_view(Path(data), scratch))
    _need(identity == manifest['identity'] and state == manifest['state'], 'BACKUP_IDENTITY_CHANGED')
    if kind.check is not None:
        view = _staged_view(Path(data), scratch)
        try:
            kind.check(view)
        finally:
            view.close()
    if genesis is not None:
        _need(kind.guard == 'signing' and kind.layout == 'base', 'BACKUP_KIND')
        from .proofs import verify_history
        chain = journal_chain(genesis)[0]
        _need(journal_matches(identity, genesis), 'BACKUP_CHAIN_MISMATCH')
        view = _staged_view(Path(data), scratch)
        try:
            db = view.sqlite('base.sqlite3')
            history = [json.loads(row[0]) for row in db.execute('SELECT body FROM commits ORDER BY height')] if db else []
        finally:
            view.close()
        try:
            verify_history(genesis, history, chain)
        except (ValueError, KeyError, TypeError) as exc:
            raise BackupError('BACKUP_HISTORY') from exc
    return identity, state


def journal_chain(genesis):
    """(chain id, initial committee pin) of a genesis, as consensus.Engine pins its journal."""
    from . import crypto
    chain = crypto.genesis_id(genesis)
    return chain, crypto.digest('COVENANT_CHAIN_CONFIG', {'chain_id': chain, 'validators': genesis.get('validators'),
                                                          'faults': genesis.get('faults')})


def journal_matches(identity, genesis):
    """A journal belongs to this genesis: its chain id, or before any block or vote, its initial committee pin."""
    chain, pin = journal_chain(genesis)
    if identity.get('chain') is None:
        return identity.get('config') == pin
    return identity['chain'] == chain


def verify(path, *, expect_sha256=None, genesis=None, max_bytes=MAX_ARCHIVE):
    """Full check: archive structure, every checksum, SQLite integrity and the stated identity."""
    scratch = Path(tempfile.mkdtemp(prefix='covenant-verify-'))
    try:
        data = scratch / 'data'
        data.mkdir(mode=0o700)
        manifest, archive_sha256 = read_archive(path, data, expect_sha256=expect_sha256, max_bytes=max_bytes)
        _deep_checks(manifest, data, scratch, genesis)
    finally:
        shutil.rmtree(scratch, ignore_errors=True)
    # readiness: not-secret The private_keys field lists relative archive paths, not key bytes.
    return {'ok': True, 'kind': manifest['kind'], 'identity': manifest['identity'],
            'identity_sha256': manifest['identity_sha256'], 'state': manifest['state'],
            'service': manifest['service'], 'created': manifest['created'], 'files': len(manifest['files']),
            'sha256': archive_sha256, 'private_keys': [i['path'] for i in manifest['files'] if i['private_key']]}


# ------------------------------------------------------------------ restore
def _fsync_tree(root):
    for directory, _directories, _files in os.walk(root, topdown=False):
        _fsync_directory(directory)


def _target_paths(kind, target, manifest):
    """Final live path for each archive name, plus the live paths a replace must move aside."""
    target = Path(target)
    if kind.layout == 'base':
        finals = {item['path']: Path(str(target) + item['path'][len('base'):]) for item in manifest['files']}
        existing = []
        for suffix in kind.members:
            for tail in ('',) + (SIDECARS if suffix else ()):
                path = Path(str(target) + suffix + tail)
                if os.path.lexists(path):
                    existing.append(path)
        return finals, existing
    if kind.layout == 'file':
        existing = [Path(str(target) + tail) for tail in ('',) + SIDECARS if os.path.lexists(str(target) + tail)]
        return {'store': target}, existing
    return {item['path']: target / item['path'] for item in manifest['files']}, ([target] if target.exists() else [])


def _has_data(kind, target):
    return bool(_members(kind, target))


def _guard(kind, manifest, target_state, *, allow_rollback, attest):
    backup_state = manifest['state']
    if kind.guard == 'signing':
        if target_state is None:
            _need(attest, 'RESTORE_SIGNING_FLOOR_UNKNOWN')
            return
        floor = (target_state['signing_height'], target_state['signing_round'])
        _need(floor <= (backup_state['signing_height'], backup_state['signing_round']), 'RESTORE_SIGNING_FLOOR_REGRESSION')
        _need(target_state['committed_height'] <= backup_state['committed_height'], 'RESTORE_HISTORY_REGRESSION')
    elif kind.guard in ('records', 'generation') and target_state is not None:
        field = 'generation' if kind.guard == 'generation' else 'records'
        _need(allow_rollback or target_state.get(field, 0) <= backup_state.get(field, 0), 'RESTORE_WOULD_ROLL_BACK')


def _aside(path, stamp):
    candidate = Path(str(path) + ASIDE + stamp)
    index = 1
    while os.path.lexists(candidate):
        candidate = Path(str(path) + ASIDE + stamp + f'-{index}')
        index += 1
    return candidate


def roll_forward(intent):
    """Apply each recorded rename once; already-applied steps are skipped. Idempotent after a crash."""
    for source, destination in intent['moves']:
        source, destination = Path(source), Path(destination)
        if os.path.lexists(source) and not os.path.lexists(destination):
            destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            os.rename(source, destination)
            _fsync_directory(destination.parent)
            if source.parent != destination.parent:
                _fsync_directory(source.parent)
        elif os.path.lexists(source) and os.path.lexists(destination):
            raise BackupError('RESTORE_INTENT_CONFLICT')
    for directory in intent.get('cleanup', []):
        shutil.rmtree(directory, ignore_errors=True)


def _load_intent(target):
    path = intent_path(target)
    if not path.exists():
        return None
    intent = _strict_json(path.read_bytes(), 'RESTORE_INTENT')
    _need(type(intent) is dict and intent.get('v') == INTENT_VERSION and type(intent.get('moves')) is list
          and all(type(m) is list and len(m) == 2 and all(type(p) is str for p in m) for m in intent['moves']),
          'RESTORE_INTENT')
    return intent


def recover(path):
    """Finish an interrupted restore for ``path`` from its intent file."""
    target = Path(path).expanduser().absolute()
    intent = _load_intent(target)
    _need(intent is not None, 'RESTORE_NOTHING_PENDING')
    roll_forward(intent)
    intent_path(target).unlink()
    _fsync_directory(target.parent)
    return {'recovered': str(target), 'moves': len(intent['moves'])}


def restore(archive, path, *, identity=None, service_stopped=False, allow_rollback=False,
            attest_no_later_signatures=False, genesis=None, expect_sha256=None, max_bytes=MAX_ARCHIVE,
            now=None):
    """Verify, check identity and floors, then swap the store in through a durable intent file."""
    target = Path(path).expanduser().absolute()
    _need(target.parent.is_dir() and not target.parent.is_symlink() and not target.is_symlink(), 'RESTORE_TARGET')
    _need(not intent_path(target).exists(), 'RESTORE_PENDING')
    now = _now() if now is None else now
    staging = Path(str(target) + STAGING + secrets.token_hex(6))
    staging.mkdir(mode=0o700)
    lock = None
    try:
        data = staging / 'data'
        data.mkdir(mode=0o700)
        manifest, archive_sha256 = read_archive(archive, data, expect_sha256=expect_sha256, max_bytes=max_bytes)
        kind = KINDS[manifest['kind']]
        _deep_checks(manifest, data, staging, genesis)
        lock = _try_lock(_lock_path(kind, target))
        _need(lock is not None, 'RESTORE_SERVICE_RUNNING')
        _need(lock != -1 or service_stopped or not _has_data(kind, target), 'RESTORE_STOP_UNCONFIRMED')
        target_state = None
        if _has_data(kind, target):
            target_identity, target_state = _facts(kind, _live_view(kind, target, staging))
            if kind.mode != 'merge':
                _need(target_identity == manifest['identity'], 'RESTORE_IDENTITY_MISMATCH')
        elif kind.mode != 'merge':
            _need(identity is not None, 'RESTORE_IDENTITY_UNCONFIRMED')
            _need(identity.lower() == manifest['identity_sha256'], 'RESTORE_IDENTITY_DIGEST')
        _guard(kind, manifest, target_state, allow_rollback=allow_rollback, attest=attest_no_later_signatures)
        stamp = _stamp(now)
        finals, existing = _target_paths(kind, target, manifest)
        moves, cleanup = [], [str(staging)]
        if kind.mode == 'merge':
            for item in manifest['files']:
                final = finals[item['path']]
                if os.path.lexists(final):
                    _need(_file_digest(final) == item['sha256'], 'RESTORE_CONTENT_CONFLICT')
                else:
                    moves.append([str(data / item['path']), str(final)])
            if not target.exists():
                target.mkdir(mode=0o700)
        elif kind.layout == 'tree':
            for directory in manifest['directories']:
                (data / directory['path']).mkdir(mode=int(directory['mode'], 8), parents=True, exist_ok=True)
                os.chmod(data / directory['path'], int(directory['mode'], 8))
            if target.exists():
                for name, live in _members(kind, target).items():
                    if _is_key(kind, name) and not (data / name).exists():
                        # A restore keeps the key material the archive left out.
                        (data / name).parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                        shutil.copy2(live, data / name)
                        os.chmod(data / name, stat.S_IMODE(os.lstat(live).st_mode) & 0o700)
                os.chmod(data, stat.S_IMODE(target.stat().st_mode) & 0o700)
                moves.append([str(target), str(_aside(target, stamp))])
            moves.append([str(data), str(target)])
        else:
            for live in existing:
                moves.append([str(live), str(_aside(live, stamp))])
            for item in manifest['files']:
                moves.append([str(data / item['path']), str(finals[item['path']])])
        _fsync_tree(staging)
        intent = {'v': INTENT_VERSION, 'kind': kind.name, 'target': str(target), 'archive_sha256': archive_sha256,
                  'moves': moves, 'cleanup': cleanup}
        _write_atomic(intent_path(target), canonical(intent))
        roll_forward(intent)
        intent_path(target).unlink()
        _fsync_directory(target.parent)
        return {'restored': str(target), 'kind': kind.name, 'identity_sha256': manifest['identity_sha256'],
                'state': manifest['state'], 'archive_sha256': archive_sha256,
                'previous': [destination for source, destination in moves if ASIDE in destination],
                'files': len(manifest['files'])}
    finally:
        _unlock(lock)
        if not intent_path(target).exists():
            shutil.rmtree(staging, ignore_errors=True)


# ------------------------------------------------------------------ command line
def arguments():
    """The covenant-backup command line (documented commands are parsed with it in tests)."""
    parser = argparse.ArgumentParser(prog='covenant-backup', description=__doc__.split('\n\n')[0])
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('kinds', help='list the store kinds and their layouts')
    make = sub.add_parser('backup', help='write one archive of a store')
    make.add_argument('kind', choices=sorted(KINDS))
    make.add_argument('path', help='the path the service uses for this store')
    make.add_argument('--out', required=True, help='new archive file; never overwritten')
    make.add_argument('--online', action='store_true', help='snapshot a running store (SQLite online backup)')
    make.add_argument('--include-keys', action='store_true', help='include plaintext key files; keep the archive encrypted')
    check = sub.add_parser('verify-backup', help='check every byte, checksum, database and the identity')
    check.add_argument('archive')
    check.add_argument('--expect-sha256', help='archive sha256 recorded when the backup was made')
    check.add_argument('--genesis', help='genesis JSON: also verify a node journal history against it')
    put = sub.add_parser('restore', help='restore an archive into a stopped store')
    put.add_argument('archive')
    put.add_argument('path')
    put.add_argument('--identity', help='identity digest from verify-backup (required for an empty target)')
    put.add_argument('--expect-sha256', help='archive sha256 recorded when the backup was made')
    put.add_argument('--genesis', help='genesis JSON: verify a node journal history before restoring')
    put.add_argument('--service-stopped', action='store_true', help='attest that every user of a lock-less store stopped')
    put.add_argument('--allow-rollback', action='store_true', help='restore an older append-only store over newer records')
    put.add_argument('--attest-no-later-signatures', action='store_true',
                     help='attest the signing key signed nothing after this backup (empty validator target only)')
    finish = sub.add_parser('recover', help='finish an interrupted restore')
    finish.add_argument('path')
    return parser


def main(argv=None):
    args = arguments().parse_args(argv)
    try:
        genesis = None
        if getattr(args, 'genesis', None):
            from .crypto import loads
            genesis = loads(Path(args.genesis).read_text())
        if args.command == 'kinds':
            result = kinds()
        elif args.command == 'backup':
            result = backup(args.kind, args.path, args.out, online=args.online, include_keys=args.include_keys)
        elif args.command == 'verify-backup':
            result = verify(args.archive, expect_sha256=args.expect_sha256, genesis=genesis)
        elif args.command == 'restore':
            result = restore(args.archive, args.path, identity=args.identity, service_stopped=args.service_stopped,
                             allow_rollback=args.allow_rollback, attest_no_later_signatures=args.attest_no_later_signatures,
                             genesis=genesis, expect_sha256=args.expect_sha256)
        else:
            result = recover(args.path)
    except BackupError as exc:
        from covenant_agent.errors import refusal
        print(json.dumps({'error': exc.code, **refusal(exc.code, exc.remediation), 'remediation': exc.remediation},
                         sort_keys=True))
        return 1
    except (OSError, ValueError) as exc:
        from covenant_agent.errors import refusal
        code = exc.args[0] if exc.args and type(exc.args[0]) is str and re.fullmatch(r'[A-Z][A-Z0-9_]{2,63}', exc.args[0]) else 'BACKUP_IO'
        fix = REMEDIATION.get(code, 'Check the path, permissions and free space.')
        print(json.dumps({'error': code, **refusal(code, fix), 'remediation': fix}, sort_keys=True))
        return 1
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
