"""Replicated marketplace projection over the unchanged signed forum DAG.

Catalogs validate each application record independently. Relay omission and
partitions are visible limitations; accepted orders do not reserve inventory.
"""
from copy import deepcopy
import base64,hashlib
from covenant_language import marketplace as p
from covenant_language.agentic import canonical
from .agent_network import unpack
from .crypto import need,key
from .social_views import guarded_emit
from .proof_facility import commitment
PRIVATE='covenant-marketplace-private-notice/0.1'
MANIFEST='covenant-marketplace-manifest/0.1'

def packet_id(packet):return hashlib.sha256(b'COVENANT-MARKETPLACE-PACKET-0.1\0'+canonical(packet)).hexdigest()

def announcement(packet):
    record=packet['record'];ref=p.identifier(record)
    return {'version':MANIFEST,'object':ref,'packet':packet_id(packet),'author':record['author'],'kind':record['kind'],'title':record['title'],'market':record['data'].get('market'),'frame':p._frame(record['author'],record['title'],{'object':ref,'market':record['data'].get('market'),'mechanism':'EXPLICIT_CONTENT_ADDRESSED_PACKET_DELIVERY'})}


def private_notice(record,salt,context,delivery,market=None):
    p.validate(record);key(context);p.q.reference(delivery)
    if market is not None:key(market)
    if market is not None and 'market' in record['data']:need(market==record['data']['market'],'MARKETPLACE_PRIVATE_MARKET_MISMATCH')
    value=commitment(base64.b64encode(canonical(record)).decode(),salt,context)
    values={'who':record['author'],'which':value,'how':{'ciphertext_delivery':delivery,'decryption':'SEPARATELY_ADOPTED_PRIVACY_CONNECTOR'}}
    slots=[p.q.slot(k,k,k+'?',status='ASSERTED',answers=[p.q.answer(values[k])]) if k in values else p.q.slot(k,k,k+'?',status='UNKNOWN') if k=='when' else p.q.slot(k,k,k+'?',status='WITHHELD',reason='Private record; disclose only by adopted scope.') for k in p.q.CORE]
    notice={'version':PRIVATE,'author':record['author'],'context':context,'market':market,'commitment':value,'delivery':deepcopy(delivery),'frame':p.q.draft('Private market record',slots)['frame']}
    validate_notice(notice)
    return {'notice':notice,'plaintext_publication':False,'salt_publication':False,'metadata':'AUTHOR_CONTEXT_OPTIONAL_MARKET_DELIVERY_REFERENCE_AND_FRAME_ARE_PUBLIC','execution_authorized':False}

def validate_notice(v):
    p.fields(v,'version author context market commitment delivery frame');need(v['version']==PRIVATE,'MARKETPLACE_PRIVATE_VERSION')
    for k in ('author','context','commitment'):key(v[k])
    if v['market'] is not None:key(v['market'])
    p.q.reference(v['delivery']);p.q.validate(v['frame']);need(not p.q.inspect(v['frame'])['missing_dimensions'],'MARKETPLACE_SEVEN_DIMENSIONS')
    # Private notices have a fixed safe frame; no caller-provided descriptions
    # or answers beyond their explicitly public routing fields may hitchhike.
    expected=private_notice_frame(v)
    need(canonical(v['frame'])==canonical(expected),'MARKETPLACE_PRIVATE_FRAME')
    return True

def private_notice_frame(v):
    values={'who':v['author'],'which':v['commitment'],'how':{'ciphertext_delivery':v['delivery'],'decryption':'SEPARATELY_ADOPTED_PRIVACY_CONNECTOR'}}
    return p.q.draft('Private market record',[p.q.slot(k,k,k+'?',status='ASSERTED',answers=[p.q.answer(values[k])]) if k in values else p.q.slot(k,k,k+'?') if k=='when' else p.q.slot(k,k,k+'?',status='WITHHELD',reason='Private record; disclose only by adopted scope.') for k in p.q.CORE])['frame']

def verify_private(record,salt,notice):
    p.validate(record);validate_notice(notice);need(record['author']==notice['author'],'MARKETPLACE_PRIVATE_AUTHOR')
    need(commitment(base64.b64encode(canonical(record)).decode(),salt,notice['context'])==notice['commitment'],'MARKETPLACE_PRIVATE_OPENING')
    if notice['market'] is not None and 'market' in record['data']:need(notice['market']==record['data']['market'],'MARKETPLACE_PRIVATE_MARKET_MISMATCH')
    return {'id':p.identifier(record),'commitment_verified':True,'decryption_or_delivery_verified':False,'execution_authorized':False}

def _private_route(notice,records):
    if notice['market'] is None:return
    market=records.get(notice['market']);need(market is not None and market['kind']=='MARKET','MARKETPLACE_MARKET_MISSING')
    need(market['data']['policy']['admission']=='OPEN' or notice['author'] in {market['author'],*market['data']['members']},'MARKETPLACE_MEMBER_NOT_ADMITTED')

def _allowed(record,records):
    d=record['data']
    if record['supersedes'] is not None:
        old=records.get(record['supersedes']);need(old is not None and old['kind']==record['kind'] and old['author']==record['author'],'MARKETPLACE_PREDECESSOR')
        if record['kind']=='LISTING':need(old['data']['market']==d['market'],'MARKETPLACE_MARKET_CHANGED')
    if record['kind'] in ('LISTING','ORDER'):
        market=records.get(d['market']);need(market is not None and market['kind']=='MARKET','MARKETPLACE_MARKET_MISSING')
        if record['kind']=='LISTING':
            need(d['mechanism'] in market['data']['mechanisms'],'MARKETPLACE_MECHANISM_NOT_ADOPTED')
            need(market['data']['policy']['admission']=='OPEN' or record['author'] in {market['author'],*market['data']['members']},'MARKETPLACE_MEMBER_NOT_ADMITTED')
            if d['archetype'] is not None:need(d['archetype'] in records and records[d['archetype']]['kind']=='ARCHETYPE','MARKETPLACE_ARCHETYPE_MISSING')
        else:
            listing=records.get(d['listing']);need(listing is not None and listing['kind']=='LISTING','MARKETPLACE_LISTING_MISSING')
            ld=listing['data']
            need(d['market']==ld['market'] and d['seller']==listing['author'] and d['archetype']==ld['archetype'] and d['units']<=ld['quantity'] and canonical(d['terms'].get('listing_terms'))==canonical(ld['custom']),'MARKETPLACE_ORDER_LISTING_MISMATCH')
            # Price/asset/settlement counteroffers are permitted only because
            # every accepted order already verified both exact party assents.
            # They never inherit acceptance of an earlier listed price.

def catalog(network,group=None,market=None,query='',limit=100,objects=None):
    need(type(query) is str and len(query)<=256 and type(limit) is int and 1<=limit<=256,'MARKETPLACE_SEARCH')
    if group is not None:key(group)
    if market is not None:key(market)
    objects=[] if objects is None else objects
    need(type(objects) is list and len(objects)<=128,'MARKETPLACE_OBJECT_PACKETS')
    supplied={}
    for packet in objects:
        p.fields(packet,'version record approvals');need(packet['version']==p.VERSION,'MARKETPLACE_PACKET_VERSION');p.validate(packet['record']);supplied[packet_id(packet)]=packet
    events=network.events();pending=[];rejected=0;notices=[];announcements=[]
    for eid,e in sorted(events.items()):
        b=e['body']
        if b['kind']!='POST' or group is not None and b['group']!=group:continue
        obj=unpack(b)['content']
        if type(obj) is not dict:continue
        if obj.get('version')==PRIVATE:
            try:validate_notice(obj);need(obj['author']==b['actor'],'MARKETPLACE_AUTHOR')
            except (ValueError,TypeError,KeyError):rejected+=1;continue
            notices.append({'event':eid,'group':b['group'],'notice':obj});continue
        if obj.get('version')==MANIFEST:
            try:
                p.fields(obj,'version object packet author kind title market frame');key(obj['object']);key(obj['packet']);need(obj['author']==b['actor'],'MARKETPLACE_AUTHOR');p.text(obj['title'],256);need(obj['kind'] in p.KINDS,'MARKETPLACE_KIND');p.q.validate(obj['frame'])
                if obj['market'] is not None:key(obj['market'])
                if obj['packet'] not in supplied:
                    announcements.append({'event':eid,'group':b['group'],'announcement':deepcopy(obj),'status':'AWAITING_EXPLICIT_OBJECT_DELIVERY'});continue
                packet=supplied[obj['packet']];need(canonical(announcement(packet))==canonical(obj),'MARKETPLACE_MANIFEST_MISMATCH');obj=packet
            except (ValueError,TypeError,KeyError):rejected+=1;continue
        if obj.get('version')!=p.VERSION:continue
        try:
            p.fields(obj,'version record approvals');p.validate(obj['record']);need(obj['record']['author']==b['actor'],'MARKETPLACE_AUTHOR')
            if obj['record']['kind']=='ORDER':p.verify_order(obj['record'],obj['approvals'],p.identifier(obj['record']))
            else:need(obj['approvals']==[],'MARKETPLACE_NON_ORDER_APPROVALS')
            pending.append((eid,b['group'],obj['record']))
        except (ValueError,TypeError,KeyError):rejected+=1
    # Dependencies must have authenticated publication in this same group.
    scoped={};published={};progress=True
    while pending and progress:
        progress=False;rest=[]
        for eid,g,record in pending:
            local=scoped.setdefault(g,{})
            try:
                _allowed(record,local)
                ancestors=network._ancestors(events[eid]['body']['parents'],events)
                dependencies=[record['supersedes']] if record['supersedes'] is not None else []
                if record['kind'] in ('LISTING','ORDER'):dependencies.append(record['data']['market'])
                if record['kind']=='LISTING' and record['data']['archetype'] is not None:dependencies.append(record['data']['archetype'])
                if record['kind']=='ORDER':dependencies.append(record['data']['listing'])
                need(all(any(e in ancestors for e in published.get((g,dep),[])) for dep in dependencies),'MARKETPLACE_CAUSAL_DEPENDENCY')
            except (ValueError,TypeError,KeyError):rest.append((eid,g,record));continue
            ref=p.identifier(record);local[ref]=record;published.setdefault((g,ref),[]).append(eid);progress=True
        pending=rest
    admitted_notices=[]
    for notice in notices:
        try:
            _private_route(notice['notice'],scoped.get(notice['group'],{}))
            route=notice['notice']['market']
            if route is not None:
                ancestors=network._ancestors(events[notice['event']]['body']['parents'],events)
                need(any(e in ancestors for e in published.get((notice['group'],route),[])),'MARKETPLACE_CAUSAL_DEPENDENCY')
            admitted_notices.append(notice)
        except (ValueError,TypeError,KeyError):rejected+=1
    notices=admitted_notices
    rows=[];superseded={(g,r['supersedes']) for g,records in scoped.items() for r in records.values() if r['supersedes'] is not None}
    successors={}
    for g,records in scoped.items():
        for ref,r in records.items():
            if r['supersedes'] is not None:successors.setdefault((g,r['supersedes']),set()).add(ref)
        selected={ref for ref,r in records.items() if market is None or ref==market or r['data'].get('market')==market}
        selected.update(records[ref]['data']['archetype'] for ref in list(selected) if records[ref]['kind'] in ('LISTING','ORDER') and records[ref]['data']['archetype'] is not None)
        for ref,r in records.items():
            if ref not in selected:continue
            if query.casefold() not in (r['title']+' '+str(r['data'])).casefold():continue
            ancestor=r['supersedes'];forked=False;seen=set()
            while ancestor is not None and ancestor not in seen:
                seen.add(ancestor);forked=forked or len(successors.get((g,ancestor),set()))>1
                ancestor=records[ancestor]['supersedes']
            status='SUPERSEDED_LOCALLY' if (g,ref) in superseded else 'CONCURRENT_REVISIONS' if forked else 'WITHDRAWN_DECLARATION' if r['kind']=='LISTING' and not r['data']['active'] else 'CURRENT_DECLARATION'
            rows.append({'id':ref,'target':p.inspect(r)['target'],'group':g,'record':r,'events':sorted(published[g,ref]),'status':status})
    orders=[r for records in scoped.values() for r in records.values() if r['kind']=='ORDER' and (market is None or r['data']['market']==market)]
    usage=[]
    for aid in sorted({o['data']['archetype'] for o in orders if o['data']['archetype'] is not None}):
        using={p.identifier(o):o for o in orders if o['data']['archetype']==aid};pairs={(o['data']['buyer'],o['data']['seller']) for o in using.values()}
        usage.append({'archetype':aid,'distinct_accepted_order_ids':len(using),'distinct_counterparty_pairs':len(pairs),'basis':'EXACT_SIGNED_ORDER_ACCEPTANCE_NOT_PAYMENT_OR_INDEPENDENT_ADOPTION'})
    return {'records':sorted(rows,key=lambda r:(r['record']['kind'],r['record']['title'],r['id']))[:limit],'total_matching':len(rows),'truncated':len(rows)>limit,'announcements':[a for a in announcements if market is None or a['announcement']['market']==market or a['announcement']['object']==market],'private_notices':[n for n in notices if market is None or n['notice']['market']==market],'rejected_application_records':rejected,'unresolved_application_records':len(pending),'archetype_usage':usage,
        'freshness':'LOCAL_SIGNED_REPLICA_NOT_GLOBAL_CONSENSUS','inventory':'DECLARED_QUANTITIES_NOT_EXCLUSIVE_RESERVATIONS','operator_scope':'EXPLICITLY_ADMITTED_FORUM_PEERS','execution_authorized':False}

def publish(network,request,group,record,disclosure,approvals=None,expected_heads=None,reference_only=False,objects=None):
    need(disclosure=='PUBLIC_PLAINTEXT','MARKETPLACE_EXPLICIT_PUBLIC_DISCLOSURE');p.validate(record);need(record['author']==network.actor,'MARKETPLACE_AUTHOR')
    need(type(reference_only) is bool,'MARKETPLACE_REFERENCE_ONLY')
    existing=catalog(network,group=group,limit=256,objects=objects);records={r['id']:r['record'] for r in existing['records']}
    need(not existing['truncated'],'MARKETPLACE_CATALOG_REQUIRES_NARROWER_HOST');_allowed(record,records)
    approvals=[] if approvals is None else approvals
    if record['kind']=='ORDER':p.verify_order(record,approvals,p.identifier(record))
    else:need(approvals==[],'MARKETPLACE_NON_ORDER_APPROVALS')
    content={'version':p.VERSION,'record':deepcopy(record),'approvals':deepcopy(approvals)}
    full_post={'thread':None,'title':record['title'],'content':content,'tags':['covenant-marketplace',record['kind'].lower()]}
    detached=reference_only or len(canonical(full_post))>8192
    published=announcement(content) if detached else content
    result=guarded_emit(network,expected_heads=expected_heads,kind='POST',request=request,group=group,content={'thread':None,'title':record['title'],'content':published,'tags':['covenant-marketplace',record['kind'].lower()]})
    return {**result,'object':p.identifier(record),'publication':'SIGNED_MANIFEST_REQUIRES_EXPLICIT_PACKET_DELIVERY' if detached else 'PUBLIC_PLAINTEXT_TO_ADMITTED_REPLICAS','packet':content if detached else None,'packet_id':packet_id(content),'settlement':'NOT_EXECUTED'}

def publish_private(network,request,group,notice,acknowledge_public_metadata,expected_heads=None,objects=None):
    need(acknowledge_public_metadata is True,'MARKETPLACE_METADATA_ASSENT');validate_notice(notice);need(notice['author']==network.actor,'MARKETPLACE_AUTHOR')
    view=catalog(network,group=group,limit=256,objects=objects);need(not view['truncated'],'MARKETPLACE_CATALOG_REQUIRES_NARROWER_HOST');_private_route(notice,{r['id']:r['record'] for r in view['records']})
    result=guarded_emit(network,expected_heads=expected_heads,kind='POST',request=request,group=group,content={'thread':None,'title':'Private market record','content':deepcopy(notice),'tags':['covenant-marketplace-private']})
    return {**result,'plaintext_published':False,'public_metadata':['author','context','optional_market','commitment','delivery_reference','frame','forum_envelope'],'encryption':'REQUIRES_SEPARATE_ADOPTED_PRIVACY_DELIVERY'}

def rank(network,seeds,group=None,market=None,include_usage=False,objects=None):
    from .voting import rank_objects,target_id
    need(type(include_usage) is bool,'MARKETPLACE_RANK_USAGE')
    view=catalog(network,group=group,market=market,limit=256,objects=objects);need(not view['truncated'],'MARKETPLACE_RANK_SCOPE_TOO_WIDE')
    rows=[r for r in view['records'] if r['status']=='CURRENT_DECLARATION' and (include_usage or r['record']['kind']!='ORDER')]
    nodes={target_id(r['target']):r['target'] for r in rows};by_id={r['id']:r['target'] for r in rows};edges=[]
    for row in rows:
        record=row['record'];d=record['data'];src=row['target']
        if record['kind']=='LISTING':
            if d['market'] in by_id:edges.append({'from':by_id[d['market']],'to':src})
            if d['archetype'] in by_id:edges.append({'from':src,'to':by_id[d['archetype']]})
        if record['kind']=='ARCHETYPE':
            for link in d['links']:
                if target_id(link) in nodes:edges.append({'from':src,'to':link})
        if record['kind']=='ORDER' and include_usage:
            for k in ('listing','archetype'):
                if d[k] in by_id:edges.append({'from':src,'to':by_id[d[k]]})
    result=rank_objects(list(nodes.values()),edges,seeds)
    return {**result,'graph':'SELECTED_IMMUTABLE_MARKET_LISTING_ARCHETYPE_RELATIONS','include_usage':include_usage,'usage_evidence':'ACCEPTED_ORDERS_NOT_PAYMENTS_OR_INDEPENDENT_ADOPTION','promotions_and_votes':'SEPARATE_CONTEXTUAL_SIGNALS_NOT_AUTOMATIC_TRUST','freshness':'LOCAL_SIGNED_REPLICA'}
