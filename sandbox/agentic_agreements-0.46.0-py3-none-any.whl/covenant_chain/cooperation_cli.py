"""Bounded local assessment/diff tools; never signs, sends, or executes a job."""
import argparse
import json
from pathlib import Path
import sys

from .cooperation import CooperationPolicy, assess_bundle, proposal_changes


def _read(path):
    with Path(path).open('rb') as stream:
        raw = stream.read(16_000_001)
    if len(raw) > 16_000_000:
        raise ValueError('CLI_INPUT_SIZE')
    def pairs(items):
        result = {}
        for k, v in items:
            if k in result:
                raise ValueError('CLI_DUPLICATE_KEY')
            result[k] = v
        return result
    def bad(_):
        raise ValueError('CLI_NONINTEGER')
    return json.loads(raw, object_pairs_hook=pairs, parse_float=bad, parse_constant=bad)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    assess = commands.add_parser('assess', help='Verify raw history and exact agreement against independent local policy.')
    assess.add_argument('bundle')
    assess.add_argument('--trust', required=True, help='Independently acquired genesis, chain, job, height floor and acceptance policy.')
    assess.add_argument('--stage', choices=('WORK','EXECUTE'), default='WORK')
    compare = commands.add_parser('compare', help='Show exact proposal changes; never infers assent.')
    compare.add_argument('before')
    compare.add_argument('after')
    args = parser.parse_args(argv)
    try:
        if args.command == 'compare':
            result = proposal_changes(_read(args.before), _read(args.after))
            code = 0
        else:
            trust = _read(args.trust)
            if type(trust) is not dict or set(trust) != {'genesis','chain','job','minimum_height','policy'}:
                raise ValueError('CLI_TRUST_FIELDS')
            policy = trust['policy']
            if type(policy) is not dict:
                raise ValueError('CLI_POLICY')
            for name in ('capabilities','effect_profiles'):
                if name in policy:
                    if type(policy[name]) is not list:
                        raise ValueError('CLI_POLICY')
                    policy[name] = tuple(policy[name])
            result = assess_bundle(_read(args.bundle), trust['genesis'], trust['chain'], trust['job'],
                                   CooperationPolicy(**policy), minimum_height=trust['minimum_height'], stage=args.stage)
            code = 0 if result['ready_for_stage'] else 2
        print(json.dumps(result, ensure_ascii=True, sort_keys=True, indent=2))
        return code
    except (ValueError, TypeError, KeyError, OSError, RecursionError) as exc:
        print(json.dumps(dict(status='INVALID_INPUT_OR_PROOF', reason=str(exc)[:256],
                              automatic_assent=False, execution_authorized=False)), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
