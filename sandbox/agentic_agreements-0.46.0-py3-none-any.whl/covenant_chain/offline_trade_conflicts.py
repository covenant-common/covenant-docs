"""Conflicting spends and cloned device state, found when disconnected peers meet.

Two recipients who were offline can each hold a valid note for the same spend
slot. Nothing offline prevents that; it is found on reconnection and then made
right. A note backed by an offline_value escrow is slashed through that rule
set's own SCALE_OFFLINE_EQUIVOCATE: the losing payee is paid from what remains
and the rest is burned. Any other conflict becomes a signed dispute record for
the trade's agreed procedure; no remedy is applied automatically.

A device signs a head statement for each trade it issues: a monotonic sequence
and a hash-chained head. Two statements with the same sequence and different
heads prove its state was copied (or its key used twice). Peers retain the
newest statements, which is how a device that lost its newest checkpoint
learns how far it had gone.
"""
from copy import deepcopy

from . import crypto as c, offline_trade as trade, offline_value
from .offline_trade_backing import check_instruction
from .offline_trade_freshness import TradeError, need

HEAD_VERSION = 'covenant-offline-trade-head/0.1'
HEAD_LABEL = 'COVENANT-OFFLINE-TRADE-HEAD-0.1'
CHAIN_LABEL = 'COVENANT-OFFLINE-TRADE-HEAD-CHAIN-0.1'
DISPUTE_VERSION = 'covenant-offline-trade-dispute/0.1'
DISPUTE_LABEL = 'COVENANT-OFFLINE-TRADE-DISPUTE-0.1'
DISPUTE_KINDS = ('CONFLICTING_SPEND', 'CLONED_STATE')


# Device heads ---------------------------------------------------------------

def next_head(device, sequence, previous, trade_id):
    return c.digest(CHAIN_LABEL, {'device': device, 'sequence': sequence, 'previous': previous, 'trade': trade_id})


def head_statement(device_key, *, sequence, previous, trade_id, at):
    """The device's signed position after issuing one trade."""
    device = c.public_key(device_key)
    body = {'version': HEAD_VERSION, 'device': device, 'sequence': sequence, 'previous': previous,
            'trade': trade_id, 'head': None, 'at': at}
    try:
        c.integer(sequence, True); c.key(previous); c.key(trade_id); c.integer(at)
    except ValueError:
        raise TradeError('TRADE_HEAD') from None
    body['head'] = next_head(device, sequence, previous, trade_id)
    return {'body': body, 'signature': c.sign(device_key, HEAD_LABEL, body)}


def check_head(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'TRADE_HEAD')
    body = record['body']
    need(type(body) is dict and set(body) == {'version', 'device', 'sequence', 'previous', 'trade', 'head', 'at'} and
         body['version'] == HEAD_VERSION, 'TRADE_HEAD')
    try:
        c.verification_key(body['device']); c.integer(body['sequence'], True); c.integer(body['at'])
        for name in ('previous', 'trade', 'head'):
            c.key(body[name])
        c.verify(body['device'], HEAD_LABEL, body, record['signature'])
    except ValueError:
        raise TradeError('TRADE_HEAD') from None
    need(body['head'] == next_head(body['device'], body['sequence'], body['previous'], body['trade']), 'TRADE_HEAD')
    return deepcopy(body)


def compare_heads(first, second):
    """SAME, CONTINUES (second extends first by one), GAP, OLDER, CLONED or UNRELATED."""
    a, b = check_head(first), check_head(second)
    if a['device'] != b['device']:
        return 'UNRELATED'
    if a['sequence'] == b['sequence']:
        return 'SAME' if a['head'] == b['head'] else 'CLONED'
    if b['sequence'] < a['sequence']:
        return 'OLDER'
    if b['sequence'] == a['sequence'] + 1:
        return 'CONTINUES' if b['previous'] == a['head'] else 'CLONED'
    return 'GAP'


# Conflicting spends -----------------------------------------------------------

def classify(first, second):
    """SAME_TRADE, CONFLICTING_SPEND (one slot, two trades) or INDEPENDENT."""
    a, b = trade.terms_id(first), trade.terms_id(second)
    slot_a, slot_b = trade.slot_id(first), trade.slot_id(second)
    if a == b:
        return {'relation': 'SAME_TRADE', 'slot': slot_a}
    if slot_a is not None and slot_a == slot_b:
        return {'relation': 'CONFLICTING_SPEND', 'slot': slot_a}
    return {'relation': 'INDEPENDENT', 'slot': None}


def _statement(instruction, device):
    # offline_value.conflicts compares device and serial; the serial names the book too.
    return {'device': device, 'serial': '%s:%d' % (instruction['book'], instruction['counter']),
            'payee': instruction['payee'], 'amount': instruction['amount'], 'chain': instruction['chain']}


def slash_request(loser, *, winner):
    """The losing note's own device signature, ready for SCALE_OFFLINE_EQUIVOCATE.

    The ledger pays the losing payee from the escrow that remains and burns
    the rest; it refuses unless the winning spend is already certified.
    """
    need(classify(winner, loser)['relation'] == 'CONFLICTING_SPEND', 'TRADE_NOT_CONFLICTING')
    mine, theirs = check_instruction(loser), check_instruction(winner)
    device = loser['terms']['parties']['buyer']
    need(winner['terms']['parties']['buyer'] == device and
         offline_value.conflicts(_statement(theirs, device), _statement(mine, device)), 'TRADE_NOT_CONFLICTING')
    return {'action': 'SLASH', 'rule': 'offline_value', 'op': 'SCALE_OFFLINE_EQUIVOCATE',
            'trade': trade.terms_id(loser), 'slot': trade.slot_id(loser), 'instruction': mine,
            'assurance': 'LEDGER_DECIDES_WHICH_SPEND_WAS_CERTIFIED_FIRST'}


def dispute(raiser_key, *, kind, first, second, reason, at):
    """A signed record that opens the trade's agreed procedure; it applies no remedy itself."""
    need(type(kind) is str and kind in DISPUTE_KINDS, 'TRADE_DISPUTE')
    need(type(reason) is str and 0 < len(reason) <= 512 and reason.isascii() and reason.isprintable(), 'TRADE_DISPUTE')
    if kind == 'CONFLICTING_SPEND':
        relation = classify(first, second)
        need(relation['relation'] == 'CONFLICTING_SPEND', 'TRADE_NOT_CONFLICTING')
        evidence = sorted([trade.terms_id(first), trade.terms_id(second)])
        device, slot = first['terms']['parties']['buyer'], relation['slot']
        procedure, reviewer = first['terms']['dispute'], first['terms']['parties']['reviewer']
    else:
        need(compare_heads(first, second) == 'CLONED', 'TRADE_NOT_CONFLICTING')
        evidence = sorted([c.digest(HEAD_LABEL, first['body']), c.digest(HEAD_LABEL, second['body'])])
        device, slot, procedure, reviewer = first['body']['device'], None, 'Revoke the copied device key and ' \
            'reconcile every note it signed after the shared head.', None
    try:
        c.integer(at)
    except ValueError:
        raise TradeError('TRADE_DISPUTE') from None
    body = {'version': DISPUTE_VERSION, 'kind': kind, 'slot': slot, 'device': device, 'evidence': evidence,
            'procedure': procedure, 'reviewer': reviewer, 'raised_by': c.public_key(raiser_key), 'reason': reason,
            'at': at}
    return {'body': body, 'signature': c.sign(raiser_key, DISPUTE_LABEL, body)}


def check_dispute(record):
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'TRADE_DISPUTE')
    body = record['body']
    need(type(body) is dict and set(body) == {'version', 'kind', 'slot', 'device', 'evidence', 'procedure',
         'reviewer', 'raised_by', 'reason', 'at'} and body['version'] == DISPUTE_VERSION and
         body['kind'] in DISPUTE_KINDS and type(body['evidence']) is list and len(body['evidence']) == 2, 'TRADE_DISPUTE')
    try:
        c.verify(body['raised_by'], DISPUTE_LABEL, body, record['signature'])
    except ValueError:
        raise TradeError('TRADE_DISPUTE') from None
    return deepcopy(body)


def describe():
    return {'head': HEAD_VERSION, 'dispute': DISPUTE_VERSION, 'kinds': list(DISPUTE_KINDS),
            'bond_backed_conflicts': 'SCALE_OFFLINE_EQUIVOCATE through the offline_value rule set',
            'other_conflicts': 'SIGNED_DISPUTE_RECORD_FOR_THE_AGREED_PROCEDURE', 'prevention': 'NONE_OFFLINE',
            'copied_credentials': 'BOUNDED_AND_ATTRIBUTED_NOT_PREVENTED', 'execution_authorized': False}
