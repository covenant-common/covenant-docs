"""Native 0.7 staged burn-and-import capacity handoff.

Not universal atomicity. Source retirement is irreversible: loss of destination
progress can strand capacity. Destination explicitly adopts source committees.
No bank backing, legal recognition, price or physical fungibility is established.
"""
from covenant_chain.crypto import genesis_id
from .profile import MIGRATION_VERSION
from copy import deepcopy
from .balances import add, amount
from .crypto import canonical,digest,exact,need,key,integer
from .profile import (
    CONFIDENTIAL_VERSION, CONTINUITY_VERSION, ECONOMIC_VERSION, EXTENSIBLE_VERSION,
    FEDERATION_VERSION, MARKET_VERSION, PREDICTION_VERSION, REVIEW_VERSION, SCALE_VERSION,
)
from .state import Table
TABLES=('bridge_sources','bridge_exports','bridge_imports','bridge_retired')

def initialize(s,g,validate_source):
    sources=g['sources'];need(type(sources) is dict and len(sources)<=8,'BRIDGE_SOURCE_LIMIT')
    for chain,policy in sources.items():
        key(chain);exact(policy,'genesis resource_map'+(' lineage_resources' if 'lineage_resources' in policy else ''))
        lineage=policy.get('lineage_resources',False);need(type(lineage) is bool,'BRIDGE_LINEAGE_POLICY')
        source=policy['genesis'];canonical(source)
        adoptable=({FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION} if g['protocol'] in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION} else {FEDERATION_VERSION,EXTENSIBLE_VERSION} if g['protocol']==EXTENSIBLE_VERSION else {FEDERATION_VERSION})
        if g['protocol']==CONTINUITY_VERSION:adoptable={FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION}
        if g['protocol']==REVIEW_VERSION:adoptable={FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION}
        if g['protocol']==PREDICTION_VERSION:adoptable={FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION}
        if g['protocol'] in {SCALE_VERSION,MIGRATION_VERSION}:adoptable={FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,SCALE_VERSION}
        if g['protocol']==MIGRATION_VERSION:adoptable={FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,SCALE_VERSION,MIGRATION_VERSION}
        if g['protocol']==MARKET_VERSION:adoptable={FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION}
        need(source['protocol'] in adoptable and genesis_id(source)==chain,'BRIDGE_SOURCE_PIN')
        validate_source(source)
        mapping=policy['resource_map'];need(type(mapping) is dict and (0 if lineage else 1)<=len(mapping)<=64,'BRIDGE_RESOURCE_MAP')
        for remote,local in mapping.items():
            need(remote in source['resources'] and local in g['resources'],'BRIDGE_RESOURCE_MAP')
            need(source['resources'][remote]['unit']==g['resources'][local]['unit'],'BRIDGE_UNIT')
    for table in TABLES:s[table]=Table()
    s['bridge_sources']=Table(deepcopy(sources))
    if g['protocol'] in {SCALE_VERSION,MIGRATION_VERSION}:
        s['bridge_locked']=Table();s['bridge_acceptances']=Table()

def _ticket_exact(ticket):
    fields='source export exporter resource quantity destination recipient state'
    if type(ticket) is dict and 'refund_after' in ticket:fields+=' refund_after'
    if type(ticket) is dict and ('burned_at' in ticket or 'burn_event' in ticket):fields+=' burned_at burn_event'
    if type(ticket) is dict and ('reclaimed_at' in ticket or 'reclaim_event' in ticket):fields+=' reclaimed_at reclaim_event'
    exact(ticket,fields)

def _move(pool,rid,delta):
    updated=pool.get(rid,0)+delta;integer(updated,False);pool[rid]=updated

def apply(s,previous,op,p,actor,tid,height,verify_bundle):
    locked_profile=s.get('protocol') in {SCALE_VERSION,MIGRATION_VERSION}
    if op=='BRIDGE_EXPORT':
        if locked_profile:
            exact(p,'resource quantity destination recipient refund_after');integer(p['refund_after'])
            need(height<p['refund_after']<=height+100000,'BRIDGE_REFUND_WINDOW')
        else:exact(p,'resource quantity destination recipient')
        rid=p['resource'];integer(p['quantity'],True);key(p['destination']);key(p['recipient'])
        need(type(rid) is str and rid in s['resources'] and p['destination']!=s['chain'],'BRIDGE_DESTINATION_RESOURCE')
        qty=p['quantity']
        need(amount(s['balances'],actor,rid)>=qty and amount(s['authority_available'],actor,rid)>=qty,'BRIDGE_AVAILABLE')
        add(s['balances'],actor,rid,-qty);add(s['authority_available'],actor,rid,-qty)
        if locked_profile:_move(s['bridge_locked'],rid,qty)
        else:_move(s['bridge_retired'],rid,qty)
        ticket={'source':s['chain'],'export':tid,'exporter':actor,'resource':rid,'quantity':qty,
                'destination':p['destination'],'recipient':p['recipient'],
                'state':'LOCKED_FOR_IMPORT' if locked_profile else 'RETIRED_FOR_DESTINATION'}
        if locked_profile:ticket['refund_after']=p['refund_after']
        s['bridge_exports'][tid]=ticket
        return []
    if op=='BRIDGE_ACCEPT':
        if not locked_profile:return None
        exact(p,'source export proof');key(p['source']);key(p['export'])
        need(p['source'] in s['bridge_sources'],'BRIDGE_UNADOPTED_SOURCE')
        iid=digest('COVENANT-BRIDGE-IMPORT-0.7',{'source':p['source'],'export':p['export']})
        need(iid not in s['bridge_acceptances'] and iid not in s['bridge_imports'],'BRIDGE_ALREADY_ACCEPTED')
        policy=s['bridge_sources'][p['source']]
        report=verify_bundle(policy['genesis'],p['proof'],p['source'],1,'bridge_exports',p['export'])
        ticket=report['value'];_ticket_exact(ticket)
        need(ticket['state']=='LOCKED_FOR_IMPORT' and 'refund_after' in ticket,'BRIDGE_TICKET_CONTEXT')
        need(ticket['source']==p['source'] and ticket['export']==p['export'] and ticket['destination']==s['chain'],'BRIDGE_TICKET_CONTEXT')
        key(ticket['recipient']);key(ticket['exporter']);integer(ticket['quantity'],True);integer(ticket['refund_after'])
        s['bridge_acceptances'][iid]={'source':p['source'],'export':p['export'],'state':'ACCEPTED_LOCKED',
            'resource':ticket['resource'],'quantity':ticket['quantity'],'recipient':ticket['recipient'],
            'exporter':ticket['exporter'],'refund_after':ticket['refund_after'],'event':tid,
            'source_height':report['height'],'source_head':report['head'],'source_epoch':report['epoch']}
        return []
    if op=='BRIDGE_BURN':
        if not locked_profile:return None
        exact(p,'export destination_genesis proof');key(p['export'])
        need(p['export'] in s['bridge_exports'],'BRIDGE_EXPORT_MISSING')
        ticket=s['bridge_exports'][p['export']]
        need(ticket['state']=='LOCKED_FOR_IMPORT','BRIDGE_BURN_STATE')
        need(height<=ticket['refund_after'],'BRIDGE_BURN_CLOSED')
        genesis=p['destination_genesis'];need(type(genesis) is dict,'BRIDGE_BURN_DESTINATION');canonical(genesis)
        need(genesis_id(genesis)==ticket['destination'],'BRIDGE_BURN_DESTINATION')
        iid=digest('COVENANT-BRIDGE-IMPORT-0.7',{'source':s['chain'],'export':p['export']})
        report=verify_bundle(genesis,p['proof'],ticket['destination'],1,'bridge_acceptances',iid)
        acc=report['value'];exact(acc,'source export state resource quantity recipient exporter refund_after event source_height source_head source_epoch')
        need(acc['state']=='ACCEPTED_LOCKED' and acc['source']==s['chain'] and acc['export']==p['export'],'BRIDGE_BURN_PROOF')
        need(acc['resource']==ticket['resource'] and acc['quantity']==ticket['quantity'],'BRIDGE_BURN_PROOF')
        need(acc['recipient']==ticket['recipient'] and acc['exporter']==ticket['exporter'],'BRIDGE_BURN_PROOF')
        need(acc['refund_after']==ticket['refund_after'],'BRIDGE_BURN_PROOF')
        rid=ticket['resource'];qty=ticket['quantity']
        _move(s['bridge_locked'],rid,-qty);_move(s['bridge_retired'],rid,qty)
        ticket['state']='BURNED_ON_IMPORT';ticket['burned_at']=height;ticket['burn_event']=tid
        return []
    if op=='BRIDGE_RECLAIM':
        if not locked_profile:return None
        exact(p,'export');key(p['export']);need(p['export'] in s['bridge_exports'],'BRIDGE_EXPORT_MISSING')
        ticket=s['bridge_exports'][p['export']]
        need(actor==ticket['exporter'],'BRIDGE_RECLAIM_AUTHORITY')
        need(ticket['state']=='LOCKED_FOR_IMPORT','BRIDGE_RECLAIM_STATE')
        need(height>ticket['refund_after'],'BRIDGE_RECLAIM_CLOSED')
        rid=ticket['resource'];qty=ticket['quantity']
        add(s['balances'],actor,rid,qty);add(s['authority_available'],actor,rid,qty)
        _move(s['bridge_locked'],rid,-qty)
        ticket['state']='RECLAIMED';ticket['reclaimed_at']=height;ticket['reclaim_event']=tid
        return []
    if op=='BRIDGE_IMPORT':
        exact(p,'source export proof'+(' resource_proof' if 'resource_proof' in p else ''));key(p['source']);key(p['export'])
        need(p['source'] in s['bridge_sources'],'BRIDGE_UNADOPTED_SOURCE')
        iid=digest('COVENANT-BRIDGE-IMPORT-0.7',{'source':p['source'],'export':p['export']})
        need(iid not in s['bridge_imports'],'BRIDGE_ALREADY_IMPORTED')
        policy=s['bridge_sources'][p['source']]
        # Every native node independently verifies this scoped certificate. No
        # source RPC call, shared network clock, or source history replay required.
        report=verify_bundle(policy['genesis'],p['proof'],p['source'],1,'bridge_exports',p['export'])
        ticket=report['value']
        if locked_profile and type(ticket) is dict and 'refund_after' in ticket:
            _ticket_exact(ticket)
            need(ticket['state']=='BURNED_ON_IMPORT','BRIDGE_TICKET_CONTEXT')
        else:
            exact(ticket,'source export exporter resource quantity destination recipient state')
            need(ticket['state']=='RETIRED_FOR_DESTINATION','BRIDGE_TICKET_CONTEXT')
        need(ticket['source']==p['source'] and ticket['export']==p['export'] and ticket['destination']==s['chain'],'BRIDGE_TICKET_CONTEXT')
        key(ticket['recipient']);key(ticket['exporter']);integer(ticket['quantity'],True)
        qty=ticket['quantity']
        if ticket['resource'] in policy['resource_map']:
            need('resource_proof' not in p,'BRIDGE_UNNEEDED_RESOURCE_PROOF');local=policy['resource_map'][ticket['resource']]
        else:
            need(policy.get('lineage_resources',False) and 'resource_proof' in p,'BRIDGE_UNADOPTED_RESOURCE')
            description=verify_bundle(policy['genesis'],p['resource_proof'],p['source'],report['height'],'resources',ticket['resource'])
            need(description['head']==report['head'],'BRIDGE_RESOURCE_CHECKPOINT')
            desc=description['value'];need(type(desc) is dict and type(desc.get('unit')) is str and 0<len(desc['unit'])<=80,'BRIDGE_RESOURCE_DESCRIPTION')
            local=digest('COVENANT-BRIDGE-ASSET-0.7',{'source':p['source'],'resource':ticket['resource']})
            # Keep distinct origins distinct; do not alias unfamiliar issuance to
            # an existing domestic resource merely because unit labels match.
            expected={'unit':desc['unit'],'source_chain':p['source'],'source_resource':ticket['resource'],'import_profile':'covenant-native/0.7'}
            if local in s['resources']:need(s['resources'][local]==expected,'BRIDGE_RESOURCE_LINEAGE')
            else:s['resources'][local]=expected;s['supply'][local]=0;s['consumed'][local]=0
        if s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION}:
            from .ledger_base import RESOURCE_SUPPLY_CAP, SUPPLY_CAP_ACTIVATION_HEIGHT
            if height>=SUPPLY_CAP_ACTIVATION_HEIGHT:
                need(s['supply'][local]+qty<=RESOURCE_SUPPLY_CAP,'SUPPLY_CAP')
        integer(s['supply'][local]+qty,True);s['supply'][local]+=qty
        add(s['balances'],ticket['recipient'],local,qty);add(s['authority_available'],ticket['recipient'],local,qty)
        s['bridge_imports'][iid]={'source':p['source'],'export':p['export'],'quantity':qty,'resource':local,'recipient':ticket['recipient'],'event':tid,'source_height':report['height'],'source_head':report['head'],'source_epoch':report['epoch'],'assurance':'ADOPTED_SOURCE_COMMITTEE'}
        if locked_profile and iid in s.get('bridge_acceptances',{}):
            s['bridge_acceptances'][iid]['state']='IMPORTED'
        return []
    return None


def prepare_export(resource, quantity, destination, recipient, *, acknowledge_irreversible=False):
    """Client payload for BRIDGE_EXPORT.

    The chain still burns on a raw export. This helper refuses to build one
    until the caller records that a lost destination strands the capacity.
    """
    need(acknowledge_irreversible is True, 'BRIDGE_STRAND_UNACKNOWLEDGED')
    integer(quantity, True)
    key(destination)
    key(recipient)
    need(type(resource) is str and 0 < len(resource) <= 80, 'BRIDGE_DESTINATION_RESOURCE')
    return {'resource': resource, 'quantity': quantity, 'destination': destination, 'recipient': recipient}
