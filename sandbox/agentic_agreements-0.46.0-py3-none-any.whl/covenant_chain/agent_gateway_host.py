"""HTTP host for the verified agent gateway: A2A calls in, the owner's agent behind.

A company runs this process in front of one of its agents. External agents
send A2A 1.0 JSON-RPC SendMessage calls. Each call carries a signed
covenant-agent-gateway-request/0.1 envelope in message metadata. The host hands
the envelope and the rest of the call to AgentGateway, which decides and logs
before any effect. Admitted calls go to the owner's upstream agent, either an
A2A URL or a Python callback. Operations whose rule requires an agreement go
through the agreement gate instead.

The payload a caller signs is the SendMessage params with the request (and an
optional identity statement) removed from message.metadata, and
message.metadata removed when it is then empty.

Trust boundary. The listener binds literal IPv4 loopback only. TLS, public
addressing and connection limits belong to a proxy in front. The owner config,
keys, clock, record source and upstream are trusted. The caller is whoever
signed the request; no header names a caller. Transport refusals (bad HTTP,
bad JSON-RPC, gateway extension not activated) happen before the gateway and
are not logged. Every call that reaches the gateway is logged, admitted or
refused. The upstream call runs under the gateway lock, so calls are serial.
No request body, token or key is logged by the host.
"""
from copy import deepcopy
import argparse
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler
import json
import re
import socket
import sys
import threading
import time

from covenant_language.safe_io import bounded_read

from . import crypto as c
from . import observability
from .backup import refuse_pending_restore
from .agent_gateway import EXTENSION_URI, AgentGateway, agent_card_extension, record_from_state
from .agent_gateway_client import DECISION_HEADER, check_url, exchange, split_params
from .provider_replica_rpc import _BoundedServer

HOST_VERSION = "covenant-agent-gateway-host/0.1"
FORWARD_VERSION = "covenant-agent-gateway-forward/0.1"
PATHS = {"rpc": "/rpc", "card": "/.well-known/agent-card.json",
         "mark": "/.well-known/covenant-agent-gateway-mark.json", "export": "/audit/export"}
REFUSED = -32000
UPSTREAM_UNKNOWN = -32603
METHOD_UNSUPPORTED = -32004
EXTENSION_REQUIRED = -32008
VERSION_UNSUPPORTED = -32009
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
CODE = re.compile(r"(GATEWAY|A2A_GATE)_[A-Z0-9_]{1,90}\Z")


def token_digest(token):
    """What the owner stores for an auditor: the SHA-256 of the bearer token."""
    c.need(type(token) is str and 32 <= len(token) <= 256 and
           all(33 <= ord(ch) <= 126 for ch in token), "GATEWAY_HOST_TOKEN")
    return hashlib.sha256(token.encode("ascii")).hexdigest()


class GatewayHost:
    """Owner-built host around one AgentGateway.

    upstream is an A2A JSON-RPC URL or a callable. A callable receives the
    gateway's call dict (caller, operation, payload, withheld, decision,
    untrusted) and returns the SendMessage result object. A URL receives a
    SendMessage whose params are the admitted payload, with the decision in
    message.metadata under covenant-agent-gateway-forward/0.1.
    """

    def __init__(self, gateway, *, upstream, card, public_url=None, hosts=(), auditors=(),
                 agreement_gate=None, upstream_headers=None, allow_insecure_loopback=False,
                 timeout=10.0, max_request_bytes=262144, max_response_bytes=1048576,
                 max_export_bytes=64 * 1048576, mark_seconds=60):
        c.need(isinstance(gateway, AgentGateway), "GATEWAY_HOST_GATEWAY")
        c.need(type(allow_insecure_loopback) is bool, "GATEWAY_HOST_CONFIG")
        if callable(upstream):
            self._execute = upstream
        else:
            self.upstream_url = check_url(upstream, allow_insecure_loopback)
            self._execute = self._forward
        headers = {} if upstream_headers is None else deepcopy(upstream_headers)
        c.need(type(headers) is dict and all(type(k) is str and type(v) is str
               for k, v in headers.items()) and not {k.lower() for k in headers} &
               {"content-type", "accept", "a2a-version", "a2a-extensions"},
               "GATEWAY_HOST_HEADERS")
        c.need(type(card) is dict and set(card) <= {"name", "description", "version", "skills"} and
               all(type(card.get(k)) is str and card[k] for k in ("name", "description", "version")) and
               type(card.get("skills", [])) is list, "GATEWAY_HOST_CARD")
        if public_url is not None:
            c.need(type(public_url) is str and public_url.startswith("https://"),
                   "GATEWAY_HOST_PUBLIC_URL")
            check_url(public_url)
        c.need(type(hosts) in (list, tuple) and len(hosts) <= 16 and all(
            type(host) is str and 0 < len(host) <= 256 and host == host.lower() and
            re.fullmatch(r"[a-z0-9.:-]+", host) for host in hosts), "GATEWAY_HOST_HOSTS")
        c.need(type(auditors) in (list, tuple) and len(auditors) <= 64, "GATEWAY_HOST_AUDITORS")
        for ref in auditors:
            c.key(ref)
        for value, minimum, maximum in ((max_request_bytes, 1024, 1000000),
                                        (max_response_bytes, 1024, 4000000),
                                        (max_export_bytes, 1024, 1 << 30), (mark_seconds, 0, 86400)):
            c.need(type(value) is int and minimum <= value <= maximum, "GATEWAY_HOST_LIMIT")
        c.need(type(timeout) in (int, float) and 0 < timeout <= 120, "GATEWAY_HOST_LIMIT")
        if agreement_gate is not None:
            from .a2a_agreement_gate import AgreementGate
            c.need(isinstance(agreement_gate, AgreementGate), "GATEWAY_HOST_AGREEMENT_GATE")
        self.gateway, self.gate, self.card = gateway, agreement_gate, deepcopy(card)
        self.public_url, self.hosts, self.auditors = public_url, frozenset(hosts), tuple(auditors)
        self.upstream_headers, self.timeout = headers, float(timeout)
        self.max_request_bytes, self.max_response_bytes = max_request_bytes, max_response_bytes
        self.max_export_bytes, self.mark_seconds = max_export_bytes, mark_seconds
        self._mark_lock = threading.Lock()
        self._mark = None
        self.ops = observability.Ops('agent-gateway', routes=set(PATHS.values()))
        self.ops.health.add('decision_log', observability.writable_directory(str(gateway.store.directory)))
        self.ops.storage('decision_log', [gateway.store.directory])

    # -- Gateway calls, usable without HTTP --------------------------------

    def _forward(self, call):
        params = deepcopy(call["payload"])
        c.need(type(params) is dict and type(params.get("message")) is dict, "GATEWAY_HOST_FORWARD")
        metadata = params["message"].setdefault("metadata", {})
        c.need(type(metadata) is dict, "GATEWAY_HOST_FORWARD")
        metadata[FORWARD_VERSION] = {"decision": call["decision"], "caller": call["caller"],
                                     "operation": call["operation"], "withheld": call["withheld"],
                                     "untrusted": True}
        status, headers, raw = exchange(
            self.upstream_url, {"jsonrpc": "2.0", "id": call["decision"], "method": "SendMessage",
                                "params": params},
            headers=self.upstream_headers, timeout=self.timeout, max_bytes=self.max_response_bytes)
        c.need(200 <= status < 300 and headers.get("content-type", "").split(";")[0].strip() ==
               "application/json", "GATEWAY_HOST_UPSTREAM")
        reply = c.loads(raw)
        c.exact(reply, "jsonrpc id result")
        c.need(reply["jsonrpc"] == "2.0" and reply["id"] == call["decision"] and
               type(reply["result"]) is dict, "GATEWAY_HOST_UPSTREAM")
        return reply["result"]

    def mark(self):
        """The latest trust mark, cached for mark_seconds so reads do not replay the log each time."""
        with self._mark_lock:
            now = time.monotonic()
            if self._mark is None or now - self._mark[0] >= self.mark_seconds:
                self._mark = (now, self.gateway.trust_mark())
            return deepcopy(self._mark[1])

    def agent_card(self, url):
        card = {"name": self.card["name"], "description": self.card["description"],
                "version": self.card["version"],
                "supportedInterfaces": [{"url": self.public_url or url, "protocolBinding": "JSONRPC",
                                         "protocolVersion": "1.0"}],
                "capabilities": {"extensions": [agent_card_extension(self.mark())]},
                "defaultInputModes": ["application/json"],
                "defaultOutputModes": ["application/json"]}
        if self.card.get("skills"):
            card["skills"] = deepcopy(self.card["skills"])
        return card

    def send_message(self, params, active_extensions):
        """One SendMessage after transport checks. Returns (reply fields, decision id)."""
        c.need(EXTENSION_URI in active_extensions, "GATEWAY_HOST_EXTENSION_REQUIRED")
        request, identity, payload = split_params(params)
        operation = None
        if type(request) is dict and type(request.get("body")) is dict:
            operation = request["body"].get("operation")
        rule = self.gateway.policy["inbound"].get(operation) if type(operation) is str else None
        if rule is not None and rule["require_agreement"] and self.gate is not None:
            from .a2a_agreement_gate import EXTENSION_URI as AGREEMENT_EXTENSION
            c.need(AGREEMENT_EXTENSION in active_extensions,
                   "GATEWAY_HOST_AGREEMENT_EXTENSION_REQUIRED")
            out = self.gateway.inbound_agreement(self.gate, request, payload, identity=identity)
            result = out["task"]
        else:
            out = self.gateway.inbound(request, payload, self._execute, identity=identity)
            result = out["result"]
        decision = out["decision"]
        if out["outcome"] != "ADMIT":
            return {"error": {"code": REFUSED, "message": "GATEWAY_REFUSED",
                              "data": {"decision": decision, "outcome": "REFUSE",
                                       "codes": out["codes"]}}}, decision
        if out["execution"] == "AGREEMENT_REFUSED":
            return {"error": {"code": REFUSED, "message": "GATEWAY_AGREEMENT_REFUSED",
                              "data": {"decision": decision, "outcome": "ADMIT",
                                       "execution": "AGREEMENT_REFUSED", "code": out["code"]}}}, decision
        if out["execution"] != "RECORDED":
            # The upstream may have acted. The gateway does not retry.
            return {"error": {"code": UPSTREAM_UNKNOWN, "message": "GATEWAY_UPSTREAM_UNKNOWN",
                              "data": {"decision": decision, "outcome": "ADMIT",
                                       "execution": out["execution"]}}}, decision
        return {"result": result}, decision

    def auditor(self, value):
        if type(value) is not str or not value.startswith("Bearer "):
            return False
        try:
            candidate = token_digest(value[7:])
        except ValueError:
            return False
        return any(hmac.compare_digest(candidate, ref) for ref in self.auditors)

    # -- HTTP ---------------------------------------------------------------

    def server(self, port=0, *, host="127.0.0.1"):
        c.need(host == "127.0.0.1" and type(port) is int and 0 <= port <= 65535,
               "GATEWAY_HOST_LOOPBACK")
        service = self
        lifetime = self.timeout + 5

        class Handler(observability.Instrumented, BaseHTTPRequestHandler):
            server_version = "CovenantAgentGateway"
            ops = service.ops
            sys_version = ""

            def setup(self):
                self.request.settimeout(2)
                super().setup()
                self._deadline = threading.Timer(lifetime, self.expire)
                self._deadline.daemon = True
                self._deadline.start()

            def expire(self):
                try:
                    self.request.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            def finish(self):
                try:
                    super().finish()
                finally:
                    self._deadline.cancel()

            def log_message(self, *args):
                pass

            def reply(self, status, value, *, limit=None, decision=None):
                from covenant_agent.errors import shaped  # one refusal shape across the agent boundary
                failure = value.get("error") if type(value) is dict else None
                if type(failure) is dict and type(failure.get("message")) is str:
                    service.ops.refusal(failure["message"])  # JSON-RPC refusals travel with HTTP 200
                raw = c.canonical(shaped(value))
                if len(raw) > (limit or service.max_response_bytes):
                    status, raw = 413, c.canonical(shaped({"error": "GATEWAY_HOST_RESULT_LIMIT"}))
                try:
                    self.send_response(status)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(raw)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.send_header("Connection", "close")
                    if decision is not None:
                        self.send_header("A2A-Extensions", EXTENSION_URI)
                        self.send_header(DECISION_HEADER, decision)
                    self.end_headers()
                    if self.command != "HEAD":
                        self.wfile.write(raw)
                except OSError:
                    pass  # A lost reply does not roll back or retry the upstream call.
                self.close_connection = True

            def access(self):
                hosts = service.hosts or {"127.0.0.1:" + str(self.server.server_port)}
                received = self.headers.get_all("Host", [])
                c.need(len(received) == 1 and received[0].lower() in hosts, "GATEWAY_HOST_HOST")
                c.need(not any(self.headers.get(name) is not None for name in
                               ("Transfer-Encoding", "Expect")), "GATEWAY_HOST_HEADERS")

            def refuse(self, error):
                code = str(error)
                code = code if CODE.fullmatch(code) else "GATEWAY_HOST_REFUSED"
                status = {"GATEWAY_HOST_UNAUTHORIZED": 401, "GATEWAY_HOST_PATH": 404,
                          "GATEWAY_HOST_HOST": 421}.get(code, 400)
                self.reply(status, {"error": code})

            def do_GET(self):
                try:
                    self.access()
                    if self.path == PATHS["card"]:
                        url = "http://127.0.0.1:" + str(self.server.server_port) + PATHS["rpc"]
                        self.reply(200, service.agent_card(url))
                    elif self.path == PATHS["mark"]:
                        self.reply(200, service.mark())
                    elif self.path == PATHS["export"]:
                        auth = self.headers.get_all("Authorization", [])
                        c.need(len(auth) == 1 and service.auditor(auth[0]), "GATEWAY_HOST_UNAUTHORIZED")
                        self.reply(200, service.gateway.export(), limit=service.max_export_bytes)
                    else:
                        raise ValueError("GATEWAY_HOST_PATH")
                except (ValueError, TypeError, KeyError) as error:
                    self.refuse(error)
                except Exception:
                    self.reply(503, {"error": "GATEWAY_HOST_UNAVAILABLE"})

            def do_POST(self):
                request_id = None
                try:
                    self.access()
                    c.need(self.path == PATHS["rpc"], "GATEWAY_HOST_PATH")
                    c.need(self.headers.get("Origin") is None, "GATEWAY_HOST_HEADERS")
                    c.need(self.headers.get_all("Content-Type", []) == ["application/json"],
                           "GATEWAY_HOST_TYPE")
                    lengths = self.headers.get_all("Content-Length", [])
                    c.need(len(lengths) == 1 and re.fullmatch(r"[0-9]{1,7}", lengths[0]) and
                           0 < int(lengths[0]) <= service.max_request_bytes, "GATEWAY_HOST_LENGTH")
                    raw = self.rfile.read(int(lengths[0]))
                    c.need(len(raw) == int(lengths[0]), "GATEWAY_HOST_INCOMPLETE")
                except (ValueError, TypeError, KeyError, OSError) as error:
                    return self.refuse(error)
                try:
                    body = c.loads(raw)
                except (ValueError, TypeError, UnicodeError, RecursionError):
                    return self.reply(200, {"jsonrpc": "2.0", "id": None, "error": {
                        "code": PARSE_ERROR, "message": "GATEWAY_HOST_JSON"}})
                if not (type(body) is dict and set(body) == {"jsonrpc", "id", "method", "params"} and
                        body["jsonrpc"] == "2.0" and type(body["id"]) is str and
                        0 < len(body["id"]) <= 256 and type(body["method"]) is str and
                        type(body["params"]) is dict):
                    return self.reply(200, {"jsonrpc": "2.0", "id": None, "error": {
                        "code": INVALID_REQUEST, "message": "GATEWAY_HOST_RPC"}})
                request_id = body["id"]

                def error(code, message):
                    self.reply(200, {"jsonrpc": "2.0", "id": request_id,
                                     "error": {"code": code, "message": message}})

                if self.headers.get_all("A2A-Version", []) != ["1.0"]:
                    return error(VERSION_UNSUPPORTED, "GATEWAY_HOST_VERSION")
                if body["method"] != "SendMessage":
                    return error(METHOD_UNSUPPORTED, "GATEWAY_HOST_METHOD")
                extensions = self.headers.get_all("A2A-Extensions", [])
                active = [] if len(extensions) != 1 else [
                    value.strip() for value in extensions[0][:4096].split(",")][:16]
                if EXTENSION_URI not in active:
                    return error(EXTENSION_REQUIRED, "GATEWAY_HOST_EXTENSION_REQUIRED")
                try:
                    reply, decision = service.send_message(body["params"], active)
                except (ValueError, TypeError, KeyError) as exc:
                    code = str(exc)
                    if code == "GATEWAY_HOST_AGREEMENT_EXTENSION_REQUIRED":
                        return error(EXTENSION_REQUIRED, code)
                    return error(INVALID_REQUEST, code if CODE.fullmatch(code) else "GATEWAY_HOST_PARAMS")
                except Exception:
                    return self.reply(503, {"jsonrpc": "2.0", "id": request_id, "error": {
                        "code": UPSTREAM_UNKNOWN, "message": "GATEWAY_HOST_UNAVAILABLE"}})
                self.reply(200, {"jsonrpc": "2.0", "id": request_id, **reply}, decision=decision)

            def do_HEAD(self):
                self.reply(405, {"error": "GATEWAY_HOST_METHOD"})

            do_PUT = do_HEAD
            do_DELETE = do_HEAD
            do_OPTIONS = do_HEAD
            do_PATCH = do_HEAD

        return _BoundedServer((host, port), Handler)


def _chain_records(rpc):
    """Kept-promise records read from a node the owner runs. The node is trusted."""
    from .client import Client
    client = Client(**rpc)

    def record(account):
        context = client.context()
        return record_from_state(client.state(), account, chain=context["chain"],
                                 height=context["applied_height"])
    return record


def from_config(config, *, records=None, upstream=None, agreement_gate=None):
    """Build a gateway and host from an owner config. Keys are read from 0600 files.

    records and upstream may be passed as Python callbacks; they override the
    config. Returns (gateway, host). The caller closes the gateway.
    """
    from .agent_tools import decode
    from .runtime_host import private_text
    c.need(type(config) is dict and config.get("version") == HOST_VERSION, "GATEWAY_HOST_VERSION")
    required = {"version", "directory", "policy", "log_key_file", "card"}
    optional = {"upstream", "public_url", "hosts", "auditor_token_sha256", "records_rpc", "port",
                "timeout", "mark_seconds"}
    c.need(required <= set(config) <= required | optional, "GATEWAY_HOST_CONFIG")
    policy = config["policy"]
    if type(policy) is str:
        with open(policy, "rb") as handle:
            policy = c.loads(handle.read())
    log_key = c.load_private(private_text(config["log_key_file"]))
    if records is None:
        records = (_chain_records(config["records_rpc"]) if config.get("records_rpc") is not None
                   else (lambda account: None))
    headers = None
    if upstream is None:
        spec = config.get("upstream")
        c.need(type(spec) is dict and set(spec) >= {"url"} and
               set(spec) <= {"url", "headers_file", "allow_insecure_loopback"}, "GATEWAY_HOST_UPSTREAM")
        upstream = spec["url"]
        if "headers_file" in spec:
            headers = decode(private_text(spec["headers_file"]))
        insecure = spec.get("allow_insecure_loopback", False)
    else:
        insecure = False
    gateway = AgentGateway(config["directory"], policy=policy, log_key=log_key,
                           clock=lambda: int(time.time()), record=records)
    try:
        host = GatewayHost(gateway, upstream=upstream, card=config["card"],
                           public_url=config.get("public_url"), hosts=tuple(config.get("hosts", ())),
                           auditors=tuple(config.get("auditor_token_sha256", ())),
                           agreement_gate=agreement_gate, upstream_headers=headers,
                           allow_insecure_loopback=insecure, timeout=config.get("timeout", 10.0),
                           mark_seconds=config.get("mark_seconds", 60))
    except BaseException:
        gateway.close()
        raise
    return gateway, host


def arguments():
    """The gateway host's command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description="Serve an AAP verified agent gateway on loopback.")
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument("--config", help="Owner config, " + HOST_VERSION + ".")
    choice.add_argument("--token-digest", action="store_true",
                        help="Read an auditor token on stdin and print the SHA-256 to configure.")
    observability.add_arguments(parser)
    return parser


def main(argv=None):
    args = arguments().parse_args(argv)
    try:
        if args.token_digest:
            print(token_digest(bounded_read(sys.stdin, 4096, 'GATEWAY_HOST_TOKEN', line=True).strip()))
            return 0
        with open(args.config, "rb") as handle:
            config = c.loads(handle.read())
        refuse_pending_restore(config.get("directory") if type(config) is dict else None)
        gateway, host = from_config(config)
    except (ValueError, OSError) as error:
        print(json.dumps({"error": str(error).splitlines()[0] if str(error) else
                          type(error).__name__}, sort_keys=True), file=sys.stderr)
        return 2
    httpd = host.server(config.get("port", 8740))
    observability.start(host.ops, args)
    print(json.dumps({"listening": "http://127.0.0.1:" + str(httpd.server_port),
                      "service": gateway.service, "log_signer": gateway.log_signer}, sort_keys=True),
          flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        host.ops.close()
        gateway.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
