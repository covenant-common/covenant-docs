"""Payloads an agent can hand to a signer. Nothing here submits a transaction."""
from copy import deepcopy

from .crypto import HEX, canonical, digest, need


def search_arbitrators(records, *, category=None, min_reputation=0, exclude=(), parties=None, profiles=None,
                       now=None, max_age=None, require_profile=False):
    """Filter a registry snapshot. ``exclude`` drops those members and their affiliates.

    ``parties`` are excluded the same way. With signed arbitrator records
    (``profiles``, see arbitrator_records), a member whose record declares a
    non-waivable conflict with the parties, or who is not available at
    ``now``, drops out too. Without those arguments the result is unchanged.
    """
    need(type(records) in (list, tuple) and all(type(row) is dict and type(row.get("member")) is str for row in records), "FIELDS:records")
    need(type(exclude) in (list, tuple, set, frozenset) and all(type(item) is str for item in exclude), "FIELDS:exclude")
    need(type(min_reputation) is int, "FIELDS:min_reputation")
    need(parties is None or (type(parties) in (list, tuple) and all(type(item) is str for item in parties)), "FIELDS:parties")
    blocked = set(exclude) | set(parties or ())
    found = []
    for row in records:
        member = row['member']
        if member in blocked or not row.get('active', False):
            continue
        if category is not None and category not in row.get('categories', []):
            continue
        if row.get('reputation', 0) < min_reputation:
            continue
        if blocked & set(row.get('affiliations', [])):
            continue
        found.append({'member': member, 'categories': list(row.get('categories', [])),
                      'reputation': row.get('reputation', 0), 'stake': row.get('stake', 0)})
    found.sort(key=lambda item: (-item['reputation'], item['member']))
    if parties is not None or profiles is not None or require_profile:
        from .arbitrator_records import screen
        found = screen(found, parties=parties, profiles=profiles, now=now, max_age=max_age, require_profile=require_profile)
    return found


def open_payload(agreement):
    need(type(agreement) is str and bool(HEX.fullmatch(agreement)), 'FIELDS:agreement')
    return {'agreement': agreement}


PHASES = ('PRIMARY', 'APPEAL')
REMEDIES = ('penalty', 'redeliver', 'refund', 'release', 'split')
FORMATS = ('attestation', 'hash', 'show')
BALLOT_FIELDS = ('chain', 'agreement', 'phase', 'remedy', 'payee_bps', 'penalty', 'reasons')


def _hex(value, name):
    need(type(value) is str and bool(HEX.fullmatch(value)), 'FIELDS:' + name)


def _count(value, name, limit=2 ** 53 - 1):
    need(type(value) is int and 0 <= value <= limit, 'FIELDS:' + name)


def evidence_payload(agreement, content_hash, *, format='hash', description='HASH', attestation=None):
    """Build exact evidence fields; authenticity and admissibility need the reducer.

    An attestation can carry a guarded controller signature. Its shape is checked
    here without interpreting its claims or treating the signer as an authority.
    """
    _hex(agreement, 'agreement')
    _hex(content_hash, 'content_hash')
    need(type(format) is str and format in FORMATS, 'FIELDS:format')
    need(type(description) is str and len(description) <= 2000, 'FIELDS:description')
    if format == 'attestation':
        # A continuity-protected signer's signature is a guarded dict, which the
        # reducer verifies through its controller; vote_payload allows it too.
        need(type(attestation) is dict and set(attestation) == {'signer', 'signature'}
             and type(attestation['signer']) is str
             and type(attestation['signature']) in (str, dict), 'FIELDS:attestation')
        try:
            canonical(attestation)
        except (TypeError, ValueError) as exc:
            raise ValueError('FIELDS:attestation') from exc
        attestation = deepcopy(attestation)
    else:
        need(attestation is None, 'FIELDS:attestation')
    return {'agreement': agreement, 'format': format, 'content_hash': content_hash,
            'description': description, 'attestation': attestation}


def ballot_body(chain, agreement, phase, remedy, payee_bps, penalty, reasons):
    """The exact body an arbitrator signs under COVENANT-PANEL-BALLOT-1."""
    _hex(chain, 'chain')
    _hex(agreement, 'agreement')
    need(type(phase) is str and phase in PHASES, 'FIELDS:phase')
    need(type(remedy) is str and remedy in REMEDIES, 'FIELDS:remedy')
    _count(payee_bps, 'payee_bps', 10000)
    _count(penalty, 'penalty')
    _hex(reasons, 'reasons')
    return {'chain': chain, 'agreement': agreement, 'phase': phase, 'remedy': remedy,
            'payee_bps': payee_bps, 'penalty': penalty, 'reasons': reasons}


def vote_payload(body, ballot):
    """Build a vote, preserving the exact ballot that still needs verification.

    ``ballot`` is a signature string, a native signature object, or '' while
    unsigned. Neither well-formedness nor a signature establishes world truth.
    """
    need(type(body) is dict and set(body) == set(BALLOT_FIELDS), 'FIELDS:body')
    checked = ballot_body(*(body[name] for name in BALLOT_FIELDS))
    need(type(ballot) in (str, dict), 'FIELDS:ballot')
    try:
        canonical(ballot)
    except (TypeError, ValueError) as exc:
        raise ValueError('FIELDS:ballot') from exc
    return {'agreement': checked['agreement'], 'phase': checked['phase'], 'remedy': checked['remedy'],
            'payee_bps': checked['payee_bps'], 'penalty': checked['penalty'], 'reasons': checked['reasons'],
            'ballot': deepcopy(ballot)}


def reasons_hash(text):
    """Hash the panel's reasons text. Valid text hashes exactly as before."""
    need(type(text) is str, 'FIELDS:text')
    return digest('COVENANT-PANEL-REASONS-1', {'text': text})
