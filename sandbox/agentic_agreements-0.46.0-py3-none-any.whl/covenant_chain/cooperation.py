"""An opt-in bridge from unrestricted conversation to certified service work.

Existing native SERVICE_OFFER/BOOK approvals bind the complete proposal hash.
There is no second, inferred assent and no new consensus/application semantics.
The agreement text is interpreted by the appointed procedure, not this module.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib

from covenant_language import boundary, negotiation
from covenant_language.agentic import canonical as semantic_bytes, object_id
from .crypto import canonical, integer, key, need
from .proofs import verify_history

VERSION = 'covenant-cooperation/0.1'
TERMS = 'covenant-cooperation-terms/0.1'
FILE = 'covenant-file-publication/0.1'
REVIEWED_FILE = 'covenant-reviewed-file-publication/0.1'

REMEDIES = {
    'UNSUPPORTED_EFFECT': 'Use a supported effect profile or explicitly install a reviewed local adapter.',
    'PUBLIC_METADATA': 'Use a separately qualified private workflow or explicitly permit this public record.',
    'CAPABILITY_NOT_ALLOWED': 'Choose an allowed service or obtain a narrower policy approval.',
    'PRICE_LIMIT': 'Negotiate a lower total price or request an explicit budget increase.',
    'UNIT_LIMIT': 'Reduce the requested quantity or request an explicit capacity increase.',
    'CUSTOMER_MISMATCH': 'Obtain a job for the independently selected customer institution.',
    'PROVIDER_MISMATCH': 'Obtain a job with the independently selected provider.',
    'SETTLEMENT_RESOURCE': 'Use the approved settlement resource; numeric amounts in different units are not interchangeable.',
    'CAPACITY_RESOURCE': 'Use the independently selected capacity resource.',
    'INDEFINITE_HOLD': 'Adopt a bounded release procedure or explicitly accept potentially indefinite reservation.',
    'PARTIES_MISMATCH': 'Include every native approving signer and appointed judge in the exact proposal.',
    'TERMS_CHANGED': 'Recompile the exact terms and collect fresh native approvals.',
    'MAPPING_CHANGED': 'Compare the offer and booking with the proposal; obtain fresh approvals for changes.',
    'UNENFORCED_REQUIREMENT': 'Implement the required enforcement adapter or explicitly renegotiate it as an undertaking.',
    'PAYMENT_NOT_RESERVED': 'Wait for certified booking with sufficient settlement capacity reserved.',
    'CAPACITY_NOT_RESERVED': 'Select a provider with sufficient certified capacity and book it.',
    'JOB_NOT_LIVE': 'Inspect the certified outcome; reconcile prior effects instead of starting new work.',
    'INSUFFICIENT_TIME': 'Negotiate and certify a new deadline before starting work.',
    'REVIEW_PENDING': 'Follow the adopted review procedure before performing the gated action.',
    'JOB_NOT_CERTIFIED': 'Obtain a certified history containing this exact booking.',
    'PUBLICATION_NOT_APPROVED': 'Obtain a supported, challenge-complete decision that names the exact output hash.',
    'EXECUTOR_NOT_IMPLEMENTED': 'Install and exercise an execution gate for this profile; a descriptor validator alone is insufficient.',
    'FILE_DESCRIPTOR': 'The file effect description does not hold exactly profile covenant-file-publication/0.1, payload_hash and bytes. Build it from the file bytes with file_publication instead of by hand.',
    'FILE_DESCRIPTOR_SIZE': 'The file to publish is larger than 1048576 bytes (1 MiB). Publish a smaller file, or split the work into separately agreed parts.',
    'REVIEWED_FILE_DESCRIPTOR': 'The reviewed-file effect does not hold exactly profile covenant-reviewed-file-publication/0.1, max_bytes and publication_blocks. Send that exact shape.',
    'REVIEWED_FILE_SIZE': 'The reviewed file\'s max_bytes is not a whole number from 1 to 1048576. Agree a limit in that range.',
    'REVIEWED_FILE_WINDOW': 'The review window publication_blocks is not a whole number from 1 to 10000 blocks. Agree a window in that range.',
    'EFFECT_REGISTRY_PROFILE': 'The effect version name is empty, longer than 128 characters, or already registered. The host owner registers each effect version once, under a unique name.',
    'EFFECT_REGISTRY_BINDING': 'An effect registration lacks a capability name of 1 to 80 characters or a callable validator. The host owner supplies both when installing the adapter.',
    'EFFECT_DESCRIPTOR': 'The effect description is not an object whose profile is a text name. Send the exact effect object from the agreed terms.',
    'EFFECT_CAPABILITY': 'The effect is registered for a different capability than the one requested. Use the capability the host owner installed for this effect, or ask the owner to install a matching adapter.',
    'EFFECT_DESCRIPTOR_NOT_ACCEPTED': 'The installed adapter\'s validator refused this effect description. Change the effect terms to what the adapter accepts and get fresh signatures; the adapter is never bypassed.',
    'FILE_PAYLOAD': 'The file content is not raw bytes. Pass the exact file bytes, not text or a path.',
    'COOPERATION_TERMS': 'The cooperation terms do not hold exactly version covenant-cooperation-terms/0.1, agreement, effect and supersedes. Compile the terms again from the proposal instead of editing them.',
    'COOPERATION_RESOLVER': 'The proposal\'s resolver or appeal resolver differs from the one named in the booked terms. Use one proposal where both match, and get fresh approvals for any change.',
    'CHANGE_LIMIT': 'The change limit is not a whole number from 1 to 1024. Pass a limit in that range.',
    'COOPERATION_POLICY': 'The recipient\'s cooperation policy is incomplete or malformed: it needs a settlement resource, 1 to 64 distinct capability and effect names of 1 to 128 characters, and true-or-false flags. The host owner fixes the policy in configuration.',
    'COOPERATION_HISTORY_LIMIT': 'The policy\'s max_history_blocks is not a whole number from 1 to 1000000. The host owner sets a limit in that range.',
    'EFFECT_REGISTRY': 'The effect registry is not an EffectRegistry the host owner installed. Pass the owner\'s registry, or none to use the built-in file effects.',
    'COOPERATION_STAGE': 'The stage is neither WORK nor EXECUTE. Choose WORK to check before starting work, or EXECUTE before running the effect.',
    'COOPERATION_BUNDLE': 'The proof bundle does not hold exactly version covenant-cooperation/0.1, chain, proposal, offer, job and history. Get the bundle exactly as the provider built it.',
    'COOPERATION_CONTEXT': 'The proof is for a different chain or job than the one you pinned. Get the proof for the intended chain and job; never change your pins to make another proof pass.',
    'EXECUTOR_REGISTRY': 'The executors argument is not an AdapterRegistry. The host owner passes its own installed registry, or none.',
    'JOURNAL_CONTEXT': 'The submission journal belongs to a different chain, genesis or version than this check. Use the journal opened for this exact chain; never share one journal across chains.',
    'STALE_HISTORY': 'The certified history is shorter than the minimum height you adopted, so it may be out of date. Get a newer certified history that reaches that height.',
}


def _file_descriptor(value):
    need(type(value) is dict and set(value) == {'profile', 'payload_hash', 'bytes'} and value['profile'] == FILE,
         'FILE_DESCRIPTOR')
    key(value['payload_hash'])
    need(type(value['bytes']) is int and 0 <= value['bytes'] <= 1024*1024, 'FILE_DESCRIPTOR_SIZE')
    return True


def _reviewed_file_descriptor(value):
    need(type(value) is dict and set(value) == {'profile','max_bytes','publication_blocks'}
         and value['profile'] == REVIEWED_FILE, 'REVIEWED_FILE_DESCRIPTOR')
    need(type(value['max_bytes']) is int and 1 <= value['max_bytes'] <= 1024*1024,
         'REVIEWED_FILE_SIZE')
    need(type(value['publication_blocks']) is int and 1 <= value['publication_blocks'] <= 10000,
         'REVIEWED_FILE_WINDOW')
    return True


class EffectRegistry:
    """Explicit local bindings, never downloaded imports or network execution.

    Validators are trusted local application code, not consensus code. Registering
    a descriptor does not install an executor or prove external enforcement.
    """
    def __init__(self):
        self._profiles = {FILE: ('file.publish', _file_descriptor),
                          REVIEWED_FILE: ('file.publish', _reviewed_file_descriptor)}

    def register(self, profile, capability, validator):
        need(type(profile) is str and 0 < len(profile) <= 128 and profile not in self._profiles,
             'EFFECT_REGISTRY_PROFILE')
        need(type(capability) is str and 0 < len(capability) <= 80 and callable(validator),
             'EFFECT_REGISTRY_BINDING')
        self._profiles[profile] = (capability, validator)

    def supports(self, descriptor, capability):
        need(type(descriptor) is dict and type(descriptor.get('profile')) is str, 'EFFECT_DESCRIPTOR')
        semantic_bytes(descriptor)
        entry = self._profiles.get(descriptor['profile'])
        if entry is None:
            return False
        need(entry[0] == capability, 'EFFECT_CAPABILITY')
        need(entry[1](descriptor) is True, 'EFFECT_DESCRIPTOR_NOT_ACCEPTED')
        return True


def file_publication(payload):
    need(type(payload) is bytes, 'FILE_PAYLOAD')
    descriptor = {'profile': FILE, 'payload_hash': hashlib.sha256(payload).hexdigest(), 'bytes':len(payload)}
    _file_descriptor(descriptor)
    return descriptor


def reviewed_file_publication(*, max_bytes=65536, publication_blocks=20):
    """Output unknown at formation; the final adopted judge names its SHA-256.

    SERVICE_DECIDE/APPEAL evidence is the output hash in this opt-in application
    profile. A positive decision is procedural approval, not proof of quality.
    Native settlement is not atomically coupled to downstream publication.
    """
    value = dict(profile=REVIEWED_FILE, max_bytes=max_bytes, publication_blocks=publication_blocks)
    _reviewed_file_descriptor(value)
    return value


def _meaning(proposal):
    boundary.validate_proposal(proposal)
    negotiation._manifest(proposal['meaning'])
    t = proposal['meaning']['terms']
    need(type(t) is dict and set(t) == {'version', 'agreement', 'effect', 'supersedes'}
         and t['version'] == TERMS, 'COOPERATION_TERMS')
    need(type(t['effect']) is dict and type(t['effect'].get('profile')) is str, 'EFFECT_DESCRIPTOR')
    if t['supersedes'] is not None:
        from covenant_language.agentic import _hash
        _hash(t['supersedes'])
    need(proposal['resolver'] == proposal['meaning']['book']['resolver']
         and proposal['appeal'] == proposal['meaning']['book']['appeal_resolver'], 'COOPERATION_RESOLVER')
    return proposal['meaning']


def draft_service(conversation, parties, agreement, offer, book, effect, *, undertakings=()):
    """Prepare a draft; caller must review the projection and collect native approvals.

    No model extraction, source interpretation, signing or transmission occurs.
    The opaque agreement may use arbitrary supported JSON text/data.
    """
    terms = dict(version=TERMS, agreement=deepcopy(agreement), effect=deepcopy(effect), supersedes=None)
    proposal = negotiation.service_proposal(conversation, parties, terms, offer, book,
                                            undertakings=undertakings)
    _meaning(proposal)
    return proposal


def proposal_changes(before, after, *, limit=128):
    """Exact JSON-pointer differences. A truncated summary is never a full review."""
    _meaning(before)
    _meaning(after)
    need(type(limit) is int and 1 <= limit <= 1024, 'CHANGE_LIMIT')
    changes = []
    def walk(a, b, path):
        if semantic_bytes(a) == semantic_bytes(b):
            return
        if type(a) is dict and type(b) is dict:
            for field in sorted(set(a) | set(b)):
                target = path + '/' + field.replace('~', '~0').replace('/', '~1')
                if field not in a:
                    changes.append(dict(path=target, change='ADDED', after=deepcopy(b[field])))
                elif field not in b:
                    changes.append(dict(path=target, change='REMOVED', before=deepcopy(a[field])))
                else:
                    walk(a[field], b[field], target)
        else:
            changes.append(dict(path=path, change='CHANGED', before=deepcopy(a), after=deepcopy(b)))
    walk(before, after, '')
    return dict(before=object_id(before), after=object_id(after), changes=changes[:limit],
                change_count=len(changes), truncated=len(changes) > limit,
                requires_fresh_approvals=object_id(before) != object_id(after), automatic_assent=False)


def counteroffer(proposal, *, agreement=None, offer=None, book=None, effect=None, undertakings=None):
    old = _meaning(proposal)
    new = deepcopy(proposal)
    m = new['meaning']
    for field, value in [('offer', offer), ('book', book), ('undertakings', undertakings)]:
        if value is not None:
            m[field] = deepcopy(value)
    if agreement is not None:
        m['terms']['agreement'] = deepcopy(agreement)
    if effect is not None:
        m['terms']['effect'] = deepcopy(effect)
    m['terms']['supersedes'] = object_id(proposal)
    new['resolver'], new['appeal'] = m['book']['resolver'], m['book']['appeal_resolver']
    _meaning(new)
    return {'proposal': new, 'review': proposal_changes(proposal, new)}


def offer_payload(proposal):
    m = _meaning(proposal)
    return {**deepcopy(m['offer']), 'terms': negotiation.service_terms_hash(proposal)}


def booking_payload(proposal, offer_reference):
    key(offer_reference)
    return {**deepcopy(_meaning(proposal)['book']), 'offer': offer_reference, 'approvals': []}


def proof_bundle(proposal, chain, offer, job, history):
    _meaning(proposal)
    for ref in (chain, offer, job):
        key(ref)
    return dict(version=VERSION, chain=chain, proposal=deepcopy(proposal), offer=offer,
                job=job, history=deepcopy(history))


@dataclass(frozen=True)
class CooperationPolicy:
    """Recipient configuration acquired independently of an offered proof bundle."""
    customer: str
    capabilities: tuple
    settlement_resource: str
    max_total_price: int
    max_units: int = 1
    provider: str | None = None
    capacity_resource: str | None = None
    allow_public_metadata: bool = False
    allow_indefinite_hold: bool = False
    minimum_remaining_blocks: int = 1
    effect_profiles: tuple = (FILE, REVIEWED_FILE)
    max_history_blocks: int = 10000

    def __post_init__(self):
        key(self.customer)
        if self.provider is not None:
            key(self.provider)
        for resource in (self.settlement_resource, self.capacity_resource):
            need(resource is None or (type(resource) is str and 0 < len(resource) <= 128), 'COOPERATION_POLICY')
        need(self.settlement_resource is not None, 'COOPERATION_POLICY')
        integer(self.max_total_price)
        integer(self.max_units, True)
        integer(self.minimum_remaining_blocks)
        need(type(self.allow_public_metadata) is bool and type(self.allow_indefinite_hold) is bool,
             'COOPERATION_POLICY')
        for values in (self.capabilities, self.effect_profiles):
            need(type(values) is tuple and 0 < len(values) <= 64
                 and all(type(x) is str and 0 < len(x) <= 128 for x in values)
                 and len(set(values)) == len(values), 'COOPERATION_POLICY')
        need(type(self.max_history_blocks) is int and 1 <= self.max_history_blocks <= 1000000,
             'COOPERATION_HISTORY_LIMIT')


def assess_draft(proposal, policy, *, provider, height, registry=None):
    """Cheap prerequisites before fees/reservations; supplied height is advisory.

    No authority, funds, current governance, signatures or finality is checked.
    A positive result only permits the caller to proceed to explicit signing.
    """
    need(type(policy) is CooperationPolicy, 'COOPERATION_POLICY')
    key(provider)
    integer(height)
    m = _meaning(proposal)
    o, b = m['offer'], m['book']
    registry = EffectRegistry() if registry is None else registry
    need(type(registry) is EffectRegistry, 'EFFECT_REGISTRY')
    conditions = [
        ('CUSTOMER_MISMATCH', b['world'] == policy.customer),
        ('PROVIDER_MISMATCH', policy.provider is None or provider == policy.provider),
        ('CAPABILITY_NOT_ALLOWED', o['capability'] in policy.capabilities),
        ('SETTLEMENT_RESOURCE', o['settlement_resource'] == policy.settlement_resource),
        ('CAPACITY_RESOURCE', policy.capacity_resource is None or o['capacity_resource'] == policy.capacity_resource),
        ('UNIT_LIMIT', b['units'] <= policy.max_units),
        ('PRICE_LIMIT', b['units']*o['unit_price'] <= policy.max_total_price),
        ('PUBLIC_METADATA', policy.allow_public_metadata),
        ('INDEFINITE_HOLD', policy.allow_indefinite_hold or b['uncertainty'] != 'HOLD'),
        ('INSUFFICIENT_TIME', b['deadline']-height >= policy.minimum_remaining_blocks),
        ('UNSUPPORTED_EFFECT', m['terms']['effect']['profile'] in policy.effect_profiles
         and registry.supports(m['terms']['effect'], o['capability'])),
        ('UNENFORCED_REQUIREMENT', not any(u['required_assurance'] == 'MACHINE_ENFORCED'
                                         for u in m['undertakings']))]
    required = {provider, b['resolver']}
    if b['appeal_resolver'] is not None:
        required.add(b['appeal_resolver'])
    conditions.append(('PARTIES_MISMATCH', required <= set(proposal['parties'])))
    checks = [dict(code=code, passed=bool(ok), next_action=None if ok else REMEDIES[code])
              for code, ok in conditions]
    missing = [x['code'] for x in checks if not x['passed']]
    return dict(version=VERSION, proposal=object_id(proposal), ready_for_native_signing=not missing,
                checks=checks, missing=missing, automatic_assent=False, binding=False,
                unknown=['authority','available_capacity','native_approvals','current_governance','finality',
                         'world_performance','legal_enforceability','source_projection_completeness'],
                height_basis='CALLER_SUPPLIED_NOT_A_FRESHNESS_PROOF')


def _assess_bundle(bundle, genesis, expected_chain, expected_job, policy, *, minimum_height=0,
                   journal=None, registry=None, stage='WORK', executors=None):
    """Recompute from exact signed history; a caller-edited report grants nothing.

    READY_TO_PERFORM is readiness under this finite local policy at one head.
    It is not legal advice, a guarantee of fair judges, or an execution ticket.
    """
    need(type(policy) is CooperationPolicy, 'COOPERATION_POLICY')
    need(stage in {'WORK','EXECUTE'}, 'COOPERATION_STAGE')
    key(expected_chain)
    key(expected_job)
    integer(minimum_height)
    need(type(bundle) is dict and set(bundle) == {'version','chain','proposal','offer','job','history'}
         and bundle['version'] == VERSION, 'COOPERATION_BUNDLE')
    need(bundle['chain'] == expected_chain and bundle['job'] == expected_job, 'COOPERATION_CONTEXT')
    key(bundle['offer'])
    need(type(bundle['history']) is list and len(bundle['history']) <= policy.max_history_blocks,
         'COOPERATION_HISTORY_LIMIT')
    m = _meaning(bundle['proposal'])
    registry = EffectRegistry() if registry is None else registry
    need(type(registry) is EffectRegistry, 'EFFECT_REGISTRY')
    if executors is not None:
        from .adapters import AdapterRegistry
        need(type(executors) is AdapterRegistry,'EXECUTOR_REGISTRY')
    if journal is not None:
        from .reliable import SubmissionJournal
        need(type(journal) is SubmissionJournal and journal.chain == expected_chain
             and canonical(journal.genesis) == canonical(genesis), 'JOURNAL_CONTEXT')
        need(len(bundle['history']) >= minimum_height, 'STALE_HISTORY')
        verified = journal.observe(bundle['history'])
    else:
        verified = verify_history(genesis, bundle['history'], expected_chain, minimum_height)
    state, checks = verified['state'], []
    def check(code, ok):
        checks.append(dict(code=code, passed=bool(ok), next_action=None if ok else REMEDIES[code]))
    job = state.get('service_jobs', {}).get(expected_job)
    check('JOB_NOT_CERTIFIED', job is not None)
    if job is not None:
        offer = state['service_offers'].get(bundle['offer'])
        check('TERMS_CHANGED', offer is not None and job['terms'] == offer['terms']
              == negotiation.service_terms_hash(bundle['proposal']))
        mapped = offer is not None and job['offer'] == bundle['offer']
        if mapped:
            mapped = all(canonical(offer[k]) == canonical(m['offer'][k]) for k in negotiation.OFFER_FIELDS)
            mapped = mapped and all(canonical(job[k]) == canonical(m['book'][k]) for k in negotiation.BOOK_FIELDS)
        check('MAPPING_CHANGED', mapped)
        signers = {p['signer'] for p in job['approvals']}
        required = {job['provider'], job['resolver']}
        if job['appeal_resolver'] is not None:
            required.add(job['appeal_resolver'])
        check('PARTIES_MISMATCH', signers == set(bundle['proposal']['parties']) and required <= signers)
        check('CUSTOMER_MISMATCH', job['world'] == policy.customer)
        check('PROVIDER_MISMATCH', policy.provider is None or job['provider'] == policy.provider)
        check('SETTLEMENT_RESOURCE', job['settlement_resource'] == policy.settlement_resource)
        check('CAPACITY_RESOURCE', policy.capacity_resource is None or job['capacity_resource'] == policy.capacity_resource)
        check('INDEFINITE_HOLD', policy.allow_indefinite_hold or job['uncertainty'] != 'HOLD')
        check('CAPABILITY_NOT_ALLOWED', offer is not None and offer['capability'] in policy.capabilities)
        check('UNIT_LIMIT', job['units'] <= policy.max_units)
        check('PRICE_LIMIT', job['quantity'] <= policy.max_total_price)
        if stage == 'EXECUTE' and m['terms']['effect']['profile'] == REVIEWED_FILE:
            _reviewed_file_descriptor(m['terms']['effect'])
            approved = (job['state'] in {'PROVISIONAL','APPEALED'} and job['decision'] is not None
                        and job['decision']['outcome'] == 'SUPPORTED' and job['decision']['units'] > 0
                        and verified['height'] > job['final_after'])
            check('PUBLICATION_NOT_APPROVED', approved)
            check('JOB_NOT_LIVE', job['state'] in {'PROVISIONAL','APPEALED'})
            until = job.get('final_after', 0) + m['terms']['effect']['publication_blocks']
        else:
            check('JOB_NOT_LIVE', job['state'] == 'BOOKED')
            until = job['deadline']
        check('INSUFFICIENT_TIME', until - verified['height'] >= policy.minimum_remaining_blocks)
        check('PAYMENT_NOT_RESERVED', state['balances'].get(job['payment_escrow'], {}).get(job['settlement_resource'], 0) == job['quantity'])
        check('CAPACITY_NOT_RESERVED', state['balances'].get(job['capacity_escrow'], {}).get(job['capacity_resource'], 0) == job['units'])
        review = state.get('review_jobs', {}).get(expected_job)
        check('REVIEW_PENDING', review is None or state['review_cases'][review]['status'] == 'READY')
    effect = m['terms']['effect']
    supported = registry.supports(effect, m['offer']['capability'])
    check('UNSUPPORTED_EFFECT', effect['profile'] in policy.effect_profiles and supported)
    if stage == 'EXECUTE':
        check('EXECUTOR_NOT_IMPLEMENTED', effect['profile'] in {FILE,REVIEWED_FILE}
              or (executors is not None and executors.accepts(effect,m['offer']['capability'])))
    check('PUBLIC_METADATA', policy.allow_public_metadata)
    check('UNENFORCED_REQUIREMENT', not any(u['required_assurance'] == 'MACHINE_ENFORCED'
                                          for u in m['undertakings']))
    failures = [c['code'] for c in checks if not c['passed']]
    report = dict(version=VERSION, chain=expected_chain, job=expected_job,
                proposal=object_id(bundle['proposal']), height=verified['height'], head=verified['head'],
                state_root=verified['state_root'],
                status=('READY_TO_PERFORM' if stage == 'WORK' else 'READY_TO_EXECUTE') if not failures else 'PREREQUISITES_REQUIRED',
                stage=stage, ready_for_stage=not failures, ready_to_perform=stage == 'WORK' and not failures,
                checks=checks, missing=failures,
                effect=deepcopy(effect),
                assurance=dict(finality='CERTIFIED_HISTORY_REPLAY', freshness='RECIPIENT_HEIGHT_FLOOR_ONLY',
                               consent='EXACT_NATIVE_BOOKING_APPROVALS' if job else 'NOT_ESTABLISHED',
                               privacy='PUBLIC_LEDGER_METADATA', physical_performance='NOT_ESTABLISHED',
                               operator_independence='NOT_ESTABLISHED', legal_enforceability='NOT_ESTABLISHED',
                               projection_completeness='NOT_ESTABLISHED', future_fees='NOT_RESERVED',
                               automatic_assent=False, execution_authorized=False))
    return report, verified


def assess_bundle(*args, **kwargs):
    """Return actionable prerequisites after rechecking raw certified history.

    Trust, expected job and acceptance policy must come from the recipient.
    No returned dictionary is accepted as authorization by an execution gate.
    """
    return _assess_bundle(*args, **kwargs)[0]
