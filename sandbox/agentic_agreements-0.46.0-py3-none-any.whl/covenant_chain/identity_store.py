"""Owner-directory state files for the identity features (covenant-identity-store/0.1).

The sign-in provider, the credential issuer and the hosted wallet each keep
replay state: pending requests, single-use codes, request nonces and used
approvals. Losing it on restart would let a used code, nonce or approval be
replayed. ``StateFile`` keeps one JSON document per component in a directory
the owner controls:

- The directory must be a real directory owned by this user with mode 0700. It
  is created that way if missing. A directory that group or other can read is
  refused, not repaired, because its old contents may already have leaked.
- Each document is written to a fresh 0600 temporary file, fsynced, renamed over
  the old one with ``os.replace`` and the directory is fsynced. A crash leaves
  either the old or the new document, never a torn one.
- Each document is bound to its kind and to a context (for example the issuer
  and chain), and carries a digest of its state. A file for another context, or
  one edited by hand, is refused on load.
- One process at a time: an exclusive ``flock`` is held from open to ``close``.
  Two processes writing one file would each lose the other's replay records.

Codes, access tokens and approvals are stored as SHA-256 hashes by their
owners, so the files hold no bearer secret. They do hold consent bodies and
public passkey registrations. This is local durability, not replication: back
up the directory, and do not restore an old copy, because a restored copy
forgets every record made after it.
"""
import errno
import fcntl
import hashlib
import json
import os
import re
import secrets
import stat
from pathlib import Path

from .crypto import need

VERSION = 'covenant-identity-store/0.1'
LABEL = 'COVENANT-IDENTITY-STORE-0.1'
NAME = re.compile(r'[a-z][a-z0-9-]{0,40}\Z')
MAX_DOCUMENT = 16 * 1024 * 1024


def _wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def _digest(value):
    return hashlib.sha256(LABEL.encode('ascii') + b'\0' + _wire(value)).hexdigest()


def _pairs(items):
    out = {}
    for name, value in items:
        need(name not in out, 'IDENTITY_STORE_DOCUMENT')
        out[name] = value
    return out


def private_directory(path):
    """Return ``path`` as an owner-only directory, creating it with mode 0700 if missing."""
    path = Path(path)
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        pass
    info = os.lstat(path)
    need(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0,
         'IDENTITY_STORE_DIRECTORY')
    return path


class StateFile:
    """One component's durable state: ``load`` once at start, ``save`` before each reply.

    ``kind`` names the component and ``context`` is a small JSON value that must
    match on every later open (for example {'issuer': ..., 'chain': ...}).
    """

    def __init__(self, directory, name, *, kind, context):
        need(type(name) is str and NAME.fullmatch(name) is not None, 'IDENTITY_STORE_NAME')
        need(type(kind) is str and 0 < len(kind) <= 80 and kind.isascii(), 'IDENTITY_STORE_KIND')
        self.directory = private_directory(directory)
        self.path = self.directory / (name + '.state.json')
        self.kind = kind
        self.context = json.loads(_wire(context))
        self._name = name
        self._lock = os.open(self.directory / (name + '.state.lock'),
                             os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        try:
            info = os.fstat(self._lock)
            need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0, 'IDENTITY_STORE_FILE')
            try:
                fcntl.flock(self._lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                if exc.errno in (errno.EWOULDBLOCK, errno.EAGAIN, errno.EACCES):
                    raise ValueError('IDENTITY_STORE_IN_USE') from None
                raise
        except BaseException:
            os.close(self._lock)
            self._lock = None
            raise

    def __repr__(self):
        return f'StateFile({str(self.path)!r}, kind={self.kind!r})'

    def close(self):
        """Release the lock. Later ``save`` calls are refused."""
        if self._lock is not None:
            os.close(self._lock)
            self._lock = None

    def load(self):
        """The saved state, or None when nothing has been saved yet."""
        need(self._lock is not None, 'IDENTITY_STORE_CLOSED')
        try:
            handle = os.open(self.path, os.O_RDONLY | os.O_NOFOLLOW)
        except FileNotFoundError:
            return None
        try:
            info = os.fstat(handle)
            need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o077 == 0
                 and info.st_size <= MAX_DOCUMENT, 'IDENTITY_STORE_FILE')
            chunks = []
            while True:
                chunk = os.read(handle, 1 << 20)
                if not chunk:
                    break
                chunks.append(chunk)
        finally:
            os.close(handle)
        try:
            document = json.loads(b''.join(chunks).decode('ascii'), object_pairs_hook=_pairs)
        except (UnicodeError, ValueError):
            raise ValueError('IDENTITY_STORE_DOCUMENT') from None
        need(type(document) is dict and set(document) == {'version', 'kind', 'context', 'state', 'digest'},
             'IDENTITY_STORE_DOCUMENT')
        need(document['version'] == VERSION and document['kind'] == self.kind, 'IDENTITY_STORE_KIND')
        need(document['context'] == self.context, 'IDENTITY_STORE_CONTEXT')
        need(type(document['state']) is dict and document['digest'] == _digest(document['state']),
             'IDENTITY_STORE_DIGEST')
        return document['state']

    def save(self, state):
        """Atomically replace the document with ``state``. Returns once it is on disk."""
        need(self._lock is not None, 'IDENTITY_STORE_CLOSED')
        need(type(state) is dict, 'IDENTITY_STORE_DOCUMENT')
        raw = _wire({'version': VERSION, 'kind': self.kind, 'context': self.context, 'state': state,
                     'digest': _digest(state)})
        need(len(raw) <= MAX_DOCUMENT, 'IDENTITY_STORE_TOO_LARGE')
        temporary = self.directory / ('.' + self._name + '.' + secrets.token_hex(8) + '.tmp')
        handle = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            view = memoryview(raw)
            while view:
                view = view[os.write(handle, view):]
            os.fsync(handle)
            os.close(handle)
            handle = None
            os.replace(temporary, self.path)
        except BaseException:
            if handle is not None:
                os.close(handle)
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
            raise
        folder = os.open(self.directory, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(folder)
        finally:
            os.close(folder)


def profile():
    return {'version': VERSION, 'directory_mode': '0700', 'file_mode': '0600',
            'write': 'temporary file, fsync, os.replace, directory fsync',
            'binding': 'kind, context and a SHA-256 digest of the state', 'writers': 'ONE_PROCESS_FLOCK',
            'holds_bearer_secrets': False, 'replication': None, 'execution_authorized': False}
