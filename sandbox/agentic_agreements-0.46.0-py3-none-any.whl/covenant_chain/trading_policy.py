"""Trading limits on a reliance.GatedAdapter route (experimental).

Ported from PR 73 (WP-20, mandate_gate.py). The policy uses the field names
published for the open-covenant trading proxy: per-order cap, UTC-day notional
cap, daily loss stop, symbol allowlist, sides, order types, orders per minute,
a human-approval threshold and dry_run. Portions derived from
open-covenant/covenant, Copyright 2026 Covenant contributors, Apache-2.0; see NOTICE.

``TradingLimits.route`` wraps the owner's GatedAdapter callbacks, so every check
runs before the mandate wallet reserves anything and a refused order never
reaches the venue. Differences from PR 73's MandateGate:

- an operation the owner did not list as an order or a read is DENY_UNKNOWN_TOOL
  (PR 73 forwarded any tool not named like an order as a read);
- the UTC-day notional, the 60-second order window and the day's realized loss
  live in SQLite (WAL, synchronous=FULL, BEGIN IMMEDIATE) and survive restarts;
  an allowed effect id is idempotent on retry;
- grant, per-action and total ceilings stay in the mandate wallet, which
  enforces them atomically; bind_mandate_gate, limits_from_reliance and
  note_forwarded are not ported.

Amounts are whole USD integers. A float, a string, or both amount and notional
fail closed. Every decision is signed under COVENANT-TRADING-DECISION-0.1 and
verifies offline against the pinned gate key. Allowed orders count against the
day even when the wallet later refuses them: the counters never under-count.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json

from . import parity_ids as ids
from .crypto import digest, exact, integer, key, need, public_key, sign, verify
from .workflow_store import WorkflowStore, canonical

POLICY_FIELDS = frozenset(('venue', 'caps', 'risk', 'universe', 'order_types', 'rate', 'approvals', 'mode'))
DECISION_FIELDS = 'version code operation effect request_hash policy venue at day amount'
POLICY_LABEL = 'COVENANT-TRADING-POLICY-0.1'
MAX_ORDERS = 1_000_000
WINDOW = 60
DAY = 86400


def _text(value, limit):
    need(type(value) is str and 0 < len(value) <= limit and value.isascii() and value.isprintable(), 'TRADING_TEXT')


def _sorted_names(value, low, high, limit, code):
    need(type(value) is list and low <= len(value) <= high and all(type(x) is str for x in value)
         and value == sorted(set(value)), code)
    for name in value:
        _text(name, limit)


def validate_trading_policy(policy):
    """Accept the published policy shape. Unknown fields and floats fail closed."""
    need(type(policy) is dict, 'TRADING_POLICY')
    need(POLICY_FIELDS - {'mode'} <= set(policy) <= POLICY_FIELDS, 'TRADING_POLICY_FIELDS')
    _text(policy['venue'], 64)
    need(policy.get('mode', 'enforce') in ('dry_run', 'enforce'), 'TRADING_MODE')
    caps = policy['caps']
    exact(caps, 'per_order_usd daily_notional_usd')
    integer(caps['per_order_usd'], True)
    integer(caps['daily_notional_usd'], True)
    need(caps['per_order_usd'] <= caps['daily_notional_usd'], 'TRADING_CAPS')
    exact(policy['risk'], 'daily_loss_stop_usd')
    integer(policy['risk']['daily_loss_stop_usd'], True)
    universe = policy['universe']
    exact(universe, 'allow sides')
    _sorted_names(universe['allow'], 1, 64, 32, 'TRADING_ALLOWLIST')
    sides = universe['sides']
    need(type(sides) is list and all(type(x) is str for x in sides) and set(sides) <= {'buy', 'sell'}, 'TRADING_SIDES')
    _sorted_names(sides, 1, 2, 4, 'TRADING_SIDES')
    _sorted_names(policy['order_types'], 1, 8, 32, 'TRADING_ORDER_TYPES')
    exact(policy['rate'], 'max_orders_per_min')
    integer(policy['rate']['max_orders_per_min'], True)
    need(policy['rate']['max_orders_per_min'] <= 10000, 'TRADING_RATE')
    exact(policy['approvals'], 'require_human_over_usd')
    integer(policy['approvals']['require_human_over_usd'])
    return True


def policy_id(policy):
    validate_trading_policy(policy)
    return digest(POLICY_LABEL, policy)


def order_terms(arguments):
    """symbol, side, order_type and exactly one whole-USD amount or notional; None when unreadable.

    Owner charge callbacks can use this so the wallet exposure and the trading
    counters read the same field. Venues that size orders differently need their
    own owner adapter in front of this route.
    """
    if type(arguments) is not dict:
        return None
    sizes = [arguments[name] for name in ('amount', 'notional') if name in arguments]
    names = [arguments.get(name) for name in ('symbol', 'side', 'order_type')]
    if len(sizes) != 1 or any(type(value) is not str for value in names):
        return None
    amount = sizes[0]
    if type(amount) is not int or not 1 <= amount <= 2**53 - 1:
        return None
    return {'symbol': names[0], 'side': names[1], 'order_type': names[2], 'amount': amount}


def _operation(request):
    need(type(request) is dict and set(request) == {'protocol', 'operation', 'parameters'}
         and type(request['protocol']) is str and type(request['parameters']) is dict, 'TRADING_REQUEST')
    operation = request['operation']
    need(type(operation) is str and 0 < len(operation) <= 128 and operation.isascii() and operation.isprintable(),
         'TRADING_REQUEST')
    parameters = request['parameters']
    return operation, parameters.get('arguments') if request['protocol'] == 'MCP' else parameters


class TradingRefusal(ValueError):
    """Raised by a route before the wallet runs. ``decision`` is the signed refusal or dry run."""

    def __init__(self, decision):
        super().__init__(decision['code'])
        self.code = decision['code']
        self.decision = decision


class TradingLimits:
    """Owner-held trading checks with durable counters. One directory per venue.

    ``orders`` and ``reads`` are the owner's adapter operation aliases. Anything
    else is refused. ``clock`` returns integer UTC seconds; a rewind refuses.
    """

    def __init__(self, directory, policy, *, signing_key, clock, orders, reads=(), realized_loss=None):
        validate_trading_policy(policy)
        need(signing_key is not None and callable(getattr(signing_key, 'sign', None)) and callable(clock),
             'TRADING_OWNER')
        need(type(orders) in (list, tuple) and type(reads) in (list, tuple), 'TRADING_OPERATIONS')
        names = [*orders, *reads]
        need(orders and len(names) <= 64 and len(set(names)) == len(names)
             and all(type(n) is str and 0 < len(n) <= 128 and n.isascii() and n.isprintable() for n in names),
             'TRADING_OPERATIONS')
        self.policy = deepcopy(policy)
        self.policy_id = policy_id(policy)
        self.orders, self.reads = frozenset(orders), frozenset(reads)
        self.signing_key, self.clock = signing_key, clock
        self.signer = public_key(signing_key)
        self.store = WorkflowStore(directory, {'version': ids.TRADING_STORE_VERSION, 'venue': policy['venue']})
        try:
            db = self.store.db
            db.execute('CREATE TABLE IF NOT EXISTS trading_orders(effect TEXT PRIMARY KEY, request_hash TEXT NOT NULL, '
                       'at INTEGER NOT NULL, day INTEGER NOT NULL, amount INTEGER NOT NULL, decision TEXT NOT NULL)')
            db.execute('CREATE INDEX IF NOT EXISTS trading_orders_day ON trading_orders(day)')
            db.execute('CREATE INDEX IF NOT EXISTS trading_orders_at ON trading_orders(at)')
            db.execute('CREATE TABLE IF NOT EXISTS trading_losses(day INTEGER PRIMARY KEY, amount INTEGER NOT NULL, '
                       'at INTEGER NOT NULL)')
            for action in ('UPDATE', 'DELETE'):
                db.execute(f"CREATE TRIGGER IF NOT EXISTS trading_orders_no_{action.lower()} BEFORE {action} ON "
                           "trading_orders BEGIN SELECT RAISE(ABORT,'TRADING_APPEND_ONLY'); END")
            if realized_loss is not None:
                self.set_realized_loss(realized_loss)
        except BaseException:
            self.store.close()
            raise

    def _clock(self):
        now = self.clock()
        integer(now)
        return now

    def _now(self, db):
        now = self._clock()
        last = db.execute('SELECT max(at) FROM (SELECT max(at) AS at FROM trading_orders '
                          'UNION ALL SELECT max(at) FROM trading_losses)').fetchone()[0]
        need(last is None or now >= last, 'TRADING_CLOCK_REWIND')
        return now

    @contextmanager
    def _transaction(self):
        db = self.store.db
        db.execute('BEGIN IMMEDIATE')
        try:
            yield db
            db.execute('COMMIT')
        except BaseException:
            db.execute('ROLLBACK')
            raise

    def _decision(self, code, operation, effect, request_hash, now, amount=None):
        body = {'version': ids.TRADING_DECISION_VERSION, 'code': code, 'operation': operation, 'effect': effect,
                'request_hash': request_hash, 'policy': self.policy_id, 'venue': self.policy['venue'],
                'at': now, 'day': now // DAY, 'amount': amount}
        receipt = {'body': body, 'signer': self.signer,
                   'signature': sign(self.signing_key, ids.TRADING_DECISION_DOMAIN, body)}
        return {'ok': code in ids.FORWARD_CODES, 'code': code, 'forward': code in ids.FORWARD_CODES,
                'receipt': receipt, 'anchor': digest(ids.TRADING_ANCHOR_DOMAIN, body),
                'next_action': ids.remediation(code), 'replayed': False, 'execution_authorized': False}

    def _order(self, db, operation, effect, request_hash, now, terms):
        policy = self.policy
        if terms is None:
            return ids.CODE_FAIL_CLOSED, None
        amount = terms['amount']
        if (terms['symbol'] not in policy['universe']['allow'] or terms['side'] not in policy['universe']['sides']
                or terms['order_type'] not in policy['order_types']):
            return ids.CODE_DENY_ALLOWLIST, amount
        if amount > policy['caps']['per_order_usd']:
            return ids.CODE_DENY_PER_CALL, amount
        day = now // DAY
        loss = db.execute('SELECT amount FROM trading_losses WHERE day=?', (day,)).fetchone()
        if loss is None:
            return ids.CODE_DENY_LOSS_UNKNOWN, amount
        if loss[0] >= policy['risk']['daily_loss_stop_usd']:
            return ids.CODE_DENY_LOSS, amount
        spent = db.execute('SELECT coalesce(sum(amount),0) FROM trading_orders WHERE day=?', (day,)).fetchone()[0]
        if spent + amount > policy['caps']['daily_notional_usd']:
            return ids.CODE_DENY_DAILY, amount
        recent = db.execute('SELECT count(*) FROM trading_orders WHERE at>? AND at<=?', (now - WINDOW, now)).fetchone()[0]
        if recent >= policy['rate']['max_orders_per_min']:
            return ids.CODE_DENY_RATE, amount
        # A person cannot waive a cap: ask only after every hard limit passed.
        if amount >= policy['approvals']['require_human_over_usd']:
            return ids.CODE_NEEDS_HUMAN, amount
        if policy.get('mode') == 'dry_run':
            return ids.CODE_ALLOW_DRY_RUN, amount
        return ids.CODE_ALLOW, amount

    def decide(self, effect_id, request):
        """Signed decision for one adapter request. Only an ALLOW order is recorded."""
        key(effect_id)
        operation, arguments = _operation(request)
        request_hash = hashlib.sha256(canonical(request)).hexdigest()
        if operation in self.reads:
            return self._decision(ids.CODE_ALLOW_READ, operation, effect_id, request_hash, self._clock())
        if operation not in self.orders:
            return self._decision(ids.CODE_DENY_UNKNOWN_TOOL, operation, effect_id, request_hash, self._clock())
        with self._transaction() as db:
            row = db.execute('SELECT request_hash, decision FROM trading_orders WHERE effect=?', (effect_id,)).fetchone()
            if row is not None:
                need(row[0] == request_hash, 'TRADING_EFFECT_CHANGED')
                stored = json.loads(row[1])
                # A replay forwards only under the policy that allowed it; observe the effect instead.
                need(stored['receipt']['body']['policy'] == self.policy_id, 'TRADING_POLICY_CHANGED')
                return {**stored, 'replayed': True}
            now = self._now(db)
            code, amount = self._order(db, operation, effect_id, request_hash, now, order_terms(arguments))
            decision = self._decision(code, operation, effect_id, request_hash, now, amount)
            if code == ids.CODE_ALLOW:
                count = db.execute('SELECT coalesce(max(rowid),0) FROM trading_orders').fetchone()[0]
                need(count < MAX_ORDERS, 'TRADING_STORE_QUOTA')
                db.execute('INSERT INTO trading_orders VALUES (?,?,?,?,?,?)',
                           (effect_id, request_hash, now, now // DAY, amount, canonical(decision).decode('ascii')))
        return decision

    def route(self, authorize, charge):
        """Callbacks for reliance.gated_registry: trading checks run before the owner's authorize."""
        need(callable(authorize) and callable(charge), 'TRADING_OWNER')

        def checked(effect_id, request):
            decision = self.decide(effect_id, request)
            if not decision['forward']:
                raise TradingRefusal(decision)
            return authorize(effect_id, request)
        return {'authorize': checked, 'charge': charge}

    def set_realized_loss(self, amount):
        """Owner feed: the realized loss for the current UTC day, in whole USD. Without it orders refuse."""
        integer(amount)
        with self._transaction() as db:
            now = self._now(db)
            db.execute('INSERT INTO trading_losses VALUES (?,?,?) ON CONFLICT(day) DO UPDATE SET '
                       'amount=excluded.amount, at=excluded.at', (now // DAY, amount, now))
        return {'day': now // DAY, 'realized_loss_usd': amount, 'execution_authorized': False}

    def inspect(self):
        with self._transaction() as db:
            now = self._now(db)
            day = now // DAY
            spent = db.execute('SELECT coalesce(sum(amount),0) FROM trading_orders WHERE day=?', (day,)).fetchone()[0]
            recent = db.execute('SELECT count(*) FROM trading_orders WHERE at>? AND at<=?', (now - WINDOW, now)).fetchone()[0]
            loss = db.execute('SELECT amount FROM trading_losses WHERE day=?', (day,)).fetchone()
        policy = self.policy
        return {'venue': policy['venue'], 'policy': self.policy_id, 'signer': self.signer, 'day': day,
                'spent_today_usd': spent, 'daily_notional_usd': policy['caps']['daily_notional_usd'],
                'orders_last_minute': recent, 'max_orders_per_min': policy['rate']['max_orders_per_min'],
                'realized_loss_usd': None if loss is None else loss[0],
                'daily_loss_stop_usd': policy['risk']['daily_loss_stop_usd'],
                'mode': policy.get('mode', 'enforce'), 'execution_authorized': False}

    def close(self):
        self.store.close()


def verify_decision(receipt, *, signer):
    """Offline check of a signed decision against the pinned gate key."""
    exact(receipt, 'body signer signature')
    body = receipt['body']
    exact(body, DECISION_FIELDS)
    need(body['version'] == ids.TRADING_DECISION_VERSION, 'TRADING_RECEIPT_VERSION')
    need(receipt['signer'] == signer, 'TRADING_SIGNER_NOT_PINNED')
    verify(signer, ids.TRADING_DECISION_DOMAIN, body, receipt['signature'])
    return {'ok': True, 'code': ids.CODE_VERIFIED, 'decision': body['code'], 'effect': body['effect'],
            'anchor': digest(ids.TRADING_ANCHOR_DOMAIN, body), 'execution_authorized': False}
