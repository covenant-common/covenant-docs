"""On-demand principal schemas; caller-supplied state is never adopted trust."""
from copy import deepcopy
from .crypto import need

REF = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
PARTY = {'type': ['string', 'object'], 'description': 'Verification key accepted by the installed signature suite; a display name is not a key.'}
INT = {'type': 'integer', 'minimum': 0, 'maximum': 2**53 - 1}
POS = {**INT, 'minimum': 1}
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 80}


def obj(properties, required=None):
    return {'type': 'object', 'properties': properties,
            'required': list(properties) if required is None else list(required), 'additionalProperties': False}


def amounts(length=8, key_length=80):
    return {'type': 'object', 'minProperties': 1, 'maxProperties': length,
            'propertyNames': {'type': 'string', 'minLength': 1, 'maxLength': key_length},
            'additionalProperties': POS}


def schemas():
    scope = {'principal': PARTY, 'agent': PARTY, 'grant': REF, 'permit': REF,
        'action': TEXT, 'context': REF, 'spend': amounts(), 'expiry': INT,
        'effects': {'type': 'array', 'minItems': 1, 'items': {'enum': ['AUTHORIZE', 'CONSUME', 'TRANSFER']}},
        'profiles': {'type': 'array', 'minItems': 1, 'items': {}},
        'counterparties': {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': PARTY},
        'window': {**POS, 'maximum': 10000}}
    policy = obj({'version': {'const': 'covenant-principal-override/1.0'}, **scope})
    draft = dict(scope); draft['action_name'] = draft.pop('action')
    terms = obj({'chain': REF, 'principal': PARTY, 'agent': PARTY, 'counterparty': PARTY,
        'mandate': {'type': ['string', 'null'], 'pattern': '^[0-9a-f]{64}$'},
        'profile': TEXT, 'resource': TEXT, 'quantity': POS, 'effect': TEXT,
        'destination': {'type': 'string'}, 'executor': PARTY, 'resolver': PARTY,
        'appeal_resolver': PARTY, 'deadline': INT, 'challenge_blocks': POS,
        'timeout': {'enum': ['RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION']}, 'terms_hash': REF})
    reliance_policy = obj({'version': {'const': 'covenant-mandate-wallet/0.1'}, 'domain': REF,
        'principal': PARTY, 'not_before': INT, 'expires': POS, 'limits': amounts(32,128),
        'per_action': amounts(32,128), 'adapters': {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': REF}, 'nonce': REF})
    intent = obj({'version': {'const': 'covenant-reliance-intent/0.1'}, 'wallet': REF,
        'subject': PARTY, 'adapter': REF, 'effect': REF, 'request_hash': REF,
        'allocations': amounts(32,128), 'not_before': INT, 'expires': POS, 'nonce': REF})
    return {'draft': obj(draft), 'review': obj({'state': {'type': 'object',
            'description': 'Caller-supplied native state snapshot; freshness and provenance are not established.',
            'properties': {'chain': REF, 'grants': {'type': 'object'}, 'permissions': {'type': 'object'}},
            'required': ['chain', 'grants', 'permissions']}, 'terms': terms, 'policy': policy,
            'signature': {'type': ['string', 'object']}, 'height': POS}),
        'narrow': obj({'policy': reliance_policy, 'intent': intent, 'grant_remaining': amounts(32,128)}),
        'kill': obj({'reliance_state': {'type': ['string', 'null'], 'enum': ['HELD', None]}}, ())}


def describe():
    return {'format': 'covenant-principal-tool-guide/0.1', 'parameter_schemas': schemas(),
        'schemas': 'Complete recommended arguments; legacy draft defaults remain for compatibility.',
        'profile_boundary': 'NATIVE_GIVE_AND_PERMIT_NOT_BILATERAL_LOCAL_MANDATE',
        'steps': ['OWNER_SELECTS_NATIVE_CHAIN_AND_CURRENT_VERIFIED_STATE',
            'OWNER_SUBMITS_AND_CONFIRMS_GIVE_AND_PERMIT_USING_ITS_ADOPTED_HOST',
            'DRAFT_EXACT_POLICY_WITH_RETURNED_GRANT_AND_PERMIT_IDS',
            'PRINCIPAL_SIGNS_COVENANT-PRINCIPAL-OVERRIDE-1.0_OVER_EXACT_POLICY',
            'REVIEW_TERMS_AGAINST_SUPPLIED_STATE',
            'OWNER_GATE_RECHECKS_CURRENT_STATE_BEFORE_ANY_EFFECT'],
        'draft_result': 'RAW_UNSIGNED_POLICY; pass the entire returned policy to owner custody for exact signing. No wrapper fields are inserted into this historical signing body.',
        'authorize': 'Legacy missing-grant demonstration; it does not inspect or authorize supplied terms. Use review for an actual supplied snapshot.',
        'kill': 'Revocation plan only; no live grant is revoked and no existing agreement is unbound.',
        'review': 'A passing review checks a signed policy against supplied state, not its authenticity or freshness.',
        'bilateral': {'module': 'covenant_agent.verbs', 'helper': 'sign_mandate',
            'fields': ['holder','unit','limit','expires','rails','effects'],
            'boundary': 'Separate principal-signed local mandate, not a native grant or automatically adopted by these tools.'},
        'execution_authorized': False, 'state_adopted': False, 'submitted': False}


def review(parameters):
    from .tool_input import validate_schema
    from .principal import authorize_bind
    validate_schema(parameters, schemas()['review'])
    p = deepcopy(parameters)
    need(p['state']['chain'] == p['terms']['chain'], 'PRINCIPAL_CHAIN_MISMATCH')
    try:
        result = authorize_bind(p['state'], p['terms'], p['policy'], p['signature'], p['height'])
    except (KeyError, TypeError, AttributeError, IndexError):
        raise ValueError('PRINCIPAL_STATE_SHAPE') from None
    need(result['authorized'] is True, 'PRINCIPAL_REVIEW')
    return {'format': 'covenant-principal-snapshot-review/0.1',
        'matches_supplied_state': True, 'policy_signature_verified': True,
        'state_provenance': 'CALLER_SUPPLIED_NOT_VERIFIED', 'state_freshness': 'UNKNOWN',
        'live_authority_established': False, 'grant': result['grant'],
        'execution_authorized': False, 'state_adopted': False, 'submitted': False}
