"""Bind an ATR hash into the field each rail already has, including an offline voucher.

Maturity: experimental. Off unless the host passes ``enabled=True`` (host flag
``atr_binding``). ``bind`` writes H into the rail's own carrier field;
``recover`` reads it back from one supplied settlement record. ``recover`` is a
cross-check of that record's fields, not an observation of the rail: it opens no
connection and proves nothing about what a chain or a payee saw. Only the hash
is placed in the carrier. Nothing here runs inside ``apply_transaction``.

``BoundAdapter`` wraps an owner-installed rail adapter. Its ``execute`` recovers
H from the carrier passed with the request and refuses before the inner
``execute`` when H is absent or differs from the request's ``atr_hash``. The
wrapper checks the carrier, not the inner request's own fields: build a rail
request that carries the hash itself (EIP-3009 authorization nonce, Solana memo)
from the same ``bind`` output.

Carrier shapes follow the Apache-2.0 LCP placements (see NOTICE): EIP-3009 uses
H as the authorization nonce and expects the same nonce in the AuthorizationUsed
event; Solana carries one SPL Memo of ``lcp:sha256:0x...`` (LCP section 8.1);
Stellar uses the first 8 bytes of H as the muxed id and echoes H beside it. The
offline carrier reuses covenant_chain.offline_carriers framing.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847).
"""
from __future__ import annotations

import json
from copy import deepcopy

from .atr import from_lcp_string, hash_equals, normalize, to_lcp_string
from .crypto import canonical, exact, key, need

RAILS = ('eip3009', 'solana-memo', 'stellar-mux', 'offline-ble')
SOLANA_MEMO_PROGRAM = 'MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr'
VOUCHER_LABEL = 'COVENANT-OFFLINE-ATR-VOUCHER-0.1'
MAX_VOUCHER_FRAMES = 4
FIELDS = {
    'eip3009': {'authorization', 'authorization_used'},
    'solana-memo': {'program', 'memo'},
    'stellar-mux': {'mux_id', 'extensions'},
    'offline-ble': {'frames'},
}
ASSURANCE = 'CARRIER_FIELDS_CROSS_CHECKED_NOT_RAIL_OBSERVED'


def _enabled(enabled):
    need(enabled is True, 'PLUGIN_DISABLED')


def bind(rail, atr_hash, *, enabled=False):
    """The carrier fields that place H on one rail."""
    _enabled(enabled)
    need(rail in RAILS, 'ATR_RAIL')
    h = normalize(atr_hash)
    if rail == 'eip3009':
        return {'rail': rail, 'authorization': {'nonce': h}, 'authorization_used': {'nonce': h}, 'h': h}
    if rail == 'solana-memo':
        memo = to_lcp_string(h)
        need(len(memo.encode('ascii')) == 77, 'ATR_MEMO')
        return {'rail': rail, 'program': SOLANA_MEMO_PROGRAM, 'memo': memo, 'h': h}
    if rail == 'stellar-mux':
        return {'rail': rail, 'mux_id': int(h[2:18], 16),
                'extensions': {'legalContext': {'type': 'sha256', 'value': h}}, 'h': h}
    from .offline import b64
    from .offline_carriers import frames
    payload = canonical({'version': VOUCHER_LABEL, 'h': h})
    return {'rail': rail, 'frames': [b64(frame) for frame in frames(payload)], 'h': h}


def recover(settlement, *, enabled=False):
    """H read back from one settlement record. ATR_HASH_MISMATCH when its fields disagree or are absent.

    A claimed ``h`` field is ignored: only the rail's own carrier fields count.
    """
    _enabled(enabled)
    need(type(settlement) is dict and settlement.get('rail') in RAILS, 'ATR_SETTLEMENT')
    rail = settlement['rail']
    present = set(settlement) - {'rail', 'h'}
    need(present == FIELDS[rail], 'ATR_HASH_MISMATCH')
    try:
        if rail == 'eip3009':
            exact(settlement['authorization'], 'nonce')
            exact(settlement['authorization_used'], 'nonce')
            nonce = settlement['authorization']['nonce']
            need(hash_equals(nonce, settlement['authorization_used']['nonce']), 'ATR_HASH_MISMATCH')
            return normalize(nonce)
        if rail == 'solana-memo':
            need(settlement['program'] == SOLANA_MEMO_PROGRAM, 'ATR_HASH_MISMATCH')
            found = from_lcp_string(settlement['memo'])
            need(found is not None, 'ATR_HASH_MISMATCH')
            return found
        if rail == 'stellar-mux':
            exact(settlement['extensions'], 'legalContext')
            echoed = settlement['extensions']['legalContext']
            exact(echoed, 'type value')
            need(echoed['type'] == 'sha256', 'ATR_HASH_MISMATCH')
            h = normalize(echoed['value'])
            mux = settlement['mux_id']
            need(type(mux) is int and mux == int(h[2:18], 16), 'ATR_HASH_MISMATCH')
            return h
        from .crypto import loads
        from .offline import unb64
        from .offline_carriers import Reassembler
        encoded = settlement['frames']
        need(type(encoded) is list and 1 <= len(encoded) <= MAX_VOUCHER_FRAMES, 'ATR_HASH_MISMATCH')
        box = Reassembler(max_sessions=1)
        raw = None
        for frame in encoded:
            need(raw is None, 'ATR_HASH_MISMATCH')
            raw = box.accept(unb64(frame, 1024), now=0)
        need(raw is not None, 'ATR_HASH_MISMATCH')
        value = loads(raw)
        exact(value, 'h version')
        need(value['version'] == VOUCHER_LABEL, 'ATR_HASH_MISMATCH')
        return normalize(value['h'])
    except ValueError:
        raise ValueError('ATR_HASH_MISMATCH') from None


def check(settlement, expected, *, enabled=False):
    """Compare a settlement's carrier with an expected H without executing anything."""
    _enabled(enabled)
    try:
        found = recover(settlement, enabled=True)
    except ValueError as exc:
        return {'match': False, 'code': str(exc), 'h': None, 'assurance': ASSURANCE, 'execution_authorized': False}
    match = hash_equals(found, expected)
    return {'match': match, 'code': None if match else 'ATR_HASH_MISMATCH', 'h': found, 'assurance': ASSURANCE,
            'execution_authorized': False}


class BoundAdapter:
    """Owner-side wrapper whose ``execute`` refuses before the inner rail on a missing or different H.

    ``execute`` takes ``{'atr_hash', 'settlement', 'request'}`` and passes only
    ``request`` to the inner adapter. The manifest differs from the inner one, so
    both can sit in one RailRegistry and the bound rail is identifiable.
    """

    def __init__(self, inner, *, enabled=False):
        _enabled(enabled)
        need(type(getattr(inner, 'manifest', None)) is dict and callable(getattr(inner, 'execute', None))
             and callable(getattr(inner, 'observe', None)), 'PAYMENT_RAIL')
        self.inner = inner
        manifest = deepcopy(inner.manifest)
        requirements = manifest.get('requirements')
        manifest['requirements'] = {**(requirements if type(requirements) is dict else {}),
                                    'atr_hash': 'RECOVERED_FROM_THE_CARRIER_BEFORE_EXECUTE'}
        self.manifest = manifest

    def bind(self, atr_hash, rail):
        return bind(rail, atr_hash, enabled=True)

    def recover(self, settlement):
        return recover(settlement, enabled=True)

    def execute(self, effect_id, request, *, crash=None):
        key(effect_id)
        exact(request, 'atr_hash request settlement')
        expected = normalize(request['atr_hash'])
        found = recover(request['settlement'], enabled=True)
        need(hash_equals(found, expected), 'ATR_HASH_MISMATCH')
        if crash is None:
            return self.inner.execute(effect_id, request['request'])
        return self.inner.execute(effect_id, request['request'], crash=crash)

    def observe(self, effect_id):
        return self.inner.observe(effect_id)

    def settle(self, effect_id, request, expected, settlement):
        """``execute`` with refusals as records: nothing reaches the inner rail on a refusal."""
        try:
            result = self.execute(effect_id, {'atr_hash': expected, 'request': request, 'settlement': settlement})
        except ValueError as exc:
            if str(exc) not in ('ATR_HASH_MISMATCH', 'ATR_SETTLEMENT', 'ATR_HASH', 'FIELDS', 'KEY'):
                raise
            return {'refused': True, 'code': str(exc), 'executed': False, 'assurance': ASSURANCE,
                    'execution_authorized': False}
        return {'refused': False, 'code': None, 'executed': True, 'h': normalize(expected), 'result': result,
                'assurance': ASSURANCE, 'execution_authorized': False}


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='ATR rail binding. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    args = parser.parse_args(argv)
    print(json.dumps({'plugin': 'atr_binding', 'enabled': bool(args.enabled), 'rails': list(RAILS),
                      'assurance': ASSURANCE, 'maturity': 'experimental', 'execution_authorized': False},
                     sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
