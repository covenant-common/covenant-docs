"""Experimental single-domain Tendermint-style consensus with certified succession.

Wire: signed {kind, body, signer, signature}; vote bodies contain chain,height,
round,block_id (None is nil). Proposals additionally carry block and valid_qc
(a list of prevotes from a strictly earlier round). A commit is an unsigned
{kind:'commit', block, certificate:{height,round,block_id,votes}} envelope:
its precommit votes independently authenticate it. No networking trust assumed.

Safety assumes <=f Byzantine validators, protected signing keys, intact durable
storage, and deterministic application validation. Optional bootstrap entries must
be independently verified by the caller before construction (Node does this). Not an audited implementation.
"""
import json
import math
import os
import sqlite3
from .storage import Journal
from pathlib import Path

from .crypto import canonical, digest, sign, verify, public_key, need

# Individual gossip is not an unbounded archive. Complete quorum certificates
# remain acceptable at any past round, but partial votes/proposals are retained
# only near the current round. One authenticated future-round vote per validator
# is enough to support catchup without allowing one Byzantine key to fill disk.
ROUND_RETENTION = 8


class Engine:
    def __init__(self, path, member, key, config, block_factory, block_validator,
                 base_timeout=1.0,next_config=None,bootstrap=None,proposal_admission=None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.member, self.key, self.config = member, key, json.loads(canonical(config))
        self.failed = False
        self.members = sorted(config['validators'])
        self.f = config['faults']
        need(type(self.f) is int and self.f >= 1, 'fault_bound')
        need(len(set(digest('COVENANT-VALIDATOR-KEY',v) for v in config['validators'].values())) == len(self.members), 'duplicate_validator_key')
        need(len(self.members) == 3 * self.f + 1, 'committee_size')
        self.active=member in self.members and public_key(key)==config['validators'][member]
        self.next_config=next_config
        need(type(base_timeout) in (int, float) and math.isfinite(base_timeout)
             and base_timeout > 0, 'timeout')
        self.quorum = 2 * self.f + 1
        self.factory, self.validator = block_factory, block_validator
        # Optional successor-profile admission (for example bounded live time).
        # Certified history still uses deterministic application validation only.
        self.proposal_admission = proposal_admission
        self.base_timeout, self.now, self.deadline = base_timeout, 0.0, None
        self.last_gossip = -1e100
        self.out = []
        pin = digest('COVENANT_CHAIN_CONFIG', config)
        self.journal=Journal(self.path)
        stored=self.journal.load()
        if stored is not None or self.path.exists():
            self.s = stored if stored is not None else json.loads(self.path.read_text())
            if stored is None:
                self.journal.log.pending.extend(self.s['commits']);self.s['commits']=self.journal.log
            need(self.s['config'] == pin and self.s['member'] == member, 'storage_identity')
        else:
            self.s = dict(config=pin, member=member, height=1, round=0,
                          parent='0' * 64, stage='propose', locked_round=-1,
                          locked_id=None, valid_round=-1, valid_id=None, valid_qc=[],
                          blocks={}, votes={}, proposals={}, signed={}, commits=self.journal.log)
            if bootstrap:
                self.s['commits'].pending.extend(bootstrap)
                self.s.update(height=len(bootstrap)+1,parent=self._block_id(bootstrap[-1]['block']))
            self._save()

        # Complete interrupted local bookkeeping from signatures durably saved
        # before emission. A crash between save(signature) and save(stage) must
        # not leave a precommitter stuck indefinitely in the prevote timeout.
        self.s.setdefault('round_evidence', {})
        self._prune_round_state()
        for message in self.s['signed'].values():
            body = message['body']
            if body['height'] != self.s['height']:
                continue
            if message['kind'] == 'proposal':
                self.s['blocks'][body['block_id']] = body['block']
                self.s['proposals'].setdefault(str(body['round']), message)
            else:
                self._record_vote(message)
        if self._has_signed('precommit'):
            self.s['stage'] = 'precommit'
        elif self._has_signed('prevote'):
            self.s['stage'] = 'prevote'
        self._save()

    def _save(self):
        if self.failed:
            raise RuntimeError('consensus_storage_failed')
        try:
            self.journal.save(self.s)
        except (OSError,sqlite3.Error) as exc:
            self.failed = True
            raise RuntimeError('consensus_storage_failed') from exc

    def _healthy(self):
        if self.failed:
            raise RuntimeError('consensus_storage_failed')

    def committed(self,start=1,limit=None):
        return self.s['commits'].read(start,limit)

    def status(self):
        return {k: self.s[k] for k in ('height', 'round', 'parent', 'stage', 'locked_round', 'locked_id')}

    def _block_id(self, block):
        return digest('COVENANT_CHAIN_BLOCK', block)

    def _proposer(self, height, round_):
        return self.members[(height - 1 + round_) % len(self.members)]

    def _duration(self):
        return self.base_timeout * (self.s['round'] + 1)

    def _stage(self, stage):
        self.s['stage'] = stage
        self.deadline = self.now + self._duration()

    def _signed(self, kind, body):
        need(self.active,'retired_validator')
        halt = self.s.get('migration_halt')
        if halt is not None:
            need(body['height'] <= halt['body']['height'], 'MIGRATION_SOURCE_HALTED')
        need(body['height']==self.s['height'],'signing_height_floor')
        need(body['round']==self.s['round'],'signing_round_floor')
        slot = f"{body['height']}:{body['round']}:{kind}"
        if slot in self.s['signed']:
            previous = self.s['signed'][slot]
            need(previous['body'] == body, 'double_sign_prevented')
            return previous
        msg = dict(kind=kind, body=body, signer=self.member,
                   signature=sign(self.key, 'COVENANT_CHAIN_' + kind.upper(), body))
        self.s['signed'][slot] = msg
        self._save()  # Never expose a signature before recording it durably.
        return msg

    def halt_for_migration(self, body):
        """Owner-invoked durable signer policy; no old block validity changes.

        Preserve this journal and signing-key custody. An older binary or a
        rolled-back journal is outside this local safeguard's trust boundary.
        """
        from .crypto import exact, integer, key
        from .world_migration import VERSION, HALT_LABEL
        self._healthy(); need(self.active, 'retired_validator')
        exact(body, 'version source_chain height block_id intent successor')
        need(body['version'] == VERSION and body['source_chain'] == self.config['chain_id'], 'MIGRATION_HALT_CONTEXT')
        integer(body['height'], True)
        for field in ('block_id', 'intent', 'successor'): key(body[field])
        need(body['height'] == self.s['height'] - 1 and body['block_id'] == self.s['parent'], 'MIGRATION_HALT_HEAD')
        need(all(row['body']['height'] <= body['height'] for row in self.s['signed'].values()), 'MIGRATION_ALREADY_SIGNED_LATER')
        prior = self.s.get('migration_halt')
        need(prior is None or prior['body'] == body, 'MIGRATION_HALT_CONFLICT')
        if prior is None:
            self.s['migration_halt'] = {'body': json.loads(canonical(body)), 'signature': None}
            self._save()  # Pin the one successor before any halt signature exists.
        if self.s['migration_halt']['signature'] is None:
            self.s['migration_halt']['signature'] = sign(self.key, HALT_LABEL, body)
            self._save()  # A failed save releases no signature; retry only this body.
        return json.loads(canonical({'signer': self.member, 'signature': self.s['migration_halt']['signature']}))

    def _body(self, block_id):
        return dict(chain=self.config['chain_id'], height=self.s['height'],
                    round=self.s['round'], block_id=block_id)

    def _has_signed(self, kind):
        return f"{self.s['height']}:{self.s['round']}:{kind}" in self.s['signed']

    def _vote(self, kind, block_id):
        if self._has_signed(kind):
            return
        msg = self._signed(kind, self._body(block_id))
        self._record_vote(msg)
        self.out.append(msg)
        self._stage('prevote' if kind == 'prevote' else 'precommit')
        self._save()

    def _authenticate(self, msg):
        need(type(msg) is dict and set(msg) == {'kind', 'body', 'signer', 'signature'}, 'message_shape')
        kind, body, member = msg['kind'], msg['body'], msg['signer']
        need(kind in ('proposal', 'prevote', 'precommit'), 'message_kind')
        need(member in self.config['validators'], 'unknown_validator')
        need(type(body) is dict and body.get('chain') == self.config['chain_id'], 'wrong_chain')
        fields = {'chain', 'height', 'round', 'block_id'}
        if kind == 'proposal':
            fields |= {'block', 'valid_qc'}
        need(set(body) == fields, 'message_fields')
        need(type(body['height']) is int and body['height'] > 0, 'height')
        need(type(body['round']) is int and 0 <= body['round'] < 2**31, 'round')
        bid = body['block_id']
        need(bid is None or (type(bid) is str and len(bid) == 64 and all(c in '0123456789abcdef' for c in bid)), 'block_id')
        verify(self.config['validators'][member], 'COVENANT_CHAIN_' + kind.upper(), body, msg['signature'])

    def authenticate_ingress(self, msg):
        """Authenticate a queue candidate without altering consensus state.

        Certified commits have a quorum certificate, not a single outer signer.
        Full state-transition checks still run at receive/accept_commit.
        """
        if type(msg) is dict and msg.get('kind') == 'commit':
            need(set(msg) == {'kind', 'block', 'certificate'}, 'commit_shape')
            c = msg['certificate']
            need(type(c) is dict and set(c) == {'height', 'round', 'block_id', 'votes'}, 'certificate_shape')
            need(type(c['height']) is int and c['height'] > 0 and
                 type(c['round']) is int and 0 <= c['round'] < 2**31, 'certificate_numbers')
            need(type(msg['block']) is dict and msg['block'].get('chain') == self.config['chain_id'] and
                 msg['block'].get('height') == c['height'], 'commit_context')
            need(c['block_id'] == self._block_id(msg['block']), 'commit_id')
            self._qc(c['votes'], 'precommit', c['height'], c['round'], c['block_id'])
        else:
            self._authenticate(msg)

    def _qc(self, votes, kind, height, round_, bid):
        need(type(votes) is list and self.quorum <= len(votes) <= len(self.members), 'quorum')
        seen = set()
        for vote in votes:
            self._authenticate(vote)
            need(vote['kind'] == kind and vote['body'] == dict(chain=self.config['chain_id'], height=height, round=round_, block_id=bid), 'qc_context')
            need(vote['signer'] not in seen, 'duplicate_vote')
            seen.add(vote['signer'])
        return True

    def _valid_block(self, block):
        # `time` is present only after proof-freshness activation. The application
        # validator accepts or rejects it; historical blocks keep the five keys.
        keys = set(block) if type(block) is dict else set()
        base = {'chain', 'height', 'parent', 'txs', 'state_root'}
        need(keys == base or keys == base | {'time'}, 'block_shape')
        need(block['chain'] == self.config['chain_id'] and type(block['height']) is int and block['height'] == self.s['height'] and block['parent'] == self.s['parent'], 'block_context')
        need(self.validator(block, self.s['height'], self.s['parent']) is not False, 'invalid_application_block')

    def _record_vote(self, msg):
        b = msg['body']
        if not self._retained_round(b['round']):
            return
        slot = f"{b['round']}:{msg['kind']}"
        votes = self.s['votes'].setdefault(slot, {})
        # Count at most one vote per identity/round/stage. Equivocation cannot
        # increase quorum weight; any received certificate is checked separately.
        if msg['signer'] not in votes:
            votes[msg['signer']] = msg

    def _retained_round(self, round_):
        return abs(round_ - self.s['round']) <= ROUND_RETENTION

    def _observe_round(self, msg):
        """Retain only the greatest authenticated future claim per identity.

        The (f+1)-th highest claim has at least one honest supporter. Different
        validators need not happen to report exactly the same round to catch up.
        No single validator can force a jump, however large its claimed round.
        """
        r = msg['body']['round']
        evidence = self.s['round_evidence']
        if r > self.s['round'] and r > evidence.get(msg['signer'], {}).get('body', {}).get('round', -1):
            evidence[msg['signer']] = msg
        higher = sorted((m['body']['round'] for m in evidence.values()
                         if m['body']['round'] > self.s['round']), reverse=True)
        if len(higher) >= self.f + 1:
            self._enter_round(higher[self.f])

    def _prune_round_state(self):
        """Bound gossip state while preserving locks, valid QC and signing floor."""
        self.s['votes'] = {slot: votes for slot, votes in self.s['votes'].items()
                           if self._retained_round(int(slot.split(':')[0]))}
        self.s['proposals'] = {r: m for r, m in self.s['proposals'].items()
                               if self._retained_round(int(r))}
        self.s['signed'] = {slot: m for slot, m in self.s['signed'].items()
                            if m['body']['height'] == self.s['height'] and
                            self._retained_round(m['body']['round'])}
        keep = {m['body']['block_id'] for m in self.s['proposals'].values()}
        keep.update(x for x in (self.s['locked_id'], self.s['valid_id']) if x is not None)
        self.s['blocks'] = {bid: block for bid, block in self.s['blocks'].items() if bid in keep}
        self.s['round_evidence'] = {who: m for who, m in self.s.get('round_evidence', {}).items()
                                    if m['body']['round'] > self.s['round']}

    def _votes_for(self, round_, kind, bid):
        return [m for m in self.s['votes'].get(f'{round_}:{kind}', {}).values()
                if m['body']['block_id'] == bid]

    def _enter_round(self, round_):
        if round_ <= self.s['round']:
            return
        self.s['round'] = round_
        self._stage('propose')
        # Locks and highest valid QC survive round changes and nil votes.
        self._prune_round_state()
        self._save()

    def _propose(self):
        if self._proposer(self.s['height'], self.s['round']) != self.member or self._has_signed('proposal'):
            return
        block = (self.s['blocks'][self.s['valid_id']] if self.s['valid_id']
                 else self.factory(self.s['height'], self.s['parent']))
        if block is None:
            return
        self._valid_block(block)
        if self.proposal_admission is not None:
            self.proposal_admission(block, self.s['valid_qc'])
        bid = self._block_id(block)
        body = self._body(bid)
        body.update(block=block, valid_qc=self.s['valid_qc'])
        msg = self._signed('proposal', body)
        self.s['blocks'][bid] = block
        self.s['proposals'][str(self.s['round'])] = msg
        self._save()
        self.out.append(msg)

    def _drive(self):
        if not self.active:return
        # Bounded loop: each iteration either signs a new stage or commits.
        for _ in range(8):
            height = self.s['height']
            # Any-round precommit QC finalizes, even after a local timeout.
            for bid, block in list(self.s['blocks'].items()):
                for slot in list(self.s['votes']):
                    round_text, kind = slot.split(':')
                    if kind != 'precommit':
                        continue
                    round_ = int(round_text)
                    votes = self._votes_for(round_, kind, bid)
                    if len(votes) >= self.quorum:
                        cert = dict(height=height, round=round_, block_id=bid, votes=votes)
                        if self.accept_commit(block, cert):
                            self.out.append(dict(kind='commit', block=block, certificate=cert))
                        return
            self._propose()
            round_ = self.s['round']
            proposal = self.s['proposals'].get(str(round_))
            if proposal and not self._has_signed('prevote'):
                b = proposal['body']
                qc = b['valid_qc']
                valid_round = qc[0]['body']['round'] if qc else -1
                allowed = (self.s['locked_id'] in (None, b['block_id']) or
                           valid_round >= self.s['locked_round'])
                self._vote('prevote', b['block_id'] if allowed else None)
            changed = False
            # Observe valid value even if local timer already cast nil precommit.
            for bid in list(self.s['blocks']):
                votes = self._votes_for(round_, 'prevote', bid)
                if len(votes) >= self.quorum:
                    if self.s['valid_round'] < round_:
                        self.s.update(valid_round=round_, valid_id=bid, valid_qc=votes)
                        self._save()
                    if not self._has_signed('precommit'):
                        self.s.update(locked_round=round_, locked_id=bid)
                        self._save()
                        self._vote('precommit', bid)
                        changed = True
            if len(self._votes_for(round_, 'prevote', None)) >= self.quorum and not self._has_signed('precommit'):
                self._vote('precommit', None)
                changed = True
            if not changed:
                break

    def tick(self, now):
        self._healthy()
        need(now >= self.now, 'clock_regression')
        self.now = now
        if not self.active:return self._drain()
        if self.deadline is None:
            self.deadline = now + self._duration()
        self._drive()
        if now >= self.deadline:
            if self.s['stage'] == 'propose':
                self._vote('prevote', None)
            elif self.s['stage'] == 'prevote':
                self._vote('precommit', None)
            else:
                self._enter_round(self.s['round'] + 1)
            self._drive()
        if now - self.last_gossip >= self.base_timeout / 2:
            prefix = f"{self.s['height']}:{self.s['round']}:"
            self.out.extend(m for k, m in self.s['signed'].items() if k.startswith(prefix))
            # Rebroadcast the latest commit to lagging replicas.
            if self.s['commits']:
                c = self.s['commits'][-1]
                self.out.append(dict(kind='commit', **c))
            self.last_gossip = now
        return self._drain()

    def _drain(self):
        result, self.out = self.out, []
        return json.loads(json.dumps(result))

    def receive(self, msg):
        self._healthy()
        msg = json.loads(canonical(msg))
        if type(msg) is dict and msg.get('kind') == 'commit':
            need(set(msg) == {'kind', 'block', 'certificate'}, 'commit_shape')
            if self.accept_commit(msg['block'], msg['certificate']):
                self.out.append(msg)
            return self._drain()
        self._authenticate(msg)
        b = msg['body']
        if b['height'] != self.s['height']:
            return self._drain()
        if msg['kind'] == 'proposal':
            need(msg['signer'] == self._proposer(b['height'], b['round']), 'wrong_proposer')
            # Equivocating proposals never acquire extra durable storage weight.
            # A later complete commit certificate is verified separately.
            if not self._retained_round(b['round']) or str(b['round']) in self.s['proposals']:
                return self._drain()
            self._valid_block(b['block'])
            need(b['block_id'] == self._block_id(b['block']), 'proposal_id')
            qc = b['valid_qc']
            need(type(qc) is list, 'valid_qc')
            if qc:
                need(type(qc[0]) is dict and type(qc[0].get('body')) is dict and
                     type(qc[0]['body'].get('round')) is int, 'valid_qc_shape')
                vr = qc[0]['body']['round']
                need(vr < b['round'], 'qc_round')
                self._qc(qc, 'prevote', b['height'], vr, b['block_id'])
            if self.proposal_admission is not None:
                self.proposal_admission(b['block'], qc)
            self.s['blocks'][b['block_id']] = b['block']
            self.s['proposals'].setdefault(str(b['round']), msg)
        else:
            self._observe_round(msg)
            self._record_vote(msg)
        self._save()
        self._drive()
        return self._drain()

    def accept_commit(self, block, certificate):
        self._healthy()
        block = json.loads(canonical(block))
        certificate = json.loads(canonical(certificate))
        need(type(certificate) is dict and set(certificate) == {'height', 'round', 'block_id', 'votes'}, 'certificate_shape')
        c = certificate
        need(type(c['height']) is int and type(c['round']) is int, 'certificate_numbers')
        need(c['block_id'] == self._block_id(block), 'commit_id')
        self._qc(c['votes'], 'precommit', c['height'], c['round'], c['block_id'])
        if c['height'] < self.s['height']:
            prior = self.s['commits'][c['height'] - 1]
            need(self._block_id(prior['block']) == c['block_id'], 'conflicting_commit')
            return False
        need(c['height'] == self.s['height'], 'commit_gap')
        self._valid_block(block)
        cfg=self.next_config(block) if self.next_config else None
        self.s['commits'].append(dict(block=block, certificate=certificate))
        self.s.update(height=self.s['height'] + 1, round=0, parent=c['block_id'],
                      stage='propose', locked_round=-1, locked_id=None,
                      valid_round=-1, valid_id=None, valid_qc=[], blocks={}, votes={}, proposals={},signed={},round_evidence={})
        if cfg is not None:
            self.config=json.loads(canonical(cfg));self.members=sorted(cfg['validators']);self.f=cfg['faults'];self.quorum=2*self.f+1
            self.active=self.member in self.members and public_key(self.key)==cfg['validators'][self.member]
            self.s['config']=digest('COVENANT_CHAIN_CONFIG',cfg)
        self.deadline = self.now + self.base_timeout
        self._save()
        return True
