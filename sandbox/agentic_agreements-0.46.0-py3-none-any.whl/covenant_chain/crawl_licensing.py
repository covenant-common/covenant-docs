"""Experimental, opt-in publisher/crawler licensing from exact signed terms.

No fetching, crawling, signing, payment, connector installation or legal-rights
inference. Publishers assert the rights they offer; pins are owner-adopted,
not proof of domain control/title. AAP's existing application profile supplies
both-role meaning echoes and exact assent. ResourceObservationAdapter supplies
pinned payment assertions. WorkflowStore supplies a bounded private journal.
Its head is locally current only; an old valid whole-store restore is detectable
only against an independently retained head. An offline host cannot know a newer
revocation exists. Every new crawl needs a fresh owner-adopted issuer snapshot.
"""
from copy import deepcopy
import hashlib
import json

from covenant_language import agreement_application as app
from covenant_language import market_blueprints
# Shared with the RSL-shaped successor terms (urn:aap:crawl-terms:0.1); the checks are unchanged.
from .crawl_terms import _origin, _text, _url
from .crypto import exact, integer, key, need, verification_key, verify
from .resource_observations import verify_observation
from .workflow_store import WorkflowStore

PROFILE = 'urn:aap:crawl-licence:0.1'
OFFER_LABEL = 'AAP-CRAWL-OFFER-0.1'
STATUS_LABEL = 'AAP-CRAWL-STATUS-0.1'
RECEIPT_LABEL = 'AAP-CRAWL-RECEIPT-0.1'
RIGHTS = ('ARCHIVE','EVALUATE','INDEX','RAG','TRAIN')
FLAGS = {'execution_authorized':False,'access_authorized':False,'payment_authorized':False,
         'legal_rights_established':False,'world_truth':'NOT_ESTABLISHED'}
OFFER_FIELDS = 'version publisher origin resources rights purposes opens expires price unit rail max_crawls max_bytes policy nonce'
STATUS_FIELDS = 'version publisher origin sequence previous issued_at expires revoked'
REQUEST_FIELDS = 'crawl resource right purpose sha256 bytes'
BODY_FIELDS = 'version agreement application offer request at status_snapshot payment payment_reference'
TEMPLATE = ('Publisher/crawler licence {{profile}}. Signed offer {{offer_id}}: {{offer}}. '
            'Price for each crawl {{price}}; maximum crawl count {{max_crawls}}; maximum bytes {{max_bytes}}. '
            'Scope {{scope}}; purposes {{purposes}}; declared rights {{rights}}; window {{opens}} to {{expires}}. '
            'A fresh owner-adopted publisher status is required before every crawl. '
            'Rights and source observations remain assertions, never automatic access or payment authority.')


def _strings(value,code,allowed=None):
    need(type(value) is list and 1<=len(value)<=8,code)
    for item in value:
        _text(item,code,128)
        if allowed is not None:need(item in allowed,code)
    need(value==sorted(set(value)),code)


def policy_pin(kind,source,raw):
    """Pin supplied policy bytes. A signal or prose file is never inferred consent.

    TDMRep syntax is checked, but patterns/precedence and document/header/PDF
    merging are NOT evaluated. ai.txt is deliberately uninterpreted: different
    proposals share the name. No policy or referenced URL is fetched.
    """
    need(kind in ('TDMREP_JSON','AI_TXT_UNINTERPRETED'),'CRAWL_POLICY_KIND');_url(source)
    need(type(raw) is bytes and 0<len(raw)<=65536,'CRAWL_POLICY_SIZE')
    if kind=='TDMREP_JSON':
        from covenant_agent.commerce import document
        rows,_=document(raw,65536)
        need(type(rows) is list and 1<=len(rows)<=64,'CRAWL_TDMREP')
        for row in rows:
            need(type(row) is dict and {'location','tdm-reservation'}<=set(row)<=
                 {'location','tdm-reservation','tdm-policy'},'CRAWL_TDMREP')
            _text(row['location'],'CRAWL_TDMREP',1024)
            need(row['location'].startswith('/') and type(row['tdm-reservation']) is int and
                 row['tdm-reservation'] in (0,1),'CRAWL_TDMREP')
            if 'tdm-policy' in row:_url(row['tdm-policy'])
    return {'kind':kind,'source':source,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}


def validate_offer(body):
    need(len(app.canonical(body))<=16384,'CRAWL_OFFER_SIZE');exact(body,OFFER_FIELDS)
    need(body['version']==PROFILE,'CRAWL_PROFILE');verification_key(body['publisher']);_origin(body['origin'])
    need(type(body['resources']) is list and 1<=len(body['resources'])<=16,'CRAWL_RESOURCES')
    urls=[]
    for resource in body['resources']:
        exact(resource,'url sha256');_url(resource['url'],body['origin']);key(resource['sha256']);urls.append(resource['url'])
    need(len(set(urls))==len(urls),'CRAWL_RESOURCES')
    _strings(body['rights'],'CRAWL_RIGHTS',RIGHTS);_strings(body['purposes'],'CRAWL_PURPOSES')
    for field in ('opens','expires','price','max_crawls','max_bytes'):integer(body[field])
    need(body['expires']>body['opens'] and 1<=body['max_crawls']<=1000000 and
         1<=body['max_bytes']<=67108864 and body['price']*body['max_crawls']<=2**53-1,'CRAWL_LIMITS')
    _text(body['unit'],'CRAWL_UNIT',128);_text(body['rail'],'CRAWL_RAIL',128)
    need(body['rail'].startswith('urn:aap:rail:'),'CRAWL_RAIL');key(body['nonce'])
    need(type(body['policy']) is list and len(body['policy'])<=8,'CRAWL_POLICY')
    for pin in body['policy']:
        exact(pin,'kind source sha256 bytes');need(pin['kind'] in ('TDMREP_JSON','AI_TXT_UNINTERPRETED'),'CRAWL_POLICY_KIND')
        _url(pin['source'],body['origin']);key(pin['sha256']);integer(pin['bytes'],True);need(pin['bytes']<=65536,'CRAWL_POLICY_SIZE')
    return body


def offer_payload(body):
    validate_offer(body)
    return {'label':OFFER_LABEL,'body':deepcopy(body),'id':app.content_id(OFFER_LABEL,body),**FLAGS}


def status_payload(publisher,origin,sequence,previous,issued_at,expires,revoked):
    body=dict(version=PROFILE,publisher=publisher,origin=origin,sequence=sequence,previous=previous,
              issued_at=issued_at,expires=expires,revoked=revoked)
    _status_body(body)
    return {'label':STATUS_LABEL,'body':body,'id':app.content_id(STATUS_LABEL,body),**FLAGS}


def _status_body(body):
    exact(body,STATUS_FIELDS);need(body['version']==PROFILE,'CRAWL_PROFILE')
    verification_key(body['publisher']);_origin(body['origin']);integer(body['sequence']);integer(body['issued_at']);integer(body['expires'])
    need(body['expires']>body['issued_at'] and (body['sequence']==0)==(body['previous'] is None),'CRAWL_STATUS')
    if body['previous'] is not None:key(body['previous'])
    need(type(body['revoked']) is list and len(body['revoked'])<=256,'CRAWL_STATUS')
    for value in body['revoked']:key(value)
    need(body['revoked']==sorted(set(body['revoked'])),'CRAWL_STATUS')


def _application(offer,crawler,context):
    body=validate_offer(offer['body']);verification_key(crawler);key(context)
    terms={'profile':{'kind':'TEXT','value':PROFILE},'offer_id':{'kind':'HASH','value':app.content_id(OFFER_LABEL,body)},
           'offer':{'kind':'TEXT','value':app.canonical(offer).decode('ascii')},
           'price':{'kind':'MONEY','amount':body['price'],'unit':body['unit']},
           'scope':{'kind':'TEXT','value':app.canonical(body['resources']).decode('ascii')},
           'rights':{'kind':'TEXT','value':app.canonical(body['rights']).decode('ascii')},
           'purposes':{'kind':'TEXT','value':app.canonical(body['purposes']).decode('ascii')}}
    for name in ('opens','expires','max_crawls','max_bytes'):terms[name]={'kind':'INTEGER','value':body[name]}
    machine={'states':['ACTIVE','CLOSED'],'initial':'ACTIVE','terminals':['CLOSED'],'events':{'CLOSE':['buyer','seller']},
             'facts':[],'transitions':[{'from':'ACTIVE','event':'CLOSE','to':'CLOSED','guard':{},'release':[]}]}
    norms=[app.norm('buyer_stop','POWER','buyer','CLOSE'),app.norm('publisher_stop','POWER','seller','CLOSE')]
    made=app.draft('Publisher/crawler licence',{'buyer':crawler,'seller':body['publisher']},context,norms,machine,
                   {'amount':0,'unit':body['unit']},{'scope':{'kind':'HASH','value':app.content_id('AAP-CRAWL-SCOPE-0.1',body)}},
                   TEMPLATE,terms=terms)
    return made


class CrawlLicenceDesk:
    """Owner-installed configuration and journal. Tool arguments cannot supply it.

    Publishers: origin -> adopted public key. Observers: rail -> {source,key} for
    existing signed resource observations. No key material is held. Snapshot
    adoption and receipt recording are explicit owner SDK calls, not MCP tools.
    """
    def __init__(self,directory,publishers,observers,clock,*,max_age=300,expected_head=None):
        need(type(publishers) is dict and 1<=len(publishers)<=64 and type(observers) is dict and len(observers)<=16,'CRAWL_CONFIG')
        for origin,publisher in publishers.items():_origin(origin);verification_key(publisher)
        for rail,row in observers.items():
            _text(rail,'CRAWL_RAIL',128);exact(row,'source key');key(row['source']);verification_key(row['key'])
        need(callable(clock) and type(max_age) is int and 1<=max_age<=3600,'CRAWL_CONFIG')
        self.publishers=deepcopy(publishers);self.observers=deepcopy(observers);self.clock=clock;self.max_age=max_age
        self.configuration=app.content_id('AAP-CRAWL-CONFIG-0.1',{'publishers':publishers,'observers':observers,'max_age':max_age})
        self.store=WorkflowStore(directory,{'profile':PROFILE,'publishers':publishers,'observers':observers,'max_age':max_age})
        if expected_head is not None and self.head()!=expected_head:
            self.store.close();raise ValueError('CRAWL_JOURNAL_HEAD')

    def close(self):self.store.close()
    def now(self):
        now=self.clock();integer(now);return now
    def head(self):
        history=self.store.events();return history[-1]['id'] if history else '0'*64

    def _config(self):
        need(app.content_id('AAP-CRAWL-CONFIG-0.1',{'publishers':self.publishers,'observers':self.observers,'max_age':self.max_age})
             ==self.configuration,'CRAWL_CONFIG_CHANGED')

    def _offer(self,offer):
        self._config();exact(offer,'body signature');body=validate_offer(offer['body'])
        need(self.publishers.get(body['origin'])==body['publisher'],'CRAWL_PUBLISHER_NOT_ADOPTED')
        verify(body['publisher'],OFFER_LABEL,body,offer['signature'])
        return body,app.content_id(OFFER_LABEL,body)

    def _status(self,record,at):
        self._config();exact(record,'body signature');body=record['body'];_status_body(body)
        need(self.publishers.get(body['origin'])==body['publisher'],'CRAWL_PUBLISHER_NOT_ADOPTED')
        verify(body['publisher'],STATUS_LABEL,body,record['signature'])
        need(body['issued_at']<=at<body['expires'] and at-body['issued_at']<=self.max_age,'CRAWL_STATUS_STALE')
        return body,app.content_id(STATUS_LABEL,body)

    def adopt_status(self,record):
        """Explicit owner SDK adoption, never exposed as a tool or inferred from a URL."""
        now=self.now();body,ref=self._status(record,now)
        with self.store.exclusive():
            old=[e['body']['value']['snapshot'] for e in self.store.events() if e['body']['kind']=='CRAWL_STATUS' and e['body']['task']==body['origin']]
            if old:
                oldbody=old[-1]['body'];prior=app.content_id(STATUS_LABEL,oldbody)
                if prior==ref:return {'status':'IDEMPOTENT','snapshot':ref,'journal':self.head(),**FLAGS}
                need(body['sequence']==oldbody['sequence']+1 and body['previous']==prior,'CRAWL_STATUS_ROLLBACK_OR_FORK')
                need(set(oldbody['revoked'])<=set(body['revoked']),'CRAWL_STATUS_REVOCATION_REGRESSION')
            else:need(body['sequence']==0 and body['previous'] is None,'CRAWL_STATUS_INITIAL')
            self.store.append('CRAWL_STATUS',body['origin'],{'snapshot':record,'adopted_at':now})
            return {'status':'ADOPTED','snapshot':ref,'journal':self.head(),**FLAGS}

    def _current(self,origin,refs):
        old=[e['body']['value']['snapshot'] for e in self.store.events() if e['body']['kind']=='CRAWL_STATUS' and e['body']['task']==origin]
        need(bool(old),'CRAWL_STATUS_NOT_ADOPTED');body,ref=self._status(old[-1],self.now())
        need(not set(refs)&set(body['revoked']),'CRAWL_REVOKED')
        return ref

    def offers(self,offers,resource,right,purpose):
        need(type(offers) is list and len(offers)<=32,'CRAWL_OFFERS');_url(resource)
        _text(right,'CRAWL_RIGHTS',128);_text(purpose,'CRAWL_PURPOSES',128);rows=[];refused=[]
        for offer in offers:
            try:
                body,ref=self._offer(offer);self._current(body['origin'],[ref])
                need(body['opens']<=self.now()<body['expires'],'CRAWL_EXPIRED')
                need(resource in {r['url'] for r in body['resources']} and right in body['rights'] and purpose in body['purposes'],'CRAWL_SCOPE')
                rows.append({'offer':ref,'publisher':body['publisher'],'price':body['price'],'unit':body['unit'],'rail':body['rail']})
            except ValueError as exc:refused.append(str(exc))
        return {'offers':sorted(rows,key=lambda r:(r['unit'],r['price'],r['offer'])),'refused':refused,
                'price_comparison':'WITHIN_EXACT_UNIT_ONLY_NO_FX','currentness':'LATEST_LOCALLY_ADOPTED_FRESH_SNAPSHOT_NOT_GLOBAL',**FLAGS}

    def draft(self,offer,crawler,context):
        body,ref=self._offer(offer);self._current(body['origin'],[ref]);need(body['opens']<=self.now()<body['expires'],'CRAWL_EXPIRED')
        made=_application(offer,crawler,context);application=made['application'];report=app.rehearse(application)
        need(report['status']=='SAFE_WITHIN_MODEL','CRAWL_MODEL')
        return {**made,'profile':PROFILE,'offer':ref,'rehearsal':report,
                'echo_payloads':{role:app.echo_payload(application,role,application['acceptance']) for role in ('buyer','seller')},
                'next':'Both roles sign meaning echoes, call covenant_contract_application.prepare, then sign its exact assent payload. No payment/crawl authority follows.',**FLAGS}

    def _read(self,application):
        app.identifier(application);terms=application['terms'];need(terms.get('profile')=={'kind':'TEXT','value':PROFILE},'CRAWL_APPLICATION')
        exact(terms,'profile offer_id offer price scope rights purposes opens expires max_crawls max_bytes')
        need(set(application['parties'])=={'buyer','seller'},'CRAWL_APPLICATION')
        try:offer=json.loads(terms['offer']['value'])
        except (ValueError,TypeError):raise ValueError('CRAWL_APPLICATION') from None
        body,ref=self._offer(offer)
        expected=_application(offer,application['parties']['buyer'],application['context'])['application']
        need(app.canonical(application)==app.canonical(expected),'CRAWL_APPLICATION_CHANGED')
        return body,ref

    def _request(self,body,request):
        exact(request,REQUEST_FIELDS);key(request['crawl']);key(request['sha256']);integer(request['bytes'])
        _url(request['resource'],body['origin'])
        matches={r['url']:r['sha256'] for r in body['resources']}
        need(matches.get(request['resource'])==request['sha256'] and request['right'] in body['rights'] and
             request['purpose'] in body['purposes'] and request['bytes']<=body['max_bytes'],'CRAWL_SCOPE')

    def payment_request(self,application,agreement,request):
        body,_=self._read(application);self._request(body,request);key(agreement)
        query={'agreement':agreement,'crawl':request['crawl'],'amount':body['price'],'unit':body['unit'],
               'payer':application['parties']['buyer'],'payee':body['publisher']}
        return {'asset':market_blueprints.asset('payment',body['unit'],'minor-unit'),'query':query,
                'context':application['context'],'rail':body['rail'],'observer':deepcopy(self.observers.get(body['rail'])),
                'required':body['price']>0,'assurance':'PINNED_SOURCE_ASSERTION_NOT_BANK_OR_CHAIN_PROOF',**FLAGS}

    def _paid(self,application,agreement,request,payment,at):
        wanted=self.payment_request(application,agreement,request)
        if not wanted['required']:
            need(payment is None,'CRAWL_FREE_PAYMENT');return None,None
        need(wanted['observer'] is not None,'CRAWL_PAYMENT_SOURCE_NOT_ADOPTED');need(payment is not None,'CRAWL_PAYMENT_UNKNOWN')
        observer=wanted['observer'];checked=verify_observation(payment,wanted['asset'],wanted['query'],wanted['context'],
            observer['source'],observer['key'],at,self.max_age)
        need(checked['status']=='OBSERVED','CRAWL_PAYMENT_UNKNOWN');claim=checked['claim']
        exact(claim,'agreement crawl amount unit payer payee status reference')
        integer(claim['amount'])
        need(all(claim[k]==v for k,v in wanted['query'].items()) and claim['status']=='PAID','CRAWL_PAYMENT_CHANGED')
        _text(claim['reference'],'CRAWL_PAYMENT_REFERENCE',256)
        return checked['observation'],claim['reference']

    def _adoption(self,application,agreement,adoption):
        need(adoption is not None,'CRAWL_ASSENT_UNKNOWN');exact(adoption,'echoes approvals expected_closure')
        return app.verify(application,adoption['echoes'],adoption['approvals'],agreement,adoption['expected_closure'])

    def check(self,application,agreement,adoption,request,payment=None):
        body,ref=self._read(application);self._request(body,request);key(agreement);now=self.now()
        try:
            self._adoption(application,agreement,adoption)
            need(body['opens']<=now<body['expires'],'CRAWL_EXPIRED')
            snapshot=self._current(body['origin'],[ref,app.identifier(application),agreement])
            paid,reference=self._paid(application,agreement,request,payment,now)
            recorded=[e['body']['value'] for e in self.store.events() if e['body']['kind']=='CRAWL_RECEIPT']
            for row in recorded:
                prior=row['receipt']['body']
                need(not (prior['agreement']==agreement and prior['request']['crawl']==request['crawl']),'CRAWL_REPLAY')
                if reference is not None:
                    need(not (row['rail']==body['rail'] and prior['payment_reference']==reference),'CRAWL_PAYMENT_REUSED')
            used=sum(1 for row in recorded if row['receipt']['body']['agreement']==agreement)
            need(used<body['max_crawls'],'CRAWL_QUOTA')
        except ValueError as exc:
            return {'status':'UNKNOWN','reason':str(exc),'as_of':now,'currentness':'LOCAL_SNAPSHOT_ONLY',**FLAGS}
        return {'status':'READY_FOR_OWNER_REVIEW','status_snapshot':snapshot,'payment':paid,'payment_reference':reference,
                'remaining_local_crawls':body['max_crawls']-used,'as_of':now,'currentness':'LATEST_LOCALLY_ADOPTED_FRESH_SNAPSHOT_NOT_GLOBAL',**FLAGS}

    def receipt_payload(self,application,agreement,adoption,request,payment=None):
        checked=self.check(application,agreement,adoption,request,payment)
        need(checked['status']=='READY_FOR_OWNER_REVIEW',checked.get('reason','CRAWL_NOT_READY'))
        body={'version':PROFILE,'agreement':agreement,'application':app.identifier(application),
              'offer':application['terms']['offer_id']['value'],'request':deepcopy(request),'at':checked['as_of'],
              'status_snapshot':checked['status_snapshot'],'payment':checked['payment'],'payment_reference':checked['payment_reference']}
        return {'label':RECEIPT_LABEL,'body':body,'required_signers':deepcopy(application['parties']),**FLAGS}

    def verify_receipt(self,application,agreement,adoption,receipt,payment=None):
        body,offer=self._read(application);self._adoption(application,agreement,adoption)
        exact(receipt,'body signatures');value=receipt['body'];exact(value,BODY_FIELDS)
        need(value['version']==PROFILE and value['agreement']==agreement and value['application']==app.identifier(application)
             and value['offer']==offer,'CRAWL_RECEIPT_BINDING')
        self._request(body,value['request']);integer(value['at'])
        need(body['opens']<=value['at']<body['expires'] and value['at']<=self.now(),'CRAWL_RECEIPT_TIME')
        exact(receipt['signatures'],'buyer seller')
        for role in ('buyer','seller'):verify(application['parties'][role],RECEIPT_LABEL,value,receipt['signatures'][role])
        paid,reference=self._paid(application,agreement,value['request'],payment,value['at'])
        need(paid==value['payment'] and reference==value['payment_reference'],'CRAWL_PAYMENT_CHANGED')
        history=[e['body']['value'] for e in self.store.events() if e['body']['kind']=='CRAWL_STATUS' and
                 app.content_id(STATUS_LABEL,e['body']['value']['snapshot']['body'])==value['status_snapshot']]
        need(bool(history) and history[-1]['adopted_at']<=value['at'],'CRAWL_STATUS_HISTORY_UNKNOWN')
        snapshot,_=self._status(history[-1]['snapshot'],value['at'])
        need(snapshot['origin']==body['origin'] and not {offer,agreement,value['application']}&set(snapshot['revoked']),'CRAWL_REVOKED')
        return {'id':app.content_id(RECEIPT_LABEL,value),'signatures':'BOTH_PARTIES_VERIFIED','historical_snapshot':'LOCALLY_ADOPTED',
                'claim':'PARTIES_ASSERT_THIS_CRAWL_AND_ADOPTED_SOURCE_ASSERTS_PAYMENT_NOT_WORLD_TRUTH',**FLAGS}

    def record_receipt(self,application,agreement,adoption,receipt,payment=None):
        """Explicit owner SDK call; idempotent journal append, never a tool effect."""
        checked=self.verify_receipt(application,agreement,adoption,receipt,payment);value=receipt['body']
        with self.store.exclusive():
            old=[e['body']['value'] for e in self.store.events() if e['body']['kind']=='CRAWL_RECEIPT']
            for row in old:
                if row['id']==checked['id']:return {'status':'IDEMPOTENT','id':checked['id'],'journal':self.head(),**FLAGS}
                prior=row['receipt']['body']
                need(not (prior['agreement']==agreement and prior['request']['crawl']==value['request']['crawl']),'CRAWL_REPLAY')
            current=self.check(application,agreement,adoption,value['request'],payment)
            need(current['status']=='READY_FOR_OWNER_REVIEW',current.get('reason','CRAWL_NOT_READY'))
            body,_=self._read(application)
            if value['payment_reference'] is not None:
                need(not any(row['rail']==body['rail'] and row['receipt']['body']['payment_reference']==value['payment_reference'] for row in old),'CRAWL_PAYMENT_REUSED')
            self.store.append('CRAWL_RECEIPT',agreement,{'id':checked['id'],'rail':body['rail'],'receipt':receipt,'payment':payment})
            return {'status':'RECORDED','id':checked['id'],'journal':self.head(),**FLAGS}
