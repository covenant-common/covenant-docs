"""Portable account bundle. The same bytes move between hosted, peer and federated carriers.

The bundle holds public material, hash-addressed records, a causal export, light
pins and an archive anchor. Secrets stay out. A signed MOVED record says which
host descriptor the account left and which one it entered. The carrier mode is
outside the content hash, so a round trip keeps one content id.

archive.pack, light.export_light_bundle and ReceiptDAG.export are called by the
helpers below. Their formats are unchanged. LightClient.assess is not called.
"""
from __future__ import annotations

import hashlib

from .crypto import canonical, digest, exact, integer, key, need, sign, verify

VERSION = 'covenant-portable-bundle/1'
MOVED_VERSION = 'covenant-moved/1'
LABEL = 'COVENANT-PORTABLE-BUNDLE'
MOVED_LABEL = 'COVENANT-MOVED'
MODES = {'HOSTED', 'PEER', 'FEDERATED', 'HYBRID'}
CONTINUITY = 'covenant-authority-continuity/0.1'
LIGHT_PROFILE = 'covenant-native-light/0.1'
ARCHIVE_VERSION = 'covenant-native-archive/0.1'
SECRET_KEYS = {'private_key', 'secret', 'seed', 'mnemonic', 'key_file'}
BODY_FIELDS = 'v account continuity records causal light inclusion awards capability peer history'


def _scan(value, forbidden):
    if type(value) is dict:
        for name, item in value.items():
            need(name not in SECRET_KEYS, 'PORTABLE_SECRET')
            _scan(item, forbidden)
    elif type(value) is list:
        for item in value:
            _scan(item, forbidden)
    elif type(value) is str:
        for secret in forbidden:
            need(secret not in value, 'PORTABLE_SECRET')


def _sha256(obj):
    return hashlib.sha256(canonical(obj)).hexdigest()


def hashed_record(body):
    need(type(body) is dict, 'PORTABLE_RECORD')
    return {'sha256': _sha256(body), 'body': body}


def archive_anchor(path, genesis, entries, expected_chain, *, off_chain=()):
    """Call archive.pack and keep its anchor. The zip layout is the pack function's.

    ``off_chain`` lists SHA-256 hex of local off-chain documents that pack must refuse.
    """
    from .archive import pack, refuse_off_chain
    refuse_off_chain(genesis, entries, off_chain)
    packed = pack(path, genesis, entries, expected_chain)
    manifest = packed['manifest']
    need(manifest['version'] == ARCHIVE_VERSION, 'PORTABLE_ARCHIVE')
    piece = {
        'anchor_sha512': packed['anchor_sha512'],
        'version': manifest['version'],
        'height': manifest['height'],
        'head': manifest['head'],
    }
    need(len(piece['anchor_sha512']) == 128, 'PORTABLE_ARCHIVE')
    return piece


def light_pin(genesis, entries, table, record_key, from_epoch=0):
    """Hash a real light.export_light_bundle. The consumer still verifies that bundle itself."""
    from .light import PROFILE, export_light_bundle
    bundle = export_light_bundle(genesis, entries, table, record_key, from_epoch)
    need(bundle['profile'] == PROFILE == LIGHT_PROFILE, 'PORTABLE_LIGHT')
    key(bundle['chain'])
    return {'profile': bundle['profile'], 'chain': bundle['chain'], 'sha256': _sha256(bundle), 'bundle': bundle}


def causal_piece(dag):
    events = dag.export()
    need(type(events) is list, 'PORTABLE_CAUSAL')
    return {'domain': dag.domain, 'fingerprint': dag.fingerprint(), 'events': events}


def continuity_ref(policy_sha512):
    need(type(policy_sha512) is str and len(policy_sha512) == 128 and all(c in '0123456789abcdef' for c in policy_sha512), 'PORTABLE_CONTINUITY')
    return {'version': CONTINUITY, 'policy': policy_sha512}


def _records(records):
    need(type(records) is list and len(records) <= 256, 'PORTABLE_RECORD')
    cleaned = []
    for item in records:
        exact(item, 'sha256 body')
        key(item['sha256'])
        need(item['sha256'] == _sha256(item['body']), 'PORTABLE_RECORD')
        cleaned.append({'sha256': item['sha256'], 'body': item['body']})
    return cleaned


def _causal(causal):
    from .causal import event_id, validate
    exact(causal, 'domain fingerprint events')
    key(causal['domain'])
    key(causal['fingerprint'])
    events = causal['events']
    need(type(events) is list and len(events) <= 10000, 'PORTABLE_CAUSAL')
    ids = []
    for event in events:
        ids.append(validate(event, causal['domain']))
        need(event_id(event['body']) == ids[-1], 'PORTABLE_CAUSAL')
    need(digest('COVENANT-CAUSAL-SET-0.1', sorted(ids)) == causal['fingerprint'], 'PORTABLE_CAUSAL')
    return {'domain': causal['domain'], 'fingerprint': causal['fingerprint'], 'events': events}


def _light(light):
    exact(light, 'pins bundles')
    pins = light['pins']
    bundles = light['bundles']
    need(type(pins) is list and len(pins) <= 32, 'PORTABLE_LIGHT')
    need(type(bundles) is list and len(bundles) <= 32, 'PORTABLE_LIGHT')
    cleaned_pins = []
    for pin in pins:
        exact(pin, 'minimum_height')
        integer(pin['minimum_height'])
        cleaned_pins.append({'minimum_height': pin['minimum_height']})
    cleaned_bundles = []
    for bundle in bundles:
        exact(bundle, 'profile chain sha256')
        need(bundle['profile'] == LIGHT_PROFILE, 'PORTABLE_LIGHT')
        key(bundle['chain'])
        key(bundle['sha256'])
        cleaned_bundles.append({'profile': bundle['profile'], 'chain': bundle['chain'], 'sha256': bundle['sha256']})
    return {'pins': cleaned_pins, 'bundles': cleaned_bundles}


def _named(items, fields, code, limit):
    need(type(items) is list and len(items) <= limit, code)
    cleaned = []
    for item in items:
        exact(item, fields)
        for name in fields.split():
            if name == 'table':
                need(type(item[name]) is str and 1 <= len(item[name]) <= 64 and all(33 <= ord(c) <= 126 for c in item[name]), code)
            else:
                key(item[name])
        cleaned.append({name: item[name] for name in fields.split()})
    return cleaned


def _history(history):
    exact(history, 'anchor_sha512 version height head')
    need(type(history['anchor_sha512']) is str and len(history['anchor_sha512']) == 128 and all(c in '0123456789abcdef' for c in history['anchor_sha512']), 'PORTABLE_ARCHIVE')
    need(history['version'] == ARCHIVE_VERSION, 'PORTABLE_ARCHIVE')
    integer(history['height'])
    key(history['head'])
    return {
        'anchor_sha512': history['anchor_sha512'],
        'version': history['version'],
        'height': history['height'],
        'head': history['head'],
    }


def bundle_body(account, continuity, records, causal, light, inclusion, awards, capability_id, peer_id, history):
    key(account)
    exact(continuity, 'version policy')
    need(continuity['version'] == CONTINUITY, 'PORTABLE_CONTINUITY')
    need(type(continuity['policy']) is str and len(continuity['policy']) == 128 and all(c in '0123456789abcdef' for c in continuity['policy']), 'PORTABLE_CONTINUITY')
    key(capability_id)
    key(peer_id)
    body = {
        'v': VERSION,
        'account': account,
        'continuity': {'version': CONTINUITY, 'policy': continuity['policy']},
        'records': _records(records),
        'causal': _causal(causal),
        'light': _light(light),
        'inclusion': _named(inclusion, 'table key root', 'PORTABLE_INCLUSION', 64),
        'awards': _named(awards, 'sha256 anchor', 'PORTABLE_AWARD', 64),
        'capability': capability_id,
        'peer': peer_id,
        'history': _history(history),
    }
    canonical(body)
    return body


def content_id(body):
    exact(body, BODY_FIELDS)
    need(body['v'] == VERSION, 'PORTABLE_VERSION')
    return digest(LABEL, body)


def moved_body(account, from_host_key, to_descriptor_digest, sequence):
    key(account)
    key(from_host_key)
    key(to_descriptor_digest)
    integer(sequence)
    body = {
        'v': MOVED_VERSION,
        'account': account,
        'from_host_key': from_host_key,
        'to_descriptor_digest': to_descriptor_digest,
        'sequence': sequence,
    }
    canonical(body)
    return body


def sign_moved(private_key, account, from_host_key, to_descriptor_digest, sequence):
    from .crypto import public_key
    need(public_key(private_key) == account, 'MOVED_SIGNER')
    body = moved_body(account, from_host_key, to_descriptor_digest, sequence)
    return {'body': body, 'signature': sign(private_key, MOVED_LABEL, body)}


def verify_moved(envelope, account):
    exact(envelope, 'body signature')
    body = envelope['body']
    exact(body, 'v account from_host_key to_descriptor_digest sequence')
    cleaned = moved_body(body['account'], body['from_host_key'], body['to_descriptor_digest'], body['sequence'])
    need(cleaned == body and body['account'] == account, 'MOVED_ACCOUNT')
    verify(account, MOVED_LABEL, body, envelope['signature'])
    return body


def export_bundle(account, continuity, records, causal, light, inclusion, awards, capability_id, peer_id, history, mode, moved=None, secret=None):
    need(mode in MODES, 'PORTABLE_MODE')
    body = bundle_body(account, continuity, records, causal, light, inclusion, awards, capability_id, peer_id, history)
    forbidden = () if secret is None else (secret,)
    need(all(type(item) is str and len(item) >= 32 for item in forbidden), 'PORTABLE_SECRET')
    _scan(body, forbidden)
    envelope = {'body': body, 'content_id': content_id(body), 'mode': mode}
    if moved is not None:
        verify_moved(moved, account)
        _scan(moved, forbidden)
        envelope['moved'] = moved
    return envelope


def import_bundle(envelope, secret=None, light_bundles=None, archive_path=None):
    need(type(envelope) is dict and set(envelope) in ({'body', 'content_id', 'mode'}, {'body', 'content_id', 'mode', 'moved'}), 'PORTABLE_FIELDS')
    need(envelope['mode'] in MODES, 'PORTABLE_MODE')
    key(envelope['content_id'])
    body = bundle_body(
        envelope['body']['account'], envelope['body']['continuity'], envelope['body']['records'], envelope['body']['causal'],
        envelope['body']['light'], envelope['body']['inclusion'], envelope['body']['awards'], envelope['body']['capability'],
        envelope['body']['peer'], envelope['body']['history'],
    )
    need(body == envelope['body'], 'PORTABLE_CANONICAL')
    need(content_id(body) == envelope['content_id'], 'PORTABLE_HASH')
    if 'moved' in envelope:
        verify_moved(envelope['moved'], body['account'])
    forbidden = () if secret is None else (secret,)
    need(all(type(item) is str and len(item) >= 32 for item in forbidden), 'PORTABLE_SECRET')
    _scan(envelope, forbidden)
    if light_bundles is not None:
        need(type(light_bundles) is list and len(light_bundles) == len(body['light']['bundles']), 'PORTABLE_LIGHT')
        for pinned, supplied in zip(body['light']['bundles'], light_bundles):
            need(type(supplied) is dict and _sha256(supplied) == pinned['sha256'], 'PORTABLE_LIGHT')
            need(supplied.get('profile') == LIGHT_PROFILE and supplied.get('chain') == pinned['chain'], 'PORTABLE_LIGHT')
    if archive_path is not None:
        from .archive import anchor
        need(anchor(archive_path) == body['history']['anchor_sha512'], 'PORTABLE_ARCHIVE')
    return body
