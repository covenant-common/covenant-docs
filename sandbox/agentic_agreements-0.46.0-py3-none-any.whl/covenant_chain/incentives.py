"""Named incentive rules for covenant-native/0.15.

The reducer is unchanged. These rules are a view over settled receipts, paid
only through an existing ``ECON_REWARD_CREATE`` or ``ECON_SPONSOR_CREATE``
escrow. The PR #23 ``REFERRAL`` beneficiary row routes a share inside the same
10,000 basis points. It does not set the payout and it is not a second split.

Referral size is log of realised value, times trust-weighted diversity, times
the Wilson success lower bound, times a retention bonus. One level. Twenty
percent is held until the next epoch and dropped if that covenant is
overturned. Streaks, activity badges, quests and points are not in this rule
set. A niche subsidy pays the short side and ends after 90 blocks, the
campaign's stand-in for 90 days.
"""
from math import isqrt

from .crypto import integer, key, need
from .economics import label

RULE_SET = 'covenant-native/0.15'
RULE_NAME = 'network-incentives'
CONSENSUS_CHANGE = None
HOLDBACK_BPS = 2000
DIVERSITY_CAP = 20
REFERRAL_MIN_SETTLED = 3
REFERRAL_MIN_TRUSTED = 3
REFERRAL_WINDOW = 90
SUNSET_BLOCKS = 90
HEALTHY_EPOCHS = 4
FILL_SUPPLY = 6000
UTILISATION_SUPPLY = 5000
FILL_DEMAND = 8000
UTILISATION_DEMAND = 3000
UTILISATION_HEALTHY_MAX = 8500
ACCEPT_BPS = 8000
SPONSOR_BINDS = 5
REFUSED = ('STREAK', 'ACTIVITY_BADGE', 'QUEST', 'POINTS')
WINDOW_LABEL = 'CAMPAIGN_BLOCK_MAPPING_NOT_A_CHAIN_CALENDAR'


def activity_programme(kind):
    """No streaks, activity badges, quests or points before product-market fit."""
    need(type(kind) is str and kind in REFUSED, 'INCENTIVE_PROGRAMME')
    raise ValueError('INCENTIVE_BEFORE_PRODUCT_MARKET_FIT')


def log2_milli(value):
    """``floor(log2(1 + value) * 1000)`` for an exact power of two, else the cubic approximation."""
    integer(value)
    number = value + 1
    if number == 1:
        return 0
    bits = number.bit_length() - 1
    if bits >= 63:
        mantissa = number >> (bits - 63)
    else:
        mantissa = number << (63 - bits)
    fraction = mantissa - (1 << 63)
    linear = (fraction * 1000) >> 63
    square = (fraction * fraction) >> 63
    quadratic = (square * 500) >> 63
    cube = (square * fraction) >> 63
    cubic = (cube * 333) >> 63
    milli = bits * 1000 + linear - quadratic + cubic
    need(0 <= milli <= bits * 1000 + 1000, 'INCENTIVE_LOG')
    return milli


def wilson_lb_bps(successes, trials):
    """Integer Wilson lower bound in basis points. ``z = 196/100``."""
    integer(successes)
    integer(trials)
    need(0 <= successes <= trials, 'INCENTIVE_WILSON')
    if trials == 0:
        return 0
    scale = 10 ** 8
    radicand = (successes * (trials - successes) * scale) // trials + (9604 * scale) // 10000
    margin = 196 * isqrt(radicand) * 100 // (10 ** 4)
    numerator = successes * 10000 + 19208 - margin
    denominator = trials * 10000 + 38416
    if numerator <= 0:
        return 0
    return numerator * 10000 // denominator


def _successes(rows):
    """KEPT counts once. Two KEPT_LATE count as one. Other outcomes stay in the denominator."""
    kept = 0
    late = 0
    for row in rows:
        outcome = row.get('outcome', 'KEPT')
        if outcome == 'KEPT':
            kept += 1
        elif outcome == 'KEPT_LATE':
            late += 1
    return kept + late // 2, len(rows)


def trust_weights(rows, trust, trust_star):
    """Value weighted by ``min(1, tau / tau*)``. A missing or zero mass contributes nothing."""
    integer(trust_star, True)
    weights = {}
    for row in rows:
        tau = trust.get(row['counterparty'], 0)
        integer(tau)
        if tau <= 0 or row['value'] <= 0:
            continue
        weight = row['value'] * min(trust_star, tau) // trust_star
        if weight <= 0:
            continue
        weights[row['counterparty']] = weights.get(row['counterparty'], 0) + weight
    return weights


def effective_counterparties(weights):
    """Inverse Simpson index. Equal weights return the headcount. An empty set is 0."""
    if not weights:
        return 0
    total = sum(weights.values())
    squares = sum(weight * weight for weight in weights.values())
    if total <= 0 or squares <= 0:
        return 0
    return total * total // squares


def repeat_bps(rows):
    """Share of distinct counterparties who settled more than once. Absence is 0, not a penalty."""
    counts = {}
    for row in rows:
        counts[row['counterparty']] = counts.get(row['counterparty'], 0) + 1
    if not counts:
        return 0
    repeated = sum(1 for count in counts.values() if count >= 2)
    return repeated * 10000 // len(counts)


def quality_weight(rows, trust, *, trust_star):
    """``sum(log2(1+v)) * min(N_eff, 20) * LB * (1 + repeat/2)``.

    ``rows`` are realised settlements. Overturned rows are omitted by the caller.
    Trust mass comes from ``discovery_rank.pagerank`` or an owner-supplied view of it.
    """
    realised = [row for row in rows if row['value'] > 0]
    if not realised:
        return {'weight': 0, 'log_value_milli': 0, 'trust_neff': 0, 'lb_bps': 0, 'repeat_bps': 0,
                'capped_neff': 0}
    logs = sum(log2_milli(row['value']) for row in realised)
    diversity = effective_counterparties(trust_weights(realised, trust, trust_star))
    capped = min(diversity, DIVERSITY_CAP)
    successes, trials = _successes(realised)
    bound = wilson_lb_bps(successes, trials)
    retention = repeat_bps(realised)
    multiplier = 10000 + retention // 2
    weight = logs * capped * bound * multiplier // 10000
    integer(weight)
    return {'weight': weight, 'log_value_milli': logs, 'trust_neff': diversity, 'capped_neff': capped,
            'lb_bps': bound, 'repeat_bps': retention}


def holdback_split(amount):
    """Keep 80 percent payable and 20 percent until the next epoch."""
    integer(amount)
    if amount <= 0:
        return 0, 0
    held = amount * HOLDBACK_BPS // 10000
    return amount - held, held


def short_side(fill_bps, utilisation_bps):
    """The binding side of one niche. ``None`` when neither side is short."""
    integer(fill_bps)
    integer(utilisation_bps)
    need(fill_bps <= 10000 and utilisation_bps <= 10000, 'INCENTIVE_BPS')
    if fill_bps < FILL_SUPPLY and utilisation_bps > UTILISATION_SUPPLY:
        return 'SUPPLY'
    if fill_bps > FILL_DEMAND and utilisation_bps < UTILISATION_DEMAND:
        return 'DEMAND'
    return None


def healthy_epoch(fill_bps, utilisation_bps):
    integer(fill_bps)
    integer(utilisation_bps)
    return fill_bps >= FILL_DEMAND and UTILISATION_DEMAND <= utilisation_bps <= UTILISATION_HEALTHY_MAX


def demand_sponsor(*, resource, actors, unit_fee, expiry):
    """Sponsored first five BINDs for new owners. Existing sponsor escrow, not a new pot."""
    label(resource)
    integer(unit_fee, True)
    integer(expiry, True)
    need(type(actors) is list and 1 <= len(actors) <= 64, 'INCENTIVE_OWNERS')
    need(actors == sorted(set(actors)), 'INCENTIVE_OWNERS')
    for actor in actors:
        key(actor)
    per_actor = unit_fee * SPONSOR_BINDS
    integer(per_actor, True)
    budget = per_actor * len(actors)
    integer(budget, True)
    return {
        'operation': 'ECON_SPONSOR_CREATE',
        'payload': {
            'resource': resource,
            'budget': budget,
            'actors': list(actors),
            'operations': ['BIND'],
            'per_actor_cap': per_actor,
            'expiry': expiry,
        },
        'pot': 'EXISTING_SPONSOR_ESCROW',
        'new_treasury': False,
        'per_owner': 'FIVE_BIND_FEES',
        'rule_set': RULE_SET,
        'execution_authorized': False,
    }


def guarantee_amount(guarantee, earned, *, accepted, matched):
    """``max(0, guarantee - earned)`` when the provider accepted at least 80 percent."""
    integer(guarantee)
    integer(earned)
    integer(accepted)
    integer(matched, True)
    need(accepted <= matched, 'INCENTIVE_ACCEPTANCE')
    if accepted * 10000 // matched < ACCEPT_BPS:
        return 0
    if earned >= guarantee:
        return 0
    return guarantee - earned
