"""Issuer key rotation for adopted accreditation issuers, through precommitted successor keys.

``covenant-agent-accreditation`` pins issuer keys by version: a relying party's
policy holds {issuer: {key_version: key}} and nothing else is trusted. Without
this module a new issuer key had to be copied into the policy by hand.

An issuer can instead keep a ``covenant-portable-trust/0.1`` identity: an
inception record that commits to the hash of its next key, and signed rotation
records that each reveal the committed key and commit to the one after it
(pre-rotation). ``adopt`` pins an issuer name to one identity and the head the
relying party verified, mapping identity sequence n to key version ``v<n>``.
``rotate`` accepts a longer history only when it extends the retained head
through those precommitted successors, then adds the new version. Earlier
versions stay accepted for the credentials they signed until the relying party
retires them, or until the issuer's own signed status snapshot lists them as
withdrawn (``withdraw``). Someone holding only the current key cannot rotate:
the precommitted next key is required. Nothing here fetches an identity,
follows a rotation implicitly or creates authority.
"""
from copy import deepcopy

from . import agent_accreditation as accreditation
from . import portable_trust as trust
from .crypto import digest, integer, key, need

PIN_VERSION = 'covenant-agent-accreditation-issuer-pin/0.1'
PIN_LABEL = 'COVENANT-AGENT-ACCREDITATION-ISSUER-PIN-0.1'
MAX_VERSIONS = 16

ERRORS = {
    'ACCREDITATION_ISSUER_PIN': ('The retained issuer pin is malformed or names another issuer.',
                                 'Keep the pin returned by adopt or rotate, unchanged.', False),
    'ACCREDITATION_ROTATION_HISTORY': ('The supplied history does not extend the retained head.',
                                       'Supply the issuer\'s full identity history from inception to its new head.', False),
    'ACCREDITATION_ROTATION_VERSIONS': ('The policy would pin more than 16 versions, none, or one it never adopted.',
                                        'Retire old versions explicitly when adopting a rotation.', False),
    'ACCREDITATION_WITHDRAWN_ALL': ('The issuer withdrew every key version this policy pinned.',
                                    'Adopt the issuer\'s current key through a verified rotation before relying on it.', False),
    # covenant-portable-trust/0.1 codes an identity history can raise here.
    'TRUST_PRECOMMITTED_KEY': ('A rotation reveals a key that the previous record did not commit to.',
                               'Refuse it: only the precommitted successor can rotate. Report a possible key theft.', False),
    'TRUST_IDENTITY_PIN': ('The history starts from another inception than the pinned identity.',
                           'Supply the pinned issuer identity\'s own history.', False),
    'TRUST_IDENTITY_HEAD_PIN': ('The history does not reach the retained head.', 'Supply the history up to the retained head.',
                                False),
    'TRUST_IDENTITY_CHAIN': ('A rotation does not follow the previous record in order.', 'Supply the history in sequence.',
                             False),
    'TRUST_IDENTITY_HISTORY': ('The history is empty or longer than 256 records.', 'Supply 1 to 256 records.', False),
    'TRUST_RECORD_KIND': ('A history record is not an inception or rotation where one is required.',
                          'Supply inception first, then rotations.', False),
    'TRUST_SIGNATURES': ('A history record has no signatures or too many.', 'Supply records exactly as signed.', False),
    'TRUST_UNEXPECTED_SIGNER': ('A history record carries a signature by a key it does not name.',
                                'Supply records signed only by their named controller.', False),
    'TRUST_REQUIRED_SIGNATURES': ('A history record lacks its controller\'s signature.',
                                  'Supply records signed by their named controller.', False),
    'TRUST_EXPECTED_RECORD': ('A record differs from the one expected.', 'Supply the exact retained record.', False),
}


def explain(code):
    if code not in ERRORS:
        return accreditation.explain(code)
    happened, fix, retry = ERRORS[code]
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/AGENT_ACCREDITATION.html#' + code}


def version_name(sequence):
    integer(sequence)
    return 'v' + str(sequence)


def keys(events, *, identity, head=None):
    """Every key of a verified pre-rotation history, by key version."""
    checked = trust.verify_identity(events, identity, head)
    return {'identity': identity, 'head': checked['head'], 'sequence': checked['sequence'],
            'keys': {version_name(n): events[n]['body']['controller'] for n in range(len(events))},
            'currentness': checked['currentness'], 'execution_authorized': False}


def _pin(value):
    need(type(value) is dict and set(value) == {'version', 'issuer', 'identity', 'head', 'sequence'}
         and value['version'] == PIN_VERSION, 'ACCREDITATION_ISSUER_PIN')
    accreditation._text(value['issuer']); key(value['identity']); key(value['head']); integer(value['sequence'])
    return value


def pin_id(value):
    return digest(PIN_LABEL, _pin(value))


def _replace(accepted, issuer, versions):
    accreditation._policy(accepted)
    need(0 < len(versions) <= MAX_VERSIONS, 'ACCREDITATION_ROTATION_VERSIONS')
    updated = deepcopy(accepted)
    updated['issuers'][issuer] = dict(sorted(versions.items()))
    accreditation._policy(updated)
    return updated


def adopt(accepted, issuer, events, *, identity, head, versions=None):
    """Pin ``issuer`` to a verified identity at ``head``; adopt its current key, or the listed versions."""
    accreditation._text(issuer)
    found = keys(events, identity=identity, head=head)
    chosen = [version_name(found['sequence'])] if versions is None else list(versions)
    need(chosen and all(name in found['keys'] for name in chosen), 'ACCREDITATION_ROTATION_VERSIONS')
    policy = _replace(accepted, issuer, {name: found['keys'][name] for name in chosen})
    pin = {'version': PIN_VERSION, 'issuer': issuer, 'identity': identity, 'head': found['head'],
           'sequence': found['sequence']}
    return {'policy': policy, 'pin': pin, 'pin_id': pin_id(pin), 'adopted': sorted(chosen),
            'policy_id': accreditation.policy_id(policy), 'execution_authorized': False}


def rotate(accepted, pin, events, *, retire=()):
    """Accept a history that extends the retained head through precommitted keys; add its new versions."""
    _pin(pin)
    issuer = pin['issuer']
    accreditation._policy(accepted)
    need(issuer in accepted['issuers'], 'ACCREDITATION_ISSUER_PIN')
    need(type(events) is list and len(events) > pin['sequence'] + 1, 'ACCREDITATION_ROTATION_HISTORY')
    try:
        # The retained head must be exactly where it was: no fork, no rewritten prefix.
        trust.verify_identity(events[:pin['sequence'] + 1], pin['identity'], pin['head'])
    except ValueError:
        raise ValueError('ACCREDITATION_ROTATION_HISTORY') from None
    found = keys(events, identity=pin['identity'])
    current = dict(accepted['issuers'][issuer])
    added = [version_name(n) for n in range(pin['sequence'] + 1, found['sequence'] + 1)]
    for name in added:
        current[name] = found['keys'][name]
    need(type(retire) in (list, tuple) and all(name in current and name not in added for name in retire),
         'ACCREDITATION_ROTATION_VERSIONS')
    for name in retire:
        del current[name]
    policy = _replace(accepted, issuer, current)
    new_pin = {'version': PIN_VERSION, 'issuer': issuer, 'identity': pin['identity'], 'head': found['head'],
               'sequence': found['sequence']}
    return {'policy': policy, 'pin': new_pin, 'pin_id': pin_id(new_pin), 'added': added, 'retired': sorted(retire),
            'policy_id': accreditation.policy_id(policy), 'currentness': 'OWNER_RETAINED_HEAD_NOT_GLOBAL_LATEST',
            'execution_authorized': False}


def withdraw(accepted, issuer, withdrawn):
    """Drop versions the issuer's own signed snapshot withdrew; a withdrawn key never signs for this policy again."""
    accreditation._policy(accepted)
    need(type(withdrawn) in (list, tuple) and all(type(name) is str for name in withdrawn), 'ACCREDITATION_ROTATION_VERSIONS')
    if issuer not in accepted['issuers']:
        return {'policy': deepcopy(accepted), 'withdrawn': [], 'execution_authorized': False}
    current = {name: value for name, value in accepted['issuers'][issuer].items() if name not in set(withdrawn)}
    need(bool(current), 'ACCREDITATION_WITHDRAWN_ALL')
    policy = _replace(accepted, issuer, current)
    return {'policy': policy, 'withdrawn': sorted(set(withdrawn) & set(accepted['issuers'][issuer])),
            'policy_id': accreditation.policy_id(policy), 'execution_authorized': False}


def describe():
    return {'pin': PIN_VERSION, 'identity': trust.VERSION, 'key_versions': 'v<identity sequence>',
            'rotation': 'PRECOMMITTED_SUCCESSOR_KEY_REVEALED_BY_SIGNED_ROTATION_RECORD',
            'adoption': 'EXPLICIT_RELYING_PARTY_ACTION_RETURNING_A_NEW_POLICY',
            'previous_versions': 'KEPT_UNTIL_RETIRED_OR_WITHDRAWN_BY_THE_ISSUER',
            'limits': {'versions_per_issuer': MAX_VERSIONS, 'history': trust.MAX_HISTORY},
            'currentness': 'OWNER_RETAINED_HEAD_NOT_GLOBAL_LATEST', 'network_accessed': False,
            'execution_authorized': False}
