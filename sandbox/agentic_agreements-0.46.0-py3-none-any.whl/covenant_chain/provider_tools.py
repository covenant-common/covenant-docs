"""Keyless provider drafts and statement review; never calls the provider."""
from copy import deepcopy
from . import reliance, resource_provider as provider
from .agent_tools import _fields
from .crypto import integer, need, verification_key
from .workflow_store import canonical


def handover_review(spec, snapshot, snapshot_command, expected_provider, signer, recovery,
                    recovery_expectations, target, lease_expires, nonce, now, max_age):
    need(provider.provider_id(spec) == expected_provider and canonical(signer) == canonical(spec['signer']), 'PROVIDER_REVIEW_SPEC_PIN')
    receipt = provider.verify_receipt(snapshot,snapshot_command,expected_provider=expected_provider,signer=signer)
    need(snapshot_command['operation'] == 'snapshot', 'PROVIDER_REVIEW_SNAPSHOT_REQUIRED')
    integer(now); integer(max_age)
    need(receipt['at'] <= now and now-receipt['at'] <= max_age, 'PROVIDER_REVIEW_STALE')
    old = reliance.verify_recovery(recovery,**recovery_expectations)
    need(recovery_expectations['now'] == now, 'PROVIDER_REVIEW_CLOCK')
    value = receipt['value']; account = snapshot_command['wallet']
    need(account in spec['accounts'] and value['wallet'] == account, 'PROVIDER_REVIEW_ACCOUNT')
    need(canonical(recovery['packet']['wallet']['policy']['principal']) == canonical(spec['accounts'][account]['principal']),
         'PROVIDER_REVIEW_PRINCIPAL_MISMATCH')
    verification_key(target); integer(lease_expires,True)
    need(now < lease_expires <= now+spec['max_lease_seconds'], 'PROVIDER_LEASE_INTERVAL')
    checkpoint = reliance.recovery_payload(recovery['packet'])['body']['packet']
    draft = provider.draft_command(expected_provider,account,spec['accounts'][account]['principal'],value['custody']['epoch'],
        'handover',{'holder':target,'expires':lease_expires,'expected_head':receipt['head'],'checkpoint':checkpoint},now,now+30,nonce)
    return {'status':'DRAFT_REQUIRES_PRINCIPAL_SIGNATURE_AND_LIVE_PROVIDER_CAS','handover':draft,
            'provider_account':account,'local_wallet':old['wallet'],'provider_snapshot':deepcopy(value),
            'remaining_obligations':old['obligations'],'obligations':'CALLER_DECLARED_NOT_PROVED',
            'resource_mapping':'EXPLICIT_PROVIDER_ACCOUNT; NO_AUTOMATIC_EQUIVALENCE_TO_LOCAL_WALLET_RESOURCES',
            'live_local_wallet_import':False,'execution_authorized':False,
            'next':['If old host is active, principal freezes it first and obtains a fresh snapshot.',
                    'Principal signs this exact draft; provider refuses if head or epoch changed.',
                    'Target obtains a fresh signed snapshot and checks the adopted epoch and checkpoint.',
                    'Resume only this provider’s holds; retain other local obligations for separate resolution.']}


def definition():
    from .reliance_tools import _shape
    obj={'type':'object'}; ref={'type':'string','minLength':64,'maxLength':64}
    number={'type':'integer','minimum':0,'maximum':2**53-1}
    actions={'describe':_shape({'spec':obj}),
        'private_describe':_shape({'context':obj}),
        'private_command':_shape({'context':obj,'wallet':ref,'subject':{},'epoch':number,
                         'operation':{'type':'string','enum':list(provider.OPERATIONS)},'parameters':obj,
                         'not_before':number,'expires':number,'nonce':ref}),
        'private_receipt':_shape({'proof':obj,'context':obj,'expected_wallet':ref,'expected_request':ref,
            'minimum_checkpoint':{'type':['object','null']},'now':{'type':['integer','null']},'max_age':{'type':['integer','null']}}),
        'replica_describe':_shape({'spec':obj}),
        'replica_command':_shape({'spec':obj,'wallet':ref,'subject':{},'epoch':number,
                         'operation':{'type':'string','enum':list(provider.OPERATIONS)},'parameters':obj,
                         'not_before':number,'expires':number,'nonce':ref}),
        'command':_shape({'provider':ref,'wallet':ref,'subject':{},'epoch':number,
                         'operation':{'type':'string','enum':list(provider.OPERATIONS)},'parameters':obj,
                         'not_before':number,'expires':number,'nonce':ref}),
        'receipt':_shape({'envelope':obj,'command':obj,'expected_provider':ref,'signer':{}}),
        'handover':_shape({'spec':obj,'snapshot':obj,'snapshot_command':obj,'expected_provider':ref,'signer':{},
            'recovery':obj,'recovery_expectations':obj,'target':{},'lease_expires':number,'nonce':ref,'now':number,'max_age':number})}
    return {'name':'covenant_provider','description':'Use private_describe/private_command/private_receipt for provider 0.2 account-scoped proofs and no lifetime command cap. Historical 0.1 actions remain explicit. Draft or verify only; no provider calls, signing, inventory holds or live wallet import.',
        'inputSchema':{'type':'object','oneOf':[_shape({'action':{'const':action},'parameters':shape}) for action,shape in actions.items()]},
        'outputSchema':{'type':'object'},'annotations':{'readOnlyHint':True,'destructiveHint':False,'idempotentHint':True,'openWorldHint':False}}


def call(arguments):
    _fields(arguments,('action','parameters')); action=arguments['action']; p=arguments['parameters']
    need(type(action) is str and type(p) is dict,'PROVIDER_TOOL_ARGUMENTS')
    actions={v['properties']['action']['const']:v['properties']['parameters'] for v in definition()['inputSchema']['oneOf']}
    need(action in actions,'PROVIDER_TOOL_ACTION'); shape=actions[action]; _fields(p,shape['required'])
    if action=='describe':
        spec = p.get('spec')
        if type(spec) is not dict or not spec:
            from .surface import not_committed
            return not_committed('FIELDS')
        return {'id':provider.provider_id(spec),'spec':deepcopy(spec),
        'installed':False,'inventory_backing':'NOT_ESTABLISHED','execution_authorized':False}
    if action in ('replica_describe','replica_command'):
        from . import provider_replication as replication
        if action == 'replica_command': return replication.draft_command(**p)
        return {'cluster':replication.cluster_id(p['spec']),'spec':deepcopy(p['spec']),
                'quorum':2*p['spec']['faults']+1,'installed':False,'execution_authorized':False,
                'proof_privacy':'OWNER_ONLY_FULL_COMMAND_HISTORY_ALL_ACCOUNTS',
                'limits':{'commands':replication.MAX_COMMITS,'history_bytes':replication.MAX_HISTORY_BYTES},
                'assurance':'EXPERIMENTAL_FIXED_COMMITTEE; INTACT_SIGNING_STORAGE; NOT_EXTERNAL_BACKING'}
    if action in ('private_describe','private_command','private_receipt'):
        from . import private_provider
        if action == 'private_command':
            return private_provider.draft_command(p['context'],**{k:v for k,v in p.items() if k!='context'})
        if action == 'private_receipt':
            return {'statement':private_provider.verify_receipt(**p),'execution_authorized':False,
                    'assurance':'SCOPED_QUORUM_RECORD_INCLUSION; NOT_ZK_OR_PHYSICAL_DELIVERY'}
        return {'context':private_provider.public_context(p['context']),'lifetime_command_limit':None,
                'history_page_records':private_provider.PAGE_LIMIT,'history_page_bytes':private_provider.PAGE_BYTES,
                'proof_max_bytes':private_provider.MAX_PROOF_BYTES,'validator_plaintext_access':True,
                'installed':False,'execution_authorized':False,'proof_disclosure':'SELECTED_ACCOUNT_RECORD_ONLY'}
    if action=='command':return provider.draft_command(**p)
    if action=='receipt':return {'statement':provider.verify_receipt(**p),
        'assurance':'ADOPTED_PROVIDER_STATEMENT; NOT_EXTERNAL_DELIVERY_OR_CURRENT_AUTHORITY','execution_authorized':False}
    return handover_review(**p)
