"""Explicit module negotiation: no hidden downgrade, no unimplemented anonymity."""
from copy import deepcopy
from .crypto import canonical,exact,need,digest

VERSION='covenant-privacy-policy/0.1'
# Ordered choices are supplied by both peers; the proposer orders selection.
OPTIONS={
 'identity':{'public','counterparty-only','hidden-credential'},
 'terms':{'public','scoped-encrypted'},
 'resources':{'transparent','shielded'},
 'transport':{'direct','origin-protected'},
 'disclosure':{'none','scoped','scoped-delegable'},
}
IMPLEMENTED={
 'identity':{'public'},'terms':{'public','scoped-encrypted'},
 'resources':{'transparent'},'transport':{'direct'},
 'disclosure':{'none','scoped','scoped-delegable'},
}
# Selectable only when the negotiating party passes a real two-hop relay route.
ROUTED={'transport':{'origin-protected'}}
# Selectable only when the negotiating party passes a checked hidden-credential
# policy (covenant_chain.hidden_credentials). Both parties must pass the same one.
CREDENTIALED={'identity':{'hidden-credential'}}
SELECTION_VERSION='covenant-privacy-selection/0.1'
ROUTED_SELECTION_VERSION='covenant-privacy-selection/0.2'
CREDENTIAL_SELECTION_VERSION='covenant-privacy-selection/0.3'
SELECTION_LABELS={SELECTION_VERSION:'COVENANT-PRIVACY-SELECTION-0.1',ROUTED_SELECTION_VERSION:'COVENANT-PRIVACY-SELECTION-0.2',
                  CREDENTIAL_SELECTION_VERSION:'COVENANT-PRIVACY-SELECTION-0.3'}
CREDENTIAL_LEAKAGE=[
 'selective disclosure is not zero knowledge or network anonymity; issuer can link presentations it observes',
 'holder keys, disclosed claims, scope, audience and transport metadata can correlate presentations',
 'issuer issuance state and verifier nullifier state must be retained separately; no consensus uniqueness',
 'the native ledger still records each signing key; use a fresh key per agreement to avoid linking agreements on chain',
]
DIRECT_LEAKAGE='direct network origin may be observable'
ORIGIN_LEAKAGE=[
 'origin-protected hides network origin from the exit relay and destination only while entry and exit relays are run by independent, non-colluding operators; this code cannot verify independence',
 'the entry relay sees network origin and timing; the exit relay and destination see the transaction',
 'no global timing anonymity: an observer of entry and exit links can correlate submissions; optional batching and random delay only blur timing',
 'no Sybil resistance: one operator running both hops, or many relays, can link origin and destination',
]

def _policy(policy):
    exact(policy,'version choices');need(policy['version']==VERSION,'PRIVACY_VERSION');exact(policy['choices'],' '.join(OPTIONS))
    for axis,choices in policy['choices'].items():
        need(type(choices) is list and 0<len(choices)<=len(OPTIONS[axis]) and all(type(x) is str and x in OPTIONS[axis] for x in choices) and len(set(choices))==len(choices),'PRIVACY_CHOICES')

def _implemented(route,credential=None):
    implemented,checked=IMPLEMENTED,None
    if route is not None:
        from .relay import check_route
        checked=check_route(route)
        implemented={axis:implemented[axis]|ROUTED.get(axis,set()) for axis in implemented}
    if credential is not None:
        from .hidden_credentials import check_policy
        check_policy(credential)
        implemented={axis:implemented[axis]|CREDENTIALED.get(axis,set()) for axis in implemented}
    return implemented,checked

def negotiate(proposer,recipient,*,route=None,credential=None):
    """Pure offline negotiation. Both parties must assent to the selected digest.

    ``route`` is this party's own relay route (relay.check_route). Only with it
    can transport 'origin-protected' be selected, under selection /0.2. Each
    party checks its own route; a party without one gets BACKEND_UNAVAILABLE,
    so both cannot assent to the same selection. Without origin-protected the
    /0.1 selection bytes are unchanged.

    ``credential`` is a hidden-credential verifier policy. Only with it can
    identity 'hidden-credential' be selected, under selection /0.3, which binds
    the policy id so both parties assent to the same issuers and claims. The
    selected transport, direct or origin-protected, is part of that selection.
    Without hidden-credential the /0.1 and /0.2 selection bytes are unchanged.
    """
    _policy(proposer);_policy(recipient);selected={};failures={}
    implemented,checked=_implemented(route,credential)
    for axis in OPTIONS:
        common=[v for v in proposer['choices'][axis] if v in recipient['choices'][axis]]
        available=[v for v in common if v in implemented[axis]]
        if not common:failures[axis]='INCOMPATIBLE_REQUIREMENTS'
        elif not available:failures[axis]='BACKEND_UNAVAILABLE'
        else:selected[axis]=available[0]
    if failures:return {'compatible':False,'failures':failures,'selected':None}
    if (selected['terms']=='scoped-encrypted')!=(selected['disclosure']!='none'):
        return {'compatible':False,'failures':{'combination':'INCOMPATIBLE_MODULES'},'selected':None}
    routed=selected['transport']=='origin-protected'
    credentialed=selected['identity']=='hidden-credential'
    version=CREDENTIAL_SELECTION_VERSION if credentialed else ROUTED_SELECTION_VERSION if routed else SELECTION_VERSION
    profile={'version':version,'selected':selected}
    if credentialed:
        from .hidden_credentials import policy_id
        profile['credential_policy']=policy_id(credential)
    network=list(ORIGIN_LEAKAGE) if routed else [DIRECT_LEAKAGE]
    if routed and checked['same_host']:network.append('entry and exit relays share one host, so one operator can link origin and destination')
    leakage=['public native actors, resource identifiers and quantities, causal relationships and timing',
             *network,
             'scoped deliveries expose their grant chain to their recipients',
             'public manifests expose slot count and caller-supplied context']
    if credentialed:leakage.extend(CREDENTIAL_LEAKAGE)
    if credentialed:assurance='PINNED_ISSUER_CLAIMS_NOT_WORLD_TRUTH_OR_AUTHORITY'
    else:assurance='CONFIDENTIAL_CONTENT_ONLY' if selected['terms']=='scoped-encrypted' else 'PUBLIC_CONTENT'
    result={'compatible':True,'failures':{},'selected':profile,'id':digest(SELECTION_LABELS[version],profile),
            'leakage':leakage,'assurance':assurance}
    if routed:result['route']={'hops':checked['hops'],'same_host':checked['same_host'],'checked_at':'NEGOTIATION'}
    return result

def bind_terms(terms,selection,manifest):
    """Bind negotiated profile and private manifest into a new exact terms hash.

Do this BEFORE collecting assent. Never amend an already signed agreement.
"""
    from .disclosure import manifest_id,_manifest
    need(selection.get('compatible') is True,'PRIVACY_INCOMPATIBLE')
    chosen=selection['selected'];need(type(chosen) is dict,'FIELDS')
    credentialed=chosen.get('version')==CREDENTIAL_SELECTION_VERSION
    exact(chosen,'version selected credential_policy' if credentialed else 'version selected')
    need(chosen['version'] in SELECTION_LABELS,'PRIVACY_VERSION');exact(chosen['selected'],' '.join(OPTIONS))
    routed=chosen['selected']['transport']=='origin-protected'
    if credentialed:
        from .crypto import key
        key(chosen['credential_policy'])
        need(chosen['selected']['identity']=='hidden-credential','PRIVACY_BACKEND_UNAVAILABLE')
    else:
        need(routed==(chosen['version']==ROUTED_SELECTION_VERSION),'PRIVACY_VERSION')
    allowed={a:IMPLEMENTED[a]|(ROUTED.get(a,set()) if routed else set())|(CREDENTIALED.get(a,set()) if credentialed else set()) for a in IMPLEMENTED}
    need(all(v in allowed[a] for a,v in chosen['selected'].items()),'PRIVACY_BACKEND_UNAVAILABLE')
    need(chosen['selected']['terms']=='scoped-encrypted' and chosen['selected']['disclosure']!='none','PRIVACY_BINDING_MODE')
    need(selection['id']==digest(SELECTION_LABELS[chosen['version']],chosen),'PRIVACY_SELECTION_BINDING')
    _manifest(manifest);need(manifest['delegation']==(chosen['selected']['disclosure']=='scoped-delegable'),'PRIVACY_DELEGATION_POLICY');need(manifest['context'].get('chain')==terms['chain'],'PRIVACY_CHAIN')
    bound=deepcopy(terms);bound['terms_hash']=digest('COVENANT-PRIVATE-TERMS-0.1',{'original_terms_hash':terms['terms_hash'],'privacy':selection['id'],'manifest':manifest_id(manifest)})
    return bound
