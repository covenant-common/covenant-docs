"""Keyless commerce grafts: ACP and UCP checkouts, MPP 402 receipts and AP2 mandates, one AAP record.

Every action prepares or checks data. None signs, pays, releases escrow,
fetches a URL, holds a secret or installs a connector. Card data, payment
credentials and webhook or binding secrets are refused here; the owner SDK
(covenant_agent.commerce_acp, covenant_x402.mpp) handles secrets in-process.
"""
from .cooperation_interface import HASH, INT
from .crypto import FieldError
from .contract_application_tools import _input_models

OBJECT = {'type': 'object', 'maxProperties': 64}

PROTOCOL = {'enum': ['ACP', 'UCP']}
DOCUMENT = {'type': 'string', 'minLength': 2, 'maxLength': 262144,
            'description': 'The exact received JSON text. It is hashed and parsed, never executed or fetched.'}
HEADER = {'type': 'string', 'minLength': 1, 'maxLength': 16384}
REQUEST = {'type': 'object', 'additionalProperties': False, 'required': ['method', 'target_uri', 'headers'],
           'description': 'The received webhook request: method, the target URI it reached and its [name, value] headers.',
           'properties': {'method': {'type': 'string', 'minLength': 1, 'maxLength': 32},
                          'target_uri': {'type': 'string', 'pattern': '^https?://', 'minLength': 8, 'maxLength': 8192},
                          'headers': {'type': 'array', 'maxItems': 128, 'items': {
                              'type': 'array', 'minItems': 2, 'maxItems': 2,
                              'items': {'type': 'string', 'maxLength': 8192}}}}}
SIGNER_KEYS = {'type': 'object', 'required': ['keys'], 'maxProperties': 64,
               'description': 'The business profile JWK set you adopted (its keys[]); never fetched here.',
               'properties': {'keys': {'type': 'array', 'maxItems': 64, 'items': {'type': 'object', 'maxProperties': 32}}}}
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 256}
PARTIES = {'type': 'object', 'required': ['buyer', 'seller'], 'additionalProperties': False,
           'properties': {'buyer': HASH, 'seller': HASH}}
HASHES = {'type': 'array', 'maxItems': 32, 'items': HASH}
OBJECTS = {'type': 'array', 'maxItems': 32, 'items': OBJECT}
TIERS = {'type': 'array', 'minItems': 1, 'maxItems': 8, 'items': {
    'type': 'object', 'required': ['up_to', 'unit_price'], 'additionalProperties': False,
    'properties': {'up_to': {'type': ['integer', 'null'], 'minimum': 1, 'maximum': 2**53-1}, 'unit_price': INT}}}
APPLICATION = {**OBJECT, 'description': 'The commerce application returned by draft, unchanged.'}
# Reuse the application's existing echo model; this describes receipt verification
# material without changing the native receipt or assent formats.
ROLE = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
SIGNATURE = {'anyOf': [{'type': 'string', 'maxLength': 262144}, OBJECT]}
APPROVAL = {'type': 'object', 'additionalProperties': False,
            'required': ['concept', 'party', 'signature'],
            'properties': {'concept': HASH, 'party': ROLE, 'signature': SIGNATURE}}
ADOPTION = {'type': 'object', 'additionalProperties': False,
            'required': ['echoes', 'approvals', 'expected_closure'],
            'properties': {'echoes': {'type': 'array', 'maxItems': 128, 'items': _input_models()['echo']},
                           'approvals': {'type': 'array', 'maxItems': 128, 'items': APPROVAL},
                           'expected_closure': HASH},
            'description': 'Exact receipt adoption material: {echoes, approvals, expected_closure}. '
                           'Use both signed meaning echoes and the role-qualified approvals from '
                           'covenant_contract_application.prepare. Pass its id separately as agreement; '
                           'do not put expected_id inside adoption.'}


def spec():
    return ('covenant_commerce',
        'Bind an ACP or UCP checkout, MPP 402 payment receipts and AP2 payment mandates to one AAP agreement. '
        'Draft the typed exchange agreement and the aap_agreement checkout extension, record order and payment '
        'messages as evidence, prepare and verify the buyer\'s delivery receipt against the typed acceptance '
        'criteria, plan the agreed escrow refund or dispute-ladder step, and check whether an AP2 release '
        'condition is met. Evidence never assents, pays, releases or completes an obligation. No signing, '
        'secrets, card data, fetching or execution.', True, [
        ('extension', {'protocol': PROTOCOL}, ('protocol',)),
        ('draft', {'protocol': PROTOCOL, 'checkout': DOCUMENT, 'merchant': TEXT, 'parties': PARTIES, 'context': HASH,
                   'acceptance': {**OBJECT, 'description': 'Typed acceptance criteria: name -> {kind, value} or MONEY {kind, amount, unit}.'},
                   'remedy': {'enum': ['AAP_ESCROW', 'DISPUTE_LADDER', 'RECORD_ONLY']}, 'remedy_reference': HASH},
         ('protocol', 'checkout', 'merchant', 'parties', 'context', 'acceptance', 'remedy')),
        ('reference', {'application': APPLICATION, 'agreement': HASH}, ('application',)),
        ('check_reference', {'reference': OBJECT, 'application': APPLICATION, 'agreement': HASH}, ('reference',)),
        ('evidence', {'protocol': PROTOCOL, 'kind': {'enum': ['ORDER_EVENT', 'CHECKOUT_COMPLETED', 'PAYMENT_ALLOWANCE']},
                      'application': APPLICATION, 'document': DOCUMENT, 'content_digest': {'type': 'string', 'maxLength': 512},
                      'request': REQUEST, 'signer_keys': SIGNER_KEYS, 'now': INT},
         ('protocol', 'kind', 'application', 'document')),
        ('receipt_payload', {'application': APPLICATION, 'agreement': HASH, 'observed': OBJECT, 'evidence': HASHES, 'at': INT},
         ('application', 'agreement', 'observed', 'evidence', 'at')),
        ('verify_receipt', {'application': APPLICATION, 'agreement': HASH, 'receipt': OBJECT, 'adoption': ADOPTION},
         ('application', 'agreement', 'receipt')),
        ('remedy', {'application': APPLICATION, 'agreement': HASH, 'receipt': OBJECT, 'adoption': ADOPTION,
                    'escrow_policy': OBJECT, 'ladder': OBJECT, 'at': INT, 'refund_outcome': OBJECT, 'bond_receipt': HASH,
                    'merchant_evidence': OBJECTS},
         ('application', 'agreement', 'receipt', 'adoption')),
        ('ladder_outcome', {'application': APPLICATION, 'ladder': OBJECT, 'expected_head': HASH}, ('application', 'ladder')),
        ('mpp_pricing', {'intent': {'enum': ['charge', 'session']}, 'method': {'type': 'string', 'pattern': '^[a-z]{1,64}$'},
                         'currency': {'type': 'string', 'minLength': 1, 'maxLength': 128}, 'recipient': TEXT,
                         'amount': INT, 'unit_type': {'type': 'string', 'minLength': 1, 'maxLength': 64}, 'tiers': TIERS,
                         'max_total': INT}, ('intent', 'method', 'currency')),
        ('mpp_record', {'agreement': HASH, 'terms': OBJECT,
                        'www_authenticate': {'oneOf': [HEADER, {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': HEADER}]},
                        'receipts': {'type': 'array', 'maxItems': 32, 'items': {'type': 'string', 'minLength': 1, 'maxLength': 8192}},
                        'challenge_id': {'type': 'string', 'minLength': 1, 'maxLength': 512}},
         ('agreement', 'terms', 'www_authenticate', 'receipts')),
        ('ap2_condition', {'application': APPLICATION, 'agreement': HASH, 'mandate': DOCUMENT, 'as_of': INT,
                           'checkout_jwt': {'type': 'string', 'minLength': 1, 'maxLength': 65536}},
         ('application', 'agreement', 'mandate', 'as_of')),
        ('ap2_evaluate', {'application': APPLICATION, 'agreement': HASH, 'condition': OBJECT, 'approvals': OBJECTS,
                          'mandate': DOCUMENT, 'receipt': OBJECT, 'adoption': ADOPTION, 'as_of': INT,
                          'checkout_jwt': {'type': 'string', 'minLength': 1, 'maxLength': 65536}},
         ('application', 'agreement', 'condition', 'approvals', 'mandate', 'as_of'))])


def describe():
    from covenant_agent import commerce
    from covenant_x402 import mpp
    return {'profile': commerce.PROFILE, 'extension': commerce.EXTENSION, 'extension_version': commerce.EXTENSION_VERSION,
            'field': commerce.FIELD, 'snapshots': {k: list(v) for k, v in commerce.SNAPSHOTS.items()},
            'rail': mpp.RAIL, 'remedies': list(commerce.REMEDIES),
            'flow': ['extension: advertise or request the aap_agreement checkout extension',
                     'draft: checkout JSON -> unsigned typed agreement, echo payloads and the checkout update body',
                     'covenant_contract_application.prepare and verify: both roles echo and assent outside this tool',
                     'evidence: record order webhooks, completed checkouts and allowances',
                     'receipt_payload -> buyer signs -> verify_receipt; remedy for the agreed escrow or ladder step',
                     'mpp_pricing and mpp_record: agreed 402 pricing and its receipts; ap2_condition and ap2_evaluate'],
            'never': ['sign', 'pay', 'release escrow', 'fetch a schema or checkout', 'hold a webhook or binding secret',
                      'accept card data or payment credentials'],
            'publisher_crawler_licensing': {'tool':'covenant_crawl_licence','guide':'docs/CRAWL_LICENSING.html',
                'installation':'Owner constructs crawl_licensing.CrawlLicenceDesk with public pins and a private journal, then passes it to ExchangeTools. It is absent on the keyless host.',
                'effects':'Read-only inspection and drafting; status adoption and receipt recording are separate owner SDK calls.'},
            'guide': 'docs/COMMERCE_GRAFTS.html', 'execution_authorized': False}


def _document(text):
    return text.encode('utf-8')


def call(action, p):
    from covenant_agent import ap2_release, commerce, commerce_acp, commerce_remedies, commerce_ucp
    from covenant_agent.errors import NativeError
    from covenant_x402 import mpp
    adapters = {'ACP': commerce_acp, 'UCP': commerce_ucp}
    try:
        if action == 'extension':
            return adapters[p['protocol']].extension()
        if action == 'draft':
            parties = {'buyer': p['parties']['buyer'], 'seller': p['parties']['seller']}
            return adapters[p['protocol']].draft(_document(p['checkout']), p['merchant'], parties, p['context'],
                                                 p['acceptance'], p['remedy'], p.get('remedy_reference'))
        if action == 'reference':
            return {'reference': commerce.reference(p['application'], p.get('agreement')), 'field': commerce.FIELD,
                    **commerce.FLAGS}
        if action == 'check_reference':
            return commerce.check_reference(p['reference'], p.get('application'), p.get('agreement'))
        if action == 'evidence':
            module, kind, raw = adapters[p['protocol']], p['kind'], _document(p['document'])
            if (p['protocol'], kind) != ('UCP', 'ORDER_EVENT') and {'request', 'signer_keys', 'now'} & set(p):
                raise NativeError('COMMERCE_SIGNATURE_UCP_ONLY', commerce.HINTS['COMMERCE_SIGNATURE_UCP_ONLY'])
            if kind == 'ORDER_EVENT':
                if p['protocol'] == 'UCP':
                    return module.order_event(p['application'], raw, content_digest_header=p.get('content_digest'),
                                              request=p.get('request'), signer_keys=p.get('signer_keys'), now=p.get('now'))
                return module.order_event(p['application'], raw)
            if kind == 'CHECKOUT_COMPLETED':
                return module.completed(p['application'], raw)
            if p['protocol'] != 'ACP':
                raise ValueError('COMMERCE_EVIDENCE_KIND')
            return module.allowance(p['application'], raw)
        if action == 'receipt_payload':
            return commerce.receipt_payload(p['application'], p['agreement'], p['observed'], p['evidence'], p['at'])
        if action == 'verify_receipt':
            return commerce.verify_receipt(p['application'], p['agreement'], p['receipt'], p.get('adoption'))
        if action == 'remedy':
            return commerce_remedies.plan(p['application'], p['agreement'], p['receipt'], p['adoption'],
                                          escrow_policy=p.get('escrow_policy'), ladder=p.get('ladder'), at=p.get('at'),
                                          refund_outcome=p.get('refund_outcome'), bond_receipt=p.get('bond_receipt'),
                                          merchant_evidence=p.get('merchant_evidence'))
        if action == 'ladder_outcome':
            return commerce_remedies.ladder_outcome(p['application'], p['ladder'], expected_head=p.get('expected_head'))
        if action == 'mpp_pricing':
            terms = mpp.pricing(p['intent'], p['method'], p['currency'], p.get('recipient'), amount=p.get('amount'),
                                unit_type=p.get('unit_type'), tiers=p.get('tiers'), max_total=p.get('max_total'))
            return {'terms': terms, 'rail': mpp.rail_terms(terms), **commerce.FLAGS}
        if action == 'mpp_record':
            return mpp.record(p['agreement'], p['terms'], p['www_authenticate'], p['receipts'],
                              challenge_id=p.get('challenge_id'))
        if action == 'ap2_condition':
            return ap2_release.condition(p['application'], p['agreement'], _document(p['mandate']), as_of=p['as_of'],
                                         checkout_jwt=p.get('checkout_jwt'))
        if action == 'ap2_evaluate':
            return ap2_release.evaluate(p['application'], p['agreement'], p['condition'], p['approvals'],
                                        _document(p['mandate']), p.get('receipt'), p.get('adoption'), as_of=p['as_of'],
                                        checkout_jwt=p.get('checkout_jwt'))
    except NativeError as exc:
        # Carry the module's remediation to the agent through the shared refusal shape.
        raise FieldError(exc.code, '/parameters', 'see next_action', exc.remediation) from None
    raise ValueError('COMMERCE_ACTION')
