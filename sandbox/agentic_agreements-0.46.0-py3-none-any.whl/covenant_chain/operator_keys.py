"""Per-operator validator key generation.

make_bundle.py still mints every testnet key on one machine. This module is
the other path: each operator writes a private key locally and exports only a
public bundle. The assembler refuses private material and does not invent a
new committee size. Four members and faults=1 match the current chain. Changing
that is a consensus decision and is not done here.
"""
from __future__ import annotations

import base64
import hashlib
import ipaddress
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
import stat

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

from covenant_language.safe_io import atomic_write

from .crypto import canonical, need, public_key
from .discovery import record_body, sign_record, verify_record

PUBLIC_VERSION = 'covenant-operator-public/1'


class OperatorError(ValueError):
    pass


def _secret(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(path, text, mode=0o600, exclusive=True, follow_symlinks=False)


def _certificate(key, host, days):
    now = datetime.now(timezone.utc)
    try:
        address = ipaddress.ip_address(host)
        san = x509.SubjectAlternativeName([x509.IPAddress(address)])
    except ValueError:
        san = x509.SubjectAlternativeName([x509.DNSName(host)])
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, host[:64])])
    cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(hours=1)).not_valid_after(now + timedelta(days=days))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), True)
            .add_extension(x509.KeyUsage(True, False, False, False, False, False, False, False, False), True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH, ExtendedKeyUsageOID.CLIENT_AUTH]), False)
            .add_extension(san, False)
            .sign(key, None))
    der = cert.public_bytes(serialization.Encoding.DER)
    return base64.b64encode(der).decode('ascii'), hashlib.sha256(der).hexdigest()


def generate_operator(directory, member, endpoints, now, *, days=90, lifetime=7 * 24 * 3600):
    """Write secrets into directory and return a public bundle. Secrets are not in the return value."""
    directory = Path(directory)
    if directory.exists():
        raise OperatorError('OPERATOR_DIRECTORY_EXISTS')
    directory.mkdir(parents=True, mode=0o700)
    if not endpoints:
        raise OperatorError('OPERATOR_ENDPOINTS')
    literal = [item for item in endpoints if item['kind'] == 'ip']
    consensus = Ed25519PrivateKey.generate()
    transport = Ed25519PrivateKey.generate()
    host = _host(literal[0]['url'] if literal else endpoints[0]['url'])
    der_b64, pin = _certificate(transport, host, days)
    body = record_body(member, public_key(consensus), endpoints, pin, now + lifetime, 0)
    envelope = sign_record(consensus, body)
    _secret(directory / 'signer.key', consensus.private_bytes_raw().hex() + '\n')
    _secret(directory / 'transport-key.pem', transport.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode('ascii'))
    bundle = {
        'v': PUBLIC_VERSION,
        'member': member,
        'consensus_key': public_key(consensus),
        'tls_pin': pin,
        'certificate_der_b64': der_b64,
        'literal_endpoint': literal[0]['url'] if literal else None,
        'peer_record': envelope,
    }
    encoded = canonical(bundle)
    if b'PRIVATE' in encoded or b'signer' in encoded:
        raise OperatorError('OPERATOR_PUBLIC_LEAK')
    public_path = directory / 'public.json'
    atomic_write(public_path, encoded, mode=0o644, exclusive=True, follow_symlinks=False)
    for name in ('signer.key', 'transport-key.pem'):
        mode = stat.S_IMODE(os.stat(directory / name).st_mode)
        if mode & 0o077:
            raise OperatorError('OPERATOR_KEY_MODE')
    return bundle


def _host(url):
    from urllib.parse import urlsplit
    return urlsplit(url).hostname


def _pin(der_b64):
    der = base64.b64decode(der_b64.encode('ascii'), validate=True)
    return hashlib.sha256(der).hexdigest()


def check_public_bundle(bundle, now):
    if type(bundle) is not dict or set(bundle) != {'v', 'member', 'consensus_key', 'tls_pin', 'certificate_der_b64', 'literal_endpoint', 'peer_record'}:
        raise OperatorError('OPERATOR_FIELDS')
    encoded = canonical(bundle)
    if b'PRIVATE' in encoded or bundle['v'] != PUBLIC_VERSION:
        raise OperatorError('OPERATOR_PRIVATE_MATERIAL')
    if _pin(bundle['certificate_der_b64']) != bundle['tls_pin']:
        raise OperatorError('OPERATOR_PIN')
    body = verify_record(bundle['peer_record'], now)
    need(body['member'] == bundle['member'] and body['consensus_key'] == bundle['consensus_key'], 'OPERATOR_RECORD')
    need(body['tls_pin'] == bundle['tls_pin'], 'OPERATOR_RECORD_PIN')
    if bundle['literal_endpoint'] is not None:
        matches = [item for item in body['endpoints'] if item['url'] == bundle['literal_endpoint'] and item['kind'] == 'ip']
        need(len(matches) == 1, 'OPERATOR_LITERAL')
    return body


def assemble(bundles, out, now):
    """Public material only. Writes a fragment and bootstrap file, never a signer key."""
    out = Path(out)
    if out.exists():
        raise OperatorError('ASSEMBLE_EXISTS')
    if type(bundles) is not list or len(bundles) != 4:
        raise OperatorError('ASSEMBLE_COMMITTEE_SIZE')
    members = []
    keys = []
    literals = {}
    records = []
    for bundle in bundles:
        body = check_public_bundle(bundle, now)
        if body['member'] in members or body['consensus_key'] in keys:
            raise OperatorError('ASSEMBLE_DUPLICATE')
        members.append(body['member'])
        keys.append(body['consensus_key'])
        records.append(bundle['peer_record'])
        if bundle['literal_endpoint'] is not None:
            literals[body['member']] = bundle['literal_endpoint']
    out.mkdir(parents=True, mode=0o700)
    fragment = {
        'v': 'covenant-public-genesis-fragment/1',
        'validators': {member: public for member, public in zip(members, keys)},
        'faults': 1,
        'note': 'Public keys only. Accounts, fees and protocol version are a separate genesis decision.',
        'consensus_change': False,
    }
    bootstrap = {'v': 'covenant-peer-bootstrap/1', 'records': records}
    atomic_write(out / 'public-genesis-fragment.json', canonical(fragment))
    atomic_write(out / 'discovery-bootstrap.json', canonical(bootstrap))
    if len(literals) == 4:
        atomic_write(out / 'peers.json', canonical(literals))
    else:
        atomic_write(out / 'peers.json.absent', 'overlay endpoints are discovery records; the literal-IP gateway was not configured\n')
    for path in out.iterdir():
        if b'PRIVATE' in path.read_bytes() or path.name in {'signer.key', 'transport-key.pem'}:
            raise OperatorError('ASSEMBLE_SECRET')
    return {'members': members, 'faults': 1, 'literal_peers': len(literals) == 4, 'secrets_written': False}
