"""HTTP Message Signatures (RFC 9421) and Content-Digest (RFC 9530) over messages the caller holds.

GRAFT: the wire format is the RFCs', unchanged, so any RFC 9421 signer or
verifier interoperates with an AAP agent and nothing here is AAP-specific.

* Structured Field Values (RFC 8941, as restated by RFC 9651 sections 3-4):
  strict parsing and serialisation of Dictionaries (3.2), Inner Lists (3.1.1),
  Parameters (3.1.2) and the bare items Integer, Decimal, String, Token, Byte
  Sequence and Boolean (3.3.1-3.3.6). RFC 9651 Dates and Display Strings are
  refused, and so is a repeated Dictionary or Parameter key: RFC 9421 section
  4.1 requires unique labels, and refusing removes the last-one-wins ambiguity
  a relay could exploit.
* RFC 9421: HTTP field components (section 2.1) with the ``sf``, ``key`` and
  ``req`` parameters (2.1.1, 2.1.2, 2.4); the derived components @method,
  @target-uri, @authority, @scheme, @request-target, @path, @query and
  @status (2.2.1-2.2.7, 2.2.9); the signature parameters created, expires,
  nonce, alg, keyid and tag (2.3); the signature base (2.5); Signature-Input
  and Signature (4.1, 4.2); verification (3.2) with application requirements
  (3.2.1). Verification algorithms: ed25519 (3.3.6), ecdsa-p256-sha256 (3.3.4),
  ecdsa-p384-sha384 (3.3.5), rsa-pss-sha512 (3.3.1) and rsa-v1_5-sha256
  (3.3.2). AAP agents sign with ed25519. hmac-sha256 (no shared secrets are
  held), ``bs``, ``tr`` and @query-param are refused.
* RFC 9530 section 2: Content-Digest with sha-256 and sha-512. Other
  algorithms are ignored, as section 2 allows; every supported digest present
  must match the exact body.

Keys are the caller's: an owner-adopted JWK set (RFC 7517) or AAP keys. A
keyid only selects among them and never nominates its own key (section 3.2
step 5). A verified signature says the holder of that key signed those
components with the parameters it states. It is attribution, never authority,
delivery or payment; the clock is the caller's assertion.

AAP signs ``label || 0x00 || canonical JSON`` under an uppercase ASCII label.
Every signature base starts with a double quote and holds no NUL, so one
Ed25519 key can sign both kinds of message without either replaying as the
other.
"""
from copy import deepcopy
from decimal import ROUND_HALF_EVEN, Decimal
import base64
import hashlib
import re
import string

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from .crypto import need
from . import interop_codec as codec

MAX_FIELD = 8192
MAX_HEADERS = 128
MAX_HEADER_BYTES = 65536
MAX_URI = 8192
MAX_BODY = 4 * 1024 * 1024
MAX_MEMBERS = 64
MAX_COMPONENTS = 32
MAX_SIGNATURES = 8
MAX_KEYS = 64
MAX_NONCES = 4096
MAX_INTEGER = 999_999_999_999_999
DERIVED = ('@method', '@target-uri', '@authority', '@scheme', '@request-target', '@path', '@query', '@status')
REFUSED_DERIVED = ('@query-param', '@signature-params')
PARAMETERS = {'created': int, 'expires': int, 'nonce': str, 'alg': str, 'keyid': str, 'tag': str}
ALGORITHMS = ('ed25519', 'ecdsa-p256-sha256', 'ecdsa-p384-sha384', 'rsa-pss-sha512', 'rsa-v1_5-sha256')
JOSE_ALGORITHMS = {'EdDSA': 'ed25519', 'Ed25519': 'ed25519', 'ES256': 'ecdsa-p256-sha256',
                   'ES384': 'ecdsa-p384-sha384', 'PS512': 'rsa-pss-sha512', 'RS256': 'rsa-v1_5-sha256'}
CURVES = {'P-256': (ec.SECP256R1, 32, 'ecdsa-p256-sha256'), 'P-384': (ec.SECP384R1, 48, 'ecdsa-p384-sha384')}
PRIVATE_MEMBERS = frozenset(('d', 'p', 'q', 'dp', 'dq', 'qi', 'oth', 'k'))
DIGESTS = {'sha-256': hashlib.sha256, 'sha-512': hashlib.sha512}
WEB_BOT_AUTH_TAG = 'web-bot-auth'
# Fields whose Structured Field type this module knows, for the sf and key parameters.
DICTIONARIES = frozenset(('signature-input', 'signature', 'content-digest', 'repr-digest', 'want-content-digest',
                          'signature-agent', 'accept-signature', 'ucp-agent'))
DEFAULT_PORTS = {'http': 80, 'https': 443}
TCHAR = frozenset(string.ascii_letters + string.digits + "!#$%&'*+-.^_`|~")
KEY_FIRST = frozenset(string.ascii_lowercase + '*')
KEY_REST = KEY_FIRST | frozenset(string.digits + '_-.')
B64 = frozenset(string.ascii_letters + string.digits + '+/=')
URI = re.compile(r'([A-Za-z][A-Za-z0-9+.-]*)://([^/?#]*)([^?#]*)(?:\?([^#]*))?\Z')
HOST = re.compile(r"(\[[0-9A-Fa-f:.]{2,45}\]|[A-Za-z0-9._~!$&'()*+,;=%-]{1,253})(?::([0-9]{1,5}))?\Z")

REMEDIATION = {
    'HTTPSIG_MESSAGE': 'Pass {method, target_uri, headers[, body]} for a request or {status, headers[, body, request]} for a response.',
    'HTTPSIG_URI': 'Use an absolute http(s) target URI without user information, fragment or whitespace, at most 8192 characters.',
    'HTTPSIG_HEADER': 'Headers are at most 128 [name, value] pairs: token names and visible ASCII values without CR, LF or NUL.',
    'HTTPSIG_BODY': 'Pass the exact body bytes (or UTF-8 text) of at most 4 MiB.',
    'HTTPSIG_SF': 'The header is not a strict Structured Field (RFC 8941/9651) of the expected type; refuse it rather than guess.',
    'HTTPSIG_COMPONENT': 'Cover HTTP fields (lowercase names, optional sf, key or req) or the supported derived components.',
    'HTTPSIG_COMPONENT_MISSING': 'A covered field or dictionary member is absent from the message (RFC 9421 section 2.5).',
    'HTTPSIG_DUPLICATE_COMPONENT': 'Each component identifier may be covered once (RFC 9421 section 2.5 step 2.1).',
    'HTTPSIG_PARAMS': 'Signature parameters: created and expires non-negative integers; nonce, alg, keyid and tag strings.',
    'HTTPSIG_MISSING': 'The message carries no matching Signature-Input and Signature members for the requested label or tag.',
    'HTTPSIG_COVERAGE': 'The signature does not cover every component the verifier requires; treat the message as unsigned.',
    'HTTPSIG_TAG': 'The signature tag is not the one this verifier accepts.',
    'HTTPSIG_CREATED': 'This verifier requires the created parameter.',
    'HTTPSIG_EXPIRES': 'This verifier requires the expires parameter.',
    'HTTPSIG_NONCE': 'This verifier requires a nonce.',
    'HTTPSIG_NOT_YET_VALID': 'The signature was created after the caller clock (beyond the allowed skew).',
    'HTTPSIG_EXPIRED': 'The signature is older than the allowed age or past its expires time; ask for a fresh one.',
    'HTTPSIG_WINDOW': 'expires must follow created by at most the allowed window.',
    'HTTPSIG_REPLAY': 'This nonce was already seen; refuse the replayed message.',
    'HTTPSIG_KEY': 'Adopt public JWKs (OKP Ed25519, EC P-256/P-384, RSA 2048-8192) or 64-hex AAP keys; no private members.',
    'HTTPSIG_KEY_UNKNOWN': 'keyid names no adopted key; adopt the signer key yourself, a signature cannot nominate it.',
    'HTTPSIG_KEY_AMBIGUOUS': 'keyid matches more than one adopted key; adopt keys with distinct kids.',
    'HTTPSIG_THUMBPRINT': 'A web-bot-auth signature keyid must be the RFC 7638 SHA-256 thumbprint of the key it names.',
    'HTTPSIG_ALGORITHM': 'The algorithm is unsupported or differs between the key and the alg parameter (RFC 9421 section 3.2 step 6).',
    'HTTPSIG_SIGNATURE': 'The signature does not verify over the recreated signature base.',
    'HTTPSIG_DIGEST': 'Content-Digest does not match the exact body (RFC 9530).',
    'HTTPSIG_DIGEST_ALGORITHM': 'Content-Digest carries no sha-256 or sha-512 member.',
    'HTTPSIG_POLICY': 'Pass required components as names or serialized identifiers, bounded windows and at most 4096 seen nonces.',
    'HTTPSIG_SIGNER': 'Sign with the Ed25519 private key object of the AAP key; nothing else is signed here.',
}


def remediation(code):
    return REMEDIATION.get(code, codec.remediation(code))


class Token(str):
    """A Structured Field Token (RFC 9651 section 3.3.4); a plain ``str`` is a String."""
    __slots__ = ()


class _Message(dict):
    """A validated message. Only message() builds one, so supplied JSON never skips validation."""


# Structured Field parsing (RFC 9651 section 4.2), strict and bounded.

class _Reader:
    __slots__ = ('text', 'at')

    def __init__(self, text):
        self.text, self.at = text, 0

    def peek(self):
        return self.text[self.at:self.at + 1]

    def take(self):
        char = self.text[self.at:self.at + 1]
        self.at += 1
        return char

    def spaces(self, tabs=False):
        while self.peek() == ' ' or (tabs and self.peek() == '\t'):
            self.at += 1


def _key(reader):
    need(reader.peek() != '' and reader.peek() in KEY_FIRST, 'HTTPSIG_SF')
    start = reader.at
    while reader.peek() != '' and reader.peek() in KEY_REST:
        reader.at += 1
    need(reader.at - start <= 64, 'HTTPSIG_SF')
    return reader.text[start:reader.at]


def _number(reader):
    sign, digits, decimal = 1, '', False
    if reader.peek() == '-':
        reader.take(); sign = -1
    need(reader.peek() != '' and reader.peek() in string.digits, 'HTTPSIG_SF')
    while reader.peek() != '':
        char = reader.peek()
        if char in string.digits:
            digits += reader.take()
        elif char == '.' and not decimal:
            need(len(digits) <= 12, 'HTTPSIG_SF')
            digits += reader.take(); decimal = True
        else:
            break
        need(len(digits) <= (16 if decimal else 15), 'HTTPSIG_SF')
    if not decimal:
        return sign * int(digits)
    whole, _, fraction = digits.partition('.')
    need(1 <= len(fraction) <= 3, 'HTTPSIG_SF')
    return Decimal(('-' if sign < 0 else '') + whole + '.' + fraction)


def _string(reader):
    reader.take()
    out = []
    while reader.peek() != '':
        char = reader.take()
        if char == '\\':
            escaped = reader.take()
            need(escaped in ('"', '\\'), 'HTTPSIG_SF')
            out.append(escaped)
        elif char == '"':
            return ''.join(out)
        else:
            need(' ' <= char <= '~', 'HTTPSIG_SF')
            out.append(char)
    raise ValueError('HTTPSIG_SF')


def _token(reader):
    start = reader.at
    reader.take()
    while reader.peek() != '' and (reader.peek() in TCHAR or reader.peek() in ':/'):
        reader.at += 1
    return Token(reader.text[start:reader.at])


def _bytes(reader):
    reader.take()
    end = reader.text.find(':', reader.at)
    need(end >= 0, 'HTTPSIG_SF')
    text = reader.text[reader.at:end]
    reader.at = end + 1
    content = text.rstrip('=')
    need(all(char in B64 for char in text) and '=' not in content and len(text) - len(content) <= 2, 'HTTPSIG_SF')
    try:
        # RFC 9651 section 4.2.7: synthesise missing padding; tolerate non-zero pad bits.
        return base64.b64decode(content + '=' * (-len(content) % 4), validate=True)
    except ValueError:
        raise ValueError('HTTPSIG_SF') from None


def _bare(reader):
    char = reader.peek()
    if char == '-' or (char != '' and char in string.digits):
        return _number(reader)
    if char == '"':
        return _string(reader)
    if char == ':':
        return _bytes(reader)
    if char == '?':
        reader.take()
        value = reader.take()
        need(value in ('0', '1'), 'HTTPSIG_SF')
        return value == '1'
    need(char != '' and (char in string.ascii_letters or char == '*'), 'HTTPSIG_SF')
    return _token(reader)


def _parameters(reader):
    params = {}
    while reader.peek() == ';':
        reader.take(); reader.spaces()
        name = _key(reader)
        value = True
        if reader.peek() == '=':
            reader.take(); value = _bare(reader)
        need(name not in params and len(params) < MAX_MEMBERS, 'HTTPSIG_SF')
        params[name] = value
    return params


def _item(reader):
    value = _bare(reader)
    return (value, _parameters(reader))


def _inner(reader):
    reader.take()
    items = []
    while reader.peek() != '':
        reader.spaces()
        if reader.peek() == ')':
            reader.take()
            return (items, _parameters(reader))
        items.append(_item(reader))
        need(len(items) <= MAX_MEMBERS and reader.peek() in (' ', ')'), 'HTTPSIG_SF')
    raise ValueError('HTTPSIG_SF')


def _member(reader):
    return _inner(reader) if reader.peek() == '(' else _item(reader)


def parse_dictionary(text):
    """A strict Dictionary (RFC 9651 section 4.2.2) as an ordered {key: member} map.

    A member is ``(bare, params)`` for an Item or ``([items], params)`` for an Inner List.
    """
    need(type(text) is str and len(text) <= MAX_HEADER_BYTES and text.isascii(), 'HTTPSIG_SF')
    reader = _Reader(text)
    reader.spaces()
    members = {}
    while reader.peek() != '':
        name = _key(reader)
        if reader.peek() == '=':
            reader.take(); member = _member(reader)
        else:
            member = (True, _parameters(reader))
        need(name not in members and len(members) < MAX_MEMBERS, 'HTTPSIG_SF')
        members[name] = member
        reader.spaces(tabs=True)
        if reader.peek() == '':
            break
        need(reader.take() == ',', 'HTTPSIG_SF')
        reader.spaces(tabs=True)
        need(reader.peek() != '', 'HTTPSIG_SF')
    return members


def parse_item(text):
    """A strict Item (RFC 9651 section 4.2.3) such as one covered component identifier."""
    need(type(text) is str and len(text) <= MAX_FIELD and text.isascii(), 'HTTPSIG_SF')
    reader = _Reader(text)
    reader.spaces()
    found = _item(reader)
    reader.spaces()
    need(reader.peek() == '', 'HTTPSIG_SF')
    return found


# Structured Field serialisation (RFC 9651 section 4.1).

def _serialize_bare(value):
    if type(value) is bool:
        return '?1' if value else '?0'
    if type(value) is int:
        need(-MAX_INTEGER <= value <= MAX_INTEGER, 'HTTPSIG_SF')
        return str(value)
    if type(value) is Decimal:
        need(value.is_finite(), 'HTTPSIG_SF')
        rounded = value.quantize(Decimal('0.001'), rounding=ROUND_HALF_EVEN)
        whole, _, fraction = format(abs(rounded), 'f').partition('.')
        need(len(whole.lstrip('0') or '0') <= 12, 'HTTPSIG_SF')
        return ('-' if rounded < 0 else '') + str(int(whole)) + '.' + (fraction.rstrip('0') or '0')
    if type(value) is Token:
        need(value != '' and (value[0] in string.ascii_letters or value[0] == '*')
             and all(char in TCHAR or char in ':/' for char in value), 'HTTPSIG_SF')
        return str(value)
    if type(value) is str:
        need(all(' ' <= char <= '~' for char in value), 'HTTPSIG_SF')
        return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'
    if type(value) is bytes:
        return ':' + base64.b64encode(value).decode('ascii') + ':'
    raise ValueError('HTTPSIG_SF')


def _serialize_parameters(params):
    need(type(params) is dict, 'HTTPSIG_SF')
    out = []
    for name, value in params.items():
        need(type(name) is str and _Reader(name).peek() != '' and name[0] in KEY_FIRST
             and all(char in KEY_REST for char in name), 'HTTPSIG_SF')
        out.append(';' + name + ('' if value is True else '=' + _serialize_bare(value)))
    return ''.join(out)


def serialize_item(item):
    need(type(item) is tuple and len(item) == 2 and type(item[0]) is not list, 'HTTPSIG_SF')
    return _serialize_bare(item[0]) + _serialize_parameters(item[1])


def serialize_inner_list(member):
    need(type(member) is tuple and len(member) == 2 and type(member[0]) is list, 'HTTPSIG_SF')
    return '(' + ' '.join(serialize_item(item) for item in member[0]) + ')' + _serialize_parameters(member[1])


def serialize_member(member):
    """A Dictionary member value alone (RFC 9651 section 4.1.2 member_value), as RFC 9421 section 2.1.2 signs it."""
    return serialize_inner_list(member) if type(member[0]) is list else serialize_item(member)


def serialize_dictionary(members):
    need(type(members) is dict and len(members) <= MAX_MEMBERS, 'HTTPSIG_SF')
    out = []
    for name, member in members.items():
        need(type(name) is str and name != '' and name[0] in KEY_FIRST and all(char in KEY_REST for char in name),
             'HTTPSIG_SF')
        if type(member[0]) is not list and member[0] is True:
            out.append(name + _serialize_parameters(member[1]))
        else:
            out.append(name + '=' + serialize_member(member))
    return ', '.join(out)


# RFC 9530 Content-Digest.

def _body(value):
    if value is None:
        return None
    if type(value) is str:
        value = value.encode('utf-8')
    need(isinstance(value, (bytes, bytearray)) and len(value) <= MAX_BODY, 'HTTPSIG_BODY')
    return bytes(value)


def content_digest(body, algorithms=('sha-256',)):
    """The Content-Digest field value for the exact body bytes (RFC 9530 section 2)."""
    raw = _body(body)
    need(raw is not None and type(algorithms) in (list, tuple) and 0 < len(algorithms) <= 2
         and all(name in DIGESTS for name in algorithms) and len(set(algorithms)) == len(algorithms), 'HTTPSIG_DIGEST_ALGORITHM')
    return serialize_dictionary({name: (DIGESTS[name](raw).digest(), {}) for name in algorithms})


def check_content_digest(header, body):
    """Every sha-256 and sha-512 member must match the body; other algorithms are ignored."""
    raw = _body(body)
    need(raw is not None, 'HTTPSIG_BODY')
    members = parse_dictionary(header)
    checked = []
    for name, member in members.items():
        if name not in DIGESTS:
            continue
        need(type(member[0]) is bytes, 'HTTPSIG_SF')
        need(member[0] == DIGESTS[name](raw).digest(), 'HTTPSIG_DIGEST')
        checked.append(name)
    need(bool(checked), 'HTTPSIG_DIGEST_ALGORITHM')
    return {'status': 'MATCHES', 'algorithms': checked, 'ignored': sorted(set(members) - set(checked))}


# Messages.

def _headers(value):
    rows = list(value.items()) if type(value) is dict else value
    need(type(rows) in (list, tuple) and len(rows) <= MAX_HEADERS, 'HTTPSIG_HEADER')
    out, total = [], 0
    for row in rows:
        need(type(row) in (list, tuple) and len(row) == 2 and type(row[0]) is str and type(row[1]) is str, 'HTTPSIG_HEADER')
        name, text = row
        need(0 < len(name) <= 256 and all(char in TCHAR for char in name), 'HTTPSIG_HEADER')
        need(len(text) <= MAX_FIELD and all(char == '\t' or ' ' <= char <= '~' for char in text), 'HTTPSIG_HEADER')
        total += len(name) + len(text)
        need(total <= MAX_HEADER_BYTES, 'HTTPSIG_HEADER')
        out.append((name.lower(), text))
    return out


def _target(uri):
    need(type(uri) is str and 0 < len(uri) <= MAX_URI and all('!' <= char <= '~' for char in uri), 'HTTPSIG_URI')
    found = URI.fullmatch(uri)
    need(found is not None, 'HTTPSIG_URI')
    scheme, authority, path, query = found.group(1).lower(), found.group(2), found.group(3), found.group(4)
    need(scheme in DEFAULT_PORTS and '@' not in authority, 'HTTPSIG_URI')
    host = HOST.fullmatch(authority)
    need(host is not None, 'HTTPSIG_URI')
    port = host.group(2)
    need(port is None or 0 < int(port) <= 65535, 'HTTPSIG_URI')
    normal = host.group(1).lower() + ('' if port is None or int(port) == DEFAULT_PORTS[scheme] else ':' + str(int(port)))
    need(path == '' or path.startswith('/'), 'HTTPSIG_URI')
    return {'target_uri': uri, 'scheme': scheme, 'authority': normal, 'path': path or '/', 'query': query}


def message(value, _depth=0):
    """Validate one supplied request or response; returns the normalised form the base is built from."""
    need(type(value) is dict, 'HTTPSIG_MESSAGE')
    if 'method' in value:
        need(set(value) <= {'method', 'target_uri', 'headers', 'body'} and {'method', 'target_uri', 'headers'} <= set(value),
             'HTTPSIG_MESSAGE')
        need(type(value['method']) is str and 0 < len(value['method']) <= 32
             and all(char in TCHAR for char in value['method']), 'HTTPSIG_MESSAGE')
        return _Message(kind='REQUEST', method=value['method'], **_target(value['target_uri']),
                        headers=_headers(value['headers']), body=_body(value.get('body')))
    need(set(value) <= {'status', 'headers', 'body', 'request'} and {'status', 'headers'} <= set(value), 'HTTPSIG_MESSAGE')
    need(type(value['status']) is int and 100 <= value['status'] <= 599, 'HTTPSIG_MESSAGE')
    request = None
    if value.get('request') is not None:
        need(_depth == 0, 'HTTPSIG_MESSAGE')
        request = message(value['request'], 1)
        need(request['kind'] == 'REQUEST', 'HTTPSIG_MESSAGE')
    return _Message(kind='RESPONSE', status=value['status'], headers=_headers(value['headers']),
                    body=_body(value.get('body')), request=request)


def field(normal, name):
    """The combined value of one field (RFC 9421 section 2.1): lines joined by comma and space, or None."""
    values = [text.strip(' \t') for header, text in normal['headers'] if header == name]
    return ', '.join(values) if values else None


# RFC 9421 components and the signature base.

def _component(item):
    """Validate one covered component identifier: a lowercase String with sf, key or req."""
    need(type(item) is tuple and len(item) == 2 and type(item[0]) is str and type(item[0]) is not Token
         and type(item[1]) is dict, 'HTTPSIG_COMPONENT')
    name, params = item
    need(0 < len(name) <= 256 and name == name.lower(), 'HTTPSIG_COMPONENT')
    need(set(params) <= {'sf', 'key', 'req'} and all(params[flag] is True for flag in ('sf', 'req') if flag in params),
         'HTTPSIG_COMPONENT')
    if name.startswith('@'):
        need(name in DERIVED and not {'sf', 'key'} & set(params), 'HTTPSIG_COMPONENT')
    else:
        need(all(char in TCHAR for char in name), 'HTTPSIG_COMPONENT')
        if 'key' in params:
            need(type(params['key']) is str and type(params['key']) is not Token and name in DICTIONARIES, 'HTTPSIG_COMPONENT')
        if 'sf' in params:
            need(name in DICTIONARIES, 'HTTPSIG_COMPONENT')
    return item


def component_id(item):
    return serialize_item(_component(item))


def components(names):
    """Covered components from names ('@method', 'content-digest') or serialized identifiers."""
    need(type(names) in (list, tuple) and len(names) <= MAX_COMPONENTS, 'HTTPSIG_COMPONENT')
    out = []
    for name in names:
        need(type(name) is str, 'HTTPSIG_COMPONENT')
        out.append(_component(parse_item(name) if name.startswith('"') else (name, {})))
    return out


def _derived(normal, name):
    if name == '@status':
        need(normal['kind'] == 'RESPONSE', 'HTTPSIG_COMPONENT')
        return str(normal['status'])
    need(normal['kind'] == 'REQUEST', 'HTTPSIG_COMPONENT')
    if name == '@method':
        return normal['method']
    if name == '@target-uri':
        return normal['target_uri']
    if name == '@authority':
        return normal['authority']
    if name == '@scheme':
        return normal['scheme']
    if name == '@path':
        return normal['path']
    query = normal['query']
    if name == '@query':
        return '?' + (query or '')
    return normal['path'] + ('' if query is None else '?' + query)


def _value(normal, item):
    name, params = _component(item)
    if params.get('req') is True:
        need(normal['kind'] == 'RESPONSE' and normal['request'] is not None, 'HTTPSIG_COMPONENT')
        normal = normal['request']
    if name.startswith('@'):
        return _derived(normal, name)
    combined = field(normal, name)
    need(combined is not None, 'HTTPSIG_COMPONENT_MISSING')
    if 'key' in params:
        members = parse_dictionary(combined)
        need(params['key'] in members, 'HTTPSIG_COMPONENT_MISSING')
        return serialize_member(members[params['key']])
    if 'sf' in params:
        return serialize_dictionary(parse_dictionary(combined))
    return combined


def _parameters_checked(params):
    need(type(params) is dict and len(params) <= 16, 'HTTPSIG_PARAMS')
    for name, value in params.items():
        expected = PARAMETERS.get(name)
        if expected is int:
            need(type(value) is int and 0 <= value <= MAX_INTEGER, 'HTTPSIG_PARAMS')
        elif expected is str:
            need(type(value) is str and 0 < len(value) <= 512, 'HTTPSIG_PARAMS')
        else:
            _serialize_bare(value)
    if 'created' in params and 'expires' in params:
        need(params['created'] <= params['expires'], 'HTTPSIG_PARAMS')
    return params


def signature_base(value, covered, parameters):
    """The exact signature base (RFC 9421 section 2.5) and the @signature-params value."""
    normal = value if type(value) is _Message else message(value)
    need(type(covered) is list and len(covered) <= MAX_COMPONENTS, 'HTTPSIG_COMPONENT')
    _parameters_checked(parameters)
    lines, seen = [], set()
    for item in covered:
        ident = component_id(item)
        need(ident not in seen, 'HTTPSIG_DUPLICATE_COMPONENT')
        seen.add(ident)
        lines.append(ident + ': ' + _value(normal, item))
    params_value = serialize_inner_list((list(covered), dict(parameters)))
    lines.append('"@signature-params": ' + params_value)
    base = '\n'.join(lines)
    need(base.isascii() and '\0' not in base and '\r' not in base, 'HTTPSIG_HEADER')
    return base, params_value


# Keys.

def _jwk(value):
    """A public JWK reduced to its key members; unknown public members are ignored, private ones refused."""
    need(type(value) is dict and len(value) <= 32 and not PRIVATE_MEMBERS & set(value), 'HTTPSIG_KEY')
    kty = value.get('kty')
    try:
        if kty == 'OKP':
            need(value.get('crv') == 'Ed25519', 'HTTPSIG_KEY')
            public = codec.from_okp_jwk({'kty': 'OKP', 'crv': 'Ed25519', 'x': value.get('x')})
            key = {'kty': 'OKP', 'crv': 'Ed25519', 'x': value['x']}
            return key, 'ed25519', public
        if kty == 'EC':
            need(value.get('crv') in CURVES, 'HTTPSIG_KEY')
            curve, size, algorithm = CURVES[value['crv']]
            x, y = codec.b64url_decode(value.get('x'), size), codec.b64url_decode(value.get('y'), size)
            need(len(x) == size and len(y) == size, 'HTTPSIG_KEY')
            ec.EllipticCurvePublicNumbers(int.from_bytes(x, 'big'), int.from_bytes(y, 'big'), curve()).public_key()
            return {'kty': 'EC', 'crv': value['crv'], 'x': value['x'], 'y': value['y']}, algorithm, None
        need(kty == 'RSA', 'HTTPSIG_KEY')
        n, e = codec.b64url_decode(value.get('n'), 1024), codec.b64url_decode(value.get('e'), 8)
        modulus, exponent = int.from_bytes(n, 'big'), int.from_bytes(e, 'big')
        need(n[:1] not in (b'', b'\0') and e[:1] not in (b'', b'\0') and 2048 <= modulus.bit_length() <= 8192
             and exponent % 2 == 1 and 3 <= exponent < 2**32, 'HTTPSIG_KEY')
        algorithm = JOSE_ALGORITHMS.get(value.get('alg'), value.get('alg'))
        need(algorithm in ('rsa-pss-sha512', 'rsa-v1_5-sha256'), 'HTTPSIG_ALGORITHM')
        return {'kty': 'RSA', 'n': value['n'], 'e': value['e']}, algorithm, None
    except ValueError as error:
        raise ValueError(str(error) if str(error).startswith('HTTPSIG_') else 'HTTPSIG_KEY') from None


def thumbprint(jwk):
    """RFC 7638 section 3 SHA-256 thumbprint (base64url) of a public JWK."""
    key, _, _ = _jwk(jwk)
    return codec.b64url(hashlib.sha256(codec.jcs(key)).digest())


def adopt_keys(keys):
    """Normalise owner-adopted keys: a JWK set {keys: [...]}, a list of JWKs, or 64-hex AAP keys.

    Keys marked ``use: enc`` or whose ``key_ops`` lack ``verify`` are skipped (RFC 7517 sections
    4.2-4.3), and so is a key of a type, curve or algorithm this module does not verify: it stays
    unusable without invalidating the set (as UCP signatures.md "Signature Algorithms" requires). A
    private member anywhere refuses the whole set.
    """
    rows = keys.get('keys') if type(keys) is dict else keys
    need(type(rows) in (list, tuple) and len(rows) <= MAX_KEYS, 'HTTPSIG_KEY')
    adopted = []
    for row in rows:
        if type(row) is str:
            codec.okp_jwk(row)
            row = {**codec.okp_jwk(row), 'kid': codec.jwk_thumbprint(row)}
        need(type(row) is dict, 'HTTPSIG_KEY')
        need(not PRIVATE_MEMBERS & set(row), 'HTTPSIG_KEY')
        if row.get('use') == 'enc' or (type(row.get('key_ops')) is list and 'verify' not in row['key_ops']):
            continue
        if row.get('kty') not in ('OKP', 'EC', 'RSA') or (row.get('kty') != 'RSA' and row.get('crv') not in ('Ed25519', *CURVES)) \
                or (row.get('kty') == 'RSA' and JOSE_ALGORITHMS.get(row.get('alg'), row.get('alg')) not in ('rsa-pss-sha512', 'rsa-v1_5-sha256')):
            continue
        key, algorithm, aap = _jwk(row)
        named = row.get('alg')
        # A JWK alg may be the JOSE name (RFC 7518) or the HTTP Signature Algorithms name (RFC 9421 section 6.2).
        if named is not None and JOSE_ALGORITHMS.get(named, named) != algorithm:
            continue
        kid = row.get('kid')
        need(kid is None or (type(kid) is str and 0 < len(kid) <= 512), 'HTTPSIG_KEY')
        print_ = codec.b64url(hashlib.sha256(codec.jcs(key)).digest())
        adopted.append({'kid': kid, 'thumbprint': print_, 'jwk': key, 'algorithm': algorithm, 'aap_key': aap})
    return adopted


def _public(row):
    jwk = row['jwk']
    if jwk['kty'] == 'OKP':
        return ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(row['aap_key']))
    if jwk['kty'] == 'EC':
        curve, size, _ = CURVES[jwk['crv']]
        x, y = codec.b64url_decode(jwk['x'], size), codec.b64url_decode(jwk['y'], size)
        return ec.EllipticCurvePublicNumbers(int.from_bytes(x, 'big'), int.from_bytes(y, 'big'), curve()).public_key()
    return rsa.RSAPublicNumbers(int.from_bytes(codec.b64url_decode(jwk['e'], 8), 'big'),
                                int.from_bytes(codec.b64url_decode(jwk['n'], 1024), 'big')).public_key()


def verify_raw(algorithm, row, base, signature):
    """One algorithm check (RFC 9421 section 3.3) under an adopted key row; JWS shares these encodings."""
    public = _public(row)
    try:
        if algorithm == 'ed25519':
            need(len(signature) == 64, 'HTTPSIG_SIGNATURE')
            public.verify(signature, base)
        elif algorithm.startswith('ecdsa'):
            size = 32 if algorithm == 'ecdsa-p256-sha256' else 48
            need(len(signature) == 2 * size, 'HTTPSIG_SIGNATURE')
            der = encode_dss_signature(int.from_bytes(signature[:size], 'big'), int.from_bytes(signature[size:], 'big'))
            public.verify(der, base, ec.ECDSA(hashes.SHA256() if size == 32 else hashes.SHA384()))
        elif algorithm == 'rsa-pss-sha512':
            public.verify(signature, base, padding.PSS(mgf=padding.MGF1(hashes.SHA512()), salt_length=64), hashes.SHA512())
        else:
            public.verify(signature, base, padding.PKCS1v15(), hashes.SHA256())
    except InvalidSignature:
        raise ValueError('HTTPSIG_SIGNATURE') from None


# Signing (explicit local action) and verification.

def prepare(value, covered, parameters, label='sig1'):
    """The signature base and Signature-Input member for a message; nothing is signed here."""
    need(type(label) is str and label != '' and label[0] in KEY_FIRST and all(c in KEY_REST for c in label)
         and len(label) <= 64, 'HTTPSIG_PARAMS')
    items = components(covered) if covered and type(covered[0]) is str else covered
    base, params_value = signature_base(value, items, dict(parameters))
    return {'label': label, 'signature_base': base, 'signature_params': params_value,
            'signature_input': label + '=' + params_value,
            'signature_base_sha256': hashlib.sha256(base.encode('ascii')).hexdigest(),
            'algorithm': parameters.get('alg', 'ed25519'), 'signature_created': False, 'execution_authorized': False}


def sign(prepared, private_key):
    """Explicit local owner action: Ed25519 (RFC 9421 section 3.3.6) over the exact signature base."""
    need(isinstance(private_key, ed25519.Ed25519PrivateKey) and type(prepared) is dict, 'HTTPSIG_SIGNER')
    base = prepared.get('signature_base')
    need(type(base) is str and base.startswith('"') and '\0' not in base and base.isascii()
         and prepared.get('algorithm') == 'ed25519', 'HTTPSIG_SIGNER')
    signature = private_key.sign(base.encode('ascii'))
    return {'Signature-Input': prepared['signature_input'],
            'Signature': prepared['label'] + '=' + serialize_item((signature, {}))}


def signatures(value):
    """{label: (covered items, parameters, signature bytes)} for every labelled signature a message carries."""
    normal = value if type(value) is _Message else message(value)
    inputs, values = field(normal, 'signature-input'), field(normal, 'signature')
    need(inputs is not None and values is not None, 'HTTPSIG_MISSING')
    described, signed = parse_dictionary(inputs), parse_dictionary(values)
    need(len(described) <= MAX_SIGNATURES, 'HTTPSIG_SF')
    found = {}
    for label, member in described.items():
        need(type(member[0]) is list, 'HTTPSIG_SF')
        if label not in signed:
            continue
        value = signed[label]
        need(type(value[0]) is bytes and len(value[0]) <= 1024, 'HTTPSIG_SF')
        found[label] = (member[0], _parameters_checked(member[1]), value[0])
    return found


def _required(names):
    """Plain names require that component with any sf or key parameter; serialized identifiers require exactly that one."""
    exact, named = set(), set()
    for name in names:
        need(type(name) is str, 'HTTPSIG_POLICY')
        if name.startswith('"'):
            exact.add(component_id(parse_item(name)))
        else:
            named.add(_component((name, {}))[0])
    return exact, named


def _tags(tag):
    """None accepts any signature; a string one tag; a list the tags it names, None in it meaning untagged."""
    if tag is None:
        return None
    rows = [tag] if type(tag) is str else tag
    need(type(rows) in (list, tuple) and 0 < len(rows) <= 8 and all(
        row is None or (type(row) is str and 0 < len(row) <= 128) for row in rows), 'HTTPSIG_POLICY')
    return frozenset(rows)


def _policy(now, required, max_age, max_window, skew, seen_nonces):
    need(type(now) is int and 0 <= now <= MAX_INTEGER, 'HTTPSIG_POLICY')
    for value in (max_age, max_window):
        need(value is None or (type(value) is int and 0 < value <= 2**32), 'HTTPSIG_POLICY')
    need(type(skew) is int and 0 <= skew <= 3600, 'HTTPSIG_POLICY')
    need(type(seen_nonces) in (list, tuple, set, frozenset) and len(seen_nonces) <= MAX_NONCES, 'HTTPSIG_POLICY')
    need(type(required) in (list, tuple) and len(required) <= MAX_COMPONENTS, 'HTTPSIG_POLICY')


def _one(normal, label, entry, adopted, now, policy):
    covered, params, signature = entry
    for item in covered:
        _component(item)
    idents = [component_id(item) for item in covered]
    exact, named = policy['required']
    need(exact <= set(idents) and named <= {item[0] for item in covered if 'req' not in item[1]}, 'HTTPSIG_COVERAGE')
    need(policy['tags'] is None or params.get('tag') in policy['tags'], 'HTTPSIG_TAG')
    created, expires = params.get('created'), params.get('expires')
    need(not policy['require_created'] or created is not None, 'HTTPSIG_CREATED')
    need(not policy['require_expires'] or expires is not None, 'HTTPSIG_EXPIRES')
    need(not policy['require_nonce'] or 'nonce' in params, 'HTTPSIG_NONCE')
    if created is not None:
        need(created <= now + policy['skew'], 'HTTPSIG_NOT_YET_VALID')
        need(policy['max_age'] is None or now - created <= policy['max_age'], 'HTTPSIG_EXPIRED')
    need(expires is None or now < expires, 'HTTPSIG_EXPIRED')
    if policy['max_window'] is not None:
        need(created is not None and expires is not None and expires - created <= policy['max_window'], 'HTTPSIG_WINDOW')
    need(params.get('nonce') is None or params['nonce'] not in policy['seen_nonces'], 'HTTPSIG_REPLAY')
    keyid = params.get('keyid')
    # A kid label selects first; otherwise a keyid equal to a key's RFC 7638 thumbprint selects that key.
    matches = [row for row in adopted if keyid is not None and row['kid'] == keyid] or \
        [row for row in adopted if keyid is not None and row['thumbprint'] == keyid]
    need(bool(matches), 'HTTPSIG_KEY_UNKNOWN')
    need(len(matches) == 1, 'HTTPSIG_KEY_AMBIGUOUS')
    row = matches[0]
    # Web Bot Auth (architecture draft section 4.2) binds the advertised key identity to its bytes.
    need(params.get('tag') != WEB_BOT_AUTH_TAG or keyid == row['thumbprint'], 'HTTPSIG_THUMBPRINT')
    algorithm = row['algorithm']
    named = params.get('alg', algorithm)
    need(policy['alg_aliases'].get(named, named) == algorithm and algorithm in policy['algorithms'], 'HTTPSIG_ALGORITHM')
    base, _ = signature_base(normal, covered, params)
    verify_raw(algorithm, row, base.encode('ascii'), signature)
    body = 'NOT_SUPPLIED' if normal['body'] is None else 'NOT_COVERED'
    if 'content-digest' in {item[0] for item in covered if 'req' not in item[1]} and normal['body'] is not None:
        check_content_digest(field(normal, 'content-digest'), normal['body'])
        body = 'CONTENT_DIGEST_VERIFIED'
    return {'status': 'VERIFIED', 'label': label, 'algorithm': algorithm, 'keyid': keyid, 'kid': row['kid'],
            'thumbprint': row['thumbprint'], 'aap_key': row['aap_key'], 'covered': idents,
            'parameters': {name: (value if type(value) in (int, str, bool) else serialize_item((value, {})))
                           for name, value in params.items()},
            'signature_base_sha256': hashlib.sha256(base.encode('ascii')).hexdigest(), 'body': body,
            'authority': normal['authority'] if normal['kind'] == 'REQUEST' else None,
            'clock': 'CALLER_ASSERTION', 'transport_verified': False, 'meaning': 'KEY_HOLDER_SIGNED_THESE_COMPONENTS',
            'execution_authorized': False}


def verify(value, keys, now, *, label=None, tag=None, required=(), max_age=None, max_window=None, skew=0,
           require_created=False, require_expires=False, require_nonce=False, seen_nonces=(), algorithms=ALGORITHMS,
           alg_aliases=None):
    """Verify one signature of a supplied message against owner-adopted keys (RFC 9421 section 3.2).

    With ``label`` that signature is checked; otherwise every signature whose tag ``tag`` accepts (a
    tag, a list of tags with None for untagged, or None for any) is tried in order and the first that
    verifies is returned. ``required`` names components that must be covered: a plain name with any sf
    or key parameter, a serialized identifier exactly. Any failure is refused with its code; an
    unverified message is never reported as verified. ``alg_aliases`` maps a profile's own spelling
    of an alg parameter (Visa TAP writes Ed25519) to the registry name it means.
    """
    normal = value if type(value) is _Message else message(value)
    _policy(now, required, max_age, max_window, skew, seen_nonces)
    tags = _tags(tag)
    need(type(algorithms) in (list, tuple) and set(algorithms) <= set(ALGORITHMS), 'HTTPSIG_POLICY')
    aliases = {} if alg_aliases is None else alg_aliases
    need(type(aliases) is dict and len(aliases) <= 8 and all(type(k) is str and v in ALGORITHMS for k, v in aliases.items()),
         'HTTPSIG_POLICY')
    adopted = adopt_keys(keys)
    found = signatures(normal)
    policy = {'required': _required(required), 'tags': tags, 'max_age': max_age, 'max_window': max_window, 'skew': skew,
              'require_created': require_created, 'require_expires': require_expires, 'require_nonce': require_nonce,
              'seen_nonces': frozenset(seen_nonces), 'algorithms': tuple(algorithms), 'alg_aliases': dict(aliases)}
    if label is not None:
        need(label in found, 'HTTPSIG_MISSING')
        candidates = [label]
    else:
        candidates = [name for name, entry in found.items() if tags is None or entry[1].get('tag') in tags]
    need(bool(candidates), 'HTTPSIG_MISSING')
    first = None
    for name in candidates:
        try:
            return _one(normal, name, found[name], adopted, now, policy)
        except ValueError as error:
            first = first or (str(error) if str(error) in REMEDIATION else 'HTTPSIG_SIGNATURE')
    raise ValueError(first)


def describe():
    return {'status': 'EXPERIMENTAL_GRAFT', 'rfcs': ['RFC 9421', 'RFC 9530', 'RFC 8941 / RFC 9651', 'RFC 7517', 'RFC 7638'],
            'derived_components': list(DERIVED), 'component_parameters': ['sf', 'key', 'req'],
            'refused': ['bs', 'tr', '@query-param', 'hmac-sha256', 'RFC 9651 Date and Display String'],
            'signature_parameters': list(PARAMETERS), 'verify_algorithms': list(ALGORITHMS), 'sign_algorithms': ['ed25519'],
            'content_digest': list(DIGESTS), 'known_dictionaries': sorted(DICTIONARIES),
            'keys': 'OWNER_ADOPTED_JWKS_OR_AAP_KEYS_NEVER_FETCHED', 'clock': 'CALLER_ASSERTION',
            'limits': {'field_bytes': MAX_FIELD, 'headers': MAX_HEADERS, 'header_bytes': MAX_HEADER_BYTES, 'uri': MAX_URI,
                       'body': MAX_BODY, 'members': MAX_MEMBERS, 'components': MAX_COMPONENTS,
                       'signatures': MAX_SIGNATURES, 'keys': MAX_KEYS, 'seen_nonces': MAX_NONCES},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
