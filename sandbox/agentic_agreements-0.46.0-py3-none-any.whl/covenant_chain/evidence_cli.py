"""Seal a photo by hash, read a phone GPS fix, or show the evidence level.

The image or video is written to a local content-addressed store. The
covenant-evidence/0.1 envelope carries the hash and an optional thumbnail hash.
Run: python -m covenant_chain.evidence_cli
"""
import argparse
import json
import os
import stat
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from covenant_language.safe_io import atomic_write

from .crypto import key as hexkey
from .evidence import show_payload
from .evidence_sdk import seal_file, tool_call
from .evidence_store import EvidenceStore
from .geo_fix import exif_jpeg, parse_decimal, parse_geo_uri, parse_nmea

GUIDE = {
    'EVIDENCE_ENVELOPE_SIZE': 'The envelope is a hash reference of at most 8192 bytes. The photograph stays in the evidence store.',
    'EVIDENCE_MEDIA_SIZE': 'That file is above the store limit. It was not refused because of an envelope, draft, or seal cap.',
    'EVIDENCE_SHARDS_MISSING': 'Two shards in one stripe are missing, so the file cannot be rebuilt.',
    'GEO_EXIF': 'No EXIF GPS block was found. Pass decimal degrees, an NMEA sentence, or a geo: URI.',
    'GEO_DECIMAL': 'Latitude and longitude need decimal degrees such as -0.3031,36.0800.',
    'EVIDENCE_KEY_FILE': 'The signing key file must be a regular file and not group-readable.',
    'EVIDENCE_OUTPUT_EXISTS': 'The output file already exists, and the evidence export never overwrites a file. Choose a new --out path, or move the old file aside yourself.',
}


def _key(path):
    handle = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(handle)
        if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) & 0o077:
            raise ValueError('EVIDENCE_KEY_FILE')
        raw = os.read(handle, 128)
    finally:
        os.close(handle)
    if len(raw) == 64 and all(chr(byte) in '0123456789abcdef' for byte in raw):
        raw = bytes.fromhex(raw.decode('ascii'))
    if len(raw) != 32:
        raise ValueError('EVIDENCE_KEY_FILE')
    return Ed25519PrivateKey.from_private_bytes(raw)


def _policy(args):
    policy = {}
    if args.level is not None:
        policy['level_required'] = args.level
    if args.on_shortfall is not None:
        policy['on_shortfall'] = args.on_shortfall
    return policy or None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    seal = commands.add_parser('seal', help='Store a photo or video and sign an envelope that references it by hash.')
    seal.add_argument('--photo', required=True)
    seal.add_argument('--store', required=True)
    seal.add_argument('--agreement', required=True)
    seal.add_argument('--context', required=True)
    seal.add_argument('--adapter', required=True)
    seal.add_argument('--key', required=True, help='Owner-only file of 32 raw key bytes or 64 hex characters.')
    seal.add_argument('--level', choices=('L0', 'L1', 'L2', 'L3'))
    seal.add_argument('--on-shortfall', choices=('ACCEPT', 'HOLD', 'PANEL'))
    seal.add_argument('--thumbnail')
    gps = commands.add_parser('gps', help='Read a fixed-point fix from EXIF, decimal degrees, NMEA, or a geo: URI.')
    source = gps.add_mutually_exclusive_group(required=True)
    source.add_argument('--photo')
    source.add_argument('--decimal', metavar='LAT,LON', help='Decimal degrees. Attach a leading minus: --decimal=-0.3031,36.0800')
    source.add_argument('--nmea')
    source.add_argument('--geo')
    policy = commands.add_parser('policy', help='Show the release choice a stored evidence level produces.')
    policy.add_argument('--level', choices=('L0', 'L1', 'L2', 'L3', 'ABSENT'), default='ABSENT')
    policy.add_argument('--on-shortfall', choices=('ACCEPT', 'HOLD', 'PANEL', 'ABSENT'), default='ABSENT')
    policy.add_argument('--single-source', choices=('DEFAULT', 'ADMITTED', 'ABSENT'), default='ABSENT')
    policy.add_argument('--model', choices=('DEFAULT', 'ADMITTED', 'ABSENT'), default='ABSENT')
    policy.add_argument('--assurance', choices=('SELF_ASSERTED', 'PARTY_SIGNED', 'THIRD_PARTY_SIGNED', 'CRYPTOGRAPHICALLY_VERIFIED', 'ABSENT'), default='ABSENT')
    opened = commands.add_parser('open', help='Rebuild stored bytes from the manifest hash, including one missing shard.')
    opened.add_argument('--store', required=True)
    opened.add_argument('--manifest', required=True)
    opened.add_argument('--out', required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'seal':
            for name in (args.agreement, args.context, args.adapter):
                hexkey(name)
            thumb = Path(args.thumbnail).read_bytes() if args.thumbnail else None
            result = seal_file(args.photo, args.store, _key(args.key), args.agreement, args.context, args.adapter,
                               policy=_policy(args), thumbnail=thumb)
            public = {'version': result['version'], 'content_hash': result['content_hash'], 'envelope': result['envelope'],
                      'show': show_payload(result['envelope'], 'EVIDENCE'), 'gps': result['gps'], 'observed_at': result['observed_at'],
                      'clock': result['clock'], 'store_manifest': result['store_manifest'], 'thumbnail': result['thumbnail'],
                      'policy': result['policy'], 'release': result['release'], 'photo_bytes_in_envelope': False,
                      'execution_authorized': False}
        elif args.command == 'gps':
            if args.photo:
                point, observed = exif_jpeg(Path(args.photo).read_bytes())
                public = {'fix': point, 'observed_at': observed, 'clock': 'EXIF_UTC_ASSUMED', 'execution_authorized': False}
            elif args.decimal:
                lat, _, lon = args.decimal.partition(',')
                public = {'fix': parse_decimal(lat, lon), 'execution_authorized': False}
            elif args.nmea:
                public = {'fix': parse_nmea(args.nmea), 'execution_authorized': False}
            else:
                public = {'fix': parse_geo_uri(args.geo), 'execution_authorized': False}
        elif args.command == 'policy':
            public = tool_call('policy', {'level_required': args.level, 'on_shortfall': args.on_shortfall,
                                          'single_source_release': args.single_source, 'model_release': args.model,
                                          'assurance_required': args.assurance})
        else:
            raw = EvidenceStore(args.store).read(args.manifest)
            out = Path(args.out)
            if out.exists():
                raise ValueError('EVIDENCE_OUTPUT_EXISTS')
            atomic_write(out, raw, mode=0o600, exclusive=True, follow_symlinks=False)
            public = {'manifest': args.manifest, 'bytes': len(raw), 'sha256': __import__('hashlib').sha256(raw).hexdigest(), 'execution_authorized': False}
    except (ValueError, OSError) as exc:
        code = str(exc)
        if code not in GUIDE and not code.isupper():
            code = 'EVIDENCE_CLI'
        parser.exit(2, code + ('\n' + GUIDE[code] if code in GUIDE else '') + '\n')
    print(json.dumps(public, sort_keys=True))
    return public


if __name__ == '__main__':
    main()
