"""Credit vertical for the demand exchange: term sheets, exact schedules, APR.

Amounts are integers in the currency's minor unit (cents for USD). A term sheet
is the typed part of a firm offer; nothing here lends, funds, pays, files a lien
or decides creditworthiness. Licensed judgement stays with licensed people.

APR follows Regulation Z Appendix J's actuarial method (12 CFR 1026.22(a)(1);
Appendix J paragraphs (a)(2), (b)(1), (b)(4)(ii), (b)(5)(ii) and (b)(6)), which
California (10 CCR 940(a)) and New York (23 NYCRR 600.3(b)) adopt for commercial
financing disclosures. For monthly unit periods the periodic rate i solves

    amount financed = sum_k payment_k / ((1 + f*i) * (1 + i)^(w + k - 1))

where the first period is w whole months plus f = odd days / 30, and APR = 12*i.
A single-payment loan of a year or less uses the term as its unit period.

Exact arithmetic and documented rounding: the solver works on the decimal grid
i = c / (12 * 10^6), so c is the APR in hundredths of a basis point ("cbps").
Integer Horner sums compare present values exactly; bisection returns
c = floor(true APR in cbps). Disclosure display rounds half up to one basis
point, (c + 50) // 100. Interest per period is balance * annual_bps / 120000,
rounded half up to the minor unit; a level payment is rounded half up and the
final payment clears the balance. No floating point is used.
"""
from copy import deepcopy
from fractions import Fraction
import json
import re
from functools import lru_cache
from importlib.resources import files

from .crypto import need

VERSION = 'urn:aap:exchange-credit:0.1'
NORMALISER = 'urn:aap:exchange-normaliser:credit:0.1'
DISCLOSURE_VERSION = 'urn:aap:exchange-disclosure-packs:0.1'
PRODUCTS = ('TERM_LOAN',)
PURPOSES = ('WORKING_CAPITAL', 'EQUIPMENT', 'EXPANSION', 'INVENTORY', 'REFINANCE', 'OTHER')
AMORTISATION = ('LEVEL', 'INTEREST_ONLY', 'EQUAL_PRINCIPAL')
FEE_NAMES = ('ORIGINATION', 'UNDERWRITING', 'PACKAGING', 'CLOSING', 'BROKER', 'DOCUMENTATION', 'FILING', 'OTHER')
FEE_TIMING = ('AT_FUNDING', 'WITH_FIRST_PAYMENT')
COLLATERAL = ('BLANKET_LIEN', 'EQUIPMENT', 'RECEIVABLES', 'INVENTORY', 'REAL_ESTATE', 'CASH_DEPOSIT')
GUARANTEES = ('PERSONAL', 'CORPORATE', 'GOVERNMENT_PROGRAM')
COVENANTS = ('MIN_DSCR_BPS', 'MAX_LEVERAGE_BPS', 'MIN_LIQUIDITY', 'REPORTING_MONTHLY', 'REPORTING_QUARTERLY', 'OTHER')
PREPAYMENT = ('NONE', 'PERCENT_OF_BALANCE', 'REMAINING_INTEREST')
MAX = 2**53 - 1
MAX_BPS = 100000
MAX_APR_CBPS = 12 * 10**7  # 1200 percent
GRID = 12 * 10**6
CURRENCY = re.compile(r'[A-Z]{3}\Z')
JURISDICTION = re.compile(r'US-[A-Z]{2}\Z')
INDEX = re.compile(r'[A-Z][A-Z0-9-]{1,31}\Z')
# For the requester: which way each metric is better. UNKNOWN changes need re-acceptance.
DIRECTIONS = {'apr_cbps': 'LOWER', 'apr_bps': 'LOWER', 'finance_charge': 'LOWER', 'total_of_payments': 'LOWER',
              'amount_financed': 'HIGHER', 'disbursed': 'HIGHER', 'principal': 'HIGHER', 'payment_max': 'LOWER',
              'prepayment_max': 'LOWER', 'collateral_items': 'LOWER', 'guarantees': 'LOWER', 'covenants': 'LOWER',
              'fees_total': 'LOWER', 'term_months': 'UNKNOWN', 'rate_estimated': 'LOWER'}
UNITS = {'apr_cbps': 'HUNDREDTHS_OF_A_BASIS_POINT', 'apr_bps': 'BASIS_POINTS', 'term_months': 'MONTHS',
         'collateral_items': 'COUNT', 'guarantees': 'COUNT', 'covenants': 'COUNT', 'rate_estimated': 'BOOLEAN_0_1'}


def _int(value, code, minimum=0, maximum=MAX):
    need(type(value) is int and minimum <= value <= maximum, code)
    return value


def _text(value, code, maximum=128):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value), code)
    return value


def _hash(value, code):
    need(type(value) is str and re.fullmatch(r'[0-9a-f]{64}', value) is not None, code)
    return value


def _exact(value, names, code):
    need(type(value) is dict and set(value) == set(names.split()), code)
    return value


def half_up(value):
    """Round a non-negative Fraction to the nearest integer, halves up."""
    return (value.numerator * 2 + value.denominator) // (2 * value.denominator)


def validate_want(want):
    _exact(want, 'product amount currency purpose term_months_min term_months_max collateral_offered jurisdiction',
           'CREDIT_WANT')
    need(want['product'] in PRODUCTS and want['purpose'] in PURPOSES, 'CREDIT_WANT')
    _int(want['amount'], 'CREDIT_WANT', 1)
    need(type(want['currency']) is str and CURRENCY.fullmatch(want['currency']) is not None, 'CREDIT_CURRENCY')
    _int(want['term_months_min'], 'CREDIT_WANT', 1, 360)
    _int(want['term_months_max'], 'CREDIT_WANT', want['term_months_min'], 360)
    offered = want['collateral_offered']
    need(type(offered) is list and len(offered) <= 6 and offered == sorted(set(offered))
         and all(item in COLLATERAL for item in offered), 'CREDIT_WANT')
    need(want['jurisdiction'] is None or (type(want['jurisdiction']) is str
         and JURISDICTION.fullmatch(want['jurisdiction']) is not None), 'CREDIT_WANT')
    return want


def _rate(rate):
    need(type(rate) is dict and rate.get('kind') in ('FIXED', 'INDEX_PLUS_MARGIN'), 'CREDIT_RATE')
    if rate['kind'] == 'FIXED':
        _exact(rate, 'kind bps', 'CREDIT_RATE')
        return _int(rate['bps'], 'CREDIT_RATE', 0, MAX_BPS), False
    _exact(rate, 'kind index index_bps margin_bps floor_bps cap_bps', 'CREDIT_RATE')
    need(type(rate['index']) is str and INDEX.fullmatch(rate['index']) is not None, 'CREDIT_RATE')
    _int(rate['index_bps'], 'CREDIT_RATE', 0, MAX_BPS)
    _int(rate['margin_bps'], 'CREDIT_RATE', 0, MAX_BPS)
    effective = rate['index_bps'] + rate['margin_bps']
    if rate['floor_bps'] is not None:
        effective = max(effective, _int(rate['floor_bps'], 'CREDIT_RATE', 0, MAX_BPS))
    if rate['cap_bps'] is not None:
        effective = min(effective, _int(rate['cap_bps'], 'CREDIT_RATE', 0, MAX_BPS))
    need(rate['floor_bps'] is None or rate['cap_bps'] is None or rate['floor_bps'] <= rate['cap_bps'], 'CREDIT_RATE')
    # 23 NYCRR 600.2(b): an adjustable rate is estimated from the index at disclosure plus the margin.
    return _int(effective, 'CREDIT_RATE', 0, MAX_BPS), True


def validate_terms(terms):
    _exact(terms, 'product principal currency rate fees term_months amortisation payment_frequency first_payment_days '
                  'prepayment collateral guarantees covenants', 'CREDIT_TERMS')
    need(terms['product'] in PRODUCTS and terms['amortisation'] in AMORTISATION
         and terms['payment_frequency'] == 'MONTHLY', 'CREDIT_TERMS')
    _int(terms['principal'], 'CREDIT_TERMS', 1, 10**15)
    need(type(terms['currency']) is str and CURRENCY.fullmatch(terms['currency']) is not None, 'CREDIT_CURRENCY')
    _rate(terms['rate'])
    _int(terms['term_months'], 'CREDIT_TERMS', 1, 360)
    _int(terms['first_payment_days'], 'CREDIT_TERMS', 1, 90)
    fees = terms['fees']
    need(type(fees) is list and len(fees) <= 8, 'CREDIT_FEES')
    names = []
    for fee in fees:
        _exact(fee, 'name amount timing finance_charge', 'CREDIT_FEES')
        need(fee['name'] in FEE_NAMES and fee['timing'] in FEE_TIMING and type(fee['finance_charge']) is bool, 'CREDIT_FEES')
        _int(fee['amount'], 'CREDIT_FEES', 0, terms['principal'])
        # A later non-finance charge would distort the APR; only pass-through costs at funding may be excluded.
        need(fee['finance_charge'] or fee['timing'] == 'AT_FUNDING', 'CREDIT_FEES')
        names.append(fee['name'])
    need(len(set(names)) == len(names), 'CREDIT_FEES')
    need(sum(f['amount'] for f in fees if f['timing'] == 'AT_FUNDING') < terms['principal'], 'CREDIT_FEES')
    pre = terms['prepayment']
    need(type(pre) is dict and pre.get('kind') in PREPAYMENT, 'CREDIT_PREPAYMENT')
    if pre['kind'] == 'PERCENT_OF_BALANCE':
        _exact(pre, 'kind bps months', 'CREDIT_PREPAYMENT')
        _int(pre['bps'], 'CREDIT_PREPAYMENT', 1, 1000)
        _int(pre['months'], 'CREDIT_PREPAYMENT', 1, terms['term_months'])
    else:
        _exact(pre, 'kind', 'CREDIT_PREPAYMENT')
    for field, kinds, limit, shape in (('collateral', COLLATERAL, 8, 'kind lien_position description_sha256'),
                                       ('guarantees', GUARANTEES, 4, 'kind limit_bps guarantor_role'),
                                       ('covenants', COVENANTS, 8, 'kind value text_sha256')):
        rows = terms[field]
        need(type(rows) is list and len(rows) <= limit, 'CREDIT_TERMS')
        for row in rows:
            _exact(row, shape, 'CREDIT_TERMS')
            need(row['kind'] in kinds, 'CREDIT_TERMS')
            if field == 'collateral':
                _int(row['lien_position'], 'CREDIT_TERMS', 1, 9)
                _hash(row['description_sha256'], 'CREDIT_TERMS')
            elif field == 'guarantees':
                _int(row['limit_bps'], 'CREDIT_TERMS', 1, 10000)
                _text(row['guarantor_role'], 'CREDIT_TERMS', 64)
            else:
                _int(row['value'], 'CREDIT_TERMS')
                need(row['text_sha256'] is None or _hash(row['text_sha256'], 'CREDIT_TERMS'), 'CREDIT_TERMS')
    return terms


def schedule(terms):
    """Exact integer monthly schedule. Returns payments in minor units and the interest in each."""
    validate_terms(terms)
    bps, estimated = _rate(terms['rate'])
    principal, n = terms['principal'], terms['term_months']
    rate = Fraction(bps, 120000)
    kind = terms['amortisation']
    level = None
    if kind == 'LEVEL':
        if rate == 0:
            level = half_up(Fraction(principal, n))
        else:
            growth = (1 + rate) ** n
            level = half_up(principal * rate * growth / (growth - 1))
    rows, balance = [], principal
    for k in range(1, n + 1):
        interest = half_up(balance * rate)
        if k == n:
            part = balance
        elif kind == 'LEVEL':
            part = level - interest
        elif kind == 'INTEREST_ONLY':
            part = 0
        else:
            part = principal // n
        need(0 <= part <= balance and (k == n or part < balance), 'CREDIT_TERMS')
        balance -= part
        rows.append({'month': k, 'payment': interest + part, 'interest': interest, 'principal': part, 'balance': balance})
    need(balance == 0 and sum(r['principal'] for r in rows) == principal, 'CREDIT_TERMS')
    return {'rows': rows, 'effective_bps': bps, 'estimated': estimated}


def _present_value_at_least(amount, payments, whole, odd_days, c):
    """Exact test: PV(i = c / GRID) >= amount. Integer Horner sums; no rounding anywhere.

    With b = GRID + c, PV >= amount iff
    30*GRID * GRID^whole * sum_k P_k GRID^(k-1) b^(n-k) >= amount * (30*GRID + odd*c) * b^(whole+n-1).
    """
    base = GRID + c
    acc, scale = 0, 1
    for payment in payments:
        acc = acc * base + payment * scale
        scale *= GRID
    top = whole + len(payments) - 1
    return 30 * GRID * GRID ** whole * acc >= amount * (30 * GRID + odd_days * c) * base ** top


def apr_cbps(amount_financed, payments, first_payment_days=30):
    """APR in hundredths of a basis point, floored, by Appendix J's actuarial method.

    Monthly unit periods; the first payment falls first_payment_days after funding,
    counted as whole 30-day months plus a fraction (Appendix J (b)(5)(ii), (b)(6)).
    """
    _int(amount_financed, 'CREDIT_APR', 1)
    need(type(payments) is list and 1 <= len(payments) <= 360, 'CREDIT_APR')
    for payment in payments:
        _int(payment, 'CREDIT_APR')
    need(sum(payments) > 0, 'CREDIT_APR')
    _int(first_payment_days, 'CREDIT_APR', 1, 366)
    need(sum(payments) >= amount_financed, 'CREDIT_APR_NEGATIVE')
    if len(payments) == 1:
        # Appendix J (b)(4)(ii), (b)(5)(vi)-(vii): one advance, one payment; the unit period is the term.
        per_year = (Fraction(12, first_payment_days // 30) if first_payment_days % 30 == 0
                    else Fraction(365, first_payment_days))
        value = Fraction(payments[0] - amount_financed, amount_financed) * per_year * 10**6
        need(value <= MAX_APR_CBPS, 'CREDIT_APR_RANGE')
        return value.numerator // value.denominator
    whole, odd = divmod(first_payment_days, 30)
    low, high = 0, MAX_APR_CBPS
    need(not _present_value_at_least(amount_financed, payments, whole, odd, high), 'CREDIT_APR_RANGE')
    while high - low > 1:
        middle = (low + high) // 2
        if _present_value_at_least(amount_financed, payments, whole, odd, middle):
            low = middle
        else:
            high = middle
    return low


def _payments(terms, rows):
    payments = [row['payment'] for row in rows]
    later = sum(f['amount'] for f in terms['fees'] if f['timing'] == 'WITH_FIRST_PAYMENT')
    payments[0] += later
    return payments


def normalise(terms, want=None, detail='SUMMARY'):
    """Comparable integer metrics and the computation that produced them."""
    need(detail in ('SUMMARY', 'FULL'), 'EXCHANGE_DETAIL')
    plan = schedule(terms)
    rows = plan['rows']
    payments = _payments(terms, rows)
    at_funding = [f for f in terms['fees'] if f['timing'] == 'AT_FUNDING']
    prepaid = sum(f['amount'] for f in at_funding if f['finance_charge'])
    withheld = sum(f['amount'] for f in at_funding)
    amount_financed = terms['principal'] - prepaid
    total = sum(payments)
    finance_charge = total - amount_financed
    interest = sum(row['interest'] for row in rows)
    cbps = apr_cbps(amount_financed, payments, terms['first_payment_days'])
    pre = terms['prepayment']
    if pre['kind'] == 'PERCENT_OF_BALANCE':
        balances = [terms['principal']] + [row['balance'] for row in rows]
        prepayment_max = max(half_up(Fraction(balances[k] * pre['bps'], 10000)) for k in range(pre['months']))
    elif pre['kind'] == 'REMAINING_INTEREST':
        prepayment_max = interest
    else:
        prepayment_max = 0
    metrics = {'apr_cbps': cbps, 'apr_bps': (cbps + 50) // 100, 'finance_charge': finance_charge,
               'total_of_payments': total, 'amount_financed': amount_financed, 'disbursed': terms['principal'] - withheld,
               'principal': terms['principal'], 'payment_max': max(payments), 'term_months': terms['term_months'],
               'prepayment_max': prepayment_max, 'collateral_items': len(terms['collateral']),
               'guarantees': len(terms['guarantees']), 'covenants': len(terms['covenants']),
               'fees_total': sum(f['amount'] for f in terms['fees']), 'rate_estimated': 1 if plan['estimated'] else 0}
    computation = {
        'method': 'REG_Z_APPENDIX_J_ACTUARIAL; EXACT_INTEGER_BISECTION_ON_CBPS_GRID; FLOOR_THEN_HALF_UP_TO_BPS',
        'rate': {'kind': terms['rate']['kind'], 'effective_bps': plan['effective_bps'], 'estimated': plan['estimated']},
        'amount_financed': {'principal': terms['principal'], 'minus_prepaid_finance_charges': prepaid, 'equals': amount_financed},
        'disbursed': {'principal': terms['principal'], 'minus_withheld_at_funding': withheld, 'equals': terms['principal'] - withheld},
        'payments': {'count': len(payments), 'first': payments[0], 'regular': payments[1] if len(payments) > 2 else payments[0],
                     'last': payments[-1], 'first_payment_days': terms['first_payment_days']},
        'finance_charge': {'total_of_payments': total, 'minus_amount_financed': amount_financed, 'equals': finance_charge,
                           'interest': interest, 'fees_in_finance_charge': finance_charge - interest},
        'apr': {'cbps_floor': cbps, 'percent_4dp': '%d.%04d' % divmod(cbps, 10000) if cbps < 10**8 else str(cbps),
                'display_percent': '%d.%02d%%' % divmod((cbps + 50) // 100, 100),
                'unit_periods_per_year': 12, 'tolerance': '1/8 of 1 percentage point (12 CFR 1026.22(a)(2))'}}
    result = {'vertical': 'credit', 'normaliser': NORMALISER, 'metrics': metrics, 'computation': computation,
              'binding': bind(want, terms) if want is not None else []}
    if detail == 'FULL':
        result['schedule'] = deepcopy(rows)
    return result


def bind(want, terms):
    """Reasons an offer does not answer this exact request; empty when it does."""
    validate_want(want)
    validate_terms(terms)
    reasons = []
    if terms['currency'] != want['currency']:
        reasons.append('CURRENCY_MISMATCH')
    if terms['product'] != want['product']:
        reasons.append('PRODUCT_MISMATCH')
    if terms['principal'] > want['amount']:
        reasons.append('PRINCIPAL_ABOVE_REQUEST')
    if not want['term_months_min'] <= terms['term_months'] <= want['term_months_max']:
        reasons.append('TERM_OUTSIDE_REQUEST')
    if any(row['kind'] not in want['collateral_offered'] for row in terms['collateral']):
        reasons.append('COLLATERAL_NOT_OFFERED')
    return reasons


def conditions(issuers=None):
    """Conditions-precedent templates for a business loan. Evidence closes each; the beneficiary accepts it."""
    pins = {} if issuers is None else deepcopy(issuers)
    return [
        {'id': 'kyb', 'kind': 'KYB', 'evidence': 'SD_JWT_PRINCIPAL_KYB', 'supplier': 'REQUESTER',
         'beneficiary': 'OFFEROR', 'due_after_award': 3 * 86400, 'issuers': pins.get('kyb', {})},
        {'id': 'financials', 'kind': 'VERIFIED_FINANCIALS', 'evidence': 'SD_JWT_DOSSIER_FIELDS', 'supplier': 'REQUESTER',
         'beneficiary': 'OFFEROR', 'due_after_award': 5 * 86400, 'issuers': pins.get('financials', {})},
        {'id': 'collateral', 'kind': 'COLLATERAL_PERFECTED', 'evidence': 'FILING_RECORD', 'supplier': 'REQUESTER',
         'beneficiary': 'OFFEROR', 'due_after_award': 10 * 86400, 'issuers': {}},
        {'id': 'guarantee', 'kind': 'GUARANTEES_SIGNED', 'evidence': 'SIGNED_DOCUMENT', 'supplier': 'REQUESTER',
         'beneficiary': 'OFFEROR', 'due_after_award': 10 * 86400, 'issuers': {}},
        {'id': 'insurance', 'kind': 'INSURANCE_EVIDENCE', 'evidence': 'DOCUMENT', 'supplier': 'REQUESTER',
         'beneficiary': 'OFFEROR', 'due_after_award': 10 * 86400, 'issuers': {}},
        {'id': 'no_mac', 'kind': 'NO_MATERIAL_ADVERSE_CHANGE', 'evidence': 'ATTESTATION', 'supplier': 'REQUESTER',
         'beneficiary': 'OFFEROR', 'due_after_award': 14 * 86400, 'issuers': {}},
        {'id': 'funding', 'kind': 'FUNDING_CONFIRMED', 'evidence': 'PAYMENT_OBSERVATION', 'supplier': 'OFFEROR',
         'beneficiary': 'REQUESTER', 'due_after_award': 14 * 86400, 'issuers': {}},
    ]


@lru_cache(maxsize=1)
def _disclosure_data():
    raw = files('covenant_chain').joinpath('data/exchange_disclosure_packs.json').read_bytes()
    need(len(raw) <= 262144, 'CREDIT_DISCLOSURE_PACK')
    data = json.loads(raw)
    need(type(data) is dict and data.get('profile') == DISCLOSURE_VERSION and type(data.get('packs')) is dict,
         'CREDIT_DISCLOSURE_PACK')
    for ident, pack in data['packs'].items():
        _exact(pack, 'id title jurisdiction status citations applies apr term rows signature exemptions open_questions',
               'CREDIT_DISCLOSURE_PACK')
        need(pack['id'] == ident and type(pack['rows']) is list and 1 <= len(pack['rows']) <= 16, 'CREDIT_DISCLOSURE_PACK')
    return data


def disclosure_packs():
    return deepcopy(_disclosure_data())


def _term_text(terms):
    """23 NYCRR 600.5(c) and 10 CCR 901: a year or less in days, longer terms in years and months."""
    months = terms['term_months']
    if months <= 12:
        days = terms['first_payment_days'] + 30 * (months - 1)
        return '%d days (30-day-month count; confirm against calendar dates)' % days
    years, rest = divmod(months, 12)
    return '%d year%s' % (years, '' if years == 1 else 's') + ('' if not rest else ' %d month%s' % (rest, '' if rest == 1 else 's'))


def _money(amount, currency):
    whole, cents = divmod(amount, 100)
    prefix = '$' if currency == 'USD' else currency + ' '
    return prefix + '{:,}'.format(whole) + '.%02d' % cents


def disclosure(pack_id, terms, financer, *, recipient_state=None):
    """Fields a commercial-financing disclosure pack requires for this offer. Not legal advice."""
    data = _disclosure_data()
    need(pack_id in data['packs'], 'CREDIT_DISCLOSURE_PACK')
    pack = data['packs'][pack_id]
    _text(financer, 'CREDIT_DISCLOSURE_PACK', 128)
    figures = normalise(terms)
    metrics, computation = figures['metrics'], figures['computation']
    applies = pack['applies']
    reasons = []
    if terms['currency'] != applies['currency']:
        reasons.append('CURRENCY_OUTSIDE_PACK')
    if terms['product'] not in applies['products']:
        reasons.append('PRODUCT_OUTSIDE_PACK')
    if terms['principal'] > applies['max_amount']:
        reasons.append('AMOUNT_ABOVE_THRESHOLD')
    if recipient_state is not None and recipient_state != pack['jurisdiction']:
        reasons.append('RECIPIENT_OUTSIDE_JURISDICTION')
    estimated = metrics['rate_estimated'] == 1
    values = {
        'amount_financed': _money(metrics['amount_financed'], terms['currency']),
        'apr': computation['apr']['display_percent'],
        'finance_charge': _money(metrics['finance_charge'], terms['currency']),
        'total_of_payments': _money(metrics['total_of_payments'], terms['currency']),
        'payment': _money(computation['payments']['regular'], terms['currency']) + '/month'
                   + ('' if computation['payments']['first'] == computation['payments']['regular'] else
                      '; first payment ' + _money(computation['payments']['first'], terms['currency']))
                   + ('' if computation['payments']['last'] == computation['payments']['regular'] else
                      '; final payment ' + _money(computation['payments']['last'], terms['currency'])),
        'term': _term_text(terms),
        'prepayment_finance_charge': ('up to ' + _money(metrics['prepayment_max'], terms['currency']))
                                     if metrics['prepayment_max'] else 'none beyond unpaid accrued interest',
        'prepayment_fees': 'none',
        'collateral': ', '.join(row['kind'] for row in terms['collateral']) or 'none',
        'avoidable_fees': 'none declared in the term sheet',
        'interest_rate': '%d.%02d%%' % divmod(computation['rate']['effective_bps'], 100),
    }
    rows = []
    for row in pack['rows']:
        label = row['estimated_label'] if estimated and row.get('estimated_label') else row['label']
        rows.append({'label': label, 'value': values[row['field']], 'field': row['field'],
                     'description': row['description'].replace('[name of financer]', financer)})
    return {'pack': pack['id'], 'title': pack['title'], 'jurisdiction': pack['jurisdiction'],
            'applies': not reasons, 'not_applicable_reasons': reasons, 'rows': rows,
            'apr_method': pack['apr'], 'term_rule': pack['term'], 'signature': pack['signature'],
            'exemptions_not_checked': pack['exemptions'], 'citations': pack['citations'],
            'open_questions': pack['open_questions'], 'status': pack['status'],
            'legal_advice': False, 'owner_legal_review_required': True}


def describe():
    return {'version': VERSION, 'normaliser': NORMALISER, 'products': list(PRODUCTS), 'amortisation': list(AMORTISATION),
            'rate_kinds': ['FIXED', 'INDEX_PLUS_MARGIN'], 'payment_frequency': ['MONTHLY'],
            'apr': 'Regulation Z Appendix J actuarial method; exact integer bisection; floor to 0.01 bp, display half up to 1 bp',
            'metrics': sorted(DIRECTIONS), 'directions': dict(DIRECTIONS),
            'disclosure_packs': sorted(_disclosure_data()['packs']), 'legal_advice': False,
            'not_implemented': ['open-end credit', 'sales-based financing and merchant cash advances', 'factoring',
                                'lease financing', 'multiple advances', 'United States Rule method',
                                'calendar-date odd periods (days/30 convention only)']}
