"""ANP agent descriptions and discovery pages as carriers of AAP descriptors.

Agent Network Protocol 1.2 (agent-network-protocol/AgentNetworkProtocol, tag
v1.2, Apache-2.0):

* ANP-07 Agent Description (AD): plain JSON with ``protocolType`` "ANP",
  ``protocolVersion``, ``type`` "AgentDescription", ``name``,
  ``securityDefinitions``, ``security`` and ``interfaces``; the 1.0 JSON-LD form
  (``@type`` "ad:AgentDescription") is still read. An AAP descriptor travels as one
  interface ``{"type": "StructuredInterface", "protocol": "AAP", "version":
  "covenant-signed-discovery/0.1", "content": ...}``. The content is either the
  AAP envelope, or the descriptor body covered by the AD's own
  ``DataIntegrityProof``/``eddsa-jcs-2022`` proof (W3C VC-DI-EdDSA 1.0 section
  3.3, the suite ANP-03 uses) whose verification method is self-certifying for
  the descriptor key: ``did:key`` of the key, or an e1_ did:wba whose fingerprint
  is the key's RFC 7638 thumbprint.
* ANP-08 discovery: ``/.well-known/agent-descriptions`` returns a JSON-LD
  ``CollectionPage`` of ``{"@type": "ad:AgentDescription", "name", "@id"}`` items
  and an optional ``next``; items are pointers, and descriptions the caller
  fetched for them are read like any carrier.

ANP-07 leaves its own proof suite open (its example uses
``EcdsaSecp256r1Signature2019``); such proofs are not verified and add nothing.
"""
from copy import deepcopy

from .crypto import need
from . import interop_codec as codec
from . import signed_discovery as discovery

VERSION = 'covenant-anp-discovery/0.1'
PROTOCOL_VERSION = '1.0.0'
WELL_KNOWN_PATH = '/.well-known/agent-descriptions'
AD_CONTEXT = {'@vocab': 'https://schema.org/', 'did': 'https://w3id.org/did#', 'ad': 'https://agent-network-protocol.com/ad#'}
SECURITY = {'didwba_sc': {'scheme': 'didwba', 'in': 'header', 'name': 'Authorization'}}
MAX_DOCUMENT = 65536
MAX_INTERFACES = 64
MAX_ITEMS = 256

REMEDIATION = {
    'ANP_DESCRIPTION': 'Supply an ANP-07 agent description: protocolType ANP, type AgentDescription, name, securityDefinitions and security.',
    'ANP_INTERFACE': 'Carry the descriptor in exactly one interface with protocol AAP, version covenant-signed-discovery/0.1 and content.',
    'ANP_PROOF': 'Sign the description with a DataIntegrityProof (eddsa-jcs-2022) by the descriptor key.',
    'ANP_PROOF_METHOD': 'Name a self-certifying verification method: did:key of the descriptor key or its e1_ did:wba.',
    'ANP_COLLECTION': 'Supply an ANP-08 CollectionPage with url, at most 256 items {@type, name, @id} and an optional next.',
    'ANP_DOCUMENT': 'Supply one JSON object: an agent description or a collection page.',
    'DISCOVERY_SOURCE': 'The ANP discovery source is not {source, document} with optional fetched documents and nothing else. Pass the agent description text in document.',
    'DISCOVERY_SIZE': 'The ANP document is not text or is longer than 65536 characters. Pass the description JSON as text within that size.',
    'DISCOVERY_DOCUMENTS': 'A fetched document does not answer an item the collection page lists, or came with a plain description. Pass only documents fetched from the items a CollectionPage lists.',
}


def remediation(code):
    return REMEDIATION.get(code, discovery.remediation(code))


def self_certifying(method, public_hex):
    """True when a verification method names ``public_hex`` without any resolution."""
    if type(method) is not str or len(method) > 2300:
        return False
    if method == codec.did_key(public_hex):
        return True
    did, _, fragment = method.partition('#')
    if not fragment or not did.startswith('did:wba:'):
        return False
    from .did_binding import parse_did
    try:
        return parse_did(did)['fingerprint'] == 'e1_' + codec.jwk_thumbprint(public_hex)
    except ValueError:
        return False


def _description(ad):
    need(type(ad) is dict, 'ANP_DESCRIPTION')
    if ad.get('type') == 'AgentDescription':
        need(ad.get('protocolType') == 'ANP' and type(ad.get('protocolVersion')) is str, 'ANP_DESCRIPTION')
    else:
        need(ad.get('@type') == 'ad:AgentDescription' and '@context' in ad, 'ANP_DESCRIPTION')
    need(type(ad.get('name')) is str and ad['name'] and type(ad.get('securityDefinitions')) is dict
         and 'security' in ad, 'ANP_DESCRIPTION')
    interfaces = ad.get('interfaces', [])
    need(type(interfaces) is list and len(interfaces) <= MAX_INTERFACES, 'ANP_DESCRIPTION')
    return interfaces


def extract(ad):
    """Descriptor items one parsed agent description carries."""
    interfaces = _description(ad)
    rows = [row for row in interfaces if type(row) is dict and row.get('protocol') == 'AAP']
    need(len(rows) == 1 and rows[0].get('version') == discovery.VERSION and type(rows[0].get('content')) is dict, 'ANP_INTERFACE')
    content = codec.integral(rows[0]['content'])
    if set(content) == {'body', 'signature'}:
        return [content]
    need(type(content.get('key')) is str and len(content['key']) == 64, 'ANP_INTERFACE')
    proof = ad.get('proof')
    need(type(proof) is dict and proof.get('type') == codec.DI_TYPE and proof.get('cryptosuite') == codec.DI_SUITE, 'ANP_PROOF')
    need(self_certifying(proof.get('verificationMethod'), content['key']), 'ANP_PROOF_METHOD')
    try:
        codec.di_verify(ad, content['key'])
    except ValueError:
        raise ValueError('ANP_PROOF') from None
    return [discovery.attested(content, 'W3C_EDDSA_JCS_2022', content['key'])]


def collection_items(page):
    """Pointers listed by an ANP-08 CollectionPage."""
    need(type(page) is dict and page.get('@type') == 'CollectionPage' and type(page.get('url')) is str
         and type(page.get('items')) is list and len(page['items']) <= MAX_ITEMS, 'ANP_COLLECTION')
    need('next' not in page or (type(page['next']) is str and page['next'].startswith('https://')), 'ANP_COLLECTION')
    pointers = []
    for row in page['items']:
        need(type(row) is dict and row.get('@type') == 'ad:AgentDescription' and type(row.get('@id')) is str
             and row['@id'].startswith('https://') and len(row['@id']) <= 2048, 'ANP_COLLECTION')
        pointers.append({'kind': 'ANP_AGENT_DESCRIPTION', 'url': row['@id'], 'name': str(row.get('name', ''))[:200],
                         'assurance': 'UNSIGNED_POINTER_NO_CLAIMS'})
    return pointers, page.get('next')


def source(item):
    """Signed-discovery adapter for {'source': 'ANP', 'document': text[, 'documents': [{url, body}]]}."""
    need(type(item) is dict and {'source', 'document'} <= set(item) <= {'source', 'document', 'documents'}, 'DISCOVERY_SOURCE')
    need(type(item['document']) is str and len(item['document']) <= MAX_DOCUMENT, 'DISCOVERY_SIZE')
    fetched = discovery.documents(item.get('documents'))
    try:
        value = codec.parse(item['document'], MAX_DOCUMENT, 24, 8192)
    except ValueError:
        raise ValueError('ANP_DOCUMENT') from None
    need(type(value) is dict, 'ANP_DOCUMENT')
    if value.get('@type') != 'CollectionPage':
        need(not fetched, 'DISCOVERY_DOCUMENTS')
        return extract(value), {'locator': 'anp:' + str(value.get('url', 'description'))[:256]}, [], []
    pointers, following = collection_items(value)
    items, refused = [], []
    for pointer in pointers:
        if pointer['url'] in fetched:
            try:
                found, meta = discovery.foreign_document(fetched.pop(pointer['url']))
                items.extend(found)
                pointer['fetched'] = meta['document']
            except ValueError as error:
                refused.append(str(error) if str(error).isupper() else 'ANP_DOCUMENT')
    need(not fetched, 'DISCOVERY_DOCUMENTS')  # Every supplied document must answer a listed item.
    meta = {'locator': 'anp-collection:' + value['url'][:256], 'next': following}
    return items, meta, pointers, refused


def description(envelope, url, *, did=None, owner=None, created=None, signed=True):
    """An ANP-07 agent description advertising AAP; with ``signed`` the AD proof by the key carries the body."""
    opened = discovery.open_descriptor(envelope)
    body = opened['body']
    content = deepcopy(body) if signed else deepcopy(envelope)
    interfaces = [{'type': 'StructuredInterface', 'protocol': 'AAP', 'version': discovery.VERSION,
                   'description': 'AAP signed discovery descriptor; only the agent key signature counts.', 'content': content}]
    names = {'a2a': 'A2A', 'mcp': 'MCP'}
    for row in body['endpoints']:
        if row['transport'] in names and row['uri'].startswith('https://'):
            interfaces.append({'type': 'StructuredInterface', 'protocol': names[row['transport']], 'url': row['uri'],
                               'description': names[row['transport']] + ' endpoint named by the signed descriptor.'})
    ad = {'protocolType': 'ANP', 'protocolVersion': PROTOCOL_VERSION, 'type': 'AgentDescription', 'url': url,
          'name': body['name'], 'description': body['summary'] or body['name'], 'securityDefinitions': deepcopy(SECURITY),
          'security': 'didwba_sc', 'interfaces': interfaces}
    if did is not None:
        ad['did'] = did
    if owner is not None:
        need(type(owner) is dict and set(owner) <= {'type', 'name', 'url'}, 'ANP_DESCRIPTION')
        ad['owner'] = deepcopy(owner)
    if created is not None:
        ad['created'] = codec.datetime_stamp(created)
    _description(ad)
    method = (did + '#key-1') if did is not None and self_certifying(did + '#key-1', body['key']) else codec.did_key(body['key'])
    prepared = codec.di_prepare(ad, method, created=created) if signed else None
    return {'description': ad, 'descriptor': opened['id'], 'mode': 'SIGNED_DESCRIPTION' if signed else 'CARRIER',
            'proof_options': None if prepared is None else prepared['proof_options'],
            'hash_data': None if prepared is None else prepared['hash_data'],
            'required_signers': [body['key']] if signed else [], 'signature_created': False,
            'publication': 'OWNER_PUBLISHES', 'execution_authorized': False}


def sign_description(prepared, private_key):
    """Explicit local owner action: attach the eddsa-jcs-2022 proof. Not exposed as a tool."""
    need(type(prepared) is dict and prepared.get('proof_options') is not None
         and codec.owner_key(private_key) == prepared['required_signers'][0], 'ANP_PROOF')
    return codec.di_sign(prepared['description'], prepared['proof_options'], private_key)


def collection(url, items, next_url=None):
    """An ANP-08 discovery page listing description URLs: [{name, url}]."""
    need(type(url) is str and url.startswith('https://') and type(items) is list and len(items) <= MAX_ITEMS, 'ANP_COLLECTION')
    page = {'@context': deepcopy(AD_CONTEXT), '@type': 'CollectionPage', 'url': url,
            'items': [{'@type': 'ad:AgentDescription', 'name': row['name'], '@id': row['url']} for row in items]}
    if next_url is not None:
        page['next'] = next_url
    collection_items(page)
    return page


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_ADAPTER', 'anp': 'ANP 1.2 (tag v1.2): ANP-03, ANP-07, ANP-08',
            'interface': {'type': 'StructuredInterface', 'protocol': 'AAP', 'version': discovery.VERSION},
            'proof': 'W3C_DATA_INTEGRITY_EDDSA_JCS_2022_SELF_CERTIFYING_METHOD_ONLY', 'well_known_path': WELL_KNOWN_PATH,
            'forms': ['CARRIER', 'SIGNED_DESCRIPTION'], 'remediation': dict(REMEDIATION),
            'network_accessed': False, 'execution_authorized': False}
