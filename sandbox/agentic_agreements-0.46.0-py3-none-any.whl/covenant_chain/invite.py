"""Self-verifying invite bundles that compile to a native BIND.

No new consensus operation. The first fee is an ``ECON_SPONSOR_CREATE`` escrow
the issuer already funds. The pool is emitted only after the invitee accepts,
and ``economics.charge`` spends it only when a listed actor submits ``BIND``.
Closing the pool before that bind returns the remainder.

The inviter signs the bundle and is the accountable party. Unanswered and
abusive invites dent a view. They do not move a reputation balance.
"""
from copy import deepcopy
import base64
import re
import secrets

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from . import webauthn
from .app import EFFECTS, assent, make_transaction
from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verify
from .onboarding import verifier_pins

VERSION = 'covenant-invite/0.1'
SIGN_LABEL = 'COVENANT-INVITE-0.1'
CONSENSUS_CHANGE = None
ROLES = {'COUNTERPARTY': 'counterparty', 'RESOLVER': 'resolver', 'APPEAL_RESOLVER': 'appeal_resolver'}
METHODS = {'EPHEMERAL_KEY', 'PASSKEY', 'EXISTING_KEY'}
BODY_FIELDS = (
    'version chain role inviter principal agent counterparty resolver appeal_resolver '
    'mandate profile resource quantity effect destination executor deadline '
    'challenge_blocks timeout terms_hash terms_pin projection expiry unit_fee '
    'sponsor_resource sponsor_expiry nonce owner_cap verifiers'
)
HEX128 = re.compile(r'[0-9a-f]{128}\Z')


def _hash128(value):
    need(type(value) is str and bool(HEX128.fullmatch(value)), 'INVITE_HASH')


def _party(value, *, nullable=False):
    if value is None and nullable:
        return
    key(value)


def pin_source(raw, title='Invite terms'):
    """Pin exact term bytes with the existing external-draft packer."""
    from covenant_language.external_drafts import pack
    need(type(raw) is bytes and 0 < len(raw) <= 8192, 'INVITE_TERMS_SIZE')
    pinned = pack(base64.b64encode(raw).decode('ascii'), title=title)
    key(pinned['source_sha256'])
    key(pinned['id'])
    return {
        'terms_hash': pinned['source_sha256'],
        'terms_pin': pinned['id'],
        'document': pinned['document'],
        'execution_authorized': False,
    }


def project_terms(clauses, descriptions=None):
    """Optional binding projection. Party names are roles, not a second ledger."""
    from covenant_language.agentic import make_binding_projection, object_id
    projection = make_binding_projection(
        ['agent', 'counterparty', 'resolver', 'appeal'], clauses, descriptions=descriptions or {})
    ident = object_id(projection)
    _hash128(ident)
    return {'projection': projection, 'id': ident, 'binding': False}


class InviteDesk:
    """Per-owner cap, accountability view, and sponsor payload. Not a chain table."""

    def __init__(self, *, per_owner_cap=8):
        integer(per_owner_cap, True)
        need(per_owner_cap <= 64, 'INVITE_CAP')
        self.per_owner_cap = per_owner_cap
        self.rows = {}
        self.credentials = {}
        self.passkeys = {}

    def _owner_rows(self, inviter):
        return [row for row in self.rows.values() if row['body']['inviter'] == inviter]

    def _open_count(self, inviter):
        return sum(row['status'] in {'OPEN', 'ACCEPTED'} for row in self._owner_rows(inviter))

    def _penalty(self, inviter):
        return sum(row['unanswered'] + row['abusive'] for row in self._owner_rows(inviter))

    def register_passkey(self, credential_id, public_key, *, rp_id, origin, user_verification=False, sign_count=0):
        """Keep the credential record from the owner's WebAuthn registration ceremony.

        The record, never an assertion, supplies the key each invite assertion is
        checked against (WebAuthn Level 3 sections 7.1 and 7.2, ``webauthn``).
        A credential is registered once and accepts at most one invite here.
        """
        made = webauthn.record(credential_id, public_key, rp_id=rp_id, origin=origin,
                               user_verification=user_verification, sign_count=sign_count)
        return webauthn.register(self.passkeys, made)

    def issue(self, private_key, offer, *, terms_document=None, height):
        integer(height)
        body = self._body(public_key(private_key), offer, height)
        inviter = body['inviter']
        need(self._open_count(inviter) < self.per_owner_cap, 'INVITE_CAP')
        need(self._penalty(inviter) < self.per_owner_cap, 'INVITE_UNANSWERED_CAP')
        bundle = {
            'body': body,
            'signature': sign(private_key, SIGN_LABEL, body),
        }
        if terms_document is not None:
            self._document(body, terms_document)
            bundle['terms_document'] = deepcopy(terms_document)
        ident = digest(SIGN_LABEL, body)
        bundle['id'] = ident
        verify(inviter, SIGN_LABEL, body, bundle['signature'])
        self.rows[ident] = {
            'body': deepcopy(body), 'status': 'OPEN', 'invitee': None,
            'unanswered': 0, 'abusive': 0, 'bound': False,
        }
        return {
            'bundle': bundle,
            'sponsor_payload': None,
            'paid': False,
            'reason': 'SPONSOR_ESCROW_WAITS_FOR_ACCEPT_AND_CHARGE_WAITS_FOR_BIND',
            'execution_authorized': False,
            'submitted': False,
        }

    def _body(self, inviter, offer, height):
        exact(offer, (
            'chain role principal agent counterparty resolver appeal_resolver mandate profile '
            'resource quantity effect destination executor deadline challenge_blocks timeout '
            'terms_hash terms_pin projection expiry unit_fee sponsor_resource sponsor_expiry'
        ))
        key(offer['chain'])
        need(offer['role'] in ROLES, 'INVITE_ROLE')
        field = ROLES[offer['role']]
        for name in ('agent', 'counterparty', 'resolver', 'appeal_resolver'):
            _party(offer[name], nullable=(name == field))
        need(offer[field] is None, 'INVITE_ROLE_ALREADY_FILLED')
        known = [offer[name] for name in ('agent', 'counterparty', 'resolver', 'appeal_resolver') if offer[name]]
        need(len(known) == len(set(known)) == 3, 'INVITE_PARTIES')
        key(inviter)
        need(inviter in set(known), 'INVITE_ACCOUNTABLE_PARTY')
        _party(offer['principal'])
        if offer['mandate'] is None:
            need(offer['principal'] == offer['agent'], 'PRINCIPAL_AUTHORITY')
        else:
            key(offer['mandate'])
        need(type(offer['profile']) is str and 0 < len(offer['profile']) <= 80, 'INVITE_PROFILE')
        need(type(offer['resource']) is str and 0 < len(offer['resource']) <= 80, 'INVITE_RESOURCE')
        integer(offer['quantity'], True)
        need(offer['effect'] in EFFECTS, 'EFFECT')
        need(type(offer['destination']) is str and 0 < len(offer['destination']) <= 256, 'EFFECT')
        key(offer['executor'])
        integer(offer['deadline'], True)
        integer(offer['challenge_blocks'], True)
        need(offer['challenge_blocks'] <= 10000 and offer['deadline'] > height, 'DEADLINE')
        need(offer['timeout'] in {'RELEASE_IF_UNDECIDED', 'HOLD_FOR_RESOLUTION'}, 'TIMEOUT_POLICY')
        key(offer['terms_hash'])
        key(offer['terms_pin'])
        if offer['projection'] is not None:
            _hash128(offer['projection'])
        integer(offer['expiry'], True)
        need(height < offer['expiry'] <= offer['deadline'], 'INVITE_EXPIRY')
        integer(offer['unit_fee'], True)
        need(type(offer['sponsor_resource']) is str and offer['sponsor_resource'] == offer['resource'], 'INVITE_SPONSOR_RESOURCE')
        integer(offer['sponsor_expiry'], True)
        need(offer['sponsor_expiry'] > height, 'SPONSOR_EXPIRY')
        body = {name: deepcopy(offer[name]) for name in offer}
        body.update(version=VERSION, inviter=inviter, nonce=secrets.token_hex(32),
                    owner_cap=self.per_owner_cap, verifiers=verifier_pins())
        exact(body, BODY_FIELDS)
        canonical(body)
        return body

    def verify_bundle(self, bundle, *, height=None):
        exact(bundle, 'body signature id' if 'terms_document' not in bundle else 'body signature id terms_document')
        body = bundle['body']
        exact(body, BODY_FIELDS)
        need(body['version'] == VERSION, 'INVITE_VERSION')
        key(body['chain'])
        key(body['inviter'])
        need(digest(SIGN_LABEL, body) == bundle['id'], 'INVITE_ID')
        verify(body['inviter'], SIGN_LABEL, body, bundle['signature'])
        if height is not None:
            integer(height)
            need(height <= body['expiry'], 'INVITE_EXPIRED')
        if 'terms_document' in bundle:
            self._document(body, bundle['terms_document'])
        return deepcopy(body)

    def _document(self, body, document):
        from covenant_language.external_drafts import inspect
        opened = inspect(document, body['terms_pin'])
        need(opened['manifest']['sha256'] == body['terms_hash'], 'INVITE_TERMS_PIN')

    def accept(self, bundle, method, *, height, private_key=None, assertion=None, origin=None, store=None):
        body = self.verify_bundle(bundle, height=height)
        ident = bundle['id']
        need(ident in self.rows and self.rows[ident]['status'] == 'OPEN', 'INVITE_STATE')
        need(method in METHODS, 'INVITE_METHOD')
        credential = update = None
        if method == 'PASSKEY':
            stored = webauthn.lookup(self.passkeys, assertion)
            update = webauthn.verify(bytes.fromhex(ident), assertion, stored, origin=origin)
            credential = update['credential_id']
            need(credential not in self.credentials, 'PASSKEY_REUSE')
        if method == 'EXISTING_KEY':
            need(private_key is not None and store is None, 'INVITE_KEY')
            invitee_key = private_key
            secret = None
        elif store is not None:
            invitee_key = store.ensure()
            secret = None
        else:
            invitee_key = Ed25519PrivateKey.generate()
            secret = invitee_key.private_bytes_raw().hex()
        invitee = public_key(invitee_key)
        terms = self.terms(body, invitee)
        accepted = {
            'version': VERSION,
            'invite': ident,
            'method': method,
            'invitee': invitee,
            'credential_id': credential,
            'passkey_verified': method == 'PASSKEY',
            'terms': terms,
            'assent': assent(invitee_key, terms),
            'sponsor_payload': self.sponsor_payload(body, invitee),
            'missing_assents': ['inviter'],
            'paid': False,
            'execution_authorized': False,
            'submitted': False,
        }
        if secret is not None:
            accepted['local_key'] = secret
        row = self.rows[ident]
        row['status'] = 'ACCEPTED'
        row['invitee'] = invitee
        if credential is not None:
            self.credentials[credential] = ident
            # WebAuthn Level 3 section 7.2 step 24, once every other check of this acceptance passed.
            self.passkeys[credential]['sign_count'] = update['sign_count']
        return accepted

    def terms(self, body, invitee):
        field = ROLES[body['role']]
        need(body[field] is None, 'INVITE_ROLE_ALREADY_FILLED')
        key(invitee)
        filled = deepcopy(body)
        filled[field] = invitee
        parties = [filled[name] for name in ('agent', 'counterparty', 'resolver', 'appeal_resolver')]
        need(len(set(parties)) == 4, 'INVITE_PARTIES')
        need(filled['agent'] != filled['counterparty'], 'DISTINCT_PARTIES')
        need(filled['resolver'] not in {filled['agent'], filled['counterparty']}, 'RESOLVER_CONFLICT')
        need(filled['appeal_resolver'] not in {filled['agent'], filled['counterparty'], filled['resolver']}, 'RESOLVER_CONFLICT')
        return {
            'chain': filled['chain'],
            'principal': filled['principal'],
            'agent': filled['agent'],
            'counterparty': filled['counterparty'],
            'mandate': filled['mandate'],
            'profile': filled['profile'],
            'resource': filled['resource'],
            'quantity': filled['quantity'],
            'effect': filled['effect'],
            'destination': filled['destination'],
            'executor': filled['executor'],
            'resolver': filled['resolver'],
            'appeal_resolver': filled['appeal_resolver'],
            'deadline': filled['deadline'],
            'challenge_blocks': filled['challenge_blocks'],
            'timeout': filled['timeout'],
            'terms_hash': filled['terms_hash'],
        }

    def sponsor_payload(self, body, invitee):
        """One-fee escrow for the party who can submit BIND. Not spent until that BIND."""
        key(invitee)
        if body['role'] == 'COUNTERPARTY':
            actors = [invitee]
        else:
            actors = [body['inviter']]
        payload = {
            'resource': body['sponsor_resource'],
            'budget': body['unit_fee'],
            'actors': actors,
            'operations': ['BIND'],
            'per_actor_cap': body['unit_fee'],
            'expiry': body['sponsor_expiry'],
        }
        return {
            'operation': 'ECON_SPONSOR_CREATE',
            'payload': payload,
            'pot': 'EXISTING_SPONSOR_ESCROW',
            'new_treasury': False,
            'pays': 'ONLY_WHEN_LISTED_ACTOR_SUBMITS_BIND',
            'invite': digest(SIGN_LABEL, body),
            'execution_authorized': False,
            'submitted': False,
        }

    def inviter_assent(self, bundle, acceptance, inviter_key):
        """The accountable inviter signs the completed terms. This is not the BIND submission."""
        body = self.verify_bundle(bundle)
        need(public_key(inviter_key) == body['inviter'], 'INVITE_ACCOUNTABLE_PARTY')
        terms = acceptance['terms']
        need(terms == self.terms(body, acceptance['invitee']), 'INVITE_TERMS')
        signed = assent(inviter_key, terms)
        return {'assent': signed, 'missing_assents': [], 'submitted': False, 'execution_authorized': False}

    def compile_bind(self, bundle, acceptance, *, nonce, protocol, fee_policy, sponsor, max_amount,
                     inviter_key=None, invitee_key=None, inviter_assent_value=None):
        """Signed native BIND. The caller submits it. Building it does not mark the invite paid."""
        body = self.verify_bundle(bundle)
        need(acceptance['invite'] == bundle['id'], 'INVITE_ACCEPTANCE')
        terms = acceptance['terms']
        need(terms == self.terms(body, acceptance['invitee']), 'INVITE_TERMS')
        invitee_assent = acceptance['assent']
        verify(acceptance['invitee'], 'COVENANT-ASSENT-0.1', terms, invitee_assent['signature'])
        if inviter_assent_value is None:
            need(inviter_key is not None, 'INVITE_KEY')
            inviter_assent_value = assent(inviter_key, terms)
        verify(body['inviter'], 'COVENANT-ASSENT-0.1', terms, inviter_assent_value['signature'])
        need(inviter_assent_value['signer'] == body['inviter'], 'INVITE_ACCOUNTABLE_PARTY')
        signers = {invitee_assent['signer'], inviter_assent_value['signer']}
        need(signers == {terms['agent'], terms['counterparty']}, 'ASSENT_PARTIES')
        if body['role'] == 'COUNTERPARTY':
            need(invitee_key is not None and public_key(invitee_key) == acceptance['invitee'], 'INVITE_KEY')
            actor_key = invitee_key
        else:
            need(inviter_key is not None and public_key(inviter_key) == body['inviter'], 'INVITE_KEY')
            actor_key = inviter_key
        actor = public_key(actor_key)
        need(actor in {terms['agent'], terms['counterparty']}, 'SUBMIT_PARTY')
        integer(nonce)
        integer(max_amount)
        key(fee_policy)
        if sponsor is not None:
            key(sponsor)
        fee = {'policy': fee_policy, 'max_amount': max_amount, 'sponsor': sponsor}
        assents = sorted((inviter_assent_value, invitee_assent), key=lambda row: row['signer'])
        tx = make_transaction(actor_key, terms['chain'], nonce, 'BIND',
                              {'terms': terms, 'assents': assents}, protocol, fee=fee)
        return {
            'transaction': tx,
            'operation': 'BIND',
            'agreement_preview': terms,
            'missing_assents': [],
            'sponsor': sponsor,
            'paid': False,
            'submitted': False,
            'execution_authorized': False,
            'consensus_operation_added': False,
        }

    def expire(self, ident, height):
        integer(height)
        row = self._row(ident)
        need(row['status'] in {'OPEN', 'ACCEPTED'} and height > row['body']['expiry'], 'INVITE_EXPIRE')
        row['status'] = 'EXPIRED'
        row['unanswered'] = 1
        return self.accountability(row['body']['inviter'])

    def mark_abusive(self, ident):
        row = self._row(ident)
        need(row['status'] != 'BOUND', 'INVITE_STATE')
        row['abusive'] = 1
        if row['status'] in {'OPEN', 'ACCEPTED'}:
            row['status'] = 'ABUSIVE'
        return self.accountability(row['body']['inviter'])

    def note_bound(self, ident, agreement_terms):
        row = self._row(ident)
        need(row['status'] == 'ACCEPTED' and row['invitee'] is not None, 'INVITE_STATE')
        expected = self.terms(row['body'], row['invitee'])
        need(agreement_terms == expected, 'INVITE_TERMS')
        row['status'] = 'BOUND'
        row['bound'] = True
        row['unanswered'] = 0
        return self.accountability(row['body']['inviter'])

    def _row(self, ident):
        key(ident)
        need(ident in self.rows, 'INVITE_UNKNOWN')
        return self.rows[ident]

    def accountability(self, inviter):
        key(inviter)
        rows = self._owner_rows(inviter)
        bound = sum(row['bound'] for row in rows)
        unanswered = sum(row['unanswered'] for row in rows)
        abusive = sum(row['abusive'] for row in rows)
        return {
            'inviter': inviter,
            'open': self._open_count(inviter),
            'bound': bound,
            'unanswered': unanswered,
            'abusive': abusive,
            'dent': unanswered + 2 * abusive,
            'cap': self.per_owner_cap,
            'view': 'INVITER_ACCOUNTABILITY',
            'reputation_balance': False,
            'feeds_discovery_rank': 'A_SIGNED_ENDORSE_IS_SEPARATE_THIS_VIEW_DOES_NOT_WRITE_ONE',
            'execution_authorized': False,
        }


def single_fee_payload(payload, amount):
    """Narrow an accepted sponsor payload to the exact quoted BIND fee."""
    integer(amount, True)
    need(payload['operation'] == 'ECON_SPONSOR_CREATE', 'INVITE_SPONSOR')
    out = deepcopy(payload)
    need(amount <= out['payload']['budget'], 'INVITE_FEE')
    out['payload']['budget'] = amount
    out['payload']['per_actor_cap'] = amount
    out['pays'] = 'ONE_BIND_FEE_THEN_CAP_IS_EXHAUSTED'
    return out


def _b64url(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def passkey_challenge(invite_id):
    key(invite_id)
    return _b64url(bytes.fromhex(invite_id))


def verify_passkey(invite_id, assertion, *, origin=None):
    """Retired: an assertion cannot vouch for its own key.

    This used to check the signature with a ``public_key`` the assertion itself
    carried, so any freshly generated P-256 key passed as a passkey. WebAuthn
    Level 3 section 7.2 step 6 takes the key from the relying party's
    credential record instead. Register the passkey with
    ``InviteDesk.register_passkey`` and accept through ``InviteDesk.accept``;
    ``webauthn.verify`` checks one assertion against one stored record. Kept
    so an old caller fails closed with a named refusal, whatever it passes.
    """
    key(invite_id)
    need(type(assertion) is dict and 'public_key' not in assertion, 'PASSKEY_ASSERTION_KEY')
    raise ValueError('PASSKEY_NOT_REGISTERED')


def transports(bundle, *, origin_label='covenant:invite'):
    """Local artifacts. Nothing is fetched, mailed, or dialed."""
    ident = bundle['id']
    key(ident)
    raw = canonical(bundle)
    link = origin_label + '/' + ident
    need(type(origin_label) is str and origin_label.startswith('covenant:'), 'INVITE_LINK')
    email = (
        'MIME-Version: 1.0\r\n'
        'Content-Type: application/vnd.covenant-invite+json\r\n'
        'Content-Transfer-Encoding: base64\r\n'
        '\r\n' + base64.b64encode(raw).decode('ascii') + '\r\n'
    )
    from covenant_language.survival import archive_digest, encode
    paper = encode(raw, copies=1, chunk_bytes=48)
    return {
        'url': link,
        'qr_payload': link,
        'qr_image': 'NOT_RENDERED_PAYLOAD_ONLY',
        'email': email,
        'email_sent': False,
        'a2a': {
            'kind': 'INVITE',
            'media_type': 'application/vnd.covenant-invite+json',
            'text': raw.decode('ascii'),
            'binding': False,
            'remote_delivery': False,
        },
        'paper': paper,
        'paper_sha512': archive_digest(raw),
        'paper_codec': 'COVENANT-SURVIVAL/1',
        'execution_authorized': False,
    }
