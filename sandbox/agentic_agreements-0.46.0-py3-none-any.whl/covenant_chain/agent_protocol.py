"""Agent Protocol (runs, threads and store) serving AAP's tools.

Agent Protocol 0.1.6 (langchain-ai/agent-protocol, openapi.json, OpenAPI 3.1)
standardises how a client starts and follows agent runs: ``/agents``,
``/threads``, ``/runs`` and a key-value ``/store``. This adapter serves one
agent, ``aap``. A run's input is ``{"tool": name, "arguments": {...}}``; the
run calls that installed tool through the same MCP host as covenant-agent
(agent_server.Server), so schemas, refusals and results are identical, and its
values are ``{"tool", "result", "isError"}``. Threads keep their metadata and
the last run's values; the store keeps owner-local items.

The adapter also serves ``POST /aap/tools/{tool}``, ``/openapi.json`` and
``/.well-known/agents.json`` (covenant_chain.agents_json). It never dials out:
webhooks, streaming, interrupts and message-style input are refused with a
code and a fix. Runs complete before the response; ``cancel`` therefore only
ever finds finished runs. The host it wraps decides authority: the default
keyless host cannot sign or pay. State is a private SQLite file (WAL,
synchronous FULL). Bind it to loopback; it does no authentication itself.
"""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sqlite3
import stat
import threading
import time
import uuid

from . import agents_json
from .agent_server import Server

VERSION = 'covenant-agent-protocol/0.1'
PROTOCOL = '0.1.6'
AGENT_ID = 'aap'
MAX_BODY = 262144
MAX_THREADS = 10000
MAX_RUNS = 100000
MAX_ITEMS = 10000
MAX_ITEM_BYTES = 65536
META = {'io.modelcontextprotocol/protocolVersion': '2026-07-28', 'io.modelcontextprotocol/clientCapabilities': {},
        'io.modelcontextprotocol/clientInfo': {'name': 'aap-agent-protocol', 'version': '0.1'}}

FIX = {
    'NOT_FOUND': 'Use an id this server returned, or create the thread first (if_not_exists: create).',
    'INVALID_BODY': 'Send one JSON object of at most 262144 bytes with the fields the Agent Protocol schema names.',
    'INVALID_INPUT': 'Send input {"tool": an installed tool name, "arguments": an object}. Ask covenant_explain for the schema.',
    'MESSAGES_UNSUPPORTED': 'Send input {tool, arguments}; message-style input is not interpreted by this adapter.',
    'WEBHOOK_UNSUPPORTED': 'Omit webhook: this adapter never calls out. Poll GET /runs/{run_id} instead.',
    'STREAMING_UNSUPPORTED': 'Use POST /runs/wait or POST /runs; runs finish before the response.',
    'THREAD_EXISTS': 'Use a new thread_id, or if_exists: do_nothing to read the existing thread.',
    'RUN_FINISHED': 'Runs finish before the response, so there is nothing to cancel.',
    'QUOTA': 'This server holds its maximum of threads, runs or items. Delete old ones or start another directory.',
    'ITEM_TOO_LARGE': 'Keep each store value within 65536 bytes of JSON.',
    'UNKNOWN_TOOL': 'Call an installed tool; GET /openapi.json lists them.',
    'METHOD': 'Use a method and path from GET /openapi.json or the Agent Protocol 0.1.6 subset this adapter serves.',
}


class ProtocolError(Exception):
    def __init__(self, status, code):
        super().__init__(code)
        self.status, self.code = status, code


def _error(status, code):
    return status, {'code': code, 'message': code.replace('_', ' ').lower(),
                    'metadata': {'fix': FIX[code], 'retry_helps': False, 'reference': 'docs/AGENT_PROTOCOL.html#errors'}}


def _private(directory):
    path = Path(directory)
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = os.stat(path, follow_symlinks=False)
    if not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode) & 0o077 or info.st_uid != os.getuid():
        raise ValueError('AGENT_PROTOCOL_PRIVATE_DIRECTORY')
    database = path / 'agent-protocol.sqlite'
    fd = os.open(database, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600); os.close(fd)
    return database


class AgentProtocolHost:
    """Agent Protocol routes over an installed AAP tool host (RuntimeHost(...).tools or AgentTools)."""
    def __init__(self, tools, directory, *, base_url='http://127.0.0.1', clock=time.time):
        self.tools, self.base_url, self.clock = tools, base_url.rstrip('/'), clock
        self.server = Server(tools, profile='full')
        self.lock = threading.RLock()
        self.db = sqlite3.connect(_private(directory), isolation_level=None, timeout=10, check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS threads(id TEXT PRIMARY KEY, created REAL NOT NULL, body TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, thread TEXT, created REAL NOT NULL, body TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS items(namespace TEXT NOT NULL, key TEXT NOT NULL, created REAL NOT NULL, '
                        'body TEXT NOT NULL, PRIMARY KEY(namespace, key))')

    def close(self):
        with self.lock:
            self.db.close()

    def _now(self):
        moment = self.clock()
        return moment, datetime.fromtimestamp(moment, timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')

    def _names(self):
        return {tool['name'] for tool in self.tools.list_tools()}

    def agent(self):
        return {'agent_id': AGENT_ID, 'name': 'Agentic Agreements Protocol (AAP)',
                'description': agents_json.MODEL, 'metadata': {'adapter': VERSION, 'agent_protocol': PROTOCOL},
                'capabilities': {'ap.io.messages': False, 'ap.io.streaming': False}}

    def _schemas(self):
        names = sorted(self._names())
        return {'agent_id': AGENT_ID,
                'input_schema': {'type': 'object', 'required': ['tool', 'arguments'], 'additionalProperties': False,
                                 'properties': {'tool': {'type': 'string', 'enum': names}, 'arguments': {'type': 'object'}}},
                'output_schema': {'type': 'object', 'properties': {'tool': {'type': 'string'}, 'result': {},
                                                                   'isError': {'type': 'boolean'}}},
                'state_schema': None, 'config_schema': None}

    def _call(self, tool, arguments):
        if tool not in self._names():
            raise ProtocolError(404, 'UNKNOWN_TOOL')
        reply = self.server.handle({'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
                                    'params': {'name': tool, 'arguments': arguments, '_meta': dict(META)}})
        if 'error' in reply:
            return {'content': [{'type': 'text', 'text': reply['error']['message']}], 'isError': True,
                    'structuredContent': {'code': 'MCP_ERROR', 'error': reply['error']}}
        result = dict(reply['result']); result.pop('_meta', None); result.pop('resultType', None)
        return result

    # Threads ---------------------------------------------------------------

    def _thread(self, thread_id):
        row = self.db.execute('SELECT body FROM threads WHERE id=?', (thread_id,)).fetchone()
        if row is None:
            raise ProtocolError(404, 'NOT_FOUND')
        return json.loads(row[0])

    def _save_thread(self, thread):
        self.db.execute('INSERT INTO threads VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body',
                        (thread['thread_id'], self.clock(), json.dumps(thread, sort_keys=True)))

    def create_thread(self, body):
        _fields(body, {'thread_id', 'metadata', 'if_exists'})
        thread_id = body.get('thread_id') or str(uuid.uuid4())
        _uuid(thread_id); metadata = _object(body.get('metadata', {}))
        existing = self.db.execute('SELECT body FROM threads WHERE id=?', (thread_id,)).fetchone()
        if existing is not None:
            if body.get('if_exists', 'raise') != 'do_nothing':
                raise ProtocolError(409, 'THREAD_EXISTS')
            return json.loads(existing[0])
        if self.db.execute('SELECT count(*) FROM threads').fetchone()[0] >= MAX_THREADS:
            raise ProtocolError(409, 'QUOTA')
        _, stamp = self._now()
        thread = {'thread_id': thread_id, 'created_at': stamp, 'updated_at': stamp, 'metadata': metadata,
                  'status': 'idle', 'values': {}}
        self._save_thread(thread)
        return thread

    # Runs ------------------------------------------------------------------

    def create_run(self, body, *, thread_id=None):
        _fields(body, {'thread_id', 'agent_id', 'input', 'messages', 'metadata', 'config', 'webhook', 'on_completion',
                       'on_disconnect', 'if_not_exists', 'stream_mode', 'command', 'checkpoint'})
        if body.get('webhook') is not None:
            raise ProtocolError(422, 'WEBHOOK_UNSUPPORTED')
        if body.get('messages'):
            raise ProtocolError(422, 'MESSAGES_UNSUPPORTED')
        if body.get('agent_id', AGENT_ID) != AGENT_ID:
            raise ProtocolError(404, 'NOT_FOUND')
        request = body.get('input')
        if not (type(request) is dict and set(request) == {'tool', 'arguments'} and type(request['tool']) is str
                and type(request['arguments']) is dict):
            raise ProtocolError(422, 'INVALID_INPUT')
        thread_id = body.get('thread_id', thread_id)
        if thread_id is not None:
            _uuid(thread_id)
            if self.db.execute('SELECT 1 FROM threads WHERE id=?', (thread_id,)).fetchone() is None:
                if body.get('if_not_exists', 'reject') != 'create':
                    raise ProtocolError(404, 'NOT_FOUND')
                self.create_thread({'thread_id': thread_id})
        if self.db.execute('SELECT count(*) FROM runs').fetchone()[0] >= MAX_RUNS:
            raise ProtocolError(409, 'QUOTA')
        result = self._call(request['tool'], request['arguments'])
        values = {'tool': request['tool'], 'result': result.get('structuredContent', result.get('content')),
                  'isError': bool(result.get('isError', False))}
        _, stamp = self._now()
        run = {'run_id': str(uuid.uuid4()), 'thread_id': thread_id, 'agent_id': AGENT_ID, 'created_at': stamp,
               'updated_at': stamp, 'status': 'error' if values['isError'] else 'success',
               'metadata': _object(body.get('metadata', {})), 'values': values}
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self.db.execute('INSERT INTO runs VALUES (?,?,?,?)', (run['run_id'], thread_id, self.clock(),
                                                                  json.dumps(run, sort_keys=True)))
            if thread_id is not None:
                thread = self._thread(thread_id)
                thread.update(values=values, updated_at=stamp, status='idle' if not values['isError'] else 'error')
                self._save_thread(thread)
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK'); raise
        return run

    def _run(self, run_id):
        row = self.db.execute('SELECT body FROM runs WHERE id=?', (run_id,)).fetchone()
        if row is None:
            raise ProtocolError(404, 'NOT_FOUND')
        return json.loads(row[0])

    @staticmethod
    def _public(run):
        return {k: v for k, v in run.items() if k != 'values'}

    def _wait(self, run):
        return {'run': self._public(run), 'values': run['values'], 'messages': []}

    def _page(self, body):
        limit, offset = body.get('limit', 10), body.get('offset', 0)
        if not (type(limit) is int and 1 <= limit <= 1000 and type(offset) is int and 0 <= offset <= 10**6):
            raise ProtocolError(422, 'INVALID_BODY')
        return limit, offset

    # Store -----------------------------------------------------------------

    def _item(self, namespace, key):
        if not (type(namespace) is list and 1 <= len(namespace) <= 16 and all(type(n) is str and 0 < len(n) <= 128 for n in namespace)
                and type(key) is str and 0 < len(key) <= 256):
            raise ProtocolError(422, 'INVALID_BODY')
        return '\x1f'.join(namespace)

    def handle(self, method, path, query=None, body=b''):
        """One request: returns (status, JSON value or None)."""
        with self.lock:
            try:
                return self._route(method, path, query or {}, _body(body) if method in ('POST', 'PUT', 'PATCH', 'DELETE') and body else {})
            except ProtocolError as error:
                return _error(error.status, error.code)

    def _route(self, method, path, query, body):
        parts = [p for p in path.split('?', 1)[0].split('/') if p]
        if (method, parts) == ('GET', ['openapi.json']):
            return 200, agents_json.openapi(self.tools, self.base_url)
        if (method, parts) == ('GET', ['.well-known', 'agents.json']):
            return 200, agents_json.document(self.tools, self.base_url + agents_json.OPENAPI_PATH)
        if method == 'POST' and len(parts) == 3 and parts[:2] == ['aap', 'tools']:
            return 200, self._call(parts[2], body)
        if parts[:1] == ['agents']:
            if (method, parts) == ('POST', ['agents', 'search']):
                name = body.get('name')
                return 200, [self.agent()] if name in (None, AGENT_ID) or (type(name) is str and name.lower() in 'aap agentic agreements protocol') else []
            if method == 'GET' and len(parts) >= 2 and parts[1] == AGENT_ID:
                if len(parts) == 2:
                    return 200, self.agent()
                if parts[2:] == ['schemas']:
                    return 200, self._schemas()
            raise ProtocolError(404, 'NOT_FOUND')
        if parts[:1] == ['threads']:
            if (method, parts) == ('POST', ['threads']):
                return 200, self.create_thread(body)
            if (method, parts) == ('POST', ['threads', 'search']):
                limit, offset = self._page(body)
                rows = [json.loads(r[0]) for r in self.db.execute('SELECT body FROM threads ORDER BY created, id')]
                wanted = body.get('metadata') or {}
                rows = [r for r in rows if all(r['metadata'].get(k) == v for k, v in wanted.items())
                        and body.get('status', r['status']) == r['status']]
                return 200, rows[offset:offset + limit]
            if len(parts) >= 2:
                thread_id = parts[1]
                if len(parts) == 2 and method == 'GET':
                    return 200, self._thread(thread_id)
                if len(parts) == 2 and method == 'PATCH':
                    thread = self._thread(thread_id)
                    thread['metadata'].update(_object(body.get('metadata', {}))); thread['updated_at'] = self._now()[1]
                    self._save_thread(thread)
                    return 200, thread
                if len(parts) == 2 and method == 'DELETE':
                    self._thread(thread_id)
                    self.db.execute('DELETE FROM threads WHERE id=?', (thread_id,))
                    return 204, None
                if parts[2:] == ['history'] and method == 'GET':
                    self._thread(thread_id)
                    rows = [json.loads(r[0]) for r in self.db.execute('SELECT body FROM runs WHERE thread=? ORDER BY created', (thread_id,))]
                    return 200, [{'values': r['values'], 'run_id': r['run_id'], 'created_at': r['created_at']} for r in rows]
                if parts[2:] in (['stream'], ['commands'], ['copy']):
                    raise ProtocolError(422, 'STREAMING_UNSUPPORTED')
            raise ProtocolError(404, 'NOT_FOUND')
        if parts[:1] == ['runs']:
            if (method, parts) == ('POST', ['runs', 'wait']):
                return 200, self._wait(self.create_run(body))
            if (method, parts) == ('POST', ['runs']):
                return 200, self._public(self.create_run(body))
            if (method, parts) == ('POST', ['runs', 'stream']):
                raise ProtocolError(422, 'STREAMING_UNSUPPORTED')
            if (method, parts) == ('POST', ['runs', 'search']):
                limit, offset = self._page(body)
                rows = [json.loads(r[0]) for r in self.db.execute('SELECT body FROM runs ORDER BY created, id')]
                rows = [r for r in rows if body.get('thread_id', r['thread_id']) == r['thread_id']
                        and body.get('status', r['status']) == r['status']
                        and all(r['metadata'].get(k) == v for k, v in (body.get('metadata') or {}).items())]
                return 200, [self._public(r) for r in rows[offset:offset + limit]]
            if len(parts) >= 2:
                run = self._run(parts[1])
                if len(parts) == 2 and method == 'GET':
                    return 200, self._public(run)
                if len(parts) == 2 and method == 'DELETE':
                    self.db.execute('DELETE FROM runs WHERE id=?', (parts[1],))
                    return 204, None
                if parts[2:] == ['wait'] and method == 'GET':
                    return 200, self._wait(run)
                if parts[2:] == ['cancel'] and method == 'POST':
                    raise ProtocolError(409, 'RUN_FINISHED')
                if parts[2:] == ['stream']:
                    raise ProtocolError(422, 'STREAMING_UNSUPPORTED')
            raise ProtocolError(404, 'NOT_FOUND')
        if parts[:2] == ['store', 'items']:
            if (method, parts) == ('PUT', ['store', 'items']):
                _fields(body, {'namespace', 'key', 'value'})
                space = self._item(body.get('namespace'), body.get('key'))
                value = _object(body.get('value'))
                if len(json.dumps(value, sort_keys=True)) > MAX_ITEM_BYTES:
                    raise ProtocolError(422, 'ITEM_TOO_LARGE')
                exists = self.db.execute('SELECT 1 FROM items WHERE namespace=? AND key=?', (space, body['key'])).fetchone()
                if not exists and self.db.execute('SELECT count(*) FROM items').fetchone()[0] >= MAX_ITEMS:
                    raise ProtocolError(409, 'QUOTA')
                _, stamp = self._now()
                old = self.db.execute('SELECT body FROM items WHERE namespace=? AND key=?', (space, body['key'])).fetchone()
                created = json.loads(old[0])['created_at'] if old else stamp
                item = {'namespace': body['namespace'], 'key': body['key'], 'value': value, 'created_at': created, 'updated_at': stamp}
                self.db.execute('INSERT INTO items VALUES (?,?,?,?) ON CONFLICT(namespace, key) DO UPDATE SET body=excluded.body',
                                (space, body['key'], self.clock(), json.dumps(item, sort_keys=True)))
                return 204, None
            if (method, parts) == ('GET', ['store', 'items']):
                namespace = query.get('namespace', [])
                space = self._item(namespace if type(namespace) is list else [namespace], query.get('key'))
                row = self.db.execute('SELECT body FROM items WHERE namespace=? AND key=?', (space, query['key'])).fetchone()
                if row is None:
                    raise ProtocolError(404, 'NOT_FOUND')
                return 200, json.loads(row[0])
            if (method, parts) == ('DELETE', ['store', 'items']):
                space = self._item(body.get('namespace'), body.get('key'))
                self.db.execute('DELETE FROM items WHERE namespace=? AND key=?', (space, body['key']))
                return 204, None
            if (method, parts) == ('POST', ['store', 'items', 'search']):
                limit, offset = self._page(body)
                prefix = body.get('namespace_prefix') or []
                wanted = body.get('filter') or {}
                rows = [json.loads(r[0]) for r in self.db.execute('SELECT body FROM items ORDER BY namespace, key')]
                rows = [r for r in rows if r['namespace'][:len(prefix)] == prefix
                        and all(r['value'].get(k) == v for k, v in wanted.items())]
                return 200, {'items': rows[offset:offset + limit]}
        if (method, parts) == ('POST', ['store', 'namespaces']):
            limit, offset = self._page({'limit': body.get('limit', 100), 'offset': body.get('offset', 0)})
            prefix, suffix, depth = body.get('prefix') or [], body.get('suffix') or [], body.get('max_depth')
            spaces = sorted({tuple(json.loads(r[0])['namespace']) for r in self.db.execute('SELECT body FROM items')})
            spaces = [list(s[:depth] if depth else s) for s in spaces if list(s[:len(prefix)]) == prefix
                      and (not suffix or list(s[-len(suffix):]) == suffix)]
            unique = [list(s) for s in sorted({tuple(s) for s in spaces})]
            return 200, unique[offset:offset + limit]
        raise ProtocolError(404, 'METHOD')


def _body(raw):
    if type(raw) is not bytes or len(raw) > MAX_BODY:
        raise ProtocolError(422, 'INVALID_BODY')
    try:
        value = json.loads(raw.decode('utf-8'))
    except (UnicodeError, ValueError):
        raise ProtocolError(422, 'INVALID_BODY') from None
    if type(value) is not dict:
        raise ProtocolError(422, 'INVALID_BODY')
    return value


def _fields(body, allowed):
    if not set(body) <= allowed:
        raise ProtocolError(422, 'INVALID_BODY')


def _object(value):
    if type(value) is not dict:
        raise ProtocolError(422, 'INVALID_BODY')
    return value


def _uuid(value):
    try:
        if type(value) is not str or str(uuid.UUID(value)) != value:
            raise ValueError
    except ValueError:
        raise ProtocolError(422, 'INVALID_BODY') from None


def serve(host, address='127.0.0.1', port=0):
    """A ThreadingHTTPServer for the host; the caller runs serve_forever() and shuts it down."""
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import parse_qs, urlsplit

    class Handler(BaseHTTPRequestHandler):
        timeout = 10  # seconds per socket read or write; a stalled client cannot hold a worker thread

        def log_message(self, *args):
            pass

        def _answer(self, method):
            size = int(self.headers.get('Content-Length') or 0)
            if size > MAX_BODY:
                status, value = _error(422, 'INVALID_BODY')
            else:
                raw = self.rfile.read(size) if size else b''
                split = urlsplit(self.path)
                query = {k: (v if k == 'namespace' else v[0]) for k, v in parse_qs(split.query).items()}
                status, value = host.handle(method, split.path, query, raw)
            data = b'' if value is None else json.dumps(value, sort_keys=True).encode('utf-8')
            self.send_response(status)
            if data:
                self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data))); self.end_headers()
            if data:
                self.wfile.write(data)

        def do_GET(self):
            self._answer('GET')

        def do_POST(self):
            self._answer('POST')

        def do_PUT(self):
            self._answer('PUT')

        def do_PATCH(self):
            self._answer('PATCH')

        def do_DELETE(self):
            self._answer('DELETE')

    return ThreadingHTTPServer((address, port), Handler)


def describe():
    return {'version': VERSION, 'agent_protocol': PROTOCOL, 'agent_id': AGENT_ID,
            'served': ['POST /agents/search', 'GET /agents/aap', 'GET /agents/aap/schemas', 'POST /threads',
                       'POST /threads/search', 'GET|PATCH|DELETE /threads/{id}', 'GET /threads/{id}/history',
                       'POST /runs', 'POST /runs/wait', 'POST /runs/search', 'GET|DELETE /runs/{id}', 'GET /runs/{id}/wait',
                       'POST /runs/{id}/cancel', 'PUT|GET|DELETE /store/items', 'POST /store/items/search',
                       'POST /store/namespaces', 'POST /aap/tools/{tool}', 'GET /openapi.json', 'GET /.well-known/agents.json'],
            'refused': ['streaming and stream modes', 'webhooks', 'message-style input', 'thread copy and commands'],
            'errors': dict(FIX), 'limits': {'body': MAX_BODY, 'threads': MAX_THREADS, 'runs': MAX_RUNS, 'items': MAX_ITEMS,
                                            'item_bytes': MAX_ITEM_BYTES},
            'authority': 'THE_WRAPPED_HOST_DECIDES; THE_DEFAULT_KEYLESS_HOST_CANNOT_SIGN_OR_PAY', 'network_dialled': False}


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Serve AAP tools as an Agent Protocol 0.1.6 agent on loopback.')
    parser.add_argument('--directory', required=True, help='Owner-private state directory (mode 0700).')
    parser.add_argument('--port', type=int, default=8123)
    args = parser.parse_args(argv)
    from .agent_server import keyless_host_config
    from .runtime_host import RuntimeHost
    runtime = RuntimeHost(keyless_host_config(stateless=True))
    host = AgentProtocolHost(runtime.tools, args.directory, base_url='http://127.0.0.1:%d' % args.port)
    server = serve(host, '127.0.0.1', args.port)
    try:
        server.serve_forever()
    finally:
        server.server_close(); host.close(); runtime.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
