"""Nostr events with BIP-340 signatures, carrying AAP forum posts over relays.

GRAFT: NIP-01 (nostr-protocol/nips 01.md) event serialization, id and shape;
BIP-340 Schnorr signatures over secp256k1 (bitcoin/bips bip-0340.mediawiki),
checked against the BIP's published test vectors. A forum post becomes a kind 1
text note (NIP-10) with a subject tag (NIP-14), lower-case t hashtags (NIP-24)
and an r tag holding the ipfs:// address of the post's signed AAP bytes.

TAKE-AND-IMPROVE: a relay accepts any validly signed event, so a Nostr key says
nothing about an AAP actor by itself. A carried post counts only through its
AAP envelope, which any source can supply by CID, and optionally through a
covenant-nostr-binding/0.1 record that both keys sign.

NIP-01 escapes only seven characters inside strings and includes every other
character verbatim; serializers disagree about the remaining control characters,
so events holding them are refused rather than given an ambiguous id. OpenSSL
(cryptography, SECP256K1) multiplies every secret scalar; verification uses the
public-only arithmetic in weierstrass.py. Nothing here opens a socket or talks to
a relay.
"""
from copy import deepcopy
import hashlib
import json
import os
import re

from cryptography.hazmat.primitives.asymmetric import ec

from .crypto import canonical, digest, integer, key, need, public_key, sign, verification_key, verify
from . import interop_codec as codec
from . import ipld_codecs as ipld
from .weierstrass import SECP256K1

VERSION = 'covenant-nostr-forum/0.1'
BINDING_VERSION = 'covenant-nostr-binding/0.1'
BINDING_LABEL = 'COVENANT-NOSTR-BINDING-0.1'
KIND_TEXT_NOTE = 1
MAX_EVENT = 65536
MAX_TAGS = 64
MAX_TAG_ITEMS = 16
MAX_TEXT = 32768
HEX64 = re.compile(r'[0-9a-f]{64}\Z')
HEX128 = re.compile(r'[0-9a-f]{128}\Z')
ESCAPED = '\n"\\\r\t\b\f'

REMEDIATION = {
    'NOSTR_EVENT': 'Supply a NIP-01 event: id, pubkey, created_at, kind, tags, content and sig, within 64 KiB.',
    'NOSTR_TEXT': 'Use valid Unicode text without control characters other than tab, line feed, carriage return, backspace and form feed.',
    'NOSTR_TAGS': 'Use at most 64 tags, each a list of 1 to 16 strings.',
    'NOSTR_ID': 'The id is not the NIP-01 SHA-256 of the serialized event; the event was altered.',
    'NOSTR_PUBKEY': 'Use a 32-byte x-only secp256k1 public key (BIP-340 lift_x) as lower-case hex.',
    'NOSTR_SIGNATURE': 'The BIP-340 signature does not verify for this pubkey and id.',
    'NOSTR_KEY': 'Sign with a secp256k1 private key object from the cryptography package.',
    'NOSTR_AUX': 'BIP-340 auxiliary randomness is exactly 32 bytes.',
    'NOSTR_FORUM_POST': 'Carry a forum POST envelope whose actor signature verifies.',
    'NOSTR_FORUM_MISMATCH': 'The note does not carry this post: content, subject, hashtags, aap tag and ipfs reference must match.',
    'NOSTR_BINDING_FIELDS': 'Use the exact binding fields from describe().',
    'NOSTR_BINDING_SIGNATURE': 'Both the AAP key and the Nostr key must sign the binding.',
    'NOSTR_BINDING_WINDOW': 'Use integer times with issued_at before expires, and check it inside that window.',
}


def remediation(code):
    return REMEDIATION.get(code, ipld.remediation(code))


# BIP-340.

def tagged_hash(tag, data):
    prefix = hashlib.sha256(tag.encode('ascii')).digest()
    return hashlib.sha256(prefix + prefix + data).digest()


def _secret(private):
    need(isinstance(private, ec.EllipticCurvePrivateKey) and isinstance(private.curve, ec.SECP256K1), 'NOSTR_KEY')
    return private.private_numbers().private_value


def x_only(private):
    """The BIP-340 public key (x coordinate of d·G) as lower-case hex."""
    _secret(private)
    return private.public_key().public_numbers().x.to_bytes(32, 'big').hex()


def new_key():
    """A fresh secp256k1 key for Nostr. It is not an AAP key and never signs AAP records."""
    return ec.generate_private_key(ec.SECP256K1())


def schnorr_sign(private, message, aux=None):
    """BIP-340 default signing; ``aux`` is 32 bytes of auxiliary randomness (fresh when omitted)."""
    n = SECP256K1.n
    secret = _secret(private)
    need(type(message) is bytes, 'NOSTR_EVENT')
    aux = os.urandom(32) if aux is None else aux
    need(type(aux) is bytes and len(aux) == 32, 'NOSTR_AUX')
    point = SECP256K1.base_mul(secret)
    secret = secret if point[1] % 2 == 0 else n - secret
    px = point[0].to_bytes(32, 'big')
    masked = bytes(a ^ b for a, b in zip(secret.to_bytes(32, 'big'), tagged_hash('BIP0340/aux', aux)))
    nonce = int.from_bytes(tagged_hash('BIP0340/nonce', masked + px + message), 'big') % n
    need(nonce != 0, 'NOSTR_AUX')
    commitment = SECP256K1.base_mul(nonce)
    nonce = nonce if commitment[1] % 2 == 0 else n - nonce
    rx = commitment[0].to_bytes(32, 'big')
    challenge = int.from_bytes(tagged_hash('BIP0340/challenge', rx + px + message), 'big') % n
    signature = (rx + ((nonce + challenge * secret) % n).to_bytes(32, 'big')).hex()
    schnorr_verify(px.hex(), message, signature)  # BIP-340 recommends verifying before release
    return signature


def schnorr_verify(pubkey, message, signature):
    """BIP-340 verification of a signature over arbitrary message bytes; returns True or raises."""
    need(type(pubkey) is str and HEX64.fullmatch(pubkey) is not None, 'NOSTR_PUBKEY')
    need(type(signature) is str and HEX128.fullmatch(signature) is not None, 'NOSTR_SIGNATURE')
    need(type(message) is bytes, 'NOSTR_EVENT')
    try:
        point = SECP256K1.lift_x(int(pubkey, 16))
    except ValueError:
        raise ValueError('NOSTR_PUBKEY') from None
    raw = bytes.fromhex(signature)
    r, s = int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:], 'big')
    need(r < SECP256K1.p and s < SECP256K1.n, 'NOSTR_SIGNATURE')
    challenge = int.from_bytes(tagged_hash('BIP0340/challenge', raw[:32] + bytes.fromhex(pubkey) + message), 'big')
    found = SECP256K1.add(SECP256K1.mul(s, SECP256K1.g), SECP256K1.neg(SECP256K1.mul(challenge, point)))
    need(found is not None and found[1] % 2 == 0 and found[0] == r, 'NOSTR_SIGNATURE')
    return True


# NIP-01 events.

def _text(value, maximum=MAX_TEXT):
    need(type(value) is str and len(value) <= maximum, 'NOSTR_TEXT')
    need(all(ord(c) >= 32 or c in ESCAPED for c in value), 'NOSTR_TEXT')
    try:
        value.encode('utf-8')
    except UnicodeError:
        raise ValueError('NOSTR_TEXT') from None
    return value


def _tags(tags):
    need(type(tags) is list and len(tags) <= MAX_TAGS, 'NOSTR_TAGS')
    for tag in tags:
        need(type(tag) is list and 1 <= len(tag) <= MAX_TAG_ITEMS, 'NOSTR_TAGS')
        for item in tag:
            _text(item, 4096)
    return tags


def serialize(event):
    """The NIP-01 bytes [0, pubkey, created_at, kind, tags, content] whose SHA-256 is the event id."""
    need(type(event) is dict, 'NOSTR_EVENT')
    need(type(event.get('pubkey')) is str and HEX64.fullmatch(event['pubkey']) is not None, 'NOSTR_PUBKEY')
    integer(event.get('created_at'))
    need(type(event.get('kind')) is int and 0 <= event['kind'] <= 65535, 'NOSTR_EVENT')
    _tags(event.get('tags')); _text(event.get('content'))
    text = json.dumps([0, event['pubkey'], event['created_at'], event['kind'], event['tags'], event['content']],
                      separators=(',', ':'), ensure_ascii=False)
    return text.encode('utf-8')


def event_id(event):
    return hashlib.sha256(serialize(event)).hexdigest()


def sign_event(event, private):
    """Explicit local owner action: set pubkey, id and sig. Not exposed as a tool."""
    unsigned = {name: deepcopy(event[name]) for name in ('created_at', 'kind', 'tags', 'content')}
    unsigned['pubkey'] = x_only(private)
    unsigned['id'] = event_id(unsigned)
    unsigned['sig'] = schnorr_sign(private, bytes.fromhex(unsigned['id']))
    return unsigned


def verify_event(event):
    """Shape, id and BIP-340 signature of one event, given as a dict or as relay JSON text."""
    if type(event) in (str, bytes):
        try:
            event = codec.parse(event, MAX_EVENT, 8, 4096)
        except ValueError:
            raise ValueError('NOSTR_EVENT') from None
    need(type(event) is dict and set(event) == {'id', 'pubkey', 'created_at', 'kind', 'tags', 'content', 'sig'},
         'NOSTR_EVENT')
    need(type(event['id']) is str and HEX64.fullmatch(event['id']) is not None, 'NOSTR_ID')
    need(len(serialize(event)) <= MAX_EVENT, 'NOSTR_EVENT')
    need(event_id(event) == event['id'], 'NOSTR_ID')
    schnorr_verify(event['pubkey'], bytes.fromhex(event['id']), event['sig'])
    return {'id': event['id'], 'pubkey': event['pubkey'], 'kind': event['kind'], 'created_at': event['created_at'],
            'signature': 'VERIFIED_BIP340', 'execution_authorized': False}


# Forum posts as kind 1 notes.

def _post(envelope):
    from .public_web import source_fields
    from .agent_network import unpack
    try:
        ref, authors, _ = source_fields('social', envelope)
    except (ValueError, KeyError, TypeError):
        raise ValueError('NOSTR_FORUM_POST') from None
    data = unpack(envelope['body'])
    content = data['content'] if type(data['content']) is str else canonical(data['content']).decode('ascii')
    tags = sorted({tag.lower() for tag in data['tags']})
    return {'id': ref['id'], 'actor': authors[0], 'title': data['title'], 'content': _text(content),
            'hashtags': [_text(tag, 4096) for tag in tags],
            'cid': ipld.cid_text(ipld.cid(ipld.RAW, canonical(envelope)))}


def forum_note(envelope, *, created_at, thread_root=None):
    """An unsigned kind 1 note carrying a signed AAP forum post; sign it locally with sign_event."""
    post = _post(envelope)
    integer(created_at)
    tags = ([['subject', _text(post['title'], 4096)]] if post['title'] else []) + [['t', tag] for tag in post['hashtags']]
    tags += [['aap', post['id'], post['actor']], ['r', 'ipfs://' + post['cid']]]
    if thread_root is not None:
        key(thread_root)
        tags.append(['e', thread_root, '', 'root'])
    _tags(tags)
    return {'created_at': created_at, 'kind': KIND_TEXT_NOTE, 'tags': tags, 'content': post['content'],
            'aap_event': post['id'], 'aap_cid': post['cid'], 'signature_created': False, 'execution_authorized': False}


def note_event(note):
    """The NIP-01 fields of a prepared note, ready for sign_event."""
    return {name: deepcopy(note[name]) for name in ('created_at', 'kind', 'tags', 'content')}


def verify_forum_note(event, envelope, *, binding=None, now=None):
    """A relay's note carries this AAP post exactly; the AAP signature, not the relay, makes it count."""
    checked = verify_event(event)
    if type(event) in (str, bytes):
        event = codec.parse(event, MAX_EVENT, 8, 4096)
    post = _post(envelope)
    tags = event['tags']
    expected_subject = [['subject', post['title']]] if post['title'] else []
    need(event['kind'] == KIND_TEXT_NOTE and event['content'] == post['content'], 'NOSTR_FORUM_MISMATCH')
    need([tag for tag in tags if tag[0] == 'subject'] == expected_subject, 'NOSTR_FORUM_MISMATCH')
    need(sorted(tag[1] for tag in tags if tag[0] == 't' and len(tag) == 2) == post['hashtags']
         and all(len(tag) == 2 for tag in tags if tag[0] == 't'), 'NOSTR_FORUM_MISMATCH')
    need([tag for tag in tags if tag[0] == 'aap'] == [['aap', post['id'], post['actor']]], 'NOSTR_FORUM_MISMATCH')
    need([tag for tag in tags if tag[0] == 'r' and tag[1:2] and tag[1].startswith('ipfs://')]
         == [['r', 'ipfs://' + post['cid']]], 'NOSTR_FORUM_MISMATCH')
    bound = False
    if binding is not None:
        opened = open_binding(binding, now=now)
        need(opened['body']['key'] == post['actor'] and opened['body']['nostr_pubkey'] == event['pubkey'],
             'NOSTR_BINDING_FIELDS')
        bound = True
    return {**checked, 'profile': VERSION, 'aap_event': post['id'], 'actor': post['actor'], 'aap_cid': post['cid'],
            'aap_signature': 'VERIFIED_ACTOR_KEY', 'nostr_key_bound_to_actor': bound,
            'other_tags': [tag[0] for tag in tags if tag[0] not in ('subject', 't', 'aap', 'r')],
            'relay_trust': 'NONE_RELAYS_ADD_AVAILABILITY_ONLY'}


# Both keys sign the binding, so neither can claim the other alone.

def _binding_body(body):
    need(type(body) is dict and set(body) == {'version', 'key', 'nostr_pubkey', 'issued_at', 'expires', 'nonce'},
         'NOSTR_BINDING_FIELDS')
    need(body['version'] == BINDING_VERSION and type(body['key']) is str, 'NOSTR_BINDING_FIELDS')
    verification_key(body['key'])
    need(type(body['nostr_pubkey']) is str and HEX64.fullmatch(body['nostr_pubkey']) is not None, 'NOSTR_PUBKEY')
    try:
        SECP256K1.lift_x(int(body['nostr_pubkey'], 16))
    except ValueError:
        raise ValueError('NOSTR_PUBKEY') from None
    integer(body['issued_at']); integer(body['expires']); key(body['nonce'])
    need(body['issued_at'] < body['expires'], 'NOSTR_BINDING_WINDOW')
    return body


def binding(aap_key, nostr_pubkey, issued_at, expires, nonce):
    body = _binding_body({'version': BINDING_VERSION, 'key': aap_key, 'nostr_pubkey': nostr_pubkey,
                          'issued_at': issued_at, 'expires': expires, 'nonce': nonce})
    return {'id': digest(BINDING_LABEL, body), 'body': deepcopy(body),
            'signing_payloads': {'aap': {'label': BINDING_LABEL, 'body': deepcopy(body)},
                                 'nostr': {'bip340_message_sha256': digest(BINDING_LABEL, body)}},
            'required_signers': [aap_key, nostr_pubkey], 'signature_created': False, 'execution_authorized': False}


def sign_binding(body, aap_private, nostr_private):
    """Explicit local owner action with both keys. Not exposed as a tool."""
    _binding_body(body)
    need(public_key(aap_private) == body['key'] and x_only(nostr_private) == body['nostr_pubkey'],
         'NOSTR_BINDING_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(aap_private, BINDING_LABEL, body),
            'nostr_signature': schnorr_sign(nostr_private, bytes.fromhex(digest(BINDING_LABEL, body)))}


def open_binding(record, *, now=None):
    need(type(record) is dict and set(record) == {'body', 'signature', 'nostr_signature'}, 'NOSTR_BINDING_FIELDS')
    body = _binding_body(record['body'])
    try:
        verify(body['key'], BINDING_LABEL, body, record['signature'])
        schnorr_verify(body['nostr_pubkey'], bytes.fromhex(digest(BINDING_LABEL, body)), record['nostr_signature'])
    except ValueError:
        raise ValueError('NOSTR_BINDING_SIGNATURE') from None
    if now is not None:
        integer(now)
        need(body['issued_at'] <= now < body['expires'], 'NOSTR_BINDING_WINDOW')
    return {'id': digest(BINDING_LABEL, body), 'body': deepcopy(body), 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'binding_version': BINDING_VERSION, 'status': 'EXPERIMENTAL_OPTIONAL_CARRIER',
            'event': 'NIP-01', 'signature': 'BIP-340 Schnorr over secp256k1', 'note_kind': KIND_TEXT_NOTE,
            'tags': {'subject': 'NIP-14 title', 't': 'NIP-24 lower-case hashtags', 'aap': '[aap, event id, actor key]',
                     'r': 'ipfs:// CID of the canonical signed post', 'e': 'optional NIP-10 root marker'},
            'serialization': 'NIP01_SEVEN_ESCAPES_OTHER_CONTROL_CHARACTERS_REFUSED',
            'authority': 'THE_AAP_ENVELOPE_SIGNATURE_DECIDES; RELAYS_AND_NOSTR_KEYS_ADD_AVAILABILITY_ONLY',
            'secret_scalars': 'OPENSSL_ONLY', 'limits': {'event_bytes': MAX_EVENT, 'tags': MAX_TAGS,
                                                         'tag_items': MAX_TAG_ITEMS, 'text': MAX_TEXT},
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'execution_authorized': False}
