"""Checkout wrapper for the release manifest tool.

Not a consensus module. The implementation lives in tools/release_manifest.py so
an installer can run that one file before the release zip is extracted.
"""
import importlib.util
from pathlib import Path

_PATH = Path(__file__).resolve().parents[1] / 'tools' / 'release_manifest.py'
_SPEC = importlib.util.spec_from_file_location('covenant_release_manifest', _PATH)
if _SPEC is None or _SPEC.loader is None:
    raise ImportError('RELEASE_MANIFEST_TOOL_MISSING')
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

ReleaseError = _MODULE.ReleaseError
NetworkDisabled = _MODULE.NetworkDisabled
canonical = _MODULE.canonical
cid_v1_raw = _MODULE.cid_v1_raw
describe_artifact = _MODULE.describe_artifact
verify_manifest = _MODULE.verify_manifest
sign_manifest = _MODULE.sign_manifest
sign_manifest_ml_dsa = _MODULE.sign_manifest_ml_dsa
attach_signatures = _MODULE.attach_signatures
unsigned_manifest = _MODULE.unsigned_manifest
maintainer_document = _MODULE.maintainer_document
validate_maintainers = _MODULE.validate_maintainers
stage_local = _MODULE.stage_local
mirror_plan = _MODULE.mirror_plan
publish = _MODULE.publish
fetch_remote = _MODULE.fetch_remote
torrent_v2 = _MODULE.torrent_v2
pieces_root = _MODULE.pieces_root
THRESHOLD = _MODULE.THRESHOLD
SEAT_COUNT = _MODULE.SEAT_COUNT
MANIFEST_NAME = _MODULE.MANIFEST_NAME
SOURCE_DATE_EPOCH = _MODULE.SOURCE_DATE_EPOCH
SEED_VERSION = _MODULE.SEED_VERSION
empty_seeds = _MODULE.empty_seeds
require_seed_operators = _MODULE.require_seed_operators
rollout_bucket = _MODULE.rollout_bucket
rollout_eligible = _MODULE.rollout_eligible
