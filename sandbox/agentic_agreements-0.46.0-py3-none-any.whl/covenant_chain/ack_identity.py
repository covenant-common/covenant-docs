"""Catena Labs ACK-ID ownership credentials read as principal evidence for an agent.

GRAFT: Agent Commerce Kit ACK-ID v1 (protocol version 2025-05-04; agentcommercekit/ack, release
@agentcommercekit/ack-id 0.11.0 at commit 0b8fdaa9, MIT), whose wire format its SDK defines:

* ControllerCredential (packages/ack-id/src/controller-credential.ts): a W3C VC Data Model 1.1 credential
  (@context https://www.w3.org/2018/credentials/v1; type VerifiableCredential and ControllerCredential)
  whose credentialSubject is {id: the agent DID, controller: the owner DID}.
* Proof (packages/vc, through did-jwt-vc 4.0.16 and did-jwt 8.0.18): VC-JWT (JwtProof2020), a compact JWS
  with alg ES256K, ES256 or EdDSA and payload {vc, sub, iss, nbf[, exp, jti]}. The issuer key is a
  verification method of the issuer DID; with no kid, each listed key of the algorithm is tried, as
  did-jwt does. nbf may lead the clock by the skew (300 seconds by default); exp has passed when reached;
  an aud claim is refused, as ACK configures none.
* Controller claim (controller-claim-verifier.ts, did/src/resolve-did.ts): the agent DID document names one
  controller DID, not itself, that resolves and equals the credential's controller.
* Revocation (packages/vc/src/revocation): a BitstringStatusListEntry names a status list credential
  (itself a VC-JWT by the issuer; encodedList is base64 of zlib deflate, most significant bit first). A
  credential with a status entry and no supplied, verified, unexpired list is refused, as ACK fails closed.

Offline and pinned: the owner names the issuer DIDs it trusts. did:key identifiers are decoded locally
(Ed25519 0xed, secp256k1 0xe7 and P-256 0x1200 multicodec keys); did:web documents are bytes the caller holds
(domain control is not verified). The chain is one hop, owner to agent, as ACK-ID v1 defines it; which
legal entity stands behind the owner DID is the owner's trust list, not this code.

The credential concerns a did:aap account only through that account's own signature: the agent's did:web
document bound to the AAP key by did_binding (its Data Integrity proof or a covenant-did-binding/0.1 record),
or a covenant-evidence-binding/0.1 record of kind ACK_ID_CREDENTIAL. The controller is the issuer's claim
about a principal; it grants no authority to sign, pay or bind anyone.
"""
from copy import deepcopy
import re
import zlib

from cryptography.hazmat.primitives.asymmetric import ec

from .crypto import integer, need
from . import did_binding
from . import interop_codec as codec
from . import trust_evidence as evidence

PROTOCOL = 'ACK 2025-05-04 (@agentcommercekit/ack-id 0.11.0)'
CONTEXT = 'https://www.w3.org/2018/credentials/v1'
TYPE = 'ControllerCredential'
STATUS_TYPE = 'BitstringStatusListEntry'
STATUS_LIST_TYPE = 'BitstringStatusListCredential'
ALGORITHMS = ('ES256K', 'ES256', 'EdDSA')
MULTICODEC = {b'\xed\x01': ('OKP', 'Ed25519', 32), b'\xe7\x01': ('EC', 'secp256k1', 33), b'\x80\x24': ('EC', 'P-256', 33)}
KEY_TYPES = ('JsonWebKey2020', 'JsonWebKey', 'Multikey', 'Ed25519VerificationKey2020', 'EcdsaSecp256k1VerificationKey2019',
             'EcdsaSecp256r1VerificationKey2019')
DID = re.compile(r'did:[a-z0-9]{1,32}:[A-Za-z0-9._:%-]{1,2000}\Z')
MAX_DOCUMENTS = 16
MAX_LIST = 1 << 20
DEFAULT_SKEW = 300

REMEDIATION = {
    'ACK_ID_TRUST': 'Name 1 to 16 issuer DIDs you trust; a credential cannot nominate its own issuer.',
    'ACK_ID_ISSUER_UNTRUSTED': 'The credential iss is not an issuer you trust.',
    'ACK_ID_DID': 'Use a did:key (Ed25519, secp256k1 or P-256) or a did:web whose document you supply.',
    'ACK_ID_DOCUMENT': 'Supply each did:web document as {did: bytes}; its id must equal the DID.',
    'ACK_ID_KEY': 'No key of the issuer DID verifies this credential with its alg.',
    'ACK_ID_CREDENTIAL': 'Supply a VC-JWT ControllerCredential: vc with the v1 @context, both types, credentialSubject.controller; sub and iss DIDs.',
    'ACK_ID_TIME': 'The credential is not yet valid (nbf beyond the skew) or has expired.',
    'ACK_ID_AUDIENCE': 'A ControllerCredential carries no aud; ACK verifies none.',
    'ACK_ID_CONTROLLER': 'The agent DID document must name one controller DID, not itself, that resolves and equals the claimed controller.',
    'ACK_ID_STATUS_UNKNOWN': 'The credential has a status entry: supply its status list credential, signed by a trusted issuer and unexpired.',
    'ACK_ID_STATUS_LIST': 'The status list credential is malformed, foreign, expired or its encodedList does not decode.',
    'ACK_ID_REVOKED': 'The issuer revoked this credential.',
}


def remediation(code):
    return REMEDIATION.get(code, evidence.remediation(code))


def _did(value):
    need(type(value) is str and DID.fullmatch(value) is not None, 'ACK_ID_DID')
    return value


def did_key_jwk(did):
    """The public JWK of a did:key with an Ed25519, secp256k1 or P-256 multicodec key."""
    need(type(did) is str and did.startswith('did:key:z') and len(did) <= 200, 'ACK_ID_DID')
    try:
        raw = codec.base58btc_decode(did[len('did:key:z'):].split('#')[0])
    except ValueError:
        raise ValueError('ACK_ID_DID') from None
    header = raw[:2]
    need(header in MULTICODEC, 'ACK_ID_DID')
    kty, crv, size = MULTICODEC[header]
    body = raw[2:]
    need(len(body) == size, 'ACK_ID_DID')
    if kty == 'OKP':
        return codec.okp_jwk(body.hex())
    curve = ec.SECP256K1() if crv == 'secp256k1' else ec.SECP256R1()
    try:
        numbers = ec.EllipticCurvePublicKey.from_encoded_point(curve, body).public_numbers()
    except ValueError:
        raise ValueError('ACK_ID_DID') from None
    return {'kty': 'EC', 'crv': crv, 'x': codec.b64url(numbers.x.to_bytes(32, 'big')),
            'y': codec.b64url(numbers.y.to_bytes(32, 'big'))}


def _documents(rows):
    rows = {} if rows is None else rows
    need(type(rows) is dict and len(rows) <= MAX_DOCUMENTS, 'ACK_ID_DOCUMENT')
    out = {}
    for did, raw in rows.items():
        _did(did)
        need(did.startswith('did:web:') and type(raw) in (str, bytes), 'ACK_ID_DOCUMENT')
        did_binding.parse_did(did)
        try:
            document = codec.parse(raw, did_binding.MAX_DOCUMENT, 16, 4096)
        except ValueError:
            raise ValueError('ACK_ID_DOCUMENT') from None
        need(type(document) is dict and document.get('id') == did, 'ACK_ID_DOCUMENT')
        out[did] = {'document': document, 'raw': raw}
    return out


def _method_jwk(method):
    """A JWK for one verification method, or None for a type or encoding this reader does not use."""
    if type(method) is not dict or method.get('type') not in KEY_TYPES:
        return None
    jwk = method.get('publicKeyJwk')
    if type(jwk) is dict:
        jwk = dict(jwk, crv='P-256') if jwk.get('crv') == 'secp256r1' else dict(jwk)  # ACK writes secp256r1.
        return {name: jwk[name] for name in ('kty', 'crv', 'x', 'y') if name in jwk}
    text = method.get('publicKeyMultibase')
    if type(text) is str and text.startswith('z'):
        try:
            return did_key_jwk('did:key:' + text)
        except ValueError:
            return None  # ACK's own Multikey without a multicodec header is not read.
    return None


def did_keys(did, documents):
    """Candidate public JWKs of a DID: decoded from did:key, or listed in a supplied did:web document."""
    _did(did)
    if did.startswith('did:key:'):
        return [did_key_jwk(did)]
    need(did.split('#')[0] in documents, 'ACK_ID_DOCUMENT')
    document = documents[did.split('#')[0]]['document']
    methods = document.get('verificationMethod', [])
    need(type(methods) is list and len(methods) <= 32, 'ACK_ID_DOCUMENT')
    if '#' in did:
        methods = [row for row in methods if type(row) is dict and row.get('id') in (did, '#' + did.split('#', 1)[1])]
    return [jwk for jwk in (_method_jwk(row) for row in methods) if jwk is not None]


def _verify_jwt(token, issuer, documents):
    """Header, payload and signing-input SHA-256 of a VC-JWT, trying each key of the issuer DID with its alg."""
    keys = did_keys(issuer, documents)
    last = 'ACK_ID_KEY'
    for jwk in keys:
        try:
            return evidence.jws(token, [jwk], ALGORITHMS, max_payload=65536)
        except ValueError as error:
            last = 'ACK_ID_KEY' if str(error) in ('JWS_SIGNATURE', 'JWS_ALGORITHM', 'JWS_KEY') else str(error)
            if last == 'JWS_FORMAT':
                raise ValueError('ACK_ID_CREDENTIAL') from None
    raise ValueError(last)


def _unverified_iss(token):
    need(type(token) is str and token.count('.') == 2 and len(token) <= evidence.MAX_TOKEN, 'ACK_ID_CREDENTIAL')
    try:
        payload = codec.parse(codec.b64url_decode(token.split('.')[1], 65536), 65536, 12, 2048)
    except ValueError:
        raise ValueError('ACK_ID_CREDENTIAL') from None
    need(type(payload) is dict and type(payload.get('iss')) is str, 'ACK_ID_CREDENTIAL')
    return _did(payload['iss'])


def _times(payload, now, skew):
    for name in ('nbf', 'exp'):
        need(name not in payload or (type(payload[name]) in (int, float) and 0 <= payload[name] < 1e11), 'ACK_ID_CREDENTIAL')
    need(payload.get('nbf', 0) <= now + skew and ('exp' not in payload or now < payload['exp']), 'ACK_ID_TIME')


def _proof_jwt(value):
    """The compact VC-JWT itself, or the jwt of a JSON credential's JwtProof2020 proof."""
    if type(value) is dict:
        proof = value.get('proof')
        return proof.get('jwt') if type(proof) is dict and proof.get('type', 'JwtProof2020') == 'JwtProof2020' else None
    return value


def _status(entry, status_lists, issuer, trusted_status, documents, now, skew):
    need(type(entry) is dict and entry.get('type') == STATUS_TYPE and entry.get('statusPurpose') == 'revocation'
         and type(entry.get('statusListIndex')) is str and re.fullmatch(r'0|[1-9][0-9]{0,8}', entry['statusListIndex'])
         and type(entry.get('statusListCredential')) is str and entry['statusListCredential'].startswith('https://')
         and entry.get('statusSize', 1) == 1, 'ACK_ID_STATUS_LIST')
    url = entry['statusListCredential']
    supplied = status_lists.get(url)
    need(supplied is not None, 'ACK_ID_STATUS_UNKNOWN')
    token = _proof_jwt(supplied)
    need(type(token) is str, 'ACK_ID_STATUS_LIST')
    list_issuer = _unverified_iss(token)
    need(list_issuer in (trusted_status or [issuer]), 'ACK_ID_STATUS_LIST')
    _, payload, _, _ = _verify_jwt(token, list_issuer, documents)
    vc = payload.get('vc')
    need(type(vc) is dict and type(vc.get('type')) is list and STATUS_LIST_TYPE in vc['type']
         and payload.get('jti') == url and payload.get('iss') == list_issuer, 'ACK_ID_STATUS_LIST')
    try:
        _times(payload, now, skew)
    except ValueError:
        raise ValueError('ACK_ID_STATUS_LIST') from None
    subject = vc.get('credentialSubject')
    need(type(subject) is dict and subject.get('statusPurpose') == 'revocation'
         and type(subject.get('encodedList')) is str and len(subject['encodedList']) <= 65536, 'ACK_ID_STATUS_LIST')
    try:
        inflater = zlib.decompressobj()
        bits = inflater.decompress(codec.b64_decode(subject['encodedList'], 65536), MAX_LIST)
        need(not inflater.unconsumed_tail, 'ACK_ID_STATUS_LIST')
    except (ValueError, zlib.error):
        raise ValueError('ACK_ID_STATUS_LIST') from None
    index = int(entry['statusListIndex'])
    need(index >> 3 < len(bits), 'ACK_ID_STATUS_LIST')
    need(not bits[index >> 3] >> (7 - (index & 7)) & 1, 'ACK_ID_REVOKED')
    return {'status': 'NOT_REVOKED', 'list': url, 'list_issuer': list_issuer, 'index': index,
            'list_expires': payload.get('exp')}


def verify(credential, trusted_issuers, now, *, documents=None, status_lists=None, trusted_status_issuers=None,
           skew=DEFAULT_SKEW, chain=None, did_bindings=(), bindings=()):
    """Verify one ACK-ID ControllerCredential (VC-JWT or a JSON VC with a JwtProof2020 proof); return principal evidence."""
    integer(now)
    need(type(trusted_issuers) in (list, tuple) and 0 < len(trusted_issuers) <= 16 and type(skew) is int
         and 0 <= skew <= 600, 'ACK_ID_TRUST')
    trusted = [_did(value) for value in trusted_issuers]
    status_lists = {} if status_lists is None else status_lists
    need(type(status_lists) is dict and len(status_lists) <= 8, 'ACK_ID_STATUS_LIST')
    trusted_status = None if trusted_status_issuers is None else [_did(value) for value in trusted_status_issuers]
    found = _documents(documents)
    token = _proof_jwt(credential)
    need(type(token) is str, 'ACK_ID_CREDENTIAL')
    issuer = _unverified_iss(token)
    need(issuer in trusted, 'ACK_ID_ISSUER_UNTRUSTED')  # Trust is checked before any key of the issuer is used.
    header, payload, signing_sha256, _ = _verify_jwt(token, issuer, found)
    need('aud' not in payload, 'ACK_ID_AUDIENCE')
    vc, agent = payload.get('vc'), payload.get('sub')
    need(type(vc) is dict and type(vc.get('@context')) is list and CONTEXT in vc['@context']
         and type(vc.get('type')) is list and {'VerifiableCredential', TYPE} <= set(vc['type'])
         and type(vc.get('credentialSubject')) is dict and type(agent) is str, 'ACK_ID_CREDENTIAL')
    controller = vc['credentialSubject'].get('controller')
    need(type(controller) is str, 'ACK_ID_CREDENTIAL')
    _did(agent); _did(controller)
    _times(payload, now, skew)
    # Controller claim: the agent's own document names this controller, and the controller resolves.
    need(agent in found, 'ACK_ID_CONTROLLER')
    named = found[agent]['document'].get('controller')
    need(type(named) is str and named == controller and named != agent, 'ACK_ID_CONTROLLER')
    need(controller.startswith('did:key:') or controller in found, 'ACK_ID_CONTROLLER')
    if controller.startswith('did:key:'):
        did_key_jwk(controller)
    revocation = {'status': 'NO_STATUS_ENTRY'}
    if 'credentialStatus' in vc:
        revocation = _status(vc['credentialStatus'], status_lists, issuer, trusted_status, found, now, skew)
    claims = {'protocol': PROTOCOL, 'agent': agent, 'controller': controller, 'issuer': issuer,
              'credential_id': payload.get('jti') if type(payload.get('jti')) is str else None,
              'issued': payload.get('nbf'), 'expires': payload.get('exp'), 'revocation': revocation,
              'principal': {'did': controller, 'domain': controller.split(':')[2] if controller.startswith('did:web:') else None,
                            'legal_entity': 'OWNER_TRUST_LIST_DECIDES', 'domain_control': 'NOT_VERIFIED_SUPPLIED_BYTES'}}
    checks = {'signature': 'VERIFIED_UNDER_ISSUER_DID_KEY', 'alg': header['alg'], 'issuer_trusted': True,
              'controller_claim': 'AGENT_DOCUMENT_NAMES_THIS_CONTROLLER', 'clock': 'CALLER_ASSERTION', 'hops': 1}
    signed_by = None
    if agent.startswith('did:web:') and did_bindings:
        resolved = did_binding.resolve(agent, document=found[agent]['raw'], bindings=did_bindings, now=now)
        keys = [row['key'] for row in resolved['bound_keys']]
        checks['did_binding'] = resolved['status']
        if len(keys) == 1:
            signed_by = keys[0]
    result = evidence.evidence('ACK_ID_CREDENTIAL', 'CATENA_ACK_ID', issuer, agent, signing_sha256, claims, checks,
                               signed_by=signed_by, chain=chain, bindings=bindings, now=now)
    for row in result['bound']:
        if row['basis'] == 'SIGNED_BY_AAP_KEY':
            row['basis'] = 'AAP_KEY_BOUND_THE_AGENT_DID_DOCUMENT'
    result['principal'] = deepcopy(claims['principal'])
    return result


def describe():
    return {'status': 'EXPERIMENTAL_GRAFT', 'protocol': PROTOCOL, 'credential': {'context': CONTEXT, 'type': TYPE,
            'subject': ['id (agent DID)', 'controller (owner DID)'], 'proof': 'VC-JWT JwtProof2020'},
            'algorithms': list(ALGORITHMS), 'did_methods': ['did:key (Ed25519, secp256k1, P-256)', 'did:web (supplied bytes)'],
            'revocation': 'BitstringStatusListEntry; unknown status refuses', 'hops': 1,
            'binding': 'DID_BINDING_OF_THE_AGENT_DOCUMENT_OR_COVENANT_EVIDENCE_BINDING',
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'authority_granted': False,
            'execution_authorized': False}
