"""Isolated activation gate for consensus changes.

Pull request #21 is the planned home of the shared activation-height
mechanism. It is not merged. Until it is, a chain opts in by putting a
``features`` object on its genesis document. Chains that omit ``features``
never enter these rules, so their replay state is unchanged.

Each feature names the first height at which it applies. Earlier heights keep
the previous transition.
"""
from copy import deepcopy

from .crypto import canonical, exact, integer, need

PRINCIPAL = 'principal_override'
SALTED = 'salted_terms'
INVARIANTS = 'core_invariants'
FIELDS = {
    PRINCIPAL: 'activation window max_cancellation_fee',
    SALTED: 'activation',
    INVARIANTS: 'activation',
}


def accept_features(features):
    """Validate a genesis feature map and return a canonical copy."""
    need(type(features) is dict and 0 < len(features) <= len(FIELDS) and set(features) <= set(FIELDS), 'FEATURES')
    out = {}
    for name, cfg in features.items():
        exact(cfg, FIELDS[name])
        integer(cfg['activation'], True)
        if name == PRINCIPAL:
            integer(cfg['window'], True)
            need(1 <= cfg['window'] <= 100, 'OVERRIDE_WINDOW')
            integer(cfg['max_cancellation_fee'])
        out[name] = deepcopy(cfg)
    canonical(out)
    return out


def feature(state, name):
    features = state.get('features')
    if type(features) is not dict or name not in features:
        return None
    return features[name]


def active(state, name, height):
    cfg = feature(state, name)
    return cfg is not None and height >= cfg['activation']
