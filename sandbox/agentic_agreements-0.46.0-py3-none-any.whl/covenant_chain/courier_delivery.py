"""One pharmacy drop, from the sentence to a carried photo and a 320/640 split.

Every step calls a module that already existed: the drafter, the evidence
checker, the private-evidence envelope, offline carry, covenant-expr/0.2, the
panel ballot, and the payment rail registry. Nothing here is a second copy of
those rules.
"""
from pathlib import Path
import importlib
import secrets
import tempfile
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from . import app
from .arbitration import appeal_id, panel_id
from .arbitration_clause import clause_for
from .arbitration_sdk import ballot_body, reasons_hash, vote_payload
from .crypto import canonical, digest, public_key, sign
from .offline_cli import initialize, load_identity, scope_key
from .offline_store import OfflineStore
from . import offline as offline
from . import offline_carriers as carriers

SENTENCE = (
    'Market Street Pharmacy pays Northline to deliver the chilled parcel RX-2041 by 16:00 '
    'for 640p with a photo and GPS and a temperature log, and refund half the fee if the '
    'temperature goes out of range. If the reading is missing, hold the fee.'
)
AS_OF = '2026-10-22'
QUANTITY = 640
WARM_MILLIS = 9200
COLD_MILLIS = 7400
RANGE_CEILING = 8


def draft_agreement(text=None, as_of=AS_OF):
    from covenant_agent.drafting import draft, lint, simulate
    document = draft(text or SENTENCE, as_of=as_of)
    report = lint(document)
    preview = simulate(document)
    return {'document': document, 'lint': report, 'simulation': preview, 'execution_authorized': False}


def refund_program(quantity=QUANTITY):
    """Half the fee when the temperature fact is above 8C. A missing fact is not zero."""
    half = quantity // 2
    return {
        'op': 'PIECEWISE',
        'args': [
            {'op': 'GT', 'args': [
                {'op': 'FACT', 'name': 'temp_c', 'source': 'temperature'},
                {'op': 'RAT', 'n': str(RANGE_CEILING), 'd': '1'},
            ]},
            {'op': 'RAT', 'n': str(half), 'd': '1'},
            {'op': 'RAT', 'n': str(quantity), 'd': '1'},
        ],
    }


def _facts(temp_c_millis):
    if temp_c_millis is None:
        return {}
    return {'temp_c': {
        'value': {'n': str(temp_c_millis), 'd': '1000'},
        'source': 'temperature',
        'confidence': {'n': '1', 'd': '1'},
    }}


def _verification_key(value):
    from covenant_language.key_validation import valid_ed25519_key
    return value if type(value) is str and valid_ed25519_key(value) else None


def _ask(fn, argument):
    try:
        return _verification_key(fn(argument))
    except (ValueError, KeyError, LookupError, TypeError):
        return None


def resolve_name(name, *, directory=None, aliases=None, phones=None, phonebook=None):
    """Find a verification key for a party name.

    An alias table, a phone book, or a directory object is used when one is
    passed. A directory, phone book, or alias module is used when it can be
    imported. Otherwise the name stays unresolved and the agents exchange keys.
    """
    found = _verification_key(name)
    if found:
        return found
    if type(aliases) is dict:
        found = _verification_key(aliases.get(name))
        if found:
            return found
    phone = phones.get(name) if type(phones) is dict else None
    if type(phonebook) is dict and type(phone) is str:
        found = _verification_key(phonebook.get(phone))
        if found:
            return found
    if directory is not None:
        for method, argument in (('lookup_alias', name), ('lookup', name), ('resolve', name)):
            fn = getattr(directory, method, None)
            if callable(fn):
                found = _ask(fn, argument)
                if found:
                    return found
        if type(phone) is str:
            fn = getattr(directory, 'lookup_phone', None)
            if callable(fn):
                found = _ask(fn, phone)
                if found:
                    return found
    for dotted in ('covenant_chain.directory', 'covenant_chain.phonebook', 'covenant_chain.aliases'):
        try:
            module = importlib.import_module(dotted)
        except ImportError:
            continue
        for attr, argument in (('lookup_alias', name), ('lookup', name), ('resolve', name)):
            fn = getattr(module, attr, None)
            if callable(fn):
                found = _ask(fn, argument)
                if found:
                    return found
        if type(phone) is str:
            fn = getattr(module, 'lookup_phone', None)
            if callable(fn):
                found = _ask(fn, phone)
                if found:
                    return found
    return None


def propose_drop(document=None, *, payer_key=None, payee_key=None, referee_key=None,
                 directory=None, aliases=None, phones=None, phonebook=None):
    """Bind verification keys and prepare the human agreement.

    Names that do not resolve become a key-exchange prompt. propose is not
    called until both parties have keys, so it does not stop on a display name.
    """
    from covenant_agent.drafting import bind_parties
    document = document or draft_agreement()['document']
    parties = document['terms']['parties']
    payer = _verification_key(payer_key) or resolve_name(
        parties.get('payer'), directory=directory, aliases=aliases, phones=phones, phonebook=phonebook)
    payee = _verification_key(payee_key) or resolve_name(
        parties.get('payee'), directory=directory, aliases=aliases, phones=phones, phonebook=phonebook)
    missing = [role for role, key in (('payer', payer), ('payee', payee)) if not key]
    if missing:
        return {
            'status': 'KEY_EXCHANGE',
            'ready': False,
            'unresolved': missing,
            'names': {'payer': parties.get('payer'), 'payee': parties.get('payee')},
            'prompt': 'Each unresolved agent publishes a 64-character Ed25519 verification key. '
                      'Call propose_drop again with payer_key and payee_key.',
            'execution_authorized': False,
            'payment_verified': False,
        }
    bound = bind_parties(document, payer=payer, payee=payee, referee=referee_key)
    human = bound['compiled']['human_agreement']
    return {
        'status': 'PROPOSED' if human.get('ready') else 'NOT_READY',
        'ready': bool(human.get('ready')),
        'document': bound,
        'human': human,
        'payer': payer,
        'payee': payee,
        'execution_authorized': False,
        'payment_verified': False,
    }


def _fee_policy(beneficiary):
    from .payment_rails import FEE_VERSION, TOKEN_VERSION
    return {
        'version': FEE_VERSION, 'unit': 'pence', 'fixed': 0, 'bps': 0, 'minimum': 0, 'maximum': 0,
        'beneficiary': beneficiary,
        'token': {'version': TOKEN_VERSION, 'resource': 'pence', 'discount_bps': 0, 'credit_prices': {}},
    }


def pay_split(root, *, payer, payee, amount, quantity):
    """Move the payee share on the demo rail, through an agreed link when the toolkit has one.

    The payer is funded with the whole fee. The transfer is the courier's share.
    The remainder stays with the payer, which is the refund. One receipt, one ledger.
    """
    from .payment_rails import DemoPaymentRail, RailRegistry
    root = Path(root)
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    beneficiary = public_key(Ed25519PrivateKey.generate())
    registry = RailRegistry()
    demo = DemoPaymentRail(root / 'demo', 'pence', {payer: quantity, payee: 0, beneficiary: 0}, _fee_policy(beneficiary))
    try:
        demo_ref = registry.register(demo)
        agreed_ref = None
        try:
            from covenant_agent.settlement import AgreedLinkAdapter, register_on
            agreed_ref = register_on(registry, AgreedLinkAdapter(registry, demo_ref))
        except ImportError:
            agreed_ref = None
        effect = digest('COVENANT-DELIVERY-PAYMENT-0.1', {
            'payer': payer, 'payee': payee, 'amount': amount, 'quantity': quantity})
        request = {'action': 'TRANSFER', 'payer': payer, 'recipient': payee, 'unit': 'pence',
                   'amount': amount, 'maximum_fee': 0}
        receipt = registry.get(agreed_ref or demo_ref).execute(effect, request)
        balances = dict(demo.db.execute('SELECT account, amount FROM rail_balances'))
    finally:
        demo.close()
    return {
        'rail': 'agreed-link' if agreed_ref else 'demo',
        'demo_rail': demo_ref,
        'agreed_link_rail': agreed_ref,
        'receipt': receipt,
        'balances': {'payer': balances[payer], 'payee': balances[payee]},
        'amount': amount,
        'unit': 'pence',
        'assurance': receipt['value']['assurance'],
        'execution_authorized': True,
        'payment_verified': False,
    }


def grade(temp_c_millis=None, *, quantity=QUANTITY, signer=None):
    """Apply the 0.2 formula. One temperature source is enough. A missing reading is UNKNOWN."""
    from covenant_agent.codec import public_key as agent_public
    from covenant_agent.evidence import check, json_blob, pin, sign_provenance
    from covenant_agent.evidence.adapters import JsonAdapter
    from covenant_language.expressions import evaluate_02, program_id

    program = refund_program(quantity)
    formula = evaluate_02(program, facts=_facts(temp_c_millis))
    signer = signer or Ed25519PrivateKey.generate()
    terms_hash = program_id(program)
    claim = {'subject': 'RX-2041', 'predicate': 'temperature_log', 'expect': {'json': {'parcel': 'RX-2041'}}}
    if temp_c_millis is None:
        pinned = pin(terms_hash, [JsonAdapter.id], claim, 0, [signer])
        evidence = check(pinned, [], terms_hash=terms_hash, quantity=quantity)
        settlement = {
            'quantity': quantity, 'payee': 0, 'refund': 0, 'escrow': quantity,
            'reading': 'UNKNOWN', 'applied': True, 'via': 'agreed_default', 'default': 'HOLD',
        }
    else:
        blob = json_blob({'parcel': 'RX-2041', 'temp_c_millis': temp_c_millis})
        provenance = sign_provenance(signer, adapter=JsonAdapter.id, blob=blob,
                                     mime='application/json', kind='DEVICE')
        pinned = pin(terms_hash, [JsonAdapter.id], claim, 1, [signer])
        evidence = check(pinned, [{
            'adapter': JsonAdapter.id, 'source': 'van-probe', 'mime': 'application/json',
            'blob': blob, 'provenance': provenance,
        }], terms_hash=terms_hash, quantity=quantity)
        value = formula['value']
        payee = int(value['n']) // int(value['d'])
        settlement = {
            'quantity': quantity, 'payee': payee, 'refund': quantity - payee, 'escrow': 0,
            'reading': 'VALUE', 'applied': True, 'via': 'covenant-expr/0.2',
            'program': program_id(program),
        }
    payment = None
    if settlement['payee'] > 0 and evidence['met'] and evidence['applied'] is False:
        from covenant_agent.evidence import consume
        payer_key = public_key(Ed25519PrivateKey.generate())
        courier_key = public_key(Ed25519PrivateKey.generate())
        with tempfile.TemporaryDirectory() as folder:
            payment = pay_split(Path(folder) / 'rail', payer=payer_key, payee=courier_key,
                                amount=settlement['payee'], quantity=quantity)
        evidence = consume(evidence, payment['receipt'], payee=settlement['payee'], quantity=quantity)
    return {
        'applied': settlement['applied'],
        'split': {'payee': settlement['payee'], 'refund': settlement['refund'], 'quantity': quantity},
        'reading': settlement['reading'],
        'settlement': settlement,
        'formula': formula,
        'payment': None if payment is None else {
            'rail': payment['rail'], 'amount': payment['amount'], 'unit': payment['unit'],
            'balances': payment['balances'], 'assurance': payment['assurance'],
            'agreed_link': payment['agreed_link_rail'] is not None,
            'status': payment['receipt']['status'],
        },
        'evidence': {
            'met': evidence['met'],
            'quorum': evidence['quorum'],
            'supporters': evidence['supporters'],
            'notes': evidence['notes'],
            'checker_applied': evidence['applied'],
        },
        'single_source': evidence['quorum'] <= 1 and evidence['met'],
        'signer': agent_public(signer),
        'execution_authorized': evidence['applied'] is True,
        'payment_verified': False,
    }


class _PanelDesk:
    """Submit panel transactions on one chain. It does not invent a second state."""

    def __init__(self, keys, pubs, secrets, state):
        self.keys = keys
        self.p = pubs
        self.secrets = secrets
        self.s = state
        self.h = 1

    def guarded(self, name):
        from . import continuity
        return continuity.GuardedSigner(
            self.s, self.p[name], self.keys[name], self.secrets[name], colocate=True)

    def act(self, who, op, payload, guard=False, advance=True):
        from . import economics
        signer = self.guarded(who) if guard else self.keys[who]
        fee = {'policy': economics.policy_at(self.s, self.h)['id'], 'max_amount': 100000, 'sponsor': None}
        nonce = self.s['nonces'].get(self.p[who], 0)
        tx = app.make_transaction(
            signer, self.s['chain'], nonce, op, payload, protocol=self.s['protocol'],
            actor=self.p[who], fee=fee)
        self.s = app.apply_transaction(self.s, tx, self.h)
        if advance:
            self.h += 1
        return app.transaction_id(tx)

    def roll(self, target):
        while self.h < target:
            self.s = app.begin_block(self.s, self.h)
            self.h += 1

    def activate_panel(self):
        """List panel_arbitration through the upgrade the registry left off at genesis."""
        from . import market
        payload = {'kind': 'UPGRADE', 'change': {
            'features': ['panel_arbitration'], 'activation_height': self.h + 8,
            'code_hash': 'ab' * 32, 'testnet': 'covenant-upgrade-sandbox',
            'protocol_version': 'covenant-consensus/2'}, 'not_before': self.h + 2, 'expiry': self.h + 40,
            'epoch': self.s['market_config']['active']['epoch'], 'rationale': digest('reason', 'panel'),
            'deposit': {'resource': 'payment', 'quantity': 1}}
        pid = self.act('stranger', 'GOV_PROPOSE', payload)
        self.act('owner', 'GOV_APPROVE', {'proposal': pid}, guard=True)
        self.act('resolver', 'GOV_APPROVE', {'proposal': pid}, guard=True)
        epoch = self.s['market_config']['active']['epoch']
        signature = market.ready_signature(self.keys['v0'], self.s['chain'], pid, epoch, 'v0')
        self.act('stranger', 'GOV_READY', {'proposal': pid, 'member': 'v0', 'signature': signature})
        while self.h < self.s['governance_proposals'][pid]['not_before']:
            self.roll(self.h + 1)
        self.act('stranger', 'GOV_EXECUTE', {'proposal': pid})
        activation = self.s['upgrade']['scheduled'][pid]['activation_height']
        self.roll(activation + 1)


def shared_chain(quantity=QUANTITY):
    """Boot the one 0.15 genesis. The feature list is the registry, not a private copy."""
    from .fixtures import ensure_founder_quorum, market_fixture
    from .rule_registry import GENESIS_FEATURES
    keys, pubs, genesis, secrets = market_fixture()
    genesis['protocol'] = app.UPGRADE_VERSION
    genesis['resources']['pence'] = {'unit': 'pence'}
    genesis['accounts'][pubs['owner']]['pence'] = quantity
    ensure_founder_quorum(genesis, secrets)
    state = app.genesis_state(genesis)
    features = list(state['upgrade']['features'])
    if features != list(GENESIS_FEATURES) or 'panel_arbitration' in features:
        raise ValueError('REGISTRY')
    return keys, pubs, secrets, state, features


def _short_notice():
    from . import governance
    saved = (dict(governance.PARAMETER_TIMELOCK), dict(governance.CONSENSUS_TIMELOCK), governance.PAUSE_SECONDS)
    for stage in (1, 2, 3):
        governance.PARAMETER_TIMELOCK[stage] = 5
        governance.CONSENSUS_TIMELOCK[stage] = 5
    governance.PAUSE_SECONDS = 100
    return saved


def _restore_notice(saved):
    from . import governance
    governance.PARAMETER_TIMELOCK.clear()
    governance.PARAMETER_TIMELOCK.update(saved[0])
    governance.CONSENSUS_TIMELOCK.clear()
    governance.CONSENSUS_TIMELOCK.update(saved[1])
    governance.PAUSE_SECONDS = saved[2]


def settle_dispute(quantity=QUANTITY):
    """Submit one 50 percent ballot on the shared 0.15 chain and let it settle escrow."""
    from .fixtures import terms as covenant_terms
    saved = _short_notice()
    try:
        keys, pubs, secrets, state, genesis_features = shared_chain(quantity)
        desk = _PanelDesk(keys, pubs, secrets, state)
        desk.activate_panel()
        resource = 'pence'
        seat = pubs['agent']
        desk.act('agent', 'ARBITRATOR_JOIN', {
            'categories': ['delivery'], 'affiliations': [], 'quantity': 1000})
        panel = clause_for(
            'named', threshold=1, remedies=['split'], arbitrators=[seat],
            penalty_cap=quantity, amount=0, resource=resource,
            evidence_blocks=1, deliberation_blocks=1, vote_blocks=1)
        record = covenant_terms(
            pubs, desk.s['chain'], resource=resource, quantity=quantity, effect='TRANSFER',
            deadline=desk.h + 40, description='Pharmacy drop')
        record['panel'] = panel
        record['resolver'] = panel_id(panel)
        record['appeal_resolver'] = appeal_id(panel)
        record['timeout'] = 'HOLD_FOR_RESOLUTION'
        assents = []
        for name in ('owner', 'worker'):
            assents.append({
                'signer': pubs[name],
                'signature': sign(desk.guarded(name), 'COVENANT-ASSENT-0.1', record),
            })
        desk.act('owner', 'BIND', {'terms': record, 'assents': assents}, guard=True)
        agreement_id = app.agreement_id(record)
        opened = desk.h
        desk.act('owner', 'PANEL_OPEN', {'agreement': agreement_id}, guard=True)
        desk.roll(opened + 3)
        reasons = reasons_hash('temperature out of range, refund half the fee')
        body = ballot_body(desk.s['chain'], agreement_id, 'PRIMARY', 'split', 5000, 0, reasons)
        payload = vote_payload(body, sign(keys['agent'], 'COVENANT-PANEL-BALLOT-1', body))
        submitted = desk.act('agent', 'PANEL_VOTE', payload, advance=False)
        agreement = desk.s['agreements'][agreement_id]
        settlement = agreement['settlement']
        payer, payee = pubs['owner'], pubs['worker']
        return {
            'submitted': submitted is not None,
            'settled': agreement['state'] == 'SETTLED' and agreement['panel_case']['status'] == 'SETTLED',
            'remedy': agreement['decision']['remedy'],
            'payee_bps': agreement['decision']['payee_bps'],
            'quantity': quantity,
            'payee': settlement['counterparty'],
            'refund': settlement['principal'],
            'applied': True,
            'balances': {
                'pharmacy': desk.s['balances'][payer][resource],
                'courier': desk.s['balances'][payee][resource],
            },
            'protocol': desk.s['protocol'],
            'chain': desk.s['chain'],
            'genesis_features': genesis_features,
            'features': list(desk.s['upgrade']['features']),
            'execution_authorized': False,
            'payment_verified': False,
        }
    finally:
        _restore_notice(saved)


def _jpeg():
    # A tiny JPEG (SOI, APP0, EOI). The bytes are the attachment, not a claim about a door.
    return bytes.fromhex('ffd8ffe000104a46494600010100000100010000ffd9')


def carry(root, *, password='pharmacy-drop-1'):
    """Van seals the agreement and a JPEG. The shop imports both and can read them."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    scope = scope_key('northline-pharmacy')
    van_dir, shop_dir = root / 'van', root / 'shop'
    van = initialize(van_dir, scope=scope, password=password)
    shop = initialize(shop_dir, scope=scope, password=password)
    now = int(time.time())
    drafted = draft_agreement()
    agreement = offline.draft(
        scope=scope, parties=sorted([van['owner'], shop['owner']]),
        terms=drafted['document']['terms'], valid_from=now, valid_until=now + 86400,
        nonce=secrets.token_hex(32))
    van_key, van_storage, _ = load_identity(van_dir, password=password)
    assents = [offline.assent(agreement, van_key)]
    packet_body = {'agreement': agreement, 'assents': assents}
    shared = secrets.token_bytes(32)
    sealed = offline.seal('AGREEMENT', packet_body, signing_key=van_key, recipient=shop['owner'],
                          shared_key=shared, scope=scope, created=now, expires=now + 86400)
    photo = _jpeg()
    attachment = offline.evidence_attachment(photo, key=shared, scope=scope, media_type='image/jpeg')
    photo_packet = offline.seal('DATA', attachment, signing_key=van_key, recipient=shop['owner'],
                                shared_key=shared, scope=scope, created=now, expires=now + 86400)
    shop_key, shop_storage, _ = load_identity(shop_dir, password=password)
    vault = OfflineStore(shop_dir / 'vault', owner=shop['owner'], scope=scope, storage_key=shop_storage)
    try:
        agreement_ref = vault.retain(sealed, allowed_senders={van['owner']}, now=now, shared_key=shared)
        vault.note_carried_agreement(agreement_ref, now=now)
        photo_ref = vault.retain(photo_packet, allowed_senders={van['owner']}, now=now, shared_key=shared)
        status = vault.overview(now=now)
        opened = vault.agreement(offline.agreement_id(agreement), now=now)
        stored = vault.packet(photo_ref)['payload']['value']
        opened_photo = offline.open_attachment(stored, key=shared, scope=scope)
    finally:
        vault.close()
    raw = canonical(sealed)
    frames = carriers.frames(raw, mtu=900)
    assembler = carriers.Reassembler(max_bytes=68000)
    restored = None
    for frame in frames:
        restored = assembler.accept(carriers.scan_qr(carriers.qr_png(frame)), now=now)
    return {
        'shop_agreements': len(status['agreements']),
        'terms_fee': opened['agreement']['terms']['consideration']['quantity'],
        'terms_deadline': opened['agreement']['terms']['time']['deadline_text'],
        'evidence': status['evidence'],
        'photo_sha256': status['evidence'][0]['sha256'] if status['evidence'] else None,
        'photo_opened': opened_photo == photo,
        'qr_round_trip': restored == raw,
        'awaiting_shop_signature': opened['review']['status'] == 'AWAITING_SIGNATURES',
        'agreement_packet': agreement_ref,
        'photo_packet': photo_ref,
        'execution_authorized': False,
        'payment_verified': False,
    }


def run(root):
    drafted = draft_agreement()
    document = drafted['document']
    plain = document['plain']
    warm = grade(WARM_MILLIS)
    missing = grade(None)
    disputed = settle_dispute()
    carried = carry(root)
    exchange = propose_drop()
    pharmacy, courier = (Ed25519PrivateKey.generate() for _ in range(2))
    proposed = propose_drop(payer_key=public_key(pharmacy), payee_key=public_key(courier))
    return {
        'sentence_keeps': {
            'price': document['terms']['consideration']['quantity'],
            'deadline': document['terms']['time']['deadline_text'],
            'photo': 'photo' in plain,
            'gps': 'GPS' in plain,
            'half': 'half' in plain,
        },
        'simulation_nonzero': all(
            row['payer'] or row['payee'] or row['escrow'] for row in drafted['simulation']['scenarios']),
        'warm': warm['split'],
        'warm_applied': warm['applied'],
        'warm_paid': warm['payment']['balances'] if warm['payment'] else None,
        'checker_applied': warm['evidence']['checker_applied'],
        'payment_rail': warm['payment']['rail'] if warm['payment'] else None,
        'missing_reading': missing['reading'],
        'missing_default': missing['settlement']['default'],
        'missing_checker_applied': missing['evidence']['checker_applied'],
        'key_exchange': exchange['status'],
        'proposed': proposed['ready'],
        'dispute': {'submitted': disputed['submitted'], 'settled': disputed['settled'],
                    'payee': disputed['payee'], 'refund': disputed['refund'],
                    'protocol': disputed['protocol'],
                    'genesis_features': disputed['genesis_features']},
        'carried': {key: carried[key] for key in (
            'shop_agreements', 'terms_fee', 'terms_deadline', 'photo_opened', 'qr_round_trip')},
        'execution_authorized': warm['execution_authorized'],
        'payment_verified': False,
    }
