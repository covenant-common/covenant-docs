"""Network-effect health views: monoculture alarm and viral coefficient per niche.

Both are read-only views over observations the caller passes or desks already
hold. They write nothing, pay nothing and change no consensus rule.

Monoculture (network-effects spec section 1, spread mechanism 6): "ten
services using the same dependency do not make ten independent experiments".
The alarm fires when one SDK, rail or host carries more than 60 percent of the
observed traffic in its dimension.

Viral coefficient (section 2.2): k = invites per active covenant x acceptance
rate x fraction of invitees who make a second covenant, measured per niche per
window (weekly by default). The product reduces to repeat invitees per active
covenant; the factors are reported so a niche can see which one is weak.
"""
from .crypto import integer, key, need

MONOCULTURE_PROFILE = 'covenant-monoculture-alarm/0.1'
VIRAL_PROFILE = 'covenant-viral-coefficient/0.1'
DIMENSIONS = ('SDK', 'RAIL', 'HOST')
THRESHOLD_BPS = 6000
MAX_ROWS = 4096


def _label(value, code):
    need(type(value) is str and 0 < len(value) <= 80 and value.isprintable(), code)
    return value


def _tally(observations):
    """Aggregate rows ``{dimension, label, count}`` and event rows ``{sdk?, rail?, host?}``."""
    need(type(observations) is list and len(observations) <= MAX_ROWS, 'MONOCULTURE_OBSERVATIONS')
    totals = {dimension: {} for dimension in DIMENSIONS}
    for row in observations:
        need(type(row) is dict and row, 'MONOCULTURE_OBSERVATIONS')
        if 'dimension' in row:
            need(set(row) == {'dimension', 'label', 'count'} and row['dimension'] in DIMENSIONS,
                 'MONOCULTURE_OBSERVATIONS')
            integer(row['count'])
            pairs = [(row['dimension'], _label(row['label'], 'MONOCULTURE_OBSERVATIONS'), row['count'])]
        else:
            need(set(row) <= {'sdk', 'rail', 'host'}, 'MONOCULTURE_OBSERVATIONS')
            pairs = [(name.upper(), _label(value, 'MONOCULTURE_OBSERVATIONS'), 1) for name, value in sorted(row.items())]
        for dimension, label, count in pairs:
            bucket = totals[dimension]
            bucket[label] = bucket.get(label, 0) + count
    return totals


def monoculture(observations, *, threshold_bps=THRESHOLD_BPS):
    """Alarm per dimension when the leading label's share is strictly above the threshold."""
    integer(threshold_bps, True)
    need(threshold_bps < 10000, 'MONOCULTURE_THRESHOLD')
    totals = _tally(observations)
    rows = []
    for dimension in DIMENSIONS:
        bucket = totals[dimension]
        total = sum(bucket.values())
        if total == 0:
            rows.append({'dimension': dimension, 'observed': 0, 'leader': None, 'leader_share_bps': 0,
                         'labels': 0, 'alarm': False})
            continue
        leader, count = sorted(bucket.items(), key=lambda item: (-item[1], item[0]))[0]
        share = count * 10000 // total
        alarm = count * 10000 > threshold_bps * total
        rows.append({'dimension': dimension, 'observed': total, 'leader': leader, 'leader_share_bps': share,
                     'labels': len(bucket), 'alarm': alarm})
    alarms = [row['dimension'] for row in rows if row['alarm']]
    return {
        'profile': MONOCULTURE_PROFILE,
        'threshold_bps': threshold_bps,
        'rule': 'LEADER_SHARE_STRICTLY_ABOVE_THRESHOLD',
        'dimensions': rows,
        'alarm': bool(alarms),
        'alarms': alarms,
        'action_needed': 'DIVERSIFY_' + '_AND_'.join(alarms) if alarms else 'NONE',
        'observations_source': 'CALLER_SUPPLIED',
        'independence_verified': False,
        'invalidates_transactions': False,
        'consensus_changed': False,
        'view': True,
        'execution_authorized': False,
    }


def _ratio(numerator, denominator):
    return numerator * 10000 // denominator if denominator else 0


def viral_coefficient(windows):
    """k per niche and window from counts ``{niche, start, end, active, invites, bound, repeat}``."""
    need(type(windows) is list and 0 < len(windows) <= 256, 'VIRAL_WINDOWS')
    seen = set()
    rows = []
    for window in windows:
        need(type(window) is dict and set(window) == {'niche', 'start', 'end', 'active', 'invites', 'bound', 'repeat'},
             'VIRAL_WINDOWS')
        niche = _label(window['niche'], 'VIRAL_WINDOWS')
        for name in ('start', 'end', 'active', 'invites', 'bound', 'repeat'):
            integer(window[name])
        need(window['start'] < window['end'], 'VIRAL_WINDOW_ORDER')
        need(window['bound'] <= window['invites'] and window['repeat'] <= window['bound'], 'VIRAL_FUNNEL')
        ident = (niche, window['start'])
        need(ident not in seen, 'VIRAL_DUPLICATE_WINDOW')
        seen.add(ident)
        invites_per = _ratio(window['invites'], window['active'])
        acceptance = _ratio(window['bound'], window['invites'])
        retention = _ratio(window['repeat'], window['bound'])
        k_bps = _ratio(window['repeat'], window['active'])
        rows.append({
            'niche': niche, 'start': window['start'], 'end': window['end'],
            'active': window['active'], 'invites': window['invites'], 'bound': window['bound'],
            'repeat': window['repeat'],
            'invites_per_active_bps': invites_per, 'acceptance_bps': acceptance,
            'second_covenant_bps': retention, 'k_bps': k_bps,
            'self_sustaining': k_bps > 10000, 'measurable': window['active'] > 0,
        })
    rows.sort(key=lambda row: (row['niche'], row['start']))
    return {
        'profile': VIRAL_PROFILE,
        'formula': 'K = INVITES_PER_ACTIVE x ACCEPTANCE x SECOND_COVENANT = REPEAT / ACTIVE',
        'cadence': 'CALLER_WINDOW_WEEKLY_RECOMMENDED',
        'windows': rows,
        'paid': False,
        'reward': None,
        'counts_clicks': False,
        'view': True,
        'execution_authorized': False,
    }


def window_counts(invites, growth, *, niche, start, end, invite_ids, agreements):
    """Count one niche window from an ``InviteDesk`` and a ``GrowthDesk``.

    Neither desk records a niche, so the caller names which invite ids and
    which agreements belong to it. An invite is counted once; the window is
    the caller's (the invite body carries no issue height). ``bound`` is an
    invite that reached BIND. ``repeat`` is a bound invitee with at least two
    distinct recorded agreements by ``end``. ``active`` is the named
    agreements recorded inside ``[start, end)``.
    """
    _label(niche, 'VIRAL_WINDOWS')
    integer(start)
    integer(end)
    need(start < end, 'VIRAL_WINDOW_ORDER')
    need(type(invite_ids) is list and len(invite_ids) <= MAX_ROWS, 'VIRAL_WINDOWS')
    need(type(agreements) is list and len(agreements) <= MAX_ROWS, 'VIRAL_WINDOWS')
    for ident in invite_ids + agreements:
        key(ident)
    chosen = set(agreements)
    active = len({fact['agreement'] for fact in growth.facts
                  if fact['agreement'] in chosen and start <= fact['height'] < end})
    bound_invitees = []
    invite_count = 0
    for ident in sorted(set(invite_ids)):
        row = invites.rows.get(ident)
        need(row is not None, 'INVITE_UNKNOWN')
        invite_count += 1
        if row['bound'] and row['invitee'] is not None:
            bound_invitees.append(row['invitee'])
    repeat = 0
    for invitee in bound_invitees:
        made = {fact['agreement'] for fact in growth.facts if fact['actor'] == invitee and fact['height'] < end}
        if len(made) >= 2:
            repeat += 1
    return {'niche': niche, 'start': start, 'end': end, 'active': active, 'invites': invite_count,
            'bound': len(bound_invitees), 'repeat': repeat}
