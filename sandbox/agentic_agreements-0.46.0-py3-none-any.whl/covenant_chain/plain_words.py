"""Plain words for everything a person or an agent reads first.

One sentence gives the model, three steps give the golden path and seven jobs
hold every action. The glossary keeps each plain word beside the technical
term that code, specifications and reference pages keep using. Only what people
read changes here: wire fields, protocol identifiers and signed bytes never do.

Nothing here opens sockets or grants authority; the seven jobs are read from the packaged job map.
"""
from copy import deepcopy
import re

from covenant_agent.action_jobs import document as _job_map

FORMAT = 'covenant-golden-path/0.1'
MODEL = "A deal is a promise both sides sign. Proof shows it was kept. If it wasn't, there is a fair way to fix it."

# The golden path, the same everywhere: the aap command, the agent entry and the docs.
STEPS = (
    ('propose', 'Offer exact terms and sign them.'),
    ('accept', 'The other side signs the same terms. The price is held.'),
    ('settle', 'Deliver with proof, then release payment.'),
)

# Plain word -> the technical terms it stands for. Users meet the left side;
# code, specifications and reference pages keep the right side.
GLOSSARY = (
    ('deal', ('agreement', 'envelope')),
    ('sign', ('assent',)),
    ('permission', ('mandate', 'capability grant')),
    ('limit', ('reservation cap', 'threshold')),
    ('proof', ('receipt', 'evidence')),
    ('payment method', ('rail',)),
    ('fair fix', ('dispute ladder',)),
    ('independent check', ('witness',)),
    ('version', ('profile',)),
    ('ID', ('URN', 'content id')),
)

# Seven jobs in the order users meet them. Each verb says what it does and
# where it lives: an aap command, and installed tools as name or name.action
# separated by " | " ("covenant_action work:..." names a catalogue action on a
# signing host). One string per verb keeps each tool's declaring file as its
# coverage-catalogue home.
# The golden-path words, the aap command and the agent tools for each verb. The seven jobs,
# their titles, their order and their verbs come from the one job map,
# covenant_agent/data/action_jobs.json, so the two can never disagree.
VERB_WORDS = {
    'propose': ('Offer exact terms and sign them.', 'aap propose "WHAT" --price N',
                'covenant_make | covenant_marketplace.quick_trade'),
    'counter': ('Answer with changed terms. Signatures on the old terms stop counting.',
                'aap covenant counter DRAFT.json --party NAME --set quantity=40',
                'covenant_counter | covenant_marketplace.counter'),
    'accept': ('Sign the same terms. The price is held until the work is done.', 'aap accept DEAL',
               'covenant_accept'),
    'change': ('Change signed terms with a new version that both sides sign again.', None,
               'covenant_agreement.revise | covenant_contract.amend'),
    'fund': ('Hold the price once both sides have signed.', 'aap accept DEAL', 'covenant_accept'),
    'pay': ('Pay the other side by the payment method the deal names.', 'aap settle DEAL', 'covenant_settle'),
    'release': ('Let the held price go to the seller once the work is delivered.', 'aap settle DEAL',
                'covenant_settle'),
    'refund': ('Return the held price when the work fails or never comes.', None,
               'covenant_reflex | covenant_settle'),
    'deliver': ('Hand over the work.', 'aap settle DEAL', 'covenant_deliver'),
    'prove': ('Sign a fingerprint of the exact work, so anyone can check what was delivered.',
              'aap settle DEAL', 'covenant_deliver | covenant_evidence_export'),
    'check': ('Check a deal offline: both signatures, the proof and the payment.', 'aap show DEAL',
              'covenant_verify | covenant_light_verify'),
    'raise': ('Say what went wrong and start the fair fix.', None,
              'covenant_action work:covenant_dispute | covenant_dispute.prepare'),
    'respond': ('Answer with your side and your proof.', None,
                'covenant_submit_evidence.prepare | covenant_arbitration_interop.response_message'),
    'decide': ('The referee decides who was right and how much is paid.', None,
               'covenant_action work:covenant_decide | covenant_settle'),
    'appeal': ('Ask the appeal referee to decide again, inside the agreed window.', None,
               'covenant_action work:covenant_decide | covenant_agreement_procedure.escalation'),
    'find': ('Find a task, a tool or a service by ordinary words.', 'aap covenant actions search WORDS',
             'covenant_find | covenant_request.search'),
    'list': ('List your service where others can find it, or plug it into AAP as an adapter.',
             'aap adapter new --kind KIND NAME',
             'covenant_marketplace.simple_listing | covenant_public_web.prepare'),
    'ask': ('Post what you need and compare the offers that come back.', None,
            'covenant_request_write.create | covenant_request.compare'),
    'permit': ('Let an agent act for you, within limits you set.', None,
               'covenant_principal.draft | covenant_portable_trust.mandate'),
    'limit': ('Cap what an agent may spend, and say when it must ask you first.', None,
              'covenant_principal.narrow | covenant_reflex'),
    'approve': ('Approve one exact action before it happens.', None,
                'covenant_assent_review | covenant_portable_agreement.owner_approval'),
    'revoke': ('Take a permission back.', None,
               'covenant_principal.kill | covenant_portable_trust.revocations'),
    'show': ('See where each deal stands and what is still owed.', 'aap show',
             'covenant_obligations | covenant_next'),
    'export': ('Package the exact record to keep or to send.', 'aap show DEAL --json',
               'covenant_evidence_export'),
    'verify': ('Check a record someone sends you, offline.', 'aap show DEAL',
               'covenant_verify | covenant_portable_trust.verify_trust_bundle'),
}


def _jobs():
    return tuple((row['id'], row['title'], tuple((verb,) + VERB_WORDS[verb] for verb in row['verbs']))
                 for row in _job_map()['jobs'])


JOBS = _jobs()

_TERMS = {
    'agreement': r'agreements?', 'envelope': r'envelopes?', 'assent': r'assent(?:s|ed|ing)?',
    'mandate': r'mandates?', 'capability grant': r'capability\s+grants?',
    'reservation cap': r'reservation\s+caps?', 'threshold': r'thresholds?',
    'receipt': r'receipts?', 'evidence': r'evidence', 'rail': r'rails?',
    'dispute ladder': r'dispute\s+ladders?', 'witness': r'witness(?:es|ed|ing)?',
    'profile': r'profiles?', 'URN': r'URNs?', 'content id': r'content\s+ids?|CIDs?',
}
PLAIN = {term: plain for plain, terms in GLOSSARY for term in terms}
_FOUND = re.compile(r'\b(?:' + '|'.join('(?P<t%d>%s)' % (i, pattern) for i, pattern in enumerate(_TERMS.values())) + r')\b',
                    re.IGNORECASE)
_NAMES = tuple(_TERMS)
# Code is not prose: backtick spans, URLs, paths, flags, identifiers with
# _ : / = or a dot inside, codes in capitals and <placeholders> stay as written.
_CODE = re.compile(r'`[^`]*`|<[^<>]*>|https?://\S+|(?<![\w-])--?[A-Za-z][\w-]*|\S*(?:[_/=@#]|\w:\w)\S*'
                   r'|\b\w+\.\w[\w.]*|\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b|\b[A-Z]{4,}[0-9]*\b')
# Names, not prose: the display name and the distribution and command name.
NAMES = ('Agentic Agreements Protocol', 'agentic-agreements')
# Earlier command names such as covenant-evidence are identifiers too.
_COMMAND = re.compile(r'\bcovenant-[a-z0-9-]+')


def jargon(text):
    """Technical words used as prose in ``text``, each with its plain word.

    Returns sorted (term, plain) pairs; empty means the text is plain.
    """
    if type(text) is not str:
        raise ValueError('PLAIN_WORDS_TEXT')
    for name in NAMES:
        text = text.replace(name, ' ')
    prose = _CODE.sub(' ', _COMMAND.sub(' ', text))
    found = set()
    for match in _FOUND.finditer(prose):
        term = _NAMES[int(match.lastgroup[1:])]
        found.add((term, PLAIN[term]))
    return sorted(found)


def strings(value, skip=()):
    """Every string inside a JSON-like value, except under keys named in skip."""
    if type(value) is str:
        yield value
    elif type(value) is dict:
        for key, item in value.items():
            if key not in skip:
                yield from strings(item, skip)
    elif type(value) in (list, tuple):
        for item in value:
            yield from strings(item, skip)


def reference_term(plain):
    """A plain word with its technical terms in brackets, for first use in reference pages."""
    for word, terms in GLOSSARY:
        if word == plain:
            return f"{word} ({', '.join(terms)})"
    raise ValueError('PLAIN_WORDS_UNKNOWN')


def job(name):
    """One job by number (1-7), key, title or any of its verbs; None when nothing matches."""
    if type(name) is not str or not 0 < len(name) <= 40:
        return None
    wanted = name.strip().lower()
    for number, row in enumerate(JOBS, 1):
        key, title, verbs = row
        if wanted in (str(number), key, title.lower()) or any(wanted == verb[0] for verb in verbs):
            return number, row
    return None


POINTER = 'Three steps: propose, accept, settle; covenant_onboard start shows the exact calls.'


def golden_pointer():
    """The model and a one-line pointer: what every later onboarding reply leads with.

    The full block with exact calls is sent once, by covenant_onboard start.
    """
    return {'model': MODEL, 'three_steps': POINTER}


def golden_path():
    """The three steps with exact calls for an agent on the signing test hosts.

    Values in <angle brackets> come from aap setup or from the previous result;
    everything else is exact. The calls are data: they sign nothing here.
    """
    return deepcopy(_PATH)


def _call(host, tool, arguments):
    return {'host': host, 'name': tool, 'arguments': arguments}


_PATH = {
    'format': FORMAT,
    'model': MODEL,
    'steps': [
        {'step': 'propose', 'say': STEPS[0][1], 'command': 'aap propose "One logo" --price 50',
         'calls': [_call('buyer', 'covenant_make', {
             'document': 'One logo.', 'counterparty': '<seller ID>', 'resolver': '<referee ID>',
             'appeal_resolver': '<appeal referee ID>', 'quantity': 50, 'pay_to': 'seller',
             'deadline': 1900000000})]},
        {'step': 'accept', 'say': STEPS[1][1], 'command': 'aap accept DEAL',
         'calls': [_call('seller', 'covenant_accept', {'envelope': '<envelope from covenant_make>'})]},
        {'step': 'settle', 'say': STEPS[2][1], 'command': 'aap settle DEAL',
         'calls': [_call('seller', 'covenant_deliver',
                         {'envelope': '<envelope from covenant_accept>', 'content': 'The finished logo.'}),
                   _call('buyer', 'covenant_settle', {'envelope': '<envelope from covenant_deliver>'})]},
    ],
    'test_mode': 'Default: synthetic units, test keys, nothing real. aap setup prints the IDs and both test hosts.',
    'try_first': 'aap demo',
    'execution_authorized': False,
}
