"""Keyless drafting and inspection; owner SDKs retain all keys and effects."""
from .cooperation_interface import HASH, INT, TEXT, OBJECT
from covenant_agent.stripe_gateway import describe as _stripe_description
from .agent_accreditation import describe as _accreditation_description
from .offline_trade import describe as _offline_description

NAMES = ('covenant_stripe', 'covenant_accreditation', 'covenant_offline_trade')


def specs():
    positive = {'type': 'integer', 'minimum': 1, 'maximum': 2**53 - 1}
    flags = {'type': 'boolean'}
    return [
        ('covenant_stripe', 'Prepare an exact Stripe Checkout collection for owner review. '
         'Keys, payment execution and provider reconciliation stay in the owner gateway. '
         'This is hosted Checkout collection, not an outbound Stripe Pay transfer.', True, [
            ('profile', {}, ()),
            ('verify_record', {'record': OBJECT, 'policy': OBJECT, 'expected_effect': HASH},
                             ('record', 'policy', 'expected_effect')),
            ('policy', {'account': TEXT, 'payer_keys': {'type': 'array', 'minItems': 1,
                        'maxItems': 64, 'items': HASH}, 'currency': TEXT,
                        'maximum_order': positive, 'operation_budget': positive,
                        'return_origin': TEXT, 'livemode': flags},
                       ('account', 'payer_keys', 'currency', 'maximum_order', 'operation_budget', 'return_origin')),
            ('prepare', {'policy': OBJECT, 'agreement': HASH, 'revision': positive,
                         'payer': HASH, 'amount': positive, 'description': TEXT,
                         'expires': positive, 'nonce': HASH},
                        ('policy', 'agreement', 'revision', 'payer', 'amount', 'description', 'expires')),
        ]),
        ('covenant_accreditation', 'Inspect a portable agent qualification against supplied issuer, '
         'scope and freshness policy. Keyless checks do not adopt trust or persist anti-replay state. '
         'Owner issuer/holder signing and durable verification are separate SDK operations.', True, [
            ('profile', {}, ()),
            ('inspect', {'presentation': OBJECT, 'accepted': OBJECT, 'nonce': {'type': 'string', 'minLength': 1, 'maxLength': 256},
                         'now': INT, 'offline': flags}, ('presentation', 'accepted', 'nonce', 'now')),
        ]),
        ('covenant_offline_trade', 'Draft or inspect an exact private offline trade. '
         'Owner SDKs sign, encrypt, carry and retain it. Delivery, payment claims, authority '
         'and provider-observed settlement remain separate. No network calls or funds move.', True, [
            ('profile', {}, ()),
            ('draft', {'agreement': HASH, 'buyer': HASH, 'supplier': HASH,
                       'description': TEXT, 'quantity': positive, 'unit': TEXT,
                       'asset': TEXT, 'rail': TEXT, 'issued_at': INT, 'spend_until': INT,
                       'redeem_until': INT, 'delivery_check': TEXT, 'delivery_due': INT,
                       'dispute': TEXT, 'reviewer': HASH, 'revision': TEXT, 'nonce': HASH,
                       'mode': {'enum': ['RECORD_ONLY', 'PREALLOCATED_CLAIM', 'ISSUER_CREDIT', 'LOCAL_QUORUM']},
                       'reservation': OBJECT, 'authority_reference': HASH,
                       'credential_policy': HASH, 'credential_reference': HASH,
                       'maximum_status_age': INT},
                      ('agreement', 'buyer', 'supplier', 'description', 'quantity', 'issued_at',
                       'spend_until', 'redeem_until', 'delivery_check', 'delivery_due', 'nonce')),
            ('inspect', {'bundle': OBJECT, 'expected_id': HASH, 'now': INT},
                        ('bundle', 'expected_id', 'now')),
        ]),
    ]


def call(name, action, parameters):
    if name == 'covenant_stripe':
        from covenant_agent import stripe_gateway as module
        description = _stripe_description
        guide = 'docs/STRIPE_GATEWAY.html'
    elif name == 'covenant_accreditation':
        from . import agent_accreditation as module
        description = _accreditation_description
        guide = 'docs/AGENT_ACCREDITATION.html'
    elif name == 'covenant_offline_trade':
        from . import offline_trade as module
        description = _offline_description
        guide = 'docs/OFFLINE_TRADE.html'
    else:
        raise ValueError('INFRASTRUCTURE_TOOL')
    if action in ('describe', 'profile'):
        return {'guide': guide, **description(), 'execution_authorized': False,
                'trust_adoption': 'OWNER_REQUIRED', 'keyless': True}
    if name == 'covenant_stripe':
        if action == 'verify_record':
            result = module.verify_record(**parameters)
        elif action == 'policy':
            result = {'policy': module.make_policy(**parameters)}
        else:
            result = {'intent': module.prepare(**parameters)}
    elif name == 'covenant_accreditation':
        result = module.inspect_presentation(**parameters)
    else:
        result = {'bundle': module.draft(**parameters)} if action == 'draft' else module.inspect(**parameters)
    return {**result, 'guide': guide, 'execution_authorized': False,
            'policy_adoption': 'NOT_ESTABLISHED_BY_CALLER_INPUT', 'keyless': True}
