"""Upgrade profile for covenant-native/0.15.

Older native versions do not consult this module for a different result.
A chain that never adopts 0.15 keeps the rule set it was created with.
0.15 extends market governance (GOV_PROPOSE, GOV_APPROVE, GOV_VETO,
GOV_READY, GOV_EXECUTE), continuity policies, and DOMAIN_SUCCESSION.
It does not enforce founder_governance.py. A panel is not a new court:
when `panel_arbitration` is active, a covenant may name a panel in place of
the single resolver. Review and prediction panels are unchanged.

A covenant records the rule hash in force at BIND. A later parameter or
software activation applies only to covenants bound after that height.
Changing one that is already bound takes a fresh MIGRATE or AMEND from
every party. Nothing here moves on a clock: the council signs each
handover, and a milestone figure is only a recommendation.
"""
from .profile import MIGRATION_VERSION
from copy import deepcopy

from .crypto import digest, exact, integer, key, need
from .rule_registry import CATALOGUE, GENESIS_FEATURES

PROFILE = 'covenant-governance/1'
RULES_LABEL = 'COVENANT-RULES-1'
PAUSE_LABEL = 'COVENANT-PAUSE-RATIFY-1'
MIN_BLOCK_INTERVAL = 5
BLOCK_TIME_SKEW = 60
PAUSE_SECONDS = 72 * 3600
HISTORICAL_MAX_AGE = 8
WIDE_MAX_AGE = 32
HOLDER_QUORUM_BPS = 5000
PUBLIC_DEPOSIT = 1
FEATURES = CATALOGUE
PARAMETERS = {'archive_cap'}
UPGRADE_KINDS = {'UPGRADE', 'PARAMETER', 'MODULE', 'HANDOVER', 'PAUSE'}
OSSIFIED = {
    'supply_cap', 'founder_bps', 'founder_share', 'fee_cap', 'base_fee', 'per_kib',
    'fee_base', 'fee_per_kib', 'chain_id', 'chain', 'balances', 'escrow', 'confiscate',
}
MODULE_KINDS = {'ads', 'marketplace', 'toolkit', 'privacy'}
PAUSE_KINDS = {'BIND', 'SERVICE_BOOK', 'WORLD_HIRE'}
CORE_MODULES = {'supply', 'escrow', 'consensus', 'chain', 'fee', 'founder'}
PARAMETER_TIMELOCK = {1: 48 * 3600, 2: 7 * 86400, 3: 14 * 86400}
CONSENSUS_TIMELOCK = {1: 14 * 86400, 2: 14 * 86400, 3: 30 * 86400}
ARCHIVE_MAX = {1: 65536, 2: 32768, 3: 8192}
ARCHIVE_STEP = {1: 61440, 2: 8192, 3: 1024}
MILESTONES = {1: 100, 2: 1000}


def blocks_for(seconds):
    need(type(seconds) is int and seconds >= 0, 'TIMELOCK')
    return max(1, (seconds + MIN_BLOCK_INTERVAL - 1) // MIN_BLOCK_INTERVAL)


def _upgrade(state):
    from .profile import UPGRADE_VERSION
    if type(state) is not dict or state.get('protocol') not in {UPGRADE_VERSION,MIGRATION_VERSION}:
        return None
    gov = state.get('upgrade')
    return gov if type(gov) is dict else None


def install(state):
    """Empty upgrade profile. Called only while building a 0.15 genesis."""
    from .state import Table
    state['upgrade'] = {
        'v': PROFILE, 'stage': 1, 'veto': True, 'protocol_version': PROFILE,
        'features': list(GENESIS_FEATURES), 'parameters': {}, 'modules': {}, 'scheduled': {},
        'pauses': {}, 'handovers': [], 'log': [],
    }
    state['upgrade_deposits'] = Table({rid: 0 for rid in state['resources']})
    zeros = {rid: 0 for rid in state['resources']}
    state['arbitrator_stake'] = Table(dict(zeros))
    state['arbitration_held'] = Table(dict(zeros))
    state['arbitrators'] = Table()
    state['standing_panels'] = Table()


def feature_active(state, name):
    gov = _upgrade(state)
    return gov is not None and name in gov.get('features', [])


def freshness_limit(state):
    if feature_active(state, 'proof_freshness'):
        return WIDE_MAX_AGE
    return HISTORICAL_MAX_AGE


def archive_limit(state):
    from .shielded import ARCHIVE_CAP
    gov = _upgrade(state)
    if gov is None:
        return ARCHIVE_CAP
    return gov.get('parameters', {}).get('archive_cap', ARCHIVE_CAP)


def exit_open(state, feature, height):
    """Pool-exit window only. It does not rewrite a bound covenant."""
    gov = _upgrade(state)
    if gov is None or type(height) is not int:
        return None
    found = None
    for prop in gov.get('scheduled', {}).values():
        if prop.get('class') == 'consensus' and prop.get('status') == 'SCHEDULED' and feature in prop.get('features', []):
            if height < prop['activation_height'] and (found is None or prop['activation_height'] < found['activation_height']):
                found = prop
    return found


def pool_rollover(state, kind, height):
    if feature_active(state, 'pool_epoch_rollover'):
        return True
    return kind != 'deposit' and exit_open(state, 'pool_epoch_rollover', height) is not None


def admission_paused(state, kind):
    gov = _upgrade(state)
    return gov is not None and kind in gov.get('pauses', {})


def accept_block_time(block, parent, required):
    """Deterministic block-time rule. The local clock is not an input."""
    if type(block) is not dict or bool(required) != ('time' in block):
        return False
    if not required:
        return True
    stamp = block['time']
    if type(stamp) is not int or stamp < 0 or stamp > 2**53 - 1:
        return False
    if type(parent) is dict and 'time' in parent:
        previous = parent['time']
        if type(previous) is not int or stamp < previous + MIN_BLOCK_INTERVAL:
            return False
    return True


def proposed_time(parent, now):
    if type(now) is not int:
        return None
    if type(parent) is dict and type(parent.get('time')) is int and now < parent['time'] + MIN_BLOCK_INTERVAL:
        return None
    return now


def time_is_votable(block, now, skew=BLOCK_TIME_SKEW):
    if type(block) is not dict or 'time' not in block:
        return True
    return type(block['time']) is int and type(now) is int and block['time'] <= now + skew


def rules_in_force(state):
    gov = _upgrade(state)
    if gov is None:
        return None
    parameters = gov.get('parameters') or {}
    body = {
        'native': state['protocol'],
        'protocol_version': gov['protocol_version'],
        'features': sorted(gov.get('features') or []),
        'parameters': {name: parameters[name] for name in sorted(parameters)},
    }
    pinned = deepcopy(body)
    pinned['rules_hash'] = digest(RULES_LABEL, body)
    return pinned


def pin_rules(state, record):
    pinned = rules_in_force(state)
    if pinned is not None and type(record) is dict:
        record['rules'] = pinned
    return record


def obligation_active(record, feature):
    """True only when this covenant was bound, or later amended, under `feature`."""
    rules = record.get('rules') if type(record) is dict else None
    if not isinstance(rules, dict):
        return False
    features = rules.get('features')
    return type(features) is list and feature in features


def recommend(state):
    """A dashboard hint. Calling it does not change the stage."""
    gov = _upgrade(state)
    usage = _usage(state if type(state) is dict else {})
    if gov is None:
        return {'current': None, 'recommended': None, 'reason': 'no 0.15 upgrade profile', 'usage': usage}
    stage = gov['stage']
    if stage >= 3 or usage['agreements'] < MILESTONES.get(stage, 10**9):
        reason = 'final stage' if stage >= 3 else 'below the published milestone'
        return {'current': stage, 'recommended': stage, 'reason': reason, 'usage': usage}
    return {'current': stage, 'recommended': stage + 1,
            'reason': 'usage milestone reached; handover is a council signature, not automatic', 'usage': usage}


def activate_due(state, height):
    """Apply scheduled 0.15 changes once their height has arrived.

    Returns the same object when nothing is due, so an idle chain keeps its
    state hash. Waiting never turns a short vote into a yes.
    """
    gov = _upgrade(state)
    if gov is None:
        return state
    integer(height, True)
    expiring = [kind for kind, pause in gov['pauses'].items() if height > pause['until']]
    ready = [pid for pid, prop in gov['scheduled'].items() if _due(prop, height)]
    if not expiring and not ready:
        return state
    state = deepcopy(state)
    gov = state['upgrade']
    for kind in expiring:
        gov['pauses'].pop(kind, None)
        _mark(gov, state['chain'], 'PAUSE_EXPIRED', {'kind': kind}, None, height)
    for pid in sorted(ready):
        prop = gov['scheduled'][pid]
        if prop['class'] == 'parameter' and not _parameter_ok(gov, prop['name'], prop['value']):
            prop['status'] = 'EXPIRED'
            _proposal_status(state, pid, 'EXPIRED')
            _mark(gov, state['chain'], 'PARAMETER_EXPIRED', {'proposal': pid}, None, height)
            continue
        prop['status'] = 'ACTIVE'
        _proposal_status(state, pid, 'ACTIVE')
        if prop['class'] == 'consensus':
            for feature in prop['features']:
                if feature not in gov['features']:
                    gov['features'].append(feature)
            gov['features'] = sorted(gov['features'])
            gov['protocol_version'] = prop['protocol_version']
        elif prop['class'] == 'parameter':
            gov['parameters'][prop['name']] = prop['value']
        elif prop['class'] == 'module':
            gov['modules'][prop['name']] = {
                'kind': prop['module_kind'], 'version': prop['version'], 'digest': prop['digest'], 'event': pid}
        _mark(gov, state['chain'], 'ACTIVATE', {'proposal': pid, 'class': prop['class']}, pid, height)
    return state


def validate_change(state, kind, change, height, not_before, scheduling):
    gov = _upgrade(state)
    need(gov is not None, 'UPGRADE_PROFILE')
    stage = gov['stage']
    if kind == 'UPGRADE':
        exact(change, 'features activation_height code_hash testnet protocol_version')
        version = change['protocol_version']
        need(type(version) is str and version.startswith('covenant-consensus/') and version.split('/')[-1].isdigit()
             and len(version) <= 40, 'PROTOCOL_VERSION')
        features = change['features']
        need(type(features) is list and 1 <= len(features) <= 8 and features == sorted(set(features)), 'CHANGES')
        for name in features:
            if name in OSSIFIED:
                raise ValueError('OSSIFIED')
            need(name in FEATURES, 'FEATURE_UNKNOWN')
        key(change['code_hash'])
        need(type(change['testnet']) is str and 1 <= len(change['testnet']) <= 80, 'TESTNET')
        _activation(change['activation_height'], height, not_before, blocks_for(CONSENSUS_TIMELOCK[stage]), scheduling)
    elif kind == 'PARAMETER':
        exact(change, 'name value activation_height')
        if change['name'] in OSSIFIED:
            raise ValueError('OSSIFIED')
        need(change['name'] in PARAMETERS, 'PARAMETER_UNKNOWN')
        need(_parameter_ok(gov, change['name'], change['value']), 'PARAMETER_BOUNDS')
        _activation(change['activation_height'], height, not_before, blocks_for(PARAMETER_TIMELOCK[stage]), scheduling)
    elif kind == 'MODULE':
        exact(change, 'name kind version digest replaces activation_height')
        _module_ok(gov, change)
        _activation(change['activation_height'], height, not_before, blocks_for(PARAMETER_TIMELOCK[stage]), scheduling)
    elif kind == 'HANDOVER':
        exact(change, 'stage release_veto')
        integer(change['stage'], True)
        need(change['stage'] == stage + 1 and change['stage'] <= 3, 'STAGE_DIRECTION')
        need(type(change['release_veto']) is bool, 'VETO_FLAG')
        need(change['release_veto'] is False or change['stage'] == 3, 'VETO_FLAG')
    elif kind == 'PAUSE':
        exact(change, 'kind')
        need(change['kind'] in PAUSE_KINDS and change['kind'] not in gov['pauses'], 'PAUSE_KIND')
    else:
        raise ValueError('GOVERNANCE_CHANGE_UNSUPPORTED')


def stamp_proposal(state, proposal):
    """Remember the vote this proposal was published under. Later stages do not rewrite it."""
    gov = _upgrade(state)
    if gov is None or proposal.get('kind') not in UPGRADE_KINDS:
        return
    faults = state['domain']['active']['faults']
    quorum = 2 * faults + 1
    kind = proposal['kind']
    stage = gov['stage']
    # Handover and pause stay with the council. Validator quorum is added
    # for parameters, modules and consensus upgrades from stage 2.
    if kind in {'HANDOVER', 'PAUSE'} or (kind in {'PARAMETER', 'MODULE'} and stage == 1):
        required = 0
    elif kind == 'UPGRADE' and stage == 1:
        required = 1
    else:
        required = quorum
    proposal['readiness_required'] = required
    proposal['needs_holders'] = stage >= 3 and kind == 'UPGRADE'
    proposal['holders'] = []
    proposal['deposit_settled'] = False


def lock_deposit(state, actor, deposit):
    exact(deposit, 'resource quantity')
    resource = _reserve(state)
    need(deposit['resource'] == resource, 'DEPOSIT_RESOURCE')
    integer(deposit['quantity'], True)
    need(deposit['quantity'] >= PUBLIC_DEPOSIT, 'DEPOSIT')
    from .ledger_base import add, amount
    need(amount(state['balances'], actor, resource) >= deposit['quantity'], 'DEPOSIT_FUNDS')
    need(amount(state['authority_available'], actor, resource) >= deposit['quantity'], 'DEPOSIT_FUNDS')
    add(state['balances'], actor, resource, -deposit['quantity'])
    add(state['authority_available'], actor, resource, -deposit['quantity'])
    escrow = state['upgrade_deposits']
    escrow[resource] = escrow.get(resource, 0) + deposit['quantity']


def unlock_deposit(state, actor, deposit):
    resource = deposit['resource']
    quantity = deposit['quantity']
    from .ledger_base import add
    escrow = state['upgrade_deposits']
    need(escrow.get(resource, 0) >= quantity, 'DEPOSIT')
    escrow[resource] = escrow.get(resource, 0) - quantity
    add(state['balances'], actor, resource, quantity)
    add(state['authority_available'], actor, resource, quantity)


def readiness_met(state, proposal):
    required = proposal.get('readiness_required')
    if required is None:
        faults = state['domain']['active']['faults']
        return len(proposal['readiness']) >= 2 * faults + 1
    if len(proposal['readiness']) < required:
        return False
    if proposal.get('needs_holders') and not _holders_met(state, proposal):
        raise ValueError('HOLDER_VOTE')
    return True


def add_holder(state, proposal, actor):
    need(proposal.get('needs_holders'), 'HOLDER_VOTE')
    need(all(row['actor'] != actor for row in proposal['holders']), 'HOLDER_VOTE')
    resource = _reserve(state)
    from .ledger_base import amount
    weight = amount(state['balances'], actor, resource)
    need(weight > 0, 'HOLDER_WEIGHT')
    proposal['holders'].append({'actor': actor, 'weight': weight, 'resource': resource})


def execute(state, proposal, tid, height):
    gov = _upgrade(state)
    need(gov is not None, 'UPGRADE_PROFILE')
    kind = proposal['kind']
    change = proposal['change']
    if kind == 'UPGRADE':
        gov['scheduled'][tid] = {
            'class': 'consensus', 'status': 'SCHEDULED', 'activation_height': change['activation_height'],
            'features': list(change['features']), 'protocol_version': change['protocol_version'],
            'code_hash': change['code_hash'], 'testnet': change['testnet'],
        }
    elif kind == 'PARAMETER':
        gov['scheduled'][tid] = {
            'class': 'parameter', 'status': 'SCHEDULED', 'activation_height': change['activation_height'],
            'name': change['name'], 'value': change['value'],
        }
    elif kind == 'MODULE':
        gov['scheduled'][tid] = {
            'class': 'module', 'status': 'SCHEDULED', 'activation_height': change['activation_height'],
            'name': change['name'], 'module_kind': change['kind'], 'version': change['version'],
            'digest': change['digest'],
        }
    elif kind == 'HANDOVER':
        gov['stage'] = change['stage']
        if change['release_veto']:
            gov['veto'] = False
        gov['handovers'].append({'stage': change['stage'], 'release_veto': change['release_veto'],
                                 'height': height, 'event': tid})
    elif kind == 'PAUSE':
        gov['pauses'][change['kind']] = {
            'until': height + blocks_for(PAUSE_SECONDS), 'ratified': False, 'signals': [], 'event': tid}
    else:
        raise ValueError('GOVERNANCE_CHANGE_UNSUPPORTED')
    gov['log'].append({'event': tid, 'action': kind, 'height': height, 'actor': proposal['proposer']})


def note_pause_signal(state, kind, member):
    gov = _upgrade(state)
    need(gov is not None and kind in gov['pauses'], 'PAUSE_KIND')
    pause = gov['pauses'][kind]
    need(pause['ratified'] is False and member not in pause['signals'], 'PAUSE_RATIFIED' if pause['ratified'] else 'VALIDATOR_SIGNAL')
    active = state['domain']['active']
    need(member in active['validators'], 'GOVERNANCE_VALIDATOR')
    pause['signals'].append(member)
    if len(pause['signals']) >= 2 * active['faults'] + 1:
        pause['ratified'] = True
        return True
    return False


def extend_pause(pause, height):
    pause['until'] = min(pause['until'] + blocks_for(PAUSE_SECONDS), height + blocks_for(14 * 86400))


def _activation(activation, height, not_before, delay, scheduling):
    integer(activation, True)
    if not scheduling:
        return
    need(type(height) is int and type(not_before) is int, 'TIMELOCK')
    need(activation >= not_before and activation >= height + delay, 'TIMELOCK')


def _module_ok(gov, change):
    need(type(change['name']) is str and 1 <= len(change['name']) <= 32, 'MODULE_NAME')
    need(all(c.islower() or c.isdigit() or c == '-' for c in change['name']), 'MODULE_NAME')
    need(change['name'] not in CORE_MODULES and change['kind'] in MODULE_KINDS, 'MODULE_CORE')
    need(type(change['version']) is str and 1 <= len(change['version']) <= 32, 'MODULE_VERSION')
    key(change['digest'])
    current = gov['modules'].get(change['name'])
    if current is None:
        need(change['replaces'] is None, 'MODULE_REPLACES')
    else:
        key(change['replaces'])
        need(change['replaces'] == current['digest'], 'MODULE_REPLACES')


def _parameter_ok(gov, name, value):
    if name != 'archive_cap':
        return False
    from .shielded import ARCHIVE_CAP
    current = gov['parameters'].get('archive_cap', ARCHIVE_CAP)
    stage = gov['stage']
    return type(value) is int and current < value <= ARCHIVE_MAX[stage] and value - current <= ARCHIVE_STEP[stage]


def _due(prop, height):
    return prop.get('status') == 'SCHEDULED' and height >= prop['activation_height']


def _holders_met(state, proposal):
    resource = _reserve(state)
    supply = state.get('supply')
    total = supply.get(resource, 0) if supply is not None else 0
    if type(total) is not int or total <= 0:
        return False
    weight = sum(row['weight'] for row in proposal.get('holders', []) if row.get('resource') == resource)
    return weight * 10000 >= HOLDER_QUORUM_BPS * total


def _reserve(state):
    return state['market_config']['active']['body']['reserve']['resource']


def _proposal_status(state, pid, status):
    proposals = state.get('governance_proposals')
    if proposals is not None and pid in proposals:
        proposals[pid]['status'] = status


def _mark(gov, chain, action, body, tid, height):
    gov['log'].append({'event': tid, 'action': action, 'height': height,
                       'statement': digest(RULES_LABEL, {'chain': chain, 'action': action, 'body': body})})


def _usage(state):
    return {'agreements': _count(state, 'agreements'), 'service_jobs': _count(state, 'service_jobs'),
            'world_jobs': _count(state, 'world_jobs')}


def _count(state, name):
    value = state.get(name)
    if value is None:
        return 0
    try:
        return len(value)
    except TypeError:
        return 0
