"""Synthetic demand exchange in test mode: one $500K business loan, 20 lenders, then an agent-work task.

Run ``python -m covenant_chain.exchange_demo demo`` (add ``--json`` for machine output).
Every key comes from a fixed synthetic seed, every unit is test money, the clock is
a fixed synthetic clock, and nothing leaves the process: no network, no real
funds, no real credentials and no legal effect. The commitment deposit moves only
inside a local disposable-credit escrow desk.
"""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from covenant_language import agreement_application as app
from covenant_language import market_blueprints, marketplace

from . import exchange_book as book
from . import exchange_close as close
from . import exchange_credit as credit
from . import exchange_dossier as dossier
from . import exchange_profile as profile
from . import exchange_retrade as retrade
from . import hidden_credentials as hc
from .crypto import digest, public_key, sign

T0 = 1_893_456_000
DAY = 86400
CHAIN = hashlib.sha256(b'aap-exchange-demo-chain').hexdigest()
KYB_ISSUER = 'https://kyb.synthetic.example'
LENDER_REGISTRY = 'https://lender-registry.synthetic.example'
ROGUE_REGISTRY = 'https://unpinned-registry.synthetic.example'
ACCOUNTS = 'https://accounts.synthetic.example'
MODE = {'mode': 'TEST', 'synthetic': True, 'funds_moved': False, 'network': False, 'legal_effect': False}


def key(label):
    return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(b'aap-exchange-demo/' + label.encode()).digest())


def hexdigest(label):
    return hashlib.sha256(label.encode()).hexdigest()


class Clock:
    def __init__(self, at=T0):
        self.at = at

    def __call__(self):
        return self.at


def signed(kind, payload, private):
    return profile.sign_record(kind, payload['body'], private)


def lender_terms(index):
    """Deterministic variety: fixed and index-plus-margin rates, fees, terms, amortisation and protections."""
    rate = ({'kind': 'FIXED', 'bps': 925 + 37 * index} if index % 4 else
            {'kind': 'INDEX_PLUS_MARGIN', 'index': 'SOFR-30D-AVG', 'index_bps': 430, 'margin_bps': 450 + 25 * index,
             'floor_bps': 500, 'cap_bps': 2400})
    fees = [{'name': 'ORIGINATION', 'amount': 250000 * (index % 5), 'timing': 'AT_FUNDING', 'finance_charge': True}]
    if index % 3 == 0:
        fees.append({'name': 'FILING', 'amount': 15000, 'timing': 'AT_FUNDING', 'finance_charge': False})
    if index % 7 == 2:
        fees.append({'name': 'DOCUMENTATION', 'amount': 50000, 'timing': 'WITH_FIRST_PAYMENT', 'finance_charge': True})
    terms = {'product': 'TERM_LOAN', 'principal': 50000000, 'currency': 'USD', 'rate': rate, 'fees': fees,
             'term_months': (36, 48, 60)[index % 3], 'amortisation': 'EQUAL_PRINCIPAL' if index == 11 else 'LEVEL',
             'payment_frequency': 'MONTHLY', 'first_payment_days': 30 if index % 5 else 45,
             'prepayment': ({'kind': 'NONE'} if index % 2 else {'kind': 'PERCENT_OF_BALANCE', 'bps': 100 + 50 * (index % 4), 'months': 12}),
             'collateral': [{'kind': 'BLANKET_LIEN', 'lien_position': 1, 'description_sha256': hexdigest('all business assets')}],
             'guarantees': ([{'kind': 'PERSONAL', 'limit_bps': 10000, 'guarantor_role': 'majority owner'}] if index % 3 != 1 else []),
             'covenants': ([{'kind': 'MIN_DSCR_BPS', 'value': 12500, 'text_sha256': None}] if index % 4 == 1 else [])}
    if index == 19:
        terms['rate'] = {'kind': 'FIXED', 'bps': 3400}
    return terms


class LoanMarket:
    """The $500K loan journey with real signatures, a real journal and test-mode money only."""

    def __init__(self, directory, lenders=20, *, operator=True, policy_limit=10000000):
        self.root = Path(directory)
        self.clock = Clock()
        self.principal, self.agent = key('business/principal'), key('business/agent')
        self.owner, self.adviser, self.operator = key('business/owner-approver'), key('business/adviser'), key('venue/operator')
        self.kyb_issuer, self.registry, self.rogue, self.accounts = (key('issuer/kyb'), key('issuer/lender-registry'),
                                                                       key('issuer/rogue'), key('issuer/accounts'))
        self.guarantor = key('business/guarantor')
        self.lenders = [key('lender/%02d' % index) for index in range(1, lenders + 1)]
        self.pub = lambda private: public_key(private)
        self.venue = None
        if operator:
            prepared = book.venue(operator=self.pub(self.operator), name='Synthetic SMB credit venue',
                                  verticals=['agent-work', 'credit'], modes=['SEALED'],
                                  require=['principal_kyb', 'verified_agent'], max_window=7 * DAY,
                                  required_metrics=['apr_cbps'], max_metrics=8,
                                  fee={'model': 'PROTOCOL_FEE', 'rate': None, 'payer': 'OFFEROR'},
                                  created_at=T0 - DAY, nonce=hexdigest('venue'))
            self.venue = profile.sign_record('VENUE', prepared['body'], self.operator)
            self.venue_ref = prepared['id']
        policy = __import__('covenant_agent.assent_gate', fromlist=['policy_body'])
        body = policy.policy_body(self.pub(self.owner), self.pub(self.agent), method={'kind': 'OWNER_KEY', 'key': self.pub(self.owner)},
                                  thresholds={'USD': policy_limit}, roles=('agent',), max_age=3600, nonce=hexdigest('policy'))
        self.policy = policy.sign_policy(self.owner, body)
        self.book = book.ExchangeBook(self.root / ('venue' if operator else 'book'), clock=self.clock,
                                      role='OPERATOR' if operator else 'REQUESTER', venue=self.venue,
                                      approval_policy=self.policy, log=self._log)
        self.log_lines = []
        self.dossier = self._dossier()

    def _log(self, line):
        self.log_lines.append(line)

    def close(self):
        self.book.close()

    # the business, its dossier and its request ------------------------------------------
    def _dossier(self):
        pack = dossier.Dossier(key('business/dossier-holder'))
        pack.fill('business_identity', {'legal_name': 'Synthetic Bakery LLC', 'ein_sha256': hexdigest('synthetic-ein'),
                                        'formed': 2014, 'state': 'NY'})
        pack.fill('use_of_funds', {'category': 'WORKING_CAPITAL', 'summary': 'Inventory and fit-out for two new stores'})
        pack.fill('ownership', {'owners': [{'role': 'majority owner', 'share_bps': 7000}, {'role': 'minority owner', 'share_bps': 3000}]})
        pack.fill('collateral', {'offered': ['BLANKET_LIEN', 'EQUIPMENT'], 'equipment_value': 31000000})
        figures = dossier.attest(ACCOUNTS, self.accounts, pack.holder,
                                 {'financial_statements': {'year': 2029, 'revenue': 412000000, 'ebitda': 61000000,
                                                           'reviewed_by': 'synthetic CPA review'},
                                  'bank_cash_flow': {'months': 12, 'average_monthly_inflow': 34500000, 'nsf_events': 0}},
                                 now=T0 - DAY, lifetime=60 * DAY)
        kyb = dossier.attest(KYB_ISSUER, self.kyb_issuer, pack.holder,
                             {'kyb_attestation': {'status': 'VERIFIED', 'checked': 'synthetic registry and beneficial owners'}},
                             now=T0 - DAY, lifetime=60 * DAY)
        pack.attach(figures)
        pack.attach(kyb)
        self.dossier_issuers = {ACCOUNTS: self.pub(self.accounts), KYB_ISSUER: self.pub(self.kyb_issuer)}
        return pack

    def plan(self):
        return {'PUBLIC_TEASER': ['use_of_funds'], 'ELIGIBLE': ['business_identity', 'use_of_funds'],
                'SHORTLIST': ['bank_cash_flow', 'business_identity', 'financial_statements', 'kyb_attestation', 'use_of_funds'],
                'AWARD': sorted(dossier.CREDIT_FIELDS)}

    def rule(self):
        return {'hard': [{'metric': 'principal', 'op': 'EQ', 'value': 50000000},
                         {'metric': 'apr_cbps', 'op': 'LE', 'value': 300000},
                         {'metric': 'term_months', 'op': 'GE', 'value': 36}],
                'score': [{'metric': 'apr_cbps', 'weight': 60, 'best': 80000, 'worst': 250000},
                          {'metric': 'payment_max', 'weight': 15, 'best': 900000, 'worst': 2000000},
                          {'metric': 'prepayment_max', 'weight': 15, 'best': 0, 'worst': 2500000},
                          {'metric': 'guarantees', 'weight': 10, 'best': 0, 'worst': 2}],
                'tie_break': ['METRIC:apr_cbps:LOWER', 'EARLIEST_SUBMISSION', 'OFFER_ID'], 'shortlist': 3}

    def mandate(self):
        from .portable_trust import mandate, sign_record
        made = mandate(self.pub(self.principal), self.pub(self.agent), ['EXCHANGE_AWARD', 'EXCHANGE_REQUEST'],
                       ['exchange:agent-work', 'exchange:credit'], profile.PROFILE, {'USD': 50000000},
                       T0 - DAY, T0 + 120 * DAY, hexdigest('mandate'))
        return [sign_record(made['body'], [self.principal])]

    def request(self, **changes):
        window = {'opens': T0 + 3600, 'closes': T0 + 3600 + 2 * DAY, 'reveal_by': T0 + 3600 + 3 * DAY, 'min_validity': 30 * DAY}
        fields = dict(vertical='credit', principal=self.pub(self.principal), agent=self.pub(self.agent),
                      want={'product': 'TERM_LOAN', 'amount': 50000000, 'currency': 'USD', 'purpose': 'WORKING_CAPITAL',
                            'term_months_min': 36, 'term_months_max': 60, 'collateral_offered': ['BLANKET_LIEN', 'EQUIPMENT'],
                            'jurisdiction': 'US-NY'},
                      eligibility={'require': ['principal_kyb', 'verified_agent'],
                                   'issuers': {LENDER_REGISTRY: self.pub(self.registry)}, 'max_offers': 32, 'requirement': None},
                      disclosure_plan=self.plan(),
                      teaser={'use_of_funds': {'category': 'WORKING_CAPITAL', 'summary': 'Inventory and fit-out for two new stores'}},
                      window=window, mode='SEALED', award_rule=self.rule(),
                      conditions=credit.conditions({'kyb': {KYB_ISSUER: self.pub(self.kyb_issuer)},
                                                    'financials': {ACCOUNTS: self.pub(self.accounts)}}),
                      close_by=window['reveal_by'] + 30 * DAY,
                      dispute={'procedure': 'urn:aap:dispute-ladder:negotiate-then-arbitrate', 'resolver': None, 'appeal': None},
                      fees={'operator': {'payer': 'OFFEROR' if self.venue else 'NONE'},
                            'adviser': {'adviser': self.pub(self.adviser), 'payer': 'REQUESTER', 'bps': 100, 'flat': 0, 'unit': 'USD',
                                        'conflicts': ['Adviser receives no lender compensation']}},
                      venues=[self.venue_ref] if self.venue else [], created_at=T0, nonce=hexdigest('request'))
        fields.update(changes)
        prepared = profile.request(**fields)
        envelope = {**profile.sign_record('REQUEST', prepared['body'], self.agent), 'permission': self.mandate()}
        return prepared, envelope

    # lenders ----------------------------------------------------------------------------
    def credential(self, index, rogue=False):
        issuer_key = self.rogue if rogue else self.registry
        issuer = hc.CredentialIssuer(ROGUE_REGISTRY if rogue else LENDER_REGISTRY, issuer_key, clock=lambda: T0)
        account = self.lenders[index]
        holder = key('lender/%02d/holder' % (index + 1))
        request = hc.issuance_request(CHAIN, self.pub(account), [self.pub(holder)], mode='SCOPED',
                                      scope='aap-exchange-lenders', nonce=hexdigest('issue/%d/%s' % (index, rogue)))
        issued = issuer.issue(request, sign(account, hc.REQUEST_LABEL, request),
                              hc.claims_template(verified_agent=True, principal_kyb=True))
        return holder, issued['credentials'][0]

    def offer(self, request_record, index, at, *, rogue=False, terms=None, deposit=True):
        lender = self.lenders[index]
        holder, credential = self.credential(index, rogue)
        ref = request_record['id']
        presentation = hc.present(credential, holder, disclose={'verified_agent': True, 'principal_kyb': True},
                                  audience=profile.eligibility_audience(ref),
                                  nonce=profile.eligibility_nonce(ref, self.pub(lender)), now=at)
        made = profile.offer(request_record, offeror=self.pub(lender), terms=terms or lender_terms(index + 1),
                             valid_until=request_record['body']['window']['closes'] + 45 * DAY, created_at=at,
                             nonce=hexdigest('offer/%d' % index), eligibility=presentation,
                             conditions=[{'id': 'deposit', 'kind': 'COMMITMENT_DEPOSIT', 'evidence': 'DEPOSIT_RECEIPT',
                                          'supplier': 'OFFEROR', 'beneficiary': 'REQUESTER', 'due_after_award': 2 * DAY,
                                          'issuers': {}}] if deposit else [],
                             deposit={'amount': 500000, 'unit': 'USD', 'payer': 'OFFEROR'} if deposit else None)
        return made, profile.sign_record('OFFER', made['body'], lender)

    def seal(self, request_record, offer_record, index, at):
        salt = hexdigest('salt/%d' % index)
        sealed = profile.commitment(request_record['id'], offer_record['id'], salt)
        prepared = profile.seal(request_record['id'], self.pub(self.lenders[index]), sealed, at)
        return profile.sign_record('SEAL', prepared['body'], self.lenders[index]), salt


def run_loan(directory, lenders=20, detail=False):
    started = time.perf_counter()
    market = LoanMarket(directory, lenders)
    out = {'vertical': 'credit', 'test_mode': dict(MODE)}
    try:
        record, envelope = market.request()
        rid = record['id']
        market.clock.at = T0 + 60
        out['posted'] = market.book.post(envelope)['status']
        market.clock.at = record['body']['window']['opens'] + 60
        withdrawn, silent, declined, rogue = 3, 8, 12, 16  # zero-based lender indexes with special roles
        sealed, offers, relays = {}, {}, 0
        for index in range(lenders):
            at = market.clock.at
            if index == declined:
                made = profile.decline(rid, market.pub(market.lenders[index]), ['CASH_FLOW_INSUFFICIENT', 'DEBT_LEVEL'], at,
                                       pack=profile.shipped_verticals()['verticals']['credit'])
                result = market.book.decline(rid, profile.sign_record('DECLINE', made['body'], market.lenders[index]))
                out['decline_notice'] = {'action': result['notice']['action'],
                                         'reasons': [row['text'] for row in result['notice']['principal_reasons']]}
                continue
            # ELIGIBLE stage: each lender gets only what the plan allows, under a signed consent receipt.
            released = market.dossier.release(market.pub(market.lenders[index]), rid, 'ELIGIBLE',
                                              ['business_identity', 'use_of_funds'], 'CREDIT_DECISION', plan=market.plan(),
                                              retention_until=T0 + 400 * DAY, expires=T0 + 60 * DAY, now=at,
                                              nonce=hexdigest('consent/eligible/%d' % index))
            dossier.verify_release(released['release'], released['consent'], plan=market.plan(),
                                   issuers=market.dossier_issuers, now=at)
            market.book.consent(rid, released['consent'])
            made, offer_envelope = market.offer(record, index, at, rogue=index == rogue)
            seal_envelope, salt = market.seal(record, made, index, at)
            result = market.book.seal(rid, seal_envelope)
            relays += result['relay_payload'] is not None
            sealed[index] = (offer_envelope, salt, seal_envelope)
            offers[index] = made
            market.clock.at += 300
        # A withdrawal before close is recorded against the lender's close record.
        lender = market.lenders[withdrawn]
        target = profile.verify_seal(sealed[withdrawn][2], rid)[1]
        made = profile.withdrawal(rid, market.pub(lender), target, 'CAPACITY', market.clock.at)
        market.book.withdraw(rid, profile.sign_record('WITHDRAW', made['body'], lender))
        out['sealed'] = len(sealed)
        out['relay_receipts_prepared'] = relays
        try:
            market.book.compare(rid)
            out['compare_before_close'] = 'ALLOWED'
        except profile.ExchangeError as exc:
            out['compare_before_close'] = exc.code
        market.clock.at = record['body']['window']['closes'] + 600
        refused = {}
        for index, (offer_envelope, salt, _) in sealed.items():
            if index in (withdrawn, silent):
                continue
            try:
                market.book.reveal(rid, offer_envelope, salt)
            except profile.ExchangeError as exc:
                refused[market.pub(market.lenders[index])] = exc.code
        out['reveal_refusals'] = sorted(refused.values())
        market.clock.at = record['body']['window']['reveal_by'] + 60
        comparison = market.book.compare(rid, detail='FULL' if detail else 'SUMMARY')
        out['comparison'] = {'id': comparison['id'], 'final': comparison['final'], 'ranked': len(comparison['ranked']),
                             'excluded': [{'offeror': row['offeror'][:12], 'reasons': row['reasons']} for row in comparison['excluded']],
                             'not_revealed': len(comparison['not_revealed']), 'ordering': comparison['ordering']}
        out['ranking'] = [{'rank': row['rank'], 'offeror': row['offeror'][:12], 'score_ppm': row['score_ppm'],
                           'apr': '%d.%04d%%' % divmod(row['metrics']['apr_cbps'], 10000),
                           'finance_charge': row['metrics']['finance_charge'], 'payment_max': row['metrics']['payment_max'],
                           'term_months': row['metrics']['term_months'], 'eligibility': row['eligibility']['status'],
                           'venue_fee': row['fees']['venue']['amount'], 'adviser_fee': row['fees']['adviser']['amount'],
                           'adviser_conflicts': row['fees']['adviser']['conflicts'],
                           'explanation': [{'metric': part['metric'], 'value': part['value'], 'points_ppm': part['points_ppm']}
                                           for part in row['explanation']],
                           'versus_next': row['versus_next']} for row in comparison['ranked']]
        # SHORTLIST stage releases, then the award for the top offer.
        for row in comparison['ranked'][:3]:
            index = next(i for i, made in offers.items() if made['id'] == row['offer'])
            released = market.dossier.release(row['offeror'], rid, 'SHORTLIST', market.plan()['SHORTLIST'], 'UNDERWRITING',
                                              plan=market.plan(), retention_until=T0 + 400 * DAY, expires=T0 + 60 * DAY,
                                              now=market.clock.at, nonce=hexdigest('consent/shortlist/%d' % index))
            dossier.verify_release(released['release'], released['consent'], plan=market.plan(),
                                   issuers=market.dossier_issuers, now=market.clock.at)
            market.book.consent(rid, released['consent'])
        top = comparison['ranked'][0]
        winner = next(i for i, made in offers.items() if made['id'] == top['offer'])
        out['award'] = award(market, record, envelope, sealed[winner][0], comparison, winner)
        out['notices'] = len(market.book.notices(rid)['notices'])
        out['retrade_check'] = retrade_check(market, out['award']['_award'])
        out['checklist'] = satisfy(market, record, out['award']['_award'], winner)
        out['close'] = close_deal(market, rid, out['award']['_award'], winner)
        records = market.book.close_records(rid)
        out['close_records'] = [{'offeror': row['offeror'][:12], **{k: row[k] for k in (
            'offered', 'awarded', 'closed_on_offered_terms', 'closed_retraded', 'withdrawn', 'failed_condition',
            'close_on_terms_lb_bps', 'firm_offer_lb_bps', 'not_revealed_statements', 'refused_reveal_statements')}}
            for row in records['records']]
        out['health'] = market.book.health()['status']
        out['metrics_lines'] = len(market.book.metrics().splitlines())
        out['log_lines'] = len(market.log_lines)
        out['award'].pop('_award')
    finally:
        market.close()
    out['seconds'] = round(time.perf_counter() - started, 3)
    return out


def award(market, record, request_envelope, offer_envelope, comparison, winner):
    rid = record['id']
    lender = market.lenders[winner]
    context = hexdigest('award-context')
    prepared_award = close.prepare_award(request_envelope, offer_envelope, comparison, context=context,
                                         at=market.clock.at)
    application = prepared_award['application']
    echoes = [{'party': role, 'acceptance': application['acceptance'],
               'signature': sign(signer, payload['label'], payload['body'])}
              for role, signer in (('requester', market.agent), ('offeror', lender))
              for payload in [prepared_award['echo_payloads'][role]]]
    ready = app.prepare(application, echoes)
    assent = ready['prepared']['assent_payload']
    approvals = [{'concept': row['concept'], 'party': row['party'],
                  'signature': sign(market.agent if row['party'] == 'requester' else lender, assent['label'], row['body'])}
                 for row in assent['required_assents']]
    verified = app.verify(application, echoes, approvals, ready['prepared']['id'], assent['body']['closure'])
    request = close.approval_request(market.policy, prepared_award, occurrence=hexdigest('approval-1'), at=market.clock.at)
    approval = close.sign_approval(market.owner, request)
    record_body = close.award_record(prepared_award, ready['prepared']['id'], approval=request['occurrence'])
    envelope = profile.sign_record('AWARD', record_body['body'], market.agent)
    try:
        market.book.award(rid, prepared_award, envelope)
        without = 'ALLOWED'
    except profile.ExchangeError as exc:
        without = exc.code
    result = market.book.award(rid, prepared_award, envelope, approval=approval)
    released = market.dossier.release(market.pub(lender), rid, 'AWARD', market.plan()['AWARD'], 'CLOSING', plan=market.plan(),
                                      retention_until=T0 + 400 * DAY, expires=T0 + 60 * DAY, now=market.clock.at,
                                      nonce=hexdigest('consent/award'))
    dossier.verify_release(released['release'], released['consent'], plan=market.plan(), issuers=market.dossier_issuers,
                           now=market.clock.at)
    market.book.consent(rid, released['consent'])
    disclosure = credit.disclosure('us-ny-cfdl', json.loads(application['terms']['offer_terms']['value']),
                                   'Synthetic Lender %02d' % (winner + 1))
    return {'_award': prepared_award, 'status': result['status'], 'approval_required': result['approval_required'],
            'without_owner_approval': without, 'assent': 'BOTH_PARTIES' if verified['exact_assent'] else 'MISSING',
            'application': prepared_award['id'][:16], 'rehearsal': prepared_award['rehearsal']['status'],
            'disclosure': [{'label': row['label'], 'value': row['value']} for row in disclosure['rows']],
            'disclosure_legal_advice': disclosure['legal_advice']}


def retrade_check(market, prepared_award):
    """A lender that changes the APR at closing is caught; without re-acceptance it cannot close."""
    terms = close.award_terms(prepared_award['application'])
    worse = deepcopy(terms['offer_terms'])
    if worse['rate']['kind'] == 'FIXED':
        worse['rate']['bps'] += 100
    else:
        worse['rate']['margin_bps'] += 100
    application = deepcopy(prepared_award['application'])
    application['terms']['offer_terms']['value'] = close._canon(worse)
    application['explicit_terms']['offer_terms']['value'] = close._canon(worse)
    application['rendered'] = app._render(application['template'], application['terms'])
    pack = profile.shipped_verticals()['verticals']['credit']
    change = retrade.diff(pack, terms['want'], terms['offer_terms'], worse)
    try:
        retrade.classify(pack, prepared_award, application)
        outcome = 'ACCEPTED'
    except profile.ExchangeError as exc:
        outcome = exc.code
    return {'change': change['outcome'], 'apr_change': [row for row in change['metrics'] if row['metric'] == 'apr_bps'],
            'without_reacceptance': outcome}


def deposit_desk(market, directory, prepared_award, winner):
    """Commitment deposit in test mode: a local disposable-credit quorum escrow, nothing real."""
    from .escrow_desk import DemoEscrowDesk
    lender = market.lenders[winner]
    people = {'lender': market.pub(lender), 'requester': market.pub(market.agent), 'operator': market.pub(market.operator)}
    desk = DemoEscrowDesk(Path(directory) / 'deposit', 'TEST-USD', {people['lender']: 1000000, people['requester']: 0,
                                                                     people['operator']: 0})
    asset = market_blueprints.asset('covenant-disposable', 'TEST-USD', 'TEST-USD', desk.ref)
    policy = marketplace.escrow_policy('Commitment deposit', people['lender'], asset, 500000, people['lender'],
                                       people['requester'], sorted(people.values()), 2, close.award_terms(prepared_award['application'])['application'],
                                       release={'mode': 'EXACT_QUORUM'}, refund={'mode': 'EXACT_QUORUM'}, connector=desk.ref)['record']
    signers = {people['lender']: lender, people['requester']: market.agent, people['operator']: market.operator}

    def execute(effect, request):
        payload = desk.assent_payload(effect, request)
        approvals = [{'party': party, 'signature': sign(signers[party], payload['label'], payload['body'])}
                     for party in payload['eligible_signers'][:max(payload['threshold'], 2)]]
        return desk.execute(effect, {**request, 'approvals': approvals})
    return desk, policy, execute, people


def satisfy(market, record, prepared_award, winner):
    rid = record['id']
    application = prepared_award['application']
    terms = close.award_terms(application)
    agreement = terms['application']
    lender = market.lenders[winner]
    at = market.clock.at + 600
    market.clock.at = at
    desk, policy, execute, people = deposit_desk(market, market.root, prepared_award, winner)
    try:
        funded = execute(hexdigest('deposit/fund'), {'action': 'FUND', 'policy': policy})
        holder = key('business/kyb-holder')
        kyb = hc.CredentialIssuer(KYB_ISSUER, market.kyb_issuer, clock=lambda: at)
        request = hc.issuance_request(CHAIN, market.pub(market.principal), [market.pub(holder)], mode='BATCH', scope=None,
                                      nonce=hexdigest('kyb-issue'))
        issued = kyb.issue(request, sign(market.principal, hc.REQUEST_LABEL, request), hc.claims_template(principal_kyb=True))
        kyb_presentation = hc.present(issued['credentials'][0], holder, disclose={'principal_kyb': True},
                                      audience=close.condition_audience(agreement),
                                      nonce=close.condition_nonce(agreement, 'kyb'), now=at)
        figures = next(c for c in market.dossier.credentials if 'financial_statements' in c['claims'])
        financials = dossier.present(figures, market.dossier._key, ['bank_cash_flow', 'financial_statements'],
                                     audience=close.condition_audience(agreement),
                                     nonce=close.condition_nonce(agreement, 'financials'), now=at)
        document = hexdigest('personal guarantee v1')
        guarantee = {'document_sha256': document, 'signer': market.pub(market.guarantor),
                     'signature': sign(market.guarantor, close.DOCUMENT_LABEL, {'agreement': agreement, 'document_sha256': document})}
        payloads = {
            'kyb': ('SD_JWT_PRINCIPAL_KYB', {'presentation': kyb_presentation}),
            'financials': ('SD_JWT_DOSSIER_FIELDS', {'presentation': financials, 'fields': ['bank_cash_flow', 'financial_statements']}),
            'collateral': ('FILING_RECORD', {'document_sha256': hexdigest('UCC-1 synthetic'), 'filing_reference': 'SYN-UCC-2030-000123',
                                             'jurisdiction': 'US-NY'}),
            'guarantee': ('SIGNED_DOCUMENT', guarantee),
            'insurance': ('DOCUMENT', {'document_sha256': hexdigest('insurance certificate'), 'description': 'Synthetic property cover'}),
            'no_mac': ('ATTESTATION', {'statement': 'NO_MATERIAL_ADVERSE_CHANGE', 'as_of': at}),
            'funding': ('PAYMENT_OBSERVATION', {'reference': 'TEST-RAIL-0001', 'amount': 50000000, 'unit': 'USD',
                                                'rail': 'urn:aap:rail:manual:1', 'observed_at': at}),
            'deposit': ('DEPOSIT_RECEIPT', {'adapter': desk.ref, 'effect': hexdigest('deposit/fund'), 'escrow': funded['value']['escrow'],
                                            'amount': 500000, 'state': 'LOCKED'}),
        }
        keys = {'REQUESTER': market.agent, 'OFFEROR': lender}
        for item in close.checklist(application):
            kind, payload = payloads[item['id']]
            made = close.evidence(agreement, item['id'], kind, payload, item['supplier_key'], at)
            market.book.evidence(rid, profile.sign_record('EVIDENCE', made['body'], keys[item['supplier']]))
            decided = close.decision(agreement, item['id'], made['id'], 'SATISFIED', item['beneficiary_key'], at + 60)
            market.book.decide(rid, profile.sign_record('DECISION', decided['body'], keys[item['beneficiary']]))
        status = market.book.checklist(rid)
        released = execute(hexdigest('deposit/release'), {'action': 'PAYOUT', 'escrow': funded['value']['escrow'],
                                                           'payouts': {people['lender']: 500000}})
        snapshot = desk.snapshot()
    finally:
        desk.close()
    return {'status': status['status'], 'items': [[row['id'], row['status']] for row in status['items']],
            'digest': status['digest'], 'deposit': {'funded': funded['value']['state'], 'released': released['value']['state'],
                                                     'locked_after': snapshot['locked'], 'conserved_total': snapshot['conserved_total'],
                                                     'unit': 'TEST-USD'}}


def close_deal(market, rid, prepared_award, winner):
    lender = market.lenders[winner]
    status = market.book.checklist(rid)
    classified = retrade.classify(profile.shipped_verticals()['verticals']['credit'], prepared_award, prepared_award['application'])
    payload = close.close_payload(prepared_award, outcome=classified['outcome'],
                                  final_application=close.award_terms(prepared_award['application'])['application'],
                                  checklist_digest=status['digest'], closed_at=market.clock.at)
    receipt = {'body': payload['body'], 'signatures': {'requester': sign(market.agent, payload['label'], payload['body']),
                                                       'offeror': sign(lender, payload['label'], payload['body'])}}
    result = market.book.close_deal(rid, receipt)
    again = market.book.close_deal(rid, receipt)
    return {'outcome': result['outcome'], 'acknowledged': result['acknowledged'], 'retry': again['status']}


# --- the agent-work market AAP owns ----------------------------------------------------

def outcome_record(spec_id, artifact, status='MECHANICAL_PASS'):
    """A structured-outcome record in the covenant-structured-outcome/0.1 shape, built as synthetic data."""
    artifact_sha = hashlib.sha256(artifact).hexdigest()
    result = {'version': close.OUTCOME_RECORD, 'checker': 'covenant-structured-records-checker/0.1', 'spec': spec_id,
              'artifact_sha256': artifact_sha, 'status': 'PASS' if status == 'MECHANICAL_PASS' else 'FAIL',
              'valid_rows': 1000 if status == 'MECHANICAL_PASS' else 0, 'total_rows': 1000, 'errors': [], 'omitted_errors': 0,
              'source_truth_verified': False, 'agreement_assent_verified': False, 'execution_authorized': False,
              'payment_verified': False}
    result['id'] = digest(close.OUTCOME_RESULT_LABEL, result)
    return {'spec_id': spec_id, 'artifact_sha256': artifact_sha,
            'outcome': {'status': status, 'result': result, 'review_verified': False, 'external_truth_verified': False,
                        'agreement_assent_verified': False, 'execution_authorized': False, 'settlement_authorized': False}}


def run_agent_work(directory, providers=5):
    started = time.perf_counter()
    clock = Clock(T0)
    buyer, principal = key('work/buyer-agent'), key('work/principal')
    agents = [key('work/provider/%d' % index) for index in range(providers)]
    spec_id = hexdigest('outcome spec: 1,000 supplier contracts reviewed with clause flags')
    plan = {'PUBLIC_TEASER': ['task_brief'], 'ELIGIBLE': ['task_brief'], 'SHORTLIST': ['sample_inputs', 'task_brief'],
            'AWARD': ['access_terms', 'sample_inputs', 'task_brief']}
    rule = {'hard': [{'metric': 'deliver_by', 'op': 'LE', 'value': T0 + 5 * DAY}],
            'score': [{'metric': 'price', 'weight': 50, 'best': 100000, 'worst': 400000},
                      {'metric': 'deliver_by', 'weight': 20, 'best': T0 + 2 * DAY, 'worst': T0 + 5 * DAY},
                      {'metric': 'warranty_days', 'weight': 20, 'best': 30, 'worst': 0},
                      {'metric': 'rework_rounds', 'weight': 10, 'best': 3, 'worst': 0}],
            'tie_break': ['EARLIEST_SUBMISSION', 'OFFER_ID'], 'shortlist': 2}
    work = profile.shipped_verticals()['verticals']['agent-work']
    prepared = profile.request(vertical='agent-work', principal=public_key(principal), agent=public_key(principal),
                               want={'task': 'Review 1,000 supplier contracts by Friday and flag indemnity and auto-renewal clauses',
                                     'task_sha256': hexdigest('task text'), 'quantity': 1000, 'unit': 'USD', 'budget': 400000,
                                     'deliver_by': T0 + 5 * DAY, 'outcome_spec': spec_id, 'acceptance': 'MECHANICAL_PASS'},
                               eligibility={'require': [], 'issuers': {}, 'max_offers': 16, 'requirement': None},
                               disclosure_plan=plan, teaser={'task_brief': 'Contract review, 1,000 documents, English'},
                               window={'opens': T0 + 60, 'closes': T0 + 6 * 3600, 'reveal_by': T0 + 6 * 3600, 'min_validity': 3 * DAY},
                               mode='OPEN', award_rule=rule, conditions=deepcopy(_work_conditions(work)), close_by=T0 + 9 * DAY,
                               dispute={'procedure': 'urn:aap:dispute-ladder:negotiate-then-arbitrate', 'resolver': None, 'appeal': None},
                               fees={'operator': {'payer': 'NONE'}, 'adviser': None}, created_at=T0, nonce=hexdigest('work-request'))
    envelope = {**profile.sign_record('REQUEST', prepared['body'], principal), 'permission': []}
    out = {'vertical': 'agent-work', 'test_mode': dict(MODE)}
    desk = book.ExchangeBook(Path(directory) / 'work-book', clock=clock)
    try:
        desk.post(envelope)
        clock.at = T0 + 120
        for index, agent in enumerate(agents):
            terms = {'price': 180000 + 35000 * index, 'unit': 'USD', 'deliver_by': T0 + (2 + index % 3) * DAY,
                     'outcome_spec': spec_id, 'warranty_days': (30, 14, 7, 0, 21)[index % 5], 'rework_rounds': (2, 1, 3, 0, 1)[index % 5]}
            made = profile.offer(prepared, offeror=public_key(agent), terms=terms, valid_until=T0 + 8 * DAY,
                                 created_at=clock.at, nonce=hexdigest('work-offer/%d' % index))
            desk.submit(prepared['id'], profile.sign_record('OFFER', made['body'], agent))
            clock.at += 60
        clock.at = T0 + 6 * 3600 + 10
        comparison = desk.compare(prepared['id'])
        top = comparison['ranked'][0]
        winner = next(agent for agent in agents if public_key(agent) == top['offeror'])
        offer_envelope = next(e['value']['envelope'] for e in desk._events('X_OFFER', prepared['id'])
                              if e['value']['id'] == top['offer'])
        prepared_award = close.prepare_award(envelope, offer_envelope, comparison, context=hexdigest('work-context'), at=clock.at)
        record = close.award_record(prepared_award, hexdigest('work-assent-target'))
        desk.award(prepared['id'], prepared_award, profile.sign_record('AWARD', record['body'], principal))
        agreement = prepared_award['id']
        artifact = b'{"contracts":1000,"flags":"synthetic"}'
        clock.at += DAY
        keys = {'REQUESTER': principal, 'OFFEROR': winner}
        payloads = {'delivery': ('OUTCOME_CHECK_RECORD', outcome_record(spec_id, artifact)),
                    'payment': ('PAYMENT_OBSERVATION', {'reference': 'TEST-x402-0001', 'amount': top['metrics']['price'],
                                                        'unit': 'USD', 'rail': 'urn:aap:rail:x402:test', 'observed_at': clock.at})}
        for item in close.checklist(prepared_award['application']):
            kind, payload = payloads[item['id']]
            made = close.evidence(agreement, item['id'], kind, payload, item['supplier_key'], clock.at)
            desk.evidence(prepared['id'], profile.sign_record('EVIDENCE', made['body'], keys[item['supplier']]))
            decided = close.decision(agreement, item['id'], made['id'], 'SATISFIED', item['beneficiary_key'], clock.at + 30)
            desk.decide(prepared['id'], profile.sign_record('DECISION', decided['body'], keys[item['beneficiary']]))
        status = desk.checklist(prepared['id'])
        payload = close.close_payload(prepared_award, outcome='CLOSED_ON_OFFERED_TERMS', final_application=agreement,
                                      checklist_digest=status['digest'], closed_at=clock.at)
        receipt = {'body': payload['body'], 'signatures': {'requester': sign(principal, payload['label'], payload['body']),
                                                           'offeror': sign(winner, payload['label'], payload['body'])}}
        closed = desk.close_deal(prepared['id'], receipt)
        failing = outcome_record(spec_id, artifact, 'CHECKS_FAILED')
        out.update(offers=len(comparison['ranked']) + len(comparison['excluded']),
                   ranking=[{'rank': row['rank'], 'price': row['metrics']['price'], 'deliver_by_day': (row['metrics']['deliver_by'] - T0) // DAY,
                             'warranty_days': row['metrics']['warranty_days'], 'score_ppm': row['score_ppm']} for row in comparison['ranked']],
                   checklist=[[row['id'], row['status']] for row in status['items']], close=closed['outcome'],
                   failed_check_maps_to=close.outcome_check(failing, spec_id, 'MECHANICAL_PASS')['status'],
                   close_records=[{'offeror': row['offeror'][:12], 'awarded': row['awarded'],
                                   'closed_on_offered_terms': row['closed_on_offered_terms'],
                                   'close_on_terms_lb_bps': row['close_on_terms_lb_bps']} for row in desk.close_records()['records']
                                  if row['awarded']])
    finally:
        desk.close()
    out['seconds'] = round(time.perf_counter() - started, 3)
    return out


def _work_conditions(pack):
    return [{'id': 'delivery', 'kind': 'DELIVERY_WITH_OUTCOME_CHECK', 'evidence': 'OUTCOME_CHECK_RECORD', 'supplier': 'OFFEROR',
             'beneficiary': 'REQUESTER', 'due_after_award': 5 * DAY, 'issuers': {}},
            {'id': 'payment', 'kind': 'PAYMENT_RELEASED', 'evidence': 'PAYMENT_OBSERVATION', 'supplier': 'REQUESTER',
             'beneficiary': 'OFFEROR', 'due_after_award': 7 * DAY, 'issuers': {}}]


def run(lenders=20, providers=5):
    with tempfile.TemporaryDirectory(prefix='aap-exchange-demo-') as directory:
        Path(directory).chmod(0o700)
        loan = run_loan(directory, lenders)
        work = run_agent_work(directory, providers)
    return {'model': 'A deal is a promise both sides sign. Proof shows it was kept. If it wasn\'t, there is a fair way to fix it.',
            'loan': loan, 'agent_work': work, **MODE}


def render(result):
    loan, work = result['loan'], result['agent_work']
    lines = [result['model'], 'TEST MODE: synthetic keys, synthetic clock, test money only; nothing leaves this process.', '',
             'Demand: $500,000.00 term loan, 36 to 60 months, posted to one venue, sealed offers.',
             'Sealed: %d lenders; compare before close: %s; reveal refusals: %s.' % (
                 loan['sealed'], loan['compare_before_close'], ', '.join(loan['reveal_refusals']) or 'none'),
             'Decline notice: %s.' % '; '.join(loan['decline_notice']['reasons']), '',
             'Ranked only by the signed award rule (APR 60, monthly payment 15, prepayment 15, guarantees 10):']
    for row in loan['ranking'][:8]:
        parts = ', '.join('%s %d ppm' % (part['metric'], part['points_ppm']) for part in row['explanation'])
        lines.append('  %2d. %s APR %s  score %d ppm  [%s]  venue fee $%d.%02d, adviser fee $%d.%02d' % (
            row['rank'], row['offeror'], row['apr'], row['score_ppm'], parts, *divmod(row['venue_fee'], 100),
            *divmod(row['adviser_fee'], 100)))
    lines.append('  ... %d ranked in total; excluded: %s' % (loan['comparison']['ranked'], '; '.join(
        '%s %s' % (row['offeror'], ','.join(row['reasons'])) for row in loan['comparison']['excluded']) or 'none'))
    award = loan['award']
    lines += ['', 'Award: %s; owner approval required: %s; without it: %s; assent: %s; rehearsal %s.' % (
        award['status'], award['approval_required'], award['without_owner_approval'], award['assent'], award['rehearsal']),
              'Disclosure (us-ny-cfdl, not legal advice): ' + '; '.join('%s %s' % (r['label'], r['value']) for r in award['disclosure'][:5]),
              'Retrade check: an APR rise at closing is %s; without re-acceptance: %s.' % (
                  loan['retrade_check']['change'], loan['retrade_check']['without_reacceptance']), '',
              'Checklist (%s):' % loan['checklist']['status']]
    lines += ['  %-12s %s' % (name, status) for name, status in loan['checklist']['items']]
    lines += ['Commitment deposit (TEST-USD): %s then %s; locked after close %d.' % (
        loan['checklist']['deposit']['funded'], loan['checklist']['deposit']['released'], loan['checklist']['deposit']['locked_after']),
              'Close: %s (both signatures: %s; retry %s).' % (loan['close']['outcome'], loan['close']['acknowledged'],
                                                               loan['close']['retry']), '', 'Close records (signed receipts; Wilson lower bound):']
    for row in loan['close_records']:
        if row['awarded'] or row['withdrawn'] or row['not_revealed_statements'] or row['refused_reveal_statements']:
            lines.append('  %s offered %d awarded %d closed-on-terms %d withdrawn %d not-revealed %d refused-reveal %d  '
                         'close LB %d bps  firm LB %d bps' % (
                row['offeror'], row['offered'], row['awarded'], row['closed_on_offered_terms'], row['withdrawn'],
                row['not_revealed_statements'], row['refused_reveal_statements'], row['close_on_terms_lb_bps'],
                row['firm_offer_lb_bps']))
    lines.append('  (%d other lenders: offered 1, awarded 0, firm LB %d bps each)' % (
        sum(1 for row in loan['close_records'] if row['offered'] and not (row['awarded'] or row['withdrawn'])),
        next((row['firm_offer_lb_bps'] for row in loan['close_records'] if row['offered'] and not row['awarded']), 0)))
    lines += ['', 'Agent work: %d provider offers; winner price $%d.%02d; checklist %s; close %s; a failed outcome check maps to %s.' % (
        work['offers'], *divmod(work['ranking'][0]['price'], 100), ', '.join('%s %s' % tuple(row) for row in work['checklist']),
        work['close'], work['failed_check_maps_to']),
              'Seconds: loan %.2f, agent work %.2f.' % (loan['seconds'], work['seconds'])]
    return '\n'.join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_chain.exchange_demo', description=__doc__.splitlines()[0])
    parser.add_argument('command', choices=['demo'], help='run the synthetic $500K loan and an agent-work task')
    parser.add_argument('--json', action='store_true', help='print machine-readable JSON')
    parser.add_argument('--lenders', type=int, default=20, choices=range(5, 33), metavar='5..32')
    args = parser.parse_args(argv)
    result = run(lenders=args.lenders)
    print(json.dumps(result, indent=2, sort_keys=True) if args.json else render(result))
    return 0


if __name__ == '__main__':
    sys.exit(main())
