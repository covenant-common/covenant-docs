"""Fresh-agent onboarding benchmark for the installed stdio MCP server.

It starts the server the way a new MCP client does and counts the bytes read
and written until the first useful result: initialization, every tools/list
page, covenant_onboard guide, covenant_find, the exact action schema from
covenant_explain, and a successful synthetic draft through the typed route
covenant_call. Tokens are estimated as bytes / 4. The draft uses the public
synthetic quickstart identities; nothing is signed, sent, paid or persisted.

    python -m covenant_chain.onboarding_benchmark --check
    python -m covenant_chain.onboarding_benchmark -- /venv/bin/agentic-agreements --keyless --stateless
    python -m covenant_chain.onboarding_benchmark --list-only -- /old/venv/bin/agentic-agreements --keyless --stateless

--list-only stops after first contact, so an older server without
covenant_explain or covenant_call can be measured the same way.
"""
import argparse
import json
import queue
import subprocess
import sys
import threading

from .crypto import need

BENCHMARK_FORMAT = 'covenant-onboarding-benchmark/0.1'
LEGACY = '2025-06-18'
MODERN = '2026-07-28'
QUERY = 'I want to buy one report and preserve the exact price'
GUIDE = 'covenant_onboard'
FIND = 'covenant_find'
EXPLAIN = 'covenant_explain'
ROUTER = 'covenant_call'
# Regressions fail tests/test_agent_onboarding_profiles.py. Raise a budget only
# with a measured reason in the same change.
BUDGETS = {'tools_listed': 9, 'list_bytes': 12000, 'first_contact_bytes': 14000,
           'first_useful_result_bytes': 66000}
LINE_LIMIT = 8 * 1024 * 1024
REPLY_TIMEOUT = 30
PAGE_LIMIT = 256


def default_command(profile='entry'):
    """This interpreter, no current-directory imports, keyless and stateless."""
    need(profile in ('entry', 'full'), 'AGENT_TOOL_PROFILE')
    return [sys.executable, '-P', '-m', 'covenant_chain.agent_server', '--keyless', '--stateless',
            '--profile', profile]


class _Client:
    """One stdio MCP client. Every read is bounded in bytes and time."""

    def __init__(self, command, env=None, cwd=None):
        need(type(command) is list and command and all(type(x) is str for x in command), 'ONBOARDING_BENCHMARK_COMMAND')
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=subprocess.DEVNULL, env=env, cwd=cwd)
        self.lines = queue.Queue()
        self.sent = self.received = 0
        self.ident = 0
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()

    def _read(self):
        stream = self.process.stdout
        while True:
            line = stream.readline(LINE_LIMIT + 1)
            self.lines.put(line)
            if not line or len(line) > LINE_LIMIT:
                return

    def send(self, message, *, reply=True):
        raw = (json.dumps(message, ensure_ascii=True, separators=(',', ':')) + '\n').encode('ascii')
        self.process.stdin.write(raw)
        self.process.stdin.flush()
        self.sent += len(raw)
        if not reply:
            return len(raw), 0, None
        try:
            line = self.lines.get(timeout=REPLY_TIMEOUT)
        except queue.Empty:
            raise ValueError('ONBOARDING_BENCHMARK_TIMEOUT') from None
        need(line and len(line) <= LINE_LIMIT and line.endswith(b'\n'), 'ONBOARDING_BENCHMARK_REPLY')
        self.received += len(line)
        value = json.loads(line)
        need(type(value) is dict and value.get('id') == message.get('id'), 'ONBOARDING_BENCHMARK_REPLY')
        return len(raw), len(line), value

    def request(self, method, params):
        self.ident += 1
        return self.send({'jsonrpc': '2.0', 'id': self.ident, 'method': method, 'params': params})

    def close(self):
        try:
            self.process.stdin.close()
        except OSError:
            pass
        try:
            self.process.wait(timeout=REPLY_TIMEOUT)
        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=REPLY_TIMEOUT)
        finally:
            self.reader.join(timeout=REPLY_TIMEOUT)
            self.process.stdout.close()


def _structured(reply, step):
    result = reply.get('result') if type(reply) is dict else None
    need(type(result) is dict and result.get('isError') is False
         and type(result.get('structuredContent')) is dict, 'ONBOARDING_BENCHMARK_' + step.upper())
    return result['structuredContent']


def run(command=None, *, protocol=LEGACY, env=None, cwd=None, list_only=False):
    """Measure one fresh session. Raises a stable code when a step fails."""
    need(protocol in (LEGACY, MODERN), 'ONBOARDING_BENCHMARK_PROTOCOL')
    command = default_command() if command is None else list(command)
    meta = {'io.modelcontextprotocol/protocolVersion': MODERN, 'io.modelcontextprotocol/clientCapabilities': {}}
    def params(value):
        return {**value, '_meta': meta} if protocol == MODERN else value
    client = _Client(command, env=env, cwd=cwd)
    steps = []
    def record(step, sent, received):
        steps.append({'step': step, 'request_bytes': sent, 'response_bytes': received})
    try:
        if protocol == LEGACY:
            sent, received, reply = client.request('initialize', {'protocolVersion': LEGACY, 'capabilities': {},
                'clientInfo': {'name': 'covenant-onboarding-benchmark', 'version': '0.1'}})
            need('result' in reply, 'ONBOARDING_BENCHMARK_INITIALIZE')
            record('initialize', sent, received)
            sent, _, _ = client.send({'jsonrpc': '2.0', 'method': 'notifications/initialized'}, reply=False)
            record('notifications/initialized', sent, 0)
        else:
            sent, received, reply = client.request('server/discover', params({}))
            need('result' in reply, 'ONBOARDING_BENCHMARK_DISCOVER')
            record('server/discover', sent, received)
        tools, cursor, pages, list_bytes = [], None, 0, 0
        while True:
            need(pages < PAGE_LIMIT, 'ONBOARDING_BENCHMARK_PAGES')
            sent, received, reply = client.request('tools/list', params({} if cursor is None else {'cursor': cursor}))
            need(type(reply.get('result')) is dict and type(reply['result'].get('tools')) is list,
                 'ONBOARDING_BENCHMARK_LIST')
            pages += 1
            list_bytes += received
            record('tools/list', sent, received)
            tools.extend(reply['result']['tools'])
            cursor = reply['result'].get('nextCursor')
            if cursor is None:
                break
        names = [tool.get('name') for tool in tools]
        first_contact = client.sent + client.received
        if list_only:
            return {'format': BENCHMARK_FORMAT, 'command': command, 'protocol': protocol, 'tools': names,
                    'list_pages': pages, 'tools_listed': len(names), 'list_bytes': list_bytes,
                    'first_contact_bytes': first_contact,
                    'approx_tokens': {'list': -(-list_bytes // 4), 'first_contact': -(-first_contact // 4)},
                    'steps': steps, 'scope': 'FIRST_CONTACT_ONLY', 'token_estimate': 'BYTES_DIVIDED_BY_4',
                    'over_budget': sorted(key for key, value in (('tools_listed', len(names)), ('list_bytes', list_bytes),
                                                                 ('first_contact_bytes', first_contact))
                                          if value > BUDGETS[key]),
                    'execution_authorized': False}
        def call(step, name, arguments):
            sent, received, reply = client.request('tools/call', params({'name': name, 'arguments': arguments}))
            record(step, sent, received)
            return _structured(reply, step)
        guided = call('guide', GUIDE, {'action': 'guide', 'parameters': {'query': QUERY}})
        need((guided.get('task') or {}).get('id') == 'simple-trade', 'ONBOARDING_BENCHMARK_GUIDE')
        found = call('find', FIND, {'action': 'search', 'parameters': {'query': QUERY}})
        need(any(row.get('id') == 'simple-trade' for row in found.get('task_routes') or ()), 'ONBOARDING_BENCHMARK_FIND')
        family, action = guided['task']['native_tool'], guided['task']['action']
        explained = call('explain', EXPLAIN, {'action': 'action', 'parameters': {'id': 'tool:' + family + '.' + action}})
        need(explained.get('status') == 'DESCRIBED' and type(explained.get('action_schema')) is dict,
             'ONBOARDING_BENCHMARK_EXPLAIN')
        from .quickstart import request
        sample = request()
        need(sample['tool'] == family and sample['arguments']['action'] == action, 'ONBOARDING_BENCHMARK_SAMPLE')
        drafted = call('draft', ROUTER, {'tool': family, 'arguments': sample['arguments']})
        amount = ((drafted.get('cashflows') or {}).get('buyer_gives') or [{}])[0].get('amount')
        need(amount == sample['arguments']['parameters']['amount'] and drafted.get('automatic_assent') is False
             and drafted.get('execution_authorized') is False, 'ONBOARDING_BENCHMARK_DRAFT')
        useful = client.sent + client.received
    finally:
        client.close()
    measured = {'tools_listed': len(names), 'list_bytes': list_bytes, 'first_contact_bytes': first_contact,
                'first_useful_result_bytes': useful}
    return {'format': BENCHMARK_FORMAT, 'command': command, 'protocol': protocol,
        'tools': names, 'list_pages': pages, **measured,
        'approx_tokens': {'list': -(-list_bytes // 4), 'first_contact': -(-first_contact // 4),
                          'first_useful_result': -(-useful // 4)},
        'steps': steps, 'draft': {'id': drafted.get('id'), 'buyer_gives': amount},
        'budgets': dict(BUDGETS), 'over_budget': sorted(k for k, v in BUDGETS.items() if measured[k] > v),
        'token_estimate': 'BYTES_DIVIDED_BY_4', 'signed': False, 'payment_verified': False,
        'execution_authorized': False}


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_chain.onboarding_benchmark',
                                     description=__doc__.strip().splitlines()[0])
    parser.add_argument('--profile', choices=('entry', 'full'), default='entry',
                        help='Profile for the default command (this Python, keyless and stateless).')
    parser.add_argument('--protocol', choices=(LEGACY, MODERN), default=LEGACY)
    parser.add_argument('--check', action='store_true', help='Exit 1 when an entry-profile budget is exceeded.')
    parser.add_argument('--list-only', action='store_true', help='Stop after initialization and every tools/list page.')
    parser.add_argument('command', nargs='*', help='Server argv after --; default: this Python with -P.')
    args = parser.parse_args(argv)
    try:
        report = run(args.command or default_command(args.profile), protocol=args.protocol, list_only=args.list_only)
    except (ValueError, OSError) as exc:
        code = str(exc) if str(exc).isupper() else 'ONBOARDING_BENCHMARK_FAILED'
        print(json.dumps({'status': 'FAILED', 'code': code}))
        return 1
    print(json.dumps(report, indent=2, sort_keys=True))
    return 1 if args.check and report['over_budget'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
