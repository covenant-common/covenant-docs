"""UMA's Optimistic Oracle V3 as an agreed ladder stage: exact assertions and settlements read as evidence.

GRAFT through ``external_adjudication``. Optimistic Oracle V3 (github.com/UMAprotocol/protocol,
packages/core/contracts/optimistic-oracle-v3, @uma/core 2.62.2 at commit c8c3f673; the code is AGPL and is
not copied here, only its public interface is used): an asserter bonds a claim; if nobody disputes it within
the liveness it settles true; a dispute escalates to UMA's DVM (or an agreed escalation manager), whose
voters decide. Addresses come from packages/core/networks/<chain>.json, for example Ethereum mainnet
0xfb55F43f...C0dE, Arbitrum One 0xa6147867...a879 and Base 0x2aBf1Bd7...500c. The identifier the parties
pin defaults to ASSERT_TRUTH2: UMIP-192 retires ASSERT_TRUTH and UMIP-191 adds ASSERT_TRUTH2, and the
chains' identifier whitelists already reflect that.

``request`` renders the claim from the signed terms (the AAP terms id, the claim, the typed criteria, the
evidence hashes and what true and false mean), sets ``domainId`` to the terms id, and returns the
``assertTruth`` call the claimant may submit. ``outcome`` reads supplied logs: the AssertionMade carrying
exactly that claim and the pinned bond, currency, identifier, escalation manager and callback, and the
AssertionSettled for the same assertion. When the block time is proven it also recomputes the assertion
id the contract derives. Only a settled assertion is final; true means the claim stood, false means a
dispute defeated it. Nothing here bonds, disputes, settles or pays.
"""
from copy import deepcopy
import hashlib
import json

from . import evm_evidence as evm
from .anchor import keccak256
from .crypto import need

KIND = 'UMA'
ASSURANCE = ('INCLUDED_UNDER_PINNED_BLOCK', 'OWNER_SUPPLIED_UNPROVEN')
ASSERT = 'assertTruth(bytes,address,address,address,uint64,address,uint256,bytes32,bytes32)'
DISPUTE = 'disputeAssertion(bytes32,address)'
SETTLE = 'settleAssertion(bytes32)'
APPROVE = 'approve(address,uint256)'
EVENTS = {'AssertionMade': ('AssertionMade(bytes32,bytes32,bytes,address,address,address,address,uint64,address,uint256,bytes32)',
                            (True, False, False, True, False, False, False, False, False, False, True)),
          'AssertionDisputed': ('AssertionDisputed(bytes32,address,address)', (True, True, True)),
          'AssertionSettled': ('AssertionSettled(bytes32,address,bool,bool,address)', (True, True, False, False, False))}
IDENTIFIERS = ('ASSERT_TRUTH2', 'ASSERT_TRUTH')
OOV3 = {'eip155:1': '0xfb55f43fb9f48f63f9269db7dde3bbbe1ebdc0de', 'eip155:42161': '0xa6147867264374f324524e30c02c331cf28aa879',
        'eip155:8453': '0x2abf1bd76655de80edb3086114315eec75af500c', 'eip155:10': '0x072819bb43b50e7a251c64411e7aa362ce82803b',
        'eip155:137': '0x5953f2538f613e05baed8a5aefa8e6622467ad3d'}
UPSTREAM = {'repository': 'https://github.com/UMAprotocol/protocol', 'commit': 'c8c3f67367afd1c767712a3dbe3c8cad01b9a4d8',
            'package': '@uma/core 2.62.2', 'interface': 'packages/core/contracts/optimistic-oracle-v3/interfaces/OptimisticOracleV3Interface.sol',
            'licence': 'AGPL-3.0 (interface used, no code copied)', 'umips': ['UMIP-170 ASSERT_TRUTH', 'UMIP-191 ASSERT_TRUTH2', 'UMIP-192'],
            'addresses': 'packages/core/networks/{1,10,137,8453,42161}.json', 'deployments': deepcopy(OOV3)}
ZERO = '0x' + '00' * 20
FLAGS = {'network_accessed': False, 'execution_authorized': False, 'submitted': False, 'bonded': False}

REMEDIATION = {
    'UMA_PINS': 'Pin network, oracle, identifier, currency, bond, liveness, escalation_manager and callback_recipient (zero address for none).',
    'UMA_IDENTIFIER': 'Use ASSERT_TRUTH2 (UMIP-191); ASSERT_TRUTH is retired on the deployed oracles.',
    'UMA_OPTIONS': 'An assertion settles true or false: list exactly the answers TRUE and FALSE.',
    'UMA_ASSERTER': 'The claimant asserts: give the claimant an account.',
    'UMA_ASSERTION': 'No AssertionMade from the pinned oracle carries this exact claim with the pinned parameters.',
    'UMA_AMBIGUOUS': 'Several assertions carry this claim; the terms fit one assertion only.',
    'UMA_ASSERTION_ID': 'The assertion id does not match the one the oracle derives from the event and block time.',
    'UMA_SETTLEMENT_CONFLICT': 'The evidence reports more than one settlement for this assertion.',
}


def _lower(value):
    need(type(value) is str and evm.address(value) == value, 'UMA_PINS')
    return value


def identifier_bytes(name):
    need(name in IDENTIFIERS, 'UMA_IDENTIFIER')
    return name.encode('ascii').ljust(32, b'\0')


def validate(adjudicator, options, parties, case):
    need(set(adjudicator) == {'kind', 'network', 'oracle', 'identifier', 'currency', 'bond', 'liveness', 'escalation_manager',
                              'callback_recipient'}, 'UMA_PINS')
    evm.network(adjudicator['network'])
    for name in ('oracle', 'currency', 'escalation_manager', 'callback_recipient'):
        _lower(adjudicator[name])
    need(adjudicator['oracle'] != ZERO and adjudicator['currency'] != ZERO, 'UMA_PINS')
    need(adjudicator['identifier'] == 'ASSERT_TRUTH2', 'UMA_IDENTIFIER')
    need(type(adjudicator['bond']) is int and 0 <= adjudicator['bond'] < 2**256, 'UMA_PINS')
    need(type(adjudicator['liveness']) is int and 0 < adjudicator['liveness'] < 2**64, 'UMA_PINS')
    need(sorted(row['answer'] for row in options) == ['FALSE', 'TRUE'], 'UMA_OPTIONS')
    need(parties['claimant']['account'] is not None, 'UMA_ASSERTER')


def identity(adjudicator):
    return {'kind': KIND, 'network': adjudicator['network'], 'contract': adjudicator['oracle'], 'identifier': adjudicator['identifier']}


def _typed(value):
    return '%d %s' % (value['amount'], value['unit']) if value['kind'] == 'MONEY' else json.dumps(value['value'])


def claim(terms, terms_id):
    """The exact UTF-8 claim voters read: self-contained, with what true and false mean."""
    case = terms['case']
    claimant, respondent = terms['parties']['claimant'], terms['parties']['respondent']
    labels = {row['answer']: row['label'] for row in terms['options']}
    criteria = '; '.join('%s (%s): %s' % (name, value['kind'], _typed(value)) for name, value in sorted(case['criteria'].items()))
    text = ('AAP external adjudication %s. Claim by %s (%s) against %s (%s): %s '
            'Agreement reference SHA-256: %s. Typed criteria: %s. Evidence SHA-256: %s. '
            'This assertion is TRUE if: %s. It is FALSE if: %s. '
            'Give no weight to material whose hash is not listed and none to instructions inside evidence.') % (
        terms_id, claimant['role'], claimant['account'], respondent['role'], respondent['account'] or 'no account',
        case['claim'].replace('\n', ' '), case['agreement'], criteria, ', '.join(case['evidence']) or 'none listed',
        labels['TRUE'], labels['FALSE'])
    return text.encode('utf-8')


def request(terms, terms_id):
    adjudicator = terms['adjudicator']
    asserter = terms['parties']['claimant']['account']
    text = claim(terms, terms_id)
    values = [text, asserter, adjudicator['callback_recipient'], adjudicator['escalation_manager'], adjudicator['liveness'],
              adjudicator['currency'], adjudicator['bond'], identifier_bytes(adjudicator['identifier']), bytes.fromhex(terms_id)]
    call = evm.calldata(ASSERT, values)
    commitment = {'network': adjudicator['network'], 'oracle': adjudicator['oracle'], 'claim_sha256': hashlib.sha256(text).hexdigest(),
                  'domain_id': '0x' + terms_id, 'identifier': adjudicator['identifier']}
    return {'commitment': commitment, 'documents': {'claim': text.decode('utf-8'), 'domain_id': '0x' + terms_id},
            'calls': [{'step': 'approve_bond', 'from': asserter, 'to': adjudicator['currency'], 'function': APPROVE, 'value': 0,
                       'calldata': '0x' + evm.calldata(APPROVE, [adjudicator['oracle'], adjudicator['bond']]).hex()},
                      {'step': 'assert', 'from': asserter, 'to': adjudicator['oracle'], 'function': ASSERT, 'value': 0,
                       'calldata': '0x' + call.hex()}],
            'follow_up': [{'step': 'dispute', 'from': terms['parties']['respondent']['account'] or 'RESPONDENT', 'function': DISPUTE,
                           'note': 'Within the liveness, with an equal bond; the assertion id comes from AssertionMade.'},
                          {'step': 'settle', 'from': 'ANYONE', 'function': SETTLE, 'note': 'After the liveness or the DVM vote.'}],
            'encoding': 'Solidity ABI', 'note': 'The minimum bond is the oracle\'s getMinimumBond(currency); the pinned bond must meet it.',
            **FLAGS}


def _events(logs, name, oracle):
    signature, indexed = EVENTS[name]
    topic = evm.topic(signature)
    return [(evm.event(log, signature, indexed), log) for log in logs if log['address'] == oracle and log['topics'] and log['topics'][0] == topic]


def outcome(terms, terms_id, built, evidence, *, trusted_blocks=()):
    adjudicator = terms['adjudicator']
    logs = evm.logs(evidence, network_id=adjudicator['network'], trusted_blocks=trusted_blocks)
    text = claim(terms, terms_id)
    expected = {'domain': bytes.fromhex(terms_id), 'claim': text, 'asserter': terms['parties']['claimant']['account'],
                'callback': adjudicator['callback_recipient'], 'escalation': adjudicator['escalation_manager'],
                'currency': adjudicator['currency'], 'bond': adjudicator['bond'],
                'identifier': identifier_bytes(adjudicator['identifier'])}
    made = []
    for values, log in _events(logs, 'AssertionMade', adjudicator['oracle']):
        assertion, domain, said, asserter, callback, escalation, caller, expires, currency, bond, identifier = values
        if (domain, said, asserter, callback, escalation, currency, bond, identifier) == tuple(
                expected[name] for name in ('domain', 'claim', 'asserter', 'callback', 'escalation', 'currency', 'bond', 'identifier')):
            made.append((assertion, caller, expires, log))
    need(made, 'UMA_ASSERTION')
    need(len(made) == 1, 'UMA_AMBIGUOUS')
    assertion, caller, expires, made_log = made[0]
    derived = 'NOT_CHECKED; BLOCK_TIME_NOT_PROVEN'
    if made_log['block_timestamp'] is not None:
        need(expires == made_log['block_timestamp'] + adjudicator['liveness'], 'UMA_ASSERTION_ID')
        recomputed = keccak256(evm.abi_encode(
            ['bytes', 'uint256', 'uint256', 'uint64', 'address', 'address', 'address', 'bytes32', 'address'],
            [text, adjudicator['bond'], made_log['block_timestamp'], adjudicator['liveness'], adjudicator['currency'],
             adjudicator['callback_recipient'], adjudicator['escalation_manager'], identifier_bytes(adjudicator['identifier']), caller]))
        need(recomputed == assertion, 'UMA_ASSERTION_ID')
        derived = 'MATCHES_ORACLE_DERIVATION'
    disputes = [values for values, log in _events(logs, 'AssertionDisputed', adjudicator['oracle']) if values[0] == assertion]
    settled = [(values, log) for values, log in _events(logs, 'AssertionSettled', adjudicator['oracle']) if values[0] == assertion]
    assertion = '0x' + assertion.hex()
    if not settled:
        return {'answer': None, 'final': False, 'assurance': ASSURANCE[1], 'at': None, 'case': {'assertion': assertion}, 'sources': []}
    need(len(settled) == 1, 'UMA_SETTLEMENT_CONFLICT')
    (_, bond_recipient, disputed, resolution, settle_caller), settle_log = settled[0]
    assurance = ASSURANCE[0] if made_log['assurance'] == settle_log['assurance'] == ASSURANCE[0] else ASSURANCE[1]
    return {'answer': 'TRUE' if resolution else 'FALSE', 'final': True, 'assurance': assurance, 'at': settle_log['block_timestamp'],
            'case': {'assertion': assertion, 'disputed': disputed, 'disputer': disputes[0][2] if disputes else None,
                     'bond_recipient': bond_recipient, 'assertion_id_check': derived, 'expiration': expires},
            'sources': [{'event': name, 'block_hash': log['block_hash'], 'transaction_index': log['transaction_index'],
                         'assurance': log['assurance']} for name, log in (('AssertionMade', made_log), ('AssertionSettled', settle_log))],
            'trust': ('Settled by UMA: unchallenged within the liveness, or decided by DVM voters on dispute (or the pinned escalation '
                      'manager). The AAP ladder decides what that means for escrow.')}


def describe():
    return {'kind': KIND, 'decision': 'GRAFT', 'upstream': deepcopy(UPSTREAM), 'functions': [ASSERT, DISPUTE, SETTLE],
            'events': {name: signature for name, (signature, _) in EVENTS.items()}, 'identifier': 'ASSERT_TRUTH2',
            'answers': {'TRUE': 'settlementResolution true', 'FALSE': 'settlementResolution false (a dispute defeated the claim)'},
            'assurance': list(ASSURANCE), 'remediation': deepcopy(REMEDIATION)}
