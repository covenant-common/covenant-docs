"""Isolated round-2 consensus rules. They are off unless a process opts in.

PR #21 does not publish a numeric activation height. Historical blocks keep
the previous rules while this set is empty. Turning a rule on for only part
of a committee forks the chain. Schedule it with that upgrade, not before.
"""
import contextvars
from contextlib import contextmanager

# None until a committee adopts PR #21 and picks one height. Do not invent one.
PR21_ACTIVATION_HEIGHT = None

_RULES = contextvars.ContextVar('covenant_round2_rules', default=frozenset())


def rule_enabled(name, height=None):
    if name not in _RULES.get():
        return False
    gate = PR21_ACTIVATION_HEIGHT
    if gate is not None and height is not None and height < gate:
        return False
    return True


@contextmanager
def isolated_rules(*names):
    token = _RULES.set(frozenset(names))
    try:
        yield
    finally:
        _RULES.reset(token)
