"""MCP client configuration for the local keyless AAP server.

Nothing is written, installed, launched or published here. The default
launcher is the absolute Python of the environment where the hash-verified
wheel or the invited revision was installed. It runs with -P, so a client's
working directory (a project folder) cannot shadow the installed package.
uvx, pipx and npx lines name the pinned distribution that would be published
(npx runs the thin npm launcher of the same version, which finds or installs
that Python package); they are not an installation route until that
publication happens.
"""
import json
import os
import re
import shlex
import sys

from covenant_language._version import __version__
from .crypto import need

CONFIG_FORMAT = 'covenant-client-config/0.1'
DISTRIBUTION = 'agentic-agreements'
SERVER_NAME = 'covenant'
CLIENTS = ('claude-code', 'claude-desktop', 'cursor', 'vscode', 'codex', 'generic')
LAUNCHERS = ('python', 'uvx', 'pipx', 'npx')
PROTOCOL_VERSIONS = ('2026-07-28', '2025-06-18')
ENTRY_TOOL = 'covenant_onboard'
FIRST_CALL = {'name': ENTRY_TOOL, 'arguments': {'action': 'guide', 'parameters': {'task': 'simple-trade'}}}
_NAME = re.compile(r'[A-Za-z0-9_-]{1,64}\Z')
_INTERPRETER_LIMIT = 4096


def launch(launcher='python', *, interpreter=None, profile=None):
    """Exact argv an MCP client starts. No shell is involved."""
    need(launcher in LAUNCHERS, 'CLIENT_LAUNCHER')
    need(profile in (None, 'entry', 'full'), 'AGENT_TOOL_PROFILE')
    tail = ['--keyless', '--stateless'] + (['--profile', profile] if profile else [])
    if launcher == 'python':
        executable = sys.executable if interpreter is None else interpreter
        need(type(executable) is str and 0 < len(executable) <= _INTERPRETER_LIMIT
             and '\x00' not in executable and os.path.isabs(executable), 'CLIENT_INTERPRETER')
        return [executable, '-P', '-m', 'covenant_chain.agent_server', *tail]
    pinned = DISTRIBUTION + '==' + __version__
    if launcher == 'uvx':
        return ['uvx', '--from', pinned, DISTRIBUTION, *tail]
    if launcher == 'npx':
        return ['npx', '-y', DISTRIBUTION + '@' + __version__, *tail]
    return ['pipx', 'run', '--spec', pinned, DISTRIBUTION, *tail]


_TOML_ESCAPES = {'"': '\\"', '\\': '\\\\', '\b': '\\b', '\t': '\\t', '\n': '\\n', '\f': '\\f', '\r': '\\r'}


def _toml(value):
    """A TOML 1.0 basic string, or an array of them, in ASCII.

    Controls and DEL are escaped as TOML requires; other non-ASCII scalar
    values use \\u or \\U escapes. A lone surrogate is not a scalar value.
    """
    if type(value) is list:
        return '[' + ', '.join(_toml(item) for item in value) + ']'
    need(type(value) is str, 'CLIENT_CONFIG_VALUE')
    out = ['"']
    for char in value:
        code = ord(char)
        need(not 0xD800 <= code <= 0xDFFF, 'CLIENT_CONFIG_VALUE')
        if char in _TOML_ESCAPES:
            out.append(_TOML_ESCAPES[char])
        elif 0x20 <= code < 0x7f:
            out.append(char)
        elif code <= 0xFFFF:
            out.append('\\u%04X' % code)
        else:
            out.append('\\U%08X' % code)
    return ''.join(out) + '"'


def _json(value):
    return json.dumps(value, indent=2, ensure_ascii=True) + '\n'


def _entries(client, name, argv):
    command, args = argv[0], argv[1:]
    servers = {'mcpServers': {name: {'command': command, 'args': args}}}
    if client == 'claude-code':
        return [
            {'kind': 'command', 'scope': 'user', 'format': 'shell',
             'text': shlex.join(['claude', 'mcp', 'add', '--transport', 'stdio', '--scope', 'user', name, '--', *argv])},
            {'kind': 'file', 'scope': 'project', 'path': '.mcp.json', 'format': 'json',
             'content': {'mcpServers': {name: {'command': command, 'args': args}}},
             'note': 'A project file is shared with everyone who opens the project; each user approves it, and the interpreter path must exist on their machine.'}]
    if client == 'claude-desktop':
        return [{'kind': 'file', 'scope': 'user', 'format': 'json', 'content': servers,
                 'path': '~/Library/Application Support/Claude/claude_desktop_config.json',
                 'note': 'Merge into the existing mcpServers object, then restart Claude Desktop.'}]
    if client == 'cursor':
        typed = {'mcpServers': {name: {'type': 'stdio', 'command': command, 'args': args}}}
        return [{'kind': 'file', 'scope': 'user', 'format': 'json', 'path': '~/.cursor/mcp.json', 'content': typed,
                 'note': 'Use .cursor/mcp.json in a project for project scope. Merge into the existing mcpServers object.'}]
    if client == 'vscode':
        entry = {'type': 'stdio', 'command': command, 'args': args}
        return [
            {'kind': 'command', 'scope': 'user', 'format': 'shell',
             'text': shlex.join(['code', '--add-mcp', json.dumps({'name': name, **entry}, ensure_ascii=True, separators=(',', ':'))])},
            {'kind': 'file', 'scope': 'workspace', 'path': '.vscode/mcp.json', 'format': 'json',
             'content': {'servers': {name: entry}},
             'note': 'VS Code uses a servers object, not mcpServers. Merge into the existing file.'}]
    if client == 'codex':
        return [
            {'kind': 'command', 'scope': 'user', 'format': 'shell',
             'text': shlex.join(['codex', 'mcp', 'add', name, '--', *argv])},
            {'kind': 'file', 'scope': 'user', 'path': '~/.codex/config.toml', 'format': 'toml',
             'text': '[mcp_servers.' + name + ']\ncommand = ' + _toml(command) + '\nargs = ' + _toml(args) + '\n',
             'note': 'Edit the file if your Codex CLI has no mcp add command. The table name must be unique.'}]
    return [{'kind': 'file', 'scope': 'client', 'path': None, 'format': 'json', 'content': servers,
             'note': 'Common mcpServers shape. Any MCP client that starts a stdio process can use argv directly.'}]


def snippet(client, *, launcher='python', interpreter=None, profile=None, name=SERVER_NAME):
    """Paste-ready configuration for one named client. Writes and starts nothing."""
    need(client in CLIENTS, 'CLIENT_UNKNOWN')
    need(type(name) is str and _NAME.fullmatch(name) is not None, 'CLIENT_SERVER_NAME')
    argv = launch(launcher, interpreter=interpreter, profile=profile)
    entries = _entries(client, name, argv)
    for entry in entries:
        if 'content' in entry:
            entry['text'] = _json(entry['content'])
    check = launch(launcher, interpreter=interpreter) + ['--list-tools', '--profile', profile or 'entry']
    installed = launcher == 'python'
    return {'format': CONFIG_FORMAT, 'client': client, 'launcher': launcher, 'server_name': name,
        'transport': 'stdio', 'protocol_versions': list(PROTOCOL_VERSIONS), 'profile': profile or 'entry',
        'argv': argv, 'snippets': entries, 'check_command': shlex.join(check),
        'install_status': 'INSTALLED_ENVIRONMENT' if installed else 'UNPUBLISHED_NOT_AN_INSTALL_PATH',
        'install': ('Install the hash-verified wheel or invited revision into a virtual environment, then run '
                    'connect with that environment\'s python so the absolute path is correct.' if installed else
                    'No public package is claimed. Use launcher python with the verified wheel until the owner publishes '
                    + DISTRIBUTION + ' ' + __version__ + '.'),
        'first_call': json.loads(json.dumps(FIRST_CALL)),
        'owner_action': 'Review the command, then add it to the client yourself and enable it.',
        'files_written': False, 'connected': False, 'authority_granted': False, 'published': False}
