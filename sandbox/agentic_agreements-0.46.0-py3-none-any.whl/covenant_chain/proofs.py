"""Verify finalized native history without trusting the node's state RPC."""
from covenant_chain.crypto import genesis_id
from .crypto import exact,digest,verify,need,integer,canonical
from .app import genesis_state,apply_transaction,state_hash,begin_block

def verify_history(genesis,entries,expected_chain,minimum_height=0):
    integer(minimum_height)
    state=genesis_state(genesis);need(state['chain']==expected_chain,'GENESIS_PIN')
    parent='0'*64;members=genesis['validators'];q=2*genesis['faults']+1;need(type(entries) is list,'HISTORY')
    certificate_members=members;certificate_faults=genesis['faults'];parent_block=None
    for height,entry in enumerate(entries,1):
        certificate_members=members;certificate_faults=(q-1)//2
        exact(entry,'block certificate');block=entry['block'];cert=entry['certificate']
        if genesis['protocol'] == 'covenant-native/0.16':
            # Reproduce the existing node's deterministic block-time validity.
            # Older signed profiles retain their historical replay behavior.
            from .governance import accept_block_time, feature_active
            timed_state=begin_block(state,height)
            need(accept_block_time(block,parent_block,feature_active(timed_state,'proof_freshness')),'BLOCK_TIME')
        need(set(block) in ({'chain','height','parent','txs','state_root'},{'chain','height','parent','txs','state_root','time'}),'FIELDS');exact(cert,'height round block_id votes')
        integer(cert['height'],True);integer(cert['round']);need(block['chain']==expected_chain and type(block['height']) is int and block['height']==height and block['parent']==parent and cert['height']==height,'BLOCK_CONTEXT')
        bid=digest('COVENANT_CHAIN_BLOCK',block);need(cert['block_id']==bid,'BLOCK_ID')
        need(type(cert['votes']) is list and q<=len(cert['votes'])<=len(members),'QUORUM');seen=set()
        for msg in cert['votes']:
            exact(msg,'kind body signer signature');signer=msg['signer'];need(signer in members and signer not in seen,'SIGNER');seen.add(signer)
            body={'chain':expected_chain,'height':height,'round':cert['round'],'block_id':bid}
            need(msg['kind']=='precommit' and msg['body']==body,'VOTE_CONTEXT');verify(members[signer],'COVENANT_CHAIN_PRECOMMIT',body,msg['signature'])
        need(type(block['txs']) is list and len(block['txs'])<=32,'BLOCK_SIZE')
        from .app import FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,FEDERATION_MAX_BLOCK_TX_BYTES,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION
        if genesis['protocol'] in {FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:need(sum(len(canonical(tx)) for tx in block['txs'])<=(768*1024 if genesis['protocol']in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else FEDERATION_MAX_BLOCK_TX_BYTES),'FEDERATION_BLOCK_SIZE')
        state=begin_block(state,height)
        for tx in block['txs']:state=apply_transaction(state,tx,height)
        need(state_hash(state)==block['state_root'],'STATE_ROOT');parent=bid;parent_block=block
        if 'domain' in state:
            active=state['domain']['active'];members=active['validators'];q=2*active['faults']+1
    need(len(entries)>=minimum_height,'STALE_HISTORY')
    return {'chain':expected_chain,'height':len(entries),'head':parent,'state_root':state_hash(state),'state':state,'certificate_members':certificate_members,'certificate_faults':certificate_faults}

def assess_commitment(agreement,verified_history):
    """Describe mechanically established state at one verified head, not world safety."""
    state=verified_history['state'];need(agreement in state['agreements'],'AGREEMENT_MISSING')
    a=state['agreements'][agreement]
    return {'agreement':agreement,'chain':verified_history['chain'],'at_height':verified_history['height'],
            'formation':'VERIFIED','exact_terms':a['terms'],'reservation':'HELD' if a['held'] else 'DISCHARGED',
            'procedural_state':a['state'],'world_claims':'ATTESTATIONS_ONLY','freshness':'REQUIRES_RECIPIENT_POLICY',
            'effect':state['effects'].get(a.get('effect_id'))}

def verify_scoped_record(genesis,bundle,expected_chain,minimum_height,verified_history=None):
    """Verify a record under a pinned committee certificate, without full replay.

Recipient supplies the chain and freshness floor independently. This establishes
committee-certified state under that committee's fault assumptions, not an
independent replay of all transitions or the latest head's existence. Native 0.3
requires the recipient's independently verified history report at this exact head
to establish the active committee; pass only a report from verify_history.
"""
    from .app import NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION
    from .state import verify_record
    exact(bundle,'proof checkpoint');genesis_state(genesis)
    need(genesis['protocol'] in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} and genesis_id(genesis)==expected_chain,'GENESIS_PIN')
    exact(bundle['checkpoint'],'block certificate');block=bundle['checkpoint']['block'];cert=bundle['checkpoint']['certificate']
    need(set(block) in ({'chain','height','parent','txs','state_root'},{'chain','height','parent','txs','state_root','time'}),'FIELDS');exact(cert,'height round block_id votes')
    integer(minimum_height);integer(block['height'],True);integer(cert['height'],True);integer(cert['round'])
    need(block['chain']==expected_chain and block['height']==cert['height'] and block['height']>=minimum_height,'CHECKPOINT_CONTEXT')
    bid=digest('COVENANT_CHAIN_BLOCK',block);need(cert['block_id']==bid,'BLOCK_ID')
    votes=cert['votes'];members=genesis['validators'];faults=genesis['faults']
    if genesis['protocol'] in {LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        need(verified_history is not None and verified_history['chain']==expected_chain and verified_history['height']==block['height'] and verified_history['head']==bid and verified_history['state_root']==block['state_root'],'EPOCH_LINEAGE_REQUIRED')
        members=verified_history['certificate_members'];faults=verified_history['certificate_faults']
    need(type(votes) is list and 2*faults+1<=len(votes)<=len(members),'QUORUM');seen=set()
    for msg in votes:
        exact(msg,'kind body signer signature');who=msg['signer'];need(who in members and who not in seen,'SIGNER');seen.add(who)
        body={'chain':expected_chain,'height':block['height'],'round':cert['round'],'block_id':bid}
        need(msg['kind']=='precommit' and msg['body']==body,'VOTE_CONTEXT');verify(members[who],'COVENANT_CHAIN_PRECOMMIT',body,msg['signature'])
    need(bundle['proof']['descriptor']['chain']==expected_chain,'PROOF_CHAIN')
    value=verify_record(bundle['proof'],block['state_root'])
    return {'value':value,'height':block['height'],'state_root':block['state_root'],
            'assurance':'COMMITTEE_CERTIFIED','history_replayed':genesis['protocol'] in {LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION},'freshness':'RECIPIENT_HEIGHT_FLOOR_ONLY'}


def assess_service(job_id,verified_history):
    """Use only the result of verify_history; describes one head, not world truth."""
    from copy import deepcopy
    state=verified_history['state'];need(job_id in state.get('service_jobs',{}),'SERVICE_JOB')
    j=state['service_jobs'][job_id]
    return {'job':job_id,'chain':verified_history['chain'],'at_height':verified_history['height'],
            'formation':'EXACT_PARTY_AND_JUDGE_ASSENT_VERIFIED','procedural_state':j['state'],
            'terms':j['terms'],'practice':j['practice'],'payment_resource':j['settlement_resource'],
            'payment_reserved':state['balances'].get(j['payment_escrow'],{}).get(j['settlement_resource'],0),
            'capacity_resource':j['capacity_resource'],
            'capacity_reserved':state['balances'].get(j['capacity_escrow'],{}).get(j['capacity_resource'],0),
            'decision':deepcopy(j['decision']),'uncertainty_policy':j['uncertainty'],
            'world_claims':'ATTESTATIONS_ONLY','physical_capacity':'NOT_ESTABLISHED',
            'practice_correctness':'NOT_ESTABLISHED','freshness':'REQUIRES_RECIPIENT_POLICY'}
