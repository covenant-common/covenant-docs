"""Guarded-signature check. Crypto calls this without importing continuity."""

from .crypto import canonical, exact, need, verify
from .defense import HASH, backend, fingerprints, _hex

SIGNATURE = 'covenant-controller-and-hash/0.1'
LABEL = 'COVENANT-CONTINUITY-HASH-0.1'


def _message(descriptor, label, body):
    return {
        'chain': descriptor['chain'], 'entity': descriptor['entity'], 'policy': descriptor['policy'],
        'generation': descriptor['generation'], 'controller_epoch': descriptor['controller_epoch'],
        'policy_fingerprints': descriptor['policy_fingerprints'], 'label': label,
        'body_fingerprints': fingerprints(canonical(body)),
    }


def verify_hash(policy, label, body, proofs):
    need(type(proofs) is list and policy['threshold'] <= len(proofs) <= min(2, len(policy['guardians'])),
         'CONTINUITY_HASH_QUORUM')
    seen = set()
    message = label.encode('ascii') + b'\0' + canonical(body)
    for proof in proofs:
        exact(proof, 'member signature')
        member = proof['member']
        need(member in policy['guardians'] and member not in seen, 'CONTINUITY_SIGNER')
        seen.add(member)
        signature = _hex(proof['signature'], backend(HASH).SIGNATURE_SIZE)
        public = _hex(policy['guardians'][member]['key'], backend(HASH).PUBLIC_KEY_SIZE)
        need(backend(HASH).verify(public, message, signature), 'CONTINUITY_HASH_SIGNATURE')


def verify_guarded(descriptor, label, body, signature):
    need(not descriptor['paused'], 'CONTINUITY_RECOVERY_PENDING')
    exact(signature, 'version policy generation controller_epoch operational guardians')
    need(signature['version'] == SIGNATURE and signature['policy'] == descriptor['policy'] and
         signature['generation'] == descriptor['generation'] and signature['controller_epoch'] == descriptor['controller_epoch'],
         'CONTINUITY_SIGNATURE_CONTEXT')
    verify(descriptor['controller'], label, body, signature['operational'])
    verify_hash(descriptor, LABEL, _message(descriptor, label, body), signature['guardians'])
    return True
