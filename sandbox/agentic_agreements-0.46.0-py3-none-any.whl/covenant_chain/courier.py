"""Transport-independent bounded envelopes for removable media/local links.

An envelope hash detects accidental damage, not publisher authority. Signatures,
adopted state and consensus are checked by the recipient. Packet possession is
never finality. Do not carry private terms in these public courier packets.
EVIDENCE packets (PR 73, WP-24) carry only {kind, id} pairs for offline
evidence records; they are never submitted. They use covenant-courier/0.2
and its own hash label. Historical 0.1 packet kinds keep their exact bytes.
"""
from copy import deepcopy
from .crypto import canonical, digest, exact, integer, key, need, loads

VERSION = 'covenant-courier/0.1'
EVIDENCE_VERSION = 'covenant-courier/0.2'
KINDS = {'TRANSACTIONS', 'CONSENSUS', 'CERTIFIED_HISTORY', 'EVIDENCE'}
# Kept equal to parity_ids.EVIDENCE_KINDS; courier is on the node import path, parity_ids is not.
EVIDENCE_KINDS = frozenset(('ATR', 'BOND', 'VERDICT'))
MAX_PACKET_BYTES = 2*1024*1024
MAX_ITEMS = 64


def _evidence(item):
    """An EVIDENCE item is an id, never a record body or a transaction."""
    exact(item, 'kind id'); key(item['id'])
    need(type(item['kind']) is str and item['kind'] in EVIDENCE_KINDS, 'COURIER_EVIDENCE')


def pack(chain, kind, items):
    key(chain); need(type(kind) is str and kind in KINDS, 'COURIER_KIND')
    need(type(items) is list and 1 <= len(items) <= MAX_ITEMS, 'COURIER_ITEMS')
    need(all(type(x) is dict for x in items), 'COURIER_ITEM')
    if kind == 'EVIDENCE':
        for item in items: _evidence(item)
    version = EVIDENCE_VERSION if kind == 'EVIDENCE' else VERSION
    body = {'v': version, 'chain': chain, 'kind': kind, 'items': deepcopy(items)}
    packet = {'body':body, 'id':digest('COVENANT-COURIER-0.2' if kind == 'EVIDENCE' else 'COVENANT-COURIER-0.1',body)}
    need(len(canonical(packet)) <= MAX_PACKET_BYTES, 'COURIER_SIZE')
    return packet


def unpack(raw, expected_chain, expected_kind=None):
    key(expected_chain)
    need(isinstance(raw, (bytes,str)) and len(raw) <= MAX_PACKET_BYTES, 'COURIER_SIZE')
    p=loads(raw); exact(p, 'body id'); exact(p['body'],'v chain kind items')
    body=p['body']; version=EVIDENCE_VERSION if body['kind']=='EVIDENCE' else VERSION
    need(body['v']==version and body['chain']==expected_chain,'COURIER_CONTEXT')
    rebuilt=pack(expected_chain,body['kind'],body['items'])
    need(p['id']==rebuilt['id'],'COURIER_INTEGRITY')
    need(expected_kind is None or body['kind']==expected_kind,'COURIER_KIND')
    return deepcopy(body['items'])


def receive(node, packet):
    """Trusted local operator path. Uses existing application/signature checks.

    Partial per-item success is explicit. It neither starts networking nor
    clears locks. Caller forwards returned signed messages through any medium.
    Transport privacy, replay admission and physical-media custody are separate.
    """
    items=unpack(canonical(packet),node.chain_id)
    kind=packet['body']['kind']; results=[]; outgoing=[]
    if kind=='EVIDENCE':
        # Ids only: never node.submit, never a commit. Verify full records offline.
        results=[{'accepted':False,'reason':'EVIDENCE_NOT_SUBMITTED','kind':item['kind'],'id':item['id']} for item in items]
        return {'packet':packet['id'],'results':results,'outgoing':[],'finality':'OFFLINE_RECORD_NOT_A_COMMIT'}
    with node.lock:
        for item in items:
            try:
                if kind=='TRANSACTIONS': result=node.submit(item)
                elif kind=='CONSENSUS':
                    outgoing.extend(node.engine.receive(item));node.refresh();result={'accepted_for_processing':True}
                else:
                    exact(item,'block certificate')
                    outgoing.extend(node.engine.receive({'kind':'commit',**item}));node.refresh();result={'accepted_for_processing':True}
                results.append({'accepted':True,'result':result})
            except (ValueError,KeyError,TypeError) as exc:
                results.append({'accepted':False,'reason':str(exc)[:160]})
    return {'packet':packet['id'],'results':results,'outgoing':outgoing,'finality':'VERIFY_CERTIFICATES_SEPARATELY'}
