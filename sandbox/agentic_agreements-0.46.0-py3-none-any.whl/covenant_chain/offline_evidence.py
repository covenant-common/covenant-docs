"""Offline evidence records carried on the existing offline bytes (experimental).

Ported from PR 73 (WP-24). Records ride an offline.seal DATA envelope and the
existing frame splitters: offline_carriers.frames for NFC and files,
offline_ble.frames for BLE. Reassembly is offline_carriers.Reassembler and
offline_ble.payload_of, unchanged; there is no second frame format. A courier
EVIDENCE packet carries only {kind, id} pairs and courier.receive never submits it.

- ATR: the exact agreement-terms bytes and their SHA-256 (trust_verify.atr_hash).
- BOND: a signed bond-coverage claim with 0 <= locked <= bond.
- VERDICT: a signed test verdict over test, image, input and output digests.

A signed record shows that its signer said something, not that the world agrees.
verify_record accepts a BOND or VERDICT record only from a pinned Ed25519 signer.
"""
from copy import deepcopy

from . import courier, offline, offline_ble, offline_carriers, parity_ids as ids
from .crypto import canonical, digest, exact, key, need, public_key, sign, verify
from .trust_verify import HEX, atr_document, verify_atr

MAX_RECORDS = 16
MAX_AMOUNT = 2**53 - 1
OUTCOMES = ('SUPPORTED', 'REFUTED', 'UNKNOWN')
DOMAINS = {'BOND': ids.BOND_PROOF_DOMAIN, 'VERDICT': ids.VERDICT_DOMAIN}


def atr_record(raw):
    """Exact terms bytes for offline carriage: ASCII text when possible, else canonical base64."""
    return {'version': ids.EVIDENCE_VERSION, 'kind': 'ATR', **atr_document(raw)}


def _bond(body):
    exact(body, 'position locked bond')
    key(body['position'])
    locked, bond = body['locked'], body['bond']
    need(type(locked) is int and type(bond) is int and 0 <= locked <= bond <= MAX_AMOUNT, 'EVIDENCE_BOND')


def _verdict(body):
    exact(body, 'test image input output outcome')
    for name in ('test', 'image', 'input', 'output'):
        key(body[name])
    need(body['outcome'] in OUTCOMES, 'EVIDENCE_OUTCOME')


def _signed(private, kind, body):
    return {'version': ids.EVIDENCE_VERSION, 'kind': kind, 'body': body, 'signer': public_key(private),
            'signature': sign(private, DOMAINS[kind], body)}


def bond_proof(private, *, position, locked, bond):
    body = {'position': position, 'locked': locked, 'bond': bond}
    _bond(body)
    return _signed(private, 'BOND', body)


def verdict_record(private, *, test_digest, image_digest, input_hash, output_hash, outcome):
    """A signed test verdict. PR 73 called this test_verdict; renamed so no test runner collects it."""
    body = {'test': test_digest, 'image': image_digest, 'input': input_hash, 'output': output_hash,
            'outcome': outcome}
    _verdict(body)
    return _signed(private, 'VERDICT', body)


def _check(record):
    """Shape, ATR hash and signature integrity against the record's own signer. Not a trust decision."""
    need(type(record) is dict and record.get('version') == ids.EVIDENCE_VERSION, 'EVIDENCE_VERSION')
    kind = record.get('kind')
    if kind == 'ATR':
        need(set(record) in ({'version', 'kind', 'atr_hash', 'bytes_ascii'},
                             {'version', 'kind', 'atr_hash', 'bytes_base64'}), 'FIELDS')
        checked = verify_atr({name: value for name, value in record.items() if name not in ('version', 'kind')})
        need(checked['ok'], 'EVIDENCE_ATR')
        return kind, checked['atr_hash'], None
    need(type(kind) is str and kind in DOMAINS, 'EVIDENCE_KIND')
    exact(record, 'version kind body signer signature')
    (_bond if kind == 'BOND' else _verdict)(record['body'])
    need(type(record['signer']) is str and HEX.fullmatch(record['signer']), 'EVIDENCE_SIGNER')
    verify(record['signer'], DOMAINS[kind], record['body'], record['signature'])
    return kind, digest(DOMAINS[kind], record['body']), record['signer']


def _pins(signers):
    need(type(signers) in (list, tuple) and len(signers) <= 32
         and all(type(s) is str and HEX.fullmatch(s) for s in signers), 'EVIDENCE_SIGNER')
    return tuple(signers)


def verify_record(record, *, signers=()):
    """Verify one record. BOND and VERDICT records need their signer in ``signers``."""
    pins = _pins(signers)
    kind, ref, signer = _check(record)
    need(signer is None or signer in pins, 'EVIDENCE_SIGNER')
    return {'ok': True, 'code': ids.CODE_VERIFIED, 'kind': kind, 'id': ref, 'signer': signer,
            'execution_authorized': False}


def seal_records(records, *, signing_key, recipient, shared_key, scope, created, expires, nfc_mtu=200, ble_mtu=23):
    """Seal 1 to 16 checked records in one DATA envelope and split it for NFC and BLE."""
    need(type(records) is list and 1 <= len(records) <= MAX_RECORDS, 'EVIDENCE_SET')
    for record in records:
        _check(record)
    packet = offline.seal('DATA', {'version': ids.EVIDENCE_VERSION, 'records': deepcopy(records)},
                          signing_key=signing_key, recipient=recipient, shared_key=shared_key, scope=scope,
                          created=created, expires=expires)
    raw = canonical(packet)
    return {'packet': packet, 'bytes': raw, 'nfc_frames': offline_carriers.frames(raw, mtu=nfc_mtu),
            'ble_frames': offline_ble.frames(raw, mtu=ble_mtu), 'execution_authorized': False}


def open_carried(raw, *, recipient_key, shared_key, scope, allowed_senders, now, signers=()):
    """Open reassembled envelope bytes from a pinned sender, then verify every carried record."""
    packet = offline.exact_load(raw)
    payload = offline.open_packet(packet, recipient=recipient_key, shared_key=shared_key, scope=scope,
                                  allowed_senders=allowed_senders, now=now)
    need(payload['kind'] == 'DATA', 'EVIDENCE_KIND')
    value = payload['value']
    need(type(value) is dict and set(value) == {'version', 'records'} and value['version'] == ids.EVIDENCE_VERSION,
         'EVIDENCE_VERSION')
    records = value['records']
    need(type(records) is list and 1 <= len(records) <= MAX_RECORDS, 'EVIDENCE_SET')
    return [verify_record(record, signers=signers) for record in records]


def courier_ids(chain, verified):
    """A courier EVIDENCE packet of ids from verify_record results. Nothing is submitted."""
    need(type(verified) is list and verified
         and all(type(row) is dict and row.get('ok') is True for row in verified), 'EVIDENCE_SET')
    return courier.pack(chain, 'EVIDENCE', [{'kind': row['kind'], 'id': row['id']} for row in verified])
