"""Award, conditions-precedent checklist and close receipts for urn:aap:exchange:0.1.

The award prepares the exact agreement both sides sign through the typed
application profile urn:aap:agreement-application:0.1: both roles sign meaning
echoes, a bounded rehearsal runs, then each signs the exact assent payload. The
award itself never signs, funds, pays or releases anything. An award above the
owner's adopted limit (covenant-assent-policy/0.1 thresholds) needs a fresh
owner approval bound to the exact award, rendering, amount and payee; each
approval works once, which the book records.

A condition closes only on evidence signed by its named supplier and a decision
signed by its named beneficiary. A missed deadline is a failed condition, the
first decision binds, and unknown is never satisfied. Agent-work deliveries are
checked through an adapter for the structured-outcome record shape
(covenant-structured-outcome/0.1); the adapter validates that record as data and
imports no unmerged code.
"""
from copy import deepcopy
import hashlib
import json

from covenant_language import agreement_application as app

from . import exchange_dossier as dossier
from . import exchange_profile as profile
from .crypto import digest, sign, verify
from .exchange_profile import ExchangeError, need, teaching

AWARD_TITLE = 'Demand exchange award'
APPROVAL_VERSION = 'urn:aap:exchange-award-approval:0.1'
APPROVAL_LABEL = 'AAP-EXCHANGE-AWARD-APPROVAL-0.1'
CONDITION_NONCE_LABEL = 'AAP-EXCHANGE-CONDITION-NONCE-0.1'
DOCUMENT_LABEL = 'AAP-EXCHANGE-DOCUMENT-SIGNATURE-0.1'
CHECKLIST_LABEL = 'AAP-EXCHANGE-CHECKLIST-0.1'
DECISIONS = ('SATISFIED', 'FAILED', 'WAIVED')
SKIP_REASONS = ('WITHDRAWN', 'DECLINED', 'FAILED_CONDITION', 'EXPIRED', 'LAPSED')
OUTCOMES = ('CLOSED_ON_OFFERED_TERMS', 'CLOSED_IMPROVED', 'CLOSED_RETRADED', 'FAILED_CONDITION', 'LAPSED')
CLOSED = ('CLOSED_ON_OFFERED_TERMS', 'CLOSED_IMPROVED', 'CLOSED_RETRADED')
OUTCOME_RECORD = 'covenant-structured-outcome/0.1'
OUTCOME_RESULT_LABEL = 'COVENANT-STRUCTURED-OUTCOME-RESULT-0.1'
# finalize() status -> the checker statuses it can follow (structured-outcome record shape).
OUTCOME_STATUSES = {'EVIDENCE_PENDING': ('UNASSESSED',), 'CHECKS_FAILED': ('FAIL',), 'PARTIAL_CHECKS': ('PARTIAL',),
                    'MECHANICAL_PASS': ('PASS',), 'REVIEW_PENDING': ('PASS',), 'REVIEWED_ACCEPTED': ('PASS',),
                    'REVIEWED_PARTIAL': ('UNASSESSED', 'FAIL', 'PARTIAL', 'PASS'),
                    'REVIEWED_REJECTED': ('UNASSESSED', 'FAIL', 'PARTIAL', 'PASS'),
                    'REVIEW_INCONCLUSIVE': ('UNASSESSED', 'FAIL', 'PARTIAL', 'PASS')}
OUTCOME_MEANING = {'MECHANICAL_PASS': 'PASSED', 'REVIEWED_ACCEPTED': 'PASSED', 'CHECKS_FAILED': 'FAILED',
                   'REVIEWED_REJECTED': 'FAILED', 'PARTIAL_CHECKS': 'PARTIAL', 'REVIEWED_PARTIAL': 'PARTIAL',
                   'EVIDENCE_PENDING': 'UNKNOWN', 'REVIEW_PENDING': 'UNKNOWN', 'REVIEW_INCONCLUSIVE': 'UNKNOWN'}
FLAGS = dict(profile.FLAGS, funds_moved=False)
TEMPLATE = ('Demand exchange award under {{profile}}. Request {{request}} was answered by firm offer {{offer}}, '
            'ranked {{rank}} in comparison {{comparison}} under award rule {{rule}} for vertical {{vertical}}. '
            'Principal {{principal}}. Amount {{amount}}; firm terms {{offer_terms}}; the demand {{want}}. '
            'Awarded at {{awarded_at}}; the offer stays firm until {{valid_until}}; close by {{close_by}}. '
            'Conditions precedent {{conditions}} close only on supplier evidence and the beneficiary\'s signed decision. '
            'Commitment deposit {{deposit}}. Disputes {{dispute}}. Fees disclosed {{fees}}. '
            'This award is not funding, payment, delivery or legal advice; any change against the requester '
            'needs the requester\'s signed re-acceptance.')


def _canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def _machine():
    transitions = [{'from': 'AWARDED', 'event': event, 'to': target, 'guard': {}, 'release': []}
                   for event, target in (('CLOSE', 'CLOSED'), ('LAPSE', 'LAPSED'))]
    return {'states': ['AWARDED', 'CLOSED', 'LAPSED'], 'initial': 'AWARDED', 'terminals': ['CLOSED', 'LAPSED'],
            'events': {'CLOSE': ['offeror', 'requester'], 'LAPSE': ['offeror', 'requester']}, 'facts': [],
            'transitions': transitions}


def _norms():
    return [app.norm(role + '_' + event.lower(), 'POWER', role, event)
            for role in ('requester', 'offeror') for event in ('CLOSE', 'LAPSE')]


def _skipped(skipped):
    skipped = {} if skipped is None else skipped
    need(type(skipped) is dict and len(skipped) <= profile.MAX_SUBMISSIONS, 'EXCHANGE_NOT_RANKED')
    for ref, reason in skipped.items():
        profile._hash(ref)
        need(reason in SKIP_REASONS, 'EXCHANGE_NOT_RANKED')
    return skipped


@teaching
def prepare_award(request_envelope, offer_envelope, comparison, *, context, at, packs=(), skipped=None,
                  revocation_history=None):
    """Exact application for both parties to echo and sign. Higher-ranked offers must be accounted for."""
    checked = profile.verify_request(request_envelope, packs=packs, revocation_history=revocation_history)
    body, ref, pack = checked['body'], checked['id'], checked['vertical']
    offer_body, offer_ref = profile.verify_offer(offer_envelope, body, ref, packs)
    profile._hash(context)
    profile._int(at)
    core = profile.comparison_core(comparison)
    need(core['request'] == ref and core['rule'] == checked['rule'], 'EXCHANGE_COMPARISON')
    rows = {row[0]: row for row in core['ranked']}
    need(offer_ref in rows, 'EXCHANGE_NOT_RANKED')
    position = rows[offer_ref][1]
    skipped = _skipped(skipped)
    above = [row[0] for row in core['ranked'] if row[1] < position]
    need(all(item in skipped for item in above), 'EXCHANGE_NOT_RANKED')
    made = profile.normalise(pack, body['want'], offer_body['terms'])
    verdict = profile.evaluate(body['award_rule'], made['metrics'])
    need(verdict['passed'] and [verdict['score'].numerator, verdict['score'].denominator] == rows[offer_ref][2:],
         'EXCHANGE_COMPARISON')
    need(at < offer_body['valid_until'], 'EXCHANGE_OFFER_VALIDITY')
    need(at < body['close_by'], 'EXCHANGE_WINDOW')
    money = profile.amount_of(pack, offer_body['terms'])
    conditions = deepcopy(body['conditions']) + deepcopy(offer_body['conditions'])
    terms = {'profile': {'kind': 'TEXT', 'value': profile.PROFILE}, 'request': {'kind': 'HASH', 'value': ref},
             'offer': {'kind': 'HASH', 'value': offer_ref}, 'comparison': {'kind': 'HASH', 'value': comparison['id']},
             'rule': {'kind': 'HASH', 'value': checked['rule']}, 'rank': {'kind': 'INTEGER', 'value': position},
             'vertical': {'kind': 'TEXT', 'value': pack['id']}, 'principal': {'kind': 'TEXT', 'value': body['principal']},
             'amount': deepcopy(money), 'offer_terms': {'kind': 'TEXT', 'value': _canon(offer_body['terms'])},
             'want': {'kind': 'TEXT', 'value': _canon(body['want'])},
             'awarded_at': {'kind': 'INTEGER', 'value': at}, 'valid_until': {'kind': 'INTEGER', 'value': offer_body['valid_until']},
             'close_by': {'kind': 'INTEGER', 'value': body['close_by']},
             'conditions': {'kind': 'TEXT', 'value': _canon(conditions)},
             'deposit': {'kind': 'TEXT', 'value': _canon(offer_body['deposit'])},
             'dispute': {'kind': 'TEXT', 'value': _canon(body['dispute'])}, 'fees': {'kind': 'TEXT', 'value': _canon(body['fees'])}}
    acceptance = {'offer': {'kind': 'HASH', 'value': offer_ref}, 'amount': deepcopy(money),
                  'close_by': {'kind': 'INTEGER', 'value': body['close_by']}}
    parties = {'requester': body['agent'], 'offeror': offer_body['offeror']}
    made_app = app.draft(AWARD_TITLE, parties, context, _norms(), _machine(), {'amount': 0, 'unit': money['unit']},
                         acceptance, TEMPLATE, terms=terms)
    application = made_app['application']
    report = app.rehearse(application)
    need(report['status'] == 'SAFE_WITHIN_MODEL', 'EXCHANGE_AWARD')
    return {'application': application, 'id': made_app['id'], 'rehearsal': report, 'amount': money,
            'checklist': checklist(application),
            'echo_payloads': {role: app.echo_payload(application, role, acceptance) for role in ('requester', 'offeror')},
            'skipped': dict(skipped),
            'next': 'Both roles sign meaning echoes; prepare with agreement_application.prepare; both sign the exact '
                    'assent payload. An award above the owner limit needs the owner approval first.', **FLAGS}


def award_terms(application):
    """Read the typed award back out of an application; refuses anything that is not an exchange award."""
    try:
        app.identifier(application)
    except ValueError:
        raise ExchangeError('EXCHANGE_AWARD') from None
    terms = application['terms']
    need(set(terms) == {'profile', 'request', 'offer', 'comparison', 'rule', 'rank', 'vertical', 'principal', 'amount',
                        'offer_terms', 'want', 'awarded_at', 'valid_until', 'close_by', 'conditions', 'deposit',
                        'dispute', 'fees'} and terms['profile'] == {'kind': 'TEXT', 'value': profile.PROFILE}
         and set(application['parties']) == {'requester', 'offeror'}, 'EXCHANGE_AWARD')
    value = {name: (row['value'] if row['kind'] != 'MONEY' else {'amount': row['amount'], 'unit': row['unit']})
             for name, row in terms.items()}
    for name in ('offer_terms', 'want', 'conditions', 'deposit', 'dispute', 'fees'):
        try:
            value[name] = json.loads(value[name])
        except (TypeError, ValueError):
            raise ExchangeError('EXCHANGE_AWARD') from None
    value['parties'] = deepcopy(application['parties'])
    value['application'] = app.identifier(application)
    return value


# --- owner approval above the adopted limit -----------------------------------------

def _policy(policy_record):
    from covenant_agent import assent_gate
    try:
        policy = assent_gate.verify_policy(policy_record)
        return policy, assent_gate.policy_id(policy)
    except ValueError:
        raise ExchangeError('EXCHANGE_APPROVAL_POLICY') from None


@teaching
def approval_required(policy_record, signer, amount):
    """Owner threshold check (covenant-assent-policy/0.1): above the unit's limit, or an unlisted unit, needs approval."""
    if policy_record is None:
        return False
    policy, _ = _policy(policy_record)
    need(policy['signer'] == signer, 'EXCHANGE_APPROVAL_POLICY')
    if 'agent' not in policy['roles']:
        return False
    limit = next((row['amount'] for row in policy['thresholds'] if row['unit'] == amount['unit']), None)
    return limit is None or amount['amount'] > limit


@teaching
def approval_request(policy_record, award, *, occurrence, at):
    """The exact request an owner approves; bound to the award, its rendering, amount, payee and one occurrence."""
    policy, ref = _policy(policy_record)
    need(policy['method']['kind'] == 'OWNER_KEY', 'EXCHANGE_APPROVAL_METHOD_UNSUPPORTED')
    terms = award_terms(award['application'])
    profile._hash(occurrence)
    profile._int(at)
    need(policy['not_before'] <= at <= policy['expires'], 'EXCHANGE_APPROVAL_POLICY')
    need(policy['signer'] == terms['parties']['requester'], 'EXCHANGE_APPROVAL_POLICY')
    return {'version': APPROVAL_VERSION, 'policy': ref, 'signer': policy['signer'], 'award': terms['application'],
            'rendering': hashlib.sha256(award['application']['rendered'].encode('utf-8')).hexdigest(),
            'amount': {'kind': 'MONEY', **terms['amount']}, 'payee': terms['parties']['offeror'],
            'occurrence': occurrence, 'issued_at': at, 'expires_at': at + policy['max_age']}


def sign_approval(owner_private, approval):
    """Owner-side tool; the owner key never reaches the agent host or any MCP tool."""
    body = {'decision': 'APPROVE', 'request': deepcopy(approval)}
    from .crypto import public_key
    return {'version': APPROVAL_VERSION, 'decision': 'APPROVE', 'request': deepcopy(approval), 'method': 'OWNER_KEY',
            'proof': {'key': public_key(owner_private), 'signature': sign(owner_private, APPROVAL_LABEL, body)}}


@teaching
def verify_approval(policy_record, approval, award, *, at):
    policy, ref = _policy(policy_record)
    need(policy['method']['kind'] == 'OWNER_KEY', 'EXCHANGE_APPROVAL_METHOD_UNSUPPORTED')
    profile._exact(approval, 'version decision request method proof', 'EXCHANGE_APPROVAL_INVALID')
    need(approval['version'] == APPROVAL_VERSION and approval['decision'] == 'APPROVE' and approval['method'] == 'OWNER_KEY',
         'EXCHANGE_APPROVAL_INVALID')
    request = approval['request']
    terms = award_terms(award['application'])
    expected = {'version': APPROVAL_VERSION, 'policy': ref, 'signer': policy['signer'], 'award': terms['application'],
                'rendering': hashlib.sha256(award['application']['rendered'].encode('utf-8')).hexdigest(),
                'amount': {'kind': 'MONEY', **terms['amount']}, 'payee': terms['parties']['offeror']}
    profile._exact(request, 'version policy signer award rendering amount payee occurrence issued_at expires_at',
                   'EXCHANGE_APPROVAL_INVALID')
    need(all(request[name] == value for name, value in expected.items()), 'EXCHANGE_APPROVAL_INVALID')
    profile._hash(request['occurrence'], 'EXCHANGE_APPROVAL_INVALID')
    profile._exact(approval['proof'], 'key signature', 'EXCHANGE_APPROVAL_INVALID')
    need(approval['proof']['key'] == policy['method']['key'], 'EXCHANGE_APPROVAL_INVALID')
    try:
        verify(approval['proof']['key'], APPROVAL_LABEL, {'decision': 'APPROVE', 'request': request},
               approval['proof']['signature'])
    except ValueError:
        raise ExchangeError('EXCHANGE_APPROVAL_INVALID') from None
    profile._int(at)
    need(request['issued_at'] <= at <= request['expires_at'], 'EXCHANGE_APPROVAL_EXPIRED')
    return {'occurrence': request['occurrence'], 'policy': ref, 'approved': True, **FLAGS}


# --- the award record the requester signs ------------------------------------------

@teaching
def award_record(award, prepared_agreement, *, approval=None):
    """Requester-signed AWARD record: binds request, offer, comparison, application and assent target."""
    terms = award_terms(award['application'])
    profile._hash(prepared_agreement)
    body = {'version': profile.PROFILE, 'kind': 'AWARD', 'request': terms['request'], 'offer': terms['offer'],
            'comparison': terms['comparison'], 'application': terms['application'], 'agreement': prepared_agreement,
            'rank': terms['rank'], 'amount': {'kind': 'MONEY', **terms['amount']}, 'requester': terms['parties']['requester'],
            'offeror': terms['parties']['offeror'], 'approval': approval, 'awarded_at': terms['awarded_at']}
    _award_body(body)
    return {'label': profile.LABELS['AWARD'], 'body': body, 'id': profile.record_id('AWARD', body),
            'required_signer': body['requester'], **FLAGS}


def _award_body(body):
    profile._exact(body, 'version kind request offer comparison application agreement rank amount requester offeror '
                         'approval awarded_at', 'EXCHANGE_AWARD')
    for name in ('request', 'offer', 'comparison', 'application', 'agreement'):
        profile._hash(body[name])
    profile._key(body['requester'])
    profile._key(body['offeror'])
    profile._int(body['rank'], 'EXCHANGE_AWARD', 1)
    profile._int(body['awarded_at'])
    need(body['approval'] is None or profile._hash(body['approval'], 'EXCHANGE_AWARD'), 'EXCHANGE_AWARD')


@teaching
def verify_award_record(envelope, award=None):
    body, ref = profile._signed('AWARD', envelope, 'requester')
    _award_body(body)
    if award is not None:
        terms = award_terms(award['application'])
        need(body['application'] == terms['application'] and body['offer'] == terms['offer']
             and body['request'] == terms['request'] and body['offeror'] == terms['parties']['offeror'], 'EXCHANGE_AWARD')
    return body, ref


# --- conditions-precedent checklist ---------------------------------------------------

@teaching
def checklist(application):
    """Every condition with its supplier, beneficiary, evidence slot and absolute deadline."""
    terms = award_terms(application)
    keys = {'REQUESTER': terms['parties']['requester'], 'OFFEROR': terms['parties']['offeror']}
    items = []
    for row in terms['conditions']:
        profile.validate_condition(row)
        items.append({'id': row['id'], 'kind': row['kind'], 'evidence': row['evidence'], 'supplier': row['supplier'],
                      'beneficiary': row['beneficiary'], 'supplier_key': keys[row['supplier']],
                      'beneficiary_key': keys[row['beneficiary']], 'issuers': deepcopy(row['issuers']),
                      'due': min(terms['awarded_at'] + row['due_after_award'], terms['close_by'])})
    return items


def condition_nonce(agreement, condition):
    return digest(CONDITION_NONCE_LABEL, {'agreement': agreement, 'condition': condition})


def condition_audience(agreement):
    return 'urn:aap:exchange-condition:' + agreement


@teaching
def evidence(agreement, condition, kind, payload, supplier, created_at):
    body = {'version': profile.PROFILE, 'kind': 'EVIDENCE', 'agreement': agreement, 'condition': condition,
            'evidence': kind, 'payload': deepcopy(payload), 'supplier': supplier, 'created_at': created_at}
    _evidence_body(body)
    return {'label': profile.LABELS['EVIDENCE'], 'body': body, 'id': profile.record_id('EVIDENCE', body),
            'required_signer': supplier, **FLAGS}


def _evidence_body(body):
    profile._exact(body, 'version kind agreement condition evidence payload supplier created_at', 'EXCHANGE_EVIDENCE')
    profile._hash(body['agreement'])
    need(type(body['condition']) is str and profile.NAME.fullmatch(body['condition']) is not None, 'EXCHANGE_EVIDENCE')
    need(body['evidence'] in profile.EVIDENCE and type(body['payload']) is dict, 'EXCHANGE_EVIDENCE')
    profile._key(body['supplier'])
    profile._int(body['created_at'])


@teaching
def decision(agreement, condition, evidence_ref, outcome, beneficiary, created_at, reason=None):
    body = {'version': profile.PROFILE, 'kind': 'DECISION', 'agreement': agreement, 'condition': condition,
            'evidence': evidence_ref, 'decision': outcome, 'reason': reason, 'beneficiary': beneficiary,
            'created_at': created_at}
    _decision_body(body)
    return {'label': profile.LABELS['DECISION'], 'body': body, 'id': profile.record_id('DECISION', body),
            'required_signer': beneficiary, **FLAGS}


def _decision_body(body):
    profile._exact(body, 'version kind agreement condition evidence decision reason beneficiary created_at', 'EXCHANGE_EVIDENCE')
    profile._hash(body['agreement'])
    need(type(body['condition']) is str and profile.NAME.fullmatch(body['condition']) is not None, 'EXCHANGE_EVIDENCE')
    need(body['decision'] in DECISIONS, 'EXCHANGE_EVIDENCE')
    need((body['evidence'] is None) == (body['decision'] == 'WAIVED'), 'EXCHANGE_EVIDENCE')
    if body['evidence'] is not None:
        profile._hash(body['evidence'])
    need(body['reason'] is None or (type(body['reason']) is str and profile.CODE.fullmatch(body['reason']) is not None),
         'EXCHANGE_EVIDENCE')
    need(body['decision'] != 'FAILED' or body['reason'] is not None, 'EXCHANGE_EVIDENCE')
    profile._key(body['beneficiary'])
    profile._int(body['created_at'])


def outcome_check(payload, spec_id, required):
    """Adapter for the structured-outcome record shape; validates it as data and maps it to PASSED or not."""
    profile._exact(payload, 'spec_id artifact_sha256 outcome', 'EXCHANGE_OUTCOME_RECORD')
    profile._hash(payload['spec_id'], 'EXCHANGE_OUTCOME_RECORD')
    profile._hash(payload['artifact_sha256'], 'EXCHANGE_OUTCOME_RECORD')
    need(payload['spec_id'] == spec_id, 'EXCHANGE_OUTCOME_RECORD')
    outcome = payload['outcome']
    profile._exact(outcome, 'status result review_verified external_truth_verified agreement_assent_verified '
                            'execution_authorized settlement_authorized', 'EXCHANGE_OUTCOME_RECORD')
    need(outcome['status'] in OUTCOME_STATUSES and type(outcome['review_verified']) is bool
         and outcome['external_truth_verified'] is False and outcome['agreement_assent_verified'] is False
         and outcome['execution_authorized'] is False and outcome['settlement_authorized'] is False, 'EXCHANGE_OUTCOME_RECORD')
    result = outcome['result']
    profile._exact(result, 'version checker spec artifact_sha256 status valid_rows total_rows errors omitted_errors '
                           'source_truth_verified agreement_assent_verified execution_authorized payment_verified id',
                   'EXCHANGE_OUTCOME_RECORD')
    body = {name: value for name, value in result.items() if name != 'id'}
    need(result['version'] == OUTCOME_RECORD and result['spec'] == spec_id
         and result['artifact_sha256'] == payload['artifact_sha256']
         and result['status'] in OUTCOME_STATUSES[outcome['status']]
         and result['execution_authorized'] is False and result['payment_verified'] is False, 'EXCHANGE_OUTCOME_RECORD')
    try:
        need(digest(OUTCOME_RESULT_LABEL, body) == result['id'], 'EXCHANGE_OUTCOME_RECORD')
    except ValueError:
        raise ExchangeError('EXCHANGE_OUTCOME_RECORD') from None
    meaning = OUTCOME_MEANING[outcome['status']]
    if meaning == 'PASSED' and required == 'REVIEWED_ACCEPTED' and outcome['status'] != 'REVIEWED_ACCEPTED':
        meaning = 'UNKNOWN'
    return {'status': meaning, 'checker_status': result['status'], 'outcome_status': outcome['status'],
            'artifact_sha256': payload['artifact_sha256'], 'record': 'covenant-structured-outcome/0.1 shape, checked as data'}


def check_payload(item, kind, payload, terms, created_at):
    """Validate evidence against its condition; returns PASSED, FAILED, PARTIAL, VALID (a claim) or UNKNOWN."""
    need(kind == item['evidence'], 'EXCHANGE_EVIDENCE')
    agreement = terms['application']
    try:
        if kind == 'SD_JWT_PRINCIPAL_KYB':
            profile._exact(payload, 'presentation', 'EXCHANGE_EVIDENCE')
            from . import hidden_credentials
            policy = hidden_credentials.make_policy(issuers=item['issuers'], require=['principal_kyb'],
                                                    audience=condition_audience(agreement))
            checked = hidden_credentials.verify_presentation(payload['presentation'], policy,
                                                             nonce=condition_nonce(agreement, item['id']), now=created_at)
            return {'status': 'PASSED', 'issuer': checked['issuer'], 'claims': sorted(checked['claims'])}
        if kind == 'SD_JWT_DOSSIER_FIELDS':
            profile._exact(payload, 'presentation fields', 'EXCHANGE_EVIDENCE')
            need(type(payload['fields']) is list and 1 <= len(payload['fields']) <= dossier.MAX_FIELDS
                 and payload['fields'] == sorted(set(payload['fields'])) and all(type(name) is str and
                 dossier.NAME.fullmatch(name) for name in payload['fields']), 'EXCHANGE_EVIDENCE')
            names = payload['fields']
            checked = dossier.verify_attested(payload['presentation'], item['issuers'], audience=condition_audience(agreement),
                                              nonce=condition_nonce(agreement, item['id']), now=created_at)
            need(set(names) <= set(checked['claims']), 'EXCHANGE_EVIDENCE')
            return {'status': 'PASSED', 'issuer': checked['issuer'], 'claims': sorted(checked['claims'])}
    except ExchangeError:
        raise
    except ValueError:
        return {'status': 'FAILED', 'reason': 'ATTESTATION_DID_NOT_VERIFY'}
    if kind == 'FILING_RECORD':
        profile._exact(payload, 'document_sha256 filing_reference jurisdiction', 'EXCHANGE_EVIDENCE')
        profile._hash(payload['document_sha256'], 'EXCHANGE_EVIDENCE')
        profile._text(payload['filing_reference'], 'EXCHANGE_EVIDENCE', 128)
        profile._text(payload['jurisdiction'], 'EXCHANGE_EVIDENCE', 64)
    elif kind == 'SIGNED_DOCUMENT':
        profile._exact(payload, 'document_sha256 signer signature', 'EXCHANGE_EVIDENCE')
        profile._hash(payload['document_sha256'], 'EXCHANGE_EVIDENCE')
        profile._key(payload['signer'], 'EXCHANGE_EVIDENCE')
        try:
            verify(payload['signer'], DOCUMENT_LABEL, {'agreement': agreement, 'document_sha256': payload['document_sha256']},
                   payload['signature'])
        except ValueError:
            return {'status': 'FAILED', 'reason': 'DOCUMENT_SIGNATURE_DID_NOT_VERIFY'}
        return {'status': 'PASSED', 'signer': payload['signer']}
    elif kind == 'DOCUMENT':
        profile._exact(payload, 'document_sha256 description', 'EXCHANGE_EVIDENCE')
        profile._hash(payload['document_sha256'], 'EXCHANGE_EVIDENCE')
        profile._text(payload['description'], 'EXCHANGE_EVIDENCE', 256)
    elif kind == 'ATTESTATION':
        profile._exact(payload, 'statement as_of', 'EXCHANGE_EVIDENCE')
        need(type(payload['statement']) is str and profile.CODE.fullmatch(payload['statement']) is not None, 'EXCHANGE_EVIDENCE')
        profile._int(payload['as_of'], 'EXCHANGE_EVIDENCE')
    elif kind == 'OUTCOME_CHECK_RECORD':
        spec = terms['offer_terms'].get('outcome_spec')
        need(type(spec) is str, 'EXCHANGE_OUTCOME_RECORD')
        return outcome_check(payload, spec, terms['want'].get('acceptance'))
    elif kind == 'PAYMENT_OBSERVATION':
        profile._exact(payload, 'reference amount unit rail observed_at', 'EXCHANGE_EVIDENCE')
        profile._text(payload['reference'], 'EXCHANGE_EVIDENCE', 128)
        profile._int(payload['amount'], 'EXCHANGE_EVIDENCE')
        need(type(payload['unit']) is str and profile.UNIT.fullmatch(payload['unit']) is not None, 'EXCHANGE_EVIDENCE')
        profile._text(payload['rail'], 'EXCHANGE_EVIDENCE', 64)
        profile._int(payload['observed_at'], 'EXCHANGE_EVIDENCE')
    else:
        profile._exact(payload, 'adapter effect escrow amount state', 'EXCHANGE_EVIDENCE')
        for name in ('adapter', 'effect', 'escrow'):
            profile._hash(payload[name], 'EXCHANGE_EVIDENCE')
        profile._int(payload['amount'], 'EXCHANGE_EVIDENCE')
        need(payload['state'] in ('LOCKED', 'SETTLED'), 'EXCHANGE_EVIDENCE')
    return {'status': 'VALID', 'assurance': 'SUPPLIER_CLAIM_UNTIL_THE_BENEFICIARY_SIGNS'}


@teaching
def checklist_status(application, evidence_records=(), decisions=(), *, at):
    """Status of every condition from signed evidence and beneficiary decisions; the first decision binds."""
    terms = award_terms(application)
    items = checklist(application)
    by_id = {item['id']: item for item in items}
    profile._int(at)
    need(type(evidence_records) in (list, tuple) and len(evidence_records) <= 256
         and type(decisions) in (list, tuple) and len(decisions) <= 256, 'EXCHANGE_RECORDS')
    found = {}
    for envelope in evidence_records:
        body, ref = profile._signed('EVIDENCE', envelope, 'supplier')
        _evidence_body(body)
        need(body['agreement'] == terms['application'], 'EXCHANGE_EVIDENCE')
        need(body['condition'] in by_id, 'EXCHANGE_CONDITION_UNKNOWN')
        item = by_id[body['condition']]
        need(body['supplier'] == item['supplier_key'], 'EXCHANGE_NOT_SUPPLIER')
        found[ref] = (body, check_payload(item, body['evidence'], body['payload'], terms, body['created_at']))
    chosen = {}
    for envelope in decisions:
        body, ref = profile._signed('DECISION', envelope, 'beneficiary')
        _decision_body(body)
        need(body['agreement'] == terms['application'], 'EXCHANGE_EVIDENCE')
        need(body['condition'] in by_id, 'EXCHANGE_CONDITION_UNKNOWN')
        need(body['beneficiary'] == by_id[body['condition']]['beneficiary_key'], 'EXCHANGE_NOT_BENEFICIARY')
        if body['evidence'] is not None:
            need(body['evidence'] in found and found[body['evidence']][0]['condition'] == body['condition'], 'EXCHANGE_EVIDENCE')
        current = chosen.get(body['condition'])
        if current is None or (body['created_at'], ref) < (current[0]['created_at'], current[1]):
            chosen[body['condition']] = (body, ref)
    rows = []
    for item in items:
        submitted = sorted(ref for ref, (body, _) in found.items() if body['condition'] == item['id'])
        status, detail = 'OPEN', None
        picked = chosen.get(item['id'])
        if picked is not None:
            body, ref = picked
            if body['decision'] == 'WAIVED':
                status = 'WAIVED'
            elif body['decision'] == 'FAILED':
                status, detail = 'FAILED', body['reason']
            else:
                evidence_body, checked = found[body['evidence']]
                # A beneficiary cannot turn failed, partial, unknown or late evidence into satisfied.
                if checked['status'] in ('PASSED', 'VALID') and evidence_body['created_at'] <= item['due']:
                    status = 'SATISFIED'
                else:
                    status, detail = 'NOT_SATISFIABLE', checked['status'] if checked['status'] != 'PASSED' else 'LATE'
        elif at > item['due']:
            status = 'EXPIRED'
        elif submitted:
            status = 'AWAITING_DECISION'
        rows.append({**{k: item[k] for k in ('id', 'kind', 'evidence', 'supplier', 'beneficiary', 'due')},
                     'status': status, 'detail': detail, 'evidence_records': submitted})
    if any(row['status'] in ('FAILED', 'EXPIRED') for row in rows):
        overall = 'FAILED'
    elif all(row['status'] in ('SATISFIED', 'WAIVED') for row in rows):
        overall = 'READY_TO_CLOSE'
    else:
        overall = 'PENDING'
    summary = {'agreement': terms['application'], 'items': [[row['id'], row['status']] for row in rows]}
    return {'agreement': terms['application'], 'status': overall, 'items': rows, 'at': at,
            'digest': digest(CHECKLIST_LABEL, summary), 'unknown_is_never_satisfied': True, **FLAGS}


# --- close receipts ----------------------------------------------------------------

@teaching
def close_payload(award, *, outcome, final_application, checklist_digest, closed_at, retrade=None,
                  reacceptance=None, failed_condition=None, failed_party=None):
    terms = award_terms(award['application'])
    body = {'version': profile.PROFILE, 'kind': 'CLOSE', 'request': terms['request'], 'offer': terms['offer'],
            'award': terms['application'], 'final': final_application, 'outcome': outcome,
            'requester': terms['parties']['requester'], 'offeror': terms['parties']['offeror'],
            'checklist': checklist_digest, 'retrade': retrade, 'reacceptance': reacceptance,
            'failed_condition': failed_condition, 'failed_party': failed_party, 'closed_at': closed_at}
    _close_body(body)
    return {'label': profile.LABELS['CLOSE'], 'body': body, 'id': profile.record_id('CLOSE', body),
            'required_signers': required_signers(body), **FLAGS}


def _close_body(body):
    profile._exact(body, 'version kind request offer award final outcome requester offeror checklist retrade reacceptance '
                         'failed_condition failed_party closed_at', 'EXCHANGE_CLOSE')
    for name in ('request', 'offer', 'award', 'final', 'checklist'):
        profile._hash(body[name], 'EXCHANGE_CLOSE')
    profile._key(body['requester'])
    profile._key(body['offeror'])
    need(body['outcome'] in OUTCOMES, 'EXCHANGE_CLOSE')
    profile._int(body['closed_at'], 'EXCHANGE_CLOSE')
    retraded = body['outcome'] == 'CLOSED_RETRADED'
    need((body['retrade'] is not None) == (body['outcome'] in ('CLOSED_RETRADED', 'CLOSED_IMPROVED')), 'EXCHANGE_CLOSE')
    need((body['reacceptance'] is not None) == retraded, 'EXCHANGE_CLOSE')
    for name in ('retrade', 'reacceptance'):
        need(body[name] is None or profile._hash(body[name], 'EXCHANGE_CLOSE'), 'EXCHANGE_CLOSE')
    failed = body['outcome'] == 'FAILED_CONDITION'
    need((body['failed_condition'] is not None) == failed and (body['failed_party'] is not None) == failed, 'EXCHANGE_CLOSE')
    if failed:
        need(type(body['failed_condition']) is str and profile.NAME.fullmatch(body['failed_condition']) is not None
             and body['failed_party'] in profile.ROLES, 'EXCHANGE_CLOSE')
    need(body['outcome'] in CLOSED + ('LAPSED',) or body['final'] == body['award'], 'EXCHANGE_CLOSE')


def required_signers(body):
    """Closing needs both parties. A failed condition needs its beneficiary. A lapse needs at least one party."""
    if body['outcome'] in CLOSED:
        return ['requester', 'offeror']
    if body['outcome'] == 'FAILED_CONDITION':
        return ['offeror' if body['failed_party'] == 'REQUESTER' else 'requester']
    return []


@teaching
def verify_close(receipt, award):
    profile._exact(receipt, 'body signatures', 'EXCHANGE_CLOSE')
    body = receipt['body']
    need(type(body) is dict and body.get('version') == profile.PROFILE and body.get('kind') == 'CLOSE', 'EXCHANGE_CLOSE')
    _close_body(body)
    ref = profile.record_id('CLOSE', body)
    terms = award_terms(award['application'])
    need(body['award'] == terms['application'] and body['request'] == terms['request'] and body['offer'] == terms['offer']
         and body['requester'] == terms['parties']['requester'] and body['offeror'] == terms['parties']['offeror'],
         'EXCHANGE_CLOSE')
    signatures = receipt['signatures']
    need(type(signatures) is dict and set(signatures) <= {'requester', 'offeror'} and signatures, 'EXCHANGE_CLOSE_SIGNATURES')
    signed = set()
    for role, signature in signatures.items():
        try:
            verify(body[role], profile.LABELS['CLOSE'], body, signature)
        except ValueError:
            raise ExchangeError('EXCHANGE_SIGNATURE') from None
        signed.add(role)
    need(set(required_signers(body)) <= signed, 'EXCHANGE_CLOSE_SIGNATURES')
    return {'id': ref, 'body': body, 'signed_by': sorted(signed), 'acknowledged': signed == {'requester', 'offeror'},
            'claim': 'SIGNED_PARTY_STATEMENTS_NOT_WORLD_TRUTH', **FLAGS}


def describe():
    return {'version': profile.PROFILE, 'award': 'urn:aap:agreement-application:0.1 with meaning echoes and exact assent',
            'approval': {'version': APPROVAL_VERSION, 'policy': 'covenant-assent-policy/0.1', 'methods': ['OWNER_KEY'],
                         'not_implemented': ['PASSKEY approvals for exchange awards']},
            'decisions': list(DECISIONS), 'outcomes': list(OUTCOMES), 'evidence': list(profile.EVIDENCE),
            'outcome_record': OUTCOME_RECORD + ' shape, adapter only', **FLAGS}
