"""The demand exchange as exchange_* actions of covenant_request (read-only, request family).

A deal is a promise both sides sign. Proof shows it was kept. If it wasn't,
there is a fair way to fix it. Every action is a pure computation over records
the caller supplies: it prepares or checks a demand post or a firm offer,
ranks offers by the requester's signed rule, prepares an award for both sides
to sign, and reports the close checklist and close records. It never signs,
stores, publishes, contacts an offeror, lends, pays or installs anything; the
owner's ExchangeBook (an SDK object) is the only writer.
"""
from . import exchange_book as book
from . import exchange_close as close
from . import exchange_credit as credit
from . import exchange_profile as profile
from .cooperation_interface import HASH

TOOL = 'covenant_request'
PREFIX = 'exchange_'
OBJECT = {'type': 'object', 'maxProperties': 32}
ENVELOPE = {'type': 'object', 'maxProperties': 4}
TIME = {'type': 'integer', 'minimum': 0, 'maximum': 2**53 - 1}
PACKS = {'type': 'array', 'maxItems': 8, 'items': OBJECT}
ROWS = {'type': 'array', 'maxItems': 256, 'items': OBJECT}
RECORDS = {'type': 'array', 'maxItems': 1024, 'items': OBJECT}
CODE = {'type': 'string', 'minLength': 2, 'maxLength': 64, 'pattern': '^[A-Z][A-Z0-9_]*$'}
JOBS = {'request': 'Find and be found', 'offer': 'Make a deal', 'compare': 'Make a deal', 'award': 'Make a deal',
        'disclose': 'Make a deal', 'checklist': 'Keep records', 'record': 'Keep records', 'explain': 'Keep records'}
DESCRIPTION = (' Demand exchange actions (exchange_*): post one demand, check firm signed offers bound to its digest, '
               'rank them only by the rule signed before offers opened, prepare the award both sides sign, and read '
               'the close checklist and close records. Pure computation; never signs, stores, lends or pays.')


def actions():
    """The exchange actions inside covenant_request; every name starts with exchange_."""
    return [
        ('exchange_describe', {}, ()),
        ('exchange_request', {'body': OBJECT, 'envelope': ENVELOPE, 'packs': PACKS}, ()),
        ('exchange_offer', {'request': ENVELOPE, 'body': OBJECT, 'envelope': ENVELOPE, 'salt': HASH, 'packs': PACKS}, ('request',)),
        ('exchange_compare', {'request': ENVELOPE, 'submissions': ROWS, 'at': TIME, 'expected_request': HASH,
                              'withdrawals': ROWS, 'detail': {'enum': ['SUMMARY', 'FULL']}, 'packs': PACKS},
         ('request', 'submissions', 'at')),
        ('exchange_award', {'request': ENVELOPE, 'offer': ENVELOPE, 'comparison': {'type': 'object', 'maxProperties': 2},
                            'context': HASH, 'at': TIME,
                            'skipped': {'type': 'object', 'maxProperties': 256,
                                        'additionalProperties': {'enum': list(close.SKIP_REASONS)}},
                            'packs': PACKS}, ('request', 'offer', 'comparison', 'context', 'at')),
        ('exchange_disclose', {'pack': {'enum': sorted(credit.disclosure_packs()['packs'])}, 'terms': OBJECT,
                               'financer': {'type': 'string', 'minLength': 1, 'maxLength': 128}},
         ('pack', 'terms', 'financer')),
        ('exchange_checklist', {'award': {'type': 'object', 'maxProperties': 16}, 'evidence': ROWS, 'decisions': ROWS,
                                'at': TIME}, ('award', 'at')),
        ('exchange_record', {'offers': RECORDS, 'withdrawals': RECORDS, 'awards': RECORDS, 'closes': RECORDS,
                             'statements': RECORDS, 'packs': PACKS}, ()),
        ('exchange_explain', {'code': CODE}, ('code',)),
    ]


def refusals_html():
    """The refusal table of docs/DEMAND_EXCHANGE.html, generated from the code so the two cannot drift."""
    from html import escape
    rows = ['<table><tr><th>Code</th><th>What happened</th><th>What to do next</th><th>Retry</th></tr>']
    for code in sorted(profile.REFUSALS):
        what, fix, retry = profile.REFUSALS[code]
        rows.append('<tr id="%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (
            code.lower(), code, escape(what), escape(fix), escape(profile.RETRY[retry])))
    rows.append('</table>')
    return '\n'.join(rows)


def describe():
    return {'tool': TOOL, **profile.describe(), 'actions': {PREFIX + action: JOBS[action] for action in JOBS},
            'credit': credit.describe(), 'close': close.describe(), 'book': book.describe(),
            'guide': 'docs/DEMAND_EXCHANGE.html', 'maturity': 'experimental',
            'owner_sdk': ['exchange_book.ExchangeBook (post, seal, submit, reveal, withdraw, decline, compare, award, '
                          'evidence, decide, close_deal, close_records, health, metrics, backup)',
                          'exchange_dossier.Dossier (fill once, release per stage with consent)']}


def _call(action, p):
    if action == 'describe':
        return describe()
    if action == 'explain':
        return {**profile.explain(p['code']), **profile.FLAGS}
    if action == 'request':
        need_one = ('body' in p) != ('envelope' in p)
        profile.need(need_one, 'EXCHANGE_FIELDS')
        packs = p.get('packs', [])
        if 'envelope' in p:
            checked = profile.verify_request(p['envelope'], packs=packs)
            return {'status': 'VERIFIED', 'request': checked['id'], 'rule': checked['rule'],
                    'vertical': checked['vertical']['id'], 'authority': checked['authority'], **profile.FLAGS}
        profile.validate_request(p['body'], packs)
        return {'status': 'READY_TO_SIGN', 'label': profile.LABELS['REQUEST'], 'body': p['body'],
                'id': profile.record_id('REQUEST', p['body']), 'rule': profile.rule_id(p['body']['award_rule']),
                'required_signer': p['body']['agent'], **profile.FLAGS}
    if action == 'offer':
        packs = p.get('packs', [])
        checked = profile.verify_request(p['request'], packs=packs)
        profile.need(('body' in p) != ('envelope' in p), 'EXCHANGE_FIELDS')
        if 'envelope' in p:
            body, ref = profile.verify_offer(p['envelope'], checked['body'], checked['id'], packs)
            return {'status': 'VERIFIED', 'offer': ref, 'request': checked['id'], 'offeror': body['offeror'],
                    'normalised': profile.normalise(checked['vertical'], checked['body']['want'], body['terms']), **profile.FLAGS}
        profile.validate_offer(p['body'], checked['body'], checked['id'], packs)
        ref = profile.record_id('OFFER', p['body'])
        result = {'status': 'READY_TO_SIGN', 'label': profile.LABELS['OFFER'], 'body': p['body'], 'id': ref,
                  'required_signer': p['body']['offeror'],
                  'eligibility_binding': {'audience': profile.eligibility_audience(checked['id']),
                                          'nonce': profile.eligibility_nonce(checked['id'], p['body']['offeror'])},
                  'normalised': profile.normalise(checked['vertical'], checked['body']['want'], p['body']['terms']),
                  **profile.FLAGS}
        if 'salt' in p:
            sealed = profile.commitment(checked['id'], ref, p['salt'])
            result['seal'] = profile.seal(checked['id'], p['body']['offeror'], sealed, p['body']['created_at'])
            result['keep_secret_until_close'] = ['salt', 'signed offer']
        return result
    if action == 'compare':
        return profile.compare(p['request'], p['submissions'], at=p['at'], expected_request=p.get('expected_request'),
                               packs=p.get('packs', []), withdrawals=p.get('withdrawals', []),
                               detail=p.get('detail', 'SUMMARY'))
    if action == 'award':
        return close.prepare_award(p['request'], p['offer'], p['comparison'], context=p['context'], at=p['at'],
                                   packs=p.get('packs', []), skipped=p.get('skipped'))
    if action == 'disclose':
        return credit.disclosure(p['pack'], p['terms'], p['financer'])
    if action == 'checklist':
        return close.checklist_status(p['award'].get('application'), p.get('evidence', []), p.get('decisions', []), at=p['at'])
    if action == 'record':
        return book.close_record(offers=p.get('offers', []), withdrawals=p.get('withdrawals', []),
                                 awards=p.get('awards', []), closes=p.get('closes', []),
                                 statements=p.get('statements', []), packs=p.get('packs', []))
    raise profile.ExchangeError('EXCHANGE_ACTION')


def call(action, parameters):
    """exchange_<name> actions; every refusal leaves as a teaching ExchangeError (code, what, fix, retry, reference)."""
    try:
        profile.need(type(action) is str and action.startswith(PREFIX), 'EXCHANGE_ACTION')
        return _call(action[len(PREFIX):], parameters)
    except profile.ExchangeError:
        raise
    except (ValueError, TypeError, KeyError, AttributeError, IndexError) as exc:
        if isinstance(exc, ValueError):
            raise profile.refusal(exc) from None
        raise profile.ExchangeError('EXCHANGE_FIELDS') from None
