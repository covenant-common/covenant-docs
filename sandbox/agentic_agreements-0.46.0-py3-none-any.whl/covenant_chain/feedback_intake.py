"""Structured feedback on the existing founder inbox.

Reports are signed local records. They are not consensus, not votes, and not
payments. Security and abuse text stays off the public dashboard. A reward is
a draft beneficiary row for economics.py; this module does not move a balance.
"""
import hashlib
import re
from copy import deepcopy

from covenant_language.agentic import canonical as text_canonical
from covenant_language.ecology import attention_feed, threat_memory

from .crypto import digest, key, need
from .economics import validate_policy
from .feedback import open_content

PROFILE = 'covenant-feedback-report/0.1'
DASHBOARD = 'covenant-feedback-dashboard/0.1'
NAMES = {
    'bug': 'bug',
    'friction': 'friction',
    'feature request': 'feature request',
    'feature_request': 'feature request',
    'docs': 'docs',
    'security': 'security',
    'abuse': 'abuse',
}
ENVELOPE = {
    'bug': 'BUG',
    'friction': 'FRICTION',
    'feature request': 'REQUEST',
    'docs': 'DESIGN',
    'security': 'SECURITY',
    'abuse': 'SECURITY',
}
SEVERITY = ('low', 'medium', 'high', 'critical')
PRIVATE = frozenset({'security', 'abuse'})
BOUNTY = {'high': 50, 'critical': 100}
TOOL = re.compile(r'[A-Za-z0-9_.:-]{1,80}\Z')
AGENT = re.compile(r'[A-Za-z0-9_.:@/-]{1,80}\Z')
SECRET = re.compile(
    r'(?i)(?:\b(?:api[_-]?key|secret|password|token|seed|private[_-]?key|authorization)\b\s*[:=]\s*\S+|\bBearer\s+\S+)'
)
PEM = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----', re.S)
EMAIL = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b')
PHONE = re.compile(r'\b(?:\+\d{8,15}|\d{3}-\d{3}-\d{4})\b')
CONFIRMED = frozenset({'PLANNED', 'IMPLEMENTED'})


def _hid(label, value):
    return hashlib.sha256(label.encode('ascii') + b'\0' + text_canonical(value)).hexdigest()


def redact(text):
    """Replace secrets and common PII. The replacement count is returned."""
    return _redact(text)


def _redact(text):
    need(type(text) is str and 1 <= len(text) <= 4000, 'FEEDBACK_TEXT')
    count = 0

    def sub(pattern, value):
        nonlocal count

        def repl(match):
            nonlocal count
            count += 1
            return '[REDACTED]'

        return pattern.sub(repl, value)

    cleaned = sub(PEM, text)
    cleaned = sub(SECRET, cleaned)
    cleaned = sub(EMAIL, cleaned)
    cleaned = sub(PHONE, cleaned)
    if not cleaned.strip():
        cleaned = '[REDACTED]'
    return cleaned, count


def feedback_hint(surface, code=None):
    """A stable handle for one call back into covenant_feedback. No report text."""
    need(type(surface) is str and TOOL.fullmatch(surface), 'FEEDBACK_SURFACE')
    need(code is None or (type(code) is str and 1 <= len(code) <= 80), 'FEEDBACK_CODE')
    handle = digest('COVENANT-FEEDBACK-HINT-0.1', {'surface': surface, 'code': code or 'NONE'})
    return {
        'tool': 'covenant_feedback',
        'action': 'report',
        'surface': surface,
        'code': code,
        'report_this': handle,
        'prompt': 'Report this with covenant_feedback. Security and abuse stay off the public dashboard.',
        'execution_authorized': False,
    }


def _words(text):
    return re.findall(r'[a-z]{3,}', text.lower())[:6]


def compose(category, severity, tool, text, steps=None, reference=None, agent=None):
    """Redact and describe one report. This does not store or pay it."""
    need(category in NAMES, 'FEEDBACK_CATEGORY')
    name = NAMES[category]
    need(severity in SEVERITY, 'FEEDBACK_SEVERITY')
    need(type(tool) is str and TOOL.fullmatch(tool), 'FEEDBACK_TOOL')
    cleaned, redactions = _redact(text)
    step_text = None
    if steps is not None:
        step_text, extra = _redact(steps)
        redactions += extra
    if reference is not None:
        key(reference)
    if agent is not None:
        need(type(agent) is str and AGENT.fullmatch(agent), 'FEEDBACK_AGENT')
    body = {
        'profile': PROFILE,
        'category': name,
        'severity': severity,
        'tool': tool,
        'reference': reference,
        'text': None if name in PRIVATE else cleaned,
        'steps': None if name in PRIVATE else step_text,
        'agent': agent,
        'redactions': redactions,
        'withheld': 'PRIVATE_CHANNEL' if name in PRIVATE else None,
    }
    cluster = _hid('COVENANT-FEEDBACK-CLUSTER-0.1', {
        'category': name, 'tool': tool, 'words': _words(cleaned),
    })
    handle = _hid('COVENANT-FEEDBACK-HANDLE-0.1', {**body, 'cluster': cluster})
    return {
        **body,
        'handle': handle,
        'cluster': cluster,
        'envelope_category': ENVELOPE[name],
        'channel': 'PRIVATE' if name in PRIVATE else 'PUBLIC',
        'stored': False,
        'stored_text': False if name in PRIVATE else True,
        'consensus': False,
        'view': True,
        'governance_weight': 'NONE',
        'execution_authorized': False,
        'maintainer_confirmed': False,
        '_private_text': cleaned if name in PRIVATE else None,
        '_private_steps': step_text if name in PRIVATE else None,
    }


def share(composed):
    """Drop sealed text before a tool result or a public aggregate."""
    return {key: value for key, value in composed.items() if not key.startswith('_')}


def public_body(composed):
    """Bytes safe to put on a public dashboard or a public inbox."""
    hidden = composed['channel'] == 'PRIVATE'
    return {
        'profile': PROFILE,
        'category': composed['category'],
        'severity': composed['severity'],
        'tool': composed['tool'],
        'reference': composed['reference'],
        'text': None if hidden else composed['text'],
        'steps': None if hidden else composed['steps'],
        'agent': composed['agent'],
        'redactions': composed['redactions'],
        'withheld': composed['withheld'],
        'handle': composed['handle'],
        'cluster': composed['cluster'],
    }


def store_report(channel, composed):
    """Append one redacted report to the owner inbox. Private text is sealed or withheld."""
    body = public_body(composed)
    seal = composed['channel'] == 'PRIVATE' and channel.recipient is not None
    content = body
    if seal:
        content = {**body, 'text': composed['_private_text'], 'steps': composed['_private_steps'], 'withheld': None}
    scope = {
        'tool': composed['tool'],
        'severity': composed['severity'],
        'cluster': composed['cluster'],
        'agent': composed['agent'] or 'unspecified',
    }
    related = (composed['reference'],) if composed['reference'] else ()
    stored = channel.send(composed['handle'], composed['envelope_category'], scope, content, related)
    return {
        **public_body(composed),
        'channel': composed['channel'],
        'stored': True,
        'stored_text': seal or composed['channel'] == 'PUBLIC',
        'id': stored['id'],
        'duplicate': stored['duplicate'],
        'status': stored['status'],
        'externally_delivered': False,
        'governance_weight': 'NONE',
        'consensus': False,
        'execution_authorized': False,
    }


def issue_template(composed):
    """A GitHub issue body. Nothing is filed without a maintainer token."""
    if composed['channel'] == 'PRIVATE':
        return {
            'filed': False,
            'auto_file': False,
            'requires': 'MAINTAINER_TOKEN',
            'channel': 'PRIVATE',
            'route': 'SECURITY.md private vulnerability channel',
            'title': 'Private ' + composed['category'] + ' report',
            'body': 'Do not file this text on a public tracker. Route it through the private channel in SECURITY.md.',
            'labels': ['security'],
            'execution_authorized': False,
        }
    title = '[covenant] ' + composed['category'] + ' in ' + composed['tool']
    lines = [
        'Category: ' + composed['category'],
        'Severity: ' + composed['severity'],
        'Tool: ' + composed['tool'],
        'Agent: ' + (composed['agent'] or 'unspecified'),
        'Reference: ' + (composed['reference'] or 'none'),
        'Handle: ' + composed['handle'],
        '',
        composed['text'] or '',
    ]
    if composed['steps']:
        lines.extend(['', 'Steps:', composed['steps']])
    return {
        'filed': False,
        'auto_file': False,
        'requires': 'MAINTAINER_TOKEN',
        'channel': 'PUBLIC',
        'route': 'TEMPLATE_ONLY',
        'title': title,
        'body': '\n'.join(lines),
        'labels': [composed['category']],
        'execution_authorized': False,
    }


def _signal(row, count):
    return {
        'cluster': row['cluster'], 'category': row['category'], 'tool': row['tool'],
        'severity': row['severity'], 'count': count,
    }


def aggregate(records):
    """Public counts and views. Private text is not copied into the result."""
    need(type(records) is list and len(records) <= 500, 'FEEDBACK_PAGE')
    counts = {name: 0 for name in ('bug', 'friction', 'feature request', 'docs', 'security', 'abuse')}
    clusters = {}
    confirmed_public = {}
    confirmed_private = {}
    private = 0
    for row in records:
        need(type(row) is dict and row.get('profile') == PROFILE, 'FEEDBACK_REPORT')
        name = row.get('category')
        need(name in counts, 'FEEDBACK_CATEGORY')
        counts[name] += 1
        hidden = name in PRIVATE or row.get('withheld') or row.get('channel') == 'PRIVATE'
        if hidden:
            private += 1
        key_id = row.get('cluster')
        need(type(key_id) is str and len(key_id) == 64, 'FEEDBACK_REPORT')
        bucket = clusters.setdefault(key_id, {'cluster': key_id, 'category': name, 'tool': row.get('tool'),
                                              'severity': row.get('severity'), 'count': 0, 'samples': []})
        bucket['count'] += 1
        if not hidden and row.get('text') and len(bucket['samples']) < 3:
            bucket['samples'].append(row['text'][:240])
        if row.get('maintainer_confirmed') is True:
            target = confirmed_private if hidden else confirmed_public
            target[key_id] = _signal(row, target.get(key_id, _signal(row, 0))['count'] + 1)
    listed = sorted(clusters.values(), key=lambda item: (-item['count'], item['cluster']))
    return {
        'profile': DASHBOARD,
        'view': True,
        'consensus': False,
        'native_state': False,
        'execution_authorized': False,
        'counts': counts,
        'clusters': listed[:32],
        'private_reports': private,
        'private_text': 'WITHHELD',
        'attention': attention_feed(list(confirmed_public.values())),
        'threat_memory': threat_memory(list(confirmed_private.values())),
    }


def dashboard_from_desk(desk):
    """Read the append-only inbox. Confidential envelopes stay sealed."""
    records = []
    confirmed = set()
    after = 0
    while True:
        page = desk.page(after, 100)
        if not page['items']:
            break
        for item in page['items']:
            body = item['envelope']['body']
            if body['kind'] == 'RESPONSE' and body['status'] in CONFIRMED:
                confirmed.add(body['parent'])
                continue
            if body['kind'] != 'REPORT':
                continue
            if body['content']['mode'] != 'PUBLIC':
                scope = body['scope'] if type(body.get('scope')) is dict else {}
                cluster = scope.get('cluster')
                if type(cluster) is not str or len(cluster) != 64:
                    cluster = _hid('COVENANT-FEEDBACK-SEALED-0.1', {'id': item['id']})
                tool_name = scope.get('tool') if type(scope.get('tool')) is str and TOOL.fullmatch(scope.get('tool') or '') else 'withheld'
                severity = scope.get('severity') if scope.get('severity') in SEVERITY else 'high'
                named = {'BUG': 'bug', 'FRICTION': 'friction', 'REQUEST': 'feature request',
                         'DESIGN': 'docs', 'SECURITY': 'security'}.get(body['category'], 'security')
                records.append({
                    'profile': PROFILE, 'category': named, 'severity': severity, 'tool': tool_name,
                    'cluster': cluster, 'withheld': 'SEALED', 'channel': 'PRIVATE', 'id': item['id'],
                })
                continue
            try:
                opened = open_content(item['envelope'])
            except ValueError:
                continue
            if type(opened) is dict and opened.get('profile') == PROFILE:
                records.append({**opened, 'id': item['id'], 'channel': 'PRIVATE' if opened.get('withheld') else 'PUBLIC'})
        after = page['next_after']
    for row in records:
        row['maintainer_confirmed'] = row.get('id') in confirmed
    return aggregate(records)


def reward_proposal(policy, resources, reporter, *, confirmed, reproducible, severity, already_rewarded=()):
    """Draft a beneficiary row inside an existing 10,000 bps schedule.

    The row is not submitted and no escrow moves. SECURITY.md does not offer
    a public bounty; a maintainer has to adopt the schedule themselves.
    """
    refused = {
        'paid': False, 'submitted': False, 'execution_authorized': False,
        'native_op': 'ECON_FEE_SCHEDULE', 'fee_accountant': 'covenant_chain.economics',
        'consensus': False,
    }
    if not confirmed:
        return {**refused, 'reason': 'MAINTAINER_CONFIRMATION_REQUIRED'}
    if not reproducible:
        return {**refused, 'reason': 'REPRODUCTION_REQUIRED'}
    if severity not in BOUNTY:
        return {**refused, 'reason': 'NOT_BOUNTY_TIER'}
    key(reporter)
    need(type(already_rewarded) in (list, tuple) and len(already_rewarded) <= 256, 'FEEDBACK_SYBIL')
    for prior in already_rewarded:
        key(prior)
    if reporter in already_rewarded:
        return {**refused, 'reason': 'FEEDBACK_SYBIL_CAP'}
    bounty = BOUNTY[severity]
    draft = deepcopy(policy)
    donor = max(range(len(draft['beneficiaries'])), key=lambda i: draft['beneficiaries'][i]['bps'])
    need(draft['beneficiaries'][donor]['account'] != reporter, 'FEEDBACK_REWARD_SOURCE')
    need(draft['beneficiaries'][donor]['bps'] > bounty, 'FEEDBACK_REWARD_SOURCE')
    draft['beneficiaries'][donor]['bps'] -= bounty
    existing = next((row for row in draft['beneficiaries'] if row['account'] == reporter), None)
    if existing:
        existing['bps'] += bounty
    else:
        draft['beneficiaries'].append({'account': reporter, 'bps': bounty, 'purpose': 'bug-bounty'})
    validate_policy(draft, resources)
    return {
        **refused,
        'reason': 'DRAFT_NOT_SUBMITTED',
        'paid': False,
        'bps': bounty,
        'reporter': reporter,
        'source': 'EXISTING_FEE_BENEFICIARY_ROWS',
        'policy': draft,
        'maintainer_confirmation': 'CALLER_ASSERTED_NOT_A_SIGNATURE',
    }
