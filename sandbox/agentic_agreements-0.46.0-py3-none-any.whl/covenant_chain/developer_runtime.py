"""Owner adoption and guarded routing for immutable application packages.

Publisher signatures are attribution, not code audits or native authority.
Existing mechanism-plan assent, gates and workflow approvals remain mandatory.
No application install or backend import is exposed to agent requests.
"""
from copy import deepcopy
import hashlib
from pathlib import Path
from covenant_language import developer_apps as a, developer_economics as e, mechanism_plans as p
from .crypto import verify,verification_key
from .adapters import manifest as adapter_manifest,manifest_id
from .workflow_store import canonical as wire

CALL='covenant-application-call/0.1'
IMPLEMENTATION=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def call_id(call):
    a.fields(call,'version application operation context units arguments');a.need(call['version']==CALL,'APPLICATION_CALL_VERSION');p.ref(call['application']);a.name(call['operation']);p.ref(call['context']);e.integer(call['units']);a.need(call['units']>0,'DEVELOPER_UNITS');p.canonical(call['arguments'])
    return p._id('COVENANT-APPLICATION-CALL-0.1',call)


class _Effect:
    def __init__(self,registry,app,operation,backend,pin):
        self.registry=registry;self.app=app;self.operation=operation;self.backend=backend;self.pin=pin
        self.manifest=adapter_manifest('application:'+operation,'application.invoke',effect='PINNED_OWNER_APPLICATION_BACKEND',instance=p._id('COVENANT-APP-ADAPTER-0.1',{'application':app,'operation':operation,'backend':pin}),recovery=backend.manifest['recovery'],max_bytes=1000000)
        self.manifest['requirements'].update(application=app,backend=pin,authority='EXACT_PLAN_ASSENT_AND_NATIVE_WORKFLOW_APPROVALS')
    def _observed(self,result):
        a.need(type(result) is dict and type(result.get('status')) is str,'APPLICATION_BACKEND_OBSERVATION')
        if result['status']=='OBSERVED':return result
        return {'status':'NOT_OBSERVED','output_hash':None,'backend_status':result['status'],'assurance':'NO_OBSERVED_COMPLETION_NOT_PROOF_OF_FAILURE'}
    def _effect_id(self,ref):p.ref(ref);return p._id('COVENANT-APP-EFFECT-0.1',{'effect':ref,'application':self.app,'operation':self.operation})
    def execute(self,effect_id,request,*,crash=None):
        self.registry.check(self.app);self.registry._call(self.app,self.operation,request);a.need(manifest_id(self.backend.manifest)==self.pin,'APPLICATION_BACKEND_CHANGED')
        a.need(len(wire(request['arguments']))<=self.backend.manifest['max_bytes'],'APPLICATION_BACKEND_INPUT_SIZE')
        return self._observed(self.backend.execute(self._effect_id(effect_id),deepcopy(request['arguments']),crash=crash))
    def observe(self,effect_id):
        self.registry.check(self.app);a.need(manifest_id(self.backend.manifest)==self.pin,'APPLICATION_BACKEND_CHANGED');return self._observed(self.backend.observe(self._effect_id(effect_id)))


class ApplicationRegistry:
    def __init__(self,mechanisms,trusted_publishers,policies=()):
        a.need(type(trusted_publishers) is dict and len(trusted_publishers)<=64,'APPLICATION_PUBLISHERS')
        for actor,key in trusted_publishers.items():p.ref(actor);verification_key(key)
        self.mechanisms=mechanisms;self.publishers=deepcopy(trusted_publishers);self._trust=p.canonical(self.publishers);self.entries={};self.policies={}
        for policy in policies:
            ref=e.identifier(policy);a.need(ref not in self.policies,'APPLICATION_POLICY_DUPLICATE');self.policies[ref]=deepcopy(policy)
    def _route(self,manifest,operation):return self.mechanisms.get(manifest['routes'][operation]['mechanism'],manifest['routes'][operation]['operation'],manifest['routes'][operation]['mode'])
    def _call(self,ref,operation,call):
        request=call_id(call);a.need(call['application']==ref and call['operation']==operation,'APPLICATION_CALL_SCOPE');return request
    def _local(self,ref,operation):
        def invoke(context,call):
            self.check(ref);request=self._call(ref,operation,call)
            a.need(context['context']==call['context'] and p.canonical(context['parameters'])==p.canonical({'application':ref,'request':request}),'APPLICATION_CALL_NOT_ASSENTED')
            record=self.entries[ref]['manifest'];route=record['routes'][operation]
            return self.mechanisms.local(route['mechanism'],route['operation'],context,call['arguments'])
        return invoke
    def install(self,manifest,signature):
        ref=a.identifier(manifest);a.need(ref not in self.entries,'APPLICATION_ALREADY_INSTALLED');a.need(len(self.entries)<a.MAX_APPS,'APPLICATION_INSTALL_LIMIT');a.need(p.canonical(self.publishers)==self._trust,'APPLICATION_TRUST_CHANGED')
        actor=manifest['publisher'];a.need(actor in self.publishers,'APPLICATION_PUBLISHER_NOT_ADOPTED');pl=a.payload(manifest);verify(self.publishers[actor],pl['label'],pl['body'],signature)
        refs=set(manifest['dependencies']+([] if manifest['parent'] is None else [manifest['parent']]))
        a.need(refs<=set(self.entries),'APPLICATION_DEPENDENCY_NOT_INSTALLED')
        for dependency in refs:self.check(dependency)
        if manifest['supersedes'] is not None:
            old=self.check(manifest['supersedes'])['manifest'];a.need(old['publisher']==actor and old['name']==manifest['name'],'APPLICATION_SUCCESSOR_PUBLISHER_OR_NAME')
        policy=manifest['economics'];a.need(policy in self.policies and e.identifier(self.policies[policy])==policy,'APPLICATION_ECONOMICS_NOT_ADOPTED')
        closure=a.resolve(ref,[manifest]+[v['manifest'] for v in self.entries.values()])
        routes={};handlers={};pins={}
        for operation,route in manifest['routes'].items():
            backend_manifest,handler,pin=self._route(manifest,operation)
            a.need(backend_manifest['semantics']==route['interface'],'APPLICATION_INTERFACE_MISMATCH');pins[operation]=(handler,pin)
            handlers[operation]=self._local(ref,operation) if route['mode']=='LOCAL' else _Effect(self,ref,operation,handler,pin)
            routes[operation]={'mode':route['mode'],'description':'Exact application call for '+manifest['name']+'.'+operation}
        bridge=p.manifest('application:'+manifest['name'],'application',p._id('COVENANT-APP-BRIDGE-0.1',{'application':ref}),IMPLEMENTATION,routes,assumptions=['Owner-installed code and publisher trust; composition is not inherited consensus security.'])['manifest']
        bridge_ref=self.mechanisms.register(bridge,handlers)
        self.entries[ref]={'manifest':deepcopy(manifest),'signature':deepcopy(signature),'pins':pins,'bridge':bridge_ref,'handlers':handlers,'closure':closure['closure']}
        return {'application':ref,'mechanism':bridge_ref,'level':closure['levels'][ref],'publisher_signature_verified':True,'security_inherited':False,'execution_authorized':False}
    def check(self,ref,_seen=None):
        p.ref(ref);a.need(p.canonical(self.publishers)==self._trust,'APPLICATION_TRUST_CHANGED');a.need(ref in self.entries,'APPLICATION_NOT_INSTALLED')
        record=self.entries[ref];manifest=record['manifest'];a.need(a.identifier(manifest)==ref,'APPLICATION_MANIFEST_CHANGED')
        seen=set() if _seen is None else _seen
        if ref in seen:return record
        a.need(len(seen)<a.MAX_APPS,'APPLICATION_CHECK_LIMIT');seen.add(ref)
        for dependency in set(manifest['dependencies']+([] if manifest['parent'] is None else [manifest['parent']])):self.check(dependency,seen)
        pl=a.payload(manifest);verify(self.publishers[manifest['publisher']],pl['label'],pl['body'],record['signature'])
        policy=manifest['economics'];a.need(policy in self.policies and e.identifier(self.policies[policy])==policy,'APPLICATION_ECONOMICS_CHANGED')
        for op,(handler,pin) in record['pins'].items():
            _,actual,actual_pin=self._route(manifest,op);a.need(actual is handler and actual_pin==pin,'APPLICATION_HANDLER_CHANGED')
            _,bridge_handler,_=self.mechanisms.get(record['bridge'],op,manifest['routes'][op]['mode']);a.need(bridge_handler is record['handlers'][op],'APPLICATION_BRIDGE_CHANGED')
        return record
    def describe(self):
        rows=[]
        for ref in sorted(self.entries):
            record=self.check(ref);info=a.resolve(ref,[v['manifest'] for v in self.entries.values()])
            rows.append({'id':ref,'manifest':deepcopy(record['manifest']),'mechanism':record['bridge'],'level':info['levels'][ref],'closure':info['closure'],'publisher_signature_verified':True,'security_inherited':False})
        return {'applications':rows,'installation':'OWNER_ONLY_PINNED_BACKENDS_NO_CODE_LOADING','execution_authorized':False}
    def export(self,application):
        record=self.check(application);publisher=record['manifest']['publisher']
        return {'application':application,'manifest':deepcopy(record['manifest']),'publisher_signature':deepcopy(record['signature']),'verification_key':deepcopy(self.publishers[publisher]),'signature_scope':'RELEASE_ATTRIBUTION; RECEIVER_MUST_INDEPENDENTLY_ADOPT_PUBLISHER_AND_BACKENDS','installation_authority_transferred':False,'execution_authorized':False}
    def prepare(self,application,operation,arguments,context,controllers,units=1,request_salt=None):
        record=self.check(application);a.name(operation);a.need(operation in record['manifest']['routes'],'APPLICATION_OPERATION')
        closure=a.resolve(application,[v['manifest'] for v in self.entries.values()])
        for ref in closure['applications']:self.check(ref)
        p.ref(context);call={'version':CALL,'application':application,'operation':operation,'context':context,'units':units,'arguments':deepcopy(arguments)};request=call_id(call);mode=record['manifest']['routes'][operation]['mode']
        parameters={'application':application,'request':request}
        if mode=='EFFECT':
            a.need(request_salt is not None,'APPLICATION_EFFECT_SALT_REQUIRED');parameters['request_commitment']=p.field_commitment(call,request_salt,context,'call','/mechanisms/0/request')
        else:a.need(request_salt is None,'APPLICATION_LOCAL_SALT_UNEXPECTED')
        step=p.step('call',{'kind':'application','id':application},[],{},visibility='WITHHELD',mechanisms=[p.binding(record['bridge'],operation,parameters)])
        plan=p.plan(context,{'kind':'application','id':application},controllers,[step],purpose='Exact application call; no automatic effects')
        return {'application':application,'request':request,'call':call,'closure':closure,'plan':plan['plan'],'id':plan['id'],'assent_payload':p.assent_payload(plan['plan']),'route_mode':mode,'step':'call','binding':0,'request_salt':request_salt,'economics':record['manifest']['economics'],'next':'EXPLICIT_CONTROLLER_ASSENT_THEN_GUARDED_LOCAL_CALL' if mode=='LOCAL' else 'EXPLICIT_CONTROLLER_ASSENT_THEN_PREPARE_EFFECT_AND_NATIVE_WORKFLOW','execution_authorized':False}
    def quote(self,application,units):
        record=self.check(application);return e.quote(self.policies[record['manifest']['economics']],units)
    def settlement(self,call,payer):
        application=call.get('application') if type(call) is dict else None;record=self.check(application);request=self._call(application,call['operation'],call)
        a.need(call['operation'] in record['manifest']['routes'],'APPLICATION_OPERATION')
        return e.clearing(self.policies[record['manifest']['economics']],application,request,payer,call['units'],call['context'])


def native_fee_policy(resource,base_fee,per_kib,beneficiaries,governors,threshold,change_delay,work_fees=None,market_profile=False):
    """Prepare an existing native policy, never change a running chain."""
    from .economics import VERSION,MARKET_VERSION,validate_policy,policy_id
    a.need(type(market_profile) is bool,'APPLICATION_MARKET_PROFILE')
    policy={'version':MARKET_VERSION if market_profile else VERSION,'resource':resource,'base_fee':base_fee,'per_kib':per_kib,'work_fees':{} if work_fees is None else deepcopy(work_fees),'beneficiaries':deepcopy(beneficiaries),'governors':deepcopy(governors),'threshold':threshold,'change_delay':change_delay}
    validate_policy(policy,{resource:{}})
    return {'id':policy_id(policy),'policy':policy,'adopted':False,'resource_existence':'NOT_VERIFIED_BY_DRAFT','next':'EXPLICIT_GENESIS_OR_EXISTING_GOVERNANCE_ADOPTION_WITH_NOTICE; MARKET_PROFILE_MUST_PRESERVE_REQUIRED_MAINTENANCE_AND_REWARD_ROUTES','execution_authorized':False}


def sponsor(resource,budget,actors,operations,per_actor_cap,expiry):
    from .economics import label
    label(resource);e.integer(budget);e.integer(per_actor_cap);e.integer(expiry)
    a.need(budget>0 and per_actor_cap>0 and per_actor_cap<=budget and expiry>0,'APPLICATION_SPONSOR_BUDGET')
    a.need(type(actors) is list and 1<=len(actors)<=64,'APPLICATION_SPONSOR_ACTORS')
    for actor in actors:p.ref(actor)
    a.need(actors==sorted(set(actors)),'APPLICATION_SPONSOR_ACTORS')
    a.need(type(operations) is list and 1<=len(operations)<=64,'APPLICATION_SPONSOR_OPERATIONS')
    for op in operations:label(op)
    a.need(operations==sorted(set(operations)),'APPLICATION_SPONSOR_OPERATIONS')
    return {'operation':'ECON_SPONSOR_CREATE','payload':{'resource':resource,'budget':budget,'actors':deepcopy(actors),'operations':deepcopy(operations),'per_actor_cap':per_actor_cap,'expiry':expiry},'funding':'NOT_RESERVED; NATIVE_CREATION_DEBITS_ISSUER_AND_ENFORCES_SCOPE_AND_CAPS','execution_authorized':False}


class _PinnedView:
    """An application deployment snapshots only explicitly adopted mechanisms."""
    def __init__(self,applications,application,extra):
        self.applications=applications;self.application=application;self.source=applications.mechanisms
        a.need(type(extra) in (list,tuple) and len(extra)<=32,'APPLICATION_EXTRA_MECHANISMS')
        for ref in extra:p.ref(ref)
        a.need(len(extra)==len(set(extra)),'APPLICATION_EXTRA_MECHANISMS_DUPLICATE')
        closure=a.resolve(application,[v['manifest'] for v in applications.entries.values()]);refs=set(extra)
        for ref in closure['applications']:
            entry=applications.check(ref);refs.add(entry['bridge']);refs.update(r['mechanism'] for r in entry['manifest']['routes'].values())
        for ref in refs:p.ref(ref)
        a.need(len(refs)<=128,'APPLICATION_MECHANISM_SCOPE_LIMIT');self.refs=refs;self.pins={}
        self.snapshot={ref:deepcopy(self.source.describe()[ref]) for ref in refs}
        for ref,row in self.snapshot.items():
            for op in row['operations']:self.pins[ref,op]=self.source.get(ref,op)[1:]
    def describe(self):
        self.applications.check(self.application);current=self.source.describe();a.need(all(ref in current and current[ref]==row for ref,row in self.snapshot.items()),'APPLICATION_DEPLOYMENT_CHANGED')
        for (ref,op),(handler,pin) in self.pins.items():
            _,actual,actual_pin=self.source.get(ref,op);a.need(actual is handler and actual_pin==pin,'APPLICATION_DEPLOYMENT_HANDLER_CHANGED')
        return deepcopy(self.snapshot)
    def get(self,ref,operation,mode=None):
        a.need(ref in self.refs,'APPLICATION_MECHANISM_OUTSIDE_DEPLOYMENT');self.describe();return self.source.get(ref,operation,mode)
    def local(self,ref,operation,context,payload):
        self.get(ref,operation,'LOCAL');return self.source.local(ref,operation,context,payload)


from .mechanism_runtime import PlanEffectAdapter

class ApplicationEffectAdapter(PlanEffectAdapter):
    def __init__(self,directory,applications,application,extra_mechanisms=()):
        self.applications=applications;self.application=application
        super().__init__(directory,_PinnedView(applications,application,extra_mechanisms))
    def _scope(self,plan,call,step,index):
        app=self.application;record=self.applications.check(app)
        self.applications._call(app,call.get('operation') if type(call) is dict else None,call)
        try:p.validate(plan)
        except (KeyError,TypeError,IndexError):raise ValueError('APPLICATION_PLAN_INVALID') from None
        a.need(plan['context']==call['context'] and plan['subject']=={'kind':'application','id':app},'APPLICATION_EFFECT_SCOPE')
        selected=next((s for s in plan['steps'] if s['id']==step),None)
        a.need(selected is not None and type(index) is int and 0<=index<len(selected['mechanisms']),'APPLICATION_EFFECT_BINDING')
        binding=selected['mechanisms'][index];a.need(binding['mechanism']==record['bridge'] and binding['operation']==call['operation'],'APPLICATION_EFFECT_ROUTE')
        a.need(binding['parameters'].get('request')==call_id(call) and binding['parameters'].get('application')==app,'APPLICATION_EFFECT_REQUEST')
    def _request_scope(self,request):
        a.fields(request,'plan step binding payload request_salt approvals expected_id expected_controllers evidence previous expected_previous')
        self._scope(request['plan'],request['payload'],request['step'],request['binding'])
    def _history(self):
        intents,receipts=super()._history()
        for request in intents.values():self._request_scope(request)
        return intents,receipts
    def execute(self,effect_id,request,*,crash=None):
        self._request_scope(request)
        return super().execute(effect_id,request,crash=crash)


def prepare_application_effect(applications,adapter,**parameters):
    from .mechanism_runtime import prepare_effect
    a.need(isinstance(adapter,ApplicationEffectAdapter) and adapter.applications is applications,'APPLICATION_EFFECT_DEPLOYMENT_REQUIRED')
    a.need({'plan','payload','step','binding'}<=set(parameters),'APPLICATION_EFFECT_PARAMETERS')
    adapter._scope(parameters['plan'],parameters['payload'],parameters['step'],parameters['binding'])
    return prepare_effect(adapter.registry,adapter,**parameters)
