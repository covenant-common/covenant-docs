"""Bounded HTTP connection lifetimes for owner-operated application servers.

These limits protect accepted socket reads and writes. They do not turn Python's
HTTP server into a public edge proxy or interrupt arbitrary application code.
"""
from http.server import ThreadingHTTPServer
import math
import socket
import threading
import time


class BoundedHTTPServer(ThreadingHTTPServer):
    """Admit a fixed worker population and expire each accepted connection.

    The deadline is measured from admission, never refreshed by a byte arriving.
    Shutdown closes active sockets and joins workers and their deadline timers.
    Call shutdown() before server_close() when serve_forever() runs elsewhere.
    """
    daemon_threads = False
    block_on_close = True

    def __init__(self, address, handler, *, max_connections=32,
                 connection_seconds=5):
        if type(max_connections) is not int or not 1 <= max_connections <= 128:
            raise ValueError('HTTP_CONNECTION_LIMIT')
        if (type(connection_seconds) not in (int, float)
                or not 0 < connection_seconds <= 60
                or not math.isfinite(connection_seconds)):
            raise ValueError('HTTP_CONNECTION_DEADLINE')
        self.max_connections = max_connections
        self.connection_seconds = connection_seconds
        self.request_queue_size = 2 * max_connections
        self._slots = threading.BoundedSemaphore(max_connections)
        self._active = {}
        self._active_lock = threading.Lock()
        self._closing = False
        super().__init__(address, handler)

    @staticmethod
    def _interrupt(request):
        try:
            request.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass

    def process_request(self, request, client_address):
        # An idle timeout alone permits a client to retain its worker forever
        # by sending one byte at a time. The independent timer closes the whole
        # socket, including blocked header/body reads and response writes.
        deadline = time.monotonic() + self.connection_seconds
        with self._active_lock:
            admitted = not self._closing and self._slots.acquire(blocking=False)
            if admitted:
                timer = threading.Timer(max(0, deadline - time.monotonic()),
                                        self._interrupt, (request,))
                timer.daemon = True
                self._active[request] = timer
        if not admitted:
            self.shutdown_request(request)
            return
        try:
            request.settimeout(min(1, self.connection_seconds))
            timer.start()
            super().process_request(request, client_address)
        except BaseException:
            self._release(request)
            raise

    def _release(self, request):
        with self._active_lock:
            timer = self._active.pop(request, None)
        if timer is not None:
            timer.cancel()
            if timer.ident is not None:
                timer.join()
            self._slots.release()

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._release(request)

    def handle_error(self, request, client_address):
        # Expiry/disconnects are ordinary hostile-input outcomes. Request
        # metadata and private values must not become incidental trace logs.
        import sys
        if not isinstance(sys.exc_info()[1], OSError):
            super().handle_error(request, client_address)

    def server_close(self):
        with self._active_lock:
            self._closing = True
            active = tuple(self._active)
        for request in active:
            self._interrupt(request)
        super().server_close()
