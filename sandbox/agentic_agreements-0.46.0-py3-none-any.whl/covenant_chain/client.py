"""Small standard-library HTTP client for the experimental native Covenant chain."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
import urllib.parse


class RPCError(RuntimeError):
    def __init__(self,message,*,status=None):
        super().__init__(message);self.status=status


class Client:
    def __init__(self, url: str, timeout: float = 3.0, private_route=None, *, tls_context=None, certificate_pin=None, admission_token=None):
        self.url = url.rstrip('/')
        self.timeout = timeout
        from .transport import client_opener
        import math,re
        if type(timeout) not in (int,float) or not math.isfinite(timeout) or timeout<=0:raise ValueError('RPC_TIMEOUT')
        if admission_token is not None and (type(admission_token) is not str or re.fullmatch('[0-9a-f]{64}',admission_token) is None):raise ValueError('RPC_ADMISSION_TOKEN')
        self.opener=client_opener(self.url,tls_context,certificate_pin) if private_route is None else None
        self.admission_token=admission_token
        self.private_route=private_route
        if private_route is not None and private_route['destination']!=self.url:raise ValueError('RELAY_DESTINATION_BINDING')

    def _request(self, path: str, value=None):
        if not path.startswith('/') or path.startswith('//') or any(ord(c)<33 or ord(c)>126 for c in path):raise RPCError('RPC_PATH')
        data = None if value is None else json.dumps(value, separators=(',', ':')).encode()
        headers={'Content-Type': 'application/json'}
        if self.admission_token is not None:headers['Authorization']='Bearer '+self.admission_token
        request = urllib.request.Request(self.url + path, data=data,headers=headers)
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                raw=response.read(4_000_001)
                if len(raw)>4_000_000:raise ValueError('RPC_REPLY_SIZE')
                from .crypto import loads
                return loads(raw), response.headers
        except urllib.error.HTTPError as exc:
            raise RPCError(f'HTTP {exc.code}: {exc.read(4096).decode(errors="replace")}',status=exc.code) from exc
        except (OSError, ValueError) as exc:
            raise RPCError(str(exc)) from exc

    def request(self, path: str, value=None):
        if self.private_route is not None:
            from .relay import request
            return request(self.private_route,'GET' if value is None else 'POST',path,value)
        body, _headers = self._request(path, value)
        return body

    @staticmethod
    def negotiate_privacy(proposer,recipient,route=None):
        """Pass this party's relay route to make transport 'origin-protected' selectable."""
        from .privacy import negotiate
        return negotiate(proposer,recipient,route=route)

    def submit_batch(self, transactions, *, max_delay_ms=0):
        """Submit through the configured relay route in random order with random gaps.

        Requires ``private_route``. Timing is blurred for one link only; see
        relay.TIMING_LIMITS. Direct clients refuse RELAY_ROUTE_REQUIRED.
        """
        if getattr(self, 'private_route', None) is None:raise ValueError('RELAY_ROUTE_REQUIRED')
        from .relay import submit_batch
        return submit_batch(self.private_route,transactions,max_delay_ms=max_delay_ms)

    @staticmethod
    def bind_private_terms(terms,selection,manifest):
        from .privacy import bind_terms
        return bind_terms(terms,selection,manifest)

    def status(self):
        return self.request('/status')

    def _state_body(self):
        """One /state read. A client built with ``__new__`` uses the replaced ``request``."""
        if not hasattr(self, 'url'):
            return self.request('/state')
        body, headers = self._request('/state')
        if headers.get('X-Covenant-Reliance') != 'advisory-not-a-proof':
            raise RPCError('STATE_DUMP_IS_NOT_AUTHORITY')
        return body

    def state(self, *, backoff=False):
        """Bounded diagnostic dump. It is not a substitute for certified history.

        The node marks the body ``X-Covenant-Reliance: advisory-not-a-proof``.
        A reply without that header is refused. ``backoff=True`` retries HTTP 429,
        which is what a local demo does when a burst meets the diagnostic bucket.
        """
        if getattr(self, 'private_route', None) is not None:
            raise RPCError('STATE_DUMP_IS_NOT_AUTHORITY')
        if not backoff:
            return self._state_body()
        delay = 0.05
        last = None
        for _attempt in range(6):
            try:
                return self._state_body()
            except RPCError as exc:
                if exc.status != 429:
                    raise
                last = exc
                time.sleep(delay)
                delay = min(0.8, delay * 2)
        raise last

    def context(self):
        """Advisory chain/profile/height context; independently pin trust."""
        return self.request('/context')

    def read_record(self,table,key):
        """Bounded advisory lookup; result is not a certified membership proof."""
        from .crypto import need
        need(type(table) is str and type(key) is str and len(table)<=80 and len(key)<=256,'RECORD_QUERY')
        return self.request('/record?'+urllib.parse.urlencode({'table':table,'key':key}))

    def offers_page(self,capability=None,max_price=None,*,after=None,limit=32,provider=None):
        """Bounded advisory current-state search; cursor is not a snapshot proof."""
        from .crypto import need,integer,key,canonical
        need(type(limit) is int and 1<=limit<=32,'OFFERS_LIMIT')
        need(after is None or type(after) is str,'OFFERS_CURSOR')
        if after not in (None,''):key(after)
        need(capability is None or (type(capability) is str and 0<len(capability)<=80),'OFFERS_CAPABILITY')
        query={'limit':limit}
        if after not in (None,''):query['after']=after
        if capability is not None:query['capability']=capability
        if max_price is not None:integer(max_price);query['max_price']=max_price
        if provider is not None:key(provider);query['provider']=provider
        canonical(query)
        return self.request('/offers?'+urllib.parse.urlencode(query))

    def genesis(self):
        return self.request('/genesis')

    def blocks(self, from_height: int = 1):
        return self.request(f'/blocks?from={from_height}')

    def submit(self, transaction):
        return self.request('/submit', transaction)

    def preview(self, transaction):
        return self.request('/preview',transaction)

    def proof(self, table: str, key: str):
        return self.request('/proof',{'table':table,'key':key})

    def transaction(self, transaction_id: str):
        return self.request('/tx/' + transaction_id)

    def wait(self, transaction_id: str, timeout: float = 20.0, interval: float = 0.1):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:result = self.transaction(transaction_id)
            except RPCError as exc:
                if exc.status != 429:raise
                time.sleep(min(1,max(0,deadline-time.monotonic())));continue
            if result.get('status') == 'committed':
                return result
            if result.get('status') == 'rejected':
                raise RPCError(result.get('reason', 'transaction rejected'))
            time.sleep(interval)
        raise TimeoutError(f'Transaction {transaction_id} did not finalize within {timeout}s')

    def control(self, blocked):
        """Only accepted by nodes explicitly started with --sandbox-control."""
        return self.request('/control', {'blocked': list(blocked)})
