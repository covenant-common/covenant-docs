"""Service instruments composed from existing agreement and storage engines.

No custody clone: local allocation histories use WorkflowStore's append-only
journal and lock. Budget cancellation is bookkeeping, never a payment refund.
Historical signed profiles and native reducers are not changed. All clocks,
current authority, external spending and performance require separate checks.
"""
from copy import deepcopy
import threading

from covenant_language import agreement_application as a, agreement_procedures as procedures
from covenant_language import legal_composition as legal, marketplace
from covenant_language import service_relationships as terms
from .workflow_store import WorkflowStore

VERSION = 'urn:aap:service-workflow:0.1'
FLAGS = terms.FLAGS


def _payment_asset(price):
    # The marketplace uses integers. Name the denomination explicitly rather
    # than displaying 2550 whole USD for a decimal USD25.50 service quote.
    return marketplace.asset('service-payment', price['unit'], price['unit'] + ':minor:' + str(price['exponent']),
        transfer_terms={'currency': price['unit'], 'exponent': price['exponent'],
                        'amount_basis': 'EXACT_INTEGER_MINOR_UNITS; NO_AUTOMATIC_PAYMENT_ADAPTER'})


def simple_job(customer, provider, context, description, amount, unit, exponent=2, source=None):
    """One job can use the existing direct-trade path without creating a master."""
    a.parties({'customer': customer, 'provider': provider}); a.reference(context)
    terms._text(description)
    parsed = None if source is None else terms.parse_terms(source, exponent)
    if amount is None:
        return {'status': 'OPEN_PRICE; NO_ORDER_OR_ALLOCATION', 'terms': parsed, 'order': None, **FLAGS}
    quote = terms.money(amount, unit, exponent)
    if parsed is not None and parsed['price'] is not None:
        a.need(parsed['price'] == quote, 'SERVICE_PRICE_ECHO')
    made = marketplace.quick_trade(provider, customer, description[:200], quote['minor'],
        _payment_asset(quote), context,
        terms={'service_quote': {'description': description, 'price': quote, 'parsed': parsed},
               'interpretation': 'EXACT_QUOTE_ONLY; NO_PERFORMANCE_OR_PAYMENT_OBSERVATION'})
    return {**made, 'status': 'UNSIGNED_SIMPLE_JOB; BOTH_PARTIES_REQUIRED', 'price': quote, **FLAGS}


def prepare_calloff(master, calloff):
    terms.validate_calloff(master, calloff)
    if calloff['price'] is None:
        return {'calloff': deepcopy(calloff), 'id': a.content_id(terms.CALLOFF, calloff),
                'status': 'OPEN_PRICE; NO_ORDER_OR_ALLOCATION', 'order': None, **FLAGS}
    price = calloff['price']; parties = master['parties']
    made = marketplace.quick_trade(parties['provider'], parties['customer'], calloff['specification'][:200], price['minor'],
        _payment_asset(price), calloff['context'],
        terms={'service_calloff': calloff, 'master': terms.prepare_master(master)['id'],
               'interpretation': 'EXACT_CALLOFF_WITH_SEPARATE_MASTER_ASSENT; NO_PAYMENT_OR_PERFORMANCE'})
    return {**made, 'calloff': deepcopy(calloff), 'calloff_id': a.content_id(terms.CALLOFF, calloff),
            'status': 'UNSIGNED_CALLOFF; FRESH_BOTH_PARTY_ASSENT_REQUIRED', **FLAGS}


def _verify_calloff(master, calloff, approvals, expected_order):
    made = prepare_calloff(master, calloff)
    a.need(made['order'] is not None, 'SERVICE_OPEN_PRICE')
    marketplace.verify_order(made['order'], approvals, expected_order)
    return made


def _record(previous, sequence, kind, value):
    body = {'version': VERSION, 'previous': previous, 'sequence': sequence, 'kind': kind, 'value': deepcopy(value)}
    return {**body, 'id': a.content_id('AAP-SERVICE-ALLOCATION-EVENT-0.1', body)}


def replay(master, master_approvals, events, expected_master, expected_head=None):
    """Verify exact assents and derive active local allocation; no asset ledger."""
    terms.verify_master(master, master_approvals, expected_master)
    a.need(type(events) is list and len(events) <= terms.MAX_EVENTS, 'SERVICE_EVENT_LIMIT')
    head = a.content_id('AAP-SERVICE-ALLOCATION-INITIAL-0.1', {'master': expected_master})
    calls = {}; cancellation_nonces = {}; allocated = 0
    for sequence, event in enumerate(events):
        a.fields(event, 'version previous sequence kind value id')
        a.need(type(event['sequence']) is int and event['sequence'] == sequence and event['previous'] == head,
               'SERVICE_EVENT_PARENT')
        a.need(event == _record(head, sequence, event['kind'], event['value']), 'SERVICE_EVENT_CHANGED')
        value = event['value']
        if event['kind'] == 'ALLOCATE':
            a.fields(value, 'calloff approvals expected_order')
            made = _verify_calloff(master, value['calloff'], value['approvals'], value['expected_order'])
            calloff = value['calloff']; nonce = calloff['nonce']; price = calloff['price']['minor']
            a.need(nonce not in calls, 'SERVICE_NONCE_REUSED')
            a.need(allocated + price <= master['budget']['total']['minor'], 'SERVICE_TOTAL_CAP')
            calls[nonce] = {'calloff': deepcopy(calloff), 'id': made['calloff_id'], 'order': made['id'],
                            'active': True, 'cancellation': None}
            allocated += price
        elif event['kind'] == 'CANCEL':
            a.fields(value, 'calloff_nonce cancellation approvals expected_id')
            nonce = value['calloff_nonce']; a.need(type(nonce) is str and nonce in calls, 'SERVICE_CALLOFF_MISSING')
            prior = calls[nonce]; obj = value['cancellation']
            a.fields(obj, 'version master calloff calloff_nonce nonce context at reason effect')
            made = terms.cancellation(master, prior['calloff'], obj['nonce'], obj['reason'], obj['at'])
            a.need(a.canonical(obj) == a.canonical(made['cancellation']), 'SERVICE_CANCELLATION_CHANGED')
            legal.verify_assents(made['module'], obj['context'], value['approvals'], value['expected_id'])
            a.need(prior['active'] and obj['nonce'] not in cancellation_nonces, 'SERVICE_ALREADY_CANCELLED')
            a.need(obj['at'] >= prior['calloff']['issued_at'], 'SERVICE_CANCELLATION_TIME')
            prior['active'] = False; prior['cancellation'] = made['id']; cancellation_nonces[obj['nonce']] = made['id']
            allocated -= prior['calloff']['price']['minor']
        else:
            raise ValueError('SERVICE_EVENT_KIND')
        head = event['id']
    if expected_head is not None:
        a.reference(expected_head); a.need(expected_head == head, 'SERVICE_EXPECTED_HEAD')
    return {'version': VERSION, 'master': expected_master, 'head': head, 'events': len(events),
            'calloffs': calls, 'cancellation_nonces': cancellation_nonces,
            'allocated_minor': allocated, 'remaining_minor': master['budget']['total']['minor'] - allocated,
            'unit': master['budget']['total']['unit'], 'exponent': master['budget']['total']['exponent'],
            'scope': 'ONLY_SUPPLIED_SIGNED_LOCAL_ACTIVE_ALLOCATIONS; NO_EXTERNAL_SPENDING_OR_WORLD_TRUTH',
            'currentness': 'UNKNOWN; RETAINED_HEAD_AND_SINGLE_OWNER_HISTORY_REQUIRED',
            'cancel_effect': 'LOCAL_CAPACITY_RELEASE_ONLY; NO_REFUND_OR_LEGAL_DISCHARGE', **FLAGS}


def allocate(master, master_approvals, events, calloff, approvals, expected_master, expected_order, expected_head):
    state = replay(master, master_approvals, events, expected_master)
    made = _verify_calloff(master, calloff, approvals, expected_order)
    old = state['calloffs'].get(calloff['nonce'])
    if old is not None:
        a.need(old['id'] == made['calloff_id'] and old['order'] == expected_order, 'SERVICE_NONCE_REUSED')
        return {'state': state, 'events': deepcopy(events), 'exact_retry': True, 'record': None, **FLAGS}
    a.need(state['head'] == expected_head, 'SERVICE_EXPECTED_HEAD')
    a.need(len(events) < terms.MAX_EVENTS, 'SERVICE_EVENT_LIMIT')
    record = _record(state['head'], len(events), 'ALLOCATE', {'calloff': calloff, 'approvals': approvals, 'expected_order': expected_order})
    after = [*events, record]
    return {'state': replay(master, master_approvals, after, expected_master), 'events': deepcopy(after),
            'record': record, 'exact_retry': False, **FLAGS}


def cancel(master, master_approvals, events, cancellation, approvals, expected_master, expected_id, expected_head):
    state = replay(master, master_approvals, events, expected_master)
    a.fields(cancellation, 'version master calloff calloff_nonce nonce context at reason effect')
    a.need(type(cancellation) is dict and type(cancellation.get('calloff_nonce')) is str and cancellation['calloff_nonce'] in state['calloffs'], 'SERVICE_CALLOFF_MISSING')
    calloff = state['calloffs'][cancellation['calloff_nonce']]['calloff']
    made = terms.cancellation(master, calloff, cancellation['nonce'], cancellation['reason'], cancellation['at'])
    a.need(a.canonical(made['cancellation']) == a.canonical(cancellation), 'SERVICE_CANCELLATION_CHANGED')
    legal.verify_assents(made['module'], cancellation['context'], approvals, expected_id)
    if cancellation['nonce'] in state['cancellation_nonces']:
        a.need(state['cancellation_nonces'][cancellation['nonce']] == expected_id, 'SERVICE_NONCE_REUSED')
        return {'state': state, 'events': deepcopy(events), 'exact_retry': True, 'record': None, **FLAGS}
    a.need(state['head'] == expected_head, 'SERVICE_EXPECTED_HEAD')
    a.need(len(events) < terms.MAX_EVENTS, 'SERVICE_EVENT_LIMIT')
    record = _record(state['head'], len(events), 'CANCEL', {'calloff_nonce': calloff['nonce'], 'cancellation': cancellation,
                      'approvals': approvals, 'expected_id': expected_id})
    after = [*events, record]
    return {'state': replay(master, master_approvals, after, expected_master), 'events': deepcopy(after),
            'record': record, 'exact_retry': False, **FLAGS}


class ServiceBook:
    """One local journal, using existing WorkflowStore locking/atomic append.

    Local OS, filesystem and retained master/head are trusted. Cloned/rolled
    back stores or independently operated books cannot share one global cap.
    """
    def __init__(self, directory, master, master_approvals, expected_master):
        terms.verify_master(master, master_approvals, expected_master)
        self.master = deepcopy(master); self.approvals = deepcopy(master_approvals); self.id = expected_master
        self.lock = threading.RLock()
        self.store = WorkflowStore(directory, {'version': VERSION, 'master': expected_master}, check_same_thread=False)

    def _history(self):
        history = self.store.events()
        a.need(all(row['body']['kind'] == 'SERVICE_EVENT' for row in history), 'SERVICE_JOURNAL_KIND')
        return [row['body']['value'] for row in history]

    def state(self, expected_head=None):
        with self.lock, self.store.exclusive():
            return replay(self.master, self.approvals, self._history(), self.id, expected_head)

    def allocate(self, calloff, approvals, expected_order, expected_head):
        with self.lock, self.store.exclusive():
            result = allocate(self.master, self.approvals, self._history(), calloff, approvals, self.id, expected_order, expected_head)
            if result['record'] is not None:
                self.store.append('SERVICE_EVENT', result['record']['id'], result['record'])
            return {**result, 'recorded': True, 'storage': 'EXISTING_WORKFLOW_STORE; PRIVATE_PLAINTEXT_LOCAL_JOURNAL'}

    def cancel(self, cancellation, approvals, expected_id, expected_head):
        with self.lock, self.store.exclusive():
            result = cancel(self.master, self.approvals, self._history(), cancellation, approvals, self.id, expected_id, expected_head)
            if result['record'] is not None:
                self.store.append('SERVICE_EVENT', result['record']['id'], result['record'])
            return {**result, 'recorded': True, 'storage': 'EXISTING_WORKFLOW_STORE; NO_REFUND_TRANSACTION'}

    def close(self):
        with self.lock: self.store.close()


def owner_package(master, master_approvals=None, calloff=None, calloff_approvals=None):
    """Prepare existing portable LEGAL/ORDER handoff; owner confirmation stays separate."""
    from . import portable_agreements, coordination_review
    prepared = terms.prepare_master(master)
    rows = [{'id': 'master', 'kind': 'LEGAL', 'module': prepared['module'], 'context': master['context'],
             'approvals': [] if master_approvals is None else master_approvals, 'expected_id': prepared['id']}]
    if calloff is not None:
        made = prepare_calloff(master, calloff); a.need(made['order'] is not None, 'SERVICE_OPEN_PRICE')
        rows.append({'id': 'calloff', 'kind': 'ORDER', 'order': made['order'], 'expected_id': made['id'],
                     'approvals': [] if calloff_approvals is None else calloff_approvals})
    result = portable_agreements.pack(coordination_review.case(master['title'], rows, primary='calloff' if calloff is not None else 'master'))
    return {**result, 'owner_step': 'RECEIVE_THEN_REVIEW_SIGN_EXACT_ROLE_THEN_CONFIRM_IN_EXISTING_HANDOFF_SESSION',
            'signature_created': False, **FLAGS}


def competition(title, parties, principal, context, configuration, mode='TENDER', exponent=2):
    """Invited tender/contest under the existing signed finite negotiation engine."""
    a.need(mode in ('TENDER', 'CONTEST'), 'SERVICE_COMPETITION_MODE')
    a.need(type(exponent) is int and 0 <= exponent <= 9, 'SERVICE_EXPONENT')
    config = deepcopy(configuration)
    a.need(type(config) is dict and type(config.get('allowed_terms')) is dict and
           not {'service_mode', 'minor_exponent'} & set(config['allowed_terms']), 'SERVICE_RESERVED_TERMS')
    config['allowed_terms'].update({'service_mode': [{'kind': 'TEXT', 'value': mode}],
                                    'minor_exponent': [{'kind': 'INTEGER', 'value': exponent}]})
    return {**procedures.negotiation(title, parties, principal, context, config),
            'mode': mode, 'selection': 'SIGNED_PRINCIPAL_SELECTION_ONLY; FRESH_FINAL_TWO_PARTY_ASSENT_REQUIRED', **FLAGS}


def _mode(policy):
    procedures.validate(policy); a.need(policy['kind'] == 'NEGOTIATION', 'SERVICE_NEGOTIATION_REQUIRED')
    allowed = policy['configuration']['allowed_terms']
    a.need(allowed.get('service_mode') in ([{'kind': 'TEXT', 'value': 'TENDER'}], [{'kind': 'TEXT', 'value': 'CONTEST'}]), 'SERVICE_COMPETITION_PROFILE')
    a.need(type(allowed.get('minor_exponent')) is list and len(allowed['minor_exponent']) == 1, 'SERVICE_COMPETITION_PROFILE')
    exponent = allowed['minor_exponent'][0]; a.fields(exponent, 'kind value')
    a.need(exponent['kind'] == 'INTEGER' and type(exponent['value']) is int and 0 <= exponent['value'] <= 9, 'SERVICE_EXPONENT')
    return allowed['service_mode'][0]['value'], exponent['value']


def competition_offer(policy, bidder, amount, deliver_by, offer_terms, acceptance):
    mode, exponent = _mode(policy)
    a.need(type(offer_terms) is dict and not {'service_mode', 'minor_exponent'} & set(offer_terms), 'SERVICE_RESERVED_TERMS')
    price = terms.money(amount, policy['configuration']['unit'], exponent)['minor']
    a.need(mode != 'CONTEST' or price == policy['configuration']['maximum_price'], 'SERVICE_CONTEST_FIXED_PRIZE')
    return procedures.offer(policy, bidder, price, deliver_by,
        {**offer_terms, 'service_mode': {'kind': 'TEXT', 'value': mode}, 'minor_exponent': {'kind': 'INTEGER', 'value': exponent}}, acceptance)


def competition_replay(policy, adoptions, events, expected_head=None):
    mode, _ = _mode(policy)
    state = procedures.replay(policy, adoptions, events, expected_head)
    offers = list(state['reveals'].values()) + list(state['proposals'].values())
    if state['selected'] is not None: offers.append(state['selected'])
    a.need(mode != 'CONTEST' or all(row['price']['amount'] == policy['configuration']['maximum_price'] for row in offers), 'SERVICE_CONTEST_FIXED_PRIZE')
    return state


def competition_event(policy, adoptions, events, actor, action, arguments, at):
    competition_replay(policy, adoptions, events)
    mode, _ = _mode(policy)
    if mode == 'CONTEST' and action in ('PROPOSE', 'COUNTER', 'REVEAL'):
        a.need(type(arguments) is dict and type(arguments.get('offer')) is dict and
               type(arguments['offer'].get('price')) is dict and
               arguments['offer'].get('price', {}).get('amount') == policy['configuration']['maximum_price'], 'SERVICE_CONTEST_FIXED_PRIZE')
    return procedures.event_payload(policy, adoptions, events, actor, action, arguments, at)


def competition_advance(policy, adoptions, events, event):
    result = procedures.advance(policy, adoptions, events, event)
    result['state'] = competition_replay(policy, adoptions, result['events'])
    return result


def selected_calloff(policy, adoptions, events, expected_head, master, nonce, context, issued_at, specification, source=None):
    state = competition_replay(policy, adoptions, events, expected_head)
    a.need(state['status'] == 'SELECTED_PROPOSAL' and state['selected'] is not None, 'SERVICE_NO_SELECTED_PROPOSAL')
    offer = state['selected']; _, exponent = _mode(policy)
    a.need(master['parties']['customer'] == policy['parties'][policy['principal']] and
           master['parties']['provider'] == policy['parties'][offer['bidder']], 'SERVICE_SELECTED_PARTIES')
    a.need(master['budget']['total']['unit'] == policy['configuration']['unit'] and
           master['budget']['total']['exponent'] == exponent, 'SERVICE_UNIT')
    parsed = None if source is None else terms.parse_terms(source, exponent)
    made = terms.calloff(master, nonce, context, specification, terms.amount_text(offer['price']['amount'], exponent),
                         issued_at, offer['deliver_by'], parsed, selection={
                             'policy': state['policy'], 'head': state['head'], 'offer': a.content_id(procedures.OFFER_VERSION, offer)})
    return {**prepare_calloff(master, made['calloff']), 'selected_offer': deepcopy(offer),
            'selection_authority': 'PROPOSAL_SELECTION_ONLY; NO_PAYMENT_OR_CALLOFF_ASSENT', **FLAGS}


def award_event(policy, adoptions, events, proposal, actor, action, at, bond_receipt=None):
    """Prepare existing escalation events; reasons bind only in a separate award."""
    _proposal(proposal)
    state = procedures.replay(policy, adoptions, events)
    a.need(policy['kind'] == 'ESCALATION', 'SERVICE_ESCALATION_REQUIRED')
    if action == 'OPEN':
        arguments = {'claim': proposal['evidence'], 'result': proposal['outcome'], 'bond_receipt': bond_receipt}
    elif action in ('AGREE', 'VOTE'):
        arguments = {'result': proposal['outcome']}
    elif action == 'CHALLENGE':
        next_round = state['round'] + 1 if state['round'] is not None else -1
        a.need(0 <= next_round < len(policy['configuration']['stages']), 'SERVICE_APPEAL_STAGE')
        optimistic = policy['configuration']['stages'][next_round]['mode'] == 'OPTIMISTIC'
        arguments = {'evidence': proposal['evidence'], 'bond_receipt': bond_receipt,
                     'result': proposal['outcome'] if optimistic else None}
    else:
        a.need(action in ('FINALIZE', 'CLOSE_UNRESOLVED'), 'SERVICE_AWARD_ACTION'); arguments = {}
    payload = procedures.event_payload(policy, adoptions, events, actor, action, arguments, at)
    return {**payload, 'rationale_binding': 'SEPARATE_FINAL_AWARD_SIGNATURE_REQUIRED; PROCEDURE_EVENT_BINDS_ONLY_ITS_EXACT_ARGUMENTS', **FLAGS}


def _proposal(value):
    a.fields(value, 'version total paid paid_share refunded_minor outcome reasons evidence appeal_of precedents status precedent_effect execution_authorized payment_authorized funds_reserved refund_executed current_authority_verified')
    a.need(type(value) is dict and type(value.get('total')) is dict and type(value.get('paid')) is dict, 'SERVICE_AWARD_PROPOSAL')
    terms._money(value['total']); terms._money(value['paid'])
    rebuilt = terms.partial_award(value['total']['amount'], value['paid']['amount'], value['total']['unit'],
        value['total']['exponent'], value['reasons'], value['evidence'], value['appeal_of'], value['precedents'])
    a.need(a.canonical(value) == a.canonical(rebuilt), 'SERVICE_AWARD_PROPOSAL_CHANGED')


def prepare_award(policy, adoptions, events, expected_head, proposal, case, title, issued, seat, method, tribunal,
                  threshold, agreement_reference, clause):
    """Use existing canonical award/PDF preparer after the exact adopted ladder finalises."""
    from . import award_documents
    _proposal(proposal)
    state = procedures.replay(policy, adoptions, events, expected_head)
    a.need(policy['kind'] == 'ESCALATION' and state['status'] == 'FINAL_ATTESTED_OUTCOME' and
           a.canonical(state['outcome']) == a.canonical(proposal['outcome']), 'SERVICE_AWARD_NOT_FINAL_OR_MISMATCH')
    stage = policy['configuration']['stages'][state['round']]
    a.need(stage['mode'] == 'JUDGMENT' and type(tribunal) is list and
           all(type(row) is dict and type(row.get('key')) is str for row in tribunal) and
           {row['key'] for row in tribunal} == {policy['parties'][role] for role in stage['deciders']} and
           type(threshold) is int and threshold >= stage['quorum'], 'SERVICE_AWARD_TRIBUNAL_NOT_ADOPTED')
    body = {'version': award_documents.VERSION, 'case': case, 'title': title, 'issued': issued, 'seat': seat, 'method': method,
            'parties': [{'role': role, 'name': role, 'key': policy['parties'][role]} for role in policy['configuration']['disputants']],
            'tribunal': tribunal, 'threshold': threshold,
            'basis': {'kind': 'PROCEDURE', 'reference': state['policy'], 'head': state['head']},
            'agreement': {'reference': agreement_reference, 'clause': clause},
            'sections': [{'heading': 'Reasons and exact allocation', 'paragraphs': [proposal['reasons'],
                         'Paid minor units: ' + str(proposal['paid']['minor']) + '; refunded minor units: ' + str(proposal['refunded_minor']) +
                         '; original total minor units: ' + str(proposal['total']['minor']) + '.', 'Evidence reference: ' + proposal['evidence']]},
                         {'heading': 'Appeal and precedent references', 'paragraphs': [
                          'Appeal of: ' + (proposal['appeal_of'] or 'none declared') + '.',
                          'Precedent references: ' + (', '.join(proposal['precedents']) or 'none declared') + '. References do not establish binding legal authority.' ]}],
            'outcome': deepcopy(proposal['outcome']), 'escrow_effect': 'DECIDED_BY_AAP_TERMS_AND_LADDER'}
    return {**award_documents.prepare(body), 'status': 'UNSIGNED_CANONICAL_AWARD; TRIBUNAL_SIGNATURES_REQUIRED',
            'conservation': 'PAID_PLUS_REFUNDED_EQUALS_ORIGINAL_TOTAL',
            'agreement_reference_scope': 'DECLARED_REFERENCE; EXTERNAL_JURISDICTION_AND_LEGAL_EFFECT_NOT_VERIFIED', **FLAGS}


def schemas():
    """Exact action envelopes; adopted engine validators enforce nested semantics."""
    shapes = terms.schemas()
    def obj(props, required=None):
        return {'type': 'object', 'properties': props, 'required': list(props) if required is None else required, 'additionalProperties': False}
    def array(item, maximum=256): return {'type': 'array', 'items': item, 'maxItems': maximum}
    def nullable(item): return {'anyOf': [item, {'type': 'null'}]}
    raw = {'type': 'object', 'maxProperties': 64}
    text = {'type': 'string', 'minLength': 1, 'maxLength': 4096}
    name = {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.:-]{0,63}$'}
    ref = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
    integer = {'type': 'integer', 'minimum': 0, 'maximum': 2**53-1}
    decimal = {'type': 'string', 'maxLength': 32, 'pattern': '^(?:0|[1-9][0-9]*)(?:\\.[0-9]{1,9})?$'}
    signature = {'type': 'string', 'pattern': '^[0-9a-f]{128}$'}
    master_proofs = array(obj({'party': name, 'signature': signature}), 2)
    calloff_proofs = array(obj({'concept': ref, 'party': name, 'signature': signature}), 16)
    procedure_proofs = array(obj({'party': name, 'signature': {'anyOf': [signature, raw]}}), 16)
    history = array(raw, terms.MAX_EVENTS)
    procedure_events = array(raw, procedures.MAX_EVENTS)
    common = {'master': shapes['master'], 'master_approvals': master_proofs, 'events': history, 'expected_master': ref, 'expected_head': ref}
    procedure = {'policy': raw, 'adoptions': procedure_proofs, 'events': procedure_events}
    actions = {
        'simple_job': obj({'customer': ref, 'provider': ref, 'context': ref, 'description': text, 'amount': nullable(decimal),
                           'unit': {**text, 'maxLength': 64}, 'exponent': {'type': 'integer', 'minimum': 0, 'maximum': 9},
                           'source': nullable({'type': 'string', 'maxLength': 8192})},
                          ['customer', 'provider', 'context', 'description', 'amount', 'unit']),
        'prepare_calloff': obj({'master': shapes['master'], 'calloff': shapes['calloff']}),
        'owner_package': obj({'master': shapes['master'], 'master_approvals': master_proofs,
                              'calloff': nullable(shapes['calloff']), 'calloff_approvals': calloff_proofs}, ['master']),
        'replay': obj(common, ['master', 'master_approvals', 'events', 'expected_master']),
        'allocate': obj({**common, 'calloff': shapes['calloff'], 'approvals': calloff_proofs, 'expected_order': ref}),
        'cancel': obj({**common, 'cancellation': shapes['cancellation'], 'approvals': master_proofs, 'expected_id': ref}),
        'competition': obj({'title': {**text, 'maxLength': 256}, 'parties': raw, 'principal': name, 'context': ref,
                             'configuration': raw, 'mode': {'type': 'string', 'enum': ['TENDER', 'CONTEST']},
                             'exponent': {'type': 'integer', 'minimum': 0, 'maximum': 9}},
                            ['title', 'parties', 'principal', 'context', 'configuration']),
        'competition_offer': obj({'policy': raw, 'bidder': name, 'amount': decimal, 'deliver_by': integer,
                                   'offer_terms': raw, 'acceptance': raw}),
        'competition_replay': obj({**procedure, 'expected_head': ref}, list(procedure)),
        'competition_event': obj({**procedure, 'actor': name,
                                   'action': {'type': 'string', 'enum': ['PROPOSE', 'COUNTER', 'COMMIT', 'REVEAL', 'SELECT']},
                                   'arguments': raw, 'at': integer}),
        'competition_advance': obj({**procedure, 'event': raw}),
        'selected_calloff': obj({**procedure, 'expected_head': ref, 'master': shapes['master'], 'nonce': name, 'context': ref,
                                 'issued_at': integer, 'specification': text, 'source': nullable({'type': 'string', 'maxLength': 8192})},
                                [*procedure, 'expected_head', 'master', 'nonce', 'context', 'issued_at', 'specification']),
        'award_event': obj({**procedure, 'proposal': shapes['partial_award'], 'actor': name,
                             'action': {'type': 'string', 'enum': ['OPEN', 'AGREE', 'VOTE', 'CHALLENGE', 'FINALIZE', 'CLOSE_UNRESOLVED']},
                             'at': integer, 'bond_receipt': nullable(ref)}, [*procedure, 'proposal', 'actor', 'action', 'at']),
        'prepare_award': obj({**procedure, 'expected_head': ref, 'proposal': shapes['partial_award'], 'case': {**text, 'maxLength': 128},
                               'title': {**text, 'maxLength': 200}, 'issued': {'type': 'string', 'pattern': '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$'},
                               'seat': nullable({**text, 'maxLength': 128}),
                               'method': {'type': 'string', 'enum': ['BINDING_ARBITRATION', 'EXPERT_DETERMINATION', 'HYBRID', 'MEDIATION']},
                               'tribunal': array(obj({'name': {**text, 'maxLength': 128}, 'key': ref}), 16),
                               'threshold': {'type': 'integer', 'minimum': 1, 'maximum': 16}, 'agreement_reference': ref,
                               'clause': {**text, 'maxLength': 2000}})}
    return {'actions': actions, 'terms_actions': shapes['actions'],
            'nested_protocols': {'marketplace': marketplace.VERSION, 'procedure': procedures.VERSION, 'legal': legal.VERSION},
            'runtime_checks': 'SCHEMA_IS_SHAPE_ONLY; ACTUAL_NATIVE_SIGNATURE_RULES_AND_BUDGET_HISTORY_REPLAY_REQUIRED',
            'private_storage_actions': 'NOT_EXPOSED_BY_THIS_SCHEMA; SERVICEBOOK_REQUIRES_OWNER_CONFIGURED_SDK_CUSTODY'}


def describe():
    return {'version': VERSION, 'terms': terms.describe(),
            'actions': {'simple_job': ['customer', 'provider', 'context', 'description', 'amount', 'unit', 'exponent', 'source'],
                        'prepare_calloff': ['master', 'calloff'], 'owner_package': ['master', 'master_approvals', 'calloff', 'calloff_approvals'],
                        'replay': ['master', 'master_approvals', 'events', 'expected_master', 'expected_head'],
                        'allocate': ['master', 'master_approvals', 'events', 'calloff', 'approvals', 'expected_master', 'expected_order', 'expected_head'],
                        'cancel': ['master', 'master_approvals', 'events', 'cancellation', 'approvals', 'expected_master', 'expected_id', 'expected_head'],
                        'competition': ['title', 'parties', 'principal', 'context', 'configuration', 'mode', 'exponent'],
                        'competition_offer': ['policy', 'bidder', 'amount', 'deliver_by', 'offer_terms', 'acceptance'],
                        'competition_replay': ['policy', 'adoptions', 'events', 'expected_head'],
                        'competition_event': ['policy', 'adoptions', 'events', 'actor', 'action', 'arguments', 'at'],
                        'competition_advance': ['policy', 'adoptions', 'events', 'event'],
                        'selected_calloff': ['policy', 'adoptions', 'events', 'expected_head', 'master', 'nonce', 'context', 'issued_at', 'specification', 'source'],
                        'award_event': ['policy', 'adoptions', 'events', 'proposal', 'actor', 'action', 'at', 'bond_receipt'],
                        'prepare_award': ['policy', 'adoptions', 'events', 'expected_head', 'proposal', 'case', 'title', 'issued', 'seat', 'method', 'tribunal', 'threshold', 'agreement_reference', 'clause']},
            'schemas': schemas(),
            'existing_engines': ['legal_composition', 'marketplace', 'agreement_procedures', 'WorkflowStore', 'portable_agreements', 'owner_handoff', 'award_documents'],
            'store': 'ServiceBook is owner-local SDK only; MCP inputs cannot choose/open private custody directories',
            'limits': ['256 local events', 'caller-retained master/head; cloned stores cannot share a global cap',
                       'cancellation releases local allocation only; actual money/refund/dispatch status remains unknown',
                       'selection is not assent, authority, prize funding or performance evidence',
                       'partial outcomes must be explicitly adopted in the existing ladder; native frozen changes require a versioned successor'], **FLAGS}
