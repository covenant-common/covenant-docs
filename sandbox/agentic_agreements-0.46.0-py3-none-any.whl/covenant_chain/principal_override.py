"""Principal override of an agent acting under a mandate.

Off unless genesis sets ``features.principal_override`` and the block height
has reached ``activation``. Before that, caller-visible errors and state
match the previous rules.

A principal publishes one policy per resource: a spend limit, an open-commitment
limit, the counterparties and categories the agent may bind, an approval
threshold, and the cancellation fee the counterparty keeps if the principal
reverses. BIND enforces the policy. Within ``window`` blocks of formation the
principal may reverse a still-BOUND agreement. The counterparty receives only
the fee both sides assented to. After delivery (the effect is authorized) the
same call is refused: there is no clawback.
"""
from copy import deepcopy

from .crypto import exact, integer, key, need
from .feature_gate import PRINCIPAL, active, feature


def terms_suffix(state, terms, height):
    if active(state, PRINCIPAL, height) and terms.get('mandate') is not None:
        return ' cancellation_fee'
    return ''


def _policies(state):
    found = state.get('principal_policies')
    if found is None:
        found = {}
        state['principal_policies'] = found
    return found


def policy_for(state, principal, resource):
    return _policies(state).get(principal, {}).get(resource)


def evidence_actors(state, terms, height):
    actors = {terms['agent'], terms['counterparty'], terms['resolver'], terms['appeal_resolver']}
    if active(state, PRINCIPAL, height):
        actors.add(terms['principal'])
    return actors


def challenge_actors(state, terms, height):
    actors = {terms['agent'], terms['counterparty']}
    if active(state, PRINCIPAL, height):
        actors.add(terms['principal'])
    return actors


def required_signers(state, terms, height):
    signers = {terms['agent'], terms['counterparty']}
    if not active(state, PRINCIPAL, height) or terms.get('mandate') is None:
        return signers
    policy = policy_for(state, terms['principal'], terms['resource'])
    need(policy is not None, 'PRINCIPAL_POLICY')
    if terms['quantity'] > policy['approval_above']:
        signers.add(terms['principal'])
    return signers


def enforce_bind(state, terms, height):
    """Reject an agent BIND that falls outside the principal's policy."""
    if not active(state, PRINCIPAL, height) or terms.get('mandate') is None:
        return
    policy = policy_for(state, terms['principal'], terms['resource'])
    need(policy is not None, 'PRINCIPAL_POLICY')
    need(terms['quantity'] <= policy['spend_limit'], 'SPEND_LIMIT')
    need(terms['profile'] in policy['categories'], 'CATEGORY_DENIED')
    need(terms['counterparty'] in policy['counterparties'], 'COUNTERPARTY_DENIED')
    need(terms['cancellation_fee'] == policy['cancellation_fee'], 'CANCELLATION_FEE')
    need(terms['cancellation_fee'] <= terms['quantity'], 'CANCELLATION_FEE')
    held = 0
    for agreement in state['agreements'].values():
        previous = agreement['terms']
        if agreement['held'] and previous['principal'] == terms['principal'] and previous['resource'] == terms['resource']:
            held += previous['quantity']
    need(held + terms['quantity'] <= policy['open_limit'], 'OPEN_LIMIT')


def _adopt(state, payload, actor):
    exact(payload, 'resource spend_limit open_limit counterparties categories approval_above cancellation_fee')
    need(payload['resource'] in state['resources'], 'RESOURCE')
    integer(payload['spend_limit'], True)
    integer(payload['open_limit'], True)
    need(payload['open_limit'] >= payload['spend_limit'], 'OPEN_LIMIT')
    integer(payload['approval_above'])
    cap = feature(state, PRINCIPAL)['max_cancellation_fee']
    integer(payload['cancellation_fee'])
    need(payload['cancellation_fee'] <= cap and payload['cancellation_fee'] <= payload['spend_limit'], 'CANCELLATION_FEE')
    parties = payload['counterparties']
    need(type(parties) is list and 1 <= len(parties) <= 32 and parties == sorted(set(parties)), 'COUNTERPARTY_DENIED')
    for party in parties:
        key(party)
    categories = payload['categories']
    need(type(categories) is list and 1 <= len(categories) <= 32 and categories == sorted(set(categories)), 'CATEGORY_DENIED')
    for category in categories:
        need(type(category) is str and category in state['profiles'], 'CATEGORY_DENIED')
    _policies(state).setdefault(actor, {})[payload['resource']] = deepcopy(payload)
    return []


def _reverse(state, payload, actor, tid, height):
    from .app import add
    exact(payload, 'agreement')
    need(payload['agreement'] in state['agreements'], 'AGREEMENT')
    agreement = state['agreements'][payload['agreement']]
    terms = agreement['terms']
    delivered = (not agreement['held']) or agreement.get('effect_id') is not None or agreement['state'] in {
        'AUTHORIZED', 'RELEASED', 'MUTUALLY_DISCHARGED'}
    if delivered:
        raise ValueError('NO_CLAWBACK')
    need(agreement['state'] == 'BOUND' and agreement['decision'] is None, 'NOT_REVERSIBLE')
    need(actor == terms['principal'] and terms['principal'] != terms['agent'], 'PRINCIPAL_AUTHORITY')
    need('cancellation_fee' in terms, 'NOT_REVERSIBLE')
    window = feature(state, PRINCIPAL)['window']
    need(agreement['height'] <= height <= agreement['height'] + window, 'OVERRIDE_WINDOW')
    fee = terms['cancellation_fee']
    rest = terms['quantity'] - fee
    resource = terms['resource']
    if fee:
        add(state['balances'], terms['counterparty'], resource, fee)
        add(state['authority_available'], terms['counterparty'], resource, fee)
    if rest:
        add(state['balances'], terms['principal'], resource, rest)
        if terms['mandate'] is None:
            add(state['authority_available'], terms['principal'], resource, rest)
        else:
            grant = state['grants'][terms['mandate']]
            grant['remaining'] += rest
            integer(grant['remaining'])
    agreement['held'] = False
    agreement['state'] = 'PRINCIPAL_REVERSED'
    agreement['history'].append(tid)
    parents = [agreement['formation']]
    if terms['mandate'] is not None:
        parents.append(terms['mandate'])
    return parents


def apply_principal(state, op, payload, actor, tid, height):
    if not active(state, PRINCIPAL, height):
        raise ValueError('UNKNOWN_OPERATION')
    if op == 'ADOPT_PRINCIPAL_POLICY':
        return _adopt(state, payload, actor)
    if op == 'PRINCIPAL_REVERSE':
        return _reverse(state, payload, actor, tid, height)
    raise ValueError('UNKNOWN_OPERATION')
