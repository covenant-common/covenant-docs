"""Explicit owner-local custody for unchanged, offline portable agreements.

This is a trusted local owner's control surface, never an agent signing tool.
Native signed profiles, meanings, labels and verification remain unchanged.
"""
from copy import deepcopy
from contextlib import contextmanager
import base64
import fcntl
import json
import os
from pathlib import Path
import re
import secrets
import stat
import threading
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from . import coordination_review as review, portable_agreements as portable
from .crypto import need, public_key, sign as native_sign, verify, valid_ed25519_key
from covenant_language import capsules, external_drafts as external
from covenant_language.safe_io import atomic_write
from covenant_language import frame_concepts as concepts, marketplace, legal_composition

VERSION = 'covenant-owner-handoff/0.1'
MAX_RECORD_BYTES = portable.MAX_BYTES + 524288
MAX_RECEIPTS = 128
REVIEW_SECONDS = 600
SUPPORTED = ('EXTERNAL', 'CONCEPT', 'ORDER', 'LEGAL')
SYNTHETIC_KEYS = frozenset((
    '66be7e332c7a453332bd9d0a7f7db055f5c5ef1a06ada66d98b39fb6810c473a',
    '0b513ad9b4924015ca0902ed079044d3ac5dbec2306f06948c10da8eb6e39f2d'))


def _fields(value, required, optional=()):
    need(type(value) is dict and set(required) <= set(value) <= set(required) | set(optional),
         'HANDOFF_FIELDS')


def _pin(value, nullable=False):
    need((nullable and value is None) or
         (type(value) is str and re.fullmatch('[0-9a-f]{64}', value)), 'HANDOFF_PACKAGE_PIN')


def _private(fd, directory=False):
    info = os.fstat(fd)
    need((stat.S_ISDIR(info.st_mode) if directory else
          stat.S_ISREG(info.st_mode) and info.st_nlink == 1)
         and info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) & 0o077 == 0,
         'HANDOFF_PRIVATE_DIRECTORY' if directory else 'HANDOFF_PRIVATE_FILE')
    return info


def _stamp(info):
    return [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]


def _roles(payload):
    if 'required_assents' in payload:
        return deepcopy(payload['required_assents'])
    return [{'concept': None, 'party': party, 'identity': identity, 'body': payload['body']}
            for party, identity in sorted(payload['required_parties'].items())]


def _role_key(role):
    return role.get('concept'), role['party']


def _ordered_proofs(proofs):
    """Deterministic owner-produced proof set; native signed bodies stay exact."""
    return sorted(proofs, key=lambda proof: (proof.get('concept') or '', proof['party']))


def _checked(package):
    """Additional owner-action eligibility, not a historical verifier change."""
    ref = portable.identifier(package)
    checked = portable.inspect(package, ref)
    result = {}
    for row in package['case']['agreements']:
        kind = row['kind']
        need(kind in SUPPORTED, 'HANDOFF_UNSUPPORTED_' + kind + '_USE_NATIVE_REVIEW')
        data, obj = review._agreement(row, package['case']['version'])
        payload = data['required_assent']
        roles = _roles(payload)
        required = {_role_key(role): role for role in roles}
        need(len(required) == len(roles), 'HANDOFF_DUPLICATE_REQUIRED_ROLE')
        proofs = row['approvals']
        need(type(proofs) is list and len(proofs) <= len(roles), 'HANDOFF_PROOF_SET')
        seen = set()
        for proof in proofs:
            fields = ('party', 'signature') if kind == 'LEGAL' else ('concept', 'party', 'signature')
            _fields(proof, fields)
            key = _role_key(proof)
            need(type(key[1]) is str and (key[0] is None or type(key[0]) is str), 'HANDOFF_PROOF_ROLE')
            need(key in required, 'HANDOFF_UNKNOWN_PROOF_ROLE')
            need(key not in seen, 'HANDOFF_DUPLICATE_PROOF_ROLE')
            verify(required[key]['identity'], payload['label'], required[key]['body'], proof['signature'])
            seen.add(key)
        # A partial set is expected, but a complete set must pass its native verifier.
        if len(seen) == len(roles) and roles:
            need(data['status'] == 'VERIFIED', 'HANDOFF_NATIVE_ASSENT_REFUSED')
        compact = next(item for item in checked['agreements'] if item['item'] == row['id'])
        eligible = (bool(roles) and payload.get('root_has_parties', True)
                    and not any(type(r['identity']) is str and r['identity'] in SYNTHETIC_KEYS for r in roles)
                    and compact['closure']['status'] in ('COMPLETE', 'ROOT_OBJECT_COMPLETE'))
        result[row['id']] = (row, payload, roles, seen, obj, eligible)
    return ref, checked, result


def _sources(package, row):
    """Open every reachable byte document, including child concept documents."""
    if row['kind'] not in ('EXTERNAL', 'CONCEPT', 'ORDER'):
        return []
    bundle = row['bundle'] if row['kind'] != 'ORDER' else marketplace.order_review(row['order'])['prepared']['bundle']
    resolved = concepts.resolve(**bundle)
    used = {(item['kind'], item['id']) for item in resolved['manifest']['artifacts']}
    caps = {capsules.capsule_id(item['value']): item for item in bundle['artifacts'] if item['kind'] == 'capsule'}
    sources = []
    for ref, artifact in sorted(caps.items()):
        cap = artifact['value']
        if ('capsule', ref) not in used or cap['language'] != external.VERSION:
            continue
        document = {'version': external.VERSION, 'root': ref,
                    'artifacts': [caps[key] for key in sorted({ref, *cap['dependencies']})]}
        opened = external.inspect(document, ref)
        raw = base64.b64decode(opened['source_base64'])
        try:
            source, encoding = raw.decode('utf-8'), 'UTF8'
        except UnicodeError:
            source, encoding = opened['source_base64'], 'BASE64'
        sources.append({'agreement': row['id'], 'document': opened['manifest']['title'],
                        'document_id': ref, 'source': source, 'encoding': encoding,
                        'source_sha256': opened['manifest']['sha256'], 'manifest': opened['manifest'],
                        'execution_authorized': False})
    return sources


def _structured_terms(package, row):
    if row['kind'] != 'LEGAL':
        return deepcopy(row.get('bundle', row.get('order')))
    objects = {legal_composition.identifier(r['module']): r['module']
               for r in package['case']['agreements'] if r['kind'] == 'LEGAL'}
    root = row['expected_id']
    pending = [(root, r['module'], r['term']) for r in objects[root]['roots']]
    visited, included = set(), {root}
    while pending:
        current, owner, label = pending.pop()
        owner = current if owner == 'SELF' else owner
        if (owner, label) in visited:
            continue
        need(len(visited) < 256, 'HANDOFF_LEGAL_REVIEW_TRAVERSAL_LIMIT')
        need(owner in objects and label in objects[owner]['definitions'],
             'HANDOFF_LEGAL_REVIEW_REFERENCE_MISSING')
        visited.add((owner, label))
        included.add(owner)
        pending.extend((owner, r['module'], r['term'])
                       for r in objects[owner]['definitions'][label]['references'])
    return {'root': root, 'modules': [{'id': ref, 'module': deepcopy(objects[ref]),
             'relation': 'SELECTED_ROOT' if ref == root else 'REFERENCED_MODULE'} for ref in sorted(included)],
            'visited_terms': len(visited), 'scope': 'THIS_EXACT_MODULE_AND_REFERENCES_NOT_ASSENT_BY_CHILD_MODULE_PARTIES',
            'interpretation': 'EXACT_INERT_MODULES; NO_LEGAL_EVALUATION_OR_EXECUTION'}


class HandoffSession:
    """One owner-private home, one process, explicit roles, atomic CAS updates."""
    def __init__(self, home):
        self.home = Path(home).expanduser().absolute()
        need(not self.home.is_symlink(), 'HANDOFF_PRIVATE_DIRECTORY')
        self.home.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self._closed = False
        self._reviews = {}
        self._dir = os.open(self.home, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            _private(self._dir, directory=True)
            self._fd = os.open('.handoff.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK,
                               0o600, dir_fd=self._dir)
            try:
                _private(self._fd)
                fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BaseException:
                os.close(self._fd)
                raise ValueError('HANDOFF_HOME_IN_USE') from None
        except BaseException:
            os.close(self._dir)
            self._closed = True
            raise

    def close(self):
        with self.lock:
            if not self._closed:
                self._reviews.clear()
                fcntl.flock(self._fd, fcntl.LOCK_UN)
                os.close(self._fd)
                os.close(self._dir)
                self._closed = True

    @contextmanager
    def _guard(self):
        with self.lock:
            need(not self._closed, 'HANDOFF_CLOSED')
            current = os.stat(self.home, follow_symlinks=False)
            actual = _private(self._dir, directory=True)
            need(stat.S_ISDIR(current.st_mode) and (current.st_dev, current.st_ino) ==
                 (actual.st_dev, actual.st_ino), 'HANDOFF_HOME_CHANGED')
            lock_info = os.stat('.handoff.lock', dir_fd=self._dir, follow_symlinks=False)
            locked = _private(self._fd)
            need((lock_info.st_dev, lock_info.st_ino) == (locked.st_dev, locked.st_ino),
                 'HANDOFF_LOCK_CHANGED')
            yield

    def _read(self, name, limit=MAX_RECORD_BYTES):
        try:
            fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=self._dir)
        except FileNotFoundError:
            return None
        except OSError:
            raise ValueError('HANDOFF_PRIVATE_FILE') from None
        try:
            before = _private(fd)
            need(before.st_size <= limit, 'HANDOFF_STORAGE_SIZE')
            chunks, remaining = [], limit + 1
            while remaining:
                chunk = os.read(fd, min(65536, remaining))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
            raw = b''.join(chunks)
            need(len(raw) <= limit and _stamp(before) == _stamp(_private(fd)), 'HANDOFF_STORAGE_CHANGED')
            return raw
        finally:
            os.close(fd)

    def _write(self, name, raw):
        need(type(raw) is bytes and len(raw) <= MAX_RECORD_BYTES, 'HANDOFF_STORAGE_SIZE')
        self._read(name)
        temporary = '.' + name + '.' + secrets.token_hex(16)
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=self._dir)
        try:
            with os.fdopen(fd, 'wb', closefd=False) as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(fd)
            os.replace(temporary, name, src_dir_fd=self._dir, dst_dir_fd=self._dir)
            os.fsync(self._dir)
        finally:
            os.close(fd)
            try:
                os.unlink(temporary, dir_fd=self._dir)
            except FileNotFoundError:
                pass

    def _key(self):
        try:
            fd = os.open('identity.hex', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=self._dir)
        except FileNotFoundError:
            return None, None
        except OSError:
            raise ValueError('HANDOFF_KEY_FILE') from None
        try:
            before = _private(fd)
            need(64 <= before.st_size <= 65, 'HANDOFF_KEY_FILE')
            raw = os.read(fd, 66)
            secret = raw[:-1] if raw.endswith(b'\n') else raw
            need(len(secret) == 64 and all(c in b'0123456789abcdef' for c in secret), 'HANDOFF_KEY_FILE')
            after = _private(fd)
            named = os.stat('identity.hex', dir_fd=self._dir, follow_symlinks=False)
            need(_stamp(before) == _stamp(after) == _stamp(named), 'HANDOFF_KEY_CHANGED')
            return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(secret.decode('ascii'))), _stamp(after)
        finally:
            os.close(fd)

    def _record(self):
        raw = self._read('handoff.json')
        if raw is None:
            return {'version': VERSION, 'identity_public': None, 'package': None,
                    'receipts': {}, 'last_signature': None, 'generation': 0}
        def pairs(items):
            value = {}
            for key, item in items:
                need(key not in value, 'HANDOFF_STORAGE_DUPLICATE')
                value[key] = item
            return value
        def invalid(_):
            raise ValueError('HANDOFF_STORAGE_JSON')
        try:
            record = json.loads(raw, object_pairs_hook=pairs, parse_float=invalid, parse_constant=invalid)
        except (UnicodeError, json.JSONDecodeError, RecursionError):
            raise ValueError('HANDOFF_STORAGE_JSON') from None
        _fields(record, ('version', 'identity_public', 'package', 'receipts', 'last_signature', 'generation'))
        need(record['version'] == VERSION and type(record['generation']) is int and record['generation'] >= 0,
             'HANDOFF_STORAGE_VERSION')
        _pin(record['identity_public'], nullable=True)
        need(type(record['receipts']) is dict and len(record['receipts']) <= MAX_RECEIPTS, 'HANDOFF_RECEIPTS')
        for token, receipt in record['receipts'].items():
            _pin(token)
            _fields(receipt, ('review_id', 'package_id', 'previous_package_id', 'agreement', 'roles', 'identity_public', 'signed_at', 'sequence'))
            need(receipt['review_id'] == token, 'HANDOFF_RECEIPT_CHANGED')
            for field in ('package_id', 'previous_package_id', 'identity_public'):
                _pin(receipt[field])
            need(receipt['identity_public'] == record['identity_public'] and
                 type(receipt['sequence']) is int and 0 < receipt['sequence'] <= record['generation'] and
                 type(receipt['signed_at']) is int and receipt['signed_at'] >= 0, 'HANDOFF_RECEIPT_CHANGED')
            review._name(receipt['agreement'])
            need(type(receipt['roles']) is list and 0 < len(receipt['roles']) <= 256, 'HANDOFF_RECEIPT_CHANGED')
            for role in receipt['roles']:
                _fields(role, ('concept', 'party'))
                _pin(role['concept'], nullable=True)
                review._name(role['party'])
            portable.canonical(receipt)
        need(record['last_signature'] is None or record['last_signature'] in record['receipts'], 'HANDOFF_RECEIPTS')
        if record['package'] is not None:
            portable.identifier(record['package'])
        return record

    def _save(self, record):
        while True:
            raw = json.dumps(record, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode('ascii')
            if len(raw) <= MAX_RECORD_BYTES or len(record['receipts']) <= 1:
                break
            oldest = min(record['receipts'], key=lambda item: record['receipts'][item]['sequence'])
            del record['receipts'][oldest]
        self._write('handoff.json', raw)

    def _identity(self, record):
        key, stamp = self._key()
        public = public_key(key) if key is not None else None
        expected = record['identity_public']
        if expected is not None:
            need(public is not None, 'HANDOFF_KEY_MISSING_RESTORE_EXISTING_CUSTODY')
            need(public == expected, 'HANDOFF_KEY_CHANGED')
        return key, public, stamp

    def _cas(self, record, expected):
        _pin(expected, nullable=True)
        actual = portable.identifier(record['package']) if record['package'] is not None else None
        need(actual == expected, 'HANDOFF_PACKAGE_CHANGED')
        return actual

    def _state(self, record):
        custody_codes = {'HANDOFF_KEY_FILE', 'HANDOFF_PRIVATE_FILE', 'HANDOFF_KEY_CHANGED',
                         'HANDOFF_KEY_MISSING_RESTORE_EXISTING_CUSTODY'}
        try:
            _, public, _ = self._identity(record)
            custody = {'status': 'AVAILABLE' if public is not None else 'NOT_CREATED', 'code': None}
            if public is not None and record['identity_public'] is None:
                public = None
                custody = {'status': 'AWAITING_EXPLICIT_ADOPTION', 'code': 'HANDOFF_IDENTITY_CREATE_EXPLICITLY'}
        except ValueError as error:
            if str(error) not in custody_codes:
                raise
            public = None
            custody = {'status': 'UNAVAILABLE', 'code': str(error)}
        except OSError:
            public = None
            custody = {'status': 'UNAVAILABLE', 'code': 'HANDOFF_KEY_FILE'}
        package = record['package']
        ref, compact, checked = _checked(package) if package is not None else (None, None, {})
        agreements = []
        for name, (row, payload, roles, seen, obj, eligible) in checked.items():
            sample_identity = any(type(r['identity']) is str and r['identity'] in SYNTHETIC_KEYS for r in roles)
            agreements.append({'item': name, 'kind': row['kind'], 'id': row['expected_id'],
                               'title': obj.get('title', name), 'supported': True,
                               'sample_identity_present': sample_identity,
                               'signing_status': ('KNOWN_SAMPLE_IDENTITY_REQUIRES_REPLACEMENT' if sample_identity else
                                                  'UNRESOLVED_DEPENDENCIES_OR_ROLES' if not eligible else
                                                  'ALL_REQUIRED_ASSENTS_VERIFIED' if len(seen) == len(roles) else
                                                  'PARTIAL_ASSENT' if seen else 'AWAITING_SIGNATURES'),
                               'signed_count': len(seen), 'required_count': len(roles),
                               'remaining_roles': [{'concept': r.get('concept'), 'party': r['party']}
                                                   for r in roles if _role_key(r) not in seen],
                               'roles': [{'concept': role.get('concept'), 'party': role['party'],
                                          'identity': deepcopy(role['identity']),
                                          'status': 'VALID_ROLE_SIGNATURE' if _role_key(role) in seen else 'MISSING_ROLE_SIGNATURE',
                                          'eligible': eligible and role['identity'] == public and _role_key(role) not in seen}
                                         for role in roles]})
        last = record['receipts'].get(record['last_signature'])
        if package is None:
            next_actions = ['Draft with actual party public keys or receive an independently pinned package.']
        elif any(a['sample_identity_present'] for a in agreements):
            next_actions = ['A known public sample key appears in this package. Retain it for inspection, then draft with actual party keys and obtain fresh assent. Owner signing is disabled for affected agreements.']
        elif any(r['eligible'] for a in agreements for r in a['roles']):
            next_actions = ['Review the exact agreement and explicitly select your roles before signing.']
        elif all(a['signing_status'] == 'ALL_REQUIRED_ASSENTS_VERIFIED' for a in agreements):
            next_actions = ['All required assents verified. Retain the package; separately check authority, performance, payment and remaining obligations.']
        else:
            next_actions = ['Inspect outstanding roles or unresolved dependencies; other parties sign using their own custody.']
        if package is not None:
            next_actions.append('Export the plaintext package explicitly and communicate its pin independently.')
        return {'version': VERSION, 'identity_public': public,
                'expected_identity_public': record['identity_public'], 'custody': custody, 'package_id': ref,
                'review': compact, 'agreements': agreements, 'last_signature': deepcopy(last),
                'next_actions': (['Restore the existing private identity file through the owner operating system; review and export remain available.']
                                 if custody['status'] == 'UNAVAILABLE' else
                                 ['Create a local identity explicitly to sign.'] if public is None else []) +
                 next_actions,
                'execution_authorized': False}

    def state(self):
        with self._guard():
            return self._state(self._record())

    def create_identity(self, payload):
        _fields(payload, ('confirm',))
        need(payload['confirm'] is True, 'HANDOFF_CONFIRM_REQUIRED')
        with self._guard():
            record = self._record()
            key, public, _ = self._identity(record)
            if key is None:
                key = Ed25519PrivateKey.generate()
                raw = key.private_bytes_raw().hex().encode('ascii') + b'\n'
                atomic_write('identity.hex', raw, mode=0o600, exclusive=True, dir_fd=self._dir)
                public = public_key(key)
            if record['identity_public'] is None:
                record['identity_public'] = public
                record['generation'] += 1
                self._save(record)
                self._reviews.clear()
            return self._state(record)

    def _adopt(self, record, package):
        _checked(package)
        record['package'] = deepcopy(package)
        record['generation'] += 1
        self._save(record)
        self._reviews.clear()
        return self._state(record)

    def draft(self, payload):
        _fields(payload, ('title', 'terms', 'parties', 'context', 'expected_package_id'), ('previous_agreement',))
        portable.canonical(payload)
        need(type(payload['parties']) is dict and 1 <= len(payload['parties']) <= 64, 'HANDOFF_PARTIES_REQUIRED')
        for identity in payload['parties'].values():
            need(type(identity) is str and valid_ed25519_key(identity), 'HANDOFF_ACTUAL_PUBLIC_KEY_REQUIRED')
            need(identity not in SYNTHETIC_KEYS, 'HANDOFF_SYNTHETIC_KEY_REPLACE_WITH_ACTUAL_PARTY')
        need(type(payload['terms']) is str and 0 < len(payload['terms'].encode('utf-8')) <= external.MAX_BYTES, 'HANDOFF_TERMS_SIZE')
        with self._guard():
            record = self._record()
            self._identity(record)
            self._cas(record, payload['expected_package_id'])
            previous = None
            if 'previous_agreement' in payload:
                need(record['package'] is not None and type(payload['previous_agreement']) is str,
                     'HANDOFF_PREDECESSOR_REQUIRED')
                _, _, existing = _checked(record['package'])
                need(payload['previous_agreement'] in existing, 'HANDOFF_PREDECESSOR_REQUIRED')
                prior = existing[payload['previous_agreement']]
                need(prior[0]['kind'] == 'EXTERNAL', 'HANDOFF_REVISE_EXTERNAL_ONLY_USE_NATIVE_DRAFTER')
                previous = prior[4]
            context = external.context_reference(payload['context'])
            document = external.pack(base64.b64encode(payload['terms'].encode('utf-8')).decode('ascii'),
                                     title=payload['title'], media_type='text/plain')
            prepared = external.prepare({'terms': document['document']}, payload['parties'], context['id'],
                                        title=payload['title'], previous=previous)
            row = {'id': 'agreement', 'kind': 'EXTERNAL', 'bundle': prepared['bundle'],
                   'context': context['id'], 'approvals': [], 'expected_id': prepared['id'],
                   'expected_closure': prepared['assent_payload']['body']['closure'],
                   'expected_current_id': prepared['id']}
            package = portable.pack(review.case(payload['title'], [row], primary='agreement'),
                                    {context['id']: payload['context']})['package']
            return self._adopt(record, package)

    def receive(self, payload):
        _fields(payload, ('package', 'expected_id', 'expected_package_id', 'confirm'))
        need(payload['confirm'] is True, 'HANDOFF_CONFIRM_REQUIRED')
        portable._pinned(payload['package'], payload['expected_id'])
        with self._guard():
            record = self._record()
            self._identity(record)
            self._cas(record, payload['expected_package_id'])
            return self._adopt(record, payload['package'])

    def review_sign(self, payload):
        _fields(payload, ('expected_package_id', 'agreement', 'roles'))
        portable.canonical(payload)
        with self._guard():
            record = self._record()
            _, public, stamp = self._identity(record)
            need(public is not None and record['identity_public'] == public, 'HANDOFF_IDENTITY_CREATE_EXPLICITLY')
            ref = self._cas(record, payload['expected_package_id'])
            need(ref is not None, 'HANDOFF_PACKAGE_REQUIRED')
            _, _, checked = _checked(record['package'])
            need(type(payload['agreement']) is str and payload['agreement'] in checked, 'HANDOFF_AGREEMENT_REQUIRED')
            row, native, required, seen, _, eligible = checked[payload['agreement']]
            need(not any(type(r['identity']) is str and r['identity'] in SYNTHETIC_KEYS for r in required),
                 'HANDOFF_SYNTHETIC_KEY_REPLACE_WITH_ACTUAL_PARTY')
            need(eligible, 'HANDOFF_SIGNING_DEPENDENCIES_OR_ROLES_UNRESOLVED')
            need(type(payload['roles']) is list and 0 < len(payload['roles']) <= len(required), 'HANDOFF_EXPLICIT_ROLES_REQUIRED')
            selected = []
            requested = set()
            for role in payload['roles']:
                _fields(role, ('concept', 'party'))
                need(type(role['party']) is str and (role['concept'] is None or type(role['concept']) is str), 'HANDOFF_ROLE')
                key = _role_key(role)
                need(key not in requested, 'HANDOFF_DUPLICATE_ROLE_SELECTION')
                requested.add(key)
                match = next((r for r in required if _role_key(r) == key), None)
                need(match is not None and match['identity'] == public, 'HANDOFF_ROLE_NOT_LOCAL_IDENTITY')
                need(key not in seen, 'HANDOFF_ROLE_ALREADY_SIGNED')
                selected.append(deepcopy(match))
            now = int(time.time())
            self._reviews = {key: value for key, value in self._reviews.items() if value['expires_at'] > now}
            need(len(self._reviews) < 64, 'HANDOFF_PENDING_REVIEW_LIMIT')
            token = secrets.token_hex(32)
            binding = {'package_id': ref, 'generation': record['generation'], 'agreement': row['id'],
                       'identity_public': public, 'key_stamp': stamp, 'roles': selected,
                       'label': native['label'], 'expires_at': now + REVIEW_SECONDS,
                       'package': deepcopy(record['package'])}
            self._reviews[token] = binding
            return {'review_id': token, 'expires_at': binding['expires_at'], 'package_id': ref,
                    'agreement': row['id'], 'identity_public': public,
                    'roles': [{**{k: r.get(k) for k in ('concept', 'party', 'identity')}, 'status': 'SELECTED_FOR_EXPLICIT_ASSENT'} for r in selected],
                    'required_assent': {'label': native['label'], 'bodies': [{k: deepcopy(r.get(k)) for k in ('concept', 'party', 'body')} for r in selected]},
                    'sources': _sources(record['package'], row),
                    'object': portable.open_object(record['package'], ref, row['id']),
                    'structured_terms': _structured_terms(record['package'], row),
                    'context_openings': deepcopy(record['package']['context_openings']),
                    'disclosure': portable.PLAINTEXT, 'signature_created': False, 'execution_authorized': False}

    def sign(self, payload):
        _fields(payload, ('review_id', 'confirm'))
        need(payload['confirm'] is True, 'HANDOFF_CONFIRM_REQUIRED')
        _pin(payload['review_id'])
        with self._guard():
            record = self._record()
            token = payload['review_id']
            if token in record['receipts']:
                receipt = deepcopy(record['receipts'][token])
                state = self._state(record)
                return {'status': 'RECOVERED', 'package_id': receipt['package_id'], 'last_signature': receipt,
                        'state': state, 'active_result': state['package_id'] == receipt['package_id']}
            pending = self._reviews.get(token)
            need(pending is not None, 'HANDOFF_REVIEW_UNKNOWN_OR_INVALIDATED')
            need(int(time.time()) < pending['expires_at'], 'HANDOFF_REVIEW_EXPIRED')
            need(record['generation'] == pending['generation'], 'HANDOFF_REVIEW_CHANGED')
            self._cas(record, pending['package_id'])
            need(record['package'] == pending['package'], 'HANDOFF_REVIEW_CHANGED')
            _, _, checked = _checked(record['package'])
            row, native, required, seen, _, eligible = checked[pending['agreement']]
            need(eligible and native['label'] == pending['label'], 'HANDOFF_REVIEW_CHANGED')
            selected = []
            for selected_role in pending['roles']:
                match = next((r for r in required if _role_key(r) == _role_key(selected_role)), None)
                need(match == selected_role and _role_key(match) not in seen, 'HANDOFF_REVIEW_CHANGED')
                selected.append(match)
            # Reopen custody only after re-deriving the complete native signable scope.
            key, public, stamp = self._identity(record)
            need(key is not None and public == pending['identity_public'] and stamp == pending['key_stamp'], 'HANDOFF_KEY_CHANGED')
            need(all(role['identity'] == public for role in selected), 'HANDOFF_ROLE_NOT_LOCAL_IDENTITY')
            package = deepcopy(record['package'])
            target = next(r for r in package['case']['agreements'] if r['id'] == pending['agreement'])
            for role in selected:
                signature = native_sign(key, native['label'], role['body'])
                verify(role['identity'], native['label'], role['body'], signature)
                proof = {'party': role['party'], 'signature': signature}
                if role.get('concept') is not None:
                    proof['concept'] = role['concept']
                target['approvals'].append(proof)
            target['approvals'] = _ordered_proofs(target['approvals'])
            package['case_id'] = review.identifier(package['case'])
            ref, _, _ = _checked(package)
            receipt = {'review_id': token, 'package_id': ref, 'previous_package_id': pending['package_id'],
                       'agreement': pending['agreement'], 'roles': [{k: r.get(k) for k in ('concept', 'party')} for r in selected],
                       'identity_public': public, 'signed_at': int(time.time()), 'sequence': record['generation'] + 1}
            # Exact signed package and recovery receipt become durable together.
            record['package'] = package
            if len(record['receipts']) >= MAX_RECEIPTS:
                oldest = min(record['receipts'], key=lambda item: record['receipts'][item]['sequence'])
                del record['receipts'][oldest]
            record['receipts'][token] = receipt
            record['last_signature'] = token
            record['generation'] += 1
            self._save(record)
            self._reviews.clear()
            return {'status': 'SIGNED', 'package_id': ref, 'last_signature': deepcopy(receipt),
                    'state': self._state(record), 'active_result': True}

    def merge(self, payload):
        _fields(payload, ('package', 'expected_id', 'expected_package_id', 'confirm'))
        need(payload['confirm'] is True, 'HANDOFF_CONFIRM_REQUIRED')
        portable._pinned(payload['package'], payload['expected_id'])
        with self._guard():
            record = self._record()
            self._identity(record)
            ref = self._cas(record, payload['expected_package_id'])
            need(ref is not None, 'HANDOFF_PACKAGE_REQUIRED')
            _checked(record['package'])
            _checked(payload['package'])
            before, incoming = deepcopy(record['package']), deepcopy(payload['package'])
            def unsigned(package):
                value = deepcopy(package)
                value.pop('case_id')
                for row in value['case']['agreements']:
                    row['approvals'] = []
                return value
            need(portable.canonical(unsigned(before)) == portable.canonical(unsigned(incoming)), 'HANDOFF_MERGE_TERMS_OR_CONTEXT_CHANGED')
            for row, other in zip(before['case']['agreements'], incoming['case']['agreements']):
                existing = {_role_key(proof): proof for proof in row['approvals']}
                for proof in other['approvals']:
                    key = _role_key(proof)
                    need(key not in existing or existing[key] == proof, 'HANDOFF_MERGE_PROOF_CONFLICT')
                    if key not in existing:
                        row['approvals'].append(deepcopy(proof))
                        existing[key] = proof
                row['approvals'] = _ordered_proofs(row['approvals'])
            before['case_id'] = review.identifier(before['case'])
            return self._adopt(record, before)

    def export(self, payload):
        _fields(payload, ('expected_package_id', 'confirm'))
        need(payload['confirm'] is True, 'HANDOFF_PLAINTEXT_DISCLOSURE_CONFIRM_REQUIRED')
        with self._guard():
            record = self._record()
            ref = self._cas(record, payload['expected_package_id'])
            need(ref is not None, 'HANDOFF_PACKAGE_REQUIRED')
            _checked(record['package'])
            return {'package': deepcopy(record['package']), 'id': ref,
                    'case_id': record['package']['case_id'], 'disclosure': portable.PLAINTEXT,
                    'execution_authorized': False}

    def open_source(self, payload):
        _fields(payload, ('expected_package_id', 'agreement'), ('document', 'encoding'))
        with self._guard():
            record = self._record()
            ref = self._cas(record, payload['expected_package_id'])
            need(ref is not None, 'HANDOFF_PACKAGE_REQUIRED')
            return portable.open_source(record['package'], ref, payload['agreement'],
                                        payload.get('document', 'terms'), payload.get('encoding', 'UTF8'))

    def open_object(self, payload):
        _fields(payload, ('expected_package_id', 'agreement'), ('path',))
        with self._guard():
            record = self._record()
            ref = self._cas(record, payload['expected_package_id'])
            need(ref is not None, 'HANDOFF_PACKAGE_REQUIRED')
            return portable.open_object(record['package'], ref, payload['agreement'], payload.get('path', ''))

    def open_context(self, payload):
        _fields(payload, ('expected_package_id', 'agreement'))
        with self._guard():
            record = self._record()
            ref = self._cas(record, payload['expected_package_id'])
            need(ref is not None, 'HANDOFF_PACKAGE_REQUIRED')
            _, compact, checked = _checked(record['package'])
            need(type(payload['agreement']) is str and payload['agreement'] in checked,
                 'HANDOFF_AGREEMENT_REQUIRED')
            summary = next(r for r in compact['agreements'] if r['item'] == payload['agreement'])
            context_id = summary['context']['id']
            openings = record['package']['context_openings']
            return {'package_id': ref, 'agreement': payload['agreement'],
                    'context': deepcopy(summary['context']), 'carried': context_id in openings,
                    'value': deepcopy(openings.get(context_id)), 'execution_authorized': False,
                    'disclosure': 'EXPLICIT_CARRIED_CONTEXT_OPENING; NOT_WORLD_TRUTH_OR_AUTHORITY'}


def spec():
    def obj(properties, required=None):
        return {'type': 'object', 'properties': properties, 'required': list(properties if required is None else required), 'additionalProperties': False}
    string = {'type': 'string'}
    pin = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
    current = {'anyOf': [pin, {'type': 'null'}]}
    confirm = {'const': True}
    role = obj({'concept': current, 'party': string})
    schemas = {
        'state': obj({}), 'create_identity': obj({'confirm': confirm}),
        'draft': obj({'title': {'type': 'string', 'minLength': 1, 'maxLength': 256},
                      'terms': {'type': 'string', 'minLength': 1, 'maxLength': external.MAX_BYTES},
                      'parties': {'type': 'object', 'minProperties': 1, 'maxProperties': 64, 'additionalProperties': pin},
                      'context': {}, 'expected_package_id': current, 'previous_agreement': string},
                     ('title', 'terms', 'parties', 'context', 'expected_package_id')),
        'receive': obj({'package': {'type': 'object'}, 'expected_id': pin, 'expected_package_id': current, 'confirm': confirm}),
        'review_sign': obj({'expected_package_id': pin, 'agreement': string,
                            'roles': {'type': 'array', 'minItems': 1, 'maxItems': 256, 'items': role}}),
        'sign': obj({'review_id': pin, 'confirm': confirm}),
        'export': obj({'expected_package_id': pin, 'confirm': confirm}),
        'open_source': obj({'expected_package_id': pin, 'agreement': string, 'document': string,
                            'encoding': {'enum': ['UTF8', 'BASE64']}}, ('expected_package_id', 'agreement')),
        'open_object': obj({'expected_package_id': pin, 'agreement': string, 'path': string}, ('expected_package_id', 'agreement'))}
    schemas['open_context'] = obj({'expected_package_id': pin, 'agreement': string})
    schemas['merge'] = deepcopy(schemas['receive'])
    return {'version': VERSION, 'owner_api': schemas, 'supported_agreements': list(SUPPORTED),
            'response_shapes': {'state_actions': ['state', 'create_identity', 'draft', 'receive', 'merge'],
                'state_actions_result': 'OWNER_STATE_DIRECT',
                'sign': 'RECEIPT_WRAPPER; current owner state is result.state; receipt package_id may describe a recovered earlier result',
                'review_sign': 'PENDING_EXACT_REVIEW; not owner state',
                'export': 'PACKAGE_WRAPPER; package and id',
                'recovery': 'Always inspect result.state.package_id and active_result before treating a recovered receipt as the current package'},
            'review_seconds': REVIEW_SECONDS, 'maximum_receipts': MAX_RECEIPTS, 'maximum_record_bytes': MAX_RECORD_BYTES,
            'trust': 'OWNER_LOCAL_PROCESS_AND_PRIVATE_OPERATING_SYSTEM_ACCOUNT',
            'agent_discovery': {'owner_app': 'covenant-handoff', 'signing_tool': None,
                                'safe_actions': ['portable spec', 'portable inspect', 'portable open-source', 'portable open-object'],
                                'owner_actions': ['create_identity', 'draft', 'receive', 'review_sign', 'sign', 'merge', 'export']},
            'custody': 'EXPLICIT_LOCAL_ED25519_CREATION_ONLY; NEVER_RETURN_PRIVATE_KEY',
            'recovery': 'UP_TO_128_MOST_RECENT_DURABLE_RECEIPTS_WITHIN_STORAGE_BYTE_BOUND; EXACT_SIGN_RETRY_RETURNS_ORIGINAL_RESULT_WITHOUT_REPLACING_CURRENT_PACKAGE; OLDER_TOKENS_REFUSE_AND_NEVER_SIGN_AGAIN',
            'disclosure': portable.PLAINTEXT, 'signed_profiles': 'UNCHANGED',
            'network': False, 'automatic_payment': False, 'delegated_authority': False,
            'execution_authorized': False}
