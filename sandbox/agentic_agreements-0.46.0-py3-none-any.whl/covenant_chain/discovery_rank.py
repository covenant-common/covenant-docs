"""Personalized graph discovery, separated from contextual outcome evidence.

``pagerank`` bounds are denial-of-service limits, not graph semantics, and the
owner configures them: ``limits`` may set ``nodes``, ``edges`` and ``work`` up to
``CEILINGS``. ``work`` counts the mass transfers one call makes:
``iterations`` times, for each node, 8 plus its distinct out-neighbours (or the
seeds when it has none) plus the seeds. The defaults admit every graph the
historical 256-node, 4096-edge bound admitted, with that bound's worst-case work,
and swarms of up to 4096 nodes; results are unchanged. Measured on one core
(Python 3.14, 60 iterations, one seed, four edges a node): 300 nodes 0.03 s,
1024 nodes 0.12 s, 4096 nodes 0.5 s; 40960 nodes (ten times the default, limits
raised) 5.9 s and 22 MB peak. The default work limit is the historical worst case
(256 nodes and seeds, 200 iterations): 4.5 s; the work ceiling is ten times that.
A refusal over a limit is a ``LimitRefusal`` that says what was refused, the fix
and whether a retry helps.
"""
from .crypto import integer,key,need
from .agent_network import LimitRefusal,unpack

SCALE=10**9
LIMITS={'nodes':4096,'edges':65536,'work':26_624_000}
CEILINGS={'nodes':65536,'edges':1_048_576,'work':266_240_000}


def rank_limits(limits=None):
    """Owner limits merged over the defaults. A value above its ceiling is refused, never clipped."""
    need(limits is None or type(limits) is dict and set(limits)<=set(LIMITS),'RANK_LIMITS')
    out=dict(LIMITS,**(limits or {}))
    for name,value in out.items():
        integer(value,True)
        if value>CEILINGS[name]:
            raise LimitRefusal('RANK_LIMITS',f'limits.{name}',f'{name} limit {value} is above the ceiling {CEILINGS[name]}',
                               f'Set limits.{name} to at most {CEILINGS[name]}. A larger population needs '
                               'scalable_discovery.sparse_rank.')
    return out


def _over(code,path,count,limit,noun):
    raise LimitRefusal(code,path,f'{count} {noun} is above the owner limit of {limit}',
                       f'Rank at most {limit} {noun} per call, or have the host owner raise limits.{path} '
                       f'(ceiling {CEILINGS[path]}) in pagerank(..., limits=...). Populations beyond the ceiling '
                       'use scalable_discovery.sparse_rank.')


def allocate(total,weights):
    denominator=sum(weights.values());need(denominator>0,'RANK_ZERO_WEIGHT')
    result={k:total*w//denominator for k,w in weights.items()}
    rest=total-sum(result.values())
    order=sorted(weights,key=lambda k:(-(total*weights[k]%denominator),k))
    for k in order[:rest]:result[k]+=1
    return result


def pagerank(nodes,edges,seeds,damping_bps=8500,iterations=60,*,limits=None):
    bound=rank_limits(limits)
    need(type(nodes) is list and len(nodes)>0,'RANK_NODES')
    if len(nodes)>bound['nodes']:_over('RANK_NODES','nodes',len(nodes),bound['nodes'],'nodes')
    need(nodes==sorted(set(nodes)),'RANK_NODES')
    for node in nodes:key(node)
    if type(edges) is list and len(edges)>bound['edges']:_over('RANK_GRAPH','edges',len(edges),bound['edges'],'edges')
    need(type(edges) is list and type(seeds) is dict and set(seeds)<=set(nodes) and bool(seeds),'RANK_GRAPH')
    for value in seeds.values():integer(value,True)
    integer(damping_bps);need(damping_bps<=9500,'RANK_DAMPING');integer(iterations,True);need(iterations<=200,'RANK_ITERATIONS')
    adjacency={n:set() for n in nodes}
    for edge in edges:
        need(type(edge) is list and len(edge)==2 and all(n in adjacency for n in edge),'RANK_EDGE')
        if edge[0]!=edge[1]:adjacency[edge[0]].add(edge[1])
    work=iterations*sum(8+(len(adjacency[n]) or len(seeds))+len(seeds) for n in nodes)
    if work>bound['work']:
        raise LimitRefusal('RANK_WORK','work',f'this graph needs {work} transfers, above the owner limit of {bound["work"]}',
                           'Use fewer seeds, nodes or iterations, or have the host owner raise limits.work '
                           f'(ceiling {CEILINGS["work"]}). Each seed adds one transfer per node per iteration.')
    seed_mass=allocate(SCALE,seeds);mass={n:seed_mass.get(n,0) for n in nodes}
    for _ in range(iterations):
        nxt={n:0 for n in nodes}
        for source,amount in mass.items():
            continuation=amount*damping_bps//10000
            teleport=amount-continuation
            targets={n:1 for n in adjacency[source]} if adjacency[source] else seeds
            for n,v in allocate(continuation,targets).items():nxt[n]+=v
            for n,v in allocate(teleport,seeds).items():nxt[n]+=v
        need(sum(nxt.values())==SCALE,'RANK_MASS_CONSERVATION');mass=nxt
    return mass


def reputation(network,context,subject=None,query='',group=None,now=None,*,limits=None):
    need(type(context) is str and 0<len(context)<=80,'RANK_CONTEXT')
    if subject is not None:key(subject)
    if group is not None:key(group)
    events=network.events();origins={}
    for ref,e in events.items():
        b=e['body']
        if b['kind']!='ENDORSE' or group is not None and b['group']!=group:continue
        p=unpack(b)
        if 'result' not in p or 'origin' not in p or 'subject' not in p:continue
        from .network_incentives import endorsement_counts
        if not endorsement_counts(p,events,b['actor'],now):continue
        if p['context']!=context:continue
        origins.setdefault((b['actor'],p['subject'],p['origin']),set()).add(p['result'])
    edges=[];summary={}
    for (author,target,origin),outcomes in origins.items():
        row=summary.setdefault(target,{'positive_origins':0,'negative_origins':0,'unknown_origins':0,'conflicting_origins':0})
        if len(outcomes)>1:row['conflicting_origins']+=1
        elif 'POSITIVE' in outcomes:row['positive_origins']+=1;edges.append([author,target])
        elif 'NEGATIVE' in outcomes:row['negative_origins']+=1
        else:row['unknown_origins']+=1
    nodes=sorted(network.peers);rank_edges=[e for e in edges if e[1] in network.peers];mass=pagerank(nodes,rank_edges,network.seeds,limits=limits)
    rows=[{'agent':n,'discovery_mass_ppb':mass[n],**summary.get(n,{'positive_origins':0,'negative_origins':0,'unknown_origins':0,'conflicting_origins':0})} for n in nodes if subject is None or n==subject]
    rows.sort(key=lambda x:(-x['discovery_mass_ppb'],x['agent']))
    external=[{'agent':n,'discovery_mass_ppb':0,**summary[n]} for n in sorted(set(summary)-network.peers) if subject is None or n==subject]
    view=network.view(group,query)
    posts=sorted(view['posts'],key=lambda p:(-mass.get(p['actor'],0),p['id']))
    return {'context':context,'agents':rows,'results':posts,'graph_nodes':len(nodes),
            'external_evidence':external[:256],'external_evidence_omitted':max(0,len(external)-256),'external_subjects_are_ranked':False,'ranking':'PERSONALIZED_PAGERANK_FROM_OWNER_ADOPTED_SEEDS',
            'origin_independence':'NOT_ESTABLISHED','claims':'SIGNED_OPINIONS_NOT_CERTIFIED_PERFORMANCE',
            'pending_disputes_are_penalties':False,'graph_rank_is_authority':False,'sybil_resistance':'BOUNDED_ADMISSION_AND_TRUST_SEEDS_NOT_A_PROOF',
            'execution_authorized':False}
