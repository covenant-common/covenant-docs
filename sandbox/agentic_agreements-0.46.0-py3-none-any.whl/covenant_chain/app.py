"""Native, deterministic authority-to-commitment state machine.

This sandbox pins one interpreter at genesis. Quantities are protocol units;
world performance and legal authority remain explicit outside assumptions.
"""
from copy import deepcopy
from .crypto import canonical,digest,sign,verify,public_key,need,exact,integer,key,verification_key
from .profile import (
    VERSION, NEXT_VERSION, LIFECYCLE_VERSION, SHIELDED_VERSION, ECOSYSTEM_VERSION, MISSION_VERSION,
    FEDERATION_VERSION, EXTENSIBLE_VERSION, ECONOMIC_VERSION, CONFIDENTIAL_VERSION, CONTINUITY_VERSION,
    MARKET_VERSION, REVIEW_VERSION, PREDICTION_VERSION, SCALE_VERSION, UPGRADE_VERSION, TOKENOMICS_VERSION,
    RESOLUTION_VERSION, MIGRATION_VERSION,
)
# Shared leaf helpers live in ledger_base so extension modules need not import app.
from .ledger_base import RESOURCE_SUPPLY_CAP, SUPPLY_CAP_ACTIVATION_HEIGHT, agreement_id, amount, add
CONTINUITY_MAX_TX_BYTES=512*1024
CONTINUITY_MAX_BLOCK_TX_BYTES=768*1024
FEDERATION_MAX_TX_BYTES=256*1024
FEDERATION_MAX_BLOCK_TX_BYTES=512*1024
from .state import Table, seal, check_deltas
from .approval import bind_controller
EFFECTS={'TRANSFER','CONSUME','AUTHORIZE'}

def genesis_state(g):
    canonical(g)
    # Economics-shaped 0.15 (the token profile) omits the 0.10–0.14 layers.
    # A genesis that carries confidential, continuity, and market gets the full stack.
    stack = g.get('protocol') if g.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and {'confidential','continuity','market'} <= set(g) else None
    exact(g,'protocol name validators faults accounts resources profiles'+(' shielded' if g.get('protocol') in {SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else '')+(' sources' if g.get('protocol') in {FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else '')+(' economics' if g.get('protocol') in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else '')+(' confidential confidential_admission' if g.get('protocol') in {CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,stack} else '')+(' continuity' if g.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,stack} else '')+(' market' if g.get('protocol') in {MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,stack} else '')+(' features' if 'features' in g else '')+(' migration' if g.get('protocol')==MIGRATION_VERSION and 'migration' in g else ''))
    need(g['protocol'] in {VERSION,NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION},'VERSION')
    need(type(g['faults']) is int and g['faults']>=1,'FAULTS')
    need(type(g['validators']) is dict and len(g['validators'])==3*g['faults']+1,'VALIDATORS')
    need(len(set(digest('COVENANT-VALIDATOR-KEY',v) for v in g['validators'].values()))==len(g['validators']),'DUPLICATE_VALIDATOR')
    for pub in g['validators'].values():
        if g['protocol'] in {LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:verification_key(pub)
        else:key(pub);verification_key(pub)
    need(type(g['resources']) is dict and 0<len(g['resources'])<=64,'RESOURCES')
    for rid,desc in g['resources'].items():
        need(type(rid) is str and 0<len(rid)<=80,'RESOURCE')
        exact(desc,'unit');need(type(desc['unit']) is str and bool(desc['unit']),'UNIT')
    need(type(g['profiles']) is dict and 0<len(g['profiles'])<=64,'PROFILES')
    for pid,desc in g['profiles'].items():
        need(type(pid) is str and 0<len(pid)<=80,'PROFILE')
        exact(desc,'description');need(type(desc['description']) is str,'PROFILE_DESCRIPTION')
    for pub,balances in g['accounts'].items():
        key(pub);need(type(balances) is dict,'BALANCES')
        for rid,qty in balances.items():need(rid in g['resources'],'RESOURCE');integer(qty)
    canonical(g)
    supply={rid:sum(a.get(rid,0) for a in g['accounts'].values()) for rid in g['resources']}
    if g['protocol'] in {UPGRADE_VERSION,MIGRATION_VERSION}:
        for total in supply.values():need(type(total) is int and 0<=total<=RESOURCE_SUPPLY_CAP,'SUPPLY_CAP')
    from .crypto import genesis_id
    state={'chain':genesis_id(g),'resources':deepcopy(g['resources']),
           'profiles':deepcopy(g['profiles']),'balances':deepcopy(g['accounts']),
           'authority_available':deepcopy(g['accounts']),'supply':supply,
           'consumed':{rid:0 for rid in g['resources']},'nonces':{},'grants':{},
           'agreements':{},'evidence':{},'events':{},'effects':{}}
    canonical(state)
    if g['protocol'] in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        state={k:Table(v) if type(v) is dict else v for k,v in state.items()}
        state['protocol']=g['protocol'];state['controllers']=Table();state['permissions']=Table()
    if g['protocol'] in {LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        for name in ['recovery_policies','recovery_requests','controller_epochs','multilateral']:state[name]=Table()
        state['domain']=Table({'active':{'epoch':0,'activation':1,'validators':g['validators'],'faults':g['faults'],'event':None}})
    if g['protocol'] in {SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .shielded import validate_descriptor,tree
        need(type(g['shielded']) is dict and (0 if g['protocol'] in {ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else 1)<=len(g['shielded'])<=8,'SHIELDED_CONFIG')
        for rid,desc in g['shielded'].items():need(rid in state['resources'],'SHIELDED_RESOURCE');validate_descriptor(desc)
        empty=tree([])['root'] if g['shielded'] else None;state['shielded_config']=Table(g['shielded']);state['shielded_pools']=Table({rid:{'root':empty,'roots':[empty],'notes':[]} for rid in g['shielded']});state['shielded_nullifiers']=Table();state['shielded_escrow']=Table({rid:0 for rid in g['shielded']})
    if g['protocol'] in {ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .ecosystem import TABLES
        for name in TABLES:state[name]=Table()
    if g['protocol'] in {MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .mission import TABLES
        for name in TABLES:state[name]=Table()
    if g['protocol'] in {FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .federation import initialize
        initialize(state,g,genesis_state)
    if g['protocol'] in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .economics import initialize as economic_initialize
        economic_initialize(state,g)
    if g['protocol'] in {CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,stack}:
        from .confidential import initialize as confidential_initialize
        confidential_initialize(state,g)
    if g['protocol']in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,stack}:
        from .continuity import initialize as continuity_initialize
        continuity_initialize(state,g)
    if g['protocol'] in {MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,stack}:
        from .market import initialize as market_initialize
        market_initialize(state,g)
    if g['protocol'] in {REVIEW_VERSION,PREDICTION_VERSION,stack}:
        from .review import TABLES as review_tables
        for name in review_tables:state[name]=Table()
    if g['protocol'] in {PREDICTION_VERSION,stack}:
        from .prediction import TABLES as prediction_tables
        for name in prediction_tables:state[name]=Table()
    if g['protocol'] in {UPGRADE_VERSION,MIGRATION_VERSION}:
        from .governance import install
        install(state)
        from .scale.native import TABLES as scale_tables
        for name in scale_tables:state[name]=Table()
        if _armed_resolution(g):
            state['fork_pin']=digest('COVENANT-FORK-PIN-0.15', {'chain':state['chain']})
            state['release_nonces']=Table()
    if 'features' in g:
        from .feature_gate import accept_features
        state['features']=accept_features(g['features'])
    if g['protocol']==MIGRATION_VERSION and 'migration' in g:
        from .world_migration import adopt
        from .light import verify_light_bundle
        adopt(state,g,validate_genesis=genesis_state,verify_bundle=verify_light_bundle)
    return state

def _armed_resolution(g):
    """True when genesis continuity names the veto-guardian that arms resolution rules."""
    policies=(g.get('continuity') or {}).get('policies') or {}
    if type(policies) is not dict:return False
    for policy in policies.values():
        guardians=policy.get('guardians') if type(policy) is dict else None
        if type(guardians) is dict and 'veto-guardian' in guardians:return True
    return False

def begin_block(state,height):
    from .governance import activate_due
    state=activate_due(state,height)
    if state.get('protocol') in {MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION} or (state.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'market_meter' in state):
        from .market import begin
        return begin(state,height)
    return state

def state_hash(state):
    if state.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:return digest('COVENANT-STATE-'+state['protocol'].split('/')[-1],seal(state))
    return digest('COVENANT-STATE-0.1',state)
def transaction_id(tx):return digest('COVENANT-TX-ID-0.1',tx['body'])
def make_transaction(private_key,chain,nonce,op,payload,protocol=VERSION,actor=None,fee=None):
    body={'v':protocol,'chain':chain,'actor':actor or public_key(private_key),'nonce':nonce,'op':op,'payload':deepcopy(payload)}
    if protocol in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .economics import validate_fee_envelope
        if type(fee) is dict and ({'asset', 'integrator', 'referrer', 'sponsor_program'} & set(fee)):
            from .economics import validate_scale_fee_envelope
            validate_scale_fee_envelope(fee)
        else:
            validate_fee_envelope(fee)
        body['fee']=deepcopy(fee)
    else:need(fee is None,'FEE_PROFILE')
    return {'body':body,'signature':sign(private_key,'COVENANT-TX-SIGN-0.1',body)}
def assent(private_key,terms,entity=None):return {'signer':entity or public_key(private_key),'signature':sign(private_key,'COVENANT-ASSENT-0.1',terms)}

def controller(s,entity):
    ordinary=s['controllers'].get(entity,entity) if s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else entity
    if s.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .continuity import descriptor
        return descriptor(s,entity,ordinary)
    return ordinary

bind_controller(controller)

def live_grant(s,gid,height):
    seen=set();first=None
    while gid is not None:
        need(gid not in seen and len(seen)<64,'GRANT_DEPTH');seen.add(gid)
        need(gid in s['grants'],'GRANT_MISSING');g=s['grants'][gid]
        if first is None:first=g
        need(not g['revoked'] and height<=g['expiry'],'GRANT_INACTIVE')
        if s.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
            from .continuity import authority_epoch
            need(g.get('continuity_epoch',0)==authority_epoch(s,g['principal']),'GRANT_INACTIVE')
        gid=g['parent']
    return first

def _terms(s,t,height):
    panelled=s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'panel' in t
    fields='chain principal agent counterparty mandate profile resource quantity effect destination executor resolver appeal_resolver deadline challenge_blocks timeout terms_hash'
    if panelled:fields+=' panel'
    if 'appeal_bench' in t:fields+=' appeal_bench'
    if 'arbiter' in t:fields+=' arbiter'
    if 'indeterminate_outcome' in t:fields+=' indeterminate_outcome'
    from .principal_override import terms_suffix
    fields+=terms_suffix(s,t,height)
    exact(t,fields)
    need(t['chain']==s['chain'],'CHAIN')
    for field in ['principal','agent','counterparty','executor','resolver','appeal_resolver']:key(t[field])
    need(t['agent']!=t['counterparty'],'DISTINCT_PARTIES')
    need(t['resolver'] not in {t['agent'],t['counterparty']} and t['appeal_resolver'] not in {t['agent'],t['counterparty'],t['resolver']},'RESOLVER_CONFLICT')
    need(t['profile'] in s['profiles'] and t['resource'] in s['resources'],'PROFILE_RESOURCE')
    integer(t['quantity'],True);integer(t['deadline']);integer(t['challenge_blocks'],True)
    need(height<t['deadline'] and t['challenge_blocks']<=10000,'DEADLINE')
    need(t['effect'] in EFFECTS,'EFFECT')
    from .salted_terms import destination_ok
    destination_ok(s,t,height)
    timeouts={'RELEASE_IF_UNDECIDED','HOLD_FOR_RESOLUTION'}
    if s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION}:timeouts.add('WAIT_FOREVER')
    need(t['timeout'] in timeouts,'TIMEOUT_POLICY')
    key(t['terms_hash']);_appeal_bench(s,t)
    if 'indeterminate_outcome' in t:
        from .resolution_rules import _resolution
        need(_resolution(s),'DEADLINE_OUTCOME')
    from .resolution_rules import accept_terms
    accept_terms(s,t)
    if t['mandate'] is None:
        need(t['principal']==t['agent'],'PRINCIPAL_AUTHORITY')
        need(amount(s['authority_available'],t['principal'],t['resource'])>=t['quantity'],'AUTHORITY_CAPACITY')
    else:
        g=live_grant(s,t['mandate'],height)
        need(g['holder']==t['agent'] and g['principal']==t['principal'],'GRANT_HOLDER')
        need(g['resource']==t['resource'] and t['effect'] in g['effects'] and t['profile'] in g['profiles'],'GRANT_SCOPE')
        need(g['remaining']>=t['quantity'],'GRANT_CAPACITY')
    need(amount(s['balances'],t['principal'],t['resource'])>=t['quantity'],'INSUFFICIENT_BACKING')
    if panelled:
        from .resolution_rules import PANEL_VERSION, _resolution
        panel=t['panel']
        if not (_resolution(s) and type(panel) is dict and panel.get('v')==PANEL_VERSION):
            from .arbitration import validate_terms_panel
            validate_terms_panel(s,t,height)

def _evidence_refs(s,cid,refs):
    need(type(refs) is list and 0<len(refs)<=32 and refs==sorted(set(refs)),'EVIDENCE_SET')
    for eid in refs:need(eid in s['evidence'] and s['evidence'][eid]['agreement']==cid,'EVIDENCE_BINDING')

def _appeal_bench(s,t):
    """Optional 0.15 draw. The seated appeal resolver is the first name."""
    if 'appeal_bench' not in t:return
    from .resolution_rules import _resolution
    need(_resolution(s),'APPEAL_BENCH')
    bench=t['appeal_bench']
    need(type(bench) is list and 1<=len(bench)<=8 and bench[0]==t['appeal_resolver'],'APPEAL_BENCH')
    seen=set()
    for who in bench:
        key(who)
        need(who not in seen and who not in {t['agent'],t['counterparty'],t['resolver']},'APPEAL_BENCH')
        seen.add(who)

def _appeal_until(a,t):
    return a['appeal_until'] if 'appeal_until' in a else a['challenge_end']+t['challenge_blocks']

def _seated_appeal(a,t):
    return a['seated_appeal'] if 'seated_appeal' in a else t['appeal_resolver']

def _appeal_lapsed(s,a,t,height):
    from .resolution_rules import _resolution
    if not _resolution(s):return False
    if a['state']!='CHALLENGED' or a['appeal_final'] or a['challenge_end'] is None or a.get('decision') is None:return False
    return height>_appeal_until(a,t) and height>t['deadline']

def _next_appeal_judge(a,t):
    bench=t.get('appeal_bench')
    if type(bench) is not list:return None
    used=a.get('appeal_seated',[t['appeal_resolver']])
    for who in bench:
        if who not in used:return who
    return None

def _record_silent_judge(a,t,height,tid):
    seated=_seated_appeal(a,t)
    rows=a.setdefault('judge_record',[])
    if any(row['judge']==seated for row in rows):return
    rows.append({'judge':seated,'reputation':'LOST','bond':'FORFEIT_RECORDED','height':height,'event':tid})
    a['silent_judges']=[row['judge'] for row in rows]

def _replace_silent_appeal(s,a,t,height,tid):
    if not _appeal_lapsed(s,a,t,height):return False
    nxt=_next_appeal_judge(a,t)
    if nxt is None:return False
    _record_silent_judge(a,t,height,tid)
    used=list(a.get('appeal_seated',[t['appeal_resolver']]));used.append(nxt)
    a['appeal_seated']=used;a['seated_appeal']=nxt;a['appeal_until']=height+t['challenge_blocks']
    a['appeal_basis']='REPLACED_FROM_DRAWN_LIST'
    return True

def _award_stands(s,a,t,height):
    return _appeal_lapsed(s,a,t,height) and _next_appeal_judge(a,t) is None

def _close_lapsed_appeal(a,t,height,tid):
    _record_silent_judge(a,t,height,tid)
    a['appeal_final']=True;a['appeal_basis']='FIRST_INSTANCE_STANDS'
    a['appeal_lapse']={'basis':'FIRST_INSTANCE_STANDS','silent_judges':list(a.get('silent_judges',[])),'event':tid,'height':height}

def invariant(s):
    from .custody import conserved
    from .native_custody import partitions
    free={rid:sum(b.get(rid,0) for b in s['balances'].values()) for rid in s['supply']}
    held={rid:sum(a['terms']['quantity'] for a in s['agreements'].values()
          if a['held'] and a['terms']['resource']==rid) for rid in s['supply']}
    conserved(s['supply'],[free,held,s['consumed'],*partitions(s)])
    # Every available unit has exactly one local authority allocation.
    for principal,balances in s['balances'].items():
        for rid,free in balances.items():
            grants=sum(g['remaining'] for g in s['grants'].values() if g['principal']==principal and g['resource']==rid)
            need(amount(s['authority_available'],principal,rid)+grants==free,'AUTHORITY_CONSERVATION')

def apply_transaction(state,tx,height):
    integer(height,True);canonical(tx);exact(tx,'body signature');b=tx['body']
    if state.get('protocol') in {FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:need(len(canonical(tx))<=(CONTINUITY_MAX_TX_BYTES if state.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else FEDERATION_MAX_TX_BYTES),'FEDERATION_TX_SIZE')
    exact(b,'v chain actor nonce op payload'+(' fee' if state.get('protocol') in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION} else ''))
    need(b['v']==state.get('protocol',VERSION) and b['chain']==state['chain'],'CHAIN_VERSION')
    key(b['actor']);integer(b['nonce'])
    verify(controller(state,b['actor']),'COVENANT-TX-SIGN-0.1',b,tx['signature'])
    need(b['nonce']==state['nonces'].get(b['actor'],0),'NONCE')
    need(type(b['op']) is str and type(b['payload']) is dict,'OP_PAYLOAD')
    s=deepcopy(begin_block(state,height));p=b['payload'];actor=b['actor'];op=b['op'];tid=transaction_id(tx);parents=[]
    need(tid not in s['events'],'REPLAY')
    extension=None
    if s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and type(op) is str and op.startswith('SCALE_'):
        from .governance import feature_active
        from .rule_registry import scale_feature
        if feature_active(s, scale_feature(op)):
            from .scale.native import apply as scale_apply
            extension=scale_apply(s,state,op,p,actor,tid,height)
    if extension is None and (s.get('protocol')==PREDICTION_VERSION or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'prediction_markets' in s)):
        from .prediction import apply as prediction_apply
        extension=prediction_apply(s,state,op,p,actor,tid,height)
    if s.get('protocol') in {REVIEW_VERSION,PREDICTION_VERSION} or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'review_jobs' in s):
        from .review import preflight as review_preflight,apply as review_apply
        review_preflight(s,op,p)
        if extension is None:extension=review_apply(s,state,op,p,actor,tid,height)
    if s.get('protocol') in {MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION} or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'market_config' in s):
        from .market import preflight as market_preflight,apply as market_apply
        market_preflight(s,op)
        if extension is None:extension=market_apply(s,state,op,p,actor,tid,height)
    if s.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION} or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'continuity_policies' in s):
        from .continuity import preflight,apply as continuity_apply
        preflight(s,op,p,actor)
        if extension is None:extension=continuity_apply(s,state,op,p,actor,tid,height)
    if s.get('protocol') in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .economics import activate,apply as economics
        economic_policy=activate(s,height)
        if extension is None and (s.get('protocol') in {CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION} or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'confidential_config' in s)):
            from .confidential import apply as confidential
            extension=confidential(s,state,op,p,actor,b['nonce'],tid,height,tx,economic_policy)
        if extension is None:extension=economics(s,state,op,p,actor,tid,height)
    if extension is None and s.get('protocol') in {FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .federation import apply as federation
        from .light import verify_light_bundle
        extension=federation(s,state,op,p,actor,tid,height,verify_light_bundle)
    if extension is None and s.get('protocol') in {MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .mission import apply as mission
        extension=mission(s,state,op,p,actor,tid,height)
    if extension is None and s.get('protocol') in {ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .ecosystem import apply as ecosystem
        extension=ecosystem(s,state,op,p,actor,tid,height)
    if extension is None and s.get('protocol') in {SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .shielded import apply as shielded
        extension=shielded(s,state,op,p,actor,b['nonce'],tid,height)
    if extension is None and s.get('protocol') in {LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .lifecycle import apply as lifecycle
        extension=lifecycle(s,state,op,p,actor,tid,height,lambda who:controller(s,who),state_hash)
    if extension is not None:parents=extension
    elif op=='ROTATE' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'successor possession');key(p['successor'])
        rotation={'chain':s['chain'],'entity':actor,'nonce':b['nonce'],'successor':p['successor']}
        verify(p['successor'],'COVENANT-CONTROLLER-ACCEPT-0.2',rotation,p['possession'])
        need(p['successor']!=controller(s,actor),'UNCHANGED_CONTROLLER')
        s['controllers'][actor]=p['successor']
        if s.get('protocol') in {LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
            s['controller_epochs'][actor]=s['controller_epochs'].get(actor,0)+1;s['recovery_requests'][actor]=None
    elif op=='REGISTER_RESOURCE' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'unit quantity');need(type(p['unit']) is str and 0<len(p['unit'])<=80,'UNIT');integer(p['quantity'],True)
        if s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and height>=SUPPLY_CAP_ACTIVATION_HEIGHT:
            need(p['quantity']<=RESOURCE_SUPPLY_CAP,'SUPPLY_CAP')
        rid=tid;need(rid not in s['resources'],'RESOURCE_EXISTS')
        s['resources'][rid]={'unit':p['unit'],'issuer':actor};s['supply'][rid]=p['quantity'];s['consumed'][rid]=0
        add(s['balances'],actor,rid,p['quantity']);add(s['authority_available'],actor,rid,p['quantity'])
    elif op=='PERMIT' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'holder action context expiry');key(p['holder']);key(p['context']);integer(p['expiry'])
        need(type(p['action']) is str and 0<len(p['action'])<=80 and p['expiry']>=height,'PERMISSION_SCOPE')
        s['permissions'][tid]={**deepcopy(p),'issuer':actor,'revoked':False}
        if s.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
            from .continuity import authority_epoch
            s['permissions'][tid]['continuity_epoch']=authority_epoch(s,actor)
    elif op=='WITHDRAW_PERMISSION' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'permission');need(p['permission'] in s['permissions'],'PERMISSION_MISSING')
        permission=s['permissions'][p['permission']];need(actor==permission['issuer'],'PERMISSION_ISSUER')
        permission['revoked']=True;parents=[p['permission']]
    elif op=='EXERCISE_PERMISSION' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'permission action context request_hash');key(p['request_hash'])
        need(p['permission'] in s['permissions'],'PERMISSION_MISSING');permission=s['permissions'][p['permission']]
        need(actor==permission['holder'] and not permission['revoked'] and height<=permission['expiry'],'PERMISSION_INACTIVE')
        if s.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
            from .continuity import authority_epoch
            need(permission.get('continuity_epoch',0)==authority_epoch(s,permission['issuer']),'PERMISSION_INACTIVE')
        need(p['action']==permission['action'] and p['context']==permission['context'],'PERMISSION_SCOPE')
        parents=[p['permission']]
    elif op=='REGISTER_PROFILE' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'interpreter description terms_schema_hash');key(p['terms_schema_hash'])
        need(p['interpreter']=='bilateral-reservation/0.2','UNSUPPORTED_INTERPRETER')
        need(type(p['description']) is str and len(p['description'])<=2000,'PROFILE_DESCRIPTION')
        pid=digest('COVENANT-PROFILE-0.2',p);need(pid not in s['profiles'],'PROFILE_EXISTS')
        s['profiles'][pid]=deepcopy(p)
    elif op=='DISCHARGE' and s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        exact(p,'agreement assents');need(p['agreement'] in s['agreements'],'AGREEMENT')
        a=s['agreements'][p['agreement']];t=a['terms'];need(a['held'],'ALREADY_DISCHARGED')
        body={'chain':s['chain'],'agreement':p['agreement'],'formation':a['formation'],'action':'MUTUAL_DISCHARGE'}
        required={t['principal'],t['counterparty']};seen=set()
        need(type(p['assents']) is list and len(p['assents'])==len(required),'DISCHARGE_ASSENTS')
        for consent in p['assents']:
            exact(consent,'signer signature');who=consent['signer'];need(who in required and who not in seen,'DISCHARGE_SIGNER')
            verify(controller(s,who),'COVENANT-DISCHARGE-0.2',body,consent['signature']);seen.add(who)
        need(seen==required,'DISCHARGE_ASSENTS')
        add(s['balances'],t['principal'],t['resource'],t['quantity']);add(s['authority_available'],t['principal'],t['resource'],t['quantity'])
        a['held']=False;a['state']='MUTUALLY_DISCHARGED';a['history'].append(tid);parents=[a['formation']]
    elif op=='GIVE':
        from .resolution_rules import give_fields, stamp_grant, _resolution
        exact(p,give_fields(s) if _resolution(s) else 'parent holder resource limit expiry effects profiles delegate')
        key(p['holder']);integer(p['limit'],True);integer(p['expiry'])
        need(p['expiry']>=height and type(p['delegate']) is bool,'GRANT_EXPIRY')
        for field in ['effects','profiles']:
            need(type(p[field]) is list and p[field]==sorted(set(p[field])) and len(p[field])>0,'SCOPE_SET')
        need(set(p['effects'])<=EFFECTS and all(profile in s['profiles'] for profile in p['profiles']) and p['resource'] in s['resources'],'GRANT_SCOPE')
        if p['parent'] is None:
            principal=actor
            need(amount(s['authority_available'],actor,p['resource'])>=p['limit'],'AUTHORITY_CAPACITY')
            add(s['authority_available'],actor,p['resource'],-p['limit'])
        else:
            g=live_grant(s,p['parent'],height);principal=g['principal'];parents=[p['parent']]
            need(g['holder']==actor and g['delegate'],'DELEGATION')
            need(p['expiry']<=g['expiry'] and p['resource']==g['resource'] and set(p['effects'])<=set(g['effects']) and set(p['profiles'])<=set(g['profiles']),'ATTENUATION')
            need(g['remaining']>=p['limit'],'GRANT_CAPACITY');g['remaining']-=p['limit']
        s['grants'][tid]={**deepcopy(p),'principal':principal,'remaining':p['limit'],'revoked':False,'issuer':actor}
        stamp_grant(s,s['grants'][tid],p,None if p['parent'] is None else s['grants'][p['parent']])
        if s.get('protocol')in {CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
            from .continuity import authority_epoch
            s['grants'][tid]['continuity_epoch']=authority_epoch(s,principal)
    elif op=='REVOKE':
        exact(p,'grant');need(p['grant'] in s['grants'],'GRANT_MISSING');g=s['grants'][p['grant']]
        need(actor in {g['principal'],g['issuer']},'REVOKE_AUTHORITY');g['revoked']=True;parents=[p['grant']]
    elif op=='RECLAIM':
        exact(p,'grant');need(p['grant'] in s['grants'],'GRANT_MISSING');g=s['grants'][p['grant']]
        need(actor==g['principal'],'RECLAIM_AUTHORITY')
        try:live_grant(s,p['grant'],height)
        except ValueError as exc:need(str(exc)=='GRANT_INACTIVE','GRANT_ERROR')
        else:raise ValueError('GRANT_STILL_LIVE')
        add(s['authority_available'],actor,g['resource'],g['remaining']);g['remaining']=0;parents=[p['grant']]
    elif op=='BIND':
        if s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION}:
            from .governance import admission_paused
            need(not admission_paused(s,'BIND'),'NEW_AGREEMENTS_PAUSED')
        exact(p,'terms assents');t=p['terms'];_terms(s,t,height)
        from .principal_override import enforce_bind, required_signers
        enforce_bind(s,t,height)
        need(actor in {t['agent'],t['counterparty']},'SUBMIT_PARTY')
        required=required_signers(s,t,height)
        need(type(p['assents']) is list and len(p['assents'])==len(required),'ASSENTS')
        signers=set()
        for a in p['assents']:
            exact(a,'signer signature');need(a['signer'] not in signers,'DUPLICATE_ASSENT');signers.add(a['signer'])
            verify(controller(s,a['signer']),'COVENANT-ASSENT-0.1',t,a['signature'])
        need(signers==required,'ASSENT_PARTIES')
        cid=agreement_id(t);need(cid not in s['agreements'],'ALREADY_BOUND')
        add(s['balances'],t['principal'],t['resource'],-t['quantity'])
        if t['mandate'] is None:add(s['authority_available'],t['principal'],t['resource'],-t['quantity'])
        else:
            from .resolution_rules import bind_grant
            bind_grant(s,s['grants'][t['mandate']],t)
            s['grants'][t['mandate']]['remaining']-=t['quantity'];parents=[t['mandate']]
        s['agreements'][cid]={'terms':deepcopy(t),'assents':deepcopy(p['assents']),'formation':tid,'height':height,'state':'BOUND','held':True,'decision':None,'challenge_end':None,'appeal_final':False,'evidence':[],'history':[tid]}
        if s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION}:
            from .governance import pin_rules
            pin_rules(s,s['agreements'][cid])
            if 'panel' in t:
                from .resolution_rules import PANEL_VERSION, _resolution
                panel=t['panel']
                if not (_resolution(s) and type(panel) is dict and panel.get('v')==PANEL_VERSION):
                    from .arbitration import accept_bind
                    accept_bind(s,s['agreements'][cid],height)
    elif op=='SAY':
        from .salted_terms import accept_say
        if not accept_say(s,p,height):
            exact(p,'subject content_hash description parents');key(p['content_hash'])
            need(type(p['subject']) is str and type(p['description']) is str,'CLAIM')
            need(type(p['parents']) is list and p['parents']==sorted(set(p['parents'])) and len(p['parents'])<=32,'PARENTS')
            need(all(x in s['events'] for x in p['parents']),'MISSING_PARENT')
        parents=p['parents']
    elif op=='SHOW':
        from .resolution_rules import _resolution, accept_show as resolution_show
        from .salted_terms import accept_show as salted_show
        from .principal_override import evidence_actors
        salted=False
        if not _resolution(s):
            salted=salted_show(s,p,height)
            if not salted:exact(p,'agreement content_hash description')
        key(p['content_hash'])
        need(p['agreement'] in s['agreements'],'AGREEMENT');a=s['agreements'][p['agreement']];t=a['terms']
        if _resolution(s):resolution_show(s,p)
        elif 'panel' in t:raise ValueError('PANEL_PROCEDURE')
        need(actor in evidence_actors(s,t,height),'EVIDENCE_AUTHORITY')
        if salted:need(a['held'],'EVIDENCE_STATE')
        else:need(type(p['description']) is str and a['held'],'EVIDENCE_STATE')
        s['evidence'][tid]={**deepcopy(p),'actor':actor,'height':height};a['evidence'].append(tid);parents=[a['formation']]
    elif op in {'DECIDE','RESOLVE'}:
        from .resolution_rules import _resolution, decision_gate, schedule_indeterminate
        exact(p,'agreement result evidence');need(p['agreement'] in s['agreements'],'AGREEMENT')
        a=s['agreements'][p['agreement']];t=a['terms'];need(a['held'],'ALREADY_DISCHARGED')
        if 'panel' in t and not _resolution(s):raise ValueError('PANEL_PROCEDURE')
        need(p['result'] in {'SUPPORTED','REFUTED','INDETERMINATE'},'RESULT');_evidence_refs(s,p['agreement'],p['evidence'])
        final=True
        if op=='DECIDE':
            if _resolution(s):final=decision_gate(s,a,t,actor,p)=='final'
            if final and not a.get('panel_tally'):need(actor==t['resolver'] and a['state'] in {'BOUND','INDETERMINATE'} and not a['appeal_final'],'RESOLVER_STATE')
        else:
            need(actor==(_seated_appeal(a,t) if _resolution(s) else t['appeal_resolver']) and a['state']=='CHALLENGED','APPEAL_AUTHORITY')
            if _resolution(s):need(height<=_appeal_until(a,t),'APPEAL_WINDOW')
            a['appeal_final']=True
        if final:
            a['decision']={'result':p['result'],'evidence':list(p['evidence']),'actor':actor,'event':tid}
            a['state']='INDETERMINATE' if p['result']=='INDETERMINATE' else 'DECIDED';a['challenge_end']=height+t['challenge_blocks']
            if p['result']=='INDETERMINATE':schedule_indeterminate(s,a,t,height)
        a['history'].append(tid)
        parents=sorted(set([a['formation']]+p['evidence']))
    elif op=='CHALLENGE':
        exact(p,'agreement evidence');need(p['agreement'] in s['agreements'],'AGREEMENT');a=s['agreements'][p['agreement']];t=a['terms']
        if 'panel' in t:raise ValueError('PANEL_PROCEDURE')
        from .principal_override import challenge_actors
        need(actor in challenge_actors(s,t,height) and a['state'] in {'DECIDED','INDETERMINATE'} and not a['appeal_final'],'CHALLENGE_AUTHORITY_STATE')
        need(height<=a['challenge_end'],'CHALLENGE_CLOSED');_evidence_refs(s,p['agreement'],p['evidence'])
        a['state']='CHALLENGED';a['history'].append(tid);parents=sorted(set([a['decision']['event']]+p['evidence']))
    elif op in {'EXECUTE','RELEASE'}:
        from .resolution_rules import _resolution, release_fields, bind_custody, require_panel
        if _resolution(s):
            exact(p,release_fields(s));need(p['agreement'] in s['agreements'],'AGREEMENT');a=s['agreements'][p['agreement']];t=a['terms']
            bind_custody(s,state,p,height,tid)
            need(a['held'],'ALREADY_DISCHARGED')
            if op=='EXECUTE':require_panel(s,a,t)
            if _replace_silent_appeal(s,a,t,height,tid):
                a['history'].append(tid);parents=[a['formation'],a['decision']['event']]
            elif op=='EXECUTE':
                stood=_award_stands(s,a,t,height)
                decision=a.get('decision')
                pay_due=(_resolution(s) and a.get('deadline_outcome')=='PAY'
                    and a.get('release_height') is not None and height>a['release_height'] and decision
                    and decision['result']=='INDETERMINATE' and (a['state']=='INDETERMINATE' or stood))
                award_execute=bool(decision) and decision['result']=='SUPPORTED' and height>a['challenge_end'] and (a['state']=='DECIDED' or stood)
                need(pay_due or award_execute,'NOT_EXECUTABLE')
                if award_execute and stood:_close_lapsed_appeal(a,t,height,tid)
                if pay_due and stood:
                    _record_silent_judge(a,t,height,tid);a['appeal_final']=True;a['appeal_basis']='DEADLINE_OUTCOME'
                if t['effect']=='TRANSFER':
                    add(s['balances'],t['counterparty'],t['resource'],t['quantity']);add(s['authority_available'],t['counterparty'],t['resource'],t['quantity'])
                else:s['consumed'][t['resource']]+=t['quantity']
                eid=digest('COVENANT-EFFECT-0.1',{'agreement':p['agreement'],'effect':t['effect'],'destination':t['destination'],'executor':t['executor']})
                need(eid not in s['effects'],'EFFECT_REPLAY')
                s['effects'][eid]={'agreement':p['agreement'],'effect':t['effect'],'destination':t['destination'],'executor':t['executor'],'status':'AUTHORIZED','receipt':None,'event':tid}
                a['effect_id']=eid;a['state']='AUTHORIZED';a['held']=False;a['history'].append(tid);parents=[a['formation']]
            else:
                refuted=a['state']=='DECIDED' and a['decision']['result']=='REFUTED' and height>a['challenge_end']
                timedout=a['state'] in {'BOUND','INDETERMINATE'} and t['timeout']=='RELEASE_IF_UNDECIDED' and height>t['deadline'] and (a['challenge_end'] is None or height>a['challenge_end'])
                silent=_resolution(s) and a['state']=='BOUND' and a['decision'] is None and height>t['deadline']
                stood=_award_stands(s,a,t,height)
                award_release=stood and a['decision']['result']=='REFUTED'
                indeterminate=_resolution(s) and a.get('deadline_outcome','REFUND')=='REFUND' and (
                    (a['state']=='INDETERMINATE' and a.get('release_height') is not None and height>a['release_height'])
                    or (stood and a['decision']['result']=='INDETERMINATE'))
                if award_release:_close_lapsed_appeal(a,t,height,tid)
                if indeterminate:
                    if stood:_record_silent_judge(a,t,height,tid);a['appeal_final']=True
                    a['appeal_basis']='DEADLINE_OUTCOME'
                need(refuted or timedout or silent or award_release or indeterminate,'NOT_RELEASABLE')
                add(s['balances'],t['principal'],t['resource'],t['quantity']);add(s['authority_available'],t['principal'],t['resource'],t['quantity']);a['state']='RELEASED'
                a['held']=False;a['history'].append(tid);parents=[a['formation']]
            if a['decision']:parents.append(a['decision']['event'])
        else:
            exact(p,'agreement');need(p['agreement'] in s['agreements'],'AGREEMENT');a=s['agreements'][p['agreement']];t=a['terms']
            need(a['held'],'ALREADY_DISCHARGED')
            if op=='EXECUTE':
                need(a['state']=='DECIDED' and a['decision']['result']=='SUPPORTED' and height>a['challenge_end'],'NOT_EXECUTABLE')
                if t['effect']=='TRANSFER':
                    add(s['balances'],t['counterparty'],t['resource'],t['quantity']);add(s['authority_available'],t['counterparty'],t['resource'],t['quantity'])
                else:s['consumed'][t['resource']]+=t['quantity']
                eid=digest('COVENANT-EFFECT-0.1',{'agreement':p['agreement'],'effect':t['effect'],'destination':t['destination'],'executor':t['executor']})
                need(eid not in s['effects'],'EFFECT_REPLAY')
                s['effects'][eid]={'agreement':p['agreement'],'effect':t['effect'],'destination':t['destination'],'executor':t['executor'],'status':'AUTHORIZED','receipt':None,'event':tid}
                a['effect_id']=eid;a['state']='AUTHORIZED'
            else:
                refuted=a['state']=='DECIDED' and a['decision']['result']=='REFUTED' and height>a['challenge_end']
                timedout=a['state'] in {'BOUND','INDETERMINATE'} and t['timeout']=='RELEASE_IF_UNDECIDED' and height>t['deadline'] and (a['challenge_end'] is None or height>a['challenge_end'])
                # 0.1-0.14 stop here. 0.15 may also refund a HOLD covenant, and only
                # when that covenant's own pinned rules include the feature. An
                # INDETERMINATE ruling stays locked. Silence is not a ruling.
                silent=False;appeal_silent=False;panel_silent=False
                if s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION}:
                    from .governance import obligation_active
                    live=obligation_active(a,'silent_referee_release') and t['timeout']=='HOLD_FOR_RESOLUTION'
                    silent=live and a['state']=='BOUND' and a['decision'] is None and height>t['deadline']
                    appeal_silent=live and a['state']=='CHALLENGED' and not a['appeal_final'] and a['challenge_end'] is not None and height>a['challenge_end']+t['challenge_blocks'] and height>t['deadline']
                    if 'panel' in t:
                        from .arbitration import panel_missed
                        panel_silent=panel_missed(s,a,height)
                need(refuted or timedout or silent or appeal_silent or panel_silent,'NOT_RELEASABLE')
                if panel_silent:
                    from .arbitration import settle_miss
                    settle_miss(s,a,tid,height)
                add(s['balances'],t['principal'],t['resource'],t['quantity']);add(s['authority_available'],t['principal'],t['resource'],t['quantity']);a['state']='RELEASED'
            a['held']=False;a['history'].append(tid);parents=[a['formation']]
            if a['decision']:parents.append(a['decision']['event'])
    elif op=='RECEIPT':
        exact(p,'effect content_hash outcome');key(p['content_hash']);need(p['effect'] in s['effects'],'EFFECT_MISSING');e=s['effects'][p['effect']]
        need(actor==e['executor'] and e['receipt'] is None,'RECEIPT_AUTHORITY_REPLAY')
        need(p['outcome'] in {'REPORTED_SUCCESS','REPORTED_FAILURE','UNKNOWN'},'OUTCOME')
        e['receipt']={**deepcopy(p),'actor':actor,'event':tid};e['status']=p['outcome'];parents=[e['event']]
    elif op in {'AMEND','MIGRATE'} and s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION}:
        if 'proposal' in p:exact(p,'agreement assents proposal')
        else:exact(p,'agreement assents')
        need(p['agreement'] in s['agreements'],'AGREEMENT');a=s['agreements'][p['agreement']];t=a['terms']
        need(a['held'],'AMEND_CLOSED')
        from .governance import rules_in_force
        target=rules_in_force(s);need(target is not None,'RULES_ABSENT')
        proposal=p.get('proposal')
        if proposal is not None:
            key(proposal);prop=s['governance_proposals'].get(proposal)
            need(prop is not None and prop.get('kind')=='UPGRADE' and prop.get('status')=='ACTIVE','MIGRATION')
        body={'chain':s['chain'],'agreement':p['agreement'],'formation':a['formation'],'action':'MIGRATE','rules_hash':target['rules_hash']}
        if proposal is not None:body['proposal']=proposal
        required={t['principal'],t['agent'],t['counterparty']};seen=set()
        need(type(p['assents']) is list and len(p['assents'])==len(required),'AMEND_ASSENTS')
        for consent in p['assents']:
            exact(consent,'signer signature');who=consent['signer'];need(who in required and who not in seen,'AMEND_SIGNER')
            verify(controller(s,who),'COVENANT-AMEND-1',body,consent['signature']);seen.add(who)
        need(seen==required,'AMEND_ASSENTS')
        a['rules']=target;a.setdefault('migrations',[]).append({'event':tid,'rules_hash':target['rules_hash'],'proposal':proposal})
        a['history'].append(tid);parents=[a['formation']]
    elif s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and (op.startswith('PANEL_') or op.startswith('ARBITRATOR_')):
        from .arbitration import apply as arbitration_apply
        extension=arbitration_apply(s,state,op,p,actor,tid,height)
        need(extension is not None,'UNKNOWN_OPERATION');parents=extension
    elif op in {'ADOPT_PRINCIPAL_POLICY','PRINCIPAL_REVERSE'}:
        from .principal_override import apply_principal
        parents=apply_principal(s,op,p,actor,tid,height)
    else:raise ValueError('UNKNOWN_OPERATION')
    if s.get('protocol') in {REVIEW_VERSION,PREDICTION_VERSION} or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'review_jobs' in s):
        from .review import after as review_after
        review_after(s,op,p,tid,height)
    if s.get('protocol') in {ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        from .economics import charge
        charge(s,state,tx,economic_policy,tid,height)
    if s.get('protocol') in {MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION} or (s.get('protocol') in {UPGRADE_VERSION,MIGRATION_VERSION} and 'market_meter' in s):
        from .market import meter
        meter(s,tx)
    s['nonces'][actor]=b['nonce']+1;s['events'][tid]={'actor':actor,'op':op,'height':height,'parents':sorted(set(parents))}
    if s.get('protocol') in {NEXT_VERSION,LIFECYCLE_VERSION,SHIELDED_VERSION,ECOSYSTEM_VERSION,MISSION_VERSION,FEDERATION_VERSION,EXTENSIBLE_VERSION,ECONOMIC_VERSION,CONFIDENTIAL_VERSION,CONTINUITY_VERSION,MARKET_VERSION,REVIEW_VERSION,PREDICTION_VERSION,UPGRADE_VERSION,MIGRATION_VERSION}:
        check_deltas(s);seal(s)
    else:invariant(s);canonical(s)
    if s.get('protocol') in {TOKENOMICS_VERSION,MIGRATION_VERSION}:
        policy = s.get('economic_policy')
        if policy is not None and 'scale' in policy:
            from .token_invariants import check
            violations = check(state, s, b['op'])
            need(not violations, violations[0] if violations else 'CORE')
    return s
