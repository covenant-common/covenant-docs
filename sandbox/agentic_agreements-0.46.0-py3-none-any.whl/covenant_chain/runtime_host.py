"""Owner-configured JSON host for optional consequential stdio tools.

Never use an agent/counterparty-provided config. This is a trusted local signer
custodian; private keys stay outside tool arguments. No automatic judge or assent
is installed. Approvals come from exact externally signed proofs.
"""
from covenant_chain.crypto import genesis_id
from pathlib import Path
import os,stat
from .agent_tools import decode,_fields
from .crypto import need,load_private,digest
from .client import Client
from .workflow import WorkflowRuntime
from .adapters import AdapterRegistry,FileAdapter,RecordAdapter
from .market_runtime import MarketRuntime,MarketPolicy
from .workflow_tools import WorkflowTools


def private_text(path,max_bytes=1000000):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        info=os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode)&0o077==0,'HOST_PRIVATE_KEY_FILE')
        raw=os.read(fd,max_bytes+1);need(len(raw)<=max_bytes,'HOST_PRIVATE_KEY_SIZE')
        return raw.decode('utf-8')
    finally:os.close(fd)


def _guardian_secret(value):
    """JSON guardian files store one hex secret; the signer needs bytes."""
    if type(value) is dict and set(value)=={'secret'}:value=value['secret']
    if type(value) is str:
        import re
        need(re.fullmatch(r'[0-9a-f]+',value) is not None and len(value)%2==0,'HOST_GUARDIAN_SECRET')
        return bytes.fromhex(value)
    need(type(value) is bytes,'HOST_GUARDIAN_SECRET')
    return value


def guardian_secrets(value):
    """Load either one combined guardian file or one file per guardian, never both."""
    combined='guardian_file' in value;split='guardian_share_files' in value
    need(not (combined and split),'HOST_GUARDIAN_SPLIT')
    if split:
        shares=value['guardian_share_files']
        need(type(shares) is dict and 1<=len(shares)<=3,'HOST_GUARDIAN_SPLIT')
        loaded={}
        for member,path in shares.items():
            need(type(member) is str and type(path) is str,'HOST_GUARDIAN_SPLIT')
            loaded[member]=_guardian_secret(decode(private_text(path)))
        return loaded
    if combined:
        loaded=decode(private_text(value['guardian_file']))
        need(type(loaded) is dict and loaded,'HOST_GUARDIAN_REQUIRED')
        return {member:_guardian_secret(secret) for member,secret in loaded.items()}
    return None


def history_reader(client,max_blocks=10000,max_bytes=128*1024*1024):
    def read():
        import json
        result=[];size=0;start=1
        while True:
            page=client.blocks(start)
            need(type(page) is list and len(page)<=16,'HOST_HISTORY_PAGE')
            if not page:return result
            for entry in page:
                need(entry['block']['height']==start,'HOST_HISTORY_SEQUENCE')
                size+=len(json.dumps(entry));need(size<=max_bytes and len(result)<max_blocks,'HOST_HISTORY_LIMIT')
                result.append(entry);start+=1
            # A short page may be byte-limited. Ask again until an empty page.
    return read


class RuntimeHost:
    def __init__(self,config,*,proof_registry=None,extra_adapters=(),privacy_desk=None,mechanism_registry=None,access_desks=(),identity_desks=(),reviewer_acceptances=(),applications=None,builders=None,navigation=None,discovery_index=None):
        _fields(config,('version','read_tools'),('workflow','feedback','memory','cooperation','network','commerce','privacy','validator','local_keys','directory_board','a2a','requests','settlement'))
        need(config['version']=='covenant-runtime-host/0.1','HOST_VERSION')
        self.closers=[];workflow=markets=feedback=memory=cooperation=network=exchange=None
        local_keys=None
        board=None
        settlement_flags=None
        if 'settlement' in config:
            # Owner opt-in for the experimental settlement plugins. Every flag defaults off.
            from .settlement_plugins.flags import HostFlags
            settlement_flags=HostFlags.from_config(config['settlement'])
        read_adapters=None
        requests=None
        if 'local_keys' in config:
            from .onboarding import LocalKeyStore
            _fields(config['local_keys'],('directory',))
            local_keys=LocalKeyStore(config['local_keys']['directory'])
        try:
            if 'requests' in config:
                from .request_workspace import RequestWorkspace
                _fields(config['requests'],('directory',))
                requests=RequestWorkspace(config['requests']['directory'])
                self.closers.append(requests)
            if 'workflow' in config:
                w=config['workflow']
                _fields(w,('directory','genesis','chain','rpc','templates','signers','adapters',
                           'maximum_fees','lifetime_fee_budget','lifetime_service_budget'),('minimum_height','market_policy','task_fee_budget'))
                need(genesis_id(w['genesis'])==w['chain'],'HOST_GENESIS_PIN')
                client=Client(**w['rpc']);registry=AdapterRegistry()
                for a in w['adapters']:
                    _fields(a,('kind','directory'),('namespace','max_bytes','unit','balances','fee_policy','inventory','http_routes','file_roots','tcp_endpoints','timeout','max_request_bytes','max_response_bytes','agents','allow_insecure_loopback','max_wire_bytes','models','headers','endpoint','max_output_tokens'))
                    need(a['kind'] in {'FILE','RECORD','EXPR','PAYMENT_DEMO','ESCROW_DEMO','CONNECTOR','A2A','GROK'},'HOST_ADAPTER_KIND')
                    options={k:v for k,v in a.items() if k!='kind'}
                    if a['kind']=='GROK':
                        from .grok_connector import GrokConnector
                        _fields(a,('kind','directory','models','headers'),('endpoint','allow_insecure_loopback','timeout','max_request_bytes','max_wire_bytes','max_output_tokens'))
                        adapter=GrokConnector(**options)
                    elif a['kind']=='A2A':
                        from .a2a_connector import A2AConnector
                        _fields(a,('kind','directory','agents'),('allow_insecure_loopback','timeout','max_request_bytes','max_wire_bytes'))
                        adapter=A2AConnector(**options)
                    elif a['kind']=='CONNECTOR':
                        from .connector_harness import ConnectorHarness
                        _fields(a,('kind','directory'),('http_routes','file_roots','tcp_endpoints','timeout','max_request_bytes','max_response_bytes'))
                        adapter=ConnectorHarness(**options)
                    elif a['kind']=='PAYMENT_DEMO':
                        from .payment_rails import DemoPaymentRail
                        adapter=DemoPaymentRail(**options)
                    elif a['kind']=='ESCROW_DEMO':
                        from .escrow_desk import DemoEscrowDesk
                        adapter=DemoEscrowDesk(**options)
                    elif a['kind']=='EXPR':
                        from .expression_adapter import ExpressionRecordAdapter
                        adapter=ExpressionRecordAdapter(**options)
                    else:adapter=(FileAdapter if a['kind']=='FILE' else RecordAdapter)(**options)
                    self.closers.append(adapter);registry.register(adapter)
                for adapter in extra_adapters:
                    registry.register(adapter);self.closers.append(adapter)
                signers={}
                for entity,value in w['signers'].items():
                    _fields(value,('key_file',),('guardian_file','guardian_share_files'))
                    operational=load_private(private_text(value['key_file']))
                    need(not ('guardian_file' in value and 'guardian_share_files' in value),'HOST_GUARDIAN_SPLIT')
                    guardian_spec={k:value[k] for k in ('guardian_file','guardian_share_files') if k in value}
                    def factory(state,entity=entity,k=operational,spec=guardian_spec):
                        if entity in state.get('continuity_policies',{}):
                            from .continuity import GuardedSigner
                            need(bool(spec),'HOST_GUARDIAN_REQUIRED')
                            def load(spec=spec):
                                # Both layouts decode hex secrets to bytes; a combined file is not raw hex text.
                                return guardian_secrets(spec)
                            return GuardedSigner(state,entity,k,guardian_loader=load)
                        return k
                    signers[entity]=factory
                workflow=WorkflowRuntime(w['directory'],w['genesis'],w['chain'],client,history_reader(client),
                    w['templates'],signers,registry,maximum_fees=w['maximum_fees'],lifetime_fee_budget=w['lifetime_fee_budget'],
                    lifetime_service_budget=w['lifetime_service_budget'],minimum_height=w.get('minimum_height',0),
                    task_fee_budget=w.get('task_fee_budget'))
                self.closers.append(workflow)
                if 'market_policy' in w:
                    p=dict(w['market_policy'])
                    for k in ('source_policies','primary_members','appeal_members'):p[k]=tuple(p[k])
                    markets=MarketRuntime(workflow,MarketPolicy(**p))
            if 'feedback' in config:
                from .feedback import FeedbackDesk
                from .feedback_channel import FeedbackChannel
                f=config['feedback'];_fields(f,('path','domain','owner','reporter_key_file'),('recipient','reporters'))
                # The containing directory must already be private and owner-managed.
                d=Path(f['path']).parent
                need(d.is_dir() and not d.is_symlink() and stat.S_IMODE(d.stat().st_mode)&0o077==0,'HOST_FEEDBACK_DIRECTORY')
                desk=FeedbackDesk(f['path'],f['domain'],f['owner'],reporters=f.get('reporters'));self.closers.append(desk)
                feedback=FeedbackChannel(desk,load_private(private_text(f['reporter_key_file'])),f.get('recipient'))
            if 'memory' in config:
                from covenant_language.practices import PracticeStore
                m=config['memory'];_fields(m,('path','trusted_authors'))
                d=Path(m['path']).parent
                need(d.is_dir() and not d.is_symlink() and stat.S_IMODE(d.stat().st_mode)&0o077==0 and not Path(m['path']).is_symlink(),'HOST_MEMORY_DIRECTORY')
                memory=PracticeStore(m['path'],m['trusted_authors']);os.chmod(m['path'],0o600);self.closers.append(memory)
            if 'cooperation' in config:
                from .cooperation_interface import CooperationInterface
                from .procedure_library import ProcedureLibrary
                c=config['cooperation'];_fields(c,('version',),('quote_blocks','library_directory','adoptions'))
                need(c['version']=='covenant-cooperation-interface/0.1','HOST_COOPERATION_VERSION')
                need(workflow is None or workflow.task_fee_budget is not None,'COOPERATION_COST_POLICY_REQUIRED')
                library=ProcedureLibrary(c['library_directory']) if 'library_directory' in c else None
                if library:self.closers.append(library)
                cooperation=CooperationInterface(workflow,quote_blocks=c.get('quote_blocks',8),library=library,adoptions=c.get('adoptions'))
            if 'network' in config:
                from .agent_network import AgentNetwork
                n=config['network'];_fields(n,('directory','domain','key_file','peers'),('seeds',))
                network=AgentNetwork(n['directory'],n['domain'],load_private(private_text(n['key_file'])),n['peers'],n.get('seeds'))
                self.closers.append(network)
            fee_policy=None
            if 'commerce' in config:
                _fields(config['commerce'],('fee_policy',));fee_policy=config['commerce']['fee_policy']
            if 'privacy' in config:
                from .privacy_scopes import PrivacyDesk
                privacy_config=config['privacy'];_fields(privacy_config,('recipient_key_files',))
                recipient_keys={}
                for alias,path in privacy_config['recipient_key_files'].items():
                    record=decode(private_text(path));_fields(record,('public','secret'))
                    public=bytes.fromhex(record['public']);secret=bytes.fromhex(record['secret'])
                    need(len(public)==1184 and len(secret)==2400,'PRIVACY_RECIPIENT_KEY')
                    recipient_keys[alias]={'public':public,'secret':secret}
                need(privacy_desk is None,'PRIVACY_DUPLICATE_CONFIGURATION');privacy_desk=PrivacyDesk(recipient_keys)
            if 'directory_board' in config:
                from .directory_board import DirectoryBoard
                spec=config['directory_board'];_fields(spec,('path',),('key_file','chain'))
                signer=load_private(private_text(spec['key_file'])) if 'key_file' in spec else None
                board=DirectoryBoard(spec['path'],signer,spec.get('chain','a'*64))
            if config.get('a2a',{}).get('default') is True and workflow is None:
                from .a2a_connector import default_adapter
                a2a=config['a2a'];_fields(a2a,('default','directory'),())
                need(a2a['default'] is True,'HOST_A2A')
                a2a_path=Path(a2a['directory']);a2a_path.mkdir(parents=True,exist_ok=True);os.chmod(a2a_path,0o700)
                adapter=default_adapter(a2a['directory']);self.closers.append(adapter)
                read_adapters=AdapterRegistry();read_adapters.register(adapter)
            if discovery_index is not None or navigation is not None or requests is not None or local_keys is not None or cooperation is not None or network is not None or board is not None or read_adapters is not None or settlement_flags is not None or 'commerce' in config or 'privacy' in config or access_desks or identity_desks or reviewer_acceptances or applications is not None or builders is not None or mechanism_registry is not None or (workflow is not None and any(m['capability']=='connector.invoke' for m in workflow.adapters.describe().values())):
                from .agent_exchange_tools import ExchangeTools
                exchange=ExchangeTools(network=network,workflow=workflow,markets=markets,fee_policy=fee_policy,proofs=proof_registry,privacy=privacy_desk,mechanisms=mechanism_registry,access_desks=access_desks,identity_desks=identity_desks,reviewer_acceptances=reviewer_acceptances,applications=applications,builders=builders,local_keys=local_keys,board=board,adapters=read_adapters,requests=requests,settlement_flags=settlement_flags,navigation=navigation,discovery_index=discovery_index)
            validator=None
            if 'validator' in config:
                from .validator_ops import OperatorDesk
                v=config['validator'];_fields(v,('member','key_file','committee'))
                validator=OperatorDesk(v['member'],load_private(private_text(v['key_file'])),v['committee'])
            self.tools=WorkflowTools(config['read_tools'],workflow=workflow,markets=markets,feedback=feedback,memory=memory,cooperation=cooperation,exchange=exchange,validator=validator)
        except BaseException:self.close();raise
    def close(self):
        for value in reversed(self.closers):value.close()
        self.closers=[]
