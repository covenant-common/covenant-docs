"""Selective-disclosure issuer claims bound to did:aap accounts; not ZK or anonymity.

An issuer that has checked agreed evidence (for example an identity-facility
attestation, a live GIVE grant, or a KYB review it performed) signs a batch of
credentials for one did:aap account. The holder later discloses only the claims
a verifier asks for, such as ``verified_agent``, ``principal_kyb`` or
``mandate_at_most``, and keeps the account hidden.

Format: IETF SD-JWT (RFC 9901) with an SD-JWT VC
type and a Key Binding JWT. JWS algorithm EdDSA (Ed25519), digests SHA-256.
Both primitives come from the pinned ``cryptography`` package. Nothing here is
new cryptography: an SD-JWT is a signed list of salted hashes.

This module implements no BBS or zero-knowledge proof. Selective disclosure
hides omitted claim values; it does not hide the issuer, scope, holder key,
disclosed attributes or transport metadata, or establish global unlinkability.

What this proves, and what it does not:
- The pinned issuer signed the disclosed claims for a holder key, and whoever
  presented now controls that holder key (KB-JWT over the verifier's nonce and
  audience).
- Undisclosed claims, including the did:aap account, stay hidden behind 128-bit
  salted hashes. The claim count is padded with decoys.
- Each credential is one-time. Presenting it twice gives the same nullifier, so a
  NullifierSet counts it once. Different credentials from one batch are not
  linkable by verifiers, but the issuer can link every presentation it sees
  back to the account, because it saw the signatures it issued.
- ``SCOPED`` issuance gives one credential per (account, scope). In that scope one
  account counts once, as long as the issuer keeps its issuance record and does
  not mint extra credentials. The issuer learns which scopes an account joins.
- ``BATCH`` credentials are unscoped. One account can present each of its batch
  once in the same scope, so a batch is not one-person-one-count.
- A claim is a point-in-time issuer statement. Revocation is expiry only.

Versions. /0.2 gives each ladder step its own claim name
(``mandate_at_most_<amount>``), so every disclosure in an issued credential has a
distinct name, as the SD-JWT format requires. A standard holder can then pick one
step. /0.1 used one name for every step: the issued credential is refused by a
standard SD-JWT processor, and a standard holder discloses every step, which shows
the tightest one. /0.1 requests and credentials still verify unchanged.

/0.3 (opt-in, attribute_request and CredentialIssuer.issue_attributes) adds
issuer-checked attribute predicates for regulated deals: age_equal_or_over_<N>,
jurisdiction, jurisdiction_in_<SET> (the issuer names the set's members) and
licensed_<activity>, the same "issuer precomputes every true statement" pattern
as the mandate ladder. It may also carry aap_escrow, the id of a disclosure
escrow (accountable_privacy) that k of n authorities can open on a ladder order.
verify_presentation keeps accepting /0.1 and /0.2 only; /0.3 is read through
open_attribute_presentation and attribute_proofs, so no old verifier silently
accepts the new claims.

State. The issuer's request nonces and SCOPED record, and a verifier's
NullifierSet, are replay protection. Pass ``store`` (an owner directory,
covenant-identity-store/0.1) to keep them across restarts.
"""
from copy import deepcopy
import base64
import hashlib
import hmac
import json
import os
import re
import threading
from functools import wraps

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .crypto import canonical, digest, integer, key, need, public_key, verification_key, verify
from .scale.identity import did, resolve_did
from .json_bounds import validate_json

VERSION = 'covenant-hidden-credential/0.2'
LEGACY_VERSION = 'covenant-hidden-credential/0.1'
POLICY_VERSION = 'covenant-hidden-credential-policy/0.1'
REQUEST_LABEL = 'COVENANT-HIDDEN-CREDENTIAL-REQUEST-0.1'
POLICY_LABEL = 'COVENANT-HIDDEN-CREDENTIAL-POLICY-0.1'
NULLIFIER_LABEL = 'COVENANT-HIDDEN-CREDENTIAL-NULLIFIER-0.1'
VCT = 'urn:aap:vct:agent-attributes:0.2'
LEGACY_VCT = 'urn:aap:vct:agent-attributes:0.1'
VCTS = {LEGACY_VERSION: LEGACY_VCT, VERSION: VCT}
STEP_CLAIM = re.compile(r'mandate_at_most_([1-9][0-9]{0,17})\Z')
ISSUER_STORE_KIND = 'covenant-hidden-credential-issuer-state/0.1'
NULLIFIER_STORE_KIND = 'covenant-hidden-credential-nullifiers/0.1'
SD_ALG = 'sha-256'
TYP = 'dc+sd-jwt'
KB_TYP = 'kb+jwt'
MODES = ('SCOPED', 'BATCH')
BOOLEAN_CLAIMS = ('verified_agent', 'principal_kyb')
MAX_BATCH = 16
MAX_LIFETIME = 30 * 86400
MAX_PRESENTATION = 32768
DIGEST_SLOTS = 24
SALT_BYTES = 16
KB_MAX_AGE = 300
RESERVED = frozenset(('_sd', '_sd_alg', '...', 'iss', 'iat', 'exp', 'nbf', 'cnf', 'vct', 'status', 'aap_scope',
                      'aap_mode', 'sub', 'aud', 'jti', 'aap_escrow'))
ATTRIBUTE_VERSION = 'covenant-hidden-credential/0.3'
ATTRIBUTE_VCT = 'urn:aap:vct:agent-attributes:0.3'
ATTRIBUTE_SLOTS = 48
ALL_VCTS = {**VCTS, ATTRIBUTE_VERSION: ATTRIBUTE_VCT}
SLOTS = {LEGACY_VERSION: DIGEST_SLOTS, VERSION: DIGEST_SLOTS, ATTRIBUTE_VERSION: ATTRIBUTE_SLOTS}
AGE_CLAIM = re.compile(r'age_equal_or_over_([1-9][0-9]?|1[0-4][0-9]|150)\Z')
SET_CLAIM = re.compile(r'jurisdiction_in_([A-Z][A-Z0-9_]{0,31})\Z')
LICENCE_CLAIM = re.compile(r'licensed_([a-z][a-z0-9_]{0,39})\Z')
JURISDICTION = re.compile(r'[A-Z]{2}(-[A-Z0-9]{1,3})?\Z')
SET_NAME = re.compile(r'[A-Z][A-Z0-9_]{0,31}\Z')
ACTIVITY = re.compile(r'[a-z][a-z0-9_]{0,39}\Z')
MAX_ATTRIBUTE_ITEMS = 8
MAX_SET_MEMBERS = 64

PROVES = ['the pinned issuer signed each disclosed claim for this one holder key',
          'the presenter controls that holder key now (KB-JWT bound to the verifier nonce and audience)',
          'a stable nullifier to check and record separately before counting a credential']
DOES_NOT_PROVE = ['who the account is, unless the holder disclosed the account claim',
                  'that the issuer checked its evidence honestly; trust in the issuer is pinned by the verifier',
                  'that a claim is still true after issuance; revocation is expiry only',
                  'unlinkability against the issuer: the issuer can link presentations it sees to the account',
                  'one-person-one-count across a BATCH; only SCOPED issuance limits an account to one credential per scope',
                  'any authority to sign, spend or bind; execution_authorized is always false']


def _serialized(method):
    @wraps(method)
    def invoke(self, *args, **kwargs):
        with self._lock:
            return method(self, *args, **kwargs)
    return invoke


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _unb64(text, maximum=MAX_PRESENTATION):
    need(type(text) is str and 0 < len(text) <= maximum and text.isascii(), 'CREDENTIAL_ENCODING')
    need(all(c.isalnum() or c in '-_' for c in text), 'CREDENTIAL_ENCODING')
    try:
        raw = base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))
    except (ValueError, TypeError):
        raise ValueError('CREDENTIAL_ENCODING') from None
    need(_b64(raw) == text, 'CREDENTIAL_ENCODING')
    return raw


def _json(raw):
    def pairs(items):
        result = {}
        for name, value in items:
            need(name not in result, 'CREDENTIAL_DUPLICATE_JSON_KEY')
            result[name] = value
        return result
    def bad_number(_):
        raise ValueError('CREDENTIAL_JSON_NUMBER')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                           parse_float=bad_number, parse_constant=bad_number)
        validate_json(value)
    except (UnicodeError, ValueError, RecursionError):
        raise ValueError('CREDENTIAL_JSON') from None
    return value


def _wire(value):
    validate_json(value)
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')


def _jwk(public_hex):
    verification_key(public_hex)
    return {'kty': 'OKP', 'crv': 'Ed25519', 'x': _b64(bytes.fromhex(public_hex))}


def _jwk_public(jwk):
    need(type(jwk) is dict and set(jwk) == {'kty', 'crv', 'x'} and jwk['kty'] == 'OKP' and jwk['crv'] == 'Ed25519',
         'CREDENTIAL_HOLDER_KEY')
    raw = _unb64(jwk['x'], 64)
    need(len(raw) == 32, 'CREDENTIAL_HOLDER_KEY')
    verification_key(raw.hex())
    return raw.hex()


def _jws(private, header, payload):
    signing = _b64(_wire(header)) + '.' + _b64(_wire(payload))
    return signing + '.' + _b64(private.sign(signing.encode('ascii')))


def _open_jws(token, public_hex, typ):
    need(type(token) is str and token.count('.') == 2, 'CREDENTIAL_JWS')
    head, body, signature = token.split('.')
    header = _json(_unb64(head, 4096))
    need(type(header) is dict and header == {'alg': 'EdDSA', 'typ': typ}, 'CREDENTIAL_JWS_HEADER')
    raw = _unb64(signature, 128)
    need(len(raw) == 64, 'CREDENTIAL_SIGNATURE')
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex)).verify(raw, (head + '.' + body).encode('ascii'))
    except InvalidSignature:
        raise ValueError('CREDENTIAL_SIGNATURE') from None
    payload = _json(_unb64(body))
    need(type(payload) is dict, 'CREDENTIAL_JWS')
    return payload


def _disclosure_digest(encoded):
    return _b64(hashlib.sha256(encoded.encode('ascii')).digest())


def _ladder(value):
    need(type(value) is list and 1 <= len(value) <= 12, 'CREDENTIAL_LADDER')
    for step in value:
        integer(step, True)
    need(value == sorted(set(value)), 'CREDENTIAL_LADDER')
    return value


def _resource(value):
    need(type(value) is str and 0 < len(value) <= 80 and value.isprintable(), 'CREDENTIAL_RESOURCE')
    return value


def _scope(value):
    need(value is None or (type(value) is str and 0 < len(value) <= 256 and value.isascii() and value.isprintable()),
         'CREDENTIAL_SCOPE')
    return value


def _members(value):
    need(type(value) is list and 1 <= len(value) <= MAX_SET_MEMBERS and value == sorted(set(value))
         and all(type(code) is str and JURISDICTION.fullmatch(code) for code in value), 'CREDENTIAL_ATTRIBUTES')
    return value


def _attributes(value):
    """Issuer-checked attribute predicates for /0.3; every listed statement must be true when issued."""
    need(type(value) is dict and value and set(value) <= {'age_equal_or_over', 'jurisdiction', 'jurisdiction_in',
                                                          'licensed'}, 'CREDENTIAL_ATTRIBUTES')
    out = {}
    if 'age_equal_or_over' in value:
        ages = value['age_equal_or_over']
        need(type(ages) is list and 1 <= len(ages) <= MAX_ATTRIBUTE_ITEMS and ages == sorted(set(ages))
             and all(type(age) is int and 1 <= age <= 150 for age in ages), 'CREDENTIAL_ATTRIBUTES')
        out['age_equal_or_over'] = list(ages)
    if 'jurisdiction' in value:
        need(type(value['jurisdiction']) is str and JURISDICTION.fullmatch(value['jurisdiction']) is not None,
             'CREDENTIAL_ATTRIBUTES')
        out['jurisdiction'] = value['jurisdiction']
    if 'jurisdiction_in' in value:
        sets = value['jurisdiction_in']
        need(type(sets) is dict and 1 <= len(sets) <= MAX_ATTRIBUTE_ITEMS, 'CREDENTIAL_ATTRIBUTES')
        for name, members in sets.items():
            need(type(name) is str and SET_NAME.fullmatch(name) is not None, 'CREDENTIAL_ATTRIBUTES')
            _members(members)
            # A set claim says the holder's jurisdiction is one of the members; the issuer checks it.
            need('jurisdiction' not in out or out['jurisdiction'] in members, 'CREDENTIAL_ATTRIBUTE_FALSE')
        out['jurisdiction_in'] = {name: list(members) for name, members in sorted(sets.items())}
    if 'licensed' in value:
        activities = value['licensed']
        need(type(activities) is list and 1 <= len(activities) <= MAX_ATTRIBUTE_ITEMS
             and activities == sorted(set(activities)) and all(type(item) is str and ACTIVITY.fullmatch(item)
                                                               for item in activities), 'CREDENTIAL_ATTRIBUTES')
        out['licensed'] = list(activities)
    return out


def _attribute_rows(attributes):
    rows = []
    for age in (attributes or {}).get('age_equal_or_over', ()):
        rows.append(['age_equal_or_over_' + str(age), True])
    if attributes and 'jurisdiction' in attributes:
        rows.append(['jurisdiction', attributes['jurisdiction']])
    for name, members in (attributes or {}).get('jurisdiction_in', {}).items():
        rows.append(['jurisdiction_in_' + name, {'set': name, 'members': list(members)}])
    for activity in (attributes or {}).get('licensed', ()):
        rows.append(['licensed_' + activity, True])
    return rows


def claims_template(*, verified_agent=False, principal_kyb=False, mandate=None, ladder=None, principal=None):
    """What the issuer has established. ``mandate`` is {'resource', 'limit'} from a checked grant."""
    need(type(verified_agent) is bool and type(principal_kyb) is bool, 'CREDENTIAL_CLAIMS')
    out = {}
    if verified_agent:
        out['verified_agent'] = True
    if principal_kyb:
        out['principal_kyb'] = True
    if mandate is not None:
        need(type(mandate) is dict and set(mandate) == {'resource', 'limit'}, 'CREDENTIAL_MANDATE')
        _resource(mandate['resource'])
        integer(mandate['limit'])
        steps = _ladder(ladder if ladder is not None else [10 ** n for n in range(0, 10)])
        # Every bucket at or above the real limit is a true "at most" statement.
        buckets = [step for step in steps if step >= mandate['limit']]
        need(bool(buckets), 'CREDENTIAL_LADDER')
        out['mandate_at_most'] = [{'resource': mandate['resource'], 'amount': step} for step in buckets]
    if principal is not None:
        resolve_did(principal)
        out['principal'] = principal
    need(bool(out), 'CREDENTIAL_CLAIMS')
    return out


def mandate_from_state(state, grant, account, height):
    """Read a live native GIVE grant held by ``account``. The claim is true only at this height."""
    from .app import live_grant
    key(grant)
    key(account)
    integer(height)
    row = live_grant(state, grant, height)
    need(row['holder'] == account, 'CREDENTIAL_GRANT_HOLDER')
    return {'resource': row['resource'], 'limit': row['remaining']}


def issuance_request(chain, account, holder_keys, *, mode='SCOPED', scope=None, nonce, version=VERSION):
    """The exact body the did:aap account signs to ask for credentials.

    ``version`` picks the credential format; /0.1 is kept only for old callers.
    """
    need(version in VCTS, 'CREDENTIAL_VERSION')
    key(chain)
    key(account)
    need(mode in MODES, 'CREDENTIAL_MODE')
    _scope(scope)
    need((mode == 'SCOPED') == (scope is not None), 'CREDENTIAL_SCOPE')
    need(type(holder_keys) is list and 1 <= len(holder_keys) <= MAX_BATCH and all(type(k) is str for k in holder_keys)
         and len(set(holder_keys)) == len(holder_keys),
         'CREDENTIAL_BATCH')
    need(mode == 'BATCH' or len(holder_keys) == 1, 'CREDENTIAL_SCOPED_SINGLE')
    for holder in holder_keys:
        verification_key(holder)
        need(holder != account, 'CREDENTIAL_HOLDER_IS_ACCOUNT')
    key(nonce)
    return {'version': version, 'chain': chain, 'account': account, 'holder_keys': list(holder_keys),
            'mode': mode, 'scope': scope, 'nonce': nonce}


def attribute_request(chain, account, holder_keys, *, mode='SCOPED', scope=None, nonce, disclosure=None):
    """The body the did:aap account signs to ask for /0.3 attribute credentials.

    ``disclosure`` names an accountable_privacy policy id the principal consents to:
    the issuer then seals the account-to-pseudonym binding for that policy's
    authorities. With an escrow the request is SCOPED to one holder key, so a
    disclosure order reveals one pseudonym and never links the rest of a batch.
    """
    body = issuance_request(chain, account, holder_keys, mode=mode, scope=scope, nonce=nonce, version=VERSION)
    if disclosure is not None:
        key(disclosure)
        need(len(holder_keys) == 1, 'CREDENTIAL_ESCROW_SINGLE_HOLDER')
        need(mode == 'SCOPED', 'CREDENTIAL_ESCROW_SCOPED')
    return {**body, 'version': ATTRIBUTE_VERSION, 'disclosure': disclosure}


def attribute_claims(*, attributes, verified_agent=False, principal_kyb=False, mandate=None, ladder=None,
                     principal=None):
    """/0.3 claims: the /0.2 claim families plus issuer-checked attribute predicates."""
    base = verified_agent or principal_kyb or mandate is not None or principal is not None
    out = claims_template(verified_agent=verified_agent, principal_kyb=principal_kyb, mandate=mandate, ladder=ladder,
                          principal=principal) if base else {}
    out['attributes'] = _attributes(attributes)
    return out


def new_holder_keys(count):
    """Fresh one-time holder keys. They are not the account key and must never be reused."""
    integer(count, True)
    need(count <= MAX_BATCH, 'CREDENTIAL_BATCH')
    return [Ed25519PrivateKey.generate() for _ in range(count)]


class CredentialIssuer:
    """An owner-run issuer. It signs only after the owner's own evidence check.

    ``issued`` is the persisted record of (account, scope) pairs already served
    in SCOPED mode. Losing it lets one account obtain a second credential for the
    same scope. Request nonces are replay protection too. Pass ``store`` (an owner
    directory) to keep both across restarts; otherwise persist ``issued_record()``
    with the issuer key, and note that the nonces are then lost on restart.
    """

    def __init__(self, issuer_id, signing_key, *, clock, issued=None, lifetime=7 * 86400, store=None):
        self._lock = threading.RLock()
        need(type(issuer_id) is str and 0 < len(issuer_id) <= 256 and issuer_id.isascii(), 'CREDENTIAL_ISSUER')
        need(isinstance(signing_key, Ed25519PrivateKey), 'CREDENTIAL_ISSUER_KEY')
        need(callable(clock), 'CREDENTIAL_CLOCK')
        integer(lifetime, True)
        need(lifetime <= MAX_LIFETIME, 'CREDENTIAL_LIFETIME')
        self.issuer_id = issuer_id
        self._key = signing_key
        self.public = public_key(signing_key)
        self._clock = clock
        self.lifetime = lifetime
        self._issued = set()
        for row in issued or ():
            need(type(row) is str and len(row) == 64, 'CREDENTIAL_ISSUED_RECORD')
            self._issued.add(row)
        self._nonces = set()
        self._lock = threading.RLock()
        self._store = None
        if store is not None:
            from .identity_store import StateFile
            self._store = StateFile(store, 'credential-issuer', kind=ISSUER_STORE_KIND,
                                    context={'issuer': issuer_id, 'key': self.public})
            try:
                saved = self._store.load()
                if saved is not None:
                    need(set(saved) == {'issued', 'nonces'}, 'CREDENTIAL_STORE_STATE')
                    for row in saved['issued'] + saved['nonces']:
                        key(row)
                    self._issued.update(saved['issued'])
                    self._nonces.update(saved['nonces'])
            except BaseException:
                self._store.close()
                raise

    def __repr__(self):
        return f'CredentialIssuer({self.issuer_id!r}, public={self.public!r})'

    def close(self):
        if self._store is not None:
            self._store.close()

    @_serialized
    def issued_record(self):
        return sorted(self._issued)

    def _now(self):
        now = self._clock()
        integer(now)
        return now

    @_serialized
    def issue(self, request, signature, claims):
        """Return one compact SD-JWT (without disclosures selected) per requested holder key."""
        need(type(request) is dict, 'CREDENTIAL_REQUEST')
        checked = issuance_request(request.get('chain', ''), request.get('account', ''),
                                   request.get('holder_keys'), mode=request.get('mode'),
                                   scope=request.get('scope'), nonce=request.get('nonce', ''),
                                   version=request.get('version'))
        need(checked == request, 'CREDENTIAL_REQUEST')
        verify(request['account'], REQUEST_LABEL, request, signature)
        need(type(claims) is dict and claims == claims_template(**_template_args(claims)), 'CREDENTIAL_CLAIMS')
        return self._grant(request, claims, {})

    @_serialized
    def issue_attributes(self, request, signature, claims, *, escrows=None):
        """/0.3: one SD-JWT per holder key with attribute predicates and, if the principal consented, aap_escrow.

        ``escrows`` maps each holder key to the escrow record this issuer sealed for
        it (disclosure_escrow.create_escrow); it is required exactly when the
        signed request names a disclosure policy.
        """
        need(type(request) is dict and request.get('version') == ATTRIBUTE_VERSION, 'CREDENTIAL_VERSION')
        checked = attribute_request(request.get('chain', ''), request.get('account', ''), request.get('holder_keys'),
                                    mode=request.get('mode'), scope=request.get('scope'), nonce=request.get('nonce', ''),
                                    disclosure=request.get('disclosure'))
        need(checked == request, 'CREDENTIAL_REQUEST')
        verify(request['account'], REQUEST_LABEL, request, signature)
        need(type(claims) is dict and 'attributes' in claims, 'CREDENTIAL_ATTRIBUTES')
        base = {name: value for name, value in claims.items() if name != 'attributes'}
        need(claims == attribute_claims(attributes=claims['attributes'], **(_template_args(base) if base else {})),
             'CREDENTIAL_CLAIMS')
        ids = {}
        if request['disclosure'] is None:
            need(escrows is None, 'CREDENTIAL_ESCROW')
        else:
            from .disclosure_escrow import escrow_for_credential
            need(type(escrows) is dict and set(escrows) == set(request['holder_keys']), 'CREDENTIAL_ESCROW')
            for holder, record in escrows.items():
                ids[holder] = escrow_for_credential(record, request=request, signature=signature, holder=holder,
                                                    issuer_key=self.public)
        return self._grant(request, claims, ids)

    def _grant(self, request, claims, escrows):
        """Replay and scope checks, signing, then the durable record, under one lock."""
        slot = None
        if request['mode'] == 'SCOPED':
            slot = digest('COVENANT-HIDDEN-CREDENTIAL-SLOT-0.1',
                          {'account': request['account'], 'scope': request['scope'], 'issuer': self.issuer_id})
        with self._lock:
            need(request['nonce'] not in self._nonces, 'CREDENTIAL_REQUEST_REPLAY')
            need(slot not in self._issued, 'CREDENTIAL_SCOPE_ALREADY_ISSUED')
            now = self._now()
            account_did = did(request['account'], request['chain'])
            out = []
            for holder in request['holder_keys']:
                out.append(self._one(holder, claims, account_did, request, now, escrows.get(holder)))
            self._nonces.add(request['nonce'])
            if slot is not None:
                self._issued.add(slot)
            # Nothing is handed out until the nonce and slot are on disk.
            if self._store is not None:
                try:
                    self._store.save({'issued': sorted(self._issued), 'nonces': sorted(self._nonces)})
                except OSError:
                    self._nonces.discard(request['nonce'])
                    self._issued.discard(slot)
                    raise ValueError('CREDENTIAL_STORE_WRITE') from None
        return {'version': request['version'], 'credentials': out, 'mode': request['mode'], 'scope': request['scope'],
                'issuer': self.issuer_id, 'issuer_key': self.public, 'expires': now + self.lifetime,
                'execution_authorized': False}

    def _one(self, holder, claims, account_did, request, now, escrow=None):
        rows = [['account', account_did]]
        for name in BOOLEAN_CLAIMS:
            if name in claims:
                rows.append([name, True])
        for bucket in claims.get('mandate_at_most', ()):
            if request['version'] == LEGACY_VERSION:
                rows.append(['mandate_at_most', bucket])
            else:
                rows.append(['mandate_at_most_' + str(bucket['amount']), bucket])
        if 'principal' in claims:
            rows.append(['principal', claims['principal']])
        rows += _attribute_rows(claims.get('attributes'))
        slots = SLOTS[request['version']]
        need(len(rows) <= slots, 'CREDENTIAL_CLAIMS')
        disclosures = [_b64(_wire([_b64(os.urandom(SALT_BYTES)), name, value])) for name, value in rows]
        digests = [_disclosure_digest(item) for item in disclosures]
        # Decoys hide how many claims this credential carries.
        digests += [_b64(hashlib.sha256(os.urandom(32)).digest()) for _ in range(slots - len(digests))]
        payload = {'iss': self.issuer_id, 'iat': now, 'exp': now + self.lifetime, 'vct': ALL_VCTS[request['version']],
                   'cnf': {'jwk': _jwk(holder)}, '_sd': sorted(digests), '_sd_alg': SD_ALG,
                   'aap_mode': request['mode']}
        if request['scope'] is not None:
            payload['aap_scope'] = request['scope']
        if escrow is not None:
            payload['aap_escrow'] = escrow
        token = _jws(self._key, {'alg': 'EdDSA', 'typ': TYP}, payload)
        return {'holder_key': holder, 'sd_jwt': token, 'disclosures': disclosures}


def _template_args(claims):
    need(type(claims) is dict and set(claims) <= {'verified_agent', 'principal_kyb', 'mandate_at_most', 'principal'},
         'CREDENTIAL_CLAIMS')
    args = {'verified_agent': claims.get('verified_agent', False), 'principal_kyb': claims.get('principal_kyb', False),
            'principal': claims.get('principal')}
    buckets = claims.get('mandate_at_most')
    if buckets is not None:
        need(type(buckets) is list and buckets and all(type(b) is dict and set(b) == {'resource', 'amount'}
                                                         for b in buckets), 'CREDENTIAL_MANDATE')
        need(len({b['resource'] for b in buckets}) == 1, 'CREDENTIAL_MANDATE')
        steps = [b['amount'] for b in buckets]
        args['mandate'] = {'resource': buckets[0]['resource'], 'limit': steps[0]}
        args['ladder'] = steps
    return args


def present(credential, holder_private, *, disclose, audience, nonce, now):
    """Holder side. ``disclose`` names claims to reveal; for mandate_at_most give the amount.

    Example: ``disclose={'verified_agent': True, 'mandate_at_most': 1000}``.
    The account claim is revealed only when ``disclose`` names it.
    """
    need(type(credential) is dict and {'holder_key', 'sd_jwt', 'disclosures'} <= set(credential), 'CREDENTIAL_FORMAT')
    need(public_key(holder_private) == credential['holder_key'], 'CREDENTIAL_HOLDER_KEY')
    need(type(disclose) is dict and disclose, 'CREDENTIAL_DISCLOSE')
    need(type(audience) is str and 0 < len(audience) <= 256 and audience.isascii(), 'CREDENTIAL_AUDIENCE')
    need(type(nonce) is str and 16 <= len(nonce) <= 128 and nonce.isascii(), 'CREDENTIAL_NONCE')
    integer(now)
    chosen = []
    for item in credential['disclosures']:
        salt, name, value = _json(_unb64(item))
        if STEP_CLAIM.fullmatch(name) is not None:
            name = 'mandate_at_most'
        if name not in disclose:
            continue
        if name == 'mandate_at_most':
            integer(disclose[name], True)
            if value['amount'] != disclose[name]:
                continue
        elif disclose[name] is not True:
            continue
        chosen.append(item)
    need(len(chosen) == len(disclose), 'CREDENTIAL_DISCLOSE')
    issued = credential['sd_jwt'] + '~' + ''.join(item + '~' for item in chosen)
    sd_hash = _b64(hashlib.sha256(issued.encode('ascii')).digest())
    kb = _jws(holder_private, {'alg': 'EdDSA', 'typ': KB_TYP},
              {'iat': now, 'aud': audience, 'nonce': nonce, 'sd_hash': sd_hash})
    return issued + kb


def make_policy(*, issuers, require=(), max_mandate=None, scope=None, audience):
    """A verifier policy. ``issuers`` maps issuer id to its Ed25519 key, pinned by the verifier."""
    need(type(issuers) is dict and 1 <= len(issuers) <= 8, 'CREDENTIAL_POLICY_ISSUERS')
    for name, value in issuers.items():
        need(type(name) is str and 0 < len(name) <= 256 and name.isascii(), 'CREDENTIAL_POLICY_ISSUERS')
        verification_key(value)
    need(type(require) in (list, tuple) and all(type(name) is str for name in require), 'CREDENTIAL_POLICY_REQUIRE')
    require = sorted(set(require))
    need(all(name in BOOLEAN_CLAIMS for name in require), 'CREDENTIAL_POLICY_REQUIRE')
    if max_mandate is not None:
        need(type(max_mandate) is dict and set(max_mandate) == {'resource', 'amount'}, 'CREDENTIAL_POLICY_MANDATE')
        _resource(max_mandate['resource'])
        integer(max_mandate['amount'], True)
    need(bool(require) or max_mandate is not None, 'CREDENTIAL_POLICY_EMPTY')
    _scope(scope)
    need(type(audience) is str and 0 < len(audience) <= 256 and audience.isascii(), 'CREDENTIAL_AUDIENCE')
    return {'version': POLICY_VERSION, 'issuers': deepcopy(issuers), 'require': require,
            'max_mandate': deepcopy(max_mandate), 'scope': scope, 'audience': audience}


def check_policy(policy):
    need(type(policy) is dict and set(policy) == {'version', 'issuers', 'require', 'max_mandate', 'scope', 'audience'},
         'CREDENTIAL_POLICY')
    need(policy['version'] == POLICY_VERSION, 'CREDENTIAL_POLICY_VERSION')
    rebuilt = make_policy(issuers=policy['issuers'], require=policy['require'], max_mandate=policy['max_mandate'],
                          scope=policy['scope'], audience=policy['audience'])
    need(rebuilt == policy, 'CREDENTIAL_POLICY')
    return digest(POLICY_LABEL, policy)


def policy_id(policy):
    return check_policy(policy)


def _open(presentation, issuers, *, audience, scope, nonce, now, clock_skew, vcts):
    """Signature, key binding and disclosure checks shared by every version a caller accepts."""
    integer(now)
    integer(clock_skew)
    need(clock_skew <= 120, 'CREDENTIAL_CLOCK_SKEW')
    need(type(nonce) is str and 16 <= len(nonce) <= 128 and nonce.isascii(), 'CREDENTIAL_NONCE')
    need(type(presentation) is str and 0 < len(presentation) <= MAX_PRESENTATION and presentation.isascii(),
         'CREDENTIAL_ENCODING')
    parts = presentation.split('~')
    need(len(parts) >= 2 and parts[-1] != '', 'CREDENTIAL_KEY_BINDING_REQUIRED')
    issuer_jwt, disclosures, kb_jwt = parts[0], parts[1:-1], parts[-1]
    need(all(disclosures), 'CREDENTIAL_ENCODING')
    # The issuer is named inside the signed payload; read it, then verify with the pinned key only.
    try:
        unverified = _json(_unb64(issuer_jwt.split('.')[1]))
    except IndexError:
        raise ValueError('CREDENTIAL_JWS') from None
    need(type(unverified) is dict and type(unverified.get('iss')) is str
         and unverified['iss'] in issuers, 'CREDENTIAL_ISSUER_NOT_PINNED')
    payload = _open_jws(issuer_jwt, issuers[unverified['iss']], TYP)
    fields = {'iss', 'iat', 'exp', 'vct', 'cnf', '_sd', '_sd_alg', 'aap_mode', 'aap_scope'}
    need(set(payload) <= fields | ({'aap_escrow'} if ATTRIBUTE_VERSION in vcts else set()), 'CREDENTIAL_PAYLOAD')
    version = next((name for name, vct in vcts.items() if payload.get('vct') == vct), None)
    need(version is not None and payload.get('_sd_alg') == SD_ALG, 'CREDENTIAL_TYPE')
    need(payload.get('aap_mode') in MODES, 'CREDENTIAL_MODE')
    if 'aap_escrow' in payload:
        need(version == ATTRIBUTE_VERSION and type(payload['aap_escrow']) is str, 'CREDENTIAL_PAYLOAD')
        key(payload['aap_escrow'])
    for name in ('iat', 'exp'):
        integer(payload.get(name))
    need(payload['iat'] <= now + clock_skew and now < payload['exp'] + clock_skew, 'CREDENTIAL_EXPIRED')
    need(0 < payload['exp'] - payload['iat'] <= MAX_LIFETIME, 'CREDENTIAL_LIFETIME')
    need(type(payload.get('cnf')) is dict and set(payload['cnf']) == {'jwk'}, 'CREDENTIAL_HOLDER_KEY')
    holder = _jwk_public(payload['cnf']['jwk'])
    sd = payload.get('_sd')
    need(type(sd) is list and len(sd) == SLOTS[version] and all(type(v) is str for v in sd)
         and len(set(sd)) == len(sd), 'CREDENTIAL_DIGESTS')
    for value in sd:
        need(len(_unb64(value, 43)) == 32, 'CREDENTIAL_DIGESTS')
    if scope is not None:
        need(payload['aap_mode'] == 'SCOPED' and payload.get('aap_scope') == scope, 'CREDENTIAL_SCOPE')
    # Key binding: the holder signed this exact issuer JWT plus these disclosures for us, now.
    issued = issuer_jwt + '~' + ''.join(item + '~' for item in disclosures)
    kb = _open_jws(kb_jwt, holder, KB_TYP)
    need(set(kb) == {'iat', 'aud', 'nonce', 'sd_hash'}, 'CREDENTIAL_KEY_BINDING')
    need(kb['aud'] == audience, 'CREDENTIAL_AUDIENCE')
    need(type(kb['nonce']) is str and kb['nonce'].isascii()
         and hmac.compare_digest(kb['nonce'].encode('ascii'), nonce.encode('ascii')),
         'CREDENTIAL_NONCE')
    integer(kb['iat'])
    need(now - KB_MAX_AGE - clock_skew <= kb['iat'] <= now + clock_skew, 'CREDENTIAL_KEY_BINDING_STALE')
    need(kb['sd_hash'] == _b64(hashlib.sha256(issued.encode('ascii')).digest()), 'CREDENTIAL_KEY_BINDING_HASH')
    disclosed = {}
    seen = set()
    for item in disclosures:
        hashed = _disclosure_digest(item)
        need(hashed in sd and hashed not in seen, 'CREDENTIAL_DISCLOSURE_UNKNOWN')
        seen.add(hashed)
        row = _json(_unb64(item))
        need(type(row) is list and len(row) == 3 and type(row[0]) is str and len(row[0]) >= 22 and type(row[1]) is str,
             'CREDENTIAL_DISCLOSURE')
        _, name, value = row
        need(name not in RESERVED, 'CREDENTIAL_DISCLOSURE')
        step = STEP_CLAIM.fullmatch(name)
        attribute = version == ATTRIBUTE_VERSION
        if (name == 'mandate_at_most' and version == LEGACY_VERSION) or (step is not None and version != LEGACY_VERSION):
            need(type(value) is dict and set(value) == {'resource', 'amount'}, 'CREDENTIAL_DISCLOSURE')
            _resource(value['resource'])
            integer(value['amount'], True)
            need(step is None or (type(value['amount']) is int and str(value['amount']) == step.group(1)), 'CREDENTIAL_DISCLOSURE')
            need('mandate_at_most' not in disclosed, 'CREDENTIAL_DISCLOSURE_DUPLICATE')
            name = 'mandate_at_most'
        elif name in BOOLEAN_CLAIMS:
            need(value is True and name not in disclosed, 'CREDENTIAL_DISCLOSURE')
        elif name in ('account', 'principal'):
            resolve_did(value)
            need(name not in disclosed, 'CREDENTIAL_DISCLOSURE_DUPLICATE')
        elif attribute and (AGE_CLAIM.fullmatch(name) is not None or LICENCE_CLAIM.fullmatch(name) is not None):
            need(value is True and name not in disclosed, 'CREDENTIAL_DISCLOSURE')
        elif attribute and name == 'jurisdiction':
            need(type(value) is str and JURISDICTION.fullmatch(value) is not None and name not in disclosed,
                 'CREDENTIAL_DISCLOSURE')
        elif attribute and SET_CLAIM.fullmatch(name) is not None:
            need(type(value) is dict and set(value) == {'set', 'members'} and value['set'] == name[16:]
                 and name not in disclosed, 'CREDENTIAL_DISCLOSURE')
            try:
                _members(value['members'])
            except ValueError:
                raise ValueError('CREDENTIAL_DISCLOSURE') from None
        else:
            raise ValueError('CREDENTIAL_DISCLOSURE')
        disclosed[name] = value
    nullifier = digest(NULLIFIER_LABEL, {'issuer': payload['iss'], 'scope': payload.get('aap_scope'), 'holder': holder})
    return {'version': version, 'payload': payload, 'holder': holder, 'claims': disclosed, 'nullifier': nullifier}


def verify_presentation(presentation, policy, *, nonce, now, clock_skew=30):
    """Pure verifier check. Record the returned nullifier with a NullifierSet before relying on it."""
    check_policy(policy)
    opened = _open(presentation, policy['issuers'], audience=policy['audience'], scope=policy['scope'], nonce=nonce,
                   now=now, clock_skew=clock_skew, vcts=VCTS)
    disclosed, payload = opened['claims'], opened['payload']
    for name in policy['require']:
        need(disclosed.get(name) is True, 'CREDENTIAL_CLAIM_MISSING')
    limit = policy['max_mandate']
    if limit is not None:
        shown = disclosed.get('mandate_at_most')
        need(shown is not None, 'CREDENTIAL_CLAIM_MISSING')
        need(shown['resource'] == limit['resource'] and shown['amount'] <= limit['amount'], 'CREDENTIAL_MANDATE_TOO_HIGH')
    return {'version': opened['version'], 'accepted': True, 'issuer': payload['iss'], 'mode': payload['aap_mode'],
            'scope': payload.get('aap_scope'), 'claims': disclosed, 'nullifier': opened['nullifier'],
            'identity_revealed': 'account' in disclosed, 'policy': digest(POLICY_LABEL, policy),
            'proves': list(PROVES), 'does_not_prove': list(DOES_NOT_PROVE), 'execution_authorized': False}


def open_attribute_presentation(presentation, issuers, *, audience, nonce, now, scope=None, clock_skew=30):
    """/0.3 only: the issuer signature, key binding and disclosed claims; statements are judged by attribute_proofs."""
    need(type(issuers) is dict and 1 <= len(issuers) <= 8, 'CREDENTIAL_POLICY_ISSUERS')
    for name, value in issuers.items():
        need(type(name) is str and 0 < len(name) <= 256 and name.isascii(), 'CREDENTIAL_POLICY_ISSUERS')
        verification_key(value)
    _scope(scope)
    need(type(audience) is str and 0 < len(audience) <= 256 and audience.isascii(), 'CREDENTIAL_AUDIENCE')
    opened = _open(presentation, issuers, audience=audience, scope=scope, nonce=nonce, now=now, clock_skew=clock_skew,
                   vcts={ATTRIBUTE_VERSION: ATTRIBUTE_VCT})
    payload, claims = opened['payload'], opened['claims']
    return {'version': ATTRIBUTE_VERSION, 'accepted': True, 'issuer': payload['iss'], 'issuer_key': issuers[payload['iss']],
            'mode': payload['aap_mode'], 'scope': payload.get('aap_scope'), 'claims': claims,
            'nullifier': opened['nullifier'], 'holder': opened['holder'], 'escrow': payload.get('aap_escrow'),
            'expires': payload['exp'], 'account_revealed': 'account' in claims, 'principal_revealed': 'principal' in claims,
            'proves': list(PROVES), 'does_not_prove': list(DOES_NOT_PROVE), 'execution_authorized': False}


class NullifierSet:
    """Verifier-side record. One nullifier counts once per scope; a repeat is refused.

    It is local state. Two verifiers that do not share it can each count the same
    credential once. Anchoring nullifiers on chain would need a new gated
    consensus profile; see docs/IDENTITY_AND_ACCOUNTS.md.
    """

    def __init__(self, spent=None, *, store=None, verifier='default'):
        self._lock = threading.RLock()
        self._spent = {}
        self._lock = threading.RLock()
        self._store = None
        if store is not None:
            from .identity_store import StateFile
            need(type(verifier) is str and 0 < len(verifier) <= 256 and verifier.isascii(), 'CREDENTIAL_VERIFIER')
            self._store = StateFile(store, 'nullifiers', kind=NULLIFIER_STORE_KIND, context={'verifier': verifier})
            try:
                saved = self._store.load()
            except BaseException:
                self._store.close()
                raise
            spent = {**(saved or {}), **{name: sorted({*(saved or {}).get(name, ()), *rows})
                                          for name, rows in (spent or {}).items()}}
        for scope, rows in (spent or {}).items():
            for row in rows:
                key(row)
                self._spent.setdefault(scope, set()).add(row)

    def close(self):
        if self._store is not None:
            self._store.close()

    @_serialized
    def spend(self, result):
        need(type(result) is dict and result.get('accepted') is True, 'CREDENTIAL_NOT_ACCEPTED')
        nullifier = result['nullifier']
        key(nullifier)
        scope = result['scope'] or ''
        with self._lock:
            spent = self._spent.setdefault(scope, set())
            need(nullifier not in spent, 'CREDENTIAL_NULLIFIER_SPENT')
            spent.add(nullifier)
            if self._store is not None:
                try:
                    self._store.save(self.export())
                except OSError:
                    spent.discard(nullifier)
                    raise ValueError('CREDENTIAL_STORE_WRITE') from None
            count = len(spent)
        return {'scope': result['scope'], 'nullifier': nullifier, 'count': count, 'execution_authorized': False}

    @_serialized
    def count(self, scope=None):
        return len(self._spent.get(scope or '', ()))

    @_serialized
    def export(self):
        return {scope: sorted(rows) for scope, rows in sorted(self._spent.items())}


def profile():
    """Trust boundary card for agents."""
    return {'version': VERSION, 'format': 'SD-JWT VC with Key Binding JWT', 'algorithm': 'EdDSA (Ed25519)',
            'digest': SD_ALG, 'vct': VCT, 'accepted_versions': sorted(VCTS), 'modes': list(MODES),
            'claims': [*BOOLEAN_CLAIMS, 'mandate_at_most', 'principal', 'account'],
            'mandate_claim_names': {VERSION: 'mandate_at_most_<amount>', LEGACY_VERSION: 'mandate_at_most'},
            'state': 'OWNER_DIRECTORY_STORE_OPTIONAL',
            'library': 'cryptography (pinned); no BBS or zero-knowledge backend is implemented',
            'privacy': 'SELECTIVE_DISCLOSURE_NOT_ANONYMITY; ISSUER_AND_DISCLOSED_METADATA_CAN_CORRELATE',
            'uniqueness': 'VERIFICATION_ALONE_DOES_NOT_SPEND_A_NULLIFIER_OR_PROVE_ONE_PERSON_ONE_VOTE',
            'proves': list(PROVES), 'does_not_prove': list(DOES_NOT_PROVE),
            'nullifiers': 'LOCAL_NULLIFIER_SET_PER_VERIFIER', 'consensus_change': None,
            'issuance_state': 'SERIALIZED_IN_PROCESS_ONLY; OWNER_MUST_PERSIST_AND_COORDINATE_ISSUANCE_ACROSS_RESTARTS_AND_PROCESSES',
            'global_uniqueness': False,
            'execution_authorized': False}
