"""Bounded per-peer I/O, independent of consensus timers and sibling peers.

Messages may be dropped on pressure. Consensus retransmission and verified
history catchup remain necessary; a queue is not availability or finality.
"""
from collections import OrderedDict
import hashlib
import threading
import time
from . import crypto
from .scale.backpressure import observe

MAX_PER_PEER_ITEMS=64
MAX_PER_PEER_BYTES=4*1024*1024
MAX_TOTAL_BYTES=16*1024*1024


class PeerIO:
    def __init__(self,node):
        self.node=node
        self.lock=threading.Condition()
        self.queues={peer:OrderedDict() for peer in node.peers if peer!=node.member}
        self.sizes={peer:0 for peer in self.queues}
        self.sync={peer:None for peer in self.queues}
        self.total=0;self.dropped=0;self.threads=[]

    def start(self):
        for peer in self.queues:
            worker=threading.Thread(target=self.worker,args=(peer,),daemon=True,name='covenant-peer-'+peer)
            worker.start();self.threads.append(worker)

    def enqueue(self,peer,path,value):
        encoded=crypto.canonical(value)
        identity=hashlib.sha256(path.encode()+b'\0'+encoded).digest();size=len(encoded)+len(path)
        with self.lock:
            q=self.queues.get(peer)
            if q is None:return False
            if identity in q:return True
            if len(q)>=MAX_PER_PEER_ITEMS or self.sizes[peer]+size>MAX_PER_PEER_BYTES or self.total+size>MAX_TOTAL_BYTES:
                self.dropped+=1;return False
            q[identity]=(path,encoded,size)
            self.sizes[peer]+=size;self.total+=size;self.lock.notify_all()
            return True

    def catchup(self,peer,height):
        with self.lock:
            if peer in self.sync:
                self.sync[peer]=height;self.lock.notify_all()

    def worker(self,peer):
        while not self.node.stopping.is_set():
            with self.lock:
                if not self.queues[peer] and self.sync[peer] is None:
                    self.lock.wait(.1);continue
                # Catchup always gets a turn, even if outgoing gossip is full.
                height=self.sync[peer];self.sync[peer]=None
                job=self.queues[peer].popitem(last=False)[1] if self.queues[peer] else None
                if job:self.sizes[peer]-=job[2];self.total-=job[2]
            if height is not None:
                try:
                    entries=self.node.request(peer,'/blocks?from='+str(height))
                    if entries is not None:
                        with self.node.lock:
                            for entry in entries:
                                if self.node.engine.accept_commit(entry['block'],entry['certificate']):self.node.refresh()
                except Exception as exc:
                    with self.node.lock:
                        self.node.record_error('peer-sync:'+peer,exc)
                        if self.node.engine.failed or not isinstance(exc,(ValueError,KeyError,TypeError,OSError)):self.node.stopping.set()
            if job and not self.node.stopping.is_set():
                started=time.monotonic()
                try:
                    reply=self.node.request(peer,job[0],crypto.loads(job[1]))
                except Exception as exc:
                    observe(getattr(self.node,'backpressure',None),job[0],started,False)
                    with self.node.lock:self.node.record_error('peer-send:'+peer,exc)
                else:
                    if reply is not None:
                        observe(getattr(self.node,'backpressure',None),job[0],started,True)

    def status(self):
        with self.lock:
            return {'queued_items':sum(len(q) for q in self.queues.values()),'queued_bytes':self.total,'dropped_on_pressure':self.dropped}

    def close(self):
        with self.lock:self.lock.notify_all()
        # Shared bounded join deadline; never wait 64*timeout serially.
        import time
        deadline=time.monotonic()+1
        for worker in self.threads:worker.join(max(0,deadline-time.monotonic()))
