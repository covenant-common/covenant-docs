"""Opt-in proposal and service-bond SDK. RPC reads are advisory, not finality."""
from copy import deepcopy
from .world_sdk import WorldClient
from .app import MARKET_VERSION
from .crypto import need,sign
from .market import ACCEPTANCE_FIELDS, ready_signature, checkpoint, require_fields

class MarketClient(WorldClient):
    def __init__(self,client,private_key,chain,*,fee_policy,max_fee,actor=None,sponsor=None):
        super().__init__(client,private_key,chain,actor=actor,protocol=MARKET_VERSION,
                         fee_policy=fee_policy,max_fee=max_fee,sponsor=sponsor)
    def propose_change(self,kind,change,not_before,expiry,rationale):
        cfg=self._advisory_record('market_config','active');need(type(cfg) is dict,'MARKET_CONFIG')
        return self.submit('GOV_PROPOSE',dict(kind=kind,change=deepcopy(change),not_before=not_before,
            expiry=expiry,epoch=cfg['epoch'],rationale=rationale))
    def approve_change(self,proposal):return self.submit('GOV_APPROVE',{'proposal':proposal})
    def accept_successor(self,proposal):return self.submit('GOV_ACCEPT',{'proposal':proposal})
    def veto_change(self,proposal):return self.submit('GOV_VETO',{'proposal':proposal})
    def certify_readiness(self,proposal,epoch,member,validator_key):
        need(callable(getattr(validator_key,'sign',None)),'FIELDS:validator_key')
        return self.submit('GOV_READY',{'proposal':proposal,'member':member,
            'signature':ready_signature(validator_key,self.chain,proposal,epoch,member)})
    def execute_change(self,proposal):return self.submit('GOV_EXECUTE',{'proposal':proposal})
    def fund_maintenance(self,quantity):return self.submit('MARKET_FUND',{'quantity':quantity,'destination':'MAINTENANCE'})
    def fund_service_rewards(self,quantity):return self.submit('MARKET_FUND',{'quantity':quantity,'destination':'SERVICE_REWARDS'})
    def _guarded_operator(self, guardians):
        """Build the signer the reducer verifies, from the operational key plus guardians."""
        from .continuity import local_quorum
        entity = self.actor
        policy = self._advisory_record('continuity_policies', entity)
        need(type(policy) is dict and 'body' in policy and 'id' in policy, 'FIELDS:policy')
        state = {
            'chain': self.chain,
            'continuity_policies': {entity: policy},
            'controllers': {},
            'controller_epochs': {},
            'continuity_pending': {},
        }
        controller = self._advisory_record('controllers', entity)
        if controller is not None:
            state['controllers'][entity] = controller
        epoch = self._advisory_record('controller_epochs', entity)
        if epoch is not None:
            state['controller_epochs'][entity] = epoch
        pending = self._advisory_record('continuity_pending', entity)
        if pending is not None:
            state['continuity_pending'][entity] = pending
        return local_quorum(state, entity, self.key, guardians)
    def stake_acceptance(self, owner, quantity, policy, guardians=None):
        """Operator signs exact capital backing as the guarded acceptance the chain verifies.

        A plain operational signature is not that object. Pass ``guardians``
        (member name to secret) or construct this client with a signer that
        already implements ``sign_native``.
        Fields are checked as the reducer checks STAKE_OPEN before anything is
        signed, so a malformed owner, quantity or policy is never accepted.
        """
        from .crypto import integer, key
        key(owner); integer(quantity, True); key(policy)
        if hasattr(self.key, 'sign_native'):
            signer = self.key
        else:
            need(type(guardians) is dict and len(guardians) >= 1, 'FIELDS:guardians')
            signer = self._guarded_operator(guardians)
        acceptance = sign(signer, 'COVENANT-STAKE-ACCEPT-0.1', {
            'chain': self.chain, 'owner': owner, 'operator': self.actor,
            'quantity': quantity, 'policy': policy,
        })
        require_fields(acceptance, ACCEPTANCE_FIELDS, 'acceptance')
        return acceptance
    def stake(self, operator, quantity, acceptance):
        require_fields(acceptance, ACCEPTANCE_FIELDS, 'acceptance')
        return self.submit('STAKE_OPEN', {'operator': operator, 'quantity': quantity, 'acceptance': acceptance})
    def show_stake(self, position):
        from .crypto import key
        key(position)
        row = self._advisory_record('service_stakes', position)
        need(type(row) is dict, 'STAKE_POSITION')
        return row
    def request_exit(self,position):return self.submit('STAKE_EXIT',{'position':position})
    def withdraw_stake(self,position):return self.submit('STAKE_WITHDRAW',{'position':position})
    def unstake(self, position):
        """Withdraw principal once the exit delay has elapsed. Alias of withdraw_stake."""
        return self.withdraw_stake(position)
    def claim_service_reward(self,position):return self.submit('STAKE_CLAIM',{'position':position})
    def report_equivocation(self,position,proofs):return self.submit('STAKE_SLASH',{'position':position,'proofs':proofs})
    def service_checkpoint(self,position,slot,content):
        """Check reducer field shapes before signing the unchanged service-head body."""
        from .crypto import integer,key
        key(position);integer(slot,True);key(content)
        return checkpoint(self.key,self.chain,position,self.actor,slot,content)


from .world_sdk import bind_agent_methods
bind_agent_methods(MarketClient)
