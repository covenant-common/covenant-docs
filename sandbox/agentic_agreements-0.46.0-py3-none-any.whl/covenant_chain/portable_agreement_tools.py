"""Discoverable, read-only handoff for complete portable agreement packages."""
from .cooperation_interface import HASH, OBJECT


def spec():
    text = {'type': 'string', 'minLength': 1, 'maxLength': 256}
    package = {**OBJECT, 'description': 'Exact .package returned by pack, not its response wrapper. Contains plaintext agreements and optional context openings; transport encryption is separate.'}
    pin = {**HASH, 'description': 'Package ID retained independently through an adopted channel. Copying an ID from the same untrusted package does not authenticate it.'}
    source = {'package': package, 'expected_id': pin, 'agreement': text}
    return ('covenant_portable_agreement',
        'Carry exact agreements between agents and verify them locally without an account, chain, owner config or network. Pack an existing coordination case; inspect with an independently retained package ID. Signatures, source bytes, context, history and current authority are distinct. Plaintext package; no secret scanner, encryption, execution, retrieval or automatic signing.', True, [
            ('spec', {}, ()),
            ('owner_handoff', {}, ()),
            ('owner_approval', {}, ()),
            ('pack', {'case': {**OBJECT, 'description': 'Exact coordination case from covenant_review.case or start.case, including complete agreement bundles and explicit approvals. Existing signed profiles remain unchanged.'},
                      'context_openings': {**OBJECT, 'description': 'Optional map of external_drafts.context_reference IDs to exact typed context values. Included values are disclosed in plaintext. Unsupported context schemes remain hash-only.'}}, ('case',)),
            ('inspect', {'package': package, 'expected_id': pin}, ('package', 'expected_id')),
            ('open_source', {**source, 'document': text, 'encoding': {'enum': ['UTF8', 'BASE64']}}, ('package', 'expected_id', 'agreement')),
            ('open_object', {**source, 'path': {'type': 'string', 'maxLength': 1024, 'description': 'Optional JSON pointer into the typed agreement root. Source bytes use open_source.'}}, ('package', 'expected_id', 'agreement')),
        ])


def call(action, parameters):
    if action == 'owner_approval':
        if parameters:
            raise ValueError('HANDOFF_DISCOVERY_PARAMETERS')
        return owner_approval()
    if action == 'owner_handoff':
        if parameters:
            raise ValueError('HANDOFF_DISCOVERY_PARAMETERS')
        return owner_handoff()
    from . import portable_agreements
    return getattr(portable_agreements, action)(**parameters)


def owner_approval():
    """Static path to separately installed owner approval, never custody access."""
    return {'status': 'OWNER_CONFIGURATION_REQUIRED', 'guide': 'docs/ASSENT_APPROVAL.html',
        'describe_command': ['python', '-m', 'covenant_agent.assent_gate', '--help'],
        'steps': ['Owner adopts an approval policy, thresholds, exact signer and separate approval method.',
                  'Select every role to protect. A buying owner normally includes counterparty as well as agent.',
                  'Owner installs the policy and private journal in the bilateral host configuration.',
                  'Review the exact rendered agreement, amount, payee and occurrence before separately approving.',
                  'Without fresh matching approval the protected operation stays unsigned; inspect pending state to recover.'],
        'signing_tool': None, 'signature_created': False, 'custody_opened': False,
        'configuration_written': False, 'execution_authorized': False,
        'scope': 'SEPARATE_BILATERAL_HOST_APPROVAL; NATIVE_PRINCIPAL_AUTHORITY_DOES_NOT_INSTALL_THIS_POLICY'}


def owner_handoff():
    """Static owner instructions. This function never opens custody or a server."""
    return {'status': 'OWNER_ACTION_REQUIRED',
        'guide': 'docs/OWNER_HANDOFF.html',
        'inspect_command': ['python', '-m', 'covenant_chain.owner_handoff_app', '--describe'],
        'launch_command': ['python', '-m', 'covenant_chain.owner_handoff_app',
                           '--home', '/owner-chosen/private/agreement-home', '--port', '0'],
        'steps': ['Owner starts the local application and explicitly creates its identity.',
                  'Parties exchange and independently authenticate their public keys.',
                  'Draft with real party keys, or import with an independently obtained package fingerprint.',
                  'Owner selects its roles, reviews the exact source and signing payload, and explicitly signs.',
                  'Export the plaintext package deliberately and convey its fingerprint independently.',
                  'Recipient reviews and countersigns using its own private home; merge unchanged returned agreements.'],
        'supported_signing_profiles': ['EXTERNAL', 'CONCEPT', 'ORDER', 'LEGAL'],
        'unsupported_signing_profiles': ['REFERENCE', 'BILATERAL'],
        'custody': 'OWNER_LOCAL_OS_ACCOUNT', 'remote_signing': False,
        'disclosure': 'PLAINTEXT_PACKAGE_PRIVATE_PERMISSION_RESTRICTED_LOCAL_STORAGE',
        'execution_authorized': False, 'signature_created': False,
        'current_authority': 'UNKNOWN', 'global_latest': 'UNKNOWN'}
