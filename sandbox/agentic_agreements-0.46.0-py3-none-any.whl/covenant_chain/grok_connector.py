"""Owner-pinned xAI Responses client, above the existing effect journal.

Grok Bot can use the inbound MCP connector independently of this optional API
client. All outbound calls are potentially billed external effects; preparation
and model function calls never supply Covenant assent or spending authority.
"""
from copy import deepcopy
import base64
import hashlib
import json
from pathlib import Path

from .a2a_connector import _endpoint, _json, _text
from .connector_harness import ConnectorHarness
from .crypto import exact, need
from .tool_surface import grok_functions
from .workflow_store import canonical as wire

VERSION = 'covenant-grok-responses/0.1'
IMPLEMENTATION = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def inspect_response(response_json, maximum=262144):
    """Return bounded proposals; keep the entire raw response for continuation."""
    response = _json(response_json, maximum)
    need(type(response) is dict and type(response.get('id')) is str
         and 0 < len(response['id']) <= 256, 'GROK_RESPONSE_ID')
    need(response.get('object') == 'response', 'GROK_RESPONSE_OBJECT')
    status = response.get('status')
    need(status in ('completed', 'incomplete', 'failed', 'in_progress', 'queued', 'cancelled'),
         'GROK_RESPONSE_STATUS')
    output = response.get('output')
    need(type(output) is list and len(output) <= 128, 'GROK_RESPONSE_OUTPUT')
    proposals, texts, seen = [], [], set()
    for item in output:
        need(type(item) is dict and type(item.get('type')) is str, 'GROK_OUTPUT_ITEM')
        if item['type'] == 'function_call':
            for field in ('call_id', 'name', 'arguments'):
                _text(item.get(field), maximum if field == 'arguments' else 256)
            need(item['call_id'] not in seen, 'GROK_DUPLICATE_CALL_ID')
            seen.add(item['call_id'])
            proposals.append({k: item[k] for k in ('type', 'call_id', 'name', 'arguments')})
        elif item['type'] == 'message':
            content = item.get('content')
            need(type(content) is list and len(content) <= 128, 'GROK_MESSAGE_CONTENT')
            for part in content:
                need(type(part) is dict, 'GROK_MESSAGE_CONTENT')
                if part.get('type') == 'output_text':
                    _text(part.get('text'), maximum, empty=True)
                    texts.append(part['text'])
    return {'response_id': response['id'], 'status': status, 'text': texts,
            'function_calls': proposals, 'raw_response_json': response_json,
            'assurance': 'MODEL_OUTPUT_IS_UNTRUSTED_DATA_AND_TOOL_PROPOSALS',
            'automatic_dispatch': False, 'execution_authorized': False}


def _external_dump(value):
    """Carry external finite decimal numbers without native-float coercion."""
    from decimal import Decimal
    if type(value) is dict:
        return '{' + ','.join(json.dumps(k, ensure_ascii=True) + ':' + _external_dump(v)
                              for k, v in value.items()) + '}'
    if type(value) is list:
        return '[' + ','.join(_external_dump(v) for v in value) + ']'
    if type(value) is Decimal:
        return str(value)
    return json.dumps(value, ensure_ascii=True, allow_nan=False, separators=(',', ':'))


def continuation(input_json, response_json, tool_outputs):
    """Pure next-input assembly; preserve all output including encrypted state.

    Callers retain the original inputs and full response privately. No provider
    previous_response_id or hidden server-side conversation is required.
    """
    history = _json(input_json)
    need(type(history) is list and len(history) <= 256, 'GROK_INPUT')
    inspected = inspect_response(response_json)
    need(inspected['status'] == 'completed', 'GROK_RESPONSE_NOT_COMPLETED')
    response = _json(response_json)
    need(type(tool_outputs) is list and len(tool_outputs) <= 128, 'GROK_TOOL_OUTPUTS')
    calls = {c['call_id'] for c in inspected['function_calls']}
    seen = set()
    for value in tool_outputs:
        exact(value, 'type call_id output')
        need(value['type'] == 'function_call_output' and type(value['call_id']) is str
             and value['call_id'] in calls and value['call_id'] not in seen
             and type(value['output']) is str, 'GROK_TOOL_OUTPUT_CORRELATION')
        seen.add(value['call_id'])
    need(seen == calls, 'GROK_TOOL_OUTPUTS_MISSING')
    result = _external_dump(history + response['output'] + deepcopy(tool_outputs))
    _json(result)
    return {'input_json': result, 'provider_storage_requested': False,
            'execution_authorized': False}


class GrokConnector(ConnectorHarness):
    def __init__(self, directory, *, models, headers, surface=None,
                 endpoint='https://api.x.ai/v1/responses', allow_insecure_loopback=False,
                 timeout=30, max_request_bytes=262144, max_wire_bytes=131072,
                 max_output_tokens=4096, observer=None):
        need(type(models) is list and 1 <= len(models) <= 16
             and all(type(m) is str and 0 < len(m) <= 128 for m in models)
             and len(set(models)) == len(models), 'GROK_OWNER_MODELS')
        need(type(max_output_tokens) is int and 1 <= max_output_tokens <= 64000, 'GROK_OUTPUT_TOKEN_CAP')
        need(type(max_wire_bytes) is int and 1024 <= max_wire_bytes <= 240000, 'GROK_WIRE_LIMIT')
        need(type(allow_insecure_loopback) is bool, 'GROK_OWNER_LOOPBACK_POLICY')
        origin, path = _endpoint(endpoint, allow_insecure_loopback)
        self._models, self._path = tuple(models), path
        self._tools = [] if surface is None else grok_functions(surface)
        self.max_output_tokens, self.max_wire_bytes = max_output_tokens, max_wire_bytes
        self._configuration_pin = self._configuration()
        def owner_headers():
            value = headers() if callable(headers) else deepcopy(headers)
            need(type(value) is dict and not ({k.lower() for k in value} & {'content-type', 'accept'}),
                 'GROK_OWNER_HEADERS')
            return {**value, 'Content-Type': 'application/json', 'Accept': 'application/json'}
        policy = {'profile': VERSION, 'implementation': IMPLEMENTATION, 'endpoint': endpoint,
                  'models': models, 'tools': self._tools, 'store': False,
                  'max_output_tokens': max_output_tokens, 'max_wire_bytes': max_wire_bytes}
        super().__init__(directory, http_routes={'responses-http': {'origin': origin, 'path_prefix': path,
            'methods': ['POST'], 'headers': owner_headers}}, custom_protocols={'responses': {
                'protocol': 'GROK_RESPONSES', 'implementation': hashlib.sha256(wire(policy)).hexdigest(),
                'call': self._call}}, timeout=timeout, max_request_bytes=max_request_bytes,
                max_response_bytes=4 * max_wire_bytes + 16384, observer=observer)

    def _configuration(self):
        return hashlib.sha256(wire({'models': list(self._models), 'path': self._path,
            'tools': self._tools, 'max_output_tokens': self.max_output_tokens,
            'max_wire_bytes': self.max_wire_bytes})).hexdigest()

    def _check_configuration(self):
        need(self._configuration() == self._configuration_pin, 'GROK_OWNER_CONFIGURATION_CHANGED')

    def describe_requests(self):
        self._check_configuration()
        return {'profile': VERSION, 'adapter': self.ref, 'models': list(self._models),
                'operations': [{'protocol': 'GROK_RESPONSES', 'operation': 'responses',
                    'parameters': {'required': ['model', 'input_json', 'max_output_tokens']}}],
                'functions': [t['name'] for t in self._tools], 'provider_store': False,
                'credentials': 'OWNER_CUSTODY', 'recovery': 'OBSERVE_ONLY_NO_BLIND_RETRY',
                'max_output_tokens': self.max_output_tokens, 'execution_authorized': False,
                'all_calls': 'BILLED_EXTERNAL_EFFECT_REQUIRES_SEPARATE_WORKFLOW_APPROVAL'}

    def validate_request(self, request):
        self._check_configuration()
        result = super().validate_request(request)
        need(request['protocol'] == 'GROK_RESPONSES' and request['operation'] == 'responses', 'GROK_OPERATION')
        value = request['parameters']
        exact(value, 'model input_json max_output_tokens')
        need(type(value['model']) is str and value['model'] in self._models, 'GROK_MODEL_NOT_ADOPTED')
        need(type(value['max_output_tokens']) is int
             and 1 <= value['max_output_tokens'] <= self.max_output_tokens, 'GROK_OUTPUT_TOKEN_CAP')
        history = _json(value['input_json'], self.max_request_bytes)
        need(type(history) is list and 1 <= len(history) <= 256
             and all(type(item) is dict for item in history), 'GROK_INPUT')
        need(len(self._body(value)) <= self.max_request_bytes, 'GROK_REQUEST_LIMIT')
        return result

    def prepare(self, model, input_json, *, max_output_tokens=1024):
        request = {'protocol': 'GROK_RESPONSES', 'operation': 'responses', 'parameters': {
            'model': model, 'input_json': input_json, 'max_output_tokens': max_output_tokens}}
        result = self.validate_request(request)
        return {'adapter': self.ref, 'request': request,
                'request_binding': {'kind': 'FIXED', 'hash': result['request_hash']},
                'billing': 'POTENTIALLY_PAID_API_CALL; TOKEN_CAP_IS_NOT_A_CURRENCY_SPEND_CAP',
                'execution_authorized': False}

    def _body(self, value):
        fields = {'model': value['model'], 'store': False, 'stream': False,
                  'max_output_tokens': value['max_output_tokens'], 'parallel_tool_calls': False,
                  'include': ['reasoning.encrypted_content'], 'tools': self._tools}
        return (json.dumps(fields, ensure_ascii=True, separators=(',', ':'))[:-1]
                + ',"input":' + value['input_json'] + '}').encode('utf-8')

    def _call(self, parameters):
        self._check_configuration()
        http = self._http('responses-http', {'method': 'POST', 'path': self._path,
            'body_base64': base64.b64encode(self._body(parameters)).decode('ascii')})
        raw = base64.b64decode(http['body_base64'], validate=True)
        need(len(raw) <= self.max_wire_bytes, 'GROK_WIRE_LIMIT')
        result = {'profile': VERSION, 'http_status': http['status'], 'body_base64': http['body_base64'],
                  'body_sha256': hashlib.sha256(raw).hexdigest(), 'protocol_status': 'INVALID_RESPONSE',
                  'assurance': 'MODEL_OUTPUT_IS_UNTRUSTED_DATA_AND_TOOL_PROPOSALS', 'automatic_dispatch': False}
        if not 200 <= http['status'] < 300:
            return {**result, 'protocol_status': 'HTTP_ERROR'}
        try:
            need(http['headers'].get('content-type', '').split(';')[0].strip().lower() == 'application/json',
                 'GROK_RESPONSE_CONTENT_TYPE')
            inspected = inspect_response(raw.decode('utf-8'), self.max_wire_bytes)
            return {**result, 'protocol_status': 'RESPONSE', 'response_id': inspected['response_id'],
                    'response_status': inspected['status']}
        except (ValueError, TypeError, KeyError, UnicodeError):
            return result
