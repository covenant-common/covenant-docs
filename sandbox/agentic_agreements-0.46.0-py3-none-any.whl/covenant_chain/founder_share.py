"""Marginal founder profit-share. A ratio of realised revenue, never interest and never issuance.

Illustrative bands, in fee-resource units treated as one unit per illustrated dollar.
The 14% top rate is the ossified ceiling. Every band can only fall. Thresholds can
only move up. Both changes lower the take. 14% of revenue on a cost-priced flow
sits inside the one-sixth ona'ah margin (14/86 ≈ 16.3% of cost).
"""
from .crypto import integer, need

# Ossified. Not a governance parameter. A new profile id would be required to replace it.
CEILING_BPS = 1400
BANDS = (
    {'up_to': 10_000_000, 'rate_bps': 1400},
    {'up_to': 100_000_000, 'rate_bps': 1000},
    {'up_to': 1_000_000_000, 'rate_bps': 600},
    {'up_to': None, 'rate_bps': 300},
)
MAX_BANDS = 16
STABLE_BPS = 5000
TOKEN_BPS = 5000
FLOWS = ('protocol_fee', 'ad_revenue', 'marketplace', 'settlement_fee', 'sponsorship_fee', 'bond_income',
         'treasury_income', 'cost_report', 'serving_reward', 'licence_royalty')
ILLUSTRATIVE = True


def _rate_ok(rate):
    integer(rate)
    need(rate <= CEILING_BPS, 'FOUNDER_CEILING')


def income(gross):
    """Cumulative founder income on cumulative gross. Marginal, so it never falls as gross rises."""
    integer(gross)
    need(gross >= 0, 'FOUNDER_GROSS')
    left = gross
    cursor = 0
    total = 0
    for band in BANDS:
        _rate_ok(band['rate_bps'])
        if band['up_to'] is None:
            width = left
        else:
            width = min(left, band['up_to'] - cursor)
        if width > 0:
            total += width * band['rate_bps'] // 10000
            left -= width
            cursor = band['up_to'] if band['up_to'] is not None else cursor + width
        if left <= 0:
            break
    return total


def slice_for(prior_gross, amount):
    """Founder line on one new inflow, given the rolling gross already booked."""
    integer(prior_gross)
    integer(amount)
    need(amount >= 0 and prior_gross >= 0, 'FOUNDER_GROSS')
    return income(prior_gross + amount) - income(prior_gross)


def effective_rate_bps(gross):
    integer(gross)
    if gross <= 0:
        return BANDS[0]['rate_bps']
    return income(gross) * 10000 // gross


def split(amount, flow, prior_gross=0):
    """Carve the founder line out of realised `amount`. Nothing is added on top and nothing is minted."""
    need(flow in FLOWS, 'FOUNDER_FLOW')
    founder = slice_for(prior_gross, amount)
    need(founder <= amount, 'FOUNDER_FROM_REVENUE')
    stable = founder * STABLE_BPS // 10000
    token_leg = founder - stable
    return {'flow': flow, 'base': amount, 'founder': founder, 'stable': stable, 'token_leg': token_leg,
            'rate_bps': 0 if amount == 0 else founder * 10000 // amount,
            'ceiling_bps': CEILING_BPS, 'interest': False, 'minted': 0,
            'character': 'MUDARABAH_OR_HETER_ISKA_PROFIT_SHARE', 'illustrative_bands': ILLUSTRATIVE,
            'execution_authorized': False}


def _schedule(bands):
    """A band schedule: 1 to 16 bands of exactly {up_to, rate_bps}, integer thresholds strictly rising, only the last open."""
    need(type(bands) in (list, tuple) and 1 <= len(bands) <= MAX_BANDS, 'FOUNDER_SCHEDULE')
    previous = 0
    for position, band in enumerate(bands):
        need(type(band) is dict and set(band) == {'up_to', 'rate_bps'}, 'FOUNDER_SCHEDULE')
        need(type(band['rate_bps']) is int and 0 <= band['rate_bps'] <= 2**53 - 1, 'FOUNDER_SCHEDULE')
        _rate_ok(band['rate_bps'])
        if band['up_to'] is None:
            need(position == len(bands) - 1, 'FOUNDER_THRESHOLD')
        else:
            need(type(band['up_to']) is int and previous < band['up_to'] <= 2**53 - 1, 'FOUNDER_THRESHOLD')
            previous = band['up_to']


def schedule_is_lower(old_bands, new_bands):
    """F1: every rate ≤ the old rate and every finite threshold ≥ the old threshold.

    Both schedules are checked first: canonical integers only (no float, bool
    or value above 2**53 - 1), thresholds strictly rising, and only the last
    band open. A malformed schedule is a refusal code, never a TypeError.
    """
    _schedule(old_bands)
    _schedule(new_bands)
    need(len(new_bands) == len(old_bands), 'FOUNDER_SCHEDULE')
    for old, new in zip(old_bands, new_bands):
        need(new['rate_bps'] <= old['rate_bps'], 'FOUNDER_RATE_RISES')
        if old['up_to'] is None:
            need(new['up_to'] is None, 'FOUNDER_THRESHOLD')
        else:
            need(new['up_to'] is not None and new['up_to'] >= old['up_to'], 'FOUNDER_THRESHOLD')
    return True


def ad_settle(gross, prior_gross=0):
    """Hook for ads.attribution.settle. Founder line comes off gross CPA before agent splits."""
    integer(gross, True)
    line = split(gross, 'ad_revenue', prior_gross)
    line['agents_base'] = gross - line['founder']
    line['added_on_top_of_bid'] = False
    return line


def settlement_fee(fee, principal, prior_gross=0):
    """x402/AP2 and payment-rail hook. The share applies to the network fee, never the principal."""
    integer(principal)
    line = split(fee, 'settlement_fee', prior_gross)
    line['principal'] = principal
    line['principal_touched'] = 0
    return line


def sponsorship_fee(fee, pooled_funds, prior_gross=0):
    integer(pooled_funds)
    line = split(fee, 'sponsorship_fee', prior_gross)
    line['pooled_funds'] = pooled_funds
    line['pooled_funds_touched'] = 0
    return line
