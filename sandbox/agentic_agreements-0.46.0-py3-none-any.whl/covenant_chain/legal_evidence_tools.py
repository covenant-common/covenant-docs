"""Agent tools for the optional legal-evidence plugins, as PR 87 spec tuples.

Maturity: experimental. A tool is listed only when the owner turns its flag on in
``host_flags.HostPlugins``; every call checks the flag again (PLUGIN_DISABLED).
Arguments are hashes, ids, short text and bounded objects, and they are data:
they cannot choose keys, pins, mandates, forums, clocks or files. Results keep
``execution_authorized`` false. The SLA and git tools sign with the host key the
owner installed; their output is the host's own statement about the data it was
given, which is why they are off by default and marked as not read-only.

Ported from Cursor PR 80's parity_tools.py (refs/pull/80/head, 575be847), renamed
so the module says what it holds.
"""
from __future__ import annotations

import base64
from copy import deepcopy

from .cooperation_interface import HASH, INT
from .crypto import need
from .host_flags import TOOLS, flag_of

ATR_HASH = {'type': 'string', 'pattern': '^0x[0-9a-fA-F]{64}$', 'minLength': 66, 'maxLength': 66}
URL = {'type': 'string', 'minLength': 9, 'maxLength': 2048}
WORD = {'type': 'string', 'minLength': 1, 'maxLength': 128}
TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 4096}
NAME = {'type': 'string', 'minLength': 1, 'maxLength': 256}
SLOT = {'type': 'string', 'pattern': '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$'}
HEX_OBJECT = {'type': 'string', 'pattern': '^([0-9a-f]{40}|[0-9a-f]{64})$'}
RAIL = {'type': 'string', 'enum': ['eip3009', 'solana-memo', 'stellar-mux', 'offline-ble']}
KEYS = {'type': 'array', 'minItems': 1, 'maxItems': 8, 'items': HASH}
POINTERS = {'type': 'array', 'minItems': 1, 'maxItems': 32,
            'items': {'type': 'string', 'minLength': 2, 'maxLength': 256, 'pattern': '^/'}}


def _object(limit=64):
    return {'type': 'object', 'maxProperties': limit}


def _nullable(shape):
    return {'oneOf': [shape, {'type': 'null'}]}


OFFER = {
    'type': 'object', 'additionalProperties': False,
    'required': ['kind', 'amount', 'unit', 'counterparty', 'level', 'jurisdiction', 'method', 'link',
                 'served_base64', 'hash'],
    'properties': {
        'kind': {'type': 'string', 'enum': ['lcp', 'native']},
        'amount': {'type': 'integer', 'minimum': 1, 'maximum': 2 ** 53 - 1},
        'unit': WORD, 'counterparty': NAME,
        'level': _nullable({'type': 'integer', 'minimum': 1, 'maximum': 4}),
        'jurisdiction': _nullable(WORD), 'method': _nullable(WORD), 'link': _nullable(URL),
        'served_base64': _nullable({'type': 'string', 'maxLength': 1398104}),
        'hash': _nullable(ATR_HASH),
    },
}

DESCRIPTIONS = {
    'lcp_emit': 'Experimental, off by default. Emit Legal Context Protocol discovery bytes, or the ATR of agreed '
                'terms with private fields dropped before any byte is written. Hashes and ids only; no fetch, '
                'publication, signature or assent.',
    'lcp_buyer': 'Experimental, off by default. Apply the owner-adopted buyer annex to one LCP purchase or native deal '
                 'with bytes already in hand: LCP declines, the mandate per-unit cap, and recorded principal '
                 'decisions above the approval limit. Never fetches, signs, reserves or pays.',
    'atr_binding': 'Experimental, off by default. Place an ATR hash in a rail carrier field (EIP-3009 nonce, Solana memo, '
                   'Stellar mux id, offline voucher) or cross-check one supplied settlement record. Not a rail '
                   'observation; nothing executes.',
    'acceptance_test': 'Experimental, off by default. Re-hash a deterministic acceptance image offline, verify a '
                       'runner verdict, or evaluate a test leaf whose runner keys and quorum the leaf pins. Unpinned '
                       'or party runners do not count. A grade is not permission to settle.',
    'forum_arbiter': 'Experimental, off by default. Resolve an LCP dispute method against the forums the owner '
                     'installed, or ask a human when it is unknown; prepare an unsigned private-agreement proposal '
                     'for a bound procedure. The AAA-ICDR entry is a mock with no network.',
    'sla_telemetry': 'Experimental, off by default. The host verifies supplied resource-observation envelopes and signs '
                     'its own view against one deadline: OK, LATE, MISSED or PENDING. A host statement about the '
                     'readings it was given, not world truth.',
    'git_anchors': 'Experimental, off by default. The host signs a commit-to-receipt binding or a receipt note body with '
                   'its installed key, or verifies one. The signature is the host statement; certificates are not '
                   'checked and nothing is written to a repository.',
}


def _actions(flag):
    if flag == 'lcp_emit':
        return [
            ('emit', {'terms': URL, 'terms_format': {'type': 'string', 'minLength': 1, 'maxLength': 64},
                      'atr_hash': ATR_HASH, 'acceptance_required': {'type': 'boolean'}, 'dispute': _object(6),
                      'contact': _object(2), 'returns': URL, 'api': URL}, ('terms',)),
            ('atr', {'atr_id': NAME, 'terms': _object(), 'binding_slot': SLOT, 'binding': _object(),
                     'scope_fields': POINTERS}, ('atr_id', 'terms')),
        ]
    if flag == 'lcp_buyer':
        return [
            ('annex', {}, ()),
            ('decide', {'offer': OFFER, 'decisions': {'type': 'array', 'maxItems': 64, 'items': _object(2)}},
             ('offer',)),
        ]
    if flag == 'atr_binding':
        return [
            ('bind', {'rail': RAIL, 'atr_hash': ATR_HASH}, ('rail', 'atr_hash')),
            ('recover', {'settlement': _object(8)}, ('settlement',)),
            ('check', {'settlement': _object(8), 'expected': ATR_HASH}, ('settlement', 'expected')),
        ]
    if flag == 'acceptance_test':
        return [
            ('rerun', {'image': HASH, 'inputs': HASH,
                       'program_hex': {'type': 'string', 'pattern': '^([0-9a-f]{2})+$', 'maxLength': 131072}},
             ('image', 'inputs', 'program_hex')),
            ('evaluate', {'leaf': _object(16), 'parties': KEYS}, ('leaf',)),
            ('verify', {'verdict': _object(4), 'runners': KEYS}, ('verdict',)),
        ]
    if flag == 'forum_arbiter':
        return [
            ('methods', {}, ()),
            ('resolve', {'dispute': _object(6)}, ('dispute',)),
            ('prepare', {'method': NAME, 'question': TEXT, 'context': _object(2), 'parties': _object(8),
                         'terms': _object()}, ('method', 'question', 'context', 'parties', 'terms')),
        ]
    if flag == 'sla_telemetry':
        return [
            ('evaluate', {'policy': _object(8), 'observations': {'type': 'array', 'maxItems': 64, 'items': _object(2)}},
             ('policy', 'observations')),
            ('verify', {'event': _object(5), 'signers': KEYS}, ('event',)),
        ]
    return [
        ('commit', {'commit': HEX_OBJECT, 'receipt': HASH}, ('commit', 'receipt')),
        ('note', {'receipt': HASH, 'chain': HASH, 'height': INT, 'certificate': HASH},
         ('receipt', 'chain', 'height', 'certificate')),
        ('verify', {'kind': {'type': 'string', 'enum': ['commit', 'note']}, 'signed': _object(6), 'receipt': HASH,
                    'signers': KEYS}, ('kind', 'signed', 'receipt')),
    ]


def specs(plugins):
    """Spec tuples ``(name, description, readonly, actions)`` for the enabled flags only."""
    out = []
    for flag, name in TOOLS.items():
        if plugins.enabled(flag):
            out.append((name, DESCRIPTIONS[flag], flag not in ('sla_telemetry', 'git_anchors'), _actions(flag)))
    return out


def _served(value):
    if value is None:
        return None
    try:
        raw = base64.b64decode(value, validate=True)
    except ValueError:
        raise ValueError('BUYER_SERVED_ENCODING') from None
    need(base64.b64encode(raw).decode('ascii') == value, 'BUYER_SERVED_ENCODING')
    return raw


def _lcp(action, p):
    from . import lcp_emit
    if action == 'emit':
        names = {'terms': 'terms', 'terms_format': 'termsFormat', 'atr_hash': 'atrHash',
                 'acceptance_required': 'acceptanceRequired', 'dispute': 'disputeResolution', 'contact': 'contact',
                 'returns': 'returns', 'api': 'api'}
        result = lcp_emit.emit_discovery({names[k]: v for k, v in p.items()}, enabled=True)
        if result['refused']:
            return {**result, 'execution_authorized': False}
        return {'refused': False, 'discovery': result['bytes'].decode('utf-8'), 'document': result['document'],
                'path': lcp_emit.WELL_KNOWN_LEGAL_CONTEXT, 'execution_authorized': False}
    binding = [p.get('binding_slot', 'bind'), p.get('binding', {})]
    result = lcp_emit.from_terms(p['terms'], p['atr_id'], binding, enabled=True, scope_fields=p.get('scope_fields'))
    if result['refused']:
        return {**result, 'execution_authorized': False}
    return {'refused': False, 'ledger': result['ledger'], 'scoped': result['scoped'],
            'atr': result['bytes'].decode('utf-8'), 'execution_authorized': False}


def _buyer(plugins, action, p):
    need(plugins.mandate is not None, 'BUYER_MANDATE_NOT_INSTALLED')
    if action == 'annex':
        return {'annex': deepcopy(plugins.mandate['annex']), 'annex_id': plugins.mandate['annex_id'],
                'mandate': plugins.mandate['mandate'], 'execution_authorized': False}
    from .lcp_buyer import gate
    raw = deepcopy(p['offer'])
    offer = {**{k: v for k, v in raw.items() if k != 'served_base64'}, 'served': _served(raw['served_base64'])}
    return gate(plugins.mandate, offer, decisions=p.get('decisions', []), enabled=True)


def _atr(action, p):
    from . import atr_binding
    if action == 'bind':
        return {**atr_binding.bind(p['rail'], p['atr_hash'], enabled=True), 'execution_authorized': False}
    if action == 'recover':
        return {'h': atr_binding.recover(p['settlement'], enabled=True), 'assurance': atr_binding.ASSURANCE,
                'execution_authorized': False}
    return atr_binding.check(p['settlement'], p['expected'], enabled=True)


def _acceptance(action, p):
    from . import acceptance_tests
    if action == 'rerun':
        output = acceptance_tests.rerun(p['image'], p['inputs'], bytes.fromhex(p['program_hex']))
        return {'outputs': output, 'executed': False, 'execution_authorized': False}
    if action == 'verify':
        runners = p.get('runners')
        return {'valid': acceptance_tests.verify_verdict(p['verdict'], runners=None if runners is None else set(runners)),
                'pinned': runners is not None, 'execution_authorized': False}
    from .conditions import Context, evaluate
    context = Context({}, {}, profile='covenant-conditions/0.3', plugins={'test': acceptance_tests.plugin(parties=p.get('parties', []))})
    report = evaluate(p['leaf'], context)
    return {'status': report['status'], 'observations': report['observations'], 'execution_authorized': False}


def _forum(plugins, action, p):
    from .forum_arbiter import _unknown
    registry = plugins.forums
    if action == 'methods':
        return registry.describe() if registry is not None else {'enabled': False, 'methods': {},
                                                                  'execution_authorized': False}
    if action == 'resolve':
        if registry is not None:
            return registry.resolve(p['dispute'])
        method = p['dispute'].get('method')
        return _unknown(method if type(method) is str and len(method) <= 256 else None)
    found = registry.resolve({'method': p['method']}) if registry is not None else _unknown(p['method'])
    if found['status'] != 'BOUND' or found['kind'] != 'PRIVATE_PROCEDURE':
        return found
    from .private_covenant import create_agreement
    procedure = {**found['procedure'], 'question': p['question']}
    agreement = create_agreement(context=p['context'], parties=p['parties'], terms=p['terms'], procedure=procedure)
    return {'status': 'BOUND', 'method': p['method'], 'agreement': agreement, 'assented': False,
            'runs_procedure': True, 'execution_authorized': False}


def _sla(plugins, action, p):
    from . import sla_view
    if action == 'verify':
        signers = p.get('signers')
        return {'valid': sla_view.verify_event(p['event'], signers=None if signers is None else set(signers)),
                'pinned': signers is not None, 'execution_authorized': False}
    sla_view._policy(p['policy'])
    return sla_view.evaluate(p['policy'], p['observations'], plugins.now(), plugins.key('sla'), enabled=True)


def _git(plugins, action, p):
    from . import git_anchors
    if action == 'verify':
        signers = p.get('signers')
        check = git_anchors.verify_commit if p['kind'] == 'commit' else git_anchors.verify_note
        return {'valid': check(p['signed'], p['receipt'], signers=None if signers is None else set(signers)),
                'pinned': signers is not None, 'execution_authorized': False}
    signer = plugins.key('git')
    if action == 'commit':
        return git_anchors.sign_commit(signer, p['commit'], p['receipt'])
    return git_anchors.sign_note(signer, git_anchors.note_body(p['receipt'], p['chain'], p['height'], p['certificate']))


def call(plugins, name, action, parameters, schema=None):
    """Dispatch one validated call. The flag is required again here."""
    flag = flag_of(name)
    plugins.require(flag)
    p = deepcopy(parameters)
    if action == 'describe':
        return {'status': 'DESCRIBED', 'tool': name, 'flag': flag, 'schema': deepcopy(schema),
                'maturity': 'experimental', 'guide': 'docs/LEGAL_EVIDENCE.html', 'code': 'NOT_COMMITTED',
                'automatic_assent': False, 'execution_authorized': False}
    if flag == 'lcp_emit':
        return _lcp(action, p)
    if flag == 'lcp_buyer':
        return _buyer(plugins, action, p)
    if flag == 'atr_binding':
        return _atr(action, p)
    if flag == 'acceptance_test':
        return _acceptance(action, p)
    if flag == 'forum_arbiter':
        return _forum(plugins, action, p)
    if flag == 'sla_telemetry':
        return _sla(plugins, action, p)
    return _git(plugins, action, p)
