"""Cross-implementation vectors for covenant-spec/1.0.

The document version is not a rename of the wire versions. Signing labels stay
covenant-common/0.1 and covenant-native/0.1. Regenerating these files does not
publish a package.
"""
import base64
import json
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from covenant_language.core import SIGNING, make_body, sign as common_sign
from covenant_language.safe_io import atomic_write
from . import app
from .crypto import canonical, digest, public_key, sign
from .core_freeze import pins
from .network_gateway import token_hash, token_record
from .principal import LABEL as PRINCIPAL_LABEL
from .principal import authorize_bind, draft as draft_policy
from .salted_terms import LABEL as SALTED_LABEL
from .salted_terms import applies_to, assent_body, prepare, public_record, verify_transition
from .state import prove_record, verify_record

PROFILE = 'covenant-spec/1.0'
NAMES = ('owner', 'agent', 'worker', 'resolver', 'appeal', 'executor', 'stranger', 'v0', 'v1', 'v2', 'v3')


def reference_keys():
    keys = {}
    publics = {}
    for index, name in enumerate(NAMES):
        keys[name] = Ed25519PrivateKey.from_private_bytes(bytes([index + 1]) + bytes(31))
        publics[name] = public_key(keys[name])
    return keys, publics


def reference_genesis(protocol=app.VERSION):
    _, publics = reference_keys()
    return {
        'protocol': protocol,
        'name': 'Covenant commitment devnet',
        'validators': {name: publics[name] for name in ('v0', 'v1', 'v2', 'v3')},
        'faults': 1,
        'accounts': {publics['owner']: {'compute': 100, 'data': 10, 'instrument': 1, 'payment': 100}},
        'resources': {name: {'unit': unit} for name, unit in (
            ('compute', 'compute-unit'), ('data', 'access-ticket'),
            ('instrument', 'exclusive-session'), ('payment', 'test-payment-unit'))},
        'profiles': {'task-v1': {'description': 'Exact bilateral terms; evidence; independent resolver and appeal; ledger-height deadlines.'}},
    }


def _tx(keys, state, name, op, payload, protocol):
    who = reference_keys()[1][name]
    return app.make_transaction(keys[name], state['chain'], state['nonces'].get(who, 0), op, payload, protocol=protocol, actor=who)


def build():
    keys, publics = reference_keys()
    genesis = reference_genesis()
    state = app.genesis_state(genesis)
    say_payload = {'subject': 'star', 'content_hash': '00' * 32, 'description': 'observation', 'parents': []}
    say = app.make_transaction(keys['worker'], state['chain'], 0, 'SAY', say_payload)
    after_say = app.apply_transaction(state, say, 1)
    signed_body = {'chain': state['chain'], 'nonce': 0, 'op': 'SAY'}
    native_signature = sign(keys['owner'], 'COVENANT-TX-SIGN-0.1', signed_body)
    common_body = make_body('commons', 'first', 'DEFINE', 'owner', {
        'name': 'temperature', 'meaning': 'A reading with its instrument.',
        'ratio': 'Keep the measurement with its context.'}, instance='ab' * 16)
    common_signature = common_sign(common_body, keys['owner'])
    modern = app.genesis_state(reference_genesis(app.NEXT_VERSION))
    proof = prove_record(modern, 'balances', publics['owner'])
    root = app.state_hash(modern)
    verify_record(proof, root)
    principal = _principal(keys, publics)
    salted = _salted(keys, publics)
    frozen = pins()
    admin, host0, host1 = 'ab' * 32, 'cd' * 32, 'ef' * 32
    return {
        'keys.json': {
            'profile': PROFILE,
            'seeds': {name: (bytes([index + 1]) + bytes(31)).hex() for index, name in enumerate(NAMES)},
            'public_keys': publics,
        },
        'canonical.json': {
            'profile': PROFILE,
            'cases': [
                {'name': 'object', 'canonical': canonical({'b': 1, 'a': 2}).decode('ascii')},
                {'name': 'hash', 'sha256': digest('COVENANT-SPEC-VECTOR', {'n': 1})},
            ],
        },
        'signatures.json': {
            'profile': PROFILE,
            'document_version': PROFILE,
            'byte_compatible_versions': ['covenant-common/0.1', 'covenant-native/0.1'],
            'native': {'label': 'COVENANT-TX-SIGN-0.1', 'public': publics['owner'], 'body': signed_body, 'signature': native_signature},
            'common': {'label': 'COVENANT-COMMON-SIGN-0.1', 'version': 'covenant-common/0.1',
                       'public': publics['owner'], 'body': common_body, 'signature': common_signature,
                       'signing_prefix': SIGNING.decode('ascii').rstrip('\0')},
            'rejected_relabels': ['COVENANT-TX-SIGN-1.0', 'COVENANT-COMMON-SIGN-1.0', 'covenant-common/1.0'],
        },
        'state.json': {
            'profile': PROFILE,
            'protocol': 'covenant-native/0.1',
            'chain': state['chain'],
            'genesis_root': app.state_hash(state),
            'say_id': app.transaction_id(say),
            'say_root': app.state_hash(after_say),
            'say_payload_keeps_description': 'description' in say['body']['payload'],
            'event_omits_description': 'description' not in after_say['events'][app.transaction_id(say)],
            'historical_keys': sorted(state),
        },
        'light_proof.json': {
            'profile': PROFILE,
            'protocol': 'covenant-native/0.2',
            'root': root,
            'account': publics['owner'],
            'proof': proof,
            'opened_compute': verify_record(proof, root)['compute'],
        },
        'principal.json': principal,
        'salted_terms.json': salted,
        'core_freeze.json': {'profile': PROFILE, 'pins': frozen, 'boundary': 'docs/NATIVE_VERSION_BOUNDARY.md'},
        'rpc_tokens.json': {
            'profile': PROFILE,
            'consensus_op': None,
            'in_genesis': False,
            'admin': {'path': 'admin/rpc-token', 'hash': token_hash(admin), 'identity': 'admin'},
            'hosts': {
                'host-v0': {'path': 'host-v0/etc/covenant/rpc-token', 'hash': token_hash(host0), 'record': token_record('host-v0')},
                'host-v1': {'path': 'host-v1/etc/covenant/rpc-token', 'hash': token_hash(host1), 'record': token_record('host-v1')},
            },
        },
    }


def _principal(keys, publics):
    protocol = app.NEXT_VERSION
    state = app.genesis_state(reference_genesis(protocol))
    give = {'parent': None, 'holder': publics['agent'], 'resource': 'compute', 'limit': 50, 'expiry': 1000,
            'effects': ['AUTHORIZE', 'CONSUME', 'TRANSFER'], 'profiles': ['task-v1'], 'delegate': True}
    tx = _tx(keys, state, 'owner', 'GIVE', give, protocol)
    state = app.apply_transaction(state, tx, 1)
    grant = app.transaction_id(tx)
    permit_body = {'holder': publics['agent'], 'action': 'BIND', 'context': '11' * 32, 'expiry': 1000}
    tx = _tx(keys, state, 'owner', 'PERMIT', permit_body, protocol)
    state = app.apply_transaction(state, tx, 2)
    permit = app.transaction_id(tx)
    policy = draft_policy(publics['owner'], publics['agent'], grant, permit, 'BIND', '11' * 32,
                          {'compute': 40}, 500, ['CONSUME', 'TRANSFER'], ['task-v1'], [publics['worker']], 20)
    signature = sign(keys['owner'], PRINCIPAL_LABEL, policy)
    from .fixtures import terms
    proposed = terms(publics, state['chain'], grant, quantity=10, deadline=400)
    decision = authorize_bind(state, proposed, policy, signature, 3)
    missing = dict(proposed)
    missing['mandate'] = None
    try:
        authorize_bind(state, missing, policy, signature, 3)
        grantless = None
    except ValueError as exc:
        grantless = str(exc)
    return {
        'profile': PROFILE, 'label': PRINCIPAL_LABEL, 'consensus_op': None,
        'wire_protocol_for_grant': protocol, 'policy': policy, 'signature': signature,
        'authorized': decision['authorized'], 'delegate_bound_without_grant': decision['delegate_bound_without_grant'],
        'grantless': grantless,
    }


def _salted(keys, publics):
    context = 'ab' * 32
    target = {'kind': 'salted-terms', 'id': 'cd' * 32}
    salt = base64.b64encode(b'\x11' * 32).decode('ascii')
    terms = {'narrative': 'off-chain wording'}
    packet = prepare(terms, {'/narrative': salt}, context, [publics['owner']], target)
    body = assent_body(packet)
    approval = {'controller': publics['owner'], 'signature': sign(keys['owner'], SALTED_LABEL, body)}
    nxt_salt = base64.b64encode(b'\x22' * 32).decode('ascii')
    successor = prepare({'narrative': 'revised off-chain wording'}, {'/narrative': nxt_salt}, context,
                        [publics['owner']], target, supersedes=packet['id'])
    fresh = {'controller': publics['owner'], 'signature': sign(keys['owner'], SALTED_LABEL, assent_body(successor))}
    transition = verify_transition(packet, successor, [fresh])
    record = public_record(packet)
    return {
        'profile': PROFILE, 'version': 'covenant-salted-terms/1.0', 'assent_label': SALTED_LABEL,
        'applies_to_disclosure_0_1': applies_to('covenant-disclosure-scope/0.1'),
        'applies_to_native_0_1': applies_to('covenant-native/0.1'),
        'opening': {'terms': terms, 'salt': salt, 'context': context, 'path': '/narrative'},
        'public': record, 'plaintext_in_public': 'narrative' in record or 'off-chain wording' in json.dumps(record),
        'previous_assent_body': body, 'successor_id': transition['current'], 'fresh_assent': transition['fresh_assent'],
        'native_terms_hash_changed': transition['native_terms_hash_changed'],
    }


def write_all(directory):
    destination = Path(directory)
    destination.mkdir(parents=True, exist_ok=True)
    written = []
    for name, document in build().items():
        path = destination / name
        atomic_write(path, json.dumps(document, indent=2, sort_keys=True) + '\n')
        written.append(str(path))
    return written
