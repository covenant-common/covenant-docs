"""Named rule sets for the one covenant-native/0.15 profile.

`extend_features` stays the expr union: it adds `covenant_expr_02` and sorts,
and that is the contract tests pin. This module passes the full catalogue
through that function so the release candidate has one registry.

Security and expression sets stay off until `upgrade.features` lists them.
Economics and p2p sets are written into that list at 0.15 genesis, so
`feature_active` is the gate and a fresh chain already runs them.
"""
from covenant_language.expr_consensus import extend_features

ARBITRATION = ('panel_arbitration',)
CONSENSUS = ('pool_epoch_rollover', 'silent_referee_release', 'proof_freshness')
ECONOMICS = ('serving_rewards', 'offline_value', 'human_incentives')
P2P = ('scale_channels', 'scale_batches', 'scale_lineage')

CATALOGUE = extend_features(ARBITRATION + CONSENSUS + ECONOMICS + P2P)
GENESIS_FEATURES = tuple(sorted(set(ECONOMICS + P2P)))


def scale_feature(op):
    """Feature name that must be listed before a SCALE_* operation commits."""
    if type(op) is not str:
        return ''
    if op.startswith('SCALE_CHANNEL_'):
        return 'scale_channels'
    if op.startswith('SCALE_BATCH_'):
        return 'scale_batches'
    if op.startswith('SCALE_LINEAGE'):
        return 'scale_lineage'
    if op.startswith('SCALE_OFFLINE_'):
        return 'offline_value'
    return ''
