"""Keyless offline preparation and historical verification. No I/O or signing."""
from . import offline as o
from .cooperation_interface import HASH, INT, OBJECT


def spec():
    return ('covenant_offline',
        'Prepare exact offline agreements and explicit signing payloads; verify supplied signatures '
        'or pinned native history. No keys, signatures, transmission, storage or execution.', True, [
        ('spec', {}, ()),
        ('draft', {'scope': HASH, 'parties': {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': HASH},
                   'terms': {}, 'valid_from': INT, 'valid_until': INT, 'nonce': HASH,
                   'previous': HASH}, ('scope', 'parties', 'terms', 'valid_from', 'valid_until', 'nonce')),
        ('review', {'agreement': OBJECT, 'assents': {'type': 'array', 'maxItems': 16, 'items': OBJECT},
                    'expected_id': HASH, 'now': INT}, ('agreement', 'assents', 'expected_id', 'now')),
        ('verify_history', {'genesis': OBJECT, 'entries': {'type': 'array', 'maxItems': 64, 'items': OBJECT},
                            'expected_chain': HASH, 'minimum_height': INT},
                           ('genesis', 'entries', 'expected_chain', 'minimum_height')),
    ])


def instructions():
    return {'agreement_profile': o.AGREEMENT, 'transport_profile': o.ENVELOPE,
        'journey': ['Draft and review exact terms; retain the independent agreement ID.',
                    'Each party explicitly signs locally in its own custody.',
                    'Cache and merge supplied signatures in an encrypted OfflineStore.',
                    'Seal to an adopted recipient and shared transport key; enqueue once.',
                    'Carry exact bytes by file, QR, local link, or owner-installed adapter.',
                    'Retain at destination; signed delivery ACK only means recipient custody.',
                    'Confirm ledger history against independent genesis and a freshness floor.'],
        'statuses': ['AWAITING_SIGNATURES', 'SIGNED', 'AWAITING_DELIVERY', 'RECEIVED',
                     'RECIPIENT_RETAINED', 'EXPIRED', 'LEDGER_CERTIFIED'],
        'limits': _limits(),
        'privacy': 'AES-256-GCM-SIV for custody and adopted shared-key transport; Ed25519 sender signatures. '
                   'Routing identities, scope, length and times remain visible. No forward secrecy or ZK claim.',
        'settlement': 'Disconnected signatures cannot establish exclusive spend. An adopted connected quorum '
                      'and its certificate/state checks remain necessary. GPS is optional evidence, not a carrier.',
        'carrier_standard': 'Covenant store/carry/forward envelope. Optional BPv7 (RFC 9171) bundle carrier '
                            'in dtn_bundle and one-way broadcast_fec chunks; carrier success never '
                            'certifies settlement.',
        'execution_authorized': False, 'payment_verified': False}



def _limits():
    """Every offline bound an agent needs before it frames bytes (BLE, carrier, hop, vault added from Cursor PR 58)."""
    from .offline_ble import describe_limits as ble
    from .offline_carriers import describe_limits as carrier
    from .offline_forwarding import describe_hop
    from .offline_store import describe_vault
    strip = lambda row: {k: v for k, v in row.items() if k != 'execution_authorized'}
    return {'payload_bytes': o.MAX_PAYLOAD, 'packet_bytes': o.MAX_PACKET,
            'mesh_frame_bytes': 200, 'packet_lifetime_seconds': o.MAX_LIFETIME,
            'ble': strip(ble()), 'carrier': strip(carrier()), 'hop': strip(describe_hop()), 'vault': strip(describe_vault())}


def call(action, parameters):
    if action == 'spec':
        return instructions()
    if action == 'draft':
        agreement = o.draft(**parameters)
        return {'agreement': agreement, 'id': o.agreement_id(agreement),
                'signing_payload': o.signing_payload(agreement), 'execution_authorized': False}
    if action == 'review':
        return o.review(**parameters)
    if action == 'verify_history':
        from .proofs import verify_history
        o.c.need(type(parameters.get('entries')) is list and len(parameters['entries']) <= 64,
                 'OFFLINE_HISTORY_COUNT')
        o.c.need(len(o.c.canonical(parameters)) <= 262144, 'OFFLINE_HISTORY_SIZE')
        result = verify_history(**parameters)
        return {k: result[k] for k in ('chain', 'height', 'head', 'state_root')} | {
            'status': 'LEDGER_CERTIFIED' if result['height'] else 'GENESIS_ONLY',
            'current_freshness_verified': False, 'payment_verified': False, 'execution_authorized': False}
    raise ValueError('OFFLINE_ACTION')
