"""Skyfire KYAPay tokens read as identity evidence for an agent, bound to a did:aap key only by its signature.

GRAFT: draft-skyfire-oauth-kyapay-token-02 (2 October 2026; Agarwal, Jones) with the recipient rules of
draft-skyfire-oauth-using-kyapay-tokens-01 (2 October 2026):

* Header (section 4.1.1): ``typ`` is kya+jwt, pay+jwt or kya-pay+jwt, compared case-insensitively (RFC
  7515 section 4.1.9); the legacy kya+pay+JWT spelling is another value and is refused. ``alg`` is one the
  owner accepts (ES256 is RECOMMENDED; never none). ``kid`` names a key of the issuer JWK set the owner
  pinned for that issuer.
* Issuer (sections 3.1-3.2; using-tokens 6.1 step 2 and 8.6): an origin the owner trusts, named before
  anything in the token is resolved. Its keys are the pinned set; ``iss`` never causes a fetch.
* Payload (section 4.1.2, in order): signature, iss, exp and iat within the skew (section 4.1.3: 5 to 60
  seconds, 30 by default), jti a UUID, aud this recipient, env the expected environment; a lifetime no
  longer than the owner's maximum and a jti not seen before (using-tokens 8.2, 8.3).
* KYA claims (section 3.3): hid with email, aid with name and creation_ip, apd with id and name when
  present. PAY claims (sections 3.4, 4.2): amt and val above zero, cur, stp and sti.type, and tps and tpr
  equal to the owner's configured pricing when the owner names one. The settlement instrument is never
  read back: sti.payment_token, its expiry and token_security_code are dropped, so no card data or
  cryptogram leaves this module, and personal data (hid, aid addresses) is reported as presence plus one
  SHA-256 commitment, never copied. Skyfire's deployed names ssi, btg, sdm, spr and sps are read as aliases
  of tsi, itg, tdm, tpr and tps.
* cnf (RFC 7800; section 5.5): a sender-constrained token names a public JWK, and the request must carry an
  RFC 9421 signature by that key (using-tokens 6.1 step 6), checked with http_signatures; without that
  request the token is refused, never treated as bearer.

A KYA token is its issuer's bearer statement about an agent account at that issuer. It concerns a did:aap
account only through that account's signature: a covenant-evidence-binding/0.1 record (kind KYA_TOKEN) the
account key signs, or a cnf key that is the account's Ed25519 key and signed the presenting request. Two
accounts claiming one token is a CONFLICT. Nothing here grants authority, pays or releases.
"""
from copy import deepcopy
import hashlib
import re
from urllib.parse import urlsplit

from .crypto import integer, need
from . import http_signatures as httpsig
from . import interop_codec as codec
from . import trust_evidence as evidence

DRAFT = 'draft-skyfire-oauth-kyapay-token-02'
USING = 'draft-skyfire-oauth-using-kyapay-tokens-01'
TYPES = ('kya+jwt', 'pay+jwt', 'kya-pay+jwt')
ALIASES = {'ssi': 'tsi', 'btg': 'itg', 'sdm': 'tdm', 'spr': 'tpr', 'sps': 'tps'}
UUID = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\Z')
DECIMAL = re.compile(r'(0|[1-9][0-9]{0,17})(\.[0-9]{1,18})?\Z')
TOKEN_CHARS = re.compile(r'[A-Za-z0-9_.-]+\Z')
DEFAULT_SKEW = 30
DEFAULT_MAX_LIFETIME = 86400
MAX_TOKENS = 8
MAX_SEEN = 4096

REMEDIATION = {
    'KYA_ISSUER': 'Pin the issuer yourself as an https origin (no path) with its JWK set; a token cannot nominate it.',
    'KYA_ISSUER_UNTRUSTED': 'The token iss is not the issuer you pinned; refuse it (using-tokens section 6.1 step 2).',
    'KYA_TYPE': 'typ must be kya+jwt, pay+jwt or kya-pay+jwt (draft section 4.1.1 item 3).',
    'KYA_POLICY': 'Pass now, audience, skew 5-60 s, a maximum lifetime, at most 4096 seen jtis and accepted algorithms.',
    'KYA_CLAIMS': 'The token lacks a required claim or has the wrong type (sections 3.1, 3.3, 3.4).',
    'KYA_EXPIRED': 'The token expired beyond the clock skew; obtain a fresh token.',
    'KYA_NOT_YET_VALID': 'iat lies in the future beyond the clock skew.',
    'KYA_LIFETIME': 'exp minus iat exceeds the maximum lifetime you accept (using-tokens section 8.2).',
    'KYA_AUDIENCE': 'aud does not name this recipient (section 4.1.2 item 6).',
    'KYA_ENVIRONMENT': 'env does not equal the environment you operate in (section 4.1.2 item 7).',
    'KYA_REPLAY': 'This jti was already accepted; refuse the replayed token (using-tokens section 8.3).',
    'KYA_PAYMENT': 'A PAY token needs amt and val above zero, cur, stp and sti.type, and pricing equal to yours (section 4.2).',
    'KYA_CONFIRMATION': 'cnf must hold a public jwk only (RFC 7800; section 3.1).',
    'KYA_SENDER_CONSTRAINED': 'This token carries cnf: pass the presenting request so its RFC 9421 signature by that key is checked.',
    'KYA_HEADER': 'KYAPay-Token holds at most 8 comma-separated JWTs (using-tokens section 5.1).',
    'JWS_HEADER': 'The JWS header needs alg (and kid when several keys are adopted); crit is refused.',
}


def remediation(code):
    return REMEDIATION.get(code, evidence.remediation(code))


def _origin(value):
    need(type(value) is str and 0 < len(value) <= 256 and value.isascii() and value.isprintable(), 'KYA_ISSUER')
    try:
        parts = urlsplit(value)
        port = parts.port
    except ValueError:
        raise ValueError('KYA_ISSUER') from None
    need(parts.scheme == 'https' and parts.hostname and not parts.username and not parts.password
         and parts.path == '' and not parts.query and not parts.fragment and port in (None, *range(1, 65536)), 'KYA_ISSUER')
    return value


def header_tokens(value):
    """The JWTs of one KYAPay-Token field value (using-tokens section 5.1); a member that does not parse is ignored."""
    need(type(value) is str and len(value) <= evidence.MAX_TOKEN * MAX_TOKENS, 'KYA_HEADER')
    found = [member.strip(' \t') for member in value.split(',')]
    tokens = [member for member in found if TOKEN_CHARS.fullmatch(member) and member.count('.') == 2]
    need(len(tokens) <= MAX_TOKENS, 'KYA_HEADER')
    return tokens


def _text(value, code='KYA_CLAIMS', limit=512):
    need(type(value) is str and 0 < len(value) <= limit, code)
    return value


def _time(value):
    need(type(value) in (int, float) and value == value and 0 <= value <= 2**53, 'KYA_CLAIMS')
    return value


def _amount(value):
    need(type(value) is str and DECIMAL.fullmatch(value) is not None and float(value) > 0, 'KYA_PAYMENT')
    return value


def _commitment(value):
    return hashlib.sha256(codec.jcs(value)).hexdigest()


def _kya(claims):
    hid, aid, apd = claims.get('hid'), claims.get('aid'), claims.get('apd')
    need(type(hid) is dict and type(hid.get('email')) is str and type(aid) is dict, 'KYA_CLAIMS')
    _text(aid.get('name')); _text(aid.get('creation_ip'), limit=64)
    need(type(hid.get('verified', False)) is bool and type(aid.get('source_ips', [])) is list, 'KYA_CLAIMS')
    out = {'hid': {'present': sorted(hid), 'verified': hid.get('verified') is True,
                   'verifier': hid['verifier'][:512] if type(hid.get('verifier')) is str else None,
                   'sha256': _commitment(hid)},
           'aid': {'name': aid['name'], 'id': aid['id'][:256] if type(aid.get('id')) is str else None,
                   'source_ips': len(aid.get('source_ips', [])), 'addresses_sha256': _commitment(
                       {'creation_ip': aid['creation_ip'], 'source_ips': aid.get('source_ips', [])})}}
    if apd is not None:
        need(type(apd) is dict, 'KYA_CLAIMS')
        _text(apd.get('id')); _text(apd.get('name'))
        need(type(apd.get('verified', False)) is bool, 'KYA_CLAIMS')
        out['apd'] = {name: apd[name][:512] for name in ('id', 'name', 'organization_name', 'verifier', 'verification_id')
                      if type(apd.get(name)) is str}
        out['apd'].update(verified=apd.get('verified') is True, present=sorted(apd))
    if 'scope' in claims:
        out['scope'] = _text(claims['scope'], limit=2048)
    return out


def _pay(claims, pricing):
    sti = claims.get('sti')
    need(type(sti) is dict and type(sti.get('type')) is str and type(claims.get('stp')) is str
         and type(claims.get('cur')) is str and re.fullmatch(r'[A-Za-z]{3}', claims['cur']), 'KYA_PAYMENT')
    out = {'amt': _amount(claims.get('amt')), 'val': _amount(claims.get('val')), 'cur': claims['cur'],
           'stp': claims['stp'][:32], 'sti_type': sti['type'][:64],
           'instrument': 'NOT_READ_SETTLEMENT_CREDENTIAL_DROPPED'}
    for name in ('tpr', 'tps'):
        if name in claims:
            need(type(claims[name]) is str and len(claims[name]) <= 64, 'KYA_PAYMENT')
            out[name] = claims[name]
            if pricing is not None and name in pricing:
                need(claims[name] == pricing[name], 'KYA_PAYMENT')
    if 'mnr' in claims:
        need(type(claims['mnr']) is int and claims['mnr'] >= 0, 'KYA_PAYMENT')
        out['mnr'] = claims['mnr']
    return out


def _confirmation(claims):
    cnf = claims.get('cnf')
    if cnf is None:
        return None
    need(type(cnf) is dict and type(cnf.get('jwk')) is dict and not httpsig.PRIVATE_MEMBERS & set(cnf['jwk']),
         'KYA_CONFIRMATION')
    rows = httpsig.adopt_keys([cnf['jwk']])
    need(len(rows) == 1, 'KYA_CONFIRMATION')
    return rows[0]


def verify(token, issuer, issuer_keys, now, *, audience, env=None, skew=DEFAULT_SKEW, max_lifetime=DEFAULT_MAX_LIFETIME,
           seen_jti=(), algorithms=('ES256',), pricing=None, request=None, chain=None, bindings=()):
    """Verify one KYAPay token under the issuer and keys the owner pinned; return labelled identity evidence."""
    issuer = _origin(issuer)
    integer(now)
    need(type(audience) is str and 0 < len(audience) <= 512 and type(skew) is int and 5 <= skew <= 60
         and type(max_lifetime) is int and 0 < max_lifetime <= 31_536_000 and type(seen_jti) in (list, tuple, set, frozenset)
         and len(seen_jti) <= MAX_SEEN and type(algorithms) in (list, tuple) and 0 < len(algorithms) <= 4
         and 'none' not in algorithms and (env is None or type(env) is str)
         and (pricing is None or (type(pricing) is dict and set(pricing) <= {'tpr', 'tps'})), 'KYA_POLICY')
    header, claims, signing_sha256, row = evidence.jws(token, issuer_keys, tuple(algorithms))
    need(type(header.get('kid')) is str, 'JWS_HEADER')
    typ = header.get('typ')
    need(type(typ) is str and typ.lower() in TYPES, 'KYA_TYPE')
    typ = typ.lower()
    for legacy, name in ALIASES.items():
        if legacy in claims and name not in claims:
            claims[name] = claims[legacy]
    need(type(claims.get('iss')) is str, 'KYA_CLAIMS')
    need(claims['iss'] == issuer, 'KYA_ISSUER_UNTRUSTED')
    _text(claims.get('sub')); _text(claims.get('aud'))
    exp, iat = _time(claims.get('exp')), _time(claims.get('iat'))
    need(now <= exp + skew, 'KYA_EXPIRED')
    need(iat <= now + skew, 'KYA_NOT_YET_VALID')
    need(type(claims.get('jti')) is str and UUID.fullmatch(claims['jti']) is not None, 'KYA_CLAIMS')
    need(claims['aud'] == audience, 'KYA_AUDIENCE')
    need(env is None or claims.get('env') == env, 'KYA_ENVIRONMENT')
    need(exp - iat <= max_lifetime, 'KYA_LIFETIME')
    need(claims['jti'] not in seen_jti, 'KYA_REPLAY')
    summary = {'typ': typ, 'iss': issuer, 'sub': claims['sub'], 'aud': audience, 'jti': claims['jti'], 'iat': iat,
               'exp': exp, 'env': claims.get('env') if type(claims.get('env')) is str else None,
               'target': {name: claims[name][:256] for name in ('tdm', 'tsi', 'itg', 'ori') if type(claims.get(name)) is str}}
    if typ in ('kya+jwt', 'kya-pay+jwt'):
        summary.update(_kya(claims))
    if typ in ('pay+jwt', 'kya-pay+jwt'):
        summary['payment'] = _pay(claims, pricing)
    confirmation = _confirmation(claims)
    checks = {'signature': 'VERIFIED_UNDER_PINNED_ISSUER_KEY', 'kid': header['kid'], 'alg': header['alg'],
              'clock': 'CALLER_ASSERTION', 'bearer': confirmation is None}
    signed_by = None
    if confirmation is not None:
        need(request is not None, 'KYA_SENDER_CONSTRAINED')
        # The request keyid may be the cnf key's own kid or its RFC 7638 thumbprint; both name this one key.
        named = claims['cnf']['jwk'].get('kid')
        keys = [confirmation['jwk']] + ([dict(confirmation['jwk'], kid=named)]
                                        if type(named) is str and named != confirmation['thumbprint'] else [])
        required = ['@method', '@authority', '@path']
        if type(request) is dict and request.get('body') is not None:
            required.append('content-digest')
        signed = httpsig.verify(request, keys, now, required=required, require_created=True, max_age=300, skew=skew)
        checks.update(sender_constrained=confirmation['thumbprint'], request_signature=signed['signature_base_sha256'])
        signed_by = confirmation['aap_key']
    found = evidence.evidence('KYA_TOKEN', 'SKYFIRE_KYAPAY', issuer, claims['sub'], signing_sha256, summary, checks,
                              signed_by=signed_by, chain=chain, bindings=bindings, audience=audience, now=now)
    if confirmation is not None:
        kept = [row for row in found['bound'] if row['basis'] == 'SIGNED_BY_AAP_KEY'
                or row.get('holder') == confirmation['thumbprint']
                or evidence.httpsig.thumbprint(codec.okp_jwk(row['key'])) == confirmation['thumbprint']]
        found['excluded'] += [{'status': 'EXCLUDED', 'reason': 'KYA_CONFIRMATION', 'key': row['key']}
                              for row in found['bound'] if row not in kept]
        found['bound'] = kept
        found['status'] = 'CONFLICT' if len({row['key'] for row in kept}) > 1 else ('BOUND' if kept else 'NOT_BOUND')
    found.update(draft=DRAFT, token_type=typ, jti=claims['jti'], expires=exp, token_returned=False,
                 card_data_returned=False, personal_data='PRESENCE_AND_SHA256_COMMITMENT_ONLY')
    return found


def describe():
    return {'status': 'EXPERIMENTAL_GRAFT', 'drafts': [DRAFT, USING], 'types': list(TYPES), 'aliases': dict(ALIASES),
            'issuer': 'OWNER_PINNED_ORIGIN_AND_JWK_SET_NEVER_FETCHED', 'skew': {'default': DEFAULT_SKEW, 'range': [5, 60]},
            'max_lifetime_default': DEFAULT_MAX_LIFETIME, 'card_data': 'NEVER_READ_OR_RETURNED',
            'binding': 'COVENANT_EVIDENCE_BINDING_KYA_TOKEN_OR_CNF_KEY_REQUEST_SIGNATURE',
            'remediation': dict(REMEDIATION), 'network_accessed': False, 'authority_granted': False,
            'execution_authorized': False}
