"""Portable, explicitly adopted agent qualifications; no authority or legal accreditation.

This new profile signs exact assessment claims and exact status snapshots. It
does not reinterpret historical hidden credentials or implement a W3C status
list. The owner adopts issuer keys, accepted scope and freshness limits. A
signed snapshot establishes what that issuer said at that time, not the latest
global status, assessor honesty, identity, financial backing or permission.

VerifierStore retains snapshot high-water marks and consumed challenges across
restarts. Its private local files require trusted owner custody. Retaining an
external checkpoint is necessary to detect replacement of the whole directory
by an old valid copy. No online callback, code loader or secret-export API exists.
"""
from copy import deepcopy
import threading

from .crypto import canonical, digest, integer, key, loads, need, public_key, sign, verify
from .identity_store import StateFile

VERSION = 'covenant-agent-accreditation/0.1'
STATUS_VERSION = 'covenant-agent-accreditation-status/0.1'
LEGACY_POLICY_VERSION = 'covenant-agent-accreditation-policy/0.1'
POLICY_VERSION = 'covenant-agent-accreditation-policy/0.2'
PRESENTATION_VERSION = 'covenant-agent-accreditation-presentation/0.1'
STATE_VERSION = 'covenant-agent-accreditation-verifier/0.1'
ISSUE_LABEL = 'COVENANT-AGENT-ACCREDITATION-0.1'
STATUS_LABEL = 'COVENANT-AGENT-ACCREDITATION-STATUS-0.1'
HOLDER_LABEL = 'COVENANT-AGENT-ACCREDITATION-HOLDER-0.1'
MAX_PACKET = 1_048_576
MAX_LIFETIME = 366 * 86400
MAX_FRESHNESS = 30 * 86400
MAX_STATUS_ENTRIES = 4096
MAX_CONSUMED = 8192
MAX_ISSUERS = 64

# Every refusal: what happened, what to do, whether an unchanged retry can succeed.
ERRORS = {
    'ACCREDITATION_FIELDS': ('A packet, credential, snapshot, policy or holder proof has missing or unknown fields.',
                             'Send the object exactly as the profile defines it; unknown fields are never adopted.', False),
    'ACCREDITATION_TEXT': ('A text field is empty, longer than allowed or not printable ASCII.',
                           'Use 1 to 160 printable ASCII characters (256 for a challenge).', False),
    'ACCREDITATION_SIZE': ('The packet is larger than 1 MiB.', 'Carry a smaller packet.', False),
    'ACCREDITATION_SCOPE': ('The scope list is empty, unsorted, repeated or longer than 16 entries.',
                            'Give a sorted list of distinct covered-work names.', False),
    'ACCREDITATION_EVIDENCE': ('Evidence is not a sorted list of at most 32 distinct digests.',
                               'Give sorted, distinct SHA-256 evidence digests.', False),
    'ACCREDITATION_OUTCOME': ('The outcome is not PASS, FAIL or INCOMPLETE.', 'Record one of the three outcomes.', False),
    'ACCREDITATION_VERSION': ('The credential names another profile version.', 'Use covenant-agent-accreditation/0.1.', False),
    'ACCREDITATION_VALIDITY': ('Issue, start and expiry times are out of order or more than 366 days apart.',
                               'Use issued_at <= not_before < expires_at within 366 days.', False),
    'ACCREDITATION_STATUS_VERSION': ('The snapshot names another profile version.',
                                     'Use covenant-agent-accreditation-status/0.1.', False),
    'ACCREDITATION_STATUS_VALIDITY': ('The snapshot expires before it is issued, or lasts more than 30 days.',
                                      'Sign snapshots valid for at most 30 days.', False),
    'ACCREDITATION_STATUS_ENTRIES': ('The snapshot lists more than 4096 credentials.', 'Split credentials across issuers or lists.',
                                     False),
    'ACCREDITATION_STATUS_VALUE': ('A snapshot entry is not ACTIVE, SUSPENDED or REVOKED.', 'Use one of the three values.', False),
    'ACCREDITATION_POLICY_VERSION': ('The policy names an unknown version.',
                                     'Use covenant-agent-accreditation-policy/0.2 (or /0.1 for its original meaning).', False),
    'ACCREDITATION_ISSUERS': ('The policy adopts no issuer, too many, or more than 16 key versions for one issuer.',
                              'Adopt between 1 and 64 issuers, each with 1 to 16 pinned key versions.', False),
    'ACCREDITATION_FRESHNESS': ('A maximum age is not between 1 second and 30 days.', 'Choose an explicit maximum age.', False),
    'ACCREDITATION_ISSUER_NOT_ADOPTED': ('The relying party has not adopted this issuer and key version.',
                                         'Ask for a qualification from an adopted issuer, or adopt the issuer explicitly.', False),
    'ACCREDITATION_STATUS_ISSUER': ('The status snapshot comes from another issuer than the credential.',
                                    'Use the credential issuer\'s own snapshot.', False),
    'ACCREDITATION_EXPIRED': ('The credential is not yet valid or has expired at the supplied time.',
                              'Ask the holder for a current credential, or check the clock.', False),
    'ACCREDITATION_STATUS_STALE': ('The status snapshot is older than the maximum age, expired or dated after the clock.',
                                   'Obtain the issuer\'s fresh snapshot; a stale one never becomes current.', True),
    'ACCREDITATION_STATUS_PREDATES_CREDENTIAL': ('The status snapshot was issued before the credential.',
                                                 'Use a snapshot issued after the credential.', True),
    'ACCREDITATION_PRESENTATION_BINDING': ('The holder proof does not bind this exact credential, snapshot or disclosures.',
                                           'Ask the holder to present again; do not edit a presentation.', True),
    'ACCREDITATION_CHALLENGE': ('The presentation answers another audience or challenge.',
                                'Ask for a presentation over your current audience and challenge.', True),
    'ACCREDITATION_PRESENTATION_STALE': ('The holder proof is older than the maximum presentation age, or from the future.',
                                         'Ask for a fresh presentation.', True),
    'ACCREDITATION_SCOPE_MISMATCH': ('The qualification is for another artifact, profile, qualification or narrower scope.',
                                     'Ask for a qualification of exactly what you require.', False),
    'ACCREDITATION_CRITERIA_MISMATCH': ('The qualification was assessed against other criteria than the policy pins.',
                                        'Ask for an assessment against the pinned criteria.', False),
    'ACCREDITATION_NOT_PASSED': ('The recorded outcome is FAIL or INCOMPLETE.', 'Only a PASS qualifies; a record is not a pass.',
                                 False),
    'ACCREDITATION_STATUS_SUSPENDED': ('The issuer suspended this qualification.',
                                       'Wait for a newer snapshot that lifts the suspension, or decline.', True),
    'ACCREDITATION_STATUS_REVOKED': ('The issuer revoked this qualification; revocation is never undone.',
                                     'Decline; a new qualification needs a new credential.', False),
    'ACCREDITATION_STATUS_UNKNOWN': ('The snapshot does not list this credential.',
                                     'Missing means unknown, never active; obtain a snapshot that lists it.', True),
    'ACCREDITATION_HOLDER': ('The presenter does not control the credential\'s holder key.',
                             'Only the holder can present; ask the holder.', False),
    'ACCREDITATION_OFFLINE': ('The offline flag is not a boolean.', 'Pass true or false.', False),
    'ACCREDITATION_VERIFIER_STORE_REQUIRED': ('Durable verification needs the owner\'s VerifierStore.',
                                              'Open the owner\'s store and pass it.', False),
    'ACCREDITATION_STORE_AUDIENCE': ('The store belongs to another audience than the policy.',
                                     'Use the store opened for this audience.', False),
    'ACCREDITATION_STORE': ('The store state is malformed.', 'Restore the store from a verified backup and its checkpoint.',
                            False),
    'ACCREDITATION_STORE_CLOSED': ('The store was closed.', 'Open the store again.', True),
    'ACCREDITATION_STORE_QUOTA': ('The store reached its limit of issuers, revocations or challenges.',
                                  'Review migration to a new verifier context; history is never silently dropped.', False),
    'ACCREDITATION_STORE_ROLLBACK': ('The store does not match the retained external checkpoint.',
                                     'The directory may have been replaced by an old copy; restore the latest state.', False),
    'ACCREDITATION_CLOCK_ROLLBACK': ('The supplied clock is earlier than one this store already used.',
                                     'Use a trustworthy, monotonic owner clock.', False),
    'ACCREDITATION_STATUS_ROLLBACK': ('This snapshot is older than one the store already accepted.',
                                      'Obtain the issuer\'s current snapshot; an older list could hide a revocation.', True),
    'ACCREDITATION_STATUS_EQUIVOCATION': ('The issuer signed two different snapshots with the same sequence.',
                                          'Keep both as evidence; stop relying on the issuer until it explains.', False),
    'ACCREDITATION_STATUS_TIME_ROLLBACK': ('A newer sequence carries an earlier issue time.',
                                           'Refuse the snapshot and report the issuer clock inconsistency.', False),
    'ACCREDITATION_PRESENTATION_REPLAY': ('This challenge was already used.', 'Issue a new challenge for each check.', False),
    'ACCREDITATION_INPUT_FILE': ('The input is not a regular file within the size limit, or is a link.',
                                 'Pass a regular file you own, at most 1 MiB.', False),
    'ACCREDITATION_REFUSED': ('The command refused an input without echoing it.', 'Check the inputs against the profile.', False),
    # Shared low-level codes these modules can surface.
    'SIGNATURE': ('A signature does not verify under the key it must verify under.',
                  'The signed bytes were changed or signed by another key; obtain them again from the signer.', False),
    'KEY': ('A key or digest is not 64 lowercase hex characters.', 'Pass the exact 64-hex value.', False),
    'PUBLIC_KEY': ('A 64-hex value is not a valid Ed25519 public key.', 'Pass the signer\'s actual verification key.', False),
    'INTEGER': ('A number is not a non-negative integer within 2**53 - 1.', 'Pass whole seconds or counts; booleans and '
                'fractions are refused.', False),
}


def explain(code):
    """Code, what happened, what to do, whether retrying helps, and the reference entry."""
    happened, fix, retry = ERRORS.get(code, ('Unrecognised refusal.', 'Read docs/AGENT_ACCREDITATION.html.', False))
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/AGENT_ACCREDITATION.html#' + code}

# Fix text for each refusal code raised here: what happened, then what to do next.
# tools/build_lead_docs.py copies it into the error catalogue every agent host reads.
REMEDIATION = {
    'ACCREDITATION_FIELDS':
        'The qualification record does not have exactly the fields this version defines. Pass the credential,'
        ' status snapshot, policy or presentation exactly as it was issued.',
    'ACCREDITATION_TEXT':
        'A text field is empty, too long or not plain printable ASCII (most fields take at most 160 '
        'characters, a challenge nonce at most 256). Use short printable ASCII text.',
    'ACCREDITATION_SIZE':
        'The qualification packet is larger than 1048576 bytes. Send a smaller packet and carry large '
        'evidence as hashes.',
    'ACCREDITATION_SCOPE':
        'The scope is not a sorted list of 1 to 16 distinct short text items. Sort the scope, remove repeats '
        'and keep each item printable ASCII.',
    'ACCREDITATION_VERSION':
        'The credential is not version covenant-agent-accreditation/0.1. Use a credential of this version; '
        'another version needs its own reader.',
    'ACCREDITATION_EVIDENCE':
        'The evidence list is not a sorted list of at most 32 distinct 64-character hex hashes. Pass the '
        'evidence hashes sorted and without repeats.',
    'ACCREDITATION_OUTCOME': 'The outcome is not PASS, FAIL or INCOMPLETE. Use one of those three values.',
    'ACCREDITATION_VALIDITY':
        'The credential times are out of order, or it lasts longer than 366 days; it needs issued_at <= '
        'not_before < expires_at. Ask the issuer to issue it again with valid times.',
    'ACCREDITATION_STATUS_VERSION':
        'The status snapshot is not version covenant-agent-accreditation-status/0.1. Get a snapshot of this '
        'version from the issuer.',
    'ACCREDITATION_STATUS_VALIDITY':
        'The status snapshot is valid for no time, or for longer than 30 days. Get a fresh snapshot from the '
        'issuer with a shorter validity.',
    'ACCREDITATION_STATUS_ENTRIES':
        'The status snapshot entries are not an object, or list more than 4096 credentials. Ask the issuer '
        'for a snapshot within that limit.',
    'ACCREDITATION_STATUS_VALUE':
        'A status entry is not ACTIVE, SUSPENDED or REVOKED. Ask the issuer for a valid snapshot; a missing '
        'entry means unknown, never active.',
    'ACCREDITATION_POLICY_VERSION':
        'The acceptance policy is not version covenant-agent-accreditation-policy/0.2 or the older 0.1. Build'
        ' the policy with this package and have the owner adopt it.',
    'ACCREDITATION_ISSUERS':
        'The policy names no issuers or more than 64, or an issuer with no key versions or more than 16. The '
        'owner lists each adopted issuer with its key versions.',
    'ACCREDITATION_FRESHNESS':
        'A maximum status or presentation age in the policy is longer than 30 days. Choose a shorter age.',
    'ACCREDITATION_ISSUER_NOT_ADOPTED':
        'The issuer or its key version is not adopted in your policy, so its claim does not count. Ask the '
        'owner to adopt that issuer key after checking it; a key inside the packet is not trust.',
    'ACCREDITATION_HOLDER':
        'The key presenting the credential is not the holder key the credential names. Present it with the '
        'holder key it was issued to.',
    'ACCREDITATION_PRESENTATION_BINDING':
        'The presentation does not cover this exact credential and status snapshot. Make a new presentation '
        'over the exact pair you send.',
    'ACCREDITATION_OFFLINE': 'The offline flag is not true or false. Pass a boolean.',
    'ACCREDITATION_STATUS_ISSUER':
        'The status snapshot comes from another issuer than the credential. Get the snapshot from the issuer '
        'that signed the credential.',
    'ACCREDITATION_EXPIRED':
        'The credential is not valid at this time: it is before not_before, or at or after expires_at. Ask '
        'the issuer for a current credential.',
    'ACCREDITATION_STATUS_STALE':
        'The status snapshot is older than your policy allows, or not valid at this time. Get a fresh '
        'snapshot from the issuer and present again.',
    'ACCREDITATION_STATUS_PREDATES_CREDENTIAL':
        'The status snapshot is older than the credential, so it cannot speak for it. Get a snapshot issued '
        'after the credential.',
    'ACCREDITATION_CHALLENGE':
        'The presentation is for another verifier or another challenge nonce. Ask the holder to present again'
        ' for your audience and your fresh nonce.',
    'ACCREDITATION_PRESENTATION_STALE':
        'The presentation is dated in the future or is older than your policy allows. Ask the holder for a '
        'fresh presentation.',
    'ACCREDITATION_SCOPE_MISMATCH':
        'The credential does not cover the artifact, profile, qualification or scope your policy asks for. '
        'Ask for a credential that covers exactly what you need.',
    'ACCREDITATION_CRITERIA_MISMATCH':
        'The credential was assessed against other criteria than your policy pins. Ask for a credential '
        'assessed against the pinned criteria.',
    'ACCREDITATION_NOT_PASSED':
        'The assessment outcome is not PASS, so the qualification is not accepted. Ask the issuer about a new'
        ' assessment; a FAIL or INCOMPLETE result does not count.',
    'ACCREDITATION_STORE_ROLLBACK':
        'The verifier store does not match the checkpoint you kept, so it may have been replaced by an older '
        'copy. Stop, and have the owner restore the store that matches the checkpoint.',
    'ACCREDITATION_STORE':
        'The verifier store file is malformed or over its limits (64 issuers, 4096 revocations, 8192 used '
        'challenges). Have the owner restore it from a backup; never edit it by hand.',
    'ACCREDITATION_STORE_CLOSED': 'The verifier store was closed. Open it again before checking presentations.',
    'ACCREDITATION_CLOCK_ROLLBACK':
        'The time given is earlier than a time this verifier already used. Pass the current time from a '
        'trusted clock; time never goes back here.',
    'ACCREDITATION_STATUS_ROLLBACK':
        'The status snapshot has a lower sequence number than one this verifier already saw. Get the latest '
        'snapshot from the issuer; an older one is refused.',
    'ACCREDITATION_STATUS_EQUIVOCATION':
        'The issuer signed two different snapshots with the same sequence number. Keep both as proof and stop'
        ' relying on this issuer until it explains.',
    'ACCREDITATION_STATUS_TIME_ROLLBACK':
        'The status snapshot is dated earlier than one this verifier already saw. Get the latest snapshot '
        'from the issuer.',
    'ACCREDITATION_STORE_QUOTA':
        'The verifier store is full (64 issuers, 4096 known revocations or 8192 used challenges). Keep this '
        'store as a record and have the owner open a new one, retaining its checkpoint.',
    'ACCREDITATION_VERIFIER_STORE_REQUIRED':
        'This check needs an owner verifier store to stop replays and rollbacks. Open a VerifierStore and '
        'pass it as store.',
    'ACCREDITATION_STORE_AUDIENCE':
        'The verifier store belongs to another audience than the policy names. Use the store opened for this '
        'audience.',
    'ACCREDITATION_STATUS_REVOKED':
        'The issuer revoked this credential, so it no longer counts. Ask the holder for another '
        'qualification.',
    'ACCREDITATION_STATUS_SUSPENDED':
        'The issuer suspended this credential, so it does not count now. Ask the holder or the issuer when it'
        ' is active again, then present a fresh snapshot.',
    'ACCREDITATION_STATUS_UNKNOWN':
        'The status snapshot does not list this credential, and unknown never counts as active. Ask the '
        'issuer for a snapshot that lists it.',
    'ACCREDITATION_PRESENTATION_REPLAY':
        'This challenge was already used for an accepted presentation. Issue a new challenge nonce and ask '
        'the holder to present again.',
    'ACCREDITATION_INPUT_FILE':
        'An input file is not a regular file of at most 1048576 bytes. Pass the path of the exact '
        'presentation or policy file.',
    'ACCREDITATION_REFUSED':
        'The input could not be read as a qualification packet or policy, and its contents are not echoed '
        'back. Check that the files are the exact packets as exported.',
}



def _exact(value, fields):
    need(type(value) is dict and set(value) == set(fields.split()), 'ACCREDITATION_FIELDS')


def _text(value, maximum=160):
    need(type(value) is str and 0 < len(value) <= maximum and
         all(32 <= ord(c) <= 126 for c in value), 'ACCREDITATION_TEXT')
    return value


def _time(value):
    integer(value)
    return value


def _packet(value):
    need(len(canonical(value)) <= MAX_PACKET, 'ACCREDITATION_SIZE')


def _strings(values, maximum=16):
    need(type(values) is list and 0 < len(values) <= maximum, 'ACCREDITATION_SCOPE')
    for value in values:
        _text(value)
    need(values == sorted(set(values)), 'ACCREDITATION_SCOPE')


def age_text(seconds):
    """A short human age: 45s, 12m 5s, 3h 2m, 4d 1h."""
    integer(seconds)
    days, rest = divmod(seconds, 86400)
    hours, rest = divmod(rest, 3600)
    minutes, secs = divmod(rest, 60)
    if days:
        return f'{days}d {hours}h'
    if hours:
        return f'{hours}h {minutes}m'
    if minutes:
        return f'{minutes}m {secs}s'
    return f'{secs}s'


def status_label(issued_at, now):
    """The sentence every status answer carries, online or offline. The clock is the caller's."""
    from datetime import datetime, timezone
    integer(issued_at); integer(now)
    dated = (datetime.fromtimestamp(issued_at, timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
             if issued_at <= 253402300799 else f'unix time {issued_at}')
    if issued_at > now:
        return f'checked against the snapshot dated {dated} ({age_text(issued_at - now)} after the supplied clock)'
    return f'checked against the snapshot dated {dated} (age {age_text(now - issued_at)})'


def _credential(body):
    _exact(body, 'version issuer issuer_key key_version subject holder_key artifact profile qualification scope criteria evidence outcome issued_at not_before expires_at nonce')
    need(body['version'] == VERSION, 'ACCREDITATION_VERSION')
    for name in ('issuer', 'key_version', 'subject', 'profile', 'qualification'):
        _text(body[name])
    for name in ('issuer_key', 'holder_key', 'artifact', 'criteria', 'nonce'):
        key(body[name])
    _strings(body['scope'])
    need(type(body['evidence']) is list and len(body['evidence']) <= 32, 'ACCREDITATION_EVIDENCE')
    for value in body['evidence']:
        key(value)
    need(body['evidence'] == sorted(set(body['evidence'])), 'ACCREDITATION_EVIDENCE')
    need(type(body['outcome']) is str and body['outcome'] in ('PASS', 'FAIL', 'INCOMPLETE'), 'ACCREDITATION_OUTCOME')
    for name in ('issued_at', 'not_before', 'expires_at'):
        _time(body[name])
    need(body['issued_at'] <= body['not_before'] < body['expires_at'] and
         body['expires_at'] - body['issued_at'] <= MAX_LIFETIME, 'ACCREDITATION_VALIDITY')
    _packet(body)


def issue(issuer_private, *, issuer, key_version, subject, holder_key, artifact,
          profile, qualification, scope, criteria, evidence, issued_at,
          not_before, expires_at, nonce, outcome='PASS'):
    """Owner-side issuer signing. Caller, not this library, supplies assessment evidence."""
    body = dict(version=VERSION, issuer=issuer, issuer_key=public_key(issuer_private),
                key_version=key_version, subject=subject, holder_key=holder_key,
                artifact=artifact, profile=profile, qualification=qualification,
                scope=deepcopy(scope), criteria=criteria, evidence=deepcopy(evidence),
                outcome=outcome, issued_at=issued_at, not_before=not_before,
                expires_at=expires_at, nonce=nonce)
    _credential(body)
    return {'credential': body, 'signature': sign(issuer_private, ISSUE_LABEL, body)}


def credential_id(credential):
    _exact(credential, 'credential signature')
    _credential(credential['credential'])
    verify(credential['credential']['issuer_key'], ISSUE_LABEL, credential['credential'], credential['signature'])
    return digest(ISSUE_LABEL, credential['credential'])


def _status(body):
    _exact(body, 'version issuer issuer_key key_version sequence issued_at expires_at entries')
    need(body['version'] == STATUS_VERSION, 'ACCREDITATION_STATUS_VERSION')
    _text(body['issuer']); _text(body['key_version']); key(body['issuer_key'])
    integer(body['sequence'], True)
    _time(body['issued_at']); _time(body['expires_at'])
    need(body['issued_at'] < body['expires_at'] and
         body['expires_at'] - body['issued_at'] <= MAX_FRESHNESS, 'ACCREDITATION_STATUS_VALIDITY')
    need(type(body['entries']) is dict and len(body['entries']) <= MAX_STATUS_ENTRIES, 'ACCREDITATION_STATUS_ENTRIES')
    for reference, value in body['entries'].items():
        key(reference)
        need(type(value) is str and value in ('ACTIVE', 'SUSPENDED', 'REVOKED'), 'ACCREDITATION_STATUS_VALUE')
    _packet(body)


def status(issuer_private, *, issuer, key_version, sequence, issued_at, expires_at, entries):
    """Sign an explicit status map. Missing entries mean unknown, never active."""
    body = dict(version=STATUS_VERSION, issuer=issuer, issuer_key=public_key(issuer_private),
                key_version=key_version, sequence=sequence, issued_at=issued_at,
                expires_at=expires_at, entries=deepcopy(entries))
    _status(body)
    return {'status': body, 'signature': sign(issuer_private, STATUS_LABEL, body)}


def status_id(snapshot):
    _exact(snapshot, 'status signature'); _status(snapshot['status'])
    verify(snapshot['status']['issuer_key'], STATUS_LABEL, snapshot['status'], snapshot['signature'])
    return digest(STATUS_LABEL, snapshot['status'])


def policy(*, issuers, audience, qualification, scope, artifact, profile,
           maximum_status_age=300, maximum_presentation_age=300, criteria=None):
    """A relying party's explicit acceptance policy; issuer material is never fetched."""
    body = dict(version=POLICY_VERSION, issuers=deepcopy(issuers), audience=audience,
                qualification=qualification, scope=deepcopy(scope), artifact=artifact,
                profile=profile, maximum_status_age=maximum_status_age,
                maximum_presentation_age=maximum_presentation_age, criteria=criteria)
    _policy(body)
    return body


def _policy(body):
    need(type(body) is dict and body.get('version') in (POLICY_VERSION, LEGACY_POLICY_VERSION), 'ACCREDITATION_POLICY_VERSION')
    fields = 'version issuers audience qualification scope artifact profile maximum_status_age maximum_presentation_age'
    _exact(body, fields + (' criteria' if body['version'] == POLICY_VERSION else ''))
    if body.get('criteria') is not None: key(body['criteria'])
    for name in ('audience', 'qualification', 'profile'):
        _text(body[name])
    key(body['artifact']); _strings(body['scope'])
    need(type(body['issuers']) is dict and 0 < len(body['issuers']) <= MAX_ISSUERS, 'ACCREDITATION_ISSUERS')
    for issuer, versions in body['issuers'].items():
        _text(issuer)
        need(type(versions) is dict and 0 < len(versions) <= 16, 'ACCREDITATION_ISSUERS')
        for version, public in versions.items():
            _text(version); key(public)
    for name in ('maximum_status_age', 'maximum_presentation_age'):
        integer(body[name], True)
        need(body[name] <= MAX_FRESHNESS, 'ACCREDITATION_FRESHNESS')
    _packet(body)


def policy_id(accepted):
    _policy(accepted)
    return digest(POLICY_VERSION, accepted)


def _adopted(issuer, version, public, accepted):
    need(issuer in accepted['issuers'] and
         accepted['issuers'][issuer].get(version) == public, 'ACCREDITATION_ISSUER_NOT_ADOPTED')


def present(credential, holder_private, *, status, audience, nonce, now):
    """Holder-side proof over the entire credential and snapshot, verifier and challenge."""
    cid = credential_id(credential); sid = status_id(status)
    need(public_key(holder_private) == credential['credential']['holder_key'], 'ACCREDITATION_HOLDER')
    _text(audience); _text(nonce, 256); _time(now)
    body = dict(version=PRESENTATION_VERSION, credential=cid, status=sid,
                audience=audience, nonce=nonce, at=now)
    result = {'credential': deepcopy(credential), 'snapshot': deepcopy(status),
              'holder': body, 'signature': sign(holder_private, HOLDER_LABEL, body)}
    _packet(result)
    return result


def export_presentation(presentation):
    """Canonical plaintext public packet; never exports a private signing key.

    This checks packet integrity, not issuer adoption, freshness or replay. Use
    the encrypted carrier/storage facilities for confidential qualifications.
    """
    _packet(presentation); _exact(presentation, 'credential snapshot holder signature')
    cid = credential_id(presentation['credential']); sid = status_id(presentation['snapshot'])
    holder = presentation['holder']; _exact(holder, 'version credential status audience nonce at')
    need(holder['version'] == PRESENTATION_VERSION and holder['credential'] == cid and holder['status'] == sid,
         'ACCREDITATION_PRESENTATION_BINDING')
    _text(holder['audience']); _text(holder['nonce'], 256); _time(holder['at'])
    verify(presentation['credential']['credential']['holder_key'], HOLDER_LABEL, holder, presentation['signature'])
    return canonical(presentation)


def import_presentation(raw):
    """Bounded duplicate-key rejecting decode; acceptance policy remains separate."""
    need(type(raw) in (bytes, str) and 0 < len(raw) <= MAX_PACKET, 'ACCREDITATION_SIZE')
    value = loads(raw)
    export_presentation(value)
    return value


def _inspect(presentation, accepted, *, nonce, now, offline):
    _policy(accepted); _text(nonce, 256); _time(now)
    need(type(offline) is bool, 'ACCREDITATION_OFFLINE')
    _packet(presentation)
    _exact(presentation, 'credential snapshot holder signature')
    cid = credential_id(presentation['credential'])
    sid = status_id(presentation['snapshot'])
    cred = presentation['credential']['credential']; snapshot = presentation['snapshot']['status']
    _adopted(cred['issuer'], cred['key_version'], cred['issuer_key'], accepted)
    _adopted(snapshot['issuer'], snapshot['key_version'], snapshot['issuer_key'], accepted)
    need(cred['issuer'] == snapshot['issuer'], 'ACCREDITATION_STATUS_ISSUER')
    need(cred['not_before'] <= now < cred['expires_at'], 'ACCREDITATION_EXPIRED')
    need(snapshot['issued_at'] <= now < snapshot['expires_at'] and
         now - snapshot['issued_at'] <= accepted['maximum_status_age'], 'ACCREDITATION_STATUS_STALE')
    need(snapshot['issued_at'] >= cred['issued_at'], 'ACCREDITATION_STATUS_PREDATES_CREDENTIAL')
    holder = presentation['holder']
    _exact(holder, 'version credential status audience nonce at')
    _time(holder['at'])
    need(holder['version'] == PRESENTATION_VERSION and holder['credential'] == cid and holder['status'] == sid,
         'ACCREDITATION_PRESENTATION_BINDING')
    need(holder['audience'] == accepted['audience'] and holder['nonce'] == nonce,
         'ACCREDITATION_CHALLENGE')
    need(holder['at'] <= now and now - holder['at'] <= accepted['maximum_presentation_age'],
         'ACCREDITATION_PRESENTATION_STALE')
    verify(cred['holder_key'], HOLDER_LABEL, holder, presentation['signature'])
    need(cred['artifact'] == accepted['artifact'] and cred['profile'] == accepted['profile'] and
         cred['qualification'] == accepted['qualification'] and
         set(accepted['scope']).issubset(cred['scope']), 'ACCREDITATION_SCOPE_MISMATCH')
    need(accepted.get('criteria') is None or cred['criteria'] == accepted['criteria'], 'ACCREDITATION_CRITERIA_MISMATCH')
    result = dict(criteria=cred['criteria'], evidence=deepcopy(cred['evidence']),
                  criteria_checked=accepted.get('criteria') is not None,
                  accepted=False, credential=cid, subject=cred['subject'], holder_key=cred['holder_key'],
                  issuer=cred['issuer'], artifact=cred['artifact'], profile=cred['profile'],
                  qualification=cred['qualification'], scope=deepcopy(accepted['scope']),
                  outcome=cred['outcome'], status=snapshot['entries'].get(cid, 'UNKNOWN'),
                  status_snapshot=sid, status_sequence=snapshot['sequence'],
                  status_as_of=snapshot['issued_at'], status_expires_at=snapshot['expires_at'],
                  status_label=status_label(snapshot['issued_at'], now),
                  offline=offline, current_global_status='NOT_ESTABLISHED',
                  authority_verified=False, execution_authorized=False, identity_verified=False,
                  funds_verified=False, external_accreditation=False, replay_checked=False,
                  assurance='PINNED_ISSUER_CLAIM_AGAINST_ADOPTED_SNAPSHOT')
    return result, cred, snapshot, sid


def inspect_presentation(presentation, accepted, *, nonce, now, offline=False):
    """Read-only cryptographic assessment, without replay or rollback protection."""
    result, cred, _snapshot, _sid = _inspect(presentation, accepted, nonce=nonce, now=now, offline=offline)
    need(result['status'] == 'ACTIVE', 'ACCREDITATION_STATUS_' + result['status'])
    need(cred['outcome'] == 'PASS', 'ACCREDITATION_NOT_PASSED')
    result['accepted'] = True
    result['replay_or_rollback_protection'] = 'NOT_CHECKED_USE_OWNER_VERIFIER_STORE'
    return result


class VerifierStore:
    """One owner-custodied verifier, with exclusive durable state and known revocations."""
    def __init__(self, directory, *, audience, expected_checkpoint=None):
        _text(audience)
        self.audience = audience
        self._lock = threading.RLock()
        self._file = StateFile(directory, 'agent-accreditation', kind=STATE_VERSION,
                               context={'version': STATE_VERSION, 'audience': audience})
        self._closed = False
        try:
            self._state = self._file.load() or {'snapshots': {}, 'consumed': {}, 'last_now': 0}
            self._validate_state()
            if expected_checkpoint is not None:
                key(expected_checkpoint)
                need(self.checkpoint() == expected_checkpoint, 'ACCREDITATION_STORE_ROLLBACK')
        except BaseException:
            self._file.close()
            raise

    def _validate_state(self):
        value = self._state
        _exact(value, 'snapshots consumed last_now'); _time(value['last_now'])
        need(type(value['snapshots']) is dict and len(value['snapshots']) <= MAX_ISSUERS, 'ACCREDITATION_STORE')
        for issuer, entry in value['snapshots'].items():
            _text(issuer); _exact(entry, 'sequence id issued_at revoked')
            integer(entry['sequence'], True); key(entry['id']); _time(entry['issued_at'])
            need(type(entry['revoked']) is list and len(entry['revoked']) <= MAX_STATUS_ENTRIES,
                 'ACCREDITATION_STORE')
            for cid in entry['revoked']:
                key(cid)
            need(entry['revoked'] == sorted(set(entry['revoked'])), 'ACCREDITATION_STORE')
        need(type(value['consumed']) is dict and len(value['consumed']) <= MAX_CONSUMED, 'ACCREDITATION_STORE')
        for reference, at in value['consumed'].items():
            key(reference); _time(at)

    def checkpoint(self):
        with self._lock:
            return digest(STATE_VERSION, self._state)

    def _observe(self, snapshot, reference, now):
        need(not self._closed, 'ACCREDITATION_STORE_CLOSED')
        need(now >= self._state['last_now'], 'ACCREDITATION_CLOCK_ROLLBACK')
        issuer = snapshot['issuer']; old = self._state['snapshots'].get(issuer)
        if old:
            need(snapshot['sequence'] >= old['sequence'], 'ACCREDITATION_STATUS_ROLLBACK')
            need(snapshot['sequence'] != old['sequence'] or reference == old['id'], 'ACCREDITATION_STATUS_EQUIVOCATION')
            need(snapshot['issued_at'] >= old['issued_at'], 'ACCREDITATION_STATUS_TIME_ROLLBACK')
        else:
            need(len(self._state['snapshots']) < MAX_ISSUERS, 'ACCREDITATION_STORE_QUOTA')
        revoked = sorted(set((old or {}).get('revoked', [])) |
                         {cid for cid, value in snapshot['entries'].items() if value == 'REVOKED'})
        need(len(revoked) <= MAX_STATUS_ENTRIES, 'ACCREDITATION_STORE_QUOTA')
        self._state['snapshots'][issuer] = dict(sequence=snapshot['sequence'], id=reference,
                                              issued_at=snapshot['issued_at'], revoked=revoked)
        self._state['last_now'] = now
        self._file.save(self._state)
        return revoked

    def close(self):
        with self._lock:
            self._file.close()
            self._closed = True



def adopt_status(snapshot, accepted, *, now, store):
    """Retain an adopted issuer's fresh signed status independently of claim admission."""
    need(isinstance(store, VerifierStore), 'ACCREDITATION_VERIFIER_STORE_REQUIRED')
    _policy(accepted); _time(now)
    sid = status_id(snapshot); body = snapshot['status']
    _adopted(body['issuer'], body['key_version'], body['issuer_key'], accepted)
    need(store.audience == accepted['audience'], 'ACCREDITATION_STORE_AUDIENCE')
    need(body['issued_at'] <= now < body['expires_at'] and
         now - body['issued_at'] <= accepted['maximum_status_age'], 'ACCREDITATION_STATUS_STALE')
    with store._lock:
        revoked = store._observe(body, sid, now)
    return {'status_snapshot': sid, 'known_revocations': len(revoked),
            'verifier_checkpoint': store.checkpoint(), 'current_global_status': 'NOT_ESTABLISHED'}


def verify_presentation(presentation, accepted, *, nonce, now, store, offline=False):
    """Assess and durably consume a fresh challenge; accepted claims do not grant authority."""
    need(isinstance(store, VerifierStore), 'ACCREDITATION_VERIFIER_STORE_REQUIRED')
    # Issuer status is an independently signed fact. Retain it even if a
    # carrier's qualification, holder proof or requested scope later refuses.
    need(type(presentation) is dict and 'snapshot' in presentation, 'ACCREDITATION_FIELDS')
    adopt_status(presentation['snapshot'], accepted, now=now, store=store)
    result, cred, snapshot, sid = _inspect(presentation, accepted, nonce=nonce, now=now, offline=offline)
    need(store.audience == accepted['audience'], 'ACCREDITATION_STORE_AUDIENCE')
    with store._lock:
        # Persist newer known status even if the requested claim is suspended,
        # revoked or absent. Otherwise presenting a later refusal then an older
        # active snapshot could hide a revocation the verifier already saw.
        revoked = store._observe(snapshot, sid, now)
        need(result['credential'] not in revoked, 'ACCREDITATION_STATUS_REVOKED')
        need(result['status'] == 'ACTIVE', 'ACCREDITATION_STATUS_' + result['status'])
        need(cred['outcome'] == 'PASS', 'ACCREDITATION_NOT_PASSED')
        challenge = digest(HOLDER_LABEL, {'audience': accepted['audience'], 'nonce': nonce})
        need(challenge not in store._state['consumed'], 'ACCREDITATION_PRESENTATION_REPLAY')
        need(len(store._state['consumed']) < MAX_CONSUMED, 'ACCREDITATION_STORE_QUOTA')
        store._state['consumed'][challenge] = now
        store._file.save(store._state)
    result['accepted'] = True; result['replay_checked'] = True
    result['verifier_checkpoint'] = store.checkpoint()
    result['replay_or_rollback_protection'] = 'DURABLE_LOCAL_STATE_RETAIN_EXTERNAL_CHECKPOINT_FOR_FULL_RESTORE_DETECTION'
    return result


def profile():
    return {'version': VERSION, 'status': STATUS_VERSION, 'policy': POLICY_VERSION,
            'presentation': PRESENTATION_VERSION, 'state': STATE_VERSION,
            'format': 'EXACT_ASCII_JSON_ED25519_DOMAIN_SEPARATED',
            'standard_interoperability': 'NOT_A_W3C_VC_OR_BITSTRING_STATUS_LIST_IMPLEMENTATION',
            'claim_disclosure': 'ALL_PACKET_FIELDS_VISIBLE_TO_RECIPIENT_USE_ENCRYPTED_CARRIER_FOR_PRIVACY',
            'trust': 'OWNER_ADOPTED_ISSUER_KEYS_SCOPE_AND_FRESHNESS',
            'current_global_status': 'NOT_ESTABLISHED',
            'execution_authorized': False, 'external_accreditation': False,
            'maximum_packet_bytes': MAX_PACKET,
            'extensions': {
                'status_label': 'every result states: checked against the snapshot dated <UTC time> (age <age>)',
                'standard_status_lists': 'covenant_chain.status_lists and accreditation_status: IETF Token Status List '
                                         '(draft-ietf-oauth-status-list-21) and W3C Bitstring Status List v1.0 encodings '
                                         'of the same issuer snapshots, judged under this policy',
                'selective_disclosure': 'covenant_chain.accreditation_disclosure: covenant-agent-accreditation-sd/0.1, '
                                        'the same claims as an SD-JWT VC with key binding',
                'key_rotation': 'covenant_chain.accreditation_trust: adopt precommitted successor keys and explicit '
                                'trust lists into this policy',
                'market_types': 'covenant_chain.market_accreditation: lender, broker, insurance producer, accredited '
                                'investor, KYB, AML, conformance, security and domain-competence types as data',
                'assessor_register': 'covenant_chain.accreditation_register: assessments, reasons, suspension, '
                                     'revocation, appeals and signed snapshots in every carrier',
                'eligibility': 'covenant_chain.eligibility: identity, qualifications, spending authority, financial '
                               'backing and reputation reported separately; never one score',
                'guide': 'docs/AGENT_ACCREDITATION.html'},
            'does_not_prove': ['issuer honesty or competence', 'legal or external accreditation',
                              'current unseen revocations', 'identity or spending authority',
                              'financial backing', 'global replay uniqueness across disconnected verifiers']}


describe = profile


def main(argv=None):
    """Read public packets or operate an explicitly selected owner verifier store."""
    import argparse
    import json
    import os
    import re
    import stat
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    sub.add_parser('profile')
    for action in ('inspect', 'verify'):
        command = sub.add_parser(action)
        command.add_argument('--presentation', type=Path, required=True)
        command.add_argument('--policy', type=Path, required=True)
        command.add_argument('--nonce', required=True)
        command.add_argument('--now', type=int, required=True,
                             help='Owner-adopted Unix time; caller must provide a trustworthy clock')
        command.add_argument('--offline', action='store_true')
        if action == 'verify':
            command.add_argument('--store', type=Path, required=True)
            command.add_argument('--checkpoint')
    args = parser.parse_args(argv)
    try:
        if args.action == 'profile':
            result = profile()
        else:
            def read(path):
                handle = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                try:
                    info = os.fstat(handle)
                    need(stat.S_ISREG(info.st_mode) and info.st_size <= MAX_PACKET, 'ACCREDITATION_INPUT_FILE')
                    with os.fdopen(handle, 'rb', closefd=False) as stream:
                        raw = stream.read(MAX_PACKET + 1)
                finally:
                    os.close(handle)
                need(len(raw) <= MAX_PACKET, 'ACCREDITATION_SIZE')
                return raw
            packet = import_presentation(read(args.presentation))
            accepted = loads(read(args.policy)); _policy(accepted)
            if args.action == 'inspect':
                result = inspect_presentation(packet, accepted, nonce=args.nonce,
                                              now=args.now, offline=args.offline)
            else:
                store = VerifierStore(args.store, audience=accepted['audience'],
                                       expected_checkpoint=args.checkpoint)
                try:
                    result = verify_presentation(packet, accepted, nonce=args.nonce,
                                                 now=args.now, offline=args.offline, store=store)
                finally:
                    store.close()
        print(json.dumps(result, sort_keys=True, indent=2))
        return 0
    except (ValueError, TypeError, KeyError, OSError) as error:
        # Files can be untrusted. Do not echo their contents or exception text.
        code = str(error)
        code = code if re.fullmatch(r'[A-Z][A-Z0-9_]{1,80}', code) else 'ACCREDITATION_REFUSED'
        from covenant_agent.errors import refusal
        print(json.dumps({'accepted': False, 'error': code, **refusal(code, REMEDIATION.get(code)),
                          'execution_authorized': False}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
