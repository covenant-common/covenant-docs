"""Keyless agent tool for postage, signed discovery, introductions and anchored reputation.

Preparation and verification only. Signing helpers are absent; trusted contacts,
adopted logs, holders and resolvers come from the caller's own host, never from
a counterparty's record. Nothing is fetched, paid, published or executed.
"""
from .cooperation_interface import HASH, INT, OBJECT
from .crypto import need
from . import anchored_reputation as reputation
from . import introductions as intro
from . import postage
from . import signed_discovery as discovery

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 80}
LONG_TEXT = {'type': 'string', 'minLength': 0, 'maxLength': 240}
UNIT = {'type': 'string', 'minLength': 1, 'maxLength': 32}
SIGNATURE = {'type': 'string', 'pattern': '^[0-9a-f]{128}$', 'minLength': 128, 'maxLength': 128}
ENVELOPE = {'type': 'object', 'maxProperties': 2, 'required': ['body', 'signature'], 'additionalProperties': False,
            'properties': {'body': {'type': 'object', 'maxProperties': 32}, 'signature': SIGNATURE}}
RECORD = {'type': 'object', 'maxProperties': 2}
RECORDS = {'type': 'array', 'maxItems': 1024, 'items': RECORD}
ENVELOPES = {'type': 'array', 'maxItems': 1024, 'items': ENVELOPE}
KEYS = {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': HASH}
HASHES = {'type': 'array', 'minItems': 1, 'maxItems': 256, 'items': HASH}
TEXTS = {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': TEXT}
CONTACTS = {'type': 'object', 'minProperties': 1, 'maxProperties': 64,
            'propertyNames': {'type': 'string', 'pattern': '^[0-9a-f]{64}$'},
            'additionalProperties': {'type': 'integer', 'minimum': 1, 'maximum': 10000}}
TIERS = {'type': 'object', 'maxProperties': 4, 'additionalProperties': False,
         'required': list(postage.TIERS), 'properties': {name: INT for name in postage.TIERS}}
NULLABLE_HASH = {'type': ['string', 'null'], 'pattern': '^[0-9a-f]{64}$'}
ENDPOINTS = {'type': 'array', 'maxItems': 8, 'items': {
    'type': 'object', 'maxProperties': 2, 'required': ['transport', 'uri'], 'additionalProperties': False,
    'properties': {'transport': {'enum': list(discovery.TRANSPORTS)}, 'uri': {'type': 'string', 'minLength': 1, 'maxLength': 256}}}}
SOURCES = {'type': 'array', 'maxItems': 256, 'items': {'type': 'object', 'maxProperties': 6,
           'required': ['source'], 'properties': {'source': {'enum': list(discovery.SOURCES)}}}}
LOGS = {'type': 'array', 'maxItems': 16, 'items': {'type': 'object', 'maxProperties': 3}}
ITEMS = {'type': 'array', 'maxItems': 256, 'items': {'type': 'object', 'maxProperties': 4}}
MARKS = {'type': 'array', 'maxItems': 1024, 'items': {'type': 'object', 'maxProperties': 2}}
LINKS = {'type': 'array', 'maxItems': 1024, 'items': {'type': 'array', 'minItems': 2, 'maxItems': 2, 'items': HASH}}
RULES = {'type': 'object', 'maxProperties': len(reputation.DEFAULT_POLICY), 'additionalProperties': False,
         'properties': {name: INT for name in reputation.DEFAULT_POLICY}}
RESOLVERS = {'type': 'object', 'maxProperties': 256, 'propertyNames': {'type': 'string', 'pattern': '^[0-9a-f]{64}$'},
             'additionalProperties': HASH}
DEPTH = {'type': 'integer', 'minimum': 0, 'maximum': intro.MAX_DEPTH}
BPS = {'type': 'integer', 'minimum': 1, 'maximum': 10000}
EVIDENCE = {'trusted_contacts': CONTACTS, 'introductions': ENVELOPES, 'receipts': RECORDS, 'withdrawals': ENVELOPES,
            'released': MARKS, 'kept': MARKS, 'adopted_resolvers': RESOLVERS, 'max_depth': DEPTH, 'decay_bps': BPS}


def spec():
    return ('covenant_network_trust',
        'Experimental compounding trust without a chain. Prepare and check refundable postage for unsolicited '
        'proposals, gather descriptors signed by the agent\'s own key from untrusted carriers (well-known paths, '
        'DNS TXT, Nostr events, transparency logs, introductions), walk signed introductions a few hops from your '
        'trusted contacts, and rank providers by anchored, independent evidence. Contacts, logs, holders and '
        'resolvers are your own host\'s choices. No signing, fetching, payment, publication or execution.', True, [
        ('describe', {}, ()),
        ('postage_policy', {'recipient': HASH, 'sequence': INT, 'issued_at': INT, 'expires': INT, 'unit': UNIT,
                            'holders': KEYS, 'contexts': TEXTS, 'tiers': TIERS, 'max_amount': INT,
                            'decision_window': INT, 'kept_step_bps': INT, 'beneficiary': NULLABLE_HASH,
                            'shared_evidence': {'type': 'boolean'}},
         ('recipient', 'sequence', 'issued_at', 'expires', 'unit', 'holders', 'contexts', 'tiers', 'max_amount',
          'decision_window')),
        ('postage_reference', {'kind': {'enum': list(postage.PROPOSAL_KINDS)},
                               'value': {'type': ['object', 'string'], 'maxLength': 349528, 'maxProperties': 16}},
         ('kind', 'value')),
        ('postage_stamp', {'sender': HASH, 'policy': ENVELOPE, 'proposal': HASH, 'context': TEXT, 'amount': INT,
                           'holder': HASH, 'issued_at': INT, 'nonce': HASH},
         ('sender', 'policy', 'proposal', 'context', 'amount', 'holder', 'issued_at', 'nonce')),
        ('postage_decision', {'recipient': HASH, 'stamp': HASH, 'decision': {'enum': list(postage.DECISIONS)},
                              'decided_at': INT}, ('recipient', 'stamp', 'decision', 'decided_at')),
        ('postage_quote', {'policy': ENVELOPE, 'tier': {'enum': list(postage.TIERS)}, 'kept': INT}, ('policy', 'tier')),
        ('postage_screen', {'policy': ENVELOPE, 'items': ITEMS, 'now': INT, **EVIDENCE},
         ('policy', 'items', 'now', 'trusted_contacts')),
        ('descriptor', {'key': HASH, 'sequence': INT, 'previous': NULLABLE_HASH, 'issued_at': INT, 'expires': INT,
                        'name': TEXT, 'summary': LONG_TEXT, 'task_classes': TEXTS, 'endpoints': ENDPOINTS,
                        'operator': NULLABLE_HASH, 'postage_policy': NULLABLE_HASH},
         ('key', 'sequence', 'previous', 'issued_at', 'expires', 'name', 'summary', 'task_classes', 'endpoints')),
        ('discover', {'sources': SOURCES, 'now': INT, 'adopted_logs': LOGS}, ('sources', 'now')),
        ('discover_search', {'goal': {'type': 'string', 'maxLength': 256}, 'sources': SOURCES, 'now': INT,
                             'adopted_logs': LOGS, 'task_class': TEXT, 'order': {'enum': ['RELEVANCE', 'ANCHORED']}},
         ('goal', 'sources', 'now')),
        ('introduction', {'introducer': HASH, 'subject': HASH, 'task_class': TEXT,
                          'amount': {'type': 'integer', 'minimum': 1, 'maximum': intro.MAX_AMOUNT}, 'depth': DEPTH,
                          'basis': {**HASHES, 'maxItems': 32}, 'issued_at': INT, 'expires': INT, 'nonce': HASH},
         ('introducer', 'subject', 'task_class', 'amount', 'depth', 'basis', 'issued_at', 'expires', 'nonce')),
        ('withdrawal', {'introducer': HASH, 'introductions': HASHES, 'withdrawn_at': INT, 'nonce': HASH},
         ('introducer', 'introductions', 'withdrawn_at', 'nonce')),
        ('reach', {'trusted_contacts': CONTACTS, 'introductions': ENVELOPES, 'receipts': RECORDS, 'now': INT,
                   'task_class': TEXT, 'withdrawals': ENVELOPES, 'adopted_resolvers': RESOLVERS, 'max_depth': DEPTH,
                   'decay_bps': BPS}, ('trusted_contacts', 'introductions', 'receipts', 'now')),
        ('report', {'reporter': HASH, 'subject': HASH, 'agreement': HASH, 'task_class': TEXT,
                    'outcome': {'enum': ['FULFILLED', 'FAILED']}, 'evidence': {'type': 'array', 'maxItems': 32, 'items': HASH},
                    'issued_at': INT, 'nonce': HASH},
         ('reporter', 'subject', 'agreement', 'task_class', 'outcome', 'evidence', 'issued_at', 'nonce')),
        ('stake', {'holder': HASH, 'agreement': HASH, 'party': HASH, 'amount': INT, 'unit': UNIT, 'held_at': INT,
                   'nonce': HASH}, ('holder', 'agreement', 'party', 'amount', 'unit', 'held_at', 'nonce')),
        ('rank', {'trusted_contacts': CONTACTS, 'task_class': TEXT, 'now': INT, 'receipts': RECORDS,
                  'reports': ENVELOPES, 'introductions': ENVELOPES, 'withdrawals': ENVELOPES, 'stakes': ENVELOPES,
                  'spam': MARKS, 'adopted_resolvers': RESOLVERS,
                  'adopted_holders': {'type': 'array', 'maxItems': 64, 'items': HASH}, 'links': LINKS,
                  'candidates': {'type': 'array', 'maxItems': 256, 'items': HASH}, 'rules': RULES, 'principal': HASH},
         ('trusted_contacts', 'task_class', 'now')),
    ])


def describe():
    """Compact orientation; each profile's full describe() stays in its module."""
    return {'tool': 'covenant_network_trust', 'status': 'EXPERIMENTAL_APPLICATION_PROFILES',
            'profiles': [postage.VERSION, discovery.VERSION, intro.VERSION, reputation.VERSION],
            'postage': {'tiers': list(postage.TIERS), 'silence': 'REFUND', 'ranking': 'ADMITS_NEVER_RANKS'},
            'discovery': {'sources': list(discovery.SOURCES), 'only_signatures_count': True,
                          'conflicts': 'SURFACED_NOT_MERGED'},
            'introductions': {'depth_limit': intro.MAX_DEPTH, 'trust_amount': 'OPENPGP_120_COMPLETE_60_PARTIAL',
                              'accountability': 'INTRODUCER_WEIGHT_FALLS_WHEN_SUBJECTS_FAIL'},
            'reputation': {'standings': list(reputation.STANDINGS), 'policy_keys': sorted(reputation.DEFAULT_POLICY),
                           'independence': 'ONE_CREDIT_PER_TRUSTED_CONTACT_ROOT', 'global_score': False},
            'workflow': ['publish a signed descriptor and postage policy', 'gather descriptors with discover',
                         'screen unsolicited proposals with postage_screen', 'introduce agents you did good work with',
                         'rank providers for a task class from your own trusted contacts'],
            'guide': 'docs/NETWORK_EFFECTS.html', 'signing_in_tool': False, 'network_accessed': False,
            'execution_authorized': False}


def _quote(policy, tier, kept=0):
    opened = postage.open_record(policy, 'POLICY')
    return {'policy': opened['id'], 'tier': tier, 'kept': kept, 'required': postage.required(opened['body'], tier, kept),
            'unit': opened['body']['unit'], 'basis': 'PUBLISHED_POLICY_ARITHMETIC_RECIPIENT_DECIDES_THE_TIER',
            'execution_authorized': False}


def _discover_search(goal, sources, now, adopted_logs=None, task_class=None, order='RELEVANCE'):
    gathered = discovery.gather(sources, now, adopted_logs)
    return discovery.search(goal, gathered, task_class=task_class, order=order)


def _reach(trusted_contacts, introductions, receipts, now, task_class=None, withdrawals=(), adopted_resolvers=None,
           max_depth=intro.DEFAULT_DEPTH, decay_bps=intro.DEFAULT_DECAY_BPS):
    return intro.reach(trusted_contacts, introductions, receipts, task_class, now, withdrawals=withdrawals,
                       adopted_resolvers=adopted_resolvers, max_depth=max_depth, decay_bps=decay_bps)


def _flagged(result):
    if type(result) is dict:
        result.setdefault('execution_authorized', False)
    return result


ACTIONS = {
    'describe': lambda p: describe(),
    'postage_policy': lambda p: postage.policy(**p),
    'postage_reference': lambda p: _flagged(postage.proposal_reference(p['kind'], p['value'])),
    'postage_stamp': lambda p: postage.stamp(p['sender'], p['policy'], p['proposal'], p['context'], p['amount'],
                                             p['holder'], p['issued_at'], p['nonce']),
    'postage_decision': lambda p: postage.decision(p['recipient'], p['stamp'], p['decision'], p['decided_at']),
    'postage_quote': lambda p: _quote(**p),
    'postage_screen': lambda p: postage.screen(p.pop('policy'), p.pop('items'), p.pop('now'), **p),
    'descriptor': lambda p: discovery.descriptor(p.pop('key'), **p),
    'discover': lambda p: discovery.gather(p['sources'], p['now'], p.get('adopted_logs')),
    'discover_search': lambda p: _discover_search(**p),
    'introduction': lambda p: intro.introduction(**p),
    'withdrawal': lambda p: intro.withdrawal(**p),
    'reach': lambda p: _reach(**p),
    'report': lambda p: reputation.report(**p),
    'stake': lambda p: reputation.stake(**p),
    'rank': lambda p: reputation.rank(p.pop('trusted_contacts'), p.pop('task_class'), p.pop('now'), **p),
}


def call(action, parameters):
    need(type(action) is str and action in ACTIONS and type(parameters) is dict, 'NETWORK_TRUST_TOOL_ACTION')
    return ACTIONS[action](dict(parameters))
