"""The exchange book and venues for urn:aap:exchange:0.1: the brokerage in its new form.

One ExchangeBook is a private, append-only journal (WorkflowStore: SQLite WAL,
synchronous FULL, hash-chained events). A requester can run its own book peer
to peer, or an operator can run one as a venue under signed venue rules: which
verticals, modes and eligibility it accepts, limits on the award rule, and one
declared per-close fee (match_surface.protocol_fee or a licence_royalty rate).
A venue relays sealed offers as commitments only and refuses every reveal and
comparison before the window closes, so it cannot open them early. Several
venues can carry one request; offers bind to the request digest, not the venue.

Close records count signed receipts per offeror: offered, awarded, closed on the
offered terms, closed on worse terms (retrade), withdrawn and failed condition,
with the Wilson lower bound from match_surface. They are a reader's computation
over supplied records, not a global score or authority. Owner SDK calls write;
the MCP tool never writes a book. Nothing here signs, pays or moves funds.
"""
from contextlib import contextmanager
from copy import deepcopy
import json
import os
from pathlib import Path
import sqlite3
import threading

from . import exchange_close as close
from . import exchange_profile as profile
from . import exchange_retrade as retrade
from .crypto import digest, verify
from .exchange_profile import ExchangeError, need, teaching
from .match_surface import protocol_fee, wilson_lb_bps
from .workflow_store import WorkflowStore

BOOK_VERSION = 'urn:aap:exchange-book:0.1'
RECORD_VERSION = 'urn:aap:exchange-close-record:0.1'
ROLES = ('REQUESTER', 'OPERATOR')
FEE_MODELS = ('NONE', 'PROTOCOL_FEE', 'LICENCE_RATE')
MAX_RECORDS = 4096
FLAGS = dict(profile.FLAGS)


# --- venues ------------------------------------------------------------------------

@teaching
def venue(*, operator, name, verticals, modes, require, max_window, required_metrics, max_metrics, fee, created_at, nonce):
    """Venue rules an operator signs. There is no placement field: ranking stays the requester's rule."""
    body = {'version': profile.PROFILE, 'kind': 'VENUE', 'operator': operator, 'name': name, 'verticals': sorted(verticals),
            'modes': sorted(modes), 'require': sorted(require), 'max_window': max_window,
            'required_metrics': sorted(required_metrics), 'max_metrics': max_metrics, 'fee': deepcopy(fee),
            'paid_placement': False, 'created_at': created_at, 'nonce': nonce}
    _venue_body(body)
    return {'label': profile.LABELS['VENUE'], 'body': body, 'id': profile.record_id('VENUE', body),
            'required_signer': operator, **FLAGS}


def _venue_body(body):
    profile._exact(body, 'version kind operator name verticals modes require max_window required_metrics max_metrics fee '
                         'paid_placement created_at nonce', 'EXCHANGE_VENUE')
    need(body['version'] == profile.PROFILE and body['kind'] == 'VENUE' and body['paid_placement'] is False, 'EXCHANGE_VENUE')
    profile._key(body['operator'])
    profile._text(body['name'], 'EXCHANGE_VENUE', 128)
    for field, allowed in (('verticals', None), ('modes', profile.MODES), ('require', ('principal_kyb', 'verified_agent')),
                           ('required_metrics', None)):
        rows = body[field]
        need(type(rows) is list and len(rows) <= 16 and rows == sorted(set(rows)) and all(type(r) is str for r in rows),
             'EXCHANGE_VENUE')
        need(allowed is None or set(rows) <= set(allowed), 'EXCHANGE_VENUE')
    need(bool(body['verticals']) and bool(body['modes']), 'EXCHANGE_VENUE')
    profile._int(body['max_window'], 'EXCHANGE_VENUE', 60, 366 * 86400)
    profile._int(body['max_metrics'], 'EXCHANGE_VENUE', 1, 8)
    fee = body['fee']
    profile._exact(fee, 'model rate payer', 'EXCHANGE_VENUE')
    need(fee['model'] in FEE_MODELS and fee['payer'] in profile.PAYERS, 'EXCHANGE_VENUE')
    need((fee['model'] == 'NONE') == (fee['payer'] == 'NONE'), 'EXCHANGE_VENUE')
    need((fee['rate'] is not None) == (fee['model'] == 'LICENCE_RATE'), 'EXCHANGE_VENUE')
    if fee['model'] == 'LICENCE_RATE':
        from .licence_royalty import _check_rate
        try:
            _check_rate(fee['rate'])
        except ValueError:
            raise ExchangeError('EXCHANGE_VENUE') from None
    profile._int(body['created_at'])
    profile._hash(body['nonce'])


@teaching
def verify_venue(envelope):
    profile._exact(envelope, 'body signature', 'EXCHANGE_VENUE')
    body = envelope['body']
    need(type(body) is dict, 'EXCHANGE_VENUE')
    _venue_body(body)
    try:
        verify(body['operator'], profile.LABELS['VENUE'], body, envelope['signature'])
    except ValueError:
        raise ExchangeError('EXCHANGE_VENUE_SIGNATURE') from None
    return body, profile.record_id('VENUE', body)


@teaching
def check_venue(request_body, venue_body, venue_ref):
    """The request must meet the venue's published rules; reasons are returned for the refusal."""
    reasons = []
    if venue_ref not in request_body['venues']:
        reasons.append('VENUE_NOT_NAMED')
    if request_body['vertical']['id'] not in venue_body['verticals']:
        reasons.append('VERTICAL')
    if request_body['mode'] not in venue_body['modes']:
        reasons.append('MODE')
    if not set(venue_body['require']) <= set(request_body['eligibility']['require']):
        reasons.append('ELIGIBILITY')
    window = request_body['window']
    if window['closes'] - window['opens'] > venue_body['max_window']:
        reasons.append('WINDOW')
    scored = {row['metric'] for row in request_body['award_rule']['score']}
    if not set(venue_body['required_metrics']) <= scored or len(scored) > venue_body['max_metrics']:
        reasons.append('AWARD_RULE')
    if request_body['fees']['operator']['payer'] != venue_body['fee']['payer']:
        reasons.append('FEE_PAYER')
    return reasons


@teaching
def venue_fee(venue_body, amount):
    """The one declared per-close fee. It is disclosed on every row and never enters the ranking."""
    profile._int(amount)
    fee = venue_body['fee']
    if fee['model'] == 'NONE':
        value, basis = 0, 'no venue fee'
    elif fee['model'] == 'PROTOCOL_FEE':
        value, basis = protocol_fee(amount), 'match_surface.protocol_fee (network-match/0.15, 30 bps)'
    else:
        from .licence_royalty import royalty_amount
        value, basis = royalty_amount(fee['rate'], amount, 1), 'licence_royalty rate over the closed amount'
    return {'amount': value, 'payer': fee['payer'], 'basis': basis, 'ranking_input': False}


@teaching
def relay_receipt(venue_ref, seal_body, seal_ref, received_at):
    """What the operator signs when it relays a seal: proof of timely submission, without the offer."""
    body = {'version': profile.PROFILE, 'kind': 'RELAY', 'venue': venue_ref, 'request': seal_body['request'],
            'seal': seal_ref, 'offeror': seal_body['offeror'], 'commitment': seal_body['commitment'], 'received_at': received_at}
    _relay_body(body)
    return {'label': profile.LABELS['RELAY'], 'body': body, 'id': profile.record_id('RELAY', body), **FLAGS}


def _relay_body(body):
    profile._exact(body, 'version kind venue request seal offeror commitment received_at', 'EXCHANGE_VENUE')
    for name in ('venue', 'request', 'seal', 'commitment'):
        profile._hash(body[name], 'EXCHANGE_VENUE')
    profile._key(body['offeror'])
    profile._int(body['received_at'])


@teaching
def verify_relay(envelope, venue_envelope):
    venue_body, venue_ref = verify_venue(venue_envelope)
    profile._exact(envelope, 'body signature', 'EXCHANGE_VENUE')
    body = envelope['body']
    need(type(body) is dict and body.get('version') == profile.PROFILE and body.get('kind') == 'RELAY', 'EXCHANGE_VENUE')
    _relay_body(body)
    need(body['venue'] == venue_ref, 'EXCHANGE_VENUE')
    try:
        verify(venue_body['operator'], profile.LABELS['RELAY'], body, envelope['signature'])
    except ValueError:
        raise ExchangeError('EXCHANGE_VENUE_SIGNATURE') from None
    return body


# --- close records ---------------------------------------------------------------------

def _counts():
    return {'offered': 0, 'awarded': 0, 'closed_on_offered_terms': 0, 'closed_improved': 0, 'closed_retraded': 0,
            'withdrawn': 0, 'failed_condition': 0, 'failed_condition_acknowledged': 0, 'lapsed': 0}


@teaching
def close_record(*, offers=(), withdrawals=(), awards=(), closes=(), statements=(), packs=()):
    """Per-offeror counts from signed receipts and their Wilson lower bounds (match_surface.wilson_lb_bps).

    offers: {request, offer} envelopes; withdrawals: {request, withdrawal}; awards: {award, record};
    closes: {award, receipt}; statements: unsigned book statements, listed but never counted.
    """
    total = sum(len(rows) for rows in (offers, withdrawals, awards, closes, statements))
    need(total <= MAX_RECORDS, 'EXCHANGE_RECORDS')
    seen, per = set(), {}

    def count(offeror, field):
        per.setdefault(offeror, _counts())[field] += 1

    for row in offers:
        profile._exact(row, 'request offer', 'EXCHANGE_RECORDS')
        checked = profile.verify_request(row['request'], packs=packs)
        body, ref = profile.verify_offer(row['offer'], checked['body'], checked['id'], packs)
        if ('OFFER', ref) not in seen:
            seen.add(('OFFER', ref))
            count(body['offeror'], 'offered')
    for row in withdrawals:
        profile._exact(row, 'request withdrawal', 'EXCHANGE_RECORDS')
        checked = profile.verify_request(row['request'], packs=packs)
        body, ref = profile.verify_withdrawal(row['withdrawal'], checked['id'])
        if ('WITHDRAW', body['offeror'], body['target']) not in seen:
            seen.add(('WITHDRAW', body['offeror'], body['target']))
            count(body['offeror'], 'withdrawn')
    for row in awards:
        profile._exact(row, 'award record', 'EXCHANGE_RECORDS')
        body, ref = close.verify_award_record(row['record'], row['award'])
        if ('AWARD', body['offer']) not in seen:
            seen.add(('AWARD', body['offer']))
            count(body['offeror'], 'awarded')
    for row in closes:
        profile._exact(row, 'award receipt', 'EXCHANGE_RECORDS')
        checked = close.verify_close(row['receipt'], row['award'])
        body = checked['body']
        if ('CLOSE', body['offer']) in seen:
            continue
        seen.add(('CLOSE', body['offer']))
        outcome = body['outcome']
        if outcome == 'CLOSED_ON_OFFERED_TERMS':
            count(body['offeror'], 'closed_on_offered_terms')
        elif outcome == 'CLOSED_IMPROVED':
            count(body['offeror'], 'closed_improved')
        elif outcome == 'CLOSED_RETRADED':
            count(body['offeror'], 'closed_retraded')
        elif outcome == 'FAILED_CONDITION' and body['failed_party'] == 'OFFEROR':
            count(body['offeror'], 'failed_condition')
            if checked['acknowledged']:
                count(body['offeror'], 'failed_condition_acknowledged')
        elif outcome == 'LAPSED' and checked['acknowledged']:
            count(body['offeror'], 'lapsed')
    listed = []
    for row in statements:
        profile._exact(row, 'kind offeror request at', 'EXCHANGE_RECORDS')
        need(row['kind'] in ('NOT_REVEALED', 'REFUSED_REVEAL'), 'EXCHANGE_RECORDS')
        profile._key(row['offeror'])
        profile._hash(row['request'], 'EXCHANGE_RECORDS')
        profile._int(row['at'], 'EXCHANGE_RECORDS')
        listed.append(deepcopy(row))
        per.setdefault(row['offeror'], _counts())
    records = []
    for offeror, counts in sorted(per.items()):
        kept = counts['closed_on_offered_terms'] + counts['closed_improved']
        firm = max(counts['offered'] - counts['withdrawn'], 0)
        records.append({'offeror': offeror, **counts,
                        'close_on_terms_lb_bps': wilson_lb_bps(kept, counts['awarded']) if counts['awarded'] else 0,
                        'firm_offer_lb_bps': wilson_lb_bps(firm, counts['offered']) if counts['offered'] else 0,
                        'not_revealed_statements': sum(1 for row in listed if row['offeror'] == offeror and row['kind'] == 'NOT_REVEALED'),
                        'refused_reveal_statements': sum(1 for row in listed if row['offeror'] == offeror and row['kind'] == 'REFUSED_REVEAL')})
    return {'version': RECORD_VERSION, 'records': records,
            'method': 'counts of signed receipts; Wilson lower bound z=1.96 in basis points (match_surface.wilson_lb_bps)',
            'close_on_terms': 'closed on offered or better terms / awarded', 'firm_offer': 'offers not withdrawn / offered',
            'unilateral_claims': 'a failed condition counts against the offeror only when it was the supplier; '
                                 'acknowledged counts carry both signatures; unsigned book statements are listed, not counted',
            'scope': 'READER_COMPUTATION_OVER_SUPPLIED_RECEIPTS_NOT_A_GLOBAL_SCORE', **FLAGS}


# --- the durable book ---------------------------------------------------------------

def _counted(method):
    def wrapped(self, *args, **kwargs):
        try:
            with self._lock:
                return method(self, *args, **kwargs)
        except ExchangeError as exc:
            self._refused(method.__name__, exc.code)
            raise
        except sqlite3.Error:
            self._refused(method.__name__, 'EXCHANGE_STORAGE')
            raise ExchangeError('EXCHANGE_STORAGE') from None
        except ValueError as exc:
            converted = profile.refusal(exc)
            self._refused(method.__name__, converted.code)
            raise converted from None
        except (TypeError, KeyError, AttributeError, IndexError):
            self._refused(method.__name__, 'EXCHANGE_FIELDS')
            raise ExchangeError('EXCHANGE_FIELDS') from None
    wrapped.__name__ = method.__name__
    wrapped.__doc__ = method.__doc__
    return wrapped


def qualified_eligibility(store_for):
    """The demand exchange's default eligibility hook with qualifications and durable verifier state.

    ``store_for(audience)`` returns the owner's agent_accreditation.VerifierStore for one audience.
    - An agent_accreditation acceptance policy is checked with verify_presentation against that store.
    - A covenant-eligibility/0.1 requirement (covenant_chain.eligibility) is a template: for each offer its
      subject becomes the offeror, its clock the check time and every qualification challenge this request and
      offeror; eligibility.eligible(presentations, requirement) then decides, with qualifications verified
      through the same stores. Every required facet must be MET; the first qualification's credential is the
      one-offer-per-credential nullifier.
    - Anything else is exchange_profile.default_eligibility. An owner can still install any other hook.
    """
    need(callable(store_for), 'EXCHANGE_CONFIG')

    def hook(request_body, request_ref, offer_body, at):
        requirement = request_body['eligibility']['requirement']
        if profile._accreditation_policy(requirement):
            return profile._accredited(requirement, request_ref, offer_body, at, store=store_for(requirement['audience']))
        if type(requirement) is dict and requirement.get('version') == 'covenant-eligibility/0.1':
            return _qualified(requirement, request_ref, offer_body, at, store_for)
        return profile.default_eligibility(request_body, request_ref, offer_body, at)
    return hook


def _qualified(template, request_ref, offer_body, at, store_for):
    from . import eligibility
    presented = offer_body['eligibility']
    if type(presented) is not dict:
        return profile.eligibility_result('INELIGIBLE', reasons=['ELIGIBILITY_PRESENTATIONS_MISSING'], checked_at=at)
    nonce = profile.eligibility_nonce(request_ref, offer_body['offeror'])
    try:
        requirement = eligibility.requirement(
            purpose=template['purpose'], subject=offer_body['offeror'], now=at, identity=template['identity'],
            qualifications=[{**entry, 'nonce': nonce} for entry in template['qualifications']],
            spending_authority=template['spending_authority'], financial_backing=template['financial_backing'],
            reputation=template['reputation'], risk=template['risk'], value=template['value'],
            high_risk=template['high_risk'])
        audiences = sorted({entry['policy']['audience'] for entry in requirement['qualifications']})
        need(len(audiences) <= 1, 'EXCHANGE_ELIGIBILITY_POLICY')
        found = eligibility.eligible(presented, requirement, store=store_for(audiences[0]) if audiences else None)
    except (ValueError, KeyError, TypeError) as exc:
        return profile.eligibility_result('INELIGIBLE', reasons=[str(exc)[:80] if isinstance(exc, ValueError) else 'ELIGIBILITY_PRESENTATIONS'],
                                  checked_at=at)
    if not found['eligible']:
        return profile.eligibility_result('INELIGIBLE', reasons=['ELIGIBILITY_' + name.upper() for name in found['unmet']][:8]
                                  or ['ELIGIBILITY_NOTHING_REQUIRED'], checked_at=at)
    evidence = found['facets']['qualifications']['evidence']
    credential = next((row['credential'] for row in evidence if 'credential' in row), None)
    return profile.eligibility_result('ELIGIBLE', issuer=(found['facets']['qualifications']['issuers'] or [None])[0], checked_at=at,
                              nullifier=credential,
                              freshness={'kind': 'ELIGIBILITY_FACETS', 'snapshot': None, 'as_of': None, 'expires_at': None})


class ExchangeBook:
    """Owner-installed exchange journal. Tool arguments cannot install, open or write it.

    role REQUESTER runs a peer-to-peer book; role OPERATOR runs a venue under
    signed venue rules. ``eligibility`` is an optional plain callable hook (see
    exchange_profile); ``approval_policy`` is the owner-signed assent policy whose
    limit makes larger awards need owner approval. ``log`` receives JSON lines
    without secrets or dossier values.
    """

    def __init__(self, directory, *, clock, role='REQUESTER', venue=None, eligibility=None, packs=(),
                 approval_policy=None, expected_head=None, log=None):
        need(callable(clock) and role in ROLES and (eligibility is None or callable(eligibility))
             and (log is None or callable(log)), 'EXCHANGE_CONFIG')
        need((venue is not None) == (role == 'OPERATOR'), 'EXCHANGE_CONFIG')
        need(type(packs) in (list, tuple) and len(packs) <= 8, 'EXCHANGE_CONFIG')
        self.venue, self.venue_ref = (None, None) if venue is None else verify_venue(venue)
        self.venue_record = deepcopy(venue)
        self.packs = [deepcopy(pack) for pack in packs]
        pins = sorted(profile.pack_id(pack) for pack in self.packs)
        self.policy_ref = None
        if approval_policy is not None:
            self.policy_ref = close._policy(approval_policy)[1]
        self.approval_policy = deepcopy(approval_policy)
        # Without an owner hook, qualifications are checked against durable verifier state kept with the book.
        self.clock, self.role, self.log = clock, role, log
        self.eligibility = eligibility if eligibility is not None else qualified_eligibility(self._verifier_store)
        self._verifiers = {}
        self._lock = threading.RLock()
        self.refusals = {}
        self.log_failures = 0
        self.directory = Path(directory)
        self.store = WorkflowStore(directory, {'book': BOOK_VERSION, 'profile': profile.PROFILE, 'role': role,
                                               'venue': self.venue_ref, 'packs': pins, 'policy': self.policy_ref},
                                   check_same_thread=False)
        if expected_head is not None and self.head() != expected_head:
            self.store.close()
            raise ExchangeError('EXCHANGE_JOURNAL_HEAD')

    def close(self):
        for verifier in self._verifiers.values():
            verifier.close()
        self.store.close()

    def _verifier_store(self, audience):
        """The owner's durable agent_accreditation.VerifierStore for one audience, kept beside the book."""
        from . import agent_accreditation
        from .identity_store import private_directory
        with self._lock:
            found = self._verifiers.get(audience)
            if found is None:
                base = private_directory(self.directory / 'verifiers')
                found = agent_accreditation.VerifierStore(
                    private_directory(base / digest('AAP-EXCHANGE-VERIFIER-0.1', {'audience': audience})[:32]),
                    audience=audience)
                self._verifiers[audience] = found
            return found

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def now(self):
        value = self.clock()
        need(type(value) is int and 0 <= value <= profile.MAX, 'EXCHANGE_CONFIG')
        return value

    def head(self):
        events = self.store.events()
        return events[-1]['id'] if events else '0' * 64

    def _emit(self, event, **fields):
        if self.log is not None:
            line = json.dumps({'event': event, 'book': BOOK_VERSION, 'role': self.role, **fields}, sort_keys=True,
                              separators=(',', ':'), ensure_ascii=True)
            try:
                self.log(line)
            except (OSError, ValueError, TypeError, RuntimeError):
                self.log_failures += 1  # a failed log line never changes an outcome; it is counted in metrics

    def _refused(self, action, code):
        self.refusals[code] = self.refusals.get(code, 0) + 1
        self._emit('REFUSED', action=action, code=code)

    def _events(self, kind=None, task=None):
        return [e['body'] for e in self.store.events()
                if (kind is None or e['body']['kind'] == kind) and (task is None or e['body']['task'] == task)]

    @contextmanager
    def _write(self):
        with self.store.exclusive():
            yield

    def _append(self, kind, task, value, **log):
        self.store.append(kind, task, value)
        self._emit(kind, request=task, **log)

    def _request(self, ref):
        rows = self._events('X_REQUEST', ref)
        need(bool(rows), 'EXCHANGE_UNKNOWN_REQUEST')
        envelope = rows[-1]['value']['envelope']
        return envelope, profile.verify_request(envelope, packs=self.packs)

    # requests ---------------------------------------------------------------------
    @_counted
    def post(self, envelope):
        """Record a signed demand post. A revision after offers opened is refused."""
        checked = profile.verify_request(envelope, packs=self.packs)
        body, ref = checked['body'], checked['id']
        now = self.now()
        need(now < body['window']['closes'], 'EXCHANGE_WINDOW_CLOSED')
        if self.venue is not None:
            need(not check_venue(body, self.venue, self.venue_ref), 'EXCHANGE_VENUE_RULES')
        with self._write():
            if self._events('X_REQUEST', ref):
                return {'status': 'IDEMPOTENT', 'request': ref, 'journal': self.head(), **FLAGS}
            if body['supersedes'] is not None:
                old_envelope, old = self._request(body['supersedes'])
                opened = now >= old['body']['window']['opens'] or self._events('X_SEAL', old['id']) or \
                    self._events('X_OFFER', old['id'])
                if opened:
                    need(old['rule'] == checked['rule'], 'EXCHANGE_RULE_CHANGED_AFTER_OPENING')
                    raise ExchangeError('EXCHANGE_REQUEST_LOCKED')
            self._append('X_REQUEST', ref, {'envelope': deepcopy(envelope), 'posted_at': now})
        return {'status': 'POSTED', 'request': ref, 'rule': checked['rule'], 'venue': self.venue_ref,
                'authority': checked['authority'], 'journal': self.head(), **FLAGS}

    # offers -----------------------------------------------------------------------
    def _window(self, body, now):
        need(now >= body['window']['opens'], 'EXCHANGE_WINDOW_NOT_OPEN')
        need(now < body['window']['closes'], 'EXCHANGE_WINDOW_CLOSED')

    def _admitted(self, ref):
        rows = {}
        for event in self._events('X_SEAL', ref) + self._events('X_OFFER', ref):
            rows[event['value']['offeror']] = event['value']
        return rows

    @_counted
    def seal(self, request_ref, envelope):
        """Record a sealed commitment during the window. Returns the relay payload the operator signs."""
        _, checked = self._request(request_ref)
        body = checked['body']
        need(body['mode'] == 'SEALED', 'EXCHANGE_MODE')
        seal_body, seal_ref = profile.verify_seal(envelope, request_ref)
        need(seal_body['offeror'] not in (body['principal'], body['agent']), 'EXCHANGE_SELF_OFFER')
        now = self.now()
        with self._write():
            admitted = self._admitted(request_ref)
            prior = admitted.get(seal_body['offeror'])
            if prior is not None:
                need(prior['id'] == seal_ref, 'EXCHANGE_DUPLICATE_OFFER')
                return {'status': 'IDEMPOTENT', 'seal': seal_ref, 'received_at': prior['received_at'], **FLAGS}
            self._window(body, now)
            need(len(admitted) < body['eligibility']['max_offers'], 'EXCHANGE_OFFER_LIMIT')
            self._append('X_SEAL', request_ref, {'envelope': deepcopy(envelope), 'id': seal_ref,
                                                 'offeror': seal_body['offeror'], 'received_at': now}, seal=seal_ref)
        relay = relay_receipt(self.venue_ref, seal_body, seal_ref, now) if self.venue_ref else None
        return {'status': 'SEALED', 'seal': seal_ref, 'received_at': now, 'relay_payload': relay,
                'terms_visible_to_book': False, **FLAGS}

    def _eligible(self, body, ref, offer_body, at):
        """(gate, refusal code or None). One credential (nullifier) backs at most one offeror per request."""
        gate = profile._hooked(self.eligibility, body, ref, offer_body, at)
        if gate['status'] not in ('ELIGIBLE', 'NOT_REQUIRED'):
            return gate, 'EXCHANGE_INELIGIBLE'
        if gate['nullifier'] is not None:
            for event in self._events('X_OFFER', ref):
                if event['value'].get('nullifier') == gate['nullifier'] and event['value']['offeror'] != offer_body['offeror']:
                    return dict(gate, reasons=['SHARED_CREDENTIAL']), 'EXCHANGE_DUPLICATE_OFFER'
        return gate, None

    @_counted
    def submit(self, request_ref, envelope):
        """OPEN mode: record a firm offer in the clear during the window."""
        _, checked = self._request(request_ref)
        body = checked['body']
        need(body['mode'] == 'OPEN', 'EXCHANGE_MODE')
        offer_body, offer_ref = profile.verify_offer(envelope, body, request_ref, self.packs)
        now = self.now()
        with self._write():
            admitted = self._admitted(request_ref)
            prior = admitted.get(offer_body['offeror'])
            if prior is not None:
                need(prior['id'] == offer_ref, 'EXCHANGE_DUPLICATE_OFFER')
                return {'status': 'IDEMPOTENT', 'offer': offer_ref, **FLAGS}
            self._window(body, now)
            need(len(admitted) < body['eligibility']['max_offers'], 'EXCHANGE_OFFER_LIMIT')
            gate, problem = self._eligible(body, request_ref, offer_body, now)
            need(problem is None, problem or 'EXCHANGE_INELIGIBLE')
            self._append('X_OFFER', request_ref, {'envelope': deepcopy(envelope), 'id': offer_ref, 'offeror': offer_body['offeror'],
                                                  'received_at': now, 'seal': None, 'salt': None,
                                                  'nullifier': gate['nullifier']}, offer=offer_ref)
        return {'status': 'RECORDED', 'offer': offer_ref, 'received_at': now, 'eligibility': gate['status'], **FLAGS}

    @_counted
    def reveal(self, request_ref, envelope, salt):
        """SEALED mode, after close and before reveal_by: open one seal with its signed offer and salt."""
        _, checked = self._request(request_ref)
        body = checked['body']
        need(body['mode'] == 'SEALED', 'EXCHANGE_MODE')
        now = self.now()
        need(now >= body['window']['closes'], 'EXCHANGE_SEALED_UNTIL_CLOSE')
        need(now <= body['window']['reveal_by'], 'EXCHANGE_REVEAL_LATE')
        offer_body, offer_ref = profile.verify_offer(envelope, body, request_ref, self.packs)
        with self._write():
            seals = {e['value']['offeror']: e['value'] for e in self._events('X_SEAL', request_ref)}
            sealed = seals.get(offer_body['offeror'])
            need(sealed is not None, 'EXCHANGE_SEAL_MISSING')
            for event in self._events('X_OFFER', request_ref):
                if event['value']['offeror'] == offer_body['offeror']:
                    need(event['value']['id'] == offer_ref, 'EXCHANGE_DUPLICATE_OFFER')
                    return {'status': 'IDEMPOTENT', 'offer': offer_ref, **FLAGS}
            seal_body = sealed['envelope']['body']
            profile.open_seal(seal_body, envelope, salt, body, request_ref, self.packs)
            gate, problem = self._eligible(body, request_ref, offer_body, sealed['received_at'])
            if problem is not None:
                # The seal entered the book, so its refused reveal is recorded as a statement, then refused.
                if not any(e['value']['offer'] == offer_ref for e in self._events('X_REFUSED_REVEAL', request_ref)):
                    self._append('X_REFUSED_REVEAL', request_ref, {'offeror': offer_body['offeror'], 'offer': offer_ref,
                                                                   'reasons': gate['reasons'][:4], 'at': now}, offer=offer_ref)
                raise ExchangeError(problem)
            self._append('X_OFFER', request_ref, {'envelope': deepcopy(envelope), 'id': offer_ref, 'offeror': offer_body['offeror'],
                                                  'received_at': sealed['received_at'], 'seal': sealed['id'], 'salt': salt,
                                                  'revealed_at': now, 'nullifier': gate['nullifier']}, offer=offer_ref)
        return {'status': 'REVEALED', 'offer': offer_ref, 'sealed_at': sealed['received_at'], 'eligibility': gate['status'], **FLAGS}

    @_counted
    def withdraw(self, request_ref, envelope):
        """Record a signed withdrawal of the offeror's own seal or offer; it counts against its close record."""
        self._request(request_ref)
        body, ref = profile.verify_withdrawal(envelope, request_ref)
        now = self.now()
        with self._write():
            own = [e['value'] for e in self._events('X_SEAL', request_ref) + self._events('X_OFFER', request_ref)
                   if e['value']['offeror'] == body['offeror']]
            need(any(row['id'] == body['target'] for row in own), 'EXCHANGE_WITHDRAWAL')
            if any(e['value']['id'] == ref for e in self._events('X_WITHDRAW', request_ref)):
                return {'status': 'IDEMPOTENT', 'withdrawal': ref, **FLAGS}
            self._append('X_WITHDRAW', request_ref, {'envelope': deepcopy(envelope), 'id': ref, 'recorded_at': now},
                         withdrawal=ref)
        return {'status': 'RECORDED', 'withdrawal': ref, 'counts_against_offeror': True, **FLAGS}

    @_counted
    def decline(self, request_ref, envelope):
        """Record a signed structured decline; the requester can turn it into a decline notice."""
        request_envelope, checked = self._request(request_ref)
        body, ref = profile.verify_decline(envelope, checked['body'], request_ref, self.packs)
        with self._write():
            if any(e['value']['id'] == ref for e in self._events('X_DECLINE', request_ref)):
                return {'status': 'IDEMPOTENT', 'decline': ref, **FLAGS}
            self._append('X_DECLINE', request_ref, {'envelope': deepcopy(envelope), 'id': ref, 'recorded_at': self.now()},
                         decline=ref)
        return {'status': 'RECORDED', 'decline': ref, 'notice': retrade.decline_notice(request_envelope, envelope, packs=self.packs)}

    # comparison and award -------------------------------------------------------------
    def _statements(self, request_ref, body, now):
        """Book statements, never signed facts: refused reveals, and after reveal_by each silent seal."""
        rows = [{'kind': 'REFUSED_REVEAL', 'offeror': e['value']['offeror'], 'request': request_ref, 'at': e['value']['at']}
                for e in self._events('X_REFUSED_REVEAL', request_ref)]
        if body['mode'] != 'SEALED' or now <= body['window']['reveal_by']:
            return rows
        settled = {e['value']['offeror'] for e in self._events('X_OFFER', request_ref)}
        settled |= {e['value']['envelope']['body']['offeror'] for e in self._events('X_WITHDRAW', request_ref)}
        settled |= {row['offeror'] for row in rows}
        for event in self._events('X_SEAL', request_ref):
            if event['value']['offeror'] not in settled:
                rows.append({'kind': 'NOT_REVEALED', 'offeror': event['value']['offeror'], 'request': request_ref,
                             'at': body['window']['reveal_by']})
        return rows

    @_counted
    def compare(self, request_ref, detail='SUMMARY'):
        """Rank the admitted offers by the request's own rule; record the comparison id for the award."""
        envelope, checked = self._request(request_ref)
        body = checked['body']
        now = self.now()
        submissions = [{'offer': e['value']['envelope'], 'submitted_at': e['value']['received_at']}
                       for e in self._events('X_OFFER', request_ref)]
        withdrawals = [e['value']['envelope'] for e in self._events('X_WITHDRAW', request_ref)]
        result = profile.compare(envelope, submissions, at=now, packs=self.packs, eligibility=self.eligibility,
                                 withdrawals=withdrawals, detail=detail)
        pending = []
        if body['mode'] == 'SEALED' and now <= body['window']['reveal_by']:
            revealed = {e['value']['offeror'] for e in self._events('X_OFFER', request_ref)}
            pending = [e['value']['offeror'] for e in self._events('X_SEAL', request_ref) if e['value']['offeror'] not in revealed]
        result['pending_reveal'] = sorted(pending)
        result['not_revealed'] = self._statements(request_ref, body, now)
        result['final'] = result['final'] and not pending
        if self.venue is not None:
            pack = checked['vertical']
            for row in result['ranked']:
                money = profile.amount_of(pack, next(s['offer']['body']['terms'] for s in submissions
                                                     if profile.record_id('OFFER', s['offer']['body']) == row['offer']))
                row['fees']['venue'] = venue_fee(self.venue, money['amount'])
        with self._write():
            if not any(e['value']['id'] == result['id'] for e in self._events('X_COMPARISON', request_ref)):
                self._append('X_COMPARISON', request_ref, {'id': result['id'], 'core': result['core'], 'at': now,
                                                           'final': result['final']}, comparison=result['id'])
        return result

    def _skips_hold(self, request_ref, skipped, now):
        for offer_ref, reason in skipped.items():
            offer_rows = [e['value'] for e in self._events('X_OFFER', request_ref) if e['value']['id'] == offer_ref]
            need(bool(offer_rows), 'EXCHANGE_NOT_RANKED')
            offeror = offer_rows[0]['offeror']
            if reason == 'WITHDRAWN':
                ok = any(e['value']['envelope']['body']['offeror'] == offeror for e in self._events('X_WITHDRAW', request_ref))
            elif reason == 'DECLINED':
                ok = any(e['value']['envelope']['body']['offeror'] == offeror for e in self._events('X_DECLINE', request_ref))
            elif reason == 'EXPIRED':
                ok = offer_rows[0]['envelope']['body']['valid_until'] <= now
            else:
                ok = any(e['value']['body']['offer'] == offer_ref and e['value']['body']['outcome'] == reason
                         for e in self._events('X_CLOSE', request_ref))
            need(ok, 'EXCHANGE_NOT_RANKED')

    @_counted
    def award(self, request_ref, award, record, *, approval=None):
        """Record the requester-signed award after checking rank, skips, the owner limit and one-time approval."""
        envelope, checked = self._request(request_ref)
        body, ref = close.verify_award_record(record, award)
        terms = close.award_terms(award['application'])
        need(body['request'] == request_ref, 'EXCHANGE_AWARD')
        now = self.now()
        need(terms['awarded_at'] <= now, 'EXCHANGE_AWARD')
        comparisons = {e['value']['id']: e['value'] for e in self._events('X_COMPARISON', request_ref)}
        need(body['comparison'] in comparisons and comparisons[body['comparison']]['final'], 'EXCHANGE_COMPARISON')
        offer_rows = [e['value'] for e in self._events('X_OFFER', request_ref) if e['value']['id'] == body['offer']]
        need(bool(offer_rows), 'EXCHANGE_AWARD')
        comparison = {'id': body['comparison'], 'core': comparisons[body['comparison']]['core']}
        rebuilt = close.prepare_award(envelope, offer_rows[0]['envelope'], comparison, context=award['application']['context'],
                                      at=terms['awarded_at'], packs=self.packs, skipped=award.get('skipped'))
        need(rebuilt['id'] == terms['application'], 'EXCHANGE_AWARD')
        self._skips_hold(request_ref, award.get('skipped') or {}, now)
        required = close.approval_required(self.approval_policy, body['requester'], body['amount'])
        occurrence = None
        if required:
            need(approval is not None, 'EXCHANGE_APPROVAL_REQUIRED')
            occurrence = close.verify_approval(self.approval_policy, approval, award, at=now)['occurrence']
            need(body['approval'] == occurrence, 'EXCHANGE_APPROVAL_INVALID')
        with self._write():
            # An approval binds this exact award, so it cannot approve any other award; a replay is idempotent.
            for event in self._events('X_AWARD', request_ref):
                if event['value']['id'] == ref:
                    return {'status': 'IDEMPOTENT', 'award': ref, **FLAGS}
                outcome = [e['value']['body']['outcome'] for e in self._events('X_CLOSE', request_ref)
                           if e['value']['body']['award'] == event['value']['application']]
                need(outcome and outcome[0] in ('FAILED_CONDITION', 'LAPSED'), 'EXCHANGE_AWARD_EXISTS')
            self._append('X_AWARD', request_ref, {'envelope': deepcopy(record), 'id': ref, 'application': terms['application'],
                                                  'award': deepcopy(award), 'occurrence': occurrence, 'approval': deepcopy(approval),
                                                  'recorded_at': now}, award=ref)
        return {'status': 'AWARDED', 'award': ref, 'application': terms['application'], 'approval_required': required,
                'checklist': close.checklist(award['application']), **FLAGS}

    def _award(self, request_ref, application=None):
        rows = [e['value'] for e in self._events('X_AWARD', request_ref)
                if application is None or e['value']['application'] == application]
        need(bool(rows), 'EXCHANGE_AWARD')
        return rows[-1]

    @_counted
    def notices(self, request_ref, consents=()):
        """NOT_SELECTED notice payloads for every other offeror; the requester signs each."""
        self._request(request_ref)
        current = self._award(request_ref)
        core = {e['value']['id']: e['value']['core'] for e in self._events('X_COMPARISON', request_ref)}
        comparison_ref = current['envelope']['body']['comparison']
        comparison = {'id': comparison_ref, 'core': core[comparison_ref]}
        requester = current['envelope']['body']['requester']
        out = []
        for event in self._events('X_OFFER', request_ref):
            value = event['value']
            if value['id'] == current['envelope']['body']['offer']:
                continue
            own = [c for c in consents if c['body']['recipient'] == value['offeror']]
            out.append(retrade.award_notice(comparison, value['id'], value['offeror'], self.now(), consents=own,
                                            requester=requester))
        return {'notices': out, 'delivered': False, **FLAGS}

    @_counted
    def record_notice(self, request_ref, envelope):
        self._request(request_ref)
        body, ref = profile._signed('NOTICE', envelope, 'requester')
        need(body['request'] == request_ref, 'EXCHANGE_NOTICE')
        with self._write():
            if not any(e['value']['id'] == ref for e in self._events('X_NOTICE', request_ref)):
                self._append('X_NOTICE', request_ref, {'envelope': deepcopy(envelope), 'id': ref}, notice=ref)
        return {'status': 'RECORDED', 'notice': ref, 'delivered': False, **FLAGS}

    # consent and the checklist -----------------------------------------------------------
    @_counted
    def consent(self, request_ref, record, revocation=None):
        """Record a holder consent receipt (and optionally its revocation); never the dossier values."""
        self._request(request_ref)
        terms, ref = profile.dossier.verify_consent(record)
        need(terms['request'] == request_ref, 'DOSSIER_CONSENT')
        with self._write():
            if not any(e['value']['id'] == ref for e in self._events('X_CONSENT', request_ref)):
                self._append('X_CONSENT', request_ref, {'record': deepcopy(record), 'id': ref}, consent=ref)
            if revocation is not None:
                revoked = profile.dossier.verify_revocation(revocation)
                need(revoked['consent'] == ref and revoked['holder'] == terms['holder'], 'DOSSIER_REVOCATION')
                if not any(e['value']['consent'] == ref for e in self._events('X_REVOKE', request_ref)):
                    self._append('X_REVOKE', request_ref, {'record': deepcopy(revocation), 'consent': ref}, consent=ref)
        return {'status': 'RECORDED', 'consent': ref, 'revoked': revocation is not None, 'values_stored': False, **FLAGS}

    def _checklist(self, request_ref, current, now):
        application = current['award']['application']
        evidence = [e['value']['envelope'] for e in self._events('X_EVIDENCE', request_ref)
                    if e['value']['application'] == current['application']]
        decisions = [e['value']['envelope'] for e in self._events('X_DECISION', request_ref)
                     if e['value']['application'] == current['application']]
        return close.checklist_status(application, evidence, decisions, at=now)

    @_counted
    def evidence(self, request_ref, envelope):
        current = self._award(request_ref)
        body, ref = profile._signed('EVIDENCE', envelope, 'supplier')
        need(body['agreement'] == current['application'], 'EXCHANGE_EVIDENCE')
        with self._write():
            if not any(e['value']['id'] == ref for e in self._events('X_EVIDENCE', request_ref)):
                close.checklist_status(current['award']['application'], [envelope], (), at=self.now())
                self._append('X_EVIDENCE', request_ref, {'envelope': deepcopy(envelope), 'id': ref,
                                                         'application': current['application']}, evidence=ref)
            status = self._checklist(request_ref, current, self.now())
        return {'status': 'RECORDED', 'evidence': ref, 'checklist': status['status'], **FLAGS}

    @_counted
    def decide(self, request_ref, envelope):
        current = self._award(request_ref)
        body, ref = profile._signed('DECISION', envelope, 'beneficiary')
        need(body['agreement'] == current['application'], 'EXCHANGE_EVIDENCE')
        with self._write():
            evidence = [e['value']['envelope'] for e in self._events('X_EVIDENCE', request_ref)
                        if e['value']['application'] == current['application']]
            close.checklist_status(current['award']['application'], evidence, [envelope], at=self.now())
            if not any(e['value']['id'] == ref for e in self._events('X_DECISION', request_ref)):
                self._append('X_DECISION', request_ref, {'envelope': deepcopy(envelope), 'id': ref,
                                                         'application': current['application']}, decision=ref)
            status = self._checklist(request_ref, current, self.now())
        return {'status': 'RECORDED', 'decision': ref, 'checklist': status['status'], **FLAGS}

    @_counted
    def checklist(self, request_ref):
        current = self._award(request_ref)
        return self._checklist(request_ref, current, self.now())

    @_counted
    def close_deal(self, request_ref, receipt, *, final_application=None, reacceptance=None):
        """Record a close receipt after checking the checklist, the retrade rule and the required signatures."""
        _, checked = self._request(request_ref)
        current = self._award(request_ref)
        award = current['award']
        verified = close.verify_close(receipt, award)
        body = verified['body']
        now = self.now()
        status = self._checklist(request_ref, current, now)
        if body['outcome'] in close.CLOSED:
            need(status['status'] == 'READY_TO_CLOSE' and body['checklist'] == status['digest'], 'EXCHANGE_CHECKLIST_INCOMPLETE')
            final = award['application'] if final_application is None else final_application
            need(body['final'] == close.award_terms(final)['application'], 'EXCHANGE_CLOSE')
            classified = retrade.classify(checked['vertical'], award, final, reacceptance_record=reacceptance)
            need(classified['outcome'] == body['outcome'] and classified['retrade'] == body['retrade']
                 and classified['reacceptance'] == body['reacceptance'], 'EXCHANGE_RETRADE_UNACCEPTED')
        elif body['outcome'] == 'FAILED_CONDITION':
            item = next((row for row in status['items'] if row['id'] == body['failed_condition']), None)
            need(item is not None and item['status'] in ('FAILED', 'EXPIRED') and item['supplier'] == body['failed_party'],
                 'EXCHANGE_CLOSE')
        else:
            need(now > close.award_terms(award['application'])['close_by'] and status['status'] != 'READY_TO_CLOSE',
                 'EXCHANGE_CLOSE')
        with self._write():
            if any(e['value']['id'] == verified['id'] for e in self._events('X_CLOSE', request_ref)):
                return {'status': 'IDEMPOTENT', 'close': verified['id'], **FLAGS}
            need(not any(e['value']['body']['award'] == body['award'] for e in self._events('X_CLOSE', request_ref)),
                 'EXCHANGE_CLOSE')
            self._append('X_CLOSE', request_ref, {'receipt': deepcopy(receipt), 'id': verified['id'], 'body': body,
                                                  'final': deepcopy(final_application), 'reacceptance': deepcopy(reacceptance)},
                         close=verified['id'], outcome=body['outcome'])
        return {'status': 'RECORDED', 'close': verified['id'], 'outcome': body['outcome'],
                'acknowledged': verified['acknowledged'], **FLAGS}

    # records, health, metrics, backup ----------------------------------------------------
    def export(self, request_ref=None):
        """Signed receipts in the close_record input shape; dossier values are never in a book."""
        offers, withdrawals, awards, closes, statements = [], [], [], [], []
        for event in self._events('X_REQUEST'):
            ref = event['task']
            if request_ref is not None and ref != request_ref:
                continue
            envelope = event['value']['envelope']
            offers += [{'request': envelope, 'offer': e['value']['envelope']} for e in self._events('X_OFFER', ref)]
            withdrawals += [{'request': envelope, 'withdrawal': e['value']['envelope']} for e in self._events('X_WITHDRAW', ref)]
            awards += [{'award': e['value']['award'], 'record': e['value']['envelope']} for e in self._events('X_AWARD', ref)]
            for e in self._events('X_CLOSE', ref):
                award = next(a['value']['award'] for a in self._events('X_AWARD', ref)
                             if a['value']['application'] == e['value']['body']['award'])
                closes.append({'award': award, 'receipt': e['value']['receipt']})
            body = envelope['body']
            statements += self._statements(ref, body, self.now())
        return {'offers': offers, 'withdrawals': withdrawals, 'awards': awards, 'closes': closes, 'statements': statements}

    @_counted
    def close_records(self, request_ref=None):
        return close_record(**self.export(request_ref), packs=self.packs)

    def health(self):
        try:
            events = self.store.events()
            chain = 'OK'
        except ValueError:
            events, chain = [], 'HISTORY_CHANGED'
        private = 'OK'
        try:
            mode = os.stat(self.directory).st_mode & 0o077
            private = 'OK' if mode == 0 else 'TOO_OPEN'
        except OSError:
            private = 'MISSING'
        ready = chain == 'OK' and private == 'OK'
        return {'status': 'READY' if ready else 'NOT_READY', 'live': True, 'journal_head': events[-1]['id'] if events else '0' * 64,
                'events': len(events), 'checks': {'journal_chain': chain, 'storage_private': private},
                'role': self.role, 'venue': self.venue_ref, **FLAGS}

    def metrics(self):
        """Prometheus text exposition (version 0.0.4) of journal counts and refusals since start."""
        kinds = {}
        for event in self.store.events():
            kinds[event['body']['kind']] = kinds.get(event['body']['kind'], 0) + 1
        lines = ['# HELP aap_exchange_journal_events Journal events by kind.', '# TYPE aap_exchange_journal_events gauge']
        for kind in sorted(kinds):
            lines.append('aap_exchange_journal_events{kind="%s"} %d' % (kind, kinds[kind]))
        lines += ['# HELP aap_exchange_refusals_total Refusals since this process started.',
                  '# TYPE aap_exchange_refusals_total counter']
        for code in sorted(self.refusals):
            lines.append('aap_exchange_refusals_total{code="%s"} %d' % (code, self.refusals[code]))
        lines += ['# HELP aap_exchange_log_failures_total Log lines the owner hook refused since start.',
                  '# TYPE aap_exchange_log_failures_total counter', 'aap_exchange_log_failures_total %d' % self.log_failures]
        return '\n'.join(lines) + '\n'

    def backup(self, destination):
        """Consistent SQLite online backup into a new private directory; restore by opening it with expected_head."""
        target = Path(destination)
        need(not target.exists(), 'EXCHANGE_CONFIG')
        target.mkdir(mode=0o700, parents=True)
        with self._lock, self.store.exclusive():
            head = self.head()
            copy = sqlite3.connect(target / 'workflow.sqlite')
            try:
                copy.execute('PRAGMA journal_mode=WAL')
                copy.execute('PRAGMA synchronous=FULL')
                self.store.db.backup(copy)
            finally:
                copy.close()
        os.chmod(target / 'workflow.sqlite', 0o600)
        descriptor = os.open(target, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        return {'path': str(target), 'journal_head': head, 'restore': 'ExchangeBook(path, ..., expected_head=journal_head)'}


def describe():
    return {'version': BOOK_VERSION, 'profile': profile.PROFILE, 'roles': list(ROLES), 'fee_models': list(FEE_MODELS),
            'storage': 'WorkflowStore: SQLite WAL, synchronous FULL, hash-chained append-only events, 0700/0600',
            'sealed': 'commitments only until close; reveals and comparisons refused before close',
            'close_record': RECORD_VERSION, 'observability': ['health()', 'metrics() Prometheus text', 'JSON-line log hook'],
            'limits': {'records': MAX_RECORDS, 'submissions': profile.MAX_SUBMISSIONS},
            'writes_through_tools': False, **FLAGS}
