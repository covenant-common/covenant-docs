"""Mastercard Agent Pay: AI-initiation signals as labelled evidence, and agentic-token references as an AAP rail.

GRAFT for the signal Mastercard specifies, TAKE-AND-IMPROVE for the rail, as published on 28 October 2026:

* Agent Pay Acceptance Framework (Mastercard, "Agentic token framework", 14 October 2025): agents are
  registered and verified before they transact, pay with agentic tokens, and identify themselves to merchants
  with Web Bot Auth. Mastercard Developers Merchant Cloud "Level 1 Agentic Commerce" ("Identifying Agent
  Traffic with Web Bot Auth") gives the wire signal: an RFC 9421 signature with tag agent-pay-auth covering
  @authority and @path, with created, keyid, expires, alg and nonce, at most 8 minutes, nonces kept 8 minutes.
  ``verify_signal`` checks it with web_bot_auth (profile MASTERCARD_AGENT_PAY) under keys the owner adopted:
  a SIGNED signal that an agent, not a person at a browser, initiated the request.
* Other announced signals (the Agent Pay Trust Framework's probability that an agent initiated a
  transaction, 30 September 2026) have no published fields or format. ``record_signal`` keeps such a
  statement exactly as the owner's adapter received it, content-addressed and labelled
  UNVERIFIED_NETWORK_STATEMENT; it is never read as verified.
* The rail. An agentic-token payment is referenced, never carried: ``urn:aap:rail:mastercard-agent-pay:1``
  is a covenant-work-order/0.3 rail (open_work.rail) whose instructions hold one non-sensitive reference, an
  EMVCo Payment Account Reference (29 alphanumeric characters) or an MDES Token Unique Reference. A primary
  account number, token number, expiry, cryptogram (DSRP, DTVC), security code or any 12 to 19 digit number
  with a valid Luhn check digit is refused before anything else is read, so no card data is ever handled. ``bind`` attaches the reference
  to a bound work order through open_work.payment_link, so the agreement names its payment leg.

A signal is evidence about how a request was initiated; a reference names a payment leg. Neither pays,
authorizes, releases escrow or proves that a payment happened.
"""
from copy import deepcopy
import hashlib
import json
import re

from .crypto import need
from . import interop_codec as codec
from . import trust_evidence as evidence
from . import web_bot_auth as wba

RAIL = 'urn:aap:rail:mastercard-agent-pay:1'
NETWORK = 'mastercard'
REFERENCES = {'PAYMENT_ACCOUNT_REFERENCE': re.compile(r'[A-Z0-9]{29}\Z'),
              'TOKEN_UNIQUE_REFERENCE': re.compile(r'[A-Za-z0-9_-]{8,64}\Z')}
CARD_FIELDS = frozenset(name.replace('_', '').lower() for name in (
    'pan', 'primaryAccountNumber', 'accountNumber', 'cardNumber', 'number', 'paymentToken', 'payment_token', 'token',
    'tokenNumber', 'expirationMonth', 'expirationYear', 'expiry', 'expiryDate', 'token_expiration_month',
    'token_expiration_year', 'cvc', 'cvv', 'csc', 'cvc2', 'securityCode', 'token_security_code', 'cryptogram',
    'dsrp', 'dtvc', 'tavv', 'dynamicData', 'track2', 'credential'))
DIGITS = re.compile(r'[0-9 -]{12,23}\Z')
MAX_STATEMENT = 16384

REMEDIATION = {
    'AGENT_PAY_CARD_DATA': 'Remove card numbers, token numbers, expiries, cryptograms and security codes; AAP keeps references only.',
    'AGENT_PAY_REFERENCE': 'Use a 29-character Payment Account Reference or an 8-64 character Token Unique Reference.',
    'AGENT_PAY_RAIL': 'Name currency, payee and unit as bounded text; the rail is urn:aap:rail:mastercard-agent-pay:1.',
    'AGENT_PAY_ORDER': 'Bind the reference to a bound covenant-work-order/0.3 whose payment rail is the Agent Pay rail.',
    'AGENT_PAY_STATEMENT': 'Pass the network statement as one JSON object of at most 16 KiB and name its source.',
}


def remediation(code):
    return REMEDIATION.get(code, evidence.remediation(code))


def no_card_data(value):
    """Refuse a document carrying card data anywhere: a card field name, or a 12 to 19 digit string or
    integer that passes the Luhn check every card and network token number carries (ISO/IEC 7812)."""
    pending, seen = [value], 0
    while pending:
        node = pending.pop()
        seen += 1
        need(seen <= 20000, 'AGENT_PAY_CARD_DATA')
        if type(node) is dict:
            need(not {name.replace('_', '').replace('-', '').lower() for name in node if type(name) is str} & CARD_FIELDS,
                 'AGENT_PAY_CARD_DATA')
            pending.extend(node.values())
        elif type(node) is list:
            pending.extend(node)
        elif type(node) is str and DIGITS.fullmatch(node):
            digits = re.sub(r'[ -]', '', node)
            need(not (12 <= len(digits) <= 19 and digits.isdigit() and _luhn(digits)), 'AGENT_PAY_CARD_DATA')
        elif type(node) is int and 10**11 <= abs(node) < 10**19:
            need(not _luhn(str(abs(node))), 'AGENT_PAY_CARD_DATA')
    return value


def _luhn(digits):
    total = 0
    for index, char in enumerate(reversed(digits)):
        number = int(char) * (2 if index % 2 else 1)
        total += number - 9 if number > 9 else number
    return total % 10 == 0


def reference(kind, value):
    """One non-sensitive agentic-token payment reference."""
    need(kind in REFERENCES and type(value) is str, 'AGENT_PAY_REFERENCE')
    no_card_data(value)
    need(REFERENCES[kind].fullmatch(value) is not None, 'AGENT_PAY_REFERENCE')
    return {'kind': kind, 'value': value}


def rail(currency, payee, ref, unit='minor'):
    """The work-order 0.3 rail naming an agentic-token payment by reference; feed it to open_work.draft."""
    from covenant_agent.open_work import rail as open_rail
    for text in (currency, payee, unit):
        need(type(text) is str and 0 < len(text) <= 256 and text.isascii() and text.isprintable(), 'AGENT_PAY_RAIL')
    need(type(ref) is dict and set(ref) == {'kind', 'value'}, 'AGENT_PAY_REFERENCE')
    checked = reference(ref['kind'], ref['value'])
    return open_rail(RAIL, NETWORK, currency, unit, payee,
                     instructions={'reference': checked, 'card_data': 'NEVER_HANDLED'})


def bind(order, expected_id):
    """Attach the order's own Agent Pay reference to the bound work order as its payment leg."""
    from covenant_agent.open_work import payment_link
    need(type(order) is dict and type(order.get('body')) is dict, 'AGENT_PAY_ORDER')
    payment = order['body'].get('terms', {}).get('payment') if type(order['body'].get('terms')) is dict else None
    need(type(payment) is dict and payment.get('identifier') == RAIL and type(payment.get('instructions')) is dict,
         'AGENT_PAY_ORDER')
    ref = payment['instructions'].get('reference')
    need(type(ref) is dict and set(ref) == {'kind', 'value'}, 'AGENT_PAY_ORDER')
    reference(ref['kind'], ref['value'])
    document = {'rail': RAIL, 'network': NETWORK, 'reference': deepcopy(ref), 'agreement': expected_id,
                'card_data': 'NEVER_HANDLED'}
    link = payment_link(order, expected_id, RAIL, document)
    return {**link, 'reference': deepcopy(ref), 'payment_observed': False}


def verify_signal(request, adopted, now, *, seen_nonces=(), chain=None, bindings=(), agreement=None):
    """The Agent Pay Web Bot Auth signal: a request an agent key signed with tag agent-pay-auth."""
    if agreement is not None:
        need(type(agreement) is str and re.fullmatch(r'[0-9a-f]{64}', agreement), 'AGENT_PAY_ORDER')
    found = wba.verify_request(request, adopted, now, profile='MASTERCARD_AGENT_PAY', seen_nonces=seen_nonces)
    signature = found['signature']
    claims = {'signal': 'AGENT_INITIATED_REQUEST_SIGNED', 'framework': 'Mastercard Agent Pay Acceptance Framework',
              'tag': found['record']['claims']['tag'], 'authority': signature['authority'],
              'nonce': found['record']['claims']['nonce'], 'agreement': agreement}
    checks = {'signature': 'VERIFIED', 'profile': 'MASTERCARD_AGENT_PAY', 'window_seconds': wba.NETWORK_WINDOW,
              'keyid': signature['keyid'], 'clock': 'CALLER_ASSERTION', 'payment': 'NOT_A_PAYMENT_OR_AUTHORIZATION'}
    result = evidence.evidence('AGENT_PAY_SIGNAL', 'MASTERCARD_AGENT_PAY', found['record']['issuer'], signature['thumbprint'],
                               signature['signature_base_sha256'], claims, checks, signed_by=signature['aap_key'],
                               chain=chain, bindings=bindings, now=now, key_bound=True)
    result['label'] = 'SIGNED_AI_INITIATION_SIGNAL'
    return result


def record_signal(statement, source, *, agreement=None, chain=None, bindings=(), now=None):
    """Keep an announced but unspecified network trust signal exactly, labelled as an unverified statement."""
    need(type(statement) in (str, bytes) and 0 < len(statement) <= MAX_STATEMENT, 'AGENT_PAY_STATEMENT')
    raw = statement.encode('utf-8') if type(statement) is str else statement
    try:
        value = codec.parse(raw, MAX_STATEMENT, 8, 512)
    except ValueError:
        raise ValueError('AGENT_PAY_STATEMENT') from None
    need(type(value) is dict and type(source) is str and 0 < len(source) <= 128 and source.isascii()
         and source.isprintable(), 'AGENT_PAY_STATEMENT')
    no_card_data(value)
    if agreement is not None:
        need(type(agreement) is str and re.fullmatch(r'[0-9a-f]{64}', agreement), 'AGENT_PAY_ORDER')
    digest = hashlib.sha256(raw).hexdigest()
    claims = {'statement': json.loads(codec.jcs(value)), 'agreement': agreement, 'format': 'UNPUBLISHED_BY_THE_NETWORK'}
    checks = {'signature': 'NONE_OR_UNKNOWN_FORMAT', 'verified': False}
    result = evidence.evidence('AGENT_PAY_SIGNAL', 'MASTERCARD_AGENT_PAY', source, 'statement-' + digest[:16], digest,
                               claims, checks, chain=chain, bindings=bindings, now=now)
    result['label'] = 'UNVERIFIED_NETWORK_STATEMENT'
    return result


def describe():
    return {'status': 'EXPERIMENTAL_ADAPTER', 'rail': RAIL, 'network': NETWORK, 'references': sorted(REFERENCES),
            'signal': {'profile': 'MASTERCARD_AGENT_PAY', 'tags': list(wba.PROFILES['MASTERCARD_AGENT_PAY']['tags']),
                       'window_seconds': wba.NETWORK_WINDOW},
            'unpublished': ['AI-initiation probability score format', 'authorization-message agentic indicators',
                            'Agent User Identity and Payment Data object signatures', 'key directory URL'],
            'card_data': 'REFUSED_NEVER_HANDLED', 'remediation': dict(REMEDIATION), 'network_accessed': False,
            'payment_authorized': False, 'authority_granted': False, 'execution_authorized': False}
