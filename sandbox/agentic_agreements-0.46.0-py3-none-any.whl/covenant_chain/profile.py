"""Genesis profile names.

Nothing in this module imports the reducer. Callers that only need the version
string stay outside ``app``.
"""

VERSION = 'covenant-native/0.1'
NEXT_VERSION = 'covenant-native/0.2'
LIFECYCLE_VERSION = 'covenant-native/0.3'
SHIELDED_VERSION = 'covenant-native/0.4'
ECOSYSTEM_VERSION = 'covenant-native/0.5'
MISSION_VERSION = 'covenant-native/0.6'
FEDERATION_VERSION = 'covenant-native/0.7'
EXTENSIBLE_VERSION = 'covenant-native/0.8'
ECONOMIC_VERSION = 'covenant-native/0.9'
CONFIDENTIAL_VERSION = 'covenant-native/0.10'
CONTINUITY_VERSION = 'covenant-native/0.11'
MARKET_VERSION = 'covenant-native/0.12'
REVIEW_VERSION = 'covenant-native/0.13'
PREDICTION_VERSION = 'covenant-native/0.14'
# One protocol string. Upgrade, tokenomics, and scale are aliases of it.
NATIVE_015 = 'covenant-native/0.15'
SCALE_VERSION = NATIVE_015
UPGRADE_VERSION = NATIVE_015
TOKENOMICS_VERSION = NATIVE_015
# Alias of the one protocol string. The five resolution rules turn on only
# when a continuity policy names veto-guardian (see resolution_rules).
RESOLUTION_VERSION = NATIVE_015

# Explicit successor: certified legacy-world migration with witness-independent identity.
MIGRATION_VERSION = 'covenant-native/0.16'
UPGRADE_PROFILES = frozenset({UPGRADE_VERSION, MIGRATION_VERSION})
