"""Git notes and signed commit bindings that carry a certified receipt id.

Maturity: experimental. Off unless the host turns flag ``git_anchors`` on (agent
tool) or passes ``--enabled`` (tools/git_anchors.py). A note is a signature over
receipt, chain, height and certificate ids; a tampered note fails the signature.
A commit binding signs ``{commit, receipt}``. Only ids are stored. The signature
is the signer's statement that these ids belong together: the certificate id is
recorded, not checked against a commit certificate here (a host can check it
with the light client first), and an unpinned signer key is attribution only.
Git anchors add a commit-to-receipt binding beside, not instead of, witness
checkpoints (portable_trust) and anchor.py.

The notes ref is fixed: ``refs/notes/covenant-anchors``. It is never derived from
a product name, so existing notes stay readable after a rename.

Ported from Cursor PR 80 (refs/pull/80/head, 575be847), with bounded and timed
git subprocesses and optional signer pins.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path
from covenant_language.safe_io import run_subprocess

from .crypto import canonical, digest, exact, integer, key, loads, need, public_key, sign, verify

NOTES_NAME = 'covenant-anchors'
NOTES_REF = 'refs/notes/covenant-anchors'
NOTE_VERSION = 'git-anchor/1'
LABEL = 'COVENANT-GIT-ANCHOR-0.1'
COMMIT_LABEL = 'COVENANT-GIT-COMMIT-0.1'
NOTE_MAX_BYTES = 8192
GIT_TIMEOUT = 30
_OBJECT = re.compile(r'[0-9a-f]{40}\Z|[0-9a-f]{64}\Z')


def _object(value):
    """Git object ids are SHA-1 or SHA-256 hex."""
    need(type(value) is str and _OBJECT.fullmatch(value) is not None, 'GIT_OBJECT')


def note_body(receipt, chain, height, certificate):
    key(receipt)
    key(chain)
    key(certificate)
    integer(height)
    return {'version': NOTE_VERSION, 'receipt': receipt, 'chain': chain, 'height': height, 'certificate': certificate}


def sign_note(signing_key, body):
    exact(body, 'version receipt chain height certificate')
    need(body['version'] == NOTE_VERSION, 'GIT_ANCHOR_VERSION')
    note_body(body['receipt'], body['chain'], body['height'], body['certificate'])
    return {'body': dict(body), 'public': public_key(signing_key), 'signature': sign(signing_key, LABEL, body),
            'ref': NOTES_REF, 'statement': 'SIGNER_BINDS_THESE_IDS_NOT_A_VERIFIED_CERTIFICATE',
            'execution_authorized': False}


def _signed(value, signers):
    if type(value) is not dict or not {'body', 'public', 'signature'} <= set(value) or type(value.get('public')) is not str:
        return False
    return signers is None or value['public'] in signers


def verify_note(signed, expected_receipt, *, signers=None):
    """True for an untampered note naming the expected receipt; with ``signers``, only from a pinned key."""
    if not _signed(signed, signers):
        return False
    body = signed['body']
    try:
        exact(body, 'version receipt chain height certificate')
        need(body['version'] == NOTE_VERSION, 'GIT_ANCHOR_VERSION')
        note_body(body['receipt'], body['chain'], body['height'], body['certificate'])
        verify(signed['public'], LABEL, body, signed['signature'])
    except (ValueError, TypeError):
        return False
    return body['receipt'] == expected_receipt


def sign_commit(signing_key, commit, receipt):
    _object(commit)
    key(receipt)
    body = {'commit': commit, 'receipt': receipt}
    return {'body': body, 'public': public_key(signing_key), 'signature': sign(signing_key, COMMIT_LABEL, body),
            'statement': 'SIGNER_BINDS_COMMIT_TO_RECEIPT_NOT_A_VERIFIED_RECEIPT', 'execution_authorized': False}


def verify_commit(signed, expected_receipt, *, signers=None):
    if not _signed(signed, signers):
        return False
    body = signed['body']
    try:
        exact(body, 'commit receipt')
        _object(body['commit'])
        key(body['receipt'])
        verify(signed['public'], COMMIT_LABEL, body, signed['signature'])
    except (ValueError, TypeError):
        return False
    return body['receipt'] == expected_receipt


def _repository(repo):
    root = Path(repo)
    need(root.is_dir() and (root / '.git').exists(), 'GIT_ANCHOR_REPOSITORY')
    return root


def _git(root, args, *, input_text=None, limit=None, missing=False):
    """Run git in an existing checkout with a timeout and a bounded reply. Never a shell."""
    limit = NOTE_MAX_BYTES if limit is None else limit
    env = {**os.environ, 'GIT_TERMINAL_PROMPT': '0'}
    try:
        result = run_subprocess(['git', *args], cwd=root, input=None if input_text is None else input_text.encode('utf-8'),
                                timeout=GIT_TIMEOUT, env=env, max_output=limit, max_error=65536)
    except subprocess.TimeoutExpired:
        raise ValueError('GIT_ANCHOR_TIMEOUT') from None
    except OSError:
        raise ValueError('GIT_ANCHOR_COMMAND') from None
    need(len(result.stdout) <= limit, 'GIT_ANCHOR_SIZE')
    need(result.returncode == 0, 'GIT_ANCHOR_MISSING' if missing and result.returncode == 1 else 'GIT_ANCHOR_COMMAND')
    try:
        return result.stdout.decode('utf-8')
    except UnicodeError:
        raise ValueError('GIT_ANCHOR_NOTE') from None


def write_note(repo, commit, signed):
    """Attach a verified note at the fixed notes ref of an existing checkout."""
    need(type(signed) is dict and type(signed.get('body')) is dict, 'GIT_ANCHOR_SIGNATURE')
    need(verify_note(signed, signed['body'].get('receipt')), 'GIT_ANCHOR_SIGNATURE')
    _object(commit)
    root = _repository(repo)
    payload = canonical({'body': signed['body'], 'public': signed['public'], 'signature': signed['signature']})
    _git(root, ['notes', '--ref', NOTES_NAME, 'add', '-f', '-F', '-', commit], input_text=payload.decode('ascii'))
    return {'ref': NOTES_REF, 'commit': commit, 'receipt': signed['body']['receipt'],
            'certificate': signed['body']['certificate'], 'execution_authorized': False}


def read_note(repo, commit):
    _object(commit)
    root = _repository(repo)
    text = _git(root, ['notes', '--ref', NOTES_NAME, 'show', commit], missing=True)
    try:
        value = loads(text.strip().encode('ascii'))
        exact(value, 'body public signature')
    except (ValueError, UnicodeError):
        raise ValueError('GIT_ANCHOR_NOTE') from None
    return value


def register_verifier(registry, *, signers=None):
    """ProofRegistry check ``git-anchor/1`` for a note or commit proof; with ``signers``, pinned keys only."""
    from .proof_facility import binary
    if signers is not None:
        need(type(signers) in (list, tuple, set) and 1 <= len(signers) <= 32, 'GIT_ANCHOR_SIGNERS')
        for signer in signers:
            key(signer)
        signers = sorted(set(signers))
    manifest = {
        'system': 'git-anchor/1',
        'semantics': digest('COVENANT-GIT-ANCHOR-VERIFIER-0.1', {'ref': NOTES_REF, 'signers': signers}),
        'implementation': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': 'Ed25519 note or commit signature over receipt and certificate ids. Not certificate verification.',
        'trust': 'PINNED_SIGNER' if signers is not None else 'LOCAL_SIGNATURE',
    }
    pinned = None if signers is None else set(signers)

    def callback(envelope):
        statement = envelope['statement']
        try:
            raw = loads(binary(envelope['proof'], NOTE_MAX_BYTES))
            exact(statement, 'kind receipt')
        except ValueError:
            return False
        if statement['kind'] == 'commit':
            return verify_commit(raw, statement['receipt'], signers=pinned)
        if statement['kind'] == 'note':
            return verify_note(raw, statement['receipt'], signers=pinned)
        return False

    return registry.register(manifest, callback)


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Git receipt anchors. Off unless --enabled.')
    parser.add_argument('--enabled', action='store_true')
    args = parser.parse_args(argv)
    print(json.dumps({'plugin': 'git_anchors', 'enabled': bool(args.enabled), 'ref': NOTES_REF,
                      'maturity': 'experimental', 'execution_authorized': False}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
