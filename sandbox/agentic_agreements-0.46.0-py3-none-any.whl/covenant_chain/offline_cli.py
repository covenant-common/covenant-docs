"""Owner-operated offline custody. Passwords are prompted, never CLI arguments.

The prompt appears only when standard input is an interactive terminal. Otherwise
(a pipe, a closed stdin, a test or a service) the password is the next line of
standard input, and end of input refuses at once with OFFLINE_PASSWORD_REQUIRED.
The controlling terminal is never read then, so a headless run cannot wait on it.
--password-file works everywhere.
"""
import argparse
import getpass
import hashlib
import json
import os
import re
from pathlib import Path
import secrets
import socket
import stat
import sys
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from . import crypto as c, offline as o, offline_carriers as carriers
from .offline_store import OfflineStore

IDENTITY = 'covenant-offline-owner/0.1'


def _password_key(password, salt):
    c.need(type(password) is str and 12 <= len(password) <= 1024, 'OFFLINE_PASSWORD_LENGTH_12_TO_1024')
    return Scrypt(salt=salt, length=32, n=32768, r=8, p=1).derive(password.encode('utf-8'))


def initialize(directory, *, scope, password):
    c.key(scope)
    directory = Path(directory); directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    c.need(not directory.is_symlink() and stat.S_IMODE(directory.stat().st_mode)&0o077 == 0,
           'OFFLINE_PRIVATE_DIRECTORY')
    signing = Ed25519PrivateKey.generate(); storage = secrets.token_bytes(32)
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    body = {'signing_secret': signing.private_bytes_raw().hex(), 'storage_key': storage.hex(), 'scope': scope}
    cipher = o.transport_cipher()(_password_key(password, salt)).encrypt(nonce, c.canonical(body), IDENTITY.encode('ascii'))
    carriers.write_file(directory/'owner.key', c.canonical({'version': IDENTITY, 'salt': o.b64(salt),
        'nonce': o.b64(nonce), 'ciphertext': o.b64(cipher)}))
    return {'owner': c.public_key(signing), 'scope': scope}


def scope_key(value):
    """64 hex stays as written. A shop name is hashed so the CLI does not demand a hash."""
    if type(value) is str and c.HEX.fullmatch(value):
        return value
    c.need(type(value) is str and 1 <= len(value) <= 128 and all(32 <= ord(ch) <= 126 for ch in value), 'OFFLINE_SCOPE')
    return hashlib.sha256(b'COVENANT-OFFLINE-SCOPE\0' + value.encode('ascii')).hexdigest()


def load_identity(directory, *, password):
    """A missing ``owner.key`` is ``OFFLINE_OWNER_KEY_MISSING``, never an uncoded error."""
    path = Path(directory)/'owner.key'
    try:
        info = path.lstat()
    except FileNotFoundError:
        raise ValueError('OFFLINE_OWNER_KEY_MISSING') from None
    c.need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode)&0o077 == 0, 'OFFLINE_PRIVATE_KEY_FILE')
    try:
        raw = carriers.read_file(path, limit=4096)
    except FileNotFoundError:
        raise ValueError('OFFLINE_OWNER_KEY_MISSING') from None
    value = o.exact_load(raw, 4096)
    c.exact(value, 'version salt nonce ciphertext'); c.need(value['version'] == IDENTITY, 'OFFLINE_OWNER_VERSION')
    salt, nonce = o.unb64(value['salt'], 16), o.unb64(value['nonce'], 12)
    c.need(len(salt) == 16 and len(nonce) == 12, 'OFFLINE_OWNER_PARAMETERS')
    try:
        raw = o.transport_cipher()(_password_key(password, salt)).decrypt(nonce,
            o.unb64(value['ciphertext'], 2048), IDENTITY.encode('ascii'))
    except Exception as exc:
        raise ValueError('OFFLINE_OWNER_PASSWORD_OR_AUTHENTICATION') from exc
    record = o.exact_load(raw, 2048); c.exact(record, 'signing_secret storage_key scope')
    for field in record:
        c.key(record[field])
    return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(record['signing_secret'])), bytes.fromhex(record['storage_key']), record['scope']


def _transport_key(path):
    # Separately provisioned random 32-byte shared key; never read from a packet.
    c.need(not Path(path).is_symlink() and stat.S_IMODE(Path(path).stat().st_mode)&0o077 == 0,
           'OFFLINE_PRIVATE_TRANSPORT_KEY')
    raw = carriers.read_file(path, limit=64)
    c.need(len(raw) == 32, 'OFFLINE_KEY_32_BYTES')
    return raw


def load_input(path, *, shared_key, scope):
    """JSON stays JSON. A JPEG, or any other bytes, becomes an evidence attachment."""
    raw = carriers.read_file(path, limit=o.MAX_PAYLOAD)
    try:
        if raw[:1] in (b'{', b'['):
            return c.loads(raw)
    except (ValueError, UnicodeError, json.JSONDecodeError):
        pass
    media = 'image/jpeg' if raw[:3] == b'\xff\xd8\xff' else 'application/octet-stream'
    return o.evidence_attachment(raw, key=shared_key, scope=scope, media_type=media)


def parser():
    p = argparse.ArgumentParser(description='Offline Covenant: exact agreements, encrypted custody and explicit delivery.')
    p.add_argument('directory', help='Owner private custody directory')
    p.add_argument('--retained-head', help='Independent retained vault checkpoint to refuse an older copy')
    p.add_argument('--password-file', help='UTF-8 password file. The trailing newline is not part of the password.')
    sub = p.add_subparsers(dest='action', required=True)
    init = sub.add_parser('init'); init.add_argument('--scope', required=True)
    sub.add_parser('status')
    show = sub.add_parser('agreement'); show.add_argument('--id', required=True)
    cached = sub.add_parser('cache'); cached.add_argument('--input', required=True)
    cached.add_argument('--expected-id', required=True)
    d = sub.add_parser('draft')
    d.add_argument('--terms', required=True, help='Exact JSON terms file (text or structured object)')
    d.add_argument('--party', action='append', required=True); d.add_argument('--expires', type=int, required=True)
    d.add_argument('--previous'); d.add_argument('--out', required=True)
    s = sub.add_parser('sign'); s.add_argument('--agreement', required=True)
    s.add_argument('--expected-id', required=True); s.add_argument('--out', required=True)
    e = sub.add_parser('seal'); e.add_argument('--kind', choices=sorted(o.KINDS), required=True)
    e.add_argument('--input', required=True); e.add_argument('--recipient', required=True)
    e.add_argument('--shared-key-file', required=True); e.add_argument('--expires', type=int, required=True)
    i = sub.add_parser('import'); i.add_argument('--input', required=True)
    i.add_argument('--sender', action='append', required=True); i.add_argument('--shared-key-file')
    i.add_argument('--relay', action='store_true')
    for name in ('export', 'ack', 'qr'):
        cmd = sub.add_parser(name); cmd.add_argument('--id', required=True)
        cmd.add_argument('--out', required=True, help='New file; QR uses a new directory')
    a = sub.add_parser('accept-ack'); a.add_argument('--id', required=True); a.add_argument('--input', required=True)
    scan = sub.add_parser('scan'); scan.add_argument('--image', required=True); scan.add_argument('--out', required=True)
    send = sub.add_parser('send-local'); send.add_argument('--id', required=True)
    send.add_argument('--host', required=True); send.add_argument('--port', type=int, required=True)
    recv = sub.add_parser('receive-local'); recv.add_argument('--bind', default='127.0.0.1')
    recv.add_argument('--port', type=int, required=True); recv.add_argument('--sender', action='append', required=True)
    recv.add_argument('--shared-key-file'); recv.add_argument('--relay', action='store_true')
    return p


def run(args, *, password):
    if args.action == 'init':
        return initialize(args.directory, scope=scope_key(args.scope), password=password)
    signing, storage, scope = load_identity(args.directory, password=password)
    owner = c.public_key(signing); now = int(time.time())
    vault = OfflineStore(Path(args.directory)/'vault', owner=owner, scope=scope, storage_key=storage,
                         retained_head=args.retained_head)
    try:
        action = args.action
        if action == 'status':
            return {**vault.overview(now=now), 'retained_head': vault.checkpoint()}
        if action == 'agreement':
            return vault.agreement(args.id, now=now)
        if action == 'cache':
            value = o.exact_load(carriers.read_file(args.input)); c.exact(value, 'agreement assents')
            return vault.cache_agreement(**value, expected_id=args.expected_id, now=now)
        if action == 'draft':
            terms = c.loads(carriers.read_file(args.terms, limit=32768))
            agreement = o.draft(scope=scope, parties=sorted(set(args.party)), terms=terms,
                valid_from=now, valid_until=args.expires, nonce=secrets.token_hex(32), previous=args.previous)
            ref = o.agreement_id(agreement)
            vault.cache_agreement(agreement, [], expected_id=ref, now=now)
            carriers.write_file(args.out, c.canonical({'agreement': agreement, 'assents': []}))
            return {'id': ref, 'status': 'AWAITING_SIGNATURES'}
        if action == 'sign':
            value = o.exact_load(carriers.read_file(args.agreement)); c.exact(value, 'agreement assents')
            o.review(**value, expected_id=args.expected_id, now=now)
            c.need(value['agreement']['scope'] == scope and
                   value['agreement']['valid_from'] <= now < value['agreement']['valid_until'],
                   'OFFLINE_SIGNING_SCOPE_WINDOW')
            signed = o.assent(value['agreement'], signing)
            supplied = [a for a in value['assents'] if a['signer'] != owner]+[signed]
            vault.cache_agreement(value['agreement'], supplied, expected_id=args.expected_id, now=now)
            merged = vault.agreement(args.expected_id, now=now)
            carriers.write_file(args.out, c.canonical({k: merged[k] for k in ('agreement', 'assents')}))
            return merged['review']
        if action == 'seal':
            shared = _transport_key(args.shared_key_file)
            value = load_input(args.input, shared_key=shared, scope=scope)
            packet = o.seal(args.kind, value, signing_key=signing, recipient=args.recipient,
                shared_key=shared, scope=scope, created=now, expires=args.expires)
            ref = vault.enqueue(packet, now=now)
            return vault.status(ref, now=now)
        if action in ('import', 'receive-local'):
            shared = _transport_key(args.shared_key_file) if args.shared_key_file else None
            def retain(raw):
                packet = o.exact_load(raw)
                return vault.retain(packet, allowed_senders=set(args.sender), now=int(time.time()),
                                    shared_key=shared, relay=args.relay)
            if action == 'import':
                ref = retain(carriers.read_file(args.input))
            else:
                bind = carriers._address(args.bind)
                c.need(type(args.port) is int and 1 <= args.port <= 65535, 'OFFLINE_LOCAL_POLICY')
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                    listener.bind((bind, args.port)); listener.listen(1)
                    ref = carriers.receive_local(listener, retain, timeout=10)
            if not args.relay:
                vault.note_carried_agreement(ref, now=int(time.time()))
            return vault.status(ref, now=int(time.time()))
        if action == 'scan':
            frame = carriers.scan_qr(carriers.read_file(args.image, limit=2*1024*1024))
            raw = vault.ingest_frame(frame, now=now)
            if raw is None:
                return {'status': 'AWAITING_FRAGMENTS', 'packet_verified': False}
            o.exact_load(raw)  # Byte reconstruction alone does not authenticate the peer.
            carriers.write_file(args.out, raw)
            return {'status': 'REASSEMBLED', 'packet_verified': False, 'next': 'import with independent sender/key pins'}
        if action == 'accept-ack':
            return vault.acknowledge(args.id, o.exact_load(carriers.read_file(args.input)))
        value = vault.packet(args.id); packet = value['packet']; raw = c.canonical(packet)
        if action == 'export':
            carriers.write_file(args.out, raw)
        elif action == 'ack':
            c.need(value['direction'] == 'IN' and value.get('payload') is not None, 'OFFLINE_ACK_REQUIRES_CUSTODY')
            carriers.write_file(args.out, c.canonical(o.delivery_ack(packet, signing, at=now)))
        elif action == 'qr':
            # A new directory avoids overwriting prior exports.
            path = Path(args.out); path.mkdir(mode=0o700)
            parts = carriers.frames(raw, mtu=900)
            for index, frame in enumerate(parts):
                carriers.write_file(path/f'{index:04d}.png', carriers.qr_png(frame))
            return {'status': 'QR_EXPORTED', 'images': len(parts), 'delivery': 'AWAITING_DELIVERY'}
        elif action == 'send-local':
            vault.record_attempt(args.id, now=now)
            return carriers.send_local(raw, host=args.host, port=args.port)
        return {'id': args.id, 'status': 'EXPORTED', 'ledger_confirmed': False}
    finally:
        vault.close()


_CODE = re.compile(r'[A-Z][A-Z0-9_]{0,80}\Z')


def prompt_password(text):
    """getpass on an interactive stdin; otherwise one bounded line of stdin, never /dev/tty.

    getpass reads the controlling terminal even when stdin is a pipe or closed.
    """
    stream = sys.stdin
    try:
        interactive = stream is not None and stream.isatty()
    except (AttributeError, ValueError, OSError):
        interactive = False
    if interactive:
        return getpass.getpass(text)
    line = stream.readline(1026) if stream is not None else ''
    c.need(line != '', 'OFFLINE_PASSWORD_REQUIRED')
    return line[:-1] if line.endswith('\n') else line


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.password_file:
            raw = Path(args.password_file).read_text(encoding='utf-8')
            password = raw[:-1] if raw.endswith('\n') else raw
        else:
            password = prompt_password('Offline custody password: ')
            if args.action == 'init':
                c.need(password == prompt_password('Repeat password: '), 'OFFLINE_PASSWORD_MISMATCH')
        result = run(args, password=password)
        print(c.canonical(result).decode('ascii'))
        return 0
    except (ValueError, EOFError, OSError) as exc:
        reason = str(exc)
        if _CODE.fullmatch(reason) is None:
            reason = 'OFFLINE_INPUT' if not isinstance(exc, EOFError) else 'OFFLINE_PASSWORD_REQUIRED'
        print(c.canonical({'status': 'REFUSED', 'reason': reason, 'execution_authorized': False}).decode('ascii'))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
