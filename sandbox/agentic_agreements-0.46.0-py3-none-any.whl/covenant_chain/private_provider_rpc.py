"""Account-scoped owner SDK for provider 0.2; no full-history client transfer.

Transport uses the existing pinned DNS/TLS/size/deadline implementation. This
protocol owns its unbounded SQLite intent/checkpoint journal rather than the
generic transport harness's bounded trial event ledger. Exact signed command
IDs make explicit cross-endpoint retries safe for this inventory protocol only.
"""
from copy import deepcopy
from collections import deque
import base64
import secrets
import time

from . import crypto as c, private_provider as p
from . import resource_provider
from .connector_harness import ConnectorHarness
from .agent_tools import decode
from .adapters import manifest_id
from .provider_replica_rpc import ReplicaService, _token, _endpoint
from .provider_connector import ProviderAdapter
from .workflow_store import WorkflowStore,canonical,identifier


class PrivateProviderClient:
    def __init__(self,directory,*,context,endpoints,token,wallet,controller,epoch,lease_expires,clock,
                 allow_insecure_loopback=False,timeout=10,minimum_checkpoint=None):
        self.context = p.public_context(context); _token(token); c.key(wallet); c.integer(epoch); c.integer(lease_expires)
        c.need(callable(clock) and type(timeout) in (int,float) and 0 < timeout <= 30,'PRIVATE_PROVIDER_CLIENT_CONFIG')
        c.need(type(endpoints) is dict and 1 <= len(endpoints) <= len(self.context['validators']) and
               set(endpoints) <= set(self.context['validators']),'PRIVATE_PROVIDER_CLIENT_ENDPOINTS')
        if minimum_checkpoint is not None: p._checkpoint(minimum_checkpoint)
        self.provider = self.context['provider']; self.wallet = wallet; self.controller = controller
        self.epoch = epoch; self.lease_expires = lease_expires; self.clock = clock; self.timeout = timeout
        self._pin = identifier('COVENANT-PRIVATE-PROVIDER-CLIENT-0.2',{'context':self.context,'wallet':wallet})
        self.store = WorkflowStore(directory,{'scope':self._pin,'minimum_checkpoint':minimum_checkpoint})
        self.store.db.execute('CREATE TABLE IF NOT EXISTS private_intents (id TEXT PRIMARY KEY, command BLOB NOT NULL, state TEXT NOT NULL, proof BLOB)')
        if 'proof' not in {row[1] for row in self.store.db.execute('PRAGMA table_info(private_intents)')}:
            self.store.db.execute('ALTER TABLE private_intents ADD COLUMN proof BLOB')
        self.store.db.execute('CREATE TABLE IF NOT EXISTS private_checkpoints (sequence INTEGER PRIMARY KEY, previous TEXT NOT NULL, id TEXT UNIQUE NOT NULL, body BLOB NOT NULL)')
        self._sequence = 0; self._event_head = resource_provider.ZERO; self._checkpoint = deepcopy(minimum_checkpoint)
        self.last_errors = deque(maxlen=32)
        self._read_checkpoints()
        routes = {}
        for who,endpoint in endpoints.items():
            u = _endpoint(endpoint,allow_insecure_loopback)
            routes[who] = {'origin':u.scheme+'://'+u.netloc,'methods':['POST'],'path_prefix':'/replica/command',
                'headers':{'Content-Type':'application/json','Authorization':'Bearer '+token}}
        self.routes = tuple(routes)
        self.transport = ConnectorHarness(self.store.directory/'transport',http_routes=routes,timeout=.5,
                                          max_request_bytes=700000,max_response_bytes=1000000)

    def _read_checkpoints(self):
        for seq,previous,ref,raw in self.store.db.execute('SELECT sequence,previous,id,body FROM private_checkpoints WHERE sequence>? ORDER BY sequence',(self._sequence,)):
            body = decode(raw)
            c.need(seq == self._sequence+1 and previous == self._event_head and ref == identifier('PRIVATE-PROVIDER-CLIENT-CHECKPOINT-0.2',{'sequence':seq,'previous':previous,'body':body}),'PRIVATE_PROVIDER_CLIENT_JOURNAL')
            c.exact(body,'checkpoint floor')
            self._checkpoint = p.verify_checkpoint(body['checkpoint'],context=self.context,minimum_checkpoint=self._checkpoint,floor=body['floor'])
            self._sequence,self._event_head = seq,ref

    def checkpoint(self):
        with self.store.exclusive():
            self._read_checkpoints(); return deepcopy(self._checkpoint)

    def prepare(self,operation,parameters,*,nonce=None,ttl=30):
        c.integer(ttl,True); c.need(ttl<=300,'PRIVATE_PROVIDER_CLIENT_TTL'); now = self.clock(); c.integer(now)
        return p.draft_command(self.context,self.wallet,c.public_key(self.controller),self.epoch,operation,parameters,now,now+ttl,nonce or secrets.token_hex(32))

    def pending(self,*,after='',limit=32):
        """Private owner view: saved signed envelopes, never a public read tool."""
        c.integer(limit,True); c.need(limit<=128,'PRIVATE_PROVIDER_PENDING_PAGE')
        if after: c.key(after)
        return [{'request':cid,'envelope':decode(raw),'state':state} for cid,raw,state in self.store.db.execute(
            'SELECT id,command,state FROM private_intents WHERE state=? AND id>? ORDER BY id LIMIT ?',('UNKNOWN',after,limit))]

    def retry(self,request_id):
        """Explicit owner retry of the original envelope, without a new nonce."""
        c.key(request_id); row = self.store.db.execute('SELECT command FROM private_intents WHERE id=?',(request_id,)).fetchone()
        c.need(row is not None,'PRIVATE_PROVIDER_INTENT_MISSING'); envelope = decode(row[0])
        c.need(resource_provider.command_id(p.verify_command(envelope,self.context)) == request_id,'PRIVATE_PROVIDER_INTENT_CHANGED')
        return self.send(envelope)

    def saved_receipt(self,request_id):
        """Historical selected evidence retained locally even during outage."""
        c.key(request_id); row = self.store.db.execute('SELECT proof FROM private_intents WHERE id=?',(request_id,)).fetchone()
        if row is None or row[0] is None: return None
        proof = decode(row[0]); floor = proof['floor']['value'] if proof['floor'] is not None else None
        p.verify_receipt(proof,context=self.context,expected_wallet=self.wallet,expected_request=request_id,minimum_checkpoint=floor)
        return proof

    def send(self,envelope):
        c.need(self._pin == identifier('COVENANT-PRIVATE-PROVIDER-CLIENT-0.2',{'context':self.context,'wallet':self.wallet}) and self.provider == self.context['provider'],'PRIVATE_PROVIDER_CLIENT_SCOPE_CHANGED')
        command = p.verify_command(envelope,self.context); cid = resource_provider.command_id(command)
        c.need(command['wallet'] == self.wallet,'PRIVATE_PROVIDER_CLIENT_SCOPE')
        with self.store.exclusive():
            raw = canonical(envelope); prior = self.store.db.execute('SELECT command FROM private_intents WHERE id=?',(cid,)).fetchone()
            c.need(prior is None or canonical(decode(prior[0])['command']) == canonical(command),'PRIVATE_PROVIDER_INTENT_CHANGED')
            self.store.db.execute('INSERT OR IGNORE INTO private_intents(id,command,state) VALUES (?,?,?)',(cid,raw,'UNKNOWN'))
        deadline = time.monotonic()+self.timeout
        while time.monotonic()<deadline:
            for who in self.routes:
                if time.monotonic()>=deadline: break
                floor = self.checkpoint()
                payload = {'envelope':envelope,'minimum_checkpoint':floor}
                params = {'path':'/replica/command','method':'POST','body_base64':base64.b64encode(canonical(payload)).decode('ascii')}
                request = {'protocol':'HTTP','operation':who,'parameters':params}
                try:
                    # Intent above commits before dispatch. This protocol owns
                    # retry semantics; _http only performs the adopted bounded
                    # transport and does not impose a lifetime harness quota.
                    self.transport.validate_request(request)
                    c.need(manifest_id(self.transport.manifest) == self.transport.ref,'PRIVATE_PROVIDER_TRANSPORT_CHANGED')
                    response = self.transport._http(who,params)
                    if response['status'] != 200:
                        if response['status'] != 202:self.last_errors.append('HTTP_'+str(response['status']))
                        continue
                    result = decode(base64.b64decode(response['body_base64'],validate=True))
                    p.verify_receipt(result,command,context=self.context,minimum_checkpoint=floor)
                    with self.store.exclusive():
                        self._read_checkpoints()
                        # Another local client may advance while this request is
                        # in flight; ask again from that stronger floor.
                        if self._checkpoint != floor: continue
                        checkpoint = p.verify_certificate(self.context,result['checkpoint'])
                        if checkpoint != floor:
                            body = {'checkpoint':result['checkpoint'],'floor':result['floor']}
                            seq = self._sequence+1; ref = identifier('PRIVATE-PROVIDER-CLIENT-CHECKPOINT-0.2',{'sequence':seq,'previous':self._event_head,'body':body})
                            self.store.db.execute('BEGIN IMMEDIATE')
                            try:
                                self.store.db.execute('INSERT INTO private_checkpoints VALUES (?,?,?,?)',(seq,self._event_head,ref,canonical(body)))
                                self.store.db.execute('UPDATE private_intents SET state=?,proof=? WHERE id=?',('OBSERVED',canonical(result),cid)); self.store.db.execute('COMMIT')
                            except BaseException:
                                if self.store.db.in_transaction:self.store.db.execute('ROLLBACK')
                                raise
                            self._sequence,self._event_head,self._checkpoint = seq,ref,checkpoint
                        else:self.store.db.execute('UPDATE private_intents SET state=?,proof=? WHERE id=?',('OBSERVED',canonical(result),cid))
                    return result
                except Exception as exc:
                    import re
                    message = str(exc)
                    self.last_errors.append(message if re.fullmatch('[A-Za-z][A-Za-z0-9_]{0,95}',message) else type(exc).__name__)
                    # No response, malformed proof or a stale peer is never a
                    # negative settlement. Only exact-envelope retries follow.
                    continue
            time.sleep(.025)
        raise ValueError('PRIVATE_PROVIDER_OUTCOME_UNKNOWN')

    def call(self,operation,parameters):
        draft = self.prepare(operation,parameters)
        return self.send({'cluster':draft['cluster'],'command':draft['command'],
                          'signature':c.sign(self.controller,draft['label'],draft['body'])})

    def close(self):
        self.transport.close(); self.store.close()


class PrivateProviderAdapter(ProviderAdapter):
    def __init__(self,client,*,hold_seconds=30):
        super().__init__(client,hold_seconds=hold_seconds)
        self._cluster = client.context['cluster']
        self.manifest['instance'] = identifier('COVENANT-PRIVATE-PROVIDER-ADAPTER-0.2',
            {'cluster':self._cluster,'provider':client.provider,'wallet':client.wallet,'hold_seconds':hold_seconds})
        self.manifest['privacy'] = ['ACCOUNT_SCOPED_INCLUSION_PROOFS','VALIDATORS_SEE_PLAINTEXT']
        self.manifest['requirements']['resources'] = 'QUORUM_VALIDATED_PRIVATE_PROVIDER_INVENTORY'

    def observe(self,effect_id):
        c.need(self.client.context['cluster'] == self._cluster,'PRIVATE_PROVIDER_ADAPTER_SCOPE_CHANGED')
        return super().observe(effect_id)
