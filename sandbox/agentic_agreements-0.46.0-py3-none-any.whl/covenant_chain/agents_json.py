"""agents.json flows and an OpenAPI 3.1 document describing AAP's tools over HTTP.

agents.json 0.1.0 (wild-card-ai/agents-json, MIT; schema
agents_json/agentsJson.schema.json) describes multi-step API flows over
OpenAPI operations: ``sources`` name OpenAPI documents, each flow lists
``actions`` by ``operationId`` and ``links`` that carry a flow input
(``parameters.``/``requestBody.`` paths on the flow id) or an earlier action's
``responses.success.`` value into a later action. The file is conventionally
served at ``/.well-known/agents.json``.

The OpenAPI document here gives every installed AAP tool one operation,
``POST /aap/tools/{tool}``, whose request body is the tool's exact input
schema; covenant_chain.agent_protocol serves those routes through the same MCP
host, so validation and refusals are identical to an MCP tools/call. Both
documents are descriptions, not permissions: they never sign, pay or install.
"""
from copy import deepcopy

from .crypto import need

VERSION = 'covenant-agents-json/0.1'
AGENTS_JSON = '0.1.0'
OPENAPI = '3.1.0'
SOURCE_ID = 'aap'
WELL_KNOWN_PATH = '/.well-known/agents.json'
OPENAPI_PATH = '/openapi.json'
MODEL = ('A deal is a promise both sides sign. Proof shows it was kept. If it was not, there is a fair way to fix it. '
         'Every AAP tool is one POST operation; flows lead with finding, explaining and then calling a tool.')

FLOWS = [
    {'id': 'find_and_explain_an_action', 'title': 'Find and explain an AAP action',
     'description': 'Search the installed actions in ordinary words, then read the exact schema of the best match.',
     'tools': {'find': 'covenant_find', 'explain': 'covenant_explain'},
     'fixed': {'covenant_find': {'requestBody.action': 'search'}, 'covenant_explain': {'requestBody.action': 'action'}},
     'inputs': {'query': {'type': 'string', 'maxLength': 400, 'description': 'What you want to do, in ordinary words.'}},
     'links': [(None, 'requestBody.query', 'find', 'requestBody.parameters.query'),
               ('find', 'responses.success.matches.0.id', 'explain', 'requestBody.parameters.id')]},
    {'id': 'guided_call', 'title': 'Guided first call',
     'description': 'Ask the onboarding guide for the exact next call for a task, then make that call. '
                    'A call that needs a signature or payment still needs the owner\'s key and approval.',
     'tools': {'guide': 'covenant_onboard', 'call': 'covenant_call'},
     'fixed': {'covenant_onboard': {'requestBody.action': 'guide'}},
     'inputs': {'query': {'type': 'string', 'maxLength': 400, 'description': 'The request in ordinary words.'},
                'task': {'type': 'string', 'maxLength': 80, 'description': 'A task id from the guide, when known.'},
                'parameters': {'type': 'object', 'description': 'Known values for the task.'}},
     'links': [(None, 'requestBody.query', 'guide', 'requestBody.parameters.query'),
               (None, 'requestBody.task', 'guide', 'requestBody.parameters.task'),
               (None, 'requestBody.parameters', 'guide', 'requestBody.parameters.parameters'),
               ('guide', 'responses.success.next_call', 'call', 'requestBody')]},
]


def _tools(host_tools):
    rows = host_tools.list_tools() if hasattr(host_tools, 'list_tools') else host_tools
    need(type(rows) is list and rows, 'AGENTS_JSON_TOOLS')
    return {row['name']: row for row in rows}


def openapi(host_tools, base_url):
    """One POST operation per installed tool, request body = the tool's exact input schema."""
    need(type(base_url) is str and base_url.startswith(('http://', 'https://')) and len(base_url) <= 2048, 'AGENTS_JSON_URL')
    paths = {}
    for name, tool in sorted(_tools(host_tools).items()):
        paths['/aap/tools/' + name] = {'post': {
            'operationId': name, 'summary': tool.get('description', '')[:300],
            'requestBody': {'required': True, 'content': {'application/json': {'schema': deepcopy(tool['inputSchema'])}}},
            'responses': {'200': {'description': 'The MCP tools/call result: content, structuredContent and isError. '
                                                 'A refusal is a result with isError true, a code and a fix.',
                                  'content': {'application/json': {'schema': {'type': 'object'}}}},
                          '404': {'description': 'No such installed tool.'},
                          '422': {'description': 'The body is not one JSON object within the size limit.'}}}}
    return {'openapi': OPENAPI, 'info': {'title': 'Agentic Agreements Protocol (AAP) tools', 'version': VERSION,
                                         'description': MODEL},
            'servers': [{'url': base_url.rstrip('/')}], 'paths': paths}


def document(host_tools, openapi_url):
    """agents.json 0.1.0 for the installed tools; flows whose tools are absent are left out."""
    need(type(openapi_url) is str and openapi_url.startswith(('http://', 'https://')), 'AGENTS_JSON_URL')
    installed = _tools(host_tools)
    flows, overrides = [], {}
    for spec in FLOWS:
        if not set(spec['tools'].values()) <= set(installed):
            continue
        for operation, fields in spec['fixed'].items():
            for path, value in fields.items():
                overrides[(operation, path)] = value
        links = [{'origin': {'actionId': spec['id'] if origin is None else origin, 'fieldPath': source},
                  'target': {'actionId': target, 'fieldPath': field}} for origin, source, target, field in spec['links']]
        flows.append({'id': spec['id'], 'title': spec['title'], 'description': spec['description'],
                      'actions': [{'id': action, 'sourceId': SOURCE_ID, 'operationId': operation}
                                  for action, operation in spec['tools'].items()],
                      'links': links,
                      'fields': {'parameters': [],
                                 'requestBody': {'required': True, 'content': {'application/json': {'schema': {
                                     'type': 'object', 'properties': deepcopy(spec['inputs'])}}}},
                                 'responses': {'success': {'type': 'object',
                                                           'description': 'The last action\'s result; data, never authority.'}}}})
    return {'agentsJson': AGENTS_JSON,
            'info': {'title': 'Agentic Agreements Protocol (AAP)', 'version': AGENTS_JSON, 'description': MODEL},
            'sources': [{'id': SOURCE_ID, 'path': openapi_url}],
            'overrides': [{'sourceId': SOURCE_ID, 'operationId': operation, 'fieldPath': path, 'value': value}
                          for (operation, path), value in sorted(overrides.items())],
            'flows': flows}


def validate(value, openapi_document):
    """Structural agents.json 0.1.0 checks plus every reference resolving in the OpenAPI document."""
    need(type(value) is dict and {'agentsJson', 'info', 'sources', 'flows'} <= set(value), 'AGENTS_JSON_SHAPE')
    need(type(value['info']) is dict and all(type(value['info'].get(k)) is str for k in ('title', 'version', 'description')),
         'AGENTS_JSON_SHAPE')
    sources = {row['id'] for row in value['sources'] if type(row) is dict and type(row.get('path')) is str}
    need(sources == {SOURCE_ID} and len(value['sources']) == 1, 'AGENTS_JSON_SHAPE')
    operations = {op['operationId'] for path in openapi_document['paths'].values() for op in path.values()}
    for row in value.get('overrides', []):
        need(set(row) == {'sourceId', 'operationId', 'fieldPath', 'value'} and row['sourceId'] in sources
             and row['operationId'] in operations, 'AGENTS_JSON_REFERENCE')
    for flow in value['flows']:
        need({'id', 'title', 'description', 'actions', 'fields'} <= set(flow) and
             {'parameters', 'responses'} <= set(flow['fields']) and 'success' in flow['fields']['responses'], 'AGENTS_JSON_SHAPE')
        actions = {action['id'] for action in flow['actions']}
        need(len(actions) == len(flow['actions']) and all(action['sourceId'] in sources and action['operationId'] in operations
                                                          for action in flow['actions']), 'AGENTS_JSON_REFERENCE')
        for link in flow.get('links', []):
            need(set(link) == {'origin', 'target'}, 'AGENTS_JSON_SHAPE')
            origin, target = link['origin'], link['target']
            need(origin.get('actionId') in actions | {flow['id'], None} and target.get('actionId') in actions | {None},
                 'AGENTS_JSON_REFERENCE')
            if origin.get('actionId') in actions:
                need(origin['fieldPath'].startswith('responses.success'), 'AGENTS_JSON_REFERENCE')
            else:
                need(origin['fieldPath'].startswith(('parameters', 'requestBody')), 'AGENTS_JSON_REFERENCE')
            need(target['fieldPath'].startswith(('parameters', 'requestBody')), 'AGENTS_JSON_REFERENCE')
    return True


def describe():
    return {'version': VERSION, 'agents_json': AGENTS_JSON, 'openapi': OPENAPI, 'well_known_path': WELL_KNOWN_PATH,
            'openapi_path': OPENAPI_PATH, 'flows': [flow['id'] for flow in FLOWS],
            'operation': 'POST /aap/tools/{tool}: request body = the tool input schema',
            'authority': 'DESCRIPTION_ONLY; NO_SIGNATURE_PAYMENT_OR_INSTALLATION', 'network_accessed': False}
