"""Pinned-history gate for a real local file effect; no remote credential support."""
import hashlib
from .crypto import need,digest,verify
from .proofs import verify_history
from .app import controller
from covenant_language.handoff import FileOutbox
LABEL='COVENANT-FILE-GATE-0.1'

class FileGate:
    def __init__(self,directory,genesis,expected_chain,minimum_height):
        self.outbox=FileOutbox(directory);self.genesis=genesis;self.chain=expected_chain;self.minimum_height=minimum_height
    def execute(self,history,job_id,payload,signature,*,crash=None):
        report=verify_history(self.genesis,history,self.chain,self.minimum_height);s=report['state']
        if job_id in s.get('service_jobs',{}):
            job=s['service_jobs'][job_id];service=s['service_offers'][job['offer']]
            need(job['state']=='BOOKED' and report['height']<=job['deadline'],'GATE_JOB_NOT_LIVE')
            if job_id in s.get('review_jobs',{}):
                review=s['review_cases'][s['review_jobs'][job_id]]
                need(review['status']=='READY','GATE_REVIEW_PENDING')
        else:
            need('world_jobs' in s and job_id in s['world_jobs'],'GATE_JOB')
            job=s['world_jobs'][job_id];service=s['world_services'][job['service']]
            need(job['state']=='OPEN' and report['height']<=job['deadline'],'GATE_JOB_NOT_LIVE')
        need(service['capability']=='file.publish','GATE_CAPABILITY')
        content=hashlib.sha256(payload).hexdigest();need(content==service['terms'],'GATE_CONTENT')
        body={'chain':self.chain,'job':job_id,'content':content}
        verify(controller(s,job['provider']),LABEL,body,signature)
        # The gate selects the path; caller content can never choose a destination.
        effect=digest(LABEL,body);self.outbox.enqueue(effect,payload)
        return {'effect':effect,'result':self.outbox.run(effect,crash=crash),'content':content,'verified_height':report['height']}
    def close(self):self.outbox.close()
