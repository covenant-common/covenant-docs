"""Python commands for a covenant-evidence/0.1 envelope.

``seal_file`` hashes a photograph or video into the byte store and signs an
envelope that carries the hash, an optional thumbnail hash, and a fixed-point
GPS fix. The file itself is not a field of the envelope. ``execution_authorized``
stays false: a level such as L0 changes the release recommendation only.
"""
import base64
import binascii
from copy import deepcopy
from pathlib import Path

from .aggregation import recommend_release, resolve_policy
from .crypto import canonical, key, need
from .evidence import BYTES_PROFILE, ENVELOPE_MAX, VERSION, blob_descriptor, seal, show_payload
from .evidence_grade import envelope_assurance
from .evidence_store import EvidenceStore
from .geo_fix import exif_jpeg, exif_tiff, fix, normalize_claim, parse_decimal, parse_geo_uri, parse_nmea

EXHIBIT_FIELDS = frozenset(('kind', 'version', 'agreement', 'content_hash', 'media_type', 'blob_sha256', 'bytes',
                            'exif', 'gps', 'assurance', 'signer'))
TOOL_FIELDS = {'spec': (set(), set()), 'release': ({'readings'}, {'policy'}),
               'reference': ({'media_type', 'sha256', 'bytes'}, set()),
               'agreement': ({'agreement', 'photos'}, set()), 'dispute': ({'agreement', 'photos', 'cited'}, set()),
               'gps': (set(), {'lat', 'lon', 'nmea', 'geo', 'exif_base64'})}


def spec():
    return {'version': 'covenant-evidence/0.1', 'bytes_profile': BYTES_PROFILE,
            'placement': 'ERASURE', 'envelope_max_bytes': ENVELOPE_MAX,
            'photo_bytes': 'STORED_BY_HASH_OUTSIDE_THE_ENVELOPE',
            'thumbnail': 'OPTIONAL_HASH',
            'gps': ['DECIMAL', 'EXIF', 'NMEA', 'GEO_URI'],
            'levels': {'L0': 'one source may recommend release_bps', 'L1': 'template default withholds that recommendation',
                       'L2': 'two readings before the recommendation', 'L3': 'two readings, shortfall routes to a panel'},
            'photo': 'submit_jpeg or covenant_evidence.photo seals image/jpeg as this envelope',
            'views': ['agreement_view', 'dispute_view'],
            'assurance': ['SELF_ASSERTED', 'PARTY_SIGNED', 'THIRD_PARTY_SIGNED', 'CRYPTOGRAPHICALLY_VERIFIED'],
            'grader': 'evidence_grade.grade pays only the assurance the policy accepts; quorum 1 is a single source',
            'protocol_gate': False, 'execution_authorized': False}


def _store(store):
    return store if isinstance(store, EvidenceStore) else EvidenceStore(store)


def _media(path, media_type):
    if media_type is not None:
        return media_type
    suffix = Path(path).suffix.lower()
    if suffix in {'.jpg', '.jpeg'}:
        return 'image/jpeg'
    if suffix in {'.mp4', '.mov'}:
        return 'video/mp4'
    return 'application/octet-stream'


def seal_file(path, store, private_key, agreement, context, adapter, *, claim_field='sacks_photographed', claim_value=True,
              confidence_bps=8000, observed_at=None, reported_at=None, policy=None, thumbnail=None, media_type=None,
              source_class_name=None):
    """Seal a hash reference. ``path`` is read into the store, not into the envelope."""
    try:
        raw_path = Path(path)
        media = _media(raw_path, media_type)
        with raw_path.open('rb') as handle:
            raw = handle.read()
    except (OSError, TypeError, ValueError):
        raise ValueError('EVIDENCE_FILE') from None
    placed = _store(store).put_bytes(raw, media, thumbnail)
    point = None
    pictured_at = None
    if media == 'image/jpeg':
        try:
            point, pictured_at = exif_jpeg(raw)
        except ValueError as exc:
            if str(exc) != 'GEO_EXIF':
                raise
    when = pictured_at if observed_at is None else observed_at
    need(type(when) is int, 'EVIDENCE_TIME')
    reported = when if reported_at is None else reported_at
    kind = source_class_name or ('IMAGE' if media.startswith('image/') else 'VIDEO' if media.startswith('video/') else 'DOCUMENT')
    carrier = {'profile': BYTES_PROFILE, 'placement': 'ERASURE', 'manifest': placed['manifest'], 'thumbnail': placed['thumbnail']}
    sealed = seal(private_key, agreement, context, adapter, kind,
                  blob_descriptor(media, sha256=placed['sha256'], nbytes=placed['bytes']),
                  {'field': claim_field, 'value': claim_value}, when, reported, [], confidence_bps,
                  {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []}, carrier, point)
    wire = canonical(sealed['envelope'])
    need(raw not in wire and len(wire) <= ENVELOPE_MAX, 'EVIDENCE_ENVELOPE_SIZE')
    reading = {'confidence_bps': confidence_bps, 'independence_key': adapter, 'source_class': kind, 'adapter': adapter}
    resolved = resolve_policy(policy)
    return {**sealed, 'gps': point, 'observed_at': when, 'clock': 'EXIF_UTC_ASSUMED' if observed_at is None and pictured_at is not None else 'CALLER',
            'store_manifest': placed['manifest'], 'thumbnail': placed['thumbnail'], 'policy': resolved,
            'release': recommend_release([reading], policy), 'photo_bytes_in_envelope': False}


def _keys(values, code):
    need(type(values) in (list, tuple) and len(values) <= 8, code)
    for value in values:
        key(value)
    return list(values)


def _exif_app1(raw):
    """Return the TIFF inside an Exif APP1 segment, or None when the JPEG has none."""
    if type(raw) is not bytes or len(raw) < 4 or raw[:2] != b'\xff\xd8':
        return None
    index = 2
    while index + 4 <= len(raw) and raw[index] == 0xFF:
        marker = raw[index + 1]
        if marker in (0xDA, 0xD9):
            return None
        if marker == 0x01 or 0xD0 <= marker <= 0xD9:
            index += 2
            continue
        length = int.from_bytes(raw[index + 2:index + 4], 'big')
        if length < 2 or index + 2 + length > len(raw):
            return None
        segment = raw[index + 4:index + 2 + length]
        if marker == 0xE1 and segment.startswith(b'Exif\x00\x00'):
            return segment[6:]
        index += 2 + length
    return None


def submit_jpeg(raw, private_key, agreement, context, adapter, *, store=None, parties=(), pinned_signers=(),
                claim_field='flat', claim_value=True, observed_at=None, confidence_bps=8000):
    """Seal a JPEG as covenant-evidence/0.1. The picture stays out of the envelope.

    The signer is labelled honestly: a party is ``PARTY_SIGNED``, a pinned
    non-party is ``THIRD_PARTY_SIGNED``, and anyone else is ``SELF_ASSERTED``.
    EXIF and GPS are recorded when the file has them. They do not raise the label.
    """
    need(type(raw) is bytes and raw[:2] == b'\xff\xd8' and 4 <= len(raw) <= 8_388_608, 'EVIDENCE_JPEG')
    party_keys = _keys(parties, 'EVIDENCE_PARTY')
    pinned = _keys(pinned_signers, 'EVIDENCE_PIN')
    exif_block = _exif_app1(raw)
    point = None
    pictured_at = None
    if exif_block is not None:
        try:
            point, pictured_at = exif_tiff(exif_block)
        except ValueError as exc:
            if str(exc) != 'GEO_EXIF':
                raise
    when = pictured_at if observed_at is None else observed_at
    need(type(when) is int and not type(when) is bool, 'EVIDENCE_TIME')
    if store is None:
        blob = blob_descriptor('image/jpeg', raw=raw)
        carrier = None
        manifest = None
    else:
        placed = _store(store).put_bytes(raw, 'image/jpeg')
        blob = blob_descriptor('image/jpeg', sha256=placed['sha256'], nbytes=placed['bytes'])
        carrier = {'profile': BYTES_PROFILE, 'placement': 'ERASURE', 'manifest': placed['manifest'], 'thumbnail': placed['thumbnail']}
        manifest = placed['manifest']
    sealed = seal(private_key, agreement, context, adapter, 'IMAGE', blob,
                  {'field': claim_field, 'value': claim_value}, when, when, [], confidence_bps,
                  {'mode': 'HASH_ONLY', 'commitment': None, 'recipients': []}, carrier, point)
    wire = canonical(sealed['envelope'])
    need(raw not in wire and len(wire) <= ENVELOPE_MAX, 'EVIDENCE_ENVELOPE_SIZE')
    assurance = envelope_assurance(sealed['envelope'], [], None, party_keys, pinned)
    exhibit = {'kind': 'PHOTO', 'version': VERSION, 'agreement': sealed['envelope']['agreement'],
               'content_hash': sealed['content_hash'], 'media_type': 'image/jpeg',
               'blob_sha256': sealed['envelope']['blob']['sha256'], 'bytes': sealed['envelope']['blob']['bytes'],
               'exif': exif_block is not None, 'gps': point, 'assurance': assurance,
               'signer': sealed['envelope']['signature']['signer']}
    return {**sealed, 'gps': point, 'exif': exif_block is not None, 'observed_at': when,
            'clock': 'EXIF_UTC_ASSUMED' if observed_at is None and pictured_at is not None else 'CALLER',
            'store_manifest': manifest, 'assurance': assurance, 'exhibit': exhibit,
            'agreement_view': agreement_view(agreement, [exhibit]),
            'dispute_view': dispute_view(agreement, [exhibit], []),
            'photo_bytes_in_envelope': False, 'execution_authorized': False}


def _exhibit(item):
    """Check known display metadata, preserving caller extensions as untrusted data.

    An exhibit is not a signed envelope. In particular, its assurance label and
    any extension named execution_authorized are caller claims, never authority.
    """
    if type(item) is dict and item.get('kind') == 'PHOTO':
        row = item
    elif type(item) is dict and type(item.get('exhibit')) is dict:
        row = item['exhibit']
    else:
        raise ValueError('EVIDENCE_EXHIBIT')
    need(EXHIBIT_FIELDS <= set(row), 'EVIDENCE_EXHIBIT')
    need(row['kind'] == 'PHOTO' and row['version'] == VERSION and row['media_type'] == 'image/jpeg', 'EVIDENCE_EXHIBIT')
    key(row['agreement'])
    key(row['content_hash'])
    key(row['blob_sha256'])
    key(row['signer'])
    need(type(row['bytes']) is int and row['bytes'] > 0, 'EVIDENCE_EXHIBIT')
    need(type(row['exif']) is bool and type(row['assurance']) is str and row['assurance'] in {'SELF_ASSERTED', 'PARTY_SIGNED', 'THIRD_PARTY_SIGNED', 'CRYPTOGRAPHICALLY_VERIFIED'}, 'EVIDENCE_EXHIBIT')
    gps = row['gps']
    if gps is not None:
        fields = {'version', 'lat_microdeg', 'lon_microdeg', 'scale', 'source'}
        need(type(gps) is dict and fields <= set(gps) and type(gps['source']) is str, 'EVIDENCE_EXHIBIT')
        expected = fix(gps['lat_microdeg'], gps['lon_microdeg'], gps['source'])
        need(type(gps['scale']) is int and {name: gps[name] for name in fields} == expected, 'EVIDENCE_EXHIBIT')
    return deepcopy(row)


def agreement_view(agreement, photos):
    """Group supplied photo metadata; no envelope, assurance or authority is verified."""
    key(agreement)
    need(type(photos) is list and len(photos) <= 32, 'EVIDENCE_EXHIBIT')
    rows = [row for row in (_exhibit(item) for item in photos) if row['agreement'] == agreement]
    return {'agreement': agreement, 'photo_exhibits': rows, 'execution_authorized': False}


def dispute_view(agreement, photos, cited):
    """Group cited metadata. Citation verifies neither its assurance nor world truth."""
    key(agreement)
    need(type(cited) is list and len(cited) <= 32, 'EVIDENCE_DISPUTE')
    for item in cited:
        key(item)
    chosen = set(cited)
    rows = [row for row in agreement_view(agreement, photos)['photo_exhibits'] if row['content_hash'] in chosen]
    return {'agreement': agreement, 'cited': sorted(chosen), 'photo_exhibits': rows, 'execution_authorized': False}


def tool_call(action, parameters):
    need(type(parameters) is dict, 'EVIDENCE_FIELDS')
    need(type(action) is str, 'EVIDENCE_ACTION')
    if action in TOOL_FIELDS:
        required, optional = TOOL_FIELDS[action]
        need(required <= set(parameters) <= required | optional, 'EVIDENCE_FIELDS')
    if action == 'spec':
        need(parameters == {}, 'EVIDENCE_FIELDS')
        return spec()
    if action == 'policy':
        return {**resolve_policy(parameters), 'execution_authorized': False}
    if action == 'release':
        return recommend_release(parameters['readings'], parameters.get('policy'))
    if action == 'reference':
        blob = blob_descriptor(parameters['media_type'], sha256=parameters['sha256'], nbytes=parameters['bytes'])
        return {'blob': blob, 'bytes_included': False, 'envelope_max_bytes': ENVELOPE_MAX, 'execution_authorized': False}
    if action == 'agreement':
        return agreement_view(parameters['agreement'], parameters['photos'])
    if action == 'dispute':
        return dispute_view(parameters['agreement'], parameters['photos'], parameters['cited'])
    if action == 'gps':
        chosen = [name for name in ('nmea', 'geo', 'exif_base64') if name in parameters]
        if 'lat' in parameters or 'lon' in parameters:
            chosen.append('decimal')
        need(len(chosen) == 1, 'GEO_INPUT')
        if chosen[0] == 'decimal':
            need('lat' in parameters and 'lon' in parameters, 'GEO_PAIR')
            point = parse_decimal(parameters['lat'], parameters['lon'])
        elif chosen[0] == 'nmea':
            point = parse_nmea(parameters['nmea'])
        elif chosen[0] == 'geo':
            point = parse_geo_uri(parameters['geo'])
        else:
            need(type(parameters['exif_base64']) is str, 'GEO_EXIF')
            try:
                raw = base64.b64decode(parameters['exif_base64'], validate=True)
            except (binascii.Error, ValueError):
                raise ValueError('GEO_EXIF') from None
            point, observed = exif_jpeg(raw) if raw[:2] == b'\xff\xd8' else (None, None)
            if point is None:
                from .geo_fix import exif_tiff
                point, observed = exif_tiff(raw)
            return {'fix': point, 'observed_at': observed, 'clock': 'EXIF_UTC_ASSUMED', 'claim': normalize_claim({'lat_microdeg': point['lat_microdeg'], 'lon_microdeg': point['lon_microdeg']}), 'execution_authorized': False}
        return {'fix': point, 'claim': normalize_claim({'lat': parameters['lat'], 'lon': parameters['lon']} if chosen[0] == 'decimal' else {'nmea': parameters['nmea']} if chosen[0] == 'nmea' else {'geo': parameters['geo']}), 'execution_authorized': False}
    raise ValueError('EVIDENCE_ACTION')
