"""Explicitly adopted native 0.3 recovery, promise graphs and domain succession."""
from copy import deepcopy
from .crypto import exact,need,key,integer,digest,verify,verification_key

def approved(proofs,required,threshold,label,body,resolve):
    need(type(proofs) is list and threshold<=len(proofs)<=len(required),'APPROVAL_COUNT');seen=set()
    for p in proofs:
        exact(p,'signer signature');who=p['signer'];need(who in required and who not in seen,'APPROVAL_SIGNER')
        verify(resolve(who),label,body,p['signature']);seen.add(who)

def apply(s,previous,op,p,actor,tid,height,resolve,root):
    if op=='SET_CONTROLLER_SUITE':
        exact(p,'controller possession');verification_key(p['controller'])
        body={'chain':s['chain'],'entity':actor,'nonce':previous['nonces'].get(actor,0),'controller':p['controller']}
        verify(p['controller'],'COVENANT-CONTROLLER-SUITE-0.3',body,p['possession'])
        s['controllers'][actor]=deepcopy(p['controller']);s['controller_epochs'][actor]=s['controller_epochs'].get(actor,0)+1;s['recovery_requests'][actor]=None
        return []
    if op=='SET_RECOVERY':
        exact(p,'guardians threshold delay');need(type(p['guardians']) is list and p['guardians']==sorted(set(p['guardians'])) and 1<=len(p['guardians'])<=16,'GUARDIANS')
        for who in p['guardians']:key(who);need(who!=actor,'SELF_GUARDIAN')
        integer(p['threshold'],True);integer(p['delay'],True);need(p['threshold']<=len(p['guardians']) and p['delay']<=100000,'RECOVERY_POLICY')
        s['recovery_policies'][actor]={'policy':deepcopy(p),'id':tid};s['recovery_requests'][actor]=None;return []
    if op=='REQUEST_RECOVERY':
        exact(p,'entity successor policy generation approvals possession');entity=p['entity'];key(entity);integer(p['generation']);verification_key(p['successor'])
        need(entity in s['recovery_policies'],'NO_RECOVERY_POLICY');policy=s['recovery_policies'][entity]
        need(p['policy']==policy['id'] and p['generation']==s['controller_epochs'].get(entity,0),'RECOVERY_CONTEXT')
        body={k:v for k,v in p.items() if k not in {'approvals','possession'}};body['chain']=s['chain']
        approved(p['approvals'],set(policy['policy']['guardians']),policy['policy']['threshold'],'COVENANT-RECOVERY-0.3',body,resolve)
        verify(p['successor'],'COVENANT-RECOVERY-POSSESSION-0.3',body,p['possession'])
        need(s['recovery_requests'].get(entity) is None,'RECOVERY_PENDING')
        s['recovery_requests'][entity]={'body':body,'ready':height+policy['policy']['delay'],'id':tid};return [policy['id']]
    if op=='CANCEL_RECOVERY':
        exact(p,'request');r=s['recovery_requests'].get(actor);need(r and r['id']==p['request'],'RECOVERY_REQUEST')
        s['recovery_requests'][actor]=None;return [p['request']]
    if op=='RECOVER':
        exact(p,'entity request');entity=p['entity'];key(entity);r=s['recovery_requests'].get(entity);need(r and r['id']==p['request'],'RECOVERY_REQUEST')
        need(height>=r['ready'],'RECOVERY_DELAY');need(r['body']['generation']==s['controller_epochs'].get(entity,0),'STALE_RECOVERY')
        s['controllers'][entity]=r['body']['successor'];s['controller_epochs'][entity]=r['body']['generation']+1;s['recovery_requests'][entity]=None
        return [p['request']]
    if op=='MULTI_BIND':
        exact(p,'terms assents');t=p['terms'];exact(t,'chain parties obligations meaning_hash resolver deadline')
        need(t['chain']==s['chain'],'CHAIN');key(t['meaning_hash']);key(t['resolver']);integer(t['deadline'],True);need(height<t['deadline'],'DEADLINE')
        parties=t['parties'];need(type(parties) is list and parties==sorted(set(parties)) and 2<=len(parties)<=16,'PARTIES')
        for who in parties:key(who)
        need(t['resolver'] not in parties,'RESOLVER_CONFLICT');need(actor in parties,'SUBMIT_PARTY')
        need(type(t['obligations']) is list and 1<=len(t['obligations'])<=32,'OBLIGATIONS')
        for obligation in t['obligations']:
            exact(obligation,'obligor beneficiary condition_hash performance_hash')
            need(obligation['obligor'] in parties and obligation['beneficiary'] in parties and obligation['obligor']!=obligation['beneficiary'],'OBLIGATION_PARTIES')
            key(obligation['condition_hash']);key(obligation['performance_hash'])
        approved(p['assents'],set(parties),len(parties),'COVENANT-MULTI-ASSENT-0.3',t,resolve)
        cid=digest('COVENANT-MULTI-0.3',t);need(cid not in s['multilateral'],'ALREADY_BOUND')
        s['multilateral'][cid]={'terms':deepcopy(t),'assents':deepcopy(p['assents']),'formation':tid,'state':'BOUND','backing':'NONE','outcomes':{}}
        return []
    if op=='MULTI_RESOLVE':
        exact(p,'agreement obligation result evidence_hash');need(p['agreement'] in s['multilateral'],'AGREEMENT')
        a=s['multilateral'][p['agreement']];need(a['state']=='BOUND' and actor==a['terms']['resolver'],'RESOLVER_STATE')
        integer(p['obligation']);need(p['obligation']<len(a['terms']['obligations']) and p['result'] in {'SUPPORTED','REFUTED','INDETERMINATE'},'OUTCOME');key(p['evidence_hash'])
        a['outcomes'][str(p['obligation'])]={'result':p['result'],'evidence_hash':p['evidence_hash'],'event':tid};return [a['formation']]
    if op=='MULTI_DISCHARGE':
        exact(p,'agreement assents');need(p['agreement'] in s['multilateral'],'AGREEMENT');a=s['multilateral'][p['agreement']];need(a['state']=='BOUND','ALREADY_DISCHARGED')
        body={'chain':s['chain'],'agreement':p['agreement'],'formation':a['formation'],'action':'DISCHARGE'}
        required=set(a['terms']['parties']);approved(p['assents'],required,len(required),'COVENANT-MULTI-DISCHARGE-0.3',body,resolve)
        a['state']='DISCHARGED';return [a['formation']]
    if op=='DOMAIN_SUCCESSION':
        exact(p,'epoch source_root activation validators faults approvals acceptances')
        old=s['domain']['active'];integer(p['epoch'],True);integer(p['faults'],True)
        if p['activation']!='NEXT_HEIGHT':integer(p['activation'],True)
        need(height>=old['activation'] and p['epoch']==old['epoch']+1 and p['activation'] in {'NEXT_HEIGHT',height+1},'EPOCH_BOUNDARY')
        need(p['source_root']==root(previous),'SOURCE_ROOT')
        members=p['validators'];need(type(members) is dict and len(members)==3*p['faults']+1 and len(members)<=64,'COMMITTEE_SIZE')
        for name,pub in members.items():need(type(name) is str and 0<len(name)<=80,'MEMBER_NAME');verification_key(pub)
        need(len(set(digest('COVENANT-VALIDATOR-KEY',pub) for pub in members.values()))==len(members),'DUPLICATE_VALIDATOR')
        body={k:v for k,v in p.items() if k not in {'approvals','acceptances'}};body['chain']=s['chain']
        approved(p['approvals'],set(old['validators']),2*old['faults']+1,'COVENANT-SUCCESSION-0.3',body,lambda who:old['validators'][who])
        approved(p['acceptances'],set(members),2*p['faults']+1,'COVENANT-SUCCESSION-ACCEPT-0.3',body,lambda who:members[who])
        s['domain']['active']={'epoch':p['epoch'],'activation':height+1,'validators':deepcopy(members),'faults':p['faults'],'event':tid}
        return [old['event']] if old['event'] else []
    return None
