"""Launch four autonomous native validators and exercise commitment/fault flows."""
import argparse,json,math,os,socket,subprocess,sys,tempfile,time
from pathlib import Path
from copy import deepcopy
from covenant_language.safe_io import atomic_write
from .client import Client,RPCError

class DemoClient(Client):
    """Local demo client. /state backs off when the diagnostic bucket is empty."""
    def state(self, *, backoff=True):
        return super().state(backoff=backoff)
from .fixtures import fresh_fixture,terms
from .app import make_transaction,transaction_id,assent,agreement_id,NEXT_VERSION,LIFECYCLE_VERSION
from .crypto import digest,canonical,public_key,sign,pq_keypair
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from .proofs import verify_history,assess_commitment,verify_scoped_record

ROOT=Path(__file__).resolve().parents[1]
def read_record(client, table, key):
    """One state record. /state is rate-limited and returns the whole diagnostic export."""
    row = client.read_record(table, key)
    return row['value'] if row.get('found') else None

def nonce_of(client, actor):
    value = read_record(client, 'nonces', actor)
    return 0 if value is None else value

def eventually(fn,seconds=30,*,processes=()):
    end=time.monotonic()+seconds;last=None
    while time.monotonic()<end:
        for name, process, logfile in processes:
            code=process.poll()
            if code is not None:
                path=Path(logfile)
                tail=path.read_bytes()[-2000:].decode('utf-8', errors='replace') if path.exists() else 'log unavailable'
                raise RuntimeError(f"Validator {name} exited {code}; log: {path}\n{tail}")
        try:
            v=fn()
            if v:return v
        except (RPCError,OSError,KeyError) as e:last=e
        time.sleep(.1)
    raise TimeoutError(str(last or 'condition did not become true'))

def _challenge_wait(remaining, pacing):
    """Bound a local demo wait using its actual height window and paced rounds."""
    if type(remaining) is not int or remaining < 0 or not math.isfinite(pacing) or not 0 <= pacing <= 30:
        raise ValueError('DEMO_PACING_USE_0_TO_30_SECONDS')
    return min(300, max(45, (remaining + 2) * (3 * pacing + 4)))

def run(out,quantum=False,privacy=False):
    pacing = float(os.environ.get('COVENANT_EMPTY_BLOCK_INTERVAL', '5'))
    _challenge_wait(0, pacing)
    child_env = {**os.environ, 'COVENANT_EMPTY_BLOCK_INTERVAL': str(pacing)}
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    keys,p,g=fresh_fixture(protocol=LIFECYCLE_VERSION);keys['v4']=pq_keypair() if quantum else Ed25519PrivateKey.generate();chain=digest('COVENANT-GENESIS',g);observations=[];procs={};logs={}
    def record(name,detail=True):observations.append({'check':name,'passed':True,'detail':detail});print(name,flush=True)
    with tempfile.TemporaryDirectory(prefix='covenant-native-') as tmp:
        d=Path(tmp);(d/'genesis.json').write_bytes(canonical(g))
        sockets=[socket.socket() for _ in range(5)]
        for s in sockets:s.bind(('127.0.0.1',0))
        ports=[s.getsockname()[1] for s in sockets];peers={f'v{i}':f'http://127.0.0.1:{ports[i]}' for i in range(5)}
        for s in sockets:s.close()
        (d/'peers.json').write_bytes(canonical(peers));clients=[DemoClient(peers[f'v{i}']) for i in range(4)]
        for i in range(5):
            f=d/f'v{i}.key';f.write_text(json.dumps(keys[f'v{i}'].private_record()) if hasattr(keys[f'v{i}'],'private_record') else keys[f'v{i}'].private_bytes_raw().hex());f.chmod(0o600)
        def start(i,bootstrap=False):
            logs[i]=open(out/f'validator_{i}.log','ab')
            args=[sys.executable,'-m','covenant_chain.node','--genesis',str(d/'genesis.json'),'--peers',str(d/'peers.json'),'--member',f'v{i}','--key',str(d/f'v{i}.key'),'--db',str(d/f'v{i}.journal'),'--port',str(ports[i]),'--base-timeout',str(max(.8,pacing+2)),'--sandbox-control']
            if bootstrap:args+=['--bootstrap',str(d/'bootstrap.json')]
            procs[i]=subprocess.Popen(args,cwd=ROOT,env=child_env,stdout=logs[i],stderr=subprocess.STDOUT)
        def stop(i,kill=False):
            proc=procs.pop(i)
            proc.kill() if kill else proc.terminate()
            try:proc.wait(timeout=8)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            logs.pop(i).close()
        def send(name,op,payload,index=0):
            c=clients[index];tx=make_transaction(keys[name],chain,nonce_of(c,p[name]),op,payload,protocol=g['protocol'],actor=p[name])
            assert c.preview(tx)['binding'] is False
            c.submit(tx);c.wait(transaction_id(tx),timeout=45);return transaction_id(tx)
        def all_know(tid):return eventually(lambda:all(c.transaction(tid)['status']=='committed' for c in clients),45)
        def finish(cid):
            eid=send('worker','SHOW',{'agreement':cid,'content_hash':digest('OBSERVATION',{'job':cid}),'description':'scripted sandbox observation'})
            send('resolver','DECIDE',{'agreement':cid,'result':'SUPPORTED','evidence':[eid]})
            decided = eventually(lambda: read_record(clients[0],'agreements',cid),45)
            end = decided['challenge_end']
            if type(end) is not int:
                raise ValueError('DEMO_DECISION_CHALLENGE_END_MISSING')
            remaining = max(0,end-clients[0].status()['applied_height'])
            eventually(lambda:clients[0].status()['applied_height']>end,_challenge_wait(remaining,pacing))
            send('worker','EXECUTE',{'agreement':cid})
        def collect(client,limit=None):
            entries=[]
            while True:
                batch=client.blocks(len(entries)+1)
                if not batch:break
                if limit is not None:batch=[e for e in batch if e['block']['height']<=limit]
                entries.extend(batch)
                if limit is not None and len(entries)>=limit:break
                if len(batch)<16:break
            return entries
        try:
            for i in range(4):start(i)
            eventually(lambda:all(c.status()['consensus_running'] for c in clients), processes=[(f'v{i}', procs[i], logs[i].name) for i in range(4)])
            record('four autonomous validator processes started')
            def give(resource,qty):
                tid=send('owner','GIVE',{'parent':None,'holder':p['agent'],'resource':resource,'limit':qty,'expiry':10000,'effects':['AUTHORIZE','CONSUME','TRANSFER'],'profiles':['task-v1'],'delegate':False});all_know(tid);return tid
            cg=give('compute',30);t=terms(p,chain,cg,quantity=10)
            if privacy:
                from .privacy import VERSION as PRIVACY_VERSION
                from .disclosure import prepare,grant,delegate,open_fields,manifest_id
                from covenant_language.quantum import recipient_keypair
                policy={'version':PRIVACY_VERSION,'choices':{'identity':['public'],'terms':['scoped-encrypted'],'resources':['transparent'],'transport':['direct'],'disclosure':['scoped-delegable']}}
                selection=Client.negotiate_privacy(policy,policy)
                private_fields={'specification':'confidential spectral analysis', 'price':73, 'destination':'confidential instrument control'}
                manifest,openings,slots=prepare(private_fields,{'chain':chain,'purpose':'compute agreement'},delegation=True)
                t=Client.bind_private_terms(t,selection,manifest);adopted_manifest=manifest_id(manifest);private_terms_hash=t['terms_hash']
                wp,ws=recipient_keypair();rp,rs=recipient_keypair();ep,es=recipient_keypair()
                wc,wd=grant(manifest,openings,keys['owner'],p['worker'],wp,sorted([slots['specification'],slots['price']]),0,10000,1)
                view=open_fields(manifest,wc,wd,ws,p['owner'],0,expected_manifest=adopted_manifest)
                assert view=={'specification':private_fields['specification'],'price':73}
                record('worker decrypts only adopted specification and price')
                rc,rd=delegate(manifest,wc,wd,ws,keys['worker'],p['owner'],0,p['resolver'],rp,[slots['specification']],0,10000,expected_manifest=adopted_manifest)
                assert open_fields(manifest,rc,rd,rs,p['owner'],0,expected_manifest=adopted_manifest)=={'specification':private_fields['specification']}
                record('worker delegates specification only to resolver')
                ec,ed=grant(manifest,openings,keys['owner'],p['executor'],ep,[slots['destination']],0,10000)
                assert open_fields(manifest,ec,ed,es,p['owner'],0,expected_manifest=adopted_manifest)=={'destination':private_fields['destination']}
                record('executor decrypts only instruction field')
                try:open_fields(manifest,wc,wd,rs,p['owner'],0,expected_manifest=adopted_manifest)
                except ValueError:record('unadopted recipient cannot decrypt worker delivery')
                else:raise AssertionError('recipient isolation failed')
            cid=agreement_id(t)
            formation=send('agent','BIND',{'terms':t,'assents':[assent(keys['agent'],t),assent(keys['worker'],t)]});all_know(formation)
            assert read_record(clients[0],'agreements',cid)['held'];record('atomic delegated formation reserves compute')
            send('owner','REVOKE',{'grant':cg});assert read_record(clients[0],'agreements',cid)['held'];record('revocation preserves existing reservation')
            finish(cid);assert read_record(clients[0],'consumed','compute')==10;record('compute agreement resolves and authorizes once')
            try:send('worker','EXECUTE',{'agreement':cid})
            except RPCError:record('duplicate consequence rejected')
            else:raise AssertionError('duplicate effect accepted')
            dg=give('data',2);dt=terms(p,chain,dg,resource='data',quantity=1,effect='AUTHORIZE',description='Data access ticket');dcid=agreement_id(dt)
            send('agent','BIND',{'terms':dt,'assents':[assent(keys['agent'],dt),assent(keys['worker'],dt)]});finish(dcid);record('nonfinancial data ticket authorized')
            pt=terms(p,chain,resource='payment',quantity=7,effect='TRANSFER',description='Service payment');pcid=agreement_id(pt)
            send('owner','BIND',{'terms':pt,'assents':[assent(keys['owner'],pt),assent(keys['worker'],pt)]});finish(pcid)
            assert read_record(clients[0],'balances',p['worker'])['payment']==7;record('conditional payment uses same commitment lifecycle')
            # One process is killed; remaining three must continue and certify.
            stop(3,True)
            claim=send('worker','SAY',{'subject':'research','content_hash':digest('DATA',{'finding':'test'}),'description':'attributed research assertion','parents':[]});record('three validators progress with one killed')
            start(3);eventually(lambda:clients[3].transaction(claim)['status']=='committed',45);record('killed validator restores journal and catches up')
            prior=clients[0].blocks(1)
            original=next(tx for entry in prior for tx in entry['block']['txs'])
            assert clients[3].submit(original)['status']=='committed'
            record('retry after restart returns durable original receipt')
            # Exclusive reservation competing across 2+2 network partition.
            ig=give('instrument',1)
            for i,c in enumerate(clients):c.control([f'v{j}' for j in range(4) if (j<2)!=(i<2)])
            time.sleep(2)
            ts=[terms(p,chain,ig,resource='instrument',quantity=1,effect='AUTHORIZE',description=f'Booking {i}') for i in [0,1]]
            nonce=nonce_of(clients[0],p['agent']);txs=[]
            for i,t in enumerate(ts):
                tx=make_transaction(keys['agent'],chain,nonce,'BIND',{'terms':t,'assents':[assent(keys['agent'],t),assent(keys['worker'],t)]},protocol=g['protocol']);clients[0 if i==0 else 2].submit(tx);txs.append(tx)
            time.sleep(3)
            assert all(read_record(c,'agreements',agreement_id(t)) is None for t in ts for c in clients);record('2+2 partition certifies neither competing booking')
            for c in clients:c.control([])
            eventually(lambda:any(read_record(clients[0],'agreements',agreement_id(t)) is not None for t in ts),60)
            ids=[agreement_id(t) for t in ts]
            eventually(lambda:all(sum(read_record(c,'agreements',cid) is not None for cid in ids)==1 for c in clients),45)
            record('healed network recovers and reserves exactly one booking')
            # Independent verifier checks certificates and deterministic transitions.
            entries=[];cursor=1
            while True:
                batch=clients[0].blocks(cursor)
                if not batch:break
                entries.extend(batch);cursor+=len(batch)
                if len(batch)<16:break
            report=verify_history(g,entries,chain)
            assert report['state']['consumed']['compute']==10
            assessment=assess_commitment(cid,report)
            assert assessment['formation']=='VERIFIED' and assessment['reservation']=='DISCHARGED'
            record('offline verifier reconstructs finalized state from genesis and certificates',{'height':report['height'],'head':report['head']})
            scoped=clients[0].proof('agreements',cid)
            assert verify_scoped_record(g,scoped,chain,scoped['checkpoint']['block']['height'],verify_history(g,collect(clients[0],scoped['checkpoint']['block']['height']),chain))['value']['held'] is False
            record('scoped agreement proof verifies against committee certificate')
            bad=deepcopy(entries);bad[0]['certificate']['votes'][0]['signature']='0'*128
            try:verify_history(g,bad,chain)
            except ValueError:record('offline verifier rejects forged certificate')
            else:raise AssertionError('forged proof accepted')
            try:verify_history(g,entries,'0'*64)
            except ValueError:record('offline verifier rejects substituted genesis')
            else:raise AssertionError('wrong genesis accepted')
            for c in clients:assert c.status()['consensus_running']
            record('all validators remain live after recovery')
            # Planned committee cutover with a live reservation carried forward.
            successor_keys={n:pq_keypair() for n in ['v0','v1','v2']} if quantum else {n:keys[n] for n in ['v0','v1','v2']}
            successor_keys['v4']=keys['v4']
            next_members={n:public_key(k) for n,k in successor_keys.items()}
            for attempt in range(20):
                status=clients[0].status()
                payload={'epoch':1,'source_root':status['state_root'],'activation':'NEXT_HEIGHT','validators':next_members,'faults':1}
                body={**payload,'chain':chain}
                payload['approvals']=[{'signer':n,'signature':sign(keys[n],'COVENANT-SUCCESSION-0.3',body)} for n in ['v0','v1','v2']]
                payload['acceptances']=[{'signer':n,'signature':sign(successor_keys[n],'COVENANT-SUCCESSION-ACCEPT-0.3',body)} for n in ['v0','v1','v4']]
                try:succession=send('worker','DOMAIN_SUCCESSION',payload);break
                except RPCError:
                    if attempt==19:raise
            eventually(lambda:all((read_record(c,'domain','active') or {}).get('epoch')==1 for c in clients))
            assert clients[3].status()['validator_active'] is False
            record('retired validator stops voting at certified committee boundary')
            bootstrap=collect(clients[0]);(d/'bootstrap.json').write_text(json.dumps(bootstrap))
            if quantum:
                for i in [0,1,2]:
                    stop(i,True);keys[f'v{i}']=successor_keys[f'v{i}']
                    (d/f'v{i}.key').write_text(json.dumps(keys[f'v{i}'].private_record()));start(i)
                eventually(lambda:all(clients[i].status()['validator_active'] for i in [0,1,2]))
                record('continuing operators restart with accepted post-quantum keys')
            start(4,True);fifth=Client(peers['v4'])
            eventually(lambda:fifth.status()['validator_active'])
            record('new validator bootstraps from independently replayed history')
            stop(2,True)
            claim=send('worker','SAY',{'subject':'succession','content_hash':'7'*64,'description':'new committee action','parents':[]})
            eventually(lambda:fifth.transaction(claim)['status']=='committed')
            record('successor committee progresses with one continuing validator offline')
            active_booking=next(cid for cid in ids if read_record(clients[0],'agreements',cid) is not None)
            assert read_record(clients[0],'agreements',active_booking)['held']
            record('existing reserved obligation survives validator replacement')
            if quantum:
                new=pq_keypair();descriptor=public_key(new)
                body={'chain':chain,'entity':p['owner'],'nonce':nonce_of(clients[0],p['owner']),'controller':descriptor}
                send('owner','SET_CONTROLLER_SUITE',{'controller':descriptor,'possession':sign(new,'COVENANT-CONTROLLER-SUITE-0.3',body)})
                keys['owner']=new
                send('owner','SAY',{'subject':'quantum-succession','content_hash':'8'*64,'description':'ML-DSA native principal action','parents':[]})
                record('principal migrates to ML-DSA-65 and signs native action')
                record('all successor quorum signatures use ML-DSA-65')
            entries=collect(clients[0]);report=verify_history(g,entries,chain)
            record('independent replay verifies source and successor committee certificates')
            if privacy:
                assert report['state']['agreements'][cid]['terms']['terms_hash']==private_terms_hash
                wire=canonical(entries).decode()
                assert all(secret not in wire for secret in [private_fields['specification'],private_fields['destination']])
                record('finalized native terms bind privacy manifest without confidential field content')
            atomic_write(out/'genesis.json',canonical(g));atomic_write(out/'history.json',canonical(entries))
            result={'protocol':g['protocol'],'checks':observations,'passed':len(observations),'chain':chain,'verified_height':report['height'],'verified_head':report['head'],'agents':'scripted independently keyed clients','validators':'four-member committee; five processes over operator succession on one machine','privacy':'public commitments, content hashes; no shielded state','quantum_native':quantum,'scoped_disclosure':privacy,'production':False}
            atomic_write(out/'results.json',json.dumps(result,indent=2)+'\n');return result
        finally:
            for i in list(procs):stop(i)
            for i in range(5):
                log=d/f'v{i}.log'
                if log.exists():atomic_write(out/f'validator_{i}.log',log.read_bytes())

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='reports/native_chain');p.add_argument('--quantum',action='store_true');p.add_argument('--privacy',action='store_true');args=p.parse_args();print(json.dumps(run(args.out,args.quantum,args.privacy),indent=2))
