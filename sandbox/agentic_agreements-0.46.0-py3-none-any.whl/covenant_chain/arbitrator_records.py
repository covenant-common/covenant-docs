"""Arbitrator records: backed qualifications, availability, conflicts and bias audits.

TAKE-AND-IMPROVE from the Agentic Arbitration Protocol's arbitrator manifest
(schema.arbitrator-manifest.json), where every field is self-reported. Here
the arbitrator signs a versioned record. A case-count or specialization claim
is BACKED only by portable-trust OUTCOME receipts about that arbitrator from
contacts the caller trusts; other claims stay SELF_DECLARED. Bias audits are
separate statements signed by auditors the caller adopts. Conflicts follow
the disclosure-and-challenge shape of the UNCITRAL Arbitration Rules
(articles 11-13), sorted like the red and orange lists of the IBA Guidelines
on Conflicts of Interest: NON_WAIVABLE blocks appointment, WAIVABLE needs
every party's signed waiver, DISCLOSURE is shown to the parties. Conflicts are
checked against the parties before any appointment payload is prepared.

Nothing here appoints, seats, stakes, pays or contacts anyone: the parties
and the arbitrator sign the prepared appointment, and a chain panel still
applies its own registry and conflict rules.
"""
from copy import deepcopy
import re

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .crypto import canonical, digest, integer, key, need, verify

VERSION = 'urn:aap:arbitrator-record:0.1'
LABEL = 'AAP-ARBITRATOR-RECORD-0.1'
AUDIT_VERSION = 'urn:aap:bias-audit:0.1'
AUDIT_LABEL = 'AAP-BIAS-AUDIT-0.1'
WAIVER_VERSION = 'urn:aap:conflict-waiver:0.1'
WAIVER_LABEL = 'AAP-CONFLICT-WAIVER-0.1'
APPOINTMENT_VERSION = 'urn:aap:arbitrator-appointment:0.1'
APPOINTMENT_LABEL = 'AAP-ARBITRATOR-APPOINTMENT-0.1'
SUBJECT_KIND = 'aap-arbitrator'
FIELDS = ('version arbitrator kind name sequence previous issued_at expires categories qualifications availability '
          'conflicts external_key')
QUALIFICATIONS = ('CASES', 'CERTIFICATION', 'EXPERIENCE_YEARS', 'JURISDICTION', 'MODEL', 'SPECIALIZATION')
CONFLICTS = ('DISCLOSURE', 'NON_WAIVABLE', 'WAIVABLE')
STATUS = ('AVAILABLE', 'BUSY', 'UNAVAILABLE')
_CATEGORY = re.compile(r'[a-z0-9-]{1,32}\Z')
_METRIC = re.compile(r'[a-z][a-z0-9_]{0,63}\Z')
_JURISDICTION = re.compile(r'[A-Z]{2}(-[A-Z]{2})?\Z')
FLAGS = {'execution_authorized': False, 'appointed': False, 'network_accessed': False}

REMEDIATION = {
    'ARBITRATOR_RECORD_FIELDS': 'Use the exact record fields from record_draft with printable ASCII text.',
    'ARBITRATOR_RECORD_VERSION': 'Use urn:aap:arbitrator-record:0.1; a meaning change needs a new version.',
    'ARBITRATOR_RECORD_QUALIFICATION': 'Give up to 32 rows {kind, value, context}; CASES and SPECIALIZATION need a receipt context.',
    'ARBITRATOR_RECORD_AVAILABILITY': 'Give {status, max_caseload >= 1, current_caseload, next_available or null, as_of}.',
    'ARBITRATOR_RECORD_CONFLICT': 'Give up to 64 rows {subject key, relation, category DISCLOSURE, WAIVABLE or NON_WAIVABLE}, each once.',
    'ARBITRATOR_RECORD_SIGNATURE': 'Pass {body, signature} signed by the arbitrator key the body names.',
    'ARBITRATOR_RECORD_EXPECTED': 'The record differs from the id you retained; obtain the record you reviewed.',
    'ARBITRATOR_RECORD_EXPIRED': 'The record is not valid at the supplied time; ask the arbitrator for a current record.',
    'ARBITRATOR_RECORD_SUCCESSOR': 'A successor must name the previous record id and the next sequence.',
    'ARBITRATOR_RECORD_DUPLICATE': 'Pass at most one record per arbitrator.',
    'ARBITRATOR_AUDIT_FIELDS': 'Use the exact bias audit fields with integer basis-point metrics.',
    'ARBITRATOR_AUDIT_SELF': 'An arbitrator cannot audit itself; obtain an independent auditor.',
    'ARBITRATOR_PARTIES': 'Pass 2 to 16 distinct party keys, and affiliations as party key to a list of keys.',
    'ARBITRATOR_CONFLICT': 'A non-waivable conflict with the parties blocks this appointment; choose another arbitrator.',
    'ARBITRATOR_CONFLICT_WAIVER': 'Every party must sign a waiver naming this case, record and conflict subject.',
    'ARBITRATOR_WAIVER_FIELDS': 'Pass {body, signatures} with the exact waiver body and one signature per party.',
    'ARBITRATOR_UNAVAILABLE': 'The record says the arbitrator is not available, is full, or is stale for the supplied time.',
    'ARBITRATOR_UNQUALIFIED': 'A required qualification is not backed by trusted outcome receipts.',
    'ARBITRATOR_REQUIREMENTS': 'Give requirements as rows {kind, context} for CASES or SPECIALIZATION.',
    'ARBITRATOR_PROFILES': 'Pass up to 64 signed arbitrator records and an integer now with max_age.',
    'ARBITRATOR_EXTERNAL_KEY': 'The PEM does not match the external key pin in the record.',
}


def _text(value, limit, code='ARBITRATOR_RECORD_FIELDS'):
    need(type(value) is str and 0 < len(value) <= limit and all(32 <= ord(c) <= 126 for c in value), code)


def validate_record(body):
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'ARBITRATOR_RECORD_FIELDS')
    need(body['version'] == VERSION, 'ARBITRATOR_RECORD_VERSION')
    key(body['arbitrator'])
    need(body['kind'] in ('AI', 'HUMAN'), 'ARBITRATOR_RECORD_FIELDS')
    _text(body['name'], 128)
    integer(body['sequence']); integer(body['issued_at']); integer(body['expires'])
    need(body['expires'] > body['issued_at'], 'ARBITRATOR_RECORD_FIELDS')
    need((body['sequence'] == 0) == (body['previous'] is None), 'ARBITRATOR_RECORD_SUCCESSOR')
    if body['previous'] is not None: key(body['previous'])
    categories = body['categories']
    need(type(categories) is list and len(categories) <= 8 and categories == sorted(set(categories))
         and all(type(item) is str and _CATEGORY.match(item) for item in categories), 'ARBITRATOR_RECORD_FIELDS')
    rows = body['qualifications']
    need(type(rows) is list and len(rows) <= 32, 'ARBITRATOR_RECORD_QUALIFICATION')
    for row in rows:
        need(type(row) is dict and set(row) == {'kind', 'value', 'context'} and row['kind'] in QUALIFICATIONS, 'ARBITRATOR_RECORD_QUALIFICATION')
        if row['kind'] in ('CASES', 'EXPERIENCE_YEARS'):
            need(type(row['value']) is int and 0 <= row['value'] <= 1_000_000, 'ARBITRATOR_RECORD_QUALIFICATION')
        else:
            _text(row['value'], 128, 'ARBITRATOR_RECORD_QUALIFICATION')
        if row['kind'] == 'JURISDICTION':
            need(_JURISDICTION.match(row['value']) is not None, 'ARBITRATOR_RECORD_QUALIFICATION')
        if row['kind'] in ('CASES', 'SPECIALIZATION'): _text(row['context'], 256, 'ARBITRATOR_RECORD_QUALIFICATION')
        else: need(row['context'] is None, 'ARBITRATOR_RECORD_QUALIFICATION')
    need(len({canonical(row) for row in rows}) == len(rows), 'ARBITRATOR_RECORD_QUALIFICATION')
    available = body['availability']
    need(type(available) is dict and set(available) == {'status', 'max_caseload', 'current_caseload', 'next_available', 'as_of'}
         and available['status'] in STATUS, 'ARBITRATOR_RECORD_AVAILABILITY')
    integer(available['max_caseload'], True); integer(available['current_caseload']); integer(available['as_of'])
    if available['next_available'] is not None: integer(available['next_available'])
    conflicts = body['conflicts']
    need(type(conflicts) is list and len(conflicts) <= 64, 'ARBITRATOR_RECORD_CONFLICT')
    for row in conflicts:
        need(type(row) is dict and set(row) == {'subject', 'relation', 'category'} and row['category'] in CONFLICTS, 'ARBITRATOR_RECORD_CONFLICT')
        key(row['subject']); _text(row['relation'], 256, 'ARBITRATOR_RECORD_CONFLICT')
        need(row['subject'] != body['arbitrator'], 'ARBITRATOR_RECORD_CONFLICT')
    need(len({(row['subject'], row['category']) for row in conflicts}) == len(conflicts), 'ARBITRATOR_RECORD_CONFLICT')
    if body['external_key'] is not None: key(body['external_key'])
    need(len(canonical(body)) <= 65536, 'ARBITRATOR_RECORD_FIELDS')
    return body


def record_id(body):
    return digest(LABEL, validate_record(body))


def record_draft(*, arbitrator, kind, name, issued_at, expires, qualifications, availability, conflicts=(),
                 categories=(), sequence=0, previous=None, external_key=None):
    """The record the arbitrator signs; disclosure is the arbitrator's continuing duty."""
    body = {'version': VERSION, 'arbitrator': arbitrator, 'kind': kind, 'name': name, 'sequence': sequence,
            'previous': previous, 'issued_at': issued_at, 'expires': expires, 'categories': sorted(categories),
            'qualifications': deepcopy(list(qualifications)), 'availability': deepcopy(availability),
            'conflicts': deepcopy(list(conflicts)), 'external_key': external_key}
    return {'body': body, 'id': record_id(body), 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [arbitrator], **FLAGS}


def verify_record(record, *, expected_id=None, now=None, previous=None):
    """The arbitrator's own signature over the exact body; optionally current and a successor."""
    need(type(record) is dict and set(record) == {'body', 'signature'}, 'ARBITRATOR_RECORD_SIGNATURE')
    body = record['body']
    ident = record_id(body)
    if expected_id is not None:
        need(ident == expected_id, 'ARBITRATOR_RECORD_EXPECTED')
    try:
        verify(body['arbitrator'], LABEL, body, record['signature'])
    except ValueError:
        raise ValueError('ARBITRATOR_RECORD_SIGNATURE') from None
    if now is not None:
        integer(now); need(body['issued_at'] <= now < body['expires'], 'ARBITRATOR_RECORD_EXPIRED')
    if previous is not None:
        prior = verify_record(previous)
        need(prior['arbitrator'] == body['arbitrator'] and body['previous'] == prior['id']
             and body['sequence'] == prior['body']['sequence'] + 1, 'ARBITRATOR_RECORD_SUCCESSOR')
    return {'id': ident, 'arbitrator': body['arbitrator'], 'body': deepcopy(body)}


# Bias audits signed by an auditor ----------------------------------------------

def validate_audit(body):
    need(type(body) is dict and set(body) == {'version', 'arbitrator', 'auditor', 'period', 'method', 'metrics',
                                             'sample', 'report', 'issued_at', 'nonce'}, 'ARBITRATOR_AUDIT_FIELDS')
    need(body['version'] == AUDIT_VERSION, 'ARBITRATOR_AUDIT_FIELDS')
    key(body['arbitrator']); key(body['auditor']); key(body['nonce'])
    need(body['arbitrator'] != body['auditor'], 'ARBITRATOR_AUDIT_SELF')
    period = body['period']
    need(type(period) is dict and set(period) == {'from', 'to'}, 'ARBITRATOR_AUDIT_FIELDS')
    integer(period['from']); integer(period['to']); integer(body['sample']); integer(body['issued_at'])
    need(period['from'] < period['to'] <= body['issued_at'], 'ARBITRATOR_AUDIT_FIELDS')
    _text(body['method'], 512, 'ARBITRATOR_AUDIT_FIELDS')
    metrics = body['metrics']
    need(type(metrics) is dict and 1 <= len(metrics) <= 16, 'ARBITRATOR_AUDIT_FIELDS')
    for name, value in metrics.items():
        need(type(name) is str and _METRIC.match(name) is not None and type(value) is int and 0 <= value <= 10000, 'ARBITRATOR_AUDIT_FIELDS')
    if body['report'] is not None: key(body['report'])
    return body


def audit_draft(*, arbitrator, auditor, period, method, metrics, sample, report, issued_at, nonce):
    """What an auditor signs: method, period, sample size and basis-point results; never a verdict."""
    body = {'version': AUDIT_VERSION, 'arbitrator': arbitrator, 'auditor': auditor, 'period': deepcopy(period),
            'method': method, 'metrics': deepcopy(metrics), 'sample': sample, 'report': report, 'issued_at': issued_at,
            'nonce': nonce}
    validate_audit(body)
    return {'body': body, 'id': digest(AUDIT_LABEL, body), 'signing_payload': {'label': AUDIT_LABEL, 'body': deepcopy(body)},
            'required_signers': [auditor], **FLAGS}


def _audit(audit, arbitrator, adopted):
    need(type(audit) is dict and set(audit) == {'body', 'signature'}, 'ARBITRATOR_AUDIT_FIELDS')
    body = validate_audit(audit['body'])
    need(body['arbitrator'] == arbitrator, 'ARBITRATOR_AUDIT_FIELDS')
    verify(body['auditor'], AUDIT_LABEL, body, audit['signature'])
    return {'id': digest(AUDIT_LABEL, body), 'auditor': body['auditor'], 'period': deepcopy(body['period']),
            'method': body['method'], 'metrics': deepcopy(body['metrics']), 'sample': body['sample'], 'report': body['report'],
            'status': 'ADOPTED_AUDITOR' if body['auditor'] in adopted else 'UNADOPTED_AUDITOR_CLAIM'}


# Evaluation against receipts, audits and the clock the caller supplies ----------------

def evaluate(record, *, now, max_age, receipts=(), trusted_contacts=None, adopted_resolvers=None, audits=(), adopted_auditors=()):
    """What the record's claims are worth to this caller, right now."""
    from .portable_trust import local_reputation
    checked = verify_record(record, now=now)
    body = checked['body']
    integer(max_age, True)
    subject = {'kind': SUBJECT_KIND, 'id': body['arbitrator']}
    rows, agreements = [], set()
    for row in body['qualifications']:
        entry = {'kind': row['kind'], 'value': row['value'], 'context': row['context']}
        if row['kind'] in ('CASES', 'SPECIALIZATION'):
            if trusted_contacts:
                view = local_reputation(list(receipts), subject, row['context'], trusted_contacts, now, max_age, adopted_resolvers)
                fulfilled = sorted(item['agreement'] for item in view['agreements'] if item['status'] == 'FULFILLED')
                failed = sorted(item['agreement'] for item in view['agreements'] if item['status'] == 'FAILED')
                agreements.update(fulfilled)
                needed = row['value'] if row['kind'] == 'CASES' else 1
                entry.update(backed=len(fulfilled), failed=len(failed),
                             backing='BACKED' if len(fulfilled) >= needed else 'PARTIALLY_BACKED' if fulfilled else 'UNBACKED')
            else:
                entry.update(backed=0, failed=0, backing='UNBACKED_NO_TRUSTED_CONTACTS')
        else:
            entry['backing'] = 'SELF_DECLARED'
        rows.append(entry)
    available = body['availability']
    fresh = available['as_of'] <= now and now - available['as_of'] <= max_age
    appointable = (fresh and available['status'] == 'AVAILABLE' and available['current_caseload'] < available['max_caseload']
                   and (available['next_available'] is None or available['next_available'] <= now))
    adopted = set(adopted_auditors)
    accepted, excluded = [], []
    need(type(audits) in (list, tuple) and len(audits) <= 32, 'ARBITRATOR_AUDIT_FIELDS')
    for audit in audits:
        try:
            accepted.append(_audit(audit, body['arbitrator'], adopted))
        except ValueError as error:
            excluded.append({'status': 'EXCLUDED', 'reason': str(error)})
    return {'record': checked['id'], 'arbitrator': body['arbitrator'], 'kind': body['kind'], 'name': body['name'],
            'qualifications': rows, 'backed_agreements': sorted(agreements),
            'availability': {**deepcopy(available), 'fresh': fresh, 'appointable': appointable,
                             'basis': 'ARBITRATOR_STATEMENT_AT_AS_OF; CALLER_CLOCK'},
            'audits': accepted, 'excluded_audits': excluded,
            'disclosed_conflicts': len(body['conflicts']), 'reputation_basis': 'OWNER_TRUSTED_CONTACTS_ONLY; NOT_GLOBAL',
            **FLAGS}


def _parties(parties, affiliations):
    need(type(parties) in (list, tuple) and 2 <= len(parties) <= 16 and len(set(parties)) == len(parties), 'ARBITRATOR_PARTIES')
    for party in parties: key(party)
    affiliations = {} if affiliations is None else affiliations
    need(type(affiliations) is dict and set(affiliations) <= set(parties), 'ARBITRATOR_PARTIES')
    related = set(parties)
    for party, rows in affiliations.items():
        need(type(rows) is list and len(rows) <= 32, 'ARBITRATOR_PARTIES')
        for item in rows: key(item)
        related.update(rows)
    return related


def conflict_check(record, parties, *, affiliations=None, registry_row=None):
    """Sort every relation between the arbitrator and the parties (or their affiliates)."""
    body = verify_record(record)['body']
    related = _parties(parties, affiliations)
    blocking, waivable, disclosed = [], [], []
    if body['arbitrator'] in related:
        blocking.append({'subject': body['arbitrator'], 'relation': 'The arbitrator is a party or a party affiliate.',
                         'category': 'NON_WAIVABLE', 'source': 'PARTIES'})
    if registry_row is not None:
        need(type(registry_row) is dict and registry_row.get('member') == body['arbitrator'], 'ARBITRATOR_PARTIES')
        for subject in sorted(set(registry_row.get('affiliations') or []) & related):
            blocking.append({'subject': subject, 'relation': 'Affiliation recorded in the chain registry.',
                             'category': 'NON_WAIVABLE', 'source': 'CHAIN_REGISTRY'})
    for row in body['conflicts']:
        if row['subject'] in related:
            target = {'NON_WAIVABLE': blocking, 'WAIVABLE': waivable, 'DISCLOSURE': disclosed}[row['category']]
            target.append({**deepcopy(row), 'source': 'ARBITRATOR_DISCLOSURE'})
    return {'record': record_id(body), 'arbitrator': body['arbitrator'], 'blocking': blocking, 'waivable': waivable,
            'disclosed': disclosed, 'clear': not blocking and not waivable,
            'completeness': 'DECLARED_AND_SUPPLIED_RELATIONS_ONLY; UNDISCLOSED_RELATIONS_ARE_NOT_EXCLUDED', **FLAGS}


def waiver_draft(*, case, record, subject, parties):
    """The waiver every party signs for one WAIVABLE conflict in one case."""
    key(case); key(record); key(subject)
    body = {'version': WAIVER_VERSION, 'case': case, 'record': record, 'subject': subject, 'parties': sorted(parties)}
    _parties(body['parties'], None)
    return {'body': body, 'id': digest(WAIVER_LABEL, body), 'signing_payload': {'label': WAIVER_LABEL, 'body': deepcopy(body)},
            'required_signers': sorted(parties), **FLAGS}


def _waived(waivers, case, record, subject, parties):
    need(type(waivers) in (list, tuple) and len(waivers) <= 64, 'ARBITRATOR_WAIVER_FIELDS')
    expected = {'version': WAIVER_VERSION, 'case': case, 'record': record, 'subject': subject, 'parties': sorted(parties)}
    for waiver in waivers:
        need(type(waiver) is dict and set(waiver) == {'body', 'signatures'} and type(waiver['signatures']) is list, 'ARBITRATOR_WAIVER_FIELDS')
        if waiver['body'] != expected: continue
        signed = set()
        for row in waiver['signatures']:
            need(type(row) is dict and set(row) == {'signer', 'signature'} and row['signer'] in expected['parties']
                 and row['signer'] not in signed, 'ARBITRATOR_WAIVER_FIELDS')
            verify(row['signer'], WAIVER_LABEL, expected, row['signature']); signed.add(row['signer'])
        if signed == set(expected['parties']):
            return digest(WAIVER_LABEL, expected)
    return None


def appointment(record, *, case, parties, now, max_age, waivers=(), affiliations=None, registry_row=None,
                requirements=(), receipts=(), trusted_contacts=None, adopted_resolvers=None):
    """Prepare an appointment only after the conflict check, waivers, availability and requirements pass."""
    key(case)
    evaluation = evaluate(record, now=now, max_age=max_age, receipts=receipts, trusted_contacts=trusted_contacts,
                          adopted_resolvers=adopted_resolvers)
    conflicts = conflict_check(record, parties, affiliations=affiliations, registry_row=registry_row)
    need(not conflicts['blocking'], 'ARBITRATOR_CONFLICT')
    waived = []
    for row in conflicts['waivable']:
        ident = _waived(waivers, case, conflicts['record'], row['subject'], parties)
        need(ident is not None, 'ARBITRATOR_CONFLICT_WAIVER')
        waived.append(ident)
    need(evaluation['availability']['appointable'], 'ARBITRATOR_UNAVAILABLE')
    need(type(requirements) in (list, tuple) and len(requirements) <= 16, 'ARBITRATOR_REQUIREMENTS')
    for wanted in requirements:
        need(type(wanted) is dict and set(wanted) == {'kind', 'context'} and wanted['kind'] in ('CASES', 'SPECIALIZATION'), 'ARBITRATOR_REQUIREMENTS')
        need(any(row['kind'] == wanted['kind'] and row['context'] == wanted['context'] and row['backing'] == 'BACKED'
                 for row in evaluation['qualifications']), 'ARBITRATOR_UNQUALIFIED')
    body = {'version': APPOINTMENT_VERSION, 'case': case, 'arbitrator': conflicts['arbitrator'], 'record': conflicts['record'],
            'parties': sorted(parties), 'disclosures': sorted(row['subject'] for row in conflicts['disclosed']),
            'waivers': sorted(waived), 'issued_at': now}
    return {'appointment': body, 'id': digest(APPOINTMENT_LABEL, body),
            'signing_payload': {'label': APPOINTMENT_LABEL, 'body': deepcopy(body)},
            'required_signers': sorted(parties) + [conflicts['arbitrator']], 'evaluation': evaluation, 'conflicts': conflicts,
            'chain_panel_rules': 'A chain panel still applies its own registry, stake and conflict checks.', **FLAGS}


def screen(rows, *, parties=None, profiles=None, now=None, max_age=None, require_profile=False):
    """Registry search rows narrowed by signed records: blocking conflicts and unavailable members drop out."""
    profiles = [] if profiles is None else profiles
    need(type(profiles) in (list, tuple) and len(profiles) <= 64, 'ARBITRATOR_PROFILES')
    if profiles or require_profile:
        need(type(now) is int and type(max_age) is int and max_age > 0, 'ARBITRATOR_PROFILES')
    index = {}
    for record in profiles:
        checked = verify_record(record, now=now)
        need(checked['arbitrator'] not in index, 'ARBITRATOR_RECORD_DUPLICATE')
        index[checked['arbitrator']] = record
    out = []
    for row in rows:
        record = index.get(row['member'])
        if record is None:
            if require_profile: continue
            out.append({**row, 'profile': None, 'conflict_check': 'REGISTRY_AFFILIATIONS_ONLY'})
            continue
        conflicts = None
        if parties is not None:
            conflicts = conflict_check(record, list(parties), registry_row={'member': row['member'], 'affiliations': row.get('affiliations', [])})
            if conflicts['blocking']: continue
        evaluation = evaluate(record, now=now, max_age=max_age)
        if not evaluation['availability']['appointable']: continue
        out.append({**row, 'conflict_check': 'RECORD_AND_REGISTRY' if conflicts is not None else 'NOT_REQUESTED',
                    'profile': {'record': evaluation['record'], 'kind': evaluation['kind'], 'name': evaluation['name'],
                                'availability': evaluation['availability']['status'],
                                'waiver_required': sorted(item['subject'] for item in (conflicts or {}).get('waivable', [])),
                                'disclosures': sorted(item['subject'] for item in (conflicts or {}).get('disclosed', [])),
                                'qualifications': [{'kind': item['kind'], 'value': item['value'], 'backing': item['backing']}
                                                   for item in evaluation['qualifications']]}})
    return out


# The Agentic Arbitration Protocol's arbitrator manifest ------------------------------------

def to_manifest(record, evaluation, *, external_pem=None):
    """Export as schema.arbitrator-manifest.json; only backed numbers are exported as numbers."""
    from . import agentic_arbitration as wire
    body = verify_record(record)['body']
    need(type(evaluation) is dict and evaluation.get('record') == record_id(body), 'ARBITRATOR_RECORD_EXPECTED')
    if external_pem is not None:
        need(body['external_key'] is not None and wire.key_pin(external_pem) == body['external_key'], 'ARBITRATOR_EXTERNAL_KEY')
        pem = external_pem
    else:
        pem = Ed25519PublicKey.from_public_bytes(bytes.fromhex(body['arbitrator'])).public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode('ascii')
    rows = evaluation['qualifications']
    qualifications = {
        'certifications': [row['value'] for row in rows if row['kind'] == 'CERTIFICATION'],
        'jurisdictions': [row['value'] for row in rows if row['kind'] == 'JURISDICTION'],
        'specializations': [row['value'] for row in rows if row['kind'] == 'SPECIALIZATION' and row['backing'] == 'BACKED'],
        'casesCompleted': len(evaluation['backed_agreements'])}
    models = [row['value'] for row in rows if row['kind'] == 'MODEL']
    if models: qualifications['model'] = models[0]
    years = [row['value'] for row in rows if row['kind'] == 'EXPERIENCE_YEARS']
    if years: qualifications['yearsExperience'] = years[0]
    available = evaluation['availability']
    manifest = {'arbitratorId': 'aap:' + body['arbitrator'], 'name': body['name'], 'type': body['kind'],
                'qualifications': qualifications,
                'availability': {'status': available['status'] if available['fresh'] else 'UNAVAILABLE',
                                 'maxCaseload': available['max_caseload'], 'currentCaseload': available['current_caseload']},
                'publicKey': pem}
    adopted = [audit for audit in evaluation['audits'] if audit['status'] == 'ADOPTED_AUDITOR']
    if adopted:
        latest = max(adopted, key=lambda audit: (audit['period']['to'], audit['id']))
        bias = {}
        if 'fairness' in latest['metrics']: bias['fairnessScore'] = latest['metrics']['fairness'] / 10000
        metrics = {name: latest['metrics'][source] / 10000 for name, source in (
            ('genderBias', 'gender_bias'), ('organizationSizeBias', 'organization_size_bias'), ('claimAmountBias', 'claim_amount_bias'))
            if source in latest['metrics']}
        if metrics: bias['biasMetrics'] = metrics
        if latest['report'] is not None: bias['auditResults'] = wire.ni_uri(latest['report'])
        manifest['biasAudit'] = bias
    manifest['x-agentic-agreements'] = {
        'record': evaluation['record'], 'backing': [{'kind': row['kind'], 'value': row['value'], 'backing': row['backing']} for row in rows],
        'audits': [{'id': audit['id'], 'status': audit['status']} for audit in evaluation['audits']]}
    wire.validate(manifest, 'ArbitratorManifest')
    return manifest


def from_manifest(manifest):
    """Read a registry entry for discovery only: every claim stays the publisher's."""
    from . import agentic_arbitration as wire
    if type(manifest) in (bytes, str):
        manifest = wire.parse(manifest)
    wire.validate(manifest, 'ArbitratorManifest')
    try:
        pin = wire.key_pin(manifest['publicKey'])
    except ValueError:
        pin = None
    return {'external_id': manifest['arbitratorId'], 'type': manifest['type'], 'name': manifest.get('name'),
            'key_pin': pin, 'claims': {name: deepcopy(manifest[name]) for name in
                                       ('qualifications', 'availability', 'biasAudit', 'performanceMetrics', 'pricing') if name in manifest},
            'status': 'EXTERNAL_SELF_REPORTED_UNVERIFIED', 'appointable': False,
            'next_action': 'Obtain an AAP arbitrator record signed by this arbitrator and check conflicts before appointment.',
            **FLAGS}
