"""Named rule sets for covenant-native/0.15.

They are read-only labels on the economics view. They do not write chain state.
A chain that is not 0.15 has none of them active.
"""

from .profile import NATIVE_015 as PROTOCOL
NAMES = ('serving_rewards', 'offline_value', 'human_incentives')


def active_rule_sets(protocol):
    if protocol == PROTOCOL:
        return NAMES
    return ()
