"""Bounded, read-only agreement planning and evidence-based selection aids.

Declarations never acquire factual, legal or financial force from this module.
Callers adopt exact evidence checks and common-control groupings independently.
There are no automatic signers, arbitrary code imports, or universal ratings.
"""
from copy import deepcopy

from .crypto import exact, integer, key, need
from .discovery_rank import pagerank
from .workflow_store import canonical, identifier

PLAN = 'covenant-reliance-plan/0.1'
QUALIFICATION = 'covenant-extension-qualification/0.1'


def plan(goal, steps, *, observations=None, available=None, failures=None):
    """Compile an adopted dependency DAG; an expected hash is not evidence.

    The caller must check observations using its independently adopted verifier.
    Every complete step requires its exact expected output. A ready step still
    requires current authority, a live atomic reservation and native approvals.
    A caller-supplied failure marks that step FAILED and unpaid. It is not evidence
    and does not authorize a replacement, a refund, or a new reservation.
    """
    need(type(goal) is str and 0 < len(goal) <= 2048, 'RELIANCE_GOAL')
    need(type(steps) is list and 1 <= len(steps) <= 128, 'RELIANCE_STEPS')
    steps = deepcopy(steps); canonical(steps)
    observations = deepcopy({} if observations is None else observations)
    available = deepcopy({} if available is None else available)
    failures = deepcopy({} if failures is None else failures)
    need(type(observations) is dict and type(available) is dict and type(failures) is dict, 'RELIANCE_PLAN_INPUT')
    by_id = {}
    for step in steps:
        exact(step, 'id purpose actor adapter dependencies allocations expected_output deadline fallback')
        key(step['id']); key(step['actor']); key(step['adapter']); key(step['expected_output'])
        need(step['id'] not in by_id, 'RELIANCE_DUPLICATE_STEP'); by_id[step['id']] = step
        need(type(step['purpose']) is str and 0 < len(step['purpose']) <= 1024, 'RELIANCE_STEP_PURPOSE')
        need(type(step['dependencies']) is list and len(step['dependencies']) <= 32
             and len(set(step['dependencies'])) == len(step['dependencies']), 'RELIANCE_DEPENDENCIES')
        for dep in step['dependencies']: key(dep)
        from .reliance import _amounts
        _amounts(step['allocations'], True); integer(step['deadline'])
        need(type(step['fallback']) is str and len(step['fallback']) <= 2048, 'RELIANCE_FALLBACK')
    need(all(d in by_id for s in steps for d in s['dependencies']), 'RELIANCE_DEPENDENCY_MISSING')
    order = []; remaining = set(by_id)
    while remaining:
        ready = sorted(ref for ref in remaining if set(by_id[ref]['dependencies']) <= set(order))
        need(bool(ready), 'RELIANCE_DEPENDENCY_CYCLE'); order.extend(ready); remaining -= set(ready)
    need(set(observations) <= set(by_id), 'RELIANCE_OBSERVATION_UNKNOWN')
    need(set(failures) <= set(by_id), 'RELIANCE_FAILURE_UNKNOWN')
    need(not (set(failures) & set(observations)), 'RELIANCE_FAILURE_OBSERVED')
    for info in failures.values():
        exact(info, 'reason recovery_ms')
        need(type(info['reason']) is str and 0 < len(info['reason']) <= 400, 'RELIANCE_FAILURE')
        integer(info['recovery_ms'])
    complete = set()
    for ref, output in observations.items():
        key(output)
        need(output == by_id[ref]['expected_output'], 'RELIANCE_OUTPUT_MISMATCH'); complete.add(ref)
    for value in available.values(): integer(value)
    rows = []; frontier_cost = {}
    for ref in order:
        step = by_id[ref]
        if ref in failures:
            state = 'FAILED'
        elif ref in complete:
            state = 'OBSERVED_BY_CALLER'
        elif set(step['dependencies']) <= complete:
            state = 'READY_FOR_AUTHORIZATION'
        else:
            state = 'WAITING_FOR_EVIDENCE'
        if state == 'READY_FOR_AUTHORIZATION':
            for resource, amount in step['allocations'].items(): frontier_cost[resource] = frontier_cost.get(resource, 0) + amount
        row = {**step, 'status':state, 'evidence_assumption':'CALLER_SUPPLIED_NOT_VERIFIED_HERE',
               'authority':'RECHECK_AT_DISPATCH', 'reservation':'NOT_CREATED'}
        if state == 'FAILED':
            row['recovery_ms'] = failures[ref]['recovery_ms']
            row['reason'] = failures[ref]['reason']
            row['paid'] = 0
        rows.append(row)
    source = dict(version=PLAN, goal=goal, steps=steps)
    for amount in frontier_cost.values(): integer(amount)
    return {'version':PLAN, 'id':identifier('COVENANT-RELIANCE-PLAN-0.1', source), 'plan':source,
                     'steps':rows, 'ready_frontier_exposure':frontier_cost,
            'shortfalls':{r:max(0,v-available.get(r,0)) for r,v in frontier_cost.items()},
            'resource_values':'OWNER_DECLARED_UNITS; NO_FX_OR_TITLE_INFERRED',
            'unresolved':['Current authority and revocation', 'Atomic holds at the adopted coordinator',
                          'Acceptance tests and interpretations must be adopted by the parties',
                          'Deadlines and fallback text are declarations, not scheduled execution'],
            'execution_authorized':False}


def outcomes(subjects, reports, *, context, seeds, edges=()):
    """Contextual graph discovery plus origin/control-cluster performance counts.

    Callers should obtain reports from an owner-selected observation verifier. We count
    at most one outcome for (subject, case, control cluster). Conflicting reports
    are visible, and open disputes are not negative results. Control independence
    and factual truth cannot be established from these caller-provided records.
    """
    need(type(subjects) is list and 1 <= len(subjects) <= 256, 'RELIANCE_SUBJECTS')
    need(type(context) is str and 0 < len(context) <= 128, 'RELIANCE_OUTCOME_CONTEXT')
    need(type(reports) is list and len(reports) <= 4096, 'RELIANCE_OUTCOME_LIMIT')
    subjects = sorted(subjects); need(len(set(subjects)) == len(subjects), 'RELIANCE_DUPLICATE_SUBJECT')
    mass = pagerank(subjects, list(edges), seeds)
    origins = {}; omitted = 0
    for report in reports:
        exact(report, 'subject context case control_cluster result evidence recovery_ms')
        for name in ('subject','case','control_cluster','evidence'): key(report[name])
        need(report['result'] in {'DELIVERED','FAILED','OPEN_DISPUTE','RECOVERED','UNKNOWN'}, 'RELIANCE_OUTCOME_RESULT')
        integer(report['recovery_ms'])
        if report['context'] != context or report['subject'] not in subjects: omitted += 1; continue
        bucket = origins.setdefault((report['subject'], report['case'], report['control_cluster']), [])
        bucket.append(report)
    rows = []
    for subject in subjects:
        counts = {k:0 for k in ('delivered','failed','open_dispute','recovered','unknown','conflicting')}
        delays = []; clusters = set(); cases = set()
        for (target, case, cluster), items in origins.items():
            if target != subject: continue
            clusters.add(cluster); cases.add(case); results = {r['result'] for r in items}
            if len(results) > 1: counts['conflicting'] += 1
            else:
                result = next(iter(results)); counts[result.lower()] += 1
                if result in {'RECOVERED', 'FAILED'}: delays.append(max(r['recovery_ms'] for r in items))
        rows.append({'subject':subject, 'discovery_mass_ppb':mass[subject], **counts,
                     'distinct_cases':len(cases), 'declared_control_clusters':len(clusters),
                     'worst_reported_recovery_ms':max(delays) if delays else None})
    rows.sort(key=lambda row:(-row['discovery_mass_ppb'],row['subject']))
    return {'context':context,'subjects':rows,'omitted_reports':omitted,
            'evidence':'CALLER_SUPPLIED_RECORDS; EVIDENCE_CONTENT_NOT_VERIFIED_HERE',
            'control_independence':'CALLER_ADOPTED_NOT_ESTABLISHED', 'rank_is_authority':False,
            'open_disputes_are_penalties':False,'execution_authorized':False}


def qualification(subject, implementation, cases, *, required_categories=None):
    """Publish a precise qualification record without conferring trust or safety.

    Missing evidence and mismatched outcomes fail closed. This pure aggregator
    does not run arbitrary tests supplied by an agent. Owners run their installed
    test harness separately and retain its content-addressed evidence.
    """
    key(subject); key(implementation)
    required = ['interoperability','failure','privacy','adversarial'] if required_categories is None else required_categories
    need(type(required) is list and 1 <= len(required) <= 32 and all(type(c) is str and 0 < len(c) <= 64 for c in required)
         and len(set(required)) == len(required), 'RELIANCE_QUALIFICATION_CATEGORIES')
    need(type(cases) is list and len(cases) <= 256, 'RELIANCE_QUALIFICATION_CASES')
    seen = set(); checked = []; covered = set()
    for case in cases:
        exact(case, 'id category expected observed evidence')
        key(case['id']); need(case['id'] not in seen, 'RELIANCE_DUPLICATE_CASE'); seen.add(case['id'])
        need(type(case['category']) is str and 0 < len(case['category']) <= 64, 'RELIANCE_QUALIFICATION_CATEGORY')
        canonical(case)
        if case['evidence'] is not None: key(case['evidence'])
        passed = canonical(case['expected']) == canonical(case['observed']) and case['evidence'] is not None
        if passed: covered.add(case['category'])
        checked.append({**deepcopy(case), 'passed':passed})
    source = dict(version=QUALIFICATION, subject=subject, implementation=implementation,
                  required_categories=deepcopy(required), cases=deepcopy(cases))
    missing = sorted(set(required)-covered)
    return {'id':identifier('COVENANT-EXTENSION-QUALIFICATION-0.1', source), 'record':source,
            'cases':checked, 'missing_categories':missing,
            'status':'REPORTED_PASS' if cases and all(c['passed'] for c in checked) and not missing else 'INCOMPLETE_OR_FAILED',
            'assurance':'RESULT_AGGREGATION; EVIDENCE_CONTENT_AND_HARNESS_NOT_CHECKED',
            'installed':False,'adopted':False,'security_inherited':False,'execution_authorized':False}
