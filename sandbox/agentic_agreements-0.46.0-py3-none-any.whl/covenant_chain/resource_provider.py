"""Provider-owned inventory with atomic consumption and persistent custody fencing.

The reference authority is one private POSIX SQLite database, not a replicated
consensus service. A coordinator may move between hosts; this provider remains
the single resource authority. No callback or external effect runs after a fence
check. The actual effect is a durable inventory entitlement inside the same
transaction. Physical backing, delivery and other providers remain separate.
"""
from copy import deepcopy
import hashlib

from .crypto import exact, integer, key, need, public_key, sign, verification_key, verify
from .reliance import _amounts
from .workflow_store import WorkflowStore, canonical, identifier

VERSION = 'covenant-resource-provider/0.1'
COMMAND = 'covenant-provider-command/0.1'
RECEIPT = 'covenant-provider-receipt/0.1'
LABEL = 'COVENANT-PROVIDER-COMMAND-0.1'
RECEIPT_LABEL = 'COVENANT-PROVIDER-RECEIPT-0.1'
ZERO = '0'*64
OPERATIONS = ('freeze','handover','snapshot','reserve','consume','cancel','observe')


def validate_spec(spec):
    canonical(spec)
    exact(spec, 'version instance signer capacities accounts max_lease_seconds max_hold_seconds')
    need(spec['version'] == VERSION, 'PROVIDER_VERSION'); key(spec['instance']); verification_key(spec['signer'])
    _amounts(spec['capacities'], True)
    need(type(spec['accounts']) is dict and 1 <= len(spec['accounts']) <= 32, 'PROVIDER_ACCOUNTS')
    for wallet, account in spec['accounts'].items():
        key(wallet); exact(account, 'principal limits'); verification_key(account['principal'])
        _amounts(account['limits'], True)
        need(set(account['limits']) <= set(spec['capacities']), 'PROVIDER_ACCOUNT_RESOURCES')
    for field in ('max_lease_seconds','max_hold_seconds'):
        integer(spec[field], True); need(spec[field] <= 86400*30, 'PROVIDER_DURATION_LIMIT')


def provider_id(spec):
    validate_spec(spec)
    return identifier('COVENANT-RESOURCE-PROVIDER-0.1', spec)


def validate_command(command):
    canonical(command)
    exact(command, 'version provider wallet subject epoch operation parameters not_before expires nonce')
    need(command['version'] == COMMAND and command['operation'] in OPERATIONS, 'PROVIDER_COMMAND_VERSION_OR_OPERATION')
    for field in ('provider','wallet','nonce'): key(command[field])
    verification_key(command['subject']); integer(command['epoch'])
    integer(command['not_before']); integer(command['expires'], True)
    need(0 < command['expires']-command['not_before'] <= 300, 'PROVIDER_COMMAND_INTERVAL')
    need(type(command['parameters']) is dict, 'PROVIDER_PARAMETERS')


def command_id(command):
    validate_command(command)
    return identifier(LABEL, command)


def command_payload(command):
    return {'label':LABEL,'body':{'command':command_id(command),'provider':command['provider']},'execution_authorized':False}


def draft_command(provider, wallet, subject, epoch, operation, parameters, not_before, expires, nonce):
    command = dict(version=COMMAND,provider=provider,wallet=wallet,subject=deepcopy(subject),epoch=epoch,
                   operation=operation,parameters=deepcopy(parameters),not_before=not_before,expires=expires,nonce=nonce)
    return {'command':command,'id':command_id(command),**command_payload(command)}


def verify_command(envelope):
    exact(envelope, 'command signature'); command = envelope['command']; p = command_payload(command)
    verify(command['subject'], p['label'], p['body'], envelope['signature'])
    return command


def initial_state(spec):
    validate_spec(spec)
    return {'clock':0,'custody':{wallet:{'epoch':0,'holder':None,'expires':0,'checkpoint':ZERO}
            for wallet in spec['accounts']},'holds':{},'nonces':{}}


def hold_id(provider, wallet, effect):
    for ref in (provider,wallet,effect): key(ref)
    return identifier('COVENANT-PROVIDER-HOLD-0.1',dict(provider=provider,wallet=wallet,effect=effect))


def _record(value):
    exact(value, 'items content'); _amounts(value['items'], True)
    need(type(value['content']) is dict and len(canonical(value)) <= 65536, 'PROVIDER_RECORD_SIZE_OR_CONTENT')
    return hashlib.sha256(canonical(value)).hexdigest()


def _status(hold, now):
    return 'EXPIRED' if hold['state'] == 'HELD' and now >= hold['expires'] else hold['state']


def _allocated(state, now, wallet=None):
    used = {}
    for hold in state['holds'].values():
        if wallet is not None and hold['wallet'] != wallet: continue
        if _status(hold, now) not in ('HELD','CONSUMED'): continue
        for resource, amount in hold['items'].items(): used[resource] = used.get(resource, 0) + amount
    return used


def _capacity(spec, state, now):
    used = _allocated(state, now)
    need(all(used.get(r,0) <= capacity for r,capacity in spec['capacities'].items()), 'PROVIDER_CAPACITY_EXCEEDED')
    for wallet, account in spec['accounts'].items():
        used = _allocated(state, now, wallet)
        need(all(used.get(r,0) <= limit for r,limit in account['limits'].items()), 'PROVIDER_BUDGET_EXCEEDED')


def _snapshot(spec, state, wallet, now):
    used = _allocated(state, now, wallet)
    return {'wallet':wallet,'custody':deepcopy(state['custody'][wallet]),
            'balances':{r:{'limit':limit,'allocated':used.get(r,0),'available':limit-used.get(r,0)}
                        for r,limit in spec['accounts'][wallet]['limits'].items()},
            'holds':{ref:{**deepcopy(hold),'state':_status(hold,now)}
                     for ref,hold in state['holds'].items() if hold['wallet'] == wallet},
            'scope':'PROVIDER_OWNED_LOGICAL_INVENTORY; EXTERNAL_BACKING_NOT_ESTABLISHED',
            'raw_records_disclosed':False}


def _authorize(spec, state, command, now):
    need(command['provider'] == provider_id(spec) and command['wallet'] in spec['accounts'], 'PROVIDER_SCOPE')
    need(command['not_before'] <= now < command['expires'], 'PROVIDER_COMMAND_EXPIRED')
    lease = state['custody'][command['wallet']]
    principal = spec['accounts'][command['wallet']]['principal']
    root = canonical(command['subject']) == canonical(principal)
    if command['operation'] in ('snapshot','observe') and root: return
    need(command['epoch'] == lease['epoch'], 'PROVIDER_FENCED')
    if command['operation'] in ('freeze','handover'): need(root, 'PROVIDER_PRINCIPAL_REQUIRED')
    else:
        need(canonical(command['subject']) == canonical(lease['holder']) and now < lease['expires'],
             'PROVIDER_CUSTODY_EXPIRED_OR_WRONG_HOLDER')


def transition(spec, state, command, now, head):
    """Pure bounded inventory FSM. Caller authenticates envelope separately.

    Both checks and the returned state must commit atomically at the provider.
    Calling this function alone does not confer a reservation or custody right.
    """
    validate_command(command); integer(now); key(head)
    need(now >= state['clock'], 'PROVIDER_CLOCK_REWIND'); _authorize(spec,state,command,now)
    state = deepcopy(state); wallet = command['wallet']; p = command['parameters']; operation = command['operation']
    nonce = wallet + ':' + command['nonce']; need(nonce not in state['nonces'], 'PROVIDER_NONCE_REPLAY')
    state['clock'] = now; state['nonces'][nonce] = command_id(command)
    if operation == 'freeze':
        exact(p, 'checkpoint'); key(p['checkpoint'])
        next_epoch = state['custody'][wallet]['epoch'] + 1; integer(next_epoch,True)
        state['custody'][wallet] = dict(epoch=next_epoch,holder=None,expires=0,checkpoint=p['checkpoint'])
        result = _snapshot(spec,state,wallet,now)
    elif operation == 'handover':
        exact(p, 'holder expires expected_head checkpoint'); verification_key(p['holder']); integer(p['expires'],True)
        key(p['expected_head']); key(p['checkpoint'])
        need(p['expected_head'] == head, 'PROVIDER_CHECKPOINT_MOVED')
        need(now < p['expires'] <= now + spec['max_lease_seconds'], 'PROVIDER_LEASE_INTERVAL')
        next_epoch = state['custody'][wallet]['epoch'] + 1; integer(next_epoch,True)
        state['custody'][wallet] = dict(epoch=next_epoch,holder=deepcopy(p['holder']),expires=p['expires'],checkpoint=p['checkpoint'])
        result = _snapshot(spec,state,wallet,now)
    elif operation == 'snapshot':
        exact(p, ''); result = _snapshot(spec,state,wallet,now)
    else:
        if operation == 'reserve': exact(p, 'effect request expires')
        elif operation == 'consume': exact(p, 'effect request')
        else: exact(p, 'effect')
        key(p['effect']); ref = hold_id(command['provider'],wallet,p['effect']); hold = state['holds'].get(ref)
        if operation in ('reserve','consume'):
            request_hash = _record(p['request']); items = p['request']['items']
            need(set(items) <= set(spec['accounts'][wallet]['limits']), 'PROVIDER_RESOURCE_NOT_ADOPTED')
            if hold is not None: need(hold['request_hash'] == request_hash, 'PROVIDER_REQUEST_CHANGED')
        if operation == 'reserve':
            integer(p['expires'],True)
            need(now < p['expires'] <= min(now+spec['max_hold_seconds'],state['custody'][wallet]['expires']), 'PROVIDER_HOLD_INTERVAL')
            if hold is None:
                hold = dict(wallet=wallet,effect=p['effect'],request_hash=request_hash,items=deepcopy(items),
                            expires=p['expires'],state='HELD',output_hash=None)
                state['holds'][ref] = hold
            else:
                need(_status(hold,now) in ('HELD','CONSUMED'), 'PROVIDER_HOLD_TERMINAL')
                need(hold['expires'] == p['expires'], 'PROVIDER_HOLD_CHANGED')
            _capacity(spec,state,now)
            result = {'hold':ref,'state':_status(hold,now),'request_hash':request_hash}
        elif operation == 'consume':
            need(hold is not None, 'PROVIDER_HOLD_MISSING')
            need(_status(hold,now) in ('HELD','CONSUMED'), 'PROVIDER_HOLD_TERMINAL')
            hold['state'] = 'CONSUMED'; hold['output_hash'] = request_hash
            result = _observation(ref,hold,now)
        elif operation == 'cancel':
            need(hold is not None and hold['state'] != 'CONSUMED', 'PROVIDER_CANNOT_CANCEL')
            hold['state'] = 'CANCELLED'; result = {'hold':ref,'state':'CANCELLED'}
        else: result = _observation(ref,hold,now)
    return state, result


def _observation(ref, hold, now):
    observed = hold is not None and hold['state'] == 'CONSUMED'
    return {'hold':ref,'status':'OBSERVED' if observed else 'NOT_OBSERVED',
            'state':_status(hold,now) if hold else 'ABSENT','output_hash':hold['output_hash'] if observed else None,
            'request_hash':hold['request_hash'] if hold else None,'expires':hold['expires'] if hold else None,
            'assurance':'PROVIDER_ATOMIC_LOGICAL_INVENTORY_ENTITLEMENT',
            'physical_delivery':'NOT_ESTABLISHED'}


class ResourceProvider:
    """Owner API. Do not copy this database into two live authorities.

    Live coordinator handover is a principal-signed compare-and-swap over this
    provider's current head and epoch. All holders contact this same authority.
    Independent expected heads/backups are required for provider rollback checks.
    """
    def __init__(self, directory, spec, *, signer, clock, minimum_head=ZERO):
        self.spec = deepcopy(spec); self.id = provider_id(spec)
        need(canonical(public_key(signer)) == canonical(spec['signer']) and callable(clock), 'PROVIDER_OWNER_CONFIGURATION')
        self.signer = signer; self.clock = clock
        key(minimum_head); self.minimum_head = minimum_head
        self.store = WorkflowStore(directory, {'provider':self.id,'version':VERSION})
        # Denial-only hint: a missing/altered hint cannot authorize an action.
        # Accepted commands still replay and verify the authoritative journal.
        self.store.db.execute('CREATE TABLE IF NOT EXISTS admission(account TEXT PRIMARY KEY,holder BLOB,epoch INTEGER NOT NULL)')

    def _preflight(self, command):
        need(command['provider'] == self.id and command['wallet'] in self.spec['accounts'], 'PROVIDER_SCOPE')
        account = self.spec['accounts'][command['wallet']]
        if canonical(command['subject']) == canonical(account['principal']): return
        hint = self.store.db.execute('SELECT holder,epoch FROM admission WHERE account=?',(command['wallet'],)).fetchone()
        need(hint is not None, 'PROVIDER_CUSTODY_EXPIRED_OR_WRONG_HOLDER')
        need(command['epoch'] == hint[1], 'PROVIDER_FENCED')
        need(canonical(command['subject']) == hint[0], 'PROVIDER_CUSTODY_EXPIRED_OR_WRONG_HOLDER')

    def _history(self):
        history = self.store.events(); state = initial_state(self.spec); receipts = {}; head = ZERO
        need(self.minimum_head == ZERO or any(e['id'] == self.minimum_head for e in history), 'PROVIDER_REQUIRED_CHECKPOINT_MISSING')
        for event in history:
            body = event['body']; exact(body, 'kind task value'); need(body['kind'] == 'PROVIDER_COMMIT', 'PROVIDER_HISTORY_KIND')
            exact(body['value'], 'at envelope'); envelope = body['value']['envelope']; command = verify_command(envelope)
            ref = command_id(command); need(body['task'] == ref, 'PROVIDER_HISTORY_COMMAND')
            state,result = transition(self.spec,state,command,body['value']['at'],head)
            head = event['id']; receipts[ref] = dict(version=RECEIPT,provider=self.id,request=ref,at=state['clock'],head=head,value=result)
        return history,state,receipts,head

    def handle(self, envelope, *, crash=None):
        envelope = deepcopy(envelope); command = verify_command(envelope); ref = command_id(command)
        need(provider_id(self.spec) == self.id, 'PROVIDER_POLICY_CHANGED')
        self._preflight(command)
        self.store.db.execute('BEGIN IMMEDIATE')
        try:
            history,state,receipts,head = self._history(); now = self.clock(); integer(now)
            need(now >= state['clock'], 'PROVIDER_CLOCK_REWIND'); _authorize(self.spec,state,command,now)
            if ref in receipts: receipt = receipts[ref]
            else:
                state,result = transition(self.spec,state,command,now,head)
                body = dict(kind='PROVIDER_COMMIT',task=ref,value={'at':now,'envelope':envelope})
                raw = canonical(body); seq = len(history)+1
                need(seq <= 10000 and sum(len(canonical(e['body'])) for e in history)+len(raw) <= 128*1024*1024,
                     'PROVIDER_STORAGE_QUOTA')
                event = dict(sequence=seq,previous=head,body=body)
                head = identifier('COVENANT-WORKFLOW-EVENT-0.1',event)
                if crash == 'before_commit': raise RuntimeError('PROVIDER_INJECTED_BEFORE_COMMIT')
                self.store.db.execute('INSERT INTO events VALUES (?,?,?,?)',(seq,event['previous'],head,raw))
                receipt = dict(version=RECEIPT,provider=self.id,request=ref,at=now,head=head,value=result)
            for wallet, lease in state['custody'].items():
                self.store.db.execute('INSERT INTO admission VALUES (?,?,?) ON CONFLICT(account) DO UPDATE SET holder=excluded.holder,epoch=excluded.epoch',
                                      (wallet,canonical(lease['holder']),lease['epoch']))
            self.store.db.execute('COMMIT')
        except BaseException:
            self.store.db.execute('ROLLBACK'); raise
        if crash == 'after_commit':
            from covenant_language.handoff import InjectedCrash
            raise InjectedCrash('PROVIDER_AFTER_COMMIT')
        return {'receipt':receipt,'signature':sign(self.signer,RECEIPT_LABEL,{'receipt':identifier(RECEIPT_LABEL,receipt)})}

    def close(self): self.store.close()


def verify_receipt(envelope, command, *, expected_provider, signer):
    """Correlate one provider statement; this does not prove physical backing."""
    exact(envelope, 'receipt signature'); receipt = envelope['receipt']; canonical(receipt)
    exact(receipt, 'version provider request at head value')
    key(expected_provider); verification_key(signer)
    need(receipt['version'] == RECEIPT and receipt['provider'] == command['provider'] == expected_provider
         and receipt['request'] == command_id(command), 'PROVIDER_RECEIPT_CORRELATION')
    integer(receipt['at']); key(receipt['head']); need(type(receipt['value']) is dict, 'PROVIDER_RECEIPT_VALUE')
    need(command['not_before'] <= receipt['at'] < command['expires'], 'PROVIDER_RECEIPT_TIME')
    verify(signer,RECEIPT_LABEL,{'receipt':identifier(RECEIPT_LABEL,receipt)},envelope['signature'])
    _receipt_value(command,receipt['value'],receipt['at'])
    return deepcopy(receipt)


def _receipt_value(command, value, at):
    """Validate the adopted profile's statement shape, not external truth."""
    operation = command['operation']; parameters = command['parameters']
    if operation in ('snapshot','handover','freeze'):
        exact(value, 'wallet custody balances holds scope raw_records_disclosed')
        need(value['wallet'] == command['wallet'] and value['raw_records_disclosed'] is False
             and value['scope'] == 'PROVIDER_OWNED_LOGICAL_INVENTORY; EXTERNAL_BACKING_NOT_ESTABLISHED', 'PROVIDER_RECEIPT_SCOPE')
        custody = value['custody']; exact(custody, 'epoch holder expires checkpoint')
        integer(custody['epoch']); integer(custody['expires']); key(custody['checkpoint'])
        if custody['holder'] is not None: verification_key(custody['holder'])
        if operation in ('handover','freeze'):
            need(custody['epoch'] == command['epoch']+1 and custody['checkpoint'] == parameters['checkpoint'], 'PROVIDER_RECEIPT_CUSTODY')
            need((operation == 'freeze' and custody['holder'] is None and custody['expires'] == 0) or
                 (operation == 'handover' and canonical(custody['holder']) == canonical(parameters['holder'])
                  and custody['expires'] == parameters['expires']), 'PROVIDER_RECEIPT_CUSTODY')
        need(type(value['balances']) is dict and 1 <= len(value['balances']) <= 32
             and type(value['holds']) is dict and len(value['holds']) <= 10000, 'PROVIDER_RECEIPT_BALANCES')
        used = {}
        for ref, hold in value['holds'].items():
            key(ref); exact(hold, 'wallet effect request_hash items expires state output_hash')
            need(hold['wallet'] == command['wallet'] and ref == hold_id(command['provider'],command['wallet'],hold['effect']), 'PROVIDER_RECEIPT_HOLD')
            key(hold['request_hash']); _amounts(hold['items'],True); integer(hold['expires'],True)
            need(hold['state'] in ('HELD','EXPIRED','CANCELLED','CONSUMED'), 'PROVIDER_RECEIPT_HOLD')
            need((hold['state'] == 'CONSUMED' and hold['output_hash'] == hold['request_hash']) or
                 (hold['state'] != 'CONSUMED' and hold['output_hash'] is None), 'PROVIDER_RECEIPT_HOLD')
            need(hold['state'] != 'HELD' or at < hold['expires'], 'PROVIDER_RECEIPT_HOLD')
            need(hold['state'] != 'EXPIRED' or at >= hold['expires'], 'PROVIDER_RECEIPT_HOLD')
            if hold['state'] in ('HELD','CONSUMED'):
                for resource, amount in hold['items'].items(): used[resource] = used.get(resource,0)+amount
        need(set(used) <= set(value['balances']), 'PROVIDER_RECEIPT_BALANCES')
        for resource, balance in value['balances'].items():
            _amounts({resource:1},True); exact(balance, 'limit allocated available')
            for amount in balance.values(): integer(amount)
            need(balance['allocated'] == used.get(resource,0) and balance['allocated']+balance['available'] == balance['limit'], 'PROVIDER_RECEIPT_BALANCES')
        return
    expected_hold = hold_id(command['provider'],command['wallet'],parameters['effect'])
    if operation == 'reserve':
        exact(value, 'hold state request_hash')
        need(value['hold'] == expected_hold and value['state'] in ('HELD','CONSUMED')
             and value['request_hash'] == _record(parameters['request']), 'PROVIDER_RECEIPT_HOLD')
    elif operation == 'cancel':
        exact(value, 'hold state'); need(value['hold'] == expected_hold and value['state'] == 'CANCELLED', 'PROVIDER_RECEIPT_HOLD')
    else:
        exact(value, 'hold status state output_hash request_hash expires assurance physical_delivery')
        need(value['hold'] == expected_hold and value['state'] in ('ABSENT','HELD','EXPIRED','CANCELLED','CONSUMED')
             and value['assurance'] == 'PROVIDER_ATOMIC_LOGICAL_INVENTORY_ENTITLEMENT'
             and value['physical_delivery'] == 'NOT_ESTABLISHED', 'PROVIDER_RECEIPT_OBSERVATION')
        observed = value['state'] == 'CONSUMED'
        need(value['status'] == ('OBSERVED' if observed else 'NOT_OBSERVED'), 'PROVIDER_RECEIPT_OBSERVATION')
        if value['state'] == 'ABSENT': need(value['request_hash'] is None and value['expires'] is None, 'PROVIDER_RECEIPT_OBSERVATION')
        else: key(value['request_hash']); integer(value['expires'],True)
        need((observed and value['output_hash'] == value['request_hash']) or
             (not observed and value['output_hash'] is None), 'PROVIDER_RECEIPT_OBSERVATION')
        if operation == 'consume':need(observed and value['request_hash'] == _record(parameters['request']), 'PROVIDER_RECEIPT_OBSERVATION')
