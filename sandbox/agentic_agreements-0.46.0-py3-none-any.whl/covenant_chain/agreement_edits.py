"""Explicit draft-term removal above the unchanged human agreement profile.

Empty dictionaries retain the earlier recursive-merge meaning. Removal is a
separate opt-in operation on extension object members, never a credential
revocation, deletion of old copies, or reinterpretation of a signed record.
"""
from copy import deepcopy
from . import human_agreements as h


def revise(packet, changes, remove):
    h.validate(packet)
    h.need(type(remove) is list and len(remove) <= 32 and all(type(p) is str for p in remove),
           'AGREEMENT_REMOVE_PATHS')
    if not remove:return h.revise(packet, changes)
    parsed=[]
    for path in remove:
        h.p._path(path);parts=[p.replace('~1','/').replace('~0','~') for p in path[1:].split('/')]
        h.need(len(parts)>=2 and parts[0]=='extensions', 'AGREEMENT_REMOVE_ONLY_EXTENSION_MEMBERS')
        h.need(not any(parts[:len(old)]==old or old[:len(parts)]==parts for old in parsed),
               'AGREEMENT_REMOVE_DUPLICATE_OR_OVERLAPPING_PATHS')
        parsed.append(parts)
    candidate=deepcopy(packet)
    if changes:
        try:candidate=h.revise(packet, changes)['packet']
        except ValueError as exc:
            # The merge is only the first part of this combined operation.
            # Legacy revise validates the full candidate before this refusal;
            # valid no-op merges may still be followed by a real removal.
            if str(exc)!='HUMAN_AGREEMENT_NO_CHANGES':raise
    h.fields(changes,h.JOB_FIELDS,partial=True)
    terms=deepcopy(candidate['terms']);job=terms['job']
    for parts in parsed:
        node=job
        for part in parts[:-1]:
            h.need(type(node) is dict and part in node, 'AGREEMENT_REMOVE_PATH_MISSING');node=node[part]
        h.need(type(node) is dict, 'AGREEMENT_REMOVE_OBJECT_MEMBERS_ONLY_REPLACE_ARRAY_EXPLICITLY')
        h.need(parts[-1] in node,'AGREEMENT_REMOVE_PATH_MISSING');del node[parts[-1]]
    h._job(job)
    h.need(not h.same(job,packet['terms']['job']), 'HUMAN_AGREEMENT_NO_CHANGES')
    # Drop inherited default summaries that include a removed member; never
    # present a stale default value alongside the committed successor terms.
    removed_dots=['.'.join(parts) for parts in parsed]
    terms['proposed_defaults']=[row for row in terms['proposed_defaults'] if not any(
        row['field']==p or row['field'].startswith(p+'.') or p.startswith(row['field']+'.') for p in removed_dots)]
    successor=h._packet(terms,packet['context'],packet['target'],packet['plan'])
    return {'packet':successor,'review':h.review(successor,previous=packet),
            'changes':h._diff(packet['terms']['job'],job),'removed_paths':deepcopy(remove),
            'fresh_assents_required':True,'external_grants_revoked':False,
            'prior_copies_erased':False,'execution_authorized':False}
