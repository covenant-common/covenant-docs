"""Keyless preparation and inspection; owner trust pins cannot come from source metadata."""
from .cooperation_interface import HASH, INT, OBJECT
from . import parity_ids as ids, portable_trust as trust

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 512}
RECORDS = {'type': 'array', 'maxItems': 256, 'items': OBJECT}
HASHES = {'type': 'array', 'maxItems': 4096, 'items': HASH}
KEYS = {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': HASH}
SCOPES = {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': TEXT}
BOOL = {'type': 'boolean'}
STRINGS = {'type': 'array', 'maxItems': 32, 'items': TEXT}
POSITIVE = {'type': 'integer', 'minimum': 1, 'maximum': 2**53-1}
TERMS_ASCII = {'type': 'string', 'minLength': 1, 'maxLength': 65536,
               'description': 'Exact agreement-terms bytes as ASCII text. Give this or bytes_base64.'}
TERMS_BASE64 = {'type': 'string', 'minLength': 4, 'maxLength': 349528,
                'description': 'Canonical base64 of the exact terms bytes, at most 262144 bytes.'}
SIGNERS = {**KEYS, 'description': 'Owner-adopted Ed25519 signer keys. A valid signature by any other key is SIGNER_NOT_PINNED.'}


def spec():
    claim = {'record': OBJECT, 'events': RECORDS, 'expected_identity': HASH, 'expected_id': HASH,
             'now': INT, 'expected_identity_head': HASH}
    claim_required = ('record', 'events', 'expected_identity', 'expected_id', 'now')
    return ('covenant_portable_trust',
        'Experimental chain-independent trust records. Prepare exact unsigned key rotations, signed namespace claims, '
        'Merkle checkpoints, attenuable per-request capabilities, revocations, outcomes and introductions. Verify only '
        'against independently owner-adopted roots, witnesses, contacts, clock and pins. Full-prefix consistency; '
        'no global latest, external identity truth, cumulative spending enforcement, encryption, network, keys or execution. '
        'Offline receipt checks: an exact-terms ATR hash, a causal receipt and an opencovenant-receipt/0.1 receipt '
        '(interop unverified) against pinned signers, alone or as one bundle with an SD-JWT credential.', True, [
        ('describe', {}, ()),
        ('key_commitment', {'controller': HASH, 'nonce': HASH}, ('controller', 'nonce')),
        ('inception', {'controller': HASH, 'next_commitment': HASH, 'nonce': HASH}, ('controller', 'next_commitment', 'nonce')),
        ('rotation', {'events': RECORDS, 'expected_identity': HASH, 'next_controller': HASH,
                      'reveal_nonce': HASH, 'next_commitment': HASH},
         ('events', 'expected_identity', 'next_controller', 'reveal_nonce', 'next_commitment')),
        ('verify_identity', {'events': RECORDS, 'expected_identity': HASH, 'expected_head': HASH}, ('events', 'expected_identity')),
        ('alias', {'identity': HASH, 'identity_head': HASH, 'controller': HASH, 'namespace': TEXT,
                   'value': {}, 'issued_at': INT, 'expires': INT, 'nonce': HASH},
         ('identity', 'identity_head', 'controller', 'namespace', 'value', 'issued_at', 'expires', 'nonce')),
        ('verify_alias', claim, claim_required),
        ('checkpoint', {'log': HASH, 'entry_ids': HASHES, 'sequence': INT, 'issued_at': INT, 'previous': HASH},
         ('log', 'entry_ids', 'sequence', 'issued_at')),
        ('verify_witness', {'entry_ids': HASHES, 'record': OBJECT, 'expected_id': HASH, 'expected_log': HASH,
                            'witness_keys': KEYS, 'quorum': POSITIVE, 'now': INT, 'max_age': POSITIVE,
                            'previous_record': OBJECT, 'previous_entry_ids': HASHES},
         ('entry_ids', 'record', 'expected_id', 'expected_log', 'witness_keys', 'quorum', 'now', 'max_age')),
        ('compare_checkpoints', {'left': OBJECT, 'right': OBJECT, 'expected_log': HASH,
                                 'witness_keys': KEYS, 'quorum': POSITIVE},
         ('left', 'right', 'expected_log', 'witness_keys', 'quorum')),
        ('mandate', {'issuer': HASH, 'recipient': HASH, 'actions': SCOPES, 'resources': SCOPES,
                     'audience': TEXT, 'per_request_limits': OBJECT, 'not_before': INT, 'expires': INT,
                     'nonce': HASH, 'may_delegate': BOOL},
         ('issuer', 'recipient', 'actions', 'resources', 'audience', 'per_request_limits', 'not_before', 'expires', 'nonce')),
        ('delegate', {'parent': OBJECT, 'expected_parent_id': HASH, 'recipient': HASH, 'actions': SCOPES,
                      'resources': SCOPES, 'per_request_limits': OBJECT, 'not_before': INT, 'expires': INT,
                      'nonce': HASH, 'may_delegate': BOOL},
         ('parent', 'expected_parent_id', 'recipient', 'actions', 'resources', 'per_request_limits', 'not_before', 'expires', 'nonce')),
        ('revocations', {'root': HASH, 'revoked': HASHES, 'issued_at': INT, 'expires': INT, 'previous': OBJECT},
         ('root', 'revoked', 'issued_at', 'expires')),
        ('check_capability', {'records': RECORDS, 'root_key': HASH, 'recipient': HASH, 'action': TEXT,
                              'resource': TEXT, 'audience': TEXT, 'usage': OBJECT, 'now': INT,
                              'revocation_history': RECORDS, 'witness': OBJECT, 'minimum_revocation_sequence': INT,
                              'root_events': RECORDS, 'expected_identity': HASH, 'expected_identity_head': HASH},
         ('records', 'root_key', 'recipient', 'action', 'resource', 'audience', 'usage', 'now')),
        ('outcome', {'agreement': HASH, 'context': TEXT, 'subject': OBJECT, 'parties': KEYS,
                     'outcome': {'enum': ['FULFILLED', 'FAILED', 'DISPUTED', 'UNKNOWN']}, 'evidence': HASHES,
                     'issued_at': INT, 'nonce': HASH, 'mode': {'enum': ['BILATERAL', 'RESOLVER']}, 'resolver': HASH},
         ('agreement', 'context', 'subject', 'parties', 'outcome', 'evidence', 'issued_at', 'nonce')),
        ('verify_outcome', {'record': OBJECT, 'expected_id': HASH, 'agreement': HASH, 'context': TEXT,
                            'subject': OBJECT, 'adopted_resolvers': OBJECT},
         ('record', 'expected_id', 'agreement', 'context', 'subject')),
        ('local_reputation', {'receipts': RECORDS, 'subject': OBJECT, 'context': TEXT, 'trusted_contacts': OBJECT,
                              'now': INT, 'max_age': POSITIVE, 'adopted_resolvers': OBJECT},
         ('receipts', 'subject', 'context', 'trusted_contacts', 'now', 'max_age')),
        ('descriptor', {'identity': HASH, 'identity_head': HASH, 'controller': HASH, 'capabilities': OBJECT,
                        'endpoints': {'type': 'array', 'maxItems': 32}, 'source_claims': {'type': 'array', 'maxItems': 32},
                        'issued_at': INT, 'expires': INT, 'nonce': HASH},
         ('identity', 'identity_head', 'controller', 'capabilities', 'endpoints', 'source_claims', 'issued_at', 'expires', 'nonce')),
        ('verify_descriptor', claim, claim_required),
        ('introduction', {'issuer': HASH, 'descriptor': HASH, 'context': TEXT, 'sources': {'type': 'array', 'maxItems': 32},
                          'issued_at': INT, 'expires': INT, 'nonce': HASH},
         ('issuer', 'descriptor', 'context', 'sources', 'issued_at', 'expires', 'nonce')),
        ('verify_introduction', {'record': OBJECT, 'expected_id': HASH, 'trusted_introducers': KEYS,
                                 'context': TEXT, 'now': INT},
         ('record', 'expected_id', 'trusted_introducers', 'context', 'now')),
        ('atr_hash', {'bytes_ascii': TERMS_ASCII, 'bytes_base64': TERMS_BASE64}, ()),
        ('verify_atr', {'atr_hash': HASH, 'bytes_ascii': TERMS_ASCII, 'bytes_base64': TERMS_BASE64}, ('atr_hash',)),
        ('verify_opencovenant_receipt', {'receipt': OBJECT, 'signers': SIGNERS}, ('receipt', 'signers')),
        ('verify_causal_receipt', {'domain': HASH, 'event': OBJECT, 'signers': SIGNERS, 'expected_id': HASH},
         ('domain', 'event', 'signers')),
        ('verify_trust_bundle', {'receipt': OBJECT, 'atr': OBJECT, 'credential': OBJECT, 'signers': SIGNERS},
         ('receipt', 'atr', 'signers')),
    ])


def call(action, parameters):
    actions = {row[0] for row in spec()[3]}
    if type(action) is not str or action not in actions: raise ValueError('TRUST_TOOL_ACTION')
    if action in ids.VERIFY_ACTIONS:
        from .trust_verify import call as verify_call
        return verify_call(action, parameters)
    function = getattr(trust, action)
    result = function(**parameters)
    return {'commitment': result, 'execution_authorized': False} if action == 'key_commitment' else result
