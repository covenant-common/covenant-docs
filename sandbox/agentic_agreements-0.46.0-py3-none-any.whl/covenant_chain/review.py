"""Opt-in native0.13 bounded, consensual review of an existing service escrow.

Certifies procedure and attributed findings, not external truth. No prosecution
power over strangers, subjective slashing, automatic bounty or global rating.
"""
from .profile import MIGRATION_VERSION
from copy import deepcopy
from .crypto import exact, need, key, integer, digest
from .ecosystem import authorized, governed
from .review_status import performance_confirmed

VERSION = 'covenant-review/0.1'
TABLES = ('review_cases', 'review_jobs')
TERMINAL = {'FINAL', 'UNRESOLVED', 'CONSENSUAL'}

def _refs(refs, limit):
    need(type(refs) is list and len(refs) <= limit, 'REVIEW_EVIDENCE_LIMIT')
    for ref in refs:key(ref)
    need(refs == sorted(set(refs)), 'REVIEW_EVIDENCE_SET')

def _panel(panel, threshold):
    need(type(panel) is list and 1 <= len(panel) <= 5, 'REVIEW_PANEL')
    for who in panel:key(who)
    need(panel == sorted(set(panel)), 'REVIEW_PANEL')
    integer(threshold, True)
    need(threshold <= len(panel) and 2*threshold > len(panel), 'REVIEW_THRESHOLD')

def validate_policy(p, job, world, height):
    exact(p, 'version context procedure claimant claimant_advocate respondent_advocate judges threshold appeal_judges appeal_threshold filing_blocks response_blocks decision_blocks appeal_blocks max_evidence fallback_units')
    need(p['version'] == VERSION, 'REVIEW_VERSION');key(p['context']);key(p['procedure'])
    for f in ('claimant', 'claimant_advocate', 'respondent_advocate'):key(p[f])
    need(p['claimant'] in world['members'] and p['claimant'] != job['provider'], 'REVIEW_CLAIMANT')
    left = {p['claimant'], p['claimant_advocate']}
    right = {job['provider'], p['respondent_advocate']}
    need(not left & right, 'REVIEW_SIDE_CONFLICT')
    _panel(p['judges'], p['threshold']);_panel(p['appeal_judges'], p['appeal_threshold'])
    forbidden = set(world['members']) | set(world['seed']['governors']) | {job['world'], job['provider']} | left | right
    need(not forbidden & set(p['judges'] + p['appeal_judges']) and not set(p['judges']) & set(p['appeal_judges']), 'REVIEW_JUDGE_CONFLICT')
    for f in ('filing_blocks', 'response_blocks', 'decision_blocks', 'appeal_blocks'):
        integer(p[f], True);need(p[f] <= 1000, 'REVIEW_DURATION')
    integer(p['max_evidence'], True);need(p['max_evidence'] <= 16, 'REVIEW_EVIDENCE_LIMIT')
    integer(p['fallback_units']);need(p['fallback_units'] <= job['units'], 'REVIEW_FALLBACK')
    # Leave enough space for both equal-response phases, one appeal and finality.
    expires = height + p['filing_blocks'] + 2*(p['response_blocks']+p['decision_blocks']) + p['appeal_blocks'] + 3
    need(expires <= job['deadline'], 'REVIEW_DEADLINE')
    return expires

def preflight(s, op, p):
    if op in {'SERVICE_DECIDE', 'SERVICE_APPEAL', 'SERVICE_CHALLENGE', 'SERVICE_SETTLE', 'SERVICE_TIMEOUT'}:
        if type(p.get('job')) is str and p['job'] in s['review_jobs']:
            raise ValueError('REVIEW_PROCEDURE_REQUIRED')

def _case(s, p):
    key(p.get('case'));need(p['case'] in s['review_cases'], 'REVIEW_CASE')
    return s['review_cases'][p['case']]

def _side(c, actor):
    policy = c['policy']
    if actor in {policy['claimant'], policy['claimant_advocate']}:return 'CLAIMANT'
    if actor in {c['provider'], policy['respondent_advocate']}:return 'RESPONDENT'
    raise ValueError('REVIEW_STANDING')

def _phase(c, requested):
    need(type(requested) is str and requested in {'PRIMARY', 'APPEAL'} and c['phase'] is not None and c['phase']['kind'] == requested, 'REVIEW_PHASE')
    return c['phase']

def _argument(p, limit):
    key(p['argument']);_refs(p['evidence'], limit)
    return {'argument':p['argument'], 'evidence':deepcopy(p['evidence'])}

def manifest(case, c):
    phase = c['phase'];need(phase is not None, 'REVIEW_PHASE')
    return digest('COVENANT-REVIEW-MANIFEST-0.1', {'case':case, 'question':c['terms'], 'procedure':c['policy']['procedure'],
        'phase':phase['kind'], 'arguments':phase['arguments']})

def _start(c, kind, side, argument, height):
    p = c['policy'];response_by = height+p['response_blocks']
    c['phase'] = {'kind':kind, 'arguments':{side:argument}, 'response_by':response_by,
                  'decision_by':response_by+p['decision_blocks'], 'acks':{}, 'votes':{}}
    c['status'] = 'FILED' if kind == 'PRIMARY' else 'APPEAL'

def _finding(result, units, max_units):
    need(type(result) is str and result in {'SUPPORTED', 'REFUTED', 'INDETERMINATE'}, 'REVIEW_RESULT')
    integer(units);need(units <= max_units and (units > 0 if result == 'SUPPORTED' else units == 0), 'REVIEW_UNITS')

def _finish(s, c, tid, height, unresolved=False):
    from .mission import _finish as finish_service
    j = s['service_jobs'][c['job']];need(j['state'] == 'BOOKED', 'REVIEW_JOB_CLOSED')
    d = c.get('decision')
    uncertain = unresolved or d is None or d['result'] == 'INDETERMINATE'
    units = c['policy']['fallback_units'] if uncertain else d['units']
    finish_service(s, j, units, tid)
    c.update(status='UNRESOLVED' if uncertain else 'FINAL', final_event=tid, final_height=height,
             settled_units=units, finding={'result':'INDETERMINATE' if uncertain else d['result'],
             'units':0 if uncertain else d['units'], 'event':tid, 'source':'PROCEDURAL_RESOLUTION'},
             corrections=[])
    j['decision']={'outcome':c['finding']['result'], 'units':c['finding']['units'],
        'settlement_units':units, 'review':c['adoption'], 'event':tid, 'profile':VERSION}

def after(s, op, p, tid, height):
    # Existing bilateral discharge remains an exit; it is not a guilty finding.
    if op == 'SERVICE_DISCHARGE' and p['job'] in s['review_jobs']:
        c = s['review_cases'][s['review_jobs'][p['job']]]
        c.update(status='CONSENSUAL', final_event=tid, final_height=height,
                 settled_units=s['service_jobs'][p['job']]['delivered'],
                 finding={'result':'INDETERMINATE', 'units':0, 'event':tid, 'source':'BILATERAL_DISCHARGE'}, corrections=[])

def apply(s, old, op, p, actor, tid, height):
    if not op.startswith('REVIEW_'):return None
    if op == 'REVIEW_ADOPT':
        exact(p, 'world revision job policy approvals');key(p['job'])
        need(p['job'] in s['service_jobs'] and p['job'] not in s['review_jobs'], 'REVIEW_JOB')
        j = s['service_jobs'][p['job']];need(j['state'] == 'BOOKED' and p['world'] == j['world'], 'REVIEW_JOB_STATE')
        w = governed(s, p, op);q = p['policy'];expires = validate_policy(q, j, w, height)
        # Both sides, advocates, every new judge and every original adjudicator
        # expressly accept this exact replacement before any native decision.
        required = sorted({j['provider'], q['claimant'], q['claimant_advocate'], q['respondent_advocate'],
            j['resolver'], *q['judges'], *q['appeal_judges']} | ({j['appeal_resolver']} if j['appeal_resolver'] else set()))
        authorized(s, required, len(required), p['approvals'], op, p)
        s['review_cases'][tid] = {'job':p['job'], 'world':j['world'], 'provider':j['provider'], 'terms':j['terms'],
            'policy':deepcopy(q), 'adoption':tid, 'status':'READY', 'phase':None, 'primary':None, 'decision':None,
            'file_by':height+q['filing_blocks'], 'expires':expires, 'appeal_used':False}
        s['review_jobs'][p['job']] = tid;w['revision'] += 1
        return [p['job']]
    c = _case(s, p);j = s['service_jobs'][c['job']];q = c['policy']
    if op == 'REVIEW_FILE':
        exact(p, 'case argument evidence')
        need(c['status'] == 'READY' and height <= c['file_by'], 'REVIEW_FILE_WINDOW')
        need(_side(c, actor) == 'CLAIMANT', 'REVIEW_FILING_SIDE')
        _start(c, 'PRIMARY', 'CLAIMANT', _argument(p, q['max_evidence']), height)
    elif op == 'REVIEW_ARGUMENT':
        exact(p, 'case phase argument evidence');phase = _phase(c, p['phase'])
        need(c['status'] in {'FILED', 'APPEAL'} and height <= phase['response_by'], 'REVIEW_RESPONSE_WINDOW')
        side = _side(c, actor);need(side not in phase['arguments'], 'REVIEW_ARGUMENT_EXISTS')
        phase['arguments'][side] = _argument(p, q['max_evidence'])
    elif op == 'REVIEW_ACK':
        exact(p, 'case phase manifest');phase = _phase(c, p['phase'])
        need(c['status'] in {'FILED', 'APPEAL'} and height <= phase['decision_by'], 'REVIEW_ACK_WINDOW')
        need(set(phase['arguments']) == {'CLAIMANT', 'RESPONDENT'}, 'REVIEW_RESPONSE_REQUIRED')
        side = _side(c, actor);key(p['manifest']);need(p['manifest'] == manifest(p['case'], c), 'REVIEW_MANIFEST')
        need(side not in phase['acks'], 'REVIEW_ACK_EXISTS')
        phase['acks'][side] = {'actor':actor, 'manifest':p['manifest'], 'event':tid}
    elif op == 'REVIEW_VOTE':
        exact(p, 'case phase result units manifest reasons');phase = _phase(c, p['phase'])
        need(c['status'] in {'FILED', 'APPEAL'} and phase['response_by'] < height <= phase['decision_by'], 'REVIEW_VOTE_WINDOW')
        need(set(phase['acks']) == {'CLAIMANT', 'RESPONDENT'}, 'REVIEW_ACCESS_ACK_REQUIRED')
        key(p['manifest']);need(p['manifest'] == manifest(p['case'], c), 'REVIEW_MANIFEST');key(p['reasons'])
        panel = q['judges'] if p['phase'] == 'PRIMARY' else q['appeal_judges']
        threshold = q['threshold'] if p['phase'] == 'PRIMARY' else q['appeal_threshold']
        need(actor in panel and actor not in phase['votes'], 'REVIEW_JUDGE')
        _finding(p['result'], p['units'], j['units'])
        phase['votes'][actor] = {'result':p['result'], 'units':p['units'], 'reasons':p['reasons'], 'event':tid}
        agreeing = [v for v in phase['votes'].values() if (v['result'],v['units']) == (p['result'],p['units'])]
        if len(agreeing) >= threshold:
            c['decision'] = {'result':p['result'], 'units':p['units'], 'event':tid, 'phase':p['phase'], 'manifest':p['manifest']}
            if p['phase'] == 'PRIMARY':
                c['primary'] = deepcopy(phase);c.update(status='PROVISIONAL', appeal_until=height+q['appeal_blocks'])
            else:c.update(status='READY_TO_FINALIZE', final_after=height)
    elif op == 'REVIEW_APPEAL':
        exact(p, 'case argument evidence')
        need(c['status'] == 'PROVISIONAL' and not c['appeal_used'] and height <= c['appeal_until'], 'REVIEW_APPEAL_WINDOW')
        side = _side(c, actor);c['appeal_used'] = True
        _start(c, 'APPEAL', side, _argument(p, q['max_evidence']), height)
    elif op == 'REVIEW_FINALIZE':
        exact(p, 'case');need(c['status'] not in TERMINAL, 'REVIEW_CLOSED')
        if c['status'] == 'PROVISIONAL':
            need(height > c['appeal_until'], 'REVIEW_NOT_FINAL');_finish(s,c,tid,height)
        elif c['status'] == 'READY_TO_FINALIZE':
            need(height > c['final_after'], 'REVIEW_NOT_FINAL');_finish(s,c,tid,height)
        elif s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION} and c['status']=='APPEAL' and c.get('decision') and c['decision'].get('phase')=='PRIMARY' and c['decision'].get('result')!='INDETERMINATE':
            need(height > c['phase']['decision_by'], 'REVIEW_NOT_EXPIRED')
            silent=[judge for judge in q['appeal_judges'] if judge not in c['phase']['votes']]
            c['silent_judges']=silent
            c['judge_record']=[{'judge':judge,'reputation':'LOST','bond':'FORFEIT_RECORDED','event':tid} for judge in silent]
            c['appeal_basis']='FIRST_INSTANCE_STANDS'
            _finish(s,c,tid,height)
            c['finding']['source']='FIRST_INSTANCE_STANDS'
        else:
            boundary = c['file_by'] if c['status'] == 'READY' else c['phase']['decision_by']
            need(height > boundary, 'REVIEW_NOT_EXPIRED');_finish(s,c,tid,height,True)
    elif op == 'REVIEW_CORRECT':
        exact(p, 'case previous world revision result units reasons evidence approvals')
        need(c['status'] == 'FINAL' and len(c['corrections']) < 16, 'REVIEW_CORRECTION_STATE')
        key(p['previous']);need(p['previous'] == c['finding']['event'] and p['world'] == c['world'], 'REVIEW_CORRECTION_PARENT')
        key(p['reasons']);_refs(p['evidence'],q['max_evidence']);_finding(p['result'],p['units'],j['units'])
        w = governed(s,p,op);authorized(s,[c['provider']],1,p['approvals'],op,p)
        panel = q['appeal_judges'] if c['decision']['phase'] == 'APPEAL' else q['judges']
        threshold = q['appeal_threshold'] if c['decision']['phase'] == 'APPEAL' else q['threshold']
        authorized(s,panel,threshold,p['approvals'],op,p)
        # New attributed interpretation changes a derived view, NEVER settlement.
        c['corrections'].append({'previous':p['previous'], 'result':p['result'], 'units':p['units'],
            'reasons':p['reasons'], 'evidence':deepcopy(p['evidence']), 'event':tid})
        c['finding'] = {'result':p['result'], 'units':p['units'], 'event':tid, 'source':'CONSENSUAL_CORRECTION'}
        w['revision'] += 1
    else:raise ValueError('REVIEW_OPERATION')
    return sorted({p['case'], c['job']})

def contextual_view(state, subject, context):
    """Advisory deterministic view; callers needing assurance use verified_view."""
    key(subject);key(context)
    rows=[];counts={'SUPPORTED':0,'REFUTED':0,'INDETERMINATE':0,'PENDING':0}
    for case,c in sorted(state.get('review_cases',{}).items()):
        if c['provider'] != subject or c['policy']['context'] != context:continue
        finding = c.get('finding') if c['status'] in TERMINAL else None
        result = finding['result'] if finding else 'PENDING';counts[result] += 1
        rows.append({'case':case, 'job':c['job'], 'status':c['status'], 'result':result,
            'finding':deepcopy(finding), 'settled_units':c.get('settled_units'), 'correction_count':len(c.get('corrections',[]))})
    return {'subject':subject, 'context':context, 'counts':counts, 'cases':rows,
        'coverage':'ADOPTED_REVIEW_CASES_IN_THIS_CHAIN_ONLY', 'world_truth':'NOT_ESTABLISHED',
        'operator_independence':'NOT_ESTABLISHED', 'global_score':None}

def verified_view(genesis, history, expected_chain, minimum_height, subject, context):
    from .proofs import verify_history
    report=verify_history(genesis,history,expected_chain,minimum_height)
    return {**contextual_view(report['state'],subject,context), 'chain':expected_chain,
            'verified_height':report['height'], 'assurance':'COMMITTEE_CERTIFIED_PROCEDURE_AND_ATTRIBUTION'}

def verified_access(genesis, history, expected_chain, minimum_height, case, documents):
    """Check a certified case AND small SHA256-addressed plaintext materials.

    Access acknowledges availability, never assent to the opponent's claims.
    Large objects/custom content-addressing require an explicit external adapter.
    """
    import hashlib
    from .proofs import verify_history
    report=verify_history(genesis,history,expected_chain,minimum_height)
    c=_case(report['state'],{'case':case});phase=c['phase']
    need(c['status'] in {'FILED','APPEAL'} and phase is not None and set(phase['arguments'])=={'CLAIMANT','RESPONDENT'}, 'REVIEW_RESPONSE_REQUIRED')
    required={c['terms'],c['policy']['procedure']}
    for argument in phase['arguments'].values():required.add(argument['argument']);required.update(argument['evidence'])
    need(type(documents) is dict and set(documents)==required, 'REVIEW_MATERIAL_SET')
    total=0
    for ref,data in documents.items():
        need(type(data) is bytes and len(data)<=4*1024*1024, 'REVIEW_MATERIAL_SIZE');total+=len(data)
        need(total<=16*1024*1024 and hashlib.sha256(data).hexdigest()==ref, 'REVIEW_MATERIAL_HASH')
    return {'case':case,'phase':phase['kind'],'manifest':manifest(case,c)}
