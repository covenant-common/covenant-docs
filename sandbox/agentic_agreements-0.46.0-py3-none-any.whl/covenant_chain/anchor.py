"""Optional checkpoint anchoring. Not consulted by consensus or by LightClient.

A checkpoint is a hash of {chain_id, height, block_id, state_root, committee_hash,
qc_hash}. This module writes an OpenTimestamps detached proof in the pending
state and an Ethereum calldata blob. It does not talk to Bitcoin, a calendar,
or an L2. A pending proof does not move a light-client floor. A Bitcoin tag
supplied by an operator is recorded as unchecked.
"""
from __future__ import annotations

import hashlib

from .crypto import canonical, exact, integer, key, need

VERSION = 'covenant-checkpoint/1'
PENDING_URI = 'https://not-submitted.invalid/covenant'
HEADER = b'\x00OpenTimestamps\x00\x00Proof\x00\xbf\x89\xe2\xe8\x84\xe8\x92\x94'
PENDING_TAG = bytes.fromhex('83dfe30d2ef90c8e')
BITCOIN_TAG = bytes.fromhex('0588960d73d71901')
ANCHOR_SELECTOR = 'anchor(bytes32,uint64,bytes32,bytes32,bytes32,bytes32)'
_MASK = (1 << 64) - 1
_ROTATION = (
    (0, 36, 3, 41, 18),
    (1, 44, 10, 45, 2),
    (62, 6, 43, 15, 61),
    (28, 55, 25, 21, 56),
    (27, 20, 39, 8, 14),
)
_RC = (
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
)


class AnchorError(ValueError):
    pass


def broadcast(*_args, **_kwargs):
    raise AnchorError('NETWORK_PUBLISH_DISABLED')


def _rotl(value, bits):
    bits %= 64
    return ((value << bits) | (value >> (64 - bits))) & _MASK


def _keccak_f(state):
    for round_index in range(24):
        columns = [state[i] ^ state[i + 5] ^ state[i + 10] ^ state[i + 15] ^ state[i + 20] for i in range(5)]
        mixed = [_rotl(columns[(i + 1) % 5], 1) ^ columns[(i - 1) % 5] for i in range(5)]
        state = [state[index] ^ mixed[index % 5] for index in range(25)]
        rotated = [0] * 25
        for x in range(5):
            for y in range(5):
                rotated[y + 5 * ((2 * x + 3 * y) % 5)] = _rotl(state[x + 5 * y], _ROTATION[x][y])
        state = [
            rotated[index] ^ ((~rotated[(index // 5) * 5 + (index + 1) % 5]) & rotated[(index // 5) * 5 + (index + 2) % 5]) & _MASK
            for index in range(25)
        ]
        state[0] ^= _RC[round_index]
    return state


def keccak256(data):
    """Keccak-256 (the Ethereum function), not NIST SHA3-256."""
    need(type(data) is bytes and len(data) <= 4_000_000, 'KECCAK_INPUT')
    rate = 136
    state = [0] * 25
    payload = bytearray(data)
    payload.append(0x01)
    while len(payload) % rate:
        payload.append(0)
    payload[-1] |= 0x80
    for offset in range(0, len(payload), rate):
        block = payload[offset:offset + rate]
        for index in range(rate // 8):
            state[index] ^= int.from_bytes(block[index * 8:(index + 1) * 8], 'little')
        state = _keccak_f(state)
    out = bytearray()
    for index in range(rate // 8):
        out += state[index].to_bytes(8, 'little')
    return bytes(out[:32])


def make_checkpoint(chain_id, height, block_id, state_root, committee_hash, qc_hash):
    integer(height)
    for name, value in (('chain_id', chain_id), ('block_id', block_id), ('state_root', state_root),
                        ('committee_hash', committee_hash), ('qc_hash', qc_hash)):
        key(value)
    body = {
        'v': VERSION, 'chain_id': chain_id, 'height': height, 'block_id': block_id,
        'state_root': state_root, 'committee_hash': committee_hash, 'qc_hash': qc_hash,
    }
    canonical(body)
    return body


def checkpoint_digest(body):
    exact(body, 'v chain_id height block_id state_root committee_hash qc_hash')
    need(body['v'] == VERSION, 'CHECKPOINT_VERSION')
    return hashlib.sha256(canonical(body)).digest()


def due(height, interval):
    integer(height)
    integer(interval, True)
    need(interval <= 100000, 'ANCHOR_INTERVAL')
    return height > 0 and height % interval == 0


def _varuint(value):
    if value == 0:
        return b'\x00'
    out = bytearray()
    while value:
        byte = value & 0x7f
        value >>= 7
        if value:
            byte |= 0x80
        out.append(byte)
    return bytes(out)


def _varbytes(value):
    return _varuint(len(value)) + value


def ots_pending(digest):
    """Detached OpenTimestamps proof with an unroutable pending calendar URI.

    The URI ends in .invalid so an ots upgrade cannot reach a real calendar
    through this file. An operator who wants a Bitcoin attestation runs the
    official client themselves and keeps the upgraded file beside this one.
    """
    need(type(digest) is bytes and len(digest) == 32, 'OTS_DIGEST')
    uri = PENDING_URI.encode('ascii')
    payload = _varbytes(uri)
    attestation = PENDING_TAG + _varbytes(payload)
    return HEADER + bytes((1, 0x08)) + digest + b'\x00' + attestation


def _read_varuint(data, offset):
    value = 0
    shift = 0
    while True:
        if offset >= len(data) or shift > 28:
            raise AnchorError('OTS_TRUNCATED')
        byte = data[offset]
        offset += 1
        value |= (byte & 0x7f) << shift
        if not byte & 0x80:
            return value, offset
        shift += 7


def _read_varbytes(data, offset):
    length, offset = _read_varuint(data, offset)
    if length > 8192 or offset + length > len(data):
        raise AnchorError('OTS_TRUNCATED')
    return data[offset:offset + length], offset + length


def unchecked_bitcoin_tag(digest, height):
    """The byte shape of a Bitcoin attestation. This is not a Bitcoin proof.

    Nothing is submitted, and the header chain is not checked. light_floor
    will not move on the strength of this tag.
    """
    need(type(digest) is bytes and len(digest) == 32, 'OTS_DIGEST')
    integer(height)
    payload = _varuint(height)
    attestation = BITCOIN_TAG + _varbytes(payload)
    return HEADER + bytes((1, 0x08)) + digest + b'\x00' + attestation


def read_ots(proof):
    """Read the pending proof this module writes. Upgraded merkle paths are not interpreted."""
    need(type(proof) is bytes and len(proof) <= 4096, 'OTS_SIZE')
    if not proof.startswith(HEADER) or len(proof) < len(HEADER) + 2 + 32 + 1 + 8:
        raise AnchorError('OTS_HEADER')
    offset = len(HEADER)
    if proof[offset] != 1 or proof[offset + 1] != 0x08:
        raise AnchorError('OTS_VERSION')
    offset += 2
    digest = proof[offset:offset + 32]
    offset += 32
    if proof[offset] != 0x00:
        raise AnchorError('OTS_NOT_SIMPLE')
    offset += 1
    tag = proof[offset:offset + 8]
    offset += 8
    payload, offset = _read_varbytes(proof, offset)
    if offset != len(proof):
        raise AnchorError('OTS_TRAILING')
    if tag == PENDING_TAG:
        uri, used = _read_varbytes(payload, 0)
        if used != len(payload) or uri.decode('ascii') != PENDING_URI:
            raise AnchorError('OTS_URI')
        kind = 'pending'
        height = None
    elif tag == BITCOIN_TAG:
        height, used = _read_varuint(payload, 0)
        if used != len(payload):
            raise AnchorError('OTS_BITCOIN_PAYLOAD')
        kind = 'bitcoin-tag'
    else:
        raise AnchorError('OTS_ATTESTATION')
    return {
        'file_sha256': digest.hex(),
        'kind': kind,
        'bitcoin_height': height,
        'bitcoin_header_chain_checked': False,
        'calendar_contacted': False,
    }


def agree_checkpoints(sources):
    """Adopt a candidate floor only when three operators present one digest.

    A pending OpenTimestamps file is not a source. Duplicate reports from one
    operator count once. The report leaves any existing floor where it was.
    """
    need(type(sources) is list and 1 <= len(sources) <= 32, 'CHECKPOINT_SOURCES')
    by_operator = {}
    heights = {}
    for source in sources:
        exact(source, 'operator checkpoint')
        operator = source['operator']
        need(type(operator) is str and 1 <= len(operator) <= 80 and all(33 <= ord(c) <= 126 for c in operator), 'CHECKPOINT_OPERATOR')
        digest = checkpoint_digest(source['checkpoint']).hex()
        prior = by_operator.get(operator)
        if prior is not None and prior != digest:
            return _agreement(False, 'CHECKPOINT_OPERATOR_CONFLICT', len(by_operator))
        by_operator[operator] = digest
        heights[digest] = source['checkpoint']['height']
    if len(by_operator) < 3:
        return _agreement(False, 'CHECKPOINT_SOURCES', len(by_operator))
    chosen = set(by_operator.values())
    if len(chosen) != 1:
        return _agreement(False, 'CHECKPOINT_DISAGREEMENT', len(by_operator))
    digest = chosen.pop()
    report = _agreement(True, 'CHECKPOINT_AGREED', len(by_operator))
    report['digest'] = digest
    report['candidate_height'] = heights[digest]
    return report


def _agreement(adopted, reason, operators):
    return {
        'adopted': adopted,
        'reason': reason,
        'digest': None,
        'candidate_height': None,
        'operators': operators,
        'floor_moved': False,
        'applied': False,
        'light_client_called': False,
    }


def light_floor(checkpoint, proof, prior_floor=0):
    """A floor a caller may pass to LightClient. This does not call LightClient.

    Pending proofs leave the floor where it was. A Bitcoin tag is not applied:
    this process has not checked a header chain.
    """
    integer(prior_floor)
    parsed = read_ots(proof)
    need(parsed['file_sha256'] == checkpoint_digest(checkpoint).hex(), 'OTS_CHECKPOINT')
    return {
        'minimum_height': prior_floor,
        'candidate_height': checkpoint['height'] if parsed['kind'] == 'bitcoin-tag' else None,
        'applied': False,
        'bitcoin_header_chain_checked': False,
        'kind': parsed['kind'],
    }


def l2_calldata(checkpoint):
    """ABI encoding for the undeployed CovenantAnchor interface. No RPC."""
    selector = keccak256(ANCHOR_SELECTOR.encode('ascii'))[:4]
    words = [
        bytes.fromhex(checkpoint['chain_id']),
        checkpoint['height'].to_bytes(32, 'big'),
        bytes.fromhex(checkpoint['block_id']),
        bytes.fromhex(checkpoint['state_root']),
        bytes.fromhex(checkpoint['committee_hash']),
        bytes.fromhex(checkpoint['qc_hash']),
    ]
    need(all(len(word) == 32 for word in words), 'L2_WORD')
    return {
        'to': None,
        'data': (selector + b''.join(words)).hex(),
        'broadcast': False,
        'chain_checked': False,
    }


def record_l2_receipt(call, tx_hash):
    need(call.get('broadcast') is False, 'L2_CALL')
    key(tx_hash)
    return {'tx_hash': tx_hash, 'independently_confirmed': False, 'chain_checked': False}


def snapshot_locator(archive_bytes, height, state_root):
    """Content addresses for an archive.pack the caller already built. archive.py is unchanged."""
    from .release_trust import cid_v1_raw, torrent_v2
    integer(height)
    key(state_root)
    need(type(archive_bytes) is bytes and 1 <= len(archive_bytes) <= 64 * 1024 * 1024, 'SNAPSHOT_BYTES')
    torrent = torrent_v2('archive.pack', archive_bytes, [])
    return {
        'sha512': hashlib.sha512(archive_bytes).hexdigest(),
        'cid_v1': cid_v1_raw(archive_bytes),
        'infohash_v2': torrent['infohash_v2'],
        'magnet': torrent['magnet'],
        'height': height,
        'state_root': state_root,
        'published': False,
    }
