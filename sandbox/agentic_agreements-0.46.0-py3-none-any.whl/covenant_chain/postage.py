"""Refundable postage for unsolicited proposals.

AAP application profile ``covenant-postage/0.1``. A recipient publishes a signed
postage POLICY: how much a stranger must stake to put an unsolicited proposal
or RFP response in its inbox, which holders it adopts, and how long it takes to
decide. A sender signs a STAMP binding an exact proposal to that policy; an
adopted holder signs a HOLD receipt for the stake. The recipient signs a
DECISION: RELEASE (welcome, the stake goes back) or KEEP (spam, the stake goes
to the recipient or the policy's beneficiary). Silence past the deadline
refunds the sender: nothing converts an unknown into a payment.

Standing makes postage cheaper for honest agents as the network grows: trusted
contacts, agents reached through signed introductions and agents previously
welcomed pay their lower tier. Signed KEEP decisions, by the recipient and
optionally by its trusted contacts, forfeit those discounts and escalate the
price, so a spammer pays full price everywhere and loses it.

Postage admits; it never ranks. The holder here is a local custodian of
disposable units on the existing append-only workflow store; real money needs a
separately adopted custody adapter. HTTP 402 (RFC 9110 section 15.5.3) is the
old idea; nothing here moves funds on any rail.
"""
import base64
from copy import deepcopy
import hashlib
import os
from pathlib import Path
import sqlite3
import stat

from .crypto import canonical, digest, exact, integer, key, need, public_key, sign, verification_key, verify
from . import introductions as intro

VERSION = 'covenant-postage/0.1'
LABEL = 'COVENANT-POSTAGE-0.1'
PROPOSAL_LABEL = 'COVENANT-POSTAGE-PROPOSAL-0.1'
FIELDS = {
    'POLICY': 'recipient sequence issued_at expires unit holders contexts tiers kept_step_bps max_amount '
              'decision_window beneficiary shared_evidence',
    'STAMP': 'sender recipient policy proposal context amount unit holder issued_at decide_by nonce',
    'HOLD': 'holder stamp sender recipient amount unit decide_by payee held_at',
    'DECISION': 'recipient stamp decision decided_at',
    'SETTLEMENT': 'holder stamp hold outcome paid_to amount unit settled_at decision',
}
SIGNER = {'POLICY': 'recipient', 'STAMP': 'sender', 'HOLD': 'holder', 'DECISION': 'recipient', 'SETTLEMENT': 'holder'}
TIERS = ('TRUSTED', 'INTRODUCED', 'KNOWN', 'UNKNOWN')
DECISIONS = ('KEEP', 'RELEASE')
OUTCOMES = ('KEPT', 'RELEASED', 'REFUNDED_UNDECIDED')
PROPOSAL_KINDS = ('INTENT_MARKET_BID', 'DIRECTORY_BID', 'WORKSPACE_PROPOSAL', 'EXACT_BYTES')
MAX_AMOUNT = 2**53 - 1
MAX_RECORD_BYTES = 16384
MAX_ITEMS = 256
MAX_EVIDENCE = 1024
MAX_EXACT_BYTES = 262144
MAX_ESCALATION_STEPS = 64

REMEDIATION = {
    'POSTAGE_FIELDS': 'Use the exact field set of the record kind from describe().',
    'POSTAGE_PROFILE': 'Use version covenant-postage/0.1.',
    'POSTAGE_KIND': 'Use kind POLICY, STAMP, HOLD, DECISION or SETTLEMENT where each is expected.',
    'POSTAGE_TEXT': 'Use 1 to 80 printable ASCII characters (unit at most 32).',
    'POSTAGE_LIST': 'Use 1 to 16 distinct sorted entries.',
    'POSTAGE_TIERS': 'Give TRUSTED, INTRODUCED, KNOWN and UNKNOWN integer amounts; UNKNOWN at least 1 and none above max_amount.',
    'POSTAGE_POLICY_RULES': 'Use kept_step_bps 0..100000, decision_window at least 1 and a boolean shared_evidence.',
    'POSTAGE_WINDOW': 'Use integer times with issued_at strictly before expires or decide_by.',
    'POSTAGE_AMOUNT': 'Use a positive integer amount within the policy maximum.',
    'POSTAGE_SELF': 'A sender cannot stamp a proposal to itself.',
    'POSTAGE_ENVELOPE': 'Pass {"body": ..., "signature": <128 hex>} exactly.',
    'POSTAGE_SIGNATURE': 'Obtain a fresh signature by the record\'s named signer over the unchanged body.',
    'POSTAGE_COMPLEXITY': 'Flatten the input; nesting and node counts are bounded.',
    'POSTAGE_JSON_TYPE': 'Use JSON objects, arrays, strings, integers, booleans or null.',
    'POSTAGE_SIZE': 'Stay within the documented record, item and byte bounds.',
    'POSTAGE_PROPOSAL_KIND': 'Use INTENT_MARKET_BID, DIRECTORY_BID, WORKSPACE_PROPOSAL or EXACT_BYTES.',
    'POSTAGE_PROPOSAL': 'Supply the exact proposal: an intent-market BID, a signed directory BID, a 64-hex workspace event id or canonical base64 bytes.',
    'POSTAGE_POLICY_TIME': 'The policy is not in force at the supplied time; fetch the recipient\'s current signed policy.',
    'POSTAGE_POLICY_MISMATCH': 'The stamp must name this exact policy, recipient, unit, an adopted holder and a listed context.',
    'POSTAGE_DEADLINE': 'decide_by must equal issued_at plus the policy decision_window.',
    'POSTAGE_PROPOSAL_MISMATCH': 'The stamp must bind the exact proposal reference and the sender being screened.',
    'POSTAGE_STAMP_TIME': 'The stamp is not yet issued or its decision deadline has passed; send a fresh stamp.',
    'POSTAGE_REQUIRED': 'Attach a stamp and an adopted holder\'s HOLD receipt; this sender has no waiver.',
    'POSTAGE_INSUFFICIENT': 'Stake at least the required amount for your standing tier with this recipient.',
    'POSTAGE_HOLD_MISMATCH': 'The HOLD receipt must match the stamp exactly: holder, amount, unit, deadline and payee.',
    'POSTAGE_HOLD_TIME': 'The hold is dated after the supplied time; use the holder\'s actual receipt.',
    'POSTAGE_DECISION': 'A decision is KEEP or RELEASE by the stamp\'s recipient for that exact stamp.',
    'POSTAGE_DECISION_LATE': 'The decision deadline passed; the stake can only be refunded to the sender.',
    'POSTAGE_DECISION_PENDING': 'Wait for the recipient\'s decision or for the deadline to pass; silence refunds.',
    'POSTAGE_NOT_KEEP': 'Only a timely KEEP decision bound to its signed stamp is a spam mark.',
    'POSTAGE_NOT_RELEASE': 'Only a timely RELEASE decision bound to its signed stamp is a welcome mark.',
    'POSTAGE_HOLDER': 'Use the holder key named in the stamp and adopted by the recipient\'s policy.',
    'POSTAGE_BALANCES': 'Opening balances map at most 4096 keys to non-negative integers.',
    'POSTAGE_FUNDS': 'The sender\'s balance at this holder is below the stamped amount.',
    'POSTAGE_UNKNOWN_STAMP': 'No hold exists at this holder for that stamp id.',
    'POSTAGE_ALREADY_SETTLED': 'This stamp was already settled differently; the first settlement is final.',
    'POSTAGE_AUDIT': 'The holder journal does not conserve units; restore from a verified backup.',
    'POSTAGE_BACKUP_TARGET': 'Back up into a new, private directory that does not exist yet.',
}


def remediation(code):
    return REMEDIATION.get(code, intro.remediation(code))


def _text(value, maximum=80):
    need(type(value) is str and 0 < len(value) <= maximum and all(32 <= ord(c) <= 126 for c in value), 'POSTAGE_TEXT')


def _keyed(value):
    need(type(value) is str, 'KEY'); verification_key(value)


def _sorted_unique(values, check, maximum=16):
    need(type(values) is list and 1 <= len(values) <= maximum and values == sorted(set(values)), 'POSTAGE_LIST')
    for value in values:
        check(value)


def _validate(body):
    intro._bounded(body, MAX_RECORD_BYTES, 'POSTAGE')
    need(type(body) is dict and type(body.get('kind')) is str and body['kind'] in FIELDS, 'POSTAGE_KIND')
    need(set(body) == set(('version kind ' + FIELDS[body['kind']]).split()), 'POSTAGE_FIELDS')
    need(body['version'] == VERSION, 'POSTAGE_PROFILE')
    kind = body['kind']
    _keyed(body[SIGNER[kind]])
    if kind == 'POLICY':
        integer(body['sequence']); integer(body['issued_at']); integer(body['expires'])
        need(body['issued_at'] < body['expires'], 'POSTAGE_WINDOW')
        _text(body['unit'], 32); _sorted_unique(body['holders'], _keyed); _sorted_unique(body['contexts'], _text)
        tiers = body['tiers']; integer(body['max_amount'], True)
        need(type(tiers) is dict and set(tiers) == set(TIERS) and all(type(v) is int and 0 <= v <= body['max_amount']
             for v in tiers.values()) and tiers['UNKNOWN'] >= 1, 'POSTAGE_TIERS')
        need(type(body['kept_step_bps']) is int and 0 <= body['kept_step_bps'] <= 100000 and
             type(body['decision_window']) is int and 1 <= body['decision_window'] <= 2**40 and
             type(body['shared_evidence']) is bool, 'POSTAGE_POLICY_RULES')
        if body['beneficiary'] is not None:
            _keyed(body['beneficiary'])
    elif kind == 'STAMP':
        _keyed(body['recipient']); need(body['sender'] != body['recipient'], 'POSTAGE_SELF')
        key(body['policy']); key(body['proposal']); key(body['nonce']); _text(body['context']); _text(body['unit'], 32)
        _keyed(body['holder']); integer(body['amount'], True)
        integer(body['issued_at']); integer(body['decide_by'])
        need(body['issued_at'] < body['decide_by'], 'POSTAGE_WINDOW')
    elif kind == 'HOLD':
        key(body['stamp']); _keyed(body['sender']); _keyed(body['recipient']); _keyed(body['payee'])
        integer(body['amount'], True); _text(body['unit'], 32); integer(body['decide_by']); integer(body['held_at'])
    elif kind == 'DECISION':
        key(body['stamp']); integer(body['decided_at'])
        need(body['decision'] in DECISIONS, 'POSTAGE_DECISION')
    else:
        key(body['stamp']); key(body['hold']); _keyed(body['paid_to']); integer(body['amount'], True)
        _text(body['unit'], 32); integer(body['settled_at'])
        need(body['outcome'] in OUTCOMES, 'POSTAGE_DECISION')
        need((body['decision'] is None) == (body['outcome'] == 'REFUNDED_UNDECIDED'), 'POSTAGE_DECISION')
        if body['decision'] is not None:
            key(body['decision'])
    need(len(canonical(body)) <= MAX_RECORD_BYTES, 'POSTAGE_SIZE')
    return body


def record_id(body):
    _validate(body)
    return digest(LABEL, body)


def _prepare(kind, **fields):
    body = {'version': VERSION, 'kind': kind, **deepcopy(fields)}
    return {'id': record_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [body[SIGNER[kind]]], 'signature_created': False, 'execution_authorized': False}


def sign_record(body, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body[SIGNER[body['kind']]], 'POSTAGE_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}


def open_record(envelope, kind=None):
    intro._bounded(envelope, MAX_RECORD_BYTES * 2, 'POSTAGE')
    need(type(envelope) is dict and set(envelope) == {'body', 'signature'}, 'POSTAGE_ENVELOPE')
    body = _validate(envelope['body'])
    need(kind is None or body['kind'] == kind, 'POSTAGE_KIND')
    try:
        verify(body[SIGNER[body['kind']]], LABEL, body, envelope['signature'])
    except ValueError:
        raise ValueError('POSTAGE_SIGNATURE') from None
    return {'id': digest(LABEL, body), 'body': deepcopy(body)}


def policy(recipient, sequence, issued_at, expires, unit, holders, contexts, tiers, max_amount, decision_window,
           kept_step_bps=10000, beneficiary=None, shared_evidence=False):
    """Prepare an unsigned recipient policy. Amounts and rules are the recipient's own."""
    return _prepare('POLICY', recipient=recipient, sequence=sequence, issued_at=issued_at, expires=expires,
                    unit=unit, holders=holders, contexts=contexts, tiers=tiers, kept_step_bps=kept_step_bps,
                    max_amount=max_amount, decision_window=decision_window, beneficiary=beneficiary,
                    shared_evidence=shared_evidence)


def stamp(sender, policy_envelope, proposal, context, amount, holder, issued_at, nonce):
    """Prepare an unsigned stamp for one exact proposal under the recipient's signed policy."""
    rules = open_record(policy_envelope, 'POLICY')
    body = rules['body']
    need(context in body['contexts'] and holder in body['holders'], 'POSTAGE_POLICY_MISMATCH')
    need(type(amount) is int and amount <= body['max_amount'], 'POSTAGE_AMOUNT')
    return _prepare('STAMP', sender=sender, recipient=body['recipient'], policy=rules['id'], proposal=proposal,
                    context=context, amount=amount, unit=body['unit'], holder=holder, issued_at=issued_at,
                    decide_by=issued_at + body['decision_window'], nonce=nonce)


def decision(recipient, stamp_id, choice, decided_at):
    """Prepare the recipient's unsigned KEEP (spam) or RELEASE (welcome) decision."""
    return _prepare('DECISION', recipient=recipient, stamp=stamp_id, decision=choice, decided_at=decided_at)


def proposal_reference(kind, value):
    """Domain-separated reference to an exact proposal, using each profile's own identifier."""
    need(kind in PROPOSAL_KINDS, 'POSTAGE_PROPOSAL_KIND')
    try:
        if kind == 'INTENT_MARKET_BID':
            from covenant_language import intent_market
            need(type(value) is dict and value.get('kind') == 'BID', 'POSTAGE_PROPOSAL')
            ident, sender = intent_market.identifier(value), value['solver']
        elif kind == 'DIRECTORY_BID':
            from .directory_network import open_document
            opened = open_document(value)
            need(opened['body']['kind'] == 'BID', 'POSTAGE_PROPOSAL')
            ident, sender = opened['id'], opened['body']['signer']
        elif kind == 'WORKSPACE_PROPOSAL':
            key(value); ident, sender = value, None
        else:
            need(type(value) is str and len(value) <= (MAX_EXACT_BYTES * 4 + 2) // 3 + 4, 'POSTAGE_SIZE')
            raw = base64.b64decode(value.encode('ascii'), validate=True)
            need(base64.b64encode(raw).decode('ascii') == value and len(raw) <= MAX_EXACT_BYTES, 'POSTAGE_PROPOSAL')
            ident, sender = hashlib.sha256(raw).hexdigest(), None
    except (ValueError, TypeError, UnicodeError) as error:
        code = intro._code(error)
        raise ValueError(code if code.startswith('POSTAGE_') else 'POSTAGE_PROPOSAL') from None
    return {'kind': kind, 'id': ident, 'reference': digest(PROPOSAL_LABEL, {'kind': kind, 'id': ident}),
            'claimed_sender': sender}


def required(policy_body, tier, kept=0):
    """Pure policy arithmetic: tier amount, with kept stamps forfeiting discounts and escalating."""
    need(tier in TIERS, 'POSTAGE_TIERS'); integer(kept)
    tiers = policy_body['tiers']; cap = policy_body['max_amount']
    amount = tiers[tier]
    if kept and tier != 'TRUSTED':
        amount = max(amount, tiers['UNKNOWN'])
        for _ in range(min(kept, MAX_ESCALATION_STEPS)):
            amount = min(cap, amount * (10000 + policy_body['kept_step_bps']) // 10000)
    return min(amount, cap)


def price(policy_body, *, trusted, introduced, welcomed, kept):
    """Pure tier rule shared by standing() and the growth simulation: the cheapest applicable tier."""
    applicable = ['UNKNOWN']
    if welcomed:
        applicable.append('KNOWN')
    if introduced and not trusted:
        applicable.append('INTRODUCED')
    if trusted:
        applicable.append('TRUSTED')
    amount, _, tier = min((required(policy_body, name, kept), TIERS.index(name), name) for name in applicable)
    return tier, amount


def _mark(item, wanted, code):
    need(type(item) is dict and set(item) == {'stamp', 'decision'}, code)
    stamped = open_record(item['stamp'], 'STAMP'); decided = open_record(item['decision'], 'DECISION')
    body = stamped['body']; choice = decided['body']
    need(choice['stamp'] == stamped['id'] and choice['recipient'] == body['recipient'] and
         choice['decision'] == wanted and choice['decided_at'] <= body['decide_by'], code)
    return {'sender': body['sender'], 'recipient': body['recipient'], 'at': choice['decided_at'],
            'stamp': stamped['id'], 'decision': decided['id']}


def spam_mark(item):
    """A verified, timely KEEP decision bound to its stamp: {sender, recipient, at, stamp, decision}."""
    return _mark(item, 'KEEP', 'POSTAGE_NOT_KEEP')


def welcome_mark(item):
    """A verified, timely RELEASE decision bound to its stamp."""
    return _mark(item, 'RELEASE', 'POSTAGE_NOT_RELEASE')


def _marks(items, opener, excluded, label):
    need(type(items) in (list, tuple) and len(items) <= MAX_EVIDENCE, 'POSTAGE_SIZE')
    found = {}
    for item in items:
        try:
            mark = opener(item)
            found[mark['stamp']] = mark
        except ValueError as error:
            excluded.append({'kind': label, 'status': 'EXCLUDED', 'reason': intro._code(error)})
    return list(found.values())


EVIDENCE_KEYS = frozenset(('trusted_contacts', 'introductions', 'receipts', 'withdrawals', 'released', 'kept',
                           'adopted_resolvers', 'max_depth', 'decay_bps', 'anchors'))


def _evidence(evidence):
    need(set(evidence) <= EVIDENCE_KEYS and 'trusted_contacts' in evidence, 'POSTAGE_FIELDS')
    return evidence


def standing(policy_body, sender, now, *, trusted_contacts, introductions=(), receipts=(), withdrawals=(),
             released=(), kept=(), adopted_resolvers=None, max_depth=intro.DEFAULT_DEPTH,
             decay_bps=intro.DEFAULT_DECAY_BPS, anchors=None):
    """The recipient's view of one sender: tier, kept count and required postage."""
    _keyed(sender); integer(now)
    recipient = policy_body['recipient']
    contacts = intro._seeds(trusted_contacts) if trusted_contacts else {}
    excluded = []
    if anchors is None and contacts:
        anchors = intro.reach(contacts, list(introductions), list(receipts), None, now, withdrawals=list(withdrawals),
                              adopted_resolvers=adopted_resolvers, max_depth=max_depth, decay_bps=decay_bps)['reached']
    anchors = anchors or {}
    welcomed = [m for m in _marks(released, welcome_mark, excluded, 'RELEASE')
                if m['sender'] == sender and m['recipient'] == recipient and m['at'] <= now]
    spam = [m for m in _marks(kept, spam_mark, excluded, 'KEEP') if m['sender'] == sender and m['at'] <= now and
            (m['recipient'] == recipient or (policy_body['shared_evidence'] and m['recipient'] in contacts))]
    count = len(spam)
    tier, amount = price(policy_body, trusted=sender in contacts, introduced=sender in anchors,
                         welcomed=bool(welcomed), kept=count)
    return {'sender': sender, 'tier': tier, 'kept': count, 'welcomed': len(welcomed), 'required': amount,
            'shared_evidence_used': policy_body['shared_evidence'], 'excluded': excluded,
            'basis': 'RECIPIENT_CONTACTS_INTRODUCTIONS_AND_SIGNED_DECISIONS_ONLY', 'execution_authorized': False}


def admit(policy_envelope, proposal, sender, now, *, stamp=None, hold=None, view=None, **evidence):
    """Admit one unsolicited proposal to the recipient's inbox, or refuse with a stable code.

    ``proposal`` is {kind, value} for ``proposal_reference``. ``view`` may carry a
    precomputed ``standing``; otherwise it is computed from ``evidence``.
    """
    rules = open_record(policy_envelope, 'POLICY'); body = rules['body']; integer(now)
    need(body['issued_at'] <= now < body['expires'], 'POSTAGE_POLICY_TIME')
    need(type(proposal) is dict and set(proposal) == {'kind', 'value'}, 'POSTAGE_PROPOSAL')
    ref = proposal_reference(proposal['kind'], proposal['value'])
    need(ref['claimed_sender'] in (None, sender), 'POSTAGE_PROPOSAL_MISMATCH')
    seen = view if view is not None else standing(body, sender, now, **_evidence(evidence))
    base = {'proposal': ref['reference'], 'sender': sender, 'recipient': body['recipient'], 'policy': rules['id'],
            'tier': seen['tier'], 'kept': seen['kept'], 'required': seen['required'],
            'postage_affects_ranking': False, 'assent_created': False, 'execution_authorized': False}
    if seen['required'] == 0:
        return {**base, 'status': 'ADMITTED_WITHOUT_POSTAGE', 'attached': 0, 'stamp': None, 'decide_by': None}
    need(stamp is not None and hold is not None, 'POSTAGE_REQUIRED')
    stamped = open_record(stamp, 'STAMP'); held = open_record(hold, 'HOLD')
    sb, hb = stamped['body'], held['body']
    need(sb['policy'] == rules['id'] and sb['recipient'] == body['recipient'] and sb['unit'] == body['unit'] and
         sb['holder'] in body['holders'] and sb['context'] in body['contexts'], 'POSTAGE_POLICY_MISMATCH')
    need(sb['decide_by'] == sb['issued_at'] + body['decision_window'], 'POSTAGE_DEADLINE')
    need(sb['proposal'] == ref['reference'] and sb['sender'] == sender, 'POSTAGE_PROPOSAL_MISMATCH')
    need(sb['issued_at'] <= now < sb['decide_by'], 'POSTAGE_STAMP_TIME')
    payee = body['beneficiary'] or body['recipient']
    need(hb['stamp'] == stamped['id'] and hb['holder'] == sb['holder'] and hb['sender'] == sender and
         hb['recipient'] == sb['recipient'] and hb['amount'] == sb['amount'] and hb['unit'] == sb['unit'] and
         hb['decide_by'] == sb['decide_by'] and hb['payee'] == payee, 'POSTAGE_HOLD_MISMATCH')
    need(hb['held_at'] <= now, 'POSTAGE_HOLD_TIME')
    need(sb['amount'] >= seen['required'], 'POSTAGE_INSUFFICIENT')
    return {**base, 'status': 'ADMITTED', 'attached': sb['amount'], 'stamp': stamped['id'], 'hold': held['id'],
            'decide_by': sb['decide_by'],
            'custody': 'HOLDER_SIGNED_RECEIPT_ADOPTED_BY_RECIPIENT_POLICY_NOT_INDEPENDENT_SETTLEMENT_OBSERVATION'}


def screen(policy_envelope, items, now, **evidence):
    """Screen a bounded inbox batch. Input order is kept; stake never orders the inbox."""
    need(type(items) is list and len(items) <= MAX_ITEMS, 'POSTAGE_SIZE')
    rules = open_record(policy_envelope, 'POLICY'); _evidence(evidence)
    contacts = evidence.get('trusted_contacts')
    if contacts and 'anchors' not in evidence:
        evidence = dict(evidence)
        evidence['anchors'] = intro.reach(
            intro._seeds(contacts), list(evidence.get('introductions', ())), list(evidence.get('receipts', ())),
            None, now, withdrawals=list(evidence.get('withdrawals', ())), adopted_resolvers=evidence.get('adopted_resolvers'),
            max_depth=evidence.get('max_depth', intro.DEFAULT_DEPTH),
            decay_bps=evidence.get('decay_bps', intro.DEFAULT_DECAY_BPS))['reached']
    admitted, refused = [], []
    for index, item in enumerate(items):
        try:
            need(type(item) is dict and {'proposal', 'sender'} <= set(item) <= {'proposal', 'sender', 'stamp', 'hold'},
                 'POSTAGE_FIELDS')
            _keyed(item['sender'])
            result = admit(policy_envelope, item['proposal'], item['sender'], now, stamp=item.get('stamp'),
                           hold=item.get('hold'), view=standing(rules['body'], item['sender'], now, **evidence))
            admitted.append({'index': index, **result})
        except ValueError as error:
            code = intro._code(error)
            refused.append({'index': index, 'status': 'REFUSED', 'reason': code, 'remediation': remediation(code)})
    return {'version': VERSION, 'policy': rules['id'], 'admitted': admitted, 'refused': refused,
            'order': 'INPUT_ORDER_STAKE_NEVER_RANKS', 'postage_affects_ranking': False,
            'network_accessed': False, 'execution_authorized': False}


def screen_intent_bids(request, entries, policy_envelope, now, **evidence):
    """Postage-screen intent-market quotes; pass ``bids`` on to intent_market.compare unchanged."""
    from covenant_language import intent_market
    expected = intent_market.identifier(request)
    need(request.get('kind') == 'REQUEST', 'POSTAGE_PROPOSAL')
    need(type(entries) is list and len(entries) <= MAX_ITEMS, 'POSTAGE_SIZE')
    items = []
    for entry in entries:
        need(type(entry) is dict and 'bid' in entry and set(entry) <= {'bid', 'stamp', 'hold'}, 'POSTAGE_FIELDS')
        bid = entry['bid']
        need(type(bid) is dict and bid.get('request') == expected, 'POSTAGE_PROPOSAL_MISMATCH')
        items.append({'proposal': {'kind': 'INTENT_MARKET_BID', 'value': bid}, 'sender': bid['solver'],
                      **{name: entry[name] for name in ('stamp', 'hold') if name in entry}})
    screened = screen(policy_envelope, items, now, **evidence)
    bids = [deepcopy(entries[row['index']]['bid']) for row in screened['admitted']]
    return {**screened, 'request': expected, 'bids': bids,
            'next_action': 'Pass bids to covenant_intent_market compare; postage admitted them, it did not rank them.'}


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL,
            'kinds': {kind: ('version kind ' + fields).split() for kind, fields in FIELDS.items()},
            'signers': dict(SIGNER), 'tiers': list(TIERS), 'decisions': list(DECISIONS), 'outcomes': list(OUTCOMES),
            'proposal_kinds': list(PROPOSAL_KINDS),
            'tier_meaning': {'TRUSTED': 'one of the recipient\'s trusted contacts',
                             'INTRODUCED': 'reached through the recipient\'s bounded signed introductions',
                             'KNOWN': 'the recipient released (welcomed) an earlier stamp from this sender',
                             'UNKNOWN': 'none of the above'},
            'kept_rule': 'A kept stamp forfeits INTRODUCED and KNOWN discounts and escalates from UNKNOWN; '
                         'shared_evidence also counts KEEP decisions by the recipient\'s trusted contacts.',
            'silence': 'NO_DECISION_BY_DEADLINE_REFUNDS_SENDER', 'ranking': 'ADMITS_NEVER_RANKS',
            'holder': 'LOCAL_APPEND_ONLY_WORKFLOW_STORE_DISPOSABLE_UNITS; REAL_FUNDS_NEED_AN_ADOPTED_CUSTODY_ADAPTER',
            'limits': {'record_bytes': MAX_RECORD_BYTES, 'items': MAX_ITEMS, 'evidence': MAX_EVIDENCE,
                       'exact_bytes': MAX_EXACT_BYTES, 'escalation_steps': MAX_ESCALATION_STEPS},
            'standards': {'http_402': 'RFC 9110 section 15.5.3 (idea only)', 'trust_amount': 'RFC 4880 5.2.3.13'},
            'remediation': dict(REMEDIATION), 'funds_moved_on_any_rail': False, 'network_accessed': False,
            'execution_authorized': False}


class PostageHolder:
    """Local custodian of postage stakes on the existing append-only workflow store.

    Opening balances are disposable units pinned into the store context; reopening
    with different balances is refused. Every hold and settlement is idempotent by
    stamp id, signed by the holder, and replayed from the hash-chained journal.
    """

    def __init__(self, directory, private_key, unit, opening_balances):
        from .workflow_store import WorkflowStore
        _text(unit, 32)
        need(type(opening_balances) is dict and len(opening_balances) <= 4096, 'POSTAGE_BALANCES')
        for name, amount in opening_balances.items():
            _keyed(name); need(type(amount) is int and 0 <= amount <= MAX_AMOUNT, 'POSTAGE_BALANCES')
        integer(sum(opening_balances.values()))
        self.signer = private_key; self.holder = public_key(private_key); _keyed(self.holder)
        self.unit = unit; self.opening = dict(sorted(opening_balances.items()))
        self.directory = Path(directory)
        self.store = WorkflowStore(directory, {'profile': VERSION, 'holder': self.holder, 'unit': unit,
                                               'opening': self.opening})

    def _state(self):
        balances = dict(self.opening); holds = {}; settled = {}
        for event in self.store.events():
            kind, value = event['body']['kind'], event['body']['value']
            if kind == 'postage.hold':
                body = open_record(value, 'HOLD')['body']
                need(body['holder'] == self.holder, 'POSTAGE_AUDIT')
                balances[body['sender']] = balances.get(body['sender'], 0) - body['amount']
                need(balances[body['sender']] >= 0, 'POSTAGE_AUDIT')
                holds[body['stamp']] = value
            elif kind == 'postage.settle':
                body = open_record(value, 'SETTLEMENT')['body']
                need(body['stamp'] in holds and body['stamp'] not in settled, 'POSTAGE_AUDIT')
                balances[body['paid_to']] = balances.get(body['paid_to'], 0) + body['amount']
                settled[body['stamp']] = value
        return balances, holds, settled

    def _sign(self, kind, **fields):
        body = {'version': VERSION, 'kind': kind, **fields}
        return sign_record(body, self.signer)

    def hold(self, stamp_envelope, policy_envelope, now):
        """Lock the stamped amount from the sender's balance. Retrying returns the same receipt."""
        integer(now)
        stamped = open_record(stamp_envelope, 'STAMP'); rules = open_record(policy_envelope, 'POLICY')
        sb, pb = stamped['body'], rules['body']
        need(sb['holder'] == self.holder and self.holder in pb['holders'], 'POSTAGE_HOLDER')
        need(sb['policy'] == rules['id'] and sb['recipient'] == pb['recipient'] and sb['unit'] == pb['unit'] == self.unit
             and sb['context'] in pb['contexts'], 'POSTAGE_POLICY_MISMATCH')
        need(sb['decide_by'] == sb['issued_at'] + pb['decision_window'], 'POSTAGE_DEADLINE')
        need(sb['amount'] <= pb['max_amount'], 'POSTAGE_AMOUNT')
        with self.store.exclusive():
            balances, holds, _ = self._state()
            if stamped['id'] in holds:
                return deepcopy(holds[stamped['id']])
            need(pb['issued_at'] <= now < pb['expires'], 'POSTAGE_POLICY_TIME')
            need(sb['issued_at'] <= now < sb['decide_by'], 'POSTAGE_STAMP_TIME')
            need(balances.get(sb['sender'], 0) >= sb['amount'], 'POSTAGE_FUNDS')
            receipt = self._sign('HOLD', holder=self.holder, stamp=stamped['id'], sender=sb['sender'],
                                 recipient=sb['recipient'], amount=sb['amount'], unit=sb['unit'],
                                 decide_by=sb['decide_by'], payee=pb['beneficiary'] or pb['recipient'], held_at=now)
            self.store.append('postage.hold', stamped['id'], receipt)
            return deepcopy(receipt)

    def settle(self, stamp_id, now, decision_envelope=None):
        """Apply a timely recipient decision, or refund after the deadline. The first settlement is final."""
        key(stamp_id); integer(now)
        choice = None
        if decision_envelope is not None:
            choice = open_record(decision_envelope, 'DECISION')
        with self.store.exclusive():
            balances, holds, settled = self._state()
            need(stamp_id in holds, 'POSTAGE_UNKNOWN_STAMP')
            held = open_record(holds[stamp_id], 'HOLD'); hb = held['body']
            if choice is not None:
                cb = choice['body']
                need(cb['stamp'] == stamp_id and cb['recipient'] == hb['recipient'], 'POSTAGE_DECISION')
                outcome = 'KEPT' if cb['decision'] == 'KEEP' else 'RELEASED'
                timely = cb['decided_at'] <= hb['decide_by'] and now <= hb['decide_by']
            else:
                outcome = 'REFUNDED_UNDECIDED'; timely = True
            if stamp_id in settled:
                previous = open_record(settled[stamp_id], 'SETTLEMENT')['body']
                need(previous['outcome'] == outcome or (choice is None and previous['outcome'] != 'KEPT' and now > hb['decide_by']),
                     'POSTAGE_ALREADY_SETTLED')
                return deepcopy(settled[stamp_id])
            if choice is not None:
                need(timely, 'POSTAGE_DECISION_LATE')
            else:
                need(now > hb['decide_by'], 'POSTAGE_DECISION_PENDING')
            paid_to = hb['payee'] if outcome == 'KEPT' else hb['sender']
            receipt = self._sign('SETTLEMENT', holder=self.holder, stamp=stamp_id, hold=held['id'], outcome=outcome,
                                 paid_to=paid_to, amount=hb['amount'], unit=hb['unit'], settled_at=now,
                                 decision=None if choice is None else choice['id'])
            self.store.append('postage.settle', stamp_id, receipt)
            return deepcopy(receipt)

    def sweep(self, now):
        """Refund every hold whose deadline passed without a settlement."""
        integer(now)
        _, holds, settled = self._state()
        due = sorted(ref for ref, value in holds.items()
                     if ref not in settled and open_record(value, 'HOLD')['body']['decide_by'] < now)
        return [self.settle(ref, now) for ref in due]

    def balances(self):
        return dict(sorted(self._state()[0].items()))

    def audit(self):
        balances, holds, settled = self._state()
        open_amount = sum(open_record(value, 'HOLD')['body']['amount'] for ref, value in holds.items() if ref not in settled)
        need(sum(balances.values()) + open_amount == sum(self.opening.values()), 'POSTAGE_AUDIT')
        need(all(amount >= 0 for amount in balances.values()), 'POSTAGE_AUDIT')
        return {'status': 'CONSERVED', 'holder': self.holder, 'unit': self.unit, 'open_holds': len(holds) - len(settled),
                'open_amount': open_amount, 'settled': len(settled), 'execution_authorized': False}

    def health(self):
        try:
            checked = self.audit()
            return {'status': 'OK', 'ready': True, 'open_holds': checked['open_holds']}
        except ValueError as error:
            return {'status': 'FAILING', 'ready': False, 'reason': intro._code(error)}

    def metrics(self):
        """Prometheus text exposition; no keys, amounts per party or personal data."""
        _, holds, settled = self._state()
        counts = {name: 0 for name in OUTCOMES}
        for value in settled.values():
            counts[open_record(value, 'SETTLEMENT')['body']['outcome']] += 1
        unit = self.unit.replace('\\', '\\\\').replace('"', '\\"')
        lines = ['# HELP aap_postage_open_holds Postage holds awaiting a decision or refund.',
                 '# TYPE aap_postage_open_holds gauge',
                 f'aap_postage_open_holds{{unit="{unit}"}} {len(holds) - len(settled)}',
                 '# HELP aap_postage_settlements_total Settled postage holds by outcome.',
                 '# TYPE aap_postage_settlements_total counter']
        lines += [f'aap_postage_settlements_total{{outcome="{name}",unit="{unit}"}} {counts[name]}' for name in OUTCOMES]
        return '\n'.join(lines) + '\n'

    def backup(self, destination):
        """Consistent SQLite online backup into a new private directory; reopen it to restore."""
        target = Path(destination)
        need(not target.exists(), 'POSTAGE_BACKUP_TARGET')
        target.mkdir(mode=0o700, parents=True)
        need(stat.S_IMODE(os.stat(target).st_mode) & 0o077 == 0, 'POSTAGE_BACKUP_TARGET')
        for name in ('workflow.sqlite', 'writer.lock'):
            os.close(os.open(target / name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600))
        with self.store.exclusive():
            from covenant_language.safe_io import durable_sqlite
            copy = sqlite3.connect(target / 'workflow.sqlite')
            try:
                durable_sqlite(copy, journal='DELETE')
                self.store.db.backup(copy)
            finally:
                copy.close()
        return str(target)

    def close(self):
        self.store.close()
