"""100 separately keyed scripted agents on four real local validator processes.

This tests mechanics and recovery, not emergent LLM society or independent operators.
"""
import argparse,json,socket,subprocess,sys,tempfile,time,hashlib
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from covenant_language.safe_io import atomic_write
from .app import ECOSYSTEM_VERSION,make_transaction,transaction_id
from .crypto import canonical,digest,public_key,sign
from .fixtures import fresh_fixture
from .client import Client
from .demo import eventually,read_record,nonce_of
from .ecosystem import seed,approve,discover
from .proofs import verify_history
from .gate import FileGate,LABEL
from covenant_language.handoff import InjectedCrash
ROOT=Path(__file__).resolve().parents[1]

def run(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True);checks=[]
    def check(name,ok=True):
        if not ok:raise AssertionError(name)
        checks.append({'check':name,'passed':True})
    keys,p,g=fresh_fixture(ECOSYSTEM_VERSION);g['shielded']={};chain=digest('COVENANT-GENESIS',g)
    agents=[Ed25519PrivateKey.generate() for _ in range(100)]
    for i,k in enumerate(agents):keys['a'+str(i)]=k;p['a'+str(i)]=public_key(k)
    procs=[];logs=[]
    with tempfile.TemporaryDirectory(prefix='covenant-ecosystem-') as td:
        d=Path(td);(d/'genesis.json').write_bytes(canonical(g));socks=[socket.socket() for _ in range(4)]
        for sock in socks:sock.bind(('127.0.0.1',0))
        ports=[sock.getsockname()[1] for sock in socks]
        for sock in socks:sock.close()
        peers={f'v{i}':f'http://127.0.0.1:{ports[i]}' for i in range(4)};(d/'peers.json').write_bytes(canonical(peers))
        clients=[Client(peers[f'v{i}']) for i in range(4)]
        try:
            for i in range(4):
                k=d/f'v{i}.key';k.write_text(keys[f'v{i}'].private_bytes_raw().hex());k.chmod(0o600)
                log=open(d/f'v{i}.log','wb');logs.append(log)
                procs.append(subprocess.Popen([sys.executable,'-m','covenant_chain.node','--genesis',str(d/'genesis.json'),'--peers',str(d/'peers.json'),'--member',f'v{i}','--key',str(k),'--db',str(d/f'v{i}.journal'),'--port',str(ports[i]),'--base-timeout','0.8','--sandbox-control'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT))
            eventually(lambda:all(c.status()['consensus_running'] for c in clients));check('four native 0.5 validators started')
            def submit(who,op,payload,wait=True):
                nonce=nonce_of(clients[0],p[who])
                tx=make_transaction(keys[who],chain,nonce,op,payload,protocol=ECOSYSTEM_VERSION)
                clients[0].submit(tx);tid=transaction_id(tx)
                if wait:clients[0].wait(tid,45)
                return tid
            def signed(op,payload,names=('owner',)):
                payload['approvals']=[approve(keys[n],chain,op,payload) for n in names];return payload
            def governed(w,op,payload):
                base={'world':w,'revision':read_record(clients[0],'worlds',w)['revision'],**payload,'approvals':[]}
                return submit('owner',op,signed(op,base))
            w=submit('owner','WORLD_CREATE',signed('WORLD_CREATE',{'seed':seed('research-cooperative',[p['owner']],1,'a'*64),'approvals':[]}))
            submit('owner','WORLD_FUND',{'world':w,'resource':'compute','quantity':60});check('institution created and funded')
            submitted=[]
            for i in range(100):
                submitted.append(submit('a'+str(i),'WORLD_SERVICE',{'capability':'research','resource':'compute','price':1+i%9,'expiry':100000,'terms':digest('RESEARCH-TERMS',i)},False))
            for tid in submitted:clients[0].wait(tid,60)
            # Scoped reads of the advertisements this run submitted; /state is an advisory dump.
            services={sid:read_record(clients[0],'world_services',sid) for sid in submitted}
            check('100 independently signed service advertisements finalized',len(services)==100 and all(v is not None for v in services.values()))
            candidates=discover({'world_services':services},'research',clients[0].status()['applied_height'],max_price=2)
            check('intent matched affordable offers',len(candidates)>0 and candidates[0]['price']==1)
            chosen=candidates[0];job=governed(w,'WORLD_HIRE',{'service':chosen['id'],'units':10,'resolver':p['resolver'],'deadline':100000})
            submit('resolver','WORLD_RESOLVE',{'job':job,'units':8,'evidence':'b'*64});check('metered eight units paid and two refunded',read_record(clients[0],'balances',w)['compute']==52)
            fork=submit('owner','WORLD_CREATE',signed('WORLD_CREATE',{'seed':seed('fork',[p['owner']],1,'a'*64,ancestry=[w]),'approvals':[]}));check('fork has ancestry but no duplicated treasury',(read_record(clients[0],'balances',fork) or {})=={})
            payload=b'Covenant institution-funded research artifact\n';content=hashlib.sha256(payload).hexdigest()
            service=submit('worker','WORLD_SERVICE',{'capability':'file.publish','resource':'compute','price':2,'expiry':100000,'terms':content})
            filejob=governed(w,'WORLD_HIRE',{'service':service,'units':1,'resolver':p['resolver'],'deadline':100000})
            def history():
                height=clients[0].status()['applied_height'];entries=[]
                while len(entries)<height:entries.extend(clients[0].blocks(len(entries)+1))
                return entries[:height]
            entries=history();body={'chain':chain,'job':filejob,'content':content};sig=sign(keys['worker'],LABEL,body)
            gate=FileGate(d/'effects',g,chain,len(entries))
            try:
                try:gate.execute(entries,filejob,payload,sig,crash='after_effect')
                except InjectedCrash:pass
                else:raise AssertionError('crash injection failed')
                receipt=gate.execute(entries,filejob,payload,sig)
                again=gate.execute(entries,filejob,payload,sig)
                check('real file gate reconciles lost receipt without duplicate effect',again['result']=='ALREADY_DONE')
                try:gate.execute(entries,filejob,b'tampered',sig)
                except ValueError:check('gate rejects unagreed content')
                else:raise AssertionError('gate accepted tampering')
            finally:gate.close()
            submit('resolver','WORLD_RESOLVE',{'job':filejob,'units':1,'evidence':receipt['content']})
            # Consensus safety during a real network partition, followed by recovery.
            for i,c in enumerate(clients):c.control([f'v{j}' for j in range(4) if (j<2)!=(i<2)])
            time.sleep(1)
            pending=submit('owner','WORLD_FUND',{'world':w,'resource':'compute','quantity':1},False)
            time.sleep(2)
            check('two-two partition cannot finalize treasury transfer',all(c.transaction(pending)['status']!='committed' for c in clients))
            for c in clients:c.control([])
            clients[0].wait(pending,60);check('healing restores progress')
            entries=history();verified=verify_history(g,entries,chain,len(entries));check('archive replay reconstructs institution and treasury',verified['state']['balances'][w]['compute']==51)
            atomic_write(out/'genesis.json',canonical(g));atomic_write(out/'history.json',canonical(entries))
            result={'agents':100,'agent_kind':'scripted separately keyed clients; not LLM agents','validators':4,'checks':checks,'height':len(entries),'state_root':verified['state_root'],'scope':'One machine; one native finality domain; no independent Internet deployment.'}
            atomic_write(out/'results.json',json.dumps(result,indent=2));return result
        finally:
            for proc in procs:
                proc.terminate()
            for proc in procs:
                try:proc.wait(timeout=5)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
            for log in logs:log.close()
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='reports/ecosystem_0_13');args=parser.parse_args();print(json.dumps(run(args.out),indent=2))
