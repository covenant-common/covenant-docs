"""Bounded owner-installed transports behind the ordinary effect workflow.

Every call can disclose information or cause an effect, including reads. Agents
select installed aliases, never endpoints, code, credentials or wider policy.
An uncertain attempt is observed rather than blindly retried. This harness is
not a sandbox for owner callbacks or a claim of external atomicity or truth.
"""
from copy import deepcopy
import base64
import hashlib
import http.client
import io
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import ssl
import stat
import time
from urllib.parse import unquote, urlsplit

from .adapters import _instance, manifest, manifest_id
from .crypto import exact, key, need
from .workflow_store import WorkflowStore, canonical as wire

VERSION = "covenant-connector-harness/0.1"
IMPLEMENTATION = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
BUILTINS = frozenset(("HTTP", "FILE", "TCP", "MCP"))


def _alias(value):
    need(type(value) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", value) is not None,
         "CONNECTOR_ALIAS")


def _integer(value, maximum, minimum=0):
    need(type(value) is int and minimum <= value <= maximum, "CONNECTOR_INTEGER")


def _binary(value, maximum):
    need(type(value) is str and len(value) <= 4 * ((maximum + 2) // 3), "CONNECTOR_BINARY_SIZE")
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, TypeError):
        raise ValueError("CONNECTOR_BINARY_ENCODING") from None
    need(len(raw) <= maximum and base64.b64encode(raw).decode("ascii") == value, "CONNECTOR_BINARY_ENCODING")
    return raw


def _host(value):
    need(type(value) is str and 0 < len(value) <= 253 and value.isascii()
         and re.fullmatch(r"[A-Za-z0-9.:-]+", value) is not None, "CONNECTOR_OWNER_HOST")
    return value.lower()


def _resolve(host, port):
    # Resolution happens during owner installation. Calls connect only to these
    # literal addresses, so subsequent DNS changes cannot widen the origin.
    addresses = set()
    for family, kind, protocol, name, address in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM):
        if family not in (socket.AF_INET, socket.AF_INET6):
            continue
        ip = ipaddress.ip_address(address[0])
        need(not ip.is_multicast and not ip.is_unspecified, "CONNECTOR_OWNER_ADDRESS")
        addresses.add((family, str(ip)))
    need(bool(addresses) and len(addresses) <= 16, "CONNECTOR_OWNER_ADDRESSES")
    return [[int(family), ip] for family, ip in sorted(addresses)]


def _url_path(value):
    need(type(value) is str and 0 < len(value) <= 8192 and value.isascii()
         and all(32 < ord(c) < 127 for c in value) and "\\" not in value,
         "CONNECTOR_HTTP_PATH")
    parsed = urlsplit(value)
    need(not parsed.scheme and not parsed.netloc and not parsed.fragment and value.startswith("/")
         and not value.startswith("//"), "CONNECTOR_HTTP_PATH")
    need(re.search(r"%(?![0-9a-fA-F]{2})", value) is None, "CONNECTOR_HTTP_PATH")
    decoded = parsed.path
    for _ in range(8):
        try:
            after = unquote(decoded, errors="strict")
        except UnicodeError:
            raise ValueError("CONNECTOR_HTTP_PATH") from None
        if after == decoded:
            break
        decoded = after
    else:
        raise ValueError("CONNECTOR_HTTP_PATH")
    need("\\" not in decoded and "//" not in decoded and
         all(ord(c) >= 32 and ord(c) != 127 for c in decoded) and
         all(part not in (".", "..") for part in decoded.split("/")), "CONNECTOR_HTTP_PATH")
    return decoded


def _file_parts(value):
    need(type(value) is str and 0 < len(value) <= 4096 and not value.startswith("/")
         and "\\" not in value and "\0" not in value, "CONNECTOR_FILE_PATH")
    parts = value.split("/")
    need(len(parts) <= 64 and all(part not in ("", ".", "..") for part in parts), "CONNECTOR_FILE_PATH")
    return parts


class _DeadlineReader(io.RawIOBase):
    def __init__(self, transport):
        self.transport = transport

    def readable(self):
        return True

    def readinto(self, buffer):
        self.transport.remaining()
        count = self.transport.socket.recv_into(buffer)
        self.transport.received += count
        need(self.transport.received <= self.transport.maximum, "CONNECTOR_RESPONSE_LIMIT")
        return count

    def close(self):
        if not self.closed:
            self.transport.release_reader()
        super().close()


class _DeadlineSocket:
    def __init__(self, channel, deadline, maximum):
        self.socket = channel
        self.deadline = deadline
        self.maximum = maximum
        self.received = 0
        self.readers = 0
        self.close_requested = False

    def remaining(self):
        remaining = self.deadline - time.monotonic()
        need(remaining > 0, "CONNECTOR_TIMEOUT")
        self.socket.settimeout(remaining)
        return remaining

    def makefile(self, mode):
        need(mode == "rb", "CONNECTOR_HTTP_READER")
        self.readers += 1
        return io.BufferedReader(_DeadlineReader(self), buffer_size=8192)

    def release_reader(self):
        self.readers -= 1
        if self.close_requested and not self.readers:
            self.socket.close()

    def sendall(self, data):
        self.remaining()
        self.socket.sendall(data)

    def close(self):
        # HTTPConnection closes itself as soon as a will-close response is
        # parsed. Match socket.makefile's retained reader lifetime.
        self.close_requested = True
        if not self.readers:
            self.socket.close()


class ConnectorHarness:
    """Low-level owner adapter. Read tools may inspect/prepare, never execute.

    Configuration is installed locally. MCP/custom callbacks must declare an
    implementation pin; arbitrary code is never imported from a request.
    Credentials belong in the owner headers closure or callback custody.
    """
    def __init__(self, directory, *, http_routes=None, file_roots=None, tcp_endpoints=None,
                 mcp_tools=None, custom_protocols=None, observer=None, timeout=3.0,
                 max_request_bytes=65536, max_response_bytes=65536):
        need(type(timeout) in (int, float) and 0 < timeout <= 30, "CONNECTOR_OWNER_TIMEOUT")
        _integer(max_request_bytes, 1000000, 1)
        _integer(max_response_bytes, 1000000, 1)
        timeout_ms = int(timeout * 1000)
        need(timeout_ms >= 1, "CONNECTOR_OWNER_TIMEOUT")
        self.timeout = timeout_ms / 1000
        self.max_request_bytes = max_request_bytes
        self.max_response_bytes = max_response_bytes
        self.routes = {}
        self.roots = {}
        self.sockets = {}
        self.mcp = {}
        self.custom = {}
        policy = {"timeout_ms": timeout_ms, "max_request_bytes": max_request_bytes,
                  "max_response_bytes": max_response_bytes, "http": {}, "file": {},
                  "tcp": {}, "mcp": {}, "custom": {}}
        for collection in (http_routes, file_roots, tcp_endpoints, mcp_tools, custom_protocols):
            need(collection is None or type(collection) is dict, "CONNECTOR_OWNER_CONFIGURATION")
            need(collection is None or len(collection) <= 64, "CONNECTOR_OWNER_CONFIGURATION")
        for alias, entry in (http_routes or {}).items():
            _alias(alias)
            need(type(entry) is dict and set(entry) <= {"origin", "methods", "path_prefix", "headers", "response_headers"}
                 and "origin" in entry, "CONNECTOR_HTTP_CONFIGURATION")
            origin = entry["origin"]
            need(type(origin) is str and origin.isascii() and all(32 < ord(c) < 127 for c in origin)
                 and "\\" not in origin, "CONNECTOR_OWNER_ORIGIN")
            try:
                parsed = urlsplit(origin)
                port = parsed.port or (443 if parsed.scheme == "https" else 80)
            except ValueError:
                raise ValueError("CONNECTOR_OWNER_ORIGIN") from None
            need(parsed.scheme in ("http", "https") and parsed.hostname and parsed.username is None
                 and parsed.password is None and parsed.path in ("", "/") and not parsed.query
                 and not parsed.fragment, "CONNECTOR_OWNER_ORIGIN")
            host = _host(parsed.hostname)
            _integer(port, 65535, 1)
            methods = entry.get("methods", ["GET"])
            need(type(methods) is list and 0 < len(methods) <= 8 and len(set(methods)) == len(methods)
                 and all(method in ("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS") for method in methods),
                 "CONNECTOR_OWNER_METHODS")
            prefix = entry.get("path_prefix", "/")
            normalized = _url_path(prefix)
            need("?" not in prefix, "CONNECTOR_HTTP_CONFIGURATION")
            headers = entry.get("headers", {})
            need(type(headers) is dict or callable(headers), "CONNECTOR_OWNER_HEADERS")
            response_headers = entry.get("response_headers", ["content-type"])
            need(type(response_headers) is list and len(response_headers) <= 16 and
                 all(type(name) is str and re.fullmatch(r"[a-z0-9-]+", name) for name in response_headers),
                 "CONNECTOR_OWNER_HEADERS")
            addresses = _resolve(host, port)
            self.routes[alias] = {"host": host, "port": port, "scheme": parsed.scheme,
                                  "addresses": addresses, "methods": list(methods), "prefix": normalized,
                                  "headers": headers if callable(headers) else deepcopy(headers),
                                  "response_headers": list(response_headers)}
            policy["http"][alias] = {key: deepcopy(value) for key, value in self.routes[alias].items()
                                     if key != "headers"}
        for alias, directory_root in (file_roots or {}).items():
            _alias(alias)
            need(type(directory_root) in (str, Path) or isinstance(directory_root, Path), "CONNECTOR_OWNER_FILE_ROOT")
            root = Path(directory_root).resolve(strict=True)
            need(root.is_dir(), "CONNECTOR_OWNER_FILE_ROOT")
            self.roots[alias] = root
            policy["file"][alias] = str(root)
        for alias, entry in (tcp_endpoints or {}).items():
            _alias(alias)
            exact(entry, "host port")
            host = _host(entry["host"])
            port = entry["port"]
            _integer(port, 65535, 1)
            self.sockets[alias] = {"host": host, "port": port, "addresses": _resolve(host, port)}
            policy["tcp"][alias] = deepcopy(self.sockets[alias])
        for alias, entry in (mcp_tools or {}).items():
            _alias(alias)
            exact(entry, "tool call implementation")
            need(type(entry["tool"]) is str and 0 < len(entry["tool"]) <= 256 and callable(entry["call"]),
                 "CONNECTOR_OWNER_MCP_TOOL")
            key(entry["implementation"])
            self.mcp[alias] = dict(entry)
            policy["mcp"][alias] = {"tool": entry["tool"], "implementation": entry["implementation"]}
        for alias, entry in (custom_protocols or {}).items():
            _alias(alias)
            exact(entry, "protocol call implementation")
            protocol = entry["protocol"]
            need(type(protocol) is str and re.fullmatch(r"[A-Z][A-Z0-9_-]{0,63}", protocol)
                 and protocol not in BUILTINS and callable(entry["call"]), "CONNECTOR_OWNER_CUSTOM_PROTOCOL")
            key(entry["implementation"])
            self.custom[alias] = dict(entry)
            policy["custom"][alias] = {"protocol": protocol, "implementation": entry["implementation"]}
        if observer is not None:
            exact(observer, "call implementation")
            need(callable(observer["call"]), "CONNECTOR_OWNER_OBSERVER")
            key(observer["implementation"])
        self.observer = None if observer is None else dict(observer)
        policy["observer"] = None if observer is None else observer["implementation"]
        adapter_instance = _instance(directory)
        self.root_fds = {}
        try:
            for alias, root in self.roots.items():
                descriptor = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                self.root_fds[alias] = descriptor
                info = os.fstat(descriptor)
                policy["file"][alias] = {"path": str(root), "device": str(info.st_dev), "inode": str(info.st_ino)}
        except BaseException:
            for descriptor in self.root_fds.values():
                os.close(descriptor)
            raise
        self.policy_pin = hashlib.sha256(wire(policy)).hexdigest()
        self.manifest = manifest("universal-owner-connector-harness-0.1", "connector.invoke",
                                 effect="OWNER_ADOPTED_BOUNDED_TRANSPORT_CALL", instance=adapter_instance,
                                 recovery="OBSERVE_ONLY", max_bytes=max_request_bytes)
        self.manifest["requirements"].update(connector_profile=VERSION, connector_policy=self.policy_pin,
                                              connector_implementation=IMPLEMENTATION,
                                              credentials="OWNER_CLOSURE_NOT_REQUEST_POLICY_OR_MANIFEST")
        self.ref = manifest_id(self.manifest)
        self.store = None
        try:
            self.store = WorkflowStore(directory, {"adapter": self.ref, "policy": self.policy_pin})
            self.store.db.execute("CREATE TRIGGER IF NOT EXISTS connector_no_replace BEFORE INSERT ON events WHEN EXISTS(SELECT 1 FROM events WHERE sequence=NEW.sequence OR id=NEW.id) BEGIN SELECT RAISE(ABORT,'CONNECTOR_APPEND_ONLY'); END")
            self.audit()
        except BaseException:
            for descriptor in self.root_fds.values():
                os.close(descriptor)
            self.root_fds = {}
            if self.store is not None:
                self.store.close()
            raise

    def describe_requests(self):
        # These descriptions intentionally omit roots, origins, addresses,
        # tool names and headers. An owner may separately publish a manifest.
        descriptions = []
        shapes = {
            "HTTP": {"required": ["path"], "optional": ["method", "body_base64"], "method_default": "GET"},
            "FILE": {"required": ["path"], "optional": ["offset", "length"], "path": "RELATIVE_OWNER_ROOT_NO_SYMLINKS"},
            "TCP": {"required": ["payload_base64"], "optional": [], "reply": "BOUNDED_UNTIL_EOF"},
            "MCP": {"required": ["arguments"], "optional": [], "tool": "EXACT_OWNER_INSTALLED_TOOL"}}
        for protocol, aliases in (("HTTP", self.routes), ("FILE", self.roots), ("TCP", self.sockets), ("MCP", self.mcp)):
            for alias in sorted(aliases):
                entry = {"protocol": protocol, "operation": alias, "parameters": deepcopy(shapes[protocol])}
                if protocol == "HTTP":
                    entry["parameters"]["allowed_methods"] = list(self.routes[alias]["methods"])
                descriptions.append(entry)
        for alias, entry in sorted(self.custom.items()):
            descriptions.append({"protocol": entry["protocol"], "operation": alias,
                                 "parameters": {"type": "object", "interpretation": "OWNER_INSTALLED_CALLBACK"}})
        return {"profile": VERSION, "adapter": self.ref, "operations": descriptions,
                "max_request_bytes": self.max_request_bytes, "max_response_bytes": self.max_response_bytes,
                "recovery": "OBSERVE_ONLY", "credentials": "OWNER_CUSTODY",
                "all_calls": "EFFECT_CLASS_SEPARATE_WORKFLOW_APPROVAL_REQUIRED", "execution_authorized": False}

    def validate_request(self, request):
        """Pure shape/policy check. No DNS, files, sockets, callbacks or effects."""
        need(len(wire(request)) <= self.max_request_bytes, "CONNECTOR_REQUEST_LIMIT")
        exact(request, "protocol operation parameters")
        protocol, alias, parameters = request["protocol"], request["operation"], request["parameters"]
        _alias(alias)
        need(type(protocol) is str and type(parameters) is dict, "CONNECTOR_REQUEST")
        if protocol == "HTTP":
            need(alias in self.routes, "CONNECTOR_OPERATION_NOT_INSTALLED")
            need(set(parameters) <= {"path", "method", "body_base64"} and "path" in parameters,
                 "CONNECTOR_HTTP_PARAMETERS")
            route = self.routes[alias]
            decoded = _url_path(parameters["path"])
            prefix = route["prefix"].rstrip("/")
            need(not prefix or decoded == prefix or decoded.startswith(prefix + "/"), "CONNECTOR_HTTP_PATH_SCOPE")
            need(parameters.get("method", "GET") in route["methods"], "CONNECTOR_HTTP_METHOD_SCOPE")
            if "body_base64" in parameters:
                _binary(parameters["body_base64"], self.max_request_bytes)
        elif protocol == "FILE":
            need(alias in self.roots, "CONNECTOR_OPERATION_NOT_INSTALLED")
            need(set(parameters) <= {"path", "offset", "length"} and "path" in parameters,
                 "CONNECTOR_FILE_PARAMETERS")
            _file_parts(parameters["path"])
            _integer(parameters.get("offset", 0), 2**53 - 1)
            _integer(parameters.get("length", self.max_response_bytes), self.max_response_bytes)
        elif protocol == "TCP":
            need(alias in self.sockets, "CONNECTOR_OPERATION_NOT_INSTALLED")
            exact(parameters, "payload_base64")
            _binary(parameters["payload_base64"], self.max_request_bytes)
        elif protocol == "MCP":
            need(alias in self.mcp, "CONNECTOR_OPERATION_NOT_INSTALLED")
            exact(parameters, "arguments")
            need(type(parameters["arguments"]) is dict, "CONNECTOR_MCP_ARGUMENTS")
        else:
            need(alias in self.custom and self.custom[alias]["protocol"] == protocol,
                 "CONNECTOR_PROTOCOL_NOT_INSTALLED")
        return {"protocol": protocol, "operation": alias, "request_hash": hashlib.sha256(wire(request)).hexdigest(),
                "execution_authorized": False}

    def _connect(self, entry, deadline):
        for family, ip in entry["addresses"]:
            channel = socket.socket(family, socket.SOCK_STREAM)
            try:
                remaining = deadline - time.monotonic()
                need(remaining > 0, "CONNECTOR_TIMEOUT")
                channel.settimeout(remaining)
                channel.connect((ip, entry["port"]))
                return channel
            except (OSError, ValueError):
                channel.close()
        raise ValueError("CONNECTOR_CONNECTION_FAILED") from None

    def _http(self, alias, parameters):
        route = self.routes[alias]
        deadline = time.monotonic() + self.timeout
        channel = self._connect(route, deadline)
        connection = None
        response = None
        try:
            if route["scheme"] == "https":
                channel.settimeout(max(0.001, deadline - time.monotonic()))
                channel = ssl.create_default_context().wrap_socket(channel, server_hostname=route["host"])
            transport = _DeadlineSocket(channel, deadline, self.max_response_bytes + 16384)
            connection = http.client.HTTPConnection(route["host"], route["port"], timeout=self.timeout)
            connection.sock = transport
            headers = route["headers"]() if callable(route["headers"]) else deepcopy(route["headers"])
            need(type(headers) is dict and len(headers) <= 32, "CONNECTOR_OWNER_HEADERS")
            for name, value in headers.items():
                need(type(name) is str and re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name)
                     and name.lower() not in ("host", "connection", "content-length", "transfer-encoding")
                     and type(value) is str and all(32 <= ord(c) < 127 for c in value), "CONNECTOR_OWNER_HEADERS")
            need(sum(len(name) + len(value) + 4 for name, value in headers.items()) <= 16384,
                 "CONNECTOR_OWNER_HEADERS")
            body = _binary(parameters["body_base64"], self.max_request_bytes) if "body_base64" in parameters else None
            connection.request(parameters.get("method", "GET"), parameters["path"], body=body, headers=headers)
            response = connection.getresponse()
            need(not 300 <= response.status < 400, "CONNECTOR_HTTP_REDIRECT_REFUSED")
            result = bytearray()
            while True:
                chunk = response.read1(min(8192, self.max_response_bytes + 1 - len(result)))
                if not chunk:
                    break
                result.extend(chunk)
                need(len(result) <= self.max_response_bytes, "CONNECTOR_RESPONSE_LIMIT")
            return {"status": response.status,
                    "headers": {name: response.getheader(name) for name in route["response_headers"]
                                if response.getheader(name) is not None},
                    "body_base64": base64.b64encode(result).decode("ascii")}
        finally:
            if response is not None:
                response.close()
            if connection is not None:
                connection.close()
            channel.close()

    def _file(self, alias, parameters):
        parts = _file_parts(parameters["path"])
        # Retain the adopted directory identity even if its parent path is
        # renamed or replaced after installation.
        descriptor = os.dup(self.root_fds[alias])
        try:
            for index, part in enumerate(parts):
                flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
                if index + 1 < len(parts):
                    flags |= os.O_DIRECTORY
                child = os.open(part, flags, dir_fd=descriptor)
                os.close(descriptor)
                descriptor = child
            info = os.fstat(descriptor)
            need(stat.S_ISREG(info.st_mode), "CONNECTOR_FILE_NOT_REGULAR")
            offset = parameters.get("offset", 0)
            length = parameters.get("length", self.max_response_bytes)
            os.lseek(descriptor, offset, os.SEEK_SET)
            raw = bytearray()
            while len(raw) < length:
                piece = os.read(descriptor, min(8192, length - len(raw)))
                if not piece:
                    break
                raw.extend(piece)
            return {"offset": offset, "requested_length": length, "returned_length": len(raw),
                    "eof_at_observed_size": offset + len(raw) >= info.st_size,
                    "body_base64": base64.b64encode(raw).decode("ascii")}
        finally:
            os.close(descriptor)

    def _tcp(self, alias, parameters):
        endpoint = self.sockets[alias]
        deadline = time.monotonic() + self.timeout
        channel = self._connect(endpoint, deadline)
        try:
            channel.settimeout(max(0.001, deadline - time.monotonic()))
            channel.sendall(_binary(parameters["payload_base64"], self.max_request_bytes))
            channel.shutdown(socket.SHUT_WR)
            raw = bytearray()
            while True:
                remaining = deadline - time.monotonic()
                need(remaining > 0, "CONNECTOR_TIMEOUT")
                channel.settimeout(remaining)
                chunk = channel.recv(min(8192, self.max_response_bytes + 1 - len(raw)))
                if not chunk:
                    break
                raw.extend(chunk)
                need(len(raw) <= self.max_response_bytes, "CONNECTOR_RESPONSE_LIMIT")
            return {"body_base64": base64.b64encode(raw).decode("ascii"), "completion": "PEER_EOF"}
        finally:
            channel.close()

    def _perform(self, request):
        protocol, alias, parameters = request["protocol"], request["operation"], request["parameters"]
        if protocol == "HTTP":
            result = self._http(alias, parameters)
        elif protocol == "FILE":
            result = self._file(alias, parameters)
        elif protocol == "TCP":
            result = self._tcp(alias, parameters)
        elif protocol == "MCP":
            entry = self.mcp[alias]
            result = entry["call"](entry["tool"], deepcopy(parameters["arguments"]))
        else:
            result = self.custom[alias]["call"](deepcopy(parameters))
        if type(result) is bytes:
            result = {"body_base64": base64.b64encode(result).decode("ascii")}
        need(len(wire(result)) <= self.max_response_bytes, "CONNECTOR_RESPONSE_LIMIT")
        return result

    def _receipt(self, effect_id, request, response):
        value = {"connector": self.ref, "effect": effect_id, "protocol": request["protocol"],
                 "operation": request["operation"], "request_hash": hashlib.sha256(wire(request)).hexdigest(),
                 "response": deepcopy(response)}
        return {"status": "OBSERVED", "output_hash": hashlib.sha256(wire(value)).hexdigest(), "value": value,
                "assurance": "OWNER_ADOPTED_TRANSPORT_RESPONSE_NOT_WORLD_TRUTH_OR_EXTERNAL_ATOMICITY"}

    def _history(self):
        need(manifest_id(self.manifest) == self.ref, "CONNECTOR_MANIFEST_CHANGED")
        events = self.store.events()
        raw_rows = list(self.store.db.execute("SELECT body FROM events ORDER BY sequence"))
        need(len(raw_rows) == len(events), "CONNECTOR_HISTORY_CHANGED")
        intents, receipts, uncertain = {}, {}, set()
        for event, (raw,) in zip(events, raw_rows):
            body = event["body"]
            need(wire(body) == raw, "CONNECTOR_HISTORY_ENCODING")
            exact(body, "kind task value")
            effect = body["task"]
            key(effect)
            if body["kind"] == "CONNECTOR_INTENT":
                need(effect not in intents, "CONNECTOR_DUPLICATE_INTENT")
                self.validate_request(body["value"])
                intents[effect] = body["value"]
            elif body["kind"] == "CONNECTOR_UNKNOWN":
                need(effect in intents and effect not in receipts and effect not in uncertain,
                     "CONNECTOR_UNKNOWN_HISTORY")
                need(body["value"] == {"code": "CONNECTOR_CALL_OUTCOME_UNKNOWN"}, "CONNECTOR_UNKNOWN_HISTORY")
                uncertain.add(effect)
            elif body["kind"] == "CONNECTOR_RECEIPT":
                need(effect in intents and effect not in receipts, "CONNECTOR_RECEIPT_HISTORY")
                receipt = body["value"]
                need(type(receipt) is dict and "value" in receipt and type(receipt["value"]) is dict
                     and "response" in receipt["value"], "CONNECTOR_RECEIPT_HISTORY")
                need(wire(receipt) == wire(self._receipt(effect, intents[effect], receipt["value"]["response"])),
                     "CONNECTOR_RECEIPT_CHANGED")
                receipts[effect] = receipt
            else:
                raise ValueError("CONNECTOR_HISTORY_KIND")
        return events, intents, receipts, uncertain

    def _observe(self, effect_id, intents, receipts):
        if effect_id in receipts:
            return deepcopy(receipts[effect_id])
        result = {"status": "NOT_OBSERVED", "output_hash": None,
                  "assurance": "NO_LOCAL_INTENT_NOT_PROOF_OF_EXTERNAL_FAILURE" if effect_id not in intents
                               else "OUTCOME_UNKNOWN_NO_BLIND_RETRY",
                  "retry": "FORBIDDEN_WITH_SAME_EFFECT_UNLESS_OBSERVED"}
        if effect_id not in intents or self.observer is None:
            return result
        try:
            observation = self.observer["call"](effect_id, deepcopy(intents[effect_id]))
            need(type(observation) is dict and observation.get("status") in ("OBSERVED", "NOT_OBSERVED")
                 and set(observation) <= {"status", "value", "output_hash", "assurance"},
                 "CONNECTOR_OBSERVER_RESULT")
            need(len(wire(observation)) <= self.max_response_bytes, "CONNECTOR_RESPONSE_LIMIT")
            if observation["status"] != "OBSERVED":
                return result
            need("value" in observation, "CONNECTOR_OBSERVER_RESULT")
            if observation.get("output_hash") is not None:
                key(observation["output_hash"])
            receipt = self._receipt(effect_id, intents[effect_id], {"owner_recovery_observation": observation})
            self.store.append("CONNECTOR_RECEIPT", effect_id, receipt)
            return receipt
        except Exception:
            return {**result, "assurance": "OWNER_OBSERVER_FAILED_OUTCOME_STILL_UNKNOWN"}

    def execute(self, effect_id, request, *, crash=None):
        key(effect_id)
        self.validate_request(request)
        with self.store.exclusive():
            events, intents, receipts, uncertain = self._history()
            if effect_id in intents:
                need(wire(intents[effect_id]) == wire(request), "CONNECTOR_RETRY_CHANGED")
                return self._observe(effect_id, intents, receipts)
            self.store.append("CONNECTOR_INTENT", effect_id, request)
            try:
                response = self._perform(deepcopy(request))
            except Exception:
                self.store.append("CONNECTOR_UNKNOWN", effect_id, {"code": "CONNECTOR_CALL_OUTCOME_UNKNOWN"})
                raise ValueError("CONNECTOR_CALL_OUTCOME_UNKNOWN_OBSERVE_BEFORE_RETRY") from None
            if crash == "after_effect":
                from covenant_language.handoff import InjectedCrash
                raise InjectedCrash("after_effect")
            receipt = self._receipt(effect_id, request, response)
            self.store.append("CONNECTOR_RECEIPT", effect_id, receipt)
            return receipt

    def observe(self, effect_id):
        key(effect_id)
        with self.store.exclusive():
            events, intents, receipts, uncertain = self._history()
            return self._observe(effect_id, intents, receipts)

    def audit(self, expected_head=None):
        with self.store.exclusive():
            events, intents, receipts, uncertain = self._history()
            head = events[-1]["id"] if events else "0" * 64
            if expected_head is not None:
                key(expected_head)
                need(expected_head == head, "CONNECTOR_AUDIT_HEAD_MISMATCH")
            return {"profile": VERSION, "adapter": self.ref, "head": head, "entries": len(events),
                    "intents": len(intents), "observed": len(receipts),
                    "outcome_unknown": len(set(intents) - set(receipts)), "canonical_history_verified": True,
                    "freshness": "RELATIVE_TO_RETAINED_HEAD_NOT_GLOBAL_FRESHNESS", "execution_authorized": False}

    def close(self):
        if self.store is not None:
            self.store.close()
            self.store = None
        for descriptor in self.root_fds.values():
            os.close(descriptor)
        self.root_fds = {}
