"""Verifiable consensus equivocation evidence. Observation only; no penalty.

Two authenticated consensus messages from one validator for the same chain,
height, round and kind, with different signed bodies, are equivocation. The
consensus engine already refuses to sign twice for one slot and never counts a
second vote, so this cannot raise quorum weight. It records the proof instead
of discarding it. The evidence carries both signed messages unchanged, so any
holder of the committee keys can check it offline (Ed25519, RFC 8032; the
signed bytes are ``label || 0x00 || canonical(body)``, as in ``crypto.sign``).
It is the same shape as a Tendermint duplicate-vote record.

Evidence does not slash, eject or outvote anyone. Adopting a consequence is a
separate, explicit decision. A watch is bounded in slots, bytes and records.
"""
from collections import OrderedDict
from copy import deepcopy

from .crypto import HEX, canonical, digest, exact, integer, need, verify

VERSION = 'covenant-consensus-equivocation/0.1'
EVIDENCE_LABEL = 'COVENANT-CONSENSUS-EQUIVOCATION-0.1'
KINDS = ('proposal', 'prevote', 'precommit')
MAX_MESSAGE_BYTES = 16 * 1024
MAX_SLOTS = 4096
MAX_EVIDENCE = 64
HEIGHT_WINDOW = 256


def _label(kind):
    return 'COVENANT_CHAIN_' + kind.upper()


def _slot(message, validators, chain):
    """Authenticate one consensus message and return its signing slot."""
    exact(message, 'kind body signer signature')
    kind, body, signer = message['kind'], message['body'], message['signer']
    need(kind in KINDS, 'EQUIVOCATION_KIND')
    need(type(validators) is dict and type(signer) is str and signer in validators, 'EQUIVOCATION_SIGNER')
    exact(body, 'chain height round block_id' + (' block valid_qc' if kind == 'proposal' else ''))
    need(body['chain'] == chain, 'EQUIVOCATION_CHAIN')
    integer(body['height'], True)
    integer(body['round'])
    need(body['block_id'] is None or (type(body['block_id']) is str and bool(HEX.fullmatch(body['block_id']))),
         'EQUIVOCATION_BLOCK_ID')
    need(type(message['signature']) is str and len(message['signature']) <= 8192, 'EQUIVOCATION_SIGNATURE')
    need(len(canonical(message)) <= MAX_MESSAGE_BYTES, 'EQUIVOCATION_SIZE')
    verify(validators[signer], _label(kind), body, message['signature'])
    return signer, body['height'], body['round'], kind


def build(first, second, validators, chain):
    """Return evidence for two different signed bodies in one slot, or refuse."""
    need(type(chain) is str and bool(HEX.fullmatch(chain)), 'EQUIVOCATION_CHAIN')
    slot = _slot(first, validators, chain)
    need(_slot(second, validators, chain) == slot, 'EQUIVOCATION_SLOT')
    need(canonical(first['body']) != canonical(second['body']), 'EQUIVOCATION_NOT_CONFLICTING')
    signer, height, round_, kind = slot
    # One pair has one identity, whichever message a watcher saw first.
    pair = sorted((deepcopy(first), deepcopy(second)), key=canonical)
    body = {'version': VERSION, 'chain': chain, 'signer': signer, 'key': validators[signer],
            'height': height, 'round': round_, 'kind': kind, 'messages': pair}
    return {**body, 'id': digest(EVIDENCE_LABEL, body)}


def verify_evidence(evidence, validators, chain):
    """Check evidence offline against independently pinned committee keys."""
    exact(evidence, 'version chain signer key height round kind messages id')
    need(evidence['version'] == VERSION, 'EQUIVOCATION_VERSION')
    messages = evidence['messages']
    need(type(messages) is list and len(messages) == 2, 'EQUIVOCATION_MESSAGES')
    need(type(validators) is dict and validators.get(evidence['signer']) == evidence['key'], 'EQUIVOCATION_KEY')
    rebuilt = build(messages[0], messages[1], validators, chain)
    need(canonical(rebuilt) == canonical(evidence), 'EQUIVOCATION_ID')
    return {'version': VERSION, 'id': evidence['id'], 'signer': evidence['signer'],
            'height': evidence['height'], 'round': evidence['round'], 'kind': evidence['kind'],
            'verified': True, 'consequence': 'NONE_ADOPTED', 'execution_authorized': False}


class EquivocationWatch:
    """Bounded first-seen record per signing slot; returns new evidence once."""

    def __init__(self, chain, *, slots=MAX_SLOTS, keep=MAX_EVIDENCE, window=HEIGHT_WINDOW):
        need(type(chain) is str and bool(HEX.fullmatch(chain)), 'EQUIVOCATION_CHAIN')
        for value in (slots, keep, window):
            need(type(value) is int and 1 <= value <= 1_000_000, 'EQUIVOCATION_BOUNDS')
        self.chain, self.max_slots, self.keep, self.window = chain, slots, keep, window
        self.slots = OrderedDict()
        self.evidence = OrderedDict()
        self.observed = 0
        self.dropped = 0
        self.top = 0

    def observe(self, message, validators):
        """Record one message. Malformed or unauthenticated input is ignored."""
        try:
            if type(message) is not dict or message.get('kind') not in KINDS:
                return None
            body = message.get('body')
            if type(body) is not dict or type(body.get('height')) is not int or type(body.get('round')) is not int:
                return None
            if body['height'] + self.window < self.top:
                return None
            raw = canonical(message)
            if len(raw) > MAX_MESSAGE_BYTES:
                return None
            slot = (message.get('signer'), body['height'], body['round'], message['kind'])
            previous = self.slots.get(slot)
            if previous is None:
                _slot(message, validators, self.chain)
                self.observed += 1
                self.slots[slot] = message
                self.top = max(self.top, body['height'])
                while len(self.slots) > self.max_slots:
                    self.slots.popitem(last=False)
                return None
            if canonical(previous['body']) == canonical(body):
                return None
            found = build(previous, message, validators, self.chain)
        except (ValueError, KeyError, TypeError, RecursionError):
            return None
        if found['id'] in self.evidence:
            return None
        if len(self.evidence) >= self.keep:
            self.dropped += 1
            return None
        self.evidence[found['id']] = found
        return found

    def observe_commit(self, message, validators):
        """Votes inside a commit certificate are authenticated consensus messages too."""
        found = []
        certificate = message.get('certificate') if type(message) is dict else None
        votes = certificate.get('votes') if type(certificate) is dict else None
        for vote in votes if type(votes) is list else []:
            item = self.observe(vote, validators)
            if item is not None:
                found.append(item)
        return found

    def export(self):
        return {'version': VERSION, 'chain': self.chain, 'evidence': [deepcopy(e) for e in self.evidence.values()],
                'observed': self.observed, 'dropped': self.dropped, 'slots': len(self.slots),
                'consequence': 'NONE_ADOPTED', 'execution_authorized': False}
