"""Token preference on top of a fee that was already quoted. Nothing here mints or promises a yield.

Discounts can only widen as qualified volume grows, and the fee after the discount
can only fall. A stablecoin fee can be auto-routed into a governed posted rate.
That rate is not an oracle. Stake tiers are entitlements. They do not override BIND.
"""
from .crypto import integer, need

LAUNCH_DISCOUNT_BPS = 3000
MAX_DISCOUNT_BPS = 8000
SLIPPAGE_CAP_BPS = 100
HAIRCUT_BPS = 8000
LOCK_BONUS_BPS = 500
QUOTE_LABEL = 'GOVERNED_NOT_ORACLE'


def discount_bps(qualified_volume, floor_bps=LAUNCH_DISCOUNT_BPS):
    """The launch discount is the floor. Volume can only widen it, up to the cap."""
    integer(qualified_volume)
    integer(floor_bps)
    need(0 <= floor_bps <= MAX_DISCOUNT_BPS, 'TOKEN_DISCOUNT')
    extra = min(2000, qualified_volume // 1000)
    widened = min(MAX_DISCOUNT_BPS, floor_bps + extra)
    need(widened >= floor_bps, 'TOKEN_DISCOUNT')
    return widened


def wider_only(previous_bps, next_bps):
    integer(previous_bps)
    integer(next_bps)
    need(next_bps >= previous_bps, 'TOKEN_DISCOUNT_NARROWED')
    return True


def fee_after(amount, discount):
    integer(amount)
    integer(discount)
    need(0 <= discount <= MAX_DISCOUNT_BPS, 'TOKEN_DISCOUNT')
    return amount * (10000 - discount) // 10000


def fee_only_falls(previous_fee, next_fee):
    integer(previous_fee)
    integer(next_fee)
    need(next_fee <= previous_fee, 'TOKEN_FEE_ROSE')
    return True


def auto_route(stable_fee, posted_rate, slippage_bps):
    """Buy the token for the fee at a posted rate, capped by slippage. Not an oracle and not an AMM."""
    integer(stable_fee)
    integer(posted_rate, True)
    integer(slippage_bps)
    need(slippage_bps <= SLIPPAGE_CAP_BPS, 'TOKEN_SLIPPAGE')
    if stable_fee <= 0 or posted_rate <= 0:
        bought = 0
    else:
        worst = posted_rate * (10000 + slippage_bps) // 10000
        bought = stable_fee * 10000 // worst
    return {'stable_fee': stable_fee, 'token_bought': bought, 'posted_rate': posted_rate,
            'slippage_bps': slippage_bps, 'label': QUOTE_LABEL, 'oracle': False, 'guaranteed_return': False}


def collateral_requirement(stable_requirement, haircut_bps=HAIRCUT_BPS):
    """Token bonds post less than the same covenant in stablecoin. The haircut is an illustrative parameter."""
    integer(stable_requirement)
    integer(haircut_bps)
    need(0 < haircut_bps <= 10000, 'TOKEN_HAIRCUT')
    return stable_requirement * haircut_bps // 10000


def cashback(base, locked):
    """A kept-promise rebate paid in token. A lock bonus is still not a yield."""
    integer(base)
    integer(locked)
    bonus = base * LOCK_BONUS_BPS // 10000 if locked else 0
    return {'token': base + bonus, 'bonus': bonus, 'guaranteed_return': False}


def savings_line(stable_amount, token_amount):
    integer(stable_amount)
    integer(token_amount)
    saved = stable_amount - token_amount
    if saved < 0:
        saved = 0
    return 'you saved %d by paying in COV' % saved


def entitlement(lock_amount, lock_days):
    """Stake-for-service tier. An entitlement, not a consensus override of BIND and not an HTTP rate-limit boost."""
    integer(lock_amount)
    integer(lock_days)
    if lock_amount <= 0 or lock_days < 30:
        tier = 0
    elif lock_amount >= 1_000_000 and lock_days >= 365:
        tier = 3
    elif lock_amount >= 100_000 and lock_days >= 90:
        tier = 2
    else:
        tier = 1
    return {'tier': tier, 'free_actions': (0, 100, 1000, 10000)[tier], 'priority_lane': tier >= 2,
            'consensus_bind_override': False, 'unsigned_http_boost': False, 'lower_collateral': tier >= 1}


def prefer_token(holds_token, policy_allows_swap):
    """SDK and MCP default. A swap of a small float happens only when the principal's policy allows it."""
    return {'pay_in_token': bool(holds_token), 'auto_swap': bool(holds_token) and bool(policy_allows_swap),
            'principal_policy_required': True}
