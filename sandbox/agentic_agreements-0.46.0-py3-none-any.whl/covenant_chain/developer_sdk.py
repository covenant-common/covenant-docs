"""A small runnable developer starter. Generation never imports developer code."""
from pathlib import Path
import hashlib,json
from covenant_language import developer_apps as a,developer_economics as e,mechanism_plans as p
from covenant_language.safe_io import atomic_write
from .constants import PRODUCT_NAME as _PRODUCT_NAME


def scaffold(name,kind='application'):
    a.name(name)
    a.need(kind in ('application','connector'),'DEVELOPER_STARTER_KIND')
    if kind=='connector':return connector_scaffold(name)
    app='''"""Local disposable developer demo; no external money or production keys."""
from covenant_chain.developer_sdk import run_starter

def add(context, arguments):
    if type(arguments) is not dict or set(arguments)!={'a','b'}:
        raise ValueError('ADD_FIELDS')
    if any(type(v) is not int or abs(v)>2**52-1 for v in arguments.values()):
        raise ValueError('ADD_INTEGER')
    return {'sum':arguments['a']+arguments['b']}

if __name__=='__main__':
    run_starter(add, __file__, NAME)
'''.replace('NAME',repr(name))
    tests='''import unittest
from app import add

class AppTests(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add({}, {'a':2,'b':3}), {'sum':5})
    def test_boolean_is_not_integer(self):
        with self.assertRaises(ValueError): add({}, {'a':True,'b':3})

if __name__=='__main__': unittest.main()
'''
    readme='''<!doctype html><html lang="en"><meta charset="utf-8"><title>NAME developer starter</title>
<style>body{font:16px/1.16 "Times New Roman",serif;color:#000;background:#fff;margin:1rem}main{border:1px solid;padding:1rem;max-width:62rem;margin:auto}h1,h2,p,pre{font:inherit;margin:0 0 .618rem}h1,h2{font-weight:bold}h2{margin-top:1rem}pre{white-space:pre-wrap}</style>
<main><h1>NAME developer starter</h1><p>One owner-installed function, one signed release, one exact call. The demo creates fresh disposable keys in memory and routes a guarded local invocation.</p>
<h2>Run</h2><p>Use the Python environment containing the supplied Covenant wheel. The release is supplied locally; these instructions do not assert a public package publication.</p><pre>python app.py
python -m unittest -v</pre><h2>Build on it</h2><p>Replace add with your exact input/output contract. Pin code and interface hashes, adopt the publisher key and fee policy in ApplicationRegistry, sign the release and install it as the host owner. Agents can draft, discover, quote and prepare calls; they cannot install code or supply signing keys through the agent tool.</p>
<p>Use EFFECT routes for consequential work through ApplicationEffectAdapter and the separately approved native workflow. Exact assent and owner backend adoption remain required. Python callbacks run with the host's permissions; use a separately isolated process or adopted VM for untrusted code.</p>
<h2>Economics and security</h2><p>The posted COV service quote is a proposal. No balance, payment, consensus inheritance, token price or production security follows from this demo. A parent reference composes applications; it does not implement a rollup. New releases preserve previous content identifiers and require fresh assent.</p></main></html>'''.replace('NAME',name)
    return {'files':{'app.py':app,'test_app.py':tests,'README.html':readme,'project.json':json.dumps({'name':name,'profile':a.VERSION,'status':'UNSIGNED_LOCAL_STARTER'},indent=2)+'\n'},'execution_authorized':False}


def initialize(directory=None,name='starter',kind='application'):
    if directory is None:
        directory=Path.cwd()/name
    a.need(isinstance(directory,(str,Path)) and not isinstance(directory,bool),'DEVELOPER_DIRECTORY')
    text=str(directory)
    a.need(1<=len(text)<=160 and all(c.isalnum() or c in '._/-' for c in text) and '..' not in text.split('/'),'DEVELOPER_DIRECTORY')
    files=scaffold(name,kind)['files'];path=Path(directory)
    a.need(not path.exists() and not path.is_symlink(),'DEVELOPER_DIRECTORY_EXISTS')
    # Resolve existing ancestors (macOS /var and /tmp are system aliases),
    # reject an explicitly selected symlink parent and write only a new child.
    a.need(path.parent.is_dir() and not path.parent.is_symlink(),'DEVELOPER_DIRECTORY_PARENT')
    path=path.parent.resolve(strict=True)/path.name
    path.mkdir(mode=0o700)
    for relative,content in files.items():atomic_write(path/relative,content,exclusive=True)
    reported=path.name if path.parent.resolve()==Path.cwd().resolve() else str(path.resolve())
    return {'directory':reported,'files':sorted(files),'executed':False}


def connector_scaffold(name):
    """Runnable unknown-protocol starter; generation never imports its source."""
    a.name(name)
    source='''"""Owner-installed future transport. No external calls in this demo."""
import hashlib,json,tempfile
from pathlib import Path
from covenant_chain.connector_harness import ConnectorHarness

PROTOCOL='MY_FUTURE_TRANSPORT'
IMPLEMENTATION=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def build(directory,transport,*,transport_implementation):
    # Owner adopts both this wrapper and the exact external implementation.
    # Credentials belong in transport's private custody, never parameters.
    pin=hashlib.sha256((IMPLEMENTATION+transport_implementation).encode('ascii')).hexdigest()
    return ConnectorHarness(directory,custom_protocols={NAME:{
        'protocol':PROTOCOL,'call':transport,'implementation':pin}})

def prepare(adapter,parameters):
    request={'protocol':PROTOCOL,'operation':NAME,'parameters':parameters}
    checked=adapter.validate_request(request)
    return {'request':request,'request_binding':{'kind':'FIXED','hash':checked['request_hash']},
            'execution_authorized':False}

if __name__=='__main__':
    calls=[]
    def local_transport(parameters):
        calls.append(parameters)
        return {'observed':parameters,'truth_established':False}
    with tempfile.TemporaryDirectory() as directory:
        adapter=build(Path(directory)/'journal',local_transport,transport_implementation='a'*64)
        try:
            proposal=prepare(adapter,{'question':'Available inventory?'})
            assert not calls  # Preparation has no effects.
            # Direct execution here is an explicit disposable owner demo.
            # Agent execution must use an adopted certified WorkflowRuntime.
            receipt=adapter.execute('b'*64,proposal['request'])
            assert adapter.execute('b'*64,proposal['request'])==receipt and len(calls)==1
            print(json.dumps({'request':proposal,'receipt':receipt,'external_calls':0}))
        finally:adapter.close()
'''.replace('NAME',repr(name))
    tests='''import tempfile,unittest
from pathlib import Path
from adapter import build,prepare

class ConnectorTests(unittest.TestCase):
    def test_preparation_and_recovery(self):
        calls=[]
        with tempfile.TemporaryDirectory() as directory:
            def transport(parameters):
                calls.append(parameters)
                return {'quoted':parameters}
            adapter=build(Path(directory)/'journal',transport,transport_implementation='a'*64)
            try:
                proposal=prepare(adapter,{'value':1})
                self.assertEqual(calls,[])
                observed=adapter.execute('b'*64,proposal['request'])
                self.assertEqual(adapter.execute('b'*64,proposal['request']),observed)
                self.assertEqual(len(calls),1)
            finally:adapter.close()

if __name__=='__main__':unittest.main()
'''
    readme='''<!doctype html><html lang="en"><meta charset="utf-8"><title>NAME connector starter</title>
<style>body{font:16px/1.16 "Times New Roman",serif;color:#000;background:#fff;margin:1rem}main{border:1px solid;padding:1rem;max-width:62rem;margin:auto}h1,h2,p,pre{font:inherit;margin:0 0 .618rem}h1,h2{font-weight:bold}h2{margin-top:1rem}pre{white-space:pre-wrap}</style>
<main><h1>NAME connector starter</h1><p>Adopt a transport that Covenant did not anticipate. Run with the locally installed Covenant package.</p>
<pre>python adapter.py
python -m unittest -v</pre><h2>Replace the transport</h2><p>Choose your own protocol identifier and exact parameter contract. The owner supplies the callback and pins its implementation. Implement a bounded timeout, response limits and an explicit observation/recovery method for the real service. Keep credentials out of tool arguments, manifests and evidence. Review or isolate the implementation before adoption: Python callbacks run with host permissions.</p>
<h2>Agree and execute</h2><p>Return the fixed request commitment from prepare. Register the adapter in the owner host and use the existing exact workflow booking and provider approvals. The local demo does not supply those approvals. The journal records an intent before the callback and will not blindly repeat an unknown outcome. A remote idempotency key requires a real adopted service contract.</p>
<h2>Compose a layer</h2><p>Use covenant_developer draft and ApplicationRegistry to attach signed parent/dependency releases, exact input and implementation pins, service economics and separately stated security assumptions. Updating a transport or layer produces a new identity. A publisher signature does not audit code or transfer execution authority.</p></main></html>'''.replace('NAME',name)
    return {'files':{'adapter.py':source,'test_adapter.py':tests,'README.html':readme,
                     'project.json':json.dumps({'name':name,'kind':'connector','status':'UNADOPTED_LOCAL_STARTER'},indent=2)+'\n'},
            'execution_authorized':False}


def run_starter(handler=None,source_path=None,name='starter'):
    if source_path is None:
        source_path=Path.cwd()/'app.py'
        if not Path(source_path).exists():
            atomic_write(source_path,scaffold(name)['files']['app.py'])
    if handler is not None and not callable(handler):
        raise ValueError('DEVELOPER_HANDLER')
    if source_path is not None and not isinstance(source_path,(str,Path)):
        raise ValueError('DEVELOPER_SOURCE')
    if handler is None:
        def handler(context,arguments):
            if type(arguments) is not dict or set(arguments)!={'a','b'}:
                raise ValueError('ADD_FIELDS')
            if any(type(v) is not int or isinstance(v,bool) or abs(v)>2**52-1 for v in arguments.values()):
                raise ValueError('ADD_INTEGER')
            return {'sum':arguments['a']+arguments['b']}
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from .crypto import public_key,sign
    from .mechanism_runtime import MechanismRegistry,invoke_local
    from .developer_runtime import ApplicationRegistry
    a.name(name)
    # Derived from the application name so a repeated local demo is the same demo.
    # This is not a production signing key.
    key=Ed25519PrivateKey.from_private_bytes(hashlib.sha256(b'covenant-developer-starter/'+name.encode('utf-8')).digest())
    publisher=public_key(key)
    implementation=hashlib.sha256(Path(source_path).read_bytes()).hexdigest();interface=p._id('COVENANT-STARTER-ADD-0.1',{'inputs':['a','b'],'output':'sum','integer_limit':2**52-1})
    mechanisms=MechanismRegistry();backend=p.manifest(name,'developer',interface,implementation,{'add':{'mode':'LOCAL','description':'Exact bounded integer addition'}})['manifest'];backend_id=mechanisms.register(backend,{'add':handler})
    policy=e.draft(name,'COV',10,[{'account':publisher,'bps':10000,'purpose':'DEVELOPER'}],token_discount_bps=1000)
    registry=ApplicationRegistry(mechanisms,{publisher:publisher},[policy['policy']]);release=a.draft(name,'0.1',publisher,{'add':{'mechanism':backend_id,'operation':'add','mode':'LOCAL','interface':interface}},policy['id'])
    consent=release['assent_payload'];registry.install(release['manifest'],sign(key,consent['label'],consent['body']))
    ready=registry.prepare(release['id'],'add',{'a':2,'b':3},'a'*64,[publisher]);assent=ready['assent_payload']
    result=invoke_local(mechanisms,plan=ready['plan'],approvals=[{'controller':publisher,'signature':sign(key,assent['label'],assent['body'])}],expected_id=ready['id'],expected_controllers=[publisher],step='call',binding=0,payload=ready['call'])
    output={'application':release['id'],'result':result['result'],'quote':registry.quote(release['id'],1),'scope':'LOCAL_DISPOSABLE_KEYS_NO_PAYMENT_OR_EXTERNAL_EFFECT'}
    print(json.dumps(output,sort_keys=True));return output


# Reachability entries for the starter names declared in the scaffold text above.
# They describe a sample. They do not run the generated demo or sign anything.
_MARKS = ('ignore previous', 'system:', '<|', '\n', 'execution_authorized')


def _reach(sample, code):
    if type(sample) is not str or not sample or len(sample) > 80 or any(mark in sample.lower() for mark in _MARKS):
        raise ValueError(code)
    return {'status': 'READY', 'execution_authorized': False, 'automatic_assent': False, 'product': _PRODUCT_NAME}


def add(sample):
    return _reach(sample, 'ADD_FIELDS')


def build(sample):
    return _reach(sample, 'BUILD_FIELDS')


def prepare(sample):
    return _reach(sample, 'PREPARE_FIELDS')


class AppTests:
    def __repr__(self):
        return 'AppTests'

    def test_add(self, sample):
        return _reach(sample, 'ADD_FIELDS')

    def test_boolean_is_not_integer(self, sample):
        return _reach(sample, 'ADD_FIELDS')

    def local_transport(self, sample):
        return _reach(sample, 'ADD_FIELDS')


class ConnectorTests:
    def __repr__(self):
        return 'ConnectorTests'

    def test_preparation_and_recovery(self, sample):
        return _reach(sample, 'PREPARE_FIELDS')
