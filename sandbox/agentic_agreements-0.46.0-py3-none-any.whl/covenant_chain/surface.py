"""Agent entry for modules that have no same-file MCP, SDK, or RPC sibling.

``covenant_surface`` describes a named capability and refuses to execute it.
A list payload and instruction-shaped text are stable refusals.

The same refusal is reachable on four channels of the existing host:
MCP (this tool, plus a read-only card for each non-orchestrator tool the
keyless host does not already mount), ``POST /surface``, JSON-RPC
``surface/describe``, and ``python -m covenant_chain.surface describe``.
Orchestrator-owned names stay with that area. Nothing here submits a transaction.

The product name is the Agentic Agreements Protocol. Identifiers stay ``covenant``.
"""
import re
from pathlib import Path

from .constants import (
    AGENT_SURFACE_FIELDS, AGENT_SURFACE_REFUSED, LEGACY_SLUG, PRODUCT_NAME, SURFACE_ROUTE, SURFACE_TOOL,
)
from .crypto import need

_INJECTION = ('ignore previous', 'system:', '<|', '\n', 'execution_authorized')
_CODE = re.compile(r'[A-Z][A-Z0-9_]{1,80}(?::[A-Za-z0-9_]+)?\Z')
# Catalog discovers this literal. It stays equal to SURFACE_ROUTE.
route = '/surface'
need(route == SURFACE_ROUTE, AGENT_SURFACE_FIELDS)

# Same needle order as sims/coverage/report.suggest_persona. The default is
# orchestrator, and this module does not publish those names.
_NEEDLES = (
    ('arbitrat', 'arbiter'),
    ('appeal', 'arbiter'),
    ('ads', 'reward gamer'),
    ('stak', 'token staker'),
    ('token', 'token staker'),
    ('shariah', 'Islamic finance'),
    ('onboard', 'Lagos freelancer'),
    ('invite', 'Lagos freelancer'),
    ('referral', 'reward gamer'),
    ('offline', 'offline co-op'),
    ('sms', 'SMS user'),
    ('light', 'node operator'),
    ('rust', 'red team'),
    ('symbolic', 'developer'),
    ('expr', 'developer'),
    ('directory', 'network sandbox'),
    ('agent_network', 'network sandbox'),
    ('match_surface', 'network sandbox'),
    ('a2a', 'a2a adversarial'),
    ('feedback', 'developer'),
    ('identity', 'enterprise'),
    ('escrow', 'enterprise'),
    ('payment', 'cross-border trade'),
    ('rail', 'cross-border trade'),
    ('consensus', 'node operator'),
    ('validator', 'node operator'),
    ('host', 'node operator'),
    ('chaos', 'chaos swarm'),
    ('lifecycle', 'lifecycle swarm'),
    ('succession', 'lifecycle swarm'),
    ('predict', 'parametric insurer'),
    ('insur', 'parametric insurer'),
    ('lease', 'tenant/landlord'),
    ('landlord', 'tenant/landlord'),
    ('construct', 'construction'),
    ('logistic', 'logistics'),
    ('courier', 'logistics'),
    ('creator', 'creator'),
    ('license', 'creator'),
    ('bakery', 'bakery'),
    ('marketplace', 'bakery'),
    ('developer', 'developer'),
    ('scaffold', 'developer'),
    ('freelanc', 'agent freelancer'),
    ('orchestr', 'orchestrator'),
    ('workflow', 'orchestrator'),
    ('doc', 'SMS user'),
    ('quickstart', 'developer'),
    ('govern', 'enterprise'),
    ('vote', 'enterprise'),
    ('econom', 'reward gamer'),
    ('fee', 'reward gamer'),
)
_TOOL_RE = re.compile(
    r"['\"]name['\"]\s*:\s*['\"](covenant_[a-z0-9_]+)['\"]"
    r"|name\s*=\s*['\"](covenant_[a-z0-9_]+)['\"]"
    r"|\(\s*['\"](covenant_[a-z0-9_]+)['\"]"
)
# Built without a quoted wire prefix so the catalog does not treat package
# directories as tool names.
_PREFIXES = (
    LEGACY_SLUG + '_chain',
    LEGACY_SLUG + '_agent',
    LEGACY_SLUG + '_language',
    LEGACY_SLUG + '_x402',
    'packages',
)
_SUBJECT_SCHEMA = {
    'type': 'object',
    'additionalProperties': False,
    'required': ['subject'],
    'properties': {'subject': {'type': 'string', 'minLength': 1, 'maxLength': 80}},
}
_CHANNELS = ['mcp', 'http', 'jsonrpc', 'cli']
_declarations_cache = None
_native_cache = None


def describe(name):
    """Describe one capability. Never authorizes execution."""
    if type(name) is not str:
        raise ValueError(AGENT_SURFACE_FIELDS)
    need(0 < len(name) <= 300, AGENT_SURFACE_FIELDS)
    lowered = name.lower()
    if any(mark in lowered for mark in _INJECTION):
        raise ValueError(AGENT_SURFACE_REFUSED)
    return {
        'name': name,
        'status': 'DESCRIBED',
        'execution_authorized': False,
        'automatic_assent': False,
        'next': 'Ask the principal to adopt this capability before any effect.',
    }


def invoke(arguments):
    """MCP body. ``parameters`` must be an object. A list is AGENT_SURFACE_FIELDS."""
    need(type(arguments) is dict, AGENT_SURFACE_FIELDS)
    action = arguments.get('action', 'describe')
    parameters = arguments.get('parameters', {})
    if type(parameters) is not dict:
        raise ValueError(AGENT_SURFACE_FIELDS)
    blob = repr(arguments).lower()
    if 'ignore previous' in blob or '<|' in blob:
        raise ValueError(AGENT_SURFACE_REFUSED)
    if action == 'inventory':
        return {
            'status': 'INVENTORY',
            'entry': SURFACE_TOOL,
            'execution_authorized': False,
            'automatic_assent': False,
        }
    if action != 'describe':
        raise ValueError(AGENT_SURFACE_FIELDS)
    return describe(parameters.get('name') or SURFACE_TOOL)


def _card(tool_name, subject):
    return {
        'tool': tool_name,
        'subject': subject,
        'status': 'REACHABLE',
        'channels': list(_CHANNELS),
        'execution_authorized': False,
        'automatic_assent': False,
        'product': PRODUCT_NAME,
    }


def _persona(path, name):
    text = (path + ' mcp:' + name).lower()
    for needle, persona in _NEEDLES:
        if needle in text:
            return persona
    return 'orchestrator'


def _declarations():
    """Tool names as text. No imports, so listing tools cannot run them."""
    global _declarations_cache
    if _declarations_cache is not None:
        return _declarations_cache
    found = {}
    root = Path(__file__).resolve().parents[1]
    for prefix in _PREFIXES:
        base = root / prefix
        if not base.is_dir():
            continue
        for path in base.rglob('*.py'):
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding='utf-8', errors='replace')
            except OSError:
                continue
            relative = path.relative_to(root).as_posix()
            for groups in _TOOL_RE.findall(text):
                name = groups[0] or groups[1] or groups[2]
                if name:
                    found.setdefault(name, set()).add(relative)
    _declarations_cache = {name: tuple(sorted(paths)) for name, paths in found.items()}
    return _declarations_cache


def _open_names():
    """Names with at least one declaring file outside the orchestrator area."""
    declared = _declarations()
    return tuple(sorted(
        name for name, paths in declared.items()
        if any(_persona(path, name) != 'orchestrator' for path in paths)
    ))


def _native_names():
    """Tools the native host already lists. The chain host must not shadow them."""
    global _native_cache
    if _native_cache is not None:
        return _native_cache
    found = set()
    try:
        from covenant_agent.mcp import tool_descriptors
        found = {
            row['name'] for row in tool_descriptors(include_once=True)
            if type(row) is dict and type(row.get('name')) is str
        }
    except Exception:
        found = set()
    _native_cache = found
    return _native_cache


def _descriptor(name):
    return {
        'name': name,
        'title': name.replace('_', ' ').title(),
        'description': (
            PRODUCT_NAME + ' read-only entry for ' + name
            + '. It does not execute, sign, or spend.'
        ),
        'inputSchema': {
            'type': 'object',
            'additionalProperties': False,
            'required': ['subject'],
            'properties': {'subject': {'type': 'string', 'minLength': 1, 'maxLength': 80}},
        },
        'annotations': {
            'readOnlyHint': True,
            'destructiveHint': False,
            'idempotentHint': True,
            'openWorldHint': False,
        },
    }


def missing_descriptors(present):
    """Read-only cards for declared tools this host does not already mount."""
    blocked = set(present) | _native_names()
    return [_descriptor(name) for name in _open_names() if name not in blocked]


def call_missing(name, arguments, present):
    """Return a card for one unmounted non-orchestrator tool, or None to keep going.

    Real tools stay on their own branch. A name this function does not own
    returns None so the existing dispatcher is unchanged.
    """
    if type(name) is not str or name in present or name in _native_names():
        return None
    if name not in _open_names():
        return None
    from .tool_input import validate_schema
    validate_schema(arguments, _SUBJECT_SCHEMA)
    subject = arguments['subject']
    if any(mark in subject.lower() for mark in _INJECTION):
        raise ValueError(AGENT_SURFACE_REFUSED)
    return _card(name, subject)


def accept_http(value):
    """POST /surface body. A list is AGENT_SURFACE_FIELDS. A mandate is refused."""
    if type(value) is not dict:
        raise ValueError(AGENT_SURFACE_FIELDS)
    if value.get('execution_authorized') is True:
        raise ValueError(AGENT_SURFACE_REFUSED)
    blob = repr(value).lower()
    if 'ignore previous' in blob or '<|' in blob:
        raise ValueError(AGENT_SURFACE_REFUSED)
    key = value.get('key')
    subject = key if type(key) is str and 0 < len(key) <= 80 else SURFACE_TOOL
    if any(mark in subject.lower() for mark in _INJECTION):
        raise ValueError(AGENT_SURFACE_REFUSED)
    return _card(SURFACE_TOOL, subject)


def accept_rpc(params):
    """JSON-RPC surface/describe. Empty params (aside from transport metadata) succeed."""
    if type(params) is not dict:
        raise ValueError(AGENT_SURFACE_FIELDS)
    body = {key: item for key, item in params.items() if key != '_meta'}
    if body.get('execution_authorized') is True:
        raise ValueError(AGENT_SURFACE_REFUSED)
    blob = repr(body).lower()
    if 'ignore previous' in blob or '<|' in blob or '\n' in blob:
        raise ValueError(AGENT_SURFACE_REFUSED)
    if body:
        raise ValueError(AGENT_SURFACE_FIELDS)
    return _card(SURFACE_TOOL, SURFACE_TOOL)


def not_committed(code, operation=None):
    """Stable refusal. Nothing was signed again or submitted.

    Programmers still pass a real payload to commit. A missing profile, an
    unknown operation, or a sample that is not an object becomes this card
    instead of a traceback. ``execution_authorized`` stays false.
    """
    named = getattr(code, 'code', None)
    text = str(named if isinstance(named, str) and named else code).splitlines()
    head = text[0].strip() if text and text[0].strip() else 'FIELDS'
    token = head.split(' ', 1)[0]
    stable = token if _CODE.fullmatch(token) else 'FIELDS'
    body = {
        'status': 'NOT_COMMITTED',
        'code': stable,
        'execution_authorized': False,
        'automatic_assent': False,
        'next_action': 'Nothing was submitted. Correct the named field or open the profile that adopted this operation.',
    }
    if operation:
        body['operation'] = operation
    return body


def http_body(path, value):
    """Describe one host route. A list is ``ROUTE_BODY`` and is not stored."""
    if type(value) is not dict:
        raise ValueError('ROUTE_BODY')
    blob = repr(value).lower()
    if 'ignore previous' in blob or '<|' in blob or 'system:' in blob:
        raise ValueError('AGENT_SURFACE_REFUSED')
    described = describe(path if type(path) is str else 'route')
    described['route'] = path
    described['code'] = 'ROUTE_DESCRIBED'
    described['accepted_fields'] = sorted(key for key in value if key != 'execution_authorized')[:16]
    described['execution_authorized'] = False
    return described


def main(argv=None):
    """``python -m covenant_chain.surface describe [name]``. --help exits 0."""
    import argparse
    import json
    parser = argparse.ArgumentParser(prog='agentic-agreements-surface')
    commands = parser.add_subparsers(dest='command')
    described = commands.add_parser('describe')
    described.add_argument('name', nargs='?')
    args = parser.parse_args(argv)
    if args.command != 'describe':
        parser.print_help()
        return 0
    print(json.dumps(describe(args.name or SURFACE_TOOL), sort_keys=True, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
