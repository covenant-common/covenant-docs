"""One committee ledger for every deploy mode.

Hosted, federated, peer, and hybrid all call the same ``submit``. A federated
transfer is a transaction on that ledger. It is not a bridge export and it is
not kept on a side list.
"""
from __future__ import annotations

from .app import apply_transaction, transaction_id
from .crypto import need

MODES = ('hosted', 'federated', 'peer', 'hybrid')
LEDGER = 'committee'


class CommitteeLedger:
    """In-process committee ledger. ``submit`` preflights and ``commit`` includes."""

    def __init__(self, state):
        self.state = state
        self.pending = {}
        self.order = []
        self.included = []
        self.height = 0

    def submit(self, transaction):
        tid = transaction_id(transaction)
        if tid in self.included:
            return {'id': tid, 'status': 'committed'}
        if tid in self.pending:
            return {'id': tid, 'status': 'pending'}
        apply_transaction(self.state, transaction, self.height + 1)
        self.pending[tid] = transaction
        self.order.append(tid)
        return {'id': tid, 'status': 'pending'}

    def commit(self):
        if not self.order:
            return []
        self.height += 1
        state = self.state
        included = []
        for tid in self.order:
            state = apply_transaction(state, self.pending[tid], self.height)
            included.append(tid)
        self.state = state
        self.included.extend(included)
        self.pending = {}
        self.order = []
        return included


def submit(ledger, mode, transaction):
    """Hand ``transaction`` to the committee ledger. The mode does not pick another chain."""
    need(mode in MODES, 'DEPLOY_MODE')
    receipt = ledger.submit(transaction)
    need(type(receipt) is dict and type(receipt.get('id')) is str, 'LEDGER_RECEIPT')
    return {'mode': mode, 'ledger': LEDGER, 'bridge_export': False, 'receipt': receipt}


def forward_targets(host_id, peers, epoch, recipients=None):
    """Peers a federated host forwards to.

    When ``covenant_chain.scale.overlay`` is installed, this is the same
    ``recipients(..., '/submit', epoch)`` draw the p2p view uses. A small
    committee with that module absent receives every other member.
    """
    need(type(host_id) is str and len(host_id) > 0, 'FEDERATED_HOST')
    need(type(peers) is list and all(type(peer) is str for peer in peers), 'FEDERATED_PEERS')
    if recipients is None:
        try:
            from covenant_chain.scale.overlay import recipients as overlay_recipients
        except ImportError:
            overlay_recipients = None
        recipients = overlay_recipients
    if recipients is None:
        return [peer for peer in peers if peer != host_id]
    chosen = list(recipients(host_id, list(peers), '/submit', epoch))
    need(all(type(peer) is str and peer != host_id for peer in chosen), 'FEDERATED_TARGET')
    return chosen


def federated_forward(transaction, host_id, peers, epoch, deliver, recipients=None):
    """Forward one transaction from a federated host onto the committee.

    ``deliver(peer, transaction)`` writes that peer's committee mempool.
    The transaction object is the one the other modes already submit.
    """
    targets = forward_targets(host_id, peers, epoch, recipients)
    for peer in targets:
        deliver(peer, transaction)
    return {'mode': 'federated', 'ledger': LEDGER, 'targets': targets, 'bridge_export': False}
