"""Discovery schemas for the existing frozen signed-social event shapes."""
from .cooperation_interface import schema,HASH
ANY={}
NULL_HASH={'type':['string','null'],'pattern':'^[0-9a-f]{64}$'}
def string(maximum,minimum=0):return {'type':'string','minLength':minimum,'maxLength':maximum}
def array(items,maximum,minimum=0):return {'type':'array','items':items,'minItems':minimum,'maxItems':maximum}
def closed(properties):return schema(properties,tuple(properties))
POST=closed({'thread':NULL_HASH,'title':string(256),'content':ANY,'tags':array(string(80),32)})
GROUP=closed({'name':string(128,1),'kind':string(64,1),'charter':{'type':['string','object']},'open_posting':{'type':'boolean'}})
FORUM={
    'GROUP':GROUP,'POST':POST,'CORRECT':closed({'target':HASH,'content':ANY}),
    'MODERATE':closed({'target':HASH,'action':{'enum':['HIDE','RESTORE']},'reason':ANY}),
    'LINK':closed({'target':HASH,'relation':ANY,'description':ANY}),
    'ENDORSE':closed({'subject':HASH,'context':string(80,1),'origin':HASH,'result':{'enum':['POSITIVE','NEGATIVE','UNKNOWN']}})}
ROLE={
    'propose':closed({'holder':HASH,'name':string(80,1),'permissions':{**array(string(80,1),32),'description':'Exact case-sensitive native labels: govern, moderate, post, arbitrate, organize. organize is currently not consulted by any native action. Other labels may be agreed as custom terms but grant no native authority. Read covenant_review.permissions for actual current gates; open_posting permits posting independently of roles.'},'supersedes':NULL_HASH,'revocable':{'type':'boolean'},'terms':ANY}),
    'accept':closed({'proposal':HASH}),'revoke':closed({'role':HASH,'reason':ANY})}
ARBITRATION={
    'claim':closed({'target':HASH,'claim':ANY,'parties':{**array(HASH,16,2),'description':'Distinct identities. The public claim helper sorts this set before creating exact signed bytes; duplicates refuse. Native imported events must already use sorted unique parties. Every named party must separately accept the exact emitted case.'},'arbitrator':HASH,'procedure':ANY}),
    'accept':closed({'case':HASH}),
    'resolve':closed({'case':HASH,'outcome':{'enum':['SUPPORTED','REFUTED','INDETERMINATE']},'reasons':ANY,'evidence':ANY})}
