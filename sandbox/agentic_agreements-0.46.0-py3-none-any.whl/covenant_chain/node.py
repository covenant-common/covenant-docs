"""Experimental native validator: separate durable process, bounded HTTP networking.

Consensus is implemented by consensus.Engine. HTTP is a development transport,
not an Internet-hardened peer discovery or Sybil-resistance layer. The optional
partition endpoint is restricted to the loopback listener and disabled by default.

`python -m covenant_chain.node balance --state STATE.json --account HEX` reads a
ledger balance and exits without starting a validator.
"""
from __future__ import annotations

from covenant_language.platform_support import require_posix
require_posix("covenant_chain/node")
import argparse
from collections import OrderedDict, deque
import copy
import fcntl
import ipaddress
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import math
import os
from pathlib import Path
import signal
import socket
import threading
import time
import urllib.parse
import urllib.request
from socketserver import ThreadingMixIn

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from . import app, crypto, observability
from .backup import refuse_pending_restore
from .security import require_patched_backend
from .consensus import Engine
from .consensus_evidence import EquivocationWatch
from .storage import Journal
from .proofs import verify_history
from .state import prove_record,Table,pairs,pairs_after
from .launch_security import read_signing_key, validate_peers, check_storage_paths, local_opener
from .shielded import BackendUnavailable
from .profile_features import (has as profile_has, STATE_PROOFS, TX_64K, COMMITTEE_HANDOFF,
                               LIGHT_TRANSITIONS, SERVICE_OFFERS, FEDERATION_LIMITS, CONTINUITY_LIMITS)

MAX_BODY = 1024 * 1024
MAX_TX_BYTES = 16 * 1024
MAX_PENDING = 1024
MAX_QUEUE = 4096
MAX_QUEUE_BYTES = 16 * MAX_BODY
FEDERATION_TX_BYTES = app.FEDERATION_MAX_TX_BYTES
FEDERATION_BLOCK_TX_BYTES = app.FEDERATION_MAX_BLOCK_TX_BYTES
MAX_STATE_REPLY_BYTES = 3*MAX_BODY
MAX_SCOPED_REPLY_BYTES = 256*1024
# Route shapes for metric labels; anything else is counted as 'other'.
ROUTES = frozenset({'/', '/status', '/context', '/genesis', '/record', '/offers', '/state', '/economics', '/blocks',
                    '/tx/*', '/feedback', '/feedback/dashboard', '/causal', '/causal/*', '/surface', '/submit',
                    '/preview', '/light-proof', '/light-proofs', '/timed-light-proof', '/timed-light-proofs', '/proof', '/message', '/control', '/mcp', '/provider',
                    '/relay', '/replica/command', '/replica/history', '/replica/message', '/rpc',
                    '/.well-known/covenant.json', '/.well-known/openapi.json', '/.well-known/agent-card.json'})
# Client proof admission. Consensus gossip is not charged against this bucket.
PROOF_BURST = 4.0
PROOF_RATE = 1.0
# The command line waits this long before an empty block when COVENANT_EMPTY_BLOCK_INTERVAL
# is unset, and its round timeout leaves the round-0 proposer this margin after the wait.
CLI_EMPTY_BLOCK_WAIT = 5.0
PACING_MARGIN = 2.0


def empty_block_due(pending, interval, since, now):
    """Honest proposers wait before an empty block. Validity does not use this clock."""
    if not interval or interval <= 0 or pending:
        return True
    return now - since >= interval


def pacing_problem(base_timeout, empty_block_interval):
    """NODE_TIMEOUT_BELOW_PACING when an idle height would time out before its proposer may propose.

    Round 0 lasts base_timeout seconds (consensus.Engine._duration); the proposer
    of an idle height proposes only after the empty-block wait. A timeout at or
    below the wait spends rounds that cannot succeed on every idle height. Slow,
    not unsafe, so the node warns; covenant-doctor applies the same rule.
    """
    if not empty_block_interval or base_timeout > empty_block_interval:
        return None
    return {'code': 'NODE_TIMEOUT_BELOW_PACING',
            'what': f'--base-timeout {base_timeout:g} s is not above the {empty_block_interval:g} s empty-block wait, '
                    'so every idle height times out before its proposer may propose and needs extra rounds.',
            'fix': f'Use --base-timeout {empty_block_interval + PACING_MARGIN:g} (the wait plus {PACING_MARGIN:g} '
                   'seconds), or a shorter COVENANT_EMPTY_BLOCK_INTERVAL.',
            'retry': 'after the fix'}


def _proof_op(tx):
    try:op=tx['body']['op']
    except (KeyError, TypeError):return False
    return type(op) is str and (op.startswith('SHIELD_') or op.startswith('CONFIDENTIAL_'))


def proof_admission(buckets, identity, now, *, burst=PROOF_BURST, rate=PROOF_RATE):
    """Token bucket for client proof checks. Returns False when the caller should wait."""
    slot = buckets.setdefault(identity, {'tokens': burst, 'updated': now})
    slot['tokens'] = min(burst, slot['tokens'] + max(0.0, now - slot['updated']) * rate)
    slot['updated'] = now
    if slot['tokens'] < 1:
        return False
    slot['tokens'] -= 1
    return True


def bounded_state(state,maximum=MAX_STATE_REPLY_BYTES):
    """Diagnostic export stops before copying an unbounded authenticated table."""
    used=2;out={}
    for table,value in state.items():
        used+=len(crypto.canonical(table))+2
        if isinstance(value,Table):
            value.seal();records={};used+=2
            for record_key,record in pairs(value.root):
                used+=len(crypto.canonical(record_key))+len(crypto.canonical(record))+2
                crypto.need(used<=maximum,'STATE_EXPORT_LIMIT: use /context and /record')
                records[record_key]=copy.deepcopy(record)
            out[table]=records
        else:
            used+=len(crypto.canonical(value))+1
            crypto.need(used<=maximum,'STATE_EXPORT_LIMIT: use /context and /record')
            out[table]=copy.deepcopy(value)
    crypto.need(len(crypto.canonical(out))<=maximum,'STATE_EXPORT_LIMIT: use /context and /record')
    return out

def _loopback_host(host):
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def allow_state_export(node, host, peer_header):
    """Admit one /state read.

    A loopback client, including the local demo, draws a separate larger
    budget. Every other caller keeps the public diagnostic bucket. A claimed
    X-Covenant-Peer header is not authenticated identity and exempts nothing.
    """
    del peer_header
    local = _loopback_host(host)
    cap, rate = (128.0, 16.0) if local else (16.0, 2.0)
    attr = 'state_export_local_tokens' if local else 'state_export_tokens'
    clock = 'state_export_local_updated' if local else 'state_export_updated'
    now = time.monotonic()
    tokens = min(cap, getattr(node, attr) + max(0.0, now - getattr(node, clock)) * rate)
    setattr(node, clock, now)
    if tokens < 1:
        setattr(node, attr, tokens)
        return False
    setattr(node, attr, tokens - 1)
    return True


def offers_page(node,query):
    """Bounded current-state discovery, never a certified complete track record."""
    crypto.need(type(query) is dict and set(query)<={'after','limit','capability','max_price','provider'} and
                all(type(v) is list and len(v)==1 for v in query.values()),'OFFERS_QUERY')
    after=query.get('after',[''])[0];limit_raw=query.get('limit',['32'])[0]
    crypto.need(type(after) is str and (after=='' or bool(crypto.HEX.fullmatch(after))),'OFFERS_CURSOR')
    crypto.need(type(limit_raw) is str and 1<=len(limit_raw)<=2 and limit_raw.isascii() and limit_raw.isdigit(),'OFFERS_LIMIT')
    limit=int(limit_raw);crypto.need(1<=limit<=32,'OFFERS_LIMIT')
    capability=query.get('capability',[None])[0]
    crypto.need(capability is None or (type(capability) is str and 0<len(capability)<=80),'OFFERS_CAPABILITY')
    price=query.get('max_price',[None])[0]
    if price is not None:
        crypto.need(type(price) is str and 1<=len(price)<=16 and price.isascii() and price.isdigit(),'OFFERS_PRICE')
        price=int(price);crypto.integer(price)
    provider=query.get('provider',[None])[0]
    if provider is not None:crypto.key(provider)
    crypto.canonical([after,capability,provider])
    table_name='service_offers' if profile_has(node.genesis['protocol'],SERVICE_OFFERS) else 'world_services'
    table=node.state.get(table_name);crypto.need(isinstance(table,Table),'OFFERS_PROFILE')
    # Native state is sealed at every certified application checkpoint.
    table.seal();iterator=pairs_after(table.root,after);items=[];examined=0;last=after;exhausted=False
    while examined<512 and len(items)<limit:
        try:sid,offer=next(iterator)
        except StopIteration:exhausted=True;break
        examined+=1;last=sid
        unit_price=offer.get('unit_price',offer.get('price'))
        if node.applied>=offer['expiry'] or (capability is not None and offer['capability']!=capability) or (price is not None and unit_price>price) or (provider is not None and offer['provider']!=provider):continue
        items.append({'id':sid,'offer':copy.deepcopy(offer)})
    if not exhausted:
        try:next(iterator)
        except StopIteration:exhausted=True
    result={'chain':node.chain_id,'protocol':node.genesis['protocol'],'applied_height':node.applied,'items':items,
            'next_after':None if exhausted else last,'exhausted':exhausted,'examined':examined}
    crypto.need(len(crypto.canonical(result))<=MAX_SCOPED_REPLY_BYTES,'OFFERS_REPLY_LIMIT')
    return result


class Node:
    def __init__(self, genesis, peers, member, key, db, base_timeout=1.0, sandbox_control=False,bootstrap=None,causal_receipts=False,feedback_owner=None,feedback_reporters=None,peer_tls=None,empty_block_interval=None):
        # An explicit host interval does not rewrite process-global owner configuration.
        raw_interval = (os.environ.get('COVENANT_EMPTY_BLOCK_INTERVAL') or 0) if empty_block_interval is None else empty_block_interval
        try:
            self.empty_block_interval = float(raw_interval)
        except (TypeError, ValueError):
            raise ValueError('EMPTY_BLOCK_INTERVAL') from None
        if not math.isfinite(self.empty_block_interval) or not 0 <= self.empty_block_interval <= 3600:
            raise ValueError('EMPTY_BLOCK_INTERVAL')
        if peer_tls is None:
            validate_peers(peers)
            self.transport_opener = local_opener()
        else:
            from .transport import peer_opener
            self.transport_opener = peer_opener(peers,peer_tls)
        Path(db).parent.mkdir(parents=True, exist_ok=True)
        self.storage_lock = open(str(db) + ".lock", "a")
        try:
            fcntl.flock(self.storage_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.storage_lock.close()
            raise RuntimeError("validator database already in use") from exc
        self.genesis = genesis
        self.max_tx_bytes=64*1024 if profile_has(genesis['protocol'],TX_64K) else MAX_TX_BYTES
        if profile_has(genesis['protocol'],FEDERATION_LIMITS):self.max_tx_bytes=FEDERATION_TX_BYTES
        if profile_has(genesis['protocol'],CONTINUITY_LIMITS):self.max_tx_bytes=app.CONTINUITY_MAX_TX_BYTES
        self.max_block_tx_bytes=app.CONTINUITY_MAX_BLOCK_TX_BYTES if profile_has(genesis['protocol'],CONTINUITY_LIMITS) else FEDERATION_BLOCK_TX_BYTES
        self.chain_id = crypto.genesis_id(genesis)
        # Bounded proof of a validator signing two bodies for one slot. Observation only.
        self.evidence = EquivocationWatch(self.chain_id)
        self.member = member
        self.peers = dict(peers)
        self.blocked = set()
        self.sandbox_control = sandbox_control
        self.lock = threading.RLock()
        self.proof_buckets = {}
        self.timed_proof_buckets = {}
        self.state = app.genesis_state(genesis)
        self.applied = 0
        self.pending = OrderedDict()
        self.results = OrderedDict()
        self.inbox = deque()
        self.inbox_bytes = 0
        self.gossip = deque()
        self.seen = OrderedDict()
        self.errors = deque(maxlen=40)
        self.stopping = threading.Event()
        # Host clock for Engine.tick, behind a monotonic floor (see _tick).
        self.clock = time.monotonic
        self._tick_raw = None
        self._tick_now = 0.0
        self.clock_refusals = 0
        self.state_export_tokens=16.0
        self.state_export_updated=time.monotonic()
        self.state_export_local_tokens=128.0
        self.state_export_local_updated=time.monotonic()
        journal=Journal(db);stored=journal.load()
        history=journal.log.read() if stored is not None else (bootstrap or [])
        verified=verify_history(genesis,history,self.chain_id)
        self.state=verified['state'];self.applied=verified['height']
        active=self.state['domain']['active'] if 'domain' in self.state else genesis
        if member in active['validators'] and crypto.public_key(key) != active['validators'][member]:
            journal.db.close()
            self.storage_lock.close()
            raise ValueError('LAUNCH_VALIDATOR_KEY_MISMATCH')
        cfg={'chain_id':self.chain_id,'validators':active['validators'],'faults':active['faults']}
        journal.db.close()
        self.engine = Engine(db, member, key,cfg,self.build_block,self.validate_block,
                             base_timeout=base_timeout,next_config=self.next_config,
                             bootstrap=history if stored is None else None,
                             proposal_admission=self.admit_proposal)
        self.pacing = pacing_problem(base_timeout, self.empty_block_interval)
        # A durable owner halt remains read-only across process restarts, even
        # when the halt receipt was not returned before the earlier crash.
        if self.engine.s.get('migration_halt') is not None:
            self.stopping.set()
        verify_history(genesis, self.engine.committed(), self.chain_id)
        self.refresh()
        self.light_transitions=[]
        if profile_has(self.genesis['protocol'],LIGHT_TRANSITIONS):
            from .light import build_transition_index
            self.light_transitions=build_transition_index(self.genesis,self.engine.committed())
        self.causal = None
        if causal_receipts:
            from .causal import ReceiptDAG
            self.causal = ReceiptDAG(str(db)+'.causal.sqlite3', self.chain_id)
        self.feedback=None
        if feedback_owner is not None:
            from .feedback import FeedbackDesk
            self.feedback=FeedbackDesk(str(db)+'.feedback.sqlite3',self.chain_id,feedback_owner,feedback_reporters)
        # Local scheduling only. Inert unless COVENANT_SCALE=1, so replay and
        # the default proposer stay on the historical path. PR #21 rewrites the
        # pump; this hook stays at the end of construction so it can wrap the
        # factory the engine already captured.
        from .scale.runtime import attach
        attach(self)
        from .scale.backpressure import Backpressure
        self.backpressure = Backpressure()
        self._observe(db)

    def _observe(self, db):
        """Operator health and metrics. Readiness is a process fact, never consensus evidence."""
        self.ops = observability.Ops('node', routes=ROUTES)
        self.ops.health.add('consensus', self._consensus_ready)
        self.ops.health.add('storage', observability.writable_directory(str(Path(db).absolute().parent)))
        self.ops.queue('pending_transactions', lambda: len(self.pending))
        self.ops.queue('inbox_messages', lambda: len(self.inbox))
        self.ops.queue('gossip_jobs', lambda: len(self.gossip))
        self.ops.storage('journal', [str(db) + suffix + tail for suffix in ('.sqlite3', '.causal.sqlite3', '.feedback.sqlite3')
                                     for tail in ('', '-wal', '-shm', '-journal')])
        self.ops.metrics.gauge('aap_node_applied_height', 'Highest committed height this node has applied.',
                               fn=lambda: self.applied)
        self.ops.metrics.gauge('aap_node_consensus_round', 'Consensus round at the current height.',
                               fn=lambda: self.engine.s.get('round'))
        self.ops.metrics.gauge('aap_node_outbound_queued_items', 'Peer messages waiting in outbound queues.',
                               fn=lambda: self.peer_io.status().get('queued_items') if hasattr(self, 'peer_io') else 0)
        self.node_errors = self.ops.metrics.counter('aap_node_errors_total', 'Pump errors by category.', ('category',))

    def _consensus_ready(self):
        if self.engine.failed:
            return 'CONSENSUS_STORAGE_FAILED'
        if self.engine.s.get('migration_halt') is not None:
            return 'MIGRATION_HALTED'
        if self.stopping.is_set():
            return 'CONSENSUS_STOPPED'
        return True

    def _dispatch(self, jobs, peers):
        """Validator votes stay all-to-all. View gossip uses the epoch overlay and AIMD."""
        from .scale.overlay import epoch_beacon, recipients, view_epoch
        epoch = view_epoch(self.applied)
        self.backpressure.begin_epoch(epoch)
        beacon = epoch_beacon(epoch)
        for path, value in jobs:
            for peer in recipients(self.member, peers, path, epoch, beacon=beacon):
                if path != '/message' and not self.backpressure.permit():
                    continue
                self.peer_io.enqueue(peer, path, value)

    def _tick(self):
        """One Engine.tick behind a monotonic floor. Called with ``self.lock`` held.

        Engine.tick refuses a time below its last tick (``clock_regression``),
        and the pump used to stop on that refusal. Here a host clock reading
        below the previous one, or one that is not finite, is refused for this
        tick, recorded as ``clock-regression`` and survived. The next reading
        re-anchors, so engine time only advances by the clock's forward steps
        and never takes a regressed reading: no vote, timeout or commit sees
        time run backwards. Safety never depends on this clock; liveness does.
        """
        raw = self.clock()
        if type(raw) not in (int, float) or not math.isfinite(raw):
            return self._clock_refused('clock_not_finite')
        last, self._tick_raw = self._tick_raw, raw
        if last is not None and raw < last:
            return self._clock_refused('clock_regression')
        self._tick_now = raw if last is None else self._tick_now + (raw - last)
        try:
            return self.engine.tick(max(self._tick_now, self.engine.now)) or []
        except ValueError as exc:
            if str(exc) != 'clock_regression':
                raise
            return self._clock_refused('clock_regression')

    def _clock_refused(self, code):
        self.clock_refusals += 1
        self.record_error('clock-regression', code)
        return []

    def next_config(self,block):
        if not profile_has(self.genesis['protocol'],COMMITTEE_HANDOFF):return None
        state=app.begin_block(self.state,block['height'])
        for tx in block['txs']:state=app.apply_transaction(state,tx,block['height'])
        active=state['domain']['active']
        return {'chain_id':self.chain_id,'validators':active['validators'],'faults':active['faults']}

    def observe_evidence(self, message):
        """Retain equivocation proof from authenticated consensus messages. Never raises."""
        validators = self.engine.config['validators']
        if type(message) is not dict:
            return []
        if message.get('kind') == 'commit':
            found = self.evidence.observe_commit(message, validators)
        else:
            found = [self.evidence.observe(message, validators)]
            body = message.get('body')
            qc = body.get('valid_qc') if message.get('kind') == 'proposal' and type(body) is dict else None
            for vote in qc[:64] if type(qc) is list else []:
                found.append(self.evidence.observe(vote, validators))
        found = [item for item in found if item is not None]
        for item in found:
            self.record_error('equivocation-evidence', item['signer'])
        return found

    def record_error(self, category, detail):
        # Keep a short code. Do not retain exception text that may carry a
        # payload, proof, or other party data.
        text = str(detail)
        if len(text) > 160 or any(mark in text for mark in '{[<'):
            text = type(detail).__name__
        self.errors.append({'category': category, 'detail': text[:160]})
        if hasattr(self, 'ops'):
            self.node_errors.inc(category=category)
            self.ops.log.event('node_error', 'warning', category=category, code=observability.refusal_code(text))

    def refresh(self):
        for entry in self.engine.committed(start=self.applied+1):
            block = entry['block']
            if block['height'] <= self.applied:
                continue
            if block['height'] != self.applied + 1:
                raise RuntimeError('non-contiguous committed history')
            state = app.begin_block(self.state,block['height'])
            for tx in block['txs']:
                if len(crypto.canonical(tx)) > self.max_tx_bytes:
                    raise RuntimeError('committed transaction exceeds transport profile')
                state = app.apply_transaction(state, tx, block['height'])
            if app.state_hash(state) != block['state_root']:
                raise RuntimeError('committed state root mismatch')
            self.state = state
            if hasattr(self,'light_transitions') and 'domain' in state:
                active=state['domain']['active']
                if active['activation']==block['height']+1:
                    from copy import deepcopy
                    self.light_transitions.append({'proof':prove_record(state,'domain','active'),'checkpoint':deepcopy(entry)})
            self.applied = block['height']
            for tx in block['txs']:
                tid = app.transaction_id(tx)
                self.pending.pop(tid, None)
                self.results[tid] = {'id': tid, 'status': 'committed', 'height': self.applied}
            self.trim_results()

    def trim_results(self):
        while len(self.results) > 10000:
            self.results.popitem(last=False)

    def build_block(self, height, parent):
        self.refresh()
        if height != self.applied + 1:
            raise ValueError('cannot propose without predecessor state')
        # Pace on the engine's own floored clock, the one its round timeouts use.
        now = self.engine.now
        if getattr(self, '_pace_height', None) != height:
            self._pace_height, self._pace_since = height, now
        if not empty_block_due(self.pending, self.empty_block_interval, self._pace_since, now):
            return None
        state = app.begin_block(self.state,height)
        selected = []
        selected_bytes=0
        for tid, tx in list(self.pending.items()):
            if len(selected) >= 32:
                break
            if tx['body']['op'] in {'DOMAIN_SUCCESSION','GOV_EXECUTE'} and selected:continue
            tx_bytes=len(crypto.canonical(tx))
            if profile_has(self.genesis['protocol'],FEDERATION_LIMITS) and selected_bytes+tx_bytes>self.max_block_tx_bytes:continue
            try:
                state = app.apply_transaction(state, tx, height)
                selected.append(tx)
                selected_bytes+=tx_bytes
                if tx['body']['op'] in {'DOMAIN_SUCCESSION','GOV_EXECUTE'}:break
            except BackendUnavailable:
                break
            except ValueError as exc:
                self.pending.pop(tid, None)
                self.results[tid] = {'id': tid, 'status': 'rejected', 'reason': str(exc)[:500]}
        self.trim_results()
        block = {'chain': self.chain_id, 'height': height, 'parent': parent,
                 'txs': selected, 'state_root': app.state_hash(state)}
        from .governance import feature_active, proposed_time
        if feature_active(state, 'proof_freshness'):
            stamp = proposed_time(self._parent_block(), int(time.time()))
            if stamp is None:
                return None
            block['time'] = stamp
        return block

    def _parent_block(self):
        rows = self.engine.committed()
        return rows[-1]['block'] if rows else None

    def admit_proposal(self, block, _qc):
        """Vote policy only. A future timestamp is not an invalid historical block."""
        from .governance import time_is_votable
        if not time_is_votable(block, int(time.time())):
            raise ValueError('BLOCK_TIME_AHEAD')

    def halt_for_migration(self, successor_genesis):
        """Local owner SDK only. Never exposed through the network/tool API.

        Quiesce first and independently review the complete successor intent.
        The signature commits to that intent; it is not an audit of its utility.
        """
        from .world_migration import halt_body
        from .world_migration_client import validate_intent
        with self.lock:
            self.refresh()
            crypto.need(self.genesis['protocol'] == app.ECOSYSTEM_VERSION, 'MIGRATION_SOURCE')
            migration = successor_genesis.get('migration') if type(successor_genesis) is dict else None
            crypto.need(type(migration) is dict and migration.get('source') == self.genesis, 'MIGRATION_SOURCE_PIN')
            body = halt_body(successor_genesis)
            prior = self.engine.s.get('migration_halt')
            crypto.need(prior is None or prior['body'] == body, 'MIGRATION_HALT_CONFLICT')
            validate_intent(successor_genesis)
            answer = self.engine.halt_for_migration(body)
            self.stopping.set()
            return answer

    def validate_block(self, block, height, parent):
        self.refresh()
        try:
            from .governance import accept_block_time, feature_active
            required = False
            if type(block) is dict and type(block.get('height')) is int:
                required = feature_active(app.begin_block(self.state, block['height']), 'proof_freshness')
            if not accept_block_time(block, self._parent_block(), required):
                return False
            expected = {'chain', 'height', 'parent', 'txs', 'state_root'}
            if required:
                expected = expected | {'time'}
            if set(block) != expected:
                return False
            if block['chain'] != self.chain_id or block['height'] != self.applied + 1 or block['height'] != height or block['parent'] != parent:
                return False
            if not isinstance(block['txs'], list) or len(block['txs']) > 32:
                return False
            if profile_has(self.genesis['protocol'],FEDERATION_LIMITS) and sum(len(crypto.canonical(tx)) for tx in block['txs'])>self.max_block_tx_bytes:return False
            state = app.begin_block(self.state,block['height'])
            ids = set()
            for tx in block['txs']:
                if len(crypto.canonical(tx)) > self.max_tx_bytes:
                    return False
                tid = app.transaction_id(tx)
                if tid in ids:
                    return False
                ids.add(tid)
                state = app.apply_transaction(state, tx, block['height'])
            return app.state_hash(state) == block['state_root']
        except BackendUnavailable:
            raise
        except (ValueError, KeyError, TypeError):
            return False

    def _private_state(self):
        """A copy for work done off the lock. Call with the lock held.

        A Table read caches the record in the table's dirty map, and a deep copy
        or seal iterates that map. Two unlocked readers of the live state race
        ("dictionary changed size during iteration") and the pump stopped. A deep
        copy shares each sealed table root, so it costs one small object per table.
        """
        return copy.deepcopy(self.state)

    def _warm_transaction(self, tx, height, state):
        """Run expensive checks without the consensus lock. Cryptographic rejection still raises."""
        app.apply_transaction(state, tx, height)

    def _blocks_of(self, message):
        if type(message) is not dict:return []
        if message.get('kind')=='proposal':
            block=message.get('body',{}).get('block') if type(message.get('body')) is dict else None
        elif message.get('kind')=='commit':
            block=message.get('block')
        else:
            block=None
        return [block] if type(block) is dict else []

    def submit(self, tx, identity='local'):
        # A stopped/failed pump can serve retained history, not accept new work.
        if self.stopping.is_set() or self.engine.failed or self.engine.s.get('migration_halt') is not None:raise ValueError('NODE_NOT_ACCEPTING_NEW_WORK')
        if type(tx) is not dict or 'body' not in tx:raise ValueError('TX_BODY')
        # Preflight authority/signature and current state before accepting work.
        if len(crypto.canonical(tx)) > self.max_tx_bytes:
            raise ValueError('transaction exceeds 16KiB transport profile')
        tid = app.transaction_id(tx)
        with self.lock:
            if self.stopping.is_set() or self.engine.failed or self.engine.s.get('migration_halt') is not None:raise ValueError('NODE_NOT_ACCEPTING_NEW_WORK')
            committed=self.engine.journal.transaction(tid)
            if committed:return committed
            if tid in self.results and self.results[tid]['status'] == 'committed':
                return self.results[tid]
            if tid in self.pending:
                return {'id': tid, 'status': 'pending'}
            if len(self.pending) >= MAX_PENDING:
                raise ValueError('mempool full')
            if _proof_op(tx) and not proof_admission(self.proof_buckets, identity or 'local', time.monotonic()):
                raise ValueError('PROOF_RATE_LIMIT')
            state_ref=self._private_state();height=self.applied+1
        # Proof verification happens here, off the single node lock.
        self._warm_transaction(tx, height, state_ref)
        with self.lock:
            # Proof warming releases the lock. An owner may have durably halted
            # the source in the meantime; do not enqueue the warmed work.
            if self.stopping.is_set() or self.engine.failed or self.engine.s.get('migration_halt') is not None:raise ValueError('NODE_NOT_ACCEPTING_NEW_WORK')
            if tid in self.pending:
                return {'id': tid, 'status': 'pending'}
            if len(self.pending) >= MAX_PENDING:
                raise ValueError('mempool full')
            app.apply_transaction(self.state, tx, self.applied + 1)
            self.pending[tid] = tx
            self.results.pop(tid, None)
            if tid not in self.seen:
                self.seen[tid] = True
                if len(self.gossip) < MAX_QUEUE:
                    self.gossip.append(('/submit', tx))
                while len(self.seen) > 10000:
                    self.seen.popitem(last=False)
            return {'id': tid, 'status': 'pending'}

    def preview_tx(self, tx, identity='local'):
        if len(crypto.canonical(tx))>self.max_tx_bytes:raise ValueError('transaction exceeds profile')
        with self.lock:
            if _proof_op(tx) and not proof_admission(self.proof_buckets, identity or 'local', time.monotonic()):
                raise ValueError('PROOF_RATE_LIMIT')
            state_ref=self._private_state();height=self.applied+1;before=app.state_hash(state_ref)
        projected=app.apply_transaction(state_ref, tx, height)
        return {'valid_at_height':height,'predecessor_root':before,
                'projected_root':app.state_hash(projected),'binding':False}

    def request(self, peer, path, payload=None):
        if peer == self.member or peer in self.blocked:
            return None
        data = None if payload is None else json.dumps(payload, separators=(',', ':')).encode()
        req = urllib.request.Request(self.peers[peer].rstrip('/') + path, data=data,
            headers={'Content-Type': 'application/json', 'X-Covenant-Peer': self.member})
        with self.transport_opener.open(req, timeout=0.3) as response:
            raw = response.read(4 * MAX_BODY + 1)
            if len(raw) > 4 * MAX_BODY:
                raise ValueError('oversized peer reply')
            return crypto.loads(raw.decode())

    def run(self):
        from .peer_io import PeerIO
        self.peer_io=PeerIO(self);self.peer_io.start()
        next_sync = 0.0
        sync_index = 0
        while not self.stopping.is_set():
            try:
                with self.lock:
                    batch=[]
                    for _ in range(min(32, len(self.inbox))):
                        message=self.inbox.popleft()
                        self.inbox_bytes=max(0, self.inbox_bytes-len(crypto.canonical(message)))
                        batch.append(message)
                    pending_txs=list(self.pending.values())[:32]
                    state_ref=self._private_state() if batch or pending_txs else None
                    next_height=self.applied+1
                deferred=[]
                for message in batch:
                    try:
                        for block in self._blocks_of(message):
                            txs=block.get('txs') if type(block.get('txs')) is list else []
                            height=block.get('height') if type(block.get('height')) is int else next_height
                            for tx in txs[:32]:
                                try:self._warm_transaction(tx, height, state_ref)
                                except (ValueError, KeyError, TypeError):
                                    break
                    except BackendUnavailable as exc:
                        deferred.append((message, exc))
                for tx in pending_txs:
                    try:self._warm_transaction(tx, next_height, state_ref)
                    except (ValueError, KeyError, TypeError, BackendUnavailable):
                        continue
                if deferred:
                    with self.lock:
                        self.record_error('verifier-unavailable', deferred[0][1])
                        for message,_exc in deferred:
                            # Back of the queue: one stuck proof must not sit at the head forever.
                            message_bytes=len(crypto.canonical(message))
                            if len(self.inbox)>=MAX_QUEUE or self.inbox_bytes+message_bytes>MAX_QUEUE_BYTES:continue
                            self.inbox.append(message);self.inbox_bytes+=message_bytes
                    if len(deferred)==len(batch):
                        self.stopping.wait(0.25)
                        continue
                ready=[message for message in batch if all(message is not item[0] for item in deferred)]
                with self.lock:
                    outgoing = []
                    for message in ready:
                        try:
                            outgoing.extend(self.engine.receive(message) or [])
                            self.refresh()
                        except BackendUnavailable as exc:
                            self.record_error('verifier-unavailable', exc)
                            message_bytes=len(crypto.canonical(message))
                            if len(self.inbox)<MAX_QUEUE and self.inbox_bytes+message_bytes<=MAX_QUEUE_BYTES:
                                self.inbox.append(message);self.inbox_bytes+=message_bytes
                            continue
                        except (ValueError, KeyError, TypeError) as exc:
                            self.record_error('rejected-peer-message', exc)
                    try:
                        outgoing.extend(self._tick())
                        self.refresh()
                    except BackendUnavailable as exc:
                        self.record_error('verifier-unavailable', exc)
                    # Our own signatures pass the same check: a local double-sign is evidence too.
                    for message in outgoing:
                        self.observe_evidence(message)
                    jobs = [('/message', message) for message in outgoing]
                    for _ in range(min(32, len(self.gossip))):
                        jobs.append(self.gossip.popleft())
                    peers = [p for p in self.peers if p != self.member and p not in self.blocked]
                # Per-peer bounded workers own network waits; the consensus
                # timer never waits behind an unreachable or slow sibling.
                # /message stays all-to-all. View paths use the overlay and AIMD.
                self._dispatch(jobs, peers)
                if peers and time.monotonic() >= next_sync:
                    peer=peers[sync_index % len(peers)];sync_index+=1
                    next_sync=time.monotonic()+.5
                    self.peer_io.catchup(peer,self.applied+1)
            except Exception as exc:
                with self.lock:
                    self.record_error('fatal-pump', exc)
                    self.stopping.set()
            self.stopping.wait(0.025)
        self.peer_io.close()

    def status(self):
        return {**self.engine.status(), 'member': self.member, 'chain': self.chain_id,
                'validator_active':self.engine.active, 'applied_height': self.applied, 'state_root': app.state_hash(self.state),
                'pending': len(self.pending), 'queued_messages': len(self.inbox),
                'consensus_running': not self.stopping.is_set() and not self.engine.failed and self.engine.s.get('migration_halt') is None,
                'migration_halted': self.engine.s.get('migration_halt') is not None,
                'blocked': sorted(self.blocked), 'errors': list(self.errors),
                'outbound_io': self.peer_io.status() if hasattr(self,'peer_io') else {'started':False},
                'equivocation_evidence': len(self.evidence.evidence)}


class BoundedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    request_queue_size = 32

    def __init__(self, *args, **kwargs):
        self.slots = threading.BoundedSemaphore(16)
        self.deadline_extenders = {}
        super().__init__(*args, **kwargs)

    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        # Inactivity timeouts alone permit indefinite header/body drip attacks.
        def expire():
            try: request.shutdown(socket.SHUT_RDWR)
            except OSError: pass
        # A drip must not refresh this clock. Proof work extends it only
        # after the body is already in memory.
        deadline = threading.Timer(3.0, expire)
        deadline.daemon = True
        deadline.start()
        def extend():
            nonlocal deadline
            deadline.cancel()
            deadline = threading.Timer(70.0, expire)
            deadline.daemon = True
            deadline.start()
        self.deadline_extenders[id(request)] = extend
        try:
            request.settimeout(3.0)
            super().process_request_thread(request, address)
        finally:
            self.deadline_extenders.pop(id(request), None)
            deadline.cancel()
            self.slots.release()


def _unavailable_proof(node):
    """A checked lookup with no checkpoint yet. This is not a proof and not authority."""
    return {'chain':node.chain_id,'proof':None,'checkpoint':None,'available':False,'execution_authorized':False}


def _proof_snapshot(node, path, value):
    """Capture one coherent checkpoint under node.lock; build proofs after release.

    Table.__deepcopy__ seals and shares persistent roots while giving the
    unlocked proof reader its own dirty maps. Never pass live state, the
    mutable transition index or a journal handle to the off-lock worker.
    """
    crypto.need(type(value) is dict, 'FIELDS')
    if path == '/proof':
        crypto.exact(value, 'table key')
        records = [value]
        if not profile_has(node.genesis['protocol'], STATE_PROOFS) or not node.applied:
            return {'result': _unavailable_proof(node)}
    else:
        if set(value) in ({'table', 'key'}, {'table', 'key', 'from_epoch'}):
            records = [{'table': value['table'], 'key': value['key']}]
        elif path == '/light-proofs' and set(value) in ({'records'}, {'records', 'from_epoch'}):
            records = value['records']
            crypto.need(type(records) is list and 1 <= len(records) <= 8, 'PROOF_BATCH_LIMIT')
        else:
            raise ValueError('FIELDS')
        if not node.applied:
            result = ({'chain': node.chain_id, 'proof': None, 'bundles': [], 'available': False,
                       'execution_authorized': False} if path == '/light-proofs' else _unavailable_proof(node))
            return {'result': result}
        for record in records:
            crypto.exact(record, 'table key')
    from_epoch = value.get('from_epoch', 0)
    transitions = []
    if path != '/proof':
        from .light import MAX_TRANSITIONS
        crypto.integer(from_epoch)
        transitions = [frame for frame in node.light_transitions
                       if frame['proof']['path'][-1]['value']['epoch'] > from_epoch]
        crypto.need(len(transitions) <= MAX_TRANSITIONS, 'LIGHT_TRANSITION_LIMIT')
    return {'path': path, 'records': copy.deepcopy(records), 'from_epoch': from_epoch,
            'chain': node.chain_id, 'height': node.applied,
            'genesis': copy.deepcopy(node.genesis), 'state': node._private_state(),
            'head': copy.deepcopy(node.engine.committed(start=node.applied, limit=1)[0]),
            'transitions': copy.deepcopy(transitions)}


def _proof_from_snapshot(snapshot):
    """Expensive Merkle construction/state hashing uses the retained snapshot only."""
    if 'result' in snapshot:
        return snapshot['result']
    records = snapshot['records']
    if snapshot['path'] == '/proof':
        return {'proof': prove_record(snapshot['state'], records[0]['table'], records[0]['key']),
                'checkpoint': snapshot['head']}
    if snapshot.get('timed'):
        from .timed_light import export_checkpoint_bundle
        bundles = [export_checkpoint_bundle(snapshot['genesis'], snapshot['state'], snapshot['head'],
                   snapshot['transitions'], record['table'], record['key'], snapshot['from_epoch'],
                   ancestors=snapshot['ancestors']) for record in records]
    else:
        from .light import export_checkpoint_bundle
        bundles = [export_checkpoint_bundle(snapshot['genesis'], snapshot['state'], snapshot['head'],
                                           snapshot['transitions'], record['table'], record['key'], snapshot['from_epoch'])
                   for record in records]
    if snapshot['path'] == '/light-proof':
        return bundles[0]
    result = {'chain': snapshot['chain'], 'height': snapshot['height'], 'bundles': bundles}
    crypto.need(len(crypto.canonical(result)) <= 2 * MAX_BODY, 'PROOF_BATCH_SIZE')
    return result


def _timed_proof_snapshot(node, path, value):
    """Separate opt-in reader; historical proof routes and signatures are unchanged."""
    crypto.need(type(value) is dict, 'FIELDS')
    request = dict(value); from_height = request.pop('from_height', None)
    if from_height is not None:
        crypto.integer(from_height)
        crypto.need(from_height <= node.applied and node.applied-from_height <= 65, 'TIMED_LIGHT_ANCESTRY_LIMIT')
    snapshot = _proof_snapshot(node, path.replace('/timed-light', '/light'), request)
    if 'result' in snapshot: return snapshot
    ancestors = []
    if from_height is not None:
        count = max(0,node.applied-from_height-1)
        ancestors = [copy.deepcopy(entry['block']) for entry in node.engine.committed(start=from_height+1,limit=count)] if count else []
        crypto.need(len(ancestors)==count and len(crypto.canonical(ancestors))<=MAX_BODY,'TIMED_LIGHT_ANCESTRY_LIMIT')
    snapshot.update(timed=True, ancestors=ancestors)
    return snapshot


# Chain listener names the module that owns the route. It does not perform that service.
_DEDICATED_HTTP = {
    '/': 'covenant_chain.node',
    '/mcp': 'covenant_chain.agent_connector',
    '/provider': 'covenant_chain.provider_connector',
    '/relay': 'covenant_chain.relay',
    '/replica/command': 'covenant_chain.provider_replica_rpc',
    '/replica/history': 'covenant_chain.provider_replica_rpc',
    '/replica/message': 'covenant_chain.provider_replica_rpc',
    '/rpc': 'covenant_chain.a2a_agreement_service',
}


def handler_for(node):
    # Instrumented answers /healthz and /readyz before the node lock, which the pump holds.
    class Handler(observability.Instrumented, BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def respond(self, value, code=200, headers=None):
            data = json.dumps(value, separators=(',', ':')).encode()
            try:
                self.send_response(code)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                for name, item in (headers or {}).items():
                    self.send_header(name, item)
                self.end_headers()
                self.wfile.write(data)
            except OSError:
                # Deadline/disconnected clients must not amplify traffic into logs.
                self.close_connection = True

        def do_GET(self):
            parsed = urllib.parse.urlsplit(self.path)
            with node.lock:
                peer = self.headers.get('X-Covenant-Peer')
                if peer in node.blocked:
                    return self.respond({'error': 'sandbox partition'}, 503)
                if parsed.path == '/status':
                    value = node.status()
                elif parsed.path == '/context':
                    value={'chain':node.chain_id,'protocol':node.genesis['protocol'],'applied_height':node.applied}
                elif parsed.path == '/.well-known/covenant.json':
                    from .onboarding import well_known_for_node
                    value=well_known_for_node(node)
                elif parsed.path == '/.well-known/openapi.json':
                    from .onboarding import openapi_document
                    value=openapi_document()
                elif parsed.path == '/record':
                    try:
                        query=urllib.parse.parse_qs(parsed.query,strict_parsing=True)
                        crypto.need(set(query)=={'table','key'} and all(len(v)==1 for v in query.values()),'RECORD_QUERY')
                        table,record_key=query['table'][0],query['key'][0]
                        crypto.need(type(table) is str and type(record_key) is str and len(table)<=80 and len(record_key)<=256,'RECORD_QUERY')
                        crypto.canonical([table,record_key])
                        records=node.state.get(table)
                        crypto.need(isinstance(records,(Table,dict)),'RECORD_TABLE')
                        found=record_key in records
                        item=(records.dirty.get(record_key,records.get_raw(record_key)) if isinstance(records,Table) else records[record_key]) if found else None
                        crypto.need(len(crypto.canonical(item))<=MAX_SCOPED_REPLY_BYTES,'RECORD_REPLY_LIMIT')
                        value={'chain':node.chain_id,'protocol':node.genesis['protocol'],'applied_height':node.applied,'table':table,'key':record_key,'found':found,'value':copy.deepcopy(item)}
                        crypto.need(len(crypto.canonical(value))<=MAX_SCOPED_REPLY_BYTES,'RECORD_REPLY_LIMIT')
                    except (ValueError,KeyError,TypeError) as exc:return self.respond({'error':str(exc)[:500]},400)
                elif parsed.path == '/offers':
                    try:value=offers_page(node,urllib.parse.parse_qs(parsed.query,strict_parsing=True,keep_blank_values=True))
                    except (ValueError,KeyError,TypeError) as exc:return self.respond({'error':str(exc)[:500]},400)
                elif parsed.path == '/state':
                    if not allow_state_export(node, self.client_address[0], self.headers.get('X-Covenant-Peer')):
                        return self.respond({'error':'STATE_EXPORT_RATE_LIMIT: use /context and /record'},429)
                    try:value=bounded_state(node.state)
                    except (ValueError,KeyError,TypeError) as exc:return self.respond({'error':str(exc)[:500]},413)
                    return self.respond(value, headers={'X-Covenant-Reliance': 'advisory-not-a-proof'})
                elif parsed.path == '/evidence':
                    value = {**node.evidence.export(), 'applied_height': node.applied}
                elif parsed.path == '/genesis':
                    value = node.genesis
                elif parsed.path == '/feedback/dashboard' and node.feedback is not None:
                    try:
                        from .feedback_intake import dashboard_from_desk
                        value = dashboard_from_desk(node.feedback)
                    except (ValueError, KeyError, TypeError) as exc:
                        return self.respond({'error': str(exc)}, 400)
                elif parsed.path == '/feedback' and node.feedback is not None:
                    try:
                        q=urllib.parse.parse_qs(parsed.query)
                        value=node.feedback.page(int(q.get('after',['0'])[0]),int(q.get('limit',['50'])[0]))
                    except (ValueError,KeyError,TypeError) as exc:return self.respond({'error':str(exc)},400)
                elif parsed.path == '/.well-known/agent-card.json':
                    from .onboarding import agent_card_for_node
                    value = agent_card_for_node(node)
                elif parsed.path.startswith('/causal/') and node.causal is None:
                    value = {'enabled': False, 'execution_authorized': False, 'path': parsed.path[len('/causal/'):]}
                elif parsed.path.startswith('/causal/') and node.causal is not None:
                    try:
                        value = node.causal.get(parsed.path[len('/causal/'):])
                    except ValueError as exc:
                        return self.respond({'error': str(exc)}, 404)
                elif parsed.path == '/economics':
                    try:
                        from .economics_api import render_html, view as economics_view
                        query = urllib.parse.parse_qs(parsed.query)
                        account = query.get('account', [None])[0]
                        if account is not None:
                            crypto.key(account)
                        snapshot = economics_view(node.state, node.applied, account)
                        if query.get('format', [''])[0] == 'html':
                            page = render_html(snapshot).encode()
                            self.send_response(200)
                            self.send_header('Content-Type', 'text/html; charset=utf-8')
                            self.send_header('Content-Length', str(len(page)))
                            self.end_headers()
                            self.wfile.write(page)
                            return
                        crypto.need(len(crypto.canonical(snapshot)) <= 256 * 1024, 'ECONOMICS_REPLY_LIMIT')
                        value = snapshot
                    except (ValueError, KeyError, TypeError) as exc:
                        return self.respond({'error': str(exc)[:500]}, 400)
                elif parsed.path == '/blocks':
                    try:
                        start = int(urllib.parse.parse_qs(parsed.query).get('from', ['1'])[0])
                        if start < 1:
                            raise ValueError()
                    except ValueError:
                        return self.respond({'error': 'invalid from height'}, 400)
                    value = []
                    response_bytes = 2
                    for entry in node.engine.committed(start=start,limit=16):
                        if entry['block']['height'] < start:
                            continue
                        entry_bytes = len(crypto.canonical(entry)) + 1
                        if len(value) >= 16 or response_bytes + entry_bytes > 3 * MAX_BODY:
                            break
                        value.append(entry)
                        response_bytes += entry_bytes
                elif parsed.path.startswith('/tx/'):
                    tid = parsed.path[4:]
                    value = node.engine.journal.transaction(tid) or node.results.get(tid, {'id': tid, 'status': 'pending' if tid in node.pending else 'unknown'})
                else:
                    return self.respond({'error': 'not found'}, 404)
            self.respond(value)

        def do_POST(self):
            try:
                lengths = self.headers.get_all('Content-Length', [])
                if self.headers.get_all('Transfer-Encoding', []) or len(lengths) != 1:
                    raise ValueError('INVALID_FRAMING')
                if not lengths[0] or any(c not in '0123456789' for c in lengths[0]):
                    raise ValueError('INVALID_CONTENT_LENGTH')
                length = int(lengths[0])
                if length <= 0 or length > MAX_BODY:
                    return self.respond({'error': 'invalid request size'}, 413)
                raw = self.rfile.read(length)
                if len(raw) != length: raise ValueError('TRUNCATED_BODY')
                value = crypto.loads(raw)
                if self.path.split('?', 1)[0] == '/surface':
                    from .surface import accept_http
                    try:
                        return self.respond(accept_http(value))
                    except ValueError as exc:
                        return self.respond({'error': str(exc)[:120]}, 400)
                if self.path in {'/submit','/preview'}:
                    extend = getattr(self.server, 'deadline_extenders', {}).get(id(self.request))
                    if extend is not None:
                        extend()
                    identity=self.headers.get('X-Covenant-Peer') or 'local'
                    try:
                        result=node.submit(value, identity) if self.path=='/submit' else node.preview_tx(value, identity)
                    except BackendUnavailable:
                        return self.respond({'error':'ZK_BACKEND_UNAVAILABLE'},503)
                    except (ValueError, KeyError, TypeError, UnicodeError) as exc:
                        code=429 if str(exc)=='PROOF_RATE_LIMIT' else 400
                        return self.respond({'error':str(exc)[:500]}, code)
                    return self.respond(result)
                if self.path in {'/proof', '/light-proof', '/light-proofs'}:
                    with node.lock:
                        if self.headers.get('X-Covenant-Peer') in node.blocked:
                            return self.respond({'error': 'sandbox partition'}, 503)
                        snapshot = _proof_snapshot(node, self.path, value)
                    return self.respond(_proof_from_snapshot(snapshot))
                if self.path in {'/timed-light-proof', '/timed-light-proofs'}:
                    with node.lock:
                        if self.headers.get('X-Covenant-Peer') in node.blocked:
                            return self.respond({'error':'sandbox partition'},503)
                        identity=self.client_address[0]
                        buckets=node.timed_proof_buckets
                        if identity not in buckets and len(buckets)>=1024:
                            return self.respond({'error':'TIMED_LIGHT_ADMISSION_LIMIT'},429)
                        if not proof_admission(buckets,identity,time.monotonic()):
                            return self.respond({'error':'PROOF_RATE_LIMIT'},429)
                        snapshot=_timed_proof_snapshot(node,self.path,value)
                    result=_proof_from_snapshot(snapshot)
                    crypto.need(len(crypto.canonical(result))<=2*MAX_BODY,'PROOF_BATCH_SIZE')
                    return self.respond(result)
                with node.lock:
                    peer = self.headers.get('X-Covenant-Peer')
                    if peer in node.blocked:
                        return self.respond({'error': 'sandbox partition'}, 503)
                    if self.path == '/feedback' and node.feedback is not None:
                        result=node.feedback.append(value)
                    elif self.path == '/causal' and node.causal is not None:
                        # Explicit bounded receipt replication, separate from finality gossip.
                        result = node.causal.merge(value)
                    elif self.path == '/record':
                        crypto.exact(value,'table key')
                        table,record_key=value['table'],value['key']
                        crypto.need(type(table) is str and type(record_key) is str and len(table)<=80 and len(record_key)<=256,'RECORD_QUERY')
                        records=node.state.get(table)
                        crypto.need(isinstance(records,(Table,dict)),'RECORD_TABLE')
                        found=record_key in records
                        item=(records.dirty.get(record_key,records.get_raw(record_key)) if isinstance(records,Table) else records[record_key]) if found else None
                        result={'chain':node.chain_id,'protocol':node.genesis['protocol'],'applied_height':node.applied,'table':table,'key':record_key,'found':found,'value':copy.deepcopy(item),'execution_authorized':False}
                    elif self.path == '/feedback' and node.feedback is None:
                        crypto.need(type(value) is dict,'FIELDS')
                        result={'enabled':False,'execution_authorized':False}
                    elif self.path == '/causal' and node.causal is None:
                        crypto.need(type(value) is dict,'FIELDS')
                        result={'enabled':False,'execution_authorized':False}
                    elif self.path == '/.well-known/agent-card.json':
                        crypto.need(type(value) is dict,'FIELDS')
                        from .onboarding import agent_card_for_node
                        result=agent_card_for_node(node)
                    elif self.path in _DEDICATED_HTTP:
                        crypto.need(type(value) is dict,'FIELDS')
                        result={'service':_DEDICATED_HTTP[self.path],'listener':'dedicated-service','chain':node.chain_id,'execution_authorized':False}
                    elif self.path == '/message':
                        if not isinstance(value, dict):
                            raise ValueError('MESSAGE_OBJECT')
                        # The peer header is a sandbox routing hint, never identity.
                        try:
                            node.engine.authenticate_ingress(value)
                        except ValueError as exc:
                            code=str(exc)
                            if code.replace('_','').isalpha() and code.islower():
                                raise ValueError(code.upper()) from exc
                            raise
                        node.observe_evidence(value)
                        message_bytes = len(crypto.canonical(value))
                        if len(node.inbox) >= MAX_QUEUE or node.inbox_bytes + message_bytes > MAX_QUEUE_BYTES:
                            return self.respond({'error': 'message queue full'}, 429)
                        node.inbox.append(value)
                        node.inbox_bytes += message_bytes
                        result = {'queued': True}
                    elif self.path == '/control':
                        if not node.sandbox_control:
                            return self.respond({'error': 'SANDBOX_CONTROL_DISABLED'}, 403)
                        # A list or other non-object body is a stable refusal, not a crash.
                        crypto.exact(value, 'blocked')
                        blocked = value['blocked']
                        crypto.need(type(blocked) is list and all(type(p) is str and p in node.peers for p in blocked), 'CONTROL_BLOCKED_PEERS')
                        node.blocked = set(blocked)
                        result = {'blocked': sorted(node.blocked)}
                    elif self.path in {'/', '/mcp', '/provider', '/relay', '/replica/command', '/replica/history', '/replica/message'}:
                        from .surface import http_body
                        result = http_body(self.path, value)
                    else:
                        return self.respond({'error': 'not found'}, 404)
                self.respond(result)
            except (ValueError, KeyError, TypeError, UnicodeError) as exc:
                self.respond({'error': str(exc)[:500]}, 400)
    Handler.ops = getattr(node, 'ops', None)
    return Handler


def arguments():
    """The validator's command line; covenant-doctor parses with this same parser."""
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ('genesis', 'peers', 'member', 'key', 'db'):
        parser.add_argument('--' + option, required=True)
    parser.add_argument('--peer-tls-config',help='adopted CA, distinct transport certificate/key and pinned HTTPS peers; listener remains local')
    parser.add_argument('--port', required=True, type=int)
    parser.add_argument('--base-timeout', type=float, default=CLI_EMPTY_BLOCK_WAIT + PACING_MARGIN,
                        help='round-0 timeout in seconds; keep it above the empty-block wait '
                             '(default: the 5 s wait plus 2)')
    parser.add_argument('--sandbox-control', action='store_true')
    parser.add_argument('--allow-single-operator-setup', action='store_true',
                        help='boot even if genesis private pools use a single-party Groth16 setup; not safe for value')
    parser.add_argument('--bootstrap',help='independently verified certified history JSON for a new validator')
    parser.add_argument('--causal-receipts',action='store_true',help='enable bounded nonbinding receipt DAG endpoints')
    parser.add_argument('--feedback-owner',help='file containing independently pinned founder signing public key/descriptor')
    parser.add_argument('--feedback-reporters',help='optional JSON signing-key allowlist; otherwise bounded pseudonymous inbox')
    observability.add_arguments(parser)
    return parser


def main():
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'balance':
        from .wallet import main as wallet_main
        raise SystemExit(wallet_main(sys.argv[1:]))
    args = arguments().parse_args()
    from .operator_surface import announce_console_path
    announce_console_path()
    require_patched_backend()
    # Stock validators wait before proposing an empty block so an 8-block proof
    # window is longer than a local proof. Tests construct Node directly and
    # stay on the historical eager proposer unless they set the variable.
    cli_empty_interval = None if 'COVENANT_EMPTY_BLOCK_INTERVAL' in os.environ else CLI_EMPTY_BLOCK_WAIT
    genesis = crypto.loads(Path(args.genesis).read_text())
    from .shielded import sandbox_pools, value_bearing_sandbox
    bearing = value_bearing_sandbox(genesis)
    if bearing:
        raise SystemExit('refusing value-bearing pools with a single-party setup (' + ', '.join(bearing) + '). '
                         'Genesis must carry a verified ceremony output before those resources have a balance.')
    sandbox = sandbox_pools(genesis)
    if sandbox and not args.allow_single_operator_setup:
        raise SystemExit('refusing single-party zero-knowledge pools ('+', '.join(sandbox)+'). '
                         'Use a verified multi-party ceremony (zk/ceremony/README.md) or pass '
                         '--allow-single-operator-setup for a local experiment that must not hold value.')
    peers = crypto.loads(Path(args.peers).read_text())
    key = crypto.load_private(read_signing_key(args.key))
    if args.peer_tls_config:
        from .transport import read_config,validate_https_peers
        peer_tls=read_config(args.peer_tls_config);validate_https_peers(peers)
    else:
        peer_tls=None;validate_peers(peers)
    check_storage_paths(args.db,causal=args.causal_receipts,feedback=args.feedback_owner is not None)
    refuse_pending_restore(args.db)
    owner_raw=Path(args.feedback_owner).read_text().strip() if args.feedback_owner else None
    owner=crypto.loads(owner_raw) if owner_raw and owner_raw.startswith('{') else owner_raw
    reporters=crypto.loads(Path(args.feedback_reporters).read_text()) if args.feedback_reporters else None
    previous_umask=os.umask(0o077)
    try:
        node = Node(genesis, peers, args.member, key, args.db, args.base_timeout, args.sandbox_control,crypto.loads(Path(args.bootstrap).read_text()) if args.bootstrap else None,causal_receipts=args.causal_receipts,feedback_owner=owner,feedback_reporters=reporters,peer_tls=peer_tls,empty_block_interval=cli_empty_interval)
    finally:
        os.umask(previous_umask)
    if node.pacing is not None:
        # Slow, not unsafe: warn with the teaching fields and keep running.
        print(json.dumps({'warning': node.pacing['code'], **node.pacing}, sort_keys=True), file=sys.stderr, flush=True)
        node.record_error('configuration', node.pacing['code'])
    server = BoundedHTTPServer(('127.0.0.1', args.port), handler_for(node))
    pump = threading.Thread(target=node.run, daemon=True)
    node.ops.health.add('pump', lambda: pump.is_alive() or 'PUMP_STOPPED')
    observability.start(node.ops, args)
    pump.start()
    def stop(signum, frame):
        node.stopping.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    print(json.dumps({'listening': args.port, 'member': args.member, 'chain': node.chain_id}), flush=True)
    try:
        server.serve_forever(poll_interval=0.1)
    finally:
        node.stopping.set()
        server.server_close()
        node.ops.close()
        pump.join(timeout=5)
        if not pump.is_alive():
            if node.causal is not None: node.causal.close()
            if node.feedback is not None: node.feedback.close()
            node.engine.journal.close()
            node.storage_lock.close()


if __name__ == '__main__':
    main()
