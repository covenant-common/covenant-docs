"""Bounded native shielded pool; classical Groth16.

Internal transfer amounts and owners are hidden behind commitments. Public
deposits, withdrawals, memos, the spending transaction's one-time key, and
timing stay observable. A single-operator setup must not protect value.
Not post-quantum and not audited.
"""
import json,os,re,secrets,subprocess
from functools import lru_cache
from pathlib import Path
from covenant_language.safe_io import run_subprocess
from .crypto import canonical,digest,exact,need,integer,key
P=21888242871839275222246405745257275088548364400416034343698204186575808495617
PROFILE='covenant-shielded-resource/0.1'
LEAF_CAP=1024
# One hash per retained anchor. Deposits must leave room for a later exit.
ARCHIVE_CAP=4096
EXIT_RESERVE=64

class BackendUnavailable(Exception):
    """The local prover or verifier did not finish. This is not an invalid proof."""

def field(value):
    need(type(value) is str and len(value)<=77 and re.fullmatch(r'0|[1-9][0-9]*',value) is not None and int(value)<P,'SHIELDED_FIELD');return value

def scalar(label,obj):return str(int(digest(label,obj),16)%P)
def secret():return str(secrets.randbits(248))

def _missing_package(stderr):
    err = stderr.decode('utf-8', 'replace')
    return 'circomlibjs' in err or 'Cannot find package' in err or 'ERR_MODULE_NOT_FOUND' in err

def _zk_rejected(stderr, code):
    err = stderr.decode('utf-8', 'replace').strip().replace('\n', ' ')[:400]
    hint = ' Missing package circomlibjs.' if _missing_package(stderr) else ''
    return code + '.' + hint + ' Run testnet/fetch_vendored.sh to restore zk/node_modules.' + (' ' + err if err else '')

REQUIRED_PACKAGES = ('circomlibjs', 'snarkjs')

def _packages_present(script):
    """The npm packages the bridges import, looked up where Node resolves them."""
    root = Path(script).resolve().parent.parent
    return all((root / 'node_modules' / name / 'package.json').is_file() for name in REQUIRED_PACKAGES)

def run_bridge(script, raw, timeout, unavailable, rejected, limit):
    """One consensus bridge call under the pinned runtime (see zk_runtime).

    A missing runtime or package, or a verifier that does not return, is a
    local fault: BackendUnavailable, so the node defers instead of rejecting.
    """
    from . import zk_runtime
    try:
        argv, env = zk_runtime.command(script)
        if not Path(script).is_file():
            raise OSError('ZK_BRIDGE_MISSING')
        # Output past the limit stops the child; the size check below refuses it.
        r = run_subprocess(argv, input=raw, timeout=timeout, env=env, max_output=limit, max_error=1024*1024)
    except (OSError, subprocess.TimeoutExpired) as e:
        raise BackendUnavailable(unavailable) from e
    if r.returncode != 0 and not _packages_present(script):
        # Decided from the filesystem, never from stderr: bridge errors can echo
        # transaction input, and a crafted message must not turn a rejection
        # into a deferral that stalls block building.
        raise BackendUnavailable(_zk_rejected(r.stderr, unavailable))
    if r.returncode != 0 or len(r.stdout) > limit:
        raise ValueError(_zk_rejected(r.stderr, rejected))
    from .crypto import loads
    return loads(r.stdout)

def backend_root():
    root=Path(os.environ.get('COVENANT_ZK_ROOT',Path(__file__).resolve().parents[1]/'zk')).resolve()
    if not (root/'shielded/bridge.mjs').is_file():
        raise BackendUnavailable('SHIELDED_BACKEND_UNAVAILABLE')
    return root

def bridge(op,**values):
    body=canonical({'op':op,**values})
    # Validity is the verifier's output, not a local clock. The deadline only
    # stops a verifier that does not return; it is reported as unavailable.
    return run_bridge(backend_root()/'shielded/bridge.mjs',body,120,'SHIELDED_BACKEND_UNAVAILABLE',
                      'SHIELDED_BACKEND_REJECTED',100000)

def descriptor():return bridge('descriptor')
def owner_id(spend_secret):return bridge('hash',values=[field(spend_secret)])
def tree(notes,index=None):
    values={'notes':notes}
    if index is not None:values['index']=index
    return _tree(canonical(values))
@lru_cache(maxsize=128)
def _tree(raw):return bridge('tree',**json.loads(raw))
def _verify(raw):
    from .verifier import mode
    return _verify_cached(raw, mode())

@lru_cache(maxsize=256)
def _verify_cached(raw, verifier_mode):
    from .verifier import check
    return check(verifier_mode, 'shielded', json.loads(raw))

def validate_descriptor(d):
    need(type(d) is dict and d.get('setup') in {'SINGLE_OPERATOR_SANDBOX','VERIFIED_MULTIPARTY'},'SHIELDED_PROFILE')
    fields='version depth vk_sha256 circuit_sha256 setup quantum_resistant'
    if d['setup']=='VERIFIED_MULTIPARTY':fields+=' ceremony'
    exact(d,fields)
    need(d['version']==PROFILE and type(d['depth']) is int and d['depth']==10 and d['quantum_resistant'] is False,'SHIELDED_PROFILE')
    key(d['vk_sha256']);key(d['circuit_sha256'])
    if d['setup']=='VERIFIED_MULTIPARTY':
        from .zk_ceremony import verify_ceremony
        verify_ceremony(d['ceremony'],profile=PROFILE,circuit_sha256=d['circuit_sha256'],vk_sha256=d['vk_sha256'])

def sandbox_pools(genesis):
    """Pool ids whose verification key came from a single-party setup."""
    found=[]
    if type(genesis) is not dict:return found
    for section in ('shielded','confidential'):
        block=genesis.get(section)
        if type(block) is not dict:continue
        for rid,desc in block.items():
            if type(desc) is dict and desc.get('setup')=='SINGLE_OPERATOR_SANDBOX':found.append(section+'.'+str(rid))
    return found

def value_bearing_sandbox(genesis):
    """Resources that both use a single-party setup and already have a balance."""
    if type(genesis) is not dict:return []
    pools=set()
    for section in ('shielded','confidential'):
        block=genesis.get(section)
        if type(block) is not dict:continue
        for rid,desc in block.items():
            if type(desc) is dict and desc.get('setup')=='SINGLE_OPERATOR_SANDBOX':pools.add(rid)
    found=set();accounts=genesis.get('accounts')
    if not pools or type(accounts) is not dict:return []
    for balances in accounts.values():
        if type(balances) is not dict:continue
        for rid,qty in balances.items():
            if rid in pools and type(qty) is int and qty>0:found.add(rid)
    return sorted(found)

def room_for(meta,extra,*,reserved=0,kind='transfer',archive_cap=ARCHIVE_CAP):
    """True when `extra` notes fit, possibly by sealing the current tree."""
    notes=meta['notes']
    if len(notes)+reserved+extra<=LEAF_CAP:return True
    if reserved or not notes or extra>LEAF_CAP:return False
    archived=len(meta.get('sealed_roots',[]))+len(meta['roots'])
    limit=archive_cap-EXIT_RESERVE if kind=='deposit' else archive_cap
    return archived<=limit

def commit_outputs(meta,outputs,*,reserved=0,kind='transfer',rollover=True,archive_cap=ARCHIVE_CAP):
    """Append outputs. A full tree is sealed and a new one is opened.

    Sealing is skipped entirely while the current tree still has room, so a
    chain that has never filled a pool keeps the previous state encoding.
    Deposit-style growth cannot consume the last archived anchors; a transfer,
    withdrawal or claim still can, so filling a tree does not trap funds.
    `rollover` is false until pool-epoch activation, which restores the old
    hard cap of one tree.
    """
    notes=list(meta['notes']);extra=list(outputs)
    if not rollover:
        need(len(notes)+reserved+len(extra)<=LEAF_CAP,'SHIELDED_POOL_FULL')
    else:
        need(room_for(meta,len(extra),reserved=reserved,kind=kind,archive_cap=archive_cap),'SHIELDED_POOL_FULL')
        if len(notes)+reserved+len(extra)>LEAF_CAP:
            meta['sealed_roots']=list(meta.get('sealed_roots',[]))+list(meta['roots'])
            notes=[];meta['roots']=[]
    notes=notes+extra
    root=tree(notes)['root']
    meta['notes']=notes;meta['root']=root;meta['roots']=(list(meta.get('roots',[]))+[root])[-64:]
    return root

def root_accepted(meta,root):
    return root in meta['roots'] or root in meta.get('sealed_roots',[])

def seal_epoch(meta,*,kind='deposit',archive_cap=ARCHIVE_CAP):
    """Archive the current anchors and start an empty tree. Needs the backend."""
    need(meta['notes'] and room_for(meta,LEAF_CAP,kind=kind,archive_cap=archive_cap),'SHIELDED_POOL_FULL')
    meta['sealed_roots']=list(meta.get('sealed_roots',[]))+list(meta['roots'])
    empty=tree([])['root']
    meta['notes']=[];meta['root']=empty;meta['roots']=[empty]

def action_id(chain,actor,nonce,op,p):
    return scalar('COVENANT-SHIELDED-ACTION-0.1',{'chain':chain,'actor':actor,'nonce':nonce,'op':op,'pool':p['pool'],'quantity':p['quantity'],'destination':p['destination'],'memo':p['memo']})

def apply(s,old,op,p,actor,nonce,tid,height=None):
    if not op.startswith('SHIELD_'):return None
    need(op in {'SHIELD_DEPOSIT','SHIELD_TRANSFER','SHIELD_WITHDRAW'},'SHIELDED_OPERATION')
    exact(p,'pool root nullifier outputs quantity destination memo proof');key(p['memo']);integer(p['quantity'])
    need(p['pool'] in s['shielded_config'],'SHIELDED_POOL');pool=p['pool'];d=s['shielded_config'][pool];validate_descriptor(d)
    meta=s['shielded_pools'][pool];notes=meta['notes'];reserved=s.get('confidential_reserved',{}).get(pool,0)
    kind='deposit' if op=='SHIELD_DEPOSIT' else 'transfer'
    from .governance import archive_limit, pool_rollover
    cap=archive_limit(s);roll=pool_rollover(s,kind,height)
    if roll:need(room_for(meta,2,reserved=reserved,kind=kind,archive_cap=cap),'SHIELDED_POOL_FULL')
    else:need(len(notes)+reserved+2<=LEAF_CAP,'SHIELDED_POOL_FULL')
    field(p['root']);field(p['nullifier']);need(type(p['outputs']) is list and len(p['outputs'])==2,'SHIELDED_OUTPUTS')
    for v in p['outputs']:field(v);need(v!='0' and v not in notes,'SHIELDED_OUTPUT_EXISTS')
    need(p['outputs'][0]!=p['outputs'][1],'SHIELDED_DUPLICATE_OUTPUT')
    deposit=op=='SHIELD_DEPOSIT';withdraw=op=='SHIELD_WITHDRAW'
    need(0<=p['quantity']<2**32 and ((deposit or withdraw)==(p['quantity']>0)),'SHIELDED_QUANTITY')
    if withdraw:key(p['destination'])
    else:need(p['destination'] is None,'SHIELDED_DESTINATION')
    if deposit:
        need(p['root']=='0' and p['nullifier']=='0','SHIELDED_DEPOSIT_CONTEXT')
        from .balances import amount
        need(amount(s['balances'],actor,pool)>=p['quantity'] and amount(s['authority_available'],actor,pool)>=p['quantity'],'SHIELDED_BACKING')
    else:
        need(nonce==0 and actor not in old['nonces'],'SHIELDED_ONE_TIME_ACTOR')
        need(root_accepted(meta,p['root']),'SHIELDED_ROOT')
        need(p['nullifier']!='0' and p['nullifier'] not in s['shielded_nullifiers'],'SHIELDED_DOUBLE_SPEND')
    signals=[p['root'],p['nullifier'],*p['outputs'],scalar('COVENANT-SHIELDED-DOMAIN',s['chain']),scalar('COVENANT-SHIELDED-ASSET',pool),action_id(s['chain'],actor,nonce,op,p),str(int(deposit)),str(int(withdraw)),str(p['quantity'])]
    need(type(p['proof']) is dict and len(canonical(p['proof']))<=8000,'SHIELDED_PROOF_SIZE')
    _verify(canonical({'vkHash':d['vk_sha256'],'publicSignals':signals,'proof':p['proof']}))
    from .balances import add
    if deposit:
        add(s['balances'],actor,pool,-p['quantity']);add(s['authority_available'],actor,pool,-p['quantity']);s['shielded_escrow'][pool]+=p['quantity']
    elif withdraw:
        need(s['shielded_escrow'][pool]>=p['quantity'],'SHIELDED_ESCROW')
        s['shielded_escrow'][pool]-=p['quantity'];add(s['balances'],p['destination'],pool,p['quantity']);add(s['authority_available'],p['destination'],pool,p['quantity'])
    if not deposit:s['shielded_nullifiers'][p['nullifier']]={'pool':pool,'event':tid}
    commit_outputs(meta,p['outputs'],reserved=reserved,kind=kind,rollover=roll,archive_cap=cap)
    return []

def make_transition(chain,pool,op,actor,nonce,outputs,notes=None,input_note=None,spend_secret=None,quantity=0,destination=None,memo='0'*64):
    """Private wallet helper. Return public payload and private output openings.

outputs: two {owner: hidden owner hash, quantity: integer}; do not publish returned
openings. Deposit/withdraw quantities and destination are deliberately public.
"""
    need(type(outputs) is list and len(outputs)==2,'SHIELDED_OUTPUTS')
    notes=notes or [];deposit=op=='SHIELD_DEPOSIT';withdraw=op=='SHIELD_WITHDRAW'
    need(op in {'SHIELD_DEPOSIT','SHIELD_TRANSFER','SHIELD_WITHDRAW'},'SHIELDED_OPERATION')
    domain=scalar('COVENANT-SHIELDED-DOMAIN',chain);asset=scalar('COVENANT-SHIELDED-ASSET',pool)
    p={'pool':pool,'root':'0','nullifier':'0','outputs':[],'quantity':quantity,'destination':destination,'memo':memo}
    act=action_id(chain,actor,nonce,op,p)
    if deposit:
        sec=secret();iq=quantity;ib=secret();birth='0';siblings=['0']*10;directions=['0']*10
    else:
        need(input_note is not None and spend_secret is not None,'SHIELDED_WITNESS')
        sec=spend_secret;iq=input_note['quantity'];ib=input_note['blind'];birth=input_note['birth']
        owner=owner_id(sec);need(owner==input_note['owner'],'SHIELDED_WALLET_OWNER')
        commitment=bridge('hash',values=[owner,str(iq),ib,domain,asset,birth]);need(commitment==input_note['commitment'],'SHIELDED_WALLET_NOTE')
        need(commitment in notes,'SHIELDED_WALLET_MEMBERSHIP');path=tree(notes,notes.index(commitment));p['root']=path['root'];siblings=path['siblings'];directions=path['directions']
        p['nullifier']=bridge('hash',values=[sec,commitment,domain])
    opening=[]
    for out in outputs:
        field(out['owner']);integer(out['quantity']);blind=secret();commitment=bridge('hash',values=[out['owner'],str(out['quantity']),blind,domain,asset,act])
        opening.append({'owner':out['owner'],'quantity':out['quantity'],'blind':blind,'birth':act,'commitment':commitment});p['outputs'].append(commitment)
    witness={'root':p['root'],'nullifier':p['nullifier'],'output0':p['outputs'][0],'output1':p['outputs'][1],'domain':domain,'asset':asset,'action':act,'deposit':str(int(deposit)),'withdraw':str(int(withdraw)),'quantity':str(quantity),'secret':sec,'inputQuantity':str(iq),'inputBlind':ib,'inputBirth':birth,'siblings':siblings,'directions':directions,'owners':[n['owner'] for n in opening],'quantities':[str(n['quantity']) for n in opening],'blinds':[n['blind'] for n in opening]}
    proof=bridge('prove',witness=witness);p['proof']=proof['proof'];return p,opening
