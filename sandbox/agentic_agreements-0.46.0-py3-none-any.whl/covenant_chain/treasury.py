"""Income accounting for the one reserve pot.

On a market chain that pot is market_reserve. On covenant-native/0.15 it is the
RESERVE beneficiary inside the fee's 10,000 bps. This module does not move units
and does not spend the world treasury or a sponsor escrow. Principal, the genesis
foundation allocation, is never sold. A backstop height is required on every spend
the reserve itself performs through the existing market or economics path.
"""
from .crypto import integer, need

INCOME = ('fees', 'slashing', 'ad_protocol', 'forfeiture', 'buyback_residue')


def principal_floor(supply):
    return supply['total'] * supply['foundation_bps'] // 10000


def credit_income(meter, source, amount):
    need(source in INCOME, 'WAQF_INCOME')
    integer(amount, True)
    income = dict(meter.get('treasury_income') or {})
    income[source] = income.get(source, 0) + amount
    meter['treasury_income'] = income
    meter['treasury_income_total'] = meter.get('treasury_income_total', 0) + amount
    return income[source]


def spend(meter, amount, backstop_height, height):
    """Income only. Principal is not a balance this function can see."""
    integer(amount, True)
    integer(backstop_height, True)
    integer(height)
    need(backstop_height > height, 'ESCROW_BACKSTOP')
    available = meter.get('treasury_income_total', 0) - meter.get('treasury_income_spent', 0)
    need(amount <= available, 'WAQF_INCOME')
    meter['treasury_income_spent'] = meter.get('treasury_income_spent', 0) + amount
    meter['treasury_principal_spent'] = 0
    return {'spent': amount, 'backstop': backstop_height, 'principal_touched': 0}


def buyback_room(income_balance, spent_this_window, max_per_window, runway_left, min_runway):
    """Posted limit. Not an oracle and not an AMM. Principal is not in `income_balance`."""
    integer(income_balance)
    integer(spent_this_window)
    integer(max_per_window)
    integer(runway_left)
    integer(min_runway)
    if runway_left < min_runway or income_balance <= 0 or max_per_window <= 0:
        return 0
    remaining = max_per_window - min(spent_this_window, max_per_window)
    return min(income_balance, remaining)


def forfeiture(meter, amount):
    """Unvested founder tokens past the 8-year deadline join the waqf income, not the principal."""
    return credit_income(meter, 'forfeiture', amount)
