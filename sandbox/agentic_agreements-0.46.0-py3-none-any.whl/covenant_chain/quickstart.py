"""First useful AAP draft: no keys, network, custody or payment."""
import argparse
from copy import deepcopy
import json

from .tool_surface import keyless_surface

REQUEST = {
    'tool': 'covenant_marketplace',
    'arguments': {'action': 'quick_trade', 'parameters': {
        # Synthetic public identifiers only; no signing key is present here.
        'seller': '66be7e332c7a453332bd9d0a7f7db055f5c5ef1a06ada66d98b39fb6810c473a',
        'buyer': '0b513ad9b4924015ca0902ed079044d3ac5dbec2306f06948c10da8eb6e39f2d',
        'description': 'One stock report for a small shop', 'amount': 90,
        'payment_asset': {'namespace': 'demo', 'identifier': 'CREDIT', 'unit': 'credit'},
        'context': 'a'*64, 'compact': True,
    }},
}


def request():
    return deepcopy(REQUEST)


def run(*, full=False):
    result = keyless_surface().call('covenant_marketplace__quick_trade',
                                    request()['arguments']['parameters'])
    summary = {
        'human_need': 'I run a small shop and want to agree an exact price for one stock report.',
        'status': 'DRAFT_REQUIRES_ASSENT', 'order_id': result['id'],
        'description': result['order']['title'],
        'price': {'amount': result['cashflows']['buyer_gives'][0]['amount'], 'unit': 'demo credit'},
        'acceptance': result['acceptance'], 'custody': result['custody'],
        'remaining': ['review exact terms', 'explicit buyer and seller signatures',
                      'report delivery and customer acceptance', 'separately authorised payment'],
        'automatic_assent': result['automatic_assent'],
        'execution_authorized': result['execution_authorized'], 'payment_verified': False,
        'next': 'Run with --full to inspect the complete exact order and review. '
                'Use --request to obtain the native agent-server request.',
    }
    if full:
        summary['exact_result'] = result
    return summary


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    modes = p.add_mutually_exclusive_group()
    modes.add_argument('--full', action='store_true', help='Include exact order and review, without signing.')
    modes.add_argument('--request', action='store_true', help='Emit the request accepted by agent_server --keyless --once.')
    args = p.parse_args(argv)
    print(json.dumps(request() if args.request else run(full=args.full), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
