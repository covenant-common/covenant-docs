"""Agreed identity evidence, optional holder binding and pure adopted checks.

A successful check means the exact adopted evidence rule accepted. It does not
turn a declaration, provider account or email login into legal identity, truth,
settlement authority or an automatic public record. Owners install callbacks;
LOCAL callbacks must perform no external I/O. External collection uses approved
connectors. Custody/state freshness remain trusted-owner responsibilities.
"""
from copy import deepcopy
import hashlib,os
from pathlib import Path
from .crypto import verification_key,verify
from .workflow_store import identifier as custody_id
from .workflow_store import canonical as custody_wire
from covenant_language import mechanism_plans as p

CHALLENGE='covenant-identity-challenge/0.1'
ATTESTATION='covenant-identity-attestation/0.1'
HOLDER_LABEL='COVENANT-IDENTITY-HOLDER-0.1'
ATTESTATION_LABEL='COVENANT-IDENTITY-ATTESTATION-0.1'
IMPLEMENTATION=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def need(ok,code):
    if not ok:raise ValueError(code)
def exact(value,names):need(type(value) is dict and set(value)==set(names.split()),'IDENTITY_FIELDS')
def integer(value):need(type(value) is int and 0<=value<=2**53-1,'IDENTITY_INTEGER')
def target(value):exact(value,'kind id');p.text(value['kind'],80);p.ref(value['id'])
def same(a,b):return p.canonical(a)==p.canonical(b)
def requirements(value,maximum=32):
    need(type(value) is dict and len(value)<=maximum,'IDENTITY_REQUIREMENTS')
    for name in value:p.text(name,128)
    p.canonical(value)
def subject(value,holder_binding):
    p.canonical(value);need(value is not None and value!={} and value!=[] and value!='','IDENTITY_SUBJECT')
    need(holder_binding in ('SUBJECT_SIGNATURE','AGREED_EVIDENCE'),'IDENTITY_HOLDER_BINDING')
    if holder_binding=='SUBJECT_SIGNATURE':verification_key(value)
def validate_challenge(value):
    p.canonical(value);exact(value,'version desk provider context call_context target operation subject audience claim_kind requirements request_hash holder_binding not_before expires nonce frame')
    need(value['version']==CHALLENGE,'IDENTITY_CHALLENGE_VERSION')
    for name in ('desk','provider','context','call_context','request_hash','nonce'):p.ref(value[name])
    target(value['target']);p.text(value['operation'],128);subject(value['subject'],value['holder_binding']);p.text(value['audience'],256);p.text(value['claim_kind'],128);requirements(value['requirements']);integer(value['not_before']);integer(value['expires']);need(value['not_before']<value['expires'],'IDENTITY_INTERVAL');p.frame(value['frame']);return True
def challenge_id(value):validate_challenge(value);return p._id('COVENANT-IDENTITY-CHALLENGE-0.1',value)
def holder_payload(challenge):
    return {'id':challenge_id(challenge),'label':HOLDER_LABEL,'body':{'challenge':challenge_id(challenge),'desk':challenge['desk'],'provider':challenge['provider']},'holder_binding':challenge['holder_binding'],'execution_authorized':False}
def validate_attestation(value):
    p.canonical(value);exact(value,'version challenge provider issuer assertions not_before expires');need(value['version']==ATTESTATION,'IDENTITY_ATTESTATION_VERSION');p.ref(value['challenge']);p.ref(value['provider']);verification_key(value['issuer']);requirements(value['assertions']);integer(value['not_before']);integer(value['expires']);need(value['not_before']<value['expires'],'IDENTITY_INTERVAL');return True
def attestation_id(value):validate_attestation(value);return p._id('COVENANT-IDENTITY-ATTESTATION-0.1',value)
def attest_payload(challenge,issuer,assertions,not_before,expires):
    validate_challenge(challenge);record=dict(version=ATTESTATION,challenge=challenge_id(challenge),provider=challenge['provider'],issuer=deepcopy(issuer),assertions=deepcopy(assertions),not_before=not_before,expires=expires)
    return {'id':attestation_id(record),'attestation':record,'label':ATTESTATION_LABEL,'body':{'attestation':attestation_id(record),'challenge':record['challenge'],'provider':record['provider']},'execution_authorized':False}
def provider(name,family,issuer,implementation,semantics,claim_kinds,config=None,assumptions=None):
    p.text(issuer,512);need(type(claim_kinds) is list and 1<=len(claim_kinds)<=32 and len(set(claim_kinds))==len(claim_kinds),'IDENTITY_CLAIM_KINDS')
    for kind in claim_kinds:p.text(kind,128)
    need(config is None or type(config) is dict,'IDENTITY_CONFIGURATION')
    return p.manifest(name,family,semantics,implementation,{'verify':{'mode':'LOCAL','description':'Accept only the exact agreed identity-evidence rule and current challenge.'}},assurances={'issuer':issuer,'claim_kinds':deepcopy(claim_kinds),'config':{} if config is None else deepcopy(config)},assumptions=assumptions or ['Owner-installed interpretation; exact acceptance is not universal identity, truth or authority.'])
def blueprints():
    return {'evidence_modes':[{'mode':m,'installation':'EXACT_OWNER_ADOPTED_RULE_AND_CALLBACK','inferred_identity':scope} for m,scope in [
        ('DECLARATION','Accepted declaration only'),('SIGNED_ATTESTATION','Exact adopted issuer assertion'),('OIDC','Issuer-scoped account subject'),('OFFICIAL_APP_OR_DIGITAL_ID','Only the attributes the adopted verifier establishes'),('PAYMENT_APP','Provider account/control or other explicitly verified claim'),('EMAIL_CHALLENGE_OR_LOGIN','Only mailbox/account control under adopted freshness'),('DOCUMENT_WITNESS_VOTE_PROMISE','Only the agreed acceptance rule'),('CUSTOM_OR_FUTURE','Meaning belongs to the exact adopted specification')]],'holder_binding':['SUBJECT_SIGNATURE','AGREED_EVIDENCE'],'collection':'APP_AUTHORIZATION_AND_EXTERNAL_CALLS_USE_ADOPTED_EFFECT_CONNECTORS','recording':['NO_RECORD','LOCAL_PRIVATE_RECORD','EXPLICIT_SELECTED_PUBLIC_RECORD','EXPLICIT_CIPHERTEXT_RECORD'],'automatic_publication':False,'execution_authorized':False}

class IdentityDesk:
    def __init__(self,context,target,operation,*,clock,instance=None,state_max_age=300):
        p.ref(context);globals()['target'](target);p.text(operation,128);need(callable(clock),'IDENTITY_CLOCK');integer(state_max_age);need(1<=state_max_age<=3600,'IDENTITY_STATE_AGE')
        instance=os.urandom(32).hex() if instance is None else instance;p.ref(instance)
        self.policy=dict(context=context,target=deepcopy(target),operation=operation,instance=instance,state_max_age=state_max_age)
        self.ref=p._id('COVENANT-IDENTITY-DESK-0.1',self.policy);self._policy_pin=p.canonical(self.policy);self.clock=clock;self.entries={};self._callbacks={};self._handlers={};self._installed={};self._challenges={};self._disabled=set();self._revoked=set();self._sequence=-1;self._as_of=0;self._valid_until=0;self.refresh_state()
    def _policy(self):need(p.canonical(self.policy)==self._policy_pin,'IDENTITY_POLICY_CHANGED')
    def _now(self):value=self.clock();integer(value);return value
    def _fresh(self):
        self._policy();now=self._now();need(self._as_of<=now<self._valid_until,'IDENTITY_STATE_STALE');return now
    def refresh_state(self,*,disabled=(),revoked=(),valid_until=None):
        self._policy();now=self._now();until=now+self.policy['state_max_age'] if valid_until is None else valid_until;integer(until);need(now<until<=now+self.policy['state_max_age'],'IDENTITY_STATE_INTERVAL')
        for ref in [*disabled,*revoked]:p.ref(ref)
        need(len(self._disabled|set(disabled))<=256 and len(self._revoked|set(revoked))<=4096,'IDENTITY_REVOCATION_LIMIT')
        self._disabled|=set(disabled);self._revoked|=set(revoked);self._sequence+=1;self._as_of=now;self._valid_until=until
    def disable_provider(self,ref):p.ref(ref);self.refresh_state(disabled=[ref])
    def revoke_evidence(self,proof):self.refresh_state(revoked=[custody_id('COVENANT-IDENTITY-EVIDENCE-0.1',proof)])
    def public_state(self):return {'desk':self.ref,'sequence':self._sequence,'as_of':self._as_of,'valid_until':self._valid_until,'disabled':sorted(self._disabled),'revoked_evidence_count':len(self._revoked),'challenge_count':len(self._challenges),'state_source':'TRUSTED_OWNER_CLOCK_CURRENT_PROVIDER_AND_REVOCATION_STATE','verification_writes_state':False,'custody_restore':'RETAINED_INSTANCE_REQUIRES_CURRENT_REVOCATIONS_AND_OWNER_PROVIDER_CUSTODY','execution_authorized':False}
    def register(self,manifest,callback):
        self._policy();p.validate_manifest(manifest);ref=p.mechanism_id(manifest);need(ref not in self.entries and len(self.entries)<256 and callable(callback),'IDENTITY_PROVIDER_INSTALLATION');exact(manifest['assurances'],'issuer claim_kinds config');a=manifest['assurances'];p.text(a['issuer'],512);need(type(a['claim_kinds']) is list and 1<=len(a['claim_kinds'])<=32 and len(set(a['claim_kinds']))==len(a['claim_kinds']),'IDENTITY_CLAIM_KINDS')
        for kind in a['claim_kinds']:p.text(kind,128)
        need(manifest['operations']=={'verify':{'mode':'LOCAL','description':'Accept only the exact agreed identity-evidence rule and current challenge.'}},'IDENTITY_PROVIDER_OPERATION')
        need(type(a['config']) is dict,'IDENTITY_CONFIGURATION');self.entries[ref]=(deepcopy(manifest),callback);self._callbacks[ref]=callback;return ref
    def _provider(self,ref):
        need(ref in self.entries,'IDENTITY_PROVIDER_NOT_INSTALLED');m,callback=self.entries[ref];need(p.mechanism_id(m)==ref and callback is self._callbacks.get(ref),'IDENTITY_PROVIDER_CHANGED');need(ref not in self._disabled,'IDENTITY_PROVIDER_DISABLED');return m,callback
    def register_declaration(self,name='Agreed declaration'):
        m=provider(name,'DECLARATION','parties-adopted-rule',IMPLEMENTATION,p._id('COVENANT-IDENTITY-DECLARATION-0.1',{'meaning':'EXACT_AGREED_CLAIMS_ONLY_NO_EXTERNAL_VERIFICATION'}),['*'],assumptions=['Acceptance only: assertions are declared, not independently verified.'])['manifest']
        def check(challenge,proof,now):requirements(proof);return deepcopy(proof)
        return self.register(m,check)
    def register_signed(self,name,issuer,claim_kinds):
        verification_key(issuer);issuer=deepcopy(issuer);m=provider(name,'SIGNED_ATTESTATION',p._id('COVENANT-IDENTITY-ISSUER-0.1',issuer),IMPLEMENTATION,p._id('COVENANT-IDENTITY-SIGNED-RULE-0.1',{'issuer':issuer,'profile':ATTESTATION}),claim_kinds,config={'issuer_key':issuer},assumptions=['Exact issuer signature, challenge and time bounds; issuer reliability and current status remain adopted trust.'])['manifest']
        def check(challenge,proof,now):
            exact(proof,'attestation signature');record=proof['attestation'];validate_attestation(record);need(record['challenge']==challenge_id(challenge) and record['provider']==challenge['provider'] and same(record['issuer'],issuer),'IDENTITY_ATTESTATION_SCOPE');need(challenge['not_before']<=record['not_before']<=now<record['expires']<=challenge['expires'],'IDENTITY_ATTESTATION_TIME');body={'attestation':attestation_id(record),'challenge':record['challenge'],'provider':record['provider']};verify(issuer,ATTESTATION_LABEL,body,proof['signature']);return deepcopy(record['assertions'])
        return self.register(m,check)
    def register_oidc(self,name,verifier):
        config=verifier.manifest_config;m=provider(name,'OIDC_RS256',config['issuer'],IMPLEMENTATION,p._id('COVENANT-IDENTITY-OIDC-RULE-0.1',config),['ACCOUNT_CONTROL','VERIFIED_EMAIL'],config=config,assumptions=['Pinned issuer/client/JWKS; nonce is this exact challenge ID. OIDC authenticates issuer-scoped account, not legal identity. No OAuth login or token exchange is executed.'])['manifest']
        def check(challenge,proof,now):
            need(challenge['audience']==config['client_id'],'IDENTITY_OIDC_AUDIENCE');
            if challenge['claim_kind']=='VERIFIED_EMAIL':need(type(challenge['requirements'].get('email')) is str,'IDENTITY_EMAIL_EXPECTATION_REQUIRED')
            claims=verifier.verify(proof,nonce=challenge_id(challenge),now=now,requirements=challenge['requirements'])
            return {**claims,**deepcopy(challenge['requirements'])}
        return self.register(m,check)
    def describe(self):return {'desk':self.ref,'policy':deepcopy(self.policy),'providers':{ref:{'manifest':deepcopy(m),'mechanism':self._installed.get(ref),'status':'DISABLED' if ref in self._disabled else 'INSTALLED'} for ref,(m,_) in self.entries.items()},'state':self.public_state(),'claims':'EXACT_ADOPTED_RULE_NOT_UNIVERSAL_IDENTITY_OR_AUTHORITY','execution_authorized':False}
    def install(self,registry,provider):
        self._policy();m,_=self._provider(provider)
        record=p.manifest(m['name']+' · agreed identity gate','identity',p._id('COVENANT-IDENTITY-GATE-0.1',{'desk':self.ref,'provider':provider}),IMPLEMENTATION,{'verify':{'mode':'LOCAL','description':'Check the exact current identity evidence and optional holder binding.'}},assurances={'desk':self.ref,'provider':provider,'evidence_mode':m['family'],'policy':self.policy,'provider_assumptions':m['assumptions']},assumptions=['Owner clock/current revocation and adopted provider behavior. LOCAL checks are pure; custom callbacks are trusted, not sandboxed.','Agreement acceptance and issuer attribution do not establish world truth, legal identity or native authority.'])['manifest'];ref=p.mechanism_id(record)
        if provider not in self._handlers:
            def check(context,evidence):return self._verify(provider,context,evidence)
            self._handlers[provider]=check
        handler=self._handlers[provider]
        if ref in registry.describe():
            actual,installed,pin=registry.get(ref,'verify','LOCAL');need(same(actual,record) and installed is handler and pin is None,'IDENTITY_INSTALLATION_CONFLICT')
        else:registry.register(record,{'verify':handler})
        self._installed[provider]=ref;return ref
    def issue_challenge(self,call_context,provider,subject,audience,claim_kind,requirements,request_hash,holder_binding='SUBJECT_SIGNATURE',ttl=60):
        now=self._fresh();m,_=self._provider(provider);p.ref(call_context);globals()['subject'](subject,holder_binding);p.text(audience,256);p.text(claim_kind,128);globals()['requirements'](requirements);p.ref(request_hash);integer(ttl);need(1<=ttl<=300,'IDENTITY_TTL');need(claim_kind in m['assurances']['claim_kinds'] or '*' in m['assurances']['claim_kinds'],'IDENTITY_CLAIM_KIND')
        params=dict(provider=provider,subject=deepcopy(subject),audience=audience,claim_kind=claim_kind,requirements=deepcopy(requirements),request_hash=request_hash,holder_binding=holder_binding);scope=p.canonical([call_context,params]);current=self._challenges.get(scope)
        if current is not None and current['not_before']<=now<current['expires']:return {'challenge':deepcopy(current),**holder_payload(current),'challenge_reused':True}
        self._challenges={k:v for k,v in self._challenges.items() if now<v['expires']};need(len(self._challenges)<1024,'IDENTITY_CHALLENGE_LIMIT')
        value=dict(version=CHALLENGE,desk=self.ref,**params,context=self.policy['context'],call_context=call_context,target=deepcopy(self.policy['target']),operation=self.policy['operation'],not_before=now,expires=min(now+ttl,self._valid_until),nonce=os.urandom(32).hex(),frame=p._frame('Agreed identity evidence',self.policy['target'],who={'kind':'identity-subject','id':p._id('COVENANT-IDENTITY-SUBJECT-0.1',subject)},how=m['family']));validate_challenge(value);self._challenges[scope]=deepcopy(value);return {'challenge':value,**holder_payload(value),'challenge_reused':False}
    def _verify(self,provider,context,evidence):
        try:
            from .mechanism_runtime import call_context
            now=self._fresh();m,callback=self._provider(provider);exact(evidence,'challenge proof signature');c=evidence['challenge'];validate_challenge(c);params=context['parameters'];exact(params,'provider subject audience claim_kind requirements request_hash holder_binding')
            need(c['desk']==self.ref and c['provider']==provider and context['context']==self.policy['context'] and same(context['target'],self.policy['target']) and c['call_context']==call_context(context),'IDENTITY_SCOPE');need(c['context']==self.policy['context'] and same(c['target'],self.policy['target']) and c['operation']==self.policy['operation'],'IDENTITY_SCOPE');need(all(same(c[k],v) for k,v in params.items()) and c['not_before']<=now<c['expires'],'IDENTITY_EXPECTATION')
            need(c['claim_kind'] in m['assurances']['claim_kinds'] or '*' in m['assurances']['claim_kinds'],'IDENTITY_CLAIM_KIND');scope=p.canonical([c['call_context'],params]);need(scope in self._challenges and same(c,self._challenges[scope]),'IDENTITY_CHALLENGE_NOT_CURRENT');need(custody_id('COVENANT-IDENTITY-EVIDENCE-0.1',evidence['proof']) not in self._revoked,'IDENTITY_EVIDENCE_REVOKED')
            if c['holder_binding']=='SUBJECT_SIGNATURE':payload=holder_payload(c);verify(c['subject'],payload['label'],payload['body'],evidence['signature'])
            else:need(evidence['signature'] is None,'IDENTITY_UNEXPECTED_SIGNATURE')
            claims=callback(deepcopy(c),deepcopy(evidence['proof']),now);requirements(claims,64);need(all(k in claims and same(claims[k],v) for k,v in c['requirements'].items()),'IDENTITY_CLAIM_MISMATCH');return True
        except Exception:return False

def record_packet(plan,approvals,expected_id,expected_controllers,step,delivery,expected_delivery,previous=None,expected_previous=None,plan_disclosure='REFERENCE_ONLY'):
    """Prepare exact agreed bytes for an explicitly chosen storage/ledger adapter."""
    from .mechanism_runtime import _assent,_step,delivery_id,DELIVERY
    _assent(plan,approvals,expected_id,expected_controllers,previous,expected_previous);s=_step(plan,step);exact(delivery,'version plan step visibility packet');need(delivery['version']==DELIVERY and delivery['plan']==expected_id and delivery['step']==step and delivery['visibility']==s['visibility'] and delivery_id(delivery)==expected_delivery,'IDENTITY_RECORD_DELIVERY')
    if s['visibility']=='PUBLIC':
        packet=delivery['packet'];exact(packet,'plan step selected openings');need(packet['plan']==expected_id and packet['step']==step and type(packet['selected']) is dict and set(packet['selected'])==set(s['fields']) and type(packet['openings']) is dict and set(packet['openings'])==set(s['fields']),'IDENTITY_RECORD_FIELDS')
        for path,value in packet['selected'].items():need(p.field_commitment(value,packet['openings'][path],plan['context'],step,path)==s['commitments'][path],'IDENTITY_RECORD_OPENING')
    if s['visibility']=='WITHHELD':need(delivery['packet'] is None,'IDENTITY_RECORD_WITHHELD')
    need(plan_disclosure in ('REFERENCE_ONLY','FULL'),'IDENTITY_RECORD_DISCLOSURE')
    record={'version':'covenant-agreed-evidence-record/0.1','plan':expected_id,'assent_hash':p._id('COVENANT-IDENTITY-RECORD-ASSENT-0.1',approvals),'delivery':deepcopy(delivery)}
    if plan_disclosure=='FULL':record.update(plan=deepcopy(plan),approvals=deepcopy(approvals),previous=deepcopy(previous),expected_previous=expected_previous)
    ref=custody_id('COVENANT-AGREED-EVIDENCE-RECORD-0.1',record);raw=custody_wire(record).decode('ascii');need(len(raw)<=1000000,'IDENTITY_RECORD_SIZE')
    storage={'version':'covenant-record-chunks/0.1','record':ref,'chunks':[raw[i:i+8192] for i in range(0,len(raw),8192)]}
    return {'id':ref,'record':record,'storage_request':storage,'request_binding':{'kind':'FIXED','hash':hashlib.sha256(custody_wire(storage)).hexdigest()},'disclosure':s['visibility'],'plan_disclosure':plan_disclosure,'recorded':False,'next':'OPTIONALLY_PROTECT_WHOLE_RECORD_THEN_ADOPT_STORAGE_REQUEST_IN_APPROVED_RECORD_FILE_OR_OTHER_LEDGER_WORKFLOW','record_scope':'CONTROLLER_ASSENT_CHECKED_PUBLIC_OPENINGS_CHECKED_PRIVATE_CIPHERTEXT_CONTENT_NOT_REVERIFIED_NOT_WORLD_TRUTH','metadata':'REFERENCE_ONLY_OMITS_PLAN_AND_ASSENTS_RETAIN_THEM_PRIVATELY_STEP_AND_DELIVERY_METADATA_REMAIN_UNLESS_WHOLE_RECORD_PROTECTED','execution_authorized':False}

def open_record(storage_request,expected_id):
    exact(storage_request,'version record chunks');need(storage_request['version']=='covenant-record-chunks/0.1','IDENTITY_RECORD_VERSION');p.ref(expected_id);need(storage_request['record']==expected_id,'IDENTITY_RECORD_EXPECTATION');chunks=storage_request['chunks'];need(type(chunks) is list and 1<=len(chunks)<=256 and all(type(c) is str and c.isascii() and 1<=len(c)<=8192 for c in chunks),'IDENTITY_RECORD_CHUNKS');raw=''.join(chunks);need(len(raw)<=1000000 and chunks==[raw[i:i+8192] for i in range(0,len(raw),8192)],'IDENTITY_RECORD_SIZE_OR_ENCODING')
    from .agent_tools import decode
    record=decode(raw);need(custody_wire(record).decode('ascii')==raw and custody_id('COVENANT-AGREED-EVIDENCE-RECORD-0.1',record)==expected_id,'IDENTITY_RECORD_HASH');need(type(record) is dict and record.get('version')=='covenant-agreed-evidence-record/0.1','IDENTITY_RECORD_VERSION')
    return {'id':expected_id,'record':record,'status':'EXACT_BYTES_AND_ID_VERIFIED_NOT_ASSENT_OR_PRIVATE_CONTENT','execution_authorized':False}

def install_atr_verifier(desk,name,issuer):
    """Install the ATR_HASH provider (served bytes hash to atrHash) into an IdentityDesk. Experimental."""
    from .lcp_buyer import install_identity
    return install_identity(desk,name,issuer)
