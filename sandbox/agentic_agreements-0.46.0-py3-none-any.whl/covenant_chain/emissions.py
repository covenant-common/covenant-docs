"""Kept-promise emissions. The budget halves every four years. It can only slow.

This is a bootstrap top-up of a pre-minted pool. It is not a yield and it does not mint.
"""
from .crypto import integer

# Illustrative: 1,000 blocks/day * 365 days * 4 years. A chain's blocks_per_day can
# only lengthen this interval (slower emissions), never shorten it below the floor
# stored with the profile. The floor itself is this constant.
HALVING_BLOCKS_FLOOR = 1_460_000
HALVING_YEARS = 4


def halving_budget(height, initial, halving_blocks):
    integer(height)
    integer(initial)
    integer(halving_blocks, True)
    halvings = min(height // halving_blocks, 40)
    return initial >> halvings


def slower_than(old_blocks, new_blocks):
    """A schedule change may only lengthen the halving interval."""
    integer(old_blocks, True)
    integer(new_blocks, True)
    return new_blocks >= old_blocks and new_blocks >= HALVING_BLOCKS_FLOOR
