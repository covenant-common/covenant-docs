"""Enforce scale-economies-shared fees on a covenant-economics/0.3 genesis.

The unit price is covenant-service-economics/0.2: measured cost plus a capped
margin, never above the published reference. Volume tiers and the hard take
cap can only make that price lower. Surplus above cost is split, with the
customer share routed to the fee-rebate pool. Nothing in this module mints.
"""
from copy import deepcopy

from covenant_language.shared_economics import REASONS, evaluate, propose_change

from .crypto import canonical, digest, exact, integer, key, need
from .tokenomics_config import (MODEL, SCALE_VERSION, apportion, illustrative_milestones,
    illustrative_supply, illustrative_tiers, live_meter, live_policy, validate_scale)

SCALE_OPS = ('ECON_BOND_LOCK', 'ECON_BOND_RELEASE', 'ECON_REWARD_CLAWBACK', 'ECON_REWARD_VEST',
             'ECON_REBATE_CLAIM', 'ECON_INTEGRATOR_NOTE', 'ECON_INTEGRATOR_PAY', 'ECON_INTEGRATOR_SWEEP',
             'ECON_AD_SUBSIDY', 'ECON_COST_REPORT', 'ECON_ENDOWMENT_RELEASE', 'ECON_SERVE_SETTLE',
             'ECON_SERVE_VEST', 'ECON_SERVE_FORFEIT', 'ECON_LIGHT_FETCH', 'ECON_RELAY_FETCH',
             'ECON_OFFLINE_ALLOWANCE', 'ECON_OFFLINE_SPEND', 'ECON_OFFLINE_EQUIVOCATION')
EVENT_LIMIT = 4096
GENESIS_DESTINATION = ('Scale economies shared: the protocol fee is measured cost plus a capped margin, '
                       'and that cap can only fall as kept-promise volume grows.')


def _label(value):
    need(type(value) is str and 0 < len(value) <= 80 and all(32 <= ord(c) <= 126 for c in value), 'ECONOMIC_LABEL')


def validate_scale_policy(policy, resources):
    exact(policy, 'version resource base_fee per_kib work_fees beneficiaries governors threshold change_delay scale')
    need(policy['version'] == SCALE_VERSION, 'ECONOMIC_VERSION')
    _label(policy['resource'])
    need(policy['resource'] in resources, 'FEE_RESOURCE')
    integer(policy['base_fee'])
    integer(policy['per_kib'])
    work = policy['work_fees']
    need(type(work) is dict and len(work) <= 64, 'FEE_WORK_LIMIT')
    for op, amount in work.items():
        _label(op)
        integer(amount)
    rows = policy['beneficiaries']
    need(type(rows) is list and 1 <= len(rows) <= 16, 'FEE_BENEFICIARIES')
    accounts = set()
    for row in rows:
        exact(row, 'account bps purpose')
        key(row['account'])
        integer(row['bps'])
        _label(row['purpose'])
        need((row['account'], row['purpose']) not in accounts and row['bps'] <= 10000, 'FEE_BENEFICIARIES')
        accounts.add((row['account'], row['purpose']))
    need(sum(row['bps'] for row in rows) == 10000, 'FEE_SHARES')
    from .founder_share import CEILING_BPS
    founder_bps = sum(row['bps'] for row in rows if row['purpose'] == 'FOUNDER')
    need(founder_bps <= CEILING_BPS, 'FOUNDER_CEILING')
    governors = policy['governors']
    need(type(governors) is list and 1 <= len(governors) <= 32 and governors == sorted(set(governors)), 'FEE_GOVERNORS')
    for who in governors:
        key(who)
    integer(policy['threshold'], True)
    need(policy['threshold'] <= len(governors), 'FEE_THRESHOLD')
    integer(policy['change_delay'], True)
    need(policy['change_delay'] >= 2, 'FEE_NOTICE')
    validate_scale(policy['scale'])
    need(policy['change_delay'] >= policy['scale']['governance']['min_increase_delay'], 'SCALE_NOTICE')
    need(policy['scale']['supply']['resource'] in resources, 'SUPPLY_RESOURCE')
    reason = policy['scale']['governance']['change_reason']
    need(reason == 'GENESIS' or reason in REASONS, 'SCALE_REASON')
    if reason != 'GENESIS':
        need(len(policy['scale']['governance']['destination']) >= 200, 'SCALE_DESTINATION')
    _routes_cover(policy)
    canonical(policy)
    return policy


def _routes_cover(policy):
    scale = policy['scale']
    present = {}
    for row in policy['beneficiaries']:
        present.setdefault(row['purpose'], set()).add(row['account'])
    required = {'MAINTENANCE': 'maintenance', 'FEE_REBATE': 'rebate_pool', 'OPERATORS': 'operators',
                'INTEGRATOR': 'integrator_pool', 'RESERVE': 'reserve', 'ARCHIVE_SERVE': 'archive_pool'}
    if scale['shares']['founder'] > 0:
        required['FOUNDER'] = 'founder'
    if scale['shares']['ecosystem'] > 0:
        required['ECOSYSTEM'] = 'ecosystem'
    for purpose, account_name in required.items():
        need(purpose in present and scale['accounts'][account_name] in present[purpose], 'SCALE_ROUTE')


def _merge(base, override):
    merged = dict(base)
    for name, value in (override or {}).items():
        if type(value) is dict and type(merged.get(name)) is dict:
            merged[name] = _merge(merged[name], value)
        else:
            merged[name] = value
    return merged


def make_policy(resource, governor, pools, overrides=None):
    """A complete 0.3 policy. `pools` maps the scale account roles to 32-byte keys.

    Beneficiary bps do not set the take. They are the only split of the charged
    fee, and they already sum to 10,000. FOUNDER is one of those rows. The
    service-economics `shares` block is a scenario input to the price, not a
    second founder_bps transfer.
    """
    for name in ('maintenance', 'rebate_pool', 'reserve', 'integrator_pool', 'founder', 'ecosystem', 'bond_escrow', 'operators', 'archive_pool', 'stake_pool', 'stake_escrow', 'founder_vest', 'waqf', 'burn'):
        key(pools[name])
    key(governor)
    _label(resource)
    scale = {'model': MODEL, 'planning_profile': 'covenant-service-economics/0.2',
             'bps_do_not_set_the_take': True, 'shariah_mode': False,
             'cost': {'fixed_cost_per_window': 50000, 'variable_cost_per_unit': 8, 'reference_notional': 10000},
             'caps': {'margin_cap_bps': 500, 'max_take_bps': 500, 'founder_fee_cap_bps': 0},
             'tiers': illustrative_tiers(),
             'window': {'window_blocks': 30000, 'pair_cap': 8, 'blocks_per_day': 1000, 'participant_multiplier': 32},
             'shares': {'customer': 5000, 'ecosystem': 0, 'founder': 0, 'operator': 5000},
             'accounts': {name: pools[name] for name in ('maintenance', 'rebate_pool', 'reserve', 'integrator_pool', 'founder', 'ecosystem', 'bond_escrow', 'operators', 'archive_pool', 'stake_pool', 'stake_escrow', 'founder_vest', 'waqf', 'burn')},
             'supply': {**illustrative_supply(), 'resource': resource},
             'vesting': {'cliff_days': 365, 'duration_days': 1460, 'milestone_fraction_bps': 5000,
                         'milestones': illustrative_milestones(), 'start_height': 0},
             'points': {'season_blocks': 30000, 'decay_after_seasons': 2, 'decay_bps': 5000,
                        'epoch_blocks': 7000, 'epoch_emission': 10_000_000, 'emission_decay_bps': 0,
                        'halving_blocks': 1_460_000,
                        'tokens_per_point_num': 1, 'tokens_per_point_den': 1, 'log_scale': 1000,
                        'loyalty_bps': 12500, 'min_bond': 1000, 'retention_blocks': 30000,
                        'diversity_cap': 32, 'wash_earns_zero': True, 'vest_unlock_bps': 2500,
                        'vest_blocks': 365000, 'pagerank_damping_bps': 8500, 'pledge_stake_bps': 5000},
             'rebates': {'honour_bps': 9000, 'token_rebate_bps': 10000},
             'integrator': {'fee_bps': 1500, 'round_blocks': 30000, 'per_owner_cap': 100},
             'governance': {'min_increase_delay': 14000, 'change_reason': 'GENESIS',
                            'destination': GENESIS_DESTINATION, 'robustness_min_bps': 0,
                            'robustness_max_bps': 1000000, 'reserve_target': 0},
             'pledges': [{'id': digest('COVENANT-PLEDGE-TEMPLATE', {'kind': 'RUN_NODE'}), 'kind': 'RUN_NODE',
                          'minimum': 1, 'profile': 'task-v1'},
                         {'id': digest('COVENANT-PLEDGE-TEMPLATE', {'kind': 'BRING_AGENTS'}), 'kind': 'BRING_AGENTS',
                          'minimum': 2, 'profile': 'task-v1'}],
             'ads': {'owner_bps': 3000, 'integrator_bps': 2500, 'subsidy_bps': 1000, 'exchange_bps': 3500,
                     'min_counterparties': 2}}
    scale = _merge(scale, (overrides or {}).get('scale'))
    delay = scale['governance']['min_increase_delay']
    # REFERRAL and ARCHIVE_SERVE are rows inside the same 10,000. They are not a second split.
    # The bps come out of the operator row. They route the share; they do not set its size.
    # FOUNDER stays 250, beside ARCHIVE_SERVE.
    purposes = [('maintenance', 'MAINTENANCE', 3500), ('rebate_pool', 'FEE_REBATE', 2500),
                ('operators', 'OPERATORS', 1000), ('archive_pool', 'ARCHIVE_SERVE', 500),
                ('integrator_pool', 'INTEGRATOR', 1000),
                ('integrator_pool', 'REFERRAL', 500),
                ('reserve', 'RESERVE', 500), ('founder', 'FOUNDER', 250), ('ecosystem', 'ECOSYSTEM', 250)]
    policy = {'version': SCALE_VERSION, 'resource': resource, 'base_fee': 250, 'per_kib': 0, 'work_fees': {},
              'beneficiaries': [{'account': pools[name], 'bps': bps, 'purpose': purpose} for name, purpose, bps in purposes],
              'governors': [governor], 'threshold': 1, 'change_delay': delay, 'scale': scale}
    if overrides:
        top = {k: v for k, v in overrides.items() if k != 'scale'}
        policy.update(top)
        policy['scale'] = scale
    return policy


def init_meter(state):
    state['economic_policy']['scale'] = {'events': [], 'subsidies': [], 'reserve_balance': 0,
        'integrators': {}, 'bonds': {}, 'rebate_claimed': {}, 'integrator_paid': {}, 'swept': 0,
        'last_flags': {'customer_share_falls': False, 'margin_cap_rises': False, 'planning_change': False},
        'pledges_used': [], 'founder_shadow': True, 'rolling_gross': 0, 'previous_unit_cost': None,
        'reported_unit_cost': None, 'previous_reported_unit_cost': None, 'reported_epoch': None,
        'ratchet_ceiling': None, 'savings_to_users': 0, 'savings_returned_bps': 0, 'referral_edges': [],
        'endowment_remaining': 0, 'endowment_claimable': 0, 'endowment_epoch': None,
        'serve_epoch': None, 'serve_holds': {}, 'free_fetches': {}, 'offline_allowances': {},
        'first_agreements': {},
        'ledger': [], 'totals': {'gross': 0, 'cost': 0, 'founder': 0, 'users': 0, 'protocol': 0},
        'positions': {}, 'delegations': {}, 'unbonding': [], 'work': {}, 'slash_log': [],
        'rewards_claimed': {}, 'upgrade_votes': {}, 'founder_locked': {}}


def _tier_bps(tiers, volume):
    chosen = tiers[0]['take_bps']
    for row in tiers:
        if volume >= row['min_qualified_volume']:
            chosen = row['take_bps']
    return chosen


def qualified_volume(events, window):
    counts = {}
    people = set()
    used = 0
    for event in events:
        pair = tuple(sorted((event['principal'], event['counterparty'])))
        if counts.get(pair, 0) >= window['pair_cap']:
            continue
        counts[pair] = counts.get(pair, 0) + 1
        people.add(event['principal'])
        people.add(event['counterparty'])
        used += 1
    if not people:
        return 0
    return min(used, len(people) * window['participant_multiplier'])


def scale_view(state, height, scale):
    meter = live_meter(state) or {'events': [], 'subsidies': [], 'reserve_balance': 0}
    window = scale['window']['window_blocks']
    events = [event for event in meter.get('events', []) if height - event['height'] < window]
    credit = sum(row['amount'] for row in meter.get('subsidies', []) if height - row['height'] < window)
    positions = {}
    for account, row in (meter.get('positions') or {}).items():
        positions[account] = {'amount': row['amount'], 'lock_blocks': row['lock_blocks'],
                              'locked_at': row['locked_at'], 'unbonding': row['unbonding']}
    epoch = height // scale['points']['epoch_blocks']
    free = {}
    for actor, row in (meter.get('free_fetches') or {}).items():
        if row.get('epoch') == epoch:
            free[actor] = row.get('count', 0)
    return {'qualified_volume': qualified_volume(events, scale['window']),
            'reserve_balance': meter.get('reserve_balance', 0), 'ad_subsidy_credit': credit,
            'previous_unit_cost': meter.get('previous_unit_cost'),
            'reported_unit_cost': meter.get('reported_unit_cost'),
            'previous_reported_unit_cost': meter.get('previous_reported_unit_cost'),
            'ratchet_ceiling': meter.get('ratchet_ceiling'),
            'savings_to_users': meter.get('savings_to_users', 0),
            'rolling_gross': meter.get('rolling_gross', 0),
            'founder_shadow': meter.get('founder_shadow', True),
            'positions': positions, 'height': height, 'free_fetches': free}


def _plan(policy, units, fixed, reserve_balance):
    scale = policy['scale']
    margin = min(scale['caps']['margin_cap_bps'], scale['caps']['max_take_bps'])
    return {'version': 'covenant-service-economics/0.2', 'name': 'enforced-fee', 'period': 'window',
            'resource': policy['resource'], 'reference_unit_price': policy['base_fee'], 'margin_cap_bps': margin,
            'fixed_cost': fixed, 'variable_cost_per_unit': scale['cost']['variable_cost_per_unit'],
            'paid_units': units, 'reserve_target': scale['governance']['reserve_target'],
            'reserve_balance': min(reserve_balance, scale['governance']['reserve_target']),
            'shares': {name: scale['shares'][name] for name in ('customer', 'ecosystem', 'founder', 'operator')},
            'robustness_band_bps': {'minimum': scale['governance']['robustness_min_bps'],
                                    'maximum': scale['governance']['robustness_max_bps']},
            'vesting_periods': 1, 'hurdle_bps': 0}


def protocol_price(policy, view):
    """Unit price from the 0.2 planning profile, then the stricter published tier.

    When a previous epoch recorded a higher unit cost, at least half of that drop
    is taken off the price before any founder line. A price outside the one-sixth
    ona'ah band is void: the charge is zero and the caller collects nothing.
    """
    from .token_invariants import onaah_holds, user_saving
    need(type(view) is dict and 'qualified_volume' in view, 'SCALE_VIEW_REQUIRED')
    integer(view['qualified_volume'])
    integer(view.get('reserve_balance', 0))
    integer(view.get('ad_subsidy_credit', 0))
    units = max(view['qualified_volume'], 1)
    fixed = policy['scale']['cost']['fixed_cost_per_window']
    fixed = max(0, fixed - min(fixed, view.get('ad_subsidy_credit', 0)))
    report = evaluate(_plan(policy, units, fixed, view.get('reserve_balance', 0)))
    unit_cost = report['measured_unit_cost']
    price = report['unit_price']
    tier = _tier_bps(policy['scale']['tiers'], view['qualified_volume'])
    tier_fee = policy['scale']['cost']['reference_notional'] * tier // 10000
    if unit_cost < policy['base_fee']:
        price = min(price, max(unit_cost, tier_fee))
    # A signed cost report is the measured unit cost. At least half of a drop
    # comes off the price before margin or the founder row. The ceiling only falls.
    # With no report, the epoch-to-epoch inference is unchanged.
    caps = []
    reported = view.get('reported_unit_cost')
    previous_reported = view.get('previous_reported_unit_cost')
    if type(reported) is int and type(previous_reported) is int and reported < previous_reported:
        owed = user_saving(previous_reported, reported)
        if owed:
            caps.append(previous_reported - owed)
    stored = view.get('ratchet_ceiling')
    if type(stored) is int:
        caps.append(stored)
    if type(reported) is not int:
        previous = view.get('previous_unit_cost')
        if type(previous) is int and unit_cost < previous:
            owed = user_saving(previous, unit_cost)
            if owed:
                caps.append(previous - owed)
    ratchet_cut = 0
    if caps:
        ceiling = min(caps)
        if price > ceiling:
            ratchet_cut = price - ceiling
            price = max(0, ceiling)
    voided = False
    if not onaah_holds(price, unit_cost):
        price = 0
        voided = True
    return {'unit_price': price, 'unit_cost': unit_cost, 'tier_bps': tier, 'tier_fee': tier_fee,
            'planning_unit_price': report['unit_price'], 'planning_report': report, 'fixed_cost_charged': fixed,
            'ratchet_cut': ratchet_cut, 'voided': voided}


def _token_discount(policy, view, price, unit_cost, transaction):
    """Discount comes out of surplus and only for a token fee backed by a warmed lock."""
    if transaction is None or price <= unit_cost:
        return 0
    fee = (transaction.get('body') or {}).get('fee') or {}
    asset = fee.get('asset')
    if not asset or asset != policy['scale']['supply']['resource']:
        return 0
    actor = transaction['body'].get('actor')
    row = (view.get('positions') or {}).get(actor)
    if not row or row.get('unbonding'):
        return 0
    height = view.get('height') or 0
    if row.get('locked_at', height) >= height:
        return 0
    from .staking import lock_discount_bps
    max_lock = 1460 * policy['scale']['window']['blocks_per_day']
    bps = lock_discount_bps(row['lock_blocks'], max_lock)
    margin = price - unit_cost
    return min(margin, price * bps // 10000)


def _carve(buckets, amount, dest):
    """Move `amount` from surplus rows into `dest`. Returns what fit."""
    remaining = min(amount, buckets['operator'] + buckets['ecosystem'] + buckets['founder'])
    taken = 0
    for name in ('operator', 'ecosystem', 'founder'):
        bite = min(buckets[name], remaining)
        buckets[name] -= bite
        remaining -= bite
        taken += bite
    buckets[dest] += taken
    return taken


def _under_free_quota(policy, view, transaction):
    from .serving_rewards import FETCH_OPS, under_free_quota
    if not transaction:
        return False
    body = transaction.get('body') or {}
    if body.get('op') not in FETCH_OPS:
        return False
    used = (view.get('free_fetches') or {}).get(body.get('actor'), 0)
    if type(used) is not int:
        used = 0
    return under_free_quota(used)


def fee_parts(policy, data, work, view, integrator_cut=0, transaction=None, referral_cut=0, rebate_redirect=0):
    integer(data)
    integer(work)
    integer(integrator_cut)
    integer(referral_cut)
    integer(rebate_redirect)
    priced = protocol_price(policy, view)
    price = priced['unit_price']
    unit_cost = priced['unit_cost']
    from .human_incentives import paying_in_token, stake_locked, surplus_discount, token_cashback
    in_token = paying_in_token(policy, transaction)
    lock_cut = _token_discount(policy, view, price, unit_cost, transaction)
    token_cut = surplus_discount(price, unit_cost, view.get('qualified_volume') or 0, in_token, lock_cut)
    price -= token_cut
    if _under_free_quota(policy, view, transaction):
        price = 0
        data = 0
        work = 0
        token_cut = 0
    scale = policy['scale']
    buckets = {'maintenance': 0, 'reserve': 0, 'giveback': 0, 'founder': 0, 'ecosystem': 0,
               'operator': 0, 'integrator': 0, 'referral': 0, 'archive': 0}
    if price <= unit_cost:
        buckets['maintenance'] = price
        deficit = unit_cost - price
        margin = 0
    else:
        deficit = 0
        margin = price - unit_cost
        gap = max(0, scale['governance']['reserve_target'] - view.get('reserve_balance', 0))
        buckets['reserve'] = min(margin, gap)
        distributable = margin - buckets['reserve']
        shares = scale['shares']
        buckets['giveback'] = distributable * shares['customer'] // 10000
        # shares.founder feeds the planning scenario only. The chain row is FOUNDER inside 10,000 bps.
        buckets['founder'] = 0
        buckets['ecosystem'] = distributable * shares['ecosystem'] // 10000
        buckets['operator'] = distributable * shares['operator'] // 10000
        buckets['operator'] += distributable - buckets['giveback'] - buckets['founder'] - buckets['ecosystem'] - buckets['operator']
        _carve(buckets, integrator_cut, 'integrator')
        _carve(buckets, referral_cut, 'referral')
        # Named but ineligible: the share stays with users, inside the rebate row.
        _carve(buckets, rebate_redirect, 'giveback')
        buckets['maintenance'] = unit_cost
    from .founder_share import slice_for
    gross_for_founder = price + data + work
    prior = view.get('rolling_gross') or 0
    integer(prior)
    scheduled = slice_for(prior, gross_for_founder)
    founder_paid = 0
    # Live founder income is the FOUNDER row's share of this fee, capped by the
    # marginal schedule and by surplus. It is not added on top of the price and
    # it is not a second founder_bps. Shadow mode pays the row nothing.
    if view.get('founder_shadow', True) is False and margin > 0 and scheduled > 0:
        row_bps = sum(row['bps'] for row in policy['beneficiaries'] if row['purpose'] == 'FOUNDER')
        row_amount = gross_for_founder * row_bps // 10000
        room = buckets['operator'] + buckets['ecosystem']
        founder_paid = min(scheduled, row_amount, room)
        remaining = founder_paid
        for name in ('operator', 'ecosystem'):
            bite = min(buckets[name], remaining)
            buckets[name] -= bite
            remaining -= bite
        buckets['founder'] += founder_paid - remaining
        founder_paid -= remaining
    # Archive serving is the operator surplus left after integrator, referral and the live founder.
    # The row's bps do not set this amount. A zero surplus leaves the row unpaid.
    buckets['archive'] += buckets['operator']
    buckets['operator'] = 0
    buckets['maintenance'] += data + work
    total = price + data + work
    purpose = {'maintenance': 'MAINTENANCE', 'reserve': 'RESERVE', 'giveback': 'FEE_REBATE',
               'founder': 'FOUNDER', 'ecosystem': 'ECOSYSTEM', 'operator': 'OPERATORS',
               'archive': 'ARCHIVE_SERVE', 'integrator': 'INTEGRATOR', 'referral': 'REFERRAL'}
    allocations = []
    for name, purpose_name in purpose.items():
        amount = buckets[name]
        if amount <= 0:
            continue
        rows = [row for row in policy['beneficiaries'] if row['purpose'] == purpose_name and row['bps'] > 0]
        need(rows, 'SCALE_ROUTE')
        for row, share in zip(rows, apportion(amount, [row['bps'] for row in rows])):
            if share:
                allocations.append({'account': row['account'], 'amount': share, 'purpose': purpose_name})
    need(sum(row['amount'] for row in allocations) == total, 'SCALE_CONSERVATION')
    result = {'total': total, 'protocol': price, 'data': data, 'work': work, 'allocations': allocations,
            'giveback': buckets['giveback'], 'integrator_cut': buckets['integrator'],
            'referral_cut': buckets['referral'], 'deficit': deficit,
            'reserve_topup': buckets['reserve'], 'margin': margin, 'founder_scheduled': scheduled,
            'founder_paid': founder_paid, 'founder_shadow': view.get('founder_shadow', True) is not False,
            'stake_revenue': 0, 'founder_route': 'BENEFICIARY_ROW',
            'archive': buckets['archive'], 'token_discount': token_cut,
            'token_cashback': token_cashback(buckets['giveback'], stake_locked(view, (transaction or {}).get('body', {}).get('actor') if transaction else None), in_token)}
    priced = dict(priced)
    priced['unit_price'] = price
    result.update(priced)
    return result


def enforced_amount(policy, data, work, transaction=None):
    total = fee_parts(policy, data, work, policy.get('_scale') or {}, 0, transaction)['total']
    integer(total)
    return total


def _wire(tx, policy):
    size = len(canonical(tx))
    kib = (size + 1023) // 1024
    return kib * policy['per_kib'], policy['work_fees'].get(tx['body']['op'], 0)


def _fee_name(fee, field):
    if type(fee) is not dict or field not in fee:
        return ''
    value = fee[field]
    return value if type(value) is str else ''


def _use_shares(state, tx, policy, price, height):
    """Integrator and referral shares for one settled covenant.

    Both are beneficiary rows of this fee. They are paid only after EXECUTE,
    which the ledger allows only once the challenge window has closed, and only
    when the principal already has diverse counterparties. One level: the named
    account is the whole share. A party, a wash pair, a cycle back to someone
    who already referred this principal, or a name newer than the retention
    window is unpaid. That unpaid amount is redirected to the fee-rebate row.
    """
    empty = {'integrator': 0, 'referral': 0, 'redirect': 0, 'integrator_account': '', 'referrer_account': ''}
    if tx['body']['op'] != 'EXECUTE':
        return empty
    agreement_id = tx['body']['payload'].get('agreement')
    if not agreement_id or agreement_id not in state.get('agreements', {}):
        return empty
    agreement = state['agreements'][agreement_id]
    from .kept_promises import honoured
    if not honoured(agreement):
        return empty
    terms = agreement['terms']
    principal, agent, counterparty = terms['principal'], terms['agent'], terms['counterparty']
    if principal == counterparty or agent == counterparty:
        return empty
    scale = policy['scale']
    meter = live_meter(state) or {}
    fee = tx['body'].get('fee') or {}
    note = (meter.get('integrators') or {}).get(agreement_id) or {}
    envelope_integrator = _fee_name(fee, 'integrator')
    if envelope_integrator:
        integrator, integrator_since = envelope_integrator, None
    elif note.get('integrator'):
        integrator, integrator_since = note['integrator'], note.get('height')
    else:
        integrator, integrator_since = '', None
    referrer = _fee_name(fee, 'referrer')
    if referrer and referrer == integrator:
        referrer = ''
    desired = price * scale['integrator']['fee_bps'] // 10000
    window = scale['window']
    retention = scale['points']['retention_blocks']
    events = [event for event in (meter.get('events') or []) if height - event['height'] < window['window_blocks']]
    parties = {principal, agent, counterparty}
    edges = list(meter.get('referral_edges') or [])

    def eligible(who, since):
        if not who or who in parties:
            return False
        if {'beneficiary': principal, 'principal': who} in edges:
            return False
        pair = tuple(sorted((principal, counterparty)))
        prior_pair = 0
        counterparties = set()
        retained = since is not None and height - since >= retention
        for event in events:
            if event.get('principal') != principal:
                continue
            counterparties.add(event['counterparty'])
            if tuple(sorted((event['principal'], event['counterparty']))) == pair:
                prior_pair += 1
            if since is None and height - event['height'] >= retention:
                retained = True
        counterparties.add(counterparty)
        if prior_pair >= window['pair_cap']:
            return False
        if len(counterparties) < scale['ads']['min_counterparties']:
            return False
        return retained

    integrator_ok = eligible(integrator, integrator_since)
    referrer_ok = eligible(referrer, None)
    redirect = 0
    if integrator and not integrator_ok:
        redirect += desired
    if referrer and not referrer_ok:
        redirect += desired
    return {'integrator': desired if integrator_ok else 0, 'referral': desired if referrer_ok else 0,
            'redirect': redirect, 'integrator_account': integrator if integrator_ok else '',
            'referrer_account': referrer if referrer_ok else ''}


def settle_fee(state, tx, chosen, tid, height, payer, quote):
    """Record the fee. economics.charge is the only function that moves the units."""
    policy = chosen['body']
    data, work = _wire(tx, policy)
    view = policy['_scale']
    priced = protocol_price(policy, view)
    shares = _use_shares(state, tx, policy, priced['unit_price'], height)
    parts = fee_parts(policy, data, work, view, shares['integrator'], tx, shares['referral'], shares['redirect'])
    need(parts['total'] == quote['amount'], 'SCALE_FEE_MISMATCH')
    receipt = {**quote, 'binding': True, 'finality': 'VERIFY_CERTIFICATE', 'height': height,
               'actor': tx['body']['actor'], 'payer': payer, 'sponsor': tx['body']['fee']['sponsor'],
               'allocations': parts['allocations'],
               'scale': {'model': MODEL, 'qualified_volume': view['qualified_volume'],
                         'unit_cost': parts['unit_cost'], 'unit_price': parts['unit_price'],
                         'tier_bps': parts['tier_bps'], 'giveback': parts['giveback'],
                         'integrator_cut': parts['integrator_cut'], 'referral_cut': parts['referral_cut'],
                         'integrator': shares['integrator_account'] if parts['integrator_cut'] else '',
                         'referrer': shares['referrer_account'] if parts['referral_cut'] else '',
                         'deficit': parts['deficit'],
                         'reserve_topup': parts['reserve_topup'],
                         'ad_subsidy_credit': view.get('ad_subsidy_credit', 0),
                         'planning_unit_price': parts['planning_unit_price'],
                         'founder_scheduled': parts['founder_scheduled'], 'founder_paid': parts['founder_paid'],
                         'founder_shadow': parts['founder_shadow'], 'stake_revenue': parts['stake_revenue'],
                         'voided': parts['voided'], 'ratchet_cut': parts['ratchet_cut'],
                         'reported_unit_cost': view.get('reported_unit_cost'),
                         'token_discount': parts['token_discount'], 'token_cashback': parts['token_cashback'],
                         'sponsor_program': (tx['body'].get('fee') or {}).get('sponsor_program') or ''}}
    state['fee_receipts'][tid] = receipt
    _book_revenue(state, tx, height, parts, policy)
    _note(state, tx, height, receipt)
    return receipt


def _band(gross):
    from .founder_share import BANDS
    cursor = 0
    for index, band in enumerate(BANDS):
        if band['up_to'] is None or gross < band['up_to']:
            return index
        cursor = band['up_to']
    return cursor and len(BANDS) - 1


def _book_revenue(state, tx, height, parts, policy):
    from .revenue_ledger import record
    from .staking import accrue
    meter = state['economic_policy']['scale']
    paid = 0 if parts['founder_shadow'] else parts['founder_paid']
    gross = parts['total']
    rate = 0 if gross == 0 else paid * 10000 // gross
    # A sponsor-paid fee is the sponsorship stream. The founder row was already taken inside the fee.
    sponsored = (tx['body'].get('fee') or {}).get('sponsor') is not None
    record(meter, height, 'sponsorship_fee' if sponsored else 'protocol_fee', tx['body']['op'], gross, parts['unit_cost'], paid,
           parts['giveback'], parts['protocol'], rate, _band(meter.get('rolling_gross', 0)))
    archive_paid = sum(row['amount'] for row in parts['allocations'] if row['purpose'] == 'ARCHIVE_SERVE')
    meter['endowment_remaining'] = meter.get('endowment_remaining', 0) + archive_paid
    epoch_blocks = policy['scale']['points']['epoch_blocks']
    epoch = height // epoch_blocks
    seen = meter.get('cost_epoch')
    if seen is None:
        meter['cost_epoch'] = epoch
        meter['last_unit_cost'] = parts['unit_cost']
        meter['epoch_revenue'] = parts['protocol']
    elif seen != epoch:
        _adapt_emissions(meter, policy['scale']['points'])
        meter['previous_unit_cost'] = meter.get('last_unit_cost')
        meter['last_unit_cost'] = parts['unit_cost']
        meter['cost_epoch'] = epoch
        meter['epoch_revenue'] = parts['protocol']
    else:
        meter['last_unit_cost'] = parts['unit_cost']
        meter['epoch_revenue'] = meter.get('epoch_revenue', 0) + parts['protocol']
    max_lock = 1460 * policy['scale']['window']['blocks_per_day']
    accrue(meter, parts['stake_revenue'], max_lock)
    if not parts['founder_shadow'] and parts['founder_paid']:
        from .founder_share import STABLE_BPS
        token_leg = parts['founder_paid'] - parts['founder_paid'] * STABLE_BPS // 10000
        locked = dict(meter.get('founder_locked') or {})
        locked['amount'] = locked.get('amount', 0) + token_leg
        meter['founder_locked'] = locked
    state['economic_policy']['scale'] = meter


def _adapt_emissions(meter, points):
    """Coverage at an epoch boundary can only cut the budget. It does not spring back."""
    from .emissions import halving_budget
    budget = halving_budget(meter.get('cost_epoch', 0) * points['epoch_blocks'], points['epoch_emission'], points['halving_blocks'])
    revenue = meter.get('epoch_revenue', 0)
    if budget <= 0 or revenue * 10000 < budget * 10000:
        return
    current = meter.get('emission_cap', budget)
    floor = 1
    reduced = max(floor, min(current, budget) // 2)
    if reduced < current:
        meter['emission_cap'] = reduced


def _note(state, tx, height, receipt):
    if tx['body']['op'] != 'EXECUTE':
        _remember_reserve(state, receipt)
        return
    agreement_id = tx['body']['payload']['agreement']
    agreement = state['agreements'][agreement_id]
    from .kept_promises import honoured
    if not honoured(agreement):
        _remember_reserve(state, receipt)
        return
    terms = agreement['terms']
    if terms['principal'] == terms['counterparty'] or terms['agent'] == terms['counterparty']:
        _remember_reserve(state, receipt)
        return
    meter = state['economic_policy']['scale']
    paid = receipt['scale']
    event = {'height': height, 'principal': terms['principal'], 'agent': terms['agent'],
             'counterparty': terms['counterparty'], 'agreement': agreement_id, 'quantity': terms['quantity'],
             'fee': receipt['amount'], 'giveback': paid['giveback'],
             'integrator_cut': paid.get('integrator_cut', 0), 'integrator': paid.get('integrator') or '',
             'referral_cut': paid.get('referral_cut', 0), 'referrer': paid.get('referrer') or ''}
    if event['integrator_cut'] and event['integrator']:
        _remember_edge(meter, event['integrator'], terms['principal'])
    if event['referral_cut'] and event['referrer']:
        _remember_edge(meter, event['referrer'], terms['principal'])
    events = list(meter.get('events') or [])
    events.append(event)
    meter['events'] = events[-EVENT_LIMIT:]
    state['economic_policy']['scale'] = meter
    _remember_reserve(state, receipt)


def _remember_edge(meter, beneficiary, principal):
    edges = list(meter.get('referral_edges') or [])
    row = {'beneficiary': beneficiary, 'principal': principal}
    if row not in edges and len(edges) < EVENT_LIMIT:
        edges.append(row)
    meter['referral_edges'] = edges


def _remember_reserve(state, receipt):
    meter = state['economic_policy']['scale']
    target = live_policy(state)['scale']['governance']['reserve_target']
    meter['reserve_balance'] = min(target, meter.get('reserve_balance', 0) + receipt['scale']['reserve_topup'])
    state['economic_policy']['scale'] = meter


def _grid_take(policy, volume):
    return _tier_bps(policy['scale']['tiers'], volume)


def accept_schedule(state, old, new, height, effective):
    need(new['version'] == SCALE_VERSION, 'SCALE_PROFILE')
    validate_scale_policy(new, state['resources'])
    reason = new['scale']['governance']['change_reason']
    need(reason in REASONS, 'SCALE_REASON')
    need(new['scale']['caps']['margin_cap_bps'] <= old['scale']['caps']['margin_cap_bps'], 'SCALE_TAKE_CAP')
    need(new['scale']['caps']['max_take_bps'] <= old['scale']['caps']['max_take_bps'], 'SCALE_TAKE_CAP')
    need(new['scale']['caps']['founder_fee_cap_bps'] <= old['scale']['caps']['founder_fee_cap_bps'], 'SCALE_TAKE_CAP')
    need(new['scale']['shares']['founder'] <= old['scale']['shares']['founder'], 'SCALE_TAKE_CAP')
    need(new['base_fee'] <= old['base_fee'] and new['per_kib'] <= old['per_kib'], 'SCALE_TAKE_CAP')
    need(new['scale']['cost']['reference_notional'] <= old['scale']['cost']['reference_notional'], 'SCALE_TAKE_CAP')
    for op, amount in new['work_fees'].items():
        need(amount <= old['work_fees'].get(op, 0), 'SCALE_TAKE_CAP')
    volumes = {0}
    for row in list(old['scale']['tiers']) + list(new['scale']['tiers']):
        volumes.add(row['min_qualified_volume'])
    for volume in volumes:
        need(_grid_take(new, volume) <= _grid_take(old, volume), 'SCALE_TAKE_CAP')
    need(new['scale']['window']['pair_cap'] <= old['scale']['window']['pair_cap'], 'SCALE_PAIR_CAP')
    need(new['scale']['window']['participant_multiplier'] <= old['scale']['window']['participant_multiplier'], 'SCALE_PAIR_CAP')
    need(new['scale']['governance']['min_increase_delay'] >= old['scale']['governance']['min_increase_delay'], 'SCALE_NOTICE')
    from .emissions import HALVING_BLOCKS_FLOOR, slower_than
    need(slower_than(old['scale']['points']['halving_blocks'], new['scale']['points']['halving_blocks']), 'EMISSIONS_FASTER')
    need(new['scale']['points']['halving_blocks'] >= HALVING_BLOCKS_FLOOR, 'EMISSIONS_FASTER')
    cost_rose = (new['scale']['cost']['fixed_cost_per_window'] > old['scale']['cost']['fixed_cost_per_window'] or
                 new['scale']['cost']['variable_cost_per_unit'] > old['scale']['cost']['variable_cost_per_unit'])
    if cost_rose:
        need(reason in {'COST', 'SAFETY'}, 'SCALE_COST_REASON')
    flags = {'customer_share_falls': False, 'margin_cap_rises': False, 'planning_change': False}
    old_plan = _plan(old, 1, old['scale']['cost']['fixed_cost_per_window'], 0)
    new_plan = _plan(new, 1, new['scale']['cost']['fixed_cost_per_window'], 0)
    governed = ('margin_cap_bps', 'shares', 'robustness_band_bps', 'reference_unit_price', 'hurdle_bps', 'vesting_periods')
    if any(old_plan[name] != new_plan[name] for name in governed):
        change = propose_change(old_plan, new_plan, destination=new['scale']['governance']['destination'],
                                 reason=reason, effective_after_periods=1)
        need(not change['margin_cap_rises'], 'SCALE_TAKE_CAP')
        flags = {'customer_share_falls': change['customer_share_falls'], 'margin_cap_rises': False, 'planning_change': True}
    meter = state['economic_policy']['scale']
    meter['last_flags'] = flags
    state['economic_policy']['scale'] = meter
    return flags


def _balance(state, account, resource):
    table = state.get('authority_available')
    if table is None or account not in table:
        return 0
    return table[account].get(resource, 0)


def apply_scale(state, op, payload, actor, tid, height):
    """Validate a scale op and return the transfers economics.py will perform."""
    transfers = []

    def pay(src, dst, resource, amount):
        integer(amount)
        if amount:
            transfers.append((src, dst, resource, amount))

    body = live_policy(state)
    need(body is not None, 'SCALE_PROFILE_REQUIRED')
    scale = body['scale']
    # Fees, rebates, integrator cuts and ad subsidies are denominated in the fee resource.
    # Bonds and the published token schedule use supply.resource, which a genesis may set equal to it.
    fee_resource = body['resource']
    bond_resource = scale['supply']['resource']
    meter = state['economic_policy']['scale']
    if op == 'ECON_BOND_LOCK':
        exact(payload, 'amount')
        integer(payload['amount'], True)
        pay(actor, scale['accounts']['bond_escrow'], bond_resource, payload['amount'])
        bonds = dict(meter.get('bonds') or {})
        bonds[actor] = bonds.get(actor, 0) + payload['amount']
        need(len(bonds) <= EVENT_LIMIT, 'BOND_LIMIT')
        meter['bonds'] = bonds
    elif op == 'ECON_BOND_RELEASE':
        exact(payload, 'amount')
        integer(payload['amount'], True)
        bonds = dict(meter.get('bonds') or {})
        need(bonds.get(actor, 0) >= payload['amount'], 'BOND_BALANCE')
        # An open offline allowance is still backed by this bond. Releasing it would leave the limit uncovered.
        need(bonds.get(actor, 0) - payload['amount'] >= _allowance_locked(meter, actor, height), 'OFFLINE_BOND')
        pay(scale['accounts']['bond_escrow'], actor, bond_resource, payload['amount'])
        bonds[actor] -= payload['amount']
        if bonds[actor] == 0:
            del bonds[actor]
        meter['bonds'] = bonds
    elif op == 'ECON_REBATE_CLAIM':
        from .token_rebates import rebate_entitlement
        exact(payload, 'amount')
        integer(payload['amount'], True)
        claimable = rebate_entitlement(state, actor, height)['claimable']
        need(payload['amount'] <= claimable, 'REBATE_ENTITLEMENT')
        pay(scale['accounts']['rebate_pool'], actor, fee_resource, payload['amount'])
        claimed = dict(meter.get('rebate_claimed') or {})
        claimed[actor] = claimed.get(actor, 0) + payload['amount']
        meter['rebate_claimed'] = claimed
    elif op == 'ECON_INTEGRATOR_NOTE':
        exact(payload, 'agreement integrator')
        key(payload['agreement'])
        key(payload['integrator'])
        need(payload['agreement'] in state['agreements'], 'INTEGRATOR_AGREEMENT')
        agreement = state['agreements'][payload['agreement']]
        terms = agreement['terms']
        need(actor in {terms['principal'], terms['agent'], terms['counterparty']}, 'INTEGRATOR_PARTY')
        need(agreement.get('state') == 'BOUND', 'INTEGRATOR_WINDOW')
        notes = dict(meter.get('integrators') or {})
        need(payload['agreement'] not in notes and len(notes) < EVENT_LIMIT, 'INTEGRATOR_NOTE')
        notes[payload['agreement']] = {'integrator': payload['integrator'], 'height': height, 'by': actor}
        meter['integrators'] = notes
    elif op == 'ECON_INTEGRATOR_PAY':
        from .token_rebates import integrator_entitlement
        exact(payload, 'integrator amount')
        key(payload['integrator'])
        integer(payload['amount'], True)
        claimable = integrator_entitlement(state, payload['integrator'], height)['claimable']
        need(payload['amount'] <= claimable, 'INTEGRATOR_ENTITLEMENT')
        pay(scale['accounts']['integrator_pool'], payload['integrator'], fee_resource, payload['amount'])
        paid = dict(meter.get('integrator_paid') or {})
        paid[payload['integrator']] = paid.get(payload['integrator'], 0) + payload['amount']
        meter['integrator_paid'] = paid
    elif op == 'ECON_INTEGRATOR_SWEEP':
        from .token_rebates import sweepable
        exact(payload, 'amount')
        integer(payload['amount'], True)
        info = sweepable(state, height)
        need(payload['amount'] <= info['sweepable'], 'INTEGRATOR_SWEEP')
        pay(info['pool'], scale['accounts']['rebate_pool'], fee_resource, payload['amount'])
        meter['swept'] = meter.get('swept', 0) + payload['amount']
    elif op == 'ECON_AD_SUBSIDY':
        from .ad_revenue import assess_conversion
        exact(payload, 'receipt')
        receipt = dict(payload['receipt'])
        need(receipt.get('chain') == state['chain'], 'FORK_REPLAY')
        del receipt['chain']
        need(actor in {receipt.get('exchange'), receipt.get('advertiser')}, 'AD_PAYER')
        need(receipt.get('resource') == fee_resource and receipt.get('height', height) <= height, 'AD_RESOURCE')
        shares = {name: scale['ads'][name] for name in ('owner_bps', 'integrator_bps', 'subsidy_bps', 'exchange_bps')}
        split = assess_conversion(state, receipt, shares, scale['ads']['min_counterparties'])
        pay(actor, scale['accounts']['rebate_pool'], fee_resource, split['subsidy'])
        subsidies = list(meter.get('subsidies') or [])
        subsidies.append({'height': height, 'amount': split['subsidy'], 'covenant': receipt['covenant']})
        meter['subsidies'] = subsidies[-EVENT_LIMIT:]
    elif op == 'ECON_REWARD_CLAWBACK':
        _clawback(state, payload, height, scale, pay)
    elif op == 'ECON_REWARD_VEST':
        _vest(state, payload, height, scale, pay)
    elif op in {'ECON_STAKE_LOCK', 'ECON_STAKE_DELEGATE', 'ECON_STAKE_UNBOND', 'ECON_STAKE_WITHDRAW',
                'ECON_STAKE_WORK', 'ECON_STAKE_SLASH', 'ECON_STAKE_CLAIM'}:
        raise ValueError('USE_MARKET_STAKE')
    elif op in {'ECON_TREASURY_INCOME', 'ECON_TREASURY_SPEND'}:
        raise ValueError('USE_RESERVE_POT')
    elif op == 'ECON_COST_REPORT':
        _cost_report(state, body, meter, payload, actor, height)
    elif op == 'ECON_ENDOWMENT_RELEASE':
        _endowment_release(state, meter, payload, height, scale)
    elif op == 'ECON_SERVE_SETTLE':
        _serve_settle(state, body, meter, payload, height, scale, fee_resource, pay)
    elif op == 'ECON_SERVE_VEST':
        _serve_vest(state, meter, payload, height, scale, fee_resource, pay)
    elif op == 'ECON_SERVE_FORFEIT':
        _serve_forfeit(state, body, meter, payload, actor, height, scale)
    elif op in {'ECON_LIGHT_FETCH', 'ECON_RELAY_FETCH'}:
        _fetch(state, meter, payload, actor, height, scale)
    elif op == 'ECON_OFFLINE_ALLOWANCE':
        _offline_allowance(state, meter, payload, actor, height)
    elif op == 'ECON_OFFLINE_SPEND':
        _offline_spend(state, meter, payload, height, scale, bond_resource, pay)
    elif op == 'ECON_OFFLINE_EQUIVOCATION':
        _offline_equivocation(state, meter, payload, height, scale, bond_resource, pay)
    elif op in {'ECON_FOUNDER_PAYOUTS', 'ECON_FOUNDER_FORFEIT', 'ECON_UPGRADE_VOTE', 'ECON_UPGRADE_ACTIVATE'}:
        # Ending the founder shadow is a governance act, like a cost report.
        need(op != 'ECON_FOUNDER_PAYOUTS' or actor in body['governors'], 'FOUNDER_PAYOUTS_SIGNER')
        _extend(state, op, payload, actor, height, scale, meter, bond_resource, fee_resource, pay)
    else:
        raise ValueError('UNKNOWN_ECONOMIC_OPERATION')
    state['economic_policy']['scale'] = meter
    return transfers


def _clawback(state, payload, height, scale, pay):
    from .pledge_drop import clawback_due
    exact(payload, 'campaign claim')
    key(payload['campaign'])
    key(payload['claim'])
    need(payload['campaign'] in state['reward_campaigns'] and payload['claim'] in state['reward_claims'], 'REWARD_CLAWBACK')
    campaign = state['reward_campaigns'][payload['campaign']]
    claim = state['reward_claims'][payload['claim']]
    need(claim['campaign'] == payload['campaign'], 'REWARD_CLAWBACK')
    need(clawback_due(state, claim, campaign, height, scale), 'CLAWBACK_NOT_DUE')
    held = claim.get('held_remaining', 0)
    campaign['held'] = campaign.get('held', 0) - held
    need(campaign['held'] >= 0, 'REWARD_HELD')
    campaign['remaining'] += held
    claim['held_remaining'] = 0
    unlocked = claim.get('unlocked', 0) + claim.get('released', 0) - claim.get('recovered', 0)
    recover = min(unlocked, _balance(state, claim['recipient'], campaign['resource']))
    if recover:
        pay(claim['recipient'], campaign['escrow'], campaign['resource'], recover)
    claim['recovered'] = claim.get('recovered', 0) + recover
    claim['shortfall'] = unlocked - claim['recovered']
    claim['clawed'] = True
    # Unvested units never left escrow. Recovered unlocked units join them.
    # Together they are the pool the issuer reclaims after expiry. A shortfall
    # is the part the recipient no longer holds; it is recorded, not minted.
    campaign['remaining'] += recover
    if campaign.get('closed') and campaign['remaining']:
        back = campaign['remaining']
        pay(campaign['escrow'], campaign['issuer'], campaign['resource'], back)
        campaign['returned'] = campaign.get('returned', 0) + back
        campaign['remaining'] = 0
    state['reward_campaigns'][payload['campaign']] = campaign
    state['reward_claims'][payload['claim']] = claim


def _vest(state, payload, height, scale, pay):
    from .pledge_drop import clawback_due, vest_release
    exact(payload, 'campaign claim')
    key(payload['campaign'])
    key(payload['claim'])
    need(payload['campaign'] in state['reward_campaigns'] and payload['claim'] in state['reward_claims'], 'REWARD_VEST')
    campaign = state['reward_campaigns'][payload['campaign']]
    claim = state['reward_claims'][payload['claim']]
    need(claim['campaign'] == payload['campaign'] and not claim.get('clawed'), 'REWARD_VEST')
    need(not clawback_due(state, claim, campaign, height, scale), 'CLAWBACK_DUE')
    release = vest_release(claim, height, scale['points']['vest_blocks'])
    need(release > 0 and claim.get('held_remaining', 0) >= release, 'VEST_NOTHING_DUE')
    pay(campaign['escrow'], claim['recipient'], campaign['resource'], release)
    claim['held_remaining'] -= release
    claim['released'] = claim.get('released', 0) + release
    campaign['held'] = campaign.get('held', 0) - release
    need(campaign['held'] >= 0, 'REWARD_HELD')
    state['reward_campaigns'][payload['campaign']] = campaign
    state['reward_claims'][payload['claim']] = claim


def measured_unit_cost(fixed, variable, units):
    """Ceiling of (fixed + variable × units) / units. The report does not name the unit cost."""
    integer(fixed)
    integer(variable)
    integer(units, True)
    total = fixed + variable * units
    integer(total)
    return (total + units - 1) // units


def _cost_report(state, body, meter, payload, actor, height):
    """One governor-signed observation per epoch, appended to the revenue ledger.

    The transaction signature is the governor's signature. Nothing here moves a
    balance. A drop records the users' half on the same ledger and lowers the
    price ceiling. A later report cannot lift that ceiling.
    """
    from .token_invariants import user_saving
    from .revenue_ledger import record
    exact(payload, 'chain epoch fixed variable units')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    need(actor in body['governors'], 'COST_REPORT_SIGNER')
    integer(payload['epoch'])
    current = height // body['scale']['points']['epoch_blocks']
    need(payload['epoch'] == current and meter.get('reported_epoch') != current, 'COST_REPORT_EPOCH')
    unit = measured_unit_cost(payload['fixed'], payload['variable'], payload['units'])
    previous = meter.get('reported_unit_cost')
    owed = 0
    gross = unit
    if type(previous) is int:
        meter['previous_reported_unit_cost'] = previous
        gross = previous
        if unit < previous:
            owed = user_saving(previous, unit)
            ceiling = previous - owed
            stored = meter.get('ratchet_ceiling')
            meter['ratchet_ceiling'] = ceiling if type(stored) is not int else min(stored, ceiling)
            meter['savings_to_users'] = meter.get('savings_to_users', 0) + owed
            drop = previous - unit
            meter['savings_returned_bps'] = 0 if drop == 0 else owed * 10000 // drop
    meter['reported_unit_cost'] = unit
    meter['reported_epoch'] = current
    record(meter, height, 'cost_report', 'ECON_COST_REPORT', gross, unit, 0, owed, 0, 0, 0, revenue=False)


def _chain_ok(state, payload):
    need(type(payload) is dict and payload.get('chain') == state['chain'], 'FORK_REPLAY')


def _max_lock(scale):
    return 1460 * scale['window']['blocks_per_day']


def _extend(state, op, payload, actor, height, scale, meter, bond_resource, fee_resource, pay):
    from .shariah_mode import screen_op
    screen_op(scale, op)
    _chain_ok(state, payload)
    if op == 'ECON_FOUNDER_PAYOUTS':
        exact(payload, 'chain')
        need(meter.get('founder_shadow') is True, 'FOUNDER_PAYOUTS')
        meter['founder_shadow'] = False
    elif op == 'ECON_FOUNDER_FORFEIT':
        exact(payload, 'chain amount')
        _forfeit_founder(state, meter, actor, payload, height, scale, bond_resource, pay)
    elif op == 'ECON_UPGRADE_VOTE':
        from .upgrade_gate import cast_vote
        exact(payload, 'chain proposal activation')
        cast_vote(meter, actor, state['domain']['active']['validators'], payload['proposal'], payload['activation'], height)
    elif op == 'ECON_UPGRADE_ACTIVATE':
        from .upgrade_gate import ready
        exact(payload, 'chain proposal faults')
        integer(payload['faults'], True)
        key(payload['proposal'])
        ready(meter, payload['proposal'], state['domain']['active']['validators'], payload['faults'], height)
    elif op == 'ECON_TREASURY_INCOME':
        from .treasury import credit_income
        exact(payload, 'chain source amount')
        need(actor == scale['accounts']['waqf'] or actor == scale['accounts']['founder'], 'WAQF_INCOME')
        raise ValueError('USE_RESERVE_POT')
    else:
        raise ValueError('UNKNOWN_ECONOMIC_OPERATION')


def _credit_work(state, meter, actor, payload, height):
    from .staking import work_credit
    from .kept_promises import honoured
    subject = payload['subject']
    key(subject)
    need(actor in (meter.get('positions') or {}), 'STAKE_OPERATOR')
    role = meter['positions'][actor]['role']
    vote = payload['vote']
    if role == 'VALIDATOR':
        exact(vote, 'body signature')
        exact(vote['body'], 'chain height block_id')
        need(vote['body']['chain'] == state['chain'], 'FORK_REPLAY')
        need(vote['body']['block_id'] == subject, 'STAKE_WORK')
        integer(vote['body']['height'], True)
        from .crypto import verify
        verify(actor, 'COVENANT-STAKE-VOTE-0.1', vote['body'], vote['signature'])
    elif role == 'REFEREE':
        need(vote is None, 'STAKE_WORK')
        agreement = state['agreements'][subject]
        decision = agreement.get('decision') or {}
        need(decision.get('actor') == actor and decision.get('result') in {'SUPPORTED', 'REFUTED', 'INDETERMINATE'}, 'STAKE_WORK')
    elif role == 'AD_ATTESTER':
        need(vote is None, 'STAKE_WORK')
        need(honoured(state['agreements'][subject]), 'STAKE_WORK')
    else:
        need(False, 'STAKE_ROLE')
    work_credit(meter, actor, subject)


def _slash(state, meter, payload, height, scale, bond_resource, pay):
    """Kept for market.py to call. This module does not move stake."""
    from .staking import apply_slash, prove_double_sign, prove_false_attestation, prove_no_ruling
    from .kept_promises import honoured
    exact(payload, 'chain operator fault evidence')
    key(payload['operator'])
    need(payload['fault'] in {'DOUBLE_SIGN', 'FALSE_ATTESTATION', 'NO_RULING'}, 'STAKE_FAULT')
    evidence = payload['evidence']
    exact(evidence, 'id harmed first second covenant claimed')
    key(evidence['id'])
    key(evidence['harmed'])
    log = list(meter.get('slash_log') or [])
    need(evidence['id'] not in log and len(log) < 4096, 'STAKE_SLASH_REPLAY')
    if payload['fault'] == 'DOUBLE_SIGN':
        prove_double_sign(payload['operator'], evidence['first'], evidence['second'])
        need(evidence['first']['body']['chain'] == state['chain'], 'FORK_REPLAY')
    elif payload['fault'] == 'FALSE_ATTESTATION':
        key(evidence['covenant'])
        prove_false_attestation(evidence['claimed'], honoured(state['agreements'][evidence['covenant']]))
    else:
        key(evidence['covenant'])
        agreement = state['agreements'][evidence['covenant']]
        prove_no_ruling(agreement.get('state'), agreement['terms']['deadline'], height,
                        agreement['terms']['resolver'], payload['operator'])
    parts = apply_slash(meter, payload['operator'])
    need(parts is not None, 'STAKE_SLASH')
    # Slash proceeds stay inside the market reserve. market._slash already credits it.
    parts['moved_by'] = 'market.STAKE_SLASH'
    log.append(evidence['id'])
    meter['slash_log'] = log


def _forfeit_founder(state, meter, actor, payload, height, scale, bond_resource, pay):
    from .treasury import forfeiture
    from .vesting import founder_token_status
    from .kept_promises import honoured_rows, usage_snapshot
    integer(payload['amount'], True)
    locked = dict(meter.get('founder_locked') or {})
    amount = locked.get('amount', 0)
    usage = usage_snapshot(honoured_rows(state, height), height, scale['window']['blocks_per_day'])
    status = founder_token_status(amount, scale['vesting'], scale['window']['blocks_per_day'], height, usage)
    need(payload['amount'] <= status['forfeit'] and payload['amount'] > 0, 'FOUNDER_FORFEIT')
    # One pot: the published RESERVE beneficiary. Not a second waqf ledger.
    pay(scale['accounts']['founder_vest'], scale['accounts']['reserve'], bond_resource, payload['amount'])
    forfeiture(meter, payload['amount'])
    locked['amount'] = amount - payload['amount']
    locked['forfeited'] = locked.get('forfeited', 0) + payload['amount']
    meter['founder_locked'] = locked


def _epoch_of(height, scale):
    return height // scale['points']['epoch_blocks']


def _allowance_locked(meter, actor, height):
    locked = 0
    for row in (meter.get('offline_allowances') or {}).values():
        if row.get('actor') == actor and not row.get('slashed') and height <= row.get('until', 0):
            locked += row.get('remaining', 0)
    return locked


def _endowment_release(state, meter, payload, height, scale):
    """Pay remaining // 64 once per epoch. The founder was taken when the fee funded the pool."""
    from .revenue_ledger import record
    from .serving_rewards import release_per_epoch
    exact(payload, 'chain')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    epoch = _epoch_of(height, scale)
    need(meter.get('endowment_epoch') != epoch, 'ENDOWMENT_EPOCH')
    remaining = meter.get('endowment_remaining', 0)
    integer(remaining)
    release = release_per_epoch(remaining)
    meter['endowment_remaining'] = remaining - release
    meter['endowment_claimable'] = meter.get('endowment_claimable', 0) + release
    meter['endowment_epoch'] = epoch
    record(meter, height, 'serving_reward', 'ECON_ENDOWMENT_RELEASE', release, 0, 0, release, 0, 0,
           _band(meter.get('rolling_gross', 0)), revenue=False)


def _serve_settle(state, body, meter, payload, height, scale, fee_resource, pay):
    from .serving_rewards import BATCH_LIMIT, ROLES, VEST_EPOCHS, holdback, host_weight, water_fill
    exact(payload, 'chain hosts')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    epoch = _epoch_of(height, scale)
    need(meter.get('serve_epoch') != epoch, 'SERVE_EPOCH')
    hosts = payload['hosts']
    need(type(hosts) is list and 1 <= len(hosts) <= BATCH_LIMIT, 'SERVE_BATCH')
    seen = set()
    weights = []
    for row in hosts:
        exact(row, 'host role stored_kib passes audits epochs operator_shards archive_shards bandwidth')
        key(row['host'])
        need(row['role'] in ROLES, 'SERVE_ROLE')
        need(row['host'] not in seen, 'SERVE_HOST')
        seen.add(row['host'])
        weights.append(host_weight(row['stored_kib'], row['passes'], row['audits'], row['epochs'],
                                   row['operator_shards'], row['archive_shards'], row['bandwidth']))
    claimable = meter.get('endowment_claimable', 0)
    integer(claimable)
    pays = water_fill(claimable, weights)
    paid_sum = sum(pays)
    need(paid_sum <= claimable, 'SERVE_CONSERVATION')
    paid_now = []
    held = []
    for amount in pays:
        now, later = holdback(amount)
        paid_now.append(now)
        held.append(later)
    pool = scale['accounts']['archive_pool']
    need(_balance(state, pool, fee_resource) >= sum(paid_now), 'SERVE_POOL')
    holds = dict(meter.get('serve_holds') or {})
    for index, row in enumerate(hosts):
        if paid_now[index]:
            pay(pool, row['host'], fee_resource, paid_now[index])
        if held[index]:
            hold_id = digest('COVENANT-SERVE-HOLD', {'epoch': epoch, 'host': row['host'], 'seq': index})
            need(hold_id not in holds and len(holds) < EVENT_LIMIT, 'SERVE_HOLD')
            holds[hold_id] = {'host': row['host'], 'amount': held[index], 'epoch': epoch,
                              'until_epoch': epoch + VEST_EPOCHS, 'forfeited': False, 'vested': False}
    meter['serve_holds'] = holds
    meter['endowment_claimable'] = claimable - paid_sum
    meter['serve_epoch'] = epoch


def _serve_vest(state, meter, payload, height, scale, fee_resource, pay):
    exact(payload, 'chain hold')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    key(payload['hold'])
    holds = dict(meter.get('serve_holds') or {})
    hold = holds.get(payload['hold'])
    need(hold is not None and not hold['forfeited'] and not hold['vested'], 'SERVE_VEST')
    need(_epoch_of(height, scale) >= hold['until_epoch'], 'SERVE_VEST')
    pay(scale['accounts']['archive_pool'], hold['host'], fee_resource, hold['amount'])
    hold['vested'] = True
    holds[payload['hold']] = hold
    meter['serve_holds'] = holds


def _serve_forfeit(state, body, meter, payload, actor, height, scale):
    exact(payload, 'chain hold')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    need(actor in body['governors'], 'SERVE_FORFEIT')
    key(payload['hold'])
    holds = dict(meter.get('serve_holds') or {})
    hold = holds.get(payload['hold'])
    need(hold is not None and not hold['forfeited'] and not hold['vested'], 'SERVE_FORFEIT')
    integer(height)
    hold['forfeited'] = True
    holds[payload['hold']] = hold
    meter['serve_holds'] = holds
    meter['endowment_remaining'] = meter.get('endowment_remaining', 0) + hold['amount']


def _fetch(state, meter, payload, actor, height, scale):
    exact(payload, 'chain')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    epoch = _epoch_of(height, scale)
    fetches = dict(meter.get('free_fetches') or {})
    row = dict(fetches.get(actor) or {})
    count = row.get('count', 0) if row.get('epoch') == epoch else 0
    integer(count)
    fetches[actor] = {'epoch': epoch, 'count': count + 1}
    need(len(fetches) <= EVENT_LIMIT, 'FETCH_LIMIT')
    meter['free_fetches'] = fetches


def _offline_allowance(state, meter, payload, actor, height):
    exact(payload, 'chain device limit until')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    key(payload['device'])
    integer(payload['limit'], True)
    integer(payload['until'])
    need(payload['until'] >= height, 'OFFLINE_EXPIRED')
    bonds = meter.get('bonds') or {}
    need(payload['limit'] <= bonds.get(actor, 0), 'OFFLINE_BOND')
    allowances = dict(meter.get('offline_allowances') or {})
    current = allowances.get(payload['device'])
    need(current is None or current.get('slashed') or height > current.get('until', 0), 'OFFLINE_ALLOWANCE')
    allowances[payload['device']] = {'actor': actor, 'limit': payload['limit'], 'remaining': payload['limit'],
                                     'until': payload['until'], 'serials': {}, 'slashed': False}
    need(len(allowances) <= EVENT_LIMIT, 'OFFLINE_ALLOWANCE')
    meter['offline_allowances'] = allowances


def _offline_spend(state, meter, payload, height, scale, bond_resource, pay):
    from .crypto import verify
    from .offline_value import LABEL, excess
    exact(payload, 'chain statement signature')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    statement = payload['statement']
    exact(statement, 'chain device serial amount payee')
    need(statement['chain'] == state['chain'], 'FORK_REPLAY')
    key(statement['device'])
    key(statement['payee'])
    integer(statement['serial'])
    integer(statement['amount'], True)
    verify(statement['device'], LABEL, statement, payload['signature'])
    allowances = dict(meter.get('offline_allowances') or {})
    row = dict(allowances.get(statement['device']) or {})
    need(row and not row.get('slashed'), 'OFFLINE_ALLOWANCE')
    need(height <= row['until'], 'OFFLINE_EXPIRED')
    serials = dict(row.get('serials') or {})
    serial = str(statement['serial'])
    need(serial not in serials, 'OFFLINE_SERIAL')
    serials[serial] = statement['payee']
    need(len(serials) <= EVENT_LIMIT, 'OFFLINE_SERIAL')
    over = excess(statement['amount'], row['remaining'])
    row['remaining'] = row['remaining'] - (statement['amount'] - over)
    bonds = dict(meter.get('bonds') or {})
    actor = row['actor']
    moved = min(over, bonds.get(actor, 0))
    if moved:
        pay(scale['accounts']['bond_escrow'], statement['payee'], bond_resource, moved)
        bonds[actor] -= moved
        if bonds[actor] == 0:
            del bonds[actor]
        meter['bonds'] = bonds
    row['serials'] = serials
    allowances[statement['device']] = row
    meter['offline_allowances'] = allowances


def _offline_equivocation(state, meter, payload, height, scale, bond_resource, pay):
    from .crypto import verify
    from .offline_value import LABEL, conflicts, slash_amount
    exact(payload, 'chain first second')
    need(payload['chain'] == state['chain'], 'FORK_REPLAY')
    integer(height)
    first = _signed_spend(payload['first'], state['chain'])
    second = _signed_spend(payload['second'], state['chain'])
    verify(first['device'], LABEL, first, payload['first']['signature'])
    verify(second['device'], LABEL, second, payload['second']['signature'])
    need(conflicts(first, second), 'OFFLINE_EQUIVOCATION')
    allowances = dict(meter.get('offline_allowances') or {})
    row = dict(allowances.get(first['device']) or {})
    need(row and not row.get('slashed'), 'OFFLINE_ALLOWANCE')
    bonds = dict(meter.get('bonds') or {})
    actor = row['actor']
    moved = slash_amount(bonds.get(actor, 0))
    if moved:
        pay(scale['accounts']['bond_escrow'], second['payee'], bond_resource, moved)
        del bonds[actor]
        meter['bonds'] = bonds
    row['slashed'] = True
    row['remaining'] = 0
    allowances[first['device']] = row
    meter['offline_allowances'] = allowances


def _signed_spend(envelope, chain):
    exact(envelope, 'statement signature')
    statement = envelope['statement']
    exact(statement, 'chain device serial amount payee')
    need(statement['chain'] == chain, 'FORK_REPLAY')
    key(statement['device'])
    key(statement['payee'])
    integer(statement['serial'])
    integer(statement['amount'], True)
    need(type(envelope['signature']) is str, 'SIGNATURE_ENCODING')
    return statement
