"""Pure conservation algebra, independent of application-specific pools.

Adapters supply quantities; only explicitly adopted native code may do so.
This is not an open plug-in loader or a new consensus profile.
"""
from .crypto import need


def conserved(supply, partitions):
    for resource,total in supply.items():
        need(sum(part.get(resource,0) for part in partitions)==total,'RESOURCE_CONSERVATION')


def balanced(deltas,code='RESOURCE_CONSERVATION'):
    need(all(value==0 for value in deltas.values()),code)
