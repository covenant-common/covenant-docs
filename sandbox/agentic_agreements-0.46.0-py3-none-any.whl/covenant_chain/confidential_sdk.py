"""Offline confidential wallet helpers. No custody or finality is implied.

Prepared signed envelopes can travel over arbitrary media. Returned PRIVATE
openings/keys belong in caller-controlled encrypted storage, never public logs.
"""
from copy import deepcopy
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from . import app, confidential as c, shielded
from .crypto import public_key, need, integer, key
from .economics import policy_at


def _prepare(state, op, outputs, secret, height, max_fee, memo, **inputs):
    need(state.get('protocol') in {app.CONFIDENTIAL_VERSION,app.CONTINUITY_VERSION,app.MARKET_VERSION,app.REVIEW_VERSION,app.PREDICTION_VERSION}, 'CONFIDENTIAL_PROFILE')
    integer(height, True); integer(max_fee)
    actor_key = Ed25519PrivateKey.generate(); actor = public_key(actor_key)
    chosen = policy_at(state, height)
    fee = {'policy': chosen['id'], 'max_amount': max_fee, 'sponsor': None}
    payload, openings, _ = c.make_transition(state, op, actor, fee, height, outputs,
                                            spend_secret=secret, memo=memo, **inputs)
    tx = app.make_transaction(actor_key, state['chain'], 0, op, payload,
                              protocol=state['protocol'], fee=fee)
    return {'transaction': tx, 'private_outputs': openings, 'status': 'PREPARED_NOT_FINAL',
            'privacy': 'AMOUNTS_OWNERS_HIDDEN_PUBLIC_POOL_FEE_RELAY_TIMING'}


def _unprepared(state, code):
    if type(state) is list:
        raise ValueError(code)
    from .surface import not_committed
    return not_committed(code)


def prepare_claim(state, campaign=None, opening=None, spend_secret=None, *, height=None, max_fee=None, memo='0' * 64):
    if type(state) is not dict or campaign is None or type(opening) is not dict or spend_secret is None or height is None or max_fee is None:
        return _unprepared(state, 'CLAIM_FIELDS')
    chosen = policy_at(state, height); fee = c.fee_amount(chosen, 'CONFIDENTIAL_CLAIM')
    amount = opening['grant']['amount']; need(amount > fee, 'CONFIDENTIAL_DUST')
    owner = c.owner_id(spend_secret)
    return _prepare(state, 'CONFIDENTIAL_CLAIM', [{'owner': owner, 'quantity': amount - fee},
        {'owner': owner, 'quantity': 0}], spend_secret, height, max_fee, memo,
        campaign=campaign, opening=opening)


def prepare_transfer(state, pool=None, input_note=None, spend_secret=None, recipient_owner=None, quantity=None, *, height=None, max_fee=None, memo='0' * 64):
    if type(state) is not dict or pool is None or type(input_note) is not dict or spend_secret is None or recipient_owner is None or quantity is None or height is None or max_fee is None:
        return _unprepared(state, 'TRANSFER_FIELDS')
    c.u32(quantity, True); chosen = policy_at(state, height)
    fee = c.fee_amount(chosen, 'CONFIDENTIAL_TRANSFER')
    need(input_note['quantity'] >= quantity + fee, 'CONFIDENTIAL_INSUFFICIENT_FUNDS')
    note = deepcopy(input_note); need(note.get('pool', pool) == pool, 'CONFIDENTIAL_POOL'); note['pool'] = pool
    return _prepare(state, 'CONFIDENTIAL_TRANSFER', [{'owner': c.field(recipient_owner), 'quantity': quantity},
        {'owner': c.owner_id(spend_secret), 'quantity': input_note['quantity'] - quantity - fee}],
        spend_secret, height, max_fee, memo, input_note=note)


def prepare_public_exit(state, pool=None, input_note=None, spend_secret=None, *, height=None, max_fee=None, memo='0' * 64):
    """Explicit public exit: gross amount/destination become PUBLIC.

    Withdraw into a fresh account, then pay the ordinary public fee from that
    account. The returned private account key is needed to control the funds.
    """
    if type(state) is not dict or pool is None or type(input_note) is not dict or spend_secret is None or height is None or max_fee is None:
        return _unprepared(state, 'EXIT_FIELDS')
    from .economics import quote
    need(state.get('protocol') in {app.CONFIDENTIAL_VERSION,app.CONTINUITY_VERSION,app.MARKET_VERSION,app.REVIEW_VERSION,app.PREDICTION_VERSION}, 'CONFIDENTIAL_PROFILE')
    # The reducer refuses these; refuse them before spending a proof on them.
    integer(height, True); integer(max_fee); key(memo)
    k = Ed25519PrivateKey.generate(); actor = public_key(k)
    owner = c.owner_id(spend_secret)
    payload, outputs = shielded.make_transition(state['chain'], pool, 'SHIELD_WITHDRAW', actor, 0,
        [{'owner': owner, 'quantity': 0}, {'owner': owner, 'quantity': 0}],
        notes=state['shielded_pools'][pool]['notes'], input_note=input_note, spend_secret=spend_secret,
        quantity=input_note['quantity'], destination=actor, memo=memo)
    chosen = policy_at(state, height)
    need(chosen['body']['resource'] == pool, 'CONFIDENTIAL_FEE_RESOURCE')
    fee = {'policy': chosen['id'], 'max_amount': max_fee, 'sponsor': None}
    tx = app.make_transaction(k, state['chain'], 0, 'SHIELD_WITHDRAW', payload,
                             protocol=state['protocol'], fee=fee)
    quoted = quote(chosen['body'], tx)['amount']
    need(quoted <= max_fee, 'FEE_CAP')
    need(input_note['quantity'] > quoted, 'CONFIDENTIAL_DUST')
    return {'transaction': tx, 'private_outputs': outputs, 'private_account_key': k.private_bytes_raw().hex(),
            'public_account': actor, 'status': 'PREPARED_NOT_FINAL', 'privacy': 'PUBLIC_AMOUNT_AND_DESTINATION'}


def capabilities():
    return {'confidential_claims': True, 'hidden_fee_funding': True, 'private_transfers': True,
            'private_portable_agreements': True, 'trustless_private_judgment_escrow': False,
            'network_origin_protection': False, 'post_quantum_zk': False,
            'monero_equivalence_established': False, 'maximum_notes': 1024,
            'production_audit': False, 'public_mainnet_ready': False}
