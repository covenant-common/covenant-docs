"""Accreditation types for markets, as data (covenant-market-accreditation/0.1).

Each type says what an adopted assessor records when it checks a lender, broker,
insurance producer, investor, business, agent or software build: the fields, the
verification methods, the date that ages, the evidence it keeps, the real-world
source of truth and what AAP does not check. AAP never checks a register itself.
It carries and checks the signed evidence of whoever did, and states its age.

A market qualification is an ordinary ``covenant-agent-accreditation`` claim:

* ``qualification`` is the type id (for example ``lender-licence``);
* ``profile`` is ``covenant-market-accreditation/0.1``;
* ``artifact`` is the assessed build's digest, or for a business or person the
  digest ``subject_artifact(scheme, identifier)`` of its register identifier;
* the type's fields travel as ``details`` in the selective-disclosure form
  (``covenant-agent-accreditation-sd/0.1``), with ``method`` and ``coverage``.

``requirement`` gives the demand exchange's eligibility check for lenders,
brokers, insurance producers and investors; ``match`` compares disclosed claims
with it exactly. Jurisdictions match as written: a national licence is not
inferred to cover a state, nor one product another.
"""
from copy import deepcopy
import re

from .crypto import digest, integer, need

VERSION = 'covenant-market-accreditation/0.1'
LABEL = 'COVENANT-MARKET-ACCREDITATION-0.1'
JURISDICTION = re.compile(r'[A-Z]{2}(?:-[A-Z0-9]{1,3})?\Z')
RISKS = ('LOW', 'MEDIUM', 'HIGH')
_LIMITS = ['the register entry or document itself, or that it is still current',
           'legal sufficiency for the relying party\'s own obligations',
           'the competence, independence or honesty of the assessor beyond what it declared',
           'any authority to sign, spend or bind']
_CHECKS = ['the adopted assessor\'s signature under a pinned key version',
           'holder control of the bound key, over the relying party\'s audience and challenge',
           'the disclosed type, details, method, date and coverage against the requirement',
           'status against a signed snapshot whose age is stated']

# ``details`` maps a field to (kind, required[, choices]). Kinds: jurisdiction, text, texts, time, hex, int, enum.
TYPES = (
    {'id': 'lender-licence', 'title': 'Lender licence by jurisdiction and product', 'subjects': ['BUSINESS', 'INDIVIDUAL'],
     'details': {'jurisdiction': ('jurisdiction', True), 'products': ('texts', True), 'licence_number': ('text', False),
                 'register': ('enum', True, ('NMLS', 'FCA_REGISTER', 'STATE_REGULATOR', 'OTHER_REGISTER')),
                 'register_entry': ('text', False), 'checked_at': ('time', True)},
     'date_field': 'checked_at', 'methods': ['REGISTER_LOOKUP', 'REGULATOR_CONFIRMATION', 'DOCUMENT_REVIEW'],
     'evidence': ['register extract digest', 'licence document digest'],
     'source_of_truth': 'US state licences: the licensing state regulator, most through NMLS Consumer Access; UK: the '
                        'FCA Financial Services Register; elsewhere: the licensing authority\'s public register.',
     'does_not_check': ['that the licence covers a loan beyond the recorded jurisdiction and products']},
    {'id': 'broker-licence', 'title': 'Broker licence or registration', 'subjects': ['BUSINESS', 'INDIVIDUAL'],
     'details': {'jurisdiction': ('jurisdiction', True), 'licence_class': ('text', True), 'products': ('texts', False),
                 'licence_number': ('text', False),
                 'register': ('enum', True, ('NMLS', 'FINRA_BROKERCHECK', 'SEC_IAPD', 'FCA_REGISTER', 'STATE_REGULATOR',
                                             'OTHER_REGISTER')),
                 'register_entry': ('text', False), 'checked_at': ('time', True)},
     'date_field': 'checked_at', 'methods': ['REGISTER_LOOKUP', 'REGULATOR_CONFIRMATION', 'DOCUMENT_REVIEW'],
     'evidence': ['register extract digest'],
     'source_of_truth': 'US mortgage brokers: NMLS Consumer Access; US broker-dealers and their representatives: FINRA '
                        'BrokerCheck; investment advisers: SEC Investment Adviser Public Disclosure; UK: the FCA '
                        'Financial Services Register.',
     'does_not_check': ['disciplinary history beyond what the assessor recorded']},
    {'id': 'insurance-producer-licence', 'title': 'Insurance producer licence', 'subjects': ['BUSINESS', 'INDIVIDUAL'],
     'details': {'jurisdiction': ('jurisdiction', True), 'lines': ('texts', True), 'licence_number': ('text', False),
                 'national_producer_number': ('text', False),
                 'register': ('enum', True, ('NIPR_PDB', 'STATE_INSURANCE_DEPARTMENT', 'FCA_REGISTER', 'OTHER_REGISTER')),
                 'checked_at': ('time', True)},
     'date_field': 'checked_at', 'methods': ['REGISTER_LOOKUP', 'REGULATOR_CONFIRMATION'],
     'evidence': ['register extract digest'],
     'source_of_truth': 'US: the state insurance department, with multi-state data in the NAIC National Insurance '
                        'Producer Registry (NIPR) Producer Database; UK insurance intermediaries: the FCA Financial '
                        'Services Register.',
     'does_not_check': ['appointments by particular insurers']},
    {'id': 'accredited-investor', 'title': 'Accredited investor (US Regulation D, Rule 506(c))',
     'subjects': ['BUSINESS', 'INDIVIDUAL'],
     'details': {'regime': ('enum', True, ('US_SEC_RULE_506C',)), 'basis': ('text', True),
                 'verifier_role': ('enum', True, ('REGISTERED_BROKER_DEALER', 'SEC_REGISTERED_INVESTMENT_ADVISER',
                                                  'LICENSED_ATTORNEY', 'CERTIFIED_PUBLIC_ACCOUNTANT', 'ISSUER', 'OTHER')),
                 'verified_at': ('time', True)},
     'date_field': 'verified_at',
     'methods': ['INCOME_TAX_FORMS', 'NET_WORTH_STATEMENTS', 'THIRD_PARTY_CONFIRMATION',
                 'PRIOR_506B_INVESTOR_CERTIFICATION', 'PREVIOUSLY_VERIFIED_REPRESENTATION',
                 'MINIMUM_INVESTMENT_REPRESENTATIONS', 'OTHER_REASONABLE_STEPS'],
     'method_sources': {
         'INCOME_TAX_FORMS': '17 CFR 230.506(c)(2)(ii)(A): IRS forms for the two most recent years and a written representation',
         'NET_WORTH_STATEMENTS': '17 CFR 230.506(c)(2)(ii)(B): asset and liability documents dated within the prior three months',
         'THIRD_PARTY_CONFIRMATION': '17 CFR 230.506(c)(2)(ii)(C): written confirmation within the prior three months from a '
                                     'registered broker-dealer, SEC-registered investment adviser, licensed attorney or CPA',
         'PRIOR_506B_INVESTOR_CERTIFICATION': '17 CFR 230.506(c)(2)(ii)(D): certification by an earlier Rule 506(b) investor',
         'PREVIOUSLY_VERIFIED_REPRESENTATION': '17 CFR 230.506(c)(2)(ii)(E): representation within five years of a verification',
         'MINIMUM_INVESTMENT_REPRESENTATIONS': 'SEC staff no-action letter to Latham & Watkins, 12 March 2025 (Corporation '
                                               'Finance C&DI 256.36): minimum investment amounts with written representations',
         'OTHER_REASONABLE_STEPS': '17 CFR 230.506(c)(2)(ii): the listed methods are non-exclusive'},
     'relying_party_max_age_hint': 90 * 86400,
     'evidence': ['verification letter digest', 'written representation digest'],
     'source_of_truth': 'US Regulation D: 17 CFR 230.501(a) definitions and 17 CFR 230.506(c)(2)(ii) verification methods. '
                        'The relying party sets its own maximum age; three months is the window the rule names for '
                        'net-worth documents and third-party confirmations.',
     'does_not_check': ['the documents behind the verification', 'whether the steps were reasonable for a particular offering',
                        'whether the investor\'s status changed after the verification date']},
    {'id': 'kyb', 'title': 'Know your business check', 'subjects': ['BUSINESS'],
     'details': {'provider': ('text', True), 'entity_identifier': ('text', True),
                 'identifier_scheme': ('enum', True, ('LEI', 'COMPANY_REGISTRY', 'TAX_REGISTRY', 'OTHER')),
                 'jurisdiction': ('jurisdiction', True), 'checked_at': ('time', True)},
     'date_field': 'checked_at', 'methods': ['REGISTRY_MATCH', 'DOCUMENT_REVIEW', 'PROVIDER_REPORT'],
     'evidence': ['provider report digest'],
     'source_of_truth': 'Official company registers (for example UK Companies House) and the Global LEI System (GLEIF, '
                        'ISO 17442 Legal Entity Identifiers), as read by the named KYB provider.',
     'does_not_check': ['beneficial ownership beyond what the provider recorded']},
    {'id': 'aml-programme', 'title': 'Anti-money-laundering programme attestation', 'subjects': ['BUSINESS'],
     'details': {'jurisdiction': ('jurisdiction', True), 'framework': ('text', True),
                 'attestation_kind': ('enum', True, ('SELF_ATTESTATION', 'INDEPENDENT_TEST', 'REGULATOR_EXAMINATION')),
                 'period_end': ('time', True), 'attested_at': ('time', True)},
     'date_field': 'attested_at', 'methods': ['SELF_ATTESTATION_RECORDED', 'INDEPENDENT_TEST_REPORT', 'EXAMINATION_LETTER'],
     'evidence': ['attestation or test report digest'],
     'source_of_truth': 'The programme rules of the attesting entity\'s regulator, for example the US Bank Secrecy Act rules '
                        'in 31 CFR chapter X or the UK Money Laundering Regulations 2017.',
     'does_not_check': ['that the programme operates effectively day to day']},
    {'id': 'agent-conformance', 'title': 'Agent or software conformance', 'subjects': ['AGENT', 'SOFTWARE', 'SERVICE'],
     'details': {'profile_tested': ('text', True), 'suite': ('text', True), 'suite_digest': ('hex', True),
                 'version': ('text', True)},
     'date_field': None, 'methods': ['SUITE_RUN', 'INDEPENDENT_REPLAY'],
     'evidence': ['run log digest', 'environment digest'],
     'source_of_truth': 'The published conformance suite and the run log for the exact build digest. AAP\'s own programme '
                        '(docs/COMPATIBILITY_PROGRAMME.html) is a draft that has issued no certificates.',
     'does_not_check': ['other builds, later versions or every deployment of the assessed software']},
    {'id': 'security-assessment', 'title': 'Security assessment', 'subjects': ['AGENT', 'SOFTWARE', 'SERVICE', 'BUSINESS'],
     'details': {'standard': ('text', True), 'scope_summary': ('text', True), 'report_digest': ('hex', True),
                 'period_end': ('time', False)},
     'date_field': 'period_end', 'methods': ['AUDIT_REPORT', 'PENETRATION_TEST', 'CERTIFICATION_BODY_RECORD'],
     'evidence': ['report digest'],
     'source_of_truth': 'The assessment report and, for certifications, the certification body\'s records (for example an '
                        'ISO/IEC 27001 certificate from an accredited certification body, or a SOC 2 report).',
     'does_not_check': ['controls outside the report\'s scope or period']},
    {'id': 'domain-competence', 'title': 'Domain competence on an evaluation suite', 'subjects': ['AGENT', 'SOFTWARE', 'SERVICE'],
     'details': {'task': ('text', True), 'model_build': ('text', True), 'suite': ('text', True), 'suite_digest': ('hex', True),
                 'metric': ('text', True), 'score': ('int', True), 'threshold': ('int', True), 'unit': ('text', True)},
     'date_field': None, 'methods': ['SUITE_RUN', 'INDEPENDENT_REPLAY'],
     'evidence': ['scored run log digest'],
     'source_of_truth': 'The evaluation suite, its digest and the scored run log for the exact build.',
     'does_not_check': ['performance on tasks outside the suite', 'any build other than the digest named']},
)
TYPE_IDS = tuple(row['id'] for row in TYPES)
_TYPES = {row['id']: row for row in TYPES}
ROLES = {
    'lender': ('lender-licence', 'kyb', 'aml-programme'),
    'broker': ('broker-licence', 'kyb'),
    'insurance-producer': ('insurance-producer-licence', 'kyb'),
    'investor': ('accredited-investor',),
}

ERRORS = {
    'MARKET_TYPE': ('The qualification is not one of the market accreditation types.',
                    'Use a type from types(); a new type needs a new version of this data.', False),
    'MARKET_DETAILS': ('The details do not match the type\'s fields, kinds or choices.',
                       'Read types() for the exact fields of this type.', False),
    'MARKET_METHOD': ('The verification method is not one this type lists.', 'Use a method from types() for this type.', False),
    'MARKET_SCORE': ('A domain-competence result records a score below its threshold.',
                     'Only a score at least the threshold is a pass.', False),
    'MARKET_REQUIREMENT': ('The requirement is malformed.', 'Build it with requirement(); jurisdictions are ISO 3166 codes.',
                           False),
    'MARKET_ROLE': ('The role is not lender, broker, insurance-producer or investor.', 'Choose one of those roles.', False),
    # Reasons ``match`` reports; they refuse nothing by themselves.
    'MARKET_DETAILS_WITHHELD': ('The holder did not disclose the type details.', 'Ask for a presentation disclosing details.',
                                True),
    'MARKET_JURISDICTION': ('The qualification does not name the required jurisdiction.',
                            'Ask for a qualification assessed for that jurisdiction; none is inferred.', False),
    'MARKET_PRODUCT': ('The licence does not list the required product.', 'Ask for a licence covering that product.', False),
    'MARKET_LINE': ('The producer licence does not list the required line.', 'Ask for a licence covering that line.', False),
    'MARKET_METHOD_NOT_ACCEPTED': ('The verification method is not one the relying party accepts.',
                                   'Ask for a verification by an accepted method.', False),
    'MARKET_EVIDENCE_STALE': ('The checked, verified or attested date is older than the relying party accepts.',
                              'Ask the assessor to check again and issue a fresh qualification.', False),
    'MARKET_VALUE_LIMIT': ('The assessed value limit is missing, in another unit or below the deal value.',
                           'Ask for an assessment covering this value, or reduce the deal.', False),
    'MARKET_RISK_LIMIT': ('The assessed risk level is below the deal\'s risk.', 'Ask for an assessment at this risk level.',
                          False),
    'MARKET_DETAIL': ('A detail the relying party requires differs from the one disclosed.',
                      'Compare the named detail; ask for a qualification stating it.', False),
}


def explain(code):
    happened, fix, retry = ERRORS.get(code, ('Unrecognised refusal.', 'Read docs/MARKET_ACCREDITATION.html.', False))
    return {'code': code, 'happened': happened, 'fix': fix, 'retry_helps': retry,
            'reference': 'docs/MARKET_ACCREDITATION.html#' + code}


def types():
    """Every type as data, with the digest a relying party can pin."""
    rows = []
    for row in TYPES:
        out = deepcopy(row)
        out['details'] = {name: {'kind': spec[0], 'required': spec[1], **({'choices': list(spec[2])} if len(spec) > 2 else {})}
                          for name, spec in row['details'].items()}
        out['aap_checks'] = list(_CHECKS)
        out['aap_does_not_check'] = list(_LIMITS) + list(row['does_not_check'])
        out['profile'] = VERSION
        rows.append(out)
    return {'version': VERSION, 'types': rows, 'digest': digest(LABEL, rows), 'execution_authorized': False}


def type_of(qualification):
    need(type(qualification) is str and qualification in _TYPES, 'MARKET_TYPE')
    return _TYPES[qualification]


def subject_artifact(scheme, identifier):
    """The 64-hex ``artifact`` for a business or person: a digest of its register identifier."""
    need(type(scheme) is str and re.fullmatch(r'[A-Z][A-Z0-9_:-]{1,63}', scheme) is not None
         and type(identifier) is str and 0 < len(identifier) <= 256 and identifier.isascii() and identifier.isprintable(),
         'MARKET_DETAILS')
    return digest(LABEL + '-SUBJECT', {'scheme': scheme, 'identifier': identifier})


def _text(value):
    need(type(value) is str and 0 < len(value) <= 256 and all(32 <= ord(c) <= 126 for c in value), 'MARKET_DETAILS')


def check_details(qualification, details, *, method=None):
    """The type's exact fields, kinds and choices; an optional method must be one the type lists."""
    spec = type_of(qualification)['details']
    need(type(details) is dict and set(details) <= set(spec)
         and all(name in details for name, field in spec.items() if field[1]), 'MARKET_DETAILS')
    for name, item in details.items():
        kind = spec[name][0]
        if kind == 'jurisdiction':
            need(type(item) is str and JURISDICTION.fullmatch(item) is not None, 'MARKET_DETAILS')
        elif kind == 'text':
            _text(item)
        elif kind == 'texts':
            need(type(item) is list and 1 <= len(item) <= 32 and item == sorted(set(item)), 'MARKET_DETAILS')
            for entry in item:
                _text(entry)
        elif kind in ('time', 'int'):
            need(type(item) is int and 0 <= item <= 2**53 - 1, 'MARKET_DETAILS')
        elif kind == 'hex':
            need(type(item) is str and re.fullmatch(r'[0-9a-f]{64}', item) is not None, 'MARKET_DETAILS')
        else:
            need(item in spec[name][2], 'MARKET_DETAILS')
    need(method is None or method in type_of(qualification)['methods'], 'MARKET_METHOD')
    if qualification == 'domain-competence':
        need(details['score'] >= details['threshold'], 'MARKET_SCORE')
    return details


def want(qualification, *, jurisdiction=None, product=None, line=None, methods=None, max_evidence_age=None,
         value=None, risk=None, details=None):
    """One requirement entry: what the relying party needs this qualification to state, exactly."""
    type_of(qualification)
    if jurisdiction is not None:
        need(type(jurisdiction) is str and JURISDICTION.fullmatch(jurisdiction) is not None, 'MARKET_REQUIREMENT')
    for text in (product, line):
        need(text is None or (type(text) is str and 0 < len(text) <= 256 and text.isprintable()), 'MARKET_REQUIREMENT')
    if methods is not None:
        need(type(methods) in (list, tuple) and methods and set(methods) <= set(type_of(qualification)['methods']),
             'MARKET_REQUIREMENT')
        methods = sorted(set(methods))
    need(max_evidence_age is None or (type(max_evidence_age) is int and 0 < max_evidence_age <= 10 * 366 * 86400),
         'MARKET_REQUIREMENT')
    if value is not None:
        need(type(value) is dict and set(value) == {'amount', 'unit'} and type(value['amount']) is int
             and 0 < value['amount'] <= 2**53 - 1 and type(value['unit']) is str and 0 < len(value['unit']) <= 32,
             'MARKET_REQUIREMENT')
    need(risk is None or risk in RISKS, 'MARKET_REQUIREMENT')
    need(details is None or (type(details) is dict and len(details) <= 16), 'MARKET_REQUIREMENT')
    return {'qualification': qualification, 'profile': VERSION, 'jurisdiction': jurisdiction, 'product': product,
            'line': line, 'methods': methods, 'max_evidence_age': max_evidence_age, 'value': deepcopy(value),
            'risk': risk, 'details': deepcopy(details or {})}


def check_want(value):
    """A requirement entry exactly as want() builds it; anything else is MARKET_REQUIREMENT."""
    fields = ('qualification', 'profile', 'jurisdiction', 'product', 'line', 'methods', 'max_evidence_age', 'value',
              'risk', 'details')
    need(type(value) is dict and set(value) == set(fields) and value['profile'] == VERSION, 'MARKET_REQUIREMENT')
    rebuilt = want(value['qualification'], jurisdiction=value['jurisdiction'], product=value['product'], line=value['line'],
                   methods=value['methods'], max_evidence_age=value['max_evidence_age'], value=value['value'],
                   risk=value['risk'], details=value['details'])
    need(rebuilt == value, 'MARKET_REQUIREMENT')
    return value


def requirement(role, *, jurisdiction=None, product=None, line=None, max_evidence_age=None, methods=None, value=None):
    """The demand exchange's qualification entries for a lender, broker, insurance producer or investor."""
    need(role in ROLES, 'MARKET_ROLE')
    out = []
    for qualification in ROLES[role]:
        primary = qualification == ROLES[role][0]
        out.append(want(qualification, jurisdiction=jurisdiction,
                        product=product if primary and qualification in ('lender-licence', 'broker-licence') else None,
                        line=line if primary and qualification == 'insurance-producer-licence' else None,
                        methods=methods if primary and qualification == 'accredited-investor' else None,
                        max_evidence_age=max_evidence_age if primary else None,
                        value=value if primary else None))
    return {'version': VERSION, 'role': role, 'qualifications': out, 'execution_authorized': False}


def match(claims, entry, *, now):
    """Reasons the disclosed claims fall short of one requirement entry; empty means every stated condition holds.

    ``claims`` is what a presentation disclosed: qualification, profile and, as needed, details, method and coverage.
    """
    need(type(claims) is dict, 'MARKET_REQUIREMENT')
    check_want(entry)
    integer(now)
    reasons = []
    if claims.get('qualification') != entry['qualification'] or claims.get('profile') != VERSION:
        return ['MARKET_TYPE']
    details = claims.get('details')
    if details is None:
        return ['MARKET_DETAILS_WITHHELD']
    try:
        check_details(entry['qualification'], details, method=claims.get('method'))
    except ValueError as error:
        return [str(error)]
    cover = claims.get('coverage') or {}
    if entry['jurisdiction'] is not None and entry['jurisdiction'] != details.get('jurisdiction') \
            and entry['jurisdiction'] not in cover.get('jurisdictions', []):
        reasons.append('MARKET_JURISDICTION')
    if entry['product'] is not None and entry['product'] not in details.get('products', []):
        reasons.append('MARKET_PRODUCT')
    if entry['line'] is not None and entry['line'] not in details.get('lines', []):
        reasons.append('MARKET_LINE')
    if entry['methods'] is not None and claims.get('method') not in entry['methods']:
        reasons.append('MARKET_METHOD_NOT_ACCEPTED')
    if entry['max_evidence_age'] is not None:
        field = type_of(entry['qualification'])['date_field']
        moment = details.get(field) if field else claims.get('assessed_at')
        if moment is None or now - moment > entry['max_evidence_age'] or moment > now:
            reasons.append('MARKET_EVIDENCE_STALE')
    limits = cover.get('limits') or {}
    if entry['value'] is not None:
        cap = limits.get('max_value')
        if cap is None or cap['unit'] != entry['value']['unit'] or entry['value']['amount'] > cap['amount']:
            reasons.append('MARKET_VALUE_LIMIT')
    if entry['risk'] is not None:
        if limits.get('risk') is None or RISKS.index(entry['risk']) > RISKS.index(limits['risk']):
            reasons.append('MARKET_RISK_LIMIT')
    for name, value in entry['details'].items():
        if details.get(name) != value:
            reasons.append('MARKET_DETAIL')
    return reasons


def from_connect_certificate(presented, *, now, trusted_issuers=(), assessments=('PROJECT_ASSESSMENT', 'INDEPENDENT_ASSESSMENT'),
                             require_status=True, max_status_age=None):
    """An AAP Connect conformance certificate as an agent-conformance claim an owner may issue.

    The presented certificate (and its stapled status) is first checked against the caller's own pins by
    connect_certification.verify_certificate; nothing here issues, signs or adopts. The profile tested is the
    Connect contract, the suite and its digest are the certificate's conformance suite for the adapter kind,
    the version is the adapter release and the artifact is the build digest (the implementation hash). A
    self-test or the project's own rerun is SUITE_RUN; an independent issuer's reproduced run is
    INDEPENDENT_REPLAY.
    """
    from . import connect_certification as certificates, connect_conformance as conformance
    checked = certificates.verify_certificate(presented, now=now, trusted_issuers=trusted_issuers, assessments=assessments,
                                              require_status=require_status, max_status_age=max_status_age)
    body = certificates.open_certificate(presented['certificate'])['body']
    suite = conformance.suite(body['kind'])
    need(suite['sha256'] == body['suite'], 'MARKET_DETAILS')
    method = 'INDEPENDENT_REPLAY' if body['assessment'] == 'INDEPENDENT_ASSESSMENT' else 'SUITE_RUN'
    details = check_details('agent-conformance', {'profile_tested': body['contract'], 'suite': suite['id'],
                                                  'suite_digest': body['suite'], 'version': body['release']}, method=method)
    return {'qualification': 'agent-conformance', 'profile': VERSION, 'subject': body['subject'], 'artifact': body['implementation'],
            'details': details, 'method': method, 'assessed_at': body['issued_at'], 'evidence': sorted({checked['certificate'], body['report']}),
            'source': {'certificate': checked['certificate'], 'issuer': body['issuer'], 'assessment': body['assessment'],
                       'current_status': checked['current_status']},
            'official_badge': False, 'accreditation': 'NONE_CLAIMED', 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'types': list(TYPE_IDS), 'roles': {role: list(rows) for role, rows in ROLES.items()},
            'mapping': {'qualification': 'type id', 'profile': VERSION,
                        'artifact': 'build digest, or subject_artifact(scheme, identifier) for a business or person',
                        'details': 'covenant-agent-accreditation-sd/0.1 details claim'},
            'matching': 'EXACT_AS_WRITTEN; NO_JURISDICTION_OR_PRODUCT_INFERENCE',
            'aap_checks': list(_CHECKS), 'aap_does_not_check': list(_LIMITS),
            'guide': 'docs/MARKET_ACCREDITATION.html', 'network_accessed': False, 'execution_authorized': False}
