"""Pinned, FORMAT_ONLY ACTUS PAM import into an unsigned legal composition.

This is a deterministic field mapping grounded in a retained official test
corpus. It does not implement ACTUS schedules, payoffs, state transitions or
conformance. Complete original bytes and every unmapped term stay available;
unknown metadata never installs code, grants trust or supplies old assent.
"""
from copy import deepcopy
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
import base64
import hashlib
import json
import re

from .crypto import need, verification_key
from covenant_language.agentic import canonical
from covenant_language import legal_composition as legal

VERSION = 'covenant-domain-adapter-review/0.1'
ADAPTER = 'actus-pam-format-only/0.1'
COMMIT = 'f7a8064872b69db1f0beabac771c99dc3ce0c397'
OFFICIAL_SOURCE = 'cf08dc73b63a6916a6667fd8119542b6b45c6f4d3f9409a3af528a4832255c94'
LICENSE_SHA256 = '16a89e266327c24d38e58eaa55cfc352d8bb03dad2d23b30f5e3386685edc150'
SUPPORTED = {'contractType': 'kind', 'contractID': 'source_contract_id', 'currency': 'currency',
             'notionalPrincipal': 'principal_decimal_text', 'initialExchangeDate': 'initial_exchange_text',
             'maturityDate': 'maturity_text', 'nominalInterestRate': 'nominal_rate_decimal_text',
             'contractRole': 'source_record_role'}
MAX_SOURCE = 262144


def manifest():
    value = {'version': VERSION, 'adapter': ADAPTER, 'scope': 'FORMAT_ONLY; NO_ACTUS_EVENT_OR_CASHFLOW_ENGINE',
             'basis': {'repository': 'actusfrf/actus-tests', 'commit': COMMIT,
                       'path': 'tests/actus-tests-pam.json', 'git_blob': '318201025a1e6ed2ff3c61e91b63f15f2efa6fe9',
                       'sha256': OFFICIAL_SOURCE,
                       'url': 'https://github.com/actusfrf/actus-tests/blob/' + COMMIT + '/tests/actus-tests-pam.json'},
             'licence': {'identifier': 'CC-BY-SA-4.0', 'sha256': LICENSE_SHA256,
                         'url': 'https://github.com/actusfrf/actus-tests/blob/' + COMMIT + '/LICENSE.md',
                         'attribution': 'ACTUS Financial Research Foundation; official corpus retained unchanged',
                         'scope': 'RETAINED_UPSTREAM_DATA_AND_DERIVED_DATA; REPOSITORY_CODE_LICENCE_UNCHANGED',
                         'review': 'SOURCE_LICENCE_INSPECTED; NO_LEGAL_OPINION_OR_UPSTREAM_ENDORSEMENT'},
             'supported': deepcopy(SUPPORTED),
             'unsupported': ['Interest/payment cycles', 'Day count and business-day rules', 'Fees, rate resets and scaling',
                             'Risk-factor scenarios and observed events', 'ACTUS results and numerical cashflows',
                             'Legal capacity, authority, assent and enforceability', 'External currency transfer or settlement'],
             'verifier': {'implementation_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                          'scope': 'EXACT_SOURCE_PIN_STRICT_JSON_SELECTED_STRING_FIELDS_AND_DRAFT_REFERENCE_CHECKS',
                          'official_schema_validation': 'NOT_RUN; NO_OFFICIAL_SCHEMA_ADOPTED',
                          'official_runtime_conformance': 'NOT_RUN; NO_SPECIALIST_RUNTIME_INSTALLED'},
             'remote_code_loading': False, 'execution_authorized': False}
    return {**value, 'id': hashlib.sha256(b'COVENANT-DOMAIN-ADAPTER-MANIFEST-0.1\0' + canonical(value)).hexdigest()}


class _Number(str):
    """Retain exact JSON numeric lexemes without binary floating-point coercion."""


def _inert(value, depth=0):
    need(depth <= 16, 'DOMAIN_ADAPTER_TERM_DEPTH')
    if type(value) is _Number:
        return {'json_number_lexeme': str(value)}
    if type(value) is list:
        return [_inert(item, depth+1) for item in value]
    if type(value) is dict:
        return {key: _inert(item, depth+1) for key, item in value.items()}
    return value


def _decode(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, 'DOMAIN_ADAPTER_DUPLICATE_KEY')
            out[key] = value
        return out
    def bad(_):
        raise ValueError('DOMAIN_ADAPTER_NONFINITE_NUMBER')
    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_float=_Number, parse_int=_Number, parse_constant=bad)
    except (json.JSONDecodeError, RecursionError, UnicodeError):
        raise ValueError('DOMAIN_ADAPTER_JSON') from None


def _decimal(value, positive=False):
    need(type(value) is str and len(value) <= 128 and re.fullmatch(r'[+-]?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?', value), 'DOMAIN_ADAPTER_DECIMAL_STRING_REQUIRED')
    try:
        parsed = Decimal(value)
    except InvalidOperation:
        raise ValueError('DOMAIN_ADAPTER_DECIMAL_STRING_REQUIRED') from None
    need(parsed.is_finite() and (not positive or parsed > 0), 'DOMAIN_ADAPTER_DECIMAL_VALUE')


def pam_draft(source_utf8, expected_source, case, parties, context):
    """Import one PAM case from a pinned JSON object; all unknown terms stay inert.

    parties must be the caller's explicit lender/borrower Ed25519 keys. An RPA
    source record describes the asset side and an RPL source record the
    liability side; this mapping never infers either legal party's identity.
    """
    need(type(source_utf8) is str, 'DOMAIN_ADAPTER_SOURCE')
    raw = source_utf8.encode('utf-8')
    need(len(raw) <= MAX_SOURCE, 'DOMAIN_ADAPTER_SOURCE_LIMIT')
    legal.hashref(expected_source)
    need(hashlib.sha256(raw).hexdigest() == expected_source, 'DOMAIN_ADAPTER_SOURCE_PIN')
    legal.name(case)
    legal.hashref(context)
    need(type(parties) is dict and set(parties) == {'lender', 'borrower'}, 'DOMAIN_ADAPTER_PARTIES')
    for identity in parties.values():
        need(type(identity) is str, 'DOMAIN_ADAPTER_ED25519_ONLY')
        verification_key(identity)
    need(parties['lender'] != parties['borrower'], 'DOMAIN_ADAPTER_DISTINCT_PARTIES')
    corpus = _decode(source_utf8)
    need(type(corpus) is dict and case in corpus and type(corpus[case]) is dict, 'DOMAIN_ADAPTER_CASE')
    record = corpus[case]
    need(type(record.get('terms')) is dict and 1 <= len(record['terms']) <= 64, 'DOMAIN_ADAPTER_TERMS')
    terms = record['terms']
    need(set(SUPPORTED) <= set(terms), 'DOMAIN_ADAPTER_REQUIRED_FIELDS')
    for field in SUPPORTED:
        need(type(terms[field]) is str and 0 < len(terms[field].encode('utf-8')) <= 256, 'DOMAIN_ADAPTER_STRING_FIELD')
    need(terms['contractType'] == 'PAM', 'DOMAIN_ADAPTER_UNSUPPORTED_CONTRACT')
    need(terms['contractRole'] in ('RPA', 'RPL'), 'DOMAIN_ADAPTER_UNSUPPORTED_ROLE')
    _decimal(terms['notionalPrincipal'], positive=True)
    _decimal(terms['nominalInterestRate'])
    for field in ('initialExchangeDate', 'maturityDate'):
        try:
            need('T' in terms[field], 'DOMAIN_ADAPTER_DATE')
            datetime.fromisoformat(terms[field].replace('Z', '+00:00'))
        except ValueError:
            raise ValueError('DOMAIN_ADAPTER_DATE') from None
    adopted = manifest()
    mapped = {target: terms[field] for field, target in SUPPORTED.items()}
    unmapped = {field: _inert(value) for field, value in terms.items() if field not in SUPPORTED}
    encoded_source = base64.b64encode(raw).decode('ascii')
    preserved = {'source_sha256': expected_source, 'source_encoding': 'UTF8_BASE64_CHUNKS',
                 'source_provenance': 'MATCHES_RETAINED_OFFICIAL_CORPUS' if expected_source == OFFICIAL_SOURCE else 'CALLER_SOURCE; NOT_AUTHENTICATED_AS_OFFICIAL_CORPUS',
                 'input_licence': 'RETAINED_OFFICIAL_CC_BY_SA_4_0_SOURCE' if expected_source == OFFICIAL_SOURCE else 'UNVERIFIED_CALLER_RESPONSIBILITY',
                 'source_base64_chunks': [encoded_source[i:i+8192] for i in range(0, len(encoded_source), 8192)],
                 'case': case, 'unmapped_terms': unmapped,
                 'uninterpreted_case_sections': sorted(key for key in record if key != 'terms'),
                 'losses': ['No event schedule, cashflow, ACTUS state transition or payoff is generated',
                            'No day-count/calendar/cycle/fee/risk-factor semantics is translated',
                            'Source decimal strings and timestamps stay exact; no timezone or rounding is invented',
                            'Unmapped values stay inert; numeric lexemes use explicit json_number_lexeme tags',
                            'Source identity/record role does not establish lender or borrower identity, assent or authority'],
                 'adapter_manifest': adopted}
    canonical(preserved)
    definitions = {'ImportedPAM': legal.node('custom:actus-pam-format-only/0.1',
                                           {**mapped, 'source': expected_source, 'adapter': adopted['id']}),
                   'Scope': legal.node('TERM', {'text': 'FORMAT_ONLY imported proposal. No ACTUS cashflow conformance, payment, current authority or legal effect is established.'}),
                   'Root': legal.node('ALL', references=[legal.reference('SELF', 'ImportedPAM'), legal.reference('SELF', 'Scope')])}
    made = legal.draft('PAM import proposal: ' + terms['contractID'][:160], parties, {}, definitions,
                       [legal.reference('SELF', 'Root')], extensions={'domain_adapter': preserved})
    module = made['module']
    return {'version': VERSION, 'status': 'UNSIGNED_FORMAT_ONLY_IMPORT', 'module': module, 'id': made['id'],
            'adapter_manifest': adopted, 'mapped_fields': sorted(SUPPORTED), 'unmapped_fields': sorted(unmapped),
            'losses': preserved['losses'], 'source_sha256': expected_source,
            'source_provenance': preserved['source_provenance'],
            'source_preserved_exactly': True, 'original_assent_inherited': False,
            'assent_payload': legal.assent_payload(module, context),
            'official_runtime_conformance': 'NOT_RUN', 'cashflows_generated': False, 'execution_authorized': False}


def open_source(module, expected_id):
    """Explicitly open the exact retained inert source from the imported module."""
    legal.validate(module)
    need(legal.identifier(module) == expected_id, 'DOMAIN_ADAPTER_EXPECTED_MODULE')
    row = module['extensions'].get('domain_adapter')
    need(type(row) is dict and row.get('source_encoding') == 'UTF8_BASE64_CHUNKS', 'DOMAIN_ADAPTER_SOURCE')
    chunks = row.get('source_base64_chunks')
    need(type(chunks) is list and len(chunks) <= 44 and all(type(chunk) is str and len(chunk) <= 8192 for chunk in chunks), 'DOMAIN_ADAPTER_SOURCE_LIMIT')
    try:
        encoded = ''.join(chunks)
        raw = base64.b64decode(encoded, validate=True)
        need(base64.b64encode(raw).decode('ascii') == encoded and len(raw) <= MAX_SOURCE, 'DOMAIN_ADAPTER_SOURCE')
        need(hashlib.sha256(raw).hexdigest() == row['source_sha256'], 'DOMAIN_ADAPTER_SOURCE_PIN')
        source = raw.decode('utf-8')
    except (ValueError, UnicodeError, KeyError):
        raise ValueError('DOMAIN_ADAPTER_SOURCE') from None
    return {'source_utf8': source, 'sha256': row['source_sha256'], 'execution_authorized': False}


def describe():
    return {'version': VERSION, 'manifest': manifest(), 'parameters': {
        'source_utf8': 'Complete retained JSON corpus, at most 262144 UTF-8 bytes',
        'expected_source': 'Recipient-retained SHA256 of exact source bytes', 'case': 'Exact top-level corpus case id',
        'parties': {'lender': 'Caller-adopted Ed25519 public key', 'borrower': 'Distinct caller-adopted Ed25519 public key'},
        'context': 'Fresh explicit 64-hex review context'},
        'adoption': 'Use returned existing legal_composition assent payload; source signatures are never inherited',
        'mode': 'FORMAT_ONLY; DRAFT_CUSTOM_CONCEPTS_NO_FINANCIAL_ENGINE', 'execution_authorized': False}
