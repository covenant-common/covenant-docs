"""Multi-source discovery of agent descriptors signed by the agent's own key.

AAP application profile ``covenant-signed-discovery/0.1``. A DESCRIPTOR names
its Ed25519 key, a sequence, task classes, endpoints, an optional operator and
an optional postage policy, and is signed by that key. The same signed bytes can
travel through any number of untrusted carriers; only the signature counts.

Adapters parse bytes the caller already holds; nothing is fetched or dialed:

* DIRECT: canonical JSON handed over peer to peer (file, QR, BLE).
* WELL_KNOWN: an HTTP body from ``/.well-known/aap-agent.json`` (RFC 8615 path
  convention; this suffix is a proposal, not an IANA registration).
* DNS_TXT: TXT character-strings (RFC 1035 section 3.3.14) concatenated and
  read as an RFC 6376 section 3.2 tag-list: ``v=AAP1; d=<base64url descriptor>``
  or a ``k=``/``h=`` pointer that carries no claims of its own.
* NOSTR: a NIP-01 event whose content is the descriptor; the event id is
  recomputed, its secp256k1 signature is transport metadata and is not needed.
* TLOG: a descriptor id included in a log under an owner-adopted checkpoint,
  verified with RFC 9162 section 2.1.3.2 inclusion proofs; checkpoints are
  C2SP signed notes or existing AAP chronicle heads.
* INTRODUCTION: a signed introduction carrying the descriptor.
* A2A_CARD, ANP, AGENTFACTS, OASF: foreign agent documents that carry the
  descriptor, either with its AAP signature or as a body covered by the
  document's own signature by the same key (an A2A card JWS, RFC 7515 with
  RFC 8037 EdDSA; a W3C eddsa-jcs-2022 Data Integrity proof).
* DNS_AID, ANS: DNS records (draft-mozleywilliams-dnsop-dnsaid-02 SVCB,
  ANS ``_ans`` TXT) that point at documents; they carry no claims of their own,
  and documents the caller fetched for them are read like any other carrier. An
  ANS badge the caller fetched is checked against an adopted ANS log (format
  ANS_TL) and reported beside the descriptor as registration evidence.

Descriptors are deduplicated by key. The highest valid sequence is selected
only when nothing contradicts it; two different descriptors signed for one
sequence, or a broken ``previous`` link, are surfaced as a conflict with the
signed evidence, never merged. Sources add availability, never trust.
"""
import base64
from copy import deepcopy
import hashlib
import json
from urllib.parse import urlsplit

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .crypto import canonical, digest, integer, key, loads, need, public_key, sign, verification_key, verify
from . import introductions as intro

VERSION = 'covenant-signed-discovery/0.1'
LABEL = 'COVENANT-SIGNED-DISCOVERY-0.1'
FIELDS = 'version kind key sequence previous issued_at expires name summary task_classes endpoints operator postage_policy'
SOURCES = ('DIRECT', 'WELL_KNOWN', 'DNS_TXT', 'NOSTR', 'TLOG', 'INTRODUCTION', 'A2A_CARD', 'ANP', 'DNS_AID', 'ANS',
           'AGENTFACTS', 'OASF', 'WOT_TD')
FOREIGN_SOURCES = SOURCES[6:]
SIGNATURE_FORMATS = ('AAP_ED25519', 'A2A_CARD_JWS_EDDSA', 'W3C_EDDSA_JCS_2022')
MAX_DOCUMENTS = 16
TRANSPORTS = ('https', 'a2a', 'mcp', 'nostr', 'ble', 'qr', 'other')
WELL_KNOWN_PATH = '/.well-known/aap-agent.json'
DNS_VERSION = 'AAP1'
MAX_SOURCES = 256
MAX_SOURCE_BYTES = 65536
MAX_TOTAL_BYTES = 4_000_000
MAX_DESCRIPTOR_BYTES = 8192
MAX_PER_DOCUMENT = 16
MAX_PROOF = 64
MAX_LOGS = 16

REMEDIATION = {
    'DISCOVERY_FIELDS': 'Use the exact descriptor or source field set from describe().',
    'DISCOVERY_PROFILE': 'Use version covenant-signed-discovery/0.1 and kind DESCRIPTOR.',
    'DISCOVERY_TEXT': 'Use printable ASCII: name 1-80, summary 0-240, task classes 1-80 characters.',
    'DISCOVERY_LIST': 'List 1 to 16 distinct sorted task classes and at most 8 endpoints.',
    'DISCOVERY_ENDPOINT': 'Endpoints are {transport, uri}; transport is one of describe().transports.',
    'DISCOVERY_SEQUENCE': 'Sequence 0 has previous null; a later sequence names the previous descriptor id.',
    'DISCOVERY_WINDOW': 'Use integer times with issued_at strictly before expires.',
    'DISCOVERY_SIZE': 'Stay within the per-source, per-descriptor and total byte bounds.',
    'DISCOVERY_COMPLEXITY': 'Flatten the input; nesting and node counts are bounded.',
    'DISCOVERY_JSON_TYPE': 'Use JSON objects, arrays, strings, integers, booleans or null.',
    'DISCOVERY_ENVELOPE': 'Pass {"body": ..., "signature": <128 hex>} exactly.',
    'DISCOVERY_SIGNATURE': 'The descriptor must be signed by the key it names.',
    'DISCOVERY_SOURCE': 'Name a source kind from describe().sources with its exact fields.',
    'DISCOVERY_JSON': 'Supply one strict JSON value: no duplicate keys, floats or non-ASCII text.',
    'DISCOVERY_DOCUMENT': 'A document is one signed descriptor or {"descriptors": [...]} with at most 16.',
    'DISCOVERY_ORIGIN': 'Use an https origin with a host and optional port, no path, query or credentials.',
    'DISCOVERY_DNS_NAME': 'Use a DNS name that starts with the _aap label.',
    'DISCOVERY_DNS_STRINGS': 'Supply 1 to 64 TXT character-strings of at most 255 printable ASCII bytes each.',
    'DISCOVERY_DNS_TAGS': 'Use an RFC 6376 tag-list starting v=AAP1 with d=<base64url> or k=<key>; h=<descriptor id>.',
    'DISCOVERY_BASE64': 'Use unpadded base64url for d= and standard base64 for note fields.',
    'DISCOVERY_NOSTR_EVENT': 'Supply a NIP-01 event with id, pubkey, created_at, kind, tags, content and sig.',
    'DISCOVERY_NOSTR_ID': 'The event id is not the NIP-01 hash of its fields; the carrier altered it.',
    'DISCOVERY_TLOG': 'Supply entry, index, size, path and a checkpoint for one descriptor.',
    'DISCOVERY_INCLUSION': 'The RFC 9162 inclusion proof does not lead to the checkpoint root.',
    'DISCOVERY_CHECKPOINT': 'The checkpoint is not a valid C2SP signed note or chronicle head.',
    'DISCOVERY_LOG_NOT_ADOPTED': 'Adopt the log key yourself; a checkpoint cannot nominate its own verifier.',
    'DISCOVERY_LOGS': 'Pass adopted logs as at most 16 entries {format, log, vkey|key}; ANS_TL key is the log root-keys line.',
    'DISCOVERY_INTRODUCTION': 'The introduction must be validly signed and name this descriptor or its key.',
    'DISCOVERY_ORDER': 'Use order RELEVANCE or ANCHORED.',
    'DISCOVERY_FOREIGN_DOCUMENT': 'Supply an AAP descriptor document, an A2A card, an ANP description, AgentFacts, an OASF record or a WoT Thing Description.',
    'DISCOVERY_DOCUMENTS': 'Pass at most 16 fetched documents as {url, body} with an https url.',
    'DISCOVERY_ATTESTED': 'A foreign signature must be by the key the carried descriptor names.',
}


def remediation(code):
    return REMEDIATION.get(code, intro.remediation(code))


def _text(value, maximum, empty=False):
    need(type(value) is str and (empty or len(value) > 0) and len(value) <= maximum
         and all(32 <= ord(c) <= 126 for c in value), 'DISCOVERY_TEXT')


def _keyed(value):
    need(type(value) is str, 'KEY'); verification_key(value)


def _validate(body):
    intro._bounded(body, MAX_DESCRIPTOR_BYTES, 'DISCOVERY')
    need(type(body) is dict and set(body) == set(FIELDS.split()), 'DISCOVERY_FIELDS')
    need(body['version'] == VERSION and body['kind'] == 'DESCRIPTOR', 'DISCOVERY_PROFILE')
    _keyed(body['key']); integer(body['sequence']); integer(body['issued_at']); integer(body['expires'])
    need(body['issued_at'] < body['expires'], 'DISCOVERY_WINDOW')
    need((body['sequence'] == 0) == (body['previous'] is None), 'DISCOVERY_SEQUENCE')
    if body['previous'] is not None:
        key(body['previous'])
    _text(body['name'], 80); _text(body['summary'], 240, empty=True)
    classes = body['task_classes']
    need(type(classes) is list and 1 <= len(classes) <= 16 and classes == sorted(set(classes)), 'DISCOVERY_LIST')
    for value in classes:
        _text(value, 80)
    need(type(body['endpoints']) is list and len(body['endpoints']) <= 8, 'DISCOVERY_LIST')
    for row in body['endpoints']:
        need(type(row) is dict and set(row) == {'transport', 'uri'} and row['transport'] in TRANSPORTS, 'DISCOVERY_ENDPOINT')
        _text(row['uri'], 256)
    if body['operator'] is not None:
        _keyed(body['operator'])
    if body['postage_policy'] is not None:
        key(body['postage_policy'])
    need(len(canonical(body)) <= MAX_DESCRIPTOR_BYTES, 'DISCOVERY_SIZE')
    return body


def descriptor_id(body):
    _validate(body)
    return digest(LABEL, body)


def descriptor(agent_key, sequence, previous, issued_at, expires, name, summary, task_classes, endpoints,
               operator=None, postage_policy=None):
    """Prepare an unsigned descriptor; the agent signs it with the key it names."""
    body = {'version': VERSION, 'kind': 'DESCRIPTOR', 'key': agent_key, 'sequence': sequence, 'previous': previous,
            'issued_at': issued_at, 'expires': expires, 'name': name, 'summary': summary,
            'task_classes': deepcopy(task_classes), 'endpoints': deepcopy(endpoints), 'operator': operator,
            'postage_policy': postage_policy}
    return {'id': descriptor_id(body), 'body': body, 'signing_payload': {'label': LABEL, 'body': deepcopy(body)},
            'required_signers': [agent_key], 'signature_created': False, 'execution_authorized': False}


def sign_descriptor(body, private_key):
    """Explicit local owner action. Not exposed as a tool; no permission is inferred."""
    _validate(body)
    need(public_key(private_key) == body['key'], 'DISCOVERY_SIGNATURE')
    return {'body': deepcopy(body), 'signature': sign(private_key, LABEL, body)}


def attested(body, signature_format, signer):
    """A descriptor body an adapter authenticated with a foreign signature by ``signer``.

    The tuple form cannot be produced by parsing JSON, so a carrier can never
    present a body as already verified.
    """
    from .interop_codec import integral
    body = _validate(integral(body))
    need(signature_format in SIGNATURE_FORMATS[1:] and signer == body['key'], 'DISCOVERY_ATTESTED')
    return ('ATTESTED', deepcopy(body), signature_format)


def _open_attested(item):
    need(len(item) == 3 and item[0] == 'ATTESTED' and item[2] in SIGNATURE_FORMATS[1:], 'DISCOVERY_ATTESTED')
    body = _validate(item[1])
    return {'id': digest(LABEL, body), 'body': deepcopy(body), 'envelope': None}, item[2]


def open_descriptor(envelope):
    intro._bounded(envelope, MAX_DESCRIPTOR_BYTES * 2, 'DISCOVERY')
    need(type(envelope) is dict and set(envelope) == {'body', 'signature'}, 'DISCOVERY_ENVELOPE')
    body = _validate(envelope['body'])
    try:
        verify(body['key'], LABEL, body, envelope['signature'])
    except ValueError:
        raise ValueError('DISCOVERY_SIGNATURE') from None
    return {'id': digest(LABEL, body), 'body': deepcopy(body), 'envelope': deepcopy(envelope)}


def encode(envelope):
    """Canonical JSON text of one signed descriptor, as every carrier transports it."""
    open_descriptor(envelope)
    return canonical(envelope).decode('ascii')


def dns_txt(envelope, chunk=255):
    """TXT character-strings carrying ``v=AAP1; d=<base64url canonical descriptor>``."""
    raw = canonical(envelope); open_descriptor(envelope)
    integer(chunk, True); need(chunk <= 255, 'DISCOVERY_DNS_STRINGS')
    text = 'v=' + DNS_VERSION + '; d=' + base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')
    return [text[index:index + chunk] for index in range(0, len(text), chunk)]


def nostr_event(envelope, pubkey, created_at, kind=30078, tags=None):
    """An unsigned NIP-01 event shell whose content is the descriptor; ``sig`` is left for the carrier."""
    content = encode(envelope); key(pubkey); integer(created_at); integer(kind)
    tags = [['d', 'aap-agent']] if tags is None else deepcopy(tags)
    event = {'pubkey': pubkey, 'created_at': created_at, 'kind': kind, 'tags': tags, 'content': content}
    event['id'] = _nostr_id(event)
    return event


def _nostr_id(event):
    serial = json.dumps([0, event['pubkey'], event['created_at'], event['kind'], event['tags'], event['content']],
                        separators=(',', ':'), ensure_ascii=False)
    return hashlib.sha256(serial.encode('utf-8')).hexdigest()


def leaf_hash(descriptor_hex):
    """RFC 9162 section 2.1.1 leaf hash over the 32-byte descriptor id (the chronicle convention)."""
    key(descriptor_hex)
    return hashlib.sha256(b'\x00' + bytes.fromhex(descriptor_hex)).digest()


def _node(left, right):
    return hashlib.sha256(b'\x01' + left + right).digest()


def verify_inclusion(descriptor_hex, index, size, path, root_hex):
    """RFC 9162 section 2.1.3.2 inclusion verification for any tree size."""
    integer(index); integer(size); key(root_hex)
    need(type(path) is list and len(path) <= MAX_PROOF and index < size, 'DISCOVERY_INCLUSION')
    for item in path:
        key(item)
    fn, sn, value = index, size - 1, leaf_hash(descriptor_hex)
    for item in path:
        need(sn != 0, 'DISCOVERY_INCLUSION')
        sibling = bytes.fromhex(item)
        if fn & 1 or fn == sn:
            value = _node(sibling, value)
            if not fn & 1:
                while fn and not fn & 1:
                    fn >>= 1; sn >>= 1
        else:
            value = _node(value, sibling)
        fn >>= 1; sn >>= 1
    need(sn == 0 and value.hex() == root_hex, 'DISCOVERY_INCLUSION')
    return True


def _vkey(text):
    """Parse a C2SP signed-note Ed25519 verifier key ``<name>+<hash>+<base64(0x01||key)>``."""
    need(type(text) is str and 0 < len(text) <= 512 and text.count('+') >= 2, 'DISCOVERY_LOGS')
    name, hashed, data = text.rsplit('+', 2)
    need(name and ' ' not in name and '\n' not in name and len(hashed) == 8, 'DISCOVERY_LOGS')
    try:
        raw = base64.b64decode(data.encode('ascii'), validate=True)
    except (ValueError, UnicodeError):
        raise ValueError('DISCOVERY_LOGS') from None
    need(len(raw) == 33 and raw[0] == 1, 'DISCOVERY_LOGS')
    digest_ = hashlib.sha256(name.encode('utf-8') + b'\n' + raw).digest()[:4]
    need(digest_.hex() == hashed.lower(), 'DISCOVERY_LOGS')
    return {'name': name, 'key_hash': digest_, 'key': raw[1:].hex()}


def _logs(adopted_logs):
    adopted_logs = [] if adopted_logs is None else adopted_logs
    need(type(adopted_logs) is list and len(adopted_logs) <= MAX_LOGS, 'DISCOVERY_LOGS')
    result = []
    for row in adopted_logs:
        need(type(row) is dict and row.get('format') in ('C2SP_NOTE', 'CHRONICLE', 'ANS_TL'), 'DISCOVERY_LOGS')
        if row['format'] == 'ANS_TL':
            from .ans_transparency import tl_key
            need(set(row) == {'format', 'log', 'key'} and type(row['key']) is str, 'DISCOVERY_LOGS')
            try:
                found = tl_key(row['key'])
            except ValueError:
                raise ValueError('DISCOVERY_LOGS') from None
            need(found['origin'] == row['log'], 'DISCOVERY_LOGS')
            result.append({'format': 'ANS_TL', 'log': row['log'], 'line': row['key']})
        elif row['format'] == 'C2SP_NOTE':
            need(set(row) == {'format', 'log', 'vkey'} and type(row['log']) is str and 0 < len(row['log']) <= 256,
                 'DISCOVERY_LOGS')
            result.append({'format': 'C2SP_NOTE', 'log': row['log'], **_vkey(row['vkey'])})
        else:
            need(set(row) == {'format', 'log', 'key'}, 'DISCOVERY_LOGS')
            key(row['log']); _keyed(row['key'])
            result.append({'format': 'CHRONICLE', 'log': row['log'], 'key': row['key']})
    return result


def _note_checkpoint(note, logs):
    """Verify a C2SP signed-note checkpoint against adopted keys; return (origin, size, root_hex)."""
    need(type(note) is str and 0 < len(note) <= 8192 and '\n\n' in note, 'DISCOVERY_CHECKPOINT')
    text, _, signatures = note.partition('\n\n')
    text += '\n'
    lines = text.split('\n')[:-1]
    need(len(lines) >= 3 and lines[0] and lines[1] and all(c in '0123456789' for c in lines[1])
         and (lines[1] == '0' or not lines[1].startswith('0')) and len(lines[1]) <= 19, 'DISCOVERY_CHECKPOINT')
    try:
        root = base64.b64decode(lines[2].encode('ascii'), validate=True)
    except (ValueError, UnicodeError):
        raise ValueError('DISCOVERY_CHECKPOINT') from None
    need(len(root) == 32 and base64.b64encode(root).decode('ascii') == lines[2], 'DISCOVERY_CHECKPOINT')
    origin, size = lines[0], int(lines[1])
    need(size < 2**63 and signatures.endswith('\n'), 'DISCOVERY_CHECKPOINT')
    candidates = [log for log in logs if log['format'] == 'C2SP_NOTE' and log['log'] == origin]
    need(bool(candidates), 'DISCOVERY_LOG_NOT_ADOPTED')
    for line in signatures[:-1].split('\n'):
        need(line.startswith('— ') and line.count(' ') == 2, 'DISCOVERY_CHECKPOINT')
        _, name, blob = line.split(' ')
        try:
            raw = base64.b64decode(blob.encode('ascii'), validate=True)
        except (ValueError, UnicodeError):
            raise ValueError('DISCOVERY_CHECKPOINT') from None
        for log in candidates:
            if log['name'] != name or len(raw) != 68 or raw[:4] != log['key_hash']:
                continue
            try:
                Ed25519PublicKey.from_public_bytes(bytes.fromhex(log['key'])).verify(raw[4:], text.encode('utf-8'))
            except InvalidSignature:
                raise ValueError('DISCOVERY_CHECKPOINT') from None
            return origin, size, root.hex()
    raise ValueError('DISCOVERY_LOG_NOT_ADOPTED')


def _chronicle_checkpoint(head, logs):
    from covenant_language.finality import verify_head
    need(type(head) is dict and type(head.get('body')) is dict, 'DISCOVERY_CHECKPOINT')
    for log in logs:
        if log['format'] == 'CHRONICLE' and head['body'].get('log') == log['log']:
            try:
                verify_head(head, log['log'], log['key'])
            except ValueError:
                raise ValueError('DISCOVERY_CHECKPOINT') from None
            return log['log'], head['body']['size'], head['body']['root']
    raise ValueError('DISCOVERY_LOG_NOT_ADOPTED')


def _document(text):
    need(type(text) is str and len(text) <= MAX_SOURCE_BYTES, 'DISCOVERY_SIZE')
    try:
        value = loads(text)
    except ValueError:
        raise ValueError('DISCOVERY_JSON') from None
    if type(value) is dict and set(value) == {'descriptors'}:
        need(type(value['descriptors']) is list and 1 <= len(value['descriptors']) <= MAX_PER_DOCUMENT, 'DISCOVERY_DOCUMENT')
        return value['descriptors']
    need(type(value) is dict and set(value) == {'body', 'signature'}, 'DISCOVERY_DOCUMENT')
    return [value]


def _origin(value):
    need(type(value) is str and len(value) <= 256, 'DISCOVERY_ORIGIN')
    try:
        parsed = urlsplit(value); port = parsed.port
    except ValueError:
        raise ValueError('DISCOVERY_ORIGIN') from None
    need(parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password
         and parsed.path in ('', '/') and not parsed.query and not parsed.fragment and port in (None, *range(1, 65536))
         and all(33 <= ord(c) <= 126 for c in value), 'DISCOVERY_ORIGIN')
    return value.rstrip('/')


def _tags(text):
    tags = {}
    for part in text.split(';'):
        if not part.strip():
            continue
        name, sep, value = part.partition('=')
        name = name.strip(' \t'); value = value.strip(' \t')
        need(sep == '=' and name and name[0].isalpha() and all(c.isalnum() or c == '_' for c in name)
             and name not in tags, 'DISCOVERY_DNS_TAGS')
        tags[name] = value
    need(next(iter(tags), None) == 'v' and tags['v'] == DNS_VERSION, 'DISCOVERY_DNS_TAGS')
    return tags


def _dns(item):
    need(set(item) == {'source', 'name', 'strings'}, 'DISCOVERY_SOURCE')
    name = item['name']
    need(type(name) is str and 5 <= len(name) <= 253 and name.lower().startswith('_aap.') and
         all(c.isalnum() or c in '-._' for c in name), 'DISCOVERY_DNS_NAME')
    strings = item['strings']
    need(type(strings) is list and 1 <= len(strings) <= 64, 'DISCOVERY_DNS_STRINGS')
    for value in strings:
        need(type(value) is str and len(value) <= 255 and all(32 <= ord(c) <= 126 for c in value), 'DISCOVERY_DNS_STRINGS')
    tags = _tags(''.join(strings))
    if 'd' in tags:
        data = ''.join(tags['d'].split())  # RFC 6376 section 3.6.1: whitespace in base64 values is ignored.
        need(data and all(c.isalnum() or c in '-_' for c in data), 'DISCOVERY_BASE64')
        try:
            raw = base64.urlsafe_b64decode(data + '=' * (-len(data) % 4))
        except ValueError:
            raise ValueError('DISCOVERY_BASE64') from None
        need(base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=') == data, 'DISCOVERY_BASE64')
        try:
            text = raw.decode('ascii')
        except UnicodeError:
            raise ValueError('DISCOVERY_JSON') from None
        return _document(text), {'locator': name.lower()}, None
    need('k' in tags and 'h' in tags, 'DISCOVERY_DNS_TAGS')
    _keyed(tags['k']); key(tags['h'])
    return [], {'locator': name.lower()}, {'key': tags['k'], 'descriptor': tags['h'], 'name': name.lower()}


def _nostr(item):
    need(set(item) == {'source', 'event'}, 'DISCOVERY_SOURCE')
    need(type(item['event']) is str and len(item['event']) <= MAX_SOURCE_BYTES, 'DISCOVERY_SIZE')
    try:
        event = loads(item['event'])
    except ValueError:
        raise ValueError('DISCOVERY_NOSTR_EVENT') from None
    need(type(event) is dict and set(event) == {'id', 'pubkey', 'created_at', 'kind', 'tags', 'content', 'sig'},
         'DISCOVERY_NOSTR_EVENT')
    need(type(event['sig']) is str and len(event['sig']) == 128 and all(c in '0123456789abcdef' for c in event['sig'])
         and type(event['kind']) is int and 0 <= event['kind'] <= 65535 and type(event['content']) is str
         and type(event['tags']) is list and len(event['tags']) <= 64
         and all(type(tag) is list and len(tag) <= 16 and all(type(v) is str for v in tag) for tag in event['tags']),
         'DISCOVERY_NOSTR_EVENT')
    key(event['id']); key(event['pubkey']); integer(event['created_at'])
    need(_nostr_id(event) == event['id'], 'DISCOVERY_NOSTR_ID')
    return _document(event['content']), {'locator': 'nostr:' + event['id'],
                                         'nostr_signature': 'NOT_VERIFIED_SECP256K1_SCHNORR_OUTSIDE_CORE'}, None


def _tlog(item, logs):
    need(set(item) == {'source', 'entry', 'index', 'size', 'path', 'checkpoint'}, 'DISCOVERY_TLOG')
    envelopes = _document(item['entry'])
    need(len(envelopes) == 1, 'DISCOVERY_TLOG')
    meta = {'locator': 'tlog', 'logged': 'UNKNOWN_LOG_NOT_ADOPTED'}
    try:
        checkpoint = item['checkpoint']
        if type(checkpoint) is dict and set(checkpoint) == {'note'}:
            origin, size, root = _note_checkpoint(checkpoint['note'], logs)
        else:
            origin, size, root = _chronicle_checkpoint(checkpoint, logs)
        need(size == item['size'], 'DISCOVERY_INCLUSION')
        opened = open_descriptor(envelopes[0])
        verify_inclusion(opened['id'], item['index'], item['size'], item['path'], root)
        meta.update(logged='INCLUDED_IN_OWNER_ADOPTED_CHECKPOINT', log=origin, log_size=size, log_index=item['index'])
    except ValueError as error:
        meta['logged'] = intro._code(error)
    return envelopes, meta, None


def _introduction(item, now):
    from . import portable_trust
    need(set(item) == {'source', 'introduction', 'descriptor'}, 'DISCOVERY_SOURCE')
    envelopes = _document(item['descriptor'])
    need(len(envelopes) == 1, 'DISCOVERY_INTRODUCTION')
    opened = open_descriptor(envelopes[0])
    record = item['introduction']
    need(type(record) is dict and type(record.get('body')) is dict, 'DISCOVERY_INTRODUCTION')
    try:
        if record['body'].get('version') == intro.VERSION:
            found = intro.open_record(record, 'INTRODUCTION')
            need(found['body']['subject'] == opened['body']['key'], 'DISCOVERY_INTRODUCTION')
            introducer, ident = found['body']['introducer'], found['id']
        else:
            body = record['body']
            ident = portable_trust.record_id(body)
            need(body['kind'] == 'INTRODUCTION', 'DISCOVERY_INTRODUCTION')
            portable_trust.verify_introduction(record, ident, [body['issuer']], body['context'], now)
            need(body['descriptor'] == opened['id'], 'DISCOVERY_INTRODUCTION')
            introducer = body['issuer']
    except (ValueError, KeyError, TypeError):
        raise ValueError('DISCOVERY_INTRODUCTION') from None
    return envelopes, {'locator': 'introduction:' + ident, 'introducer': introducer,
                       'introducer_trust': 'RANKING_DECIDES_NOT_DISCOVERY'}, None


def _source_bytes(item):
    """Exact supplied source item as escaped JSON; notes may carry U+2014 and newlines."""
    intro._bounded(item, MAX_SOURCE_BYTES * 2, 'DISCOVERY')
    raw = json.dumps(item, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode('ascii')
    need(len(raw) <= MAX_SOURCE_BYTES * 2, 'DISCOVERY_SIZE')
    return raw


def documents(rows):
    """Fetched documents the caller supplies beside a pointer source: [{url, body}], https only."""
    rows = [] if rows is None else rows
    need(type(rows) is list and len(rows) <= MAX_DOCUMENTS, 'DISCOVERY_DOCUMENTS')
    out = {}
    for row in rows:
        need(type(row) is dict and set(row) == {'url', 'body'} and type(row['url']) is str and row['url'].startswith('https://')
             and 8 < len(row['url']) <= 2048 and row['url'].isascii() and row['url'].isprintable()
             and type(row['body']) is str and len(row['body']) <= MAX_SOURCE_BYTES and row['url'] not in out,
             'DISCOVERY_DOCUMENTS')
        out[row['url']] = row['body']
    return out


def foreign_document(text):
    """Read one fetched document by its shape; return (items, meta). Only signatures inside it count."""
    from . import interop_codec as codec
    need(type(text) is str and len(text) <= MAX_SOURCE_BYTES, 'DISCOVERY_SIZE')
    try:
        value = codec.parse(text, MAX_SOURCE_BYTES, 24, 8192)
    except ValueError:
        raise ValueError('DISCOVERY_JSON') from None
    need(type(value) is dict, 'DISCOVERY_FOREIGN_DOCUMENT')
    if set(value) in ({'body', 'signature'}, {'descriptors'}):
        return _document(text), {'document': 'AAP_DESCRIPTOR'}
    if 'supportedInterfaces' in value or {'capabilities', 'skills', 'defaultInputModes'} <= set(value):
        from .a2a_discovery import extract
        return extract(value), {'document': 'A2A_AGENT_CARD'}
    if value.get('type') == 'AgentDescription' or value.get('@type') == 'ad:AgentDescription':
        from .anp_discovery import extract
        return extract(value), {'document': 'ANP_AGENT_DESCRIPTION'}
    if {'agent_name', 'endpoints', 'capabilities'} <= set(value):
        from .registry_records import agentfacts_items
        return agentfacts_items(value), {'document': 'NANDA_AGENTFACTS'}
    if {'schema_version', 'skills', 'authors'} <= set(value):
        from .registry_records import oasf_items
        return oasf_items(value), {'document': 'OASF_RECORD'}
    from . import wot_discovery
    if wot_discovery.is_thing(value):
        return wot_discovery.extract(value), {'document': 'WOT_THING_DESCRIPTION'}
    raise ValueError('DISCOVERY_FOREIGN_DOCUMENT')


def _adapt(item, logs, now):
    """(items, meta, pointers, excluded) for one source; items are envelopes or attested bodies."""
    need(type(item) is dict and item.get('source') in SOURCES, 'DISCOVERY_SOURCE')
    kind = item['source']
    if kind == 'DIRECT':
        need(set(item) == {'source', 'bytes'}, 'DISCOVERY_SOURCE')
        return _document(item['bytes']), {'locator': 'direct'}, [], []
    if kind == 'WELL_KNOWN':
        need(set(item) == {'source', 'origin', 'body'}, 'DISCOVERY_SOURCE')
        return _document(item['body']), {'locator': _origin(item['origin']) + WELL_KNOWN_PATH}, [], []
    if kind in FOREIGN_SOURCES:
        if kind == 'A2A_CARD':
            from .a2a_discovery import source
        elif kind == 'ANP':
            from .anp_discovery import source
        elif kind == 'WOT_TD':
            from .wot_discovery import source
        else:
            from .registry_records import source
            return source(item, logs)
        return source(item)
    if kind == 'DNS_TXT':
        found = _dns(item)
    elif kind == 'NOSTR':
        found = _nostr(item)
    elif kind == 'TLOG':
        found = _tlog(item, logs)
    else:
        found = _introduction(item, now)
    return found[0], found[1], [] if found[2] is None else [found[2]], []


def gather(sources, now, adopted_logs=None):
    """Verify descriptors from untrusted carriers; deduplicate by key; surface conflicts."""
    integer(now)
    need(type(sources) is list and len(sources) <= MAX_SOURCES, 'DISCOVERY_SIZE')
    intro._bounded(sources, MAX_TOTAL_BYTES, 'DISCOVERY')
    logs = _logs(adopted_logs)
    found = {}; excluded = []; pointers = []
    for index, item in enumerate(sources):
        try:
            source_hash = hashlib.sha256(_source_bytes(item)).hexdigest()
            envelopes, meta, found_pointers, refused = _adapt(item, logs, now)
        except ValueError as error:
            excluded.append({'index': index, 'status': 'EXCLUDED', 'reason': intro._code(error)})
            continue
        for pointer in found_pointers:
            pointers.append({'index': index, **pointer, 'assurance': pointer.get('assurance', 'UNSIGNED_DNS_POINTER_NO_CLAIMS')})
        excluded.extend({'index': index, 'status': 'EXCLUDED', 'reason': reason} for reason in refused)
        for envelope in envelopes:
            try:
                if type(envelope) is tuple:
                    opened, signature_format = _open_attested(envelope)
                else:
                    opened, signature_format = open_descriptor(envelope), 'AAP_ED25519'
            except ValueError as error:
                excluded.append({'index': index, 'status': 'EXCLUDED', 'reason': intro._code(error)})
                continue
            row = found.setdefault(opened['id'], {'id': opened['id'], 'body': opened['body'],
                                                  'envelope': opened['envelope'], 'sources': []})
            entry = {'index': index, 'source': item['source'], 'sha256': source_hash, **meta,
                     'signature_format': signature_format, 'transport_verified': False}
            if entry not in row['sources']:
                row['sources'].append(entry)
    for pointer in pointers:
        if pointer.get('descriptor') in found and found[pointer['descriptor']]['body']['key'] == pointer.get('key'):
            found[pointer['descriptor']]['sources'].append({'index': pointer['index'], 'source': 'DNS_TXT_POINTER',
                                                            'locator': pointer['name'], 'transport_verified': False})
    by_key = {}
    for row in found.values():
        body = row['body']
        if body['issued_at'] > now:
            row['status'] = 'NOT_YET_VALID'
        elif now >= body['expires']:
            row['status'] = 'EXPIRED'
        else:
            row['status'] = 'VALID'
        by_key.setdefault(body['key'], []).append(row)
    agents = []
    for agent_key, rows in sorted(by_key.items()):
        rows.sort(key=lambda row: (row['body']['sequence'], row['id']))
        valid = [row for row in rows if row['status'] == 'VALID']
        evidence = []
        by_sequence = {}
        for row in rows:
            by_sequence.setdefault(row['body']['sequence'], []).append(row['id'])
        for sequence, ids in sorted(by_sequence.items()):
            if len(ids) > 1:
                evidence.append({'kind': 'EQUIVOCATION', 'sequence': sequence, 'descriptors': sorted(ids),
                                 'proof': 'SAME_KEY_SIGNED_DIFFERENT_DESCRIPTORS_FOR_ONE_SEQUENCE'})
        ids_by_sequence = {sequence: ids[0] for sequence, ids in by_sequence.items() if len(ids) == 1}
        for row in rows:
            earlier = ids_by_sequence.get(row['body']['sequence'] - 1)
            if row['body']['sequence'] and earlier is not None and row['body']['previous'] != earlier:
                evidence.append({'kind': 'FORK', 'sequence': row['body']['sequence'], 'descriptors': [earlier, row['id']],
                                 'proof': 'PREVIOUS_LINK_DOES_NOT_NAME_THE_SIGNED_PREDECESSOR'})
        if evidence:
            status, chosen = 'CONFLICT', None
        elif valid:
            status, chosen = 'SELECTED', valid[-1]
        else:
            status, chosen = ('EXPIRED' if any(r['status'] == 'EXPIRED' for r in rows) else 'NOT_YET_VALID'), None
        kinds = sorted({src['source'] for row in rows for src in row['sources']})
        agents.append({
            'key': agent_key, 'status': status, 'selected': None if chosen is None else chosen['id'],
            'descriptor': None if chosen is None else deepcopy(chosen['body']),
            'descriptors': [{'id': row['id'], 'sequence': row['body']['sequence'], 'status': row['status'],
                             'sources': deepcopy(row['sources'])} for row in rows],
            'conflicts': evidence, 'source_kinds': kinds,
            'source_count': sum(len(row['sources']) for row in rows),
            'logged': any(src.get('logged') == 'INCLUDED_IN_OWNER_ADOPTED_CHECKPOINT' for row in rows
                          for src in row['sources']),
            'currentness': 'HIGHEST_SEEN_IN_SUPPLIED_SOURCES_NOT_GLOBAL_LATEST',
            'merged': False, 'sources_add_trust': False,
        })
    return {'version': VERSION, 'as_of': now, 'agents': agents, 'excluded': excluded, 'pointers': pointers,
            'clock': 'CALLER_ASSERTION', 'only_signatures_count': True, 'sources_add_trust': False,
            'network_accessed': False, 'installed': False, 'execution_authorized': False}


def operator_links(gathered):
    """[agent key, declared operator] pairs for anchored_reputation clustering (claims, not proof)."""
    need(type(gathered) is dict and type(gathered.get('agents')) is list, 'DISCOVERY_FIELDS')
    return [[row['key'], row['descriptor']['operator']] for row in gathered['agents']
            if row['status'] == 'SELECTED' and row['descriptor']['operator'] is not None]


def search(goal, gathered, *, task_class=None, ranking=None, order='RELEVANCE', **options):
    """Rank selected descriptors for a goal with the existing offline request discovery.

    ``ranking`` may be an anchored_reputation.rank() result computed by the
    principal; it is attached, and with order ANCHORED it orders lexical matches.
    """
    from .request_discovery import search as request_search
    need(order in ('RELEVANCE', 'ANCHORED'), 'DISCOVERY_ORDER')
    need(type(gathered) is dict and type(gathered.get('agents')) is list, 'DISCOVERY_FIELDS')
    selected = {row['key']: row for row in gathered['agents'] if row['status'] == 'SELECTED'
                and (task_class is None or task_class in row['descriptor']['task_classes'])}
    records = []
    for agent_key, row in sorted(selected.items()):
        body = row['descriptor']
        records.append({'format': 'GENERIC', 'source': 'COVENANT_SIGNED_DISCOVERY',
                        'freshness': 'SIGNED_DESCRIPTOR_WINDOW_AT_CALLER_CLOCK',
                        'record': {'target': {'kind': 'agent', 'id': agent_key}, 'title': body['name'],
                                   'description': ' '.join([body['summary'], *body['task_classes']]).strip(),
                                   'attributes': {'task_classes': body['task_classes'],
                                                  'transports': sorted({e['transport'] for e in body['endpoints']}),
                                                  'sequence': body['sequence']},
                                   'links': []}})
    result = request_search(goal, records, **options)
    standing = {}
    if ranking is not None:
        need(type(ranking) is dict and type(ranking.get('ranking')) is list, 'DISCOVERY_FIELDS')
        standing = {row['provider']: row for row in ranking['ranking']}
    for row in result['ranking'] + result['excluded']:
        agent_key = row['target']['id']
        found = selected[agent_key]
        row['signed_descriptor'] = found['selected']; row['signature_verified'] = True
        row['source_kinds'] = found['source_kinds']; row['logged'] = found['logged']
        if agent_key in standing:
            row['anchored'] = {name: standing[agent_key][name] for name in ('score', 'standing', 'independent_positive')}
    if order == 'ANCHORED':
        position = {id(row): index for index, row in enumerate(result['ranking'])}
        result['ranking'].sort(key=lambda row: (not row['lexical_match'], -row.get('anchored', {}).get('score', 0),
                                                position[id(row)]))
    result['discovery'] = {'version': VERSION, 'order': order, 'conflicts_excluded': sorted(
        row['key'] for row in gathered['agents'] if row['status'] == 'CONFLICT'), 'only_signatures_count': True}
    return result


def describe():
    return {'version': VERSION, 'status': 'EXPERIMENTAL_APPLICATION_PROFILE', 'label': LABEL,
            'descriptor_fields': FIELDS.split(), 'sources': list(SOURCES), 'transports': list(TRANSPORTS),
            'well_known_path': WELL_KNOWN_PATH, 'well_known_registration': 'PROPOSED_NOT_IANA_REGISTERED',
            'dns': {'label': '_aap', 'version_tag': 'v=' + DNS_VERSION, 'tags': {'d': 'base64url descriptor',
                    'k': 'key pointer', 'h': 'descriptor id pointer'}, 'unknown_tags': 'IGNORED_RFC6376'},
            'nostr': {'kind_default': 30078, 'id': 'RECOMPUTED_NIP01', 'signature': 'NOT_VERIFIED_NOT_NEEDED'},
            'tlog': {'leaf': 'RFC9162_LEAF_OF_32_BYTE_DESCRIPTOR_ID', 'inclusion': 'RFC9162_2.1.3.2',
                     'checkpoints': ['C2SP_SIGNED_NOTE', 'COVENANT_CHRONICLE_0.1'], 'logs': 'OWNER_ADOPTED_ONLY',
                     'ans_logs': 'ANS_TL root-keys lines check ANS badges in ANS sources'},
            'foreign': {'sources': list(FOREIGN_SOURCES), 'signature_formats': list(SIGNATURE_FORMATS),
                        'documents_per_source': MAX_DOCUMENTS,
                        'rule': 'A_FOREIGN_SIGNATURE_COUNTS_ONLY_WHEN_MADE_BY_THE_KEY_THE_DESCRIPTOR_NAMES'},
            'selection': 'HIGHEST_VALID_SEQUENCE_UNLESS_EQUIVOCATION_OR_FORK_THEN_CONFLICT_SURFACED',
            'limits': {'sources': MAX_SOURCES, 'source_bytes': MAX_SOURCE_BYTES, 'total_bytes': MAX_TOTAL_BYTES,
                       'descriptor_bytes': MAX_DESCRIPTOR_BYTES, 'per_document': MAX_PER_DOCUMENT,
                       'proof_hashes': MAX_PROOF, 'adopted_logs': MAX_LOGS},
            'remediation': dict(REMEDIATION), 'only_signatures_count': True, 'sources_add_trust': False,
            'network_accessed': False, 'installed': False, 'execution_authorized': False}
