"""Portable explicit proof statements and pinned, owner-installed verification.

Unknown proof systems remain transportable. Only a verifier installed by the
operator can interpret them. Valid means that verifier accepted this statement,
not that inputs are truthful, authority exists, or an external effect occurred.
"""
from copy import deepcopy
import base64,hashlib
from .crypto import canonical,digest,exact,key,need,verify
VERSION='covenant-proof-envelope/0.1'

def binary(value,maximum=65536):
    need(type(value) is str and len(value)<=4*((maximum+2)//3),'PROOF_SIZE')
    try:raw=base64.b64decode(value,validate=True)
    except ValueError:raise ValueError('PROOF_ENCODING') from None
    need(len(raw)<=maximum and base64.b64encode(raw).decode()==value,'PROOF_ENCODING');return raw

def pack(system,statement,proof,context):
    need(type(system) is str and 0<len(system)<=128,'PROOF_SYSTEM');key(context)
    need(type(statement) is dict,'PROOF_STATEMENT');binary(proof)
    body={'version':VERSION,'system':system,'statement':deepcopy(statement),'proof':proof,'context':context};canonical(body)
    return {'id':digest('COVENANT-PROOF-ENVELOPE-0.1',body),'envelope':body,'status':'UNVERIFIED','execution_authorized':False}

def inspect(envelope):
    exact(envelope,'version system statement proof context');need(envelope['version']==VERSION,'PROOF_VERSION')
    return pack(**{k:v for k,v in envelope.items() if k!='version'})

def commitment(data,salt,context):
    key(context);raw=binary(data);nonce=binary(salt,64);need(32<=len(nonce)<=64,'PROOF_SALT_SIZE')
    return hashlib.sha256(b'COVENANT-SALTED-COMMITMENT-0.1\0'+bytes.fromhex(context)+len(nonce).to_bytes(2,'big')+nonce+raw).hexdigest()

def _hash(envelope):
    statement=envelope['statement'];exact(statement,'commitment salt')
    key(statement['commitment'])
    return commitment(envelope['proof'],statement['salt'],envelope['context'])==statement['commitment']

def _signature(envelope):
    statement=envelope['statement'];exact(statement,'public message');need(type(statement['message']) is dict,'PROOF_STATEMENT')
    signature=binary(envelope['proof'],8192).hex()
    verify(statement['public'],'COVENANT-PROOF-STATEMENT-0.1',{'context':envelope['context'],'message':statement['message']},signature)
    return True

def merkle_leaf(data):return hashlib.sha256(b'\x00'+data).hexdigest()
def merkle_node(left,right):return hashlib.sha256(b'\x01'+bytes.fromhex(left)+bytes.fromhex(right)).hexdigest()
def _merkle(envelope):
    statement=envelope['statement'];exact(statement,'root path');key(statement['root'])
    need(type(statement['path']) is list and len(statement['path'])<=64,'PROOF_MERKLE_PATH')
    value=merkle_leaf(binary(envelope['proof']))
    for step in statement['path']:
        exact(step,'side hash');key(step['hash']);need(step['side'] in {'LEFT','RIGHT'},'PROOF_MERKLE_SIDE')
        value=merkle_node(step['hash'],value) if step['side']=='LEFT' else merkle_node(value,step['hash'])
    return value==statement['root']

BUILTINS={
 'sha256-salted-opening/0.1':(_hash,'CONTEXT_BOUND_SALTED_SHA256_PREIMAGE_NOT_TRUTH_OR_HIDING_FOR_WEAK_SALTS'),
 'domain-signature/0.1':(_signature,'DOMAIN_BOUND_ED25519_OR_ML_DSA_65_ATTRIBUTION_NOT_TRUTH'),
 'sha256-merkle-path/0.1':(_merkle,'DOMAIN_SEPARATED_BINARY_TREE_PATH_MEMBERSHIP_NOT_TREE_SIZE_ORDER_OR_UNIQUENESS')}

class ProofRegistry:
    def __init__(self):
        self.entries={};self.provers={}
        for system,(callback,scope) in BUILTINS.items():
            semantics=digest('COVENANT-BUILTIN-PROOF-SEMANTICS-0.1',{'system':system,'scope':scope})
            self.register({'system':system,'semantics':semantics,'implementation':hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest(),
                'scope':scope,'trust':'LOCAL_INSTALLED_CRYPTOGRAPHIC_VERIFIER'},callback)
    def register(self,manifest,callback):
        exact(manifest,'system semantics implementation scope trust');need(callable(callback),'PROOF_VERIFIER')
        need(type(manifest['system']) is str and 0<len(manifest['system'])<=128,'PROOF_SYSTEM')
        for f in ('semantics','implementation'):key(manifest[f])
        for f in ('scope','trust'):need(type(manifest[f]) is str and 0<len(manifest[f])<=512,'PROOF_VERIFIER')
        ref=digest('COVENANT-PROOF-VERIFIER-0.1',manifest);need(ref not in self.entries,'PROOF_VERIFIER_EXISTS')
        self.entries[ref]=(deepcopy(manifest),callback);return ref
    def register_prover(self,verifier,callback):
        need(verifier in self.entries and verifier not in self.provers and callable(callback),'PROOF_PROVER_INSTALLATION')
        self.provers[verifier]=callback
    def prove(self,verifier,statement,context,witness):
        key(context);need(verifier in self.provers and verifier in self.entries,'PROOF_PROVER_NOT_INSTALLED')
        need(type(statement) is dict and type(witness) is dict,'PROOF_STATEMENT')
        need(digest('COVENANT-PROOF-VERIFIER-0.1',self.entries[verifier][0])==verifier,'PROOF_VERIFIER_CHANGED')
        canonical(statement);canonical(witness)
        try:raw=self.provers[verifier](deepcopy(statement),context,deepcopy(witness))
        except Exception:raise ValueError('PROOF_GENERATION_FAILED') from None
        envelope=pack(self.entries[verifier][0]['system'],statement,raw,context)['envelope']
        result=self.verify(envelope,verifier,context,statement)
        need(result['verified'],'PROOF_GENERATED_PROOF_NOT_VERIFIED')
        return {**result,'separate_witness_field_returned':False,'zero_knowledge':'ONLY_IF_THE_INSTALLED_PROOF_SYSTEM_ESTABLISHES_IT','witness_privacy':'TRUSTED_LOCAL_PROVER_AND_CALLER_INPUT_BOUNDARY'}
    def describe(self):return {ref:deepcopy(m) for ref,(m,_) in self.entries.items()}
    def verify(self,envelope,verifier,expected_context,expected_statement):
        info=inspect(envelope);key(verifier);key(expected_context)
        need(envelope['context']==expected_context and canonical(envelope['statement'])==canonical(expected_statement),'PROOF_EXPECTATION_MISMATCH')
        if verifier not in self.entries:return {**info,'status':'UNKNOWN_VERIFIER','verified':False}
        manifest,callback=self.entries[verifier]
        need(digest('COVENANT-PROOF-VERIFIER-0.1',manifest)==verifier,'PROOF_VERIFIER_CHANGED')
        need(manifest['system']==envelope['system'],'PROOF_SYSTEM_MISMATCH')
        try:
            result=callback(deepcopy(envelope));need(type(result) is bool,'PROOF_VERIFIER_RESULT')
            status='VALID' if result else 'INVALID'
        except Exception:status='VERIFICATION_FAILED'
        return {**info,'status':status,'verified':status=='VALID','verifier':verifier,'scope':manifest['scope'],
                'trust':manifest['trust'],'world_truth':'NOT_ESTABLISHED','authority':'NOT_ESTABLISHED','execution_authorized':False}


CARRIER_SYSTEM='uninterpreted-carrier/0.1'
CARRIER_SCOPE='BYTE_IDENTITY_OF_UNINTERPRETED_CARRIER_NOT_EXECUTION_OR_TRUTH'


def carrier_statement(language, source, semantics):
    """Statement that names bytes. It does not interpret or execute them."""
    need(type(language) is str and 0<len(language)<=128,'CARRIER_LANGUAGE')
    need(type(source) is bytes and len(source)<=65536,'PROOF_SIZE')
    key(semantics)
    return {'language':language,'source_sha256':hashlib.sha256(source).hexdigest(),'semantics':semantics,'executed':False}


def install_carrier_verifier(registry):
    """Owner-installed checker: the proof bytes match the statement.

    Unknown languages stay data. Registering this verifier does not make
    capsules.compute adopt them, and the callback never executes source.
    It is not a builtin, so a stock ProofRegistry does not attest carriers.
    """
    semantics=digest('COVENANT-CARRIER-VERIFIER-0.1',{'system':CARRIER_SYSTEM,'scope':CARRIER_SCOPE})
    manifest={'system':CARRIER_SYSTEM,'semantics':semantics,
              'implementation':hashlib.sha256(b'uninterpreted-carrier/0.1').hexdigest(),
              'scope':CARRIER_SCOPE,'trust':'OWNER_INSTALLED_BYTE_MATCH_NOT_AN_INTERPRETER'}
    def callback(envelope):
        statement=envelope['statement']
        exact(statement,'language source_sha256 semantics executed')
        need(statement['executed'] is False,'CARRIER_EXECUTED')
        need(type(statement['language']) is str and 0<len(statement['language'])<=128,'CARRIER_LANGUAGE')
        key(statement['source_sha256']);key(statement['semantics'])
        raw=binary(envelope['proof'])
        return hashlib.sha256(raw).hexdigest()==statement['source_sha256']
    return registry.register(manifest,callback)


def register_atr_hash(registry):
    """Owner-installed ``atr-hash/1`` verifier (lcp_buyer). Experimental; not a builtin."""
    from .lcp_buyer import register_verifier
    return register_verifier(registry)


def register_acceptance_verdict(registry, runners=None):
    """Owner-installed ``acceptance-verdict/1`` verifier; pin ``runners`` for more than attribution."""
    from .acceptance_tests import register_verifier
    return register_verifier(registry, runners=runners)


def register_git_anchor(registry, signers=None):
    """Owner-installed ``git-anchor/1`` verifier; pin ``signers`` for more than attribution."""
    from .git_anchors import register_verifier
    return register_verifier(registry, signers=signers)
