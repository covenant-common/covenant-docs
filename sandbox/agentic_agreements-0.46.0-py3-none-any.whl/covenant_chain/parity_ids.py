"""Shared names, codes and profile strings for the PR 73 parity guards.

Experimental. The offline receipt checks, trading limits, key provider and
offline evidence records import these instead of inventing parallel spellings.
Nothing here is consulted by ``apply_transaction``. ``remediation`` gives the
next step for every code these modules emit.
"""

# Offline receipt checks are covenant_portable_trust actions. The PR 73 tool
# name covenant_verify is the agent-native work-order verb and is not reused.
VERIFY_ACTIONS = ('atr_hash', 'verify_atr', 'verify_opencovenant_receipt',
                  'verify_causal_receipt', 'verify_trust_bundle')
ATR_VERSION = 'covenant-atr-hash/0.1'
OPENCOVENANT_RECEIPT_DOMAIN = 'opencovenant.receipt.v1'
OPENCOVENANT_RECEIPT_VERSION = 'opencovenant-receipt/0.1'
OPENCOVENANT_INTEROP = 'UNVERIFIED_NO_EXTERNAL_VECTORS'
CODE_VERIFIED = 'VERIFIED'
CODE_BYTE_MISMATCH = 'BYTE_MISMATCH'
CODE_SIGNATURE_INVALID = 'SIGNATURE_INVALID'
CODE_SIGNER_NOT_PINNED = 'SIGNER_NOT_PINNED'
CODE_BUNDLE_PART_FAILED = 'BUNDLE_PART_FAILED'

# Trading limits on a reliance.GatedAdapter route.
TRADING_DECISION_VERSION = 'covenant-trading-decision/0.1'
TRADING_STORE_VERSION = 'covenant-trading-store/0.1'
TRADING_DECISION_DOMAIN = 'COVENANT-TRADING-DECISION-0.1'
TRADING_ANCHOR_DOMAIN = 'COVENANT-TRADING-ANCHOR-0.1'
CODE_ALLOW = 'ALLOW'
CODE_ALLOW_READ = 'ALLOW_READ'
CODE_ALLOW_DRY_RUN = 'ALLOW_DRY_RUN'
CODE_NEEDS_HUMAN = 'NEEDS_HUMAN'
CODE_FAIL_CLOSED = 'FAIL_CLOSED'
CODE_DENY_UNKNOWN_TOOL = 'DENY_UNKNOWN_TOOL'
CODE_DENY_ALLOWLIST = 'DENY_ALLOWLIST'
CODE_DENY_PER_CALL = 'DENY_PER_CALL'
CODE_DENY_DAILY = 'DENY_DAILY_CAP'
CODE_DENY_LOSS = 'DENY_LOSS_STOP'
CODE_DENY_LOSS_UNKNOWN = 'DENY_LOSS_UNKNOWN'
CODE_DENY_RATE = 'DENY_RATE'
FORWARD_CODES = (CODE_ALLOW, CODE_ALLOW_READ)

# At-rest host blobs.
KEY_PROVIDER_VERSION = 'covenant-key-provider/0.1'

# Offline evidence records and the courier EVIDENCE kind.
EVIDENCE_VERSION = 'covenant-offline-evidence/0.1'
BOND_PROOF_DOMAIN = 'COVENANT-BOND-COVERAGE-0.1'
VERDICT_DOMAIN = 'COVENANT-TEST-VERDICT-0.1'
EVIDENCE_KINDS = ('ATR', 'BOND', 'VERDICT')
CODE_EVIDENCE_NOT_SUBMITTED = 'EVIDENCE_NOT_SUBMITTED'

REMEDIATION = {
    'VERIFIED': 'Nothing to repair. The bytes match the pinned hash or a pinned signer signed them; that is integrity, not world truth.',
    'BYTE_MISMATCH': 'The bytes differ from the expected hash or receipt id. Obtain the original exact bytes; never replace the expected value to make a check pass.',
    'SIGNATURE_INVALID': 'The signature does not cover these exact bytes. Request the original signed receipt; any edit invalidates it.',
    'SIGNER_NOT_PINNED': 'A valid signature from an unpinned key only shows that someone signed. Add a signer to signers only after adopting it through your own channel.',
    'BUNDLE_PART_FAILED': 'Read parts for the failing check and repair that part. A bundle verifies only when every supplied part verifies.',
    'TRUST_ATR_FIELDS': 'Pass atr_hash with exactly one of bytes_ascii or bytes_base64.',
    'TRUST_ATR_BYTES': 'Send the exact terms as printable ASCII of at most 65536 characters, or as canonical base64.',
    'TRUST_ATR_SIZE': 'Agreement terms are 1 to 262144 bytes. Pin a larger document by a content reference instead.',
    'TRUST_ATR_HASH': 'atr_hash is 64 lowercase hex characters: SHA-256 of the exact terms bytes.',
    'TRUST_RECEIPT': 'Pass an opencovenant-receipt/0.1 object with version, body, public and signature; body is a JSON object of at most 65536 canonical bytes and public an Ed25519 key.',
    'TRUST_RECEIPT_VERSION': 'Only opencovenant-receipt/0.1 is checked here. Another receipt profile needs its own verifier.',
    'TRUST_SIGNERS': 'Pass 1 to 32 distinct pinned Ed25519 public keys, 64 lowercase hex each, in signers.',
    'TRUST_BUNDLE': 'A bundle carries receipt {domain, event, optional expected_id}, atr {atr_hash, bytes_ascii or bytes_base64} and an optional credential {presentation, policy, nonce, now}.',
    'ALLOW': 'Passed the trading limits and goes to the mandate wallet. Observe the wallet receipt before relying on a fill.',
    'ALLOW_READ': 'Owner-listed read. It goes to the mandate wallet without using the trading counters.',
    'ALLOW_DRY_RUN': 'Policy mode is dry_run: the order passed every limit and was not sent. The owner switches mode to enforce to trade.',
    'NEEDS_HUMAN': 'The amount is at or above approvals.require_human_over_usd. A person places or approves it through a separately approved path; no tool call waives this.',
    'FAIL_CLOSED': 'The order is unreadable. Send symbol, side, order_type and exactly one whole-USD integer amount or notional.',
    'DENY_UNKNOWN_TOOL': 'The operation is neither an owner-listed order nor an owner-listed read. Unknown operations are never forwarded; ask the owner to classify it.',
    'DENY_ALLOWLIST': 'Symbol, side or order type is outside universe.allow, universe.sides or order_types.',
    'DENY_PER_CALL': 'The amount exceeds caps.per_order_usd. Place a smaller order.',
    'DENY_DAILY_CAP': 'The order would pass caps.daily_notional_usd for the current UTC day. Wait for the next UTC day.',
    'DENY_LOSS_STOP': 'Realized loss for the UTC day reached risk.daily_loss_stop_usd. Orders stop until the next UTC day.',
    'DENY_LOSS_UNKNOWN': 'No realized loss is recorded for the current UTC day. The owner records it with set_realized_loss before any order passes.',
    'DENY_RATE': 'rate.max_orders_per_min orders passed in the last 60 seconds. Wait, then send the order with a new effect id.',
    'TRADING_POLICY': 'Pass a policy object with venue, caps, risk, universe, order_types, rate, approvals and an optional mode.',
    'TRADING_POLICY_FIELDS': 'Use exactly the published policy fields; unknown fields fail closed.',
    'TRADING_TEXT': 'Venue, symbols and order types are printable ASCII of bounded length.',
    'TRADING_MODE': 'mode is dry_run or enforce.',
    'TRADING_CAPS': 'caps.per_order_usd must not exceed caps.daily_notional_usd; both are positive whole USD.',
    'TRADING_ALLOWLIST': 'universe.allow is a sorted list of 1 to 64 distinct symbols.',
    'TRADING_SIDES': 'universe.sides is a sorted list drawn from buy and sell.',
    'TRADING_ORDER_TYPES': 'order_types is a sorted list of 1 to 8 distinct order types.',
    'TRADING_RATE': 'rate.max_orders_per_min is a whole number from 1 to 10000.',
    'TRADING_OPERATIONS': 'orders and reads are disjoint lists of owner adapter operation aliases; at least one order alias is required.',
    'TRADING_OWNER': 'Construct TradingLimits with an owner signing key and an integer UTC clock.',
    'TRADING_REQUEST': 'Route requests are the adapter shape {protocol, operation, parameters}.',
    'TRADING_CLOCK_REWIND': 'The owner clock went backwards. Repair the clock; counters never rewind.',
    'TRADING_EFFECT_CHANGED': 'This effect id was already allowed for different request bytes. Use a new effect id for a new order.',
    'TRADING_POLICY_CHANGED': 'The policy changed after this effect was allowed. Observe the effect through the gate; send any new order under the new policy with a new effect id.',
    'TRADING_STORE_CONTEXT': 'This directory holds counters for another venue. Use one directory per venue.',
    'TRADING_STORE_QUOTA': 'The counter store is full. Archive the directory with its owner records, then open a fresh store.',
    'TRADING_RECEIPT_VERSION': 'Only covenant-trading-decision/0.1 decisions verify here.',
    'TRADING_SIGNER_NOT_PINNED': 'The decision was signed by a key other than the pinned gate key. Do not rely on it.',
    'KEY_PROVIDER_KEY': 'LocalKeyProvider takes exactly 32 random key bytes from owner custody, never a passphrase or a tool argument.',
    'KEY_PROVIDER_KEY_ID': 'The blob names another key id or provider. Open it with that provider, then rotate.',
    'KEY_PROVIDER_PLAINTEXT': 'Seal bytes, at most 1000000 per blob.',
    'KEY_PROVIDER_AAD': 'Pass the same context bytes, at most 4096, that were used when sealing.',
    'KEY_PROVIDER_VERSION': 'Only covenant-key-provider/0.1 blobs open here.',
    'KEY_PROVIDER_FORMAT': 'The sealed document is malformed. Restore it from a backup; do not edit it.',
    'KEY_PROVIDER_OPEN': 'Authentication failed: wrong key, changed bytes or changed context. Do not guess keys; restore the blob or use the provider that sealed it.',
    'KEY_PROVIDER_KMS': 'Inject a client with encrypt(key_id, plaintext, aad) and decrypt(key_id, token, aad). Its credentials and timeouts are the owner\'s; a failed call seals nothing.',
    'KEY_PROVIDER_KMS_TOKEN': 'The KMS client must return an ASCII token of at most 2000000 characters.',
    'KEY_PROVIDER_SEAL': 'Pass a KeyProvider with a callable seal(plaintext, aad=...).',
    'KEY_PROVIDER_SUCCESSOR': 'rotate takes a successor provider, 32 key bytes for a local provider, or a key id for a KMS provider.',
    'EVIDENCE_VERSION': 'Only covenant-offline-evidence/0.1 records are read.',
    'EVIDENCE_KIND': 'Evidence records are ATR, BOND or VERDICT, carried in a DATA envelope.',
    'EVIDENCE_ATR': 'The carried terms do not hash to atr_hash. Request the exact bytes again.',
    'EVIDENCE_BOND': 'A bond proof carries whole numbers 0 <= locked <= bond <= 2^53-1.',
    'EVIDENCE_OUTCOME': 'A verdict outcome is SUPPORTED, REFUTED or UNKNOWN.',
    'EVIDENCE_SIGNER': 'The record signer is not in signers. Pin the signer through your own channel first.',
    'EVIDENCE_SET': 'Seal 1 to 16 records per envelope.',
    'EVIDENCE_NOT_SUBMITTED': 'Evidence ids are offline records, never transactions. Verify the full records with offline_evidence.open_carried.',
    'COURIER_EVIDENCE': 'Courier EVIDENCE items are exactly {kind, id}: kind ATR, BOND or VERDICT and a 64-hex id.',
}


def remediation(code):
    """Next step for a parity-guard code, or None for a code these modules do not emit."""
    return REMEDIATION.get(code) if type(code) is str else None
