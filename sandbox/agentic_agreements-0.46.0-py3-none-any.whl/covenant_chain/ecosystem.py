"""Opt-in institution profile: bounded governance, treasury and service markets.

Consensus authenticates records. External performance remains a resolver claim.
No modules, prose or unknown mechanism references execute arbitrary code.
"""
from .profile import MIGRATION_VERSION
from copy import deepcopy
from .crypto import exact, need, key, integer, digest, verify, sign
VERSION='covenant-institution/0.1'
LABEL='COVENANT-INSTITUTION-APPROVAL-0.1'
TABLES=('worlds','world_roles','world_services','world_jobs','world_catalogue','world_seeds')

def seed(name, governors, threshold, constitution, *, ancestry=(), modules=()):
    obj={'version':VERSION,'name':name,'governors':sorted(governors),'threshold':threshold,
         'constitution':constitution,'ancestry':sorted(ancestry),'modules':sorted(modules),
         'governance':'threshold/1','publication':'PUBLIC'}
    validate_seed(obj);return obj

def validate_seed(x):
    exact(x,'version name governors threshold constitution ancestry modules governance publication')
    need(x['version']==VERSION and x['governance']=='threshold/1' and x['publication']=='PUBLIC','WORLD_PROFILE')
    need(type(x['name']) is str and 0<len(x['name'])<=128,'WORLD_NAME')
    key(x['constitution']);integer(x['threshold'],True)
    for field,limit in [('governors',64),('ancestry',8),('modules',64)]:
        values=x[field];need(type(values) is list and len(values)<=limit and values==sorted(set(values)),'WORLD_SET')
        for value in values:
            if field=='modules':
                from covenant_language.agentic import _hash
                _hash(value)
            else:key(value)
    need(1<=x['threshold']<=len(x['governors']),'WORLD_THRESHOLD')

def approval_body(chain, op, payload):
    return {'chain':chain,'op':op,'payload':{k:v for k,v in payload.items() if k!='approvals'}}

def approve(private_key,chain,op,payload,actor=None):
    from .crypto import public_key
    return {'signer':actor or public_key(private_key),'signature':sign(private_key,LABEL,approval_body(chain,op,payload))}

def authorized(s,governors,threshold,proofs,op,p):
    from .approval import authorized as check
    return check(s,governors,threshold,proofs,op,p)

def world(s,p):
    key(p['world']);need(p['world'] in s['worlds'],'WORLD_MISSING')
    w=s['worlds'][p['world']];need(w['status']=='ACTIVE','WORLD_INACTIVE');return w

def governed(s,p,op):
    w=world(s,p);integer(p['revision']);need(p['revision']==w['revision'],'WORLD_REVISION')
    authorized(s,w['seed']['governors'],w['seed']['threshold'],p['approvals'],op,p)
    return w

def move(s,source,target,resource,quantity):
    from .balances import move as transfer
    return transfer(s,source,target,resource,quantity)

def role_path(s,rid,actor,height):
    # Ids are strings; other JSON values are refused before any table lookup.
    need(type(rid) is str,'WORLD_ROLE');path=[]
    while rid is not None:
        need(rid in s['world_roles'] and len(path)<16 and rid not in [a for a,b in path],'WORLD_ROLE')
        r=s['world_roles'][rid]
        need(not r['revoked'] and height<r['expiry'],'WORLD_ROLE_EXPIRED')
        if 'heartbeat' in r:need(height<=r['last_seen']+r['heartbeat'],'WORLD_HEARTBEAT_EXPIRED')
        w=s['worlds'][r['world']];need(w['status']=='ACTIVE' and r['epoch']==w['role_epoch'],'WORLD_ROLE_EPOCH')
        if not path:need(r['holder']==actor,'WORLD_ROLE_HOLDER')
        path.append((rid,r));rid=r['parent']
    return path

def apply(s,old,op,p,actor,tid,height):
    if not op.startswith('WORLD_'):return None
    if s.get('protocol')==MIGRATION_VERSION:
        from .world_migration import apply as migrated_apply
        migrated=migrated_apply(s,op,p,actor,tid,height)
        if migrated is not None:return migrated
    parents=[]
    if op=='WORLD_CREATE':
        exact(p,'seed approvals');validate_seed(p['seed'])
        for ancestor in p['seed']['ancestry']:need(ancestor in s['worlds'],'WORLD_ANCESTRY')
        # Every initial governor must accept appointment, including institution governors.
        authorized(s,p['seed']['governors'],len(p['seed']['governors']),p['approvals'],op,p)
        for module in p['seed']['modules']:need(module in s['world_catalogue'],'WORLD_MODULE_MISSING')
        sid=digest('COVENANT-WORLD-SEED',p['seed']);need(sid not in s['world_seeds'],'WORLD_SEED_EXISTS')
        s['world_seeds'][sid]=tid
        s['worlds'][tid]={'seed':deepcopy(p['seed']),'revision':0,'role_epoch':0,'status':'ACTIVE','members':list(p['seed']['governors']),'successor':None}
        parents=p['seed']['ancestry']
    elif op=='WORLD_MODULE':
        exact(p,'body');from covenant_language.agentic import object_id,validate_module_registry
        mid=object_id(p['body'])
        if s.get('protocol') in {'covenant-native/0.8','covenant-native/0.9','covenant-native/0.10','covenant-native/0.11','covenant-native/0.12','covenant-native/0.13','covenant-native/0.14','covenant-native/0.15',MIGRATION_VERSION}:
            # Bound work per installation, not the entire historical catalogue.
            # The newly adopted profile preserves old <=0.7 acceptance rules.
            # Traverse only the exact immutable dependency closure. References
            # are never interpreted as paths or executable module imports.
            from covenant_language.agentic import _hash,MAX_MODULES
            registry={mid:p['body']};pending=[mid]
            while pending:
                ref=pending.pop();body=registry[ref]
                need(type(body) is dict and type(body.get('dependencies')) is list,'WORLD_MODULE_DEPENDENCIES')
                need(len(body['dependencies'])<=MAX_MODULES,'WORLD_MODULE_DEPENDENCY_LIMIT')
                for dependency in body['dependencies']:
                    _hash(dependency)
                    if dependency in registry:continue
                    need(dependency in s['world_catalogue'],'WORLD_MODULE_DEPENDENCY_MISSING')
                    need(len(registry)<MAX_MODULES,'WORLD_MODULE_DEPENDENCY_LIMIT')
                    registry[dependency]=s['world_catalogue'][dependency]['body'];pending.append(dependency)
        else:
            registry={k:v['body'] for k,v in s['world_catalogue'].items()};registry[mid]=p['body']
        validate_module_registry(registry);need(mid not in s['world_catalogue'],'WORLD_MODULE_EXISTS')
        s['world_catalogue'][mid]={'body':deepcopy(p['body']),'publisher':actor,'event':tid}
    elif op=='WORLD_FUND':
        exact(p,'world resource quantity');world(s,p);move(s,actor,p['world'],p['resource'],p['quantity']);parents=[p['world']]
    elif op in {'WORLD_AMEND','WORLD_MEMBER','WORLD_ROLE','WORLD_REVOKE','WORLD_PAY','WORLD_LEASE'}:
        fields={'WORLD_AMEND':'seed','WORLD_MEMBER':'member admit','WORLD_ROLE':'holder resource limit expiry delegate','WORLD_REVOKE':'role','WORLD_PAY':'destination resource quantity','WORLD_LEASE':'holder resource limit expiry delegate heartbeat backup'}
        exact(p,'world revision approvals '+fields[op]);w=governed(s,p,op)
        if op=='WORLD_AMEND':
            validate_seed(p['seed']);need(p['seed']['ancestry']==w['seed']['ancestry'],'WORLD_ANCESTRY_IMMUTABLE')
            for module in p['seed']['modules']:need(module in s['world_catalogue'],'WORLD_MODULE_MISSING')
            # New controllers also accept the amendment; old authority alone cannot conscript them.
            authorized(s,p['seed']['governors'],len(p['seed']['governors']),p['approvals'],op,p)
            need(p['world'] not in p['seed']['governors'],'WORLD_AUTHORITY_CYCLE')
            # Validate recursive graph with proposed seed before accepting it.
            w['seed']=deepcopy(p['seed']);authorized(s,w['seed']['governors'],w['seed']['threshold'],p['approvals'],op,p)
            members=set(w['members'])|set(p['seed']['governors']);need(len(members)<=256,'WORLD_MEMBER_LIMIT');w['members']=sorted(members)
            w['role_epoch']+=1
        elif op=='WORLD_MEMBER':
            key(p['member']);need(type(p['admit']) is bool,'WORLD_ADMISSION')
            members=set(w['members'])
            if p['admit']:
                authorized(s,[p['member']],1,p['approvals'],op,p);members.add(p['member'])
            else:
                need(p['member'] not in w['seed']['governors'],'WORLD_GOVERNOR_MEMBER');members.discard(p['member'])
                for r in s['world_roles'].values():
                    if r['world']==p['world'] and r['holder']==p['member']:r['revoked']=True
            need(len(members)<=256,'WORLD_MEMBER_LIMIT');w['members']=sorted(members)
        elif op in {'WORLD_ROLE','WORLD_LEASE'}:
            key(p['holder']);integer(p['limit'],True);integer(p['expiry'],True)
            need(p['holder'] in w['members'] and type(p['resource']) is str and p['resource'] in s['resources'] and height<p['expiry'] and type(p['delegate']) is bool,'WORLD_ROLE_SCOPE')
            s['world_roles'][tid]={k:deepcopy(p[k]) for k in ('world','holder','resource','limit','expiry','delegate')}
            s['world_roles'][tid].update(parent=None,spent=0,revoked=False,epoch=w['role_epoch'])
            if op=='WORLD_LEASE':
                integer(p['heartbeat'],True);key(p['backup']);need(p['backup'] in w['members'] and p['backup']!=p['holder'],'WORLD_BACKUP')
                s['world_roles'][tid].update(heartbeat=p['heartbeat'],backup=p['backup'],last_seen=height)
        elif op=='WORLD_REVOKE':
            need(type(p['role']) is str and p['role'] in s['world_roles'] and s['world_roles'][p['role']]['world']==p['world'],'WORLD_ROLE')
            s['world_roles'][p['role']]['revoked']=True
        else:key(p['destination']);move(s,p['world'],p['destination'],p['resource'],p['quantity'])
        w['revision']+=1;parents=[p['world']]
    elif op=='WORLD_HEARTBEAT':
        exact(p,'role');path=role_path(s,p['role'],actor,height);r=path[0][1]
        need('heartbeat' in r,'WORLD_NOT_LEASE');r['last_seen']=height;parents=[p['role']]
    elif op=='WORLD_FAILOVER':
        exact(p,'role');need(type(p['role']) is str and p['role'] in s['world_roles'],'WORLD_ROLE');r=s['world_roles'][p['role']]
        need('heartbeat' in r and not r['revoked'] and r['backup']==actor and r['last_seen']+r['heartbeat']<height<r['expiry'],'WORLD_FAILOVER')
        w=s['worlds'][r['world']];need(w['status']=='ACTIVE' and w['role_epoch']==r['epoch'] and actor in w['members'],'WORLD_ROLE_EPOCH')
        if r['parent'] is not None:role_path(s,r['parent'],s['world_roles'][r['parent']]['holder'],height)
        successor={**deepcopy(r),'holder':actor,'backup':None,'last_seen':height}
        r['revoked']=True;s['world_roles'][tid]=successor;parents=[p['role']]
    elif op=='WORLD_DELEGATE':
        exact(p,'parent holder limit expiry delegate');path=role_path(s,p['parent'],actor,height);r=path[0][1]
        key(p['holder']);integer(p['limit'],True);integer(p['expiry'],True)
        need(r['delegate'] and type(p['delegate']) is bool and p['limit']<=r['limit'] and height<p['expiry']<=r['expiry'],'WORLD_ATTENUATION')
        need(p['holder'] in s['worlds'][r['world']]['members'],'WORLD_MEMBERSHIP')
        s['world_roles'][tid]={**{k:deepcopy(v) for k,v in r.items() if k not in {'heartbeat','backup','last_seen'}},'holder':p['holder'],'limit':p['limit'],'expiry':p['expiry'],'delegate':p['delegate'],'parent':p['parent'],'spent':0};parents=[p['parent']]
    elif op=='WORLD_SPEND':
        exact(p,'role destination quantity');path=role_path(s,p['role'],actor,height);key(p['destination']);integer(p['quantity'],True)
        for _,r in path:need(r['spent']+p['quantity']<=r['limit'],'WORLD_ROLE_BUDGET')
        r=path[0][1];move(s,r['world'],p['destination'],r['resource'],p['quantity'])
        for _,r in path:r['spent']+=p['quantity']
        parents=[p['role']]
    elif op=='WORLD_LEAVE':
        exact(p,'world');w=world(s,p)
        need(actor in w['members'] and actor not in w['seed']['governors'],'WORLD_LEAVE_GOVERNANCE_REQUIRED')
        w['members'].remove(actor);w['revision']+=1
        for r in s['world_roles'].values():
            if r['world']==p['world'] and r['holder']==actor:r['revoked']=True
        parents=[p['world']]
    elif op=='WORLD_SERVICE':
        exact(p,'capability resource price expiry terms');key(p['terms']);integer(p['price'],True);integer(p['expiry'],True)
        need(type(p['capability']) is str and 0<len(p['capability'])<=80 and type(p['resource']) is str and p['resource'] in s['resources'] and height<p['expiry'],'WORLD_SERVICE_SCOPE')
        s['world_services'][tid]={**deepcopy(p),'provider':actor};parents=[]
    elif op=='WORLD_HIRE':
        from .governance import admission_paused
        need(not admission_paused(s,'WORLD_HIRE'),'NEW_AGREEMENTS_PAUSED')
        exact(p,'world revision approvals service units resolver deadline');w=governed(s,p,op)
        need(type(p['service']) is str and p['service'] in s['world_services'],'WORLD_SERVICE');service=s['world_services'][p['service']]
        integer(p['units'],True);integer(p['deadline'],True);key(p['resolver'])
        need(height<service['expiry'] and height<p['deadline'],'WORLD_SERVICE_EXPIRED')
        need(p['resolver']!=service['provider'],'WORLD_RESOLVER_CONFLICT')
        quantity=p['units']*service['price'];integer(quantity,True)
        # Escrow is a non-signable account; only the adopted resolver procedure releases it.
        escrow=digest('COVENANT-WORLD-ESCROW',tid);move(s,p['world'],escrow,service['resource'],quantity)
        s['world_jobs'][tid]={**deepcopy(p),'approvals':[], 'provider':service['provider'],'resource':service['resource'],'price':service['price'],'escrow':escrow,'quantity':quantity,'state':'OPEN','evidence':None}
        from .governance import pin_rules
        pin_rules(s,s['world_jobs'][tid])
        w['revision']+=1;parents=[p['world'],p['service']]
    elif op=='WORLD_RESOLVE':
        exact(p,'job units evidence');need(type(p['job']) is str and p['job'] in s['world_jobs'],'WORLD_JOB');j=s['world_jobs'][p['job']]
        need(actor==j['resolver'] and j['state']=='OPEN' and height<=j['deadline'],'WORLD_RESOLVER');integer(p['units']);key(p['evidence'])
        need(p['units']<=j['units'],'WORLD_METER_LIMIT')
        paid=p['units']*j['price'];refund=j['quantity']-paid
        if paid:move(s,j['escrow'],j['provider'],j['resource'],paid)
        if refund:move(s,j['escrow'],j['world'],j['resource'],refund)
        j.update(state='RESOLVED',evidence=p['evidence'],delivered=p['units']);parents=[p['job']]
    elif op=='WORLD_RESOLUTION' and s.get('protocol') in {'covenant-native/0.15',MIGRATION_VERSION}:
        exact(p,'world revision approvals job policy challenge_blocks');w=governed(s,p,op)
        need(type(p['job']) is str and p['job'] in s['world_jobs'],'WORLD_JOB');j=s['world_jobs'][p['job']]
        need(j['world']==p['world'] and j['state']=='OPEN' and 'resolution' not in j,'WORLD_RESOLUTION')
        need(p['policy'] in {'HOLD_FOR_RESOLUTION','WAIT_FOREVER'},'WORLD_RESOLUTION')
        integer(p['challenge_blocks']);need(p['challenge_blocks']<=10000,'WORLD_RESOLUTION')
        authorized(s,[j['provider']],1,p['approvals'],op,p)
        authorized(s,[j['resolver']],1,p['approvals'],op,p)
        j['resolution']=p['policy'];j['challenge_blocks']=p['challenge_blocks'];w['revision']+=1
        parents=[p['job'],p['world']]
    elif op=='WORLD_TIMEOUT':
        exact(p,'job');need(type(p['job']) is str and p['job'] in s['world_jobs'],'WORLD_JOB');j=s['world_jobs'][p['job']]
        need(j['state']=='OPEN','WORLD_TIMEOUT')
        policy=j.get('resolution')
        if policy=='WAIT_FOREVER':need(False,'WORLD_WAIT_FOREVER')
        if policy=='HOLD_FOR_RESOLUTION':
            from .governance import obligation_active
            extra=j.get('challenge_blocks') or 0
            if not (obligation_active(j,'silent_referee_release') and height>j['deadline']+extra):need(False,'WORLD_HOLD')
        else:
            need(height>j['deadline'],'WORLD_TIMEOUT')
        move(s,j['escrow'],j['world'],j['resource'],j['quantity']);j['state']='TIMED_OUT';parents=[p['job']]
    elif op=='WORLD_MERGE':
        exact(p,'world revision other other_revision target target_revision approvals');a=governed(s,p,op)
        need(len({p['world'],p['other'],p['target']})==3,'WORLD_MERGE_IDS')
        for name,rev in [('other','other_revision'),('target','target_revision')]:
            w=world(s,{'world':p[name]});integer(p[rev]);need(w['revision']==p[rev],'WORLD_REVISION')
            authorized(s,w['seed']['governors'],w['seed']['threshold'],p['approvals'],op,p)
        sources=[p['world'],p['other']]
        need(all(wid in sources or w['status']!='ACTIVE' or not set(w['seed']['governors'])&set(sources) for wid,w in s['worlds'].items()),'WORLD_DEPENDENTS')
        need(all(j['state']!='OPEN' or j['world'] not in sources for j in s['world_jobs'].values()),'WORLD_OPEN_LIABILITIES')
        # This profile merges treasury only; historical identity/obligations are never erased.
        for source in sources:
            for rid,qty in list(s['balances'].get(source,{}).items()):
                if qty:move(s,source,p['target'],rid,qty)
            s['worlds'][source].update(status='MERGED',successor=p['target']);s['worlds'][source]['revision']+=1
        s['worlds'][p['target']]['revision']+=1;parents=sources+[p['target']]
    else:raise ValueError('WORLD_OPERATION_UNSUPPORTED')
    return parents

def discover(state,capability,height,*,max_price=None):
    return sorted([{'id':sid,**deepcopy(v)} for sid,v in state['world_services'].items() if v['capability']==capability and height<v['expiry'] and (max_price is None or v['price']<=max_price)],key=lambda v:(v['price'],v['id']))
