"""Keyless agent tool for identity and discovery interoperability.

Bridges AAP keys and signed descriptors to did:wba/did:web documents, A2A cards,
ANP descriptions, DNS-AID and ANS records, NANDA AgentFacts, OASF records,
ERC-8004 registries and SPIFFE identities. Preparation and verification only:
every document is bytes the caller already holds, every signing input is
returned unsigned, and nothing is fetched, published, submitted or executed.
Gathering descriptors from these carriers is ``covenant_network_trust.discover``.
"""
from .cooperation_interface import HASH, INT
from .crypto import need
from . import a2a_discovery
from . import anp_discovery
from . import did_binding
from . import erc8004_bridge
from . import registry_records
from . import spiffe_identity

TEXT = {'type': 'string', 'minLength': 1, 'maxLength': 256}
URL = {'type': 'string', 'pattern': '^https://', 'minLength': 9, 'maxLength': 2048}
DID = {'type': 'string', 'pattern': '^did:', 'minLength': 7, 'maxLength': 2048}
DOCUMENT = {'type': 'string', 'minLength': 2, 'maxLength': 65536}
SIGNATURE = {'type': 'string', 'pattern': '^[0-9a-f]{128}$', 'minLength': 128, 'maxLength': 128}
ENVELOPE = {'type': 'object', 'maxProperties': 2, 'required': ['body', 'signature'], 'additionalProperties': False,
            'properties': {'body': {'type': 'object', 'maxProperties': 16}, 'signature': SIGNATURE}}
RECORD = {'type': 'object', 'maxProperties': 3}
DATETIME = {'type': 'string', 'pattern': '^[0-9]{4}-[0-9]{2}-[0-9]{2}T', 'minLength': 20, 'maxLength': 35}
SEMVER = {'type': 'string', 'pattern': '^(0|[1-9][0-9]{0,8})[.](0|[1-9][0-9]{0,8})[.](0|[1-9][0-9]{0,8})$', 'maxLength': 32}
PATH = {'type': 'array', 'minItems': 1, 'maxItems': 8, 'items': {'type': 'string', 'pattern': '^[A-Za-z0-9._-]{1,128}$'}}
PORT = {'type': 'integer', 'minimum': 1, 'maximum': 65535}
ADDRESS = {'type': 'string', 'pattern': '^0x[0-9a-fA-F]{40}$', 'minLength': 42, 'maxLength': 42}
REGISTRY = {'type': 'string', 'pattern': '^eip155:[1-9][0-9]{0,18}:0x[0-9a-fA-F]{40}$', 'maxLength': 70}
URI = {'type': 'string', 'pattern': '^(ipfs|https|ar)://', 'minLength': 7, 'maxLength': 2048}
PROVIDER = {'type': 'object', 'maxProperties': 3, 'additionalProperties': False, 'required': ['name', 'url'],
            'properties': {'name': TEXT, 'url': URL, 'did': DID}}
BINDINGS = {'type': 'array', 'maxItems': 16, 'items': RECORD}
ADOPTION = {'type': 'object', 'maxProperties': 4}
FEEDBACK = {'type': 'array', 'maxItems': 1024, 'items': {'type': 'object', 'maxProperties': 2}}
SKILLS = {'type': 'array', 'minItems': 1, 'maxItems': 32, 'items': {'type': 'object', 'maxProperties': 2}}
AUTHORS = {'type': 'array', 'minItems': 1, 'maxItems': 16, 'items': TEXT}
RESOLVERS = {'type': 'object', 'maxProperties': 256, 'propertyNames': {'type': 'string', 'pattern': '^[0-9a-f]{64}$'},
             'additionalProperties': HASH}


def spec():
    return ('covenant_identity_discovery',
        'Experimental identity and discovery bridges. Bind did:wba or did:web documents you hold to an AAP key only '
        'through that key\'s signature; prepare A2A cards, ANP descriptions, DNS-AID and ANS records, NANDA AgentFacts '
        'and OASF records that carry your signed descriptor; export outcome receipts as ERC-8004 validation bytes and '
        'read ERC-8004 feedback as a weak signal outside your score; check SPIFFE identities against bundles you '
        'adopted. Gather descriptors with covenant_network_trust.discover. No signing, fetching, publication, '
        'submission or execution.', True, [
        ('describe', {}, ()),
        ('resolve_did', {'did': DID, 'document': DOCUMENT, 'bindings': BINDINGS, 'now': INT}, ('did',)),
        ('did_document', {'key': HASH, 'host': TEXT, 'path': PATH, 'port': PORT, 'agent_description': URL,
                          'aap_did': DID, 'created': DATETIME}, ('key', 'host', 'path')),
        ('did_binding', {'key': HASH, 'did': DID, 'document': DOCUMENT, 'verification_method': TEXT, 'issued_at': INT,
                         'expires': INT, 'nonce': HASH}, ('key', 'did', 'document', 'verification_method', 'issued_at',
                                                          'expires', 'nonce')),
        ('a2a_card', {'envelope': ENVELOPE, 'signed': {'type': 'boolean'},
                      'provider': {'type': 'object', 'maxProperties': 2, 'additionalProperties': False,
                                   'required': ['organization', 'url'], 'properties': {'organization': TEXT, 'url': URL}}},
         ('envelope',)),
        ('anp_description', {'envelope': ENVELOPE, 'url': URL, 'did': DID, 'created': DATETIME, 'signed': {'type': 'boolean'}},
         ('envelope', 'url')),
        ('anp_collection', {'url': URL, 'items': {'type': 'array', 'maxItems': 256, 'items': {
            'type': 'object', 'maxProperties': 2, 'additionalProperties': False, 'required': ['name', 'url'],
            'properties': {'name': TEXT, 'url': URL}}}, 'next': URL}, ('url', 'items')),
        ('dns_aid_records', {'envelope': ENVELOPE, 'owner': TEXT, 'cap_url': URL, 'target': TEXT, 'port': PORT,
                             'ttl': INT, 'numeric': {'type': 'boolean'}}, ('envelope', 'owner', 'cap_url')),
        ('ans_records', {'host': TEXT, 'version': SEMVER, 'card_url': URL, 'protocol': {'type': 'string', 'maxLength': 64}},
         ('host', 'version', 'card_url')),
        ('agentfacts', {'envelope': ENVELOPE, 'provider': PROVIDER, 'version': SEMVER, 'agent_name': TEXT,
                        'signed': {'type': 'boolean'}}, ('envelope', 'provider')),
        ('oasf_record', {'envelope': ENVELOPE, 'card': {'type': 'object', 'maxProperties': 16}, 'skills': SKILLS,
                         'authors': AUTHORS, 'version': TEXT, 'created_at': DATETIME,
                         'schema_version': {'enum': list(registry_records.OASF_VERSIONS)}},
         ('envelope', 'card', 'skills', 'authors', 'version', 'created_at')),
        ('spiffe_bundle', {'trust_domain': TEXT, 'bundle': {'type': 'string', 'minLength': 2, 'maxLength': 262144}},
         ('trust_domain', 'bundle')),
        ('spiffe_adoption', {'audience': TEXT, 'svid_types': {'type': 'array', 'minItems': 1, 'maxItems': 2,
                                                               'items': {'enum': list(spiffe_identity.SVID_TYPES)}},
                             'trust_domains': {'type': 'array', 'maxItems': 16, 'items': ADOPTION},
                             'max_jwt_ttl': {'type': 'integer', 'minimum': 1, 'maximum': spiffe_identity.MAX_JWT_TTL}},
         ('audience', 'svid_types', 'trust_domains')),
        ('spiffe_binding', {'did': DID, 'spiffe_id': {'type': 'string', 'pattern': '^spiffe://', 'maxLength': 2048},
                            'svid_type': {'enum': list(spiffe_identity.SVID_TYPES)}, 'svid_sha256': HASH, 'audience': TEXT,
                            'issued_at': INT, 'expires': INT, 'nonce': HASH},
         ('did', 'spiffe_id', 'svid_type', 'svid_sha256', 'audience', 'issued_at', 'expires', 'nonce')),
        ('spiffe_verify', {'binding': RECORD, 'adoption': ADOPTION, 'now': INT, 'counterparty': HASH},
         ('binding', 'adoption', 'now')),
        ('erc8004_export', {'receipt': {'type': 'object', 'maxProperties': 2}, 'agent_registry': REGISTRY,
                            'agent_id': INT, 'validator': ADDRESS, 'request_uri': URI, 'response_uri': URI,
                            'adopted_resolvers': RESOLVERS},
         ('receipt', 'agent_registry', 'agent_id', 'validator', 'request_uri', 'response_uri')),
        ('erc8004_feedback', {'entries': FEEDBACK, 'agent_registry': REGISTRY}, ('entries', 'agent_registry')),
    ])


def describe():
    """Compact orientation; each adapter's full describe() stays in its module."""
    return {'tool': 'covenant_identity_discovery', 'status': 'EXPERIMENTAL_ADAPTERS',
            'profiles': [did_binding.VERSION, spiffe_identity.VERSION, a2a_discovery.VERSION, anp_discovery.VERSION,
                         registry_records.VERSION, erc8004_bridge.VERSION],
            'identity': {'native': 'did:aap and did:covenant', 'web': ['did:wba (ANP 1.2)', 'did:web'],
                         'binding': 'ONLY_A_SIGNATURE_BY_THE_AAP_KEY_BINDS', 'spiffe': 'X509_SVID_AND_JWT_SVID_OFFLINE'},
            'discovery': {'carriers': ['A2A card', 'ANP description and discovery page', 'DNS-AID SVCB', 'ANS TXT',
                                       'NANDA AgentFacts', 'OASF record'],
                          'gather_with': 'covenant_network_trust.discover', 'only_signatures_count': True},
            'erc8004': {'export': 'VALIDATION_REGISTRY_BYTES_FOR_THE_OWNER', 'import': 'WEAK_SIGNAL_NEVER_IN_THE_SCORE'},
            'workflow': ['publish a signed descriptor', 'prepare carriers for it here and sign their inputs locally',
                         'gather what others publish with covenant_network_trust.discover',
                         'adopt SPIFFE bundles into covenant-agent-gateway-policy/0.4, or /0.5 with witnessed decisions'],
            'guide': 'docs/IDENTITY_DISCOVERY.html', 'signing_in_tool': False, 'network_accessed': False,
            'execution_authorized': False}


def _flag(result):
    if type(result) is dict:
        result.setdefault('execution_authorized', False)
    return result


ACTIONS = {
    'describe': lambda p: describe(),
    'resolve_did': lambda p: did_binding.resolve(p['did'], document=p.get('document'), bindings=p.get('bindings', ()),
                                                 now=p.get('now')),
    'did_document': lambda p: did_binding.document(p['key'], did_binding.wba_did(p['key'], p['host'], p['path'], p.get('port')),
                                                   agent_description=p.get('agent_description'), aap_did=p.get('aap_did'),
                                                   created=p.get('created')),
    'did_binding': lambda p: did_binding.binding(p['key'], p['did'], p['document'], p['verification_method'],
                                                 p['issued_at'], p['expires'], p['nonce']),
    'a2a_card': lambda p: a2a_discovery.card(p['envelope'], signed=p.get('signed', True), provider=p.get('provider')),
    'anp_description': lambda p: anp_discovery.description(p['envelope'], p['url'], did=p.get('did'), created=p.get('created'),
                                                           signed=p.get('signed', True)),
    'anp_collection': lambda p: _flag({'page': anp_discovery.collection(p['url'], p['items'], p.get('next'))}),
    'dns_aid_records': lambda p: registry_records.dns_aid_records(p.pop('envelope'), p.pop('owner'), p.pop('cap_url'), **p),
    'ans_records': lambda p: registry_records.ans_records(p['host'], p['version'], p['card_url'], p.get('protocol', 'a2a')),
    'agentfacts': lambda p: registry_records.agentfacts(p.pop('envelope'), p.pop('provider'), **p),
    'oasf_record': lambda p: registry_records.oasf_record(p.pop('envelope'), p.pop('card'), **p),
    'spiffe_bundle': lambda p: _flag({'adopted': spiffe_identity.adopt_bundle(p['trust_domain'], p['bundle']),
                                      'adoption': 'OWNER_PLACES_THIS_IN_ITS_OWN_GATEWAY_POLICY'}),
    'spiffe_adoption': lambda p: _flag({'spiffe': spiffe_identity.adoption(**p),
                                        'policy_version': 'covenant-agent-gateway-policy/0.3'}),
    'spiffe_binding': lambda p: spiffe_identity.binding(**p),
    'spiffe_verify': lambda p: spiffe_identity.verify_binding(p['binding'], p['adoption'], p['now'], p.get('counterparty')),
    'erc8004_export': lambda p: erc8004_bridge.export_outcome(p.pop('receipt'), **p),
    'erc8004_feedback': lambda p: erc8004_bridge.feedback_signal(p['entries'], p['agent_registry']),
}


def call(action, parameters):
    need(type(action) is str and action in ACTIONS and type(parameters) is dict, 'IDENTITY_DISCOVERY_TOOL_ACTION')
    return ACTIONS[action](dict(parameters))
