"""Outcome views for the agent network.

Settled receipts, silence, a success lower bound, repeat binding and
trust-weighted diversity are computed here. PageRank mass comes from
``discovery_rank.pagerank``. Opinions stay in ``discovery_rank.reputation``.
Fee movement stays in ``economics``. Nothing here stores a reputation balance
or pays an arbiter.
"""
import math
from copy import deepcopy

from .agent_network import unpack
from .incentive_invariants import ARBITER_PAY, PROTOCOL, RULE_SET
from .crypto import digest, exact, integer, key, need
from .discovery_rank import SCALE, pagerank
from covenant_language.agentic import canonical

VERSION = 'covenant-network-incentives/0.1'
OUTCOMES = ('KEPT', 'KEPT_LATE', 'PARTIAL', 'SILENT', 'CHALLENGED_WON', 'CHALLENGED_LOST',
            'DEFAULTED', 'RELEASED_UNDECIDED')
POSITIVE = {'KEPT', 'KEPT_LATE'}
CLEAN = {'KEPT', 'KEPT_LATE', 'SILENT', 'CHALLENGED_WON'}
REPEAT_WINDOW = 180
REVIEW_WINDOW = 14
GRACE_DAYS = 14
BAD_RATER_LB = 5000
BOOTSTRAP_OWNERS = 50
EXPLORATION_STRIDE = 8
DIVERSITY_CAP = 20
WEIGHTS = {'relevance': 50, 'pagerank': 20, 'reputation': 30}
LEVELS = ('L0', 'L1', 'L2', 'L3', 'L4')
SURFACES = ('outcome_profile', 'wilson_lb', 'commit_reveal', 'inflation_monitor', 'take_cap',
            'rank_not_for_sale', 'export', 'ladder', 'exploration_slot')


def wilson_lb_bps(k, n):
    """Integer Wilson lower bound in basis points. z = 196/100 and z² = 38416/10000."""
    integer(k)
    integer(n)
    need(k <= n, 'INCENTIVE_WILSON')
    if n == 0:
        return 0
    z2 = 38416
    num = k * (n - k) * 10000 + 9604 * n
    den = n * 10000
    root = math.isqrt(num * 10**12 // den)
    margin = 19600 * root // 10**6
    centre = k * 10000 + 19208
    numerator = max(0, centre - margin)
    denominator = n * 10000 + z2
    return numerator * 10000 // denominator


def _band(value):
    integer(value)
    if value <= 0:
        return 0
    return (value).bit_length() - 1


_RECEIPT = 'covenant role context counterparty value outcome settled_day confidential opt_in disclosed'
_RECEIPT_OPTIONAL = {'party', 'counterparty_buyer_lb', 'forfeited_bond_day'}


def _receipt(row):
    need(type(row) is dict and set(row) - set(_RECEIPT.split()) <= _RECEIPT_OPTIONAL, 'FIELDS')
    exact({name: row[name] for name in _RECEIPT.split()}, _RECEIPT)
    key(row['covenant'])
    key(row['counterparty'])
    need(row['role'] in {'PROVIDER', 'BUYER'}, 'INCENTIVE_ROLE')
    need(type(row['context']) is str and 0 < len(row['context']) <= 80, 'INCENTIVE_CONTEXT')
    integer(row['value'])
    need(row['outcome'] in OUTCOMES, 'INCENTIVE_OUTCOME')
    integer(row['settled_day'])
    need(type(row['confidential']) is bool and type(row['opt_in']) is bool and type(row['disclosed']) is bool, 'INCENTIVE_PRIVACY')
    if row['confidential']:
        need(row['opt_in'] is True or row['disclosed'] is False, 'INCENTIVE_OPT_IN')
    if 'party' in row:
        key(row['party'])
    if 'counterparty_buyer_lb' in row:
        integer(row['counterparty_buyer_lb'])
        need(row['counterparty_buyer_lb'] <= 10000, 'INCENTIVE_BOUND')
    if 'forfeited_bond_day' in row:
        integer(row['forfeited_bond_day'])
    return row


def _owned(subject, receipts):
    key(subject)
    rows = []
    seen = set()
    need(type(receipts) is list and len(receipts) <= 4096, 'INCENTIVE_RECEIPTS')
    for row in receipts:
        _receipt(row)
        if row.get('party', subject) != subject:
            continue
        if row['confidential'] and row['opt_in'] is not True:
            continue
        fingerprint = canonical(row)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        rows.append(row)
    rows.sort(key=lambda item: (item['settled_day'], item['covenant'], item['role']))
    return rows


def histogram(rows):
    counts = {name: 0 for name in OUTCOMES}
    for row in rows:
        counts[row['outcome']] += 1
    kept = counts['KEPT']
    late = counts['KEPT_LATE']
    return {'counts': counts, 'settled': len(rows), 'silence': counts['SILENT'],
            'positive_k': kept + late // 2, 'silence_in_denominator': True}


def repeat_binding_bps(rows, window=REPEAT_WINDOW):
    integer(window, True)
    by_party = {}
    for row in rows:
        by_party.setdefault(row['counterparty'], []).append(row['settled_day'])
    if not by_party:
        return 0
    repeated = 0
    for days in by_party.values():
        ordered = sorted(days)
        if any(0 <= later - earlier <= window for earlier, later in zip(ordered, ordered[1:])):
            repeated += 1
    return repeated * 10000 // len(by_party)


def trust_from_network(network, edges=()):
    """Trust mass from the existing seeded PageRank. This does not build another graph."""
    nodes = sorted(network.peers)
    return pagerank(nodes, [list(edge) for edge in edges], dict(network.seeds))


def diversity(rows, trust=None, tau_star=1):
    """Inverse Simpson index. ``trust`` is pagerank mass. Zero trust adds nothing."""
    integer(tau_star, True)
    raw = {}
    weighted = {}
    for row in rows:
        party = row['counterparty']
        raw[party] = raw.get(party, 0) + row['value']
        mass = 0 if trust is None else trust.get(party, 0)
        if mass <= 0:
            continue
        share = min(tau_star, mass)
        weighted[party] = weighted.get(party, 0) + row['value'] * share // tau_star
    def index(weights):
        if not weights:
            return 0
        total = sum(weights.values())
        squares = sum(value * value for value in weights.values())
        if total <= 0 or squares <= 0:
            return 0
        return total * total // squares
    return {'raw': index(raw), 'trusted': index(weighted), 'trusted_counterparties': len(weighted),
            'mass_scale': SCALE, 'zero_trust_counts': False}


def _log_fp8(value):
    integer(value)
    if value <= 0:
        return 0
    return math.floor(math.log2(value) * 256)


def quality_weight(rows, trust=None, tau_star=1):
    """Log value, trust-weighted diversity, the lower bound, and a repeat bonus only."""
    summary = histogram(rows)
    bound = wilson_lb_bps(summary['positive_k'], summary['settled'])
    spread = diversity(rows, trust, tau_star)
    capped = min(spread['trusted'], DIVERSITY_CAP)
    logs = sum(_log_fp8(1 + row['value']) for row in rows)
    repeat = repeat_binding_bps(rows)
    weight = logs * capped * bound // 10000 * (20000 + repeat) // 20000
    return {'weight': weight, 'log_value_fp8': logs, 'diversity_cap': capped,
            'lower_bound_bps': bound, 'repeat_binding_bps': repeat,
            'raw_diversity': spread['raw'], 'trusted_diversity': spread['trusted'],
            'holdback_bps': 2000, 'paid_here': False, 'campaign': 'economics.ECON_REWARD_CREATE',
            'eligibility': 'SETTLED_SERVICE', 'arbiter_pay': ARBITER_PAY}


def outcome_profile(subject, receipts, trust=None, context=None):
    rows = _owned(subject, receipts)
    if context is not None:
        rows = [row for row in rows if row['context'] == context]
    summary = histogram(rows)
    bound = wilson_lb_bps(summary['positive_k'], summary['settled'])
    spread = diversity(rows, trust)
    history = []
    for row in rows:
        shown = {'covenant': row['covenant'], 'role': row['role'], 'context': row['context'],
                 'outcome': row['outcome'], 'counterparty': row['counterparty'],
                 'settled_day': row['settled_day'], 'value_band': _band(row['value'])}
        if row['disclosed'] and row['opt_in']:
            shown['value'] = row['value']
        history.append(shown)
    failures = [row for row in rows if row['outcome'] in {'DEFAULTED', 'CHALLENGED_LOST'}]
    return {'version': VERSION, 'protocol': PROTOCOL, 'rule_set': RULE_SET, 'subject': subject,
            'projection': 'covenant-outcome-view/0.2',
            'receipt_authenticity': 'CALLER_SUPPLIED_NOT_VERIFIED_HERE',
            'sample_completeness': 'UNKNOWN', 'independence': 'NOT_ESTABLISHED',
            'exact_replicas_counted_once': True,
            'context': context, 'history': history, 'histogram': summary['counts'],
            'settled': summary['settled'], 'silence': summary['silence'],
            'silence_in_denominator': True, 'positive_k': summary['positive_k'],
            'lower_bound_bps': bound, 'repeat_binding_bps': repeat_binding_bps(rows),
            'trust_diversity': spread['trusted'], 'raw_diversity': spread['raw'],
            'quality': quality_weight(rows, trust), 'headline_is_first_failure': False,
            'first_failure_in_histogram': bool(failures), 'reputation_balance': False,
            'stored_reputation': False, 'portable': True, 'arbiter_pay': ARBITER_PAY,
            'execution_authorized': False}


def blend_score(relevance_ppm, trust_mass_ppb, max_mass, outcome_bps):
    """Directory order: relevance 50, seeded trust mass 20, outcome lower bound 30."""
    integer(relevance_ppm)
    integer(trust_mass_ppb)
    integer(max_mass)
    integer(outcome_bps)
    need(outcome_bps <= 10000, 'INCENTIVE_BOUND')
    pagerank_ppm = 0 if max_mass <= 0 else 1_000_000 * trust_mass_ppb // max_mass
    outcome_ppm = outcome_bps * 1_000_000 // 10000
    score = (relevance_ppm * WEIGHTS['relevance'] + pagerank_ppm * WEIGHTS['pagerank']
             + outcome_ppm * WEIGHTS['reputation']) // 100
    return {'score_ppm': score, 'components_ppm': {'relevance': relevance_ppm, 'pagerank': pagerank_ppm,
                                                    'reputation': outcome_ppm},
            'weights': dict(WEIGHTS), 'payment_input': False, 'opinion_input': False,
            'stored_reputation': False}


def review_body(opinion):
    exact(opinion, 'subject context origin result rating_bps role salt commitment')
    return {'subject': opinion['subject'], 'context': opinion['context'], 'origin': opinion['origin'],
            'result': opinion['result'], 'rating_bps': opinion['rating_bps'], 'role': opinion['role']}


def commitment_for(salt, body):
    key(salt)
    exact(body, 'subject context origin result rating_bps role')
    integer(body['rating_bps'])
    need(body['rating_bps'] <= 10000, 'INCENTIVE_RATING')
    return digest('COVENANT-REVIEW-COMMIT-0.1', {'salt': salt, 'review': body})


def _events(events):
    if type(events) is dict:
        return events
    return {item['id']: item for item in events}


def endorsement_visible(opinion, events, now=None):
    """A legacy opinion is visible. A reveal stays hidden until both commits or the window."""
    if type(opinion) is not dict or 'result' not in opinion or 'origin' not in opinion:
        return False
    if 'commitment' not in opinion:
        return True
    if 'salt' not in opinion or 'rating_bps' not in opinion or 'role' not in opinion:
        return False
    try:
        body = review_body(opinion)
    except ValueError:
        return False
    if opinion['commitment'] != commitment_for(opinion['salt'], body):
        return False
    actors = set()
    window = None
    for event in _events(events).values():
        body_event = event['body']
        if body_event.get('kind') != 'ENDORSE':
            continue
        payload = unpack(body_event)
        if payload.get('origin') != opinion['origin'] or 'commitment' not in payload or 'salt' in payload:
            continue
        actors.add(body_event['actor'])
        if window is None or payload['window_end'] < window:
            window = payload['window_end']
    opened = len(actors) >= 2 or (now is not None and window is not None and now >= window)
    return opened


def endorsement_counts(opinion, events, actor, now=None):
    """Legacy opinions count. A commit-reveal counts only while visible, and only its first text."""
    if not endorsement_visible(opinion, events, now):
        return False
    if 'commitment' not in opinion:
        return True
    key(actor)
    first = None
    first_seq = None
    for event in _events(events).values():
        body = event['body']
        if body.get('kind') != 'ENDORSE' or body.get('actor') != actor:
            continue
        payload = unpack(body)
        if payload.get('origin') != opinion['origin'] or 'salt' not in payload:
            continue
        seq = body.get('sequence', 0)
        if first is None or seq < first_seq:
            first = payload
            first_seq = seq
    return (first is not None and first['result'] == opinion['result']
            and first['rating_bps'] == opinion['rating_bps'])


def commit_payload(subject, context, origin, commitment, role, window_end):
    key(subject)
    key(origin)
    key(commitment)
    need(role in {'PROVIDER', 'BUYER'}, 'INCENTIVE_ROLE')
    integer(window_end, True)
    return {'subject': subject, 'context': context, 'origin': origin, 'commitment': commitment,
            'window_end': window_end, 'role': role}


def reveal_payload(subject, context, origin, result, rating_bps, role, salt):
    body = {'subject': subject, 'context': context, 'origin': origin, 'result': result,
            'rating_bps': rating_bps, 'role': role}
    commitment = commitment_for(salt, body)
    return {**body, 'salt': salt, 'commitment': commitment}


def open_review(events, actor, origin, now=None):
    """Return one visible reveal. A hidden or changed review is not readable."""
    key(actor)
    key(origin)
    found = []
    for event in _events(events).values():
        body = event['body']
        if body.get('kind') != 'ENDORSE' or body.get('actor') != actor:
            continue
        payload = unpack(body)
        if payload.get('origin') != origin or 'salt' not in payload:
            continue
        if not endorsement_visible(payload, events, now):
            raise ValueError('REVIEW_HIDDEN')
        found.append(payload)
    need(found, 'REVIEW_ABSENT')
    first = found[0]
    for later in found[1:]:
        need(later['rating_bps'] == first['rating_bps'] and later['result'] == first['result'], 'REVIEW_IMMUTABLE')
    return {'actor': actor, 'origin': origin, 'subject': first['subject'], 'result': first['result'],
            'rating_bps': first['rating_bps'], 'role': first['role'], 'readable': True,
            'correct_changes_score': False, 'execution_authorized': False}


def calibrated_bps(rating, history):
    """Mid-rank percentile. A rater who gives everyone the same score centres at 5,000 bps."""
    integer(rating)
    need(rating <= 10000, 'INCENTIVE_RATING')
    need(type(history) is list and 0 < len(history) <= 4096, 'INCENTIVE_HISTORY')
    for value in history:
        integer(value)
        need(value <= 10000, 'INCENTIVE_RATING')
    below = sum(1 for value in history if value < rating)
    equal = sum(1 for value in history if value == rating)
    need(equal > 0, 'INCENTIVE_RATING')
    return (below * 2 + equal) * 10000 // (2 * len(history))


def apply_calibration(rating, own_history, network_history, rater_buyer_lb):
    history = own_history if len(own_history) >= 8 else network_history
    calibrated = calibrated_bps(rating, history)
    weight = 0 if rater_buyer_lb < BAD_RATER_LB else calibrated
    return {'calibrated_bps': calibrated, 'weight_bps': weight, 'discounted': weight == 0,
            'history': 'RATER' if len(own_history) >= 8 else 'NETWORK', 'execution_authorized': False}


def inflation_monitor(previous, current):
    """Alert when top-box ratings rise more than 500 bps while the outcome bound is flat."""
    for row in (previous, current):
        integer(row['top_box_bps'])
        integer(row['outcome_lb_bps'])
        need(row['top_box_bps'] <= 10000 and row['outcome_lb_bps'] <= 10000, 'INCENTIVE_MONITOR')
    rise = current['top_box_bps'] - previous['top_box_bps']
    delta = current['outcome_lb_bps'] - previous['outcome_lb_bps']
    flat = abs(delta) <= 100
    return {'alert': rise > 500 and flat, 'top_box_rise_bps': rise, 'outcome_lb_delta_bps': delta,
            'flat_bound': flat, 'threshold_bps': 500, 'metric_not_a_rule': True,
            'execution_authorized': False}


def _level_stats(subject, receipts, trust, now, attested_day):
    rows = _owned(subject, receipts)
    summary = histogram(rows)
    trusted_rows = rows if trust is None else [row for row in rows if trust.get(row['counterparty'], 0) > 0]
    # A newcomer's failure against a weak buyer stays in the histogram and out of the level count.
    counted = []
    for row in trusted_rows:
        buyer_lb = row.get('counterparty_buyer_lb')
        weak = type(buyer_lb) is int and buyer_lb < BAD_RATER_LB
        if weak and row['outcome'] in {'DEFAULTED', 'CHALLENGED_LOST', 'PARTIAL'}:
            continue
        counted.append(row)
    recent = [row for row in counted if now - row['settled_day'] <= 100]
    half_year = [row for row in counted if now - row['settled_day'] <= 180]
    lost_recent = sum(1 for row in recent if row['outcome'] in {'CHALLENGED_LOST', 'DEFAULTED'})
    bound = wilson_lb_bps(histogram(counted)['positive_k'], histogram(counted)['settled'])
    bound_180 = wilson_lb_bps(histogram(half_year)['positive_k'], histogram(half_year)['settled']) if half_year else bound
    spread = diversity(counted, trust)
    age = 0 if attested_day is None else now - attested_day
    bond = any(type(row.get('forfeited_bond_day')) is int and now - row['forfeited_bond_day'] <= 180 for row in rows)
    return {'settled': len(counted), 'trusted_counterparties': len({row['counterparty'] for row in counted}),
            'recent': len(recent), 'diversity': spread['trusted'], 'lower_bound_bps': bound,
            'lower_bound_180_bps': bound_180, 'lost_recent': lost_recent, 'age': age,
            'forfeited_bond': bond, 'histogram_settled': summary['settled']}


def privileges(level):
    table = {
        'L0': {'sandbox': True, 'open_covenants': 3, 'value_band': 10, 'sponsored_first_fees': 5,
               'can_review': True, 'can_post': False, 'can_flag': False, 'can_invite': False,
               'can_hide': False, 'can_arbitrate': False, 'can_moderate': False},
        'L1': {'sandbox': False, 'can_post': True, 'can_flag': True, 'can_review': True,
               'can_invite': False, 'can_hide': False, 'can_arbitrate': False, 'can_moderate': False},
        'L2': {'sandbox': False, 'can_post': True, 'can_flag': True, 'can_invite': True,
               'can_publish_templates': True, 'small_claims': True, 'can_hide': False,
               'can_arbitrate': False, 'can_moderate': False},
        'L3': {'sandbox': False, 'can_hide_l0': True, 'can_arbitrate': True, 'can_curate': True,
               'can_vouch': True, 'can_moderate': False, 'demotable': True, 'grace_days': GRACE_DAYS},
        'L4': {'sandbox': False, 'can_moderate': True, 'can_propose_local_rules': True,
               'term': True, 'arbiter_pay': ARBITER_PAY},
    }
    need(level in table, 'INCENTIVE_LEVEL')
    return deepcopy(table[level])


def level(subject, receipts, attested, now, trust=None, attested_day=0, promoted_l3_day=None,
          elected=False, bootstrap_index=None):
    """L0–L4 as a view. Hosts may adopt it. It does not gate a native EXECUTE."""
    key(subject)
    integer(now)
    need(type(attested) is bool, 'INCENTIVE_ATTESTATION')
    if not attested:
        return {'level': None, 'reason': 'OWNER_ATTESTATION_REQUIRED', 'module': 'identity_facility',
                'execution_authorized': False, 'gates_execute': False}
    stats = _level_stats(subject, receipts, trust, now, attested_day)
    if bootstrap_index is not None:
        integer(bootstrap_index)
    bootstrap = bootstrap_index is not None and bootstrap_index < BOOTSTRAP_OWNERS
    reached = 'L0'
    if stats['settled'] >= 3 and stats['trusted_counterparties'] >= 3 and stats['age'] >= 7:
        reached = 'L1'
    if (stats['settled'] >= 20 and stats['diversity'] >= 10 and stats['lower_bound_bps'] >= 8000
            and stats['age'] >= 60):
        reached = 'L2'
        if stats['age'] >= 180 and stats['lower_bound_180_bps'] < 7000:
            reached = 'L1'
    l3 = (stats['recent'] >= 30 and stats['diversity'] >= 15 and stats['lower_bound_bps'] >= 9000
          and stats['lost_recent'] <= 2 and not stats['forfeited_bond'])
    if l3:
        reached = 'L3'
    grace = False
    if promoted_l3_day is not None:
        integer(promoted_l3_day)
        # Inside the 14 days after promotion the view stays at L3. After that it follows the receipts.
        if now < promoted_l3_day + GRACE_DAYS and LEVELS.index(reached) < LEVELS.index('L3'):
            reached = 'L3'
            grace = True
    if reached == 'L3' and elected and promoted_l3_day is not None and now >= promoted_l3_day + 180:
        reached = 'L4'
    if bootstrap and LEVELS.index(reached) < LEVELS.index('L1'):
        reached = 'L1'
    return {'level': reached, 'privileges': privileges(reached), 'stats': stats, 'grace': grace,
            'bootstrap': bootstrap and reached == 'L1' and stats['settled'] < 3,
            'gates_execute': False, 'reputation_balance': False, 'arbiter_pay': ARBITER_PAY,
            'execution_authorized': False}


def thompson_ppm(k, n, seed, identity):
    integer(k)
    integer(n)
    need(k <= n, 'INCENTIVE_SAMPLE')
    key(identity)
    draw = digest('COVENANT-EXPLORATION-0.1', {'seed': seed, 'identity': identity, 'k': k, 'n': n})
    first = int(draw[:16], 16) % 1_000_000_000 + 1
    second = int(draw[16:32], 16) % 1_000_000_000 + 1
    alpha = k + 1
    beta = n - k + 1
    return alpha * first * 1_000_000 // (alpha * first + beta * second)


def place_newcomers(ranked, pool, seed):
    """Reserve one shown slot in eight for a clean L0 or L1 provider. Organic order is unchanged."""
    key(seed)
    need(type(ranked) is list and len(ranked) <= 256, 'INCENTIVE_RANK')
    need(type(pool) is list and len(pool) <= 256, 'INCENTIVE_POOL')
    identities = [row['identity'] for row in ranked]
    need(len(identities) == len(set(identities)), 'INCENTIVE_RANK')
    waiting = []
    for row in pool:
        exact(row, 'identity level k n clean')
        key(row['identity'])
        need(row['level'] in {'L0', 'L1'}, 'INCENTIVE_LEVEL')
        integer(row['k'])
        integer(row['n'])
        need(row['k'] <= row['n'] and type(row['clean']) is bool, 'INCENTIVE_SAMPLE')
        if row['clean'] and row['identity'] not in identities:
            waiting.append(row)
    shown = []
    exploration = []
    displaced = []
    cursor = 0
    for index in range(len(ranked)):
        if index % EXPLORATION_STRIDE == EXPLORATION_STRIDE - 1 and waiting:
            pick = max(waiting, key=lambda row: (thompson_ppm(row['k'], row['n'], seed, row['identity']), row['identity']))
            waiting = [row for row in waiting if row['identity'] != pick['identity']]
            shown.append({'identity': pick['identity'], 'slot': 'NEWCOMER', 'level': pick['level']})
            exploration.append(pick['identity'])
            if cursor < len(ranked):
                displaced.append(ranked[cursor]['identity'])
        else:
            shown.append({'identity': ranked[cursor]['identity'], 'slot': 'ORGANIC', 'level': ranked[cursor].get('level')})
            cursor += 1
    while cursor < len(ranked):
        shown.append({'identity': ranked[cursor]['identity'], 'slot': 'ORGANIC', 'level': ranked[cursor].get('level')})
        cursor += 1
    return {'organic': [{'identity': row['identity']} for row in ranked], 'shown': shown,
            'exploration': exploration, 'displaced': displaced, 'stride': EXPLORATION_STRIDE,
            'organic_changed': False, 'payment_input': False, 'execution_authorized': False}


def export_history(subject, receipts, reviews=()):
    """Full export of covenants the subject was party to. Confidential rows stay out unless opted in."""
    rows = _owned(subject, receipts)
    revealed = []
    for review in reviews:
        if review.get('readable') is not True:
            continue
        if review.get('subject') != subject and review.get('actor') != subject:
            continue
        revealed.append({'actor': review['actor'], 'origin': review['origin'], 'result': review['result'],
                         'rating_bps': review['rating_bps'], 'role': review['role']})
    history = []
    for row in rows:
        item = {'covenant': row['covenant'], 'role': row['role'], 'context': row['context'],
                'outcome': row['outcome'], 'counterparty': row['counterparty'],
                'settled_day': row['settled_day'], 'value_band': _band(row['value']),
                'confidential': row['confidential']}
        if row['disclosed'] and row['opt_in']:
            item['value'] = row['value']
        history.append(item)
    return {'version': VERSION, 'protocol': PROTOCOL, 'rule_set': RULE_SET, 'subject': subject,
            'history': history, 'reviews': revealed, 'omitted': 'COUNTERPARTY_CONFIDENTIAL_UNLESS_OPT_IN',
            'values': 'BANDS_UNLESS_BOTH_DISCLOSE', 'reputation_balance': False,
            'execution_authorized': False}


def profile_from_export(exported, trust=None):
    """Any host recomputes the outcome view from the export alone."""
    exact(exported, 'version protocol rule_set subject history reviews omitted values reputation_balance execution_authorized')
    need(exported['version'] == VERSION and exported['protocol'] == PROTOCOL, 'INCENTIVE_EXPORT')
    receipts = []
    for row in exported['history']:
        value = row['value'] if 'value' in row else 2 ** row['value_band'] if row['value_band'] else 0
        receipts.append({'covenant': row['covenant'], 'role': row['role'], 'context': row['context'],
                         'counterparty': row['counterparty'], 'value': value, 'outcome': row['outcome'],
                         'settled_day': row['settled_day'], 'confidential': row['confidential'],
                         'opt_in': True, 'disclosed': 'value' in row, 'party': exported['subject']})
    profile = outcome_profile(exported['subject'], receipts, trust)
    profile['reviews'] = deepcopy(exported['reviews'])
    profile['recomputed_from_export'] = True
    return profile


def concentration_warning(weights, threshold_bps):
    """Warn when one weight is strictly above ``threshold_bps`` of the total. Equality does not warn."""
    need(type(weights) is dict and 1 <= len(weights) <= 4096, 'POOL_WEIGHT')
    total = 0
    for member, weight in weights.items():
        key(member)
        integer(weight, True)
        total += weight
    integer(threshold_bps)
    need(threshold_bps <= 10000, 'POOL_CONCENTRATION')
    need(total <= 2**53 - 1, 'POOL_WEIGHT')
    warned = sorted(member for member, weight in weights.items() if weight * 10000 > threshold_bps * total)
    return {'warned': warned, 'threshold_bps': threshold_bps, 'total_weight': total, 'execution_authorized': False}


def within_rate(events, now, limit, window=3600):
    """Admit one event when fewer than ``limit`` fall in the trailing window [now - window, now].

    Pure: it returns the admitted window (old stamps dropped, ``now`` added). The
    caller stores that list and passes it back; nothing here persists it.
    """
    integer(now)
    integer(limit, True)
    integer(window, True)
    need(type(events) is list and len(events) <= 4096, 'POOL_EVENTS')
    recent = []
    for stamp in events:
        integer(stamp)
        if now - window <= stamp <= now:
            recent.append(stamp)
    if len(recent) >= limit:
        raise ValueError('RATE_LIMIT')
    return recent + [now]
