"""AAP reference ``urn:aap:ref:0.1``: one small, verifiable pointer to an agreement.

A deal is a promise both sides sign. Proof shows it was kept. If it was not,
there is a fair way to fix it. A reference is how any other protocol points
at that deal: the content id of the exact agreement, optionally the content
id of a receipt, one locator hint and one signature. It is a pointer to
evidence, never permission: it cannot sign, pay, release escrow, install
anything or make an agreement binding.

One value, two spellings:

* compact, at most 255 bytes, so it fits one DNS TXT character-string
  (RFC 1035 section 3.3), an HTTP header or a metadata string::

      urn:aap:ref:0.1:<agreement>[;r=<receipt>][;l=<locator>][;s=<signature>]

* JSON, members in RFC 8785 order, absent members omitted::

      {"agreement": ..., "locator": ..., "profile": "urn:aap:ref:0.1", "receipt": ..., "signature": ...}

Rules:

* ``agreement`` and ``receipt`` are AAP Core 1.0 content identifiers (Core
  section 5.2): CIDv1, raw codec 0x55, sha2-256, base32 lower case, 59
  characters, in the one form Core emits. The bytes hashed are the exact
  record bytes; a JSON record is hashed in its RFC 8785 form, which for every
  Core-profile value is Core canonical JSON (Core section 3.5), so the
  agreement id of an AAP envelope is its existing content id. The same 32
  bytes are an LCP ``atrHash`` when the record is an ATR, and an IPFS raw CID,
  so a content-addressed store can serve the agreement without any locator.
  A verifier holding bytes accepts either their exact digest or, when the bytes
  are JSON, the digest of their RFC 8785 form, and reports which one matched.
* ``locator`` is one optional hint: an ``https`` URL without query, fragment
  or user information, or a DID. Nothing here fetches it. A reader hashes what
  it obtained elsewhere and compares; a locator never vouches for content.
* ``signature`` is optional Ed25519 (RFC 8032) by a key the verifier already
  expects, usually a party key the agreement names. The message is Core
  section 4.2's, with label ``AAP-REF-0.1`` and the unsigned compact form as
  the body: ASCII("AAP-REF-0.1") || 0x00 || canonical(<unsigned compact>).
  It is written as unpadded base64url (RFC 4648 section 5), 86 characters,
  so a signed reference still fits 255 bytes. A signature attributes the
  pointer to a key. It does not bind the pointer to the transaction that
  carries it, and it is not assent to the agreement.
* Unknown JSON members are inert: reported, never interpreted, never signed,
  never written back. The compact grammar is closed; a change of meaning is a
  new profile string, and readers of 0.1 treat that string as unsupported.
"""
import argparse
import base64
import json
import re
import sys
import time

from covenant_agent.cid import cid_from_bytes, parse_cid
from . import atr, interop_codec
from .crypto import canonical, need, sign as core_sign, verify as core_verify
from covenant_language.key_validation import valid_ed25519_key

PROFILE = 'urn:aap:ref:0.1'
PREFIX = PROFILE + ':'
FAMILY = 'urn:aap:ref:'
LABEL = 'AAP-REF-0.1'
MATURITY = 'experimental'
MAX_COMPACT = 255
MAX_JSON = 4096
MAX_UNKNOWN = 16
MAX_RECORD = 4_000_000
MAX_KEYS = 16
MEMBERS = ('profile', 'agreement', 'receipt', 'locator', 'signature')
PARAMETERS = (('r', 'receipt'), ('l', 'locator'), ('s', 'signature'))
SCHEMA_URL = 'https://covenant-common.github.io/covenant-docs/schemas/aap-ref-0.1.json'
REFERENCE_DOC = 'docs/EMBEDDING.html#errors'
CID = re.compile(r'b[a-z2-7]{58}\Z')
SIGNATURE = re.compile(r'[A-Za-z0-9_-]{86}\Z')
LOCATOR_CHARS = re.compile(r"[A-Za-z0-9._~%:@/!$&()*+=-]+\Z")
HTTPS = re.compile(r'https://[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?(:[1-9][0-9]{0,4})?(/[A-Za-z0-9._~%:@/!$&()*+=-]*)?\Z')
DID = re.compile(r'did:[a-z0-9]{1,32}:([A-Za-z0-9._%-]*:)*[A-Za-z0-9._%-]+\Z')
PERCENT = re.compile(r'%(?![0-9A-Fa-f]{2})')
FLAGS = {'authority_granted': False, 'assent_verified': False, 'payment_verified': False,
         'delivery_verified': False, 'execution_authorized': False, 'network_accessed': False}

REMEDIATION = {
    'REF_TYPE': 'Pass the compact string urn:aap:ref:0.1:... or its JSON object; nothing else is a reference.',
    'REF_PREFIX': 'Start the compact form with urn:aap:ref:0.1: followed by the agreement content id.',
    'REF_PROFILE': 'Use profile urn:aap:ref:0.1. A newer profile is inert to this reader; keep the value unchanged and use a reader for that profile.',
    'REF_FORMAT': 'Write the parameters once each, in the order r, l, s, as name=value after a semicolon, with nothing else.',
    'REF_TOO_LONG': 'Keep the compact form within 255 bytes: shorten or drop the locator, since the content id already addresses the agreement.',
    'REF_CID': 'Use the 59-character Core content id: b followed by base32 lower case of 0x01 0x55 0x12 0x20 and the SHA-256 digest.',
    'REF_LOCATOR': 'Use an https URL with a lower-case host and no query, fragment, user information, comma or semicolon, or a DID.',
    'REF_SIGNATURE_ENCODING': 'Write the Ed25519 signature as 86 characters of unpadded base64url.',
    'REF_SIGNATURE': 'The signature does not verify under any expected key. Obtain the reference again from the signer; never widen the expected keys to make it pass.',
    'REF_SIGNATURE_REQUIRED': 'This check needs a signed reference. Ask a party to the agreement to sign the reference with its own key.',
    'REF_SIGNED': 'The reference is already signed. Keep the signed value, or start from the unsigned reference to sign it again.',
    'REF_KEYS': 'Pass 1 to 16 expected Ed25519 public keys as 64-character lower-case hex, obtained apart from the reference.',
    'REF_AGREEMENT_MISMATCH': 'The agreement you hold is not the one referenced. Obtain the exact referenced agreement; do not edit the reference to match.',
    'REF_RECEIPT_MISMATCH': 'The receipt you hold is not the one referenced. Obtain the exact referenced receipt; do not edit the reference to match.',
    'REF_RECORD': 'Pass the agreement or receipt as its exact bytes (1 byte to 4,000,000 bytes) or as a JSON object or array.',
    'REF_JSON': 'Pass one JSON object of at most 4096 bytes with string members agreement, optional receipt, locator and signature, and at most 16 other members.',
}
HAPPENED = {
    'REF_TYPE': 'The value is neither a compact reference string nor a reference object.',
    'REF_PREFIX': 'The string does not start with the reference profile urn:aap:ref:0.1.',
    'REF_PROFILE': 'The object names a profile this reader does not implement.',
    'REF_FORMAT': 'The compact form has an unknown, repeated, misordered or empty parameter, or is not canonical.',
    'REF_TOO_LONG': 'The compact form is longer than 255 bytes.',
    'REF_CID': 'A content id is not the canonical Core content identifier.',
    'REF_LOCATOR': 'The locator is not an allowed https URL or DID.',
    'REF_SIGNATURE_ENCODING': 'The signature is not 86 characters of base64url encoding 64 bytes.',
    'REF_SIGNATURE': 'The signature does not verify under any expected key.',
    'REF_SIGNATURE_REQUIRED': 'The reference has no signature and the check requires one.',
    'REF_SIGNED': 'The reference already carries a signature.',
    'REF_KEYS': 'The expected keys are missing, malformed or too many.',
    'REF_AGREEMENT_MISMATCH': 'The supplied agreement hashes to a different content id.',
    'REF_RECEIPT_MISMATCH': 'The supplied receipt hashes to a different content id, or the reference names no receipt.',
    'REF_RECORD': 'The supplied record is empty, too large or not bytes or JSON.',
    'REF_JSON': 'The reference object is malformed or too large.',
}
RETRY_HELPS = frozenset()


def remediation(code):
    return REMEDIATION.get(code, 'Inspect describe() and supply the exact documented shape.')


def explain(code):
    """What happened, what to do next, whether retrying helps and where the reference entry is."""
    need(type(code) is str and code in REMEDIATION, 'REF_TYPE')
    return {'code': code, 'what_happened': HAPPENED[code], 'fix': REMEDIATION[code],
            'retry_helps': code in RETRY_HELPS, 'reference': REFERENCE_DOC}


def b64url(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _signature_bytes(text):
    need(type(text) is str and SIGNATURE.fullmatch(text) is not None, 'REF_SIGNATURE_ENCODING')
    raw = base64.urlsafe_b64decode(text + '==')
    need(len(raw) == 64 and b64url(raw) == text, 'REF_SIGNATURE_ENCODING')
    return raw


def check_cid(value):
    """The canonical Core content id (one spelling per digest), or REF_CID."""
    need(type(value) is str and CID.fullmatch(value) is not None, 'REF_CID')
    try:
        digest = parse_cid(value)
    except ValueError:
        raise ValueError('REF_CID') from None
    need(cid_from_digest(digest.hex()) == value, 'REF_CID')
    return value


def cid_from_digest(hex_digest):
    """The Core content id naming a 32-byte SHA-256 digest given as 64 lower-case hex."""
    need(type(hex_digest) is str and re.fullmatch(r'[0-9a-f]{64}', hex_digest) is not None, 'REF_CID')
    packed = bytes([1, 0x55, 0x12, 0x20]) + bytes.fromhex(hex_digest)
    return 'b' + base64.b32encode(packed).decode('ascii').lower().rstrip('=')


def digest_of(cid):
    """The 64 lower-case hex digits of the SHA-256 a content id names."""
    return parse_cid(check_cid(cid)).hex()


def content_id(record):
    """Core content id of exact bytes, or of a JSON value in its RFC 8785 form."""
    if type(record) in (bytes, bytearray):
        need(0 < len(record) <= MAX_RECORD, 'REF_RECORD')
        return cid_from_bytes(bytes(record))
    need(type(record) in (dict, list), 'REF_RECORD')
    try:
        raw = interop_codec.jcs(record, max_bytes=MAX_RECORD)
    except (ValueError, RecursionError):
        raise ValueError('REF_RECORD') from None
    return cid_from_bytes(raw)


def match(record, cid, code):
    """How a held record matches a content id: its exact bytes, or (for JSON bytes) its RFC 8785 form."""
    if content_id(record) == cid:
        return 'EXACT_BYTES' if type(record) in (bytes, bytearray) else 'RFC8785_JSON'
    if type(record) in (bytes, bytearray):
        try:
            value = interop_codec.parse(bytes(record), max_bytes=MAX_RECORD, max_depth=64, max_nodes=200000,
                                        max_text=MAX_RECORD)
        except ValueError:
            value = None
        if type(value) in (dict, list) and content_id(value) == cid:
            return 'RFC8785_JSON'
    raise ValueError(code)


def check_locator(value):
    need(type(value) is str and 0 < len(value) <= MAX_COMPACT and LOCATOR_CHARS.fullmatch(value) is not None
         and PERCENT.search(value) is None, 'REF_LOCATOR')
    if value.startswith('https://'):
        need(HTTPS.fullmatch(value) is not None and atr.is_https_link(value), 'REF_LOCATOR')
        host, _, port = value[8:].split('/', 1)[0].partition(':')
        need('..' not in host and all(0 < len(label) <= 63 for label in host.split('.')), 'REF_LOCATOR')
        need(port == '' or int(port) <= 65535, 'REF_LOCATOR')
    else:
        need(DID.fullmatch(value) is not None, 'REF_LOCATOR')
    return value


def _validate(ref):
    """A reference object with known members only, each checked; returns a clean copy."""
    need(type(ref) is dict, 'REF_JSON')
    need(set(ref) <= set(MEMBERS), 'REF_JSON')
    need(ref.get('profile') == PROFILE, 'REF_PROFILE')
    need('agreement' in ref, 'REF_JSON')
    out = {'profile': PROFILE, 'agreement': check_cid(ref['agreement'])}
    if 'receipt' in ref:
        out['receipt'] = check_cid(ref['receipt'])
    if 'locator' in ref:
        out['locator'] = check_locator(ref['locator'])
    if 'signature' in ref:
        _signature_bytes(ref['signature'])
        out['signature'] = ref['signature']
    return out


def _compact(ref):
    text = PREFIX + ref['agreement']
    for short, member in PARAMETERS:
        if member in ref:
            text += ';' + short + '=' + ref[member]
    need(len(text) <= MAX_COMPACT, 'REF_TOO_LONG')
    return text


def reference(agreement, *, receipt=None, locator=None):
    """An unsigned reference. ``agreement`` and ``receipt`` are content ids, exact bytes or JSON values."""
    ref = {'profile': PROFILE, 'agreement': check_cid(agreement) if type(agreement) is str else content_id(agreement)}
    if receipt is not None:
        ref['receipt'] = check_cid(receipt) if type(receipt) is str else content_id(receipt)
    if locator is not None:
        ref['locator'] = check_locator(locator)
    _compact(ref)
    return ref


def encode(ref):
    """The compact form of a reference object (writers accept known members only)."""
    return _compact(_validate(ref))


def decode(text):
    """The reference object of a canonical compact string; anything else is refused."""
    need(type(text) is str, 'REF_TYPE')
    need(len(text) <= MAX_COMPACT, 'REF_TOO_LONG')
    need(text.isascii(), 'REF_FORMAT')
    if not text.startswith(PREFIX):
        need(not text.startswith(FAMILY), 'REF_PROFILE')
        raise ValueError('REF_PREFIX')
    parts = text[len(PREFIX):].split(';')
    ref = {'profile': PROFILE, 'agreement': check_cid(parts[0])}
    order = [short for short, _ in PARAMETERS]
    position = 0
    names = dict(PARAMETERS)
    for part in parts[1:]:
        short, separator, value = part.partition('=')
        need(separator == '=' and short in order[position:] and value != '', 'REF_FORMAT')
        position = order.index(short) + 1
        ref[names[short]] = value
    clean = _validate(ref)
    need(_compact(clean) == text, 'REF_FORMAT')
    return clean


def parse(value):
    """Read a compact string or a JSON object. Unknown members are inert and reported, never kept."""
    if type(value) is str:
        return {'reference': decode(value), 'ignored': []}
    need(type(value) is dict, 'REF_TYPE')
    need(len(value) <= len(MEMBERS) + MAX_UNKNOWN, 'REF_JSON')
    unknown = [name for name in value if name not in MEMBERS]
    need(len(unknown) <= MAX_UNKNOWN and all(type(name) is str and 0 < len(name) <= 64 for name in unknown), 'REF_JSON')
    unknown.sort()
    if 'profile' in value and value['profile'] != PROFILE:
        need(not (type(value['profile']) is str and value['profile'].startswith(FAMILY)), 'REF_PROFILE')
    known = {name: value[name] for name in MEMBERS if name in value}
    need(all(type(item) is str for item in known.values()), 'REF_JSON')
    return {'reference': _validate(known), 'ignored': unknown}


def loads(raw):
    """A reference from received JSON text or UTF-8 bytes, bounded before decoding."""
    try:
        value = interop_codec.parse(raw, max_bytes=MAX_JSON, max_depth=4, max_nodes=64, max_text=MAX_JSON)
    except ValueError:
        raise ValueError('REF_JSON') from None
    return parse(value)


def to_json(ref):
    """RFC 8785 text of a reference object (equal to Core canonical JSON: every member is ASCII)."""
    return interop_codec.jcs(_validate(ref)).decode('ascii')


def unsigned(ref):
    clean = _validate(ref)
    clean.pop('signature', None)
    return clean


def signing_message(ref):
    """The exact bytes a signer signs: Core section 4.2 with label AAP-REF-0.1 and the unsigned compact body."""
    return LABEL.encode('ascii') + b'\x00' + canonical(_compact(unsigned(ref)))


def sign(ref, private_key):
    """Explicit local owner action; never exposed as a tool. Signing a pointer is not assent to the agreement."""
    clean = _validate(ref)
    need('signature' not in clean, 'REF_SIGNED')
    signature = bytes.fromhex(core_sign(private_key, LABEL, _compact(clean)))
    out = {**clean, 'signature': b64url(signature)}
    _compact(out)
    return out


def _keys(keys):
    need(type(keys) in (list, tuple) and 0 < len(keys) <= MAX_KEYS, 'REF_KEYS')
    for key in keys:
        need(type(key) is str and re.fullmatch(r'[0-9a-f]{64}', key) is not None and valid_ed25519_key(key), 'REF_KEYS')
    return list(dict.fromkeys(keys))


def check_signature(ref, keys):
    """The expected key that signed the reference, or REF_SIGNATURE."""
    clean = _validate(ref)
    need('signature' in clean, 'REF_SIGNATURE_REQUIRED')
    signature = _signature_bytes(clean['signature']).hex()
    body = _compact(unsigned(clean))
    for key in _keys(keys):
        try:
            core_verify(key, LABEL, body, signature)
        except ValueError:
            continue
        return key
    raise ValueError('REF_SIGNATURE')


def verify(value, *, agreement=None, receipt=None, keys=None, require_signature=False):
    """Check a reference against the agreement and receipt you hold, and its signature against keys you expect.

    A matching digest shows you hold the referenced bytes. It does not show that
    both parties assented, that anything was paid or delivered, or that the
    locator is honest: those are separate checks, and every flag below stays false.
    """
    read = parse(value)
    ref = read['reference']
    report = {'profile': PROFILE, 'reference': _compact(ref), 'agreement': ref['agreement'],
              'agreement_sha256': digest_of(ref['agreement']), 'agreement_match': 'NOT_SUPPLIED',
              'receipt': ref.get('receipt'), 'receipt_match': 'NOT_SUPPLIED', 'locator': ref.get('locator'),
              'locator_fetched': False, 'signature': 'ABSENT', 'signer': None, 'ignored': read['ignored'],
              'maturity': MATURITY, **FLAGS}
    if agreement is not None:
        report['agreement_form'] = match(agreement, ref['agreement'], 'REF_AGREEMENT_MISMATCH')
        report['agreement_match'] = 'MATCHED'
    if receipt is not None:
        need('receipt' in ref, 'REF_RECEIPT_MISMATCH')
        report['receipt_form'] = match(receipt, ref['receipt'], 'REF_RECEIPT_MISMATCH')
        report['receipt_match'] = 'MATCHED'
    if require_signature:
        need('signature' in ref, 'REF_SIGNATURE_REQUIRED')
        need(keys is not None, 'REF_KEYS')
    if keys is not None:
        _keys(keys)
    if 'signature' in ref:
        if keys is None:
            report['signature'] = 'NOT_CHECKED_NO_EXPECTED_KEY'
        else:
            report['signer'] = check_signature(ref, keys)
            report['signature'] = 'VERIFIED_UNDER_EXPECTED_KEY'
    report['status'] = 'AGREEMENT_MATCHED' if report['agreement_match'] == 'MATCHED' else 'WELL_FORMED_NOT_MATCHED'
    return report


def atr_hash(ref):
    """The LCP atrHash spelling of the agreement digest (equal when the agreement record is the ATR)."""
    return '0x' + digest_of(_validate(ref)['agreement'])


def compact_pattern():
    return (r'^urn:aap:ref:0\.1:b[a-z2-7]{58}(;r=b[a-z2-7]{58})?(;l=[A-Za-z0-9._~%:@/!$&()*+=-]+)?'
            r'(;s=[A-Za-z0-9_-]{86})?$')


def json_schema():
    """JSON Schema 2020-12 of the JSON form. Unknown members are allowed and inert, within maxProperties."""
    cid = {'type': 'string', 'pattern': '^b[a-z2-7]{58}$', 'minLength': 59, 'maxLength': 59}
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': SCHEMA_URL,
            'title': 'AAP reference ' + PROFILE,
            'description': 'A pointer to an agreement and optionally its receipt. Evidence, never authority. '
                           'Readers ignore members they do not know; the compact form is the same value.',
            'type': 'object', 'required': ['profile', 'agreement'], 'maxProperties': len(MEMBERS) + MAX_UNKNOWN,
            'properties': {'profile': {'const': PROFILE}, 'agreement': cid, 'receipt': cid,
                           'locator': {'type': 'string', 'minLength': 1, 'maxLength': 177,
                                       'pattern': r'^(https://[a-z0-9][a-z0-9.:-]*(/[A-Za-z0-9._~%:@/!$&()*+=-]*)?'
                                                  r'|did:[a-z0-9]{1,32}:[A-Za-z0-9._%:-]+)$'},
                           'signature': {'type': 'string', 'pattern': '^[A-Za-z0-9_-]{86}$'}}}


def benchmark(count=2000):
    """Local capacity: compact decodes, re-encodes and agreement matches per second on this machine."""
    need(type(count) is int and 1 <= count <= 200000, 'REF_TYPE')
    agreement = {'profile': 'benchmark', 'n': 1}
    text = encode(reference(agreement, receipt=b'receipt', locator='https://example.com/a'))
    started = time.perf_counter()
    for _ in range(count):
        encode(decode(text))
    middle = time.perf_counter()
    for _ in range(count):
        verify(text, agreement=agreement)
    finished = time.perf_counter()
    return {'count': count, 'decode_encode_per_second': int(count / max(middle - started, 1e-9)),
            'verify_per_second': int(count / max(finished - middle, 1e-9)), 'compact_bytes': len(text),
            'network_accessed': False}


def describe():
    return {'module': 'covenant_chain.aap_reference', 'profile': PROFILE, 'maturity': MATURITY,
            'model': 'A deal is a promise both sides sign. Proof shows it was kept. If it was not, there is a fair way to fix it.',
            'job': 'Keep records: show, export, verify',
            'compact': PREFIX + '<agreement>[;r=<receipt>][;l=<locator>][;s=<signature>]',
            'compact_pattern': compact_pattern(), 'max_compact_bytes': MAX_COMPACT,
            'json_members': list(MEMBERS), 'json_schema': SCHEMA_URL,
            'content_id': 'AAP Core 1.0 section 5.2: CIDv1 raw sha2-256 base32 of the exact bytes, or of RFC 8785 JSON',
            'signature': 'Ed25519 (RFC 8032) over Core section 4.2: ' + LABEL + ' 0x00 canonical(unsigned compact); '
                         'unpadded base64url; verified only under keys the caller expects',
            'locator': 'https URL (no query, fragment or userinfo) or DID; never fetched here',
            'limits': {'compact_bytes': MAX_COMPACT, 'json_bytes': MAX_JSON, 'unknown_members': MAX_UNKNOWN,
                       'record_bytes': MAX_RECORD, 'expected_keys': MAX_KEYS},
            'errors': {code: explain(code) for code in REMEDIATION}, **FLAGS}


def main(argv=None):
    parser = argparse.ArgumentParser(prog='python -m covenant_chain.aap_reference',
                                     description='Read, check and describe AAP references. Never fetches, signs or pays.')
    parser.add_argument('reference', nargs='?', help='a compact reference, or - to read a JSON object from stdin')
    parser.add_argument('--agreement', help='path of the exact agreement bytes to compare')
    parser.add_argument('--receipt', help='path of the exact receipt bytes to compare')
    parser.add_argument('--key', action='append', help='an expected Ed25519 public key (hex); repeatable')
    parser.add_argument('--describe', action='store_true', help='print the profile description')
    parser.add_argument('--bench', type=int, metavar='COUNT', help='measure local decode and verify rates')
    args = parser.parse_args(argv)

    def read(path):
        with open(path, 'rb') as handle:
            raw = handle.read(MAX_RECORD + 1)
        need(0 < len(raw) <= MAX_RECORD, 'REF_RECORD')
        return raw

    try:
        if args.describe:
            result = describe()
        elif args.bench is not None:
            result = benchmark(args.bench)
        else:
            need(args.reference is not None, 'REF_TYPE')
            value = args.reference
            if value == '-':
                value = loads(sys.stdin.buffer.read(MAX_JSON + 1))['reference']
            result = verify(value, agreement=read(args.agreement) if args.agreement else None,
                            receipt=read(args.receipt) if args.receipt else None, keys=args.key)
    except (ValueError, OSError) as error:
        code = str(error) if str(error) in REMEDIATION else 'REF_RECORD' if isinstance(error, OSError) else 'REF_TYPE'
        print(json.dumps({'status': 'REFUSED', **explain(code)}, sort_keys=True))
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
